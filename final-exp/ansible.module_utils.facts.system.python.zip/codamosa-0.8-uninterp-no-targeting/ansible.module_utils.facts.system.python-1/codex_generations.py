

# Generated at 2022-06-20 19:42:46.201987
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    pfc = PythonFactCollector()
    assert pfc.name == "python"

# Generated at 2022-06-20 19:42:48.391638
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    res = c.collect()
    assert isinstance(res, dict)
    assert 'python' in res
    assert 'version' in res['python']

# Generated at 2022-06-20 19:42:49.411296
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()

# Generated at 2022-06-20 19:42:52.847716
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    assert len(PythonFactCollector._fact_ids) == 1
    assert 'python' in PythonFactCollector._fact_ids

# Generated at 2022-06-20 19:42:58.843334
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    facts_dict = python_collector.collect()

    assert type(facts_dict["python"]["version_info"]) is list
    assert type(facts_dict["python"]["version"]) is dict
    assert type(facts_dict["python"]["has_sslcontext"]) is bool

    try:
        type(facts_dict["python"]["type"]) is str
    except AttributeError:
        assert type(facts_dict["python"]["type"]) is unicode

# Generated at 2022-06-20 19:43:04.422560
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = pc.collect()
    assert 'python' in facts.keys()
    assert 'version' in facts['python'].keys()
    assert 'version_info' in facts['python'].keys()
    assert 'executable' in facts['python'].keys()
    assert 'has_sslcontext' in facts['python'].keys()
    assert 'type' in facts['python'].keys()

# Generated at 2022-06-20 19:43:10.634126
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)
    assert isinstance(facts['python']['has_sslcontext'], bool)
    assert isinstance(facts['python']['type'], str) or facts['python']['type'] is None

# Generated at 2022-06-20 19:43:12.177324
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    kwargs = {'module': None, 'collected_facts': None}
    assert len(PythonFactCollector().collect(**kwargs)) == 1

# Generated at 2022-06-20 19:43:15.193634
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collectors import PythonFactCollector
    python_fact = PythonFactCollector()
    assert python_fact.__class__.__name__ == 'PythonFactCollector'

# Generated at 2022-06-20 19:43:26.182524
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect({}, {})
    assert result == {'python': {
                        'executable': sys.executable,
                        'has_sslcontext': HAS_SSLCONTEXT,
                        'type': sys.implementation.name,
                        'version': {
                            'major': sys.version_info[0],
                            'minor': sys.version_info[1],
                            'micro': sys.version_info[2],
                            'releaselevel': sys.version_info[3],
                            'serial': sys.version_info[4]
                        },
                        'version_info': list(sys.version_info)
                    }
    }

# Generated at 2022-06-20 19:43:32.955901
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f.name == 'python'
    assert f._fact_ids == set()
    assert f._fact_class == 'default'

# Generated at 2022-06-20 19:43:40.863329
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'
    py_collector_facts = py_collector.collect()
    assert py_collector_facts['python']['version']['major'] == sys.version_info[0]
    assert py_collector_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_collector_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_collector_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_collector_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-20 19:43:50.792620
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create fake module to get type/subversion
    fake_module = type('fake_module', (object,), {'subversion': ['CPython', '2.7.5'],
                                                  'implementation': type('implementation', (object,), {'name': 'CPython'})})

    pfc = PythonFactCollector()
    pfc.collect(fake_module)
    assert pfc.get_facts()['python']['type'] == 'CPython'
    assert pfc.get_facts()['python']['version']['major'] == 2
    assert pfc.get_facts()['python']['version']['minor'] == 7
    assert pfc.get_facts()['python']['version']['micro'] == 5



# Generated at 2022-06-20 19:44:01.319482
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test when using python executable
    import ansible.utils.plugins
    fact_collector_class = ansible.utils.plugins.fact_collector_functions['python']
    fact_collector_instance = fact_collector_class()

    fact_dict = fact_collector_instance.collect()
    expected_sys_version_info = [2, 7, 12, 'final', 0]
    expected_executable = sys.executable
    expected_sslcontext = True

    assert fact_dict['python']['version']['major'] == expected_sys_version_info[0]
    assert fact_dict['python']['version']['minor'] == expected_sys_version_info[1]
    assert fact_dict['python']['version']['micro'] == expected_sys_version_info[2]

# Generated at 2022-06-20 19:44:02.501186
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    assert p.collect() is not None

# Generated at 2022-06-20 19:44:04.955076
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:44:05.819618
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-20 19:44:09.378452
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Unit test for constructor of class PythonFactCollector"""
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert isinstance(collector._fact_ids, set)
    assert len(collector._fact_ids) == 0

# Unit test collection of Python facts

# Generated at 2022-06-20 19:44:17.922634
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect() == { 'python': {
        'executable': '/usr/bin/python2.7',
        'version': {
            'micro': 5,
            'major': 2,
            'minor': 7,
            'releaselevel': 'final',
            'serial': 0
        },
        'has_sslcontext': True,
        'version_info': [2, 7, 5, 'final', 0],
    'type': 'CPython'}}

# Generated at 2022-06-20 19:44:20.524973
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """ Unit Test for class PythonFactCollector
    """
    assert PythonFactCollector.name == 'python'
    assert len(PythonFactCollector._fact_ids) == 0

# Generated at 2022-06-20 19:44:25.039779
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 19:44:27.228472
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''
    Test constructor of class PythonFactCollector.
    '''
    p = PythonFactCollector()

    assert isinstance(p, BaseFactCollector)
    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-20 19:44:34.759624
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    python_fact = PythonFactCollector()
    python_facts = python_fact.collect()
    assert 'python' == python_fact.name
    assert set(python_facts.keys()) == set(['python'])
    assert set(python_facts['python'].keys()) == set(['version', 'version_info', 'executable', 'has_sslcontext', 'type'])
    assert set(python_facts['python']['version'].keys()) == set(['major', 'minor', 'micro', 'releaselevel', 'serial'])
    assert set(python_facts['python']['version_info']) == set(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:44:37.198545
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

    assert PythonFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:44:43.190790
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert result == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 15, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 15, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': 'CPython'}}


# Generated at 2022-06-20 19:44:53.565577
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector(None, None)
    result = python_fact.collect()

    assert 'python' in result
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:44:55.854493
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc.collect()

# Generated at 2022-06-20 19:44:58.513118
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    tested_python_fact_collector = PythonFactCollector()
    assert tested_python_fact_collector.name == 'python'
    assert tested_python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:45:07.424636
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Define the class instance
    python_fact_collector = PythonFactCollector()

    # Get the collection
    collection = python_fact_collector.collect()

    # Test if collection is a dict and containts the key 'python'
    assert isinstance(collection, dict)
    assert 'python' in collection.keys()

    # Test collection['python'] value
    assert 'version' in collection['python'].keys()
    assert 'version_info' in collection['python'].keys()
    assert 'executable' in collection['python'].keys()
    assert 'has_sslcontext' in collection['python'].keys()
    assert 'type' in collection['python'].keys()

    # Test collection['python']['version'] value
    assert 'major' in collection['python']['version'].keys()

# Generated at 2022-06-20 19:45:08.929098
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_col = PythonFactCollector()
    assert python_col.name == 'python'


# Generated at 2022-06-20 19:45:18.621901
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set(['python'])

# Generated at 2022-06-20 19:45:28.725734
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    pyfacts = pyfc.collect({})

    assert pyfacts['python']['version']['major'] == sys.version_info[0]
    assert pyfacts['python']['version']['minor'] == sys.version_info[1]
    assert pyfacts['python']['version']['micro'] == sys.version_info[2]
    assert pyfacts['python']['version']['releaselevel'] == sys.version_info[3]
    assert pyfacts['python']['version']['serial'] == sys.version_info[4]
    assert pyfacts['python']['version_info'] == sys.version_info
    assert pyfacts['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:45:31.579269
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-20 19:45:39.686124
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = AnsibleModuleMock()
    collected_facts = {}
    python_facts = PythonFactCollector().collect(module, collected_facts)
    assert python_facts == {
        "python": {
            "type": "CPython",
            "executable": sys.executable,
            "version": {"micro": 0, "releaselevel": "final", "serial": 0, "major": 2, "minor": 7},
            "version_info": [2, 7, 0, 'final', 0],
            "has_sslcontext": HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-20 19:45:46.581256
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a new instance of class PythonFactCollector
    obj = PythonFactCollector()

    # Create a new instance of class AnsibleModuleMock with correct parameters
    module = AnsibleModuleMock({}, {})

    # Add an empty fact list to the class instance
    fact_list = []

    # Call method collect of the class PythonFactCollector
    obj.collect(module, fact_list)

    # Test if the fact list is empty
    assert fact_list == []

# Generated at 2022-06-20 19:45:53.121857
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    try:
        # Check if we have SSLContext support
        from ssl import create_default_context
        has_sslcontext = True
    except ImportError:
        has_sslcontext = False

    try:
        # Check if we have SSLContext support
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        has_sslcontext = True
    except ImportError:
        has_sslcontext = False

    python_facts = PythonFactCollector()
    python_facts = python_facts.collect()
    assert 'python' in python_facts

    if sys.version_info[0] < 3:
        assert python_facts['python']['type'] == 'cpython'

# Generated at 2022-06-20 19:45:54.591964
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'
    assert py_collector._fact_ids == set()

# Generated at 2022-06-20 19:46:06.328294
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf_collector = PythonFactCollector()
    python_facts = pf_collector.collect()

    assert python_facts is not None
    assert 'python' in python_facts.keys()
    assert 'version' in python_facts['python'].keys()
    assert 'major' in python_facts['python']['version'].keys()
    assert 'minor' in python_facts['python']['version'].keys()
    assert 'micro' in python_facts['python']['version'].keys()
    assert 'releaselevel' in python_facts['python']['version'].keys()
    assert 'serial' in python_facts['python']['version'].keys()
    assert 'version_info' in python_facts['python'].keys()

# Generated at 2022-06-20 19:46:07.225181
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:46:09.547339
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert isinstance(python_fact, PythonFactCollector)

# Generated at 2022-06-20 19:46:26.362943
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert facts['python']['version']['releaselevel'] == 'final'
    assert facts['python']['version_info'][0] >= 2
    assert hasattr(facts['python'], 'executable')
    assert hasattr(facts['python'], 'type')

# Generated at 2022-06-20 19:46:28.059545
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    assert isinstance(python_collector.collect(), dict)

# Generated at 2022-06-20 19:46:35.326346
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test AnsibleModule argument_spec"""

    # Create a mock module
    import ansible.module_utils.basic
    mock_module = type('AnsibleModule', (object,), dict(
        argument_spec=ansible.module_utils.basic.AnsibleModule.argument_spec,
        params=dict()
    ))

    # Collect facts
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect(module=mock_module)
    assert 'python' in facts

# Generated at 2022-06-20 19:46:36.279208
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() != None

# Generated at 2022-06-20 19:46:46.650033
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert hasattr(pfc, 'collect')

    # Test collect
    module, collected_facts = None, None
    expected = {'python': {'has_sslcontext': True,
                           'executable': 'test_executable',
                           'version': {'serial': 0, 'micro': 0, 'releaselevel': '', 'major': 0, 'minor': 0},
                           'type': 'test_type',
                           'version_info': [0, 0, 0, '', 0]}}

# Generated at 2022-06-20 19:46:48.255866
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert 'python' == PythonFactCollector.name
    assert set() == PythonFactCollector._fact_ids


# Generated at 2022-06-20 19:46:56.750841
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    facts = pf.collect()
    assert facts == \
        dict(python=dict(version=dict(major=sys.version_info[0],
                                       minor=sys.version_info[1],
                                       micro=sys.version_info[2],
                                       releaselevel=sys.version_info[3],
                                       serial=sys.version_info[4]),
                         version_info=list(sys.version_info),
                         executable=sys.executable,
                         has_sslcontext=HAS_SSLCONTEXT,
                         type=getattr(sys, 'subversion', None) or
                              getattr(sys, 'implementation', None).name))

# Generated at 2022-06-20 19:47:05.896022
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pythonfact = PythonFactCollector()
    facts = pythonfact.collect()
    assert facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:47:12.257741
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ Test collect() method of class PythonFactCollector
    """
    python_facts = PythonFactCollector()
    result = python_facts.collect()
    assert isinstance(result, dict) and 'python' in result
    assert isinstance(result['python'], dict)
    assert isinstance(result['python']['version'], dict)

# Generated at 2022-06-20 19:47:13.469501
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:47:46.449744
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-20 19:47:50.823494
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # check that instance of PythonFactCollector can be created
    try:
        tmp = PythonFactCollector()
    except Exception:
        raise Exception('Error creating instance of PythonFactCollector')

    # check that the instance has proper methods
    assert hasattr(tmp, 'collect') is True
    assert callable(getattr(tmp, 'collect')) is True

    # check that the collect method returns expected results
    assert type(tmp.collect()) is dict

# Generated at 2022-06-20 19:47:54.466647
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:48:03.637640
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    PythonFactCollector.collect = python_fact_collector.collect
    facts_dict = {}
    actual_result = PythonFactCollector.collect(module=None, collected_facts=facts_dict)
    expected_result = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

   

# Generated at 2022-06-20 19:48:11.784391
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    if sys.version_info < (2, 7):
        # No setuptools for Python < 2.7, so skip testing
        return

    import setuptools
    import pkg_resources
    import inspect

    setuptools.setup = lambda self: 0

    module = pkg_resources.EntryPoint.parse("x = x").load(False)
    pkg_resources.EntryPoint.parse = lambda x: module
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert inspect.isclass(python_collector)

# Generated at 2022-06-20 19:48:18.907820
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_data = fact_collector.collect()
    assert isinstance(fact_data, dict)
    assert "python" in fact_data
    assert "type" in fact_data["python"]
    assert "version" in fact_data["python"]
    assert "executable" in fact_data["python"]
    assert "version_info" in fact_data["python"]
    assert "has_sslcontext" in fact_data["python"]

# Generated at 2022-06-20 19:48:21.256168
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector('python')
    print("\n" + pfc.collect())

if __name__ == '__main__':
    test_PythonFactCollector()

# Generated at 2022-06-20 19:48:23.921786
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = {}
    collector = PythonFactCollector(module=None, facts=facts)
    result = collector.collect()
    print(result)

# Generated at 2022-06-20 19:48:33.009640
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = None
    fact_collector = PythonFactCollector()
    fact_collector.collect(module)

    assert fact_collector.fact_names() == {'python'}

    collected_facts = {
        'ansible_python_version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'ansible_python_version_info': list(sys.version_info),
        'ansible_python_executable': sys.executable,
        'ansible_python_has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-20 19:48:34.959272
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc.collect() is not None


# Generated at 2022-06-20 19:49:44.177109
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-20 19:49:46.349455
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector(None)
    assert pfc is not None

# Generated at 2022-06-20 19:49:54.787711
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {
        'python': {
            'has_sslcontext': False,
            'version': {
                'major': 2,
                'micro': 7,
                'minor': 13,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 13, 'final', 0]
        }
    }
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector.collect() == python_facts

# Generated at 2022-06-20 19:50:00.479228
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, PythonFactCollector)

    python_facts = python_fact_collector.collect()

    assert 'python' in python_facts

    assert 'version' in python_facts['python']
    assert isinstance(python_facts['python']['version'], dict)
    assert 'major' in python_facts['python']['version']
    assert isinstance(python_facts['python']['version']['major'], int)
    assert 'minor' in python_facts['python']['version']
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert 'micro' in python_facts['python']['version']

# Generated at 2022-06-20 19:50:03.805991
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:50:09.080038
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ Unit tests for method collect of class PythonFactCollector.
    """
    print("Testing method collect of class PythonFactCollector")

    pfc = PythonFactCollector()

    python_facts = pfc.collect()


# Generated at 2022-06-20 19:50:12.342464
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'
    assert len(pf._fact_ids) == 0
    assert pf._fact_ids.get() == None


# Generated at 2022-06-20 19:50:13.133398
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector.collect()

# Generated at 2022-06-20 19:50:20.487295
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method collect of class PythonFactCollector"""
    # Unit test for method collect of class PythonFactCollector
    fact_collector = PythonFactCollector()
    fact = fact_collector.collect()
    assert fact['python']['version']['major'] == sys.version_info[0]
    assert fact['python']['version']['minor'] == sys.version_info[1]
    assert fact['python']['version']['micro'] == sys.version_info[2]
    assert fact['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact['python']['version']['serial'] == sys.version_info[4]
    assert fact['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:50:22.208435
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj
    assert obj.name == 'python'
    assert obj._fact_ids == set()
