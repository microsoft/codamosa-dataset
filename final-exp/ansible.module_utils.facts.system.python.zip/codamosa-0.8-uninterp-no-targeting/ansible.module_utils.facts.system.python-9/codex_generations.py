

# Generated at 2022-06-20 19:42:57.715941
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    # Initialize global variable for class Collector to have access to it
    Collector._collectors = {}
    Collector._collectors_name = []
    pfc = PythonFactCollector()
    pfc.collect()
    assert 'python' in pfc.collect()
    assert 'has_sslcontext' in pfc.collect()['python']
    assert 'type' in pfc.collect()['python']
    assert 'version' in pfc.collect()['python']
    assert 'version_info' in pfc.collect()['python']
    assert 'executable' in pfc.collect()['python']

# Generated at 2022-06-20 19:42:59.362838
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-20 19:43:01.362174
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector()
    assert pythonFactCollector.name == 'python'


# Generated at 2022-06-20 19:43:10.181852
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils import basic

    tf_collector = Collector()
    tf_collector.collect(None, None)

    tf_python_fact = PythonFactCollector(tf_collector)
    tf_python_fact.collect(None, None)

    assert 'python' in tf_collector.ansible_facts
    assert 'version' in tf_collector.ansible_facts['python']
    assert 'version_info' in tf_collector.ansible_facts['python']
    assert 'executable' in tf_collector.ansible_facts['python']
    assert 'has_sslcontext' in tf_collector.ansible_facts['python']

# Generated at 2022-06-20 19:43:13.121069
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector()

# Generated at 2022-06-20 19:43:15.044491
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set(['python'])

# Generated at 2022-06-20 19:43:17.861629
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts.get('python')

# Generated at 2022-06-20 19:43:26.343417
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    _ansible_version_facts = python_fact_collector.collect(collecte_facts={})
    assert 'python' in _ansible_version_facts
    assert 'executable' in _ansible_version_facts['python']
    assert 'has_sslcontext' in _ansible_version_facts['python']
    assert 'type' in _ansible_version_facts['python']
    assert 'version' in _ansible_version_facts['python']
    assert 'version_info' in _ansible_version_facts['python']

# Generated at 2022-06-20 19:43:27.661219
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'


# Generated at 2022-06-20 19:43:30.158727
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    ph = PythonFactCollector()
    assert ph.name == 'python'

# Generated at 2022-06-20 19:43:37.304985
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Create an instance of the class to test
    instanceOf = PythonFactCollector()

    # Check if the instance created is of type PythonFactCollector
    assert isinstance(instanceOf, PythonFactCollector)

# Generated at 2022-06-20 19:43:42.106607
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()

# Generated at 2022-06-20 19:43:52.019954
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']
    assert python_facts['python']['version']
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:43:59.318369
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python'], dict)
    assert 'type' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:44:09.121435
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact = PythonFactCollector()
    py_fact._module = {}
    py_fact._module['ANSIBLE_MODULE_ARGS'] = {}
    py_fact._module['ANSIBLE_MODULE_ARGS']['gather_subset'] = ['all']
    py_fact._module['ANSIBLE_MODULE_ARGS']['gather_timeout'] = 30
    py_fact.collect(module=None, collected_facts=None)
    assert py_fact._collected_facts['python']['type'] != None
    assert py_fact._collected_facts['python']['version']['releaselevel'] != None
    assert py_fact._collected_facts['python']['version_info'] != None
    assert py_fact._collected_facts['python']['executable'] != None

# Generated at 2022-06-20 19:44:20.687310
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_data = dict()
    fact_data['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-20 19:44:21.410087
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert True

# Generated at 2022-06-20 19:44:30.904558
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts_dict = collector.collect()
    assert facts_dict['python']['version']['major'] == sys.version_info[0]
    assert facts_dict['python']['version']['minor'] == sys.version_info[1]
    assert facts_dict['python']['version']['micro'] == sys.version_info[2]
    assert facts_dict['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts_dict['python']['version']['serial'] == sys.version_info[4]
    assert facts_dict['python']['version_info'] == list(sys.version_info)
    assert facts_dict['python']['executable'] == sys.executable
    assert facts_dict

# Generated at 2022-06-20 19:44:35.634628
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = pc.collect()
    assert isinstance(facts, dict)
    assert set(facts.keys()) == {'python'}
    assert isinstance(facts['python'], dict)
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)
    assert isinstance(facts['python']['has_sslcontext'], bool)
    assert isinstance(facts['python']['type'], (type(None), str))

# Generated at 2022-06-20 19:44:47.144131
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = PythonFactCollector().collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:44:52.801407
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()

    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-20 19:44:56.624523
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert isinstance(fact_collector._fact_ids, set)
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:45:00.962245
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert isinstance(python_facts['python'], dict)
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:45:02.285682
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == PythonFactCollector.name

# Generated at 2022-06-20 19:45:05.597540
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    python_facts = collector.collect()

    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-20 19:45:08.029988
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

    assert result

# Generated at 2022-06-20 19:45:10.414616
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert len(PythonFactCollector()._fact_ids) == 0


# Generated at 2022-06-20 19:45:13.805296
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x
    assert x.name == "python"
    assert 'python' in x._fact_ids

# Generated at 2022-06-20 19:45:14.669754
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()


# Generated at 2022-06-20 19:45:24.822577
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    result = python_fact.collect(None, None)
    assert result['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }
    assert result['python']['type'] == sys.implementation.name

# Generated at 2022-06-20 19:45:34.951129
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Unit test for constructor of class PythonFactCollector'''
    PythonFactCollector()

# Generated at 2022-06-20 19:45:36.225686
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:45:39.552232
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Unit test for constructor of class PythonFactCollector'''
    assert hasattr(PythonFactCollector, 'name')
    assert hasattr(PythonFactCollector, '_fact_ids')
    return

# Generated at 2022-06-20 19:45:49.625057
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors import collector_subset

    python_subset = collector_subset('python')
    python_subset.collect()

    python_subset.populate()

    assert 'version' in python_subset.facts
    assert isinstance(python_subset.facts['version'], dict)
    assert isinstance(python_subset.facts['version']['major'], int)
    assert isinstance(python_subset.facts['version']['minor'], int)
    assert isinstance(python_subset.facts['version']['micro'], int)
    assert isinstance(python_subset.facts['version']['releaselevel'], str)
    assert isinstance(python_subset.facts['version']['serial'], int)
    assert isinstance

# Generated at 2022-06-20 19:45:52.668276
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """This unit test checks that the function collect from
    module_utils/facts/collector/python.py returns a valid structure."""
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 19:46:00.488338
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']
    assert python_facts['python']['version']
    assert python_facts['python']['version_info']
    assert python_facts['python']['version']['major']
    assert python_facts['python']['version']['minor']
    assert python_facts['python']['version']['micro']
    assert python_facts['python']['version']['releaselevel']
    assert python_facts['python']['version']['serial']
    assert python_facts['python']['executable']
    assert python_facts['python']['type'] is not None
    assert python_facts['python']['has_sslcontext']

# Generated at 2022-06-20 19:46:02.281962
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    # TODO: Add unit tests


# Generated at 2022-06-20 19:46:05.791464
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    print(python_facts)

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-20 19:46:13.498231
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = sys.modules[__name__]
    collector = PythonFactCollector()
    facts = collector.collect(module)
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:46:19.398084
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()

    assert pfc
    assert isinstance(pfc, PythonFactCollector)
    assert isinstance(pfc, BaseFactCollector)
    assert pfc.name == "python"
    assert pfc._fact_ids == set(["python"])



# Generated at 2022-06-20 19:46:45.827958
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import collector

    import_error = None
    try:
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        HAS_SSLCONTEXT = True
    except ImportError as ex:
        import_error = ex
        HAS_SSLCONTEXT = False

    class MockModule:
        pass

    class MockBaseFactCollector(BaseFactCollector):
        name = 'pytest'
        def collect(self, module=None, collected_facts=None):
            python_facts = {}

# Generated at 2022-06-20 19:46:47.792715
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector()
    assert pythonFactCollector._fact_ids == set()
    assert pythonFactCollector.name == 'python'


# Generated at 2022-06-20 19:46:49.082678
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()
    assert len(pyfc._fact_ids) == 0

# Generated at 2022-06-20 19:46:51.950510
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    with patch('sys.subversion'):
        python = PythonFactCollector()
        facts = python.collect()
        assert 'version' in facts['python']
        assert 'version_info' in facts['python']
        assert 'executable' in facts['python']
        assert 'type' in facts['python']
        assert 'has_sslcontext' in facts['python']


# Generated at 2022-06-20 19:46:54.367363
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:46:56.353836
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector()
    assert pythonFactCollector.name == 'python'

# Generated at 2022-06-20 19:46:59.352978
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert 'python' in python_facts.collect().keys()

# Generated at 2022-06-20 19:47:04.208700
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result == dict(python=dict(version=dict(major=2, minor=7, micro=10, releaselevel='final', serial=0),
                                      version_info=[2, 7, 10, 'final', 0], executable='/usr/bin/python',
                                      has_sslcontext=True, type='CPython'))

# Generated at 2022-06-20 19:47:12.780667
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test creating an instance of PythonFactCollector class
    obj = PythonFactCollector()

    # Test instance variable 'name' of class PythonFactCollector
    assert obj.name == 'python', 'The "name" variable of PythonFactCollector() should be "python".'

    # Test instance variable '_fact_ids' of class PythonFactCollector
    assert obj._fact_ids == set(), 'The "_fact_ids" variable of PythonFactCollector() should be set().'


# Generated at 2022-06-20 19:47:23.364855
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']
    assert result['python']['version']
    assert result['python']['version']['major']
    assert result['python']['version']['minor']
    assert result['python']['version']['micro']
    assert result['python']['version']['releaselevel']
    assert result['python']['version']['serial']
    assert result['python']['version_info']
    assert result['python']['executable']
    assert result['python']['has_sslcontext']

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-20 19:48:03.850982
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test collect method of PythonFactCollector"""
    python_fact_collector = PythonFactCollector()
    # Assert the result of method collect
    assert python_fact_collector.collect() == {'python': {'version': {'releaselevel': 'final', 'serial': 0, 'micro': 2, 'major': 3, 'minor': 7}, 'executable': '/usr/bin/python3.7', 'version_info': [3, 7, 2, 'final', 0], 'has_sslcontext': True, 'type': 'CPython'}}


# Generated at 2022-06-20 19:48:13.218350
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert isinstance(facts, dict)
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'type' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']

# Generated at 2022-06-20 19:48:21.354422
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test collect method of class PythonFactCollector"""

    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-20 19:48:31.706323
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert isinstance(facts, dict)
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version_info'], list)
    assert 'executable' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']


# Generated at 2022-06-20 19:48:33.402860
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test empty constructor
    p = PythonFactCollector()

    assert p.name == 'python'
    assert p._fact_ids == set(['python'])

# Generated at 2022-06-20 19:48:36.574045
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = {}
    collected_facts = {}
    python_facts = {}
    collect_py_facts = PythonFactCollector()
    result = collect_py_facts.collect(module, collected_facts)
    assert result == python_facts

# Generated at 2022-06-20 19:48:42.733616
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    # Check the facts returned from the collect method of PythonFactCollector
    python_facts = pfc.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']

# Generated at 2022-06-20 19:48:51.946887
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert facts == { 'python': { 'version': {
                            'major': sys.version_info[0],
                            'minor': sys.version_info[1],
                            'micro': sys.version_info[2],
                            'releaselevel': sys.version_info[3],
                            'serial': sys.version_info[4]
                            },
                         'version_info': list(sys.version_info),
                         'executable': sys.executable,
                         'has_sslcontext': HAS_SSLCONTEXT,
                         'type': sys.implementation.name}
                    }

# Generated at 2022-06-20 19:48:52.503878
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-20 19:48:53.467556
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector() is not None

# Generated at 2022-06-20 19:50:09.206125
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json

    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts == {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': list(sys.version_info), 'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT, 'type': 'CPython'}}
    # This is for Python 2.7.x compatibility
    if sys.version_info < (3, 0):
        python_facts = json.loads(json.dumps(python_facts))

    python_

# Generated at 2022-06-20 19:50:18.146654
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector._facts['python']['version']['major'] == sys.version_info[0]
    assert fact_collector._facts['python']['version']['minor'] == sys.version_info[1]
    assert fact_collector._facts['python']['version']['micro'] == sys.version_info[2]
    assert fact_collector._facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_collector._facts['python']['version']['serial'] == sys.version_info[4]
    assert fact_collector._facts['python']['version_info'] == list(sys.version_info)


# Generated at 2022-06-20 19:50:20.302744
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    c.collect(collected_facts=None)

# Generated at 2022-06-20 19:50:23.109746
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python', 'Test PythonFactCollector.name failed!'
    assert isinstance(PythonFactCollector._fact_ids, set), 'Test type of PythonFactCollector._fact_ids failed'

# Generated at 2022-06-20 19:50:25.255833
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x

# Generated at 2022-06-20 19:50:35.828111
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    result = c.collect()

    assert 'python' in result
    assert isinstance(result['python'], dict)

    assert 'version' in result['python']
    assert isinstance(result['python']['version'], dict)

    assert 'major' in result['python']['version']
    assert 'minor' in result['python']['version']
    assert 'micro' in result['python']['version']
    assert 'releaselevel' in result['python']['version']
    assert 'serial' in result['python']['version']

    assert 'version_info' in result['python']
    assert isinstance(result['python']['version_info'], list)

    assert 'executable' in result['python']

# Generated at 2022-06-20 19:50:42.360152
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pythonfactcollector = PythonFactCollector()

    facts = {}
    pythonfactcollector.collect(collected_facts=facts)
    assert facts['python']
    assert facts['python']['version']
    assert facts['python']['version']['major']
    assert facts['python']['version']['minor']
    assert facts['python']['version']['micro']
    assert facts['python']['version']['releaselevel']
    assert facts['python']['version']['serial']
    assert facts['python']['version_info']
    assert facts['python']['executable']
    assert facts['python']['has_sslcontext']

# Generated at 2022-06-20 19:50:47.115289
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = {"ansible_python_version": {"micro": 0, "releaselevel": "final", "serial": 0, "major": 2, "minor": 7}}
    assert PythonFactCollector().collect(collected_facts=collected_facts) is None

# Generated at 2022-06-20 19:50:48.410779
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector(None)
    assert collector.name == 'python'

# Generated at 2022-06-20 19:50:49.811433
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert(python_fact_collector.name == 'python')