

# Generated at 2022-06-11 04:59:48.662026
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert type(python_facts) is dict
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-11 04:59:53.554759
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    js = pfc.collect()
    assert 'python' in js
    assert 'version' in js['python']
    assert 'version_info' in js['python']
    assert 'executable' in js['python']
    assert 'has_sslcontext' in js['python']
    if hasattr(sys, 'subversion'):
        assert 'type' in js['python']

# Generated at 2022-06-11 04:59:56.869045
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''

    # Create an instance of PythonFactCollector
    py = PythonFactCollector()

    # Test method
    assert isinstance(py.collect(), dict)

# vim: set et sw=4 ts=4

# Generated at 2022-06-11 05:00:04.861154
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'type': 'CPython',
            'has_sslcontext': True
        }
    }

# Generated at 2022-06-11 05:00:09.365266
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {'python': {'version': {'serial': 0, 'releaselevel': 'final', 'micro': 0, 'major': 2, 'minor': 7}, 'executable': '/usr/bin/python', 'version_info': [2, 7, 0, 'final', 0], 'type': 'CPython', 'has_sslcontext': True}}

# Generated at 2022-06-11 05:00:11.242036
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result is not None

# Generated at 2022-06-11 05:00:15.866581
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import get_collector_facts
    facts = get_collector_facts('python', {})
    assert facts['python']['version']['major'] == 3
    assert isinstance(facts['python']['version_info'], list)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:00:22.031420
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pf = pfc.collect()
    assert pf == {
        "python" : {
            "version": {
                "major": 3,
                "minor": 5,
                "micro": 2,
                "releaselevel": "final",
                "serial": 0
            },
            "version_info": [3, 5, 2, "final", 0],
            "executable": "/usr/bin/python3.5",
            "has_sslcontext": True,
            "type": "CPython"
        }
    }

# Generated at 2022-06-11 05:00:23.121851
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:00:31.818824
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    result = c.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT



# Generated at 2022-06-11 05:00:43.831265
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:00:54.537281
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()

    collected_facts = {}
    new_facts = python_collector.collect(collected_facts=collected_facts)
    assert 'python' in new_facts
    assert 'version' in new_facts['python']
    assert 'version_info' in new_facts['python']
    assert 'executable' in new_facts['python']
    assert 'type' in new_facts['python']
    assert isinstance(new_facts['python']['version']['releaselevel'], str)
    assert isinstance(new_facts['python']['version_info'][0], int)
    assert isinstance(new_facts['python']['executable'], str)
    assert isinstance(new_facts['python']['type'], str)

# Generated at 2022-06-11 05:01:03.454157
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Prepare input and expected results
    py_facts_collection = PythonFactCollector()
    expected_results = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    # Try to get type of python from sys.subversion[0]

# Generated at 2022-06-11 05:01:14.865085
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    object(PythonFactCollector)
    """

    pythonfact_collected = PythonFactCollector()
    pythonfact_collected.collect()

    assert 'python' in pythonfact_collected.collected_facts
    assert 'version' in pythonfact_collected.collected_facts['python']
    assert 'major' in pythonfact_collected.collected_facts['python']['version']
    assert 'minor' in pythonfact_collected.collected_facts['python']['version']
    assert 'micro' in pythonfact_collected.collected_facts['python']['version']
    assert 'releaselevel' in pythonfact_collected.collected_facts['python']['version']
    assert 'serial' in pythonfact_collected.collected_facts['python']['version']

# Generated at 2022-06-11 05:01:24.533725
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize empty class for testing
    test_collector = PythonFactCollector(None)
    test_collector._module = None
    test_collector._collected_facts = None

    # Run method
    result = test_collector.collect(None, None)

    # Verify results

# Generated at 2022-06-11 05:01:34.037113
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # type: () -> None
    """
        Test collect of PythonFactCollector
    """
    from ansible.module_utils.facts.collectors import find_collector
    from distutils.version import StrictVersion

    python_fact_collector = find_collector('python')
    result = python_fact_collector.collect()

    assert isinstance(result, dict)
    assert isinstance(result['python'], dict)
    assert isinstance(result['python']['version'], dict)
    assert isinstance(result['python']['version']['major'], int)
    assert isinstance(result['python']['version']['minor'], int)
    assert isinstance(result['python']['version']['micro'], int)

# Generated at 2022-06-11 05:01:44.885999
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Get PythonFactCollector class object
    pyfc = PythonFactCollector()

    # Get the result of execution of method collect of class PythonFactCollector
    result = pyfc.collect()

    # Equality test of execution result
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 7
    assert result['python']['version']['micro'] == 1
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [3, 7, 1, 'final', 0]
    assert result['python']['executable']  # sys.executable

# Generated at 2022-06-11 05:01:49.355004
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts == {'python': {
                        'version': {
                            'major': sys.version_info[0],
                            'minor': sys.version_info[1],
                            'micro': sys.version_info[2],
                            'releaselevel': sys.version_info[3],
                            'serial': sys.version_info[4]
                        },
                        'version_info': list(sys.version_info),
                        'executable': sys.executable,
                        'has_sslcontext': HAS_SSLCONTEXT,
                        'type': sys.implementation.name
                    }
                }

# Generated at 2022-06-11 05:01:58.032372
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create the PythonFactCollector object
    x = PythonFactCollector()

    # Do not use the module parameter in order to not execute module code
    # and use the test code
    # Use the collected_facts parameter in order to not call other fact
    # collectors
    # Pass a empty dictionary as argument to fill the facts_dict parameter
    facts_dict = {}
    x.collect(collected_facts=facts_dict)

    # The following keys and values should be present in facts_dict
    assert 'python' in facts_dict
    if facts_dict['python']['type'] == 'CPython':
        assert 'version' in facts_dict['python']
        assert 'version_info' in facts_dict['python']
        assert len(set(facts_dict['python']['version'].keys())) == 5

# Generated at 2022-06-11 05:02:06.578459
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Setup
    fact_collector = PythonFactCollector()

    fact_collector._module = None
    fact_collector._collected_facts = dict()

    # Run test
    result = fact_collector.collect()

    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 4
    assert result['python']['version']['micro'] == 2
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [3, 4, 2, 'final', 0]
    assert result['python']['executable'] == '/usr/bin/python'

# Generated at 2022-06-11 05:02:20.493465
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-11 05:02:29.622515
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test collect method returns a dictionary
    pfc = PythonFactCollector()
    collected_facts = pfc.collect()
    assert isinstance(collected_facts, dict)

    # Test dictionary contains a dictionary for key 'python'
    assert 'python' in collected_facts
    assert isinstance(collected_facts['python'], dict)

    # Test dictionary contains a dictionary for key 'version'
    assert 'version' in collected_facts['python']
    assert isinstance(collected_facts['python']['version'], dict)

    # Test dictionary contains a major, minor, micro and releaselevel for key
    # 'version'
    assert 'major' in collected_facts['python']['version']
    assert 'minor' in collected_facts['python']['version']

# Generated at 2022-06-11 05:02:31.298989
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()
    assert 'python' in python_facts

# Generated at 2022-06-11 05:02:39.760686
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert type(result) is dict
    assert 'python' in result.keys()
    assert type(result['python']) is dict
    assert 'version' in result['python'].keys()
    assert type(result['python']['version']) is dict
    assert len(result['python']['version']) == 5
    assert 'major' in result['python']['version'].keys()
    assert type(result['python']['version']['major']) is int
    assert 'minor' in result['python']['version'].keys()
    assert type(result['python']['version']['minor']) is int
    assert 'micro' in result['python']['version'].keys()

# Generated at 2022-06-11 05:02:43.437621
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import pprint
    fc = PythonFactCollector()
    result = fc.collect()
    #print("PythonFactCollector.collect() returned")
    #print("------------------------------------")
    #pprint.pprint(result)
    assert "python" in result

# Generated at 2022-06-11 05:02:48.739028
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    obj.populate()
    facts = obj.collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:02:50.036671
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect()['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:02:57.877475
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize the collector
    f = PythonFactCollector()

    # Run the collect method
    result = f.collect()

    # Assert that the result is what is expected
    assert result == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
            },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'type': 'CPython',
        'has_sslcontext': HAS_SSLCONTEXT
    }}

# Generated at 2022-06-11 05:03:03.283593
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    assert pc.collect() == {'python': {'version': {'major': 3, 'minor': 4, 'micro': 4, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 4, 4, 'final', 0], 'executable': '/usr/bin/python3.4', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-11 05:03:13.181256
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import ansible.module_utils.facts.collector
    py_collector = ansible.module_utils.facts.collector.get_collector("PythonFactCollector")

    ansible_vars = dict()
    ansible_facts = dict()
    collected_facts = dict()
    
    python_fact = py_collector.collect(module=None, collected_facts=None)
    python_fact_expected = dict()

# Generated at 2022-06-11 05:03:37.377536
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()

    assert type(result) == dict
    assert 'python' in result
    assert type(result['python']) == dict
    assert 'executable' in result['python']
    assert type(result['python']['executable']) == str
    assert 'has_sslcontext' in result['python']
    assert type(result['python']['has_sslcontext']) == bool
    assert 'type' in result['python']
    assert 'version' in result['python']
    assert type(result['python']['version']) == dict
    assert 'major' in result['python']['version']
    assert type(result['python']['version']['major']) == int
    assert 'minor' in result['python']['version']


# Generated at 2022-06-11 05:03:46.925079
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    python_fact = PythonFactCollector(Facts())

    # Collecting Python facts
    python_facts = python_fact.collect()

    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]


# Generated at 2022-06-11 05:03:54.452847
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create instance of PythonFactCollector
    pfc = PythonFactCollector()

    # Call the collect function
    # Should return a facts dictionary
    facts = pfc.collect()

    # Assert the expected keys
    assert 'python' in facts

    assert isinstance(facts['python']['version']['major'], int)
    assert isinstance(facts['python']['version']['minor'], int)
    assert isinstance(facts['python']['version']['micro'], int)
    assert isinstance(facts['python']['version']['releaselevel'], str)
    assert isinstance(facts['python']['version']['serial'], int)
    assert isinstance(facts['python']['version_info'], list)

# Generated at 2022-06-11 05:03:57.879579
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = PythonFactCollector().collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:04:08.445059
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector

    class DummyModule(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    dummy_module = DummyModule(
        _ansible_version=basic.__version__,
        _ansible_sys_executable=sys.executable,
        _ansible_sys_version_info=sys.version_info,
        _ansible_sys_path=sys.path
    )
    tmp_collector = Collector()
    tmp_collector.add_collection(PythonFactCollector)

    # test with python 2.6.6, py

# Generated at 2022-06-11 05:04:17.370729
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test Py2:
    if sys.version_info[0] < 3:
        py_type = 'CPython'
    else:
        py_type = 'CPython'

    # Create an instance of PythonFactCollector and invoke method collect
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()

    # Verify the results of method collect
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-11 05:04:23.492424
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    result = fc.collect()

    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]


# Generated at 2022-06-11 05:04:24.826218
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()

# Generated at 2022-06-11 05:04:32.444574
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    facts = python_collector.collect()
    assert facts['python']['version']['major'] == 3
    assert facts['python']['version']['minor'] == 4
    assert facts['python']['version']['micro'] == 4
    assert facts['python']['version']['releaselevel'] == 'final'
    assert facts['python']['version']['serial'] == 0
    assert facts['python']['version_info'] == [3, 4, 4, 'final', 0]
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] is False
    assert facts['python']['type'] == 'cpython'

# Generated at 2022-06-11 05:04:38.601920
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    if sys.version_info < (3, 0):
        assert facts['python']['type'] == sys.subversion[0]
    else:
        assert facts['python']['type'] == sys.implementation.name
    assert facts['python']['has_sslcontext'] is True

# Generated at 2022-06-11 05:05:19.355632
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    results = py_fc.collect()

    assert results['python']['version']['major'] == sys.version_info[0]
    assert results['python']['version']['minor'] == sys.version_info[1]
    assert results['python']['version']['micro'] == sys.version_info[2]
    assert results['python']['version']['releaselevel'] == sys.version_info[3]
    assert results['python']['version']['serial'] == sys.version_info[4]
    assert results['python']['version_info'] == list(sys.version_info)
    assert results['python']['executable'] == sys.executable
    assert results['python']['has_sslcontext'] == HAS_SS

# Generated at 2022-06-11 05:05:27.463469
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_obj = PythonFactCollector()
    # Can't test without these attributes
    actual = python_obj.collect()

    expected = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-11 05:05:33.481115
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_facts = PythonFactCollector()

    py_facts_return = py_facts.collect()
    assert py_facts_return == dict(python=dict(
        executable=sys.executable,
        version=dict(major=sys.version_info[0],
                     minor=sys.version_info[1],
                     micro=sys.version_info[2],
                     releaselevel=sys.version_info[3],
                     serial=sys.version_info[4]),
        version_info=list(sys.version_info),
        type=sys.subversion[0] if hasattr(sys, 'subversion') else sys.implementation.name,
        has_sslcontext=HAS_SSLCONTEXT,
    ))

# Generated at 2022-06-11 05:05:39.418310
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts['all']['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-11 05:05:48.120822
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert 'python' in facts
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['has_sslcontext'] is True
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:05:53.130205
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect() == {
        'python': {
            'executable': '/usr/bin/python',
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'major': 2,
                'minor': 7,
                'micro': 13,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 13, 'final', 0]
        }
    }

# Generated at 2022-06-11 05:06:01.976125
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result_good = {
        'python': {
            'executable': '/usr/bin/python',
            'has_sslcontext': True,
            'version': {
                'micro': 3,
                'major': 2,
                'minor': 7,
                'releaselevel': 'final',
                'serial': 0
            },
            'type': 'CPython',
            'version_info': [2, 7, 3, 'final', 0]
        }
    }

# Generated at 2022-06-11 05:06:07.208288
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    assert pyfc.collect() == {'python': {'type': 'CPython',
                                         'has_sslcontext': True,
                                         'version_info': [3, 7, 3, 'final', 0],
                                         'executable': sys.executable,
                                         'version': {'major': 3,
                                                     'minor': 7,
                                                     'micro': 3,
                                                     'serial': 0,
                                                     'releaselevel': 'final'}}}



# Generated at 2022-06-11 05:06:11.305096
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    py_fc = PythonFactCollector()
    facts = py_fc.collect()

    assert 'ansible_python' in facts
    assert 'version' in facts['ansible_python']
    assert 'version_info' in facts['ansible_python']
    assert 'version_info' in facts['ansible_python']
    assert 'executable' in facts['ansible_python']

# Generated at 2022-06-11 05:06:18.746525
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fake_module = object()
    collected_facts = {}
    expected_result = {'python': {'executable': '/usr/bin/python2.6',
                                  'has_sslcontext': False,
                                  'type': None,
                                  'version': {'major': 2,
                                              'minor': 6,
                                              'micro': 0,
                                              'releaselevel': 'final',
                                              'serial': 0},
                                  'version_info': [2, 6, 0, 'final', 0]}}
    pfc = PythonFactCollector(fake_module, collected_facts)

    assert pfc.collect(fake_module, collected_facts) == expected_result

# Generated at 2022-06-11 05:07:33.008095
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {}

    facts = python_fact_collector.collect(collected_facts=collected_facts)

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]

    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable']

# Generated at 2022-06-11 05:07:40.630759
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.resources.python import PythonFactCollector
    from ansible.module_utils.facts.resources.python import HAS_SSLCONTEXT

    module = None
    collected_facts = {}
    PythonFactCollector = PythonFactCollector()

    # Test if the method collect returns a dictionary with the correct keys
    # and correct content
    # Create a list of all expected keys
    expected_keys = ['python']
    expected_python_keys = ['version', 'version_info', 'executable', 'type', 'has_sslcontext']
    expected_version_info = list(sys.version_info)
    python_facts = PythonFactCollector.collect(module, collected_facts)
    assert isinstance(python_facts, dict) == True

# Generated at 2022-06-11 05:07:41.645634
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:07:48.289837
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    output = fact_collector.collect()
    assert output['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }
    if hasattr(sys, 'implementation'):
        assert output['python']['type'] == sys.implementation.name
    elif hasattr(sys, 'subversion'):
        assert output

# Generated at 2022-06-11 05:07:55.105709
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    class MockCollectedFacts:
        def __init__(self):
            self.FACTS = None

    class MockModule:
        def __init__(self):
            self.exit_json = None

    test_object = PythonFactCollector()

    mock_collected_facts = MockCollectedFacts()
    test_object.collect(MockModule(), collected_facts=mock_collected_facts)

    assert 'python' in mock_collected_facts.FACTS
    assert 'version' in mock_collected_facts.FACTS['python']
    assert 'version_info' in mock_collected_facts.FACTS['python']
    assert 'executable' in mock_collected_facts.FACTS['python']

# Generated at 2022-06-11 05:08:02.692196
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pseudo_module = type('PseudoModule', (object,), dict(params={}))
    pseudo_module.fail_json = lambda **kwargs: sys.exit(1)
    fact_collector = PythonFactCollector(module=pseudo_module)

    facts = fact_collector.collect()

    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version']['major'], int)
    assert isinstance(facts['python']['version']['minor'], int)
    assert isinstance(facts['python']['version']['micro'], int)

# Generated at 2022-06-11 05:08:09.579284
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector(None, None)
    facts = pfc.collect(None, None)

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']

    assert len(facts['python']['version']) == 5
    assert len(facts['python']['version_info']) == 5

    # Fail if the list returned by subversion is not 5 elements long

# Generated at 2022-06-11 05:08:14.110643
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact = fact_collector.collect()
    assert fact.get('python') is not None
    assert fact['python']['version'] is not None
    assert fact['python']['version_info'] is not None
    assert fact['python']['executable'] is not None
    assert fact['python']['type'] is not None
    assert fact['python']['has_sslcontext'] is not None

# Generated at 2022-06-11 05:08:21.665618
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # reset the class
    PythonFactCollector._fact_ids = set()

    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert 'python' in facts

    assert 'version' in facts['python']
    version = facts['python']['version']
    assert 'major' in version
    assert 'minor' in version
    assert 'micro' in version
    assert 'releaselevel' in version
    assert 'serial' in version

    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-11 05:08:30.245694
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PFC = PythonFactCollector()

    # Normally we would skip tests where Python version < 2.7
    # but this is a module that needs to support 2.6 so we
    # test it.
    py_minor = sys.version_info[1]
    py_micro = sys.version_info[2]
    py_release = sys.version_info[3]
    py_serial = sys.version_info[4]

    # Verify expected when 2.6.0 <= Python version < 2.7.0
    if py_minor == 6 and py_micro == 0:
        facts = PFC.collect()
        assert facts['python']['type'] == 'CPython'
    # Verify expected when 2.7.0 <= Python version < 2.8.0