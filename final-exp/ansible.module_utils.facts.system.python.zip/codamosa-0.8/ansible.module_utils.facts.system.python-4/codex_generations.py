

# Generated at 2022-06-11 04:59:49.309780
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import ansible.module_utils.facts.collectors.python
    test_python_fact_collector = ansible.module_utils.facts.collectors.python.PythonFactCollector()
    test_python_facts = test_python_fact_collector._collect()
    assert 'python' in test_python_facts

# Generated at 2022-06-11 04:59:58.426270
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # No argument Case
    testPythonFactCollector = PythonFactCollector()
    python_facts = testPythonFactCollector.collect()
    assert 'version_info' in python_facts['python']
    assert python_facts['python']['version_info'][0] == sys.version_info[0]
    assert 'version_info' in python_facts['python']
    assert python_facts['python']['version_info'][1] == sys.version_info[1]
    assert 'version_info' in python_facts['python']
    assert python_facts['python']['version_info'][2] == sys.version_info[2]
    assert 'version_info' in python_facts['python']

# Generated at 2022-06-11 05:00:07.850568
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors import python as python_c
    from unittest import TestCase
    from types import ModuleType
    import sys

    class MyTest(TestCase, object):
        def test(self):
            fake_module = ModuleType('fake_module')
            python_collector = python_c.PythonFactCollector()
            # case 1 when version is changed
            python_collector.collect(fake_module, 'python')
            self.assertRaises(AttributeError, getattr, sys, 'subversion')
            # case 2 when subversion attribute is added
            setattr(sys, 'subversion', ['cpython', '3.6.7'])
            result = python_collector.collect(fake_module, 'python')

            # Asserts for case 1

# Generated at 2022-06-11 05:00:14.636469
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    result = pc.collect()
    assert result is not None
    assert result == dict(python=dict(version=dict(
        major=sys.version_info[0],
        minor=sys.version_info[1],
        micro=sys.version_info[2],
        releaselevel=sys.version_info[3],
        serial=sys.version_info[4]
    ), version_info=list(sys.version_info), executable=sys.executable, has_sslcontext=HAS_SSLCONTEXT,
        type=sys.subversion[0]))



# Generated at 2022-06-11 05:00:20.602868
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert 'python' in fact_collector.fact_ids
    assert 'python' in fact_collector.collect()
    assert 'executable' in fact_collector.collect()['python']
    assert 'version_info' in fact_collector.collect()['python']
    assert 'version' in fact_collector.collect()['python']
    assert 'type' in fact_collector.collect()['python']
    assert 'has_sslcontext' in fact_collector.collect()['python']

# Generated at 2022-06-11 05:00:22.263768
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method collect of class PythonFactCollector."""
    c = PythonFactCollector()
    c.collect()

# Generated at 2022-06-11 05:00:30.864398
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # set up arbitrary values for testing
    version_info = (1, 2, 3, 'releaselevel', 'serial')
    executable = 'path/to/executable'

    # Mock the sys module to return arbitrary values
    class FakeSysModule(object):
        version_info = version_info
        executable = executable
        try:
            subversion = ['type']
        except AttributeError:
            try:
                implementation = FakeImplementationClass()
            except AttributeError:
                pass

    class FakeImplementationClass(object):
        name = 'type'

    # perform the test
    with mock.patch.dict(sys.modules, {'sys': FakeSysModule()}):
        fact_collector = PythonFactCollector()
        returned_value = fact_collector.collect()

# Generated at 2022-06-11 05:00:39.556301
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_data = fact_collector.collect()
    assert fact_data['python']['version']['major'] == sys.version_info[0]
    assert fact_data['python']['version']['minor'] == sys.version_info[1]
    assert fact_data['python']['version']['micro'] == sys.version_info[2]
    assert fact_data['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_data['python']['version']['serial'] == sys.version_info[4]
    assert fact_data['python']['version_info'] == list(sys.version_info)
    assert fact_data['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:00:44.197690
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_facts = PythonFactCollector({})
    data = py_facts.collect()
    assert 'python' in data
    assert 'type' in data['python']
    assert 'version' in data['python']
    assert 'has_sslcontext' in data['python']
    assert 'version_info' in data['python']
    assert 'executable' in data['python']

# Generated at 2022-06-11 05:00:54.428327
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:01:04.374047
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()

    try:
        from ansible.module_utils.facts import ansible_facts
        python_version = ansible_facts.get('python', {}).get('version', {})
        python_version_info = ansible_facts.get('python', {}).get('version_info', {})
        python_executable = ansible_facts.get('python', {}).get('executable', {})
        python_type = ansible_facts.get('python', {}).get('type', {})
        python_has_sslcontext = ansible_facts.get('python', {}).get('has_sslcontext', {})
    except ImportError:
        python_version = {}
        python_version_info = {}
        python_executable = {}
        python_type = {}
        python_has

# Generated at 2022-06-11 05:01:06.771371
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    m = PythonFactCollector()
    f = m.collect()
    assert isinstance(f, dict)
    assert isinstance(f['python'], dict)

# Generated at 2022-06-11 05:01:09.079636
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    x = PythonFactCollector()
    print(x.collect())

# Generated at 2022-06-11 05:01:18.060564
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    res = pfc.collect()
    assert isinstance(res, dict)
    assert 'python' in res.keys()
    assert isinstance(res['python'], dict)
    assert 'version' in res['python'].keys()
    assert 'version_info' in res['python'].keys()
    assert 'has_sslcontext' in res['python'].keys()
    if 'type' in res['python'].keys():
        assert isinstance(res['python']['type'], str)
    else:
        assert res['python']['type'] is None


# Generated at 2022-06-11 05:01:23.167109
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    m = PythonFactCollector()
    assert 'python' in m.collect()
    assert 'type' in m.collect()['python']
    assert 'version' in m.collect()['python']
    assert 'version_info' in m.collect()['python']
    assert 'executable' in m.collect()['python']
    assert 'has_sslcontext' in m.collect()['python']

# Generated at 2022-06-11 05:01:31.749951
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector
    collector.collectors['python'] = PythonFactCollector()

    test_collector = PythonFactCollector()
    python_facts = test_collector.collect(collected_facts={})

    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    if python_facts['python']['type'] is None:
        assert isinstance(python_facts['python']['executable'], str)
        assert isinstance(python_facts['python']['has_sslcontext'], bool)
    else:
        assert python_facts['python']['type'] in ('CPython', 'PyPy')



# Generated at 2022-06-11 05:01:42.885771
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collection = PythonFactCollector()

    py_fact_collection.collect()

    assert py_fact_collection.name == 'python'
    assert py_fact_collection.facts['python']['version']['major'] == sys.version_info[0]
    assert py_fact_collection.facts['python']['version']['minor'] == sys.version_info[1]
    assert py_fact_collection.facts['python']['version']['micro'] == sys.version_info[2]
    assert py_fact_collection.facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_fact_collection.facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:01:47.375949
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc._collect_platform_info = mock = MagicMock()

    pfc.collect()

    # Check if the collect method calls _collect_platform_info() method.
    assert mock.called

    # Check if the collected facts from _collect_platform_info() method is
    # returned by collect method.
    assert mock.return_value == pfc.collect()

# Generated at 2022-06-11 05:01:55.438571
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {'facter': {}, 'ohai': {}, 'ansible_facts': {}}
    python_facts = python_fact_collector.collect(collected_facts=collected_facts)
    assert python_facts == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }}

# Generated at 2022-06-11 05:02:03.529570
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Test function for collect method of class PythonFactCollector
    '''
    python_obj = PythonFactCollector(None)
    python_facts = python_obj.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert isinstance(python_facts['python']['version']['major'], int)
    assert 'minor' in python_facts['python']['version']
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert 'micro' in python_facts['python']['version']
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert 'releaselevel' in python

# Generated at 2022-06-11 05:02:08.866076
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:02:15.308232
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector.'''
    pfc = PythonFactCollector()
    collected_facts = pfc.collect()
    assert('python' in collected_facts)
    assert('version' in collected_facts['python'])
    assert('version_info' in collected_facts['python'])
    assert('executable' in collected_facts['python'])
    assert('has_sslcontext' in collected_facts['python'])
    assert('type' in collected_facts['python'])

# Generated at 2022-06-11 05:02:25.594168
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collectors import all as all_collectors

    def mock_get_collector_fact_names(collector):
        fact_names = set()
        fact_names.add('python')
        return fact_names

    def mock_get_collector_instance(collector):
        python_collector = PythonFactCollector()
        return python_collector

    def mock_all_collectors():
        return []

    python_collector = PythonFactCollector()
    python_collector_fact_names = python_collector

# Generated at 2022-06-11 05:02:33.369779
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = {}
    fact_collector = PythonFactCollector()
    fact_collector.collect(module=None, collected_facts=facts)
    python_facts = facts.get('python', {})
    assert isinstance(python_facts, dict)
    version = python_facts.get('version', {})
    assert isinstance(version, dict)
    assert isinstance(version.get('major'), int)
    assert isinstance(version.get('minor'), int)
    assert isinstance(version.get('micro'), int)
    assert isinstance(version.get('releaselevel'), str)
    assert isinstance(version.get('serial'), int)
    assert isinstance(python_facts.get('version_info'), list)
    assert isinstance(python_facts.get('executable'), str)

# Generated at 2022-06-11 05:02:42.927678
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a new PythonFactCollector and collect facts
    fc = PythonFactCollector()
    facts = fc.collect()

    # Verify that it returned a dict
    assert isinstance(facts, dict)

    # Verify that it returned a dictionary
    assert 'ansible_facts' in facts
    assert 'python' in facts['ansible_facts']

    # Verify a few fact keys
    python_facts = facts['ansible_facts']['python']
    assert 'version' in python_facts
    version = python_facts['version']
    assert 'major' in version
    assert isinstance(version['major'], int)
    assert 'minor' in version
    assert isinstance(version['minor'], int)
    assert 'micro' in version
    assert isinstance(version['micro'], int)

# Generated at 2022-06-11 05:02:53.525379
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert isinstance(facts['python']['version_info'], list)
    assert facts['python']['version_info'][0] == sys.version_info[0]
    assert facts['python']['version_info'][1] == sys.version_info[1]
    assert facts['python']['version_info'][2] == sys.version_info[2]
    assert isinstance(facts['python']['version'], dict)
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]

# Generated at 2022-06-11 05:02:58.904334
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    facts_collector = FactsCollector()
    test_collector = PythonFactCollector(facts_collector)

    facts = test_collector.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'executable' in facts['python']
    assert 'version_info' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:03:05.353207
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    assert py_collector.collect() == {'python': {'version': {'major': 3, 'minor': 7, 'micro': 3, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 7, 3, 'final', 0], 'executable': '/home/mark/.venv-ansible/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-11 05:03:10.372065
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect(None)
    assert 'python' in python_facts
    assert python_facts['python']['executable'] == sys.executable
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['version'], dict)
    assert 'major' in python_facts['python']['version']

# Generated at 2022-06-11 05:03:18.381663
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for method collect of module PythonFactCollector
    """
    def_executable = sys.executable
    # Temporarily save sys.executable, so that we can change it
    del sys.executable

# Generated at 2022-06-11 05:03:30.962094
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    res = python_fact_collector.collect()
    assert res
    assert 'python' in res
    assert 'version' in res['python']
    assert 'version_info' in res['python']
    assert 'executable' in res['python']
    assert 'type' in res['python']
    assert 'has_sslcontext' in res['python']

# Generated at 2022-06-11 05:03:39.291776
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python_

# Generated at 2022-06-11 05:03:46.800990
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create test object
    python_fact_collector = PythonFactCollector()

    # Test collect
    python_facts = python_fact_collector.collect()

    # Check result
    assert python_facts['python']
    assert python_facts['python']['version']
    assert python_facts['python']['version_info']
    assert python_facts['python']['type'] in ['CPython', 'PyPy', 'IronPython', 'Jython']
    assert python_facts['python']['executable'] is not None
    assert python_facts['python']['has_sslcontext'] is not None

# Generated at 2022-06-11 05:03:47.727812
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()

    p.collect()

# Generated at 2022-06-11 05:03:50.704019
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    py_facts = py_fact_collector.collect()
    assert py_facts != None
    assert 'python' in py_facts
    assert py_facts['python'] != None

# Generated at 2022-06-11 05:03:58.415785
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test with Python 2.6, 2.7, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6
    # 1 of 4
    python_facts = PythonFactCollector().collect()
    assert python_facts == {
        'python': {
            'executable': '/usr/bin/python',
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'major': 2,
                'micro': 0,
                'minor': 7,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [
                2, 7, 0, 'final', 0
            ]
        }
    }
    # 2 of 4
    python_facts = PythonFactCollector().collect()
    assert python

# Generated at 2022-06-11 05:04:04.173118
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect() == {'python': {'version': {'micro': 2, 'releaselevel': 'final', 'minor': 7, 'serial': 0, 'major': 2}, 'executable': '/usr/bin/python', 'has_sslcontext': True, 'version_info': [2, 7, 2, 'final', 0], 'type': 'CPython'}}

# Generated at 2022-06-11 05:04:13.827833
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Returns python facts from sys module.
    """
    # Getting facts from class PythonFactCollector
    pfc = PythonFactCollector()
    # call collect method of class PythonFactCollector
    ansible_facts = pfc.collect()
    # Unit test for method collect
    # assert python facts in dictionary
    assert 'python' in ansible_facts
    # assert version facts in dictionary
    assert ansible_facts['python']['version']
    # assert version_info facts in dictionary
    assert ansible_facts['python']['version_info']
    # assert executable facts in dictionary
    assert ansible_facts['python']['executable']
    # assert type facts in dictionary
    assert ansible_facts['python']['type']
    # assert has_sslcontext in dictionary

# Generated at 2022-06-11 05:04:20.916730
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    input_facts = {}
    python_facts = PythonFactCollector().collect(collected_facts=input_facts)
    
    assert python_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-11 05:04:25.606616
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    a = c.collect()
    assert a['python']['version']['major'] == sys.version_info[0]
    assert a['python']['version']['minor'] == sys.version_info[1]
    assert a['python']['version']['micro'] == sys.version_info[2]
    assert a['python']['version']['releaselevel'] == sys.version_info[3]
    assert a['python']['version']['serial'] == sys.version_info[4]
    assert a['python']['type'] == sys.implementation.name
    assert a['python']['executable'] == sys.executable
    assert a['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:04:43.189636
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_info = PythonFactCollector().collect()
    assert len(python_info) == 1

# Generated at 2022-06-11 05:04:50.777269
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    tf = PythonFactCollector()
    res = tf.collect()
    assert 'python' in res
    assert res['python']['version']['major'] == sys.version_info[0]
    assert res['python']['version']['minor'] == sys.version_info[1]
    assert res['python']['version']['micro'] == sys.version_info[2]
    assert res['python']['version']['releaselevel'] == sys.version_info[3]
    assert res['python']['version']['serial'] == sys.version_info[4]
    assert res['python']['version_info'] == list(sys.version_info)
    assert res['python']['executable'] == sys.executable
    assert 'type' in res['python']

# Generated at 2022-06-11 05:04:58.417710
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    from ansible.module_utils._text import to_bytes

    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector._fact_ids == {'python'}

    collected_facts = {}
    fact_collector.collect(collected_facts=collected_facts)
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'major' in collected_facts['python']['version']
    assert 'minor' in collected_facts['python']['version']
    assert 'micro' in collected_facts['python']['version']
    assert 'releaselevel' in collected_facts['python']['version']
    assert 'serial' in collected_facts['python']['version']
    assert 'version_info' in collected_

# Generated at 2022-06-11 05:05:03.158510
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test the return value of PythonFactCollector.collect()"""
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-11 05:05:11.142972
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    mock_module = type('module', (), {})
    mock_collected_facts = {}

    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect(module=mock_module, collected_facts=mock_collected_facts)
    assert python_facts['python']['version']['major'] > 0, "major version is greater than 0"
    assert python_facts['python']['version']['minor'] >= 0, "minor version is greater than 0"
    assert python_facts['python']['version']['micro'] >= 0, "micro version is greater than 0"
    assert python_facts['python']['version']['releaselevel'] != '', "release level is not empty"

# Generated at 2022-06-11 05:05:15.377508
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] > 0
    assert python_facts['python']['version']['micro'] >= 0
    assert python_facts['python']['type'] is not None
    assert python_facts['python']['version_info'] is not None
    assert python_facts['python']['executable'] is not None

# Generated at 2022-06-11 05:05:23.488638
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert type(facts) is dict
    assert type(facts['python']) is dict
    assert type(facts['python']['version']) is dict
    assert type(facts['python']['version']['major']) is int
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert type(facts['python']['version']['minor']) is int
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert type(facts['python']['version']['micro']) is int
    assert facts['python']['version']['micro'] == sys.version_info[2]

# Generated at 2022-06-11 05:05:27.041791
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import types
    import sys
    import platform

    assert(PythonFactCollector.name=='python')
    assert(isinstance(PythonFactCollector._fact_ids,set))
    assert(len(PythonFactCollector._fact_ids)==0)

    # Python 2.6

# Generated at 2022-06-11 05:05:28.329023
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    assert isinstance(pfc.collect(), dict)


# Generated at 2022-06-11 05:05:33.720610
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    collected_facts = python_collector.collect()
    assert isinstance(collected_facts, dict)
    assert 'python' in collected_facts
    python_dict = collected_facts['python']
    assert 'version' in python_dict
    assert 'major' in python_dict['version']
    assert 'minor' in python_dict['version']
    assert 'micro' in python_dict['version']
    assert 'releaselevel' in python_dict['version']
    assert 'serial' in python_dict['version']
    assert sys.version_info[0] == python_dict['version']['major']
    assert sys.version_info[1] == python_dict['version']['minor']

# Generated at 2022-06-11 05:06:11.780633
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-11 05:06:18.556377
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import _frozen_importlib
    _frozen_importlib._init_module_attrs(sys)
    del sys.modules['_frozen_importlib']

    expected_result = {'python': {'version': {'major': 3, 'minor': 5, 'micro': 2, 'releaselevel': 'final', 'serial': 0}, 'type': 'CPython', 'executable': sys.executable, 'version_info': [3, 5, 2, 'final', 0], 'has_sslcontext': True}}
    returned_result = PythonFactCollector().collect()

    assert returned_result == expected_result


# Generated at 2022-06-11 05:06:28.732976
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    result = pyfc.collect()

    assert 'version' in result['python']
    vi = result['python']['version']
    assert 'major' in vi
    assert isinstance(vi['major'], int)
    assert 'minor' in vi
    assert isinstance(vi['minor'], int)
    assert 'micro' in vi
    assert isinstance(vi['micro'], int)
    assert 'releaselevel' in vi
    assert isinstance(vi['releaselevel'], str)
    assert 'serial' in vi
    assert isinstance(vi['serial'], int)
    assert 'version_info' in result['python']
    assert isinstance(result['python']['version_info'], list)
    assert 'executable' in result['python']
    assert isinstance

# Generated at 2022-06-11 05:06:37.110708
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python

# Generated at 2022-06-11 05:06:44.938690
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import collect_subset
    import os

    print("Using {0} for python executable".format(sys.executable))
    filesdir = os.path.join(os.path.dirname(__file__), 'files')
    facts_dict = collect_subset(['python'])


# Generated at 2022-06-11 05:06:53.277320
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    py_facts = py_fc.collect()

    assert type(py_facts) is dict
    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_facts['python']['version']['serial'] == sys.version_info[4]
    assert py_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:06:54.444848
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert 'python' in c.collect().keys()

# Generated at 2022-06-11 05:07:02.644518
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None, None, None)
    result = collector.collect()

    assert 'python' in result
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)

    # Mocks for SystemExit exception

# Generated at 2022-06-11 05:07:10.341799
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = {}
    pfc = PythonFactCollector(None)
    new_facts = pfc.collect(None, collected_facts)
    assert 'python' in new_facts
    assert len(new_facts['python']) > 1
    assert new_facts['python']['version']['major'] == sys.version_info[0]
    assert new_facts['python']['version']['minor'] == sys.version_info[1]
    assert new_facts['python']['version']['micro'] == sys.version_info[2]
    assert new_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert new_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:07:14.024641
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # mock module
    class MockModule:
        def __init__(self):
            pass
    mod = MockModule()
    # mock collected_facts
    collected_facts = dict()
    # instance to test
    inst = PythonFactCollector(module=mod, collected_facts=collected_facts)
    # test
    assert inst.collect()

# Generated at 2022-06-11 05:08:28.672146
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    FACT_DATA = {
        'python': {
            'executable': '/bin/python',
            'has_sslcontext': False,
            'type': 'CPython',
            'version': {
                'major': 2,
                'micro': 6,
                'minor': 6,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 6, 6, 'final', 0]
        }
    }
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect(collected_facts=None)
    assert facts == FACT_DATA

# Generated at 2022-06-11 05:08:32.014436
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    facts = py_collector.collect()
    assert isinstance(facts['python']['version']['major'], int)
    assert isinstance(facts['python']['version']['minor'], int)
    assert isinstance(facts['python']['version']['micro'], int)

# Generated at 2022-06-11 05:08:38.721375
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    python_facts = {'python':
                    {'executable': '/usr/bin/python2.7',
                     'has_sslcontext': True,
                     'type': 'CPython',
                     'version':
                         {'major': 2,
                          'minor': 7,
                          'micro': 12,
                          'releaselevel': 'final',
                          'serial': 0},
                      'version_info': [2, 7, 12, 'final', 0]}}

    fact_collector = PythonFactCollector()
    assert isinstance(fact_collector, BaseFactCollector)
    assert python_facts == fact_collector.collect()

# Generated at 2022-06-11 05:08:46.221186
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert 'python' in fact_collector
    assert isinstance(fact_collector['python'], dict)
    assert 'version' in fact_collector['python']
    assert isinstance(fact_collector['python']['version'], dict)
    assert 'major' in fact_collector['python']['version']
    assert isinstance(fact_collector['python']['version']['major'], int)
    assert 'minor' in fact_collector['python']['version']
    assert isinstance(fact_collector['python']['version']['minor'], int)
    assert 'micro' in fact_collector['python']['version']

# Generated at 2022-06-11 05:08:48.585988
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    facts = fact_collector.collect()

    assert facts['python']['version']['major'] >= 2
    assert facts['python']['version']['minor'] >= 6

# Generated at 2022-06-11 05:08:55.698846
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors.python import PythonFactCollector
    collector = PythonFactCollector()
    result = collector.collect()
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 6
    assert result['python']['version']['micro'] == 4
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [3, 6, 4, 'final', 0]
    assert result['python']['executable'].endswith('/python3')
    assert result['python']['has_sslcontext'] == True

# Generated at 2022-06-11 05:09:00.008582
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc.collect() == {'python': {'version': {'micro': 0, 'releaselevel': 'final', 'major': 2, 'serial': 0, 'minor': 7}, 'has_sslcontext': False, 'executable': '/usr/bin/python', 'type': None, 'version_info': [2, 7, 0, 'final', 0]}}



# Generated at 2022-06-11 05:09:01.614978
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    a = PythonFactCollector()
    b = a.collect()
    assert 'python' in b.keys()

# Generated at 2022-06-11 05:09:11.269503
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:09:18.510176
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']