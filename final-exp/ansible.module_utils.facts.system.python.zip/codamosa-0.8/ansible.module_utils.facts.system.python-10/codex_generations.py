

# Generated at 2022-06-11 04:59:45.687931
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc.collect()

# Generated at 2022-06-11 04:59:51.713542
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts == {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': list(sys.version_info), 'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT, 'type': sys.implementation.name}}

# Generated at 2022-06-11 04:59:54.867720
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Method collect of class PythonFactCollector returns a dictionary with
    the fact 'python'"""

    c = PythonFactCollector()
    facts = c.collect()

    assert 'python' in facts
    assert isinstance(facts['python'], dict)


# Generated at 2022-06-11 04:59:57.656091
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector."""
    collector = PythonFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)
    assert facts['python'] != {}

# Generated at 2022-06-11 05:00:06.951090
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    r = PythonFactCollector().collect()
    assert r['python']['version']['major'] == sys.version_info[0]
    assert r['python']['version']['minor'] == sys.version_info[1]
    assert r['python']['version']['micro'] == sys.version_info[2]
    assert r['python']['version']['releaselevel'] == sys.version_info[3]
    assert r['python']['version']['serial'] == sys.version_info[4]
    assert r['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:00:13.010642
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module_mock = {}
    python_facts = {'python': {'executable': '/python', 'has_sslcontext': True, 'version': {'major': 3, 'minor': 4, 'releaselevel': 'final', 'serial': 0, 'micro': 5}, 'version_info': [3, 4, 5, 'final', 0], 'type': 'cpython'}}

    python_fc = PythonFactCollector(module=module_mock)
    assert python_fc.collect(module=module_mock) == python_facts

# Generated at 2022-06-11 05:00:21.178852
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    facts = p.collect()
    assert facts['python']['type'] in ['CPython', 'IronPython', 'MicroPython']
    assert facts['python']['version']['major'] in [2, 3]
    assert facts['python']['version']['minor'] in [x for x in range(0, 21)]
    assert facts['python']['version']['micro'] in [x for x in range(0, 50)]
    assert facts['python']['version']['releaselevel'] in ['alpha', 'beta', 'candidate', 'final']
    assert facts['python']['version']['serial'] in [x for x in range(0, 50)]

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-11 05:00:26.665741
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector(None)
    result = pfc.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'executable' in result['python']
    assert 'version_info' in result['python']
    assert 'type' in result['python']
    assert isinstance(result['python']['version_info'], list)
    assert isinstance(result['python']['version']['serial'], int)

# Generated at 2022-06-11 05:00:30.729656
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    fc = PythonFactCollector()
    out = fc.collect()
    assert 'python' in out
    p = out['python']
    assert 'version' in p
    assert 'version_info' in p
    assert 'executable' in p
    assert 'has_sslcontext' in p
    assert type(p['has_sslcontext']) is bool

# Generated at 2022-06-11 05:00:39.434981
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    
    # expected_python_facts is the expected return from method collect
    expected_python_facts = {
            'python': {
                'version': {
                    'major': sys.version_info[0],
                    'minor': sys.version_info[1],
                    'micro': sys.version_info[2],
                    'releaselevel': sys.version_info[3],
                    'serial': sys.version_info[4]
                    },
                'version_info': list(sys.version_info),
                'executable': sys.executable,
                'has_sslcontext': HAS_SSLCONTEXT
                }
            }
    

# Generated at 2022-06-11 05:00:54.005824
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    PythonFactCollector - collect method
    '''
    # Test with a module
    module = None
    collected_facts = {}
    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-11 05:01:02.313991
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = collector.collect(collected_facts=None)
    assert collected_facts == {'python': {'version': {'major': sys.version_info[0],
                                                      'minor': sys.version_info[1],
                                                      'micro': sys.version_info[2],
                                                      'releaselevel': sys.version_info[3],
                                                      'serial': sys.version_info[4]},
                                         'version_info': list(sys.version_info),
                                         'executable': sys.executable,
                                         'has_sslcontext': HAS_SSLCONTEXT,
                                         'type': sys.implementation.name}}

# Generated at 2022-06-11 05:01:13.623089
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect(module=None, collected_facts=None)

    assert facts['python']['executable'].endswith('/python')
    assert facts['python']['type'] in ('CPython', 'PyPy')
    assert '-c' not in facts['python']['executable']
    assert '-m' not in facts['python']['executable']
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]

# Generated at 2022-06-11 05:01:23.567147
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    result = py_fc.collect(None, None)

    assert len(result.keys()) == 1
    assert result['python']['version'] == dict(
        major=sys.version_info[0],
        minor=sys.version_info[1],
        micro=sys.version_info[2],
        releaselevel=sys.version_info[3],
        serial=sys.version_info[4]
    )
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-11 05:01:27.146290
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {'python': {'version': {'micro': 6, 'minor': 1, 'releaselevel': 'final', 'major': 2, 'serial': 0}, 'version_info': [2, 1, 6, 'final', 0], 'executable': '/home/cristian/anaconda2/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}


# Generated at 2022-06-11 05:01:35.197572
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_python_facts = {'python':
        {'executable': '/test/location/python',
         'has_sslcontext': True,
         'type': 'test_type',
         'version': {'major': 1,
                     'micro': 2,
                     'minor': 3,
                     'releaselevel': 'final',
                     'serial': 4},
         'version_info': [1, 2, 3, 'final', 4]}}
    obj = PythonFactCollector(None)

    obj.collect()
    assert(obj._fact_ids == {'python'})
    assert(obj.facts == test_python_facts)

# Generated at 2022-06-11 05:01:43.774724
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    expected_python_facts = {'python':
                             {'version':
                              {'micro': 0,
                               'major': 2,
                               'minor': 7,
                               'releaselevel': 'final',
                               'serial': 0},
                              'type': 'CPython',
                              'has_sslcontext': False,
                              'version_info':
                              [2, 7, 0, 'final', 0],
                              'executable': '/usr/bin/python'}}
    assert expected_python_facts == python_facts

# Generated at 2022-06-11 05:01:49.424400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for method collect of class PythonFactCollector
    """
    python_fact_collector_instance = PythonFactCollector()
    collected_facts = {}
    python_facts = python_fact_collector_instance.collect(collected_facts=collected_facts)
    assert 'python' in python_facts

    python_dict = python_facts['python']
    assert 'version' in python_dict
    assert 'version_info' in python_dict
    assert 'executable' in python_dict
    assert 'has_sslcontext' in python_dict

# Generated at 2022-06-11 05:01:56.303932
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert python_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
        }
    }

# Generated at 2022-06-11 05:02:04.603205
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector(None)
    python_facts = python_fact_collector.collect()

    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)

# Generated at 2022-06-11 05:02:23.344286
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    pfc = PythonFactCollector()
    results = pfc.collect()
    assert type(results) == dict, 'Returned value should be a dict.'
    assert results.has_key('python'), 'Dict should have key "python".'
    assert results['python'].has_key('executable'), 'Dict should have key "executable".'
    assert results['python']['executable'] == sys.executable, 'Dict should have key "executable" whose value is sys.executable.'
    assert results['python']['has_sslcontext'] == HAS_SSLCONTEXT, 'Dict should have key "has_sslcontext" whose value is HAS_SSLCONTEXT.'
    assert results['python'].has_key('type'), 'Dict should have key "type".'

# Generated at 2022-06-11 05:02:31.742864
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import types

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector

    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': True
        }
    }


# Generated at 2022-06-11 05:02:33.899201
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    # On Python 2.6 subversion is not present
    assert 'type' in c.collect()['python']
    assert 'version' in c.collect()['python']

# Generated at 2022-06-11 05:02:43.588424
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()

    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

    assert python_facts['python']['version_info'] == list(sys.version_info)

    if hasattr(sys, "implementation"):
        assert python_facts

# Generated at 2022-06-11 05:02:48.455609
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result = collector.collect()
    assert result['python']['version']['major'] > 0
    assert result['python']['type'] in ['CPython', 'Jython', 'IronPython', 'PyPy']
    assert result['python']['has_sslcontext'] is True

# Generated at 2022-06-11 05:02:50.483532
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    assert 'python' in facts

# Generated at 2022-06-11 05:02:56.194186
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pythonFactCollector = PythonFactCollector()
    collected_facts = {}
    python_facts = pythonFactCollector.collect(collected_facts)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-11 05:02:58.513261
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

if __name__ == "__main__":
    test_PythonFactCollector_collect()

# Generated at 2022-06-11 05:03:08.928195
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    module.exit_json = MagicMock(return_value=None)
    python_fact_collector = PythonFactCollector()

    try:
        python_facts = python_fact_collector.collect(module)
    except:
        python_facts = python_fact_collector.collect(module)

    assert isinstance(python_facts['python']['version_info'], list)

    assert 2 <= python_facts['python']['version']['major'] <= sys.maxsize
    assert 0 <= python_facts['python']['version']['minor'] <= sys.maxsize
    assert 0 <= python_facts['python']['version']['micro'] <= sys.maxsize

    # At the time of creation of this test, Python 3.4.3 does

# Generated at 2022-06-11 05:03:17.214170
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:03:41.649958
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    from ansible.module_utils.facts.collector.python import PythonFactCollector

    test_python_collector = PythonFactCollector()
    test_result = test_python_collector.collect()

    assert 'python' in test_result
    assert 'version' in test_result['python']
    assert 'version_info' in test_result['python']
    assert 'executable' in test_result['python']
    assert 'type' in test_result['python']
    assert 'has_sslcontext' in test_result['python']

    #Because these values can change, we just check if they
    #are non-zero
    assert test_result['python']['version']['major'] != 0
    assert test_result['python']['version']['minor'] != 0

# Generated at 2022-06-11 05:03:51.063856
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    def _do_test(platform_name):
        import ansible.module_utils.facts.collector
        ansible.module_utils.facts.collector.C.metadata.clear()
        ansible.module_utils.facts.collector.C.metadata.__platforms = [platform_name]
        ansible.module_utils.facts.collector.C.module_cache.clear()
        ansible.module_utils.facts.collector.C.module_cache[platform_name] = {
            'python': {
                'version_info': [2, 7, 12, 'final', 0],
                'executable': sys.executable,
                'has_sslcontext': HAS_SSLCONTEXT
            }
        }

        pfc = PythonFactCollector()
        facts = pfc.collect()

        assert facts

# Generated at 2022-06-11 05:03:59.068615
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact = fact_collector.collect()

    # This is test data, so we should not compare the full version,
    # as it would fail on each Python patch release.
    assert fact['python']['version']['major'] == sys.version_info[0]
    assert fact['python']['version']['minor'] == sys.version_info[1]
    assert fact['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact['python']['version']['serial'] == sys.version_info[4]
    assert fact['python']['version_info'] == list(sys.version_info)
    assert fact['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:04:09.421572
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Set up a fake module and collected_facts
    class FakeModule:
        pass
    class FakeCollectedFacts:
        pass

    fake_module = FakeModule()
    fake_collected_facts = FakeCollectedFacts()

    # Instantiate a PythonFactCollector object
    pfc = PythonFactCollector()

    # Test with all parameters empty
    python_facts = pfc.collect(fake_module, fake_collected_facts)

    # Assertions
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts

# Generated at 2022-06-11 05:04:18.117685
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector

    # Test a normal collect
    collected_facts = FactCollector().collect(module='faked-module')
    assert isinstance(collected_facts['python']['version'], dict)
    assert isinstance(collected_facts['python']['version_info'], list)
    assert type(collected_facts['python']['executable']) is unicode
    assert type(collected_facts['python']['has_sslcontext']) is bool
    assert type(collected_facts['python']['type']) is unicode

    # Test a collect when there is an error
    class FakePythonFactCollector(PythonFactCollector):
        def collect(self, module=None, collected_facts=None):
            return None
    collected_facts

# Generated at 2022-06-11 05:04:24.166961
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import Collector

    python_fact_collector = PythonFactCollector()
    facts = Collector().get_facts(python_fact_collector)
    assert  facts['python'] is not None
    py_facts = facts['python']
    assert py_facts['executable'] is not None
    assert py_facts['version'] is not None
    assert py_facts['version_info'] is not None
    assert py_facts['has_sslcontext'] is not None
    assert py_facts['type'] is not None

# Generated at 2022-06-11 05:04:26.265732
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Make sure we have the python fact collector
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert 'python' in fact_collector.facts

# Generated at 2022-06-11 05:04:30.639206
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Test PythonFactCollector.collect
    '''
    pfc = PythonFactCollector()
    facts = pfc.collect()

    assert 'executable' in facts['python']
    assert 'version' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'version_info' in facts['python']
    assert 'type' in facts['python']


# Generated at 2022-06-11 05:04:38.260853
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector

    # Stub out AnsibleModule
    class AnsibleModule():
        def __init__(self):
            self.params = {}

    # Stub out AnsibleModule
    class Facts():
        def __init__(self):
            self.values = {}

    try:
        # Get python version info and executable
        ansible_module = AnsibleModule()
        ansible_facts = Facts()

        # Call method collect of class PythonFactCollector
        ret = obj.collect(ansible_module, ansible_facts)
        # Test if ret is the expected one
        assert ret != {}

        # Test if ret is the type expected one
        assert isinstance(ret, dict)
    except:
        # Test that exception is raised
        assert False


# Generated at 2022-06-11 05:04:42.564065
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    assert facts['python']
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-11 05:05:00.368556
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()

    assert isinstance(py_fc.collect(), dict)

# Generated at 2022-06-11 05:05:08.451416
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:05:09.237661
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector.collect()

# Generated at 2022-06-11 05:05:12.607518
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'type' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-11 05:05:13.949801
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()



# Generated at 2022-06-11 05:05:17.607384
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    output = PythonFactCollector().collect()
    assert isinstance(output, dict)
    assert 'python' in output
    assert 'version' in output['python']
    assert 'version_info' in output['python']
    assert 'executable' in output['python']
    assert 'has_sslcontext' in output['python']


# Generated at 2022-06-11 05:05:19.804093
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_data = PythonFactCollector().collect()
    assert 'python' in py_data
    assert isinstance(py_data, dict)
    assert isinstance(py_data['python']['version'], dict)

# Generated at 2022-06-11 05:05:26.695421
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of the PythonFactCollector
    python_fact_collector = PythonFactCollector()
    # Test collect method
    facts = python_fact_collector.collect()
    # Test result
    assert facts['python']['version_info'] == [3, 5, 2, 'final', 0]
    assert facts['python']['version']['major'] == 3
    assert facts['python']['version']['minor'] == 5
    assert facts['python']['version']['micro'] == 2
    assert facts['python']['version']['releaselevel'] == 'final'
    assert facts['python']['version']['serial'] == 0

# Generated at 2022-06-11 05:05:30.093889
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    fc = PythonFactCollector()
    facts = {}
    facts = fc.collect(facts)
    assert 'python' in facts
    assert 'executable' in facts['python']
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:05:32.128864
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Setup
    python_collector = PythonFactCollector()
    collected_facts = {}
    # Should not throw an exception
    python_collector.collect(collected_facts=collected_facts)

# Generated at 2022-06-11 05:06:11.285190
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    python_facts = python_fact_collector.collect()['python']

    assert python_facts['version']['major'] == sys.version_info[0]
    assert python_facts['version']['minor'] == sys.version_info[1]
    assert python_facts['version']['micro'] == sys.version_info[2]
    assert python_facts['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['version']['serial'] == sys.version_info[4]
    assert python_facts['version_info'] == list(sys.version_info)
    assert python_facts['executable'] == sys.executable
    assert python_facts['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:06:19.786002
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import re

    # call method under test
    pfc = PythonFactCollector()
    python_facts = pfc.collect()

    # verify results
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:06:28.913668
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    class MockModule:
        pass

    class MockCollectedFacts:
        pass

    mock_module = MockModule()
    mock_collected_facts = MockCollectedFacts()

    # Create the PythonFactCollector instance
    fact_collector = PythonFactCollector(mock_module, mock_collected_facts)

    # Call the collect method
    result = fact_collector.collect()

    # Validate the collected facts
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']

# Generated at 2022-06-11 05:06:30.593180
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert python_facts

# Generated at 2022-06-11 05:06:33.788766
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector.'''
    c = PythonFactCollector()
    facts = c.collect()
    assert facts
    assert isinstance(facts['python'], dict)
    assert isinstance(facts['python']['version_info'], list)

# Generated at 2022-06-11 05:06:41.669018
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    py_facts = fact_collector.collect()

    # Expecting version and version_info properties
    assert 'version' in py_facts['python']
    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:06:45.906752
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector(None)
    res = pfc.collect()
    assert 'python' in res
    assert res['python']['version']['major'] == sys.version_info[0]
    if HAS_SSLCONTEXT:
        assert res['python']['has_sslcontext'] is True
    else:
        assert res['python']['has_sslcontext'] is False

# Generated at 2022-06-11 05:06:47.338277
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    fc.collect()

# Generated at 2022-06-11 05:06:55.397860
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.HAS_SSLCONTEXT = True
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

# Generated at 2022-06-11 05:06:57.413321
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector.'''
    python_fact_collector = PythonFactCollector()
    assert 'python' in python_fact_collector.collect()

# Generated at 2022-06-11 05:08:10.350164
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    print("\nStarting collect of PythonFactCollector")
    python_facts = pfc.collect()
    print("\nReturned facts: {}".format(python_facts))
    print("{}".format(python_facts['python']['version_info']))
    print("{}".format(python_facts['python']['type']))
    assert type(python_facts) == dict
    assert type(python_facts['python']) == dict
    assert type(python_facts['python']['version']) == dict
    assert type(python_facts['python']['version_info']) == list
    assert type(python_facts['python']['executable']) == str
    assert type(python_facts['python']['type']) == str

# Generated at 2022-06-11 05:08:19.055745
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    facts = python_collector.collect()
    assert type(facts['python']) is dict
    assert type(facts['python']['version']) is dict
    assert type(facts['python']['version']['major']) is int
    assert type(facts['python']['version']['minor']) is int
    assert type(facts['python']['version']['micro']) is int
    assert type(facts['python']['version']['releaselevel']) is str
    assert type(facts['python']['version']['serial']) is int
    assert type(facts['python']['version_info']) is list
    assert type(facts['python']['executable']) is str

# Generated at 2022-06-11 05:08:24.839411
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    NOTE: This is a destructed unit test which tests the behaviour of the
          collect method of the PythonFactCollector class. The method is
          supposed to extract the version of Python that is used. For this
          purpose the test code assumes that the major and minor version
          are set to 2 and 7.
    """
    pfc = PythonFactCollector()

    facts = pfc.collect()

    assert facts['python']['version']['major'] == 2
    assert facts['python']['version']['minor'] == 7

# Generated at 2022-06-11 05:08:26.485817
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # pylint: disable=unused-argument
    fc = PythonFactCollector()
    fc.collect()

# Generated at 2022-06-11 05:08:33.117098
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert len(python_facts) == 1
    assert 'python' in python_facts.keys()
    assert len(python_facts['python']) == 6
    assert 'version' in python_facts['python'].keys()
    assert 'version_info' in python_facts['python'].keys()
    assert 'executable' in python_facts['python'].keys()
    assert 'type' in python_facts['python'].keys()
    assert 'has_sslcontext' in python_facts['python'].keys()

# Generated at 2022-06-11 05:08:35.457699
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    r = PythonFactCollector()
    py_fac = r.collect()

    assert isinstance(py_fac['python'], dict)
    assert py_fac['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-11 05:08:43.094785
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Using this moduel to test the method collect of class
    # PythonFactCollector
    from ansible.module_utils.facts.collectors.python import (
        PythonFactCollector
    )
    FACTS = PythonFactCollector().collect()
    assert isinstance(FACTS, dict)
    assert isinstance(FACTS['python'], dict)
    assert isinstance(FACTS['python']['version'], dict)
    assert isinstance(FACTS['python']['version_info'], list)
    assert isinstance(FACTS['python']['executable'], str)
    assert isinstance(FACTS['python']['has_sslcontext'], bool)

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-11 05:08:45.320030
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect(collected_facts={})
    assert facts['python']['version']['major'] >= 2

# Generated at 2022-06-11 05:08:46.392797
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:08:53.477531
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = dict()
    pfc = PythonFactCollector()
    result = pfc.collect(module=None, collected_facts=facts)
    expected_result = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }