

# Generated at 2022-06-11 04:59:55.406656
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector(None, None, None)

    # Unit test for collect() with extracted sys.version_info
    sys.version_info=(2, 7, 6, 'final', 0)
    sys.executable='/usr/bin/python'
    expected_facts = {
        'python': {
            'version': {
                'major': 2,
                'minor': 7,
                'micro': 6,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 6, 'final', 0],
            'executable': '/usr/bin/python',
            'type': 'CPython',
            'has_sslcontext': False
        }
    }

# Generated at 2022-06-11 05:00:04.898972
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    import ansible_fact_collector
    sysinfo = platform.uname()

# Generated at 2022-06-11 05:00:13.577672
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_facts = PythonFactCollector().collect()

    # Test all facts are there
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']

    # test values
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']

# Generated at 2022-06-11 05:00:20.157236
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert 'type' in facts['python']
    assert 'executable' in facts['python']


# Generated at 2022-06-11 05:00:28.960278
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:00:32.094179
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    # Testing with python2.7:
    assert obj.collect()["python"]["type"] == "CPython"
    # Testing with python3.6:
    assert obj.collect()["python"]["type"] == "CPython"

# Generated at 2022-06-11 05:00:40.821227
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

    assert fact_collector.facts['python']['version']['major'] == sys.version_info[0]
    assert fact_collector.facts['python']['version']['minor'] == sys.version_info[1]
    assert fact_collector.facts['python']['version']['micro'] == sys.version_info[2]
    assert fact_collector.facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_collector.facts['python']['version']['serial'] == sys.version_info[4]
    assert fact_collector.facts['python']['version_info'] == list(sys.version_info)
    assert fact_

# Generated at 2022-06-11 05:00:43.252619
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_data = fact_collector.collect()

    assert isinstance(fact_data, dict)
    assert 'python' in fact_data

# Generated at 2022-06-11 05:00:53.565867
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    py_facts = py_collector.collect()
    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_facts['python']['version']['serial'] == sys.version_info[4]
    assert py_facts['python']['version_info'] == list(sys.version_info)
    assert py_facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:01:02.658725
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    collected_facts = dict()
    python_fact.collect(collected_facts=collected_facts)

    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert type(collected_facts['python']['version']) == dict
    assert 'version_info' in collected_facts['python']
    assert type(collected_facts['python']['version_info']) == list
    assert 'executable' in collected_facts['python']
    assert type(collected_facts['python']['executable']) == str
    assert 'has_sslcontext' in collected_facts['python']
    assert type(collected_facts['python']['has_sslcontext']) == bool

# Generated at 2022-06-11 05:01:13.286231
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert len(py_fact_collector._fact_ids) == 0
    py_facts = py_fact_collector.collect()
    assert isinstance(py_facts, dict)
    assert 'python' in py_facts
    assert isinstance(py_facts['python'], dict)

# Generated at 2022-06-11 05:01:16.114982
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    result = python_collector.collect()
    assert result is not None
    assert result['python'] is not None
    assert result['python']['version'] is not None
    assert result['python']['version_info'] is not None
    assert result['python']['executable'] is not None
    assert result['python']['type'] is not None
    assert result['python']['has_sslcontext'] is not None

# Generated at 2022-06-11 05:01:21.687677
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector(None)
    python_fact_collector._module_name = "fake_module"
    python_fact_collector._module_args = {'gather_subset': ['!all']}
    python_fact_collector.collect()
    # no assertion needed. If we make it to the end without an exception
    # then we are good.

# Generated at 2022-06-11 05:01:26.239031
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    python_fact = python_fact_collector.collect(collected_facts)

    assert 'python' in python_fact
    assert 'version' in python_fact['python']
    assert 'version_info' in python_fact['python']
    assert 'executable' in python_fact['python']
    assert 'has_sslcontext' in python_fact['python']
    assert 'type' in python_fact['python']



# Generated at 2022-06-11 05:01:36.979931
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector(None)
    result = python_fact_collector.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == sys.version_info
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:01:40.018400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    f_res = fc.collect(module=None, collected_facts=None)
    assert f_res['python']['type'] == 'CPython'

# Generated at 2022-06-11 05:01:48.752160
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import types

    fake_module = types.ModuleType('fake_module')
    fake_module.params = {"gather_subset": ["all"]}

    fake_sys = types.ModuleType('sys')
    fake_sys.version_info = (2, 7, 12, 'final', 0)
    fake_sys.executable = "/usr/bin/python"
    fake_sys.subversion = ('CPython', '', '')
    fake_sys.implementation = types.SimpleNamespace(name='CPython')

    py_collector = PythonFactCollector(fake_module)

    result = py_collector.collect(fake_module)


# Generated at 2022-06-11 05:01:57.323963
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    sys.modules['ansible'] = ''
    sys.modules['ansible.module_utils.facts.collector'] = ''
    try:
        from ansible.module_utils.facts.collector.python import PythonFactCollector
    except ImportError:
        print("Could not import the PythonFactCollector class")
        exit(1)

    m = PythonFactCollector()
    fact = m.collect()
    assert fact['python']['version']['major'] == sys.version_info[0], "Version information not equal"
    assert fact['python']['version']['minor'] == sys.version_info[1], "Version information not equal"
    assert fact['python']['version']['micro'] == sys.version_info[2], "Version information not equal"

# Generated at 2022-06-11 05:02:05.693325
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a new PythonFactCollector
    python_collector = PythonFactCollector()

    # Call method collect
    collected_facts = python_collector.collect()

    # Assert facts are correct
    assert collected_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-11 05:02:12.260610
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_dict = PythonFactCollector().collect()
    # Correct dictionary should have one element and it should be a dict
    assert len(python_dict) == 1
    assert isinstance(python_dict.get('python'), dict)
    # Correct Dictionary for the Python Facts should have the following keys
    python_fact_keys = ['version', 'version_info', 'executable', 'has_sslcontext']
    python_facts = python_dict.get('python')
    assert len(set(python_facts.keys()) - set(python_fact_keys)) == 0

# Generated at 2022-06-11 05:02:22.712759
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect(collected_facts={})
    assert fact_collector.name == 'python'

# Generated at 2022-06-11 05:02:26.469465
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Build the object
    pfc = PythonFactCollector()

    # Call the method
    result = pfc.collect()

    # Check result
    assert type(result) is dict, "Result should be a dict"
    assert 'python' in result.keys(), "Result does not contains the key python"

# Generated at 2022-06-11 05:02:33.752247
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_python_fact_collector = PythonFactCollector('test', 'test')
    assert test_python_fact_collector.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.version_info[0] == 2 and 'CPython' or None
        }
    }

# Generated at 2022-06-11 05:02:39.539623
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert 'executable' in python_facts['python']
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    if sys.version_info[0] >= 3:
        assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-11 05:02:50.217630
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''
    python_fact_collector = PythonFactCollector()

    # Test with python 2
    if sys.version_info[0] == 2:
        python_facts = python_fact_collector.collect()
        assert python_facts['python']['version']['major'] == 2
        assert python_facts['python']['version']['minor'] == 7
        assert python_facts['python']['version']['micro'] == 12
        assert python_facts['python']['version']['releaselevel'] == 'final'
        assert python_facts['python']['version']['serial'] == 0
        assert python_facts['python']['type'] == 'CPython'
        assert python_facts['python']['has_sslcontext']

# Generated at 2022-06-11 05:02:58.465140
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """test_PythonFactCollector_collect: Test if correct version is returned """

    python_version_info = list(sys.version_info)
    python_type = 'CPython'

    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': python_version_info,
            'executable': sys.executable,
            'type': python_type,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    pfc = PythonFactCollector()

# Generated at 2022-06-11 05:02:59.776310
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    py_fc.collect()

# Generated at 2022-06-11 05:03:09.967476
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector._read_facts_from_file = lambda x: dict()
    fact_collector._cache = dict()
    fact_collector._module = None
    fact_collector._collected_facts = dict()
    fact_collector._warnings = list()
    python_facts = fact_collector.collect()
    # This test is almost a copy of the method collect of the class PythonFactCollector
    # but I don't know how to import specific parts of a module
    python_facts_by_hand = dict()

# Generated at 2022-06-11 05:03:18.074525
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test the collect method of the PythonFactCollector class.
    """
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    python_info = python_facts['python']
    assert isinstance(python_info, dict)
    assert 'version' in python_info
    assert 'version_info' in python_info
    assert 'executable' in python_info
    assert 'has_sslcontext' in python_info
    version_info = python_info['version']
    assert isinstance(version_info, dict)
    assert 'major' in version_info
    assert 'minor' in version_info
    assert 'micro' in version_info
    assert 'releaselevel' in version_info
    assert 'serial' in version_

# Generated at 2022-06-11 05:03:23.341884
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Unit test for method collect of class PythonFactCollector
    '''
    fact_collector = PythonFactCollector()
    fact_collector._module = MockModule()
    fact_collector._module_name = 'python'
    collected_facts = {}
    fact_collector.collect(module=fact_collector._module,
                           collected_facts=collected_facts)
    assert(type(collected_facts) == dict)
    if 'python' not in collected_facts:
        raise AssertionError('missing "python" key in collected_facts')

# Mock class for AnsibleModule

# Generated at 2022-06-11 05:03:47.850647
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    # Create a PythonFactCollector
    fact_collector = PythonFactCollector()

    # Call the collect method
    collected_facts = fact_collector.collect()

    # Check collected_facts
    assert isinstance(collected_facts, dict)
    assert "python" in collected_facts
    python_facts = collected_facts['python']
    assert isinstance(python_facts, dict)
    assert "executable" in python_facts
    assert isinstance(python_facts["executable"], str)
    assert "has_sslcontext" in python_facts
    assert isinstance(python_facts["has_sslcontext"], bool)
    assert "type" in python_facts

# Generated at 2022-06-11 05:03:55.019588
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for method collect of class PythonFactCollector
    """
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts

# Generated at 2022-06-11 05:03:56.605746
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert 'python' in python_fact_collector.collect()

# Generated at 2022-06-11 05:03:59.825825
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Construct PythonFactCollector object
    py_collector = PythonFactCollector()

    # Test collect method of PythonFactCollector
    # Returns a dictionary of facts
    assert isinstance(py_collector.collect(), dict)

# Generated at 2022-06-11 05:04:10.055520
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test for python version 2.6.9
    sys.version_info = (2, 6, 9, 'final', 0)
    del sys.subversion
    collected_facts = {}
    module = None
    py_collector = PythonFactCollector(module=module,
                                       collected_facts=collected_facts)
    py_facts = py_collector.collect()
    py_expected_facts = {
        'python': {
            'version': {'major': 2, 'minor': 6, 'micro': 9, 'releaselevel': 'final',
                        'serial': 0},
            'version_info': [2, 6, 9, 'final', 0],
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': None
        }
    }

# Generated at 2022-06-11 05:04:12.675675
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    ansible_facts = dict()
    gathered_facts = obj.collect(module=None, collected_facts=ansible_facts)
    assert 'python' in gathered_facts

# Generated at 2022-06-11 05:04:17.012487
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result1 = fact_collector.collect(None, None)
    assert type(result1) == dict
    result2 = fact_collector.collect(None, result1)
    assert type(result2) == dict
    result3 = fact_collector.collect(None, result2)
    assert result3 == {}

# Generated at 2022-06-11 05:04:18.488054
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect()

# Generated at 2022-06-11 05:04:20.340674
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    py_collector = PythonFactCollector()
    result = py_collector.collect()

    assert ('python' in result)

# Generated at 2022-06-11 05:04:22.019510
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_value = fact_collector.collect()
    assert isinstance(fact_value, dict)

# Generated at 2022-06-11 05:05:02.241902
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python

# Generated at 2022-06-11 05:05:10.187957
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from mock import patch
    from ansible.module_utils.facts import collector

    path_import = 'ansible.module_utils.facts.collector.PythonFactCollector'

    with patch(path_import + '.sys.version_info', (2, 7, 0, 'final', 0)):
        with patch(path_import + '.sys.executable', '/usr/bin/python2.7'):
            with patch(path_import + '.HAS_SSLCONTEXT', False):
                with patch(path_import + '.sys.subversion', None):
                    with patch(path_import + '.sys.implementation.name', 'CPython'):
                        python_value = collector.PythonFactCollector().collect()

# Generated at 2022-06-11 05:05:11.271118
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:05:16.054592
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    all_facts = fact_collector.collect(None, {})

    assert all_facts
    assert type(all_facts) is dict
    assert 'python' in all_facts
    assert 'version' in all_facts['python']
    assert 'version_info' in all_facts['python']
    assert 'executable' in all_facts['python']
    assert 'type' in all_facts['python']

# Generated at 2022-06-11 05:05:20.061195
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    result = python_collector.collect()
    assert isinstance(result, dict)
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']

# Generated at 2022-06-11 05:05:21.838771
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    result = collector.collect()
    assert result.get('python')
    assert result.get('python').get('type')

# Generated at 2022-06-11 05:05:25.981646
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    fact_collector.collect()

    assert fact_collector.name == 'python'
    assert 'version' in fact_collector.facts
    assert 'version_info' in fact_collector.facts
    assert 'executable' in fact_collector.facts
    assert 'has_sslcontext' in fact_collector.facts

# Generated at 2022-06-11 05:05:32.989737
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    returned_facts = pfc.collect()
    assert returned_facts['python']['type'] is not None
    assert returned_facts['python']['version']['major'] == sys.version_info[0]
    assert returned_facts['python']['version']['minor'] == sys.version_info[1]
    assert returned_facts['python']['version']['micro'] == sys.version_info[2]
    assert returned_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert returned_facts['python']['version']['serial'] == sys.version_info[4]
    assert returned_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:05:37.279118
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect(module=None, collected_facts=None)
    assert 'python' in result

    python_facts = result['python']
    assert 'version' in python_facts
    assert 'version_info' in python_facts
    assert 'executable' in python_facts
    assert 'has_sslcontext' in python_facts
    assert 'type' in python_facts


# Generated at 2022-06-11 05:05:44.422966
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result = collector.collect()
    assert result == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'cpython'
        }
    }

# Generated at 2022-06-11 05:06:55.465590
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Without arguments
    fc = PythonFactCollector()
    assert fc.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 12, 'releaselevel': 'final', 'serial': 0},
                                  'version_info': [2, 7, 12, 'final', 0], 'executable': '/usr/bin/python2.7',
                                  'has_sslcontext': True, 'type': 'CPython'}}
    # With arguments
    fc = PythonFactCollector()

# Generated at 2022-06-11 05:07:00.237616
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc_facts = pfc.collect()

    assert 'python' in pfc_facts
    assert 'version' in pfc_facts['python']
    assert 'version_info' in pfc_facts['python']
    assert 'executable' in pfc_facts['python']
    assert 'has_sslcontext' in pfc_facts['python']
    assert 'type' in pfc_facts['python']

# Generated at 2022-06-11 05:07:02.649012
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector.python import PythonFactCollector
    test_object = PythonFactCollector()
    result = test_object.collect()
    assert 'python' in result

# Generated at 2022-06-11 05:07:10.371660
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import json

    # Set up
    _python_facts = {
        "python": {
            "version": {
                "major": sys.version_info[0],
                "minor": sys.version_info[1],
                "micro": sys.version_info[2],
                "releaselevel": sys.version_info[3],
                "serial": sys.version_info[4]
            },
            "version_info": list(sys.version_info),
            "executable": sys.executable,
            "has_sslcontext": False
        }
    }


# Generated at 2022-06-11 05:07:16.371319
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version_info'], list)
    assert 'executable' in facts['python']
    assert isinstance(facts['python']['executable'], str)

# Generated at 2022-06-11 05:07:21.690203
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    # Check we have a version, version_info and executable
    pfc_result = pfc.collect()
    assert 'version' in pfc_result['python']
    assert 'version_info' in pfc_result['python']
    assert 'executable' in pfc_result['python']

    # Check we have a python type
    assert 'type' in pfc_result['python']

    # Check if ssl context is available
    assert 'has_sslcontext' in pfc_result['python']

# Generated at 2022-06-11 05:07:30.600191
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = pc.collect()
    assert facts['python']['type'] in ['CPython', 'PyPy', 'IronPython', 'Jython', 'MicroPython']
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:07:35.014346
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect() == {'python': {'executable': '/usr/bin/python',
                                      'has_sslcontext': True,
                                      'type': 'CPython',
                                      'version': {'major': 2,
                                                  'micro': 7,
                                                  'minor': 13,
                                                  'releaselevel': 'final',
                                                  'serial': 0},
                                      'version_info': [2, 7, 13, 'final', 0]}}

# Generated at 2022-06-11 05:07:42.411142
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc._load_platform_subclass()
    facts = pfc.collect()

    assert facts is not None
    assert len(facts) == 1
    assert facts['python'] is not None

    python_facts = facts['python']

    assert python_facts['executable'] is not None
    assert python_facts['version'] is not None
    assert python_facts['version_info'] is not None
    assert python_facts['type'] is not None
    assert python_facts['has_sslcontext'] is not None
    assert python_facts['version']['major'] is not None
    assert python_facts['version']['minor'] is not None
    assert python_facts['version']['micro'] is not None
    assert python_facts['version']['releaselevel'] is not None


# Generated at 2022-06-11 05:07:42.816922
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-11 05:08:52.871229
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    py_dict = py_fact_collector.collect()

    assert py_dict['python']['version']['major'] == sys.version_info[0]
    assert py_dict['python']['version']['minor'] == sys.version_info[1]
    assert py_dict['python']['version']['micro'] == sys.version_info[2]
    assert py_dict['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_dict['python']['version']['serial'] == sys.version_info[4]
    assert py_dict['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:08:53.943841
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert isinstance(collector.collect(), dict)

# Generated at 2022-06-11 05:08:57.291004
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    pfc = PythonFactCollector()
    pf_test = pfc.collect()

    assert 'python' in pf_test
    assert 'executable' in pf_test['python']
    assert 'version_info' in pf_test['python']
    assert 'has_sslcontext' in pf_test['python']

# Generated at 2022-06-11 05:09:06.478440
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    col_fcts = dict(ansible_python=dict(
        executable='/usr/bin/python',
        has_sslcontext=True,
        version=dict(
            major=2, minor=7, micro=12, releaselevel='final', serial=0
        ),
        version_info=[
            2, 7, 12, 'final', 0
        ],
        type='CPython'
    ))

    module = AnsibleModuleMock()
    fact_col = PythonFactCollector()
    fact_col.collect(module)

    assert module.exit_args['failed'] is False
    assert module.exit_args['changed'] is False
    assert module.exit_args['ansible_facts'] == col_fcts

# Generated at 2022-06-11 05:09:13.081962
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': 'cpython'
    }}

# Generated at 2022-06-11 05:09:20.608225
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    r = PythonFactCollector().collect()
    assert r['python']['version']['major'] == sys.version_info[0]
    assert r['python']['version']['minor'] == sys.version_info[1]
    assert r['python']['version']['micro'] == sys.version_info[2]
    assert r['python']['version']['releaselevel'] == sys.version_info[3]
    assert r['python']['version']['serial'] == sys.version_info[4]
    assert r['python']['version_info'] == list(sys.version_info)
    assert r['python']['executable'] == sys.executable
    assert r['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-11 05:09:27.368601
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a PythonFactCollector
    pfc = PythonFactCollector()

    # Get the python facts from the PythonFactCollector
    python_facts = pfc.collect()

    # Assert that the major version number can be found in the python_facts
    assert python_facts['python']['version']['major'] == sys.version_info[0]

    # Assert that the minor version number can be found in the python_facts
    assert python_facts['python']['version']['minor'] == sys.version_info[1]

    # Assert that the micro version number can be found in the python_facts
    assert python_facts['python']['version']['micro'] == sys.version_info[2]

    # Assert that the releaselevel can be found in the python_facts

# Generated at 2022-06-11 05:09:32.245641
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:09:40.149752
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Act
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    # Assert
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:09:48.722632
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector

    python_fact_collector = PythonFactCollector()

    facts = {
        'ansible_python_version': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
        }
    }
