

# Generated at 2022-06-11 04:59:50.906429
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None, None)
    python_facts = collector.collect()
    assert python_facts['python']['version_info'][0]
    assert python_facts['python']['version_info'][4]
    assert python_facts['python']['executable']


# Generated at 2022-06-11 04:59:59.913012
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_collector = PythonFactCollector()
    python_fact = python_collector.collect()

    assert 'python' in python_fact

    python_fact_information = python_fact['python']

    assert 'version' in python_fact_information

    assert 'major' in python_fact_information['version']
    assert 'minor' in python_fact_information['version']
    assert 'micro' in python_fact_information['version']
    assert 'releaselevel' in python_fact_information['version']
    assert 'serial' in python_fact_information['version']

    assert 'version_info' in python_fact_information
    assert 'executable' in python_fact_information
    assert 'has_sslcontext' in python_fact_information

    if sys.implementation.name:
        assert 'type' in python_fact

# Generated at 2022-06-11 05:00:02.710317
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    :avocado: tags=python
    """
    collector = PythonFactCollector()
    collected_facts = collector.collect()
    assert set(['python']) == set(collected_facts.keys())

# Generated at 2022-06-11 05:00:06.487183
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    def mock_var(self):
        return "CPython"

    monkeypatch.setattr(sys, 'implementation', lambda: mock_var)

    pc = PythonFactCollector()
    facts = pc.collect()
    assert facts['python']['type'] == "CPython"

# Generated at 2022-06-11 05:00:08.469287
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test that the method returns a dictionary
    pfc = PythonFactCollector()
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-11 05:00:16.565592
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    collected_facts = {}

    collected_facts = pfc.collect(collected_facts)
    assert collected_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.version_info[0]
        }
    }


# Generated at 2022-06-11 05:00:25.198504
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:00:33.747909
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    pfc._collect_platform_python = lambda module, collected_facts: {'python': {'version': {'major': 2, 'minor': 7, 'micro': 5, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 5, 'final', 0], 'executable': '/usr/bin/python', 'type': 'CPython', 'has_sslcontext': False}}

# Generated at 2022-06-11 05:00:39.007358
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = python_fact_collector.collect()

    assert 'python' in collected_facts.keys()
    assert 'version' in collected_facts['python'].keys()
    assert 'version_info' in collected_facts['python'].keys()
    assert 'executable' in collected_facts['python'].keys()
    assert 'has_sslcontext' in collected_facts['python'].keys()

# Generated at 2022-06-11 05:00:48.921044
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    if sys.version_info[0] < 3:
        py_ver = 'python2'
    elif sys.version_info[0] == 3 and sys.version_info[1] < 5:
        py_ver = 'python3'
    else:
        py_ver = 'python3.5'

    py_impl_ver = '%s.%s' % (sys.implementation.name, sys.implementation.version)

    pfc = PythonFactCollector()
    py_facts = pfc.collect()

    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys

# Generated at 2022-06-11 05:00:54.573427
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # set up
    m = PythonFactCollector()
    result = m.collect(module=None, collected_facts=None)
    # check
    assert(result['python']['version']['releaselevel'] == 'final')

# Generated at 2022-06-11 05:01:00.617722
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    assert 'python' in facts
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version_info'] == list(sys.version_info)
    #assert facts['python']['executable'] == sys.executable
    #assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:01:02.353072
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    pfc = PythonFactCollector()
    test_dict = pfc.collect()
    # Check at least for the major version
    assert isinstance(test_dict['python']['version']['major'], int)

# Generated at 2022-06-11 05:01:10.765202
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    ansible_facts = {}
    python_facts_dict = python_fact_collector.collect(collected_facts=ansible_facts)
    python_facts = python_facts_dict['ansible_local']['python']
    assert isinstance(python_facts['version'], dict)
    assert isinstance(python_facts['version_info'], list)
    assert isinstance(python_facts['executable'], str)
    assert isinstance(python_facts['has_sslcontext'], bool)
    assert isinstance(python_facts['type'], str)

# Generated at 2022-06-11 05:01:12.668522
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # TODO: Test PythonFactCollector.collect method
    pass

# Generated at 2022-06-11 05:01:22.807004
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector({}, [])
    test_collect = python_fact_collector.collect()
    assert test_collect['python']['version']['major'] == sys.version_info[0]
    assert test_collect['python']['version']['minor'] == sys.version_info[1]
    assert test_collect['python']['version']['micro'] == sys.version_info[2]
    assert test_collect['python']['version']['releaselevel'] == sys.version_info[3]
    assert test_collect['python']['version']['serial'] == sys.version_info[4]
    assert test_collect['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:01:25.392827
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector(None, {})
    facts = fact_collector.collect()
    print(facts['python']['version'])

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-11 05:01:35.197208
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py = PythonFactCollector()
    py_facts = py.collect()

    assert 'python' in py_facts
    assert isinstance(py_facts['python']['version_info'], list)
    assert isinstance(py_facts['python']['version'], dict)
    assert isinstance(py['python']['has_sslcontext'], bool)
    assert py_facts['python']['executable'] is not None
    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]

# Generated at 2022-06-11 05:01:45.797042
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Init
    p = PythonFactCollector()
    # None object
    result = p.collect()
    # Testing
    assert result == {'python':
                        {
                            'version': {
                                'major': sys.version_info[0],
                                'minor': sys.version_info[1],
                                'micro': sys.version_info[2],
                                'releaselevel': sys.version_info[3],
                                'serial': sys.version_info[4]
                            },
                            'version_info': list(sys.version_info),
                            'executable': sys.executable,
                            'has_sslcontext': HAS_SSLCONTEXT,
                            'type': 'CPython'
                        }
                    }
    # Clean up
    del p

# Generated at 2022-06-11 05:01:51.871390
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None)

    data = collector.collect()
    assert len(data.keys()) == 1
    assert 'python' in data
    assert len(data['python'].keys()) == 5
    assert 'version' in data['python']
    assert 'version_info' in data['python']
    assert 'executable' in data['python']
    assert 'has_sslcontext' in data['python']
    assert 'type' in data['python']


# Test installed platform specific dependencies
# This is essentially testing the ability to import all required libraries
# on the system, as well as testing version requirements.

# Generated at 2022-06-11 05:01:56.417112
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()


if __name__ == "__main__":
    test_PythonFactCollector_collect()

# Generated at 2022-06-11 05:02:01.366205
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pythonfc = PythonFactCollector()
    result = pythonfc.collect()
    expected_result = {'python': {'version': {'major': 2, 'minor': 7, 'micro': 10, 'releaselevel': 'final', 'serial': 0},
    'version_info': [2, 7, 10, 'final', 0], 'executable': '/usr/bin/python', 'type': 'CPython', 'has_sslcontext': True}}
    assert result == expected_result

# Generated at 2022-06-11 05:02:10.539979
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()['python']

    assert python_facts['version']['major'] == sys.version_info[0]
    assert python_facts['version']['minor'] == sys.version_info[1]
    assert python_facts['version']['micro'] == sys.version_info[2]
    assert python_facts['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['version']['serial'] == sys.version_info[4]
    assert python_facts['version_info'] == list(sys.version_info)
    assert python_facts['executable'] == sys.executable
    assert python_facts['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-11 05:02:15.133922
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)

# Generated at 2022-06-11 05:02:25.385749
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Basic unit test of the collect method of the PythonFactCollector class
    '''

    c = PythonFactCollector()

    f = c.collect()

    assert f['python']['version']['major'] == sys.version_info[0]
    assert f['python']['version']['minor'] == sys.version_info[1]
    assert f['python']['version']['micro'] == sys.version_info[2]
    assert f['python']['version']['releaselevel'] == sys.version_info[3]
    assert f['python']['version']['serial'] == sys.version_info[4]
    assert f['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:02:31.912632
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    fact_data = python_fact_collector.collect()
    assert fact_data['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-11 05:02:34.904345
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Make sure the PythonFactCollector works as expected by collecting facts and
    checking the result.
    """
    try:
        pfc = PythonFactCollector()
        pfc.collect()
    except Exception:
        assert False, "Fail to collect facts."

# Generated at 2022-06-11 05:02:45.244158
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect(module=None, collected_facts={})
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:02:45.908021
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector()

# Generated at 2022-06-11 05:02:51.449435
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_facts = PythonFactCollector().collect()

    assert python_facts is not None
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-11 05:03:03.361206
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    expected_python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    if sys.version_info[0] == 2:
        expected_python_facts['python']['version_info'] = [
            2,
            7,
            15,
            'final',
            0
        ]
        expected_python_facts['python']['executable'] = '/usr/bin/python'

# Generated at 2022-06-11 05:03:09.174433
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']



# Generated at 2022-06-11 05:03:16.287199
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector(None)
    res = pc.collect()
    assert type(res) is dict
    assert res == {'python': {u'version_info': [2, 7, 10, 'final', 0], u'has_sslcontext': False, u'version': {u'serial': 0, u'micro': 10, u'releaselevel': 'final', u'major': 2, u'minor': 7}, 'type': 'CPython', u'executable': u'/usr/bin/python'}}
    # Ensure we get the same version info that comes back from sys.version_info
    assert res['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:03:22.630259
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = python_fact_collector.collect()
    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]
    assert collected_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:03:29.199837
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_info = pfc.collect()
    assert isinstance(python_info, dict) == True
    assert isinstance(python_info['python'], dict) == True
    assert isinstance(python_info['python']['type'], str) == True
    assert isinstance(python_info['python']['version'], dict) == True
    assert isinstance(python_info['python']['version_info'], list) == True
    assert isinstance(python_info['python']['executable'], str) == True
    assert isinstance(python_info['python']['has_sslcontext'], bool) == True

# Generated at 2022-06-11 05:03:31.981320
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert result['python']['type'] in ['Jython', 'PyPy', 'CPython', None]
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:03:33.155851
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    p.collect()


# Generated at 2022-06-11 05:03:41.650534
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector.collect()
    assert python_facts is not None
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:03:45.609273
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts_dict = PythonFactCollector().collect()
    assert python_facts_dict['python']['version']['major'] == sys.version_info[0]
    assert python_facts_dict['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:03:53.591576
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()

    ans = c.collect()

    # Python version
    assert (ans['python']['version']['major'] == sys.version_info[0])
    assert (ans['python']['version']['minor'] == sys.version_info[1])
    assert (ans['python']['version']['micro'] == sys.version_info[2])
    assert (ans['python']['version']['releaselevel'] == sys.version_info[3])
    assert (ans['python']['version']['serial'] == sys.version_info[4])
    assert (ans['python']['version_info'] == list(sys.version_info))

    # Check executable
    assert (ans['python']['executable'] == sys.executable)

    # Check

# Generated at 2022-06-11 05:04:10.627388
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    python_collector = PythonFactCollector()

    def get_all_facts(module):
        facts = collector.collect_all(module=module)
        return facts

    m = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False)

    # Collect facts
    facts = get_all_facts(module=m)
    python_facts = facts['ansible_python']

    # Assert that the python facts have been collected
    assert python_facts['version_info'] == list(sys.version_info)
    assert python_facts['version']['major'] == sys.version_info[0]

# Generated at 2022-06-11 05:04:15.381837
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    python_facts = p.collect()
    assert 'python' in python_facts, 'No python keys found in the output'
    assert python_facts['python']['version_info'][0] >= 2, 'Python major version must be 2 or more'
    assert python_facts['python']['version_info'][1] >= 4, 'Python minor version must be 4 or more'

# Generated at 2022-06-11 05:04:23.416901
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test case"""

    # Mock dependencies
    class MockSys(object):

        version_info = 6,12,9,'final',0
        executable = 'fake_executable'
        implementation = Mock()
        implementation.name = 'fake_name'

    def mock_hasattr(arg):
        if arg == 'subversion':
            return True
        elif arg == 'implementation':
            return False
        else:
            return True

    mock_sys = MockSys()
    mock_sys.hasattr = mock_hasattr

    python_fact_collector = PythonFactCollector()
    python_fact_collector.sys = mock_sys

    # Call the method under test
    result = python_fact_collector.collect()

    assert result is not None
    assert result['python'] is not None

# Generated at 2022-06-11 05:04:29.287654
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_collector = PythonFactCollector()
    facts = test_collector.collect()

    assert facts['python'] == {'version_info': [2, 7, 5, 'final', 0],
                               'has_sslcontext': False,
                               'type': 'cpython',
                               'version': {'micro': 5,
                                           'major': 2,
                                           'minor': 7,
                                           'releaselevel': 'final',
                                           'serial': 0},
                               'executable': '/usr/bin/python'}

# Generated at 2022-06-11 05:04:37.148998
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test collect method with no ssl.create_default_context() support
    module = []
    python_object = PythonFactCollector()
    python_object.collect(collected_facts={}, module=module)
    python_facts = python_object.collect(collected_facts={}, module=module)
    assert python_facts is not None
    assert python_facts['python']['has_sslcontext'] is False

    # Test collect method with ssl.create_default_context() support
    module = []
    python_object = PythonFactCollector()
    python_object.collect(collected_facts={}, module=module)
    python_facts = python_object.collect(collected_facts={}, module=module)
    assert python_facts is not None

# Generated at 2022-06-11 05:04:45.641311
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    def test_instance_check(mock_self):
        mock_self.name = 'python'
        mock_self._fact_ids = set()
        return mock_self

    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    mock_module = Mock(name='mock_module')
    python_facts = PythonFactCollector()
    python_facts.collect = test_instance_check(python_facts.collect)
    python_facts.collect(mock_module)

# Generated at 2022-06-11 05:04:49.058701
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    This test just verifies that the method collect of the PythonFactCollector
    returns a dictionary with a 'python' entry.
    """
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts, 'The result should contain a python entry'

# Generated at 2022-06-11 05:04:53.021478
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector(None, None)

    # TODO: Add proper tests.
    result = fact_collector.collect(None, None)
    assert result == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 15, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 15, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-11 05:04:55.669246
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector.collect()
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['version']['serial'] == sys.version_info[4]



# Generated at 2022-06-11 05:05:03.946539
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Basic test of the validation of the facts as returned by PythonFactCollector.collect()
    """
    coll = PythonFactCollector()
    facts = coll.collect()
    assert isinstance(facts.get('python'), dict)
    assert isinstance(facts['python'].get('version'), dict)
    assert isinstance(facts['python'].get('version').get('major'), int)
    assert isinstance(facts['python'].get('version').get('minor'), int)
    assert isinstance(facts['python'].get('version').get('micro'), int)
    assert isinstance(facts['python'].get('version').get('releaselevel'), str)
    assert isinstance(facts['python'].get('version').get('serial'), int)
    assert isinstance(facts['python'].get('version_info'), list)

# Generated at 2022-06-11 05:05:19.766208
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python = PythonFactCollector()
    assert isinstance(python.collect(), dict)

# Generated at 2022-06-11 05:05:25.514979
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = None
    collected_facts = {}
    fact = PythonFactCollector.collect(module, collected_facts)
    assert fact == {'python': {'version': {'serial': 0, 'minor': 6, 'major': 2, 'micro': 4, 'releaselevel': 'alpha'}, 'version_info': [2, 6, 4, 'alpha', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}
    assert PythonFactCollector.collect(module, collected_facts) == fact

# Generated at 2022-06-11 05:05:32.608353
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, BaseFactCollector)
    assert isinstance(python_fact_collector, PythonFactCollector)
    assert python_fact_collector.name == 'python'

    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts

# Generated at 2022-06-11 05:05:34.636443
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = 'module'
    collected_facts = 'collected_facts'
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result is not None
    assert result['python']['type'] is not None

# Generated at 2022-06-11 05:05:42.588992
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json
    import os

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
    from ansible.module_utils.facts import Runner
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    facts_collector = PythonFactCollector()
    facts_runner = Runner(facts_collector)
    fact_list = facts_collector.collect(facts_runner)

    with open("/tmp/python_facts.json", "w") as wf:
        wf.write(json.dumps(fact_list))

if __name__ == "__main__":
    test_PythonFactCollector_collect()

# Generated at 2022-06-11 05:05:51.011509
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    # Check that the returned dict is an instance of dict and not a subclass
    assert isinstance(python_fact_collector.collect(), dict)

    # Check that the returned dict has 'python' as key
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts

    # Check the value of 'python.update(...)'
    # Check the type of the dict
    assert isinstance(python_facts['python'], dict)
    import sys

# Generated at 2022-06-11 05:05:59.430451
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""

    pfcollector = PythonFactCollector()

    # Call the method
    pffacts = pfcollector.collect()

    # Test the returned data structure
    assert isinstance(pffacts, dict)
    assert 'python' in pffacts
    assert isinstance(pffacts['python'], dict)

    # Check the 'version' dict
    assert 'version' in pffacts['python']
    assert isinstance(pffacts['python']['version'], dict)
    assert 'major' in pffacts['python']['version']
    assert isinstance(pffacts['python']['version']['major'], int)
    assert 'minor' in pffacts['python']['version']

# Generated at 2022-06-11 05:06:07.438441
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    p1 = PythonFactCollector()
    p1_result = p1.collect()

    assert p1_result['python']['version']['major'] == sys.version_info[0]
    assert p1_result['python']['version']['minor'] == sys.version_info[1]
    assert p1_result['python']['version']['micro'] == sys.version_info[2]
    assert p1_result['python']['version']['releaselevel'] == sys.version_info[3]
    assert p1_result['python']['version']['serial'] == sys.version_info[4]
    assert p1_result['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:06:15.418125
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable


# Generated at 2022-06-11 05:06:25.306765
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    This is a test stub method to test collect method of class PythonFactCollector.
    """
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()

    # Check version
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:06:57.376500
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test case for method PythonFactCollector.collect"""
    pfc = PythonFactCollector()
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-11 05:07:05.703875
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector(None, 'ansible.builtin', ['python'])
    python_facts = python_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts

# Generated at 2022-06-11 05:07:13.230737
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_col = PythonFactCollector()
    py_facts = py_col.collect()
    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_facts['python']['version']['serial'] == sys.version_info[4]
    assert py_facts['python']['version_info'] == list(sys.version_info)
    assert py_facts['python']['executable'] == sys.executable
   

# Generated at 2022-06-11 05:07:21.070986
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    ansible_facts = python_fact_collector.collect()['ansible_facts']
    assert ansible_facts['python']['version']['major'] == sys.version_info[0]
    assert ansible_facts['python']['version']['minor'] == sys.version_info[1]
    assert ansible_facts['python']['version']['micro'] == sys.version_info[2]
    assert ansible_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert ansible_facts['python']['version']['serial'] == sys.version_info[4]
    assert ansible_facts['python']['type'] == sys.subversion[0]

# Generated at 2022-06-11 05:07:30.070260
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    This test ensures that the PythonFactCollector class can be instantiated,
    that it has the correct name, and that the collect function produces
    the expected results.
    """
    # Arrange
    python_finder = PythonFactCollector()

    # Act
    facts = python_finder.collect()

    # Assert
    assert isinstance(python_finder, PythonFactCollector)
    assert python_finder.name == 'python'
    assert 'python' in facts
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['type'] == sys.subversion[0] if hasattr(sys, 'subversion') else sys.implementation.name
    assert isinstance(facts['python']['version_info'], list)

# Generated at 2022-06-11 05:07:32.507636
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    test_obj = PythonFactCollector()

    # run without python2.6/facter/system_profiler
    result = test_obj.collect()

    # assert type(result) == dict
    assert isinstance(result, dict)



# Generated at 2022-06-11 05:07:37.705678
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts_collector = PythonFactCollector()
    python_facts = python_facts_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:07:44.691512
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Test of method collect of class PythonFactCollector'''
    my_PythonFactCollector = PythonFactCollector()
    my_PythonFactCollector.collect()
    if my_PythonFactCollector.python['version']['major'] != 3:
        raise ValueError("major version is not 3")
    if my_PythonFactCollector.python['version']['minor'] < 5:
        raise ValueError("minor version is not at least 5")
    if my_PythonFactCollector.python['version']['micro'] < 3:
        raise ValueError("micro version is not at least 3")
    if my_PythonFactCollector.python['version']['releaselevel'] != 'final':
        raise ValueError("releaselevel is not final")

# Generated at 2022-06-11 05:07:48.398368
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Mock base facts class

    class MockBaseFactCollector():
        name = 'base'
        _fact_ids = set()

    tested_facts = {}
    collected_facts = {}
    mock = MockBaseFactCollector()

    # Collect facts

    x = PythonFactCollector()
    facts = x.collect(mock, collected_facts)

    # Test results

    assert facts == tested_facts

# Generated at 2022-06-11 05:07:54.699710
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector, BaseFactCollector
    from ansible.module_utils.facts.facts import Facts

    collected_facts = Facts(collected_facts={})
    BaseFactCollector.populate(collected_facts, 'python')

    assert isinstance(collected_facts, Facts)
    assert len(collected_facts.python_facts) > 0
    assert len(collected_facts.python_facts['python']) > 0
    assert 'version' in collected_facts.python_facts['python']
    assert 'executable' in collected_facts.python_facts['python']
    assert 'has_sslcontext' in collected_facts.python_facts['python']

# Generated at 2022-06-11 05:09:07.554184
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from distutils.sysconfig import get_python_version
    from ansible.module_utils.facts import ansible_facts
    ansible_facts['ansible_python'] = PythonFactCollector().collect()['python']
    my_dict = { 'version': { 'releaselevel': 'final',
                             'minor': 6,
                             'micro': 6,
                             'serial': 0,
                             'major': 3 },
                'type': 'CPython',
                'version_info': [3, 6, 6, 'final', 0],
                'executable': sys.executable,
                'has_sslcontext': HAS_SSLCONTEXT }
    for key in my_dict.keys():
        assert my_dict[key] == ansible_facts['ansible_python'][key]

# Generated at 2022-06-11 05:09:13.145631
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()
    assert facts == {'ansible_python': {'executable': '/usr/bin/python',
                                        'has_sslcontext': True,
                                        'type': 'CPython',
                                        'version': {'major': 2,
                                                    'minor': 7,
                                                    'micro': 5,
                                                    'releaselevel': 'final',
                                                    'serial': 0},
                                        'version_info': [2, 7, 5, 'final', 0]}}

# Generated at 2022-06-11 05:09:14.153750
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    p.collect()
    return p

# Generated at 2022-06-11 05:09:17.793116
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfacts = pfc.collect()

    assert 'python' in pfacts
    assert 'version' in pfacts['python']
    assert 'version_info' in pfacts['python']
    assert 'executable' in pfacts['python']
    assert 'type' in pfacts['python']
    assert 'has_sslcontext' in pfacts['python']

# Generated at 2022-06-11 05:09:22.618865
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect() == {
            "python": {
                "type": "CPython",
                "version": {
                    "major": 2,
                    "minor": 7,
                    "micro": 5,
                    "releaselevel": "final",
                    "serial": 0
                },
                "version_info": [2, 7, 5, "final", 0],
                "executable": "/usr/bin/python",
                "has_sslcontext": True
            }
        }

# Generated at 2022-06-11 05:09:29.171862
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test data
    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4],
            },
            'version_info': [sys.version_info[0], sys.version_info[1], sys.version_info[2], sys.version_info[3], sys.version_info[4]],
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-11 05:09:35.226162
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''
    data = {
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'CPython',
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable
        }
    assert PythonFactCollector.collect() == {'python': data}

# Generated at 2022-06-11 05:09:36.893602
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pythonfact_col = PythonFactCollector()
    pythonfact_col.collect()


# Generated at 2022-06-11 05:09:45.505155
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect()."""

    import sys

    # Create instance of class PythonFactCollector
    python_fact_collector = PythonFactCollector()

    # Simulate call to collect
    python_facts = python_fact_collector.collect()
