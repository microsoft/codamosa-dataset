

# Generated at 2022-06-11 04:59:53.591596
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    collector = PythonFactCollector()

    # Execute it get the collected facts
    python_facts = collector.collect()

    # Test that we have get the expected data
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python

# Generated at 2022-06-11 05:00:02.641710
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Get a fact object for collecting python facts
    factCollector = PythonFactCollector(None, None)
    # Get a dictionary of facts from the fact collector
    python_facts = factCollector.collect()
    # Verify that the dictionary is not empty
    assert len(python_facts) > 0
    # Get the python facts
    python_facts = python_facts['python']
    # Verify that the dictionary is not empty
    assert len(python_facts) > 0
    # Get the python version facts
    python_version = python_facts['version']
    # Verify that the Python version major is not None
    assert python_version['major'] is not None
    # Verify that the Python version minor is not None
    assert python_version['minor'] is not None
    # Verify that the Python version micro is not None

# Generated at 2022-06-11 05:00:11.762233
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method collect of class PythonFactCollector"""

    # Initialize a PythonFactCollector object
    pfc = PythonFactCollector()

    # Call the method
    python_facts = pfc.collect()

    # Assert keys in returned dictionary
    assert 'python' in python_facts

    # Assert keys and values in dictionary returned by
    # method collect
    assert 'version' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'version' in python_facts['python']['version']
    assert 'major' in python_facts['python']['version']

# Generated at 2022-06-11 05:00:13.240253
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:00:21.594546
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable


# Generated at 2022-06-11 05:00:25.237398
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts['python'], dict)
    assert isinstance(facts['python']['version'], dict)
    assert facts['python']['version_info'][0] == sys.version_info[0]

# Generated at 2022-06-11 05:00:30.041619
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-11 05:00:33.280610
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create class instance
    fact_collector = PythonFactCollector()
    # Call method collect and get facts
    facts = fact_collector.collect()
    # Assert that dictionary returned and that dictionary is not empty
    assert isinstance(facts, dict)
    assert facts

# Generated at 2022-06-11 05:00:41.376952
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors.python import PythonFactCollector
    python_fact_collector = PythonFactCollector()

    result = python_fact_collector.collect()
    assert result == {
        'python': {
            'version': {
                'releaselevel': 'final',
                'micro': 0,
                'minor': 7,
                'serial': 0,
                'major': 2
            },
            'version_info': [2, 7, 0, 'final', 0],
            'type': 'CPython',
            'executable': '/usr/local/bin/python',
            'has_sslcontext': True
        }
    }

    assert python_fact_collector.name == 'python'

# Generated at 2022-06-11 05:00:51.476257
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    assert PythonFactCollector.collect(None) == {'python': {'version': {'major': 2, 'micro': 7, 'releaselevel': 'final', 'minor': 6, 'serial': 0}, 'executable': '/usr/lib/python2.7/lib-dynload', 'has_sslcontext': False, 'version_info': [2, 7, 0, 'final', 0], 'type': None}}
    assert PythonFactCollector.collect(None) == {'python': {'version': {'major': 2, 'micro': 7, 'releaselevel': 'final', 'minor': 6, 'serial': 0}, 'executable': '/usr/lib/python2.7/lib-dynload', 'has_sslcontext': False, 'version_info': [2, 7, 0, 'final', 0], 'type': None}}

# Generated at 2022-06-11 05:01:03.709847
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json
    import sys

    pfc = PythonFactCollector({})
    result = pfc.collect()
    assert result == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-11 05:01:06.405460
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    result = c.collect()
    real_result = sys.version_info
    assert result['python']['version_info'] == list(real_result)

# Generated at 2022-06-11 05:01:14.677049
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""
    py_facts = PythonFactCollector()
    result = py_facts.collect()
    assert result == {'python': {'version': {'releaselevel': 'final', 'minor': 7, 'micro': 2, 'major': 3, 'serial': 0}, 'type': 'CPython', 'version_info': [3, 7, 2, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False}}

# Generated at 2022-06-11 05:01:21.358371
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {}

    python_facts = python_fact_collector.collect(collected_facts=collected_facts)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-11 05:01:25.793938
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert isinstance(facts['python'], dict)
    assert facts['python']['version'] is not None
    assert facts['python']['version_info'] is not None
    assert facts['python']['has_sslcontext'] is True
    assert facts['python']['executable'] is not None
    assert facts['python']['type'] is not None

# Generated at 2022-06-11 05:01:36.429424
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Get an instance of the PythonFactCollector class
    python_fact_collector = PythonFactCollector()

    # Get the facts
    python_facts = python_fact_collector.collect()

    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:01:38.797514
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector({})
    facts = pf.collect()
    assert 'python' in facts.keys()


# Generated at 2022-06-11 05:01:42.555750
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect()['python']['version']['major'] == sys.version_info[0]
    assert f.collect()['python']['version']['minor'] == sys.version_info[1]

# Generated at 2022-06-11 05:01:45.576229
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    t = PythonFactCollector()
    facts = t.collect()

    # Check if key 'python' is present in facts
    assert facts['python'] is not None
    assert facts['python']['has_sslcontext'] is not None


# Generated at 2022-06-11 05:01:52.059300
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    import sys
    import types
    import random

    python_version_info = (random.randint(0, 100),
                           random.randint(0, 100),
                           random.randint(0, 100),
                           '',
                           random.randint(0, 100))

    python_version = ''
    for v in python_version_info:
        python_version += str(v) + '.'

    python_executable = '/usr/bin/python'

    tmp_sys_module = types.ModuleType('sys')
    tmp_sys_module.version_info = python_version_info
    tmp_sys_module.executable = python_executable

    def mock_import_module(name):
        if name == 'sys':
            return tmp_sys_module
        else:
            return sys.modules

# Generated at 2022-06-11 05:02:05.979125
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()['python']

    assert python_facts['version']['major']
    assert python_facts['version']['minor']
    assert python_facts['version']['micro']
    assert python_facts['version']['releaselevel'] in ('alpha', 'beta', 'candidate', 'final')
    assert python_facts['version']['serial'] >= 0

    assert python_facts['version_info']
    assert python_facts['executable']

    if python_facts['type'] is None:
        assert python_facts['has_sslcontext']

# Generated at 2022-06-11 05:02:15.896248
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a class instance
    PyFC = PythonFactCollector()

    input_params = {}
    output_params = PyFC.collect(collected_facts=None, module=None)

    assert output_params['python']['executable'] == sys.executable
    assert output_params['python']['version']['major'] == sys.version_info[0]
    assert output_params['python']['version']['minor'] == sys.version_info[1]
    assert output_params['python']['version']['micro'] == sys.version_info[2]
    assert output_params['python']['version']['releaselevel'] == sys.version_info[3]
    assert output_params['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:02:26.097977
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import collect_subset

    # Create a PythonFactCollector instance
    pfc = PythonFactCollector()

    # Create a dict for collected_facts
    collected_facts = dict()

    # Call method collect with the created instances
    pfc.collect(None, collected_facts)

    # Create expected value
    python_facts = dict()
    python_facts['python'] = dict()
    python_facts['python']['version'] = dict()
    python_facts['python']['version']['major'] = sys.version_info[0]
    python_facts['python']['version']['minor'] = sys.version_info[1]

# Generated at 2022-06-11 05:02:28.987170
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    for test_fact_name in ['version_info', 'version', 'executable', 'type', 'has_sslcontext']:
        assert test_fact_name in python_facts['python']

# Generated at 2022-06-11 05:02:35.406480
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import factual

    test_collector = PythonFactCollector()
    facts_collector = FactsCollector(fact_collectors=[test_collector])
    facts = facts_collector.get_facts(factual.FactsCache())


# Generated at 2022-06-11 05:02:45.855266
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    class MockModuleUtils:
        def __init__(self):
            self.facts = {}

        @property
        def loader(self):
            return self

        def get_module_path(self, path):
            return '/'

    class MockModule:
        def __init__(self):
            self.params = {}
            self.module_implementation_prereqs = {}

            # We need this to override the ansible.module_utils import in
            # the real thing.
            self.ansible_module_utils = MockModuleUtils()

    python_collector = PythonFactCollector()
    result = python_collector.collect(MockModule())

# Generated at 2022-06-11 05:02:52.741863
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    actual = PythonFactCollector().collect()
    assert actual is not None
    assert 'python' in actual
    assert len(actual['python']) == 5
    assert isinstance(actual['python']['version'], dict)
    assert len(actual['python']['version']) == 5
    assert isinstance(actual['python']['version_info'], list)
    assert len(actual['python']['version_info']) == 5
    assert isinstance(actual['python']['has_sslcontext'], bool)

# Generated at 2022-06-11 05:02:58.827046
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    facts = pf.collect()
    assert 'version' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:03:09.137504
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = {}
    fact_collector = PythonFactCollector()
    fact_collector.collect(collected_facts=collected_facts)
    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]
    assert collected_facts['python']['version_info'] == list(sys.version_info)
    assert collected_facts

# Generated at 2022-06-11 05:03:17.385604
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import io

    class TestParams(object):
        def __init__(self, executable=None, version_info=None):
            self._executable = executable
            self._version_info = version_info

        def executable(self):
            return self._executable

        def version_info(self):
            return self._version_info

    sys.modules['ansible.module_utils.facts.collector'] = sys.modules['ansible.module_utils.facts.collector']

    # Test for has_sslcontext=True and type=jython
    sys.version_info = (2, 7, 11, 'final', 0)
    sys.subversion = ('jython', '2.7.1RC2', 'c9e75a7d9cc4', '')

# Generated at 2022-06-11 05:03:35.514691
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'type' in facts['python']
    assert 'version_info' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:03:43.778692
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ AnsibleModule argument `module` is None, so we are just testing the
        function call.
    """
    expected_result = {
        'local': {
            'python': {
                'executable': sys.executable,
                'has_sslcontext': True,
                'type': 'CPython',
                'version': {
                    'major': 2,
                    'minor': 7,
                    'micro': 11,
                    'releaselevel': 'final',
                    'serial': 0
                },
                'version_info': [
                    2, 7, 11, 'final', 0
                ]
            }
        }
    }
    result = PythonFactCollector().collect()
    assert result == expected_result

# Generated at 2022-06-11 05:03:45.910525
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert isinstance(collector.collect(), dict)
    assert 'python' in collector.collect()

# Generated at 2022-06-11 05:03:51.166106
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    result = c.collect()
    assert result == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 12, 'releaselevel': 'final', 'serial': 0},
                                'version_info': [2, 7, 12, 'final', 0],
                                'executable': '/usr/bin/python',
                                'type': 'CPython',
                                'has_sslcontext': True}}

# Generated at 2022-06-11 05:03:59.364422
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:04:09.654662
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts import get_collector_instance

    try:
        pf = PythonFactCollector()
        pf.collect()
    except Exception:
        assert False, 'PythonFactCollector.collect() should not fail'

    pf = get_collector_instance('python')
    assert pf is not None
    facts = {}
    pf.collect(collected_facts=facts)
    assert 'python' in facts
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:04:18.333992
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['type'] == 'CPython'
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:04:20.224529
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect()
    # assert HostnameFactCollector().collect() == { 'ansible_python': sys.version_info }

# Generated at 2022-06-11 05:04:27.967481
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    result = pyfc.collect()
    assert list(result.keys()) == ['python']
    assert isinstance(result['python'], dict)
    assert list(result['python'].keys()) == ['version', 'version_info', 'executable', 'has_sslcontext', 'type']
    assert isinstance(result['python']['version'], dict)
    assert list(result['python']['version'].keys()) == ['major', 'minor', 'micro', 'releaselevel', 'serial']
    assert isinstance(result['python']['version']['major'], int)
    assert isinstance(result['python']['version']['minor'], int)
    assert isinstance(result['python']['version']['micro'], int)

# Generated at 2022-06-11 05:04:35.945243
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    python_facts = pyfc.collect()
    assert 'python' in python_facts
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:05:09.058289
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils import basic

    python_fact_collector = PythonFactCollector(
        module=basic.AnsibleModule(argument_spec={})
    )

    results = python_fact_collector.collect()
    assert 'python' in results

# Generated at 2022-06-11 05:05:17.028616
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # The module object passed to the python collect method
    # is not used at this time.
    fake_module = None

    # Create a PythonFactCollector object
    python_collector = PythonFactCollector()

    # Make a fake ansible facts dictionary
    fake_ansible_facts = {}

    # Call the method
    python_collector.collect(fake_module, fake_ansible_facts)

    # Check the result and make sure the python ansible facts are set
    assert 'python' in fake_ansible_facts

    # Test for the various python types
    # Test for cpython
    if 'subversion' in sys.__dict__:
        if sys.subversion[0] == 'CPython':
            assert fake_ansible_facts['python']['type'] == 'CPython'

    # Test for pypy

# Generated at 2022-06-11 05:05:21.468504
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact = PythonFactCollector()
    ret = fact.collect()
    assert ret == {u'python': {u'has_sslcontext': True, u'version': {u'releaselevel': u'final', u'serial': 0, u'major': 2, u'minor': 7, u'micro': 9}, u'type': u'CPython', u'version_info': [2, 7, 9, u'final', 0]}}

# Generated at 2022-06-11 05:05:29.301433
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    try:
        # Python 2
        import mock
    except ImportError:
        # Python 3
        from unittest import mock

    with mock.patch.object(PythonFactCollector, '_get_sys_version_info') as mock_method:
        mock_method.return_value = (2, 7, 9, 'final', 0)
        fake_module = mock.Mock()
        fake_module.params = {'gather_subset': '!all'}
        fake_module.params['gather_subset'] = ['!all', 'python']
        python_collector = PythonFactCollector(fake_module)
        result = python_collector.collect(fake_module)

# Generated at 2022-06-11 05:05:33.145229
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    assert 'python' in python_collector.collect()
    collected_facts = {}
    python_collector.collect(collected_facts=collected_facts)
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'has_sslcontext' in collected_facts['python']
    assert 'type' in collected_facts['python']

# Generated at 2022-06-11 05:05:41.029374
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform

    class MockModule():
        def __init__(self):
            self.params = {}

    fact_collector = PythonFactCollector(MockModule())
    result = fact_collector.collect()

    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

    if (platform.python_implementation() == 'CPython'):
        assert result['python']['version']['releaselevel'] == 'final'
        assert result['python']['type'] == 'cpython'
    elif (platform.python_implementation() == 'PyPy'):
        assert result['python']['type'] == 'pypy'

# Generated at 2022-06-11 05:05:42.322733
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert isinstance(c.collect(), dict)

# Generated at 2022-06-11 05:05:47.646710
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test collect method of PythonFactCollector"""
    pyfacts = PythonFactCollector()
    pyfacts.collect()
    assert pyfacts.collect() == {'python': {'has_sslcontext': True, 'version': {'micro': 0, 'releaselevel': 'final', 'serial': 0, 'major': 2, 'minor': 7}, 'executable': '/usr/bin/python', 'version_info': [2, 7, 6, 'final', 0], 'type': 'cpython'}}

# Generated at 2022-06-11 05:05:49.168398
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect()

# Generated at 2022-06-11 05:05:51.155681
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    result = python_fact.collect()
    assert 'python' in result
    assert result['python']['has_sslcontext'] is True

# Generated at 2022-06-11 05:06:31.275724
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    result = obj.collect()

    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT



# Generated at 2022-06-11 05:06:37.484497
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    mod = MockModule()
    mod.params = {}
    lib = PythonFactCollector()
    result = lib.collect(module=mod)
    assert isinstance(result, dict)
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    if sys.version_info[0] == 2:
        assert 'type' in result['python']
    else:
        assert 'type' not in result['python']


# Generated at 2022-06-11 05:06:45.341365
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    data = collector.collect()
    assert data["python"]["executable"] == sys.executable
    assert data["python"]["version"]["major"] == sys.version_info[0]
    assert data["python"]["version"]["minor"] == sys.version_info[1]
    assert data["python"]["version"]["micro"] == sys.version_info[2]
    assert data["python"]["version"]["releaselevel"] == sys.version_info[3]
    assert data["python"]["version"]["serial"] == sys.version_info[4]
    assert data["python"]["version_info"] == list(sys.version_info)
    assert data["python"]["has_sslcontext"] == HAS_SSLCONTEXT


# Generated at 2022-06-11 05:06:51.983124
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = pc.collect()
    assert facts == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': 'CPython'
    }}

# Generated at 2022-06-11 05:07:00.320828
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_data = fact_collector.collect()

    assert 'python' in fact_data
    assert fact_data['python']['version']['major'] == sys.version_info[0]
    assert fact_data['python']['version']['minor'] == sys.version_info[1]
    assert fact_data['python']['version']['micro'] == sys.version_info[2]
    assert fact_data['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_data['python']['version']['serial'] == sys.version_info[4]
    assert fact_data['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:07:06.135480
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc.collect() == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }}

# Generated at 2022-06-11 05:07:13.921127
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    AnsibleModule._load_params (Ansible 2.9+) or AnsibleModule.load_params (Ansible 2.3+) is not mocked,
    so AnsibleModule.__init__() and AnsibleModule.exit_json() are called during testing.
    """
    # Expected Facts

# Generated at 2022-06-11 05:07:21.580194
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    fc = PythonFactCollector()
    facts = fc.collect()

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCON

# Generated at 2022-06-11 05:07:30.498792
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:07:32.353913
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:08:13.065299
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    from mock import patch

    from ansible.module_utils.facts.collector import BaseFactCollector

    with patch.object(BaseFactCollector, '__init__', return_value=None):
        python_facts = PythonFactCollector()
        result = python_facts.collect()

        assert result
        assert 'python' in result
        assert 'version' in result['python']
        assert 'major' in result['python']['version']
        assert 'minor' in result['python']['version']
        assert 'micro' in result['python']['version']
        assert 'releaselevel' in result['python']['version']
        assert 'serial' in result['python']['version']
        assert 'version_info' in result['python']
        assert 'executable' in result['python']
       

# Generated at 2022-06-11 05:08:14.723390
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None)
    facts = collector.collect()
    assert facts['python']['executable'].endswith('/python')

# Generated at 2022-06-11 05:08:21.038860
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    # Note: the executable path may change
    assert result == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 9, 'releaselevel': 'final', 'serial': 0},
                                 'version_info': [2, 7, 9, 'final', 0],
                                 'type': 'CPython',
                                 'executable': '/usr/bin/python',
                                 'has_sslcontext': False}}



# Generated at 2022-06-11 05:08:29.696332
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    facts = p.collect()

    assert(facts.has_key('python'))
    assert(facts['python']['version'])
    assert(facts['python']['version']['major'])
    assert(facts['python']['version']['minor'])
    assert(facts['python']['version']['micro'])
    assert(facts['python']['version']['releaselevel'])
    assert(facts['python']['version']['serial'])
    assert(facts['python']['version_info'])
    assert(facts['python']['executable'])
    assert(facts['python']['has_sslcontext'])


# Generated at 2022-06-11 05:08:33.477115
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    data = c.collect()
    assert 'python' in data
    assert 'version' in data['python']
    assert 'version_info' in data['python']
    assert 'executable' in data['python']
    assert 'has_sslcontext' in data['python']
    if hasattr(sys, 'subversion'):
        assert 'type' in data['python']

# Generated at 2022-06-11 05:08:37.761307
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Run collect to gather facts and assign to python_facts
    import ansible.module_utils.facts.collector.python
    python_facts = ansible.module_utils.facts.collector.python.PythonFactCollector().collect()

    # Check if field version is present in python_facts
    assert 'version' in python_facts['python']
    assert 'executable' in python_facts['python']

# Generated at 2022-06-11 05:08:42.925793
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert result == {'python': {'version': {'major': 3,
                                             'minor': 6,
                                             'micro': 6,
                                             'releaselevel': 'final',
                                             'serial': 0},
                                 'version_info': [3, 6, 6, 'final', 0],
                                 'executable': '/usr/bin/python3.6',
                                 'has_sslcontext': True,
                                 'type': 'CPython'}}

# Generated at 2022-06-11 05:08:44.845647
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector(None, None)

    facts = fact_collector.collect()

    assert facts.get('python') is not None

# Generated at 2022-06-11 05:08:45.321929
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-11 05:08:48.240541
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['fact_id'] == 'python'
    assert python_facts['python']['version_info'][0] == sys.version_info[0]

# Generated at 2022-06-11 05:09:24.403202
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    python_fact_collect = python_fact.collect({})
    assert isinstance(python_fact_collect, dict)

# Generated at 2022-06-11 05:09:25.659880
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector = PythonFactCollector()

    assert isinstance(python_fact_collector.collect(), dict)

# Generated at 2022-06-11 05:09:29.523449
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    python_facts_collector = get_collector_instance('python')
    facts = python_facts_collector.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:09:33.984316
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = pc.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:09:42.333959
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == platform.python_version_tuple()[0]
    assert python_facts['python']['version']['minor'] == platform.python_version_tuple()[1]
    assert python_facts['python']['version']['micro'] == platform.python_version_tuple()[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == sys.version_info
    assert python_facts['python']['executable'] == sys.exec