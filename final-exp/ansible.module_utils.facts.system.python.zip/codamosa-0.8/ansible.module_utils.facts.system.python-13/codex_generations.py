

# Generated at 2022-06-11 04:59:52.711455
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector('dummy')
    facts = fact_collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:00:01.688772
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method ``collect`` of class ``PythonFactCollector``."""
    # Test case 1:
    # Test both when ``sys.subversion`` and ``sys.implementation.name`` do exist.
    module = None
    collected_facts = None
    actual = PythonFactCollector().collect(module, collected_facts)

# Generated at 2022-06-11 05:00:11.080759
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    python_facts = p.collect()
    assert 'python' in python_facts
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info

# Generated at 2022-06-11 05:00:13.204823
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    facts = python_facts.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-11 05:00:21.556221
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyclass = PythonFactCollector()
    pyfacts = {}
    pyclass.collect(collected_facts= pyfacts)
    assert'python' in pyfacts
    assert'version' in pyfacts['python']
    assert pyfacts['python']['version']['major'] == sys.version_info[0]
    assert pyfacts['python']['version']['minor'] == sys.version_info[1]
    assert pyfacts['python']['version']['micro'] == sys.version_info[2]
    assert pyfacts['python']['version']['releaselevel'] == sys.version_info[3]
    assert pyfacts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:00:22.377803
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    p.collect()

# Generated at 2022-06-11 05:00:30.977456
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {}

    collected_facts = python_fact_collector.collect(collected_facts=collected_facts)

    assert len(collected_facts) == 1
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert 'type' in collected_facts['python']
    assert 'has_sslcontext' in collected_facts['python']
    assert isinstance(collected_facts['python']['version']['major'], int)
    assert isinstance(collected_facts['python']['version']['micro'], int)

# Generated at 2022-06-11 05:00:39.678618
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import json
    pfc = PythonFactCollector()
    modules_dir = '/some/nonexistent/directory'
    collected_facts = {}
    python_facts = pfc.collect(collected_facts=collected_facts)

    expected_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-11 05:00:49.672871
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert isinstance(facts.get('python'), dict)
    assert isinstance(facts.get('python').get('version'), dict)
    assert facts.get('python').get('version').get('major') == sys.version_info[0]
    assert facts.get('python').get('version').get('minor') == sys.version_info[1]
    assert facts.get('python').get('version').get('micro') == sys.version_info[2]
    assert facts.get('python').get('version').get('releaselevel') == sys.version_info[3]
    assert facts.get('python').get('version').get('serial') == sys.version_info[4]
    assert facts.get('python').get('version_info') == list

# Generated at 2022-06-11 05:00:57.883072
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test if the collect method returns expected results"""
    facts = {}
    python_fact = PythonFactCollector()
    facts = python_fact.collect(facts)
    expected = {'python': {'version': {'major': 2, 'minor': 7, 'micro': 10, 'releaselevel': 'final', 'serial': 0},
                'version_info': [2, 7, 10, 'final', 0],
                'executable': '/usr/bin/python',
                'has_sslcontext': False,
                'type': 'CPython'},
                }
    assert facts == expected


# Generated at 2022-06-11 05:01:04.989327
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert c.collect() == {'python': {'version': {'micro': 2, 'serial': 0, 'releaselevel': 'final', 'minor': 7, 'major': 2}, 'version_info': [2, 7, 2, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-11 05:01:10.998017
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonCollector().collect()
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:01:17.830935
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector(None)
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-11 05:01:25.090681
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts == {
        'python': {
            'type': 'CPython',
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-11 05:01:34.805481
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Make the sudo executor available
    from ansible.executor.sudo_executor import SudoExecutor
    setattr(sys.modules['ansible.plugins.loader'], 'action_loader', SudoExecutor)

    # Collect the python facts
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    python_facts = fact_collector.get_facts()

    # Test python_facts.version
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]

# Generated at 2022-06-11 05:01:44.740659
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    # Covers too simple cases
    collected_facts = {
        "python": {
            "version": {
                "major": sys.version_info[0],
                "minor": sys.version_info[1],
                "micro": sys.version_info[2],
                "releaselevel": sys.version_info[3],
                "serial": sys.version_info[4]
            },
            "version_info": list(sys.version_info),
            "executable": sys.executable,
            "has_sslcontext": HAS_SSLCONTEXT
        }
    }
    # Check if method collect works fine
    assert python_collector.collect() == collected_facts

# Generated at 2022-06-11 05:01:50.359694
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    py_facts = py_fact_collector.collect()
    assert 'python' in py_facts, "python facts returned should have python key"
    py_fact = py_facts['python']
    assert 'version' in py_fact, "python facts returned should have version key"
    assert 'version_info' in py_fact, "python facts returned should have version_info key"
    assert 'executable' in py_fact, "python facts returned should have executable key"
    assert 'type' in py_fact, "python facts returned should have type key"

# Generated at 2022-06-11 05:01:56.418833
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    test_facts = fc.collect()
    assert isinstance(test_facts, dict)
    assert isinstance(test_facts['python'], dict)
    assert isinstance(test_facts['python']['version'], dict)
    assert isinstance(test_facts['python']['version_info'], list)
    assert isinstance(test_facts['python']['has_sslcontext'], bool)
    assert isinstance(test_facts['python']['executable'], str)

# Generated at 2022-06-11 05:02:04.682941
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_facts = PythonFactCollector().collect()
    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_facts['python']['version_info'] == list(sys.version_info)
    assert py_facts['python']['executable'] == sys.executable
    assert py_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

    try:
        assert py_facts['python']['type'] == sys.subversion[0]
    except AttributeError:
        try:
            assert py_facts['python']['type'] == sys.implementation.name
        except AttributeError:
            assert py_facts

# Generated at 2022-06-11 05:02:14.488801
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    class_inst = PythonFactCollector()

    # NOTE: This test is not that useful, we need to find a way to test
    # the HAS_SSLCONTEXT attribute
    collected_facts = class_inst.collect()

    assert collected_facts['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'type': sys.implementation.name,
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-11 05:02:28.593716
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert 'python' in facts
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)
    assert isinstance(facts['python']['has_sslcontext'], bool)
    assert isinstance(facts['python']['type'], str) or facts['python']['type'] is None

# Generated at 2022-06-11 05:02:33.443580
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    results = pc.collect(collected_facts={})

    try:
        assert isinstance(results['python']['has_sslcontext'], bool)
    except KeyError:
        # If python version < 2.7.9
        pass

    try:
        assert len(results['python']['version_info']) == 5
    except KeyError:
        # If python version < 2.7.9
        pass

    assert isinstance(results['python']['version']['major'], int)
    assert isinstance(results['python']['version']['minor'], int)
    assert isinstance(results['python']['version']['micro'], int)
    assert isinstance(results['python']['version']['releaselevel'], str)

# Generated at 2022-06-11 05:02:39.672964
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    result = python_fact_collector.collect()

    assert isinstance(result, dict)
    assert 'python' in result
    assert isinstance(result['python'], dict)
    assert isinstance(result['python']['version_info'], list)
    assert isinstance(result['python']['version'], dict)
    assert isinstance(result['python']['has_sslcontext'], bool)
    assert 'type' in result['python']

# Generated at 2022-06-11 05:02:50.356144
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create object
    pfc = PythonFactCollector()

    # Get facts
    facts = pfc.collect()

    # Asserts
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts

# Generated at 2022-06-11 05:02:58.574984
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result = collector.collect()

    assert result is not None
    assert 'python' in result
    assert result['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': 'final',
        'serial': 0
    }
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

    if hasattr(sys, 'subversion'):
        assert result['python']['type'] == sys.subversion[0]

# Generated at 2022-06-11 05:03:05.452816
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    # Test the collect method
    python_fact_collector = FactCollector().collectors['python']
    facts_dict = python_fact_collector.collect()
    assert 'python' in facts_dict
    assert 'version' in facts_dict['python']
    assert 'type' in facts_dict['python']
    assert 'has_sslcontext' in facts_dict['python']
    assert 'version_info' in facts_dict['python']



# Generated at 2022-06-11 05:03:10.835689
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    facts = f.collect()

    assert type(facts['python']['version']['major']) is int
    assert type(facts['python']['version_info']) is list
    assert type(facts['python']['executable']) is str
    assert type(facts['python']['has_sslcontext']) is bool
    assert type(facts['python']['type']) is str

# Generated at 2022-06-11 05:03:18.739538
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()
    assert 'python' in facts

    assert 'version' in facts['python']
    version = facts['python']['version']

    assert 'major' in version
    assert version['major'] >= 0

    assert 'minor' in version
    assert version['minor'] >= 0

    assert 'micro' in version
    assert version['micro'] >= 0

    assert 'releaselevel' in version
    assert version['releaselevel'] in ('alpha', 'beta', 'candidate', 'final')

    assert 'serial' in version
    assert version['serial'] >= 0

    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version_info'], list)

# Generated at 2022-06-11 05:03:25.989369
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    py_fc_res = py_fc.collect()
    assert isinstance(py_fc_res, dict)
    assert 'python' in py_fc_res
    assert len(py_fc_res) == 1
    assert isinstance(py_fc_res['python'], dict)
    assert 'version' in py_fc_res['python']
    assert 'version_info' in py_fc_res['python']
    assert 'executable' in py_fc_res['python']
    assert 'has_sslcontext' in py_fc_res['python']
    assert len(py_fc_res['python']) == 5
    assert isinstance(py_fc_res['python']['version_info'], list)

# Generated at 2022-06-11 05:03:34.459216
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    collected_facts = {}
    collected_facts = pfc.collect(collected_facts)
    assert collected_facts['python']['executable'] is not None
    assert collected_facts['python']['type'] is not None
    assert collected_facts['python']['version']['major'] is not None
    assert collected_facts['python']['version']['minor'] is not None
    assert collected_facts['python']['version']['micro'] is not None
    assert collected_facts['python']['version']['releaselevel'] is not None
    assert collected_facts['python']['version']['serial'] is not None
    assert collected_facts['python']['version_info'] is not None

# Generated at 2022-06-11 05:03:42.915576
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-11 05:03:51.910926
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create subversion stub
    class SubversionStub:
        subversion = ["ansible", "2.8.9"]
        def __getattr__(self, name):
            return self.subversion

    # Set sys.subversion to stub
    old_sys_subversion = sys.subversion
    sys.subversion = SubversionStub()

    # Create sys.implementation stub
    class ImplementationStub:
        def __init__(self, name):
            self.name = name
        def __getattr__(self, name):
            return self.name

    # Set sys.implementation to stub
    old_sys_implementation = sys.implementation
    sys.implementation = ImplementationStub("a")

    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collect

# Generated at 2022-06-11 05:03:57.197372
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()

    assert isinstance(facts, dict)
    python_facts = facts['python']
    assert isinstance(python_facts['version'], dict)
    assert isinstance(python_facts['version_info'], list)
    assert python_facts['version']['major'] == sys.version_info[0]
    assert python_facts['version']['minor'] == sys.version_info[1]
    assert python_facts['version']['micro'] == sys.version_info[2]
    assert python_facts['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['version']['serial'] == sys.version_info[4]


# Generated at 2022-06-11 05:04:07.777744
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

    major_version = result['python']['version']['major']
    minor_version = result['python']['version']['minor']
    micro_version = result['python']['version']['micro']
    releaselevel = result['python']['version']['releaselevel']
    serial = result['python']['version']['serial']
    version_info = result['python']['version_info']
    executable = result['python']['executable']
    has_sslcontext = result['python']['has_sslcontext']

    collect_facts = []


# Generated at 2022-06-11 05:04:16.815564
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    python_version = python_facts['python']['version']
    assert python_version['major'] == sys.version_info[0]
    assert python_version['minor'] == sys.version_info[1]
    assert python_version['micro'] == sys.version_info[2]
    assert python_version['releaselevel'] == sys.version_info[3]
    assert python_version['serial'] == sys.version_info[4]

    assert python_facts['python']['version_info'] == sys.version_info

    assert python_facts['python']['executable'] == sys.executable

    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-11 05:04:21.811185
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact = fact_collector.collect()
    assert fact['python']['version']['major'] == 2 or fact['python']['version']['major'] == 3, "Python major version not returned."
    assert fact['python']['version']['minor'] >= 6, "Python minor version not returned."
    assert fact['python']['type'] in ['CPython', 'PyPy', None], "Python type not returned."

# Generated at 2022-06-11 05:04:26.428232
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = PythonFactCollector().collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert isinstance(facts['python']['version']['major'], int)
    assert isinstance(facts['python']['version']['minor'], int)
    assert isinstance(facts['python']['version']['micro'], int)
    assert isinstance(facts['python']['version']['releaselevel'], basestring)
    assert isinstance(facts['python']['version']['serial'], int)

# Generated at 2022-06-11 05:04:34.387398
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Tests method collect of the class PythonFactCollector
    """

    # We mimic the module_utils.facts.collector.BaseFactCollector.get_collector_facts
    # function
    python_fact_collector = PythonFactCollector()
    fact_info = python_fact_collector.collect()
    assert fact_info['python']['version']['major'] == sys.version_info[0]
    assert fact_info['python']['version']['minor'] == sys.version_info[1]
    assert fact_info['python']['version']['micro'] == sys.version_info[2]
    assert fact_info['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_info['python']['version']['serial']

# Generated at 2022-06-11 05:04:36.168570
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert set(
        PythonFactCollector().collect(collected_facts=dict()).keys()
    ) == {'python'}

# Generated at 2022-06-11 05:04:38.295521
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    # Calling collect twice to call teardown method
    assert collector.collect()
    assert collector.collect()


# Generated at 2022-06-11 05:04:52.582035
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    results = python_fact_collector.collect()
    python = results['python']
    version = python['version']

    assert version['major'] == 3
    assert version['minor'] == 6
    assert version['micro'] == 8
    assert version['releaselevel'] == 'final'
    assert version['serial'] == 0
    assert version['version_info'] == [3, 6, 8, 'final', 0]
    assert python['executable'].endswith('/python3.6')

    if sys.implementation.name == 'pypy':
        assert python['type'] == 'pypy'
    else:
        assert python['type'] == 'cpython'

# Generated at 2022-06-11 05:04:57.634703
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    # check all return values are not empty
    for fact in python_fact_collector.collect().values():
        assert fact

    # check version_info returns a list
    assert isinstance(python_fact_collector.collect()['python']['version_info'], list)

    # check has_sslcontext is boolean and is set if present
    assert isinstance(python_fact_collector.collect()['python']['has_sslcontext'], bool)

# Generated at 2022-06-11 05:05:01.802408
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    facts = py_collector.collect()

    # Check that facts['python']['has_sslcontext'] is properly set
    if HAS_SSLCONTEXT:
        assert facts['python']['has_sslcontext'] is True
    else:
        assert facts['python']['has_sslcontext'] is False

# Generated at 2022-06-11 05:05:05.114407
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

    assert 'python' in result
    assert 'version' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-11 05:05:13.090018
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_info = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    try:
        python_info['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_info['python']['type'] = sys.implementation.name
        except AttributeError:
            python_

# Generated at 2022-06-11 05:05:21.005699
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    python_facts_keys = [
        'python'
    ]
    python_facts_python_keys = [
        'has_sslcontext',
        'version',
        'version_info',
        'type',
        'executable'
    ]
    python_facts_python_version_keys = [
        'serial',
        'releaselevel',
        'micro',
        'minor',
        'major'
    ]

    assert set(python_facts_keys).issubset(python_facts.keys())
    assert set(python_facts_python_keys).issubset(python_facts['python'].keys())
    assert set(python_facts_python_version_keys).issubset(python_facts['python']['version'].keys())

# Generated at 2022-06-11 05:05:28.586583
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result = collector.collect()
    assert result == {'python': {'version': {'major': sys.version_info[0],
                                             'minor': sys.version_info[1],
                                             'micro': sys.version_info[2],
                                             'releaselevel': sys.version_info[3],
                                             'serial': sys.version_info[4]},
                                  'version_info': list(sys.version_info),
                                  'executable': sys.executable,
                                  'has_sslcontext': HAS_SSLCONTEXT,
                                  'type': sys.subversion[0]}}
    try:
        del python_facts['python']['type']
    except:
        pass

# Generated at 2022-06-11 05:05:34.085975
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }}


# Generated at 2022-06-11 05:05:42.398126
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Arrange
    pfc = PythonFactCollector()

    # Act
    facts = pfc.collect()

    # Assert
    assert facts is not None
    assert 'python' in facts
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:05:50.183846
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    py_facts = py_fact_collector.collect()
    assert py_facts['python']['executable'] == sys.executable
    assert py_facts['included_collections'] == ['python']
    assert py_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    # Python 3.3 doesn't have the new sys.implementation.name style
    # In that case, sys.subversion is an empty list instead.
    if sys.version_info >= (3, 3):
        assert py_facts['python']['type'] == sys.implementation.name
    else:
        assert not py_facts['python']['type']

# Generated at 2022-06-11 05:06:12.851400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    python_facts = collector.collect()
    assert type(python_facts) is dict
    assert 'python' in python_facts.keys()
    assert all(item in python_facts['python'].keys() for item in ['version', 'version_info', 'executable', 'type', 'has_sslcontext'])
    assert python_facts['python']['version']['releaselevel'] in ['alpha', 'beta', 'candidate', 'final']

# Generated at 2022-06-11 05:06:14.202636
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fc = PythonFactCollector()
    assert isinstance(python_fc.collect(), dict)



# Generated at 2022-06-11 05:06:15.797687
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert 'python' in result

# Generated at 2022-06-11 05:06:21.134929
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # given
    mod = None
    coll_facts = dict()

    # when
    python_collector = PythonFactCollector()
    py_facts = python_collector.collect(mod, coll_facts)

    # then
    assert 'python' in py_facts
    assert 'version' in py_facts['python']
    assert 'major' in py_facts['python']['version']
    assert 'type' in py_facts['python']

# Generated at 2022-06-11 05:06:22.417641
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test setup
    c = PythonFactCollector()
    print(c.collect())

# Generated at 2022-06-11 05:06:28.592752
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import ansible_collected_facts

    ans_mod = AnsibleModuleMock(ansible_collected_facts)
    pfc = PythonFactCollector(ans_mod)

    pfc._collect()
    # Verify we have collected at least one fact
    assert len(pfc._collected_facts) > 0, "Expected some item in pfc._collected_facts"


# Generated at 2022-06-11 05:06:36.916314
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()

# Generated at 2022-06-11 05:06:44.722173
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    fact_data = python_fact_collector.collect()
    assert fact_data['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-11 05:06:53.114963
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector
    python_facts = python_collector.collect()
    assert python_facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:07:01.367420
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector.collect()
    assert python_fact['python']['version']['major'] == sys.version_info[0]
    assert python_fact['python']['version']['minor'] == sys.version_info[1]
    assert python_fact['python']['version']['micro'] == sys.version_info[2]
    assert python_fact['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_fact['python']['version']['serial'] == sys.version_info[4]
    assert python_fact['python']['version_info'] == list(sys.version_info)
    assert python_fact['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:07:36.997164
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert len(facts) == 1
    assert 'python.type' in facts['python'].keys()

# Generated at 2022-06-11 05:07:42.900736
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    assert python_collector.collect()['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': sys.implementation.name
    }

# Generated at 2022-06-11 05:07:49.049388
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    #  Expected value
    expected_value = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    #  Get the result
    result = fact_collector.collect()
    assert result == expected_value

# Generated at 2022-06-11 05:07:56.584681
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    sys.version_info = (2, 7, 10, 'final', 0)
    sys.executable = '/usr/bin/python2.7'
    sys.subversion = ('CPython', '', '')
    sys.implementation = None

    facts = PythonFactCollector().collect()
    assert facts == {
        'python': {
            'version': {
                'major': 2,
                'minor': 7,
                'micro': 10,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 10, 'final', 0],
            'executable': sys.executable,
            'type': 'CPython',
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    return True


# Generated at 2022-06-11 05:08:03.525469
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Tests collect method of class PythonFactCollector
    """
    python_facts = PythonFactCollector().collect()
    assert(python_facts['python']['version']['major'] == sys.version_info[0])
    assert(python_facts['python']['version']['minor'] == sys.version_info[1])
    assert(python_facts['python']['version']['micro'] == sys.version_info[2])
    assert(python_facts['python']['version']['releaselevel'] == sys.version_info[3])
    assert(python_facts['python']['version']['serial'] == sys.version_info[4])
    assert(python_facts['python']['version_info'] == list(sys.version_info))

# Generated at 2022-06-11 05:08:05.858466
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module_object = object
    collected_facts = {}

    pfc = PythonFactCollector()
    pfc.collect(module_object, collected_facts)

    assert(type(pfc.collect(module_object, collected_facts)) == dict)

# Generated at 2022-06-11 05:08:13.317446
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""

    # prepare base class
    base_class_instance = BaseFactCollector()

    # create fact collector
    fact_collector_instance = PythonFactCollector()

    # call method
    res = fact_collector_instance.collect(base_class_instance)
    assert 'python' in res

    if sys.version_info[0] == 2:
        assert 'type' in res['python']
        assert 'executable' in res['python']
        assert 'version_info' in res['python']

    # version must always be there
    assert 'version' in res['python']
    assert 'major' in res['python']['version']
    assert 'minor' in res['python']['version']

# Generated at 2022-06-11 05:08:20.162271
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Unit test will be run on these inputs
    python_object = PythonFactCollector()

    # Actual results from the collect method
    actual_result = python_object.collect()

    # Expected result from the collect method
    expected_result = {'python': {'version': {'micro': 0, 'releaselevel': 'final', 'serial': 0, 'major': 2, 'minor': 7}, 'version_info': [2, 7, 0, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': 'CPython'}}

    assert actual_result == expected_result

# Generated at 2022-06-11 05:08:28.888219
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    collected_python_facts = python_facts.collect()

    assert collected_python_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_python_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_python_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_python_facts['python']['version']['serial'] == sys.version_info[4]
    assert collected_python_facts['python']['executable'] == sys.executable
    # On Python < 2.6, SSLContext

# Generated at 2022-06-11 05:08:34.091521
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import collectors

    py_collector = PythonFactCollector()

    facts_collector = FactsCollector()
    facts_collector.collect(collectors=[py_collector])

    assert 'python' in facts_collector._collected_facts
    assert 'version' in facts_collector._collected_facts['python']
    assert 'version_info' in facts_collector._collected_facts['python']
    assert 'executable' in facts_collector._collecte