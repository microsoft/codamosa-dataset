

# Generated at 2022-06-11 04:59:55.747400
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-11 04:59:57.472659
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    output = c.collect()
    assert 'python' in output

# Generated at 2022-06-11 05:00:06.808275
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()

    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-11 05:00:09.593826
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    python_facts = PythonFactCollector().collect()

    assert python_facts['python']['type'] == 'CPython'

# Generated at 2022-06-11 05:00:13.758714
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'has_sslcontext' in python_facts['python']
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-11 05:00:22.114590
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # This will act as a placeholder for method collect of PythonFactCollector
    # class if we don't have mock library installed
    class MockCollector(BaseFactCollector):
        name = 'dummy'
        _fact_ids = set()
        def collect(self, module=None, collected_facts=None):
            return {}

    from ansible.module_utils.facts import collector

    monkeypatch = Mock()

    def mock_get_distribution(module_utils=None):
        return (('test1', '0.0.0', ''), ('test2', '1.0.0', ''))

    # To make sure that we have mock library installed

# Generated at 2022-06-11 05:00:25.116436
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    #Create a PythonFactCollector
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result is not None
    assert 'python' in result


# Generated at 2022-06-11 05:00:33.670943
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    fc = FactCollector()
    python_facts = fc.collect(module=None, collected_facts=None)['python']
    assert python_facts['version']['major'] == sys.version_info[0]
    assert python_facts['version']['minor'] == sys.version_info[1]
    assert python_facts['version']['micro'] == sys.version_info[2]
    assert python_facts['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['version']['serial'] == sys.version_info[4]
    assert python_facts['executable'] == sys.executable
    assert python_facts['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:00:38.292959
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect() == {'python': {'version': {'micro': 5, 'releaselevel': 'final', 'serial': 0, 'major': 2, 'minor': 7}, 'type': 'CPython', 'version_info': [2, 7, 5, 'final', 0], 'has_sslcontext': True, 'executable': '/usr/bin/python'}}


# Generated at 2022-06-11 05:00:46.597818
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector('python', None, None)
    facts_ret = collector.collect()
    assert facts_ret == {
        'python': {
            'type': 'CPython',
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-11 05:01:01.014624
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  c = PythonFactCollector()
  result = c.collect()
  assert result['python']['version']['major'] == sys.version_info[0]
  assert result['python']['version']['minor'] == sys.version_info[1]
  assert result['python']['version']['micro'] == sys.version_info[2]
  assert result['python']['version']['releaselevel'] == sys.version_info[3]
  assert result['python']['version']['serial'] == sys.version_info[4]
  assert result['python']['version_info'] == list(sys.version_info)
  assert result['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:01:02.805404
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

    facts = fact_collector.collect_facts()
    assert facts is not None, "PythonFactCollector.collect did not return facts"



# Generated at 2022-06-11 05:01:14.186458
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # If we have an old version of python
    if sys.version_info[0:3] < (3, 4, 0):
        # We want to make the python collector not collect any info
        # If we have an old version of python
        import sys
        import types

        class PythonVersionInfo(types.SimpleNamespace):
            major = sys.version_info[0]
            minor = sys.version_info[1]
            micro = sys.version_info[2]
            releaselevel = sys.version_info[3]
            serial = sys.version_info[4]
        sys.version_info = PythonVersionInfo()
    # import the PythonFactCollector
    from ansible.module_utils.facts.collector import PythonFactCollector
    # Create a python fact collector instance
    c = PythonFactCollector()
    #

# Generated at 2022-06-11 05:01:23.005157
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    # Basic test
    facts = fact_collector.collect()
    assert facts['python']['version'] == {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]}
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:01:31.037800
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    mock_module = type('MockModule', (object,), {'params': {}})()
    collector = PythonFactCollector(mock_module)
    assert collector.collect() == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': None
    }}

# Generated at 2022-06-11 05:01:42.036386
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    python_facts = collector.collect()

    expected_python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-11 05:01:50.066901
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    results = collector.collect()
    assert results['python']['executable'] == sys.executable
    assert results['python']['version']['major'] == sys.version_info[0]
    assert results['python']['version']['minor'] == sys.version_info[1]
    assert results['python']['version']['micro'] == sys.version_info[2]
    assert results['python']['version']['releaselevel'] == sys.version_info[3]
    assert results['python']['version']['serial'] == sys.version_info[4]
    assert results['python']['version_info'] == list(sys.version_info)
    assert results['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-11 05:01:55.480006
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)
    assert isinstance(facts['python']['has_sslcontext'], bool)
    assert isinstance(facts['python']['type'], (type(None), str))

# Generated at 2022-06-11 05:02:03.578469
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    pyinfo = pf.collect()

    assert pyinfo['python']['version']['major'] == sys.version_info[0]
    assert pyinfo['python']['version']['minor'] == sys.version_info[1]
    assert pyinfo['python']['version']['micro'] == sys.version_info[2]
    assert pyinfo['python']['version']['releaselevel'] == sys.version_info[3]
    assert pyinfo['python']['version']['serial'] == sys.version_info[4]
    assert pyinfo['python']['version_info'] == list(sys.version_info)
    assert pyinfo['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:02:04.555265
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect()

# Generated at 2022-06-11 05:02:17.217961
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json
    py_collector = PythonFactCollector()
    result = py_collector.collect()
    # result = py_collector.collect(module=None, collected_facts={})
    print(json.dumps(result))

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-11 05:02:24.481032
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result == {u'python': {u'has_sslcontext': True, u'version': {u'minor': 7, u'major': 2, u'serial': 0, u'releaselevel': u'final', u'micro': 13}, u'executable': u'/usr/bin/python', u'version_info': [2, 7, 13, u'final', 0], u'type': u'CPython'}}

# Generated at 2022-06-11 05:02:27.547662
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''
    pythoncollector = PythonFactCollector()
    result = pythoncollector.collect()
    assert isinstance(result, dict)
    assert 'python' in result

# Generated at 2022-06-11 05:02:30.753426
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Function to test if the method collect of class PythonFactCollector
    works as expected
    """
    import sys
    python_collector = PythonFactCollector()

    python_facts = python_collector.collect()

    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' == hasattr(python_collector, 'HAS_SSLCONTEXT')

# Generated at 2022-06-11 05:02:34.834914
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert python_facts['python']['version']['major'] == 2
    assert python_facts['python']['version']['minor'] == 7
    assert python_facts['python']['version']['micro'] == 13
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert python_facts['python']['version']['serial'] == 0
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:02:36.985415
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    py_fc.collect()
    assert 'python' in py_fc.collect()

# Generated at 2022-06-11 05:02:40.510605
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module_mock = None
    collected_facts_mock = None
    collector = PythonFactCollector()

    result = collector.collect(module_mock, collected_facts_mock)

    # no error
    assert result is not None


# Generated at 2022-06-11 05:02:46.427539
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    import sys
    assert sys.version_info[1] >= 5

    import tempfile
    python_test_module_name = tempfile.mkstemp()[1]

    python_test_module = open(python_test_module_name, "w")

# Generated at 2022-06-11 05:02:54.590382
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert 'python' in python_facts
    assert 'executable' in python_facts['python']
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']

# Generated at 2022-06-11 05:03:02.080032
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    python_facts = PythonFactCollector().collect(module=module)
    version = sys.version_info
    wanted_result = {
        'python': {
            'version': {
                'major': version[0],
                'minor': version[1],
                'micro': version[2],
                'releaselevel': version[3],
                'serial': version[4]
            },
            'version_info': list(version),
            'executable': sys.executable,
            'type': 'CPython',
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-11 05:03:23.519774
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    assert p.collect() == {
        'python': {
            'type': 'CPython',
            'executable': sys.executable,
            'has_sslcontext': hasattr(p, 'SSLContext'),
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }

# Generated at 2022-06-11 05:03:31.839812
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    result = p.collect(collected_facts={})
    assert result['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }
    if hasattr(sys, 'implementation'):
        assert result['python']['type'] == sys.implementation.name
    elif hasattr(sys, 'subversion'):
        assert result

# Generated at 2022-06-11 05:03:33.384495
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector
    assert p.collect()['python']['type'] == 'CPython'

# Generated at 2022-06-11 05:03:35.103185
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector object
    pfc = PythonFactCollector()
    # Call method collect of PythonFactCollector object
    pfc.collect()

# Generated at 2022-06-11 05:03:36.873147
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Check collect method without arguments
    fact_collector = PythonFactCollector()
    assert fact_collector.collect()


# Generated at 2022-06-11 05:03:46.502212
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    python_facts = collector.collect()

    assert python_facts["python"]
    assert python_facts["python"]["version"]
    assert python_facts["python"]["version"]["major"]
    assert python_facts["python"]["version"]["minor"]
    assert python_facts["python"]["version"]["micro"]
    assert python_facts["python"]["version"]["releaselevel"]
    assert python_facts["python"]["version"]["serial"]
    assert python_facts["python"]["version_info"]
    assert python_facts["python"]["executable"]
    assert python_facts["python"]["has_sslcontext"] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:03:54.190295
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_obj = PythonFactCollector()
    returned_facts = test_obj.collect()

    assert isinstance(returned_facts, dict)
    assert 'python' in returned_facts.keys()
    assert 'version' in returned_facts['python'].keys()
    assert 'type' in returned_facts['python'].keys()
    assert 'executable' in returned_facts['python'].keys()
    assert 'has_sslcontext' in returned_facts['python'].keys()
    assert isinstance(returned_facts['python']['has_sslcontext'], bool)
    assert isinstance(returned_facts['python']['version'], dict)
    assert 'version_info' in returned_facts['python'].keys()
    assert isinstance(returned_facts['python']['version_info'], list)

# Generated at 2022-06-11 05:03:56.764632
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    # Get the facts
    facts = python_fact_collector.collect()

    # Assert that the facts are not empty
    assert(facts['python'])

# Generated at 2022-06-11 05:04:07.276401
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_data = fact_collector.collect()

    assert 'python' in fact_data
    assert 'version' in fact_data['python']
    assert isinstance(fact_data['python']['version']['major'], int)
    assert isinstance(fact_data['python']['version']['minor'], int)
    assert isinstance(fact_data['python']['version']['micro'], int)
    assert isinstance(fact_data['python']['version']['releaselevel'], str)
    assert isinstance(fact_data['python']['version']['serial'], int)
    assert isinstance(fact_data['python']['version_info'], list)

# Generated at 2022-06-11 05:04:16.417791
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Verify if the method returns a dictionary
    result = PythonFactCollector.collect({}, {})
    assert type(result) is dict

    # Verify if the dictionary is equal to the expected one
    expected_result = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-11 05:04:54.262962
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test the collect method of the PythonFactCollector."""

    mock_module = True
    mock_collected_facts = {'python': {}}
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect(mock_module, mock_collected_facts)
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-11 05:05:01.565779
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert 'executable' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert 'type' in python_facts['python']

# Test correct execution of __init__ method of PythonFactCollector

# Generated at 2022-06-11 05:05:09.581785
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors import PythonFactCollector
    from ansible.module_utils.facts.collectors import BaseFactCollector

    # Set up the collector
    pfc = PythonFactCollector()

    # Call the collect method
    returned_facts = pfc.collect()

    # Test that the returned data structure is expected.
    assert isinstance(returned_facts, dict)
    assert 'python' in returned_facts
    python_info = returned_facts['python']
    assert isinstance(python_info, dict)
    assert 'version' in python_info
    version_info = python_info['version']
    assert isinstance(version_info, dict)
    assert 'major' in version_info
    assert isinstance(version_info['major'], int)
    assert 'minor' in version

# Generated at 2022-06-11 05:05:17.540122
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:05:25.625231
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ Test that collect method of PythonFactCollector works as expected """
    python_collector_inst = PythonFactCollector()
    py_facts = python_collector_inst.collect()

    # Check expected python facts
    assert(py_facts['python']['type'] is not None)
    assert(py_facts['python']['version']['major'] == sys.version_info[0])
    assert(py_facts['python']['version']['minor'] == sys.version_info[1])
    assert(py_facts['python']['version']['micro'] == sys.version_info[2])
    assert(py_facts['python']['version']['releaselevel'] == sys.version_info[3])

# Generated at 2022-06-11 05:05:32.690266
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create instance of class PythonFactCollector
    obj = PythonFactCollector()

    # Create fake python version
    class FakeVersion:
        major = 1
        minor = 1
        micro = 1
        releaselevel = 'beta'
        serial = 1

    class FakeSys:
        version_info = FakeVersion()
        executable = 'python'
        subversion = ['Jython', '2.7.0']
        implementation = None

    sys = FakeSys()
    ansible_facts = {'python': {'version': {'major': 1, 'minor': 1, 'micro': 1, 'releaselevel': 'beta', 'serial': 1}, \
                    'version_info': [1, 1, 1, 'beta', 1], 'executable': 'python', 'type': 'Jython', 'has_sslcontext': False}}

# Generated at 2022-06-11 05:05:40.359136
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create instance of class PythonFactCollector
    python_fact_collector = PythonFactCollector()

    # Test method collect of class PythonFactCollector
    result = python_fact_collector.collect()

    # Test code
    assert type(result) == dict
    assert 'python' in result
    assert type(result['python']) == dict
    assert 'version' in result['python']
    assert type(result['python']['version']) == dict
    assert 'version_info' in result['python']
    assert type(result['python']['version_info']) == list
    assert 'executable' in result['python']
    assert type(result['python']['executable']) == str
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-11 05:05:42.004302
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()


# Generated at 2022-06-11 05:05:48.564839
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector_object = PythonFactCollector({}, None)
    facts_dictionary = python_collector_object.collect()
    assert facts_dictionary == {
        'python': {
            'executable': '/usr/bin/python',
            'version': {
                'micro': 6,
                'major': 2,
                'minor': 7,
                'releaselevel': 'final',
                'serial': 0
            },
            'type': 'CPython',
            'version_info': [2, 7, 6, 'final', 0],
            'has_sslcontext': False
        }
    }

# Generated at 2022-06-11 05:05:57.078962
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    _temp_collector = PythonFactCollector()
    python_facts = _temp_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:07:08.265191
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    cls = PythonFactCollector()
    actual = cls.collect()
    assert actual['python']['version']['major'] > -1
    assert actual['python']['version']['minor'] > -1
    assert actual['python']['version']['micro'] > -1
    assert actual['python']['version']['releaselevel'] == 'final'
    assert actual['python']['version']['serial'] > -1
    assert actual['python']['version_info'] is not None
    assert actual['python']['executable'] is not None
    assert actual['python']['type'] is not None

# Generated at 2022-06-11 05:07:12.921844
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert 'python' not in sys.modules
    # Get python fact
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts

    # Test python fact
    python_fact = python_facts['python']
    assert 'version' in python_fact
    assert 'type' in python_fact
    assert 'version_info' in python_fact
    assert 'executable' in python_fact

# Generated at 2022-06-11 05:07:17.103237
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result
    assert result['python']
    assert result['python']['version']
    assert result['python']['version_info']
    assert result['python']['executable']
    assert result['python']['has_sslcontext']
    assert result['python']['type']

# Generated at 2022-06-11 05:07:25.383944
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    collected_facts = {}
    expected_facts = {
         'python': {
             'version': {
                 'major': sys.version_info[0],
                 'minor': sys.version_info[1],
                 'micro': sys.version_info[2],
                 'releaselevel': sys.version_info[3],
                 'serial': sys.version_info[4]
             },
             'version_info': list(sys.version_info),
             'executable': sys.executable,
             'has_sslcontext': HAS_SSLCONTEXT
         }
    }

   # There are 2 ways to get the Python interpreter name

# Generated at 2022-06-11 05:07:33.420814
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    This method unit test the collect method of PythonFactCollector
    """
    python_facts = PythonFactCollector()
    facts = python_facts.collect()
    assert 'python' in facts and len(facts['python']) == 5
    assert 'version' in facts['python'] and len(facts['python']['version']) == 5
    assert 'version_info' in facts['python'] and len(facts['python']['version_info']) == 5
    assert 'executable' in facts['python'] and isinstance(facts['python']['executable'], basestring)
    assert 'has_sslcontext' in facts['python'] and isinstance(facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-11 05:07:38.244915
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test case to check if collect() method of PythonFactCollector class,
    is working as expected"""
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 6
    if result['python']['type'] == 'CPython':
        assert result['python']['version']['releaselevel'] == 'final'
    elif result['python']['type'] == 'PyPy':
        assert result['python']['version']['releaselevel'] == 'beta'
    assert result['python']['executable'] == '/usr/bin/python'
    assert result['python']['version_info'][0] == 3

# Generated at 2022-06-11 05:07:45.083478
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module_mock = MagicMock()
    collected_facts_mock = MagicMock()

    python_fact_collector = PythonFactCollector()

    python_facts = python_fact_collector.collect(module_mock, collected_facts_mock)

    assert sys.version_info == python_facts['python']['version_info']
    assert sys.executable == python_facts['python']['executable']
    assert sys.version_info[0] == python_facts['python']['version']['major']
    assert sys.version_info[1] == python_facts['python']['version']['minor']
    assert sys.version_info[2] == python_facts['python']['version']['micro']

# Generated at 2022-06-11 05:07:46.487112
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Note: collect does not require any input and does not produce any output for unit test
    PythonFactCollector().collect()

# Generated at 2022-06-11 05:07:53.193400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  python_fact = PythonFactCollector()
  result = python_fact.collect({}, {})
  assert type(result) == dict
  assert type(result['python']) == dict
  assert type(result['python']['version']) == dict
  assert type(result['python']['version_info']) == list
  assert type(result['python']['version']['major']) == int
  assert type(result['python']['version']['minor']) == int
  assert type(result['python']['version']['micro']) == int
  assert type(result['python']['version']['releaselevel']) == str
  assert type(result['python']['version']['serial']) == int
  assert type(result['python']['executable']) == str
 

# Generated at 2022-06-11 05:08:01.009744
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    ret = python_fact_collector.collect()
    assert isinstance(ret, dict)
    assert ret['python']['version']['major'] == 3
    assert ret['python']['version']['minor'] == 6
    assert ret['python']['version']['micro'] == 3
    assert ret['python']['version']['releaselevel'] == 'final'
    assert ret['python']['version']['serial'] == 0
    assert ret['python']['version_info'] == [3, 6, 3, 'final', 0]
    assert ret['python']['executable'].endswith('python')
    assert ret['python']['has_sslcontext'] == HAS_SSLCONTEXT