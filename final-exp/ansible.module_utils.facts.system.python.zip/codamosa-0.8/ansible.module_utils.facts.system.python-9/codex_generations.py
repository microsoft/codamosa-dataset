

# Generated at 2022-06-11 04:59:54.498626
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)
    assert len(facts) == 1
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:00:03.196756
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    python_facts = c.collect()
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)



# Generated at 2022-06-11 05:00:05.245532
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector collect"""
    c = PythonFactCollector()
    facts = c.collect()
    assert 'python' in facts

# Generated at 2022-06-11 05:00:11.684979
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    res = pc.collect()
    assert 'python' in res
    res1 = res['python']
    assert 'version' in res1
    res2 = res1['version']
    assert 'major' in res2
    assert 'minor' in res2
    assert 'micro' in res2
    assert 'releaselevel' in res2
    assert 'serial' in res2
    assert 'version_info' in res1
    assert 'executable' in res1
    assert 'has_sslcontext' in res1
    assert 'type' in res1

# Generated at 2022-06-11 05:00:16.284574
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test for existence of the 'python' key
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts

    # Test for existence of the keys of the 'python' dict
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-11 05:00:17.376252
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    assert isinstance(pyfc.collect(), dict)

# Generated at 2022-06-11 05:00:24.310090
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    result = py_fact_collector.collect()
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 7
    assert result['python']['version']['micro'] == 5
    assert 'releaselevel' in result['python']['version']
    assert 'serial' in result['python']['version']
    assert result['python']['version_info'] == list(sys.version_info)
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-11 05:00:25.878047
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector(None)

    result = pfc.collect()

    assert result is not None

# Generated at 2022-06-11 05:00:29.445216
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    FactCollector.add_collector(PythonFactCollector())
    result = dict(ansible_facts={})
    assert isinstance(PythonFactCollector().collect(collected_facts=result)['python'], dict)

# Generated at 2022-06-11 05:00:35.310595
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    from ansible.module_utils.facts.collector.python import PythonFactCollector
    from ansible.module_utils.facts import FactCollector

    test = PythonFactCollector()

    assert test is not None
    for fact, value in list(test.collect().items()):
        assert fact in FactCollector.collect(), 'fact %s missing from ansible.module_utils.facts.collector.all.collect()' % fact
        assert fact in PythonFactCollector._fact_ids, 'fact %s missing from method _fact_ids' % fact

# Generated at 2022-06-11 05:00:49.116435
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    
    # Check if the fact 'python' is present
    # If not, raise an exception
    python_fact = facts['python']
    assert isinstance(python_fact, dict), 'Expected python_fact to be a dict'

    # Check if 'python' contains the following keys
    expected_keys = set(['version', 'version_info', 'executable', 'has_sslcontext'])
    found_keys = set(python_fact.keys())
    assert expected_keys == found_keys, 'Expected python_fact to contain the following keys: {0}, found: {1}'.format(expected_keys, found_keys)

    # Check if the 'version' key is of type dict
    version_key = python_

# Generated at 2022-06-11 05:00:58.455634
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
            'version': {
                'major': sys.version_info[0],
                'micro': sys.version_info[2],
                'minor': sys.version_info[1],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }

    pfc = PythonFactCollector()
    facts = pfc.collect()

    assert facts == python_facts

# Generated at 2022-06-11 05:01:03.262542
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    import sys
    import types
    import copy

    from ansible.module_utils.facts.collector import BaseFactCollector

    test_subject = PythonFactCollector()
    assert isinstance(test_subject, BaseFactCollector)

    # No need to test the full dictionary, we assume we can trust the Python
    # standard library.
    # The purpose of this test is to assert the correct keys are present.

    result = test_subject.collect()
    assert isinstance(result, dict)
    assert 'python' in result
    assert isinstance(result['python'], dict)
    assert 'version' in result['python']
    assert isinstance(result['python']['version'], dict)
    assert 'version_info' in result['python']
    assert isinstance(result['python']['version_info'], list)


# Generated at 2022-06-11 05:01:06.633067
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collect = PythonFactCollector()
    collected_facts = {'ansible_facts': {}, 'ansible_system_capabilities': {}}
    facts = python_collect.collect(None, collected_facts)
    assert facts.get('python') is not None

# Generated at 2022-06-11 05:01:10.433704
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector = sys.modules[__name__].PythonFactCollector
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:01:21.221030
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()

    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:01:24.711919
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    facts = python_fact.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-11 05:01:27.785459
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create an instance of class PythonFactCollector
    python_fact_collector = PythonFactCollector()

    # Call method collect and check result
    assert python_fact_collector is not None
    assert python_fact_collector.collect() is not None

# Generated at 2022-06-11 05:01:38.704528
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()

    version_info = list(sys.version_info)
    executable = sys.executable

    try:
        python_type = sys.subversion[0]
    except AttributeError:
        python_type = None

    if hasattr(sys, 'implementation'):
        python_type = sys.implementation.name


# Generated at 2022-06-11 05:01:47.779832
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""
    python_facts = PythonFactCollector.collect()

    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert isinstance(python_facts['python']['version_info'], list)
    assert 'executable' in python_facts['python']

# Generated at 2022-06-11 05:01:59.457806
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    python_facts = PythonFactCollector.collect(basic.AnsibleModule(argument_spec={}))
    # The particular version will vary, so we just test a key element of the version_info tuple
    assert python_facts["python"]["version_info"][0] == 3

# Generated at 2022-06-11 05:02:08.179786
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    # Not sure how to do this unit test without importing the ssl
    # module, since that is where the module_utils.python_facts.py
    # is getting the imported module from.
    #
    # TODO: Revisit if/when we can mock import.
    #
    # The following line works:
    #
    #    from ansible.module_utils.facts import python_facts

    python_facts = PythonFactCollector()

    # Check returned facts
    facts = python_facts.collect()
    assert len(facts) == 1
    assert 'python' in facts
    python_facts_data = facts['python']
    assert 'version' in python_facts_data
    assert 'version_info' in python_facts_data
    assert 'executable' in python_facts_data

# Generated at 2022-06-11 05:02:10.763559
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    key = 'python'
    PythonFactCollector_object = PythonFactCollector()
    response = PythonFactCollector_object.collect()
    assert key in response

# Generated at 2022-06-11 05:02:19.716066
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()

    assert 'python' in result

    assert 'version' in result['python']
    assert 'major' in result['python']['version']
    assert 'minor' in result['python']['version']
    assert 'micro' in result['python']['version']
    assert 'releaselevel' in result['python']['version']
    assert 'serial' in result['python']['version']

    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'type' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-11 05:02:28.989306
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None)
    result = collector.collect()

    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCON

# Generated at 2022-06-11 05:02:33.654950
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    sys.version_info = (2, 7, 12, 'final', 0)
    sys.executable = '/path/to/python2.7'
    sys.subversion = ('CPython', '', '')
    sys.version = '2.7.12 (default, IST, default)'
    sys.implementation = None

    collector = PythonFactCollector()
    result = collector.collect()


# Generated at 2022-06-11 05:02:42.850349
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyf = PythonFactCollector()
    result = pyf.collect()
    assert result != None, 'Unable to collect python facts'
    assert 'python' in result, 'Unable to find python key in collected facts'
    assert 'executable' in result['python'], 'Unable to find python.executable in collected facts'
    assert 'version' in result['python'], 'Unable to find python.version in collected facts'
    assert 'type' in result['python'], 'Unable to find python.type in collected facts'
    assert 'version_info' in result['python'], 'Unable to find python.version_info in collected facts'
    assert 'has_sslcontext' in result['python'], 'Unable to find python.has_sslcontext in collected facts'

# Generated at 2022-06-11 05:02:52.184424
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect() == {
        'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': 'cpython'
        }
    }

# Generated at 2022-06-11 05:02:59.407015
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    def gather_subset(gather_subset=None, filter=None):
        return {'others': {'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }}}


# Generated at 2022-06-11 05:03:04.680275
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Make a mock module to collect the facts
    module = type('module', (object,), {})

    # Create the PythonFactCollector object
    py_fact_collector = PythonFactCollector()

    # Run the collect method of the PythonFactCollector object
    python_facts = py_fact_collector.collect(module)

    assert 'python' in python_facts

# Generated at 2022-06-11 05:03:16.177025
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None)
    result = collector.collect({'collect_subset': ['all']})
    assert result['python']['executable'].endswith('python')
    assert isinstance(result['python']['version_info'], list)
    assert len(result['python']['version_info']) == 5

# Generated at 2022-06-11 05:03:21.165739
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import PythonFactCollector

    c = PythonFactCollector()
    
    # Test execution without the optional parameters
    facts = c.collect()

    assert type(facts) == dict
    assert 'python' in facts
    assert 'version_info' in facts['python']
    
    # Test execution with the optional parameters
    facts = c.collect({}, {})

    assert type(facts) == dict
    assert 'python' in facts
    assert 'version_info' in facts['python']


# Generated at 2022-06-11 05:03:28.643509
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # initialize the test collector
    python_fc = PythonFactCollector()
    # testing the results
    assert python_fc.collect() == {'python': {'version': {'major': sys.version_info[0],
                                                          'minor': sys.version_info[1],
                                                          'micro': sys.version_info[2],
                                                          'releaselevel': sys.version_info[3],
                                                          'serial': sys.version_info[4]},
                                            'version_info': list(sys.version_info),
                                            'executable': sys.executable,
                                            'has_sslcontext': HAS_SSLCONTEXT,
                                            'type': sys.implementation.name
                                            }
                                   }

# Generated at 2022-06-11 05:03:37.205519
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform

    collector = PythonFactCollector()
    version_info = sys.version_info
    facts = collector.collect()

    # Test basic information
    assert facts['python']['version']['major'] == version_info[0]
    assert facts['python']['version']['minor'] == version_info[1]
    assert facts['python']['version']['micro'] == version_info[2]
    assert facts['python']['version']['releaselevel'] == version_info[3]
    assert facts['python']['version']['serial'] == version_info[4]
    assert facts['python']['version_info'] == list(version_info)
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:03:46.799231
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    import subprocess
    import pkg_resources
    from ansible.module_utils.facts import FactCollector

    os_name = platform.system()

    if os_name == 'Linux':
        platform_python_output = b'python: Python 2.7.5\n'
    elif os_name == 'Darwin':
        platform_python_output = b'python: Python 2.7.16\n'
    else:
        pyvm = pkg_resources.get_distribution('pyvmomi')
        if pyvm.version.split('.')[0] == '6':
            platform_python_output = b'python: python: /usr/bin/python\n'
        else:
            platform_python_output = b'python: python: /usr/bin/python2\n'
    f

# Generated at 2022-06-11 05:03:49.877545
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert len(fact_collector.get_facts()) == 1
    assert 'python' in fact_collector.get_facts()

# Generated at 2022-06-11 05:03:55.492862
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Checks that the collect method of PythonFactCollector class
    """
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:04:06.027700
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import tempfile
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    testCollections = { 'python': PythonFactCollector }
    testFactCollector = FactsCollector(collections=testCollections)

    assert sys.version_info[0] == testFactCollector.ansible_facts['python']['version']['major']
    assert sys.version_info[1] == testFactCollector.ansible_facts['python']['version']['minor']
    assert sys.version_info[2] == testFactCollector.ansible_facts['python']['version']['micro']

# Generated at 2022-06-11 05:04:15.303549
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    pythonfc = PythonFactCollector()

    # Test 1:
    # Test if version_info attribute is presented in the result
    #   Test if this attribute is a list

    result = pythonfc.collect()
    if 'version_info' not in result['python']:
        raise Exception("'version_info' attribute not presented in the result")
    if not isinstance(result['python']['version_info'], list):
        raise Exception("'version_info' attribute is not a list")

    # Test 2:
    # Test with an empty sys.subversion attribute
    #   Test if python type is presented

    sys.subversion = ()
    result = pythonfc.collect()
    if result['python']['type'] is None:
        raise Exception("Python type is not presented in the result")

# Generated at 2022-06-11 05:04:20.402909
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    python_facts = pfc.collect()
    # Should return python version information
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']

    # Should return python type
    assert 'type' in python_facts['python']
    assert python_facts['python']['type'] == 'CPython'

# Generated at 2022-06-11 05:04:44.534332
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collection = PythonFactCollector()
    result = collection.collect()
    assert result['python']

    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:04:51.692854
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect()['python']['executable'] == sys.executable
    assert f.collect()['python']['version_info'] == list(sys.version_info)
    assert f.collect()['python']['version']['major'] == sys.version_info[0]
    assert f.collect()['python']['version']['minor'] == sys.version_info[1]
    assert f.collect()['python']['version']['micro'] == sys.version_info[2]
    assert f.collect()['python']['version']['releaselevel'] == sys.version_info[3]
    assert f.collect()['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:04:54.262333
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''
    python_facts = PythonFactCollector()

    # NOTE: We run a validator on the resulting data against
    #       python_facts.yaml
    facts = python_facts.collect()
    assert 'python' in facts

# Generated at 2022-06-11 05:05:02.500705
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_obj = PythonFactCollector()
    output = test_obj.collect()
    assert isinstance(output, dict)
    assert output['python']['version']['major'] == sys.version_info[0]
    assert output['python']['version']['minor'] == sys.version_info[1]
    assert output['python']['version']['micro'] == sys.version_info[2]
    assert output['python']['version']['releaselevel'] == sys.version_info[3]
    assert output['python']['version']['serial'] == sys.version_info[4]
    assert output['python']['version_info'] == list(sys.version_info)
    assert output['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:05:03.631701
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py = PythonFactCollector()
    result = py.collect()
    assert result

# Generated at 2022-06-11 05:05:04.790826
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    python_collector.collect()

# Generated at 2022-06-11 05:05:10.842864
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_python_facts = {
        'python': {
            'type': 'CPython',
            'version': {
                'major': 2,
                'minor': 7,
                'micro': 10,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 10, 'final', 0],
            'executable': '/usr/bin/python',
            'has_sslcontext': False
        }
    }

    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert facts == test_python_facts

# Generated at 2022-06-11 05:05:18.718761
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    expected = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-11 05:05:26.837938
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Install fake python
    pyver_bak = sys.version_info
    sys.version_info = (2, 7, 0, 'final', 0)
    sys.executable = '/usr/bin/python'

# Generated at 2022-06-11 05:05:33.610341
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors import PythonFactCollector
    from ansible.module_utils.facts.collectors import base
    base.LOADED_FACT_COLLECTORS.add(PythonFactCollector) 
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    python_facts = python_fact_collector.collect(collected_facts=collected_facts)

# Generated at 2022-06-11 05:06:11.283212
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    result = c.collect()
    assert result == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4],
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'cpython',
        }
    }

# Generated at 2022-06-11 05:06:14.391742
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize collector
    p = PythonFactCollector()

    # Call method collect
    data = p.collect()

    # Make sure that it returns a dictionary
    assert isinstance(data, dict)

    # Make sure that it returns a dictionary with python facts
    assert 'python' in data

# Generated at 2022-06-11 05:06:19.665921
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collection = PythonFactCollector()
    result = py_collection.collect()
    assert result == {'python': {'version': {'major': 3, 'minor': 6, 'micro': 0, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 6, 0, 'final', 0], 'executable': '/usr/bin/python3', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-11 05:06:29.873703
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    import os
    import sys
    import unittest

    class module(object):
        pass

    # Import here to force import before module mock
    import AnsibleModule

    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            pass

        def exit_json(self, *args, **kwargs):
            sys.exit(0)

        def fail_json(self, *args, **kwargs):
            sys.exit(1)

    sys.modules['ansible.module_utils.facts.collector'] = unittest.mock.MagicMock()
    sys.modules['ansible.module_utils.facts.collector.BaseFactCollector'] = unittest.mock.MagicMock()

# Generated at 2022-06-11 05:06:38.028728
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    expected = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-11 05:06:38.946323
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    p.collect()

# Generated at 2022-06-11 05:06:40.267830
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert c.has_fetched_all_facts == {}


# Generated at 2022-06-11 05:06:45.111943
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == dict(python=dict(executable=sys.executable, has_sslcontext=HAS_SSLCONTEXT, version={'major': sys.version_info[0], 'micro': sys.version_info[2], 'minor': sys.version_info[1], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, version_info=sys.version_info, type='cpython'))

# Generated at 2022-06-11 05:06:53.440371
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    # Check that the executable is the same as the current
    # interpreter
    assert python_facts['python']['executable'] == sys.executable

    # Check that major and minor are the same as the current
    # interpreter
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]

    # Check that the type is the same as the current interpreter
    assert python_facts['python']['type'] == sys.version.split()[0]

    # Check that the has_sslcontext is present and is the same
    # as the current interpreter

# Generated at 2022-06-11 05:07:01.670669
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_bytes

    c = FactsCollector()
    c.collect(module=None, collected_facts=None)

    python_facts = c.get_facts()['system']['python']

    # Check the python version
    pyver = sys.version_info
    assert int(python_facts['version']['major']) == pyver.major
    assert int(python_facts['version']['minor']) == pyver.minor
    assert int(python_facts['version']['micro']) == pyver.micro
    assert python_facts['version']['releaselevel'] == pyver.releaselevel
    assert int(python_facts['version']['serial']) == pyver.serial



# Generated at 2022-06-11 05:08:09.642529
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-11 05:08:18.188331
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors import collector_module

    collector = PythonFactCollector()

    # Use a copy of module_utils.facts.collectors.collector_module
    # to not affect the main test.
    sys.modules['ansible.module_utils.facts.collectors.collector_module'] = collector_module


# Generated at 2022-06-11 05:08:19.385004
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    assert obj.collect()

# Generated at 2022-06-11 05:08:22.641213
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # set up
    python_facts = PythonFactCollector()
    result = python_facts.collect()

    # check results
    print(result)
    #assert result == {}


if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-11 05:08:28.383455
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector.collect(collected_facts=dict())
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], str)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)
    assert isinstance(python_facts['python']['type'], str)

# Generated at 2022-06-11 05:08:30.379301
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    collected_facts = pfc.collect()
    assert len(collected_facts) == 1
    assert 'python' in collected_facts

# Generated at 2022-06-11 05:08:31.645631
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    assert isinstance(fact_collector.collect(), dict)

# Generated at 2022-06-11 05:08:35.124794
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert c.collect() == {'python': {'version': {'major': 2, 'minor': 6, 'micro': 6, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 6, 6, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': None}}

# Generated at 2022-06-11 05:08:38.324365
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    python_facts = fact_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']



# Generated at 2022-06-11 05:08:45.806387
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    collected_facts = {}
    result = python_fact.collect(collected_facts=collected_facts)
    assert result['python']['version'] == {
                                           'major': sys.version_info[0],
                                           'minor': sys.version_info[1],
                                           'micro': sys.version_info[2],
                                           'releaselevel': sys.version_info[3],
                                           'serial': sys.version_info[4]
                                          }
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['type'] is not None
    assert result['python']['has_sslcontext']