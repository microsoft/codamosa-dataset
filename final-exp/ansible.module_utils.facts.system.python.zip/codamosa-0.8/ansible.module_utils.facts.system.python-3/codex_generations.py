

# Generated at 2022-06-11 04:59:49.671268
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    # call method collect
    result = python_fact_collector.collect()
    assert 'python' in result

# Generated at 2022-06-11 04:59:58.742228
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    if PY3:
        py2_dict = {
            'python': {
                'version': {
                    'major': 2,
                    'minor': 7,
                    'micro': 14,
                    'releaselevel': 'final',
                    'serial': 0
                },
                'version_info': [2, 7, 14, 'final', 0],
                'executable': sys.executable,
                'has_sslcontext': False,
                'type': 'CPython'
            }
        }

# Generated at 2022-06-11 05:00:08.174453
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert 'python' in facts, "fact 'python' has to be present in facts"
    python_facts = facts['python']

    assert 'version' in python_facts, "fact 'version' has to be present in 'python' facts"
    assert 'version_info' in python_facts, "fact 'version_info' has to be present in 'python' facts"
    assert 'executable' in python_facts, "fact 'executable' has to be present in 'python' facts"
    assert 'type' in python_facts, "fact 'type' has to be present in 'python' facts"
    assert 'has_sslcontext' in python_facts, "fact 'has_sslcontext' has to be present in 'python' facts"


# Generated at 2022-06-11 05:00:16.589708
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    python_facts = collector.collect()

    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts

# Generated at 2022-06-11 05:00:18.405060
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    f.collect()
    assert isinstance(f.collect(), dict)
    assert 'python' in f.collect()

# Generated at 2022-06-11 05:00:20.527892
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create instance of PythonFactCollector
    python_fact_collector = PythonFactCollector()
    # Test output
    assert type(python_fact_collector.collect()) is dict

# Generated at 2022-06-11 05:00:25.953781
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = None
    collected_facts = None
    c = PythonFactCollector()
    facts = c.collect(module, collected_facts)
    assert type(facts) is dict
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-11 05:00:34.516243
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    # Execution
    result = collector.collect()

    # Assertion
    assert result['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-11 05:00:38.492636
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    result = p.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']

# Generated at 2022-06-11 05:00:44.899762
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    facts = python_facts.collect()
    # Test if main keys are present
    assert facts.get('python') is not None
    assert facts.get('python').get('type') is not None
    assert facts.get('python').get('version') is not None
    assert facts.get('python').get('version_info') is not None
    assert facts.get('python').get('executable') is not None
    assert facts.get('python').get('has_sslcontext') is not None

# Generated at 2022-06-11 05:00:48.773880
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect(collected_facts=None)

# Generated at 2022-06-11 05:00:59.211961
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    pf = fc.collect()
    assert pf.get('python') is not None
    assert pf.get('python').get('version') is not None
    assert pf.get('python').get('version').get('major') is not None
    assert pf.get('python').get('version').get('minor') is not None
    assert pf.get('python').get('version').get('micro') is not None
    assert pf.get('python').get('version').get('releaselevel') is not None
    assert pf.get('python').get('version').get('serial') is not None
    assert pf.get('python').get('version_info') is not None
    assert pf.get('python').get('executable') is not None

# Generated at 2022-06-11 05:01:04.104380
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    assert len(python_facts) == 1
    assert python_facts['python']['version']['major'] == 3
    assert python_facts['python']['version']['minor'] == 6
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert type(python_facts['python']['version_info']) == list
    assert python_facts['python']['executable'] is not None
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    if python_facts['python']['type'] in ('CPython', 'PyPy'):
        assert python_facts['python']['type'] is not None

# Generated at 2022-06-11 05:01:15.673709
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    json_output = {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }}


# Generated at 2022-06-11 05:01:25.124359
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact = PythonFactCollector()
    py_fact_collected = py_fact.collect()
    assert 'python' in py_fact_collected
    assert 'version' in py_fact_collected['python']
    assert 'major' in py_fact_collected['python']['version']
    assert 'minor' in py_fact_collected['python']['version']
    assert 'micro' in py_fact_collected['python']['version']
    assert 'releaselevel' in py_fact_collected['python']['version']
    assert 'serial' in py_fact_collected['python']['version']
    assert 'version_info' in py_fact_collected['python']
    assert 'executable' in py_fact_collected['python']
    assert 'type' in py

# Generated at 2022-06-11 05:01:34.856137
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    python_facts = fact_collector.collect()

    assert 'python' in python_facts

    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']

    assert 'version_info' in python_facts['python']
    assert len(python_facts['python']['version_info']) == 5

    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']


# Generated at 2022-06-11 05:01:45.530716
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test collect method of AnsiblePythonFactCollector
    """

    python_version = list(sys.version_info)
    python_executable = sys.executable

    # create a dictionary of facts that this collector should return
    expected_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': python_version,
            'executable': python_executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-11 05:01:50.562482
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.dark import collect

    def test_collect():
        python_collector = FactCollector(
            module=dict(),
            collected_facts=Facts(),
            name='python',
            aliases=[],
            fact_class='PythonFactCollector'
        )
        return python_collector.collect()

    python_facts = collect(['python'])
    assert test_collect() == python_facts

# Generated at 2022-06-11 05:01:53.774837
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector
    pfc = PythonFactCollector()
    assert isinstance(pfc, BaseFactCollector)
    assert isinstance(pfc, PythonFactCollector)

    # Test it
    assert 'python' in pfc.collect()

# Generated at 2022-06-11 05:02:02.136930
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert facts.get('python')

    py_facts = facts.get('python')

    assert py_facts.get('version')
    assert py_facts.get('type')
    assert py_facts.get('executable')
    assert py_facts.get('has_sslcontext') in (True, False)

    version_info = py_facts.get('version')
    assert version_info.get('major') >= 0
    assert version_info.get('minor') >= 0
    assert version_info.get('micro') >= 0

    if version_info.get('releaselevel') == 'final':
        assert version_info.get('serial') == 0
    else:
        assert version_info.get('serial') >= 0

# Generated at 2022-06-11 05:02:12.141413
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc.collect() == {'python': {'version': {'major': 3, 'minor': 7, 'micro': 5, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 7, 5, 'final', 0], 'executable': '/usr/bin/python3.7', 'has_sslcontext': True, 'type': 'CPython'}}


if __name__ == "__main__":
    test_PythonFactCollector_collect()

# Generated at 2022-06-11 05:02:22.766644
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()
    assert 'python' in facts

    p_facts = facts['python']
    assert 'version' in p_facts
    assert 'version_info' in p_facts
    assert 'executable' in p_facts
    assert 'has_sslcontext' in p_facts

    p_ver = p_facts['version']
    assert 'major' in p_ver
    assert p_ver['major'] == sys.version_info[0]
    assert 'minor' in p_ver
    assert 'micro' in p_ver
    assert 'releaselevel' in p_ver
    assert p_ver['releaselevel'] == sys.version_info[3]
    assert 'serial' in p_ver

# Generated at 2022-06-11 05:02:31.335266
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_text

    # Prepare some test cases

# Generated at 2022-06-11 05:02:39.837660
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.collector

    # AnsibleModuleStub is a class from `test/utils/modules` directory.
    python_collector = PythonFactCollector(AnsibleModuleStub())

    # Ensure that object is instance of appropriate class
    assert isinstance(python_collector, ansible.module_utils.facts.collector.BaseFactCollector)

    # Ensure that returned fact structure is of appropriate type
    collected_facts = python_collector.collect()
    assert type(collected_facts) == dict
    assert len(collected_facts) == 1

    fact = collected_facts[PythonFactCollector.name]
    assert type(fact) == dict

    # Ensure that major version information is of integer type

# Generated at 2022-06-11 05:02:42.733393
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-11 05:02:49.306417
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    answer = python_fact_collector.collect()
    assert isinstance(answer, dict)
    assert 'python' in answer
    assert 'version' in answer['python']
    assert 'version_info' in answer['python']
    assert 'executable' in answer['python']
    assert 'has_sslcontext' in answer['python']
    assert 'type' in answer['python']

# Generated at 2022-06-11 05:02:57.843990
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    _module = {}
    _collected_facts = {}
    pfc = PythonFactCollector()

    res = pfc.collect(_module, _collected_facts)

    assert res['python']['version']['major'] == sys.version_info[0]
    assert res['python']['version']['minor'] == sys.version_info[1]
    assert res['python']['version']['micro'] == sys.version_info[2]
    assert res['python']['version']['releaselevel'] == sys.version_info[3]
    assert res['python']['version']['serial'] == sys.version_info[4]
    assert res['python']['version_info'] == list(sys.version_info)
    assert res['python']['executable'] == sys

# Generated at 2022-06-11 05:03:01.040938
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
   fact_collector = PythonFactCollector()
   facts = fact_collector.collect()
   for fact_id in fact_collector._fact_ids:
       assert fact_id in facts


# Generated at 2022-06-11 05:03:10.006306
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test that we can successfully create a PythonFactCollector object
    python_fact_collector = PythonFactCollector()
    # Test that we can successfully collect facts
    facts = python_fact_collector.collect()
    # Assert that the returned facts are structured correctly
    assert 'python' in facts
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)
    assert isinstance(facts['python']['type'], str) or facts['python']['type'] is None
    assert isinstance(facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-11 05:03:11.605380
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:03:21.577795
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector({},[])
    assert python_collector.collect() == {'python': {'version': {'major': 2, 'micro': 7, 'serial': 0, 'minor': 7, 'releaselevel': 'final'}, 'version_info': [2, 7, 0, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': 'CPython'}}

# Generated at 2022-06-11 05:03:29.275029
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()

    # Collect facts and obtain a dictionary of python facts
    python_facts = py_collector.collect()

    # Check if the facts are obtained by calling the collect method
    assert python_facts['python']
    assert python_facts['python']['version']
    assert python_facts['python']['version']['major']
    assert python_facts['python']['version']['minor']
    assert python_facts['python']['version']['micro']
    assert python_facts['python']['version']['releaselevel']
    assert python_facts['python']['version']['serial']
    assert python_facts['python']['version_info']
    assert python_facts['python']['executable']

# Generated at 2022-06-11 05:03:34.911299
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    pfc_result = pfc.collect()

    assert isinstance(pfc_result['python']['version'], dict)
    assert isinstance(pfc_result['python']['version_info'], list)
    assert isinstance(pfc_result['python']['executable'], basestring)
    assert isinstance(pfc_result['python']['has_sslcontext'], bool)

# Generated at 2022-06-11 05:03:36.381319
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    result = python_fact.collect()
    assert result['python']

# Generated at 2022-06-11 05:03:45.560830
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    result = pf.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT
    if hasattr(sys, "subversion"):
        assert result['python']['type'] == sys.subversion[0]
    elif hasattr(sys, "implementation"):
        assert result['python']['type'] == sys.implementation.name
    else:
        assert result['python']['type'] == None

# Generated at 2022-06-11 05:03:50.333213
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    # Check that we have a python attribute in the facts returned by collect
    facts = pfc.collect()
    assert 'python' in facts

    # Check that 'python' contains the correct values
    assert len(facts['python']['version_info']) == 5
    assert facts['python']['version']['major'] == sys.version_info[0]


# Generated at 2022-06-11 05:03:52.054033
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    output = c.collect()
    assert(output != {})
    assert(output != [])

# Generated at 2022-06-11 05:03:55.261265
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    c = PythonFactCollector()
    output = c.collect()
    assert 'python' in output
    python_keys = [
        'version',
        'type',
        'version_info',
        'executable',
        'has_sslcontext'
    ]

    for key in python_keys:
        assert key in output['python']
        assert output['python'][key] is not None

# Generated at 2022-06-11 05:04:05.643617
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    py_facts = pyfc.collect()

    # The fact 'python' should exist
    assert 'python' in py_facts

    # The fact 'python' should have the following data
    assert 'python' in py_facts
    assert 'version' in py_facts['python']
    assert 'version_info' in py_facts['python']
    assert 'executable' in py_facts['python']
    assert 'has_sslcontext' in py_facts['python']

    # The fact 'python' should have a 'version' dictionary with 5 keys
    assert len(py_facts['python']['version']) == 5

    # The fact 'python' should have a 'version_info' list of 5 integers
    assert type(py_facts['python']['version_info']) == list
   

# Generated at 2022-06-11 05:04:14.982170
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector

    # Create a PythonFactCollector object
    python_fact_collector = PythonFactCollector()

    # Create a dict object to store collected facts
    collected_facts = {}
    # Call collect method
    returned_facts = python_fact_collector.collect(collected_facts=collected_facts)

    # Check if PythonFactCollector.collect() returns a dict object
    assert isinstance(returned_facts, dict)

    # Check keys of returned facts
    expected_facts_keys = ['python']
    assert sorted(returned_facts.keys()) == expected_facts_keys

    # Check keys of returned facts['python']
    expected_facts_python_keys = ['has_sslcontext','executable','type','version','version_info']

# Generated at 2022-06-11 05:04:29.930637
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test with a list of version that match with version_info and version
    for version_info, version in [
            ((2, 7, 14, 'final', 0), '2.7.14'),
            ((3, 6, 9, 'final', 0), '3.6.9')]:
        collected_facts = {}

# Generated at 2022-06-11 05:04:32.078876
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Doctest for method collect'''
    # Create an instance of PythonFactCollector class
    python_fact_collector = PythonFactCollector()
    # Test the collect method
    result = python_fact_collector.collect()
    assert 'python' in result


# Generated at 2022-06-11 05:04:36.569202
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    def create_default_context():
        pass
    import sys
    import types
    class SSLContext:
        pass
    sys.modules['ssl'] = types.ModuleType('ssl')
    sys.modules['ssl'].create_default_context = create_default_context
    sys.modules['ssl'].SSLContext = SSLContext
    del create_default_context, SSLContext
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-11 05:04:39.957874
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert 'python' == pfc.name
    assert set() == pfc._fact_ids
    assert isinstance(pfc.collect(), dict)
    assert set(['python']) == set(pfc.collect().keys())

# Generated at 2022-06-11 05:04:46.653351
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {
        "python": {
            "version": {
                "major": sys.version_info[0],
                "minor": sys.version_info[1],
                "micro": sys.version_info[2],
                "releaselevel": sys.version_info[3],
                "serial": sys.version_info[4]
            },
            "version_info": list(sys.version_info),
            "executable": sys.executable,
            "type": sys.version.split()[0],
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-11 05:04:49.140693
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method collect of class PythonFactCollector"""
    python = PythonFactCollector()
    facts = python.collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:04:51.175537
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a instance of PythonFactCollector
    obj = PythonFactCollector()

    # Check if the method collect of class PythonFactCollector is not None
    assert obj.collect() is not None


# Generated at 2022-06-11 05:04:56.931539
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector = PythonFactCollector()

    fact_data = python_fact_collector.collect()

    assert fact_data
    assert 'python' in fact_data
    assert fact_data['python']
    assert 'version' in fact_data['python']
    assert 'version_info' in fact_data['python']
    assert 'executable' in fact_data['python']
    assert 'type' in fact_data['python']
    assert 'has_sslcontext' in fact_data['python']
    assert fact_data['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:05:05.296686
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = collector.collect()

    # Check if the general structure of the collected facts matches with the
    # expected one
    assert isinstance(collected_facts, dict)
    assert 'python' in collected_facts

    # Check if all expected keys are there
    assert 'version' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'has_sslcontext' in collected_facts['python']

    # Check if version_info contains the correct amount of values
    assert isinstance(collected_facts['python']['version_info'], list)
    assert len(collected_facts['python']['version_info']) == 5

    # Check if the version_info values match  with

# Generated at 2022-06-11 05:05:08.693114
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    facts = p.collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-11 05:05:29.094165
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert 'python' in facts
    assert facts['python']['executable'] == sys.executable
    assert type(facts['python']['version']) == dict
    assert type(facts['python']['version']['major']) == int
    assert type(facts['python']['version']['minor']) == int
    assert type(facts['python']['version']['micro']) == int
    assert type(facts['python']['version']['releaselevel']) == str

# Generated at 2022-06-11 05:05:34.984883
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import ansible.module_utils.facts.collector
    collected_facts = ansible.module_utils.facts.collector.get_all_facts()
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert isinstance(collected_facts['python']['version'], dict)
    assert 'major' in collected_facts['python']['version']
    assert 'minor' in collected_facts['python']['version']
    assert 'micro' in collected_facts['python']['version']
    assert 'releaselevel' in collected_facts['python']['version']
    assert 'serial' in collected_facts['python']['version']
    assert isinstance(collected_facts['python']['version']['major'], int)

# Generated at 2022-06-11 05:05:43.337756
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        HAS_SSLCONTEXT = True
    except ImportError:
        HAS_SSLCONTEXT = False
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

# Generated at 2022-06-11 05:05:50.147049
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert c.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'cpython',
        },
    }

# Generated at 2022-06-11 05:05:58.662301
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Unit test assumes Python 2.7.15
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()
    assert python_facts['python']['version']['major'] == 2
    assert python_facts['python']['version']['minor'] == 7
    assert python_facts['python']['version']['micro'] == 15
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert python_facts['python']['version']['serial'] == 0
    assert python_facts['python']['version_info'] == [2, 7, 15, 'final', 0]
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:06:00.384245
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector(None, None)
    py_facts = py_fc.collect()
    assert py_facts.get('python')

# Generated at 2022-06-11 05:06:08.211142
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()
    assert facts['python']['executable'].endswith('/python')
    assert facts['python']['version']['major'] >= 2
    assert facts['python']['version']['releaselevel'] in ['final', 'alpha', 'beta', 'candidate']
    if not facts['python']['version']['major'] >= 3:
        assert facts['python']['type'] in ['CPython', 'PyPy']
    else:
        assert facts['python']['type'] in ['CPython', 'PyPy', None]
    assert isinstance(facts['python']['version_info'], list)
    assert len(facts['python']['version_info']) == 5
    assert facts['python']['has_sslcontext']

# Generated at 2022-06-11 05:06:15.661175
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert set(['python']).issubset(python_facts.keys())
    assert set(['version', 'version_info', 'executable', 'has_sslcontext','type']).issubset(python_facts['python'].keys())
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert len(python_facts['python']['version_info']) == 5

# Generated at 2022-06-11 05:06:25.565618
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    sys.modules['ansible.module_utils.facts.collector'] = sys.modules['ansible.module_utils.facts']
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    pfc = PythonFactCollector()
    res = pfc.collect()
    assert type(res) is dict
    assert 'version' in res['python']
    assert 'version_info' in res['python']
    assert 'executable' in res['python']
    assert 'type' in res['python']
    assert res['python']['type'] is not None
    assert res['python']['has_sslcontext'] is not None

    # Test Python 3.7.0a0
    pfc = PythonFactCollector()

# Generated at 2022-06-11 05:06:32.030387
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    expected = {
        'python': {
            'type': None,
            'version': {'major': 2, 'minor': 7, 'micro': 5, 'releaselevel': 'final', 'serial': 0},
            'version_info': [2, 7, 5, 'final', 0],
            'executable': '/usr/bin/python',
            'has_sslcontext': True},
    }
    assert result == expected

# Generated at 2022-06-11 05:07:09.641107
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_collector = PythonFactCollector()

    collected_facts = test_collector.collect()

    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]
    assert collected_facts['python']['version_info'] == list(sys.version_info)
    assert collected_facts['python']['executable'] == sys.executable

# Generated at 2022-06-11 05:07:17.465967
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = None
    python_fact_collector = PythonFactCollector()
    collected_facts = None

    # Collect the facts
    python_facts = python_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Unit test to check the python facts
    assert python_facts is not None

# Generated at 2022-06-11 05:07:18.845806
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    results = pc.collect()
    assert results is not None


# Generated at 2022-06-11 05:07:27.307908
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    collector = PythonFactCollector()
    # Can't use assertDictContainsSubset - it's only available in Python 2.7+
    subset = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': True
        }
    }
    if hasattr(sys, 'implementation'):
        subset['python'].update({
            'type': sys.implementation.name
        })
    el

# Generated at 2022-06-11 05:07:34.690857
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    results = python_collector.collect()
    assert 'python' in results
    assert 'version' in results['python']
    assert 'major' in results['python']['version']
    assert 'minor' in results['python']['version']
    assert 'micro' in results['python']['version']
    assert 'releaselevel' in results['python']['version']
    assert 'serial' in results['python']['version']
    assert 'version_info' in results['python']
    assert 'type' in results['python']
    # On some python versions 'executable' is not in data
    # assert 'executable' in results['python']
    assert 'has_sslcontext' in results['python']
    # On unit test, type will be None
    # assert

# Generated at 2022-06-11 05:07:38.003188
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    r = f.collect()
    assert 'python' in r
    assert 'version' in r['python']
    assert 'version_info' in r['python']
    assert 'executable' in r['python']
    assert 'has_sslcontext' in r['python']
    assert 'type' in r['python']

# Generated at 2022-06-11 05:07:43.182525
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_facts = PythonFactCollector.collect()
    assert py_facts['python']['version_info'][:3] >= (2, 7, 0)
    assert len(py_facts['python']['version_info']) == 5
    if sys.version_info[0] >= 3:
        assert py_facts['python']['type'] == 'cpython'
    else:
        assert py_facts['python']['type'] == 'python'
    assert py_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-11 05:07:46.817877
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()

    # Just do a simple test to show we are getting some data
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'version_info' in facts['python']

# Generated at 2022-06-11 05:07:53.528153
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect(collected_facts={})
    assert type(python_facts) == dict
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert type(python_facts['python']['version']) == dict
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert type(python_facts['python']['version']['major']) == int

# Generated at 2022-06-11 05:07:59.826440
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    res = pfc.collect()
    assert res['python']['version']['major'] == sys.version_info.major
    assert res['python']['version']['minor'] == sys.version_info.minor
    assert res['python']['version']['micro'] == sys.version_info.micro
    assert res['python']['version']['releaselevel'] == sys.version_info.releaselevel
    assert res['python']['version']['serial'] == sys.version_info.serial
    assert 'type' in res['python']

# Generated at 2022-06-11 05:09:11.714217
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect(): # pylint: disable=invalid-name
    '''Unit test for method collect of class PythonFactCollector'''
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-11 05:09:18.997179
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    # Execute method collect of class PythonFactCollector
    result = fact_collector.collect()

    # Here we are only testing the main keys in the result.
    # The content of these keys is tested in the unit tests for the
    # Python facts in test/units/modules/utils/facts/test_python.py
    assert result['python']['version']['major'] is not None
    assert result['python']['version']['minor'] is not None
    assert result['python']['version']['micro'] is not None
    assert result['python']['version']['releaselevel'] is not None
    assert result['python']['version']['serial'] is not None
    assert result['python']['version_info'] is not None
    assert result

# Generated at 2022-06-11 05:09:21.624140
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    res = pfc.collect()
    assert 'python' in res
    assert 'version' in res['python']
    assert 'version_info' in res['python']
    assert 'executable' in res['python']

# Generated at 2022-06-11 05:09:28.291124
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    assert 'python' in python_facts, \
        'Failed to get python facts'

    python_version = python_facts['python']['version']
    assert isinstance(python_version, dict), \
        'python.version fact is not a dict'

    assert 'major' in python_version, \
        'python.version.major fact does not exist'
    assert isinstance(python_version['major'], int), \
        'python.version.major fact is not an int'

    assert 'micro' in python_version, \
        'python.version.micro fact does not exist'

# Generated at 2022-06-11 05:09:32.348113
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = MockModule()
    collected_facts = {'ansible_python_version': '2.6.1'}
    python_fact_collector = PythonFactCollector(module, collected_facts)
    result = python_fact_collector.collect()
    assert result == {
        'python': {
            'version': {
                'major': 2,
                'minor': 6,
                'micro': 1,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 6, 1, 'final', 0],
            'executable': '/bin/python2.6',
            'has_sslcontext': False
        }
    }


# Generated at 2022-06-11 05:09:38.490104
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test for method collect of class PythonFactCollector"""
    c = PythonFactCollector()
    assert c.collect() == {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': list(sys.version_info), 'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT, 'type': sys.implementation.name}}


# Generated at 2022-06-11 05:09:44.865512
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize module object
    module = AnsibleModule(
        argument_spec = dict()
    )
    
    # Initialize PythonFactCollector object
    fact_collector = PythonFactCollector(module=module)

    # Collect python facts
    facts = fact_collector.collect(module=module)
    
    # Print out the fact
    print(facts)
    assert True

# This is the standard boilerplate that calls the main() function.
if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    main()

# Generated at 2022-06-11 05:09:47.589290
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Get the 'TestBaseFactCollectorClass' object
    python_collector_obj = PythonFactCollector()
    # Call the method 'collect' of class 'TestBaseFactCollectorClass' object
    python_collector_obj.collect()
