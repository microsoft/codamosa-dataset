

# Generated at 2022-06-25 00:23:35.999615
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()
    print('Success')

# Generated at 2022-06-25 00:23:41.561838
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    print(python_fact_collector_1.collect())
    assert python_fact_collector_1.collect() == {'python': {'executable': '/usr/bin/python2.7', 'has_sslcontext': True, 'type': None, 'version': {'major': 2, 'minor': 7, 'micro': 13, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 13, 'final', 0]}}

# Generated at 2022-06-25 00:23:48.291281
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    
    try:
        expected_python_facts_1 = python_fact_collector_1.collect()
    except Exception as expected_results_1:
        actual_python_facts_1 = None
        actual_results_1 = expected_results_1.args
    else:
        actual_python_facts_1 = expected_python_facts_1
        actual_results_1 = expected_python_facts_1

    assert type(actual_python_facts_1) is dict
    assert type(actual_results_1) is dict

# Generated at 2022-06-25 00:23:50.963932
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()
    assert python_facts_0['python']['version']['major'] is not None


# Generated at 2022-06-25 00:23:57.637543
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts_0 = dict()
    expected_facts_0 = dict()
    expected_facts_0['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-25 00:24:03.461646
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    rv = python_fact_collector_1.collect()
    assert rv == {}
    assert rv != []
    assert rv != False
    assert rv != True
    assert rv != "verify_ssl"
    assert rv != "distribution"
    assert rv != "distribution_version"
    assert rv != "distribution_release"
    assert rv != None


# Generated at 2022-06-25 00:24:09.994429
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'type': 'cpython', 'version_info': [2, 7, 12, 'final', 0], 'has_sslcontext': True, 'executable': '/usr/bin/python', 'version': {'serial': 0, 'major': 2, 'micro': 12, 'minor': 7, 'releaselevel': 'final'}}}


# Generated at 2022-06-25 00:24:15.684775
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    ansible_facts_1 = {
        'python': {
            'executable': '/usr/bin/python2.7',
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'micro': 7,
                'major': 2,
                'minor': 7,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [
                2,
                7,
                12,
                'final',
                0
            ]
        }
    }

    assert python_fact_collector_1.collect() == ansible_facts_1


# Generated at 2022-06-25 00:24:16.767410
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:21.335286
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    result_dict = python_fact_collector_0.collect()
    assert result_dict['python']['type'] is not None
    assert result_dict['python']['version']['major'] == sys.version_info[0]
    assert result_dict['python']['version']['minor'] == sys.version_info[1]
    assert result_dict['python']['version']['micro'] == sys.version_info[2]
    assert result_dict['python']['version']['releaselevel'] == sys.version_info[3]
    assert result_dict['python']['version']['serial'] == sys.version_info[4]
    assert result_dict['python']['has_sslcontext'] == HAS_

# Generated at 2022-06-25 00:24:26.078437
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:24:28.370840
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:24:30.729657
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    try:
        python_fact_collector.collect()
    except:
        assert False, 'Failed to collect'

# Generated at 2022-06-25 00:24:42.642804
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect(None)['python']['executable'] != None
    assert python_fact_collector_0.collect(None)['python']['version']['major'] != None
    assert python_fact_collector_0.collect(None)['python']['version']['minor'] != None
    assert python_fact_collector_0.collect(None)['python']['version']['micro'] != None
    assert python_fact_collector_0.collect(None)['python']['version']['releaselevel'] != None
    assert python_fact_collector_0.collect(None)['python']['version']['serial'] != None
    assert python_fact_collector_0

# Generated at 2022-06-25 00:24:47.307180
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_collect = python_fact_collector_0.collect()
    if python_collect['python']['type'] == 'CPython':
        print('info: Python version = %s' % sys.version)
    else:
        print('warning: Python version = %s' % sys.version)

# Generated at 2022-06-25 00:24:51.378831
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    mc = PythonFactCollector()
    ret = mc.collect()
    print(ret)

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:24:54.552063
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    if python_fact_collector_0.collect():
        python_fact_collector_0.collect()
    else:
        python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:56.145628
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:03.098305
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    assert python_fact_collector_1.collect() == {'python': {
        'version': {
            'major': 3,
            'minor': 8,
            'micro': 5,
            'releaselevel': 'final',
            'serial': 0
        },
        'version_info': [3, 8, 5, 'final', 0],
        'executable': '/Users/gulshansingh/bin/python3.8',
        'has_sslcontext': HAS_SSLCONTEXT
    }}

# Generated at 2022-06-25 00:25:08.754979
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts_1 = python_fact_collector_1.collect()
    assert 'python' in python_facts_1
    assert 'type' in python_facts_1['python']
    assert 'version' in python_facts_1['python']
    assert 'executable' in python_facts_1['python']
    assert 'has_sslcontext' in python_facts_1['python']
    assert 'version_info' in python_facts_1['python']


# Generated at 2022-06-25 00:25:25.308959
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

    assert result is not None
    assert isinstance(result, dict)
    assert 'python' in result
    assert isinstance(result['python'], dict)

    # The following test is rather arbitrary, although it can result in false
    # positives when we are testing against an interpreter that it is not the
    # one that is running.
    version = result['python']['version']
    version_info = result['python']['version_info']
    assert version['major'] == version_info[0]
    assert version['minor'] == version_info[1]
    assert version['micro'] == version_info[2]
    assert version['releaselevel'] == version_info[3]
    assert version['serial'] == version

# Generated at 2022-06-25 00:25:29.622202
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    runner = PythonFactCollector()

    #TODO: FIX ME
    expected = {'python': {'has_sslcontext': True, 'executable': '/usr/bin/python', 'version': {'micro': 3, 'major': 2, 'minor': 7, 'releaselevel': 'final', 'serial': 0}}}

    collected_facts = runner.collect()
    assert expected == collected_facts

# Generated at 2022-06-25 00:25:40.180645
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect(module, collected_facts)
    assert result['python']['version_info'] == [2, 7, 9, 'final', 0]
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['micro'] == 0
    assert result['python']['version']['serial'] == 0
    assert result['python']['version']['major'] == 2
    assert result['python']['version']['minor'] == 7
    assert result['python']['has_sslcontext'] == True
    assert result['python']['executable'] == '/usr/bin/python'


# Generated at 2022-06-25 00:25:49.469451
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT, 'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': sys.version_info, 'type': sys.subversion[0]}}, 'Failed to run collect of class PythonFactCollector'

# Generated at 2022-06-25 00:25:58.043673
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    res_0 = python_fact_collector_1.collect()
    res_1 = '2.7.11'
    print(res_0['python']['version']['major'])
    print(res_1)
    print(res_0['python']['version']['major'] == res_1)
    res_2 = '3'
    print(res_0['python']['version_info'])
    print(res_2)
    print(res_0['python']['version_info'] == res_2)
    res_3 = '/Users/david/opt/soft/anaconda/envs/py27/bin/python'
    print(res_0['python']['executable'])
    print

# Generated at 2022-06-25 00:26:08.493433
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = PythonFactCollector().collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'has_sslcontext' in facts['python']

    python_ver = sys.version_info

    assert facts['python']['version']['major'] == python_ver[0]
    assert facts['python']['version']['minor'] == python_ver[1]
    assert facts['python']['version']['micro'] == python_ver[2]
    assert facts['python']['version']['releaselevel'] == python_ver[3]
    assert facts['python']['version']['serial'] == python_ver[4]

    assert facts['python']['version_info'] == list(python_ver)


# Generated at 2022-06-25 00:26:16.415168
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # arrange
    python_fact_collector_1 = PythonFactCollector()

    # act
    actual_result_1 = python_fact_collector_1.collect()

    # assert
    assert hasattr(actual_result_1, '__getitem__')
    assert hasattr(actual_result_1, '__setitem__')
    assert hasattr(actual_result_1, '__contains__')
    assert hasattr(actual_result_1, '__delitem__')
    assert hasattr(actual_result_1, '__len__')
    assert hasattr(actual_result_1, '__iter__')
    assert hasattr(actual_result_1, '__eq__')
    assert hasattr(actual_result_1, '__repr__')

# Generated at 2022-06-25 00:26:19.349457
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # The first test case is a mismatch
    if test_case_0() != python_fact_collector_0.collect():
        raise AssertionError('Test 1 FAILED')

# Generated at 2022-06-25 00:26:25.088216
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    _python_fact_collector = PythonFactCollector()
    assert _python_fact_collector.collect() == {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': [sys.version_info[0], sys.version_info[1], sys.version_info[2], sys.version_info[3], sys.version_info[4]], 'executable': sys.executable, 'has_sslcontext': True, 'type': sys.implementation.name}}

# Generated at 2022-06-25 00:26:28.618399
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    class_ansible_module_1 = ''
    class_collected_facts_1 = {}
    assert isinstance(python_fact_collector_1.collect(class_ansible_module_1, class_collected_facts_1), type({})) == True


# Generated at 2022-06-25 00:26:45.451736
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() is not None

# Generated at 2022-06-25 00:26:52.454840
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['executable'].split('/')[-1] == 'python3'
    assert result['python']['executable'].split('/')[-2] == 'bin'
    assert result['python']['type'] == 'CPython'
    assert result['python']['version']['major'] == 3


# Generated at 2022-06-25 00:26:57.720574
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {"python": {"version": {"major": 2, "minor": 7, "micro": 14, "releaselevel": "final", "serial": 0}, "version_info": [2, 7, 14, "final", 0], "executable": "/usr/bin/python", "has_sslcontext": False}, "_ansible_version": {"full": "2.9.9", "major": 2, "minor": 9, "revision": 9, "string": "2.9.9"}}



# Generated at 2022-06-25 00:26:58.926960
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:27:00.827602
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert isinstance(python_facts, dict)


# Generated at 2022-06-25 00:27:01.414973
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:27:09.022142
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result == {
        "python": {
            "has_sslcontext": True,
            "executable": sys.executable,
            "type": "CPython",
            "version_info": [
                3,
                5,
                0,
                "final",
                0
            ],
            "version": {
                "major": 3,
                "micro": 0,
                "releaselevel": "final",
                "serial": 0,
                "minor": 5
            }
        }
    }

# Generated at 2022-06-25 00:27:12.063478
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    The test for method collect of class PythonFactCollector.
    """
    # Init needed variables.
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    # Check
    assert isinstance(python_facts, dict)
    assert python_facts.get('ansible_facts', None) is not None
    assert isinstance(python_facts['ansible_facts'].get('python', None), dict)

# Generated at 2022-06-25 00:27:13.872401
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:27:21.086108
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    out = PythonFactCollector.collect()
    assert 'python' in out.keys()
    assert 'version' in out['python'].keys()
    assert 'major' in out['python']['version'].keys()
    assert 'minor' in out['python']['version'].keys()
    assert 'micro' in out['python']['version'].keys()
    assert 'releaselevel' in out['python']['version'].keys()
    assert 'serial' in out['python']['version'].keys()
    assert 'version_info' in out['python'].keys()
    assert 'executable' in out['python'].keys()
    assert 'has_sslcontext' in out['python'].keys()

# Generated at 2022-06-25 00:27:58.838786
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Test case for collecting a dictionary
    python_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:28:02.647221
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    test_collect = python_fact_collector_0.collect(collected_facts=collected_facts)
    assert "python" in test_collect.keys()

# Generated at 2022-06-25 00:28:05.948965
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    # Test that executable is not an empty string
    assert python_facts['python']['executable'] != ''

    # Test that version is not an empty list
    assert python_facts['python']['version']['releaselevel'] != ''

# Generated at 2022-06-25 00:28:11.247997
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert facts.get('python') is not None
    assert facts['python'].get('version') is not None
    assert facts['python'].get('version_info') is not None
    assert facts['python'].get('executable') is not None

# Generated at 2022-06-25 00:28:12.354288
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:28:17.492514
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    actual = python_fact_collector_0.collect()
    expected = {'python': {'type': 'CPython', 'version_info': [3, 5, 1, 'final', 0], 'version': {'releaselevel': 'final', 'minor': 5, 'serial': 0, 'micro': 1, 'major': 3}, 'executable': '/usr/bin/python3', 'has_sslcontext': True}}

    assert actual == expected

# Generated at 2022-06-25 00:28:20.610770
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test case for method collect of class PythonFactCollector
    """
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert isinstance(result, dict)


# Generated at 2022-06-25 00:28:28.160263
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    python_fact_collector_0.collect(collected_facts=collected_facts)
    assert type(collected_facts['python']['version_info']) == list, 'variable "collected_facts[\'python\'][\'version_info\']" is not of type "list"'
    assert type(collected_facts['python']['has_sslcontext']) == bool, 'variable "collected_facts[\'python\'][\'has_sslcontext\']" is not of type "bool"'
    assert type(collected_facts['python']['executable']) == str, 'variable "collected_facts[\'python\'][\'executable\']" is not of type "str"'

# Generated at 2022-06-25 00:28:31.103108
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test collect method of class PythonFactCollector
    """
    python_fact_collector_0 = PythonFactCollector()
    result_dict = python_fact_collector_0.collect()
    assert result_dict == None

# Generated at 2022-06-25 00:28:37.686150
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    sys.version_info = (3, 5, 2, 'final', 0)
    sys.executable = '/usr/bin/python3'
    sys.subversion = ('CPython', '', '')
    sys.implementation.name = None
    python_fact_collector_0.collect()
    assert 'python' == python_fact_collector_0.name
    python_fact_collector_0.collect()
    assert python_fact_collector_0._fact_ids == set()
    python_fact_collector_0.collect()
    assert sys.executable == python_fact_collector_0.data['python']['executable']


# Generated at 2022-06-25 00:29:16.295422
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # PythonFactCollector: collect
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 == {'python': {'type': 'CPython', 'executable': '/usr/bin/python', 'version': {'micro': 3, 'minor': 7, 'major': 3, 'serial': 0, 'releaselevel': 'final'}, 'version_info': [3, 7, 3, 'final', 0], 'has_sslcontext': True}}


# Generated at 2022-06-25 00:29:20.152742
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print("Testing method collect")
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    print(var_0)
    print("Success")

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:29:25.303811
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:29:28.737721
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    class_0 = PythonFactCollector()
    class_0_instance = class_0()
    class_0_instance_collect = class_0_instance.collect()
    assert class_0_instance_collect is not None, "PythonFactCollector.collect returned an empty collection"
    assert class_0_instance_collect.get('python') is not None, "PythonFactCollector.collect returned an empty collection of python facts"

# Generated at 2022-06-25 00:29:33.823063
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # all_collector_classes = set()
    # for method_name in dir(BaseFactCollector):
    #     if method_name.startswith('collect'):
    #         method = getattr(BaseFactCollector, method_name)
    #         if callable(method):
    #             all_collector_classes.add(method.__self__.__class__)
    # tester = PytestTester(BaseFactCollector)
    # tester.assert_called_once(BaseFactCollector, 'collect')
    arg = BaseFactCollector()
    assert arg


# Generated at 2022-06-25 00:29:42.292079
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    # AssertionError: assert {} == {'python': {'type': 'CPython', 'has_sslcontext': True, 'executable': '/usr/local/bin/python', 'version': {'micro': 0, 'major': 2, 'releaselevel': 'final', 'minor': 7, 'serial': 0}, 'version_info': [2, 7, 0, 'final', 0]}}
    # ------------
    # var_0 = {}
    # assert var_0 == {'python': {'type': 'CPython', 'has_sslcontext': True, 'executable': '/usr/local/bin/python', 'version': {'micro': 0, 'major': 2, 'releaselevel': '

# Generated at 2022-06-25 00:29:52.110112
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    result = c.collect()
    assert isinstance(result, dict)
    assert isinstance(result['python']['version'], dict)
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable']

# Generated at 2022-06-25 00:29:59.901893
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_2 = PythonFactCollector()
    python_fact_collector_3 = PythonFactCollector()
    python_fact_collector_4 = PythonFactCollector()
    python_fact_collector_5 = PythonFactCollector()
    python_fact_collector_6 = PythonFactCollector()
    python_fact_collector_7 = PythonFactCollector()
    python_fact_collector_8 = PythonFactCollector()

# Generated at 2022-06-25 00:30:07.938710
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-25 00:30:12.220811
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    global python_fact_collector_0
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:31:22.137479
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:23.742432
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:31:25.331749
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert True

# Generated at 2022-06-25 00:31:26.911534
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect()


# Generated at 2022-06-25 00:31:27.352873
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:31:28.771504
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:30.416942
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print("> Test case 0")
    test_case_0()

# Generated at 2022-06-25 00:31:36.531914
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'version': {'releaselevel': 'final', 'micro': 0, 'major': 2, 'minor': 7, 'serial': 0}, 'version_info': [2, 7, 0, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-25 00:31:39.666503
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:41.977487
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert test_PythonFactCollector_collect.__doc__
