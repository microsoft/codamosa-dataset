

# Generated at 2022-06-25 00:23:31.031298
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:23:34.052311
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test case 0
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:23:39.555545
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect().keys() == ['python']
    assert python_fact_collector.collect()['python'].keys() == ['version', 'version_info', 'executable', 'has_sslcontext']
    assert python_fact_collector.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert python_fact_collector.collect()['python']['executable'] == sys.executable

# Generated at 2022-06-25 00:23:43.360525
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts = python_fact_collector_0.collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']



# Generated at 2022-06-25 00:23:52.076928
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Unit test for collect method of class PythonFactCollector
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert type(python_facts) is dict
    assert python_facts.get('python') is not None
    assert type(python_facts.get('python')) is dict
    assert python_facts['python'].get('version') is not None
    assert type(python_facts['python'].get('version')) is dict
    assert python_facts['python']['version'].get('major') is not None
    assert type(python_facts['python']['version']['major']) is int
    assert python_facts['python']['version'].get('minor') is not None

# Generated at 2022-06-25 00:23:55.398272
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Get an instance
    python_fact_collector_0 = PythonFactCollector()

    # Test the method
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:04.750101
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    type_value = 'CPython'
    major_value = sys.version_info[0]
    minor_value = sys.version_info[1]
    micro_value = sys.version_info[2]
    releaselevel_value = sys.version_info[3]
    serial_value = sys.version_info[4]
    version_info_value = list(sys.version_info)
    executable_value = sys.executable
    has_sslcontext_value = HAS_SSLCONTEXT

    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()
    python_fact_collector_2 = PythonFactCollector()
    python_fact_collector_2.collect()

    python_facts_value = python_fact_collector_2.collect()



# Generated at 2022-06-25 00:24:07.120176
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Collect facts
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:24:11.174081
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        import sys
    except ImportError:
        pass # skip - this will be tested below
    else:
        python_fact_collector_0 = PythonFactCollector()
        assert isinstance(python_fact_collector_0, PythonFactCollector)
        python_fact_collector_0.collect()
        assert type(python_fact_collector_0) == PythonFactCollector

# Generated at 2022-06-25 00:24:11.658287
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:24:19.584129
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert len(python_facts) == 1
    assert 'python' in python_facts
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-25 00:24:20.817419
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:24:27.710319
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert var_1['python']['version']['major'] == sys.version_info[0]
    assert var_1['python']['version']['micro'] == sys.version_info[2]
    assert var_1['python']['version']['minor'] == sys.version_info[1]
    assert var_1['python']['version']['releaselevel'] == sys.version_info[3]
    assert var_1['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-25 00:24:28.673370
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # TODO
    pass


# Generated at 2022-06-25 00:24:31.000798
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # create PythonFactCollector
    python_fact_collector_0 = PythonFactCollector()

    # invoke method collect
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:34.938300
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

    assert var_1 is not None


# Generated at 2022-06-25 00:24:38.576499
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector_collect = PythonFactCollector().collect()
    assert python_fact_collector_collect['python']['type'] == 'cpython'


# Generated at 2022-06-25 00:24:39.637442
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:24:43.916950
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        python_fact_collector_0 = PythonFactCollector()
        python_fact_collector_0.collect()
    except:
        var_1 = False
        var_1 = not var_1

test_case_0()
test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:24:50.241639
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    if not isinstance(var_1, dict):
        raise AssertionError('Return value from PythonFactCollector.collect() was not the expected type: expected=dict, given={}'.format(type(var_1).__name__))
    if not var_1:
        raise AssertionError('Return value from PythonFactCollector.collect() was empty, but there was data expected to be returned.')


# Generated at 2022-06-25 00:25:01.030377
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fixture_0 = [
        {
            'python': {
                'version': {
                    'major': 2,
                    'minor': 7,
                    'micro': 12,
                    'releaselevel': 'final',
                    'serial': 0
                },
                'version_info': [2, 7, 12, 'final', 0],
                'type': 'CPython',
                'executable': '/path/to/python',
                'has_sslcontext': False
            }
        }
    ]

    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == fixture_0


# Generated at 2022-06-25 00:25:07.095151
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # If what we collect not in the default facts, we'll get the events
    # In the unit test we need to set the facts
    python_fact_collector_0 = PythonFactCollector()

    # Set collected_facts to a empty dict
    collected_facts = dict()
    python_fact_collector_0.collect(collected_facts=collected_facts)

    assert 'python' in collected_facts
    assert collected_facts['python']['version']['major'] == sys.version_info[0]



# Generated at 2022-06-25 00:25:16.625919
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  # Instantiate the PythonFactCollector class
  python_fact_collector_0 = PythonFactCollector()
  # Collect a fact
  var_0 = python_fact_collector_0.collect()
  # Assert the fact is True
  assert var_0 == {
      'python': {
          'version': {
              'major': sys.version_info[0],
              'minor': sys.version_info[1],
              'micro': sys.version_info[2],
              'releaselevel': sys.version_info[3],
              'serial': sys.version_info[4]
          },
          'version_info': list(sys.version_info),
          'executable': sys.executable,
          'has_sslcontext': HAS_SSLCONTEXT
      }
  }

# Generated at 2022-06-25 00:25:19.574520
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # No parameter test exception.
    python_fact_collector_0.collect()
    # No exception should be raised.


# Generated at 2022-06-25 00:25:26.762315
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import PythonFactCollector
    import sys

    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = isinstance(var_0, dict)
    var_2 = isinstance(var_0, BaseFactCollector)
    var_3 = isinstance(var_0, Collector)
    var_4 = isinstance(var_0, PythonFactCollector)


# Generated at 2022-06-25 00:25:27.140217
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Pass
    pass

# Generated at 2022-06-25 00:25:30.120625
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # The python_fact_collector_0 object
    python_fact_collector_0 = PythonFactCollector()

    # Invoke method
    var_0 = python_fact_collector_0.collect()

    # Check return type
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:25:37.936382
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # No assertions in this test.
    # Constructor test with args
    python_fact_collector_1 = PythonFactCollector()
    assert isinstance(python_fact_collector_0, PythonFactCollector)

    # test case PythonFactCollector.collect
    # No assertions in this test.
    # Creating a new PythonFactCollector instance
    python_fact_collector_2 = PythonFactCollector()
    var_0 = python_fact_collector_2.collect()
    assert var_0 is not None
    

# Generated at 2022-06-25 00:25:43.270847
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'has_sslcontext': True, 'executable': '/usr/bin/python', 'type': 'CPython', 'version': {'releaselevel': 'final', 'micro': 0, 'serial': 0, 'major': 2, 'minor': 7}, 'version_info': [2, 7, 12, 'final', 0]}}, var_0


# Generated at 2022-06-25 00:25:46.575351
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:25:56.552596
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:58.691103
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert len(var_1['python']['version']) == 5

# Generated at 2022-06-25 00:26:00.197106
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()



# Generated at 2022-06-25 00:26:02.926859
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create object of class PythonFactCollector
    python_fact_collector_0 = PythonFactCollector()

    # Invoke method collect of class PythonFactCollector
    var_0 = python_fact_collector_0.collect()

    # Assertions
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:26:10.627328
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    sys.version_info = (1,2,3,4,5)
    sys.version = 'version string'
    sys.executable = 'the_executable_path'
    sys.implementation = object()
    sys.subversion = ('implementation', 'branch', 'revision')
    var_0 = PythonFactCollector()
    var_0.collect(module=None, collected_facts=None)
    expected_0 = 'sys.subversion'
    actual_0 = var_0.python['type']
    assert actual_0 == expected_0
    sys.subversion = None
    var_0.collect(module=None, collected_facts=None)
    expected_1 = sys.implementation.name
    actual_1 = var_0.python['type']
    assert actual_1 == expected_1


# Generated at 2022-06-25 00:26:12.725671
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert 0


# Generated at 2022-06-25 00:26:20.018638
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()
    assert var_1 == {'python': {'executable': '/usr/bin/python', 'has_sslcontext': True, 'version_info': [2, 6, 9, 'final', 0], 'type': 'CPython', 'version': {'micro': 9, 'releaselevel': 'final', 'minor': 6, 'serial': 0, 'major': 2}}}
    assert python_fact_collector_0.name == 'python'



# Generated at 2022-06-25 00:26:24.621493
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert test_case_0() == None

# Generated at 2022-06-25 00:26:25.967964
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:35.197999
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    if PY3:
        expected = {'python': {'version': {'releaselevel': 'final', 'serial': 0, 'minor': 5, 'micro': 0, 'major': 3}, 'type': 'CPython', 'executable': '/usr/bin/python3', 'version_info': [3, 5, 0, 'final', 0], 'has_sslcontext': True}}
    else:
        expected = {'python': {'version': {'releaselevel': 'final', 'serial': 0, 'minor': 4, 'micro': 4, 'major': 2}, 'type': 'CPython', 'executable': '/usr/bin/python', 'version_info': [2, 4, 4, 'final', 0], 'has_sslcontext': True}}

    result = python_

# Generated at 2022-06-25 00:26:52.978822
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_2 = PythonFactCollector()
    try:
        python_fact_collector_2.collect()
    except RuntimeError:
        pass
    else:
        assert False, "Unreachable"



# Generated at 2022-06-25 00:26:54.498766
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert False  # No known implementation


# Generated at 2022-06-25 00:26:56.476486
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:26:57.908375
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()


# Generated at 2022-06-25 00:26:59.673830
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    assert type(var_0) is dict

# Generated at 2022-06-25 00:27:01.634435
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() is not None
    assert python_fact_collector_1.collect().get('python') is not None


# Generated at 2022-06-25 00:27:02.966877
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert type(python_fact_collector_0.collect()) is dict


# Generated at 2022-06-25 00:27:04.148843
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test method is not available yet - skipped
    return


# Generated at 2022-06-25 00:27:13.101519
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-25 00:27:17.956264
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:27:54.555355
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize a variable to represent the return value of method collect of class PythonFactCollector
    retval = None

    # Invoke the function under test
    retval = PythonFactCollector.collect()

    # Assert the return value of the function under test is as expected
    assert retval == None

# Generated at 2022-06-25 00:27:58.909776
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        python_fact_collector_0 = PythonFactCollector()
        var_0 = python_fact_collector_0.collect()
    except Exception as e:
        print(str(e))



# Generated at 2022-06-25 00:28:07.146488
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector(
        ansible_facts={},
        collected_facts={}
    )
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['major'] == 3
    python_fact_collector_1 = PythonFactCollector(
        ansible_facts={},
        collected_facts={}
    )
    var_1 = python_fact_collector_1.collect()
    assert var_1['python']['version']['minor'] == 5
    python_fact_collector_2 = PythonFactCollector(
        ansible_facts={},
        collected_facts={}
    )
    var_2 = python_fact_collector_2.collect()

# Generated at 2022-06-25 00:28:08.923413
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector.collect(module=None, collected_facts=None)
    assert python_fact_collector_0 is not None


# Generated at 2022-06-25 00:28:12.202377
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:18.134821
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 is not None
    assert len(var_0) > 0
    assert var_0.startswith("{")
    assert var_0.endswith("}")
    assert var_0 == "{'python': {'type': 'CPython', 'version_info': [2, 7, 5, 'final', 0], 'executable': '/usr/bin/python', 'version': {'micro': 5, 'releaselevel': 'final', 'serial': 0, 'minor': 7, 'major': 2}, 'has_sslcontext': True}}"

# Generated at 2022-06-25 00:28:27.014971
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    if var_0.__class__ != dict:
        raise Exception("Failed test for type of method collect of class PythonFactCollector")
    var_1 = var_0.keys()
    var_2 = 'python' in var_1
    if var_2:
        var_3 = var_0['python']
        var_4 = var_3.__class__ != dict
        if var_4:
            raise Exception("Failed test for type of parameter python of method collect of class PythonFactCollector")
        var_5 = var_3.keys()
        var_6 = 'version' in var_5
        if var_6:
            var_7 = var_3['version']


# Generated at 2022-06-25 00:28:29.522113
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:28:31.006657
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fm = PythonFactCollector() #type: PythonFactCollector
    assert isinstance(fm.collect(), dict)

# Generated at 2022-06-25 00:28:32.501716
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:29:47.469369
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Unit test for method collect of class PythonFactCollector
    '''
    # This variable is used to store the failure messages
    err_msg = ''
    # This variable is used to store the row number of the test case
    row = 0

    python_fact_collector_0 = PythonFactCollector()
    try:
        var_0 = python_fact_collector_0.collect()
    except Exception as err:
        # Store the failure message or error
        err_msg = str(err)
        row = row + 1
        # Print the test case failure message
        print ("Test Case", row, ": Failed")
        print ("Error:", err_msg)
        sys.exit(1)

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector

# Generated at 2022-06-25 00:29:53.967752
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['major'] == 2
    assert var_0['python']['version']['minor'] == 7
    assert var_0['python']['version']['micro'] == 12
    assert var_0['python']['version']['releaselevel'] == 'final'
    assert var_0['python']['version']['serial'] == 0
    assert var_0['python']['version_info'] == [2, 7, 12, 'final', 0]
    assert var_0['python']['executable'] == '/usr/bin/python'
    assert var_0['python']['has_sslcontext'] == True

# Generated at 2022-06-25 00:29:55.564742
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    print(var_1)

# Generated at 2022-06-25 00:30:04.340892
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 ==  {
        "python": {
        "type": "python",
        "version": {
        "serial": 0,
        "releaselevel": "final",
        "micro": 2,
        "minor": 7,
        "major": 2
        },
        "executable": "/usr/bin/python",
        "version_info": [
        2,
        7,
        2,
        "final",
        0
        ],
        "has_sslcontext": True
        }
    }

# Generated at 2022-06-25 00:30:11.578840
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    assert type(python_facts) == dict
    assert python_facts['python']
    assert type(python_facts['python']) == dict

    assert type(python_facts['python']['version']['major']) == int
    assert type(python_facts['python']['version']['minor']) == int
    assert type(python_facts['python']['version']['micro']) == int
    assert type(python_facts['python']['version']['releaselevel']) == str
    assert type(python_facts['python']['version']['serial']) == int

    assert type(python_facts['python']['version_info']) == list

# Generated at 2022-06-25 00:30:18.254784
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'version': {'micro': 0, 'releaselevel': 'final', 'major': 2, 'minor': 7, 'serial': 0}, 'executable': '/usr/bin/python', 'version_info': [2, 7, 0, 'final', 0], 'has_sslcontext': False}}


# Generated at 2022-06-25 00:30:27.705191
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    _int_0 = var_0['python']['version']['major']
    _int_1 = var_0['python']['version']['minor']
    _int_2 = var_0['python']['version']['micro']
    _str_0 = var_0['python']['version']['releaselevel']
    _int_3 = var_0['python']['version']['serial']
    try:
        _str_1 = var_0['python']['type']
    except KeyError:
        pass
    _str_2 = var_0['python']['executable']

# Generated at 2022-06-25 00:30:29.014520
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()


# Generated at 2022-06-25 00:30:30.514380
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:30:33.907015
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 12, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 12, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False}}


# Generated at 2022-06-25 00:33:00.015624
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    x = PythonFactCollector()
    x.collect()

# Generated at 2022-06-25 00:33:06.015388
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test 1A: Calls with no arguments:
    #
    # Case 1A.1: no python.type (exception NotImplementedError)
    try:
        python_fact_collector_0 = PythonFactCollector()
        var_0 = python_fact_collector_0.collect()
    except NotImplementedError:
        pass
    #
    # Case 1A.2: python.type = "CPython"
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    #
    # Case 1A.3: python.type = "Jython"
    # NOT SUPPORTED
    #
    # Case 1A.4: python.type = "PyPy"
    # NOT SUPPORTED
    #
    # Test 2A

# Generated at 2022-06-25 00:33:07.901436
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0['python']


# Generated at 2022-06-25 00:33:09.103678
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()



# Generated at 2022-06-25 00:33:16.715958
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_0 = PythonFactCollector()
    assertion_0 = python_fact_collector_0.collect()

    assertion_0 = PythonFactCollector()
    var_0 = assertion_0.collect()

    # Verify that 'python.version_info' is of type tuple
    var_1 = var_0['python']['version_info']

    assertion_1 = isinstance(var_1, tuple)

    assertion_2 = 'python' in var_0

    assertion_3 = 'version' in var_0['python']

    assertion_4 = 'version_info' in var_0['python']

    assertion_5 = 'executable' in var_0['python']

    assertion_6 = 'has_sslcontext' in var_0['python']

    assertion_7 = 'type' in var_

# Generated at 2022-06-25 00:33:19.634899
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

test_case_0()
test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:33:20.385686
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        test_case_0()
    except Exception:
        assert False

# Generated at 2022-06-25 00:33:24.270913
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:33:28.795430
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
