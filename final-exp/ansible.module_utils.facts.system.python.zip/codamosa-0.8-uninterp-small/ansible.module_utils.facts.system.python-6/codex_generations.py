

# Generated at 2022-06-25 00:23:37.368202
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = {}
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect(collected_facts=collected_facts) == {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': list(sys.version_info), 'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT}}

if __name__ == "__main__":
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:23:40.934067
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()

    assert python_facts_0["python"]["version"]["major"] == 3
    assert python_facts_0["python"]["has_sslcontext"] == HAS_SSLCONTEXT

# Generated at 2022-06-25 00:23:49.526002
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0 is not None
    result = python_fact_collector_0.collect()
    assert 'python' in result
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 5
    assert result['python']['version']['micro'] == 2
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    # assert result['python']['version_info'] == (3, 5, 2, 'final', 0)
    # assert result['python']['executable'] == '/usr/bin/python3'
    # assert result['python'][

# Generated at 2022-06-25 00:23:51.274795
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    output = c.collect()

    # assert type(output) == dict
    # assert output == {}

# Generated at 2022-06-25 00:23:56.562458
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    return_value = {u'python': {u'has_sslcontext': HAS_SSLCONTEXT, u'version_info': [2, 7, 14, u'final', 0], u'version': {u'micro': 14, u'major': 2, u'minor': 7, u'releaselevel': u'final', u'serial': 0}, u'type': u'CPython', u'executable': u'/usr/bin/python'}}
    python_fact_collector_1 = PythonFactCollector()
    assert return_value == python_fact_collector_1.collect()


# Generated at 2022-06-25 00:24:05.508587
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts = python_fact_collector_1.collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']['version']['major'] == 3
    assert python_facts['python']['version']['minor'] == 5
    assert python_facts['python']['version']['micro'] == 0
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert python_facts['python']['version']['serial'] == 0
    assert python_facts['python']['version_info'] == [3, 5, 0, 'final', 0]
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-25 00:24:15.493580
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Test function for test case 0
    '''
    py_facts_col_0 = PythonFactCollector()
    plain_data = py_facts_col_0.collect()
    assert plain_data['python']['version']['major'] == sys.version_info[0]
    assert plain_data['python']['version']['minor'] == sys.version_info[1]
    assert plain_data['python']['version']['micro'] == sys.version_info[2]
    assert plain_data['python']['version']['releaselevel'] == sys.version_info[3]
    assert plain_data['python']['version']['serial'] == sys.version_info[4]
    assert plain_data['python']['executable'] == sys.executable



# Generated at 2022-06-25 00:24:24.152335
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect(None)
    assert result == {'python':
                          {'has_sslcontext': HAS_SSLCONTEXT,
                           'version': {'major': sys.version_info[0],
                                       'minor': sys.version_info[1],
                                       'micro': sys.version_info[2],
                                       'releaselevel': sys.version_info[3],
                                       'serial': sys.version_info[4]},
                           'version_info': list(sys.version_info),
                           'executable': sys.executable,
                           'type': sys.implementation.name}
                      }


# Generated at 2022-06-25 00:24:28.365803
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    # Generated from packet capture.
    # return python_facts
    python_facts = {
        'python': {
            u'has_sslcontext': HAS_SSLCONTEXT,
            u'executable': '/path/to/python/executable',
            u'version': {
                u'releaselevel': 'alpha',
                u'major': 3,
                u'micro': 0,
                u'minor': 5,
                u'serial': 0
            },
            u'version_info': [3, 5, 0, 'alpha', 0],
            u'type': 'CPython'
        }
    }

    facts = python_fact_collector.collect()

    assert facts == python_facts

# Generated at 2022-06-25 00:24:30.729662
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method collect of class PythonFactCollectorTestCase"""

    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:45.141608
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'type' in result['python']
    assert 'has_sslcontext' in result['python']
    assert isinstance(result['python']['version'], dict)
    assert isinstance(result['python']['version_info'], list)
    assert isinstance(result['python']['executable'], basestring)
    assert isinstance(result['python']['type'], basestring)
    assert isinstance(result['python']['has_sslcontext'], bool)

# Generated at 2022-06-25 00:24:47.074315
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect('module_0', 'collected_facts_0')


# Generated at 2022-06-25 00:24:51.192198
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector_obj = PythonFactCollector()
    assert fact_collector_obj.collect() == {'python': {'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': 'CPython', 'version': {'major': 2, 'micro': 2, 'minor': 7, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 2, 'final', 0]}}


# Generated at 2022-06-25 00:24:53.564552
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    facts_1 = python_fact_collector_1.collect()
    assert isinstance(facts_1, dict)

# Generated at 2022-06-25 00:24:55.228259
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:25:04.552035
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert isinstance(result, dict)
    assert result.get('python')
    assert 'version' in result.get('python')
    assert result.get('python').get('version').get('major')
    assert result.get('python').get('version').get('minor')
    assert result.get('python').get('version').get('micro')
    assert result.get('python').get('version').get('releaselevel')
    assert result.get('python').get('version').get('serial')
    assert result.get('python').get('version_info')
    assert result.get('python').get('executable')
    assert 'type' in result.get('python')

# Generated at 2022-06-25 00:25:05.837072
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()


# Generated at 2022-06-25 00:25:07.764315
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:17.772255
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    
    expected_python_facts_1 = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name if hasattr(sys, 'implementation') else None,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
        }
    }

    output_python_facts_1 = python_fact_collector_1

# Generated at 2022-06-25 00:25:20.079598
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert isinstance(result, dict)


# Generated at 2022-06-25 00:25:34.665530
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    testcase = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-25 00:25:38.498389
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    _python_fact_collector_0 = PythonFactCollector()
    python_facts = _python_fact_collector_0.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']


# Generated at 2022-06-25 00:25:40.834674
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass


if __name__ == "__main__":
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:25:49.986305
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    if python_fact_collector.collect(collected_facts) == collected_facts:
        return True
    else:
        return False

# Generated at 2022-06-25 00:25:51.349309
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test instantiation
    python_fact_collector_0 = PythonFactCollector()

    # No methods to test


# Generated at 2022-06-25 00:25:58.426342
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert type(result) is dict
    assert result['python']['executable'] is not None
    assert result['python']['has_sslcontext'] is not None
    assert result['python']['type'] is not None
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-25 00:26:08.523579
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert isinstance(result, dict)
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert isinstance(result['python']['version'], dict)
    assert result['python']['version']['major'] == 3
    assert isinstance(result['python']['version_info'], list)
    assert len(result['python']['version_info']) == 5
    assert result['python']['version_info'][0] == 3
    assert result['python']['executable']

# Generated at 2022-06-25 00:26:17.429279
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    actual_result = python_fact_collector_0.collect()
    expected_result = {'python': {'type': None, 'version': {'serial': 0, 'releaselevel': 'final', 'micro': 0, 'minor': 7, 'major': 3}, 'has_sslcontext': True, 'executable': '/usr/bin/python', 'version_info': [3, 7, 0, 'final', 0]}}
    print(actual_result)
    print("Actual Result : {}".format(actual_result))
    print("Expected Result : {}".format(expected_result))
    assert actual_result == expected_result

if __name__ == '__main__':
    pytest.main(test_case_0())

# Generated at 2022-06-25 00:26:19.805630
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c_0 = PythonFactCollector()
    dict_0 = c_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:26:21.987155
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    captured_result = python_fact_collector_0.collect()
    assert isinstance(captured_result, dict)

# Generated at 2022-06-25 00:26:38.133689
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert type(var_1) is dict
    assert len(var_1) > 0
    assert 'python' in var_1
    assert type(var_1['python']) is dict
    assert len(var_1['python']) > 0
    assert 'version' in var_1['python']
    assert type(var_1['python']['version']) is dict
    assert len(var_1['python']['version']) > 0
    assert 'major' in var_1['python']['version']
    assert type(var_1['python']['version']['major']) is int
    assert 'minor' in var_1['python']['version']


# Generated at 2022-06-25 00:26:41.139318
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()
    var_1 = var_0.collect()
    print(var_1)

# Generated at 2022-06-25 00:26:47.353246
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['major'] == sys.version_info[0]
    assert var_0['python']['version']['minor'] == sys.version_info[1]
    assert var_0['python']['version']['micro'] == sys.version_info[2]
    assert var_0['python']['version']['releaselevel'] == sys.version_info[3]
    assert var_0['python']['version']['serial'] == sys.version_info[4]
    assert var_0['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:26:51.601114
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:57.287350
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['type'] == 'CPython'
    assert var_0['python']['executable'] == '/usr/local/bin/ansible-test-runner'
    assert var_0['python']['has_sslcontext']
    assert var_0['python']['version']['major'] == 3
    assert var_0['python']['version']['minor'] == 4
    assert var_0['python']['version']['micro'] == 1


# Generated at 2022-06-25 00:27:04.380673
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts_dictionary = {}
    result = python_fact_collector_0.collect(None, facts_dictionary)
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 5
    assert result['python']['version']['micro'] == 2
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [3, 5, 2, 'final', 0]
    assert result['python']['executable'] == '/usr/bin/python'
    assert result['python']['has_sslcontext'] == True

# Generated at 2022-06-25 00:27:11.134235
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    parameters = { }
    parameters['module'] = None
    parameters['collected_facts'] = None
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(**parameters)
    try:
        assert var_0 == ''
    except AssertionError as e:
        print("Testcase 0 failed: " + str(e))


# Generated at 2022-06-25 00:27:12.131485
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()

    assert (var_0.collect())

# Generated at 2022-06-25 00:27:15.706334
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_0 = {'python': {'has_sslcontext': False, 'executable': '/usr/bin/python', 'version_info': [2, 6, 8, 'final', 0], 'type': 'CPython', 'version': {'releaselevel': 'final', 'major': 2, 'minor': 6, 'micro': 8, 'serial': 0}}}
    var_1 = python_fact_collector_1.collect()
    assert var_0 == var_1


# Generated at 2022-06-25 00:27:17.184313
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()

    assert var_1 != None


# Generated at 2022-06-25 00:27:35.435831
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()


# Generated at 2022-06-25 00:27:37.173911
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-25 00:27:37.574819
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:27:41.772913
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:27:47.976877
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()
    assert var_1 is not None
    assert var_1.get('python.version') is not None
    assert var_1.get('python.has_sslcontext') is not None
    assert var_1.get('python.version_info') is not None
    assert var_1.get('python.executable') is not None
    assert var_1.get('python.type') is not None
    assert var_1.get('python.version.major') == 3
    assert var_1.get('python.version.micro') == 5
    assert var_1.get('python.version.minor') == 2
    assert var_1.get('python.version.releaselevel') == 'final'

# Generated at 2022-06-25 00:27:53.235555
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_0 = python_fact_collector_1.collect()
    assert type(var_0) == dict


# Generated at 2022-06-25 00:28:02.348122
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['major'] == sys.version_info[0]
    assert var_0['python']['version']['minor'] == sys.version_info[1]
    assert var_0['python']['version']['micro'] == sys.version_info[2]
    assert var_0['python']['version']['releaselevel'] == sys.version_info[3]
    assert var_0['python']['version']['serial'] == sys.version_info[4]
    assert var_0['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:28:08.530335
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    data = PythonFactCollector().collect()
    assert 'python' in data
    assert data['python']['version']['major'] == sys.version_info[0]
    assert data['python']['version']['minor'] == sys.version_info[1]
    assert data['python']['version']['micro'] == sys.version_info[2]
    assert data['python']['version']['releaselevel'] == sys.version_info[3]
    assert data['python']['version']['serial'] == sys.version_info[4]
    assert data['python']['version_info'] == list(sys.version_info)
    assert data['python']['executable'] == sys.executable
    assert data['python']['has_sslcontext'] == HAS_SSLCON

# Generated at 2022-06-25 00:28:11.784621
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:13.390804
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_2 = PythonFactCollector()
    var_0 = python_fact_collector_2.collect()

# Generated at 2022-06-25 00:28:45.751021
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:28:47.487077
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect() is not None

# Generated at 2022-06-25 00:28:48.415208
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    py_fc.collect()

# Generated at 2022-06-25 00:28:55.982029
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

    var_0 = var_1.get('python')
    var_0 = var_0.get('version')
    # EXPECT: (1, 2, 3, 4, 5)
    print(var_0)

    var_0 = var_1.get('python')
    var_0 = var_0.get('version_info')
    # EXPECT: [1, 2, 3, 4, 5]
    print(var_0)

    var_0 = var_1.get('python')
    var_0 = var_0.get('executable')
    # EXPECT: /usr/bin/python
    print(var_0)

test_case_0()
test

# Generated at 2022-06-25 00:29:01.676447
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert (python_facts['python']['version']['major'] == sys.version_info[0])
    assert (python_facts['python']['version']['minor'] == sys.version_info[1])
    assert (python_facts['python']['version']['micro'] == sys.version_info[2])
    assert (python_facts['python']['version']['releaselevel'] == sys.version_info[3])
    assert (python_facts['python']['version']['serial'] == sys.version_info[4])


# Generated at 2022-06-25 00:29:04.340296
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()
    var_1 = var_0.collect()
    var_1.pop('python')
    var_2 = len(var_1)
    var_3 = 0
    if (var_2 == var_3):
        var_4 = True
    else:
        var_4 = False
    assert var_4


# Generated at 2022-06-25 00:29:08.331930
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # each test method requires a single assert method to be called
    #
    # this test method tests that when the collect method is called the
    # _fact_ids instance attribute is properly set
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert python_fact_collector_1._fact_ids == set(['python'])

# Generated at 2022-06-25 00:29:13.947140
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Setup test data
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

    # Verify the results
    assert isinstance(var_0, dict) == True

    # Teardown test data
    del python_fact_collector_0

# Generated at 2022-06-25 00:29:21.810039
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import sys

    yml_data = '''
        python_collector:
          - supported_by: core
          - name: python
    '''

# Generated at 2022-06-25 00:29:28.470975
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert "python" in var_0
    assert "version" in var_0['python']
    assert "version_info" in var_0['python']
    assert "executable" in var_0['python']
    if python_fact_collector_0.get_version_info()[0] < 3 or python_fact_collector_0.get_version_info()[1] < 7:
        assert "type" in var_0['python']
    assert "has_sslcontext" in var_0['python']

# Generated at 2022-06-25 00:30:38.359506
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

# Generated at 2022-06-25 00:30:39.883343
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 is not None


# Generated at 2022-06-25 00:30:47.048136
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    PythonFactCollector.collect:
    """
    # Unit test for collect()
    print("Testing collect()")
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    # Python 2.6.9 does not have the SSLContext attribute.
    # This code does not execute on the CI machines
    #if not hasattr(var_0['python']['version'], 'micro'):
    #    raise ValueError("Python version info should contain a micro attribute")

# Generated at 2022-06-25 00:30:48.241957
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector_obj = PythonFactCollector()

    # Call the method
    result = collector_obj.collect()

    # Check the result
    assert result

# Generated at 2022-06-25 00:30:49.506015
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:30:58.637654
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert sys.version_info[0] == python_fact_collector_0.collect()["python"]["version"]["major"]
    assert sys.version_info[1] == python_fact_collector_0.collect()["python"]["version"]["minor"]
    assert sys.version_info[2] == python_fact_collector_0.collect()["python"]["version"]["micro"]
    assert sys.version_info[3] == python_fact_collector_0.collect()["python"]["version"]["releaselevel"]
    assert sys.version_info[4] == python_fact_collector_0.collect()["python"]["version"]["serial"]

# Generated at 2022-06-25 00:31:02.245166
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {"python": {"executable": "/usr/bin/python", "has_sslcontext": True, "type": None, "version": {"major": 2, "micro": 7, "minor": 10, "releaselevel": 'final', "serial": 0}, "version_info": [2, 7, 10, 'final', 0]}}

# Generated at 2022-06-25 00:31:07.161567
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    host_0 = getfixture('host_0')
    python_fact_collector_0 = PythonFactCollector(host_0)
    var_1 = python_fact_collector_0.collect()
    assert var_1 is None


# Generated at 2022-06-25 00:31:12.452037
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Verifying all required attributes are present
    assert hasattr(PythonFactCollector, 'name')
    assert hasattr(PythonFactCollector, '_fact_ids')

    # Verifying that they are properties
    assert isinstance(PythonFactCollector.name, property)
    assert isinstance(PythonFactCollector._fact_ids, property)

# Generated at 2022-06-25 00:31:15.858106
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        python_fact_collector_0 = PythonFactCollector()
        var_1 = python_fact_collector_0.collect()
    except NameError:
        python_fact_collector_0 = PythonFactCollector()
        var_1 = python_fact_collector_0.collect()
