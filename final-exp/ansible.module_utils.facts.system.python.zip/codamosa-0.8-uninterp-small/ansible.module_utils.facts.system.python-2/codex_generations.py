

# Generated at 2022-06-25 00:23:33.175238
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    fact_result = python_fact_collector_0.collect()
    assert fact_result['python']['version']['micro'] == 6
    assert fact_result['python']['version_info'] == [3, 6, 6, 'final', 0]
    assert fact_result['python']['has_sslcontext'] is True

# Generated at 2022-06-25 00:23:36.070442
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    module = object()
    collected_facts = object()
    result = python_fact_collector.collect(module=module, collected_facts=collected_facts)
    assert True


# Generated at 2022-06-25 00:23:42.455321
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    fc_dict = {'collected_facts': {}}
    result = py_fc.collect(collected_facts=fc_dict['collected_facts'])

    assert result is not None
    assert result.get('python') is not None
    assert result.get('python').get('executable') is not None
    assert result.get('python').get('has_sslcontext') is not None
    assert result.get('python').get('type') is not None
    assert result.get('python').get('version_info') is not None
    assert result.get('python').get('version') is not None

# Generated at 2022-06-25 00:23:44.764449
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    facts = python_fact_collector_1.collect()
    assert facts['python']['version']['major'] >= 3

# Generated at 2022-06-25 00:23:53.468562
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collectors.python import PythonFactCollector
    from ansible.module_utils.facts.fact import Fact
    from ansible.module_utils.facts.utils import get_file_lines

    python_fact_collector_0 = PythonFactCollector()

    facts_0 = Facts(None, None, None, None, None, python_fact_collector_0)

    # Asserts 'python' in facts_0.
    assert 'python' in facts_0

    # Asserts 'python' in facts_0['python']
    python_0 = facts_0['python']

    # Asserts 'version' in python_0
    assert 'version' in python_0

    # Asserts 'major' in python_0['

# Generated at 2022-06-25 00:23:58.751691
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    test_dict_0 = {
        'python': {
            'version': {
                'releaselevel': 'final',
                'major': 3,
                'micro': 5,
                'serial': 0,
                'minor': 2
            },
            'type': None,
            'has_sslcontext': False,
            'version_info': [3, 2, 5, 'final', 0],
            'executable': '/usr/bin/python'
        }
    }
    test_tuple_0 = python_fact_collector_0.collect()
    assert test_tuple_0 == test_dict_0

# Generated at 2022-06-25 00:24:06.385508
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0 is not None
    assert python_fact_collector_0.name == 'python'
    python_facts = python_fact_collector_0.collect(None, None)
    assert python_facts['python']['executable'] is not None
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-25 00:24:15.937759
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    py_fact_collected_facts_1 = {}
    py_fact_1 = python_fact_collector_1.collect(collected_facts=py_fact_collected_facts_1)
    assert py_fact_1 == {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'has_sslcontext': True, 'type': 'cpython', 'executable': sys.executable, 'version_info': list(sys.version_info)}}


# Generated at 2022-06-25 00:24:17.071119
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect();

# Generated at 2022-06-25 00:24:22.355583
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    rc = python_fact_collector_1.collect()
    assert rc.get('python') is not None
    assert rc['python'].get('version') is not None
    assert rc['python']['version'].get('major') is not None
    assert rc['python']['version'].get('minor') is not None
    assert rc['python']['version'].get('micro') is not None
    assert rc['python']['version'].get('releaselevel') is not None
    assert rc['python']['version'].get('serial') is not None
    assert rc['python'].get('version_info') is not None
    assert rc['python']['version_info'] is not None

# Generated at 2022-06-25 00:24:28.969603
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # test collect() return type
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:24:31.859302
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_0.has_fact(python_fact_collector_1.collect()) == 1

# Generated at 2022-06-25 00:24:37.418713
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_2 = PythonFactCollector()
    python_fact_collector_0.collect()
    python_fact_collector_1.collect()
    python_fact_collector_2.collect()


# Generated at 2022-06-25 00:24:41.124058
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    assert isinstance(python_fact_collector_0.collect(collected_facts=collected_facts), dict)


# Generated at 2022-06-25 00:24:43.714603
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    try:
        python_fact_collector_1.collect()
    except:
        assert False


# Generated at 2022-06-25 00:24:46.189883
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector_0 = PythonFactCollector()
    python_facts = fact_collector_0.collect()
    del fact_collector_0
    return


# Generated at 2022-06-25 00:24:52.493078
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts = python_fact_collector_1.collect()
    expected_python_facts = {
        'python': {
            'has_sslcontext': True,
            'executable': sys.executable,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'type': 'CPython',
            'version_info': list(sys.version_info)
        }
    }
    assert python_facts == expected_python_facts

# Generated at 2022-06-25 00:24:55.607174
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result == {'python': {'version': {'major': 3, 'minor': 6, 'micro': 5, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 6, 5, 'final', 0], 'executable': '/usr/bin/python3.6', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-25 00:24:57.212465
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:25:06.453375
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # mock python version
    sys.version_info = (1, 2, 3, 'alpha', 5)
    sys.executable = '/usr/bin/python'
    sys.implementation = None
    python_fact_collector_0 = PythonFactCollector()
    # mock
    python_fact_collector_0.module = None
    python_fact_collector_0.collect = PythonFactCollector.collect.__get__(
        python_fact_collector_0)
    python_fact_collector_0.get_module_utils_facts = (
        BaseFactCollector.get_module_utils_facts.__get__(
            python_fact_collector_0))

# Generated at 2022-06-25 00:25:23.362230
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts_0 = {}
    expected_facts_0 = {
        'python': {
            'executable': '/usr/bin/python',
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'major': 2,
                'micro': 1,
                'minor': 7,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 1, 'final', 0]
        }
    }
    python_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert expected_facts_0 == collected_facts_0


# Generated at 2022-06-25 00:25:31.034904
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result is not None
    assert 'python' in result
    assert 'version' in result['python']
    assert 'major' in result['python']['version']
    assert 'minor' in result['python']['version']
    assert 'micro' in result['python']['version']
    assert 'releaselevel' in result['python']['version']
    assert 'serial' in result['python']['version']
    assert 'version_info' in result['python']
    assert 'type' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-25 00:25:34.270791
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_0.collect()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:25:38.535472
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    python_facts = python_fact_collector_1.collect()

    assert 'python' in python_facts
    assert python_facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-25 00:25:39.937019
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:47.243220
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_dict = python_fact_collector_0.collect()
    assert python_facts_dict == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 13, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 13, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': None}}

# Generated at 2022-06-25 00:25:49.072222
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:25:50.225870
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_class_0 = PythonFactCollector()
    fact_class_0.collect()

# Generated at 2022-06-25 00:25:53.451343
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()
    # Check if exception was raised
    assert (python_facts_0['python']['version']['major'] == sys.version_info[0])

# Generated at 2022-06-25 00:25:56.290170
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert 'python' in python_facts

# Generated at 2022-06-25 00:26:13.716152
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts



# Generated at 2022-06-25 00:26:18.703251
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector(module={}, collected_facts=python_fact_collector_0)
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:26:25.232995
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector_0 = PythonFactCollector()
    python_facts = fact_collector_0.collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)
    assert isinstance(python_facts['python']['version_info'], list)
   

# Generated at 2022-06-25 00:26:29.288310
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result_0 = python_fact_collector_0.collect()

    try:
        assert result_0['python']['type'] == 'CPython'
    except AssertionError:
        try:
            assert result_0['python']['type'] == 'PyPy'
        except AssertionError:
            assert result_0['python']['type'] == 'Jython'

# Generated at 2022-06-25 00:26:30.295610
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()



# Generated at 2022-06-25 00:26:33.548990
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    output = python_fact_collector_0.collect(collected_facts=collected_facts)

    assert type(output) is dict

# Generated at 2022-06-25 00:26:37.327940
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # collect should return a valid fact
    python_fact_collector_1 = PythonFactCollector()
    facts_dict = {}
    facts_dict['ansible_facts'] = python_fact_collector_1.collect()
    assert 'python' in facts_dict['ansible_facts']

# Generated at 2022-06-25 00:26:41.619489
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert 'python' in result.keys()


# Generated at 2022-06-25 00:26:50.103543
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    # test the facts are present
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'executable' in python_facts['python']

    assert python_facts['python']['type'] == 'CPython'
    assert python_facts['python']['executable']
    assert python_facts['python']['version_info']
    assert python_facts['python']['version']
    assert python

# Generated at 2022-06-25 00:26:57.556518
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # Test with no python facts collected
    python_fact_collector_0_collected_facts = {}
    o = python_fact_collector_0.collect(collected_facts=python_fact_collector_0_collected_facts)
    assert len(o) == 1
    assert 'python' in o
    assert o['python']['executable'] == sys.executable
    if HAS_SSLCONTEXT:
        assert o['python']['has_sslcontext'] == True
    else:
        assert o['python']['has_sslcontext'] == False
    assert o['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:27:34.130137
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instantiate the PythonFactCollector object
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()
    data = python_fact_collector_0.collect()
    assert data['python']['version']['major'] >= 2
    assert data['python']['version']['has_sslcontext'] == HAS_SSLCONTEXT
    assert data['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-25 00:27:36.037319
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


if __name__ == '__main__':
    # Unit tests
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:27:37.679320
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result is not None, "Method collect of PythonFactCollector returned None"


# Generated at 2022-06-25 00:27:46.832975
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, BaseFactCollector)
    assert python_fact_collector.collect()
    assert python_fact_collector.name in python_fact_collector.collect()
    assert isinstance(python_fact_collector.collect(), dict)
    assert isinstance(python_fact_collector.collect()['python']['version_info'], list)
    assert python_fact_collector.collect()['python']['version_info'][0] == sys.version_info[0]
    assert python_fact_collector.collect()['python']['version_info'][1] == sys.version_info[1]
   

# Generated at 2022-06-25 00:27:50.063887
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    tc_0 = PythonFactCollector()
    result = tc_0.collect()

if __name__ == '__main__':
    # Unit test for case_0
    test_case_0()
    # Unit test for method collect of class PythonFactCollector
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:27:56.481764
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = {'python': {'executable': '/usr/bin/python', 'type': 'CPython', 'version': {'releaselevel': 'final', 'micro': 3, 'major': 2, 'minor': 7, 'serial': 0}, 'has_sslcontext': True, 'version_info': [2, 7, 3, 'final', 0]}}
    result = python_fact_collector.collect()
    assert isinstance(result, dict)
    assert result == python_facts



# Generated at 2022-06-25 00:28:01.431756
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print("Testing: collect")
    python_fact_collector = PythonFactCollector()
    module = None
    collected_facts = {}
    python_fact_collector.collect(module, collected_facts)
    assert collected_facts['python'] == {'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython', 'version': {'major': 2, 'micro': 7, 'minor': 6, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 6, 'final', 0]}

# Generated at 2022-06-25 00:28:04.068016
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    return len(python_facts.keys()) == 1 and python_facts['python']


# Generated at 2022-06-25 00:28:06.108036
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    results = python_fact_collector_0.collect()
    assert results['python']['version']['major'] == 3


# Generated at 2022-06-25 00:28:08.247669
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert type(python_fact_collector_0.collect()) is dict

# Generated at 2022-06-25 00:29:18.586833
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''
    ansible_collector_0 = PythonFactCollector()

    assert ansible_collector_0.collect() is not None


# Generated at 2022-06-25 00:29:26.212839
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    python_fact_collector_0.collect(collected_facts=collected_facts)
    assert collected_facts['python'] == {'executable': '/usr/bin/python', 'version': {'serial': 0, 'releaselevel': 'final', 'major': 2, 'minor': 7, 'micro': 6}, 'has_sslcontext': True, 'version_info': [2, 7, 6, 'final', 0]}
    assert collected_facts['python']['version']['serial'] == 0
    assert collected_facts['python']['version']['releaselevel'] == 'final'
    assert collected_facts['python']['version']['major'] == 2

# Generated at 2022-06-25 00:29:32.302816
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == {'python': {'executable': '/usr/bin/python', 'has_sslcontext': True, 'version': {'micro': 5, 'major': 2, 'releaselevel': 'final', 'minor': 7, 'serial': 0}, 'version_info': [2, 7, 5, 'final', 0]}}


# Generated at 2022-06-25 00:29:36.442975
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == {'python': {'version': {'major': 3, 'minor': 5, 'micro': 2, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 5, 2, 'final', 0], 'executable': '/usr/bin/python3', 'type': 'CPython', 'has_sslcontext': True}}

# Generated at 2022-06-25 00:29:37.513106
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:29:40.281547
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_instance = PythonFactCollector()

    # Tests the collect method
    def test_collect_exception_handling_0(self):
        # The test makes sure that the collect method returns a dict type
        assert(isinstance(test_instance.collect(), dict))

# Generated at 2022-06-25 00:29:45.927283
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_2 = PythonFactCollector()
    python_fact_collector_0.collect()
    python_fact_collector_1.collect()
    python_fact_collector_2.collect()


# Generated at 2022-06-25 00:29:49.267470
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts = python_fact_collector_0.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-25 00:29:54.088581
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector = PythonFactCollector()

    python_facts = python_fact_collector.collect()
    python_facts_expected = {
        u'python': {u'type': u'CPython',
                    u'version': {u'major': 2, u'minor': 7, u'micro': 11,
                                 u'releaselevel': u'final', u'serial': 0},
                    u'has_sslcontext': False,
                    u'version_info': [2, 7, 11, u'final', 0]},
                    u'executable': 'python'
    }
    assert python_facts == python_facts_expected

# Generated at 2022-06-25 00:30:03.774485
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-25 00:32:30.635534
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert(result['python']['version_info'][0] == sys.version_info[0])
    assert(result['python']['version_info'][1] == sys.version_info[1])
    assert(result['python']['version_info'][2] == sys.version_info[2])
    assert(result['python']['version_info'][3] == sys.version_info[3])
    assert(result['python']['version_info'][4] == sys.version_info[4])
    assert(result['python']['executable'] == sys.executable)
    assert(result['python']['has_sslcontext'] == HAS_SSLCONTEXT)


# Generated at 2022-06-25 00:32:32.243214
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0_copy = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:32:38.396017
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts is not None
    for k, v in python_facts.items():
        assert k == 'python'
        assert v is not None
        for k, v in v.items():
            assert k == 'version' or k == 'version_info' or k == 'executable' or k == 'has_sslcontext' or k == 'type'
            if k == 'version':
                assert v is not None
                for k, v in v.items():
                    assert k == 'major' or k == 'minor' or k == 'micro' or k == 'releaselevel' or k == 'serial'
            elif k == 'version_info':
                assert v is not None

# Generated at 2022-06-25 00:32:45.109841
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import mock
    import sys
    sys.version_info = mock.Mock()
    sys.version_info.__getitem__.return_value = 0
    sys.version_info.__len__.return_value = (2, 3, 4, "final", 1)
    sys.executable = "path/python"
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result['python']['version_info'] == [0, 2, 3, 4, 1]
    assert result['python']['version']['major'] == 0
    assert result['python']['version']['minor'] == 2
    assert result['python']['version']['micro'] == 3

# Generated at 2022-06-25 00:32:46.504125
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:32:51.981504
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Tests that the Python fact collector successfully collects facts
    python_fact_collector_collect = PythonFactCollector()
    facts = python_fact_collector_collect.collect()
    assert 'python' in facts
    python_facts = facts['python']
    assert 0 in python_facts['version']['major']
    assert 1 in python_facts['version']['minor']


if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:32:54.756678
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:32:59.444270
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:33:01.653053
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    try:
        python_fact_collector_0.collect()
    except:
        pass

    assert python_fact_collector_0.name == 'python'

# Generated at 2022-06-25 00:33:06.713938
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert result is not None, "Failed to collect Python facts"
    assert 'python' in result, "The dictionary returned by PythonFactCollector.collect() does not contain the key 'python'"

