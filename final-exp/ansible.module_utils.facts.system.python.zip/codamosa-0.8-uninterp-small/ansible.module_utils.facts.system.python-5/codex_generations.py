

# Generated at 2022-06-25 00:23:38.813447
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result is not None
    assert result == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 12, 'releaselevel': 'final', 'serial': 0},
                                 'version_info': [2, 7, 12, 'final', 0],
                                 'executable': '/usr/bin/python',
                                 'has_sslcontext': True}}



# Generated at 2022-06-25 00:23:47.026016
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert(python_facts['python']['version']['major'] == sys.version_info[0])
    assert(python_facts['python']['version_info'] == list(sys.version_info))
    assert(python_facts['python']['executable'] == sys.executable)
    assert(python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT)
    try:
        python_facts['python']['type'] == sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] == sys.implementation.name
        except AttributeError:
            python_facts['python']['type']

# Generated at 2022-06-25 00:23:49.646335
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    try:
        python_fact_collector_0.collect()
    except:
        pass
    else:
        assert False, "Exception not raised"

# Generated at 2022-06-25 00:23:56.732927
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    returned_python_facts = python_fact_collector_0.collect(collected_facts=collected_facts)
    assert 'python' in returned_python_facts
    assert 'version' in returned_python_facts['python']
    assert 'version_info' in returned_python_facts['python']
    assert 'executable' in returned_python_facts['python']
    assert 'has_sslcontext' in returned_python_facts['python']
    assert isinstance(returned_python_facts['python']['version'], dict)
    assert isinstance(returned_python_facts['python']['version_info'], list)
    assert isinstance(returned_python_facts['python']['executable'], str)


# Generated at 2022-06-25 00:23:59.699042
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() is not None

# Generated at 2022-06-25 00:24:02.196182
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts_dict_0 = dict()
    python_fact_collector_0.collect(collected_facts=facts_dict_0)

# Generated at 2022-06-25 00:24:04.170957
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # Calling collect() method of class
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:08.110116
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # Test with no parameter
    python_facts = python_fact_collector_0.collect()
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']

# Generated at 2022-06-25 00:24:10.912185
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert 'python_facts' not in globals()  # make sure python_facts not defined in global scope
    python_facts = python_fact_collector_0.collect()
    assert isinstance(python_facts, dict)

# Generated at 2022-06-25 00:24:13.291050
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    dict_result_1 = python_fact_collector_1.collect()
    # test for response code and status
    assert (
        dict_result_1 is not None
    )


# Generated at 2022-06-25 00:24:26.281332
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    actual_result_python_dict = python_facts['python']
    actual_result_python_version_dict = actual_result_python_dict['version']
    actual_result_python_version_info_list = actual_result_python_dict['version_info']

    # Test the major version number is correct
    expected_major_version_number = sys.version_info[0]
    actual_major_version_number = actual_result_python_dict['version']['major']
    assert (expected_major_version_number == actual_major_version_number)

    # Test the minor version number is correct
    expected_minor_version_number = sys.version_info[1]
    actual_minor

# Generated at 2022-06-25 00:24:34.575411
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector_inst = PythonFactCollector()
    collected_facts = fact_collector_inst.collect()

    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]

    # Python version_info is a tuple, to make a proper comparison we need to convert it to a list
    assert collected_facts['python']['version_info']

# Generated at 2022-06-25 00:24:37.223086
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

test_case_0()
test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:24:47.243568
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    python_facts = python_fact_collector.collect(sys.modules[__name__], collected_facts)
    python_fact_collector.get_facts(sys.modules[__name__], collected_facts)
    assert(python_facts.get('python').get('version').get('major') == sys.version_info[0])
    assert(python_facts.get('python').get('version').get('minor') == sys.version_info[1])
    assert(python_facts.get('python').get('version').get('micro') == sys.version_info[2])
    assert(python_facts.get('python').get('version').get('releaselevel') == sys.version_info[3])

# Generated at 2022-06-25 00:24:55.696804
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test of method collect for class PythonFactCollector
    """
    python_fact_collector = PythonFactCollector()
    results = python_fact_collector.collect()
    assert results
    assert isinstance(results, dict)
    assert 'python' in results
    assert isinstance(results['python'], dict)
    assert 'version_info' in results['python']
    assert results['python']['type']
    assert 'has_sslcontext' in results['python']
    assert results['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-25 00:25:00.552714
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test using a mock AnsibleModule
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()
    # Test using a mock AnsibleModule and collected facts
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect(collected_facts={})


# Generated at 2022-06-25 00:25:08.938445
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collection_1 = python_fact_collector_1.collect()
    assert isinstance(python_fact_collection_1, dict)
    assert len(python_fact_collection_1) == 1
    assert 'python' in python_fact_collection_1
    python_facts = python_fact_collection_1['python']
    assert isinstance(python_facts, dict)
    assert 'version' in python_facts
    assert isinstance(python_facts['version'], dict)
    assert 'major' in python_facts['version']
    assert isinstance(python_facts['version']['major'], int)
    assert 'minor' in python_facts['version']

# Generated at 2022-06-25 00:25:11.348868
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
        python_fact_collector_0 = PythonFactCollector()
        result = python_fact_collector_0.collect()
        assert len(result) == 1

# =====


# Generated at 2022-06-25 00:25:21.629965
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts_returned = python_fact_collector_1.collect()
    assert python_facts_returned['python']['type'] == 'cpython'
    assert python_facts_returned['python']['version']['major'] == sys.version_info[0]
    assert python_facts_returned['python']['version']['minor'] == sys.version_info[1]
    assert python_facts_returned['python']['version']['micro'] == sys.version_info[2]
    assert python_facts_returned['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts_returned['python']['version']['serial'] == sys.version_

# Generated at 2022-06-25 00:25:29.204519
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    fact_list = []
    facts = {}
    fact = python_fact_collector_1.collect(module=None, collected_facts=facts)

    result = dict(ansible_python={'executable': '/usr/bin/python',
                                  'has_sslcontext': True,
                                  'type': 'CPython',
                                  'version': {'major': 2,
                                              'micro': 7,
                                              'minor': 14,
                                              'releaselevel': 'final',
                                              'serial': 0},
                                  'version_info': [2, 7, 14, 'final', 0]})

    assert fact == result


# Generated at 2022-06-25 00:25:34.453277
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:25:43.485844
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1_inst = PythonFactCollector()
    python_fact_collector_1_result = python_fact_collector_1_inst.collect()
    assert python_fact_collector_1_result == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }


# Generated at 2022-06-25 00:25:47.411756
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
#    python_fact_collector_0 = PythonFactCollector()
#    output = python_fact_collector_0.collect()
#    python_fact_collector_0.collect()

    pass

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:25:52.048967
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts = python_fact_collector_0.collect()
    assert facts == {'python': {'executable': '/usr/bin/python',
                                'has_sslcontext': True,
                                'version': {'major': 2,
                                            'minor': 7,
                                            'micro': 5,
                                            'releaselevel': 'final',
                                            'serial': 0},
                                'version_info': [2, 7, 5, 'final', 0],
                                'type': 'CPython'}}

# Generated at 2022-06-25 00:25:57.640132
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 15, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 15, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-25 00:26:02.993498
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect(): 
    # Positive test case
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect is not None


# Generated at 2022-06-25 00:26:05.956552
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-25 00:26:08.600240
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    python_fact_collector_collected_facts = python_fact_collector.collect(None, collected_facts)
    assert isinstance(python_fact_collector_collected_facts, dict)

# Generated at 2022-06-25 00:26:11.019042
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:26:19.472757
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    def test(c):
        res = c.collect()
        assert(res.get('python') is not None)
        assert(res.get('python').get('type') is not None)
        assert(res.get('python').get('executable') is not None)
        assert(res.get('python').get('version') is not None)
        assert(res.get('python').get('version_info') is not None)
        assert(res.get('python').get('has_sslcontext') is not None)

    test(PythonFactCollector())


# Generated at 2022-06-25 00:26:28.754419
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test function collect of class PythonFactCollector
    # See if the version information is collected
    # Note: the following only works with python 2.7+
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1['python']['version']['major'] == sys.version_info[0]
    assert var_1['python']['version']['minor'] == sys.version_info[1]
    assert var_1['python']['version']['micro'] == sys.version_info[2]
    assert var_1['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-25 00:26:30.587477
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:38.674422
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    var = python_fact_collector.collect()
    assert type(var) is dict
    assert 'python' in var
    assert type(var['python']) is dict
    assert 'version' in var['python']
    assert type(var['python']['version']) is dict
    assert 'major' in var['python']['version']
    assert type(var['python']['version']['major']) is int
    assert 'minor' in var['python']['version']
    assert type(var['python']['version']['minor']) is int
    assert 'micro' in var['python']['version']
    assert type(var['python']['version']['micro']) is int

# Generated at 2022-06-25 00:26:45.191721
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    python_facts_0 = python_fact_collector.collect()
    # Assert the version_info attribute value
    assert python_facts_0['python']['version_info'] == list(sys.version_info)
    # Assert the has_sslcontext attribute value
    assert python_facts_0['python']['has_sslcontext'] == HAS_SSLCONTEXT
    # Assert the major attribute value
    assert python_facts_0['python']['version']['major'] == sys.version_info[0]
    # Assert the releaselevel attribute value
    assert python_facts_0['python']['version']['releaselevel'] == sys.version_info[3]
    # Assert the executable attribute value

# Generated at 2022-06-25 00:26:47.266518
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Define method input parameters
    # Define expected return value
    var_0 = None
    var_0 = PythonFactCollector()
    var_1 = var_0.collect()


# Generated at 2022-06-25 00:26:55.508059
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    sys.version_info = (2, 7, 13, 'final', 0)
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'version': {'major': 2, 'minor': 7, 'releaselevel': 'final', 'serial': 0, 'micro': 13}, 'version_info': [2, 7, 13, 'final', 0], 'has_sslcontext': True, 'executable': '/usr/bin/python', 'type': 'CPython'}}


# Generated at 2022-06-25 00:26:59.642197
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'executable': '/usr/bin/python', 'type': 'CPython', 'version': {'micro': 0, 'releaselevel': 'final', 'serial': 0, 'minor': 7, 'major': 2}, 'has_sslcontext': True, 'version_info': [2, 7, 0, 'final', 0]}}


# Generated at 2022-06-25 00:27:00.336306
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:27:09.771967
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    input0 = {
        'python': {
            'type': None,
            'version': {
                'releaselevel': 'alpha',
                'serial': 0,
                'micro': 0,
                'major': 2,
                'minor': 7
            },
            'has_sslcontext': False,
            'version_info': [
                2,
                7,
                0,
                'alpha',
                0
            ],
            'executable': '/usr/bin/python'
        }
    }
    def test_case_assertion_0(pf_collect_0):
        assert (pf_collect_0 == (input0))

    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    test_case_assertion

# Generated at 2022-06-25 00:27:16.766097
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert "python" in var_0
    assert "version_info" in var_0["python"]
    assert "micro" in var_0["python"]["version"]
    assert "releaselevel" in var_0["python"]["version"]
    assert "minor" in var_0["python"]["version"]
    assert "major" in var_0["python"]["version"]
    assert "serial" in var_0["python"]["version"]
    assert "has_sslcontext" in var_0["python"]
    assert "executable" in var_0["python"]
    assert "version" in var_0["python"]

# Generated at 2022-06-25 00:27:27.630727
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:36.087105
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_sys_version_info_0 = ('CPython', 'CPython', 'CPython', 'CPython', 'CPython', 'CPython')

    # Test with a mock sys.version_info and create_default_context
    python_fact_collector_sys_version_info = [0,0,0,0,0]
    python_fact_collector_create_default_context = lambda x: x
    python_fact_collector_sys_version_info_0 = ('CPython', 'CPython', 'CPython', 'CPython', 'CPython', 'CPython')

# Generated at 2022-06-25 00:27:43.611579
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        # Normal test, we expect no exceptions here
        python_fact_collector_0 = PythonFactCollector()
        var_0 = python_fact_collector_0.collect()

        # Verify that the output from the collect method is the expected type
        assert isinstance(var_0, dict) is True
    except:
        # More advanced test, we expect some exceptions here.
        # We will raise the exception (if any) in the unit test so that it will be caught and reported
        python_fact_collector_0 = PythonFactCollector()
        var_0 = python_fact_collector_0.collect()
        raise

# Generated at 2022-06-25 00:27:45.706895
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert 'python' in var_0
    assert 'version' in var_0['python']


# Generated at 2022-06-25 00:27:49.776659
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()


if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:27:55.595020
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    assert 'python' in python_facts
    python = python_facts['python']

    assert 'version' in python
    assert 'version_info' in python
    assert 'executable' in python
    assert 'has_sslcontext' in python
    assert python['has_sslcontext'] is True


# Generated at 2022-06-25 00:27:58.956657
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['type'] == 'CPython'


# Generated at 2022-06-25 00:28:01.870355
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()

    assert True

# Generated at 2022-06-25 00:28:04.136189
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    if python_fact_collector_0.collect() is not None:
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:28:06.166937
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    assert type(var_0) is dict


# Generated at 2022-06-25 00:28:23.481633
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:25.409577
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        test_case_0()
    finally:
        try:
            python_fact_collector_0.clean_module_args()
        except NameError:
            pass

# Generated at 2022-06-25 00:28:26.197745
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 00:28:27.913457
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:29.764571
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    some_instance = PythonFactCollector()
    some_instance.collect()



# Generated at 2022-06-25 00:28:34.655815
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert type(var_1) == dict
    assert var_1 == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 15, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 15, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': 'CPython'}}

# Generated at 2022-06-25 00:28:37.149531
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Unit test for collect without arguments
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    # Unit test for collect with arguments
    # Not yet implemented

# Generated at 2022-06-25 00:28:41.147616
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'version': {'micro': 2, 'releaselevel': 'final', 'major': 2, 'minor': 7, 'serial': 0}, 'executable': '/usr/bin/python', 'version_info': [2, 7, 2, 'final', 0], 'has_sslcontext': True}}

# Generated at 2022-06-25 00:28:42.874400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect().keys() == set(['python'])


# Generated at 2022-06-25 00:28:47.756420
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    # Test with arguments specified
    var_1 = python_fact_collector_1.collect()
    assert var_1 == {'python': {'version': {'serial': 0, 'minor': 6, 'releaselevel': 'final', 'micro': 5, 'major': 2}, 'has_sslcontext': False, 'type': 'CPython', 'version_info': [2, 6, 5, 'final', 0], 'executable': '/usr/bin/python'}}

# Generated at 2022-06-25 00:29:25.405803
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:29:29.054246
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instance to test
    python_fact_collector_0 = PythonFactCollector()

    # Variables to test
    var_0 = python_fact_collector_0.collect()
    try:
        python_fact_collector_0.name
    except AttributeError:
        pass


# Generated at 2022-06-25 00:29:30.484468
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()


# Generated at 2022-06-25 00:29:36.816003
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test collect() using a mock.patch."""
    def mock__fact_ids():
        return {'python'}
    def mock_get_facts(self, module=None, collected_facts=None):
        return {'python': {'version': {'major': 3, 'minor': 4, 'micro': 2, 'releaselevel': 'final', 'serial': 0},
                           'version_info': [3, 4, 2, 'final', 0],
                           'executable': '/usr/bin/python3',
                           'has_sslcontext': True,
                           'type': 'CPython'}}

# Generated at 2022-06-25 00:29:40.802252
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    if not var_0:
        var_0 = {}

    var_1 = {  }
    if var_0:
        var_1['python'] = var_0

    return var_1

if __name__ == "__main__":
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:29:43.780982
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test collect
    """
    # Create an instance of PythonFactCollector
    python_fact_collector = PythonFactCollector()
    # Invoke method
    return_value = python_fact_collector.collect()
    assert return_value is None

# Generated at 2022-06-25 00:29:45.656460
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 is not None
    assert type(var_0) is dict

# Generated at 2022-06-25 00:29:52.235953
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 == {'python': {'version_info': [2, 7, 12, 'final', 0], 'has_sslcontext': False, 'version': {'serial': 0, 'minor': 7, 'releaselevel': 'final', 'micro': 12, 'major': 2}, 'type': 'CPython', 'executable': '/usr/bin/python'}}


# Generated at 2022-06-25 00:29:57.081130
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert type(var_0) == dict
    assert var_0['python']['has_sslcontext'] == True
    assert len(var_0) == 1

# Generated at 2022-06-25 00:30:04.121686
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Setup test environment
    python_fact_collector_0 = PythonFactCollector()

    # TODO: Finish tests
    # Test case for method collect of class PythonFactCollector
    # Test if collected facts are of a dictionary type.
    # Test if the python version is properly collected.
    # Test if the python version info is properly collected.
    # Test if the executable is properly collected.
    # Test if the type is properly collected.
    pass

# Generated at 2022-06-25 00:31:20.607948
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['executable'] == '/usr/bin/python', "Collect failed for PythonFactCollector.collect"
    assert var_0['python']['version']['major'] == 2, "Collect failed for PythonFactCollector.collect"
    assert var_0['python']['version']['micro'] == 7, "Collect failed for PythonFactCollector.collect"
    assert var_0['python']['version']['releaselevel'] == 'final', "Collect failed for PythonFactCollector.collect"
    assert var_0['python']['version']['serial'] == 0, "Collect failed for PythonFactCollector.collect"

# Generated at 2022-06-25 00:31:27.521421
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    assert var_0.has_key('python')

    var_0['python'].has_key('version')
    var_0['python']['version'].has_key('major')
    var_0['python']['version'].has_key('minor')
    var_0['python']['version'].has_key('micro')
    var_0['python']['version'].has_key('releaselevel')
    var_0['python']['version'].has_key('serial')

    var_0['python'].has_key('version_info')
    var_0['python'].has_key('executable')

# Generated at 2022-06-25 00:31:35.884535
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # test_case_0()
    python_fact_collector_0 = PythonFactCollector()
    collected_facts_0 = dict()
    python_facts_0 = python_fact_collector_0.collect(collected_facts_0)
    assert 'python' in python_facts_0
    assert 'version' in python_facts_0['python']
    assert 'micro' in python_facts_0['python']['version']
    assert 'major' in python_facts_0['python']['version']
    assert 'minor' in python_facts_0['python']['version']
    assert 'serial' in python_facts_0['python']['version']
    assert 'version_info' in python_facts_0['python']

# Generated at 2022-06-25 00:31:44.711442
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect(module='ansible.module_utils.facts.system.python')
    assert var_1['python']['version']['major'] == 3
    assert var_1['python']['version']['minor'] == 6
    assert var_1['python']['version']['micro'] == 0
    assert var_1['python']['version']['releaselevel'] == 'final'
    assert var_1['python']['version']['serial'] == 0
    assert var_1['python']['version_info'] == [3, 6, 0, 'final', 0]
    assert var_1['python']['executable'] == '/usr/bin/python3'
   

# Generated at 2022-06-25 00:31:46.630253
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:50.589430
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:55.115423
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_1 = None
    try:
        import sys
        import sys
    except ImportError:
        pass
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

    assert var_1['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert var_1['python']['version']['major'] == sys.version_info[0]
    assert var_1['python']['version']['minor'] == sys.version_info[1]
    assert var_1['python']['version']['micro'] == sys.version_info[2]
    assert var_1['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-25 00:31:56.766669
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_0


# Generated at 2022-06-25 00:32:02.046682
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    # Verify the values of variables that are used in the test case
    assert var_0['python']['version']['major'] == 3



# Generated at 2022-06-25 00:32:04.154504
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() is not None, \
        'Ansible facts could not be collected.'
