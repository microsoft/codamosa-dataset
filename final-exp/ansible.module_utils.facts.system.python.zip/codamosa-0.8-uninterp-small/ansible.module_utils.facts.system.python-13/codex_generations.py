

# Generated at 2022-06-25 00:23:32.541414
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    # Ensure no exception is raised


# Generated at 2022-06-25 00:23:40.788549
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    test_collect = python_fact_collector_0.collect(collected_facts=python_fact_collector_1.collect())
    # AssertionError: {} != {'_hostname': 'ansiballz-42200-testhost.local', 'python': {'version': {'major': 3, 'minor': 6, 'micro': 4, 'releaselevel': 'final', 'serial': 0}, 'executable': '/usr/local/bin/python3.6', 'version_info': [3, 6, 4, 'final', 0], 'type': None}}
    # assert test_collect == {'python': {'version': {'major': 3, 'minor': 6, 'micro':

# Generated at 2022-06-25 00:23:49.413548
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of PythonFactCollector
    python_fact_collector = PythonFactCollector()

    # unit test for method collect of class PythonFactCollector
    python_facts_dict = python_fact_collector.collect()
    assert python_facts_dict['python']['version']['major'] == sys.version_info[0]
    assert python_facts_dict['python']['version']['minor'] == sys.version_info[1]
    assert python_facts_dict['python']['version']['micro'] == sys.version_info[2]
    assert python_facts_dict['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts_dict['python']['version']['serial'] == sys.version_info[4]
   

# Generated at 2022-06-25 00:23:56.322137
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    a = PythonFactCollector()
    a.enabled_by_default = False

    expected_dict_0 = {
      'python': {
        'version': {
          'major': sys.version_info[0],
          'minor': sys.version_info[1],
          'micro': sys.version_info[2],
          'releaselevel': sys.version_info[3],
          'serial': sys.version_info[4],
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': None
      }
    }

    d = a.collect()
    assert d == expected_dict_0



# Generated at 2022-06-25 00:23:59.608508
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    assert isinstance(python_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:24:00.519942
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect()


# Generated at 2022-06-25 00:24:01.983514
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:24:04.816859
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Arrange
    python_fact_collector_0 = PythonFactCollector()

    # Act
    result_dict = python_fact_collector_0.collect()

    # Assert
    assert result_dict["python"]["has_sslcontext"] is not None

# Generated at 2022-06-25 00:24:14.970500
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    collected_facts['ansible_python'] = {
        'has_sslcontext': HAS_SSLCONTEXT,
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'version': {
            'releaselevel': sys.version_info[3],
            'major': sys.version_info[0],
            'micro': sys.version_info[2],
            'minor': sys.version_info[1],
            'serial': sys.version_info[4]
        }
    }

# Generated at 2022-06-25 00:24:16.308357
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()


# Generated at 2022-06-25 00:24:27.373259
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Setup
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    module = None
    collector_expected_result = {}
    collector_expected_result['ansible_facts'] = {}
    collector_expected_result['ansible_facts']['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-25 00:24:35.122883
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Call method collect of PythonFactCollector instance
    python_facts_dict_1 = python_fact_collector_0.collect()

    assert(python_facts_dict_1 is not None)
    # print(python_facts_dict_1)
    assert(isinstance(python_facts_dict_1, dict))
    assert(python_facts_dict_1['python']['version']['major'] >= 3)
    assert(python_facts_dict_1['python']['version_info'] is not None)
    assert(python_facts_dict_1['python']['executable'] is not None)


if __name__ == '__main__':
    # Get args
    import sys
    import traceback
    import trace
    import p

# Generated at 2022-06-25 00:24:36.389256
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # test collect
    assert python_fact_collector_0.collect() is not None

# Generated at 2022-06-25 00:24:39.182509
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    :return:
    """

    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:41.083069
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:44.045117
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_ = PythonFactCollector()
    module = AnsibleModule
    collected_facts = {}
    python_fact_collector_.collect(module, collected_facts)

test_case_0()

# Generated at 2022-06-25 00:24:50.793697
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    output = python_fact_collector_1.collect()
    assert output == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 12, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 12, 'final', 0], 'executable': u'/usr/bin/python', 'type': 'CPython', 'has_sslcontext': True}}, "Failed to collect facts about Python."

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()
    print("Successfully passed all the tests!")

# Generated at 2022-06-25 00:24:52.743348
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:24:57.955107
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] > 5
    assert result['python']['type'] == 'CPython'
    assert result['python']['has_sslcontext'] is True

# Generated at 2022-06-25 00:25:02.016065
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert type(result) == dict


if __name__ == '__main__':

    testcases = [test_case_0]
    for tc in testcases:
        tc()

# Generated at 2022-06-25 00:25:20.254867
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts = python_fact_collector_1.collect(None, None)

    assert 'python' in python_facts
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:25:25.843659
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']['version']['major'] == 3
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-25 00:25:27.962330
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:25:35.226299
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_0 = python_fact_collector_0.collect()
    assert python_fact_0
    assert python_fact_0['python']['version_info']
    assert python_fact_0['python']['version']
    assert python_fact_0['python']['executable']
    assert python_fact_0['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-25 00:25:38.396284
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # Test normal return
    python_fact_handler_0_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:46.255066
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result == {'python': {'version_info': [3, 7, 4, 'final', 0], 'version': {'minor': 7, 'serial': 0, 'releaselevel': 'final', 'major': 3, 'micro': 4}, 'has_sslcontext': True, 'executable': '/home/atmichalak/Documentos/GitHub/python-sf/venv/bin/python3.7'}}

# Generated at 2022-06-25 00:25:54.320036
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect()['python']['executable'] == sys.executable
    assert PythonFactCollector().collect()['python']['version']['major'] == sys.version_info[0]
    assert PythonFactCollector().collect()['python']['version']['minor'] == sys.version_info[1]
    assert PythonFactCollector().collect()['python']['version']['micro'] == sys.version_info[2]
    assert PythonFactCollector().collect()['python']['version']['releaselevel'] == sys.version_info[3]
    assert PythonFactCollector().collect()['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-25 00:26:02.101730
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print("Testing PythonFactCollector class - collect")
    c = PythonFactCollector()
    fc = c.collect()
    assert fc['ansible_python']['executable'] == sys.executable, 'Got %s expected %s' % (
        fc['ansible_python']['executable'], sys.executable)
    assert fc['ansible_python']['version']['major'] == sys.version_info[0], 'Got %s expected %s' % (
        fc['ansible_python']['version']['major'], sys.version_info[0])

# Generated at 2022-06-25 00:26:07.870971
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test of PythonFactCollector.collect
    """
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'has_sslcontext': HAS_SSLCONTEXT, 'executable': sys.executable, 'version': {'serial': sys.version_info[4], 'releaselevel': sys.version_info[3], 'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2]}, 'type': sys.implementation.name, 'version_info': [sys.version_info[0], sys.version_info[1], sys.version_info[2], sys.version_info[3], sys.version_info[4]]}}


# Generated at 2022-06-25 00:26:13.249344
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = dict()
    returned_facts = python_fact_collector_0.collect(collected_facts=collected_facts)
    assert returned_facts == {'python': {'has_sslcontext': True, 'version': {'major': 2, 'minor': 7, 'micro': 11, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 11, 'final', 0], 'executable': sys.executable, 'type': 'cpython'}}

# Generated at 2022-06-25 00:26:32.762996
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test PythonFactCollector.collect method
    """
    from ansible.module_utils.facts.collector import PythonFactCollector

    python_fact_collector_test_0 = PythonFactCollector()

    python_fact_collector_test_0.collect()


# Generated at 2022-06-25 00:26:39.634377
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    actualResult = python_fact_collector.collect()

    if actualResult['python']['version']['major'] != sys.version_info[0]:
        print(
            'Testcase Failed: expected: {0}, actual: {1}'.format(
                sys.version_info[0],
                actualResult['python']['version']['major']))
        return
    if actualResult['python']['version']['minor'] != sys.version_info[1]:
        print(
            'Testcase Failed: expected: {0}, actual: {1}'.format(
                sys.version_info[1],
                actualResult['python']['version']['minor']))
        return

# Generated at 2022-06-25 00:26:42.054475
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert isinstance(
        python_fact_collector_1.collect(),
        dict)

# Generated at 2022-06-25 00:26:49.952813
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test case for testing method 'collect' of class PythonFactCollector"""
    # Instance to test
    facts_collected = { "python": {
        "version": {
            "major": 3,
            "minor": 6,
            "micro": 9,
            "releaselevel": 'final',
            "serial": 0
        },
        "version_info": [3, 6, 9, 'final', 0],
        "executable": '/usr/bin/python3',
        "type": 'CPython',
        "has_sslcontext": False
    } }
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == facts_collected


# Generated at 2022-06-25 00:26:52.385468
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

fact_names = ('python')


# Generated at 2022-06-25 00:26:56.416065
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyt_fact_collec_0 = PythonFactCollector()
    collected_facts = {}
    collected_facts['ansible_distribution'] = 'Linux'
    pyt_fact_collec_ret_0 = pyt_fact_collec_0.collect(collected_facts=collected_facts)
    assert(pyt_fact_collec_ret_0['ansible_distribution'] == 'Linux')

# Generated at 2022-06-25 00:27:02.738404
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()

    try:
        # Detect system python
        import platform
        if tuple(platform.python_version_tuple()[:2]) >= (2, 7):
            # Only test the SSLContext feature on python 2.7+
            assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    except ImportError:
        pass

    # Detect builtin python
    try:
        import __main__
        if hasattr(__main__, '__file__'):
            assert facts['python']['type'] is None
    except (ImportError, AttributeError):
        pass

    # Detect pypy

# Generated at 2022-06-25 00:27:04.718114
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:27:13.974701
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert 'python' in result
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'version' in result['python']
    assert 'serial' in result['python']['version']
    assert 'micro' in result['python']['version']
    assert 'type' in result['python']
    assert 'releaselevel' in result['python']['version']
    assert 'version_info' in result['python']
    assert 'major' in result['python']['version']
    assert 'minor' in result['python']['version']

# Generated at 2022-06-25 00:27:14.710003
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pytest.skip('test not implemented')

# Generated at 2022-06-25 00:27:55.332251
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

#
# Run these tests:
#   $ ansible -m test_utils.nose_runner -a 'test_module,test_case_0'
#   $ ansible -m test_utils.nose_runner -a 'test_module,test_PythonFactCollector_collect'

# Generated at 2022-06-25 00:27:58.346172
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    print(python_fact_collector_1.collect())
    return

# Generated at 2022-06-25 00:28:01.509846
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_0 = PythonFactCollector()
    # No exception should be raised
    assert python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:03.711229
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect(module=None, collected_facts=None)
    assert isinstance(result, dict)

# Generated at 2022-06-25 00:28:10.548171
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts_data = {
        'python': {
            'type': 'CPython',
            'executable': sys.executable,
            'version': {
                'major': sys.version_info[0],
                'micro': sys.version_info[2],
                'minor': sys.version_info[1],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()
    assert python_fact_collector_0.collect() == python_facts_data

# Generated at 2022-06-25 00:28:13.766966
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instantiate the PythonFactCollector class
    python_fact_collector = PythonFactCollector()

    # Call method collect of PythonFactCollector class
    python_fact_collector.collect()

# Generated at 2022-06-25 00:28:17.881374
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == ({'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }})

# Generated at 2022-06-25 00:28:20.851853
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect()

# Generated at 2022-06-25 00:28:22.880951
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts = python_fact_collector_1.collect()
    assert python_facts is not False


# Generated at 2022-06-25 00:28:24.894645
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # TODO:
    # * Returned list of (python) facts should be of type dict.
    # * Assert PythonFactCollector().collect() does not raise.
    return

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:29:04.690507
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test collect method
    """

    python_fact_collector_obj = PythonFactCollector()
    var_collected_facts = {}
    result_dict = python_fact_collector_obj.collect(collected_facts=var_collected_facts)
    assert type(result_dict) == dict
    assert result_dict.keys() ==  {'python'}
    python_dict = result_dict['python']
    assert type(python_dict) == dict
    assert python_dict.keys() == {'version', 'version_info', 'executable', 'has_sslcontext', 'type'}
    version_dict = python_dict['version']
    assert type(version_dict) == dict
    assert 'major' in version_dict.keys()
    assert 'minor' in version_dict.keys()


# Generated at 2022-06-25 00:29:07.265016
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # Test for no args
    python_fact_collector_0.collect()



# Generated at 2022-06-25 00:29:09.653704
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 is not None


# Generated at 2022-06-25 00:29:11.407941
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()

if __name__ == '__main__':
    # test_case_0()
    test_PythonFactCollector_collect()

# vim: set ansible_collections=munged:

# Generated at 2022-06-25 00:29:20.324913
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert type(var_0) == dict
    # var_0['python']['version_info'][0] == sys.version_info.major
    # var_0['python']['version_info'][1] == sys.version_info.minor
    # var_0['python']['version_info'][2] == sys.version_info.micro
    # var_0['python']['version_info'][3] == sys.version_info.releaselevel
    # var_0['python']['version_info'][4] == sys.version_info.serial
    # var_0['python']['version']['major'] == sys.version_info.

# Generated at 2022-06-25 00:29:29.332609
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    assert isinstance(var_1['python'], dict)
    assert isinstance(var_1['python']['version'], dict)
    assert isinstance(var_1['python']['version']['major'], int)
    assert isinstance(var_1['python']['version']['minor'], int)
    assert isinstance(var_1['python']['version']['micro'], int)
    assert isinstance(var_1['python']['version']['releaselevel'], str)
    assert isinstance(var_1['python']['version']['serial'], int)

# Generated at 2022-06-25 00:29:35.720656
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_1 = PythonFactCollector()
    var_2 = var_1.collect()
    assert var_1._fact_ids == {'python'}
    assert var_2['python']['version']['major'] == 3
    assert var_2['python']['version']['minor'] == 6
    assert var_2['python']['version']['micro'] == 7
    assert var_2['python']['version']['releaselevel'] == 'final'
    assert var_2['python']['version']['serial'] == 0
    assert var_2['python']['version_info'] == [3, 6, 7, 'final', 0]
    assert var_2['python']['executable'] == '/usr/bin/python3'

# Generated at 2022-06-25 00:29:42.588065
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['executable'] == sys.executable
    assert var_0['python']['version']['major'] == 2
    assert var_0['python']['version']['minor'] == 7
    assert var_0['python']['version']['micro'] == 9
    assert var_0['python']['version']['releaselevel'] == 'final'
    assert var_0['python']['version']['serial'] == 0
    assert var_0['python']['version_info'] == [2, 7, 9, 'final', 0]

# Generated at 2022-06-25 00:29:50.521266
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == dict(python=dict(has_sslcontext=HAS_SSLCONTEXT, executable=sys.executable, version_info=list(sys.version_info), type=sys.subversion[0] if hasattr(sys, 'subversion') else (sys.implementation.name if hasattr(sys, 'implementation') else None), version=dict(minor=sys.version_info[1], serial=sys.version_info[4], releaselevel=sys.version_info[3], major=sys.version_info[0], micro=sys.version_info[2])))


# Generated at 2022-06-25 00:29:52.974187
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert('python' in var_0)
    assert('has_sslcontext' in var_0['python'])



# Generated at 2022-06-25 00:31:02.918151
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:08.628972
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1['python']['type'] == "cpython"
    assert var_1['python']['version'] == {
        'micro': 5,
        'minor': 5,
        'releaselevel': 'final',
        'serial': 0,
        'major': 2
    }
    assert var_1['python']['version_info'] == [2, 5, 5, 'final', 0]


# Generated at 2022-06-25 00:31:10.802998
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()
    assert True

# Generated at 2022-06-25 00:31:18.975093
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test case with no argument
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['micro'] == 7
    assert var_0['python']['version']['serial'] == 0
    assert var_0['python']['version']['major'] == 3
    assert var_0['python']['version']['minor'] == 6
    assert var_0['python']['type'] == 'CPython'
    assert var_0['python']['executable'] == '/usr/bin/python3'
    assert var_0['python']['has_sslcontext'] == True
    assert var_0['python']['version']['releaselevel'] == 'final'


# Generated at 2022-06-25 00:31:22.219783
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:31:23.812366
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:31:24.574088
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:31:29.552028
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test with no parameters
    try:
        assert False, "No parameters - this should raise"
    except:
        assert True

    # Test with valid parameters
    try:
        assert True
    except:
        assert False, "Valid parameters - this should not have raised"



# Generated at 2022-06-25 00:31:38.275067
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['releaselevel'] == 'final'
    assert var_0['python']['has_sslcontext'] == True
    assert var_0['python']['version']['minor'] == 7
    assert var_0['python']['version_info'][2] == 4
    assert var_0['python']['type'] == None
    assert var_0['python']['executable'] == '/usr/bin/python'
    assert var_0['python']['version']['micro'] == 4
    assert var_0['python']['version']['major'] == 3

# Generated at 2022-06-25 00:31:41.612443
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        test_case_0()
    except:
        print('Test case 0 failed')