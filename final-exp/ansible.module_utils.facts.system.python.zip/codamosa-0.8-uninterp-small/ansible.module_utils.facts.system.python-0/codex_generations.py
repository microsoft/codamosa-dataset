

# Generated at 2022-06-25 00:23:35.702233
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    python_fact_collector_0_collect = python_fact_collector_0.collect()
    assert python_fact_collector_0_collect['python']['version']['major'] == sys.version_info[0]
    assert python_fact_collector_0_collect['python']['version']['minor'] == sys.version_info[1]
    assert python_fact_collector_0_collect['python']['version']['micro'] == sys.version_info[2]
    assert python_fact_collector_0_collect['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_fact_collector_0_collect['python']['version']['serial'] == sys

# Generated at 2022-06-25 00:23:38.290575
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Method collect of class PythonFactCollector
    python_fact_collector_0 = PythonFactCollector()
    # test collect method
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:23:40.244016
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-25 00:23:48.852137
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = collector.collect()

    assert type(collected_facts) == dict, "collected_facts is not a dict"
    assert 'python' in collected_facts, "python facts are not in collected_facts"
    assert 'version' in collected_facts['python'], "version is not in python facts"
    assert type(collected_facts['python']['version']) == dict, "version is not a dict"
    assert 'major' in collected_facts['python']['version'], "major is not in python version"
    assert type(collected_facts['python']['version']['major']) == int, "major is not an int"
    assert 'minor' in collected_facts['python']['version'], "minor is not in python version"

# Generated at 2022-06-25 00:23:50.000639
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-25 00:23:52.372903
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Tests to see that the method fails when python_facts is None.
    assert test_PythonFactCollector_collect.python_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:23:58.563099
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print(sys.version_info)
    if sys.version_info[0] < 3 or sys.version_info[1] < 5:
        print("Skipping python 3.5+ only tests")
    else:
        python_fact_collector_0 = PythonFactCollector()
        python_facts = python_fact_collector_0.collect()
        print(python_facts)

        #Test if we have major, minor and release info
        assert(python_facts['python']['version']['major'] > 0)
        assert(python_facts['python']['version']['minor'] > 0)
        assert(python_facts['python']['version']['releaselevel'] == 'final')
        assert(python_facts['python']['executable'] is not None)

        #Test if we are

# Generated at 2022-06-25 00:24:00.714614
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert 'python' in result

# Generated at 2022-06-25 00:24:02.498721
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert False

# Generated at 2022-06-25 00:24:09.511205
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test issue #23786
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert result == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-25 00:24:19.277133
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()

    assert result['python']['type'] == 'CPython'
    assert result['python']['version']['major'] == 2
    assert result['python']['version']['minor'] == 7
    assert result['python']['version']['micro'] == 13
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [2, 7, 13, 'final', 0]
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-25 00:24:20.781804
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert  0 == 0


# Generated at 2022-06-25 00:24:27.693828
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts.get('python').get('version').get('major') == sys.version_info[0]
    assert python_facts.get('python').get('version').get('minor') == sys.version_info[1]
    assert python_facts.get('python').get('version').get('micro') == sys.version_info[2]
    assert python_facts.get('python').get('version').get('releaselevel') == sys.version_info[3]
    assert python_facts.get('python').get('version').get('serial') == sys.version_info[4]

# Generated at 2022-06-25 00:24:35.273906
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert result['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert result['python']['version_info'] == list(sys.version_info)
    if getattr(sys, 'implementation', None):
        assert result['python']['type'] == sys.implementation.name

# Generated at 2022-06-25 00:24:37.222074
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var = PythonFactCollector()
    var.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:24:47.231760
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result_0 = python_fact_collector_0.collect()
    assert isinstance(result_0, dict)
    assert 'python' in result_0
    assert isinstance(result_0['python'], dict)
    assert 'version' in result_0['python']
    assert isinstance(result_0['python']['version'], dict)
    assert 'major' in result_0['python']['version']
    assert isinstance(result_0['python']['version']['major'], int)
    assert 'minor' in result_0['python']['version']
    assert isinstance(result_0['python']['version']['minor'], int)

# Generated at 2022-06-25 00:24:51.379213
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test function collect of class PythonFactCollector
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.fact_type == "python"

# Generated at 2022-06-25 00:24:57.661181
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    res = python_fact_collector_0.collect()
    assert res['python']['type'] == 'CPython'
    assert res['python']['version']['releaselevel'] == 'final'
    assert type(res['python']['version']['micro']) == type(0)
    assert res['python']['executable'] == sys.executable
    assert res['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-25 00:24:58.927594
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:25:04.101007
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert 'python' in result
    assert result['python']['executable'] == sys.executable
    assert len(result['python']['version_info']) == 5
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert 'type' in result['python']


# Generated at 2022-06-25 00:25:11.667936
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    if not var_1:
        raise Exception("Cannot collect python facts")
    else:
        print("var_1 data : %s" % var_1)


# Generated at 2022-06-25 00:25:19.545285
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 10, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 10, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': 'CPython'}}, 'Module method collect of class PythonFactCollector returned unexpected result'

# Generated at 2022-06-25 00:25:27.369297
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    assert isinstance(
        var_0['python']['version']['releaselevel'],
        str
    )
    assert var_0['python']['version']['micro'] == 5

    assert isinstance(
        var_0['python']['version']['releaselevel'],
        str
    )
    assert var_0['python']['version']['micro'] == 5

    assert isinstance(
        var_0['python']['version']['releaselevel'],
        str
    )
    assert var_0['python']['version']['micro'] == 5



# Generated at 2022-06-25 00:25:29.432353
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert True


# Generated at 2022-06-25 00:25:32.054455
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

    # assert the return type of method collect of class PythonFactCollector is dict
    assert isinstance(var_1, dict)



# Generated at 2022-06-25 00:25:33.913041
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:39.872819
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 12, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 12, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False}}


# Generated at 2022-06-25 00:25:44.427995
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = PythonFactCollector().collect()

    assert facts['python']['version']
    assert facts['python']['version_info']
    assert facts['python']['executable']
    assert 'type' in facts['python']

# Generated at 2022-06-25 00:25:46.457057
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:54.513911
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = type(var_0)
    var_2 = isinstance(var_0, dict)
    var_3 = var_0['python']['executable']
    var_4 = type(var_3)
    var_5 = sys.executable
    var_6 = var_0['python']['type']
    var_7 = type(var_6)
    var_8 = var_0['python']['version']
    var_9 = type(var_8)
    var_10 = isinstance(var_8, dict)
    var_11 = var_8['major']
    var_12 = type(var_11)

# Generated at 2022-06-25 00:26:04.011413
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:26:05.889382
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert 'python' in var_1

# Generated at 2022-06-25 00:26:06.717020
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_1 = PythonFactCollector()

    var_1.collect()

# Generated at 2022-06-25 00:26:07.401113
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass


# Generated at 2022-06-25 00:26:09.162360
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0



# Generated at 2022-06-25 00:26:13.938861
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()
    var_1 = var_0.collect()

    assert isinstance(var_1, dict)
    assert var_1['python']['version_info'][0] == 3
    assert var_1['python']['type'] == 'CPython'
    assert var_1['python']['has_sslcontext'] == True

# Generated at 2022-06-25 00:26:17.465902
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:26:17.949590
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:26:18.694935
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:26:20.463921
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:40.498460
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()
    var_1 = var_0.collect()
    assert 'python' in var_1
    assert 'executable' in var_1['python']
    assert 'has_sslcontext' in var_1['python']
    assert 'type' in var_1['python']
    assert 'version' in var_1['python']
    assert 'version_info' in var_1['python']

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:26:46.841164
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    python_fact_collector_1 = PythonFactCollector()
    var_0 = python_fact_collector_1.collect()
    python_fact_collector_2 = PythonFactCollector()
    var_0 = python_fact_collector_2.collect()
    python_fact_collector_3 = PythonFactCollector()
    var_0 = python_fact_collector_3.collect()
    python_fact_collector_4 = PythonFactCollector()
    var_0 = python_fact_collector_4.collect()
    python_fact_collector_5 = PythonFactCollector()
    var_0 = python_fact_collector_5.collect()
   

# Generated at 2022-06-25 00:26:51.349946
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_02 = python_fact_collector_0.get_facts(None)



# Generated at 2022-06-25 00:26:52.978020
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:54.587378
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:26:55.314507
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass



# Generated at 2022-06-25 00:27:04.320580
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    assert var_0['python']['version']['major'] == sys.version_info[0]
    assert var_0['python']['version']['minor'] == sys.version_info[1]
    assert var_0['python']['version']['micro'] == sys.version_info[2]
    assert var_0['python']['version']['releaselevel'] == sys.version_info[3]
    assert var_0['python']['version']['serial'] == sys.version_info[4]
    assert var_0['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:27:06.104853
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()



# Generated at 2022-06-25 00:27:10.279048
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:27:11.001397
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert callable(PythonFactCollector.collect)

# Generated at 2022-06-25 00:27:45.921073
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:27:51.623483
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()
    var_1 = var_0.collect()
    assert var_1 == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 13, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 13, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False}}



# Generated at 2022-06-25 00:27:57.726099
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of PythonFactCollector
    test_instance_0 = PythonFactCollector()

    # Call the collect method of PythonFactCollector
    test_instance_0.collect()

    # Check that the PythonFactCollector class has an attribute _fact_ids of type set
    assert isinstance(PythonFactCollector._fact_ids, set)

    # Check that the PythonFactCollector class has an attribute name of type str
    assert isinstance(PythonFactCollector.name, str)

    # Check that the PythonFactCollector class has an attribute name of value Python
    assert PythonFactCollector.name == 'python'


# Generated at 2022-06-25 00:28:00.778466
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    collector = PythonFactCollector()
    assert set(collector.collect().keys()) == set(['python'])

# Generated at 2022-06-25 00:28:08.048551
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print("Testing collect method of class PythonFactCollector:")
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 is not None, "Test #0 Failed - Could not create instance of PythonFactCollector"
    print("Success. collect method of class PythonFactCollector ran to completion.\n")


# Generated at 2022-06-25 00:28:09.049282
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:28:13.280133
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # unit test for method collect of class PythonFactCollector
    var_1 = python_fact_collector_0.collect()
    assert var_1['python']['type'] == 'CPython'


# Generated at 2022-06-25 00:28:14.605082
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:19.170680
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:28:21.589935
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    var_1 = var_0.keys()
    assert len(var_1) == 1
    var_2 = 'python' in var_1
    assert var_2 is True


# Generated at 2022-06-25 00:29:34.797774
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert all(isinstance(i, dict) for i in var_0.values())


# Generated at 2022-06-25 00:29:38.681207
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

test_case_0()



# Generated at 2022-06-25 00:29:43.811376
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 == {'python': {'version': {'minor': 5, 'releaselevel': 'final', 'major': 2, 'micro': 3, 'serial': 0}, 'has_sslcontext': True, 'version_info': [2, 5, 3, 'final', 0], 'executable': '/usr/bin/python', 'type': 'CPython'}}


# Generated at 2022-06-25 00:29:44.909642
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print("Test collect")


# Generated at 2022-06-25 00:29:53.284515
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    # Assertions
    assert (var_0 == {'python': {'type': sys.subversion[0], 'executable': sys.executable,
                                 'version_info': list(sys.version_info),
                                 'version': {'major': sys.version_info[0], 'minor': sys.version_info[1],
                                             'micro': sys.version_info[2], 'releaselevel': sys.version_info[3],
                                             'serial': sys.version_info[4]}, 'has_sslcontext': HAS_SSLCONTEXT}})


# Generated at 2022-06-25 00:29:56.542938
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()
    var_0 = python_fact_collector_1.collect()


# Generated at 2022-06-25 00:29:59.667634
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:30:02.257381
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:30:03.044630
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:30:10.434275
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['serial'] == 0, "var_0['python']['version']['serial'] should equal 0!"
    assert var_0['python']['version']['micro'] == 2, "var_0['python']['version']['micro'] should equal 2!"
    assert var_0['python']['version']['releaselevel'] == 'final', "var_0['python']['version']['releaselevel'] should equal 'final'!"

# Generated at 2022-06-25 00:32:40.761342
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    return_value_1 = python_fact_collector_1.collect(collected_facts={})

# Generated at 2022-06-25 00:32:46.836393
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize mock objects and test subject.
    PythonFactCollector_collect_mock_object = PythonFactCollector()
    PythonFactCollector_collect_mock_object.name = 'ansible_local'
    PythonFactCollector_collect_mock_object.version = (2, 5, 3, 'final', 0)
    PythonFactCollector_collect_mock_object.version_info = (2, 5, 3, 'final', 0)
    PythonFactCollector_collect_mock_object.implementation = PythonFactCollector_collect_mock_object
    PythonFactCollector_collect_mock_object.implementation.name = 'CPython' 
    PythonFactCollector_collect_mock_object.subversion = ['CPython', 'CPython']
    PythonFactCollector_collect_mock_object

# Generated at 2022-06-25 00:32:47.974893
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:32:49.741531
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()



# Generated at 2022-06-25 00:32:56.208362
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test method with parameters
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    # Test method without parameters
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()



if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

    sys.exit(0)

# Generated at 2022-06-25 00:33:00.580782
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # Exception handling
    try:
        python_fact_collector_0.collect()
    except Exception as e:
        assert type(e) == AttributeError

# Generated at 2022-06-25 00:33:07.733150
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'version_info': [2, 7, 13, 'final', 0], 'executable': '/System/Library/Frameworks/Python.framework/Versions/2.7/Resources/Python.app/Contents/MacOS/Python', 'has_sslcontext': False, 'version': {'micro': 13, 'releaselevel': 'final', 'major': 2, 'minor': 7, 'serial': 0}}}


# Generated at 2022-06-25 00:33:10.519377
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:33:12.249919
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:33:14.643970
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
        Unit test for method collect of class PythonFactCollector
    """
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()