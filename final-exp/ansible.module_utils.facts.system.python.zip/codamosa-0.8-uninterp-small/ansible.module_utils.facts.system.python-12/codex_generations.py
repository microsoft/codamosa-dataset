

# Generated at 2022-06-25 00:23:33.568629
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Get an instance of PythonFactCollector
    python_fact_collector_1 = PythonFactCollector()
    # Testing method collect of class PythonFactCollector
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:23:39.983466
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts_1 = python_fact_collector_1.collect()
    assert python_facts_1['python']['version'] == {
        "major": 2,
        "minor": 7,
        "micro": 11,
        "releaselevel": "final",
        "serial": 0
    }
    assert python_facts_1['python']['version_info'] == [2, 7, 11, "final", 0]

# Generated at 2022-06-25 00:23:48.520400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Unit test for method collect of class PythonFactCollector
    # Test with empty parameter
    python_fact_collector_1 = PythonFactCollector()

# Generated at 2022-06-25 00:23:54.171621
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    collected_facts = dict()
    python_facts = python_fact_collector_1.collect(collected_facts=collected_facts)
    assert python_facts == {'python': {'executable': '/usr/bin/python', 'version': {'major': 2, 'micro': 7, 'minor': 10, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 10, 'final', 0], 'type': 'CPython', 'has_sslcontext': True}}

# Generated at 2022-06-25 00:23:57.118248
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of PythonFactCollector
    python_fact_collector_1 = PythonFactCollector()
    # Invoke method collect on the instance
    facts = python_fact_collector_1.collect()
    # Check if facts is a dictionary, if not raise an exception
    assert isinstance(facts, dict)

# Generated at 2022-06-25 00:24:00.037284
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:24:01.825097
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result0 = python_fact_collector_0.collect()
    print(result0)

# Generated at 2022-06-25 00:24:06.107559
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == {'python': {'executable': '/usr/bin/python', 'has_sslcontext': False, 'version': {'major': 2, 'minor': 7, 'micro': 9, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 9, 'final', 0], 'type': 'CPython'}}


# Generated at 2022-06-25 00:24:16.013982
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Test collecting with PythonFactCollector'''
    python_fact_collector_1 = PythonFactCollector()

    assert python_fact_collector_1.collect()['python']['version']['major'] == sys.version_info[0]
    assert python_fact_collector_1.collect()['python']['version']['minor'] == sys.version_info[1]
    assert python_fact_collector_1.collect()['python']['version']['micro'] == sys.version_info[2]
    assert python_fact_collector_1.collect()['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-25 00:24:20.998687
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-25 00:24:28.322578
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 7
    assert result['python']['version']['releaselevel'] == 'final'
    assert len(result['python']['version_info']) == 5
    assert result['python']['executable'] == '/usr/bin/python3'
    assert result['python']['has_sslcontext'] == True
    assert result['python']['type'] == 'CPython'

# Generated at 2022-06-25 00:24:34.575882
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts is not None
    assert 'python' in python_facts
    assert python_facts['python']['type'] in ('CPython', 'IronPython', 'Jython', 'PyPy')
    assert python_facts['python']['executable'] is not None
    assert python_facts['python']['version'] is not None
    assert python_facts['python']['version_info'] is not None
    assert python_facts['python']['has_sslcontext'] is not None



# Generated at 2022-06-25 00:24:45.140934
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result.get('python') is not None
    assert result.get('python').get('version') is not None
    assert result.get('python').get('version').get('major') == sys.version_info[0]
    assert result.get('python').get('version').get('minor') == sys.version_info[1]
    assert result.get('python').get('version').get('micro') == sys.version_info[2]
    assert result.get('python').get('version').get('releaselevel') == sys.version_info[3]
    assert result.get('python').get('version').get('serial') == sys.version_info[4]

# Generated at 2022-06-25 00:24:46.823914
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:24:51.682677
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'version': {'major': 2, 'micro': 3, 'minor': 4, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 4, 3, 'final', 0], 'has_sslcontext': False, 'type': 'CPython', 'executable': '/usr/bin/python'}}

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:24:53.009595
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()


# Generated at 2022-06-25 00:24:55.014778
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:57.218201
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # This is not a real test, but it is better than nothing
    assert 'python' in python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:01.745212
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()

    result_0 = python_fact_collector_0.collect()
    result_1 = python_fact_collector_1.collect()
    assert result_0 is not None
    assert result_1 is not None

# Generated at 2022-06-25 00:25:09.023409
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_module = PythonFactCollector()
    python_fact_collector_module_result = python_fact_collector_module.collect()

    assert 'python' in python_fact_collector_module_result

    assert 'version' in python_fact_collector_module_result['python']
    assert 'version_info' in python_fact_collector_module_result['python']
    assert 'executable' in python_fact_collector_module_result['python']
    assert 'has_sslcontext' in python_fact_collector_module_result['python']
    assert 'type' in python_fact_collector_module_result['python']


# Generated at 2022-06-25 00:25:22.664729
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert python_fact_collector_0.collect() == {
        'python': {
            'version': {
                'major': x,
                'minor': x,
                'micro': x,
                'releaselevel': x,
                'serial': x
            },
            'version_info': [
                x,
                x,
                x,
                x,
                x
            ],
            'executable': x,
            'has_sslcontext': x
        }
    }

# Generated at 2022-06-25 00:25:25.148822
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result_0 = python_fact_collector_0.collect()
    assert 'python' in result_0


# Generated at 2022-06-25 00:25:30.082711
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert (result == {"python": {"version": {"major": 2, "minor": 7, "micro": 12, "releaselevel": "final", "serial": 0}, "type": "CPython", "executable": "/usr/bin/python", "version_info": [2, 7, 12, "final", 0], "has_sslcontext": True}})

# Generated at 2022-06-25 00:25:35.584655
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    collected_facts = {}
    collected_facts['ansible_facts'] = {}
    py_fc.collect(collected_facts=collected_facts)
    assert 'python' in collected_facts['ansible_facts']


if __name__ == "__main__":
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:25:38.385849
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:39.163731
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass


# Generated at 2022-06-25 00:25:45.859693
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == {'python': {'version': {'serial': 0, 'releaselevel': 'final', 'micro': 0, 'major': 2, 'minor': 6}, 'type': None, 'executable': '/usr/bin/python', 'version_info': [2, 6, 0, 'final', 0], 'has_sslcontext': False}}

# Generated at 2022-06-25 00:25:49.905886
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # run the collect method and assert the default facts exist
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-25 00:25:58.404006
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    class AnsibleModuleMock:
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.fail_json = lambda x: sys.exit(0)

    #Case:
    # Test the code path when collected_facts is None and
    # HAS_SSLCONTEXT is true

    python_fact_collector_0 = PythonFactCollector()
    ansible_module_0 = AnsibleModuleMock()
    python_facts = python_fact_collector_0.collect(ansible_module_0)
    assert python_facts is not None
    assert python_facts['python']['type'] == 'CPython'
    assert python_facts['python']['has_sslcontext'] == True

    #Case:
    # Test the code path when collected_facts is not None

# Generated at 2022-06-25 00:26:08.523901
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    python_facts = python_fact_collector_0.collect()

    assert python_facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] is True
    assert python_facts['python']['type'] == 'cpython'

# Generated at 2022-06-25 00:26:18.204468
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:19.275147
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    arg0 = PythonFactCollector()
    arg0.collect()


# Generated at 2022-06-25 00:26:21.310253
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector_obj_0 = PythonFactCollector()
    var_0 = py_fact_collector_obj_0.collect()


# Generated at 2022-06-25 00:26:24.512585
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1['python']['type'] in set(['CPython', 'PyPy', 'Jython', 'IronPython', 'cli'])


# Generated at 2022-06-25 00:26:25.851126
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:26:29.579464
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:26:37.740196
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # The following call to collect()
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    # Should return a dictionary
    try:
        assert isinstance(var_1, dict)
    except AssertionError:
        raise AssertionError("var_1 should be a dictionary, but instead is {0}.".format(var_1.__repr__()))
    # With a key 'python'
    try:
        assert 'python' in var_1
    except AssertionError:
        raise AssertionError("python should be a key in var_1, but is not.")

# Generated at 2022-06-25 00:26:39.431399
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() is None, 'Return value of PythonFactCollector.collect() is None'

# Generated at 2022-06-25 00:26:46.005577
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_2 = PythonFactCollector()
    var_2 = python_fact_collector_2.collect()

    assert 'python' in var_2
    assert 'version' in var_2['python']
    assert 'version_info' in var_2['python']
    assert 'type' in var_2['python']
    assert 'has_sslcontext' in var_2['python']
    assert 'executable' in var_2['python']

# Generated at 2022-06-25 00:26:47.857912
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()


# Generated at 2022-06-25 00:27:03.836549
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:27:13.883078
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    fact_data = py_fact_collector.collect()
    assert fact_data['python']['version']['major'] == sys.version_info[0]
    assert fact_data['python']['version']['minor'] == sys.version_info[1]
    assert fact_data['python']['version']['micro'] == sys.version_info[2]
    assert fact_data['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_data['python']['version']['serial'] == sys.version_info[4]
    assert fact_data['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:27:16.350251
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert callable(PythonFactCollector.__dict__['collect'])
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 00:27:17.944157
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collect_test_0 = PythonFactCollector()
    # Test the collect method of class PythonFactCollector
    collect_test_0.collect()
    return 0

# Generated at 2022-06-25 00:27:19.288156
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:25.274231
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()
    var_2 = python_fact_collector_0.collect()
    var_3 = python_fact_collector_0.collect()
    var_4 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:32.793632
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Setup
    python_fact_collector_0 = PythonFactCollector()
    # Case 1
    var_0 = python_fact_collector_0.collect()
    # Assert
    assert var_0['python']['version']['major']==3
    assert var_0['python']['version']['minor']==5
    assert var_0['python']['version']['micro']==2
    assert var_0['python']['version']['releaselevel']=='final'
    assert var_0['python']['version']['serial']==0
    assert var_0['python']['version_info']==[3, 5, 2, 'final', 0]
    assert var_0['python']['executable']=='/usr/bin/python'
    assert var

# Generated at 2022-06-25 00:27:35.489420
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:27:37.494271
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:27:41.922967
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 is not None

# Generated at 2022-06-25 00:28:15.503553
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-25 00:28:20.479369
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.python import PythonFactCollector

    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:28:22.172883
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:29.535024
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    var_0 = python_fact_collector_0.collect()

    try:
        assert var_0['python']['version']['major'] == sys.version_info[0]
    except AssertionError:
        raise
    try:
        assert var_0['python']['version']['minor'] == sys.version_info[1]
    except AssertionError:
        raise
    try:
        assert var_0['python']['version']['micro'] == sys.version_info[2]
    except AssertionError:
        raise
    try:
        assert var_0['python']['version']['releaselevel'] == sys.version_info[3]
    except AssertionError:
        raise


# Generated at 2022-06-25 00:28:31.305155
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:36.169391
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()
    assert repr(var_1) == "{'python': {'version': {'micro': 5, 'minor': 6, 'releaselevel': 'final', 'serial': 0, 'major': 3}, 'executable': '/usr/bin/python', 'has_sslcontext': True, 'version_info': [3, 6, 5, 'final', 0], 'type': 'CPython'}}"

# Generated at 2022-06-25 00:28:37.563157
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:28:39.755693
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {}}, "Method 'collect' of class 'PythonFactCollector' returned unexpected value"

# Generated at 2022-06-25 00:28:43.940334
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


if __name__ == '__main__':
    import sys
    import __main__
    sys.modules['__main__'] = __main__
    # Unit test for method collect of class PythonFactCollector
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:51.306393
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test case where version_info has 6 elements
    python_fact_collector_0 = PythonFactCollector()
    version_info_0 = (3, 7, 1, 'final', 0, '')
    python_fact_collector_0._ansible_facts = {'python': {'version_info': version_info_0}}
    collected_facts_0 = {'python': {'version_info': version_info_0}}
    var_0 = python_fact_collector_0.collect(collected_facts_0)

# Generated at 2022-06-25 00:30:02.967578
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print("Test collect() method of PythonFactCollector...")
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    print("var_0: ", var_0)


# Generated at 2022-06-25 00:30:09.062176
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 == {'python': {'executable': '/usr/bin/python',
                                'has_sslcontext': True,
                                'type': 'cpython',
                                'version': {'major': 2,
                                            'micro': 7,
                                            'minor': 6,
                                            'releaselevel': 'final',
                                            'serial': 0},
                                'version_info': [2, 6, 7, 'final', 0]}}


# Generated at 2022-06-25 00:30:16.148167
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test collect (PythonFactCollector)
    """
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-25 00:30:20.585590
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'type': 'CPython', 'version_info': [2, 7, 12, 'final', 0], 'has_sslcontext': True, 'version': {'major': 2, 'serial': 0, 'minor': 7, 'micro': 12, 'releaselevel': 'final'}, 'executable': '/usr/bin/python'}}

# Generated at 2022-06-25 00:30:21.800880
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:30:23.236363
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:30:30.191752
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    print(var_0)
    print('Python version is: {0}.{1}.{2}'.format(
        var_0['python']['version']['major'],
        var_0['python']['version']['minor'],
        var_0['python']['version']['micro']))
    print('Python executable is: {0}'.format(
        var_0['python']['executable']))

# Generated at 2022-06-25 00:30:31.405229
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:30:33.162603
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect(collected_facts={})
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-25 00:30:35.381955
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['type'] == 'CPython'

# vim: set fileencoding=utf-8 :

# Generated at 2022-06-25 00:33:11.157414
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert type(var_1) == dict
    assert var_1 == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'has_sslcontext': HAS_SSLCONTEXT,
            'version_info': list(sys.version_info),
            'executable': sys.executable
        }
    }


# Generated at 2022-06-25 00:33:13.571766
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0
    var_1 = python_fact_collector_0.collect()



# Generated at 2022-06-25 00:33:18.742477
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 is not None

# Generated at 2022-06-25 00:33:23.546568
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:33:32.020918
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 == {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': list(sys.version_info), 'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT}}
