

# Generated at 2022-06-25 00:23:29.308724
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:23:35.013631
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    str_0 = '`3&CB\r}*baX.Hu\x0bb'
    dict_0 = {'python': {'type': 'CPython', 'has_sslcontext': False, 'version': {'releaselevel': 'final', 'micro': 0, 'serial': 0, 'minor': 5, 'major': 2}, 'executable': '/usr/local/bin/python', 'version_info': [2, 5, 0, 'final', 0]}}
    assert_equals(python_fact_collector_0.collect(), dict_0)


# Generated at 2022-06-25 00:23:37.833859
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    str_0 = '=\x10\x05'
    python_fact_collector_0 = PythonFactCollector(str_0)
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:23:40.136592
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector(str_0)

    # Method parameters test case 0
    python_fact_collector_0.collect(str_0)

# Generated at 2022-06-25 00:23:43.327183
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    str_0 = 'PythonFactCollector'
    python_fact_collector_0 = PythonFactCollector(str_0)
    module_0 = None
    collected_facts_0 = None
    assert python_fact_collector_0.collect(module_0, collected_facts_0)


# Generated at 2022-06-25 00:23:48.250057
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    str_0 = '+V\x1d\x1c'
    python_fact_collector_0 = PythonFactCollector(str_0)
    str_1 = '}*baX.Hu\x0bb'
    str_2 = '`3&CB\r'
    python_fact_collector_0.collect(str_1, str_2)


# Generated at 2022-06-25 00:23:50.622873
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    str_0 = '5a'
    python_fact_collector_0 = PythonFactCollector(str_0)
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:23:54.091476
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create the target object
    str_0 = 'o,=8}tMF'
    python_fact_collector_0 = PythonFactCollector(str_0)
    # Run the method
    result = python_fact_collector_0.collect()
    # Check the result
    assert result is not None


# Generated at 2022-06-25 00:23:59.103735
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Try to get the facts of PythonFactCollector
    # collect(module=None, collected_facts=None)
    # AssertionError: assert len(python_facts['python']['version_info']) == 5
    try:
        test_case_0()
    except AssertionError as e:
        print(e)
    else:
        try:
            assert len(python_facts['python']['version_info']) == 5
        except NameError as e:
            print(e)
        except AssertionError as e:
            print(e)
        else:
            print('test case 0 passed')


# Generated at 2022-06-25 00:24:02.262862
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    str_0 = '-Q\nI\x16\x1d\n\x0b\x04'
    python_fact_collector_0 = PythonFactCollector(str_0)
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:24:06.318111
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:07.595874
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:24:13.554798
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert isinstance(result, dict)
    assert isinstance(result['python'], dict)
    assert isinstance(result['python']['version'], dict)
    assert isinstance(result['python']['version_info'], list)
    assert isinstance(result['python']['executable'], str)
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']
    assert isinstance(result['python']['type'], str) or result['python']['type'] is None

# Generated at 2022-06-25 00:24:18.506619
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    collected_facts = {}
    python_fact_collector_1.collect(collected_facts=collected_facts)
    assert collected_facts == {'python': {'executable': '/usr/bin/python',
                                          'has_sslcontext': False,
                                          'type': 'CPython',
                                          'version': {'major': 2,
                                                      'micro': 7,
                                                      'minor': 10,
                                                      'releaselevel': 'final',
                                                      'serial': 0},
                                          'version_info': [2, 7, 10, 'final', 0]}}

# Generated at 2022-06-25 00:24:22.072355
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert type(result) is dict

# Generated at 2022-06-25 00:24:26.145570
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    expected = {'python': {'executable': '/usr/bin/python', 'version_info': [2, 7, 15, 'final', 0], 'type': 'CPython', 'version': {'releaselevel': 'final', 'major': 2, 'serial': 0, 'minor': 7, 'micro': 15}}}
    actual = python_fact_collector_0.collect()
    assert actual == expected

# Generated at 2022-06-25 00:24:33.719075
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {
        'python': {
            'has_sslcontext': HAS_SSLCONTEXT,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-25 00:24:35.326135
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()


# Generated at 2022-06-25 00:24:37.824065
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:24:39.637638
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector.collect()
    assert type(result) is dict
    assert 'python' in result

# Generated at 2022-06-25 00:24:46.882295
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0_instance = test_case_0()
    result = test_case_0_instance.collect()
    result.pop('python')['has_sslcontext']
    true_result = True
    assert result.pop('python')['has_sslcontext'] == true_result

# Generated at 2022-06-25 00:24:51.709331
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a new instance of PythonFactCollector
    python_fact_collector_0 = PythonFactCollector()

    # Create a new instance of AnsibleModule
    module_0 = AnsibleModule(argument_spec=dict())

    # Call method collect of PythonFactCollector with parameters module=module_0 and collected_facts=None
    return_value = python_fact_collector_0.collect(module=module_0, collected_facts=None)

    # Check if the return_value is equal to None
    assert (return_value == None)


# Generated at 2022-06-25 00:24:53.635511
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    param_0 = None
    param_1 = None
    python_fact_collector_0 = PythonFactCollector()
    assert {} == python_fact_collector_0.collect(param_0, param_1)

# Generated at 2022-06-25 00:24:55.611797
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:24:58.970524
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1_result = python_fact_collector_1.collect()
    assert python_fact_collector_1_result is not None


# Generated at 2022-06-25 00:25:07.803472
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Arrange
    python_fact_collector_1 = PythonFactCollector()

    # Act
    result = python_fact_collector_1.collect()

    # Assert
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 6
    assert result['python']['version']['micro'] == 1
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [3, 6, 1, 'final', 0]
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == True

# Generated at 2022-06-25 00:25:12.818403
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    SystemPythonFactCollector_0 = PythonFactCollector()
    assert SystemPythonFactCollector_0.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 9, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 9, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': 'CPython'}}


# Generated at 2022-06-25 00:25:23.201149
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

# Generated at 2022-06-25 00:25:27.974495
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print('Unit test for method collect of class PythonFactCollector...')
    python_fact_collector_1 = PythonFactCollector()
    facts_dict_1 = python_fact_collector_1.collect()
    print(facts_dict_1)
    print()


if __name__ == '__main__':
    print('Testing Ansible gathered facts for Python...')
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:25:34.388783
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {'python': '', 'python_version': ''}
    expected_facts = {'python': {'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython',
                                 'version': {'major': 2, 'micro': 7, 'minor': 12, 'releaselevel': 'final', 'serial': 0},
                                 'version_info': [2, 7, 12, 'final', 0]}}

    python_fact_collector_0.collect(None, collected_facts)
    assert collected_facts == expected_facts

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:25:44.392858
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0_collect = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:48.043144
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    assert len(facts) == 1
    assert facts["python"]["version"]["major"] == 3
    assert facts["python"]["version"]["releaselevel"] == "final"

# Generated at 2022-06-25 00:25:56.741953
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts = python_fact_collector_1.collect()
    assert python_facts['python']['version_info'][0] == sys.version_info[0]
    assert python_facts['python']['version_info'][1] == sys.version_info[1]
    assert python_facts['python']['version_info'][2] == sys.version_info[2]
    assert python_facts['python']['version_info'][3] == sys.version_info[3]
    assert python_facts['python']['version_info'][4] == sys.version_info[4]
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-25 00:26:01.205989
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': 
        {'version': {'major': 2, 'minor': 7, 'micro': 13, 'releaselevel': 'final', 'serial': 0}, 
        'version_info': [2, 7, 13, 'final', 0], 'executable': sys.executable, 'has_sslcontext': True, 'type': 'CPython'}}


# Generated at 2022-06-25 00:26:02.895785
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    res = python_fact_collector.collect()
    assert res.keys() == {'python'}

# Generated at 2022-06-25 00:26:07.754971
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts_0 = python_fact_collector_0.collect()
    assert 'python' in facts_0


# Generated at 2022-06-25 00:26:15.146260
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Small test
    python_fact_collector_0 = PythonFactCollector()
    # Check the expected result
    python_facts = python_fact_collector_0.collect()
    assert python_facts == {u'python': {u'version': {u'major': 2, u'tiny': 0, u'build': 0, u'releaselevel': u'final', u'minor': 7}, 'version_info': [2, 7, 6, u'final', 0], 'executable': u'/usr/bin/python', 'has_sslcontext': True}}


# Generated at 2022-06-25 00:26:23.889708
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts_0 = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-25 00:26:25.702897
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    dict_of_dicts = python_fact_collector_1.collect()
    assert 'python' in dict_of_dicts.keys()


# Generated at 2022-06-25 00:26:30.364758
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    assert isinstance(python_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:26:48.096145
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert result is not None

# Generated at 2022-06-25 00:26:57.424134
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result is not None
    assert result['python'] is not None
    assert result['python']['version'] is not None
    assert result['python']['version']['major'] is not None
    assert result['python']['version']['minor'] is not None
    assert result['python']['version']['micro'] is not None
    assert result['python']['version']['releaselevel'] is not None
    assert result['python']['version']['serial'] is not None
    assert result['python']['version_info'] is not None
    assert result['python']['executable'] is not None
    assert result['python']['has_sslcontext'] is not None



# Generated at 2022-06-25 00:26:58.609531
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:00.521146
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-25 00:27:06.893341
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert result == {'python': {'type': 'CPython', 'has_sslcontext': True, 'version': {'releaselevel': 'final', 'serial': 0, 'micro': 2, 'major': 2, 'minor': 7}, 'version_info': [2, 7, 6, 'final', 0], 'executable': './test'}}

# Generated at 2022-06-25 00:27:09.659326
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:27:11.495970
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:27:13.306328
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    my_python_fact_collector = PythonFactCollector()
    my_python_fact_collector.collect()


# Generated at 2022-06-25 00:27:18.004308
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:27:25.418648
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect({},{})
    assert result == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }}, "Method collect of class PythonFactCollector failed"


# Generated at 2022-06-25 00:28:01.878807
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    PythonFactCollector.collect(python_fact_collector_0)

# Generated at 2022-06-25 00:28:08.215397
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.python import PythonFactCollector
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']['executable'] == sys.executable
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    if python_facts['python']['type'] == 'CPython':
        assert python_facts['python']['type'] == 'CPython'

# Generated at 2022-06-25 00:28:17.672184
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        HAS_SSLCONTEXT = True
    except ImportError:
        HAS_SSLCONTEXT = False

    python_fact_collector_1 = PythonFactCollector()

    rv = python_fact_collector_1.collect()
    assert type(rv) == dict
    assert rv.get('python').get('version').get('major') == sys.version_info[0]
    assert rv.get('python').get('version').get('minor') == sys.version_info[1]
    assert rv.get('python').get('version').get('micro') == sys.version_info[2]
    assert rv.get('python').get('version').get('releaselevel')

# Generated at 2022-06-25 00:28:20.157780
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

# Generated at 2022-06-25 00:28:27.653774
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_0 = python_fact_collector_1.collect()

    assert isinstance(python_0, dict)
    assert python_0['python']['version']['micro'] == sys.version_info[2]
    assert python_0['python']['version_info'] == list(sys.version_info)
    assert python_0['python']['executable'] == sys.executable
    assert python_0['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-25 00:28:35.292760
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = test_case_0()
    python_facts = python_fact_collector_0.collect()
    assert [u'python'] == list(python_facts)
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    try:
        python_facts['python']['type'] == sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] == sys.implementation.name
        except AttributeError:
            python_facts['python']['type'] == None
# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-25 00:28:43.238637
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()

    assert 'python' in result
    python_facts = result['python']

    assert isinstance(python_facts['has_sslcontext'], bool)
    assert isinstance(python_facts['executable'], str)
    assert isinstance(python_facts['version'], dict)
    assert isinstance(python_facts['version_info'], list)
    assert isinstance(python_facts['type'], str)

    assert 'micro' in python_facts['version']
    assert 'minor' in python_facts['version']
    assert 'major' in python_facts['version']
    assert 'releaselevel' in python_facts['version']
    assert 'serial' in python_facts['version']


# Generated at 2022-06-25 00:28:44.695550
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    g = {}
    python_fact_collector_0.collect(g)


# Generated at 2022-06-25 00:28:50.764959
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == {
        'python': {
            'type': 'CPython',
            'has_sslcontext': True,
            'version_info': [
                3,
                6,
                4,
                'final',
                0
            ],
            'version': {
                'micro': 4,
                'releaselevel': 'final',
                'serial': 0,
                'minor': 6,
                'major': 3
            },
            'executable': '/usr/bin/python3.6'
        }
    }

# Generated at 2022-06-25 00:28:57.768397
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-25 00:30:10.374303
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert isinstance(python_fact_collector_1.collect(module=None, collected_facts=None), dict)

# Generated at 2022-06-25 00:30:18.959358
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector_obj = PythonFactCollector()
    collect_result = py_fact_collector_obj.collect()
    assert type(collect_result) is dict
    assert 'python' in collect_result
    assert type(collect_result['python']) is dict
    assert 'version' in collect_result['python']
    assert 'version_info' in collect_result['python']
    assert 'executable' in collect_result['python']
    assert 'has_sslcontext' in collect_result['python']
    assert 'type' in collect_result['python']

# Generated at 2022-06-25 00:30:27.948367
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        import ssl
    except ImportError:
        ssl_module_found = False
    else:
        ssl_module_found = True

    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0 is not None
    collected_facts = {}
    collected_facts['python'] = {'version': {'major': 2, 'minor': 6, 'micro': 0, 'releaselevel': 'final', 'serial': 0},
                                 'version_info': [2, 6, 0, 'final', 0], 'executable': '/usr/bin/python2.6',
                                 'has_sslcontext': ssl_module_found}

    python_fact_collector_0.collect(collected_facts=collected_facts)

# Generated at 2022-06-25 00:30:33.559153
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Test with invalid data type for argument 'module'
    # test_module = 9999
    # python_fact_collector_0.collect(module=test_module)

    # Test with invalid data type for argument 'collected_facts'
    # test_collected_facts = 9999
    # python_fact_collector_0.collect(collected_facts=test_collected_facts)

    test_module = None
    test_collected_facts = None
    res = python_fact_collector_0.collect(module=test_module, collected_facts=test_collected_facts)
    assert type(res) is dict

# Generated at 2022-06-25 00:30:35.757691
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py2 = PythonFactCollector()
    res_0 = py2.collect()
    assert res_0 is not None
    assert 'python' in res_0
    assert 'version' in res_0['python']
    assert 'type' in res_0['python']


# Generated at 2022-06-25 00:30:39.798274
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:30:44.770228
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    assert type(python_fact_collector_0.collect()) == dict


# Generated at 2022-06-25 00:30:46.727894
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector_collect_collector = PythonFactCollector()
    PythonFactCollector_collect_result = PythonFactCollector_collect_collector.collect(module=None, collected_facts=None)
    print(PythonFactCollector_collect_result)

# Generated at 2022-06-25 00:30:50.007521
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Input parameters:
    python_fact_collector_1 = PythonFactCollector()

    # Performance test with 10000 iterations
    import datetime
    x = datetime.datetime.utcnow()
    for i in range(10000):
        python_fact_collector_1.collect()
    print(datetime.datetime.utcnow() - x)


# Generated at 2022-06-25 00:30:52.277997
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test = PythonFactCollector()
    result = test.collect()
    assert result is not None


# Generated at 2022-06-25 00:33:23.263140
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:33:32.579623
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert (python_fact_collector_0.collect() == {
        'python': {
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'CPython',
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': sys.version_info,
            'executable': sys.executable
        }})
