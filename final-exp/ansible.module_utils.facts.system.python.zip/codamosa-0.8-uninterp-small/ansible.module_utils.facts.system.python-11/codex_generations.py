

# Generated at 2022-06-25 00:23:33.696193
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    assert type(python_fact_collector_0.collect(collected_facts)) is dict

# Generated at 2022-06-25 00:23:38.629342
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    output = python_fact_collector_1.collect()
    assert 'python' in output
    assert 'version' in output['python']
    assert 'version_info' in output['python']
    assert 'executable' in output['python']
    assert 'type' in output['python']
    assert 'has_sslcontext' in output['python']


# Generated at 2022-06-25 00:23:41.204942
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert 'version' in result['python']

# Generated at 2022-06-25 00:23:42.563394
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    assert python_fact_collector_1.collect()

# Generated at 2022-06-25 00:23:44.339675
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 00:23:46.557241
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:23:54.604824
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # We need to mock this because the existence of ssl.create_default_context() only shows up in Python 2.7.9 and later
    # This can be removed when we drop support for Python 2.6
    class MockSSL(object):
        class MockSSLContext(object):
            pass

        def create_default_context():
            return MockSSLContext()

    python_fact_collector_0 = PythonFactCollector()

# Generated at 2022-06-25 00:24:00.802303
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 13, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 13, 'final', 0], 'executable': '/usr/bin/python', 'type': 'CPython', 'has_sslcontext': True}}

# Generated at 2022-06-25 00:24:01.670554
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:24:03.708351
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts = python_fact_collector_1.collect()
    assert 'python' in python_facts

# Generated at 2022-06-25 00:24:12.442464
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collect_return_value = python_fact_collector_0.collect()
    assert collect_return_value == {'python': {'type': 'CPython', 'has_sslcontext': True, 'version_info': [3, 5, 6, 'final', 0], 'version': {'releaselevel': 'final', 'serial': 0, 'major': 3, 'minor': 5, 'micro': 6}, 'executable': '/usr/bin/python3.5'}}

# Generated at 2022-06-25 00:24:23.129420
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''test_PythonFactCollector_collect unit test'''
    # Retrieve object attributes and test method collect of class PythonFactCollector
    python_fact_collector_0 = PythonFactCollector()
    ret = python_fact_collector_0.collect()
    assert ret['python']['version']['major'] == sys.version_info[0]
    assert ret['python']['version']['minor'] == sys.version_info[1]
    assert ret['python']['version']['micro'] == sys.version_info[2]
    assert ret['python']['version']['releaselevel'] == sys.version_info[3]
    assert ret['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-25 00:24:29.719045
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert isinstance(result, dict)
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable


# Generated at 2022-06-25 00:24:32.392663
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:24:34.336488
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    print (python_fact_collector_0.collect())

# Generated at 2022-06-25 00:24:39.496910
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    :avocado: tags=test_PythonFactCollector_collect
    """
    # instantiating an object with module parametrization
    python_fact_collector_0 = PythonFactCollector()

    # Calling method collect of PythonFactCollector object with parametrization
    python_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:24:45.702585
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print('Testing collect...')

    # Passing empty fact
    python_fact_collector_0 = PythonFactCollector()
    collected_facts_before = dict()
    collected_facts_after = python_fact_collector_0.collect(collected_facts=collected_facts_before)

    # Asserting collected_facts_after is empty or not
    assert collected_facts_after == {} or collected_facts_after is not None or collected_facts_after is not {}

# Generated at 2022-06-25 00:24:47.160854
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:50.556391
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = python_fact_collector_0.collect()

    if var_1['python'] != var_0['python']:
       raise AssertionError

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:25:00.290837
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    retrieved_facts=PythonFactCollector().collect()
    expected_facts=dict()
    expected_facts['python'] = {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }

# Generated at 2022-06-25 00:25:10.229839
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect(module=None, collected_facts=None)
    assert result is not None


# Generated at 2022-06-25 00:25:12.322297
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Unit test for method collect
    '''

    # Test for with all no args

    python_fact_collector_1 = PythonFactCollector()


# Generated at 2022-06-25 00:25:19.868251
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    assert fc.collect() == {
        'python': {
            'version': {
                'major': 2,
                'minor': 7,
                'micro': 12,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 12, 'final', 0],
            'executable': '/usr/bin/python',
            'has_sslcontext': True,
            'type': 'CPython'
        }
    }

# Generated at 2022-06-25 00:25:28.317969
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # TODO: replace by pytest
    # Declare the parameters for each test case
    # test_case_0
    # test_case_1
    test_case_0_python_fact_collector_0_module_0 = None
    test_case_0_python_fact_collector_0_collected_facts_0 = None
    # test_case_2
    test_case_2_python_fact_collector_0_module_0 = None
    test_case_2_python_fact_collector_0_collected_facts_0 = None
    # test_case_3
    test_case_3_python_fact_collector_0_module_0 = None
    test_case_3_python_fact_collector_0_collected_facts_0 = None

    # Declare the

# Generated at 2022-06-25 00:25:30.043680
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert callable(python_fact_collector_0.collect)

# Generated at 2022-06-25 00:25:34.207501
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # First run
    python_fact_collector_a = PythonFactCollector()
    python_fact_collector_a.collect()
    # Second run
    python_fact_collector_b = PythonFactCollector()
    python_fact_collector_b.collect()

# Generated at 2022-06-25 00:25:42.432270
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Construct ansible_facts which matches the expected result
    ansible_facts = {
        'python': {
            'executable': '/usr/local/bin/python',
            'type': 'CPython',
            'version': {
                'micro': 3,
                'major': 2,
                'minor': 7,
                'releaselevel': 'final',
                'serial': 0
            },
            'has_sslcontext': False,
            'version_info': [
                2,
                7,
                3,
                'final',
                0
            ]
        }
    }

    # Get the facts
    python_facts = PythonFactCollector().collect()

    # Test if the two are equals
    assert python_facts['python'] == ansible_facts['python']

# Generated at 2022-06-25 00:25:50.846472
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # create an instance of the PythonFactCollector class
    python_fact_collector_0 = PythonFactCollector()

    # collect facts with the instance
    facts = python_fact_collector_0.collect()

    # check that the value of the version_info fact is a list and of length 5
    assert isinstance(facts['python']['version_info'], list)
    assert len(facts['python']['version_info']) == 5
    
    # check that the value of the major verion fact equals the element at position 0 of the version_info fact
    assert facts['python']['version']['major'] == facts['python']['version_info'][0]
    # check that the value of the minor verion fact equals the element at position 1 of the version_info fact

# Generated at 2022-06-25 00:25:57.393691
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact = python_fact_collector_1.collect()
    assert isinstance(python_fact, dict)
    assert 'python' in python_fact
    assert isinstance(python_fact['python'], dict)
    assert 'version' in python_fact['python']
    assert isinstance(python_fact['python']['version'], dict)
    assert 'major' in python_fact['python']['version']
    assert 'minor' in python_fact['python']['version']
    assert 'micro' in python_fact['python']['version']
    assert 'releaselevel' in python_fact['python']['version']
    assert 'serial' in python_fact['python']['version']
    assert 'version_info' in python_

# Generated at 2022-06-25 00:26:02.711472
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    print(python_fact_collector_0.collect())


# Generated at 2022-06-25 00:26:19.020660
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:26:21.896297
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    assert python_fact_collector_0.collect()


if __name__ == "__main__":
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:26:28.544480
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == { 'python': { 'version': { 'minor': 7, 'releaselevel': 'final', 'major': 3, 'micro': 9 }, 'type': 'CPython', 'version_info': [3, 7, 9, 'final', 0], 'has_sslcontext': True, 'executable': '/usr/bin/python3' } }


# Generated at 2022-06-25 00:26:33.020993
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert ('python' in python_fact_collector_0.collect()) is True
    assert ('version' in python_fact_collector_0.collect()['python']) is True
    assert ('executable' in python_fact_collector_0.collect()['python']) is True

# Generated at 2022-06-25 00:26:37.327624
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    result = python_fact_collector_0.collect(collected_facts=collected_facts)
    assert result.get('python').get('type') is None


# Generated at 2022-06-25 00:26:44.721635
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_1 = PythonFactCollector()

    assert python_fact_collector_1.collect() == {'python': {'version': {'major': 3, 'minor': 5, 'micro': 0, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 5, 0, 'final', 0], 'executable': '/usr/bin/python', 'type': 'CPython', 'has_sslcontext': True}}

# Generated at 2022-06-25 00:26:51.989683
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'type': 'CPython', 'version': {'releaselevel': 'final', 'major': 2, 'minor': 7, 'serial': 0, 'micro': 11}, 'version_info': [2, 7, 11, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False}}


# Generated at 2022-06-25 00:26:57.832389
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    assert 'python' in facts

    python_facts = facts['python']
    assert 'version' in python_facts
    assert 'version_info' in python_facts
    assert 'major' in python_facts['version']
    assert 'minor' in python_facts['version']
    assert 'micro' in python_facts['version']
    assert 'releaselevel' in python_facts['version']
    assert 'serial' in python_facts['version']
    assert 'executable' in python_facts
    assert 'has_sslcontext' in python_facts
    assert 'type' in python_facts

# Generated at 2022-06-25 00:26:58.659402
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:27:04.335812
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    expected = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }

    assert expected == pfc.collect()


# Generated at 2022-06-25 00:27:44.393318
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Case 1: Python 2.6
    sys.version_info = (2, 6)
    python_fact_collector_1 = PythonFactCollector()
    python_facts_1 = python_fact_collector_1.collect()
    # print(python_facts_1)
    assert python_facts_1['python']['version']['major'] == 2
    assert python_facts_1['python']['version']['minor'] == 6
    assert python_facts_1['python']['version']['micro'] == 0
    assert python_facts_1['python']['version']['releaselevel'] == ''
    assert python_facts_1['python']['version']['serial'] == 0

# Generated at 2022-06-25 00:27:48.976282
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'type': 'CPython', 'version_info': [2, 7, 13, 'final', 0], 'version': {'micro': 13, 'minor': 7, 'releaselevel': 'final', 'serial': 0, 'major': 2}, 'executable': '/usr/bin/python', 'has_sslcontext': True}}


# Generated at 2022-06-25 00:27:51.582210
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test method collect of class PythonFactCollector
    """
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    if result is not None:
        assert len(result) == 1
        assert result['python'] is not None
    else:
        assert False


# Generated at 2022-06-25 00:27:54.249993
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts = python_fact_collector_0.collect()
    assert isinstance(facts, dict)


# Generated at 2022-06-25 00:27:58.063277
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:06.730844
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts['python']['version']['major'] == 3
    assert python_facts['python']['version']['minor'] == 5
    assert python_facts['python']['version']['micro'] == 2
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert python_facts['python']['version']['serial'] == 0
    assert python_facts['python']['version_info'] == [3, 5, 2, 'final', 0]
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLC

# Generated at 2022-06-25 00:28:14.966619
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    python_facts = python_fact_collector.collect()

    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert isinstance(python_facts['python'], dict)

    assert 'version' in python_facts['python']
    assert isinstance(python_facts['python']['version'], dict)
    assert 'major' in python_facts['python']['version']
    assert isinstance(python_facts['python']['version']['major'], int)
    assert 'minor' in python_facts['python']['version']
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert 'micro' in python_facts['python']['version']

# Generated at 2022-06-25 00:28:24.874716
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Setup test case
    python_fact_collector_0 = PythonFactCollector()

    # Test collect method
    result = python_fact_collector_0.collect()

    # Verify the result
    assert(result == {})

    # Setup test case
    python_fact_collector_0 = PythonFactCollector()

    # Test collect method
    result = python_fact_collector_0.collect()

    # Verify the result
    assert(result == {})

    # Setup test case
    python_fact_collector_0 = PythonFactCollector()

    # Test collect method
    result = python_fact_collector_0.collect()

    # Verify the result
    assert(result == {})



# Generated at 2022-06-25 00:28:30.873276
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['type']
    assert python_facts['python']['version']
    assert python_facts['python']['version_info']
    assert python_facts['python']['executable']
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-25 00:28:32.627376
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-25 00:29:46.127636
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector() # instantiate a new collector object
    collected_facts_1 = {}
    python_fact_collector_1.collect(collected_facts_1)
    assert 'python' in collected_facts_1
    assert 'version' in collected_facts_1['python']
    assert 'major' in collected_facts_1['python']['version']
    assert 'minor' in collected_facts_1['python']['version']
    assert 'micro' in collected_facts_1['python']['version']
    assert 'releaselevel' in collected_facts_1['python']['version']
    assert 'serial' in collected_facts_1['python']['version']
    assert 'type' in collected_facts_1['python']
    assert 'executable' in collected

# Generated at 2022-06-25 00:29:50.618923
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # This will fail unless we have a version of python that provides
    # the SSLContext class
    if HAS_SSLCONTEXT:
        assert(PythonFactCollector().collect()['python']['has_sslcontext'])
    else:
        assert(not PythonFactCollector().collect()['python']['has_sslcontext'])

# Generated at 2022-06-25 00:29:51.986615
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:29:59.903296
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    ver = str(sys.version_info[0]) + '.' + str(sys.version_info[1]) + '.' + str(sys.version_info[2]) + '.' + str(sys.version_info[3]) + str(sys.version_info[4])
    assert python_fact_collector_1.collect()['python']['version'] == ver
    assert python_fact_collector_1.collect()['python']['version_info'] == list(sys.version_info)
    assert python_fact_collector_1.collect()['python']['executable'] == sys.executable
    assert python_fact_collector_1.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-25 00:30:07.939452
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts_1 = python_fact_collector_1.collect()
    assert python_facts_1['python']['version']['major'] == sys.version_info[0], \
        "The Python version major (python['version']['major']) is not equal"
    assert python_facts_1['python']['version']['minor'] == sys.version_info[1], \
        "The Python version minor (python['version']['minor']) is not equal"
    assert python_facts_1['python']['version']['micro'] == sys.version_info[2], \
        "The Python version micro (python['version']['micro']) is not equal"

# Generated at 2022-06-25 00:30:09.219092
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector.collect() == None

# Generated at 2022-06-25 00:30:16.242490
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    ansible_facts_0 = {}
    ansible_facts_0['system'] = {
        'distribution': 'RedHat',
        'distribution_major_version': '7',
        'distribution_version': '7.1'
      }
    ansible_facts_0['ansible_python'] = {
        'version_info': [
            2,
            7,
            5
          ]
      }
    ansible_facts_0['ansible_system'] = 'Linux'
    ansible_facts_0['ansible_selinux'] = {
        'status': 'enabled'
      }
    ansible_facts_0['ansible_ssh_user'] = 'ansibler'

# Generated at 2022-06-25 00:30:19.431270
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = set()
    python_fact_collector_1.collect()

    # Check whether the result from 'collect' function is equal to
    # "set()" or not
    assert result == set()


# Generated at 2022-06-25 00:30:23.530064
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_collect = PythonFactCollector()
    assert isinstance(python_fact_collector_collect.collect(), dict)

# Generated at 2022-06-25 00:30:30.823754
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_1 = PythonFactCollector()
    python_facts_result_1 = python_fact_collector_1.collect()
    assert python_facts_result_1 == {
        "python": {
            "version": {
                "major": 2,
                "micro": 0,
                "releaselevel": "final",
                "serial": 0,
                "minor": 7
            },
            "version_info": [
                2,
                7,
                0,
                'final',
                0
            ],
            "executable": '/usr/bin/python',
            "has_sslcontext": False,
            "type": "CPython"
        }
    }



# Generated at 2022-06-25 00:32:55.790551
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect(collected_facts=None)
    assert python_facts['python']['version']['major'] == 2

# Generated at 2022-06-25 00:33:02.715493
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    if python_fact_collector_0.collect() == {'python': {'version': {'releaselevel': 'final', 'minor': 7, 'micro': 5, 'major': 3, 'serial': 0}, 'executable': '/opt/ansible/bin/python', 'type': 'CPython', 'version_info': [3, 7, 5, 'final', 0], 'has_sslcontext': False}}:
        return True
    else:
        return None


# Generated at 2022-06-25 00:33:07.528001
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'version': {'major': 3, 'minor': 4, 'micro': 4, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 4, 4, 'final', 0], 'executable': '/anaconda3/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}


# Generated at 2022-06-25 00:33:11.714085
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()
    assert isinstance(python_facts_0, dict)

# Generated at 2022-06-25 00:33:14.586589
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of class PythonFactCollector
    python_fact_collector_0 = PythonFactCollector()

    # Call method 'collect' with arguments:
    # (name='python')
    print(python_fact_collector_0.collect(name='python'))

# Generated at 2022-06-25 00:33:21.562259
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector_0 = PythonFactCollector()
    python_facts = fact_collector_0.collect()
    assert (python_facts['python']['version']['major'] == 3)
    assert (python_facts['python']['version']['minor'] == 5)
    assert (python_facts['python']['version']['micro'] == 1)
    assert (python_facts['python']['version']['releaselevel'] == 'final')
    assert (python_facts['python']['version']['serial'] == 0)
    assert (python_facts['python']['has_sslcontext'] == True)

# Generated at 2022-06-25 00:33:23.318612
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert 'python' in list(python_fact_collector_0.collect().keys())

# Generated at 2022-06-25 00:33:33.321700
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    pf = python_fact_collector_0.collect()

    assert pf['python']['version']['major'] == sys.version_info[0]
    assert pf['python']['version']['minor'] == sys.version_info[1]
    assert pf['python']['version']['micro'] == sys.version_info[2]
    assert pf['python']['version']['releaselevel'] == sys.version_info[3]
    assert pf['python']['version']['serial'] == sys.version_info[4]