

# Generated at 2022-06-25 00:23:35.022297
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:23:40.610551
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result == dict(python=dict(version=dict(major=3, minor=5, micro=1, releaselevel='final', serial=0), type='CPython', version_info=[3, 5, 1, 'final', 0], executable='/home/travis/virtualenv/python3.5.1/bin/python', has_sslcontext=True))


# Generated at 2022-06-25 00:23:43.817413
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['type'] == sys.implementation.name

# Generated at 2022-06-25 00:23:45.634685
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() is not None


# Generated at 2022-06-25 00:23:54.090943
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python

# Generated at 2022-06-25 00:23:55.988910
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_collect_0 = PythonFactCollector()

    # Invoke method collect of PythonFactCollector
    python_fact_collector_collect_0.collect(None, {})

# Generated at 2022-06-25 00:23:59.890989
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts_0 = {}
    python_facts_0 = python_fact_collector_0.collect()
    assert 'python' in python_facts_0


# Generated at 2022-06-25 00:24:01.431580
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:07.115339
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print("[*] Testing PythonFactCollector class: 'collect' method")

    python_fact_collector = PythonFactCollector()
    test_python_fact_collector_collect = python_fact_collector.collect()
    expected_results = {'python': {'executable': '/usr/bin/python', 'version': {'micro': 4, 'releaselevel': 'final', 'minor': 7, 'serial': 0, 'major': 2}, 'version_info': [2, 7, 4, 'final', 0], 'type': 'CPython', 'has_sslcontext': True}}
    actual_results = test_python_fact_collector_collect['python']


# Generated at 2022-06-25 00:24:09.630101
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    print("Test print: " + repr(result))
    assert result != None


# Generated at 2022-06-25 00:24:16.786332
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    res = python_fact_collector_0.collect()
    assert res == {'python': {'version': {'major': 3, 'minor': 5, 'micro': 1, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 5, 1, 'final', 0], 'executable': '', 'has_sslcontext': False, 'type': None}}

# Generated at 2022-06-25 00:24:21.751032
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    collected_facts = python_fact_collector_1.collect()
    assert type(collected_facts) == dict
    assert collected_facts['python']['version']['major'] > 0


# Generated at 2022-06-25 00:24:27.382490
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector_collect_actual_result = PythonFactCollector().collect(None, None)
    PythonFactCollector_collect_expected_result = {
        'python': {
            'executable': '/usr/bin/python',
            'has_sslcontext': True,
            'version': {
                'major': 2,
                'micro': 7,
                'minor': 14,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 14, 'final', 0]
        }
    }
    assert PythonFactCollector_collect_expected_result == PythonFactCollector_collect_actual_result


# Generated at 2022-06-25 00:24:29.516066
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:24:36.140658
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:24:40.302174
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test collect method."""
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:24:42.892601
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    collected_facts = {}
    # omitted, not a unit test
    # fc.collect(collected_facts=collected_facts)

# Generated at 2022-06-25 00:24:49.982345
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result == {'python': {'type': 'CPython',
                                 'version': {'micro': 5,
                                             'minor': 9,
                                             'releaselevel': 'final',
                                             'major': 2,
                                             'serial': 0},
                                 'has_sslcontext': True,
                                 'version_info': [2,
                                                  9,
                                                  5,
                                                  'final',
                                                  0],
                                 'executable': '/usr/bin/python'}}

# Generated at 2022-06-25 00:24:59.649069
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    data = {}
    data = python_fact_collector_0.collect(module=None, collected_facts=None)
    assert data['python']['version']['major'] == sys.version_info[0]
    assert data['python']['version']['minor'] == sys.version_info[1]
    assert data['python']['version']['micro'] == sys.version_info[2]
    assert data['python']['version']['releaselevel'] == sys.version_info[3]
    assert data['python']['version']['serial'] == sys.version_info[4]
    assert data['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:25:08.292896
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    collected_facts_1 = python_fact_collector_1.collect()
    python_fact_collector_2 = PythonFactCollector()
    collected_facts_2 = python_fact_collector_2.collect()
    assert isinstance(collected_facts_1, dict), 'collected_facts_1 is not an instance of the dictionary type'
    assert isinstance(collected_facts_2, dict), 'collected_facts_2 is not an instance of the dictionary type'

# Generated at 2022-06-25 00:25:24.566663
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-25 00:25:26.085684
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    results = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:27.879155
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect()

# Generated at 2022-06-25 00:25:29.623743
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() is not None

# Generated at 2022-06-25 00:25:40.181771
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:50.435455
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result
    print("\n======\n")
    assert len(result.keys()) == 1
    print("\n======\n")
    assert result['python']
    print("\n======\n")
    assert result['python']['version']
    print("\n======\n")
    assert result['python']['version_info']
    print("\n======\n")
    assert result['python']['type']
    print("\n======\n")
    assert result['python']['executable']
    print("\n======\n")
    assert result['python']['has_sslcontext']
    print("\n======\n")

# Generated at 2022-06-25 00:25:56.625724
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1_out = python_fact_collector_1.collect()
    assert 'python' in python_fact_collector_1_out
    assert 'version' in python_fact_collector_1_out['python']
    assert 'major' in python_fact_collector_1_out['python']['version']
    assert 'minor' in python_fact_collector_1_out['python']['version']
    assert 'micro' in python_fact_collector_1_out['python']['version']
    assert 'releaselevel' in python_fact_collector_1_out['python']['version']
    assert 'serial' in python_fact_collector_1_out['python']['version']


# Generated at 2022-06-25 00:25:57.424392
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect()


# Generated at 2022-06-25 00:26:02.994086
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    ret = python_fact_collector_1.collect()
    assert type(ret) == dict

# Generated at 2022-06-25 00:26:04.346074
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:26:19.765325
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    tf0 = PythonFactCollector()
    tf0.collect()

# Generated at 2022-06-25 00:26:21.098277
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector_obj = PythonFactCollector()
    assert PythonFactCollector_obj.collect()


# Generated at 2022-06-25 00:26:29.590609
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert 'python_sys_executable' in python_facts
    assert 'python_version_info' in python_facts
    assert 'python_version' in python_facts
    assert 'python_major' in python_facts
    assert 'python_minor' in python_facts
    assert 'python_micro' in python_facts
    assert 'python_releaselevel' in python_facts
    assert 'python_serial' in python_facts
    assert 'python_type' in python_facts
    assert 'python_has_sslcontext' in python_facts

# Generated at 2022-06-25 00:26:34.844414
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == {'python': {'executable': '/home/me/anaconda3/bin/python', 'has_sslcontext': True, 'type': 'CPython', 'version': {'major': 3, 'micro': 5, 'minor': 2, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 2, 5, 'final', 0]}}

# Generated at 2022-06-25 00:26:35.622231
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert(True)



# Generated at 2022-06-25 00:26:37.536765
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    results = python_fact_collector_0.collect()
    assert 'python' in results


# Generated at 2022-06-25 00:26:48.520196
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts = python_fact_collector_0.collect()
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version_info'], list)

# Generated at 2022-06-25 00:26:55.152793
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact = PythonFactCollector()
    collected_facts = {}
    result = fact.collect(collected_facts=collected_facts)
    assert isinstance(result, dict)
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']
    assert len(collected_facts) == 0

# Generated at 2022-06-25 00:26:59.976718
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    returned_python_facts = python_fact_collector_1.collect()
    assert isinstance(returned_python_facts, dict) is True


# Generated at 2022-06-25 00:27:01.075467
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:17.145288
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of PythonFactCollector
    python_fact_collector_0 = PythonFactCollector()
    # Call the method under test
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:24.879469
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # instantiate the object
    python_fact_collector_0 = PythonFactCollector()
    # call the method
    var_0 = python_fact_collector_0.collect()

    assert(var_0 == {
        "python": {
            "type": sys.implementation.name,
            "executable": sys.executable,
            "version": {
                "micro": sys.version_info.micro,
                "releaselevel": sys.version_info.releaselevel,
                "serial": sys.version_info.serial,
                "major": sys.version_info.major,
                "minor": sys.version_info.minor
            },
            "has_sslcontext": HAS_SSLCONTEXT,
            "version_info": list(sys.version_info)
        }
    })

# Generated at 2022-06-25 00:27:29.965913
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 15, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 15, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False}}


# Generated at 2022-06-25 00:27:31.067171
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()

# Generated at 2022-06-25 00:27:40.769314
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_ver = sys.version_info
    py_exec = sys.executable

    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1['python']['version_info'] == [py_ver[0],py_ver[1],py_ver[2],py_ver[3],py_ver[4]]
    assert var_1['python']['executable'] == py_exec
    assert var_1['python']['has_sslcontext'] == HAS_SSLCONTEXT
try:
    # Check if we have SSLContext support
    from ssl import create_default_context, SSLContext
    del create_default_context
    del SSLContext
    HAS_SSLCONTEXT = True
except ImportError:
    HAS

# Generated at 2022-06-25 00:27:41.934796
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:27:43.296859
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:44.698563
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:47.160095
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        test_case_0()
        print('Unit test for method collect of class PythonFactCollector passed')
    except Exception as err:
        print('Unit test for method collect of class PythonFactCollector failed')
        print(err)

# Unit test PythonFactCollector

# Generated at 2022-06-25 00:27:49.272979
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()



# Generated at 2022-06-25 00:28:19.409031
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:28:27.523981
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_ver = '%d.%d' % (sys.version_info.major, sys.version_info.minor)
    expected_output = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'CPython',
            'version': {
                'major': sys.version_info.major,
                'minor': sys.version_info.minor,
                'micro': sys.version_info.micro,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [sys.version_info.major, sys.version_info.minor, sys.version_info.micro, 'final', 0]
        }
    }


# Generated at 2022-06-25 00:28:30.442790
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:28:31.692825
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:33.125886
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-25 00:28:35.259935
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 is not None


# Generated at 2022-06-25 00:28:39.713179
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1['python']['version']['major'] == 3
    assert var_1['python']['version']['minor'] == 8
    assert var_1['python']['version']['micro'] == 1
    assert var_1['python']['version']['releaselevel'] == 'final'
    assert var_1['python']['version']['serial'] == 0



# Generated at 2022-06-25 00:28:41.247073
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test case 0
    python_fact_collector = PythonFactCollector()
    var = python_fact_collector.collect()



# Generated at 2022-06-25 00:28:47.958247
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['major'] == sys.version_info[0]
    assert var_0['python']['version']['minor'] == sys.version_info[1]
    assert var_0['python']['version']['micro'] == sys.version_info[2]
    assert var_0['python']['version']['releaselevel'] == sys.version_info[3]
    assert var_0['python']['version']['serial'] == sys.version_info[4]
    assert var_0['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:28:48.982133
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:29:54.915734
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-25 00:29:56.432432
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()


# Method to test class PythonFactCollector

# Generated at 2022-06-25 00:30:04.801316
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Init PythonFactCollector instance
    python_fact_collector_0 = PythonFactCollector()
    # Call collect method
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python.version': {'releaselevel': 'final', 'major': 2, 'micro': 7, 'minor': 13, 'serial': 0}, 'python.version_info': [2, 7, 13, 'final', 0], 'python.executable': '/usr/bin/python', 'python.type': 'CPython', 'python.has_sslcontext': False}


# Generated at 2022-06-25 00:30:09.792595
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'version': {'major': 3, 'minor': 5, 'micro': 2, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 5, 2, 'final', 0], 'executable': '/usr/bin/python3', 'has_sslcontext': True, 'type': 'CPython'}}


# Generated at 2022-06-25 00:30:15.616600
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['major'] == sys.version_info[0]
    assert var_0['python']['version']['minor'] == sys.version_info[1]
    assert var_0['python']['version']['micro'] == sys.version_info[2]
    assert var_0['python']['version']['releaselevel'] == sys.version_info[3]
    assert var_0['python']['version']['serial'] == sys.version_info[4]
    assert var_0['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:30:18.095756
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:30:22.621986
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_0 = PythonFactCollector()
    var_0 = py_0.collect()



# Generated at 2022-06-25 00:30:24.348670
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:30:28.736981
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        # Run a base test
        test_case_0()

    except Exception as exception_in:
        # If we get an exception, dump out all the args
        print(str(exception_in) + ' ' + str(exception_in.args))


# Generated at 2022-06-25 00:30:30.043250
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()



# Generated at 2022-06-25 00:32:45.638356
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Input parameters
    python_fact_collector_0 = PythonFactCollector()

    # Invoke method
    var_0 = python_fact_collector_0.collect()

    return var_0

# Generated at 2022-06-25 00:32:50.071123
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    assert var_0 == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 12, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 12, 'final', 0], 'has_sslcontext': False, 'executable': '/usr/bin/python', 'type': None}}



# Generated at 2022-06-25 00:32:54.236634
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 is not None


# Generated at 2022-06-25 00:33:03.736411
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert isinstance(python_fact_collector_1.collect(), dict)
    assert isinstance(python_fact_collector_1.collect()['python'], dict)
    assert 'has_sslcontext' in python_fact_collector_1.collect()['python']
    assert 'version' in python_fact_collector_1.collect()['python']
    assert 'version_info' in python_fact_collector_1.collect()['python']
    assert 'executable' in python_fact_collector_1.collect()['python']
    assert 'type' in python_fact_collector_1.collect()['python']


# Generated at 2022-06-25 00:33:09.272498
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-25 00:33:11.346600
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Run the collect method of PythonFactCollector
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()

# Generated at 2022-06-25 00:33:17.901066
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    # Checks type of python_facts['python']['version']
    assert isinstance(var_0.get('python').get('version'), dict)
    # Checks type of python_facts['python']['version_info']
    assert isinstance(var_0.get('python').get('version_info'), list)
    # Checks type of python_facts['python']['executable']
    assert isinstance(var_0.get('python').get('executable'), str)
    # Checks type of python_facts['python']['has_sslcontext']
    assert isinstance(var_0.get('python').get('has_sslcontext'), bool)
    # Checks type of python_facts['python

# Generated at 2022-06-25 00:33:19.702905
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert isinstance(var_1, bool)
    assert True == var_1

# Generated at 2022-06-25 00:33:27.974153
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    python_fact_collector_1.collect()
    if 'python' in var_1:
        var_1 = var_1['python']

    # Assert that compare_dict is properly comparing the version data
    assert_1 = (var_1['version_info'][0] == var_1['version']['major'])
    assert_1 = (var_1['version_info'][1] == var_1['version']['minor'])
    assert_1 = (var_1['version_info'][2] == var_1['version']['micro'])

# Generated at 2022-06-25 00:33:32.977366
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

    python_fact_collector_2 = PythonFactCollector()
    var_2 = python_fact_collector_2.collect()
