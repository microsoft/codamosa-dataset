

# Generated at 2022-06-25 00:23:35.775989
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    ansible_facts = dict()
    f.collect(collected_facts=ansible_facts)
    assert 'python' in ansible_facts
    assert 'version' in ansible_facts['python']
    assert 'version_info' in ansible_facts['python']

# Generated at 2022-06-25 00:23:41.341726
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 14, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 14, 'final', 0], 'executable': '/usr/local/bin/python', 'has_sslcontext': False, 'type': None}}, python_fact_collector_0.collect()


# Generated at 2022-06-25 00:23:42.384182
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

# Generated at 2022-06-25 00:23:44.070077
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:23:52.826314
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-25 00:23:55.964380
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    collected_facts = {}
    collected_facts['ansible_facts'] = {}
    python_fact_collector_1.collect(collected_facts=collected_facts)
    assert collected_facts['ansible_facts']['python']['version']['major'] == 2


# Generated at 2022-06-25 00:24:00.335217
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_collect_0 = python_fact_collector_0.collect()
    assert python_fact_collector_collect_0 == {'python': {'version': {'micro': 8, 'major': 2, 'releaselevel': 'final', 'minor': 7, 'serial': 0}, 'version_info': [2, 7, 8, 'final', 0], 'executable': '/opt/local/Library/Frameworks/Python.framework/Versions/2.7/Resources/Python.app/Contents/MacOS/Python', 'type': 'CPython'}}



# Generated at 2022-06-25 00:24:03.354590
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    python_fact_collector_0.collect(collected_facts=collected_facts)
    assert len(collected_facts) == 1
    assert 'python' in collected_facts

# Generated at 2022-06-25 00:24:13.945963
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Tests PythonFactCollector.collect when major equals 0
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts['python']['version']['major'] == 0
    assert python_facts['python']['version_info'][0] == 0
    assert python_facts['python']['executable'] == 'n/a'

    # Tests PythonFactCollector.collect when major not equals 0
    python_fact_collector_1 = PythonFactCollector()
    python_facts = python_fact_collector_1.collect()
    assert python_facts['python']['version']['major'] is not 0
    assert python_facts['python']['version_info'] != [0]

# Generated at 2022-06-25 00:24:14.617365
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    c.collect()

# Generated at 2022-06-25 00:24:26.987089
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1_collect = python_fact_collector_1.collect()
    assert python_fact_collector_1_collect is not None
    assert type(python_fact_collector_1_collect) is dict
    assert len(python_fact_collector_1_collect) == 1
    assert 'python' in python_fact_collector_1_collect
    assert set(['python']).issubset(python_fact_collector_1_collect.keys())
    assert type(python_fact_collector_1_collect['python']) is dict
    assert len(python_fact_collector_1_collect['python']) == 5

# Generated at 2022-06-25 00:24:33.117340
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    python_facts_1 = python_fact_collector_1.collect()

    # Assert that the returned dict contains the key python
    assert 'python' in python_facts_1

    # Assert that the python key contains the key version
    assert 'version' in python_facts_1['python']

    # Assert that the python.version key contains the key major
    assert 'major' in python_facts_1['python']['version']

    # Assert that the python.version key contains the key minor
    assert 'minor' in python_facts_1['python']['version']

    # Assert that the python.version key contains the key micro
    assert 'micro' in python_facts_1['python']['version']

    # Assert that the python.

# Generated at 2022-06-25 00:24:34.508553
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert python_fact_collector_0.collect()



# Generated at 2022-06-25 00:24:45.056841
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    assert isinstance(python_fact_collector_1.collect(), dict)
    assert python_fact_collector_1.collect().get('python') is not None
    assert python_fact_collector_1.collect().get('python').get('version') is not None
    assert python_fact_collector_1.collect().get('python').get('version').get('major') is not None
    assert python_fact_collector_1.collect().get('python').get('version').get('minor') is not None
    assert python_fact_collector_1.collect().get('python').get('version').get('micro') is not None
    assert python_fact_collector_1.collect().get('python').get('version').get('releaselevel') is not None


# Generated at 2022-06-25 00:24:55.527361
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    collected_facts = python_fact_collector_1.collect()
    assert collected_facts['python']['version']['major'] == int(sys.version_info[0])
    assert collected_facts['python']['version']['minor'] == int(sys.version_info[1])
    assert collected_facts['python']['version']['micro'] == int(sys.version_info[2])
    assert collected_facts['python']['version']['releaselevel'] == str(sys.version_info[3])
    assert collected_facts['python']['version']['serial'] == int(sys.version_info[4])
    assert collected_facts['python']['version_info'] == list(sys.version_info)


# Generated at 2022-06-25 00:24:59.649804
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()
    assert python_fact_collector_0._fact_ids == {'python'}
    assert python_fact_collector_0.name == 'python'


# Generated at 2022-06-25 00:25:01.343559
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

# Generated at 2022-06-25 00:25:06.614471
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    ansible_facts = {}
    ansible_facts = python_fact_collector.collect(collected_facts=ansible_facts)
    assert isinstance(ansible_facts['python']['version'], dict)
    assert isinstance(ansible_facts['python']['version_info'], list)
    assert isinstance(ansible_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-25 00:25:08.393783
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:25:18.460201
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect(module = None)
    assert result['python']['executable'] == sys.executable
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result

# Generated at 2022-06-25 00:25:33.837502
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {'ansible_python_version': sys.version_info}
    expected_results = {'python': {'has_sslcontext': HAS_SSLCONTEXT, 'version_info': list(sys.version_info), 'executable': sys.executable, 'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'serial': sys.version_info[4], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3]}}}

# Generated at 2022-06-25 00:25:40.895296
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()['python']
    # assert False
    # assert python_facts['version']['major'] == 2 or python_facts['version']['major'] == 3
    # assert python_facts['version']['releaselevel'] == 'final'
    # assert python_facts['version']['serial'] == 0
    # assert python_facts['has_sslcontext']
    assert python_facts['executable'] == sys.executable
    assert python_facts['type'] == 'CPython'

# Generated at 2022-06-25 00:25:48.713422
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts = python_fact_collector_0.collect()
    assert facts == {'python': {'executable': '/usr/bin/python',
                                'has_sslcontext': True,
                                'type': 'CPython',
                                'version': {'major': 3,
                                            'minor': 5,
                                            'micro': 0,
                                            'releaselevel': 'final',
                                            'serial': 0},
                                'version_info': [3, 5, 0, 'final', 0]}}

# Generated at 2022-06-25 00:25:57.388277
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    task_vars = dict()
    result = dict()
    fact_module = dict(
        params=dict()
    )

    # Initialize the instance
    python_fact_collector = PythonFactCollector()

    # Invoke method
    result = python_fact_collector.collect(fact_module, task_vars, result)

    # Asserts
    assert result['python']['executable'] == sys.executable
    assert result['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:26:02.445347
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect()

# Generated at 2022-06-25 00:26:07.844231
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts == {'python': {'type': 'CPython', 'executable': sys.executable, 'version': {'releaselevel': 'final', 'micro': 2, 'minor': 7, 'major': 2, 'serial': 0}, 'has_sslcontext': True, 'version_info': [2, 7, 2, 'final', 0]}}

if __name__ == '__main__':
    pytest.main(sys.argv)

# Generated at 2022-06-25 00:26:12.400325
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect()


# Generated at 2022-06-25 00:26:19.585989
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_collect_0 = python_fact_collector_1.collect(module=None, collected_facts=None)
    assert python_collect_0 == {'python': {'type': 'CPython', 'version': {'major': 2, 'minor': 7, 'micro': 13, 'releaselevel': 'final', 'serial': 0}, 'has_sslcontext': True, 'version_info': [2, 7, 13, 'final', 0], 'executable': sys.executable}}

# Generated at 2022-06-25 00:26:20.644425
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

# Generated at 2022-06-25 00:26:25.567580
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()
    assert type(facts['python']['version']['major']) is int
    assert type(facts['python']['version']['minor']) is int
    assert type(facts['python']['version']['micro']) is int
    assert facts['python']['version']['releaselevel'] in ('alpha', 'beta', 'candidate', 'final')
    assert type(facts['python']['version']['serial']) is int
    assert type(facts['python']['executable']) is str
    assert type(facts['python']['has_sslcontext']) is bool
    assert type(facts['python']['type']) is str

# Generated at 2022-06-25 00:26:50.765865
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.python import PythonFactCollector


# Generated at 2022-06-25 00:26:58.548204
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_0 = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'type': sys.subversion[0],
        'has_sslcontext': HAS_SSLCONTEXT
    }
    python_1 = python_fact_collector_1.collect()['python']

    assert(python_0 == python_1)

# Generated at 2022-06-25 00:27:00.460896
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector_obj = PythonFactCollector()
    result = fact_collector_obj.collect()
    assert len(result)==1
    assert isinstance(result['python']['version_info'], list)

# Generated at 2022-06-25 00:27:02.251221
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    PythonFactCollector.collect(python_fact_collector_1, module=None, collected_facts=None)


# Generated at 2022-06-25 00:27:05.311034
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    return True

# Generated at 2022-06-25 00:27:14.803269
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_obj_0 = PythonFactCollector()
    returned_value = python_fact_collector_obj_0.collect()
    assert returned_value['python']['version']['major'] == 3 and returned_value['python']['version']['minor'] == 6 and returned_value['python']['version']['micro'] == 8 and returned_value['python']['version']['releaselevel'] == 'final' and returned_value['python']['version']['serial'] == 0 and returned_value['python']['version_info'] == [3, 6, 8, 'final', 0] and returned_value['python']['executable'] == '/usr/bin/python3' and returned_value['python']['type'] == 'CPython'

# Generated at 2022-06-25 00:27:22.089644
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts = python_fact_collector_0.collect(collected_facts={})
    assert 'python' in facts
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['version_info'][0] == sys.version_info[0]
    assert facts['python']['version_info'][1] == sys.version_info[1]
    assert facts['python']['version_info'][2] == sys.version_info[2]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-25 00:27:29.289081
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    # Test with ansible module
    collected_facts = None
    c.collect(module=None, collected_facts=None)

    # Test with ansible module and collected_facts
    c.collect(module=None, collected_facts=collected_facts)

    # Test with ansible module and collected_facts
    module = {'fail': 'foo', 'bool': True, 'int': 1, 'float': 1.1, 'list': [1,2], 'str': 'str', 'none': None}
    collected_facts = {'foo': 'bar'}
    c.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-25 00:27:32.935589
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    fact_collector_0 = PythonFactCollector()

    assert fact_collector_0.collect() == {'python': {'type': 'CPython', 'version': {'serial': 0, 'releaselevel': 'final', 'major': 2, 'micro': 7, 'minor': 12}, 'has_sslcontext': False, 'version_info': [2, 7, 12, 'final', 0], 'executable': '/usr/bin/python'}}


# Generated at 2022-06-25 00:27:37.410842
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 6
    assert result['python']['version']['micro'] == 0
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [3, 6, 0, 'final', 0]
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-25 00:27:57.465119
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0.get('python') is not None

# Generated at 2022-06-25 00:27:58.362311
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()
    var_0.collect()

# Generated at 2022-06-25 00:28:06.998379
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

# Generated at 2022-06-25 00:28:14.020807
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()
    assert var_1 == {u'python': {u'has_sslcontext': True, u'version_info': [2, 7, 12, u'final', 0], u'version': {u'releaselevel': u'final', u'minor': 7, u'major': 2, u'micro': 12, u'serial': 0}, u'type': u'CPython', u'executable': u'/opt/pyenvs/ansible-2.7/bin/python'}}


# Generated at 2022-06-25 00:28:18.927885
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    assert var_0['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }

    assert var_0['python']['version_info'] == [x for x in sys.version_info]

    assert var_0['python']['executable'] == sys.executable

    assert var_0['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-25 00:28:23.650024
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = python_fact_collector_0.collect()
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    var_2 = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:28:30.901273
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_1 = PythonFactCollector()
    var_2 = var_1.collect()
    assert 'python' in var_2, "collect(): expected var_2 to contain 'python'"

# Generated at 2022-06-25 00:28:33.355776
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


if __name__ == '__main__':

    # Unit tests for method collect of class PythonFactCollector
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:28:34.990751
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()
    var_1 = var_0.collect()


# Generated at 2022-06-25 00:28:38.098079
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_1 = PythonFactCollector()
    var_2 = var_1.collect()
    assert var_2 is not None
    print('Test succeeded: {}'.format(var_2))


if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:29:18.758522
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:29:19.920975
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:29:22.569009
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # parameters
    # run method
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Unit tests for class PythonFactCollector

# Generated at 2022-06-25 00:29:24.196124
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert "python" in var_1

# Generated at 2022-06-25 00:29:28.186169
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert python_fact_collector_0.collect() == {'python': {'has_sslcontext': True, 'version': {'micro': 4, 'releaselevel': 'final', 'major': 2, 'minor': 7, 'serial': 0}, 'version_info': [2, 7, 4, 'final', 0], 'executable': '/usr/bin/python', 'type': 'CPython'}}

# vim: set expandtab shiftwidth=4 softtabstop=4 tabstop=4

# Generated at 2022-06-25 00:29:31.312619
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_0 = python_fact_collector_1.collect()

test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:29:37.654332
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert (var_0['python']['version_info'][2] == sys.version_info[2])
    assert (var_0['python']['version']['minor'] == sys.version_info[1])
    assert (var_0['python']['version']['releaselevel'] == sys.version_info[3])
    assert (var_0['python']['version']['micro'] == sys.version_info[2])
    assert (var_0['python']['version']['serial'] == sys.version_info[4])
    assert (var_0['python']['version']['major'] == sys.version_info[0])
   

# Generated at 2022-06-25 00:29:40.434789
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Unit test data
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:29:41.131671
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:29:43.026795
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# vim: set et tabstop=4:

# Generated at 2022-06-25 00:31:03.286027
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    python_fact_collector_0.name
    python_fact_collector_0._fact_ids
    var_1 = python_fact_collector_0.collect()
    var_2 = python_fact_collector_0.collect()
    assert python_fact_collector_0.name == 'python'
    assert python_fact_collector_0._fact_ids == set()
    assert var_0 == var_1
    assert var_1 == var_2

# Generated at 2022-06-25 00:31:06.506687
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    assert python_fact_collector_1.collect() is not None


# Generated at 2022-06-25 00:31:13.281255
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = python_fact_collector_0.name
    assert var_0['python']['executable'] == sys.executable
    assert var_0['python']['version'] == { 'releaselevel': 'final', 'micro': 0, 'serial': 0, 'major': 2, 'minor': 7}
    assert var_1 == 'python'

# Generated at 2022-06-25 00:31:14.865782
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()



# Generated at 2022-06-25 00:31:16.559112
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:21.901218
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert HAS_SSLCONTEXT
    test_case_0()

# Generated at 2022-06-25 00:31:28.743015
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = sys.version.split(" ")[0]
    var_2 = var_0['python']['version']['major']
    var_3 = var_0['python']['version']['minor']
    var_4 = var_0['python']['version']['micro']
    var_5 = sys.version_info[0]
    var_6 = sys.version_info[1]
    var_7 = sys.version_info[2]
    var_8 = sys.version_info[3]
    var_9 = sys.version_info[4]
    var_10 = sys.version_info
    var_11 = var_0

# Generated at 2022-06-25 00:31:33.255010
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_0 = PythonFactCollector()
    # The variable that holds the returned value
    var_0 = python_fact_collector_0.collect()



# Generated at 2022-06-25 00:31:37.681143
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert repr(var_1) == "{'python': {'version_info': [2, 7, 5, 'final', 0], 'type': 'CPython', 'has_sslcontext': True, 'version': {'releaselevel': 'final', 'minor': 7, 'serial': 0, 'micro': 5, 'major': 2}, 'executable': '/usr/bin/python'}}"


# Generated at 2022-06-25 00:31:46.275054
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    t_0 = PythonFactCollector()
    var_0 = test_case_0()
    assert var_0 == {
        'python': {
            'has_sslcontext': True,
            'type': 'CPython',
            'executable': '/usr/bin/python',
            'version': {
                'serial': 0,
                'major': 2,
                'releaselevel': 'final',
                'minor': 7,
                'micro': 12
            },
            'version_info': [2, 7, 12, 'final', 0]
        }
    }