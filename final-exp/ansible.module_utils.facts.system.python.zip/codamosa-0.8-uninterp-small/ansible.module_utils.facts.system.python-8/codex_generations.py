

# Generated at 2022-06-25 00:23:34.462454
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:23:37.147925
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        python_fact_collector_0 = PythonFactCollector()
        assert type(python_fact_collector_0.collect()) is dict
    except:
        assert False


# Generated at 2022-06-25 00:23:38.996451
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() is not None


# Generated at 2022-06-25 00:23:47.258709
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()
    assert python_facts_0
    assert isinstance(python_facts_0, dict)
    assert 'python' in python_facts_0
    assert isinstance(python_facts_0['python'], dict)
    assert 'version' in python_facts_0['python']
    assert isinstance(python_facts_0['python']['version'], dict)
    assert 'version_info' in python_facts_0['python']
    assert isinstance(python_facts_0['python']['version_info'], list)
    assert 'executable' in python_facts_0['python']
    # assert isinstance(python_facts_0['python']['executable'], bas

# Generated at 2022-06-25 00:23:54.819066
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    data = python_fact_collector_0.collect()
    assert data['python']['executable'] is not None
    assert data['python']['version']['major'] is not None
    assert data['python']['version']['minor'] is not None
    assert data['python']['version']['micro'] is not None
    assert data['python']['version']['releaselevel'] is not None
    assert data['python']['version']['serial'] is not None
    assert data['python']['version_info'] is not None
    assert data['python']['has_sslcontext'] is not None
    assert data['python']['type'] is not None

# Generated at 2022-06-25 00:24:04.101384
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    # Test with required parameters
    result = python_fact_collector_1.collect()
    assert result == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 5, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 5, 'final', 0], 'executable': '/usr/local/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

    # Test with missing arguments
    try:
        python_fact_collector_1.collect(module='')
    except Exception:
        assert True
    else:
        assert False

    # Test with unsupported parameters

# Generated at 2022-06-25 00:24:06.306224
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:16.123675
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:24:17.483336
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:24:20.922093
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:24:26.841761
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    assert python_fact_collector_0.collect()


# Generated at 2022-06-25 00:24:32.610251
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Test collect() method of PythonFactCollector class
    '''
    test_facts = {'python': {'executable': '/usr/bin/python2.7',
                             'has_sslcontext': True,
                             'type': 'CPython',
                             'version': {'major': 2,
                                         'micro': 7,
                                         'minor': 13,
                                         'releaselevel': 'final',
                                         'serial': 0},
                             'version_info': [2, 7, 13, 'final', 0]}}

    python_fact_collector_0 = PythonFactCollector()
    collected_facts_0 = python_fact_collector_0.collect()
    assert collected_facts_0 == test_facts

# Generated at 2022-06-25 00:24:35.113640
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    res = python_fact_collector_1.collect()
    assert res['python']['type'] == 'CPython'

# Generated at 2022-06-25 00:24:37.407123
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:24:45.835849
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test the output of collect method.
    """

    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()

    assert result is not None
    assert isinstance(result, dict)
    assert len(result) == 1
    assert result['python'].get('type') is not None
    assert result['python'].get('version') is not None
    assert result['python'].get('version_info') is not None
    assert result['python'].get('executable') is not None
    assert result['python'].get('has_sslcontext') is not None

# Generated at 2022-06-25 00:24:56.775862
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts.get('python').get('version_info')[0] == 3
    assert python_facts.get('python').get('version_info')[1] == 6
    assert python_facts.get('python').get('version_info')[2] > 0
    assert python_facts.get('python').get('version_info')[3] == 'final'
    assert python_facts.get('python').get('version_info')[4] > 0
    assert python_facts.get('python').get('version').get('major') == 3
    assert python_facts.get('python').get('version').get('minor') == 6
    assert python_facts.get('python').get

# Generated at 2022-06-25 00:24:59.100500
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:01.124052
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result is not None

# Generated at 2022-06-25 00:25:06.733712
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'version': {'micro': 0, 'releaselevel': 'final', 'serial': 0, 'minor': 7, 'major': 2}, 'has_sslcontext': False, 'version_info': [2, 7, 0, 'final', 0], 'executable': '/usr/bin/ansible-python-interpreter', 'type': 'CPython'}}


# Generated at 2022-06-25 00:25:08.792461
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect(None, None)
    assert isinstance(python_facts_0, dict) is True
    assert python_facts_0['python']['type'] == 'CPython'


if __name__ == '__main__':
    import pytest
    pytest.main(args=["-x", "test_python_facts.py"])

# Generated at 2022-06-25 00:25:22.469817
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    result_0 = python_fact_collector_1.collect(module=0)
    result_1 = python_fact_collector_0.collect(module=0)

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:25:24.608907
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    python_fact_collector_0.collect(collected_facts=collected_facts)

# Generated at 2022-06-25 00:25:29.583532
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()
    assert python_facts_0.keys()[0] == 'python'
    keys_0 = python_facts_0['python'].keys()
    assert 'version' in keys_0
    assert 'version_info' in keys_0
    assert 'executable' in keys_0
    assert 'type' in keys_0

# Generated at 2022-06-25 00:25:30.365025
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:25:33.139507
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
   python_fact_collector_0 = PythonFactCollector()
   assert python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:39.154379
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    ansible_facts = dict()
    ansible_facts['ansible_local'] = dict()
    ansible_facts['ansible_local']['facts'] = dict()
    ansible_facts['ansible_local']['facts']['python'] = dict()
    result = python_fact_collector_0.collect(None,ansible_facts)

    expected = dict()
    expected['python'] = dict()
    expected['python']['version'] = dict()
    expected['python']['version']['major'] = 3
    expected['python']['version']['minor'] = 7
    expected['python']['version']['micro'] = 4
    expected['python']['version']['releaselevel'] = 'final'

# Generated at 2022-06-25 00:25:43.687104
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    try:
        x = python_fact_collector_0.collect()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 00:25:46.969488
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()
    assert (python_facts_0 == {'python': {'has_sslcontext': True}})


# Generated at 2022-06-25 00:25:51.008984
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector_result = python_fact_collector.collect()
    assert python_fact_collector_result is not None
    assert python_fact_collector_result == {}

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:25:52.037497
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()

# Generated at 2022-06-25 00:26:17.658545
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    ansible_module_0 = AnsibleModule(
        argument_spec=dict()
    )
    python_expected_0 = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-25 00:26:22.940874
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    python_facts.pop('python').pop('version_info').pop('releaselevel')
    expected_python_facts = {'python': {'has_sslcontext': False, 'executable': '/usr/bin/python', 'version': {'major': 2, 'micro': 3, 'serial': 5, 'minor': 6}}}
    assert python_facts == expected_python_facts


# Generated at 2022-06-25 00:26:26.637591
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Arrange
    python_fact_collector_mock_0 = PythonFactCollector()

    # Act
    python_result_0 = python_fact_collector_mock_0.collect()

    # Assert
    assert isinstance(python_result_0, dict)


# Generated at 2022-06-25 00:26:34.073237
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Call method collect of class PythonFactCollector with arguments module=None, collected_facts=None
    result = python_fact_collector_0.collect()

    # Assert if result is equal to the expected value
    assert result == {'python': {'version': {'major': '2', 'minor': '7', 'micro': '', 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 0, 'final', 0], 'executable': '', 'has_sslcontext': False}}

# Generated at 2022-06-25 00:26:39.665860
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts['python']['version']['major'] == 3
    assert python_facts['python']['version']['minor'] == 5
    assert python_facts['python']['version']['micro'] == 3
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert python_facts['python']['version']['serial'] == 0
    assert python_facts['python']['version_info'] == [3, 5, 3, 'final', 0]
    assert python_facts['python']['executable'] == '/usr/bin/python'
    assert python_facts['python']['has_sslcontext'] == True

# Generated at 2022-06-25 00:26:47.790201
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts_0 = {'python': {'executable': '/usr/bin/python'}}
    python_facts_0 = {'python': {'executable': '/usr/bin/python', 'version': {'serial': 0, 'releaselevel': 'final', 'major': 2, 'micro': 17, 'minor': 6}, 'version_info': [2, 6, 17, 'final', 0], 'has_sslcontext': True, 'type': 'CPython'}}

    assert python_fact_collector_0.collect(collected_facts=collected_facts_0) == python_facts_0

# Generated at 2022-06-25 00:26:52.316677
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    python_facts = collector.collect()
    print(python_facts)

if __name__ == "__main__":
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:26:59.213489
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

    assert isinstance(result, dict) is True
    assert set(result.keys()) == set(['python'])

    assert isinstance(result['python'], dict) is True
    assert set(result['python'].keys()) == set(['version', 'type', 'version_info', 'executable', 'has_sslcontext'])

    python_version = result['python']['version']

    assert isinstance(python_version, dict) is True
    assert set(python_version.keys()) == set(['major', 'minor', 'micro', 'releaselevel', 'serial'])

    assert isinstance(python_version['major'], int) is True
    assert isinstance(python_version['minor'], int)

# Generated at 2022-06-25 00:27:00.401047
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    assert python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:10.012525
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    res = python_fact_collector.collect()
    # If the assertion below fails, you forgot to invoke the class
    # constructor in the test function
    assert python_fact_collector._fact_ids == set()
    assert res['python']['version']['major'] == 3
    assert res['python']['version']['minor'] == 4
    assert res['python']['version']['micro'] == 3
    assert res['python']['version']['releaselevel'] == 'final'
    assert res['python']['version']['serial'] == 0
    assert res['python']['version_info'] == [3, 4, 3, 'final', 0]

# Generated at 2022-06-25 00:27:47.110520
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-25 00:27:52.915679
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    f = python_fact_collector.collect()
    assert f
    assert len(f) == 1
    assert f['python']
    assert len(f['python']) == len(python_fact_collector.__slots__)
    assert f['python']['version']
    assert len(f['python']['version']) == len(python_fact_collector.__slots__[0])
    assert f['python']['version']['major']
    assert f['python']['version']['minor']
    assert f['python']['version']['micro']
    assert f['python']['version']['releaselevel']
    assert f['python']['version']['serial']

# Generated at 2022-06-25 00:28:01.648506
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert list(result.keys()) == ['python']
    assert list(result['python'].keys()) == ['version', 'version_info', 'executable', 'has_sslcontext', 'type']
    assert list(result['python']['version'].keys()) == ['major', 'minor', 'micro', 'releaselevel', 'serial']
    assert result['python']['version_info'][0] == sys.version_info[0]
    assert result['python']['version_info'][1] == sys.version_info[1]
    assert result['python']['version_info'][2] == sys.version_info[2]

# Generated at 2022-06-25 00:28:06.535476
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 5, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 5, 'final', 0], 'executable': '/usr/bin/python2.7', 'has_sslcontext': False, 'type': 'CPython'}}


# Generated at 2022-06-25 00:28:08.768332
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Test with default args
    with pytest.raises(NotImplementedError):
        python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:12.298416
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result_1 = python_fact_collector_1.collect()
    assert result_1 is not None

# Generated at 2022-06-25 00:28:17.214027
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == {'python': {'type': 'CPython', 'has_sslcontext': True, 'version_info': [2, 7, 12, 'final', 0], 'version': {'serial': 0, 'releaselevel': 'final', 'micro': 12, 'major': 2, 'minor': 7}, 'executable': '/usr/bin/python'}}


# Generated at 2022-06-25 00:28:24.270587
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()

    assert isinstance(python_facts_0, dict) and python_facts_0

    python_fact_keys_0 = frozenset(['executable', 'has_sslcontext', 'type', 'version', 'version_info'])

    assert python_fact_keys_0.issubset(python_facts_0['python'].keys()), '\'python_facts_0[\'python\'].keys()\' should be a superset of \'python_fact_keys_0\''

# Generated at 2022-06-25 00:28:29.940226
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts_dict = {}
    ansible_facts = {}
    result = python_fact_collector_0.collect(facts_dict, ansible_facts)
    assert result == {'ansible_python': {'executable': '/usr/bin/python',\
    'has_sslcontext': True, 'type': 'CPython', 'version': {'major': 2, 'minor': 7,\
     'micro': 5, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 5, 'final', 0]}}

# Generated at 2022-06-25 00:28:31.204948
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_collect = PythonFactCollector()
    python_fact_collector_collect.collect()

# Generated at 2022-06-25 00:29:49.193271
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:29:53.356210
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    ansible_facts = PythonFactCollector().collect()
    for k, v in ansible_facts.items():
        assert k == 'python'
        for k2, v2 in v.items():
            if k2 != 'type':
                if k2 != 'version_info':
                    assert v2 != ""
                    assert not isinstance(v2, list)
                else:
                    for i in v2:
                        assert i != ""
                        assert i != -1
            else:
                assert v2 != ""

# Generated at 2022-06-25 00:29:59.944000
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for method collect of class PythonFactCollector
    """
    # Initialize the class
    python_fact_collector_0 = PythonFactCollector()

    # Run method collect
    result = python_fact_collector_0.collect()

    # Verify the results
    assert(sys.version_info[0] == result['python']['version']['major'])
    assert(sys.version_info[1] == result['python']['version']['minor'])
    assert(sys.version_info[2] == result['python']['version']['micro'])
    assert(sys.version_info[3] == result['python']['version']['releaselevel'])

# Generated at 2022-06-25 00:30:03.118726
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    FactCollector_0 = PythonFactCollector()
    if FactCollector_0 is not None:
        python_fact_collector_0 = FactCollector_0.collect()
        if python_fact_collector_0 is not None:
            pass
        pass



# Generated at 2022-06-25 00:30:10.529543
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts['python']['has_sslcontext'] is True
    assert python_facts['python']['version']['major'] == 3
    assert python_facts['python']['version']['minor'] == 7
    assert type(python_facts['python']['type']) == str
    assert python_facts['python']['type'] in ('cpython', 'pypy')
    assert python_facts['python']['version']['micro'] < 100
    assert python_facts['python']['version']['releaselevel'] in ('alpha', 'beta', 'candidate', 'final')

# Generated at 2022-06-25 00:30:18.793883
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    actual = python_fact_collector_0.collect()
    expected = {'python': {'version': {'major': 3, 'minor': 5, 'micro': 2, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 5, 2, 'final', 0], 'executable': '/usr/bin/python3.5', 'has_sslcontext': False, 'type': 'CPython'}}

    assert actual == expected


# Generated at 2022-06-25 00:30:27.854244
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    facts = python_fact_collector_0.collect()
    version_info = facts['python']['version_info']
    version = '%d.%d.%d' % (version_info[0], version_info[1], version_info[2])
    assert facts['python']['version']['major'] == version_info[0]
    assert facts['python']['version']['minor'] == version_info[1]
    assert facts['python']['version']['micro'] == version_info[2]
    assert facts['python']['version']['releaselevel'] == version_info[3]
    assert facts['python']['version']['serial'] == version_info[4]

# Generated at 2022-06-25 00:30:33.480455
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:30:38.325643
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Read in test data from test/unit/ansible_collections/ansible/community/plugins/module_utils/facts/collector/python.json
    python_result_0 = {
        'python': {
            'executable': '/usr/bin/python',
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'major': 2,
                'micro': 7,
                'minor': 12,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 12, 'final', 0]
        }
    }

    assert python_fact_collector_0.collect(None, None) == python_result_0

# Generated at 2022-06-25 00:30:40.841438
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts_1 = python_fact_collector_1.collect()
    assert 'python' in python_facts_1
    assert 'version' in python_facts_1['python']
    assert 'version_info' in python_facts_1['python']
    assert 'executable' in python_facts_1['python']


# Generated at 2022-06-25 00:33:24.343943
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert python_fact_collector_0.collect() == dict(python=dict(executable='/opt/ansible/bin/python',
                                                                has_sslcontext=HAS_SSLCONTEXT,
                                                                type='CPython',
                                                                version=dict(major=2, minor=7, micro=5,
                                                                             releaselevel='final', serial=0),
                                                                version_info=[2, 7, 5, 'final', 0]))


# Generated at 2022-06-25 00:33:33.740594
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    set_fact_0 = python_fact_collector_0.collect()

    assert set_fact_0 is not None
    assert isinstance(set_fact_0, dict)
    assert set_fact_0.get('python') is not None
    assert set_fact_0.get('python').get('version') is not None
    assert set_fact_0.get('python').get('version_info') is not None
    assert set_fact_0.get('python').get('executable') is not None
    assert set_fact_0.get('python').get('has_sslcontext') is not None
    assert set_fact_0.get('python').get('type') is not None