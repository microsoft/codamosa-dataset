

# Generated at 2022-06-25 00:23:33.373713
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Setup test case
    python_fact_collector_0 = PythonFactCollector()

    # Run test
    test_result_0 = python_fact_collector_0.collect()
    assert test_result_0['python']['version_info'] == [2, 7, 6, 'final', 0]

# Generated at 2022-06-25 00:23:41.597723
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result != "", "Didn't get a dictionary back"
    assert type(result) == dict, "Didn't get a dictionary back"
    assert "python" in result, "Didn't get a key for python"
    assert type(result['python']) == dict, "Didn't get a dictionary for key 'python'"
    assert "version" in result['python'], "Didn't get a key for version"
    assert type(result['python']['version']) == dict, "Didn't get a dictionary for key 'version'"
    assert "major" in result['python']['version'], "Didn't get a key for major"

# Generated at 2022-06-25 00:23:44.170087
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()

# Generated at 2022-06-25 00:23:52.895050
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    This test verifies the expected output of collect()
    """
    python_fact_collector_0 = PythonFactCollector()
    assert_equals(python_fact_collector_0.collect(), {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'type': sys.implementation.name,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    })

# Generated at 2022-06-25 00:23:54.529387
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()
    assert python_facts['python']

# Generated at 2022-06-25 00:24:00.521532
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = {'python': {'version': {'major': 2, 'serial': 0, 'minor': 7, 'micro': 10, 'releaselevel': 'final'}, 'executable': '/usr/bin/python', 'version_info': [2, 7, 10, 'final', 0], 'has_sslcontext': True}}
    ansible_facts_0 = {'ansible_facts': {'python': {'version': {'major': 2, 'serial': 0, 'minor': 7, 'micro': 10, 'releaselevel': 'final'}, 'executable': '/usr/bin/python', 'version_info': [2, 7, 10, 'final', 0], 'has_sslcontext': True}}}

# Generated at 2022-06-25 00:24:03.243695
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test for method collect (PythonFactCollector) of class PythonFactCollector
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect(None, None)


# Generated at 2022-06-25 00:24:07.153920
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-25 00:24:08.935445
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:24:10.614518
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    result = python_fact_collector_0.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-25 00:24:16.408093
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    del result


# Generated at 2022-06-25 00:24:18.671507
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# test_PythonFactCollector_collect excludes the following from execution
# - test_case_0
# - test_PythonFactCollector_collect

# Generated at 2022-06-25 00:24:21.320976
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()


# Generated at 2022-06-25 00:24:23.368414
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Return type of method collect is a dict
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:24:26.540993
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:24:28.185425
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result


# Generated at 2022-06-25 00:24:30.247234
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:24:31.077190
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:24:41.594457
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result is not None
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 0
    assert result['python']['version']['micro'] == 1
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [3, 0, 1, 'final', 0]
    assert result['python']['has_sslcontext'] is True

# Generated at 2022-06-25 00:24:44.804426
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of the PythonFactCollector class
    python_fact_collector_obj = PythonFactCollector()

    # Call method collect of PythonFactCollector class
    python_fact_collector_obj.collect()

# Generated at 2022-06-25 00:24:54.576470
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # no exception should be raised because of lack of python-ssl
    python_fact_collector_0.collect()



# Generated at 2022-06-25 00:24:55.422897
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:24:59.825753
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()


if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:25:05.165740
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 5, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 5, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': None}}

# Generated at 2022-06-25 00:25:08.562452
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test collect function of PythonFactCollector
    """

    python_fact_collector_0 = PythonFactCollector()
    assert 'python' in python_fact_collector_0.collect().keys()
    assert 'has_sslcontext' in python_fact_collector_0.collect()['python']

# Generated at 2022-06-25 00:25:10.346251
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:20.458109
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Collects the installed Python version and implementation information.
    '''
    python_fact_collector = PythonFactCollector()
    version = sys.version_info
    major = version[0]
    minor = version[1]
    micro = version[2]
    releaselevel = version[3]
    serial = version[4]
    version_info = list(sys.version_info)
    executable = sys.executable
    try:
        pythontype = sys.subversion[0]
    except AttributeError:
        try:
            pythontype = sys.implementation.name
        except AttributeError:
            pythontype = None


# Generated at 2022-06-25 00:25:23.079541
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    if not python_fact_collector_1.collect():
        raise AssertionError("collect of PythonFactCollector should return 'not False'")

# Generated at 2022-06-25 00:25:31.068130
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()
    assert PythonFactCollector()._fact_ids == {'python'}
    assert python_facts_0.keys() == {'python'}
    assert python_facts_0['python']['version']['serial'] == sys.version_info[4]
    version_info_0 = python_facts_0['python']['version_info']
    assert isinstance(version_info_0, list)
    assert python_facts_0['python']['executable'] == sys.executable
    assert python_facts_0['python']['type'] == sys.implementation.name
    assert python_facts_0['python']['has_sslcontext'] == HAS_SSLC

# Generated at 2022-06-25 00:25:33.490307
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector_obj = PythonFactCollector()
    py_fact = py_fact_collector_obj.collect()
    assert py_fact is not None



# Generated at 2022-06-25 00:25:50.347105
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect

    # AssertionError: module object has no attribute 'subversion'


# Generated at 2022-06-25 00:25:51.190270
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:25:59.489580
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    expected_python_facts = {}
    expected_python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-25 00:26:04.783220
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    result = python_fact_collector_1.collect()
    assert result is not None, "AnsibleFailException: Collect should return a dict"
    assert isinstance(result, dict), "AnsibleFailException: Collect should return a dict"
    assert 'python' in result

# Generated at 2022-06-25 00:26:06.438027
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_collect = PythonFactCollector()
    python_fact_collector_collect.collect()


# Generated at 2022-06-25 00:26:08.166170
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    results = python_fact_collector.collect()
    assert (results['python']['executable'] == sys.executable)

# Generated at 2022-06-25 00:26:16.395618
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
            'version': {
                'major': sys.version_info[0],
                'micro': sys.version_info[2],
                'minor': sys.version_info[1],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
        }
    }

    fact_collector_0 = python_fact_collector_0.collect()
    fact_collector_1 = fact_collector_

# Generated at 2022-06-25 00:26:19.055422
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Make sure we have a dictionary returned
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:26:23.601153
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    print("TEST: %s" % python_fact_collector_0.collect())
    if python_fact_collector_0.collect():
        print("TEST: %s" % python_fact_collector_0.collect()['python']['version']['major'])


if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:26:25.021748
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    t_PythonFactCollector_0 = PythonFactCollector()
    t_dict_0 = t_PythonFactCollector_0.collect()


# Generated at 2022-06-25 00:26:42.780024
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()
    python_fact_collector_0.collect(collected_facts=None)
    python_fact_collector_0.collect(collected_facts=None, module='ansible.module_utils.facts.facts')

# Generated at 2022-06-25 00:26:50.798489
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert 'python' in var_0.keys()
    assert 'version' in var_0['python'].keys()
    assert 'type' in var_0['python'].keys()
    assert 'version_info' in var_0['python'].keys()
    assert 'executable' in var_0['python'].keys()
    assert 'has_sslcontext' in var_0['python'].keys()

    # Test keys
    assert 'major' in var_0['python']['version'].keys()
    assert 'minor' in var_0['python']['version'].keys()
    assert 'micro' in var_0['python']['version'].keys()
   

# Generated at 2022-06-25 00:26:52.342631
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert not var_0

# Generated at 2022-06-25 00:26:59.171334
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['executable'] == sys.executable
    assert var_0['python']['version']['micro'] == sys.version_info[2]
    assert var_0['python']['version']['releaselevel'] == sys.version_info[3]
    assert var_0['python']['version']['minor'] == sys.version_info[1]
    assert var_0['python']['version']['serial'] == sys.version_info[4]
    assert var_0['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-25 00:27:05.972408
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    try:
        var_0 = python_fact_collector_0.collect()
    except Exception as exception_0:
        var_1 = sys.exc_info()
        var_2 = var_1[0]
        var_3 = var_1[1]
        var_4 = var_1[2]
        var_5 = type(var_2) is Exception
        var_6 = var_2(var_3)
        var_7 = str(var_3)
        var_8 = type(var_3) is str
        var_9 = type(var_4) is types.TracebackType

if __name__ == "__main__":
    import types

    test_PythonFactCollector_collect()
    test_case_

# Generated at 2022-06-25 00:27:11.201256
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = python_fact_collector_0.collect()
    assert(var_0 != var_1)



# Generated at 2022-06-25 00:27:15.862935
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'version': {'major': 3, 'minor': 7, 'micro': 4, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 7, 4, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}


# Generated at 2022-06-25 00:27:21.199412
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert type(var_0) == dict
    assert "version" in var_0["python"]
    assert type(var_0["python"]["version"]["major"]) == int
    assert type(var_0["python"]["version"]["minor"]) == int
    assert type(var_0["python"]["version"]["micro"]) == int
    assert type(var_0["python"]["version"]["releaselevel"]) == str
    assert type(var_0["python"]["version"]["serial"]) == int
    assert type(var_0["python"]["version_info"]) == list

# Generated at 2022-06-25 00:27:23.799435
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:31.527199
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['major'] == sys.version_info[0], \
        "Collect method of PythonFactCollector returns incorrect data"
    assert var_0['python']['version']['minor'] == sys.version_info[1], \
        "Collect method of PythonFactCollector returns incorrect data"
    assert var_0['python']['version']['micro'] == sys.version_info[2], \
        "Collect method of PythonFactCollector returns incorrect data"
    assert var_0['python']['version']['releaselevel'] == sys.version_info[3], \
        "Collect method of PythonFactCollector returns incorrect data"


# Generated at 2022-06-25 00:28:05.170122
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:28:07.023175
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = python_fact_collector_0.name


# Generated at 2022-06-25 00:28:11.655566
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1['python']['version']['major'] == 2
    assert var_1['python']['version']['minor'] == 7


# Generated at 2022-06-25 00:28:12.387265
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:28:16.135424
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert type(var_0) is dict
    assert 'python' in var_0
    assert type(var_0['python']) is dict
    assert 'version_info' in var_0['python']
    assert type(var_0['python']['version_info']) is list

# Generated at 2022-06-25 00:28:24.395197
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Cache
    cached_facts = dict()
    cached_facts['all'] = dict()

    # Test PythonFactCollector
    python_fact_collector = PythonFactCollector()
    var_result_0 = python_fact_collector.collect(cached_facts, Cache())
    assert var_result_0['python']['has_sslcontext'] == HAS_SSLCONTEXT, \
        'Expected "{0}", but the returned value is "{1}".'.format(
            HAS_SSLCONTEXT, var_result_0['python']['has_sslcontext'])

# Generated at 2022-06-25 00:28:31.568428
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import pytest

    pytest.skip("TODO: implement test_PythonFactCollector_collect")
#
#    # instantiate object
#    python_fact_collector_0 = PythonFactCollector()
#
#    # define test inputs and expected outputs
#    test_inputs_0 = [None, None]
#    test_expected_outputs_0 = ['<ansible.module_utils.facts.collector.BaseFactCollector object at 0x7fbd3caa3b38>', '<ansible.module_utils.facts.collector.BaseFactCollector object at 0x7fbd3caa3ac8>']
#
#    test_inputs_1 = [None, None]
#    test_expected_outputs_1 = ['<ansible.module_utils.facts

# Generated at 2022-06-25 00:28:33.009671
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()



# Generated at 2022-06-25 00:28:39.766571
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    python_fact_collector_2 = PythonFactCollector()
    var_2 = python_fact_collector_2.collect()
    assert isinstance(var_2, dict)
    python_fact_collector_3 = PythonFactCollector()
    var_3 = python_fact_collector_3.collect()
    assert isinstance(var_3, dict)
    python_fact_collector_4 = PythonFactCollector()
    var_4 = python_fact_collector_4.collect()
    assert isinstance(var_4, dict)
    python_fact_collector_5 = PythonFactCollector()
    var_

# Generated at 2022-06-25 00:28:46.647346
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {'python': {'version': {'major': 3, 'minor': 7, 'micro': 3, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 7, 3, 'final', 0], 'executable': 'c:\\python37\\python.exe', 'type': 'CPython', 'has_sslcontext': True}}
    var_1 = python_fact_collector_0.collect(collected_facts={'some_facts': 1})
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:29:55.038140
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:30:02.555578
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 == {'python': {'executable': '',
                                'has_sslcontext': False,
                                'type': '',
                                'version': {'major': 0, 'micro': 0, 'minor': 0, 'releaselevel': '', 'serial': 0},
                                'version_info': [0, 0, 0, '', 0]}}


# Generated at 2022-06-25 00:30:03.908564
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector_0 = PythonFactCollector()
    var_0 = collector_0.collect()



# Generated at 2022-06-25 00:30:07.552214
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    var_0 = python_fact_collector_1.collect()
    python_fact_collector_0.collect()
    python_fact_collector_1.collect()


# Generated at 2022-06-25 00:30:14.328975
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    try:
        assert (var_0['python']['version']['micro'] == 1)
    finally:
        python_fact_collector_0.cleanup()
    try:
        assert (var_0['python']['has_sslcontext'] == False)
    finally:
        python_fact_collector_0.cleanup()

# Generated at 2022-06-25 00:30:21.424731
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fixture_value_PythonFactCollector_collect_0 = {
        "distribution": "",
        "distribution_version": "",
        "machine": "",
        "python": {
            "executable": "",
            "has_sslcontext": False,
            "type": None,
            "version": {
                "major": 0,
                "micro": 0,
                "minor": 0,
                "releaselevel": "",
                "serial": 0
            },
            "version_info": [0, 0, 0, "", 0]
        },
        "system": ""
    }
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == fixture_value_PythonFactCollector_collect_0


# Generated at 2022-06-25 00:30:29.631082
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    assert 'python' in var_1
    assert isinstance(var_1['python'], dict)
    assert 'version' in var_1['python']
    assert isinstance(var_1['python']['version'], dict)
    assert 'major' in var_1['python']['version']
    assert python_fact_collector_1.name in var_1
    assert var_1['python']['version']['major'] == sys.version_info[0]
    assert var_1['python']['version']['minor'] == sys.version_info[1]

# Generated at 2022-06-25 00:30:33.558349
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert type(var_0) is dict
    assert var_0 == {'python': {'version': {'major': 2, 'micro': 7, 'minor': 15, 'releaselevel': 'final', 'serial': 0}, 'executable': '/usr/bin/python2.7', 'has_sslcontext': True, 'version_info': [2, 7, 15, 'final', 0], 'type': 'CPython'}}

# Generated at 2022-06-25 00:30:37.066797
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_0 = python_fact_collector_1.collect()
    assert(var_0['python'] == {'version': {'micro': 2, 'serial': 0, 'major': 2, 'minor': 7, 'releaselevel': 'final'}, 'has_sslcontext': True, 'executable': '/Users/travis/workspace/build/ansible-v2.5-devel/bin/python', 'version_info': [2, 7, 2], 'type': 'CPython'})


# Generated at 2022-06-25 00:30:41.631258
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert (var_0['ansible_python']['version']['major'] == sys.version_info[0])
    assert (var_0['ansible_python']['version']['minor'] == sys.version_info[1])
    assert (var_0['ansible_python']['version']['micro'] == sys.version_info[2])
    assert (var_0['ansible_python']['version']['releaselevel'] == sys.version_info[3])
    assert (var_0['ansible_python']['version']['serial'] == sys.version_info[4])

# Generated at 2022-06-25 00:33:11.564666
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print('\nTest collect of class PythonFactCollector')
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:33:15.869434
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = {'executable': '/usr/bin/python3', 'version': {'releaselevel': 'final', 'serial': 0, 'major': 3, 'minor': 5, 'micro': 2}, 'has_sslcontext': True, 'version_info': [3, 5, 2, 'final', 0], 'type': 'CPython'}
    assert var_1 == python_fact_collector_0.collect()

# Generated at 2022-06-25 00:33:19.152525
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        test_case_0()
    except Exception as err:
        print("\n=============================")
        print("UnitTest for method 'collect'")
        print("=============================")
        print("An exception was raised during testing:")
        print(err)
        sys.exit(1)
    else:
        print("\n=============================")
        print("UnitTest for method 'collect'")
        print("=============================")
        print("No errors encountered during testing")
        sys.exit(0)

# Generated at 2022-06-25 00:33:25.570621
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-25 00:33:33.208110
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect
    assert var_1() == {'python': {'type': 'CPython', 'executable': '/usr/bin/python', 'has_sslcontext': True, 'version_info': [2, 7, 12, 'final', 0], 'version': {'releaselevel': 'final', 'micro': 0, 'serial': 0, 'major': 2, 'minor': 7}}}