

# Generated at 2022-06-25 00:23:32.719889
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert(python_fact_collector_0.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 13, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 13, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': 'CPython'}})

# Generated at 2022-06-25 00:23:38.592136
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector_obj = PythonFactCollector()
    collected_facts = {}
    python_facts = python_collector_obj.collect(collected_facts)
    assert python_facts == {'python': {'version': {'major': 2, 'releaselevel': 'final', 'minor': 7, 'micro': 10, 'serial': 0}, 'version_info': [2, 7, 10, 'final', 0], 'type': 'CPython', 'executable': '/usr/bin/python', 'has_sslcontext': False}}

# Generated at 2022-06-25 00:23:39.945684
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    _python_fact_collector = PythonFactCollector()
    _python_fact_collector.collect()

# Generated at 2022-06-25 00:23:48.472650
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_dict = python_fact_collector_0.collect()
    #assert python_facts_dict is not empty
    python_facts = python_facts_dict['python']
    assert python_facts is not None
    assert 'version' in python_facts
    assert python_facts['version'] is not None
    version_dict = python_facts['version']
    assert 'major' in version_dict
    assert 'minor' in version_dict
    assert 'micro' in version_dict
    assert 'releaselevel' in version_dict
    assert 'serial' in version_dict
    assert version_dict['major'] is not None
    assert version_dict['minor'] is not None
    assert 'version_info' in python_facts

# Generated at 2022-06-25 00:23:50.237217
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:23:52.003283
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert 'changed' in python_fact_collector_0.collect()


# Generated at 2022-06-25 00:23:55.979639
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect(module=None, collected_facts=None)
    assert result.get('python')

# Generated at 2022-06-25 00:23:56.934439
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()


# Generated at 2022-06-25 00:24:05.735239
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Case 1
    python_fact_collector_1 = PythonFactCollector()

    result = python_fact_collector_1.collect()
    assert result == {'python': {'has_sslcontext': True,
                                 'version': {'major': 2,
                                             'micro': 6,
                                             'minor': 6,
                                             'releaselevel': 'final',
                                             'serial': 0},
                                 'version_info': [2,
                                                  6,
                                                  6,
                                                  'final',
                                                  0],
                                 'executable': '/usr/bin/python',
                                 'type': 'CPython'}}

    # Case 2
    python_fact_collector_2 = PythonFactCollector()


# Generated at 2022-06-25 00:24:08.109154
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    collected_facts = {}
    result = python_fact_collector_0.collect(collected_facts=collected_facts)
    assert 'python' in result

# Generated at 2022-06-25 00:24:11.922461
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect(collected_facts={})
    assert facts['python']['version']['minor'] == sys.version_info[1]


# Generated at 2022-06-25 00:24:16.612281
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = PythonFactCollector().collect()
    assert facts['python']['version']['major'] > 2
    assert facts['python']['version']['minor'] >= 6
    assert facts['python']['executable'].endswith(u'python')
    assert facts['python']['has_sslcontext']

# Generated at 2022-06-25 00:24:21.200979
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    expected_results = {
        'python': {
            'type': 'CPython',
            'executable': '/usr/bin/python',
            'has_sslcontext': False,
            'version': {
                'releaselevel': 'final',
                'micro': 0,
                'serial': 0,
                'minor': 6,
                'major': 2
            },
            'version_info': [
                2,
                6,
                0,
                'final',
                0
            ]
        }
    }
    
    # Construct call to method collect of class PythonFactCollector and check the results
    result = python_fact_collector.collect(module=None, collected_facts=None)

    assert result == expected_results

# Generated at 2022-06-25 00:24:22.964649
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect(None, None)


# Generated at 2022-06-25 00:24:28.490472
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    actual_result = python_fact_collector_0.collect()

    assert actual_result['python']['type'] == python_fact_collector_0.name

# Generated at 2022-06-25 00:24:35.698558
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    # Asserts with expected result
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-25 00:24:37.883639
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_1.collect()

# Generated at 2022-06-25 00:24:47.601827
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    rc = python_fact_collector_0.collect()
    assert type(rc) == dict, "Object 'rc' is not of type dict"
    assert rc == {'python': {'has_sslcontext': True, 'version': {'releaselevel': 'final', 'serial': 0, 'major': 2, 'minor': 7, 'micro': 12}, 'type': 'CPython', 'version_info': [2, 7, 12, 'final', 0, 'CPython', 'Darwin', 'Darwin Kernel Version 15.6.0: Mon Aug 29 20:21:34 PDT 2016; root:xnu-3248.60.10~1/RELEASE_X86_64', 64]}}, "Return value of function 'collect' test_0"


# Generated at 2022-06-25 00:24:54.748688
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Unit test for method collect of class PythonFactCollector
    '''
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    assert facts


if __name__ == '__main__':
    # You should be able to run this as
    # python -m test/test_python_fact_collector
    # No need to have ansible installed
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 00:24:56.347731
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:08.529816
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    python_facts_1 = python_fact_collector_1.collect()
    assert type(python_facts_1) is dict
    assert 'python' in python_facts_1
    assert type(python_facts_1['python']) is dict
    assert 'version' in python_facts_1['python']
    assert type(python_facts_1['python']['version']) is dict
    assert 'major' in python_facts_1['python']['version']
    assert type(python_facts_1['python']['version']['major']) is int
    assert 'minor' in python_facts_1['python']['version']
    assert type(python_facts_1['python']['version']['minor']) is int


# Generated at 2022-06-25 00:25:14.949272
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect() == {'python': {'version': {'minor': 5,
                                                  'major': 2,
                                                  'releaselevel': 'final',
                                                  'micro': 7,
                                                  'serial': 0},
                                     'version_info': [2, 7, 7, 'final', 0],
                                     'type': 'CPython', 'executable': '/usr/bin/python',
                                     'has_sslcontext': False}}

# Generated at 2022-06-25 00:25:18.333249
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_collect = PythonFactCollector()
    mymodule = None
    mycollected_facts = None
    return python_fact_collector_collect.collect(mymodule, mycollected_facts)

# Generated at 2022-06-25 00:25:20.294808
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:24.857379
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()

    result = python_fact_collector_1.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']

# Generated at 2022-06-25 00:25:32.459909
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    collected_facts = dict()
    facts = collector.collect(collected_facts)
    assert facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info':  list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-25 00:25:40.668467
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert len(python_facts['python']['version_info']) == 5

# Generated at 2022-06-25 00:25:48.359982
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_0 = PythonFactCollector()
    python_facts = python_fact_collector_0.collect()

    assert (python_facts['python']['type'] in (None, 'CPython', 'PyPy'))
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)
    assert isinstance(python_facts['python']['executable'], str)

# Generated at 2022-06-25 00:25:57.045346
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    collected_facts = python_fact_collector_1.collect()
    assert isinstance(collected_facts, dict)
    assert isinstance(collected_facts['python'], dict)
    assert isinstance(collected_facts['python']['version'], dict)
    assert isinstance(collected_facts['python']['version']['major'], int)
    assert isinstance(collected_facts['python']['version']['minor'], int)
    assert isinstance(collected_facts['python']['version']['micro'], int)
    assert isinstance(collected_facts['python']['version']['releaselevel'], str)

# Generated at 2022-06-25 00:26:02.409604
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:26:12.933357
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    result_keys = sorted(result.keys())
    assert result_keys == ['python']



# Generated at 2022-06-25 00:26:20.184109
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts_0 = PythonFactCollector.collect()
    assert python_facts_0 == {
        'python': {
            'has_sslcontext': True,
            'executable': '/usr/bin/python',
            'version': {
                'major': 3,
                'serial': 0,
                'minor': 5,
                'releaselevel': 'final',
                'micro': 2
            },
            'version_info': [3, 5, 2, 'final', 0],
            'type': 'CPython'
        }
    }


# Generated at 2022-06-25 00:26:30.192337
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts=python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-25 00:26:31.211044
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # No code for this test case yet since it hasn't been implemented
    pass

# Generated at 2022-06-25 00:26:39.226842
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    ansible_module_0 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str')
        )
    )
    with pytest.raises(Exception) as excinfo:
        python_fact_collector_0.collect(module=ansible_module_0)
    assert 'AnsibleModule object must be passed' in str(excinfo.value)

    ansible_module_1 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str')
        )
    )
    python_fact_collector_1 = PythonFactCollector()

# Generated at 2022-06-25 00:26:43.530479
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print('Testing method collect of class PythonFactCollector')
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Unit test execution
if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:26:52.487003
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Generate a collected_facts with a missing 'python' key
    collected_facts_0 = {}
    # Call method with a missing 'python' key
    returned_python_facts_0 = python_fact_collector_0.collect(None, collected_facts_0)

    # Verify the returned value

# Generated at 2022-06-25 00:26:57.961271
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        # Fails for Python 2.6
        return

    python_fact_collector_0 = PythonFactCollector()
    if sys.version_info[0] == 2:
        check_0 = python_fact_collector_0.collect(None, None)['python']['version_info'] == str(sys.version_info)
    else:
        check_0 = python_fact_collector_0.collect(None, None)['python']['version_info'] == list(sys.version_info)

    assert check_0



# Generated at 2022-06-25 00:26:59.254093
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:00.943136
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result.__class__.__name__ == 'dict'

# Generated at 2022-06-25 00:27:09.775870
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert type(python_fact_collector_0.collect(python_fact_collector_0)) == dict


# Generated at 2022-06-25 00:27:11.334926
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    var_1 = python_fact_collector.collect(python_fact_collector)

# Generated at 2022-06-25 00:27:13.940456
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0)

    assert var_0['python']['version']['major'] == 3

# Generated at 2022-06-25 00:27:15.415348
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()

# Generated at 2022-06-25 00:27:16.588442
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Arrange
    # Act
    test_case_0()
    # Assert


# Generated at 2022-06-25 00:27:18.706257
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # No error should be raised
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_2 = PythonFactCollector()
    python_fact_collector_1.collect(python_fact_collector_2)


# Generated at 2022-06-25 00:27:20.531194
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect(python_fact_collector_0)


# Generated at 2022-06-25 00:27:24.502592
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect(python_fact_collector_1)
    assert var_1 == python_fact_collector_1.collect(python_fact_collector_1)


# Generated at 2022-06-25 00:27:32.012503
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect(python_fact_collector_1)

    assert isinstance(var_1, dict)

    assert 'python' in var_1
    var_2 = var_1['python']
    assert isinstance(var_2, dict)

    assert 'version' in var_2
    var_3 = var_2['version']
    assert isinstance(var_3, dict)

    assert 'major' in var_3
    var_4 = var_3['major']
    assert isinstance(var_4, int)

    assert 'minor' in var_3
    var_5 = var_3['minor']
    assert isinstance(var_5, int)

    assert 'micro' in var

# Generated at 2022-06-25 00:27:40.971076
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    fact_collector_0 = PythonFactCollector()
    var_0 = fact_collector_0.collect(fact_collector_0)
    # Assert 0
    if (var_0.get('python') == None):
        var_0 = fact_collector_0.collect(fact_collector_0)
    else:
        var_0 = fact_collector_0.collect(fact_collector_0)
    # Assert 1
    if (var_0.get('ansible_python') == None):
        var_0 = fact_collector_0.collect(fact_collector_0)
    else:
        var_0 = fact_collector_0.collect(fact_collector_0)
    # Assert 2

# Generated at 2022-06-25 00:28:02.247691
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_0 = python_fact_collector_1.collect(python_fact_collector_1)
    try:
        assert len(var_0["python"]["type"])
    except AssertionError as e:
        raise AssertionError(str(e) + "\nFailed at test_case_0\n")


# Generated at 2022-06-25 00:28:06.077036
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    assert obj.collect() == {'python': {'executable': '/usr/bin/python', 'version': {'serial': 115, 'releaselevel': 'final', 'major': 2, 'minor': 7, 'micro': 5}, 'has_sslcontext': False, 'version_info': [2, 7, 5, 'final', 115]}}



# Generated at 2022-06-25 00:28:14.888803
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  python_fact_collector = PythonFactCollector()
  assert python_fact_collector.collect() == {'python': {'type': 'CPython', 'version': {'releaselevel': 'final', 'serial': 0, 'micro': 5, 'minor': 2, 'major': 2}, 'has_sslcontext': True, 'executable': '/usr/bin/python', 'version_info': [2, 2, 5, 'final', 0]}}, 'Ansible python fact should collect python facts'

# Generated at 2022-06-25 00:28:19.853910
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    try:
        var_0 = python_fact_collector_0.collect()
    except Exception as exception:
        sys.exit(exception)


# Generated at 2022-06-25 00:28:22.359853
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0)


# Test for method collect of class PythonFactCollector

# Generated at 2022-06-25 00:28:22.846037
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:28:24.754137
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0)


# Generated at 2022-06-25 00:28:29.303436
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Make sure the collector can be instantiated
    python_fact_collector = PythonFactCollector()

    # Issue #31226 - make sure the collector dumps a version
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] > 0


if __name__ == '__main__':
    for testcase in (0, ):
        locals()['test_case_' + str(testcase)]()

# Generated at 2022-06-25 00:28:33.769771
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0)
    assert var_0 == {'python': {'executable': '/usr/bin/python', 'type': 'CPython',
                                'version': {'major': 2, 'minor': 7, 'micro': 5, 'releaselevel': 'final', 'serial': 0},
                                'version_info': [2, 7, 5, 'final', 0], 'has_sslcontext': False}}

# Generated at 2022-06-25 00:28:39.635726
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()
    assert var_1 is not None
    assert type(var_1) is dict
    assert len(var_1) == 2
    assert 'python' in var_1
    assert type(var_1['python']) is dict
    assert len(var_1['python']) == 5
    assert 'version' in var_1['python']
    assert type(var_1['python']['version']) is dict
    assert len(var_1['python']['version']) == 5
    assert 'major' in var_1['python']['version']
    asse

# Generated at 2022-06-25 00:29:19.190933
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_var = PythonFactCollector()
    python_fact_collector_var.collect(python_fact_collector_var)


# Generated at 2022-06-25 00:29:20.773356
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # assert isinstance(test_case_0(), dict)
    assert isinstance(test_case_0(), dict)



# Generated at 2022-06-25 00:29:24.468269
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:29:25.155488
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()



# Generated at 2022-06-25 00:29:26.891532
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0)


# Generated at 2022-06-25 00:29:31.248819
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0, )

# Generated at 2022-06-25 00:29:37.203755
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Test with expected values
    var_0 = ({
        'python': {
            'type': 'CPython',
            'version': {
                'releaselevel': 'final',
                'serial': 0,
                'micro': 0,
                'minor': 7,
                'major': 2
            },
            'version_info': [
                2,
                7,
                0,
                'final',
                0
            ],
            'executable': '/usr/bin/python',
            'has_sslcontext': True
        }
    },
        [])

    # Module executes at import
    # test_case_0()

# Generated at 2022-06-25 00:29:39.116771
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0)

# Generated at 2022-06-25 00:29:40.938154
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect(python_fact_collector_1)

# Generated at 2022-06-25 00:29:44.923922
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0)
    # Check method collect of class PythonFactCollector return type
    assert type(var_0) is dict

# Generated at 2022-06-25 00:30:53.122274
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect(python_fact_collector_0)


# Generated at 2022-06-25 00:30:54.766641
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0)


# Generated at 2022-06-25 00:30:55.182980
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:31:00.884366
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    _python_fact_collector = PythonFactCollector()
    assert _python_fact_collector.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 15, 'releaselevel': 'final', 'serial': 0},
                                         'version_info': [2, 7, 15, 'final', 0],
                                         'executable': sys.executable,
                                         'has_sslcontext': HAS_SSLCONTEXT,
                                         'type': None}}



# Generated at 2022-06-25 00:31:06.248807
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect(python_fact_collector_0)
    var_1 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:31:08.951448
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect(python_fact_collector_0)

# Generated at 2022-06-25 00:31:10.393764
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:31:17.451341
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect() == {'python': {'has_sslcontext': True, 'executable': '/usr/bin/python', 'type': None, 'version': {'releaselevel': 'final', 'major': 3, 'serial': 0, 'micro': 2, 'minor': 7}, 'version_info': [3, 7, 2, 'final', 0]}}


# Generated at 2022-06-25 00:31:22.886401
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        python_fact_collector_0 = PythonFactCollector()
        python_fact_collector_0.collect()
    except:
        assert False


if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:31:23.665051
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert test_case_0() == None