

# Generated at 2022-06-25 00:23:34.712380
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test method `collect` of class `PythonFactCollector`
    """
    python_fact_collector_0 = PythonFactCollector()

    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:23:42.885944
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = dict()
    python_fact_collector.collect(module=None, collected_facts=collected_facts)
    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-25 00:23:51.629200
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    # Tests for major version
    assert python_facts['python']['version']['major'] == 3
    # Tests for minor version
    assert python_facts['python']['version']['minor'] == 5
    # Tests for micro version
    assert python_facts['python']['version']['micro'] == 2
    # Tests for releaselevel
    assert python_facts['python']['version']['releaselevel'] == 'final'
    # Tests for serial
    assert python_facts['python']['version']['serial'] == 0
    # Tests for version info
    assert python_facts['python']['version_info'] == [3, 5, 2, 'final', 0]
    #

# Generated at 2022-06-25 00:23:56.276530
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = dict()
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect(collected_facts=collected_facts)
    assert collected_facts == {'python': {'version': {'major': 3, 'micro': 7, 'minor': 0, 'releaselevel': 'final', 'serial': 0}, 'has_sslcontext': True, 'executable': '/usr/bin/python3', 'version_info': [3, 7, 0, 'final', 0], 'type': 'CPython'}}


# Generated at 2022-06-25 00:23:59.570149
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    collected_facts = dict()
    python_fact_collector_1.collect(collected_facts=collected_facts)

# Generated at 2022-06-25 00:24:04.973529
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    test_fact_result_1 = python_fact_collector_1.collect()
    assert 'python' in test_fact_result_1
    assert 'version' in test_fact_result_1['python']
    assert 'type' in test_fact_result_1['python']
    assert 'executable' in test_fact_result_1['python']
    assert 'has_sslcontext' in test_fact_result_1['python']


# Generated at 2022-06-25 00:24:10.985579
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect() == {u'python': {u'executable': u'/usr/bin/python2', u'has_sslcontext': True, u'version': {u'major': 2, u'micro': 7, u'releaselevel': u'final', u'minor': 7, u'serial': 0}, u'type': u'CPython', u'version_info': [2, 7, 13, u'final', 0]}}

# Generated at 2022-06-25 00:24:12.471113
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()


# Generated at 2022-06-25 00:24:18.252483
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print('Starting test_PythonFactCollector_collect')
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()
    assert result['python']['version']['major'] >= 2
    print('test_PythonFactCollector_collect passed!')

if __name__ == '__main__':
    test_case_0()
    test_PythonFactCollector_collect()

# Generated at 2022-06-25 00:24:21.750111
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    assert isinstance(python_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:24:32.050036
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    this_module = sys.modules[__name__]
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    python_facts = python_fact_collector.collect(this_module, collected_facts)
    assert isinstance(python_facts, dict)
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-25 00:24:42.724143
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Following tests may be prone to failure in case of garbage collection.
    # So let's just run a 100 times and keep checking if we get the answer
    # we want.
    for i in range(100):
        python_fact_collector = PythonFactCollector()
        version_info = list(sys.version_info)
        fact_dict = python_fact_collector.collect(module=None,
                                                  collected_facts=None)
        assert fact_dict['python']['version_info'] == version_info[:]
        assert fact_dict['python']['executable'] == sys.executable
        assert fact_dict['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-25 00:24:49.837387
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_facts_0 = python_fact_collector_0.collect()
    python_facts_keys_0 = python_facts_0.keys()
    python_facts_keys_0.sort()
    python_fact_collector_1 = PythonFactCollector()
    python_facts_1 = python_fact_collector_1.collect()
    python_facts_keys_1 = python_facts_1.keys()
    python_facts_keys_1.sort()
    assert python_facts_keys_0 == ['python']
    assert python_facts_keys_1 == ['python']


# Generated at 2022-06-25 00:24:56.990966
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = {
        'python': {
            'type': 'CPython',
            'version': {
                'releaselevel': 'final',
                'serial': 0,
                'micro': 0,
                'minor': 8,
                'major': 2
            },
            'version_info': [2, 8, 0, 'final', 0],
            'has_sslcontext': False,
            'executable': '/usr/bin/python'
        }
    }
    python_fact_collector_1 = PythonFactCollector()
    assert python_fact_collector_1.collect() == result

# Generated at 2022-06-25 00:24:58.969661
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:07.208517
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable


# Generated at 2022-06-25 00:25:12.779187
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    result = PythonFactCollector().collect()

    assert result == {
        'python': {
            'executable': '/usr/bin/python2.7',
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'major': 2,
                'micro': 7,
                'minor': 6,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 6, 7, 'final', 0]
        }
    }

# Generated at 2022-06-25 00:25:20.376952
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # This is really a trivial test, since the method does not take any arguments.
    assert python_fact_collector_0.collect() == {'python': {'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': None, 'version_info': [2, 7, 5, 'final', 0], 'version': {'releaselevel': 'final', 'major': 2, 'minor': 7, 'micro': 5, 'serial': 0}}}

# Generated at 2022-06-25 00:25:26.881258
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc.collect()['python']['executable'] == sys.executable
    assert pfc.collect()['python']['version_info'] == list(sys.version_info)
    assert pfc.collect()['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }

# Generated at 2022-06-25 00:25:27.410224
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:25:33.352567
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:39.305927
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = (python_fact_collector_0.collect(collected_facts={})).get('python')
    var_2 = var_1.get('version')
    var_3 = var_2.get('major')
    var_4 = var_2.get('minor')
    var_5 = var_2.get('micro')
    var_6 = var_2.get('releaselevel')
    var_7 = var_2.get('serial')
    var_8 = var_1.get('executable')
    var_9 = var_1.get('has_sslcontext')

# Generated at 2022-06-25 00:25:40.128892
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test case #0
    test_case_0()

# Generated at 2022-06-25 00:25:44.389719
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()
    assert 'python' in python_fact_collector_0.collect()


# Generated at 2022-06-25 00:25:48.360879
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector().collect()
    var_1 = PythonFactCollector().collect()

    # Test if var_0 is an instance of PythonFactCollector
    assert isinstance(var_0, dict)

    # Test if var_1 is an instance of PythonFactCollector
    assert isinstance(var_1, dict)



# Generated at 2022-06-25 00:25:50.146146
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:25:51.266051
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector(None, None).collect()


# Generated at 2022-06-25 00:25:53.272848
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    # Assertions
    # assert var_0 ==

# Generated at 2022-06-25 00:25:56.211313
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # Method collect of PythonFactCollector class is called
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:01.822393
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_1 = PythonFactCollector()
    python_fact_collector_2 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    var_1 = python_fact_collector_1.collect()
    var_2 = python_fact_collector_2.collect()
    # Check if facts returned by PythonFactCollector
    # method collect match python facts
    assert(var_0 == var_1)
    assert(var_1 == var_2)
    assert(var_0 == var_2)

# Generated at 2022-06-25 00:26:17.134633
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Arrange
    python_fact_collector_0 = PythonFactCollector()

    # Act
    var_0 = python_fact_collector_0.collect()

    # Assert
    assert var_0 == {'python': {'version': {'major': 3, 'minor': 6, 'micro': 6, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 6, 6, 'final', 0], 'executable': '/usr/local/bin/python3', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-25 00:26:18.765476
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector_0 = PythonFactCollector()
    var_0 = collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:26:20.821257
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    result_0 = python_fact_collector_0.collect()
    print(result_0)

# Generated at 2022-06-25 00:26:30.210451
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {
        u'python': {
            u'version': {
                u'major': sys.version_info[0],
                u'minor': sys.version_info[1],
                u'micro': sys.version_info[2],
                u'releaselevel': sys.version_info[3],
                u'serial': sys.version_info[4]
            },
            u'version_info': list(sys.version_info),
            u'executable': sys.executable,
            u'type': sys.implementation.name,
            u'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-25 00:26:31.755819
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:26:36.532033
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Note: there are no asserts in these tests
    global python_fact_collector_0
    test_case_0()


# Generated at 2022-06-25 00:26:39.072978
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""
    python_fact_collector_0 = PythonFactCollector()
    # PythonFactCollector has no collect method
    assert not hasattr(python_fact_collector_0, 'collect')


# Generated at 2022-06-25 00:26:43.691030
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of a class
    python_fact_collector_0 = PythonFactCollector()
    # Call method collect of the class with a specific argument
    return_value = python_fact_collector_0.collect()
    assert return_value is not None
    # Method collect of the class returns a dictionary
    assert type(return_value) == dict

# Generated at 2022-06-25 00:26:52.668427
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:26:54.855062
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0.collect()

# Generated at 2022-06-25 00:27:12.131541
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()
    var_1 = var_0.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:27:18.028379
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test with collect_subset:
    # Test with gather_subset:
    # Test with filter:
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'executable': '/Users/michaelbe/miniconda3/envs/2.7_ansible_swig/bin/python', 'has_sslcontext': True, 'type': 'CPython', 'version': {'major': 2, 'micro': 7, 'minor': 11, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 11, 'final', 0]}}, var_0

# Generated at 2022-06-25 00:27:18.906103
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert (test_case_0())

# Assert error on no arguments given

# Generated at 2022-06-25 00:27:20.474265
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()



# Generated at 2022-06-25 00:27:24.199198
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0['python']['version']['major'] == 3
    assert var_0['python']['type'] == 'CPython'

# Generated at 2022-06-25 00:27:31.812992
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Getting the value of var_0
    var_0 = python_fact_collector_0.collect()
    # Getting the value of var_1
    var_1 = python_fact_collector_0.collect()
    # Getting the value of var_2
    var_2 = python_fact_collector_0.collect()
    # Getting the value of var_3
    var_3 = python_fact_collector_0.collect()
    # Getting the value of var_4
    var_4 = python_fact_collector_0.collect()
    # Getting the value of var_5
    var_5 = python_fact_collector_0.collect()
    # Getting the value of var_6
    var_6 = python_fact_collector_0.collect()
    # Getting the value of var_7


# Generated at 2022-06-25 00:27:36.432312
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:27:41.921742
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    var_0 = PythonFactCollector()
    var_1 = var_0.collect()
    assert var_1.get('python')
    assert var_1.get('python').get('type') == 'cpython'
    assert var_1.get('python').get('executable')
    assert var_1.get('python').get('version')

# Generated at 2022-06-25 00:27:46.121440
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    print("test_PythonFactCollector_collect")
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert var_0 == {'python': {'has_sslcontext': True, 'version': {'releaselevel': 'final', 'major': 2, 'serial': 0, 'minor': 7, 'micro': 3}, 'type': 'CPython', 'executable': '/usr/bin/python', 'version_info': [2, 7, 3, 'final', 0]}}

# Generated at 2022-06-25 00:27:46.778969
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert isinstance(test_case_0(), dict)

# Generated at 2022-06-25 00:28:22.523550
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    python_fact_collector_1 = PythonFactCollector()
    var_1 = python_fact_collector_1.collect()



# Generated at 2022-06-25 00:28:26.998286
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector_0_obj = PythonFactCollector()
    py_collector_0_obj.collect()


# Generated at 2022-06-25 00:28:29.520240
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()


# Generated at 2022-06-25 00:28:32.056790
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Check that hasattr(PythonFactCollector, 'collect') is True
    assert hasattr(PythonFactCollector, 'collect')

    # Check that the call to PythonFactCollector.collect() raises no exceptions
    test_case_0()

# Generated at 2022-06-25 00:28:33.442024
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect({}, {})

# Generated at 2022-06-25 00:28:38.241609
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    var_1 = var_0.get('python', {}).get('version', {})

    assert var_1 == {'major': 3, 'minor': 5, 'micro': 2, 'releaselevel': 'final', 'serial': 0}
    assert var_0.get('python', {}).get('has_sslcontext') == False

test_case_0()

# Generated at 2022-06-25 00:28:41.588323
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    # Check if the base class is being called correctly
    # Check if _fact_ids is set correctly
    assert set(python_fact_collector_0._fact_ids) == {'python'}
    # Check if the return value is a dictionary
    assert type(python_fact_collector_0.collect()) is dict

# Generated at 2022-06-25 00:28:44.196899
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

# Generated at 2022-06-25 00:28:48.508304
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert (var_0["python"])
    assert ('type' in var_0["python"])
    assert ('version' in var_0["python"])
    assert ('has_sslcontext' in var_0["python"])
    assert ('executable' in var_0["python"])
    assert ('version_info' in var_0["python"])

# Generated at 2022-06-25 00:28:56.112678
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()

    # Test with 0 parameter(s)
    res_0 = python_fact_collector_0.collect()
    assert isinstance(res_0, dict)

# Generated at 2022-06-25 00:30:11.405604
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert(var_0 == {'python': {'version': {'major': 2, 'micro': 7, 'releaselevel': 'final', 'minor': 5, 'serial': 0}, 'has_sslcontext': False, 'type': None, 'version_info': [2, 7, 5], 'executable': u'/usr/bin/python'}})

# Generated at 2022-06-25 00:30:14.883229
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
    assert type(var_0) == dict
    assert var_0['python']['executable'] == sys.executable
    # TODO: check version, type and has_sslcontext values

# Generated at 2022-06-25 00:30:21.246532
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    try:
        if sys.version_info >= (3, 0):
            var = python_fact_collector.collect()
        else:
            var = python_fact_collector.collect()
    except Exception as e:
        print('Exception raised: {0}'.format(e))
    else:
        if var is not None:
            print('Python facts: {0}'.format(var))
    finally:
        print('Executed test case for method collect of class PythonFactCollector')


if __name__ == '__main__':
    #test_PythonFactCollector_collect()
    test_case_0()

# Generated at 2022-06-25 00:30:27.578930
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_1 = python_fact_collector_0.collect()
    assert var_1 == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 12, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 12, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': False, 'type': 'CPython'}}


# Generated at 2022-06-25 00:30:30.014762
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # No input parameters returned
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()

    # test_data has many return parms
    # which is not supported by ansible
    # As of ansible 2.6.8


# Generated at 2022-06-25 00:30:31.057741
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()


# Generated at 2022-06-25 00:30:32.387494
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Invoke method
    var_return = python_fact_collector_0.collect()

    # Verify method output
    assert var_return is not None

# Generated at 2022-06-25 00:30:36.838427
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create mock object
    python_fact_collector = PythonFactCollector()
    # Call method collect with default arguments of mock object
    var_returned = python_fact_collector.collect()
    # Assert return value of method collect
    assert var_returned == {'python': {'version': {'major': 3, 'minor': 6, 'micro': 5, 'releaselevel': 'final',
                                                   'serial': 0}, 'version_info': [3, 6, 5, 'final', 0],
                                                'executable': '/usr/bin/python3', 'has_sslcontext': True,
                                                'type': 'CPython'}}


# Generated at 2022-06-25 00:30:38.358433
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_test_python_fact_collector_0 = PythonFactCollector()
    py_test_python_fact_collector_0.collect()

# Assert function for class PythonFactCollector

# Generated at 2022-06-25 00:30:39.541260
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    function_result = python_fact_collector.collect()
    assert function_result is not None

# Generated at 2022-06-25 00:33:13.015921
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-25 00:33:15.196878
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    python_fact_collector_0._fact_ids = {}
    assert python_fact_collector_0.name == 'python'

# Generated at 2022-06-25 00:33:17.695850
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:33:27.245818
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_1 = PythonFactCollector()
    # AssertionError: The 'python' key is not in the returned facts
    assert python_fact_collector_1.collect().get('python')
    # AssertionError: The 'type' key is not in the returned facts
    assert python_fact_collector_1.collect().get('type')
    # AssertionError: The 'version' key is not in the returned facts
    assert python_fact_collector_1.collect().get('version')
    # AssertionError: The 'version_info' key is not in the returned facts
    assert python_fact_collector_1.collect().get('version_info')
    # AssertionError: The 'executable' key is not in the returned facts

# Generated at 2022-06-25 00:33:29.694024
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector_0 = PythonFactCollector()
    var_0 = python_fact_collector_0.collect()
