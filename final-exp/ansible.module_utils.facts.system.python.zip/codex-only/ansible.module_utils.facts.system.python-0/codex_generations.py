

# Generated at 2022-06-23 01:29:32.950812
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:29:34.722455
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Prepare test
    ph = PythonFactCollector()
    # Execute test
    actual_result = ph.collect()
    # Verify the result
    assert 'python' in actual_result

# Generated at 2022-06-23 01:29:49.896861
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import os
    import pwd
    import json

    # Create a mock file system
    class MockFileSystem:
        def __init__(self):
            self.files = {}

        class Tag:
            def __init__(self, file):
                self.file = file

            def __enter__(self):
                return self

            def __exit__(self, type, value, traceback):
                self.file.close()

        def open(self, path, mode):
            if not path in self.files:
                self.files[path] = open(path, mode)

            return MockFileSystem.Tag(self.files[path])

    # Check the output of method collect of class PythonFactCollector when
    # the optional arguments are not given

# Generated at 2022-06-23 01:29:56.138256
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyPack = PythonFactCollector()
    pyList = pyPack.collect()
    assert pyList == {'python':{'version':{'major':2, 'minor':7, 'micro':5, 'releaselevel':'final', 'serial':0}, 'version_info':[2, 7, 5, 'final', 0], 'executable':'/usr/bin/python', 'has_sslcontext':False, 'type':None}}

# Generated at 2022-06-23 01:29:58.158272
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test with default parameters
    PythonFactCollector()

    # Test with specified parameters
    PythonFactCollector(name='test')

# Generated at 2022-06-23 01:30:00.712497
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc is not None
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:30:04.558572
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:30:14.738721
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    fact_data = python_fact.collect()

    assert fact_data['python']['version']['major'] >= 2
    assert fact_data['python']['version']['minor'] >= 6
    assert fact_data['python']['version']['micro'] == 0
    assert fact_data['python']['version']['releaselevel'] in ('alpha', 'beta', 'candidate', 'final')
    assert fact_data['python']['version']['serial'] >= 0
    assert fact_data['python']['version_info'] >= (2,6,0)
    assert fact_data['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:30:18.160467
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pycol = PythonFactCollector()
    assert pycol is not None
    assert pycol.name == 'python'
    assert pycol._fact_ids is not None
    assert isinstance(pycol._fact_ids, set)


# Generated at 2022-06-23 01:30:19.615436
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-23 01:30:22.936603
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'
    # test that you can loop through the object
    for _ in python:
        break
    assert python.collect()['python']['version']['major'] >= 2

# Generated at 2022-06-23 01:30:31.220842
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert python_facts['python']['version'] == {'major': sys.version_info[0],
                                                 'minor': sys.version_info[1],
                                                 'micro': sys.version_info[2],
                                                 'releaselevel': sys.version_info[3],
                                                 'serial': sys.version_info[4]}
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-23 01:30:41.036779
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:30:51.209878
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts_list = python_fact_collector.collect()

    assert 'version' in python_facts_list
    assert 'python' in python_facts_list['version']
    assert 'version_info' in python_facts_list
    assert 'python' in python_facts_list['version_info']
    assert 'executable' in python_facts_list
    assert 'python' in python_facts_list['executable']
    assert 'type' in python_facts_list
    assert 'python' in python_facts_list['type']

# Generated at 2022-06-23 01:31:00.897006
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector.facts['python']['version']['major'], fact_collector.facts['python']
    assert fact_collector.facts['python']['version']['minor'], fact_collector.facts['python']
    assert fact_collector.facts['python']['version']['micro'], fact_collector.facts['python']
    assert fact_collector.facts['python']['version']['releaselevel'], fact_collector.facts['python']
    assert fact_collector.facts['python']['version']['serial'], fact_collector.facts['python']
    assert fact_collector.facts['python']['version_info'][0], fact_collector.facts

# Generated at 2022-06-23 01:31:12.402106
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    # Setup a simple collector object to test
    test_collector = Collector()
    test_collector.add_collector(PythonFactCollector())
    collected_facts = test_collector.collect(module=None, collected_facts={})

    # Expected keys to find in the return
    test_keys = ['python']

    # Test that the keys 'python' exist in the collected facts
    assert set(test_keys).issubset(set(collected_facts.keys()))

    # Test that the value of the keys in test_keys are the expected value
    for item in test_keys:
        assert isinstance(collected_facts[item], dict)

# Generated at 2022-06-23 01:31:21.125046
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    fact_data = python_fact_collector.collect()
    assert fact_data.get("python", {}).get("type") == sys.subversion[0]
    assert fact_data.get("python", {}).get("has_sslcontext") == HAS_SSLCONTEXT
    assert fact_data.get("python", {}).get("executable") == sys.executable
    assert fact_data.get("python", {}).get("version_info") == list(sys.version_info)
    assert fact_data.get("python", {}).get("version", {}).get("micro") == sys.version_info[2]
    assert fact_data.get("python", {}).get("version", {}).get("major") == sys.version_info[0]
    assert fact

# Generated at 2022-06-23 01:31:23.325918
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.collect()['python']['executable'] == sys.executable
    assert obj.name == 'python'

# Generated at 2022-06-23 01:31:26.227235
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test that it is possible to create a PythonFactCollector object."""
    python_fact_collector = PythonFactCollector()

    assert isinstance(python_fact_collector, PythonFactCollector)

# Generated at 2022-06-23 01:31:30.017128
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()


# Generated at 2022-06-23 01:31:41.376465
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import pytest
    from distutils.version import LooseVersion

    # Required for mocking
    sys.modules['ansible'] = None

    input_data = {'ansible_facts': {}}
    test_obj = PythonFactCollector()

    result = test_obj.collect(input_data, input_data['ansible_facts'])
    assert isinstance(result['python']['version']['major'], int)
    assert isinstance(result['python']['version']['minor'], int)
    assert isinstance(result['python']['version']['micro'], int)
    assert isinstance(result['python']['version']['releaselevel'], str)
    assert isinstance(result['python']['version']['serial'], int)

# Generated at 2022-06-23 01:31:49.297398
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc.collect()['python']['version']['major'] == sys.version_info[0]
    assert pfc.collect()['python']['version']['minor'] == sys.version_info[1]
    assert pfc.collect()['python']['version']['micro'] == sys.version_info[2]
    assert pfc.collect()['python']['version']['releaselevel'] == sys.version_info[3]
    assert pfc.collect()['python']['version']['serial'] == sys.version_info[4]
    assert pfc.collect()['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:31:51.948669
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:31:56.044312
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test the PythonFactCollector class"""
    from ansible.module_utils.facts.collector import CachingFileLock
    pfc = PythonFactCollector()
    assert isinstance(pfc.lock, CachingFileLock)
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:31:58.376678
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert 'python' in python_fact_collector._fact_ids

# Generated at 2022-06-23 01:31:59.531189
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc.name == 'python'

# Generated at 2022-06-23 01:32:00.689878
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:32:05.750981
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert type(facts) == dict
    assert facts.get('python',None) != None
    assert facts.get('python',{}).get('version',None) != None
    assert facts.get('python',{}).get('version_info',None) != None
    assert facts.get('python',{}).get('executable',None) != None
    assert facts.get('python',{}).get('has_sslcontext',None) != None
    assert facts.get('python',{}).get('type',None) != None


# Generated at 2022-06-23 01:32:07.295663
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-23 01:32:11.631590
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert isinstance(python_facts, PythonFactCollector)
    assert python_facts.name == 'python'
    assert python_facts._fact_ids == set()



# Generated at 2022-06-23 01:32:12.719193
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:32:19.659345
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:32:28.612778
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert 'python' in python_facts
    assert 'type' in python_facts['python']
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert isinstance(python_facts['python']['version_info'], list)
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'executable' in python_facts['python']

# Generated at 2022-06-23 01:32:37.493211
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector = PythonFactCollector()

    returned_facts = python_fact_collector.collect()

    assert returned_facts
    assert returned_facts['python']
    assert returned_facts['python']['version_info']
    assert returned_facts['python']['version']
    assert returned_facts['python']['version']['major'] == sys.version_info[0]
    assert returned_facts['python']['version']['minor'] == sys.version_info[1]
    assert returned_facts['python']['version']['micro'] == sys.version_info[2]
    assert returned_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert returned_facts['python']['version']['serial'] == sys.version_

# Generated at 2022-06-23 01:32:40.046389
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()

    # test name, _fact_ids and collect()
    assert p.name == 'python'
    assert p._fact_ids == set()
    assert isinstance(p.collect(), dict)

# Generated at 2022-06-23 01:32:40.632717
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:32:41.195282
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:32:50.508500
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    collected_facts = python_collector.collect()['python']
    assert int(collected_facts['version']['major']) > 0
    assert int(collected_facts['version']['minor']) >= 0
    assert int(collected_facts['version']['micro']) >= 0
    assert collected_facts['version']['releaselevel'] in ['alpha', 'beta', 'candidate', 'final']
    assert int(collected_facts['version']['serial']) >= 0
    assert len(collected_facts['version_info']) == 5
    assert collected_facts['executable']
    # TODO: should be in a different test file
    assert collected_facts['has_sslcontext'] == hasattr(sys, 'getdefaultcertfile')

# Generated at 2022-06-23 01:32:57.232143
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector.python import PythonFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    obj = PythonFactCollector()

    assert obj is not None
    assert isinstance(obj, PythonFactCollector)
    assert isinstance(obj, BaseFactCollector)

    python_facts = obj.collect()

    assert 'python' in python_facts
    assert python_facts['python']['type'] is not None
    assert python_facts['python']['executable'] is not None

# Generated at 2022-06-23 01:33:00.069334
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set(['python'])


# Generated at 2022-06-23 01:33:10.770742
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    result = {}
    returned_facts = p.collect(None, result)
    print(repr(result))
    assert 'python' in returned_facts
    assert returned_facts['python']
    assert 'executable' in returned_facts['python']
    assert 'version' in returned_facts['python']
    assert returned_facts['python']['version']
    assert 'major' in returned_facts['python']['version']
    assert 'minor' in returned_facts['python']['version']
    assert 'micro' in returned_facts['python']['version']
    assert 'releaselevel' in returned_facts['python']['version']
    assert 'serial' in returned_facts['python']['version']
    assert 'version_info' in returned_facts['python']
   

# Generated at 2022-06-23 01:33:14.704813
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pycollect = PythonFactCollector()
    assert pycollect.name == 'python'
    assert pycollect._fact_ids == set()

# Generated at 2022-06-23 01:33:20.870111
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:33:22.935919
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    assert isinstance(python_fact.collect(), dict)

# Generated at 2022-06-23 01:33:23.893185
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:33:29.566944
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'implementation' not in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']

# Generated at 2022-06-23 01:33:40.793804
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Setup
    python_fact_collector = PythonFactCollector()
    python_facts = {}

    # Test
    actual_result = python_fact_collector.collect(python_facts)

    # Verify
    expected_result = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-23 01:33:43.135423
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)


# Generated at 2022-06-23 01:33:45.966151
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    with patch('ansible.module_utils.facts.collector.BaseFactCollector') as bfc:
        PythonFactCollector()
        bfc.assert_called_once_with('python')


# Generated at 2022-06-23 01:33:49.956739
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:33:51.778713
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert 'python' == python_collector.name

# Generated at 2022-06-23 01:33:53.566826
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    coll = PythonFactCollector()
    assert coll.name == 'python'
    assert coll._fact_ids is not None

# Generated at 2022-06-23 01:33:56.167674
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set([])


# Generated at 2022-06-23 01:33:58.290799
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    pf_collect = pf.collect()
    assert pf_collect is not None

# Generated at 2022-06-23 01:34:07.592000
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a PythonFactCollector object
    python_fact_collector = PythonFactCollector()

    # Check if the result from the object is what we expect
    assert python_fact_collector.collect() == {'python': {'type': 'CPython',
                                                          'version': {'major': 3,
                                                                      'minor': 6,
                                                                      'micro': 0,
                                                                      'releaselevel': 'final',
                                                                      'serial': 0
                                                                      },
                                                          'version_info': [3, 6, 0, 'final', 0],
                                                          'executable': sys.executable,
                                                          'has_sslcontext': True
                                                          }
                                               }

# Generated at 2022-06-23 01:34:15.890091
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python', 'Test PythonFactCollector.name failed!'
    assert len(PythonFactCollector._fact_ids) == 0, 'Test len(PythonFactCollector._fact_ids) failed!'

    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python', 'Test python_fact_collector.name failed!'
    assert len(python_fact_collector._fact_ids) == 0, 'Test len(python_fact_collector._fact_ids) failed!'


# Generated at 2022-06-23 01:34:21.692136
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Return a dict of facts about the Python install."""
    pfc = PythonFactCollector()
    assert len(pfc._fact_ids) == 0
    assert pfc.name == 'python'
    assert len(pfc.collect().keys()) == 1
    assert list(pfc.collect().keys())[0] == 'python'

# Generated at 2022-06-23 01:34:31.677023
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = {
        'version': {
            'major': 3,
            'minor': 4,
            'micro': 4,
            'releaselevel': 'final',
            'serial': 0
        },
        'version_info': [3, 4, 4, 'final', 0],
        'executable': '/usr/bin/python',
        'has_sslcontext': True
    }

    import sys
    if sys.version_info < (3,):
        python_facts['type'] = 'CPython'
    else:
        python_facts['type'] = None

    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()
    assert pfc.collect()['python'] == python_facts

# Generated at 2022-06-23 01:34:41.226035
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from sys import version_info as python_version_info
    from sys import executable as python_executable

    pfc = PythonFactCollector()
    python_facts = pfc.collect()

    assert python_facts['python']['version']['major'] == python_version_info[0]
    assert python_facts['python']['version']['minor'] == python_version_info[1]
    assert python_facts['python']['version']['micro'] == python_version_info[2]
    assert python_facts['python']['version']['releaselevel'] == python_version_info[3]
    assert python_facts['python']['version']['serial'] == python_version_info[4]

# Generated at 2022-06-23 01:34:42.660566
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:34:44.890030
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()

    assert collector is not None
    assert isinstance(collector.name, str)
    assert isinstance(collector._fact_ids, set)

# Generated at 2022-06-23 01:34:46.686910
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    python_facts = PythonFactCollector()

    assert python_facts.name == 'python'
    assert python_facts._fact_ids == set()

# Generated at 2022-06-23 01:34:53.293919
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Check on various versions of Python
    assert PythonFactCollector().collect()['python']['version_info'] == list(sys.version_info)

    if sys.version_info[3] == 'final':
        assert PythonFactCollector().collect()['python']['version']['releaselevel'] == 'final'
    else:
        assert PythonFactCollector().collect()['python']['version']['releaselevel'] == 'alpha'


# Generated at 2022-06-23 01:34:58.747077
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()
    # There are no assertions because the collect() method has no return value
    pfc.collect()
    assert len(pfc._fact_ids) > 0

# Generated at 2022-06-23 01:35:02.217863
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'


# Generated at 2022-06-23 01:35:05.416836
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    py_fact_collector.collect()
    assert py_fact_collector._fact_ids == set(['python'])

# Generated at 2022-06-23 01:35:08.312642
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # instantiate PythonFactCollector class
    pfc_obj = PythonFactCollector()

    # call collect method to get python facts
    facts = pfc_obj.collect()

    # assert that key 'python' exists in facts
    assert 'python' in facts

# Generated at 2022-06-23 01:35:14.827449
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()

    assert python_facts.collect()['python']['version']['major'] == sys.version_info[0]
    assert python_facts.collect()['python']['version_info'] == list(sys.version_info)
    assert python_facts.collect()['python']['executable'] == sys.executable
    assert python_facts.collect()['python']['type'] == sys.subversion[0]

# Generated at 2022-06-23 01:35:16.533121
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pythonFactCollector = PythonFactCollector()
    res = pythonFactCollector.collect()
    assert res is not None

# Generated at 2022-06-23 01:35:19.954692
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()

    assert type(result) == dict
    assert len(result) == 1
    assert 'python' in result


# Generated at 2022-06-23 01:35:27.857803
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert 'python' in facts
    assert facts['python']['type'] == 'CPython'
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-23 01:35:35.824396
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    py_collector.collect()
    py_facts = py_collector.get_facts()
    assert 'ansible_facts' in py_facts
    assert 'python' in py_facts['ansible_facts']
    assert 'version' in py_facts['ansible_facts']['python']
    assert 'version_info' in py_facts['ansible_facts']['python']
    assert 'executable' in py_facts['ansible_facts']['python']
    assert 'type' in py_facts['ansible_facts']['python']
    assert 'has_sslcontext' in py_facts['ansible_facts']['python']

# Generated at 2022-06-23 01:35:39.811844
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert isinstance(PythonFactCollector._fact_ids, set)
    assert isinstance(PythonFactCollector.collect(), dict)

# Generated at 2022-06-23 01:35:48.456831
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    try:
        import collections
        # This is the BaseFactCollector.__init__ signature.
        # AnsibleModule() and collected_facts should not be used by the class.
        PythonFactCollector(None, None)
    except TypeError:
        # Python 2.6 does not support the signature we need.
        if sys.version_info < (2, 7):
            raise
        else:
            raise AssertionError("Unexpected error detecting Python version")
    except ImportError:
        # Python 2.6 does not support the signature we use.
        if sys.version_info < (2, 7):
            raise
        else:
            raise AssertionError("Unexpected error detecting Python version")
    except AssertionError:
        raise
    except Exception:
        raise AssertionError("Unexpected error detecting Python version")


# Generated at 2022-06-23 01:35:55.931683
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test the collect method of PythonFactCollector
    """
    # Create a PythonFactCollector object
    pfc = PythonFactCollector()

    # Get the facts
    facts = pfc.collect()

    # Verify there is a python key, and verify that it has required keys
    assert 'python' in facts
    fact_keys = facts['python'].keys()
    assert 'version' in fact_keys
    assert 'version_info' in fact_keys
    assert 'executable' in fact_keys

    # Verify that the mandatory keys has the correct type
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)

# Generated at 2022-06-23 01:35:59.952474
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:36:09.471744
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    def get_default_func():
        pass

    instance = get_collector_instance('python')
    result = instance.collect()

    assert 'python' in result
    assert result['python']['type'] == 'CPython'
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:36:11.217076
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_collector = PythonFactCollector()
    assert facts_collector.name == 'python'

# Generated at 2022-06-23 01:36:16.949068
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == "python"
    assert pfc.collect() == {'python': {'version': {'major': 3, 'minor': 6, 'micro': 2, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 6, 2, 'final', 0], 'executable': '/home/adamschoenemann/src/ansible/hacking/env-setup', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-23 01:36:20.328457
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set([])

# Generated at 2022-06-23 01:36:27.742909
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PF = PythonFactCollector()
    version = sys.version_info
    assert PF.collect() == dict(python=dict(has_sslcontext=HAS_SSLCONTEXT, version_info=list(version), executable=sys.executable, type=sys.subversion[0] if hasattr(sys, "subversion") else sys.implementation.name if hasattr(sys, "implementation") else None, version=dict(major=version[0], minor=version[1], micro=version[2], releaselevel=version[3], serial=version[4])))

# Generated at 2022-06-23 01:36:30.516727
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    with pytest.raises(TypeError) as excinfo:
        PythonFactCollector('test')
    assert excinfo.value.message == "PythonFactCollector takes no arguments"

# Generated at 2022-06-23 01:36:34.837473
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert isinstance(python_fact_collector._fact_ids, set)
    assert 'python' in python_fact_collector._fact_ids

# Generated at 2022-06-23 01:36:36.298509
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-23 01:36:41.686494
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    class FakeModule(object):
        def fail_json(self, kwargs):
            pass

    class FakeFactCollector(object):
        def __init__(self, module=None):
            self.module = module
        def collect(self, module=None, collected_facts=None):
            return {'test': 'value'}

    pfc = PythonFactCollector(module=FakeModule())
    pfc._collect_subset = FakeFactCollector(module=FakeModule())
    result = pfc.collect(module=FakeModule(), collected_facts=None)
    assert result['python']['type'] is not None



# Generated at 2022-06-23 01:36:52.513348
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    if HAS_SSLCONTEXT:
        assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    else:
        assert 'has_sslcontext' not in python_facts['python']
    try:
        assert python_facts['python']['type'] == sys.subversion[0]
    except AttributeError:
        try:
            assert python_facts['python']['type'] == sys.implementation.name
        except AttributeError:
            assert python_facts['python']['type'] == None

# Generated at 2022-06-23 01:37:01.267092
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Unit test for method collect of class PythonFactCollector
    '''
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, PythonFactCollector)
    result = python_fact_collector.collect()
    assert len(result['python']['version']) == 5
    assert len(result['python']['version_info']) == 5
    assert isinstance(result['python']['type'], str)
    assert isinstance(result['python']['executable'], str)
    assert isinstance(result['python']['has_sslcontext'], bool)

# Generated at 2022-06-23 01:37:04.971118
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:37:13.984468
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    import platform

    ver_tuple = platform.python_version_tuple()
    pyth_ver = ver_tuple[0] + '.' + ver_tuple[1] + '.' + ver_tuple[2]

    if ver_tuple[3] == 'alpha':
        pyth_ver = pyth_ver + 'a'
    elif ver_tuple[3] == 'beta':
        pyth_ver = pyth_ver + 'b'
    elif ver_tuple[3] == 'candidate':
        pyth_ver = pyth_ver + 'c'
    elif ver_tuple[3] == 'final':
        pyth_ver = pyth_ver

# Generated at 2022-06-23 01:37:16.128098
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:37:21.375844
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector({}, None)
    result = p.collect()

    assert result['python']['version_info'][3] in ['alpha', 'beta', 'candidate', 'final']
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:37:31.224376
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    python_facts_collection = c.collect()
    assert python_facts_collection['python']['version']['major'] == sys.version_info[0]
    assert python_facts_collection['python']['version']['minor'] == sys.version_info[1]
    assert python_facts_collection['python']['version']['micro'] == sys.version_info[2]
    assert python_facts_collection['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts_collection['python']['version']['serial'] == sys.version_info[4]
    assert python_facts_collection['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:37:44.112401
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collectors.python import PythonFactCollector
    py_collected_facts = PythonFactCollector(None, Facts({})).collect()
    assert py_collected_facts['python']['type'] == sys.subversion[0]
    assert py_collected_facts['python']['version']['major'] == sys.version_info[0]
    assert py_collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_collected_facts['python']['version']['releaselevel'] == sys.version_

# Generated at 2022-06-23 01:37:45.873600
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect().get('python')

# Generated at 2022-06-23 01:37:48.680788
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector(None)
    assert pyfc.name == 'python'
    assert pyfc.platform == None
    assert pyfc._fact_ids == set()


# Generated at 2022-06-23 01:37:59.817734
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test import of module
    try:
        # noinspection PyUnresolvedReferences
        from ansible.module_utils.facts.collector.python import PythonFactCollector
    except ImportError:
        raise AssertionError("Module `ansible.module_utils.facts.collector.python.PythonFactCollector` should be importable")

    # Test creation of object
    python_fact_collector = PythonFactCollector()

    # Check that facts were collected
    assert isinstance(python_fact_collector.collect(), dict)
    assert "python" in python_fact_collector.collect()

    # Check that facts are correct
    python_facts = python_fact_collector.collect()["python"]
    assert isinstance(python_facts, dict)
    assert "version" in python_facts

# Generated at 2022-06-23 01:38:07.006847
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = Mock()
    class_object = PythonFactCollector()
    assert class_object.collect(module) == {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': list(sys.version_info), 'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT, 'type': sys.subversion[0]}}


# Generated at 2022-06-23 01:38:16.372573
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test PythonFactCollector constructor"""
    # pylint: disable=no-member,protected-access
    assert PythonFactCollector._fact_ids == set()
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector.collect()['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-23 01:38:24.206303
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    # test for key 'python'
    facts_dict = collector.collect()
    assert 'python' in facts_dict

    # test 'python' key's value type
    assert isinstance(facts_dict['python'], dict)

    # test if keys detected in 'python'
    assert 'version' in facts_dict['python']
    assert 'version_info' in facts_dict['python']
    assert 'executable' in facts_dict['python']
    assert 'has_sslcontext' in facts_dict['python']
    assert 'type' in facts_dict['python']

# Generated at 2022-06-23 01:38:27.646033
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test collect method of PythonFactCollector"""
    # Instantiate empty class
    pc = PythonFactCollector()
    # Test no exception is raised
    try:
        pc.collect()
    except Exception:
        assert False, "An exception was raised"

# Generated at 2022-06-23 01:38:30.617185
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:38:32.322290
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-23 01:38:36.433597
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()

    # name attribute must be "python"
    assert f.name == 'python', "PythonFactCollector.name == 'python'"

    # _fact_ids is empty set
    assert f._fact_ids == set(), "PythonFactCollector._fact_ids is empty set"

# Generated at 2022-06-23 01:38:39.960105
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:38:42.527389
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fc = PythonFactCollector()
    assert python_fc.name == 'python'
    assert python_fc._fact_ids == set()


# Generated at 2022-06-23 01:38:44.738962
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    data = python_facts.collect()
    assert data is not None
    assert 'python' in data

# Generated at 2022-06-23 01:38:48.254979
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids is not None
    assert type(c._fact_ids) is set
    assert not c._fact_ids


# Generated at 2022-06-23 01:38:50.455408
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    a = PythonFactCollector()
    assert a.name == "python"
    assert a._fact_ids == set()


# Generated at 2022-06-23 01:38:51.061697
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:38:56.833313
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    assert sorted(fc.collect().keys()) == sorted([
        'python'
    ])
    assert fc.collect()['python']['type'] in [
        'CPython', 'PyPy', None
    ]
    assert fc.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:38:58.822861
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfactcollector = PythonFactCollector()
    assert pythonfactcollector._name == 'python'

# Generated at 2022-06-23 01:39:02.482957
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Unit test for constructor of class PythonFactCollector"""
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:39:06.439772
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert 'python' in python_fact_collector._fact_ids
    assert isinstance(python_fact_collector._fact_ids, set)

# Generated at 2022-06-23 01:39:08.649231
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set(['python'])

# Generated at 2022-06-23 01:39:17.485481
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_facts = PythonFactCollector.collect()

    assert 'python' in python_facts.keys()

    python_version = python_facts['python']['version']
    assert 'major' in python_version.keys()
    assert 'minor' in python_version.keys()
    assert 'micro' in python_version.keys()
    assert 'releaselevel' in python_version.keys()
    assert 'serial' in python_version.keys()

    assert 'version_info' in python_facts['python'].keys()

    assert 'executable' in python_facts['python'].keys()

    assert 'has_sslcontext' in python_facts['python'].keys()

    assert 'type' in python_facts['python'].keys()

# Generated at 2022-06-23 01:39:27.566117
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()

    assert python_facts is not None
    assert python_facts['python'] is not None
    assert python_facts['python']['version'] is not None
    assert type(python_facts['python']['version']['major']) == int
    assert type(python_facts['python']['version']['minor']) == int
    assert type(python_facts['python']['version']['micro']) == int
    assert type(python_facts['python']['version']['releaselevel']) == str
    assert type(python_facts['python']['version']['serial']) == int
    assert type(python_facts['python']['version_info']) == list

# Generated at 2022-06-23 01:39:33.867149
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert hasattr(PythonFactCollector, 'collect'), "Class does not have member 'collect'"
    assert hasattr(PythonFactCollector, 'name'), "Class does not have member 'name'"
    assert PythonFactCollector.name == 'python', "Class member 'name' does not return expected value"
    assert hasattr(PythonFactCollector, '_fact_ids'), "Class does not have member '_fact_ids'"

if __name__ == '__main__':
    test_PythonFactCollector()