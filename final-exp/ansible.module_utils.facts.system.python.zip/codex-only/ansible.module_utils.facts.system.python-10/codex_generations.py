

# Generated at 2022-06-23 01:29:32.914201
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == "python"
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:29:35.450595
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    my_inst = PythonFactCollector()
    assert isinstance(my_inst, PythonFactCollector)
    assert my_inst.name == 'python'
    assert len(my_inst._fact_ids) == 0


# Generated at 2022-06-23 01:29:41.242915
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert 'python' == collector.name
    assert set() == collector._fact_ids


# Generated at 2022-06-23 01:29:44.591054
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_class = PythonFactCollector()
    assert python_fact_class.name == 'python'
    assert python_fact_class._fact_ids == set()


# Generated at 2022-06-23 01:29:48.189209
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]


# Generated at 2022-06-23 01:29:50.759594
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    factCollector = PythonFactCollector()
    assert factCollector.name == 'python'
    assert factCollector._fact_ids == set()


# Generated at 2022-06-23 01:30:00.441290
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts_collector = PythonFactCollector()
    test_python_facts = python_facts_collector.collect()
    # Verify that it returns a dictionary
    assert isinstance(test_python_facts, dict)

    # Verify that it returns the appropriate key/value pairs
    if test_python_facts['python']['type'] == 'CPython':
        assert 'version_info' in test_python_facts['python'].keys()
        assert 'version' in test_python_facts['python'].keys()
        assert 'executable' in test_python_facts['python'].keys()

    elif test_python_facts['python']['type'] == 'IronPython':
        assert 'version_info' in test_python_facts['python'].keys()

# Generated at 2022-06-23 01:30:02.904149
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test PythonFactCollector class constructor"""
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:30:06.028397
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    osinfo = PythonFactCollector()
    assert osinfo.collect()

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:30:12.057316
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collected_facts = PythonFactCollector().collect()
    assert 'python' in python_collected_facts
    python_facts = python_collected_facts['python']
    assert 'version' in python_facts
    assert 'type' in python_facts
    assert 'executable' in python_facts
    assert 'has_sslcontext' in python_facts
    assert 'version_info' in python_facts

# Generated at 2022-06-23 01:30:22.073278
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert not result['failed']
    assert 'python' in result['ansible_facts']
    assert result['ansible_facts']['python']['type'] == 'CPython'
    assert result['ansible_facts']['python']['version']['releaselevel'] == 'final'
    assert 'version' in result['ansible_facts']['python']
    assert 'version_info' in result['ansible_facts']['python']
    assert 'executable' in result['ansible_facts']['python']
    assert 'has_sslcontext' in result['ansible_facts']['python']

# Generated at 2022-06-23 01:30:26.341094
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'type' in python_facts['python']
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:30:33.673832
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert type(facts) == dict
    assert 'version' in facts['python']
    assert facts['python']['version']

    # Older Python versions do not have the 'subversion' attribute, so
    # we need to check that.
    if 'subversion' in dir(sys):
        assert 'type' in facts['python']
    else:
        assert 'type' not in facts['python']

# Generated at 2022-06-23 01:30:35.388229
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:30:44.900281
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test collect without parameters
    pfc = PythonFactCollector()
    results = pfc.collect()
    assert type(results) is dict
    assert 'python' in results
    assert type(results['python']) is dict
    assert 'version_info' in results['python']
    assert type(results['python']['version_info']) is list
    assert 'version' in results['python']
    assert type(results['python']['version']) is dict
    assert 'major' in results['python']['version']
    assert type(results['python']['version']['major']) is int
    assert 'minor' in results['python']['version']
    assert type(results['python']['version']['minor']) is int
    assert 'micro' in results['python']['version']

# Generated at 2022-06-23 01:30:48.015316
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_collector = PythonFactCollector()

    # Check name of collector.
    assert facts_collector.name == 'python'

    # Check reserved fact ids of collector.
    assert facts_collector._fact_ids == {'python'}

# Generated at 2022-06-23 01:30:52.749153
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:30:55.347707
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:31:05.592307
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    results = python_facts.collect()
    assert results['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert isinstance(results['python']['version_info'], list)
    assert isinstance(results['python']['version']['major'], int)
    assert isinstance(results['python']['version']['minor'], int)
    assert isinstance(results['python']['version']['micro'], int)
    assert isinstance(results['python']['version']['releaselevel'], basestring)
    assert isinstance(results['python']['version']['serial'], int)
    assert isinstance(results['python']['executable'], basestring)



# Generated at 2022-06-23 01:31:07.496663
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyc = PythonFactCollector()
    assert pyc is not None

# Generated at 2022-06-23 01:31:10.048580
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Calling constructor of class PythonFactCollector
    pfc = PythonFactCollector()

    assert pfc.name == 'python'

# Generated at 2022-06-23 01:31:17.781813
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # The test script provides a null implementation for the AnsibleModule
    # class.
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import collector

    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def exit_json(self, *args, **kwargs):
            pass

    module = AnsibleModule()
    collector.collect_all(module)
    assert ansible_collector.get_ansible_facts()

# Generated at 2022-06-23 01:31:19.336224
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-23 01:31:29.596055
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = {}
    python_facts = collector.collect(collected_facts=collected_facts)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:31:38.137717
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test instantiating class `PythonFactCollector`."""
    # instantiating class with default values (e.g., args=None)
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()
    assert collector
    # instantiating class with args
    collector = PythonFactCollector(name='test', fact_ids={'foo', 'bar'})
    assert collector.name == 'test'
    assert collector._fact_ids == {'foo', 'bar'}
    assert collector


# Generated at 2022-06-23 01:31:48.801814
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyc = PythonFactCollector()
    result = pyc.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCON

# Generated at 2022-06-23 01:31:50.687569
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test with the required values
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-23 01:31:51.658329
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    _ = PythonFactCollector()

# Generated at 2022-06-23 01:31:54.222003
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()

    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()

# Generated at 2022-06-23 01:31:56.580654
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector
    assert collector.name == 'python'
    assert collector._fact_ids



# Generated at 2022-06-23 01:32:04.816446
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert 'python' in p._fact_ids
    assert p.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'CPython'
        }
    }


# Generated at 2022-06-23 01:32:07.981311
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert isinstance(python_collector, PythonFactCollector)
    assert python_collector.name == 'python'
    assert isinstance(python_collector._fact_ids, set)

# Unit tests fo collect() method of class PythonFactCollector

# Generated at 2022-06-23 01:32:17.755704
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    collector = PythonFactCollector()

    assert collector.collect() == {'python': {'version': {
                                              'major': sys.version_info[0],
                                              'minor': sys.version_info[1],
                                              'micro': sys.version_info[2],
                                              'releaselevel': sys.version_info[3],
                                              'serial': sys.version_info[4]},
                                   'version_info': list(sys.version_info),
                                   'executable': sys.executable,
                                   'has_sslcontext': HAS_SSLCONTEXT,
                                   'type': sys.subversion[0]
                                   }
                                   
                                  }



# Generated at 2022-06-23 01:32:26.145845
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    print("Testing PythonFactCollector.collect")
    print("- expect ['python': {'type' : 'CPython', 'has_sslcontext' : True, 'version' : {'micro': 1, 'serial': 0, 'releaselevel': 'final', 'major': 2, 'minor': 7}, 'version_info': [2, 7, 9, 'final', 0], 'executable': '/usr/bin/python'}]")
    print("- got %s" % pyfc._collect())

if __name__ == "__main__":
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:32:28.390322
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert 'python' in c.collect()

# Generated at 2022-06-23 01:32:30.259975
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python', 'test_PythonFactCollector assert #1 has failed'

# Generated at 2022-06-23 01:32:39.364864
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Note: the following test is not complete since we cannot write the
    # outcome of the collect method to a file for testing.
    module = MockModule()
    fact_collector = PythonFactCollector()
    fact_collector.collect(module=module)

# Generated at 2022-06-23 01:32:41.936649
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj1 = PythonFactCollector()
    obj2 = PythonFactCollector()

    assert obj1.name == "python"
    assert obj1.collect() == obj2.collect()

# Generated at 2022-06-23 01:32:51.150700
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Check that basic facts are collected correctly.

    The test relies on no changes in the ssl module. Otherwise, an ImportError
    is raised.
    """
    import sys
    import copy

    collector = PythonFactCollector()
    module = None
    facts = collector.collect(module)
    # Copy the dict, since we don't want to modify the original
    facts_copy = copy.deepcopy(facts)

    # Remove the facts we don't expect, so we have only have to check that the correct facts were added.
    # Those we don't expect, are facts that are version dependent, and therefore we don't want to test.
    del facts_copy['python']['version']
    del facts_copy['python']['version_info']
    del facts_copy['python']['executable']

# Generated at 2022-06-23 01:33:00.477522
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    @return AnsibleModuleTest
    """
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    expected_facts = {
        "python": {
            "type": "CPython",
            "version":
                {
                    "releaselevel": "final",
                    "major": 3,
                    "micro": 6,
                    "minor": 1,
                    "serial": 0
                },
            "executable": "/usr/bin/python",
            "version_info": [3, 1, 6, "final", 0],
            "has_sslcontext": True
        }
    }

    result = python_fact_collector.collect(collected_facts=collected_facts)

    assert expected

# Generated at 2022-06-23 01:33:03.689510
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == "python"
    assert python_collector._fact_ids == set([])

# Generated at 2022-06-23 01:33:08.888284
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Check instance of class PythonFactCollector
    assert isinstance(PythonFactCollector, BaseFactCollector)
    PythonFactCollector()
    # Check name of class PythonFactCollector
    assert PythonFactCollector.name == 'python'
    # Check _fact_ids of class PythonFactCollector
    assert PythonFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:33:12.230511
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    facts = collector.collect()
    #assert facts['python']['version']['major'] == sys.version_info[0]


if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:33:13.832439
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
  p = PythonFactCollector()
  assert p is not None

# Generated at 2022-06-23 01:33:23.075850
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    collected_facts = fact_collector.collect()

    assert 'python' in collected_facts
    assert 'type' in collected_facts['python']
    assert 'version' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'has_sslcontext' in collected_facts['python']

    assert 'major' in collected_facts['python']['version']
    assert 'minor' in collected_facts['python']['version']
    assert 'micro' in collected_facts['python']['version']
    assert 'releaselevel' in collected_facts['python']['version']
    assert 'serial' in collected_facts['python']['version']

# Generated at 2022-06-23 01:33:25.257810
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set(['python'])

# Generated at 2022-06-23 01:33:27.087263
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_collector = PythonFactCollector()
    assert facts_collector.name == 'python'

# Generated at 2022-06-23 01:33:34.100205
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """This is a unit test for constructor of class PythonFactCollector
    """
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert facts['python'] is not None
    assert facts['python']['version'] is not None
    assert facts['python']['version']['major'] is not None
    assert facts['python']['version_info'] is not None
    assert facts['python']['executable'] is not None
    assert facts['python']['has_sslcontext'] is not None
    assert facts['python']['type'] is not None

# Generated at 2022-06-23 01:33:40.442285
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect(module=dict(), collected_facts=dict())
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:33:42.988797
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py = PythonFactCollector()
    assert py.name == 'python'

# Generated at 2022-06-23 01:33:50.624806
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    test_object = PythonFactCollector()
    test_facts = test_object.collect()

    assert test_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }



# Generated at 2022-06-23 01:33:53.270192
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py = PythonFactCollector()

    # Check actual name
    assert py.name == 'python'

    # Check attribute _fact_ids
    assert py._fact_ids == set()

# Generated at 2022-06-23 01:34:00.369566
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pythonfc = PythonFactCollector()

    # test empty
    assert len(pythonfc.collect(collected_facts={})['ansible_facts']) == 0

    # test normal
    collected_facts = {}
    output = pythonfc.collect(collected_facts=collected_facts)['ansible_facts']
    assert output['python']['version']['major'] == 3
    assert len(output['python']['version_info']) == 5
    assert output['python']['executable'] == sys.executable
    assert output['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:34:06.535054
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'type' in result['python']
    assert 'has_sslcontext' in result['python']
    assert isinstance(result['python']['has_sslcontext'], bool)
    assert isinstance(result['python']['type'], str)
    assert isinstance(result['python']['version']['major'], int)
    assert isinstance(result['python']['version']['minor'], int)
    assert isinstance(result['python']['version']['micro'], int)

# Generated at 2022-06-23 01:34:08.802613
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector = PythonFactCollector()

    result = python_fact_collector.collect()

    assert result is not None
    assert 'python' in result


# Generated at 2022-06-23 01:34:11.141173
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert python_facts.collect()['python'] is not None

# Generated at 2022-06-23 01:34:15.981159
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''
    pfc = PythonFactCollector()
    collected_facts = pfc.collect()
    assert "python" in collected_facts
    assert "version" in collected_facts["python"]
    assert "version_info" in collected_facts["python"]
    assert "type" in collected_facts["python"]
    assert "executable" in collected_facts["python"]

# Generated at 2022-06-23 01:34:20.007557
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    # Collect facts
    facts = fact_collector.collect()

    # Assert if we were able to collect the facts successfully
    assert facts

# Generated at 2022-06-23 01:34:27.862540
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Initialise an instance of class PythonFactCollector
    myPyFacts = PythonFactCollector()
    # Call the collect method to get a dictionary of python facts
    py_facts = myPyFacts.collect()
    # Verify python version information is available in facts dictionary
    py_version = py_facts['python']['version']
    assert py_version['major'] == sys.version_info[0]
    assert py_version['minor'] == sys.version_info[1]
    assert py_version['micro'] == sys.version_info[2]
    assert py_version['releaselevel'] == sys.version_info[3]
    assert py_version['serial'] == sys.version_info[4]
    # Verify version_info is a list

# Generated at 2022-06-23 01:34:38.733351
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts['python'], dict)
    assert python_facts['python']['version'] == {'major': sys.version_info[0],
                                                 'minor': sys.version_info[1],
                                                 'micro': sys.version_info[2],
                                                 'releaselevel': sys.version_info[3],
                                                 'serial': sys.version_info[4]}
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:34:45.213511
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert type(python_facts['python']['version']) is dict
    assert type(python_facts['python']['version_info']) is list

    if 'linux' in sys.platform.lower():
        assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert type(python_facts['python']['type']) is str

# Generated at 2022-06-23 01:34:54.857691
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for the collect method of class PythonFactCollector
    """
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()

    assert result['python']['executable'] == sys.executable
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:35:05.170405
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Check if the constructor fails on a non boolean input
    expected_failure_is_success = False
    try:
        PythonFactCollector(1)
        expected_failure_is_success = True
    except ValueError:
        pass
    except:
        expected_failure_is_success = True
    assert expected_failure_is_success is False, 'Fail: constructor with non boolean'

    # Check if the constructor fails on a boolean input
    expected_failure_is_success = False
    try:
        PythonFactCollector(True)
        expected_failure_is_success = True
    except ValueError:
        pass
    except:
        expected_failure_is_success = True
    assert expected_failure_is_success is False, 'Fail: constructor with boolean'

# Generated at 2022-06-23 01:35:06.638591
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    output = p.collect()
    assert 'python' in output

# Generated at 2022-06-23 01:35:10.394055
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert len(python_collector._fact_ids) == 0

# Generated at 2022-06-23 01:35:11.781274
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert type(pfc.collect()) is dict

# Generated at 2022-06-23 01:35:21.420011
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_facts = PythonFactCollector().collect()
    assert 'python' in py_facts
    assert 'type' in py_facts['python']
    assert 'version' in py_facts['python']
    assert 'version_info' in py_facts['python']
    assert 'executable' in py_facts['python']
    assert 'has_sslcontext' in py_facts['python']

    assert 'major' in py_facts['python']['version']
    assert 'minor' in py_facts['python']['version']
    assert 'micro' in py_facts['python']['version']
    assert 'releaselevel' in py_facts['python']['version']
    assert 'serial' in py_facts['python']['version']

# Generated at 2022-06-23 01:35:29.219503
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test setup
    pc = PythonFactCollector()

    # Test collect method
    results = pc.collect()

    # Assert check
    assert results['python']['version']['major'] == 3
    assert results['python']['version']['minor'] == 7
    assert results['python']['version']['micro'] == 4
    assert results['python']['version']['releaselevel'] == 'final'
    assert results['python']['version']['serial'] == 0
    assert results['python']['type'] == 'CPython'
    assert results['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:35:33.748779
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    assert fc.collect() == {'python':
                            {'version':
                             {'major': sys.version_info[0], 'minor': sys.version_info[1],
                              'micro': sys.version_info[2], 'releaselevel': sys.version_info[3],
                              'serial': sys.version_info[4]},
                             'version_info': list(sys.version_info),
                             'executable': sys.executable,
                             'has_sslcontext': HAS_SSLCONTEXT,
                             'type': sys.subversion[0]}}

# Generated at 2022-06-23 01:35:37.511414
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    ppc = PythonFactCollector()
    result = ppc.collect(None, None)
    assert isinstance(result, dict)

# Generated at 2022-06-23 01:35:42.231134
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]

# Generated at 2022-06-23 01:35:45.200237
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    res = pfc.collect()
    assert 'version' in res['python']
    assert 'version_info' in res['python']
    assert 'type' in res['python']
    assert 'executable' in res['python']

# Generated at 2022-06-23 01:35:46.743520
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:35:54.633401
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import ansible.module_utils.facts.collector
    python_facts = ansible.module_utils.facts.collector.get_collector('python').collect()
    assert 'python' in python_facts
    assert isinstance(python_facts['python']['version']['major'],int)
    assert isinstance(python_facts['python']['version']['minor'],int)
    assert isinstance(python_facts['python']['version']['micro'],int)
    assert isinstance(python_facts['python']['version']['releaselevel'],str)
    assert isinstance(python_facts['python']['version']['serial'],int)
    assert isinstance(python_facts['python']['version_info'], list)

# Generated at 2022-06-23 01:35:57.571968
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect() is not None

# Generated at 2022-06-23 01:35:59.395214
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    data = collector.collect()
    # Just test if there is no error
    assert data

# Generated at 2022-06-23 01:36:07.373287
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    facts = {}
    python_fact.collect(collected_facts=facts)
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'type' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert len(facts['python']['version']) == 5
    assert len(facts['python']['version_info']) == 5

# Generated at 2022-06-23 01:36:10.884093
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector
    assert python_fact_collector.name == 'python'
    assert python_fact_collector.priority == 10
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:36:20.425163
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    ansible_facts = py_fc.collect()
    assert isinstance(ansible_facts, dict)
    assert isinstance(ansible_facts['python'], dict)
    assert ansible_facts['python']['executable'].endswith('python')
    assert ansible_facts['python']['version']['major'] > 0
    if HAS_SSLCONTEXT:
        assert ansible_facts['python']['has_sslcontext']

# Generated at 2022-06-23 01:36:22.812434
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:36:29.838289
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    c = PythonFactCollector()

    # Call collect and check it returns a dictionary
    assert isinstance(c.collect(), dict)

    # Check dictionary keys
    assert c.collect().keys() == {'python'}

    # Check there is a version key
    assert c.collect()['python'].keys() == {'version', 'version_info', 'executable', 'type', 'has_sslcontext'}

    # Check there is a type key
    assert 'type' in c.collect()['python']

# Generated at 2022-06-23 01:36:31.899133
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:36:42.500597
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Setup
    module = None
    collected_facts = None
    python_fact_collector = PythonFactCollector()
    expected_python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    # Test

# Generated at 2022-06-23 01:36:47.839535
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test for throwing exception if HAS_SSLCONTEXT does not exits
    """
    from ansible.module_utils.facts.collector import HAS_SSLCONTEXT
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:36:49.589537
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'


# Generated at 2022-06-23 01:37:00.756692
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert type(result) is dict
    assert "python" in result
    assert "version" in result["python"]
    assert "version_info" in result["python"]
    assert "executable" in result["python"]
    assert "has_sslcontext" in result["python"]

    assert "type" in result["python"]

# Generated at 2022-06-23 01:37:04.016774
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    if 'python' not in python_facts:
        assert False, "Cannot find python version"
    if 'version' not in python_facts['python']:
        assert False, "Cannot find python version"

# Generated at 2022-06-23 01:37:08.638153
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Setup
    module = None
    collected_facts = {}
    obj = PythonFactCollector()

    # Test
    assert 'python' in obj.collect(module, collected_facts)

# Unit test method collect of class PythonFactCollector - version_info

# Generated at 2022-06-23 01:37:11.605376
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'



# Generated at 2022-06-23 01:37:17.339459
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect({})

    assert result['python']['version']
    assert result['python']['version_info']
    assert result['python']['executable']
    assert result['python']['has_sslcontext']
    assert result['python']['type']

# Generated at 2022-06-23 01:37:27.192990
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert python_fact_collector._trim_on_disk == False
    assert python_fact_collector._cache_location == None
    assert python_fact_collector._fact_ids == set()

    python_fact_collector = PythonFactCollector(cache_location='/tmp', trim_on_disk=True)

    assert python_fact_collector.name == 'python'
    assert python_fact_collector._trim_on_disk == True
    assert python_fact_collector._cache_location == '/tmp'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:37:28.870299
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    col = PythonFactCollector()
    assert col.collect()['python']['type'] == 'CPython'

# Generated at 2022-06-23 01:37:36.546305
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import mock

    sys.version_info = (1, 2, 3, 'final', '123')
    sys.executable = '/opt/local/bin/python'
    sys.subversion = ('CPython', '', '123')
    collector = PythonFactCollector()

    ansible_module = mock.Mock()
    ansible_module.run_command.return_value = (0, 'foo bar baz qux', '')
    ansible_module.params = {}

    # Act
    result = collector.collect()

    # Assert
    assert len(result) == 1
    assert result['python']['version']['major'] == 1
    assert result['python']['version']['minor'] == 2
    assert result['python']['version']['micro'] == 3

# Generated at 2022-06-23 01:37:40.487755
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py = PythonFactCollector()
    print("TEST - PythonFactCollector - collect")
    print("TEST - PythonFactCollector - collect: %s" % py.collect())


# Generated at 2022-06-23 01:37:45.249564
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Check the constructor'''
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:37:47.405366
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:37:52.336999
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collecter = PythonFactCollector()
    results = collecter.collect()
    print(results)
    assert results['python']['type'] == 'CPython'
    assert results['python']['version']['major'] == 2

# Generated at 2022-06-23 01:37:54.743021
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector({}, {})
    assert obj.name == 'python'
    assert sorted(obj._fact_ids) == ['python']

# Generated at 2022-06-23 01:38:02.096376
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    assert py_collector.collect() == {'python': {'has_sslcontext': True,
                                                 'version': {
                                                     'serial': 0,  # type: ignore
                                                     'releaselevel': 'final',
                                                     'major': 2,  # type: ignore
                                                     'minor': 7,  # type: ignore
                                                     'micro': 12},
                                                 'executable': sys.executable,
                                                 'version_info': [2, 7, 12, 'final', 0],
                                               },
                                       }

# Generated at 2022-06-23 01:38:13.631245
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Dummy object for the class
    py_fact_collector = PythonFactCollector()

    # Dummy module object for AnsibleModule
    dummy_ansible_module = "echo"

    # Dummy facts dictionary
    dummy_facts = {"python.version": "something"}

    # Collect facts
    py_facts = py_fact_collector.collect(dummy_ansible_module, dummy_facts)

    # Assert types
    assert type(py_facts.get('python')['type']) is str
    assert type(py_facts.get('python')['version']) is dict
    assert type(py_facts.get('python')['version_info']) is list
    assert type(py_facts.get('python')['executable']) is str

    # Assert values

# Generated at 2022-06-23 01:38:16.792314
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test_object = PythonFactCollector()
    assert test_object.name == 'python'
    assert test_object._fact_ids == set()

# Generated at 2022-06-23 01:38:26.218007
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Define the test inputs and expected results
    test_input = {}
    test_output = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-23 01:38:28.698612
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()
    assert pyfc.name == 'python'
    assert len(pyfc._fact_ids) == 0
    assert callable(pyfc.collect)


# Generated at 2022-06-23 01:38:32.326081
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    # Check if name of PythonFactCollector is "python"
    assert python_fact.name == 'python'
    # Check if PythonFactCollector.collect() is a function
    assert isinstance(python_fact.collect, object)

# Generated at 2022-06-23 01:38:40.874109
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test method collect

    Expected results:
        python_facts['python']['type'] = sys.implementation.name

    """
    # pylint: disable=import-error
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.collector import collector

    # pylint: disable=unused-variable
    def create_default_context():
        """
        Avoid using certifi as it is not installed by default.
        """
        return None
    # pylint: enable=unused-variable

    # Monkey patching SSLContext to enable HAS_SSLCONTEXT
    facts.SSLContext = create_default_context

    # pylint: disable=attribute-defined-outside-init
    collector.PythonFactCollector.name = 'python'

# Generated at 2022-06-23 01:38:45.977941
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """ Check instantiation of PythonFactCollector class
        without it actually collecting facts
    """
    assert issubclass(PythonFactCollector, BaseFactCollector)
    # check whether it is abstract
    try:
        PythonFactCollector()
        assert False
    except TypeError:
        assert True
    # check instantiation with module mock
    from ansible.module_utils.facts import ModuleFailException
    from ansible.module_utils.facts.collector import CollectFailureError
    from ansible.module_utils.facts.collector.python import PythonFactCollector
    pf = PythonFactCollector(module=object())
    assert pf
    try:
        pf.collect(module=object())
    except CollectFailureError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 01:38:54.297913
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    # Correct type of collect method
    assert isinstance(pfc.collect(), dict)
    # Correct key in collect result
    assert 'python' in pfc.collect()
    # Correct subkeys in collect result
    assert 'version' in pfc.collect()['python']
    assert 'version_info' in pfc.collect()['python']
    assert 'executable' in pfc.collect()['python']
    assert 'has_sslcontext' in pfc.collect()['python']
    assert 'type' in pfc.collect()['python']
    # No exception
    assert pfc.collect()

# Generated at 2022-06-23 01:38:56.292443
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:39:05.200495
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_data = fact_collector.collect()
    assert isinstance(fact_data['python'], dict)
    assert isinstance(fact_data['python']['version_info'], list)
    assert fact_data['python']['version']['major'] == sys.version_info[0]
    assert fact_data['python']['version']['minor'] == sys.version_info[1]
    assert fact_data['python']['version']['micro'] == sys.version_info[2]
    assert fact_data['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_data['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:39:07.119624
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector(None, None)
    pfc.collect()
    assert len(pfc._fact_ids) == 0

# Generated at 2022-06-23 01:39:14.871003
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    result = p.collect()

    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT



# Generated at 2022-06-23 01:39:17.334850
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
  pfc = PythonFactCollector()
  assert pfc._fact_ids == set()
  assert pfc.name == 'python'


# Generated at 2022-06-23 01:39:21.429692
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    py_facts = pyfc.collect()
    assert py_facts['python']['type'] == 'CPython'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 01:39:23.930854
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x.priority == 10

# Generated at 2022-06-23 01:39:34.885112
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    from ansible.module_utils.facts import collector
    c = collector.get_collector('python')
    facts = c.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)