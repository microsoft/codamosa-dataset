

# Generated at 2022-06-23 01:29:36.901275
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    mf = PythonFactCollector()
    results = mf.collect(module=None, collected_facts=None)
    assert('python' in results)
    assert('version' in results['python'])
    assert('version_info' in results['python'])
    if sys.version_info[0] > 2:
        assert('type' in results['python'])
    assert('executable' in results['python'])
    assert('has_sslcontext' in results['python'])

# Generated at 2022-06-23 01:29:37.960121
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:29:39.820539
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()


if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:29:42.941262
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:29:52.671754
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collected_facts = {}
    python_collected_facts['python'] = {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': list(sys.version_info), 'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT}

# Generated at 2022-06-23 01:29:53.731467
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact = PythonFactCollector()
    print(fact)

# Generated at 2022-06-23 01:29:55.912778
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector.collect(), dict)


# Generated at 2022-06-23 01:30:03.950620
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test data
    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:30:06.427358
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector._fact_ids == set()
    assert python_collector.name == 'python'


# Generated at 2022-06-23 01:30:16.867190
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)
    assert isinstance(python_facts['python']['version_info'], list)
   

# Generated at 2022-06-23 01:30:21.104053
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector
    """
    PythonFactCollector.collect_fn = lambda self, module: {'python': {'type': 'Jython'}}
    facts = PythonFactCollector.collect()
    assert facts == {'python': {'type': 'Jython'}}

# Generated at 2022-06-23 01:30:29.838502
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    expected_keys = set(['python'])
    assert set(facts.keys()) == expected_keys

    expected_keys = set(['version', 'version_info', 'executable', 'has_sslcontext', 'type'])
    assert set(facts['python'].keys()) == expected_keys

    expected_keys = set(['major', 'minor', 'micro', 'releaselevel', 'serial'])
    assert set(facts['python']['version'].keys()) == expected_keys

    assert type(facts['python']['version']['major']) is int
    assert type(facts['python']['version']['minor']) is int
    assert type(facts['python']['version']['micro']) is int

# Generated at 2022-06-23 01:30:41.304288
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0], "Major version incorrect"
    assert python_facts['python']['version']['minor'] == sys.version_info[1], "Minor version incorrect"
    assert python_facts['python']['version']['micro'] == sys.version_info[2], "Micro version incorrect"
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3], "Releaselevel incorrect"
    assert python_facts['python']['version']['serial'] == sys.version_info[4], "Serial incorrect"
    assert python_facts['python']['version_info'] == list(sys.version_info), "Version info incorrect"
   

# Generated at 2022-06-23 01:30:43.731813
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc is not None
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:30:49.260627
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    real_collector = PythonFactCollector()
    assert real_collector.name == 'python'
    assert real_collector._fact_ids == set()


# Generated at 2022-06-23 01:31:00.543364
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }}


# Generated at 2022-06-23 01:31:01.715516
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert type(pfc.collect()) == dict

# Generated at 2022-06-23 01:31:11.545160
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfactcoll = PythonFactCollector()
    pyfacts = pyfactcoll.collect()
    assert isinstance(pyfacts, dict), 'PythonFactCollector.collect does not return a dictionary'
    assert 'python' in pyfacts, 'PythonFactCollector.collect does not contain a python key'
    assert 'version' in pyfacts['python'], 'PythonFactCollector.collect["python"] does not contain a version key'
    assert 'version_info' in pyfacts['python'], 'PythonFactCollector.collect["python"] does not contain a version_info key'
    assert 'executable' in pyfacts['python'], 'PythonFactCollector.collect["python"] does not contain an executable key'

# Generated at 2022-06-23 01:31:14.421569
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect()["python"]["version"]["major"] == 2 or collector.collect()["python"]["version"]["major"] == 3

# Generated at 2022-06-23 01:31:16.167625
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector is not None


# Generated at 2022-06-23 01:31:25.681326
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    PythonFactCollectorInstance = get_collector_instance('python')
    fact_inst = PythonFactCollectorInstance()

    fact_data = fact_inst.collect()
    assert isinstance(fact_data, dict)
    assert 'python' in fact_data
    python_data = fact_data['python']
    assert isinstance(python_data, dict)
    assert 'version' in python_data
    assert isinstance(python_data['version'], dict)
    assert 'version_info' in python_data
    assert isinstance(python_data['version_info'], list)
    assert 'executable' in python_data
    assert python_data['executable'] == sys.executable
    assert 'has_sslcontext' in python_

# Generated at 2022-06-23 01:31:29.410479
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    precision = PythonFactCollector()
    assert precision.name == 'python'
    assert precision._fact_ids == set()


# Generated at 2022-06-23 01:31:32.179009
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Setup a test object
    facts = PythonFactCollector()

    # Check that the Qt facts object is correctly initialized
    assert facts is not None
    assert facts.name == 'python'

# Generated at 2022-06-23 01:31:40.958693
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_facts = PythonFactCollector()
    result = python_facts.collect()

    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 5
    assert result['python']['version']['micro'] == 0
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [3, 5, 0, 'final', 0]
    assert result['python']['type'] == 'CPython'

# Generated at 2022-06-23 01:31:45.026969
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:31:46.654968
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # This collector should not be called if Python is not installed
    assert HAS_SSLCONTEXT is True

# Generated at 2022-06-23 01:31:51.434688
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfacts = PythonFactCollector()
    assert isinstance(pyfacts, PythonFactCollector) is True
    assert isinstance(pyfacts, BaseFactCollector) is True
    assert pyfacts.name == 'python'


# Generated at 2022-06-23 01:31:53.234266
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    out = PythonFactCollector()

    assert out.name == 'python'

# Generated at 2022-06-23 01:32:01.933282
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import loader
    from ansible.module_utils._text import to_bytes

    python_collector = PythonFactCollector()
    facts_dict = loader.get_facts(python_collector)
    python_facts = facts_dict.get('python')

    # Check major, minor, micro and releaselevel elements are present and are
    # the expected types
    assert 'python' in facts_dict
    assert python_facts.get('version_info') is not None
    assert python_facts.get('version') is not None
    assert python_facts['version']['major'] == sys.version_info[0]
    assert python_facts['version']['minor'] == sys.version_info[1]

# Generated at 2022-06-23 01:32:13.158965
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    my_collector = PythonFactCollector()
    my_collected_facts = my_collector.collect()

    assert my_collected_facts is not None
    assert 'python' in my_collected_facts
    assert 'version' in my_collected_facts['python']
    assert 'executable' in my_collected_facts['python']
    assert 'version_info' in my_collected_facts['python']

    assert type(my_collected_facts['python']['version']['major']) == int
    assert type(my_collected_facts['python']['version']['minor']) == int
    assert type(my_collected_facts['python']['version']['micro']) == int

# Generated at 2022-06-23 01:32:23.456784
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import inspect
    import copy

    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': True,
        'type': 'CPython'
    }

    f = PythonFactCollector()
    current_module = inspect.getmodule(inspect.currentframe())
    result = f.collect(current_module, None)

    assert result == python_

# Generated at 2022-06-23 01:32:36.347294
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector_python = PythonFactCollector()
    facts = fact_collector_python.collect()
    assert type(facts) == dict
    assert sorted(facts) == ['python']
    assert 'type' in facts['python']
    assert 'version' in facts['python']
    assert type(facts['python']['version']) == dict
    assert sorted(facts['python']['version']) == ['major', 'minor', 'micro', 'releaselevel', 'serial']
    assert type(facts['python']['version']['major']) == int
    assert type(facts['python']['version']['minor']) == int
    assert type(facts['python']['version']['micro']) == int
    assert type(facts['python']['version']['releaselevel']) == str


# Generated at 2022-06-23 01:32:45.802598
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector.collect()

    # Assert that the correct dictionary is returned
    assert 'python' in python_fact
    assert python_fact['python']['version']['major'] == sys.version_info[0]
    assert python_fact['python']['version']['minor'] == sys.version_info[1]
    assert python_fact['python']['version']['micro'] == sys.version_info[2]
    assert python_fact['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_fact['python']['version']['serial'] == sys.version_info[4]
    assert python_fact['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:32:48.288389
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    py_fact_collector = PythonFactCollector()
    py_facts = py_fact_collector.collect()
    assert py_facts['python']['version_info'][0] == sys.version_info[0]

# Generated at 2022-06-23 01:32:51.117175
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert python_facts['python']['executable'].endswith('/python')
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:32:52.839434
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()


# Generated at 2022-06-23 01:32:54.977889
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:33:05.545914
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a instance of PythonFactCollector
    pfc = PythonFactCollector()

    # Test collect method
    assert pfc.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.subversion[0]
        }
    }

# Generated at 2022-06-23 01:33:07.027596
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    instance = PythonFactCollector()
    assert instance._fact_ids == set()

# Generated at 2022-06-23 01:33:09.161663
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set(['python'])

# Generated at 2022-06-23 01:33:17.104338
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import ListCollector
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import _LazyFactsDict

    facts_dict = Facts({'collected_facts': {'python': {
        'executable': '/usr/bin/python',
        'has_sslcontext': True,
        'type': 'CPython',
        'version': {
            'major': 2, 'micro': 7, 'minor': 10, 'releaselevel': 'final', 'serial': 0
        },
        'version_info': [2, 7, 10, 'final', 0]
    }}})

    python_fact_collector = PythonFactCollector()

# Generated at 2022-06-23 01:33:20.472724
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:33:22.795671
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()
    assert 'python' == pyfc.name


# Generated at 2022-06-23 01:33:25.939559
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']

# Generated at 2022-06-23 01:33:27.978180
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Unit test for constructor of class PythonFactCollector"""
    fact_collector = PythonFactCollector()
    assert fact_collector != None

# Generated at 2022-06-23 01:33:29.376488
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:33:32.056565
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector instance
    python_fact_collector = PythonFactCollector()

    # Execute the collect method of PythonFactCollector
    python_fact_collector.collect()

# Generated at 2022-06-23 01:33:34.823533
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids is not None


# Generated at 2022-06-23 01:33:36.619769
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c.collect()['python']

# Generated at 2022-06-23 01:33:45.917496
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector.python import PythonFactCollector
    import sys
    import platform

    p = PythonFactCollector()
    p_fact_dict = p.collect()

    assert p_fact_dict['python']['version_info'][0] == sys.version_info[0]
    assert p_fact_dict['python']['version_info'][1] == sys.version_info[1]
    assert p_fact_dict['python']['version_info'][2] == sys.version_info[2]
    assert p_fact_dict['python']['version_info'][3] == sys.version_info[3]
    assert p_fact_dict['python']['version_info'][4] == sys.version_info[4]
    assert p_

# Generated at 2022-06-23 01:33:50.549619
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector(None, None, False, None)
    result = py_collector.collect()
    assert isinstance(result, dict) == True, 'result is not a dict'
    assert 'python' in result, 'python key should be in result'
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT, 'has_sslcontext is wrong'

# Generated at 2022-06-23 01:33:54.358489
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector
    python_fact_collector = collector.get_collector('python')
    assert isinstance(python_fact_collector, PythonFactCollector)
    facts = python_fact_collector.collect()
    assert 'python' in facts

# Generated at 2022-06-23 01:33:57.685298
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert set(python_fact_collector._fact_ids) == set(['python'])



# Generated at 2022-06-23 01:34:00.336051
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_fact_collector = PythonFactCollector()

    result = python_fact_collector.collect()
    assert 'python' in result

# Generated at 2022-06-23 01:34:02.540435
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert isinstance(obj._fact_ids, set)

# Generated at 2022-06-23 01:34:06.075239
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"

# Generated at 2022-06-23 01:34:07.110989
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector().collect()

# Generated at 2022-06-23 01:34:08.580420
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name =="python"

# Generated at 2022-06-23 01:34:11.215864
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p._fact_ids == set()
    assert p.name == 'python'


# Generated at 2022-06-23 01:34:13.299412
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x is not None

# Generated at 2022-06-23 01:34:15.109407
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:34:21.580373
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import Collectors
    import sys
    testmodule = sys.modules[__name__]
    collector = PythonFactCollector(testmodule)
    # Test that the collector has the name python (the class name)
    assert(collector.name == 'python')
    # Make sure methods get can be called
    assert collector.get_facts() == collector.collect()
    # Make sure the collector is included in facts/collectors
    assert(collector.name in Collectors.names())
    return

# Generated at 2022-06-23 01:34:25.767247
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:34:28.445012
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert 'python' in PythonFactCollector.collect().keys()
    assert 'version' in PythonFactCollector.collect()['python'].keys()
    assert 'executable' in PythonFactCollector.collect()['python'].keys()

# Generated at 2022-06-23 01:34:34.186625
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    result = python_collector.collect()

    assert result['python']
    assert result['python']['version']
    assert result['python']['version_info']
    assert result['python']['executable']
    assert result['python']['type']
    assert result['python']['has_sslcontext']

# Generated at 2022-06-23 01:34:37.096049
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f['python']['version_info'] == list(sys.version_info)
    assert f['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:34:39.158259
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    assert type(pyfc.collect()) == dict

# Generated at 2022-06-23 01:34:41.569527
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()


# Generated at 2022-06-23 01:34:44.377318
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python', 'Invalid name for PythonFactCollector'
    assert 'python' in fact_collector._fact_ids, '_fact_ids does not contain expected value'

# Generated at 2022-06-23 01:34:51.954640
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Test case for method `collect` of class PythonFactCollector.'''

    p = PythonFactCollector()
    result = p.collect()

    assert 'python' in result
    assert result['python']['has_sslcontext'] is not None
    assert result['python']['version']['major'] >= 2
    assert type(result['python']['version']['major']) is int
    assert result['python']['version']['minor'] >= 0
    assert type(result['python']['version']['minor']) is int
    assert result['python']['version']['micro'] >= 0
    assert type(result['python']['version']['micro']) is int
    assert result['python']['version']['releaselevel'] is not None

# Generated at 2022-06-23 01:34:55.292234
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()
    assert PythonFactCollector.collect().keys() == ['python']

# Generated at 2022-06-23 01:35:03.927984
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    test_python_facts = {
        'python': {
            'version': {
                'major': 2,
                'minor': 7,
                'micro': 12,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 12, 'final', 0],
            'executable': '/usr/bin/python',
            'type': 'CPython',
            'has_sslcontext': True
        }
    }

    test = PythonFactCollector()
    ansible_python_facts = test.collect()

    assert test_python_facts == ansible_python_facts

# Generated at 2022-06-23 01:35:06.403239
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Verify that the constructor is of the correct form
    python_fact_collector = PythonFactCollector()

    assert isinstance(python_fact_collector, PythonFactCollector)


# Generated at 2022-06-23 01:35:10.876587
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    facts = pyfc.collect()
    assert len(pyfc._fact_ids) == 1
    assert facts['python']['type'] is not None
    assert facts['python']['has_sslcontext'] is True

# Generated at 2022-06-23 01:35:13.048319
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    foo = PythonFactCollector()
    assert foo.name == 'python'
    assert foo._fact_ids == set()


# Generated at 2022-06-23 01:35:14.924106
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert isinstance(PythonFactCollector._fact_ids, set)

# Generated at 2022-06-23 01:35:21.283987
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector({}, None)
    facts_dict = fact_collector.collect()
    assert facts_dict['python']['version']['major'] == sys.version_info[0]
    # Additional tests for python3
    if sys.version_info[0] == 3:
        assert facts_dict['python']['type'] == 'CPython'
        assert facts_dict['python']['has_sslcontext'] == True

# Generated at 2022-06-23 01:35:22.681595
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:35:26.038900
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'


# Generated at 2022-06-23 01:35:29.017875
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
  p = PythonFactCollector()
  assert p.name == 'python'

  assert len(p._fact_ids) == 0

# Generated at 2022-06-23 01:35:30.478178
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-23 01:35:35.958583
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector is not None
    assert py_fact_collector.name == 'python'

# Generated at 2022-06-23 01:35:46.550846
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
   python_fact_collector = PythonFactCollector()

   # check if we have the requested keys
   facts = python_fact_collector.collect()
   assert facts['python']['version']['major'] == sys.version_info[0]
   assert facts['python']['version']['minor'] == sys.version_info[1]
   assert facts['python']['version']['micro'] == sys.version_info[2]
   assert facts['python']['version']['releaselevel'] == sys.version_info[3]
   assert facts['python']['version']['serial'] == sys.version_info[4]
   assert facts['python']['version_info'] == list(sys.version_info)
   assert facts['python']['executable'] == sys.executable
  

# Generated at 2022-06-23 01:35:54.628921
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = 'file'
    test_collector = PythonFactCollector(module)

    collected_facts = dict()
    expected_facts = {'python': {'has_sslcontext': True,
                                 'version': {'major': 2,
                                             'minor': 7,
                                             'micro': 17,
                                             'releaselevel': 'final',
                                             'serial': 0},
                                 'type': 'CPython',
                                 'version_info': [2, 7, 17, 'final', 0],
                                 'executable': '/usr/bin/python'}}
    test_collector.collect(module, collected_facts)
    assert test_collector.collect(module, collected_facts) == expected_facts

# Generated at 2022-06-23 01:35:57.106045
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:36:04.483495
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    assert isinstance(pyfc.collect(), dict)
    assert 'python' in pyfc.collect()
    assert 'version' in pyfc.collect()['python']
    assert 'version_info' in pyfc.collect()['python']
    assert 'executable' in pyfc.collect()['python']
    assert 'has_sslcontext' in pyfc.collect()['python']
    assert 'type' in pyfc.collect()['python']

# Generated at 2022-06-23 01:36:06.910309
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts.keys()
    assert 'executable' in python_facts['python'].keys()

# Generated at 2022-06-23 01:36:15.405495
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import re
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    python_fact_collector_instance = PythonFactCollector()
    assert isinstance(python_fact_collector_instance, BaseFactCollector)
    assert isinstance(python_fact_collector_instance.name, str)
    assert isinstance(python_fact_collector_instance.collect(), dict)
    assert isinstance(python_fact_collector_instance._fact_ids, set)
    assert isinstance(python_fact_collector_instance._fact_ids, set)
    assert isinstance(python_fact_collector_instance.collect()['python'], dict)

# Generated at 2022-06-23 01:36:18.571082
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''
    Unit test for 'python' module's PythonFactCollector class.
    '''
    # Instantiation of PythonFactCollector object
    obj = PythonFactCollector()
    assert obj
    assert obj.name == 'python'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:36:20.726279
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:36:23.974824
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert python_fact.name == 'python'
    assert isinstance(python_fact._fact_ids, set)
    assert python_fact._fact_ids == set()

# Generated at 2022-06-23 01:36:31.998594
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {'python': {
        'executable': '/usr/bin/python',
        'has_sslcontext': True,
        'type': 'CPython',
        'version': {
            'major': 2,
            'micro': 7,
            'minor': 12,
            'releaselevel': 'final',
            'serial': 0
        },
        'version_info': [2, 7, 12, 'final', 0]
    }}
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect() == python_facts

# Generated at 2022-06-23 01:36:33.976781
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:36:36.294462
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_instance = PythonFactCollector()
    assert fact_instance.name == 'python'
    assert fact_instance._fact_ids == set()

# Generated at 2022-06-23 01:36:41.188323
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    # Make sure that _fact_ids is a set
    assert isinstance(python_fact_collector._fact_ids, set)
    # Make sure that the set is empty
    assert len(python_fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:36:50.603922
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    simple_collector = PythonFactCollector()
    facts = simple_collector.collect()

    assert isinstance(facts['python'], dict)
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version']['major'], int)
    assert isinstance(facts['python']['version']['minor'], int)
    assert isinstance(facts['python']['version']['micro'], int)
    assert isinstance(facts['python']['version']['releaselevel'], str)
    assert isinstance(facts['python']['version']['serial'], int)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)

# Generated at 2022-06-23 01:36:53.045887
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:36:55.594593
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector('test.cache')
    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:37:00.803106
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    assert facts['python']['version_info'][0] == sys.version_info[0]
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:37:04.919657
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert(pfc.name == 'python')
    assert(pfc._fact_ids == set())

# Generated at 2022-06-23 01:37:06.492217
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test a regular instantiation of the class
    PythonFactCollector()


# Generated at 2022-06-23 01:37:08.735409
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    result = obj.collect()
    assert result is not None
    assert 'python' in result

# Generated at 2022-06-23 01:37:11.949070
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'
    assert py_collector._fact_ids == set()

# Generated at 2022-06-23 01:37:22.922840
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    try:
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        HAS_SSLCONTEXT_TRUE = True
    except ImportError:
        HAS_SSLCONTEXT_TRUE = False

    try:
        import ssl
        del ssl
    except ImportError:
        HAS_SSLCONTEXT_FALSE = False

    try:
        import _ssl
        del _ssl
    except ImportError:
        HAS_SSLCONTEXT_FALSE = False

    result = {}

# Generated at 2022-06-23 01:37:24.336441
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'

# Generated at 2022-06-23 01:37:26.139575
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:37:33.439846
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    # check correct values assigned to python_facts dictionary
    # when has_sslcontext is not an attribute of sys
    sys.has_sslcontext = False
    python_facts = collector.collect(collected_facts=None)
    assert python_facts == {'python': {
            'version': {
                'major': 3,
                'minor': 5,
                'micro': 1,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [3, 5, 1, 'final', 0],
            'executable': '/usr/bin/python',
            'has_sslcontext': True
        }
    }

# Generated at 2022-06-23 01:37:36.048746
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:37:42.729760
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    # collect() returns a list of key/value pairs,
    # which in this case is a single item list with a single key/value pair
    # First item in list is the key/value pair
    # First item in key/value pair is the key
    # Second item in key/value pair is the value
    assert collector.collect()[0].keys()[0] == 'python'

# Generated at 2022-06-23 01:37:48.364173
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:37:55.657264
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector._module = None
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python']['version_info'], list)
    assert len(facts['python']['version_info']) == 5
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-23 01:37:57.466527
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py = PythonFactCollector()
    assert py.name == 'python'
    assert py._fact_ids == set()

# Generated at 2022-06-23 01:37:59.679155
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert python_facts.get('python', None)

# Generated at 2022-06-23 01:38:01.360908
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)

# Generated at 2022-06-23 01:38:08.232337
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a class instance for collect method unit test
    python_collector_obj = PythonFactCollector()

    # Call the collect method
    python_facts = python_collector_obj.collect()

    # Unit test assertion: module should have version and version_info as keys
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']

    # Unit test assertion: module should have executable and has_sslcontext as keys
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:38:17.032205
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result = collector.collect()

    assert 'python' in result
    assert 'executable' in result['python']
    assert 'version' in result['python']
    assert 'major' in result['python']['version']
    assert 'minor' in result['python']['version']
    assert 'micro' in result['python']['version']
    assert 'releaselevel' in result['python']['version']
    assert 'serial' in result['python']['version']
    assert 'version_info' in result['python']
    assert isinstance(result['python']['version_info'], list)
    assert len(result['python']['version_info']) == 5
    assert 'type' in result['python']

# Generated at 2022-06-23 01:38:26.580863
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = python_fact_collector.collect()
    # If a method named collect doesn't return a Python dictionary
    # a TypeError should be raised
    assert isinstance(collected_facts, dict), 'The type of the return value of collect method is not a Python dictionary'
    # Make sure the return value of method collect is a Python dictionary
    # It should have at least one key named 'python'
    assert 'python' in collected_facts, 'There is no key named "python" in the return value of collect method'
    # The value of key 'python' should be a dictionary
    assert isinstance(collected_facts['python'], dict), 'The value of key "python" in the return value of collect method is not a Python dictionary'
    # Make sure the value of key 'python

# Generated at 2022-06-23 01:38:28.317032
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'

# Generated at 2022-06-23 01:38:30.151235
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert 'python' == fact_collector.name

# Generated at 2022-06-23 01:38:36.312362
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_test_data = PythonFactCollector().collect()
    assert isinstance(python_test_data, dict)
    assert isinstance(python_test_data['python']['version'], dict)
    assert isinstance(python_test_data['python']['version_info'], list)
    assert isinstance(python_test_data['python']['executable'], basestring)

# Generated at 2022-06-23 01:38:39.860807
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-23 01:38:41.831890
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:38:42.847863
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-23 01:38:46.744208
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector(None)
    facts = c.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']

# Generated at 2022-06-23 01:38:50.507899
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = PythonFactCollector().collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-23 01:39:01.289494
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Dummy module and facts
    module = None
    collected_facts = {}

    # Test collect method
    test = PythonFactCollector()
    generated_facts = test.collect(module, collected_facts)

    # Assertion: generated_facts is a dict
    assert isinstance(generated_facts, dict)

    # Assertion: generated_facts['python'] is a dict
    assert isinstance(generated_facts['python'], dict)

    # Assertion: generated_facts['python']['version'] is a dict
    assert isinstance(generated_facts['python']['version'], dict)

    # Assertion: generated_facts['python']['version']['major'] is an int
    assert isinstance(generated_facts['python']['version']['major'], int)

    # Assertion:

# Generated at 2022-06-23 01:39:05.308804
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collectors.python.python_fact_collector import PythonFactCollector
    collector = PythonFactCollector()
    assert isinstance(collector, PythonFactCollector)


# Generated at 2022-06-23 01:39:13.552675
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Test if method collect of class PythonFactCollector returns dict
    with correct keys and values.
    '''
    fc = PythonFactCollector()
    assert isinstance(fc.collect(), dict)
    assert 'python' in fc.collect()
    assert isinstance(fc.collect()['python'], dict)
    assert fc.collect()['python']['version']['major'] == sys.version_info[0]
    assert fc.collect()['python']['version']['minor'] == sys.version_info[1]
    assert fc.collect()['python']['version']['micro'] == sys.version_info[2]
    assert fc.collect()['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-23 01:39:24.297188
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    import sys
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    c = Collector()
    p = PythonFactCollector(c)

    fake_module = lambda: None

    retval = p.collect(fake_module, {})
    assert isinstance(retval, dict)

    assert retval['python']['executable'] == sys.executable
    assert retval['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert retval

# Generated at 2022-06-23 01:39:30.613013
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # When:
    py_facts = PythonFactCollector()

    # Then:
    assert hasattr(py_facts, 'name')
    assert py_facts.name == 'python'
    assert hasattr(py_facts, '_fact_ids')
    assert isinstance(py_facts._fact_ids, set)
    assert hasattr(py_facts, 'collect')

# Generated at 2022-06-23 01:39:32.452654
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    # Just check that no exceptions are raised
    collector.collect()

