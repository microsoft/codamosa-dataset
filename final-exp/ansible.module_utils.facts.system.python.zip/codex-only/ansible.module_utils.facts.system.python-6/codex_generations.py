

# Generated at 2022-06-23 01:29:32.131338
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()
    assert collector.collect() == {'python': {'type': u'CPython', 'version': {'releaselevel': u'final', 'micro': 0, 'minor': 6, 'serial': 0, 'major': 2}, 'version_info': [2, 6, 0, 'final', 0], 'executable': u'/usr/bin/python', 'has_sslcontext': True}}

# Generated at 2022-06-23 01:29:39.247889
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:29:50.308676
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module_args = {}
    python_fact = PythonFactCollector(module_args, {})
    result = python_fact.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:29:51.645058
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    assert p.collect()

# Generated at 2022-06-23 01:30:01.026514
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create and return a mocked ansible module
    def _get_mock_ansible_module():
        module = MockAnsibleModule()
        module.mock_params = {}
        return module

    # Test Pyhton Fact Collect
    def _test_python_fact_collect():
        # Create the Pyhton Fact Collector
        collector = PythonFactCollector()
        # Get the ansible module
        ansible_module = _get_mock_ansible_module()
        # Collect all facts
        facts = collector.collect(ansible_module)
        # Return the facts
        return facts

    # Testing Python Fact Collector
    sys.modules['ansible.module_utils.facts.collector'] = Mock()
    # Build the facts
    facts = _test_python_fact_collect()
    # Validate that we have the

# Generated at 2022-06-23 01:30:05.666159
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    x = PythonFactCollector()
    result = x.collect()
    assert result == {'python': {'version': {'major': 3, 'minor': 5, 'micro': 2, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 5, 2, 'final', 0], 'executable': '/usr/bin/python3.5', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-23 01:30:12.576379
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    atc = PythonFactCollector()
    assert atc.name == 'python'
    assert 'python' in atc.collect()
    assert 'version' in atc.collect()['python']
    assert 'version_info' in atc.collect()['python']
    assert 'executable' in atc.collect()['python']
    assert 'type' in atc.collect()['python']
    assert 'has_sslcontext' in atc.collect()['python']

# Generated at 2022-06-23 01:30:14.327077
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'


# Generated at 2022-06-23 01:30:16.525975
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # make sure we get dict back
    python_fc = PythonFactCollector()
    assert isinstance(python_fc.collect(), dict)

# Generated at 2022-06-23 01:30:26.451139
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    res = python_fact_collector.collect()
    assert(res is not None)
    assert(res['python']['version']['major'] == sys.version_info[0])
    assert(res['python']['version']['minor'] == sys.version_info[1])
    assert(res['python']['version']['micro'] == sys.version_info[2])
    assert(res['python']['version']['releaselevel'] == sys.version_info[3])
    assert(res['python']['version']['serial'] == sys.version_info[4])
    assert(res['python']['version_info'] == list(sys.version_info))

# Generated at 2022-06-23 01:30:31.169326
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, PythonFactCollector)

# Unit tests for method collect of class PythonFactCollector

# Generated at 2022-06-23 01:30:39.024303
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test method collect of class PythonFactCollector.
    """
    # Test with empty collected_facts
    collector = PythonFactCollector()
    collected_facts = collector.collect(module='', collected_facts={})
    assert 'python' in collected_facts
    assert 'executable' in collected_facts['python']
    assert 'has_sslcontext' in collected_facts['python']
    assert 'version' in collected_facts['python']
    assert 'type' in collected_facts['python']
    assert 'version_info' in collected_facts['python']

# Generated at 2022-06-23 01:30:51.089843
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector.collect(module=None) == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:31:00.838199
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()['python']
    assert 'major' in python_facts['version']
    assert 'minor' in python_facts['version']
    assert 'micro' in python_facts['version']
    assert 'releaselevel' in python_facts['version']
    assert 'serial' in python_facts['version']
    assert isinstance(python_facts['version_info'], list)
    assert isinstance(python_facts['executable'], str)
    assert isinstance(python_facts['has_sslcontext'], bool)
    # The test below is skipped on Windows, because it's not possible to
    # determine the Python version executing the ansible-test command. I.e.
    # Python 2.7.14 (default, Oct  2 2017, 15:27:57) [GCC 5.4.

# Generated at 2022-06-23 01:31:12.332017
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()   # setUp
    facts_dict = fc.collect()    # test case

    assert 'python' in facts_dict
    assert isinstance(facts_dict['python'], dict)
    assert isinstance(facts_dict['python']['version'], dict)
    assert isinstance(facts_dict['python']['version_info'], list)
    assert 'major' in facts_dict['python']['version']
    assert 'minor' in facts_dict['python']['version']
    assert 'micro' in facts_dict['python']['version']
    assert 'releaselevel' in facts_dict['python']['version']
    assert 'serial' in facts_dict['python']['version']
    assert 'executable' in facts_dict['python']

# Generated at 2022-06-23 01:31:20.822879
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    # all python have SSLContext support on 2.7.9 and later
    if sys.version_info[0] > 2 or (sys.version_info[0] == 2 and (sys.version_info[1] > 7 or (sys.version_info[1] == 7 and sys.version_info[2] > 8))):
        assert result['python']['has_sslcontext'] == True
    else:
        assert result['python']['has_sslcontext'] == False

# Generated at 2022-06-23 01:31:21.971694
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    p = PythonFactCollector()

    assert p.name == 'python'

# Generated at 2022-06-23 01:31:26.847910
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-23 01:31:31.931075
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    This unit test checks if the constructor of the class PythonFactCollector
    raises exceptions and if the instance variables are set.
    """
    fact_collector = PythonFactCollector()

    assert isinstance(fact_collector, PythonFactCollector)
    assert hasattr(fact_collector, 'name')
    assert hasattr(fact_collector, '_fact_ids')


# Generated at 2022-06-23 01:31:40.726760
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    res = c.collect()
    assert 'python' in res
    assert res['python']['version']['major'] == sys.version_info[0]
    assert res['python']['version']['minor'] == sys.version_info[1]
    assert res['python']['version']['micro'] == sys.version_info[2]
    assert res['python']['version']['releaselevel'] == sys.version_info[3]
    assert res['python']['version']['serial'] == sys.version_info[4]
    assert len(res) == 1

# Generated at 2022-06-23 01:31:48.845481
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    python_fact_collector = PythonFactCollector()

    collected_facts = CollectedFacts(invalid_facts=[])
    python_facts = python_fact_collector.collect(collected_facts=collected_facts)

    assert python_facts is not None
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]

# Generated at 2022-06-23 01:31:58.147159
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    def import_mock(name, *args, **kwargs):
        module_mock = MagicMock()
        if name == 'ssl':
            module_mock.create_default_context.return_value = 'SSLContext'
        return module_mock

    module_mock = MagicMock(name='module_mock')
    sys.modules['ansible'] = module_mock
    module_mock.version_info = [2, 3, 4, 'releaselevel', 5]
    module_mock.subversion = ['subversion']
    module_mock.subversion.append('subversion')
    module_mock.implementation = MagicMock(name='implementation')
    module_mock.implementation.name = 'implementation'


# Generated at 2022-06-23 01:32:01.993259
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector(None)
    facts = pfc.collect()
    assert 'python' in facts
    python_facts = facts['python']
    assert 'version' in python_facts
    assert 'version_info' in python_facts
    assert 'has_sslcontext' in python_facts

# Generated at 2022-06-23 01:32:12.964805
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result_python_version_info = fact_collector.collect().get('python').get('version_info')
    assert result_python_version_info == list(sys.version_info)
    result_python_executable = fact_collector.collect().get('python').get('executable')
    assert result_python_executable == sys.executable
    result_python_type = fact_collector.collect().get('python').get('type')
    try:
        assert result_python_type == sys.subversion[0]
    except AttributeError:
        try:
            assert result_python_type == sys.implementation.name
        except AttributeError:
            assert result_python_type == None




# Generated at 2022-06-23 01:32:19.867669
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_text

    # Create instance of PythonFactCollector
    pfc = PythonFactCollector()

    # Check if method collect returns dictionary
    assert isinstance(pfc.collect(), dict)

    # Check if method collect returns correct keys
    assert sorted(list(pfc.collect().keys())) == ['python']

    # Check if method collect returns correct values
    assert pfc.collect()['python']['version']['major'] == \
        sys.version_info[0]
    assert pfc.collect()['python']['version']['minor'] == \
        sys.version_info[1]
    assert pfc.collect()['python']['version']['micro'] == \
        sys.version

# Generated at 2022-06-23 01:32:21.876898
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:32:29.292583
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Build the parameters to pass to the constructor
    params = {
        'module': None,
        'collected_facts': None
    }
    obj = PythonFactCollector(**params)

    # Test default functionality of constructor
    assert hasattr(obj, 'name')
    assert hasattr(obj, '_fact_ids')

    # Test method collect
    collect_result = obj.collect(**params)
    assert 'python' in collect_result
    assert 'version' in collect_result['python']
    assert 'version_info' in collect_result['python']
    assert 'executable' in collect_result['python']
    assert 'has_sslcontext' in collect_result['python']

# Generated at 2022-06-23 01:32:31.395086
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert 'python' in python_facts._fact_ids

# Generated at 2022-06-23 01:32:32.735734
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-23 01:32:33.301688
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:32:35.871110
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    # check if has_sslcontext is in the keys returned by collect()
    assert 'has_sslcontext' in python_collector.collect()['python']

# Generated at 2022-06-23 01:32:37.944054
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # This module is not meant to be tested as a standalone unit.
    # It's expected to be tested as part of the 'python' group.
    assert True

# Generated at 2022-06-23 01:32:39.502951
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector.collect()

# Generated at 2022-06-23 01:32:48.064325
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pf = pfc._collect()
    assert type(pf) is dict
    assert 'python' in pf
    assert 'version' in pf['python']
    assert 'version_info' in pf['python']
    assert 'major' in pf['python']['version']
    assert 'minor' in pf['python']['version']
    assert 'micro' in pf['python']['version']
    assert 'releaselevel' in pf['python']['version']
    assert 'serial' in pf['python']['version']
    assert 'executable' in pf['python']
    assert 'has_sslcontext' in pf['python']

# Generated at 2022-06-23 01:32:57.992007
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # check if python_json = PythonFactCollector.collect()"
    python_json = PythonFactCollector().collect()

    assert(python_json['python']['version']['major'] == sys.version_info[0])
    assert(python_json['python']['version']['minor'] == sys.version_info[1])
    assert(python_json['python']['version']['micro'] == sys.version_info[2])
    assert(python_json['python']['version']['releaselevel'] == sys.version_info[3])
    assert(python_json['python']['version']['serial'] == sys.version_info[4])
    assert(python_json['python']['version_info'] == list(sys.version_info))

# Generated at 2022-06-23 01:32:59.164614
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()


# Generated at 2022-06-23 01:33:05.561138
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

    # PythonFactCollector is derived from BaseFactCollector, check that
    # the base class constructor can set the _fact_ids properly
    assert x._fact_ids == set(['python_' + x for x in [
        'version', 'version_info', 'executable', 'has_sslcontext', 'type'
    ]])

# Generated at 2022-06-23 01:33:14.625131
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    plat = sys.platform
    version = sys.version_info
    python_type = 'CPython'
    executable = sys.executable

    # Check if we are running on PY3
    if sys.version_info >= (3, 0):
        if plat == 'win32':
            vinfo = tuple(sys.version_info[0:2])
            if vinfo >= (3, 4):
                executable = 'C:\\Python%d%d\\python.exe' % vinfo
            else:
                executable = 'C:\\Python%d%d\\python.exe' % vinfo
    else:
        executable = 'C:\\Python%d%d\\python.exe' % (version[0], version[1])

    pf = PythonFactCollector()
    ans = pf.collect()

# Generated at 2022-06-23 01:33:19.473578
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_collector = PythonFactCollector()

    python_facts = python_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']
    return 0


if __name__ == '__main__':
    # Run the unit test
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:33:29.256193
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    collected_facts = FactCollector(
        None,
        None,
        None,
        None
    ).collect(
        module_facts = {},
        collected_facts = {}
    )

    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'has_sslcontext' in collected_facts['python']

    assert 'major' in collected_facts['python']['version']
    assert 'minor' in collected_facts['python']['version']
    assert 'micro' in collected_facts['python']['version']

# Generated at 2022-06-23 01:33:31.354393
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == "python"
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:33:35.923294
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create instance of class PythonFactCollector
    python_fact_collector = PythonFactCollector()
    # Run method collect and get the result
    result = python_fact_collector.collect()
    # Check that result is not empty dict
    assert(result)

# Generated at 2022-06-23 01:33:45.491567
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    #assert False, "Please implement unit test"
    python_facts = PythonFactCollector().collect()
    # Python
    assert isinstance(python_facts, dict) is True
    assert 'python' in python_facts
    assert isinstance(python_facts['python'], dict) is True
    assert 'version' in python_facts['python']
    assert isinstance(python_facts['python']['version'], dict) is True
    assert 'version_info' in python_facts['python']
    assert isinstance(python_facts['python']['version_info'], list) is True
    assert 'executable' in python_facts['python']
    assert isinstance(python_facts['python']['executable'], str) is True
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:33:53.826829
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test with input argument as None
    pf = PythonFactCollector()
    res = pf.collect()
    assert 'python' in res
    assert res['python']['version']['major'] == sys.version_info[0]
    assert res['python']['version']['minor'] == sys.version_info[1]
    assert res['python']['version']['micro'] == sys.version_info[2]
    assert res['python']['version']['releaselevel'] == sys.version_info[3]
    assert res['python']['version']['serial'] == sys.version_info[4]
    assert res['python']['version_info'] == list(sys.version_info)
    assert res['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:34:03.017323
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_data = fact_collector.collect()
    assert fact_data['python']['version_info'] == list(sys.version_info)
    assert fact_data['python']['version']['major'] == sys.version_info[0]
    assert fact_data['python']['version']['minor'] == sys.version_info[1]
    assert fact_data['python']['version']['micro'] == sys.version_info[2]
    assert fact_data['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_data['python']['version']['serial'] == sys.version_info[4]
    assert fact_data['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:34:07.625086
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfactcollector = PythonFactCollector()
    assert pythonfactcollector.name == 'python'
    assert type(pythonfactcollector._fact_ids) == set
    assert pythonfactcollector._fact_ids == set()

# Generated at 2022-06-23 01:34:13.926943
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact = fact_collector.collect()
    assert fact == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 9, 'releaselevel': 'final', 'serial': 0}, 'type': 'CPython', 'has_sslcontext': True, 'version_info': [2, 7, 9, 'final', 0]}}

# Generated at 2022-06-23 01:34:22.468439
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Test constructor of class PythonFactCollector
    '''
    try:
        from ssl import create_default_context, SSLContext
        has_sslcontext = True
        del create_default_context
        del SSLContext
    except ImportError:
        has_sslcontext = False

    pf = PythonFactCollector()
    assert(pf.name == "python")

    python_facts = {}

# Generated at 2022-06-23 01:34:24.693555
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:34:32.872938
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    result = python_facts.collect()
    assert result == {
        "python": {
            "version": {
                "major": sys.version_info[0],
                "minor": sys.version_info[1],
                "micro": sys.version_info[2],
                "releaselevel": sys.version_info[3],
                "serial": sys.version_info[4],
            },
            "version_info": list(sys.version_info),
            "executable": sys.executable,
            "has_sslcontext": HAS_SSLCONTEXT,
            "type": "cpython",
        }
    }


# Generated at 2022-06-23 01:34:35.513701
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:34:38.902985
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    # Test collect and make sure we get the correct data
    assert isinstance(collector.collect(), dict)

# Generated at 2022-06-23 01:34:40.164866
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect()

# Generated at 2022-06-23 01:34:42.414361
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:34:50.433098
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    from ansible.module_utils.facts.collector import BaseFactCollector

    class PythonFactCollector(BaseFactCollector):
        name = 'python'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            python_facts = {}

# Generated at 2022-06-23 01:34:51.617540
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:35:03.214521
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc is not None
    pfc_facts = pfc.collect()
    assert pfc_facts is not None

    # check for the python key in pfc_facts
    assert 'python' in pfc_facts

    python_facts = pfc_facts['python']
    assert python_facts is not None

    # check for the version key in pfc_facts
    assert 'version' in python_facts

    # check for keys in python_facts['version']
    version_info = python_facts['version']
    assert 'major' in version_info
    assert 'minor' in version_info
    assert 'micro' in version_info
    assert 'releaselevel' in version_info
    assert 'serial' in version_info

    # check for the version_info key in pfc_

# Generated at 2022-06-23 01:35:11.452963
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create instance of class PythonFactCollector
    fact_collector = PythonFactCollector()

    # Get the facts collected by PythonFactCollector
    collected_facts = fact_collector.collect()

    # Assert the facts
    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:35:13.390834
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:35:15.957693
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector(None, None, None)
    assert p.name == 'python'
    assert len(p._fact_ids) == 0


# Generated at 2022-06-23 01:35:25.266352
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector object
    python_fc = PythonFactCollector()
    # The collect method should return a dict, either
    # empty or filled with facts
    python_facts = python_fc.collect()
    if type(python_facts) is not type({}):
        raise AssertionError()
    # The fact dictionary should contain a 'python' key
    if type(python_facts.get('python')) is not type({}):
        raise AssertionError()
    # The value of the 'python' key should be a list
    python = python_facts.get('python')
    if type(python) is not type({}):
        raise AssertionError()
    # The list should contain a 'version' key
    if type(python.get('version')) is not type({}):
        raise Assert

# Generated at 2022-06-23 01:35:26.878698
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None

# Generated at 2022-06-23 01:35:28.075098
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'

# Generated at 2022-06-23 01:35:30.223759
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert 'python' in py_fact_collector._fact_ids

# Generated at 2022-06-23 01:35:39.521324
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert isinstance(result['python'], dict)
    assert isinstance(result['python']['version'], dict)
    assert isinstance(result['python']['version_info'], list)
    assert isinstance(result['python']['executable'], basestring)
    assert isinstance(result['python']['has_sslcontext'], bool)
    assert isinstance(result['python']['type'], (basestring, type(None)))

# Generated at 2022-06-23 01:35:41.335554
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()

# Generated at 2022-06-23 01:35:50.648650
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from mock import MagicMock, Mock, patch

    python_facts_collector = PythonFactCollector()
    ansible_collector.collectors = {'python': python_facts_collector}
    ansible_collector.collector_obj = None
    ansible_collector.collectors_class = None

    python_facts_collector._cache = {}

    with patch('ansible.module_utils.facts.ansible_collector.get_collector_class') as mock_get_class:
        mock_get_class.return_value = Mock()
        ansible_collector.collect()
        mock_get_class.assert_called()
        ansible_collect

# Generated at 2022-06-23 01:35:59.445388
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    ''' Test collect method of class PythonFactCollector '''
    collector = PythonFactCollector()
    python_facts = collector.collect()

    assert(python_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    })

# Generated at 2022-06-23 01:36:00.762897
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert(c != None)

# Generated at 2022-06-23 01:36:10.979876
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:36:15.469556
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:36:17.219497
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfact = PythonFactCollector()
    pyfacts = pyfact.collect()
    assert pyfacts['python']['type'] is not None

# Generated at 2022-06-23 01:36:21.543063
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()


# Generated at 2022-06-23 01:36:27.477998
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    python_facts = py_fact_collector.collect()

    _ = python_facts.get('python')

    assert _ is not None
    assert _.get('version') is not None
    assert _.get('version_info') is not None
    assert _.get('executable') is not None
    assert _.get('type') is not None

# Generated at 2022-06-23 01:36:28.969537
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact = PythonFactCollector()
    assert fact.name == 'python'

# Generated at 2022-06-23 01:36:34.189947
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-23 01:36:35.767218
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector(None, None)
    assert isinstance(c.collect(), dict)

# Test that module load

# Generated at 2022-06-23 01:36:45.207198
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'major' in facts['python']['version']
    assert type(facts['python']['version']['major']) is int
    assert 'minor' in facts['python']['version']
    assert type(facts['python']['version']['minor']) is int
    assert 'micro' in facts['python']['version']
    assert type(facts['python']['version']['micro']) is int
    assert 'releaselevel' in facts['python']['version']
    assert type(facts['python']['version']['releaselevel']) is str
    assert 'serial' in facts['python']['version']

# Generated at 2022-06-23 01:36:53.889120
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector(None)
    collected_facts = fact_collector.collect()

    assert collected_facts['python']['version']['major'] == 3
    assert collected_facts['python']['version']['minor'] == 6
    assert collected_facts['python']['version']['micro'] == 1
    assert collected_facts['python']['version']['releaselevel'] == 'final'
    assert collected_facts['python']['version_info'][0] == 3
    assert collected_facts['python']['version_info'][1] == 6
    assert collected_facts['python']['version_info'][2] == 1
    assert collected_facts['python']['version_info'][3] == 'final'

# Generated at 2022-06-23 01:37:02.667835
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test for method collect of class PythonFactCollector.
    """
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import PythonFactCollector
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, BaseFactCollector)
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()
    python_facts = python_fact_collector.collect()

# Generated at 2022-06-23 01:37:04.440552
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector(None)
    assert fact_collector.collect()['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:37:11.187909
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = 'test_module'
    c = PythonFactCollector()
    facts = c.collect(module, None)
    assert type(facts) is dict
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:37:19.866400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = dict(python=dict(
        version=dict(
            major=sys.version_info[0],
            minor=sys.version_info[1],
            micro=sys.version_info[2],
            releaselevel=sys.version_info[3],
            serial=sys.version_info[4]
        ),
        version_info=list(sys.version_info),
        executable=sys.executable,
        has_sslcontext=HAS_SSLCONTEXT,
        type=sys.implementation.name
    ))

    assert PythonFactCollector().collect() == result

# Generated at 2022-06-23 01:37:20.808734
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert set(python_facts.collect().keys()) == set(['python'])

# Generated at 2022-06-23 01:37:23.623169
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert python_fact_collector._fact_ids == set()
    assert 'python' in python_fact_collector.collect().keys()

# Generated at 2022-06-23 01:37:28.825428
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert hasattr(PythonFactCollector, '_fact_class')
    assert PythonFactCollector._fact_class is None
    assert hasattr(PythonFactCollector, '_fact_ids')
    assert len(PythonFactCollector._fact_ids) == 0
    assert hasattr(PythonFactCollector, 'name')
    assert PythonFactCollector.name == 'python'


# Generated at 2022-06-23 01:37:36.513202
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create instance of PythonFactCollector with an empty set
    module_facts = PythonFactCollector.collect()

    _facts_version = module_facts['python']['version']
    _facts_executable = module_facts['python']['executable']
    _facts_version_info = module_facts['python']['version_info']
    _facts_has_sslcontext = module_facts['python']['has_sslcontext']

    # Assert subversion info is correct
    assert _facts_version['major'] == sys.version_info[0]
    assert _facts_version['minor'] == sys.version_info[1]
    assert _facts_version['micro'] == sys.version_info[2]
    assert _facts_version['releaselevel'] == sys.version_info[3]
    assert _facts

# Generated at 2022-06-23 01:37:40.356924
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'
    assert len(python._fact_ids) == 0

if __name__ == '__main__':
    test_PythonFactCollector()

# Generated at 2022-06-23 01:37:42.148364
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:37:44.238618
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert issubclass(PythonFactCollector, BaseFactCollector)
    pyfg = PythonFactCollector()
    assert pyfg.name == 'python'

# Generated at 2022-06-23 01:37:53.412326
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    output = py_fact_collector.collect()

    # Verify the version
    assert output['python']['version_info'][0] == sys.version_info[0]
    assert output['python']['version_info'][1] == sys.version_info[1]
    assert output['python']['version_info'][2] == sys.version_info[2]
    assert output['python']['version_info'][3] == sys.version_info[3]
    assert output['python']['version_info'][4] == sys.version_info[4]

    # Verify the type
    assert 'python' in output and 'type' in output['python']

# Generated at 2022-06-23 01:37:54.889747
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_facts = PythonFactCollector()
    assert py_facts.name == 'python'

# Generated at 2022-06-23 01:37:57.466456
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    assert py_collector.collect()['python']['version_info'][0] == sys.version_info[0]

# Generated at 2022-06-23 01:38:06.057383
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils import facts

    python_fact_collector = PythonFactCollector()
    ansible_module_instance = facts.AnsibleModule(argument_spec={})
    fact_collection = {}
    python_facts = python_fact_collector.collect(ansible_module_instance, fact_collection)
    assert 'python' in python_facts
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_

# Generated at 2022-06-23 01:38:15.493529
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # The list of facts that we expect to get
    expected_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    # We try to get the type of the Python implementation

# Generated at 2022-06-23 01:38:16.433556
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:38:25.144539
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instantiate a python fact collector and run tests
    pfc = PythonFactCollector(None)
    assert pfc.collect() == {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'CPython',
            'version': {
                'major': sys.version_info[0],
                'micro': sys.version_info[2],
                'minor': sys.version_info[1],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }

# Generated at 2022-06-23 01:38:27.588646
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:38:37.113313
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    dummy_logger = object
    fact_collector = PythonFactCollector(dummy_logger)
    assert fact_collector.name == "python"
    assert fact_collector._fact_ids == set()
    assert fact_collector.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:38:46.473286
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']

# Generated at 2022-06-23 01:38:49.908251
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert(obj.name == 'python')
   # assert(obj._fact_ids == {'python'})

# Unit test to check the part of function collect() which collects facts related to python version

# Generated at 2022-06-23 01:39:00.363631
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    facts = p.collect()
    assert isinstance(facts["python"]["version_info"], list)
    assert isinstance(facts["python"]["version"]["major"], int)
    assert isinstance(facts["python"]["version"]["minor"], int)
    assert isinstance(facts["python"]["version"]["micro"], int)
    assert isinstance(facts["python"]["version"]["releaselevel"], str)
    assert isinstance(facts["python"]["version"]["serial"], int)
    assert isinstance(facts["python"]["executable"], str)
    assert isinstance(facts["python"]["has_sslcontext"], bool)

# Generated at 2022-06-23 01:39:02.897676
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:39:05.309336
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert hasattr(PythonFactCollector, 'name')
    assert hasattr(PythonFactCollector, '_fact_ids')


# Generated at 2022-06-23 01:39:08.567384
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from collections import namedtuple
    x = namedtuple('x', ['collector', 'module'])

    pfc = PythonFactCollector(x(None, None))
    assert pfc.name == 'python'
    assert isinstance(pfc._fact_ids, set)

# Generated at 2022-06-23 01:39:17.829053
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test empty fact collect
    fact_collector = PythonFactCollector()

    # Test collect with empty facts
    fact_collector.collect(collected_facts=dict())

    # Test collect with facts
    fact_collector.collect(collected_facts=dict(ansible_python=dict()))
    fact_collector.collect(collected_facts=dict(ansible_python=dict(version=dict())))
    fact_collector.collect(collected_facts=dict(ansible_python=dict(version=dict(major=sys.version_info[0]))))
    fact_collector.collect(collected_facts=dict(ansible_python=dict(version=dict(major=sys.version_info[0], minor=sys.version_info[1]))))

# Generated at 2022-06-23 01:39:27.838607
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test class constructor
    python_fact_collector = PythonFactCollector()

    # Execute method collect of the class PythonFactCollector
    result = python_fact_collector.collect()

    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)