

# Generated at 2022-06-23 01:29:32.675151
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set(['python'])

# Generated at 2022-06-23 01:29:34.371422
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector.collect()

# Generated at 2022-06-23 01:29:42.220950
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    a = c.collect({'ansible_python_version': '2.6.6'})
    assert a['python']['version']['releaselevel'] == 'final'

# Generated at 2022-06-23 01:29:51.990863
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Unit test for collect method of class PythonFactCollector
    '''
    python_fact_collector = PythonFactCollector()
    facts_dict = {}

    python_fact_collector.collect(collected_facts=facts_dict)

    assert 'python' in facts_dict
    assert 'version' in facts_dict['python']
    assert 'major' in facts_dict['python']['version']
    assert 'minor' in facts_dict['python']['version']
    assert 'micro' in facts_dict['python']['version']
    assert 'releaselevel' in facts_dict['python']['version']
    assert 'serial' in facts_dict['python']['version']
    assert 'version_info' in facts_dict['python']

# Generated at 2022-06-23 01:29:57.505122
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    pfc = PythonFactCollector()
    rv = pfc.collect()

    assert rv['python']['version']['major'] == sys.version_info[0]
    assert rv['python']['version_info'][0] == sys.version_info[0]
    assert rv['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:29:59.344437
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:30:01.059458
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    pyfc.collect()
    assert pyfc.get_fact_names()

# Generated at 2022-06-23 01:30:05.057711
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test_collector = PythonFactCollector()

    assert test_collector.name == 'python'


# Generated at 2022-06-23 01:30:07.222181
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc


# Generated at 2022-06-23 01:30:09.386373
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'



# Generated at 2022-06-23 01:30:13.790818
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts is not None
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert 'type' in collected_facts['python']

# Generated at 2022-06-23 01:30:21.492428
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fcollector = PythonFactCollector()
    assert fcollector.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:30:28.745274
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    _collector = PythonFactCollector()
    assert _collector.collect() == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': sys.implementation.name
    }}

# Generated at 2022-06-23 01:30:30.598557
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    if __name__ == '__main__':
        python_collector.collect()

# Generated at 2022-06-23 01:30:32.795125
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc.name == 'python'

# Generated at 2022-06-23 01:30:35.486625
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc.name == 'python'
    assert fc._fact_ids is not None


# Generated at 2022-06-23 01:30:38.112293
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:30:43.829770
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Get PythonFactCollector instance
    python_fact_collector = PythonFactCollector()

    # Check instance variables
    assert python_fact_collector.name == 'python'
    assert python_fact_collector.requirements == set()
    assert python_fact_collector.collect_once == False
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:30:46.102193
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:30:48.377835
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfact_collector_inst = PythonFactCollector()
    assert isinstance(pyfact_collector_inst, PythonFactCollector)
    assert isinstance(pyfact_collector_inst, BaseFactCollector)

# Generated at 2022-06-23 01:31:00.245900
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create an instance of PythonFactCollector
    fact_collector = PythonFactCollector()

    # Call the method collect
    fact_dict = fact_collector.collect()

    # Test the collected facts
    assert sorted(fact_dict['python']['version'].keys()) == [ 'major', 'micro', 'minor', 'releaselevel', 'serial' ]
    assert fact_dict['python']['version']['major'] == sys.version_info[0]
    assert fact_dict['python']['version']['minor'] == sys.version_info[1]
    assert fact_dict['python']['version']['micro'] == sys.version_info[2]
    assert fact_dict['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_dict

# Generated at 2022-06-23 01:31:02.244555
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    col = PythonFactCollector()
    assert col.name == 'python'
    assert col._fact_ids != set()


# Generated at 2022-06-23 01:31:03.748082
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    assert 'python' in py_collector.collect()

# Generated at 2022-06-23 01:31:05.110546
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c is not None

# Generated at 2022-06-23 01:31:09.144425
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert py_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:31:12.613589
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_module = sys.modules[__name__]
    fact_collector = PythonFactCollector(fact_module)
    facts_collected = fact_collector.collect()
    assert 'python' in facts_collected

# Generated at 2022-06-23 01:31:15.919505
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p is not None
    assert p._fact_ids is not None
    assert len(p.collect()) > 0

if __name__ == "__main__":
    test_PythonFactCollector()

# Generated at 2022-06-23 01:31:19.170200
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-23 01:31:20.947348
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
  pfc = PythonFactCollector()
  assert pfc.name == 'python'

# Generated at 2022-06-23 01:31:24.696055
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test with value that should be present
    fc = PythonFactCollector()
    assert fc.name == 'python'

    # Test with value that should not be present
    fc = PythonFactCollector()
    assert fc.name != 'anything_else'

# Generated at 2022-06-23 01:31:26.799620
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == "python"
    assert PythonFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:31:28.134745
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:31:31.572341
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_info = PythonFactCollector().collect()
    assert "python" in python_fact_info
    assert "version" in python_fact_info["python"]

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:31:33.195195
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == "python"

# Generated at 2022-06-23 01:31:35.372733
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:31:38.995075
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    Unit test for constructor of class PythonFactCollector
    """

    pfc = PythonFactCollector()
    assert pfc is not None
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:31:42.174665
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test the collect() method of class PythonFactCollector"""
    facts_collector = PythonFactCollector()
    facts_dict = facts_collector.collect()
    # following tests are testing implementation details and should
    # not be considered stable
    assert set(facts_dict) == set(['python'])

# Generated at 2022-06-23 01:31:46.530741
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import sys
    PythonFactCollector.collect(module=None, collected_facts=Collector())
    assert len(sys.version_info) == 5
    assert sys.version_info[1] >= 6 and sys.version_info[1] <= 9
    assert sys.version_info[3] in ['alpha', 'beta', 'candidate', 'final']

# Generated at 2022-06-23 01:31:50.257152
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:31:59.318536
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize PythonFactCollector instance
    fc = PythonFactCollector()

    # Call collect method
    facts = fc.collect()

    # Test whether facts is a dict
    assert isinstance(facts, dict)

    # Test whether the length of dict facts is one
    assert len(facts.keys()) == 1

    # Test whether the key in dict facts is 'python'
    assert 'python' in facts.keys()

    # Test whether the value in dict facts is a dict
    assert isinstance(facts['python'], dict)

    # Test whether the dict of dict facts has key 'version'
    assert 'version' in facts['python'].keys()

    # Test whether the value of key 'version' in dict facts is a dict
    assert isinstance(facts['python']['version'], dict)

# Generated at 2022-06-23 01:32:01.081345
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'
    assert pf.collect()

# Generated at 2022-06-23 01:32:02.855403
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert python_fact.name == 'python'
    assert python_fact._fact_ids == set()



# Generated at 2022-06-23 01:32:04.593553
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:32:09.115077
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert python_facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:32:11.631049
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert list(sys.version_info) == PythonFactCollector().collect(collected_facts={})['python']['version_info']

# Generated at 2022-06-23 01:32:12.266206
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:32:13.276718
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:32:13.754882
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:32:24.794341
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact = PythonFactCollector()
    assert fact.name == 'python'
    assert fact.collect() == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }}

# Generated at 2022-06-23 01:32:28.208397
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collect_method = PythonFactCollector().collect
    assert collect_method is not None

# Generated at 2022-06-23 01:32:30.455598
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    colc = PythonFactCollector()

    assert colc.name == 'python'
    assert 'python' in colc._fact_ids

# Generated at 2022-06-23 01:32:31.762004
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    actual_result = PythonFactCollector().name
    expected_result = 'python'
    assert actual_result == expected_result


# Generated at 2022-06-23 01:32:36.709944
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    facts = pyfc.collect(collected_facts=dict())
    assert facts['python']
    for key in ['version', 'version_info', 'executable', 'has_sslcontext']:
        assert key in facts['python']

# Generated at 2022-06-23 01:32:39.358352
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()
    assert obj.collect()["python"]["executable"] == sys.executable

# Generated at 2022-06-23 01:32:41.478715
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()

    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:32:49.445638
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()

    assert facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:32:51.673724
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector.name == 'python'

# Generated at 2022-06-23 01:32:59.036360
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
            'version': {
                'major': sys.version_info[0],
                'micro': sys.version_info[2],
                'minor': sys.version_info[1],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }
    collector = PythonFactCollector()
    assert collector.collect() == python_facts


# Generated at 2022-06-23 01:33:01.758349
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert len(pfc._fact_ids) == 0


# Generated at 2022-06-23 01:33:11.828666
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    if sys.executable is None:
        python_executable = 'None'
    else:
        python_executable = sys.executable

    assert python_facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == python_executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT



# Generated at 2022-06-23 01:33:13.116384
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    # Test correct class is instantiated
    assert isinstance(python_facts, PythonFactCollector)

# Generated at 2022-06-23 01:33:22.703417
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    results = collector.collect()

    assert 'python' in results
    assert 'has_sslcontext' in results['python']
    assert 'version' in results['python']
    assert 'version_info' in results['python']
    assert 'type' in results['python']
    assert 'executable' in results['python']

    # Test that the version info is a list
    assert isinstance(results['python']['version_info'], (list, tuple))

    # Test that the has_sslcontext is a boolean
    assert isinstance(results['python']['has_sslcontext'], bool)

    # Test that the version information is all integers
    for ver_info in results['python']['version'].values():
        assert isinstance(ver_info, int)

    # Test that the executable

# Generated at 2022-06-23 01:33:26.200569
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize PythonFactCollector object
    python_instance = PythonFactCollector()

    # Check if collect returns a value
    res = python_instance.collect()
    assert res, "No value returned by collect"


# Generated at 2022-06-23 01:33:34.049347
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:33:36.118483
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert python_facts._fact_ids == set()

# Generated at 2022-06-23 01:33:45.592256
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    context_module = {'module_utils': {'facts': {'collector': {}}}}

    # Test PythonFactCollector.collect()
    # Collected facts should contain a python.version.major,
    #                                      python.version.minor,
    #                                      python.type,
    #                                      python.version.micro,
    #                                      python.version.releaselevel,
    #                                      python.version.serial,
    #                                      python.executable,
    #                                      python.has_sslcontext,
    #                                      python.version_info
    #                                      python.version.version,
    #                                      python.version.full_version
    # attributes
    collect_obj = PythonFactCollector(context_module)
    facts = collect_obj.collect()

    assert 'python' in facts

# Generated at 2022-06-23 01:33:50.624368
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert isinstance(p._fact_ids, set)
    assert p._fact_ids == set()
    assert p.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert isinstance(p.collect()['python']['version'], dict)
    assert isinstance(p.collect()['python']['version_info'], list)

# Generated at 2022-06-23 01:33:57.949231
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:33:59.043282
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:34:03.850239
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.python import PythonFactCollector
    c = Collector()
    f = PythonFactCollector(c)
    validate_PythonFactCollector(f)



# Generated at 2022-06-23 01:34:06.319774
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    my_instance = PythonFactCollector()
    result = my_instance.collect()
    assert ('python' in result)

# Generated at 2022-06-23 01:34:08.957653
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    tst_PythonFactCollector = PythonFactCollector()
    assert tst_PythonFactCollector.name == 'python'
    assert isinstance(tst_PythonFactCollector.collect(), dict)

# Generated at 2022-06-23 01:34:12.551623
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:34:21.552090
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ Unit test for method collect of class PythonFactCollector """
    # Create empty instance of type PythonFactCollector
    test_collector = PythonFactCollector()

    # Unit test with empty instance
    result = test_collector.collect()
    assert result == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 5, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 5, 'final', 0], 'executable': sys.executable, 'has_sslcontext': False}}
    assert type(result['python']['version']) == dict
    assert type(result['python']['version_info']) == list
    assert result['python']['version_info'][0] == 2

# Generated at 2022-06-23 01:34:28.600405
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert 'python' in PythonFactCollector._fact_ids
    # test that `instance` is created properly
    python_fact = PythonFactCollector()
    assert python_fact.name == 'python'
    assert 'python' in python_fact._fact_ids
    # test that `collect` method is callable
    assert callable(python_fact.collect)


# Generated at 2022-06-23 01:34:31.222308
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact = PythonFactCollector()
    assert fact.name == 'python'
    assert len(fact._fact_ids) == 0


# Generated at 2022-06-23 01:34:34.479712
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector instance
    fact_collector = PythonFactCollector()

    # Check if method collect returns a dictionary
    assert isinstance(fact_collector.collect(), dict)


# Generated at 2022-06-23 01:34:37.798038
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert result is not None, "Null result from PythonFactCollector"
    assert 'executable' in result['python'], "Python executable not returned"

# Generated at 2022-06-23 01:34:39.244689
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:34:47.853081
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector('python')
    python_facts = fact_collector.collect()

    # test version
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]

    # test version info
    assert isinstance(python_facts['python']['version_info'], list)

# Generated at 2022-06-23 01:34:51.623174
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Tests for method collect of class PythonFactCollector."""
    # No exception raised with good data
    pfc = PythonFactCollector()
    assert pfc.collect()


# Generated at 2022-06-23 01:34:55.528946
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facter = PythonFactCollector()
    facts = facter.collect()
    assert facts['python']['version']['major'] == 3
    assert facts['python']['version']['minor'] == 5

# Generated at 2022-06-23 01:35:03.076725
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_result = fact_collector.collect()

    assert 'python' in fact_result
    assert 'version' in fact_result['python']
    assert 'version_info' in fact_result['python']
    assert 'executable' in fact_result['python']
    assert fact_result['python']['has_sslcontext'] is True
    assert 'type' in fact_result['python']
    # assert fact_result['python']['type'] not in [None, '']

# Generated at 2022-06-23 01:35:04.417095
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'

# Generated at 2022-06-23 01:35:05.249446
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector()

# Generated at 2022-06-23 01:35:06.181559
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)

# Generated at 2022-06-23 01:35:17.338891
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts.has_key('python')
    assert python_facts['python'].has_key('version')
    assert python_facts['python'].has_key('version_info')
    assert python_facts['python'].has_key('executable')
    assert python_facts['python'].has_key('type')
    assert python_facts['python'].has_key('has_sslcontext')
    # python_version is not present on Python 2.6
    if hasattr(sys, 'version'):
        assert python_facts['python'].has_key('version')
        assert python_facts['python']['version'].has_key('major')
        assert python_facts['python']['version'].has_key('minor')
        assert python_

# Generated at 2022-06-23 01:35:20.001061
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    fc = PythonFactCollector()
    fc.collect()
    assert fc.get_fact_names() == ['python']

# Generated at 2022-06-23 01:35:21.329734
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Just make sure this collector runs without error
    PythonFactCollector().collect()

# Generated at 2022-06-23 01:35:23.159039
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'
    assert python.collect() == {}

# Generated at 2022-06-23 01:35:24.883134
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert python_fact._fact_ids == set()

# Generated at 2022-06-23 01:35:26.538266
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'

# Generated at 2022-06-23 01:35:28.727624
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert not hasattr(PythonFactCollector, '_fact_ids')
    PythonFactCollector()
    assert hasattr(PythonFactCollector, '_fact_ids')


# Generated at 2022-06-23 01:35:36.199686
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    facts = pyfc.collect()

    # PythonFactCollector.get_facts() returns a dict
    assert isinstance(facts, dict)
    # And this dict has an only key 'python'
    assert len(facts) == 1
    assert 'python' in facts

    # Test for various python versions
    # Python 2.6.9, 2.7.6, 2.7.9, 2.7.11, 2.7.13 and 3.4.3 have been tested
    # on Fedora 25
    assert 'version' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']

# Generated at 2022-06-23 01:35:37.322648
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:35:44.656088
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    res = python_collector.collect()
    assert 'python' in res
    assert 'version' in res['python']
    assert 'version_info' in res['python']
    assert 'executable' in res['python']
    assert 'type' in res['python']
    assert 'has_sslcontext' in res['python']
    assert res['python']['type'] in ['cpython', 'ironpython', 'jython', 'pypy', None]

# Generated at 2022-06-23 01:35:47.077811
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()

    assert 'python' == c.name
    assert isinstance(c._fact_ids, set)
    assert 0 == len(c._fact_ids)


# Generated at 2022-06-23 01:35:48.663079
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    result = f.collect()

    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:35:50.235236
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set(['python'])

# Generated at 2022-06-23 01:35:50.967119
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector() is not None

# Generated at 2022-06-23 01:35:56.786055
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    assert fact_collector.collect() == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': sys.implementation.name
    }}

# Generated at 2022-06-23 01:36:07.230976
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Arrange
    python_facts = {
        "python": {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            "executable": sys.executable,
            "type": None,
            "has_sslcontext": HAS_SSLCONTEXT
        }
    }
    pfc = PythonFactCollector()

    # Act
    result = pfc.collect()

    # Assert
    assert result == python_facts

# Generated at 2022-06-23 01:36:10.611673
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    result = f.collect()
    assert result['python']['executable'].endswith('/python')
    assert result['python']['has_sslcontext'] is True
    assert result['python']['version']['major'] == 3

# Generated at 2022-06-23 01:36:14.022759
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test constructor of class PythonFactCollector
    """

    # Test constructor with parameter python
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python', \
        "The python fact collector name is 'python' instead of '%s'" \
        % python_collector.name

# Generated at 2022-06-23 01:36:23.349199
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

    python_version_info = python_facts['python']['version_info']
    assert isinstance(python_version_info, list)
    assert len(python_version_info) == 5
    for x in python_version_info:
        assert isinstance(x, int)

# vim: set expandtab: tabstop=4 shiftwidth=4 softtabstop=4

# Generated at 2022-06-23 01:36:32.547087
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    # We aren't really worried about the specific values here, just that
    # get_facts returns a dict of dict.
    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    python_facts = python_facts['python']
    assert isinstance(python_facts['version'], dict)
    assert isinstance(python_facts['version_info'], list)
    assert isinstance(python_facts['executable'], basestring)
    assert isinstance(python_facts['has_sslcontext'], bool)

# Generated at 2022-06-23 01:36:34.939623
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:36:36.795147
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'
    assert 'python' in pf._fact_ids
    assert isinstance(pf.collect(), dict)

# Generated at 2022-06-23 01:36:43.037568
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json
    import ast

    import __main__
    import ansible.module_utils.facts.collector

    sys.modules['__main__'] = __main__

    fact_collector = ansible.module_utils.facts.collector.get_collector('PythonFactCollector')


# Generated at 2022-06-23 01:36:50.412758
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector({}, None)
    facts = pc.collect()
    assert(facts.get('python'))
    assert(facts.get('python').get('version'))
    assert(facts.get('python').get('version_info'))
    assert(facts.get('python').get('executable'))
    assert(facts.get('python').get('has_sslcontext') is not None)
    assert(facts.get('python').get('type') is not None)

# Generated at 2022-06-23 01:36:53.627728
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    returned_facts = pfc.collect()
    assert isinstance(returned_facts, dict)
    assert 'python' in returned_facts

# Generated at 2022-06-23 01:36:55.762986
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:37:01.004326
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert c.collect() == {'python': {'version': {'micro': 5, 'releaselevel': 'final', 'serial': 0, 'major': 2, 'minor': 7}, 'has_sslcontext': True, 'executable': '/opt/local/Library/Frameworks/Python.framework/Versions/2.7/Resources/Python.app/Contents/MacOS/Python', 'type': None, 'version_info': [2, 7, 5, 'final', 0]}}

# Generated at 2022-06-23 01:37:12.564582
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Initializing Python Fact Collector
    python_fact_collector = PythonFactCollector('clear')

    # Set expected values
    expected_python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.subversion[0]
        }
    }

    # Collect facts
    python_facts = python_fact_collector.collect()

# Generated at 2022-06-23 01:37:23.562004
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['executable'] == sys.executable
    try:
        assert result['python']['type'] == sys.implementation.name
    except AttributeError:
        assert result['python']['type'] == sys.subversion[0]
   

# Generated at 2022-06-23 01:37:26.187867
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'
    assert pf._fact_ids == set(['python'])


# Generated at 2022-06-23 01:37:33.488686
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = collector.collect()

    assert collected_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-23 01:37:45.625516
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = pc.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]

    try:
        expected = sys.subversion[0]
    except AttributeError:
        try:
            expected = sys.implementation.name
        except AttributeError:
            expected = None
    assert facts['python']['type'] == expected

# Generated at 2022-06-23 01:37:54.034146
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'major' in facts['python']['version']
    assert isinstance(facts['python']['version']['major'], int)
    assert 'minor' in facts['python']['version']
    assert isinstance(facts['python']['version']['minor'], int)
    assert 'micro' in facts['python']['version']
    assert isinstance(facts['python']['version']['micro'], int)
    assert 'releaselevel' in facts['python']['version']

# Generated at 2022-06-23 01:37:59.496944
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    results = dict(ansible_python=PythonFactCollector().collect())

    assert 'version' in results['ansible_python']
    assert 'version_info' in results['ansible_python']
    assert 'type' in results['ansible_python']
    assert 'executable' in results['ansible_python']
    assert 'has_sslcontext' in results['ansible_python']

# Generated at 2022-06-23 01:38:01.183550
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """This should pass if class constructor has no errors"""
    pfc = PythonFactCollector()
    return pfc

# Generated at 2022-06-23 01:38:03.529088
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc is not None

# Generated at 2022-06-23 01:38:08.907794
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # TODO: implement this test properly
    # https://github.com/ansible/ansible/issues/29268
    # https://github.com/ansible/ansible/issues/29269
    c = PythonFactCollector()
    c.collect()

# Generated at 2022-06-23 01:38:10.546200
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:38:21.471096
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect method"""

    # This test needs to be fixed to pull the version info from
    # the subclass, as it makes assumptions about the major version of
    # Python being used which will break when under Python 3.
    if sys.version_info[0] == 2:
        from ansible.module_utils.facts.collector import PythonFactCollector
        from ansible.module_utils.facts.collector import BaseFactCollector
        from ansible.module_utils.facts import cache

        fact_collector = PythonFactCollector()
        cache.FACT_CACHE = {}
        results = fact_collector.collect(module=None, collected_facts=cache.FACT_CACHE)
        assert isinstance(fact_collector, PythonFactCollector)

# Generated at 2022-06-23 01:38:23.114356
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()

    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:38:26.142096
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    a = PythonFactCollector()
    assert a.name == 'python'
    assert type(a._fact_ids) == set
    assert len(a._fact_ids) == 0

# Generated at 2022-06-23 01:38:28.268920
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert isinstance(py_fact_collector, PythonFactCollector)

# Generated at 2022-06-23 01:38:35.865447
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    # Make sure that what we received from collect has the correct
    # format
    assert 'python' in facts.keys()

    # Next populate the assert statements with what we expect to receive
    # from collect for each of the keys in the dictionary
    assert 'version' in facts['python'].keys()
    assert 'version_info' in facts['python'].keys()
    assert 'executable' in facts['python'].keys()
    assert 'type' in facts['python'].keys()
    assert 'has_sslcontext' in facts['python'].keys()

# Generated at 2022-06-23 01:38:46.003208
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create instance of class PythonFactCollector
    pfc = PythonFactCollector()

    # Check if method collect returns correct values
    output = pfc.collect()
    assert output.get('python') is not None, 'output should have python key'
    assert output['python'].get('version') is not None, 'output should have python.version key'
    assert output['python'].get('version_info') is not None, 'output should have python.version_info key'
    assert output['python'].get('executable') is not None, 'output should have python.executable key'
    assert output['python'].get('has_sslcontext') is not None, 'output should have python.has_sslcontext key'

# Generated at 2022-06-23 01:38:57.097228
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ssl


# Generated at 2022-06-23 01:39:05.625826
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect(None)
    assert python_facts['python']['version']['releaselevel'] in ('final', 'alpha', 'beta', 'candidate')
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:39:07.898559
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert isinstance(pfc.collect(), dict)
    assert isinstance(pfc.collect()['python'], dict)

# Generated at 2022-06-23 01:39:19.395442
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = None
    python_facts = PythonFactCollector().collect(module)
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_

# Generated at 2022-06-23 01:39:26.388554
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collector import collect_subset_facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    python_collector = PythonFactCollector()

    assert isinstance(python_collector, BaseFactCollector)
    assert hasattr(python_collector, "name")
    assert hasattr(python_collector, "_fact_ids")
    assert hasattr(python_collector, "collect")
    assert hasattr(python_collector, "collect")


# Generated at 2022-06-23 01:39:31.957207
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # The constructor should create an object with name 'python'
    x = PythonFactCollector()
    assert x.name == 'python'