

# Generated at 2022-06-23 01:29:36.987118
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    def mock_create_default_context_true(*args, **kwargs):
        return True
    def mock_create_default_context_false(*args, **kwargs):
        return False
    def mock_version_info(major, minor, micro, releaselevel, serial):
        return (major, minor, micro, releaselevel, serial)
    def mock_version_info_no_releaselevel(major, minor, micro, serial):
        return (major, minor, micro, serial)
    def mock_version_info_no_serial(major, minor, micro, releaselevel):
        return (major, minor, micro, releaselevel)
    def mock_subversion(subversion):
        return subversion
    class Implementation:
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-23 01:29:46.535287
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for the method PythonFactCollector.collect
    """
    pfc = PythonFactCollector()

    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': True
        }
    }

# Generated at 2022-06-23 01:29:49.103488
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:29:52.984882
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name() == 'python'
    assert fact_collector.facts == {}
    assert fact_collector.collect()
    assert isinstance(fact_collector.facts, dict)

# Generated at 2022-06-23 01:29:56.002291
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector(None)
    result = fact_collector.collect(None, None)

    assert isinstance(result, dict)

# vim: set expandtab shiftwidth=4:

# Generated at 2022-06-23 01:29:58.870487
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    cll = PythonFactCollector()
    assert cll.name == 'python'
    assert cll._fact_ids == set()


# Generated at 2022-06-23 01:30:00.616587
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:30:06.988438
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    ans = pc.collect(collected_facts=dict())
    assert 'python' in ans
    assert 'type' in ans['python']
    assert 'executable' in ans['python']
    assert 'version' in ans['python']
    assert 'version_info' in ans['python']

# Generated at 2022-06-23 01:30:16.445464
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test to assure collect method returns expected dictionary when called with
    # arguments module and collected_facts
    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-23 01:30:22.985642
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert python_fact_collector.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 13, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 13, 'final', 0], 'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT, 'type': 'CPython'}}

# Generated at 2022-06-23 01:30:26.450077
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test of method collect of class PythonFactCollector.
    """
    python_fact_collector = PythonFactCollector()

    # Test with correct data.
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']

# Generated at 2022-06-23 01:30:29.480102
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    fac

# Generated at 2022-06-23 01:30:32.019039
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc.name == 'python'
    assert py_fc._fact_ids is not None
    assert len(py_fc._fact_ids) == 0

# Generated at 2022-06-23 01:30:35.206608
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    fact_collector = PythonFactCollector()

    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:30:37.784715
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p.platform == 'all'
    assert p._fact_ids == set()

# Generated at 2022-06-23 01:30:51.249834
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_col = PythonFactCollector()
    py_facts = py_col.collect()
    # Verify that the type of python is correctly returned
    print(f"{dict.__name__} {py_facts['python']}")
    assert py_facts['python']['type'] == 'CPython', \
        f"Test {py_col.collect.__name__} fail: type is not CPython but it is " \
        f"{py_facts['python']['type']}"
    # Verify that sslcontext is correctly detected to be available or not
    # based on the Python version

# Generated at 2022-06-23 01:30:53.700519
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect()

# Generated at 2022-06-23 01:31:02.046103
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Test for method collect of class PythonFactCollector.
    '''
    python_facts = PythonFactCollector()

    # Check output of collect() method
    collected_facts = python_facts.collect()
    assert collected_facts != {}
    assert collected_facts['python']['type'] == 'cpython'
    assert collected_facts['python']['version'] == {
        'releaselevel': 'final',
        'micro': 0,
        'serial': 0,
        'minor': 7,
        'major': 2
    }

# Generated at 2022-06-23 01:31:03.749899
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect()

# Generated at 2022-06-23 01:31:15.790437
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    python_fact_collector = PythonFactCollector(module)

    collected_facts = {}
    python_facts = python_fact_collector.collect(module=module, collected_facts=collected_facts)
    assert python_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:31:25.428441
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    c = PythonFactCollector()
    results = c.collect()
    assert results['python']['version']['major'] == sys.version_info[0]
    assert results['python']['version']['minor'] == sys.version_info[1]
    assert results['python']['version']['micro'] == sys.version_info[2]
    assert results['python']['version']['releaselevel'] == sys.version_info[3]
    assert results['python']['version']['serial'] == sys.version_info[4]
    assert type(results['python']['version_info']) == type(sys.version_info)
    assert results['python']['version_info'] == list(sys.version_info)
    assert results['python']['executable'] == sys

# Generated at 2022-06-23 01:31:27.182042
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert 'python' in x._fact_ids

# Generated at 2022-06-23 01:31:36.329806
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # arrange
    spec_module = None
    spec_collected_facts = None

    # act
    python_module = PythonFactCollector()
    spec_result = python_module.collect(spec_module, spec_collected_facts)

    # assert
    assert isinstance(spec_result, dict)
    assert 'python' in spec_result
    assert isinstance(spec_result['python'], dict)
    assert isinstance(spec_result['python']['version'], dict)
    assert isinstance(spec_result['python']['version_info'], list)
    assert isinstance(spec_result['python']['executable'], str)

# Generated at 2022-06-23 01:31:38.578264
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert len(pfc._fact_ids) == 0


# Generated at 2022-06-23 01:31:39.788779
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:31:42.459530
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert py_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:31:44.122971
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f.name == 'python'


# Unit tests for function collect

# Generated at 2022-06-23 01:31:45.825135
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert not python_collector._fact_ids

# Generated at 2022-06-23 01:31:50.161015
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, PythonFactCollector)

# Generated at 2022-06-23 01:31:59.189220
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test the return value of collect method of class PythonFactCollector
    """
    collector = PythonFactCollector()
    facts = collector.collect()

    assert facts.get('python')

    python_facts = facts['python']

    assert python_facts.get('version')
    assert python_facts.get('version_info')
    assert python_facts.get('executable')

    version = python_facts['version']
    assert version.get('major')
    assert version.get('minor')
    assert version.get('micro')
    assert version.get('releaselevel')
    assert version.get('serial')

    assert version['major'] == sys.version_info[0]
    assert version['minor'] == sys.version_info[1]
    assert version['micro'] == sys.version_info[2]

# Generated at 2022-06-23 01:32:03.569015
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # TODO: Write unit test for method collect of class PythonFactCollector.
    # TODO: It should not be declared in this file, but in tests/unit/collector/platform/test_PythonFactCollector.py.
    # TODO: The class and the function are prefix by test_ only to let them appear in the right order in the documentation.
    pass


# Generated at 2022-06-23 01:32:06.845424
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert isinstance(python, BaseFactCollector)
    assert python.name == 'python'
    assert python.collect()

# Generated at 2022-06-23 01:32:18.102088
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_facts_collector = PythonFactCollector()
    python_facts = python_facts_collector.collect()

    # This is a list of tuples of expected facts and their values.
    expected_facts = [
        ('executable', sys.executable),
        ('has_sslcontext', HAS_SSLCONTEXT),
        ('type', None),
        ('version', {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        }),
        ('version_info', list(sys.version_info))
    ]

    # Check if the values of the collected Python facts are the same as the
   

# Generated at 2022-06-23 01:32:20.085256
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()
    assert pyfc.name == 'python'

# Generated at 2022-06-23 01:32:22.934851
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'
    assert python._fact_ids == set()


# Generated at 2022-06-23 01:32:25.106978
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fc = PythonFactCollector()
    assert python_fc.name == 'python'
    assert python_fc._fact_ids == set()


# Generated at 2022-06-23 01:32:28.256597
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:32:30.583205
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py = PythonFactCollector()
    assert py.name == 'python'
    assert py._fact_ids == set()


# Generated at 2022-06-23 01:32:33.630842
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert hasattr(PythonFactCollector(), 'collect')


# Generated at 2022-06-23 01:32:40.617781
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector(None, None)
    assert py_fact_collector.collect() == {'python': {'version': {'major': 2,
                                                                  'minor': 7,
                                                                  'micro': 12,
                                                                  'releaselevel': 'final',
                                                                  'serial': 0},
                                                     'version_info': [2, 7, 12, 'final', 0],
                                                     'executable': '/usr/bin/python',
                                                     'type': 'CPython',
                                                     'has_sslcontext': True}}

# Generated at 2022-06-23 01:32:43.226704
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:32:52.109285
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_collector_cache

    # Clear the cache so we can check for newly added facts
    ansible_collector_cache.clear()

    # Add the PythonFactCollector to the set of collectors
    ansible_collector.add_collector(PythonFactCollector())

    res = ansible_collector.collect(module=None, collected_facts=dict())

    assert 'python' in res, 'Python facts are missing'
    assert 'version' in res['python'], 'Version facts are missing'
    assert 'version_info' in res['python'], 'Version_info facts are missing'
    assert 'executable' in res['python'], 'Executable facts are missing'
    assert 'has_sslcontext'

# Generated at 2022-06-23 01:32:55.937120
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py = PythonFactCollector()
    module_mock = {}
    collected_facts_mock = {}
    facts = py.collect(module_mock, collected_facts_mock)
    assert facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:33:00.119287
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = {}
    collector.collect(module=None, collected_facts=collected_facts)
    # Check if the method result is a dictionary
    assert(type(collected_facts) is dict)


# Generated at 2022-06-23 01:33:04.278282
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    Constructor of class PythonFactCollector should set the correct values for
    name and fact_ids
    """
    pfc = PythonFactCollector()
    assert pfc.name == "python"
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:33:05.606346
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert(obj.name == 'python')

# Generated at 2022-06-23 01:33:14.659275
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Unit test for method collect of class PythonFactCollector

    # Create instance of PythonFactCollector
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()

    # Assert that version_info exist and contain correct number of items
    assert 'version_info' in python_facts['python']
    assert len(python_facts['python']['version_info']) == 5

    # Assert that executable is of type string
    assert isinstance(python_facts['python']['executable'], str)

    # Assert that has_sslcontext is of type boolean
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

    # Assert that type return expected value
    assert python_facts['python']['type'] in ['CPython', 'PyPy']

# Generated at 2022-06-23 01:33:17.627374
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python', \
        'The name of the PythonFactCollector is incorrect.'

# Generated at 2022-06-23 01:33:22.572438
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collector import FactCollector
    fact_collector = FactCollector(module=None, collected_facts=None)
    python_collector = PythonFactCollector(fact_collector)

    assert python_collector.name == 'python'

# Generated at 2022-06-23 01:33:26.200741
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    python_facts = python_fact_collector.collect(collected_facts=collected_facts)
    assert 'python' in python_facts

# Generated at 2022-06-23 01:33:29.180340
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts = {}
    python_fact_collector = PythonFactCollector(facts)
    assert python_fact_collector.facts == facts

# Generated at 2022-06-23 01:33:38.003460
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    def mock_sys_version_info(self, module=None, collected_facts=None):
        return [3,5,1,'final',27]

    def mock_sys_subversion(self):
        return ['CPython', 'tags/v3.5.1:2', 'c765ac49ce51']

    collector = PythonFactCollector()
    collector.collect()

# Generated at 2022-06-23 01:33:44.988209
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector

    # Initialize FactCollector instance
    fact_collector = FactCollector()
    fact_collector.collector_classes['python'] = PythonFactCollector()

    collected_facts = fact_collector.collect(module=None)

    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'type' in collected_facts['python']

# Generated at 2022-06-23 01:33:49.195838
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, PythonFactCollector)
    assert python_fact_collector._fact_ids == set()
    assert python_fact_collector.name == 'python'
    assert isinstance(python_fact_collector.collect(), dict)


# Generated at 2022-06-23 01:33:51.405551
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert isinstance(collector, PythonFactCollector)


# Generated at 2022-06-23 01:33:54.459465
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert py_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:33:59.512573
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    c = Collector()
    c.add_fact_collector(PythonFactCollector())
    d = c.collect(module=None, collected_facts={})
    # This dictionary should always have these keys and values
    assert all(key in d['python'] for key in ('version', 'version_info', 'executable', 'has_sslcontext'))

# Generated at 2022-06-23 01:34:08.341076
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector

    python_fact = collector.collector_fact_classes['python']()

    fact_data = python_fact.collect()

    assert fact_data is not None
    assert type(fact_data) is dict
    assert 'python' in fact_data.keys()
    assert type(fact_data['python']) is dict
    assert 'type' in fact_data['python'].keys()
    assert type(fact_data['python']['type']) is str
    assert 'version' in fact_data['python'].keys()
    assert type(fact_data['python']['version']) is dict
    assert 'major' in fact_data['python']['version'].keys()
    assert type(fact_data['python']['version']['major']) is int

# Generated at 2022-06-23 01:34:10.215017
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj.options == {}

# Generated at 2022-06-23 01:34:14.175665
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    output = PythonFactCollector().collect()
    assert 'python' in output
    assert 'version' in output['python']
    assert 'version_info' in output['python']
    assert 'executable' in output['python']

# Generated at 2022-06-23 01:34:20.284915
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize an instance of PythonFactCollector and collect facts
    fact_collector = PythonFactCollector()
    fact_collector.collect()

    # Assert fact 'python.executable' is present and is not None
    assert 'python.executable' in fact_collector.collected_facts, \
        'Failed to collect fact "python.executable"'
    assert fact_collector.collected_facts['python.executable'] is not None, \
        'Failed to collect fact "python.executable" (was None)'

# Generated at 2022-06-23 01:34:22.194524
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc.name == "python"
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:34:26.206123
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()
    assert x.collect()
    assert x.collect(collected_facts=None)

# Generated at 2022-06-23 01:34:28.371206
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, PythonFactCollector)


# Generated at 2022-06-23 01:34:30.599394
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'

# Generated at 2022-06-23 01:34:38.963865
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module  = sys.modules['__main__']
    fact_subset = ['python']
    collected_facts = {}

    pfc = PythonFactCollector(module, fact_subset, collected_facts)
    collected_facts = pfc.collect()
    assert pfc._fact_ids == set(['python'])
    assert collected_facts == {'python': {'python': {'version': {'major': 2, 'minor': 7, 'micro': 0, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 0, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True}}}

# Generated at 2022-06-23 01:34:40.961952
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    py_facts = pyfc.collect()
    assert py_facts is not None

# Generated at 2022-06-23 01:34:46.446687
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    res = pf.collect()
    assert len(res) == 1

    data = res.get('python')
    assert isinstance(data, dict)
    assert isinstance(data.get('version'), dict)
    assert isinstance(data.get('version_info'), list)
    assert isinstance(data.get('executable'), str)
    assert isinstance(data.get('has_sslcontext'), bool)
    assert data.get('type') in ['cpython', 'pypy', 'ironpython', 'jython', None]

# Generated at 2022-06-23 01:34:47.597067
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector is not None


# Generated at 2022-06-23 01:34:50.005176
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector({})
    facts = python_fact_collector.collect()
    assert facts

# Generated at 2022-06-23 01:34:50.950104
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:34:52.510700
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f.name == 'python'

# Generated at 2022-06-23 01:34:59.362118
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    results = python_fact_collector.collect()
    assert 'python' in results
    assert 'version' in results['python']
    assert 'version_info' in results['python']
    assert 'executable' in results['python']
    assert 'has_sslcontext' in results['python']
    assert 'type' in results['python']

# Generated at 2022-06-23 01:35:09.496870
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert facts['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-23 01:35:14.827458
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    assert 'python' in python_collector.collect()
    assert 'version' in python_collector.collect()['python']['version']
    assert 'executable' in python_collector.collect()['python']
    assert isinstance(python_collector.collect()['python']['version_info'], list)


# Generated at 2022-06-23 01:35:21.300757
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Return a fact dict about the python version
    """
    py_collector = PythonFactCollector()
    res = py_collector.collect()
    assert res == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 15, 'releaselevel': 'final', 'serial': 0},
                              'version_info': [2, 7, 15, 'final', 0],
                              'executable': '/usr/bin/python',
                              'type': 'CPython',
                              'has_sslcontext': True}}

# Generated at 2022-06-23 01:35:22.735092
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == "python"

# Generated at 2022-06-23 01:35:26.038710
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'


# Generated at 2022-06-23 01:35:29.012307
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert hasattr(PythonFactCollector(),'name')
    assert not hasattr(PythonFactCollector(),'_fact_ids')

# Generated at 2022-06-23 01:35:29.967279
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:35:37.210483
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Check if collect method of PythonFactCollector class returns any data"""
    from ansible.module_utils.facts.collector import get_collector_names
    for name in get_collector_names():
        if name == 'python':
            python_collector_obj = PythonFactCollector()
            python_collector_obj.collect()


# Generated at 2022-06-23 01:35:41.658791
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set(['python'])
    assert pfc._fact_subsets == {}
    assert pfc.collect()

# Generated at 2022-06-23 01:35:43.198492
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:35:44.927879
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert 'python' in facts

# Generated at 2022-06-23 01:35:49.915925
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a PythonFactCollector object
    python_fc = PythonFactCollector()

    # Create a argument dict
    argument_dict = dict()

    # Call method collect of PythonFactCollector
    fct_result = python_fc.collect(argument_dict)

    assert 'version_info' in fct_result['python']
    assert 'type' in fct_result['python']
    assert 'version' in fct_result['python']
    assert 'executable' in fct_result['python']

# Generated at 2022-06-23 01:35:54.771840
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    fact_data = collector.collect()
    assert(fact_data['python']['version']['major'] == sys.version_info[0])

# Generated at 2022-06-23 01:36:06.960591
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python

# Generated at 2022-06-23 01:36:15.438127
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_col = PythonFactCollector()
    result = py_col.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    try:
        assert result['python']['type'] == sys.subversion[0]
    except AttributeError:
        pass
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:36:19.641377
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts.keys()
    assert 'version' in python_facts['python'].keys()
    assert 'version_info' in python_facts['python'].keys()
    assert 'executable' in python_facts['python'].keys()
    assert 'type' in python_facts['python'].keys()

# Generated at 2022-06-23 01:36:30.670404
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    results = collector.collect()
    assert results['python']['version']['major'] == sys.version_info[0]
    assert results['python']['version']['minor'] == sys.version_info[1]
    assert results['python']['version']['micro'] == sys.version_info[2]
    assert results['python']['version']['releaselevel'] == sys.version_info[3]
    assert results['python']['version']['serial'] == sys.version_info[4]
    assert results['python']['version_info'] == list(sys.version_info)
    assert results['python']['executable'] == sys.executable
    assert results['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:36:35.836804
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import add_collector
    add_collector(PythonFactCollector)
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.exit_json(ansible_facts=module.collect_facts())

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 01:36:38.119003
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:36:38.542743
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:36:41.602294
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj._fact_ids, set)


# Generated at 2022-06-23 01:36:48.092585
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-23 01:36:50.522404
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfact = PythonFactCollector()
    assert pythonfact.name == "python"
    assert pythonfact._fact_ids is not None
    assert pythonfact.collect() is not None

# Generated at 2022-06-23 01:36:53.773038
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:37:03.899387
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for method collect of class PythonFactCollector
    """
    obj = PythonFactCollector()
    collected_facts = obj.collect()

    # Check if type returned is dict and the required keys exists
    assert isinstance(collected_facts, dict)
    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:37:13.662012
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts_dict = pfc.collect()
    assert facts_dict['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-23 01:37:24.488423
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    cinstance = get_collector_instance(Collector.PYTHON)
    cinstance.collect()
    assert cinstance.facts['python']['type'] == 'CPython'
    assert cinstance.facts['python']['version']['major'] == sys.version_info[0]
    assert cinstance.facts['python']['version']['minor'] == sys.version_info[1]
    assert cinstance.facts['python']['version']['micro'] == sys.version_info[2]
    assert cinstance.facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert cinstance.facts

# Generated at 2022-06-23 01:37:27.337459
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc.name == 'python'
    assert py_fc._fact_ids == set()


# Generated at 2022-06-23 01:37:29.169875
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:37:36.789173
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert type(python_facts['python']) is dict
    assert 'version' in python_facts['python'].keys()
    assert type(python_facts['python']['version']) is dict
    assert 'version_info' in python_facts['python'].keys()
    assert type(python_facts['python']['version_info']) is list
    assert 'executable' in python_facts['python'].keys()
    assert type(python_facts['python']['executable']) is str
    assert 'has_sslcontext' in python_facts['python'].keys()
    assert type(python_facts['python']['has_sslcontext']) is bool

# Generated at 2022-06-23 01:37:42.687355
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert 'python' in facts, facts
    python = facts['python']
    assert 'version' in python, facts
    assert 'executable' in python, facts
    assert python['has_sslcontext'] == HAS_SSLCONTEXT, facts

# Generated at 2022-06-23 01:37:46.965060
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert 'python' == python_fact_collector.name
    assert 0 == len(python_fact_collector._fact_ids)


# Generated at 2022-06-23 01:37:50.057120
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'

# Generated at 2022-06-23 01:38:00.526740
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:38:02.137336
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:38:12.847851
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    collected_facts = {}
    module = None
    python_facts = pfc.collect(module, collected_facts)
    assert "python" in python_facts
    python = python_facts["python"]
    assert "version" in python
    assert "version_info" in python
    assert "executable" in python
    assert "has_sslcontext" in python
    assert "type" in python
    assert "version" in python
    # Check some version fields
    version = python["version"]
    assert "major" in version
    assert "minor" in version
    assert "micro" in version
    assert "releaselevel" in version
    assert "serial" in version

# Generated at 2022-06-23 01:38:14.855006
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc.priority == 20
    assert pfc._fact_ids == set(['python'])


# Generated at 2022-06-23 01:38:18.870738
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    Unit test for constructor of class PythonFactCollector
    """
    collector_obj = PythonFactCollector()
    assert collector_obj.name == 'python'
    assert collector_obj._fact_ids == set()


# Generated at 2022-06-23 01:38:24.155344
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test for constructor of class PythonFactCollector
    py_fact_collector = PythonFactCollector()

    # Check name of class
    assert py_fact_collector.name == 'python'

    # Check _fact_ids of class
    assert py_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:38:25.704766
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_test = PythonFactCollector()
    assert python_fact_test

# Generated at 2022-06-23 01:38:28.000818
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    # Just check we have a version
    assert(len(python_facts['python']['version']) > 0)

# Generated at 2022-06-23 01:38:35.148887
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    attr_to_check = [
        'version',
        'version_info',
        'executable',
        'has_sslcontext',
    ]
    for attr in attr_to_check:
        assert attr in facts['python'].keys()
        assert facts['python'][attr] is not None



# Generated at 2022-06-23 01:38:46.725725
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python = PythonFactCollector()
    result = python.collect()
    assert isinstance(result, dict)
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:38:48.882008
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pc = PythonFactCollector()
    assert pc.name == "python"
    assert pc._fact_ids == set()


# Generated at 2022-06-23 01:38:50.757784
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:39:01.495225
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, BaseFactCollector)
    # test __str__
    if sys.version_info[0] >= 3:
        assert str(obj) == "PythonFactCollector"
    else:
        assert str(obj) == "PythonFactCollector"
    assert repr(obj) == "<PythonFactCollector: python>"
    # test the name, the fact_ids, and the _fact_ids
    assert obj.name == "python"
    assert obj.fact_ids == set()
    assert obj._fact_ids == set()
    # test the collect method
    ret = obj.collect()
    assert isinstance(ret, dict)
    assert "python" in ret
    assert "version" in ret["python"]
    assert "major" in ret["python"]["version"]

# Generated at 2022-06-23 01:39:11.273307
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_obj = PythonFactCollector(None)
    result = test_obj.collect()
    assert result.has_key('python')
    assert len(result['python'].keys()) == 5
    assert result['python']['version_info'][0] == sys.version_info[0]
    assert result['python']['version_info'][1] == sys.version_info[1]
    assert result['python']['version_info'][2] == sys.version_info[2]
    assert result['python']['version_info'][3] == sys.version_info[3]
    assert result['python']['version_info'][4] == sys.version_info[4]
    assert result['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:39:15.339442
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()
    assert python_fact_collector.collect() is not None


# Generated at 2022-06-23 01:39:17.335168
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids is not None

# Generated at 2022-06-23 01:39:19.600426
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector(None)
    assert collector.name == 'python'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:39:22.836581
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert not python_fact_collector._fact_ids
    assert python_fact_collector.name == 'python'



# Generated at 2022-06-23 01:39:24.206343
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    xx = PythonFactCollector()
    assert xx.collect() is not None

# Generated at 2022-06-23 01:39:26.841775
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc.name == 'python'

# Generated at 2022-06-23 01:39:30.077142
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert python_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:39:37.449734
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a mocked module
    module = type('module', (object,), {})()

    # Create a mocked facts
    collected_facts = type('collected_facts', (object,), {})()

    # Create an instance of PythonFactCollector
    pfc = PythonFactCollector()

    # Create the return value of method collect of class PythonFactCollector
    python_facts = type('python_facts', (object,), {})()

    # Store the python_facts atribute of python_facts
    python_facts.python = type('python', (object,), {})()

    # Store the version atribute of python_facts.python
    python_facts.python.version = type('version', (object,), {})()

    # Store the major atribute of python_facts.python.version
    python_facts.python.version.major