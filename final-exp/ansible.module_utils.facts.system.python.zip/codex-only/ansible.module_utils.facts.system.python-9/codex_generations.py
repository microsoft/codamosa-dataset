

# Generated at 2022-06-23 01:29:30.631308
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:29:31.855996
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc.name == 'python'

# Generated at 2022-06-23 01:29:34.946732
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    my_collect_result = fc.collect()

    assert my_collect_result['python']
    assert my_collect_result['python']['version']
    assert my_collect_result['python']['type']
    assert my_collect_result['python']['executable']



# Generated at 2022-06-23 01:29:40.502817
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:29:45.963289
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import ansible.module_utils.facts.collector

    python_facts = PythonFactCollector.collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert isinstance(python_facts['python'], dict)
    assert len(python_facts['python']) == 5



# Generated at 2022-06-23 01:29:47.871517
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert (python_collector.name == "python")

# Generated at 2022-06-23 01:29:49.616083
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    result = py_fc.collect()
    assert 'python' in result, 'result is not correct'

# Generated at 2022-06-23 01:29:59.033102
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    py_collector.collect()

    assert py_collector.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': py_collector.collect()['python']['type']
        }
    }

# Generated at 2022-06-23 01:30:02.790910
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # create an instance of the PythonFactCollector class
    pfc = PythonFactCollector()
    # check if the name attribute is set correctly
    assert pfc.name == 'python'
    # check if the _fact_ids attribute is set correctly
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:30:12.299302
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert 'python' in facts
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext']

# Generated at 2022-06-23 01:30:15.770413
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector_obj = PythonFactCollector()
    assert py_collector_obj.name == 'python'
    assert isinstance(py_collector_obj._fact_ids, set)

# Generated at 2022-06-23 01:30:18.860010
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:30:24.985490
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts import collector

    if 'python' not in collector.collectors:
        raise Exception('Failed to load the Python fact collector')

    test_collector = collector.collectors['python']

    if test_collector.name != 'python':
        raise Exception('Invalid name for the Python fact collector')

    if test_collector._fact_ids != set(['python']):
        raise Exception('Invalid fact ids for the Python fact collector')

# Generated at 2022-06-23 01:30:27.818519
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test constructor and name of class PythonFactCollector
    """
    pydc = PythonFactCollector()

    assert isinstance(pydc.name, str)
    assert pydc.name == 'python'


# Generated at 2022-06-23 01:30:31.550681
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p.collector == 'python'
    assert p.collected_facts == {}
    assert p._fact_ids == set()

# Generated at 2022-06-23 01:30:39.134895
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fake_module = dict()
    python_facts = PythonFactCollector().collect(module=fake_module)
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert 'type' in python_facts['python']

# Generated at 2022-06-23 01:30:41.139044
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set(['python'])

# Generated at 2022-06-23 01:30:43.556332
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()
    assert len(x.collect()) == 1

# Generated at 2022-06-23 01:30:53.449035
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    col = PythonFactCollector('fake')
    result = col.collect()

    assert type(result) is dict
    assert type(result['python']) is dict
    assert type(result['python']['version']) is dict
    assert type(result['python']['version_info']) is list
    assert type(result['python']['executable']) is str
    assert type(result['python']['has_sslcontext']) is bool

    if 'subversion' in dir(sys):
        assert type(result['python']['type']) is str
    else:
        assert result['python']['type'] is None

# Generated at 2022-06-23 01:31:00.674974
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfact_collector_instance = PythonFactCollector()
    assert isinstance(pythonfact_collector_instance, PythonFactCollector)
    assert pythonfact_collector_instance.name == 'python'
    assert isinstance(pythonfact_collector_instance._fact_ids, set)
    assert 'python' in pythonfact_collector_instance._fact_ids
    assert 'ansible_python' not in pythonfact_collector_instance._fact_ids

# Generated at 2022-06-23 01:31:02.816201
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfact = PythonFactCollector(module=None, collected_facts=None)
    pythonfact.collect()
    assert pythonfact.name == 'python'

# Generated at 2022-06-23 01:31:06.438446
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Unit test for getting python facts

    c = PythonFactCollector()
    results = c.collect()
    assert 'python' in results
    assert 'version' in results['python']
    assert 'version_info' in results['python']
    assert 'executable' in results['python']

# Generated at 2022-06-23 01:31:09.188783
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()

    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:31:13.073092
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a instance of class PythonFactCollector
    python_fact_collector = PythonFactCollector()
    # Test if the return value of method
    # collect is a dict
    assert isinstance(python_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:31:15.240563
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:31:22.849822
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    python_facts = fact_collector.get_facts()
    assert python_facts['ansible_facts']['python']['executable'] == sys.executable
    assert python_facts['ansible_facts']['python']['type'] == sys.implementation.name
    assert python_facts['ansible_facts']['python']['version']['major'] == sys.version_info[0]
    assert python_facts['ansible_facts']['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['ansible_facts']['python']['version']['minor'] == sys.version_info[1]

# Generated at 2022-06-23 01:31:29.124223
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)

    assert isinstance(python_facts['python']['version_info'], list)
    assert all(isinstance(v, int) for v in python_facts['python']['version_info'])

    assert isinstance(python_facts['python']['executable'], str)



# Generated at 2022-06-23 01:31:33.298848
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:31:43.234119
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    # Test if the fact collector can be used to collect facts.
    facts = fact_collector.collect()
    # Test if the version information is returned as expected.
    assert facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    # Test if the version tuple is returned as a list.
    assert facts['python']['version_info'] == list(sys.version_info)
    # Test if the python executable name is returned as expected.
    assert facts['python']['executable'] == sys.exec

# Generated at 2022-06-23 01:31:46.528090
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''
    Unit tests for PythonFactCollector
    '''

    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert not python_fact_collector._fact_ids

# Generated at 2022-06-23 01:31:56.969037
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""
    pfc = PythonFactCollector()

    # Check major.minor.micro.releaselevel.serial
    assert pfc.collect()['python']['version']['major'] == sys.version_info[0]
    assert pfc.collect()['python']['version']['minor'] == sys.version_info[1]
    assert pfc.collect()['python']['version']['micro'] == sys.version_info[2]
    assert pfc.collect()['python']['version']['releaselevel'] == sys.version_info[3]
    assert pfc.collect()['python']['version']['serial'] == sys.version_info[4]

    # Check version_info

# Generated at 2022-06-23 01:31:59.131111
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    my_fact_collector = PythonFactCollector()
    result = my_fact_collector.collect()
    assert result.get('python', None) is not None

# Generated at 2022-06-23 01:32:06.253287
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts

    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    # not sure exact version of python that sets this, but just make sure it's there for now
    assert 'type' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:32:09.003554
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == "python"
    assert "python" in collector._fact_class_names

# Generated at 2022-06-23 01:32:12.767614
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfact_collector = PythonFactCollector()
    collected_facts = {}
    pyfacts = pyfact_collector.collect(collected_facts=collected_facts)
    assert 'python' in pyfacts, "Failed to collect Python facts"

# Generated at 2022-06-23 01:32:19.690315
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info.major,
                'minor': sys.version_info.minor,
                'micro': sys.version_info.micro,
                'releaselevel': sys.version_info.releaselevel,
                'serial': sys.version_info.serial
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
        }
    }

    # get python type
    try:
        python_facts['python']['type'] = sys.implementation.name
    except AttributeError:
        python_facts['python']['type'] = None

    test_collector = PythonFactCollector()



# Generated at 2022-06-23 01:32:29.258578
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors.python import PythonFactCollector
    import sys
    ansible_facts = {}
    result = PythonFactCollector.collect(ansible_facts)
    python_version = sys.version_info
    assert result['python']['version']['major'] == python_version[0]
    assert result['python']['version']['minor'] == python_version[1]
    assert result['python']['version']['micro'] == python_version[2]
    assert 'has_sslcontext' in result['python']['version']
    assert 'executable' in result['python']['version']

if __name__ == "__main__":
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:32:30.370716
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    result = pyt

# Generated at 2022-06-23 01:32:31.694173
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == "python"
    assert "python" in pfc._fact_ids



# Generated at 2022-06-23 01:32:40.729472
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert isinstance(python_facts, dict), '''Facts returned from method collect
    of class PythonFactCollector should be a dict'''

    assert 'python' in python_facts, '''Facts returned from method collect of
    class PythonFactCollector should contain a key "python" '''

    python_sub_facts = python_facts['python']

    assert isinstance(python_sub_facts, dict)
    assert 'version_info' in python_sub_facts
    assert isinstance(python_sub_facts['version_info'], list)

    assert 'version' in python_sub_facts
    version = python_sub_facts['version']
    assert isinstance(version, dict)

    assert 'major' in version
    assert isinstance(version['major'], int)



# Generated at 2022-06-23 01:32:45.528939
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect

    :return:
        """
    # Test generic function without arguments
    python_collector = PythonFactCollector()
    python_facts     = python_collector.collect()

    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:32:46.936447
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set([])

# Generated at 2022-06-23 01:32:48.485581
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_coll = PythonFactCollector()
    assert py_coll.name == 'python'
    assert py_coll._fact_ids == set()

# Generated at 2022-06-23 01:32:50.658855
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_obj = PythonFactCollector()
    test_obj.collect()

# Generated at 2022-06-23 01:32:52.800358
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert python_facts._fact_ids == set()

# Generated at 2022-06-23 01:33:00.570572
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    my_python_facts = pfc.collect()

    assert(my_python_facts['python']['version']['major'] == sys.version_info[0])
    assert(my_python_facts['python']['version']['minor'] == sys.version_info[1])
    assert(my_python_facts['python']['version']['micro'] == sys.version_info[2])
    assert(my_python_facts['python']['version']['releaselevel'] == sys.version_info[3])
    assert(my_python_facts['python']['version']['serial'] == sys.version_info[4])
    assert(my_python_facts['python']['version_info'] == list(sys.version_info))

# Generated at 2022-06-23 01:33:09.868115
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'type': None,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    facts = PythonFactCollector().collect()

    assert facts['python'] == python_facts['python'], "Failed to collect python facts"

# Generated at 2022-06-23 01:33:14.572535
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    collected_facts = {}
    c.collect(collected_facts=collected_facts)
    assert collected_facts["python"]

# Generated at 2022-06-23 01:33:23.310907
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Case 1: Python type is Jython
    class PythonFactCollectorMock(PythonFactCollector):
        def __init__(self):
            class Mock(object):
                version_info = (2, 7, 0, 'final', 0)
                executable = '/usr/bin/python'
                subversion = ('Jython',)

            self.sys = Mock()

    c = PythonFactCollectorMock()
    facts = c.collect()

    assert facts['python']['type'] == 'Jython'
    assert facts['python']['version'] == {
        'major': 2, 'minor': 7, 'micro': 0,
        'releaselevel': 'final', 'serial': 0
    }
    assert facts['python']['version_info'] == [2, 7, 0, 'final', 0]

# Generated at 2022-06-23 01:33:27.887238
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']

# Generated at 2022-06-23 01:33:36.346323
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import sys
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()
    assert c.collect()['python']['version']['major'] is sys.version_info[0]
    assert c.collect()['python']['version']['minor'] is sys.version_info[1]
    assert c.collect()['python']['version']['micro'] is sys.version_info[2]
    assert c.collect()['python']['version']['releaselevel'] is sys.version_info[3]
    assert c.collect()['python']['version']['serial'] is sys.version_info[4]
    assert c.collect()['python']['version_info'] is list(sys.version_info)
    assert c

# Generated at 2022-06-23 01:33:38.547251
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector(None)
    assert fact_collector.name == 'python'


# Generated at 2022-06-23 01:33:47.135099
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:33:52.537267
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test PythonFactCollector.collect method
    """
    # Test no module or collected_facts
    assert {} == PythonFactCollector.collect()

    # Test with a fake module
    assert {'python': {'executable': 'test_executable',
                       'has_sslcontext': True,
                       'type': 'test_type',
                       'version': {'major': 10,
                                   'minor': 8,
                                   'micro': 3,
                                   'releaselevel': 'alpha',
                                   'serial': 4},
                       'version_info': [10, 8, 3, 'alpha', 4]}} == PythonFactCollector.collect(module={'executable': 'test_executable',
                                                                                                  'subversion': ['test_type', 'random']})


# Generated at 2022-06-23 01:33:53.912928
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-23 01:33:57.538325
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    my_obj = PythonFactCollector()
    my_obj.collect()
    assert my_obj.name == 'python'
    assert my_obj._fact_ids == set()

# Generated at 2022-06-23 01:34:04.907638
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector(None)
    facts = python_fact_collector.collect(None, None)
    assert facts == {'python': {'version': {'micro': 6, 'releaselevel': 'final', 'major': 2, 'serial': 0, 'minor': 7}, 'type': 'CPython', 'version_info': [2, 7, 6, 'final', 0], 'executable': '/home/anita/miniconda3/envs/default/bin/python', 'has_sslcontext': True}}

# Generated at 2022-06-23 01:34:09.546445
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert len(python_facts['python']['version_info']) == 5
    assert python_facts['python']['type'] == 'CPython'
    assert python_facts['python']['has_sslcontext'] is True

# Generated at 2022-06-23 01:34:18.204785
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    x = PythonFactCollector()
    assert x.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-23 01:34:26.998470
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector(None, None)
    python_facts = python_fact_collector.collect(None, None)
    version_required = sys.version_info[0] >= 2 and sys.version_info[1] >= 6

    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]

# Generated at 2022-06-23 01:34:38.008847
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    # Test with required python version
    if sys.version_info[0] < 3:
        python_facts = pfc.collect()
        assert python_facts['python']
        assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
        assert python_facts['python']['type']
        assert python_facts['python']['version']
        assert python_facts['python']['version_info']

    # Test with required python version
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert python_facts['python']
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert python_facts['python']['type']

# Generated at 2022-06-23 01:34:43.662473
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect(None)

    # check if returned values are not None
    if facts['python'] is None:
        raise AssertionError("Returned 'python' dict is None.")

    for key in ['version', 'version_info', 'executable']:
        if facts['python'][key] is None:
            raise AssertionError("Returned 'python' dict contains None value for key: %s." % key)

# Generated at 2022-06-23 01:34:51.591221
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = {}
    fact_collector = PythonFactCollector()

    facts = fact_collector.collect(collected_facts=collected_facts)

    assert facts is not None
    assert 'python' in facts

    # Check some facts...
    python_facts = facts['python']

    # Check version
    assert 'version' in python_facts
    assert isinstance(python_facts['version'], dict)
    assert 'major' in python_facts['version']
    assert isinstance(python_facts['version']['major'], int)
    assert 'minor' in python_facts['version']
    assert isinstance(python_facts['version']['minor'], int)
    assert 'micro' in python_facts['version']
    assert isinstance(python_facts['version']['micro'], int)

# Generated at 2022-06-23 01:35:02.482589
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    result = py_fact_collector.collect()
    assert result is not None
    assert result == {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
            'version': {'major': sys.version_info[0],
                        'minor': sys.version_info[1],
                        'micro': sys.version_info[2],
                        'releaselevel': sys.version_info[3],
                        'serial': sys.version_info[4]},
            'version_info': list(sys.version_info)
        }
    }

# Generated at 2022-06-23 01:35:06.302028
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert hasattr(obj, 'collect')
    assert callable(getattr(obj, 'collect'))
    assert obj.FACTS_CACHE == '_python_facts'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:35:14.930737
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Method: collect

    1. Return empty dict if python is not found.
    2. Return python facts if python is found.
    """
    # Import module to test
    from ansible.module_utils.facts import collector

    # Test with python not found
    collector.python_found = False
    pf = collector.PythonFactCollector()
    assert {} == pf.collect()

    # Test with python found
    collector.python_found = True
    pf = collector.PythonFactCollector()
    assert pf.collect()


# Generated at 2022-06-23 01:35:22.984933
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector({})
    py_facts = pc.collect()
    assert py_facts == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': None}
    }

# Generated at 2022-06-23 01:35:24.741939
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert not pfc._fact_ids

# Generated at 2022-06-23 01:35:33.041133
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test the method collect of class PythonFactCollector with the following data:

    - Check the return value of the collect method with collected_facts is None,
      stack trace is None, and module is None.

    - Check the return value of the collect method with collected_facts is not None,
      stack trace is None, and module is None.

    - Check the return value of the collect method with collected_facts is None,
      stack trace is not None, and module is None.

    - Check the return value of the collect method with collected_facts is not None,
      stack trace is not None, and module is None.
    """
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']['version_info'][0] >= 2


# Generated at 2022-06-23 01:35:34.872060
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:35:43.048176
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    import sys
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    # Check if facts are generated for the 'python' key
    python_facts = facts['python']
    assert python_facts is not None

    # Check if the 'type' key is populated with expected value
    python_type = python_facts['type']
    if sys.platform.startswith('java'):
        assert python_type == 'Jython'
    elif sys.platform == 'cli':
        assert python_type == 'IronPython'
    elif platform.python_implementation() == 'PyPy':
        assert python_type == 'PyPy'
    else:
        assert python_type == 'CPython'

    # Check if the 'version' key is populated with expected values
    version_info

# Generated at 2022-06-23 01:35:44.465112
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts = PythonFactCollector()
    assert facts.name == 'python'
    assert 'python' in facts.collect()

# Generated at 2022-06-23 01:35:48.911213
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Instantiate the class 
    c = PythonFactCollector()

    # Check the name attribute
    assert c.name == 'python'

    # Check the fact_ids class attribute
    assert isinstance(type(c)._fact_ids, set)
    assert type(c)._fact_ids == set()


# Generated at 2022-06-23 01:35:49.781886
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:35:59.842068
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Setup - initialize Python fact collector
    fact_collector = PythonFactCollector()
    # Test - collect facts
    facts = fact_collector.collect()
    # Verify - make sure 'python' key and 'version' key are present
    assert 'python' in facts and 'version' in facts['python']
    # Verify - make sure 'version_info' key is present
    assert isinstance(facts['python']['version_info'], list)
    # Verify - make sure 'version' key is present
    assert 'version' in facts['python']
    # Verify - make sure 'major' key is present
    assert 'major' in facts['python']['version']
    # Verify - make sure 'minor' key is present
    assert 'minor' in facts['python']['version']
    # Verify - make sure 'micro'

# Generated at 2022-06-23 01:36:09.387627
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import sys
    import inspect
    import sys
    import unittest
    import ansible.module_utils.facts.collector

    class TestPythonFactCollector(unittest.TestCase):
        def setUp(self):
            self.test_object = ansible.module_utils.facts.collector.PythonFactCollector()

        # Checks __init__ constructor
        def test__init__(self):
            self.assertTrue(hasattr(self.test_object, 'name'))
            self.assertIsInstance(self.test_object.name, str)
            self.assertEqual(self.test_object.name, 'python')

            self.assertTrue(hasattr(self.test_object, '_fact_ids'))
            self.assertIsInstance(self.test_object._fact_ids, set)


# Generated at 2022-06-23 01:36:13.677337
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    # Test if class PythonFactCollector is subclass of BaseFactCollector
    assert issubclass(python_collector.__class__, BaseFactCollector)
    # Test if method collect returns a dictionary
    assert isinstance(python_collector.collect(), dict)


# Generated at 2022-06-23 01:36:23.207322
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts_collector = PythonFactCollector()
    collected_facts = python_facts_collector.collect(collected_facts={})

    import platform
    import sys

    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]
    assert collected_facts['python']['version_info'] == list(sys.version_info)


# Generated at 2022-06-23 01:36:27.855941
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fake_module = type('module', (object,), {})

    result = PythonFactCollector.collect(fake_module)
    assert (result['python']['type'] != None)
    assert (result['python']['type'] == 'CPython')

# Generated at 2022-06-23 01:36:30.618377
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # We should be able to create an instance of the PythonFactCollector class
    fact_collector = PythonFactCollector()
    assert fact_collector is not None


# Generated at 2022-06-23 01:36:32.794068
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-23 01:36:39.604635
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect() method."""
    # Given a PythonFactCollector object
    py = PythonFactCollector()
    # When calling its collect method
    py_facts = py.collect()
    # Then the dictionary has the python fact and the version fact
    assert "python" in py_facts
    assert "version" in py_facts["python"]
    assert "type" in py_facts["python"]
    # And the version fact has the five standard elements
    for field in ("major", "minor", "micro", "releaselevel", "serial"):
        assert field in py_facts["python"]["version"]
    # And the type field is either the subversion or implementation name
    assert py_facts["python"]["type"] in ("CPython", "PyPy")

# Generated at 2022-06-23 01:36:49.808808
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    from ansible.module_utils.facts.collector.python import PythonFactCollector
    from ansible.module_utils._text import to_text
    # The value of sys.executable can be a str or bytes
    if not isinstance(sys.executable, str):
        executable = to_text(sys.executable, errors='surrogate_or_strict')
    else:
        executable = sys.executable

# Generated at 2022-06-23 01:36:53.320426
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert len(facts['python']['version_info']) == 5
    assert facts['python']['type'] == 'CPython'

# Generated at 2022-06-23 01:36:55.840684
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == "python"
    assert set() == pfc._fact_ids


# Generated at 2022-06-23 01:37:05.287688
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a python fact collector
    python_fact_collector = PythonFactCollector()

    # Collect facts
    collected_facts = python_fact_collector.collect()

    assert collected_facts != []
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert 'type' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'major' in collected_facts['python']['version']
    assert 'minor' in collected_facts['python']['version']
    assert 'micro' in collected_facts['python']['version']
    assert 'releaselevel' in collected_facts['python']['version']

# Generated at 2022-06-23 01:37:14.150239
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    fact_result = pfc.collect()
    assert fact_result.get('python') is not None
    assert fact_result.get('python').get('version_info') is not None
    assert fact_result.get('python').get('version').get('major') == sys.version_info[0]
    assert fact_result.get('python').get('version').get('minor') == sys.version_info[1]
    assert fact_result.get('python').get('version').get('micro') == sys.version_info[2]
    assert fact_result.get('python').get('version').get('releaselevel') == sys.version_info[3]
    assert fact_result.get('python').get('version').get('serial') == sys.version_info[4]

# Generated at 2022-06-23 01:37:24.941583
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert sys.version_info[0] == 2 or sys.version_info[0] == 3

    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:37:27.789676
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_ins = PythonFactCollector()
    assert py_ins._fact_ids == set()
    assert py_ins.name == 'python'

# Generated at 2022-06-23 01:37:28.896790
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:37:36.579025
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test setup
    python_version = sys.version_info
    python_version_info = tuple(map(int, python_version.split('.')))
    python_executable = sys.executable
    python_type = sys.implementation.name
    has_sslcontext = HAS_SSLCONTEXT

    # Expected result

# Generated at 2022-06-23 01:37:38.451050
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p


# Generated at 2022-06-23 01:37:41.506657
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:37:45.971794
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test the constructor directly
    f = PythonFactCollector()

    # Test the constructor via BaseFactCollector
    parent = BaseFactCollector()
    f = PythonFactCollector(parent)

    # Test the constructor via BaseFactCollector using name keyword
    parent = BaseFactCollector()
    f = PythonFactCollector(parent, name="python")

# Generated at 2022-06-23 01:37:53.567101
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_factory
    from ansible.module_utils.facts.collection import get_collection_name
    from ansible.module_utils.facts import get_collection_factory_functions

    # update the factory functions with the new classes
    get_collection_factory_functions()

    # create the collector
    fact_class = collector_factory(get_collection_name('python'))

    # get the facts
    facts = fact_class.collect()

    assert facts is not None
    assert 'python' in facts
    assert facts['python']['type'] is not None
    assert facts['python']['version_info'][0] == 3

# Generated at 2022-06-23 01:37:54.063035
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert False, "No unit tests exist for this class"

# Generated at 2022-06-23 01:38:04.269463
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector(None, None)
    facts = python_collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:38:05.594008
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert isinstance(fc, PythonFactCollector)

# Generated at 2022-06-23 01:38:15.130704
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # initialize the fact collector instance.
    fact_collector = PythonFactCollector()

    # test the output of method collect of class PythonFactCollector
    fact_collector_output = fact_collector.collect()
    # assert if the fact collector output meets the criteria
    assert 'python' in fact_collector_output
    assert 'version' in fact_collector_output['python']
    assert 'version_info' in fact_collector_output['python']
    assert 'executable' in fact_collector_output['python']
    assert 'has_sslcontext' in fact_collector_output['python']
    assert 'type' in fact_collector_output['python']
    assert 'major' in fact_collector_output['python']['version']

# Generated at 2022-06-23 01:38:21.370121
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert any(['python' in k for k in facts])
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']



# Generated at 2022-06-23 01:38:23.032987
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py = PythonFactCollector()
    assert py.name == 'python'
    assert py._fact_ids == set()

# Generated at 2022-06-23 01:38:33.835704
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector.collect()['python']['version']['major'] == sys.version_info[0]
    assert python_fact_collector.collect()['python']['version']['minor'] == sys.version_info[1]
    assert python_fact_collector.collect()['python']['version']['micro'] == sys.version_info[2]
    assert python_fact_collector.collect()['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_fact_collector.collect()['python']['version']['serial'] == sys.version_info[4]
    assert python_fact_collector

# Generated at 2022-06-23 01:38:41.876126
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test that we can get the python version correctly
    collector = PythonFactCollector()
    collected_facts = collector.collect()
    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]
    assert collected_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:38:45.569737
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python = PythonFactCollector()
    facts = python.collect()
    assert 'python' in facts
    assert facts['python']
    assert 'type' in facts['python']
    assert 'version' in facts['python']
    assert 'executable' in facts['python']

# Generated at 2022-06-23 01:38:51.454212
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    result = f.collect()
    assert result
    assert isinstance(result, dict)
    assert result.get('python')
    assert result['python'].get('version')
    assert result['python'].get('version_info')
    assert result['python'].get('type')
    assert result['python'].get('executable')
    assert result['python'].get('has_sslcontext') is not None

# Generated at 2022-06-23 01:39:02.065713
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Call function collect of class PythonFactCollector
    collector = PythonFactCollector()
    result = collector.collect()
    assert type(result) == dict
    assert 'python' in result
    assert type(result['python']) == dict
    assert 'version' in result['python']
    assert type(result['python']['version']) == dict
    assert 'major' in result['python']['version']
    assert type(result['python']['version']['major']) == int
    assert 'minor' in result['python']['version']
    assert type(result['python']['version']['minor']) == int
    assert 'micro' in result['python']['version']
    assert type(result['python']['version']['micro']) == int

# Generated at 2022-06-23 01:39:07.842222
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyf = PythonFactCollector()

    assert pyf._fact_ids == set()
    assert pyf.name == 'python'
    assert pyf._allowed_names is None
    assert pyf.platform == 'all'
    assert pyf.priority == 20
    assert not pyf.has_dep_info()
    assert not pyf.depends_on
    assert not pyf.dep_facts

    assert len(pyf.collect()) == 1

# Generated at 2022-06-23 01:39:10.615616
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:39:12.451861
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc is not None

# Generated at 2022-06-23 01:39:22.096285
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    python_facts = FactCollector().collect(module=None, collected_facts=None)
    assert python_facts['python']['version_info'][0] == sys.version_info[0]
    assert python_facts['python']['version_info'][1] == sys.version_info[1]
    assert python_facts['python']['version_info'][2] == sys.version_info[2]
    assert python_facts['python']['version_info'][3] == sys.version_info[3]
    assert python_facts['python']['version_info'][4] == sys.version_info[4]

# Generated at 2022-06-23 01:39:25.343855
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()
    assert pfc.collect()

# Generated at 2022-06-23 01:39:27.878990
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # This class won't throw an Exception
    PythonFactCollector()