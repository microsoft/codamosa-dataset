

# Generated at 2022-06-23 01:29:30.776160
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    assert isinstance(fact_collector.collect()['python'], dict)

# Generated at 2022-06-23 01:29:37.111864
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result = collector.collect()
    version = result.get('python', {}).get('version', {})
    version_info = result.get('python', {}).get('version_info', [])
    executable = result.get('python', {}).get('executable', None)
    if sys.version_info < (3,):
        assert result.get('python', {}).get('type', None) == 'CPython'
        assert isinstance(version, dict)
        assert isinstance(version_info, list)
    else:
        assert result.get('python', {}).get('type', None) == 'python'
        assert isinstance(version, dict)
        assert isinstance(version_info, list)
    assert executable == sys.executable

# Generated at 2022-06-23 01:29:43.819369
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python'].has_key('version')
    assert python_facts['python'].has_key('version_info')
    assert python_facts['python'].has_key('version_info')
    assert python_facts['python'].has_key('executable')
    assert python_facts['python'].has_key('type')
    assert python_facts['python'].has_key('has_sslcontext')

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 01:29:45.575418
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'
    assert python.priority == 90

# Generated at 2022-06-23 01:29:53.631175
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    a = PythonFactCollector()
    assert a.name == 'python'
    assert a._fact_ids == set()
    assert a.collect() is not None
    assert a.collect()['python'] is not None
    assert a.collect()['python']['version'] is not None
    assert a.collect()['python']['version']['major'] is not None
    assert a.collect()['python']['version_info'] is not None
    assert a.collect()['python']['executable'] is not None
    assert a.collect()['python']['has_sslcontext'] is not None
    assert a.collect()['python']['type'] is not None

# Generated at 2022-06-23 01:29:55.818612
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == "python"
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:30:05.439890
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    from ansible.module_utils.facts.collector.python import PythonFactCollector

    python_collector = PythonFactCollector()

    python_facts = python_collector.collect()

    assert 'python' in python_facts
    assert python_facts['python']['type'] == 'CPython'
    assert python_facts['python']['version']['major'] == 2
    assert python_facts['python']['version']['minor'] == 7
    assert python_facts['python']['version']['micro'] == 9
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert python_facts['python']['version']['serial'] == 0

# Generated at 2022-06-23 01:30:07.851680
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'


# Generated at 2022-06-23 01:30:17.526867
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    # Call collect method
    returned_facts = collector.collect()

    # Verify returned_facts['python']['version']['major'] is integer
    assert isinstance(returned_facts['python']['version']['major'], int)
    # Verify returned_facts['python']['version']['minor'] is integer
    assert isinstance(returned_facts['python']['version']['minor'], int)
    # Verify returned_facts['python']['version']['micro'] is integer
    assert isinstance(returned_facts['python']['version']['micro'], int)
    # Verify returned_facts['python']['version']['releaselevel'] is string

# Generated at 2022-06-23 01:30:19.360430
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert(python_collector.name == 'python')


# Generated at 2022-06-23 01:30:21.539476
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()

    assert(obj.name == "python")
    assert(obj._fact_ids == set(["python"]))

# Generated at 2022-06-23 01:30:22.890532
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:30:31.551492
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module_name = "test_module_name"
    facts_d = {
        "test_key": "test_value"
    }
    python_facts = PythonFactCollector().collect(module_name, facts_d)
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:30:39.148596
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import copy
    import doctest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    sys.modules['ansible'] = type('AnsibleModule', (), {'version': '2.2.1'})
    BaseFactCollector.collectors[PythonFactCollector.name] = PythonFactCollector()
    collected_facts = BaseFactCollector.collect(module=None, filter_facts=None)
    sys.modules.pop('ansible')

    assert collected_facts['python']['executable'] == sys.executable
    assert collected_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert collected_facts['python']['version']['major']

# Generated at 2022-06-23 01:30:47.967506
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test all the possible return outcomes of the collect() method of the
    PythonFactCollector class
    """

    # Test the current version of the Python interpreter and all its
    # components against a known tuple returned by the sys.version_info tuple
    # (see https://docs.python.org/2/library/sys.html#sys.version_info)
    # when using Python v2.7.6

    # Test the python interpreter version
    test_major = 2
    test_minor = 7
    test_micro = 6
    test_releaselevel = 'final'
    test_serial = 0

    test_ver = (test_major, test_minor, test_micro, test_releaselevel, test_serial)
    test_ver_info = list(test_ver)

    # Test the python interpreter executable
    test_

# Generated at 2022-06-23 01:30:59.716042
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """test the PythonFactCollector's collect method"""
    collector = PythonFactCollector(None)
    facts = collector.collect()
    assert facts['python']['version_info'][0] == sys.version_info[0]
    assert facts['python']['version_info'][1] == sys.version_info[1]
    assert facts['python']['version_info'][2] == sys.version_info[2]
    assert facts['python']['version_info'][3] == sys.version_info[3]
    assert facts['python']['version_info'][4] == sys.version_info[4]
    assert facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:31:05.665498
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)
    assert isinstance(facts['python']['type'], str) or facts['python']['type'] is None



# Generated at 2022-06-23 01:31:09.140155
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:31:11.456496
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:31:17.160862
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

    x = PythonFactCollector(name='python')
    assert x.name == 'python'
    assert x._fact_ids == set()

    x = PythonFactCollector(name='python', fact_ids=['python'])
    assert x.name == 'python'
    assert x._fact_ids == set(['python'])


# Generated at 2022-06-23 01:31:19.917667
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Ensure the constructor properly calls superclass constructor
    pfc = PythonFactCollector()
    super_pfc = BaseFactCollector()
    assert pfc.name == super_pfc.name

# Generated at 2022-06-23 01:31:21.138515
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    x = PythonFactCollector()
    x.collect()

# Generated at 2022-06-23 01:31:25.247105
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert 'python' in facts
    assert 'python' in facts['python']
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-23 01:31:30.102750
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test PythonFactCollector class constructor"""
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert isinstance(python_fact_collector._fact_ids, set)

# Generated at 2022-06-23 01:31:33.505193
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'
    assert len(python._fact_ids) == 0

# Generated at 2022-06-23 01:31:38.459458
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector(None).collect()

    assert python_facts is not None
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:31:46.667206
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_module = type('module', (object,), dict(fail_json=lambda x: None))()

    fake_collected_facts = {}

    python_fact_collector = PythonFactCollector()

    collect_result = python_fact_collector.collect(module=python_module, collected_facts=fake_collected_facts)

    assert isinstance(collect_result, dict)
    assert 'python' in collect_result.keys()
    assert 'version' in collect_result['python'].keys()
    assert 'version_info' in collect_result['python'].keys()
    assert 'executable' in collect_result['python'].keys()
    assert 'has_sslcontext' in collect_result['python'].keys()

# Generated at 2022-06-23 01:31:53.911885
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']
    assert (result['python']['version'] ==
            {'major': sys.version_info[0],
             'minor': sys.version_info[1],
             'micro': sys.version_info[2],
             'releaselevel': sys.version_info[3],
             'serial': sys.version_info[4]})

# Generated at 2022-06-23 01:31:59.683692
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import Facts
    facts = Facts(module_args={})
    fc = PythonFactCollector(module=None, collected_facts=facts.ansible_facts)
    facts_dict = fc.collect()
    assert 'python' in facts_dict
    assert isinstance(facts_dict['python']['version'], dict)
    assert isinstance(facts_dict['python']['version_info'], list)

# Generated at 2022-06-23 01:32:01.813163
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test_PythonFactCollector = PythonFactCollector()
    assert test_PythonFactCollector.name == 'python'
    assert test_PythonFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:32:03.590646
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test_collector = PythonFactCollector()
    assert test_collector.name == 'python'
    assert test_collector._fact_ids == set()

# Generated at 2022-06-23 01:32:10.341159
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    python_fact = collector.PythonFactCollector()

    # Test whether it is a subclass of BaseFactCollector
    assert isinstance(python_fact, BaseFactCollector)

# Unit test

# Generated at 2022-06-23 01:32:18.931345
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_test_facts = PythonFactCollector().collect()
    assert 'python' in python_test_facts
    assert 'version' in python_test_facts['python']
    assert 'major' in python_test_facts['python']['version']
    assert 'minor' in python_test_facts['python']['version']
    assert 'micro' in python_test_facts['python']['version']
    assert 'type' in python_test_facts['python']
    assert 'executable' in python_test_facts['python']
    assert 'has_sslcontext' in python_test_facts['python']



# Generated at 2022-06-23 01:32:20.840349
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'

# Generated at 2022-06-23 01:32:30.095957
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of class PythonFactCollector
    pfc = PythonFactCollector()

    # Run method collect of class PythonFactCollector
    result = pfc.collect()
    assert result.get('python', {}).get('version') == {'major': sys.version_info[0],
                                                       'minor': sys.version_info[1],
                                                       'micro': sys.version_info[2],
                                                       'releaselevel': sys.version_info[3],
                                                       'serial': sys.version_info[4]}

    assert result.get('python', {}).get('version_info') == list(sys.version_info)

    assert result.get('python', {}).get('executable') == sys.executable

    assert result.get('python', {}).get('has_sslcontext') == HAS

# Generated at 2022-06-23 01:32:31.444114
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'


# Generated at 2022-06-23 01:32:35.138213
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'
    assert pf._fact_ids == set()

# Generated at 2022-06-23 01:32:37.302310
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    pf.collect()

if __name__ == '__main__':
    test_PythonFactCollector()

# Generated at 2022-06-23 01:32:39.891920
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:32:48.684659
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

  python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

  try:
    python_facts['python']['type'] = sys.subversion[0]
  except AttributeError:
    try:
        python_facts['python']['type'] = sys.implementation.name
    except AttributeError:
        python_

# Generated at 2022-06-23 01:32:58.056877
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    expected_data = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    try:
        expected_data['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            expected_data['python']['type'] = sys.implementation.name
        except AttributeError:
            expected_

# Generated at 2022-06-23 01:33:00.459297
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert isinstance(collector.name, str)
    assert isinstance(collector.collect(), dict)

# Generated at 2022-06-23 01:33:04.357790
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    try:
        pfc = PythonFactCollector()
        assert pfc.name == 'python'
        assert isinstance(pfc._fact_ids, set)
    except AttributeError:
        assert False
    else:
        assert True



# Generated at 2022-06-23 01:33:06.600656
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc= PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:33:15.283301
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test method collect of the class PythonFactCollector
    """
    # Setup the class for unit test using the
    # method get_module_instance
    module_instance = get_module_instance()
    # Instantiate the class
    pfc = PythonFactCollector(module_instance)
    # Execute the method collect, passing the module_instance
    # as a parameter and capturing the result
    pd = pfc.collect(module_instance)
    # Compare the result to the expected result

# Generated at 2022-06-23 01:33:17.872036
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector= PythonFactCollector()
    python_facts=python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['type'] == 'CPython'

# Generated at 2022-06-23 01:33:24.752592
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pythonFactCollector = PythonFactCollector()
    python_facts = pythonFactCollector.collect()

    # The collect method should return a dictionary of python facts
    assert(isinstance(python_facts, dict))

    # The dictionary should have one key
    assert(len(python_facts) == 1)

    # The key should be 'python'
    assert('python' in python_facts)

    # The value for the key python is another dictionary
    assert(isinstance(python_facts['python'], dict))

    # The dictionary should have at least the following keys

# Generated at 2022-06-23 01:33:26.612858
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc.name == 'python'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:33:29.659008
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert type(obj) == PythonFactCollector
    assert type(type(obj)) == type

# Generated at 2022-06-23 01:33:31.507995
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    assert python_collector.collect()

# Generated at 2022-06-23 01:33:40.793603
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    assert fact_collector.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-23 01:33:49.083588
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    result = python_facts.collect()
    assert result['python']['version'] == {
        'major': 3,
        'minor': 8,
        'micro': 0,
        'releaselevel': 'final',
        'serial': 0,
    }
    assert result['python']['type'] == 'CPython'
    assert result['python']['executable'] == sys.executable
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['has_sslcontext'] is True

# Generated at 2022-06-23 01:33:59.094352
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    # Check major version
    assert python_facts['python']['version']['major'] == 3

    # Check minor version
    assert python_facts['python']['version']['minor'] == 6

    # Check micro version
    assert python_facts['python']['version']['micro'] == 3

    # Check release level
    assert python_facts['python']['version']['releaselevel'] == 'final'

    # Check version serial
    assert python_facts['python']['version']['serial'] == 0

    # Check executable
    assert python_facts['python']['executable'] == sys.executable

    # Check for SSLContext support

# Generated at 2022-06-23 01:34:02.868258
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()

    assert f is not None
    assert f.name == 'python'
    assert f._fact_ids == set()

# Generated at 2022-06-23 01:34:09.209159
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'
    assert python.collect()['python']['executable'] == sys.executable
    assert python.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert python.collect()['python']['version']['major'] > 0

# Generated at 2022-06-23 01:34:10.641647
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'

# Generated at 2022-06-23 01:34:19.086667
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()

    assert python_facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }

    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

    # In Python 3.3 and beyond, the name of the implementation is
    # available in sys.

# Generated at 2022-06-23 01:34:20.420333
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:34:21.510103
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:34:23.029727
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfact = PythonFactCollector()

    assert pyfact.name == 'python'
    assert pyfact._fact_ids == set()

# Generated at 2022-06-23 01:34:29.710399
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyc = PythonFactCollector()
    res = pyc.collect()
    # Cannot test module as it is not defined when running the test, but would be when running the module
    # assert res['python']['version']['major'] == sys.version_info[0]
    # assert res['python']['version']['minor'] == sys.version_info[1]
    # assert res['python']['version']['micro'] == sys.version_info[2]
    # assert res['python']['version']['releaselevel'] == sys.version_info[3]
    # assert res['python']['version']['serial'] == sys.version_info[4]
    assert res['python']['version_info'][0] == sys.version_info[0]

# Generated at 2022-06-23 01:34:31.732985
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert isinstance(fact_collector, PythonFactCollector)

# Generated at 2022-06-23 01:34:41.225938
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    my_python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-23 01:34:49.356138
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    module = 'my_module'
    collected_facts = 'my_facts'

    python_fact = PythonFactCollector()
    facts = python_fact.collect(module, collected_facts)

    assert len(facts['python']['version_info']) == 5
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:34:53.480441
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ test collect of class PythonFactCollector """
    pfc = PythonFactCollector()
    collected = pfc.collect()
    print(collected)

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:34:55.772434
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'

# Generated at 2022-06-23 01:35:03.305234
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect() == {'python': {'executable': '/usr/bin/python',
                                              'has_sslcontext': True,
                                              'type': 'CPython',
                                              'version': {'major': 2,
                                                          'minor': 7,
                                                          'micro': 5,
                                                          'releaselevel': 'final',
                                                          'serial': 0},
                                              'version_info': [2, 7, 5, 'final', 0]}}

# Generated at 2022-06-23 01:35:05.965565
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = PythonFactCollector().collect()

    assert collected_facts['python']['version']['major'] == 2 or collected_facts['python']['version']['major'] == 3

# Generated at 2022-06-23 01:35:17.023228
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:35:18.922477
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert 'python' == python_fact_collector.name


# Generated at 2022-06-23 01:35:21.066734
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.collect() != None

if __name__ == '__main__':
    test_PythonFactCollector()

# Generated at 2022-06-23 01:35:21.628313
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert ['']

# Generated at 2022-06-23 01:35:24.215159
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert type(pfc._fact_ids) == set


# Generated at 2022-06-23 01:35:34.872492
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:35:39.291199
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert len(python_facts['python']) == 5
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:35:44.296958
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    result = py_fc.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']

# Generated at 2022-06-23 01:35:46.097469
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = None
    fact_collector = PythonFactCollector()
    fact_collector.collect(module=module)

# Generated at 2022-06-23 01:35:49.327084
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:35:51.193599
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert isinstance(fact_collector, PythonFactCollector)


# Generated at 2022-06-23 01:35:52.842645
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set(['python'])



# Generated at 2022-06-23 01:35:56.180850
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert len(pfc._fact_ids) == 0


# Generated at 2022-06-23 01:36:01.478033
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result = collector.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-23 01:36:04.994117
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()

    assert len(p._fact_ids) == 1
    assert 'python' in p._fact_ids
    assert p.name == 'python'



# Generated at 2022-06-23 01:36:06.297850
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:36:09.789544
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector(None)

    assert hasattr(pf, 'name')
    assert hasattr(pf, '_fact_ids')
    assert type(pf._fact_ids) is set
    assert hasattr(pf, 'collect')

# Generated at 2022-06-23 01:36:11.619163
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert python_fact is not None
    assert python_fact._fact_ids == {'python'}

# Generated at 2022-06-23 01:36:22.976328
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert result['python'] is not None, 'python fact should be present'
    assert len(result['python']) > 0, 'python fact should not be empty'
    assert 'version' in result['python']
    assert len(result['python']['version']) > 0, 'version fact should not be empty'
    assert 'version_info' in result['python']
    assert len(result['python']['version_info']) > 0, 'version_info fact should not be empty'
    assert 'executable' in result['python']
    assert len(result['python']['executable']) > 0, 'executable fact should not be empty'
    assert 'type' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-23 01:36:32.794582
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from test.units.ansible.module_utils.facts.collector import Collector
    from test.units.ansible.module_utils.facts.collector.python import PythonFactCollector

    # Instantiate the correct module class
    collector = Collector()
    python_fact_collector = PythonFactCollector()

    # Get the facts
    facts = python_fact_collector.collect(module=None, collected_facts=collector.collect())

    assert 'python' in facts
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)

# Generated at 2022-06-23 01:36:35.149594
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'


# Generated at 2022-06-23 01:36:43.157806
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = python_fact_collector.collect()
    assert isinstance(collected_facts, dict)
    assert 'python' in collected_facts
    assert isinstance(collected_facts['python'], dict)

    reinstantiated_collector = PythonFactCollector()
    collected_facts_2 = reinstantiated_collector.collect()
    assert isinstance(collected_facts_2, dict)
    assert 'python' in collected_facts_2
    assert isinstance(collected_facts_2['python'], dict)

    assert collected_facts == collected_facts_2

# Generated at 2022-06-23 01:36:46.512797
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

    assert result is not None

# Generated at 2022-06-23 01:36:48.766924
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj != None
    return True


# Generated at 2022-06-23 01:36:50.027895
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'



# Generated at 2022-06-23 01:36:53.570935
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import pytest

    fc = PythonFactCollector()
    facts = fc.collect()
    assert 'python' in facts

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-23 01:37:03.783915
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert python_facts['python']['version_info'][0] == sys.version_info[0]
    assert python_facts['python']['version_info'][1] == sys.version_info[1]
    assert python_facts['python']['version_info'][2] == sys.version_info[2]
    assert python_facts['python']['version_info'][3] == sys.version_info[3]
    assert python_facts['python']['version_info'][4] == sys.version_info[4]
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:37:13.603247
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    facts = fact_collector.collect()

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS

# Generated at 2022-06-23 01:37:22.825865
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""
    # Create a new instance of class PythonFactCollector
    fact_collector = PythonFactCollector()

    # Test method collect of class PythonFactCollector
    facts = fact_collector.collect()

    # Test python dictionary has key version_info
    assert 'version_info' in facts['python']
    assert 'has_sslcontext' in facts['python']

    # Test python dictionary has key executable
    assert 'executable' in facts['python']
    path_list = facts['python']['executable'].split('/')
    assert path_list[len(path_list)-1] == 'python'

# Generated at 2022-06-23 01:37:32.245347
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_collector = PythonFactCollector()
    facts = python_collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:37:35.755779
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    actual = fc.collect()
    assert isinstance(actual, dict)


# Generated at 2022-06-23 01:37:37.769566
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'



# Generated at 2022-06-23 01:37:42.634040
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_obj = PythonFactCollector()
    # Test for 'name' attribute of class PythonFactCollector
    assert python_obj.name == 'python'
    # Test for '_fact_ids' attribute of class PythonFactCollector
    assert python_obj._fact_ids == set()

# Generated at 2022-06-23 01:37:53.058803
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    class args(object):
        _ansible_module = False

    fact_collector = PythonFactCollector(args)
    test_facts = fact_collector.collect()

    assert test_facts['python']['version']['major'] == sys.version_info[0]
    assert test_facts['python']['version']['minor'] == sys.version_info[1]
    assert test_facts['python']['version']['micro'] == sys.version_info[2]
    assert test_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert test_facts['python']['version']['serial'] == sys.version_info[4]

    assert test_facts['python']['version_info'] == list(sys.version_info)


# Generated at 2022-06-23 01:37:55.370345
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:37:58.525310
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()

    assert f.name == 'python'
    assert f._fact_ids == set()

    assert hasattr(f, 'collect')
    assert callable(f.collect)

# Generated at 2022-06-23 01:38:00.167782
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:38:01.496422
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert issubclass(PythonFactCollector, BaseFactCollector)

# Generated at 2022-06-23 01:38:03.895679
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    result = PythonFactCollector()
    assert(result.name == 'python')

# Generated at 2022-06-23 01:38:05.547152
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc != None

# Generated at 2022-06-23 01:38:07.290383
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pc = PythonFactCollector(module=None, collected_facts=None)

    assert pc is not None

# Generated at 2022-06-23 01:38:14.924484
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test if collect works correctly"""
    pfc = PythonFactCollector()
    pfc_facts = pfc.collect()
    assert (pfc_facts.keys() == ['python'])
    assert (pfc_facts['python'].keys() == ['version', 'version_info', 'executable', 'type', 'has_sslcontext'])
    assert (pfc_facts['python']['type'] == 'cpython')
    assert (pfc_facts['python']['version_info'] == list(sys.version_info))
    assert (pfc_facts['python']['executable'] == sys.executable)

# Generated at 2022-06-23 01:38:18.572776
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name is not None
    assert python_fact_collector._fact_ids == set(['python'])

# Generated at 2022-06-23 01:38:19.967815
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'

# Generated at 2022-06-23 01:38:25.111875
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    class_instance = PythonFactCollector()

    # Call method collect of class CommandFactCollector
    result = class_instance.collect()

    assert result.get('python')
    assert result['python'].get('version')
    assert result['python'].get('version_info')
    assert result['python'].get('executable')
    assert result['python'].get('has_sslcontext')
    assert result['python'].get('type')

# Generated at 2022-06-23 01:38:26.006696
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x

# Generated at 2022-06-23 01:38:27.372089
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-23 01:38:29.633526
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f.name == 'python'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:38:37.098712
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
  """ Test constructor of class PythonFactCollector """
  from ansible.module_utils.facts.collectors.python import PythonFactCollector
  from ansible.module_utils.facts.collector import BaseFactCollector

  x = PythonFactCollector()
  assert(isinstance(x,BaseFactCollector))
  assert(x.name == 'python')
  assert(isinstance(x._fact_ids,frozenset))
  assert(x._fact_ids == frozenset())



# Generated at 2022-06-23 01:38:41.164533
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector(None)
    collected_facts = {}
    results = python_fact_collector.collect(None, collected_facts)
    assert isinstance(results, dict)

# Generated at 2022-06-23 01:38:43.920826
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert hasattr(obj, 'collect')

# Generated at 2022-06-23 01:38:52.394259
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors import gather_subset
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    python_collector = PythonFactCollector()

    # collect should return a dict containing a key 'python'
    # and this key should point to a dict that is not empty
    collection = python_collector.collect()

# Generated at 2022-06-23 01:38:54.973472
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()

    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:38:58.486365
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert isinstance(python_facts._fact_ids, set)


# Generated at 2022-06-23 01:39:06.907397
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    # Check that the IpxactFactCollector's name attribute is 'python'
    assert python_fact_collector.name == 'python'
    # Check that the IpxactFactCollector's _fact_ids attribute is set.
    assert type(python_fact_collector._fact_ids) == set
    # Check that the IpxactFactCollector is an instance of BaseFactCollector
    assert isinstance(python_fact_collector, BaseFactCollector)


# Generated at 2022-06-23 01:39:14.721079
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = PythonFactCollector()
    result = module.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable


# Generated at 2022-06-23 01:39:17.189150
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'
    assert python._fact_ids == set()


# Generated at 2022-06-23 01:39:22.884293
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = None
    python_facts = PythonFactCollector().collect(module, None)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-23 01:39:25.344238
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()



# Generated at 2022-06-23 01:39:35.475514
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test with Python 2.
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()
    assert python_facts['python']['version']['major'] == 2
    assert python_facts['python']['version']['minor'] == 7
    assert python_facts['python']['version']['micro'] == 13
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert python_facts['python']['version']['serial'] == 0
    assert python_facts['python']['version_info'] == sys.version_info
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['type'] == 'CPython'