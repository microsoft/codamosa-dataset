

# Generated at 2022-06-23 01:29:31.898170
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:29:33.423779
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()



# Generated at 2022-06-23 01:29:42.980410
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert type(python_facts) is dict
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-23 01:29:44.928889
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'

# Generated at 2022-06-23 01:29:54.427687
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    pfc = PythonFactCollector()
    pfc_facts = pfc.collect()

    assert pfc_facts['python']['executable'] is not None
    assert pfc_facts['python']['version']['major'] is not None
    assert pfc_facts['python']['version']['minor'] is not None
    assert pfc_facts['python']['version']['micro'] is not None
    assert pfc_facts['python']['version']['releaselevel'] is not None
    assert pfc_facts['python']['version']['serial'] is not None
    assert pfc_facts['python']['version_info'] is not None

# Generated at 2022-06-23 01:29:57.992222
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

if __name__ == '__main__':
    test_PythonFactCollector()

# Generated at 2022-06-23 01:30:06.172278
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collect
    from ansible.module_utils.facts.collectors import get_collector_name
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    # Create and register collector
    collector = PythonFactCollector()
    collect.register_collector(collector)

    # Run method collect
    facts_dict = collect.collect(module=None, collected_facts=None)

    # Verify result
    assert get_collector_name('python') in facts_dict
    python_facts = facts_dict[get_collector_name('python')]
    assert 'python' in python_facts
    python_version = python_facts['python']['version']
    assert 'major' in python_version
    assert 'minor' in python_version

# Generated at 2022-06-23 01:30:08.404661
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'

# Generated at 2022-06-23 01:30:10.032277
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-23 01:30:11.771932
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None


# Generated at 2022-06-23 01:30:13.473168
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj.collect()

# Generated at 2022-06-23 01:30:16.627118
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    for name, arg in [("python", {}), ("python", {'version': ['2.7.14']})]:
        fc = PythonFactCollector(name, arg, None)
        assert fc.name == name

# Generated at 2022-06-23 01:30:20.464608
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc._module = type('',(),{'params':{}})
    pfc._plugin_options = {}
    pfc.collected_facts = {}

    pfc.collect()
    assert 'python' in pfc.collected_facts

# Generated at 2022-06-23 01:30:26.654374
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method of PythonFactCollector collect that collects python facts."""
    python_collector = PythonFactCollector()
    ansible_python_facts = python_collector.collect()
    assert ansible_python_facts
    assert isinstance(ansible_python_facts, dict)
    assert ansible_python_facts['python']
    assert 'version' in ansible_python_facts['python']

if __name__ == "__main__":
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:30:32.337515
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collector import get_collector_instance
    python_collector = get_collector_instance('python')
    assert isinstance(PythonFactCollector, type(python_collector))
    assert python_collector.name == 'python'


# Generated at 2022-06-23 01:30:34.721402
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:30:36.430547
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    res = pfc.collect()
    assert len(res) > 0

# Generated at 2022-06-23 01:30:37.831157
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-23 01:30:39.807017
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector collect method"""
    py_facts = PythonFactCollector()
    assert 'python' in py_facts.collect()

# Generated at 2022-06-23 01:30:48.744862
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == "python"
    # minimum 2 items in PythonFactCollector._fact_ids
    assert len(x._fact_ids) >= 2
    assert 'python' in x._fact_ids
    assert 'type' in x._fact_ids
    assert 'version' in x._fact_ids
    assert 'version_info' in x._fact_ids
    assert 'executable' in x._fact_ids

# Generated at 2022-06-23 01:30:52.681643
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # TODO: implement unit test for method collect of class PythonFactCollector
    pass

# Generated at 2022-06-23 01:31:01.311835
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for collect method of class PythonFactCollector'''
    # Create instance of PythonFactCollector class
    pfc = PythonFactCollector()
    # Collect facts
    collected_facts = pfc.collect()
    # Make assertions
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert isinstance(collected_facts['python']['version']['major'], int)
    assert isinstance(collected_facts['python']['version']['minor'], int)
    assert isinstance(collected_facts['python']['version']['micro'], int)
    assert isinstance(collected_facts['python']['version']['releaselevel'], str)
    assert isinstance

# Generated at 2022-06-23 01:31:02.616469
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc is not None

# Generated at 2022-06-23 01:31:13.598129
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    result = p.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:31:14.923056
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:31:15.918448
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Ensure the constructor works
    PythonFactCollector()

# Generated at 2022-06-23 01:31:23.172073
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:31:31.739516
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_coll = PythonFactCollector()
    py_facts = py_coll.collect()
    assert py_facts['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }
    assert py_facts['python']['type'] == sys.implementation.name

# Generated at 2022-06-23 01:31:41.281174
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    result = python_fact_collector.collect()

    assert result['python']['version']['major'] == 2
    assert result['python']['version']['minor'] == 7
    assert result['python']['version']['micro'] == 15
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [2, 7, 15, 'final', 0]

    assert result['python']['executable'] == sys.executable
    assert result['python']['type'] == 'CPython'

# Generated at 2022-06-23 01:31:42.951153
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert not p._fact_ids

# Generated at 2022-06-23 01:31:53.015959
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import os
    import sys
    module_path = os.path.join(os.path.dirname(__file__), '../../../')
    sys.path.insert(0, module_path)
    from ansible.module_utils.facts.collector import PythonFactCollector
    p = PythonFactCollector()
    assert p.name == 'python'
    assert 'python' in p._fact_ids
    f = p.collect()
    assert 'python' in f.keys()
    assert 'version' in f['python'].keys()
    assert 'version_info' in f['python'].keys()
    assert 'executable' in f['python'].keys()
    assert 'type' in f['python'].keys()
    assert 'has_sslcontext' in f['python'].keys()

# Generated at 2022-06-23 01:31:55.900568
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:32:04.630493
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc is not None
    python_facts = pfc.collect()
    assert python_facts is not None
    assert 'python' in python_facts
    python = python_facts['python']
    assert python is not None
    assert 'version' in python
    version = python['version']
    assert version is not None
    assert 'major' in version
    assert 'minor' in version
    assert 'micro' in version
    assert 'releaselevel' in version
    assert 'serial' in version
    assert 'version_info' in python
    version_info = python['version_info']
    assert version_info is not None
    assert 'executable' in python
    assert 'has_sslcontext' in python
    assert 'type' in python

# Generated at 2022-06-23 01:32:09.150695
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == "python"
    assert not python_facts._fact_ids
    assert python_facts._fact_ids.__class__.__name__ == "set"

# Generated at 2022-06-23 01:32:10.936000
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()


# Generated at 2022-06-23 01:32:15.106566
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Create object
    pfc = PythonFactCollector()
    # Make sure type is 'python'
    assert pfc.name == 'python'
    # Make sure both names are in set
    assert pfc.name in pfc._fact_ids
    assert 'python' in pfc._fact_ids


# Generated at 2022-06-23 01:32:16.680563
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:32:27.501582
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = python_fact_collector.collect()
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'major' in collected_facts['python']['version']
    assert type(collected_facts['python']['version']['major']) is int
    assert 'minor' in collected_facts['python']['version']
    assert type(collected_facts['python']['version']['minor']) is int
    assert 'micro' in collected_facts['python']['version']
    assert type(collected_facts['python']['version']['micro']) is int
    assert 'releaselevel' in collected_facts['python']['version']

# Generated at 2022-06-23 01:32:29.606922
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    results = fc.collect()
    assert 'python' in results

# Generated at 2022-06-23 01:32:31.348490
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'

# Generated at 2022-06-23 01:32:32.688572
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-23 01:32:42.333315
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    collected_facts = python_collector.collect()
    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]
    assert collected_facts['python']['version_info'] == list(sys.version_info)
    assert collected_facts['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:32:48.157206
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # instantiate test PythonFactCollector
    tf = PythonFactCollector()

    # Set return value of method _collect of TestModule class to a known value
    # TestModule is the superclass of PythonFactCollector which defines
    # the method _collect.
    tf._collect = lambda: {'stuff': "value"}

    # invoke collect method of test PythonFactCollector
    results = tf.collect()

    # check that result of collect is as expected
    assert results == {'stuff': "value"}

# Generated at 2022-06-23 01:32:58.018941
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instantiate the PythonFactCollector class
    python_fact_collector = PythonFactCollector()
    
    # Call method collect
    python_facts = python_fact_collector.collect()
    
    # Assert that we get a dictionary
    assert isinstance(python_facts, dict)
    
    # Check for key "python"
    assert "python" in python_facts
    
    # Check for key "version"
    assert "version" in python_facts["python"]
    
    # Check for key "major"
    assert "major" in python_facts["python"]["version"]
    
    # Check for key "minor"
    assert "minor" in python_facts["python"]["version"]
    
    # Check for key "micro"

# Generated at 2022-06-23 01:33:02.093622
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import pytest
    import ansible.module_utils.facts.collector
    pytest.skip("Python2 support is removed, please migrate to Python3", allow_module_level=True)

    obj = PythonFactCollector()
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-23 01:33:04.200330
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert isinstance(p, BaseFactCollector)


# Generated at 2022-06-23 01:33:11.585106
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    py_facts = py_fact_collector.collect()
    assert py_facts == {'python': {'has_sslcontext': True,
                                   'type': 'CPython',
                                   'version': {'major': 2,
                                               'minor': 7,
                                               'micro': 10,
                                               'releaselevel': 'final',
                                               'serial': 0},
                                   'version_info': [2, 7, 10, 'final', 0],
                                   'executable': '/usr/bin/python'}}

# Generated at 2022-06-23 01:33:22.077925
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils._text import to_text

    # Create a PythonFactCollector object
    pfc = PythonFactCollector()
    assert isinstance(pfc, BaseFactCollector)

    # Test the collect method of PythonFactCollector
    result = pfc.collect(module=None, collected_facts=None)
    assert isinstance(result, dict)
    assert 'python' in result
    python_facts = result['python']

    # Check if python is a key in python_facts
    assert 'version' in python_facts
    assert 'executable' in python_facts
   

# Generated at 2022-06-23 01:33:26.669411
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test with no argument
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert 'python' in result
    assert 'type' in result['python']
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-23 01:33:34.420333
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    results = PythonFactCollector().collect()
    assert results['python']['version']['major'] == sys.version_info[0]
    assert results['python']['version']['minor'] == sys.version_info[1]
    assert results['python']['version']['micro'] == sys.version_info[2]
    assert results['python']['version']['releaselevel'] == sys.version_info[3]
    assert results['python']['version']['serial'] == sys.version_info[4]
    assert results['python']['version_info'] == list(sys.version_info)
    assert results['python']['executable'] == sys.executable
    assert results['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:33:39.638555
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect"""

    pythonfactcollector = PythonFactCollector()
    r = pythonfactcollector.collect()
    
    assert r['python']['type'] == 'CPython'
    assert r['python']['version']['releaselevel'] == 'final'
    assert r['python']['executable'] == '/usr/bin/python'


# Generated at 2022-06-23 01:33:46.350947
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import mock

    # Can't mock the class itself, so mock the base class it inherits
    mock_collector = mock.MagicMock(BaseFactCollector)

    fact_collector = PythonFactCollector(mock_collector)

    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:33:57.371279
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    # Test collect with no kwargs
    result = pfc.collect()

    # Make sure we got what we expected
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT
    if 'subversion' in sys.__dict__:
        assert result['python']['type'] == sys.subversion[0]
    elif 'implementation' in sys.__dict__:
        assert result['python']['type'] == sys.implementation.name

# Generated at 2022-06-23 01:34:07.061645
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    result = python_facts.collect()
    version_info = list(sys.version_info)
    assert result['version_info'] == version_info
    assert result['version']['major'] == sys.version_info[0]
    assert result['version']['minor'] == sys.version_info[1]
    assert result['version']['micro'] == sys.version_info[2]
    assert result['version']['releaselevel'] == sys.version_info[3]
    assert result['version']['serial'] == sys.version_info[4]
    assert result['executable'] == sys.executable
    assert result['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:34:09.308254
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p=PythonFactCollector()
    facts = p.collect()
    assert facts
    assert facts['python']['version']['major']

# Generated at 2022-06-23 01:34:17.026232
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    py_facts = py_collector.collect(module=None, collected_facts=None)
    assert py_facts

    # Test some keys
    assert 'python' in py_facts.keys()
    assert 'version' in py_facts['python'].keys()
    assert 'version_info' in py_facts['python'].keys()
    assert 'has_sslcontext' in py_facts['python'].keys()
    assert 'type' in py_facts['python'].keys()

# Generated at 2022-06-23 01:34:19.921692
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    p = PythonFactCollector()

    assert p.name == "python"
    assert isinstance(p._fact_ids,set)

# Generated at 2022-06-23 01:34:21.134180
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    result = PythonFactCollector()
    assert result._fact_ids == set()

# Generated at 2022-06-23 01:34:28.622526
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect method"""

    import copy
    import sys

    python_facts = {
        'python': {
            'type': sys.implementation.name if sys.implementation.name != 'cpython' else 'cpython',
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    fact_collector = PythonFactCollector()
    fact_collect

# Generated at 2022-06-23 01:34:30.445240
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfc = PythonFactCollector()
    assert pythonfc.name == 'python'

# Generated at 2022-06-23 01:34:40.275317
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from collections import namedtuple
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector

    # Create a stub class whose collect is alwyas successful.
    StubClass = namedtuple('StubClass', 'collect')

    stub_collector = StubClass(
        collect=lambda module=None, collected_facts=None: {'foo': 'bar'}
    )

    # Create another stub class whose collect raises an exception
    StubClassWithExcp = namedtuple('StubClassWithExcp', 'collect')

    def stub_collect_with_exception(module=None, collected_facts=None):
        raise Exception('test exception')


# Generated at 2022-06-23 01:34:41.255226
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:34:44.056074
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # With 'python' name
    x = PythonFactCollector()
    assert x.name == 'python'

    # With 'mock' name
    x = PythonFactCollector('mock')
    assert x.name == 'mock'

# Generated at 2022-06-23 01:34:51.035228
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_facts = {
        'python': {
            'executable': '/bin/python3.6',
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'major': 3,
                'minor': 6,
                'micro': 4,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [3, 6, 4, 'final', 0]
        }
    }

    test_obj = PythonFactCollector()

    assert test_obj.collect() == python_facts
    assert test_obj.name == 'python'
    assert test_obj._fact_ids == set(['python'])

# Generated at 2022-06-23 01:34:53.830100
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = object
    collected_facts = object
    python_fact = PythonFactCollector(module=module, collected_facts=collected_facts)
    assert python_fact.name == 'python'
    assert python_fact._fact_ids == set()

# Generated at 2022-06-23 01:34:57.440540
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import Collector

    c = Collector()
    d = c.collect(module=None, collected_facts={})
    assert d.get('python')

# Generated at 2022-06-23 01:35:00.020664
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert set(p._fact_ids) == set() # pylint: disable=protected-access

# Generated at 2022-06-23 01:35:01.371158
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == "python"

# Generated at 2022-06-23 01:35:08.754271
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    collected_facts = {}
    p.collect(collected_facts=collected_facts)
    assert collected_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:35:12.759189
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, BaseFactCollector)
    assert isinstance(python_fact_collector.name, str)
    assert isinstance(python_fact_collector._fact_ids, set)

# Generated at 2022-06-23 01:35:14.723879
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert 'python' in result


# Generated at 2022-06-23 01:35:16.632836
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:35:18.254187
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'


# Generated at 2022-06-23 01:35:24.358292
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Set up a mock AnsibleModule object
    from ansible.module_utils.facts import ModuleFacts
    module = ModuleFacts()

    pyfc = PythonFactCollector(module)

    assert pyfc.name == 'python'
    assert pyfc.priority > 0
    assert set(pyfc.collect().keys()) == set(['python'])
    assert set(pyfc.collect()['python'].keys()) == set(['version', 'version_info', 'executable', 'has_sslcontext', 'type'])

# Generated at 2022-06-23 01:35:26.146154
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:35:29.783099
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfact = PythonFactCollector()
    assert isinstance(pythonfact, PythonFactCollector)

# Unit test to verify if python version facts were obtained correctly

# Generated at 2022-06-23 01:35:30.240485
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:35:41.685883
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector
    pc = collector.get_collector('python')
    res = pc.collect()
    assert res['python']['version']['major'] == sys.version_info[0]
    assert res['python']['version']['minor'] == sys.version_info[1]
    assert res['python']['version']['micro'] == sys.version_info[2]
    assert res['python']['version']['releaselevel'] == sys.version_info[3]
    assert res['python']['version']['serial'] == sys.version_info[4]
    assert res['python']['version_info'] == list(sys.version_info)
    assert res['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:35:48.975544
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts_collector = PythonFactCollector()
    assert python_facts_collector.collect() == {
               'python': {
                   'version': {
                       'major': sys.version_info[0],
                       'minor': sys.version_info[1],
                       'micro': sys.version_info[2],
                       'releaselevel': sys.version_info[3],
                       'serial': sys.version_info[4]
                   },
                   'version_info': list(sys.version_info),
                   'executable': sys.executable,
                   'has_sslcontext': HAS_SSLCONTEXT,
                   'type': sys.version.split()[0]
               }
            }

# Generated at 2022-06-23 01:35:55.746157
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    class MockModule:
        def __init__(self):
            self.params = {}

    class MockCollectedFacts:
        def __init__(self):
            self.ansible_facts = {}

    m = MockModule()
    c = MockCollectedFacts()
    p = PythonFactCollector(m, c)
    result = p.collect()

    assert result['python']
    assert result['python']['version']
    assert result['python']['version_info']
    assert result['python']['executable']
    assert result['python']['type']
    assert result['python']['has_sslcontext']
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor']

# Generated at 2022-06-23 01:36:07.679113
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_col = PythonFactCollector()
    py_facts = py_col.collect()

    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_facts['python']['version']['serial'] == sys.version_info[4]
    assert py_facts['python']['version_info'] == list(sys.version_info)
    assert py_facts['python']['executable'] == sys.executable
   

# Generated at 2022-06-23 01:36:08.967738
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-23 01:36:11.075796
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    res = pfc.collect()
    print(res)

test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:36:19.149040
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector.'''
    python_collector = PythonFactCollector()
    result = python_collector.collect()

    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.exec

# Generated at 2022-06-23 01:36:30.155149
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert type(python_facts) == dict
    assert 'python' in python_facts
    assert type(python_facts['python']) == dict
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert type(python_facts['python']['version']) == dict
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial'

# Generated at 2022-06-23 01:36:34.886055
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    print("Testing PythonFactCollector __init__()")
    collector = PythonFactCollector()
    assert collector.name == 'python', "PythonFactCollector has wrong name"
    assert collector._fact_ids == set(), "PythonFactCollector has wrong fact_ids"

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 01:36:39.535932
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    p = PythonFactCollector()

    assert p.name == 'python'
    assert isinstance(p._fact_ids, set)
    assert isinstance(p.collect(), dict)
    assert isinstance(p.collect(collected_facts=None), dict)
    assert isinstance(p.collect(module=None, collected_facts=None), dict)

# Generated at 2022-06-23 01:36:49.680677
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Validate that the PythonFactCollector class works as expected"""

    # Generate a python_facts dict
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)

# Generated at 2022-06-23 01:36:58.799055
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc_facts = pfc.collect()

    assert pfc_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:36:59.586757
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector, object)

# Generated at 2022-06-23 01:37:00.975303
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact = fact_collector.collect()
    assert 'python' in fact

# Generated at 2022-06-23 01:37:05.314981
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert 'python' in python_fact_collector.collect()
    assert 'version' in python_fact_collector.collect().get('python')
    assert 'version_info' in python_fact_collector.collect().get('python')
    assert 'executable' in python_fact_collector.collect().get('python')
    assert 'has_sslcontext' in python_fact_collector.collect().get('python')

# Generated at 2022-06-23 01:37:07.767071
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()

    assert python_facts.name == 'python'
    assert python_facts._fact_ids == set()

# Generated at 2022-06-23 01:37:10.791785
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test with no arguments
    o = PythonFactCollector()
    assert o.name == 'python'
    assert isinstance(o._fact_ids, set)
    assert len(o._fact_ids) == 0


# Generated at 2022-06-23 01:37:22.224735
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['type'], str)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)

# Generated at 2022-06-23 01:37:24.436625
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:37:33.358632
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method `collect` of class `PythonFactCollector`.'''
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert facts['python']['version_info'][0] == sys.version_info[0]
    assert facts['python']['version_info'][1] == sys.version_info[1]
    assert facts['python']['version_info'][2] == sys.version_info[2]
    assert facts['python']['version_info'][3] == sys.version_info[3]
    assert facts['python']['version_info'][4] == sys.version_info[4]
    assert facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:37:45.483943
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()

    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()

    python_facts = fact_collector.collect()

    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']

    assert 'version_info' in python_facts['python']
    assert isinstance(python_facts['python']['version_info'], list)

   

# Generated at 2022-06-23 01:37:53.950460
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()

    assert python_facts is not None
    assert isinstance(python_facts, dict)
    assert python_facts['python'] is not None
    assert python_facts['python']['version']['major'] > 0
    assert python_facts['python']['version']['minor'] >= 0
    assert python_facts['python']['version']['micro'] >= 0
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert len(python_facts['python']['version_info']) == 5
    assert python_facts['python']['executable'] is not None
    assert python_facts['python']['has_sslcontext']

# Generated at 2022-06-23 01:37:57.930111
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''
    Unit test of constructor of PythonFactCollector class
    '''
    # pylint: disable=protected-access
    assert (PythonFactCollector._fact_ids == set(['python']))
    # pylint: enable=protected-access

# Generated at 2022-06-23 01:38:03.184851
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import python_collector
    from ansible.module_utils.facts.collector import Collector
    facts = Collector()
    facts._collect_subset = [ 'python' ]
    facts._validate_collectors()
    python_collector.collect()
    assert python_collector.name == 'python'


# Generated at 2022-06-23 01:38:12.853048
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Tests method collect of class PythonFactCollector'''
    py_fc = PythonFactCollector()
    py_facts = py_fc.collect()
    py_facts = py_facts['python']
    assert isinstance(py_facts['version']['major'], int)
    assert isinstance(py_facts['version']['minor'], int)
    assert isinstance(py_facts['version']['micro'], int)
    assert isinstance(py_facts['version']['releaselevel'], str)
    assert isinstance(py_facts['version']['serial'], int)

    assert isinstance(py_facts['version_info'], list)
    assert len(py_facts['version_info']) == 5

    assert isinstance(py_facts['executable'], str)

# Generated at 2022-06-23 01:38:17.921829
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {
        'python': {
            'version': {
                'major': 3,
                'minor': 5,
                'micro': 0,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [3, 5, 0, 'final', 0],
            'executable': '/usr/bin/python3',  # Use "/usr/bin/env python3" for Ansible to be able to replace with the correct binary
            'has_sslcontext': True,
            'type': 'CPython'
        }
    }

# Generated at 2022-06-23 01:38:28.653529
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    run_truth = {}
    run_truth['version'] = {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    run_truth['version_info'] = list(sys.version_info)
    run_truth['executable'] = sys.executable
    run_truth['has_sslcontext'] = HAS_SSLCONTEXT


# Generated at 2022-06-23 01:38:30.882464
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test with module specified
    assert PythonFactCollector(module=True)
    # Test with module set to None
    assert PythonFactCollector()

# Generated at 2022-06-23 01:38:33.497823
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert 'python' == PythonFactCollector.name
    assert isinstance(PythonFactCollector._fact_ids, set)

# Generated at 2022-06-23 01:38:35.999689
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:38:41.958192
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    fact_collector = FactCollector()
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()
    fact_collector.collect(None, None)
    assert 'python' in fact_collector.collected_facts

# Generated at 2022-06-23 01:38:53.418301
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()

    assert facts["python"]["version"]["major"] == sys.version_info[0]
    assert facts["python"]["version"]["minor"] == sys.version_info[1]
    assert facts["python"]["version"]["micro"] == sys.version_info[2]
    assert facts["python"]["version"]["releaselevel"] == sys.version_info[3]
    assert facts["python"]["version"]["serial"] == sys.version_info[4]
    assert facts["python"]["version_info"] == list(sys.version_info)
    assert facts["python"]["executable"] == sys.executable
    assert facts["python"]["has_sslcontext"] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:38:57.473278
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:39:09.301305
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json
    import sys
    import traceback
    import pytest
    from ansible.module_utils.facts import collector

    result = {
      'python': {
        'executable': '/foo/bar/python',
        'has_sslcontext': True,
        'type': 'CPython',
        'version': {
          'major': 2,
          'micro': 7,
          'minor': 13,
          'releaselevel': 'final',
          'serial': 0
        },
        'version_info': [
          2,
          7,
          13,
          'final',
          0
        ]
      }
    }

    class MockPythonFactCollector(collector.PythonFactCollector):
        def __init__(self):
            pass

        def collect(self):
            return result


# Generated at 2022-06-23 01:39:17.848650
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector

    module = object()
    collected_facts = object()
    python_fact_collector = PythonFactCollector(module=module, collected_facts=collected_facts)

    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert isinstance(python_facts['python'], dict)
    assert 'version' in python_facts['python']
    assert isinstance(python_facts['python']['version'], dict)
    assert 'version_info' in python_facts['python']
    assert isinstance(python_facts['python']['version_info'], list)
    assert 'executable' in python_facts['python']

# Generated at 2022-06-23 01:39:19.228139
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts = PythonFactCollector()
    assert facts.name == 'python'

# Generated at 2022-06-23 01:39:28.885435
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    theClass = PythonFactCollector()

    theFacts = theClass.collect()

    assert 'python' in theFacts
    assert type(theFacts['python']) is dict
    assert 'version' in theFacts['python']
    assert type(theFacts['python']['version']) is dict
    assert 'major' in theFacts['python']['version']
    assert type(theFacts['python']['version']['major']) is int
    assert 'minor' in theFacts['python']['version']
    assert type(theFacts['python']['version']['minor']) is int
    assert 'micro' in theFacts['python']['version']
    assert type(theFacts['python']['version']['micro']) is int

# Generated at 2022-06-23 01:39:32.411989
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector.priority == 1
    assert isinstance(PythonFactCollector._fact_ids, set)