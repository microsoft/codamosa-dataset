

# Generated at 2022-06-23 01:29:29.071197
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x is not None


# Generated at 2022-06-23 01:29:32.163525
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert python_facts._fact_ids == set()


# Generated at 2022-06-23 01:29:39.373607
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector_obj = PythonFactCollector()
    result = python_collector_obj.collect()
    assert 'python' in result

# Generated at 2022-06-23 01:29:49.928418
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert isinstance(facts['python']['version']['major'], int)
    assert isinstance(facts['python']['version']['minor'], int)
    assert isinstance(facts['python']['version']['micro'], int)
    assert isinstance(facts['python']['version']['releaselevel'], str)
    assert isinstance(facts['python']['version']['serial'], int)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)
    assert isinstance(facts['python']['type'], str)

# Generated at 2022-06-23 01:29:59.943259
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    v = f.collect()
    assert 'python' in v
    assert v['python']['version']['major'] == sys.version_info[0]
    assert v['python']['version']['minor'] == sys.version_info[1]
    assert v['python']['version']['micro'] == sys.version_info[2]
    assert v['python']['version']['releaselevel'] == sys.version_info[3]
    assert v['python']['version']['serial'] == sys.version_info[4]
    assert v['python']['version_info'] == list(sys.version_info)
    assert v['python']['executable'] == sys.executable
    assert v['python']['has_sslcontext']

# Generated at 2022-06-23 01:30:06.873204
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert isinstance(python_collector, BaseFactCollector)
    assert python_collector.name == 'python'
    assert hasattr(python_collector, 'collect')
    assert isinstance(python_collector._fact_ids, set)
    assert len(python_collector._fact_ids) == 0


# Generated at 2022-06-23 01:30:11.819361
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Arrange
    # Act
    pfc = PythonFactCollector()

    # Assert
    assert pfc.name == 'python'
    assert isinstance(pfc._fact_ids, set)
    assert pfc._fact_ids == pfc._fact_ids
    assert pfc.priority == 80


# Generated at 2022-06-23 01:30:15.057372
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import pprint
    pp = pprint.PrettyPrinter(indent=4)

    fact_collector = PythonFactCollector()
    python_facts = fact_collector.collect()
    pp.pprint(python_facts)


# Generated at 2022-06-23 01:30:17.263867
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector.name == 'python'


# Generated at 2022-06-23 01:30:19.111309
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    result = PythonFactCollector().collect()
    assert "python" in result


# Generated at 2022-06-23 01:30:21.299602
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert len(PythonFactCollector._fact_ids) == 0


# Generated at 2022-06-23 01:30:22.261641
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    print(PythonFactCollector())

# Generated at 2022-06-23 01:30:27.894678
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Collect facts with default settings.
    pfc = PythonFactCollector()
    collected_python_facts = pfc.collect()

    # Check what we've got.
    assert 'python' in collected_python_facts
    python_facts = collected_python_facts['python']
    assert 'version' in python_facts
    assert 'version_info' in python_facts
    assert 'executable' in python_facts
    assert 'has_sslcontext' in python_facts


# Generated at 2022-06-23 01:30:28.979213
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p != None

# Generated at 2022-06-23 01:30:30.835294
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert 'python' in p._fact_ids


# Generated at 2022-06-23 01:30:32.845445
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact = PythonFactCollector()
    assert py_fact.name == 'python'

# Generated at 2022-06-23 01:30:39.694576
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = 'n/a'
    pc = PythonFactCollector(module)
    facts = pc.collect()
    assert isinstance(facts, dict)
    print(facts)
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:30:52.309670
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    facts = python_collector.collect()

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS

# Generated at 2022-06-23 01:30:55.447701
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert python_fact.name == 'python'
    assert python_fact.priority == 90
    assert python_fact._fact_ids == set()


# Generated at 2022-06-23 01:30:57.163497
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'

# Generated at 2022-06-23 01:30:59.044882
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:31:01.230566
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_obj = PythonFactCollector()
    assert fact_obj
    assert fact_obj.name == 'python'

# Generated at 2022-06-23 01:31:05.638601
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize the collector
    pfc = PythonFactCollector()
    # The python version should be a dictionary
    assert isinstance(pfc.collect()['python']['version'], dict)
    # The python version info should be a list
    assert isinstance(pfc.collect()['python']['version_info'], list)

# Generated at 2022-06-23 01:31:09.092054
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()


# Generated at 2022-06-23 01:31:18.796192
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector({})

    res = p.collect()
    assert 'python' in res
    assert res['python']['version']['major'] == sys.version_info[0]
    assert res['python']['version']['minor'] == sys.version_info[1]
    assert res['python']['version']['micro'] == sys.version_info[2]
    assert res['python']['version']['releaselevel'] == sys.version_info[3]
    assert res['python']['version']['serial'] == sys.version_info[4]
    assert res['python']['version_info'] == list(sys.version_info)
    assert res['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:31:21.040845
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()

    assert py_fact_collector.name == 'python'

# Generated at 2022-06-23 01:31:24.011167
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:31:27.887587
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector(None, None)
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:31:39.437478
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # test for sslcontext support
    assert HAS_SSLCONTEXT

    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-23 01:31:41.379792
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()

# Generated at 2022-06-23 01:31:44.124331
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert hasattr(py_fact_collector, '_fact_ids')


# Generated at 2022-06-23 01:31:48.686492
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:31:51.028966
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:32:01.825530
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_coll = PythonFactCollector()
    result = fact_coll.collect()
    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:32:13.075143
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_version_info = sys.version_info

    collector = PythonFactCollector()

    # We do not have a module arg to this method, so pass in None
    # The collected_facts arg is required by the method signature,
    # but not used in this method, so pass in None
    result = collector.collect(None, None)

    assert(result['python']['version']['major'] == python_version_info.major)
    assert(result['python']['version']['minor'] == python_version_info.minor)
    assert(result['python']['version']['micro'] == python_version_info.micro)
    assert(result['python']['version']['releaselevel'] == python_version_info.releaselevel)

# Generated at 2022-06-23 01:32:18.940013
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector(None, 'python')
    assert isinstance(pythonFactCollector, BaseFactCollector)
    assert hasattr(pythonFactCollector, 'name')
    assert pythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:32:28.506153
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()

    expected_python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-23 01:32:30.880793
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p is not None
    assert p.name == 'python'
    assert p._fact_ids == set()


# Generated at 2022-06-23 01:32:36.030110
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # We use 'list' instead of set because we need order
    assert PythonFactCollector().collect() == {'python': {'version': {'releaselevel': 'final', 'serial': 0, 'major': 3, 'micro': 6, 'minor': 3}, 'type': 'CPython', 'executable': '/usr/bin/python', 'version_info': [3, 6, 3, 'final', 0], 'has_sslcontext': True}}

# Generated at 2022-06-23 01:32:38.772706
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert getattr(PythonFactCollector, 'name') is not None
    assert getattr(PythonFactCollector, '_fact_ids') is not None
    assert getattr(PythonFactCollector, 'collect') is not None

# Generated at 2022-06-23 01:32:47.406349
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()

    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']

    assert 'major' in result['python']['version']
    assert 'minor' in result['python']['version']
    assert 'micro' in result['python']['version']
    assert 'releaselevel' in result['python']['version']
    assert 'serial' in result['python']['version']

# Generated at 2022-06-23 01:32:57.941530
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    if sys.version_info[0] == 2:
        py_ver = sys.version_info[0:3]
    else:
        py_ver = sys.version_info[0:2]

    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc.priority == 10
    assert pfc._fact_ids == set()
    assert pfc.collect.__doc__ == 'Get Python Facts'

    # Test results
    result = pfc.collect(collected_facts={})
    assert not isinstance(result, dict)

    py_fact_dict = result['python']
    assert isinstance(py_fact_dict, dict)
    assert 'version' in py_fact_dict
    py_ver_dict = py_fact_dict['version']

# Generated at 2022-06-23 01:33:04.443492
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    python = PythonFactCollector()
    assert isinstance(python, PythonFactCollector)
    assert isinstance(python, BaseFactCollector)
    assert hasattr(python, 'name')
    assert hasattr(python, '_fact_ids')
    assert hasattr(python, 'collect')


# Generated at 2022-06-23 01:33:07.427309
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert isinstance(python_fact_collector._fact_ids, set)

# Generated at 2022-06-23 01:33:10.308097
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'
    assert PythonFactCollector._fact_ids == set()
    assert not hasattr(PythonFactCollector, '_cache')


# Generated at 2022-06-23 01:33:15.617345
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:33:17.093937
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-23 01:33:20.474238
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert python_fact.name == 'python'
    assert python_fact._fact_ids == set()

# Generated at 2022-06-23 01:33:30.081536
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    collector = PythonFactCollector()
    collected_facts = collector.collect()

    assert collected_facts["python"]["version_info"] == list(sys.version_info)
    assert collected_facts["python"]["version"]["major"] == sys.version_info[0]
    assert collected_facts["python"]["version"]["minor"] == sys.version_info[1]
    assert collected_facts["python"]["version"]["micro"] == sys.version_info[2]
    assert collected_facts["python"]["version"]["releaselevel"] == sys.version_info[3]
    assert collected_facts["python"]["version"]["serial"] == sys.version_info[4]
    assert collected_facts["python"]["executable"] is not None

# Generated at 2022-06-23 01:33:40.915153
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import mock
    import os

    class Mock_create_default_context(mock.MagicMock):
        pass

    class Mock_SSLContext(mock.MagicMock):
        pass

    module = mock.MagicMock()
    module.params = {}
    collected_facts = {}

    # If we don't have ssl module, _collect_python_info method should
    # return None. Also, we will not have sys.subversion attribute in case
    # of PyPy.
    with mock.patch('ansible.module_utils.facts.collector.PythonFactCollector._collect_python_info'):
        with mock.patch.object(sys, 'subversion', None):
            instance = PythonFactCollector(module=module, collected_facts=collected_facts)
            result = instance.collect()


# Generated at 2022-06-23 01:33:45.874270
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    m = PythonFactCollector()
    m._collector_name = 'python'
    m._collector_class = 'PythonFactCollector'
    m._fact_ids = set()
    m.name = 'python'
    m.all_facts = dict()
    m.module = {'debug': True}

# Generated at 2022-06-23 01:33:46.448847
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:33:48.184788
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj

# Generated at 2022-06-23 01:33:50.410992
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector(None, None)
    res = py_fact_collector.collect()
    print(res)

# Generated at 2022-06-23 01:33:56.999430
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector.fact_ids == []
    assert PythonFactCollector._fact_ids == set()
    assert PythonFactCollector.fact_subset == {}

    p = PythonFactCollector()
    assert p.name == 'python'
    assert p.fact_ids == []
    assert p._fact_ids == set()
    assert p.fact_subset == {}

# Unit test the collect function of the class PythonFactCollector

# Generated at 2022-06-23 01:33:58.701615
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:34:01.880100
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    my_collector = PythonFactCollector()
    assert my_collector.name == 'python'

# Generated at 2022-06-23 01:34:07.126182
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts import collector

    assert isinstance(collector.get_collector('python'), PythonFactCollector)
    assert isinstance(collector.get_collector('PythonFactCollector'), PythonFactCollector)

# Generated at 2022-06-23 01:34:08.957977
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.collect()['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:34:18.171816
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert len(python_facts['python']['version_info']) == 5
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)

# Generated at 2022-06-23 01:34:26.995300
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS

# Generated at 2022-06-23 01:34:32.294961
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Create a Test PythonFactCollector object
    python_fact_collector = PythonFactCollector()

    # check name is set correctly
    assert python_fact_collector.name == 'python'

    # check fact_ids is set correctly
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:34:41.665898
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    py_facts = PythonFactCollector().collect()

    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_facts['python']['version']['serial'] == sys.version_info[4]
    assert py_facts['python']['version_info'] == list(sys.version_info)
    assert py_facts['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:34:44.606663
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  collector = PythonFactCollector()
  results = collector.collect()
  print (results)
  #assert len(results.keys()) == 1, results.keys()
  #assert results['ansible_python'] == dict, results 


# Generated at 2022-06-23 01:34:45.849194
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f.name == 'python'
    assert f._fact_ids == set()

# Generated at 2022-06-23 01:34:47.198607
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert(collector.name == 'python')
    assert(collector._fact_ids == set())



# Generated at 2022-06-23 01:34:48.300987
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pcol = PythonFactCollector()
    assert pcol.name == 'python'

# Generated at 2022-06-23 01:34:49.559476
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p

# Generated at 2022-06-23 01:34:55.651673
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Unit tests for PythonFactCollector class."""
    # Create a PythonFactCollector
    p = PythonFactCollector()
    # Check if it is an instance of BaseFactCollector
    assert isinstance(p, BaseFactCollector)
    # Check if name attribute is 'python'
    assert p.name == 'python'
    # Check if _fact_ids is a set
    assert isinstance(p._fact_ids, set)



# Generated at 2022-06-23 01:34:58.259235
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    assert python_collector.collect() is not None

# Generated at 2022-06-23 01:35:00.437512
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()
    assert type(pyfc) is PythonFactCollector
    assert pyfc.name == 'python'

# Generated at 2022-06-23 01:35:08.896468
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test code goes here.
    from ansible.module_utils.facts import pytest_utils

    # This is the call we will be testing.
    c = PythonFactCollector()
    facts = c.collect()

    # The variable facts is a dictionary.
    # The keys of this dictionary are defined by the Ansible rules.
    # The values of the dictionary are the facts we are testing.
    # The keys of this dictionary are defined by the Ansible rules
    # in the file lib/ansible/module_utils/facts/facts.py
    pytest_utils.assert_fact_keys_are_defined(facts)

    # This is the expected result.
    # The result consists of:
    # - A dictionary
    # - A key with the name "python"
    # - The value of the key "python" is a dictionary
   

# Generated at 2022-06-23 01:35:19.683867
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    p_facts = p.collect()
    # Asserting presence of key
    assert 'python' in p_facts
    # Asserting type
    assert isinstance(p_facts['python'], dict)

    major = p_facts['python']['version']['major']
    minor = p_facts['python']['version']['minor']
    micro = p_facts['python']['version']['micro']
    releaselevel = p_facts['python']['version']['releaselevel']
    serial = p_facts['python']['version']['serial']
    executable = p_facts['python']['executable']
    version_info = p_facts['python']['version_info']

# Generated at 2022-06-23 01:35:21.009017
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)

# Generated at 2022-06-23 01:35:23.260776
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_python_facts = PythonFactCollector()
    assert test_python_facts is not None
    test_python_facts.collect(collected_facts={})

# Generated at 2022-06-23 01:35:34.817012
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert 'python' in result
    assert type(result['python']) is dict
    assert 'version' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'type' in result['python']
    assert 'major' in result['python']['version']
    assert 'minor' in result['python']['version']
    assert 'micro' in result['python']['version']
    assert 'releaselevel' in result['python']['version']
    assert 'serial' in result['python']['version']

# Generated at 2022-06-23 01:35:37.890915
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    assert pyfc.collect()['python']['executable'].endswith('/python'), 'wrong python executable'

# Generated at 2022-06-23 01:35:40.163718
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-23 01:35:44.005351
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == {'python'}


# Generated at 2022-06-23 01:35:45.171689
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    result = PythonFactCollector()
    assert result.name is not None

# Generated at 2022-06-23 01:35:49.023082
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:35:51.226307
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert python_fact.name == 'python'
    assert python_fact._fact_ids == set()

# Generated at 2022-06-23 01:35:52.878946
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector(None)
    assert pfc.collect()['python']['type'] == 'CPython'

# Generated at 2022-06-23 01:35:56.745765
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert isinstance(PythonFactCollector._fact_ids, set)
    assert isinstance(PythonFactCollector._fact_ids, set)
    assert callable(PythonFactCollector.collect)

# Generated at 2022-06-23 01:36:07.896932
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Testing PythonFactCollector class method collect
    '''
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector, CollectorFailure

    class test_PythonFactCollector(PythonFactCollector):
        _fact_ids = set(['python'])
        def __init__(self, collected_facts=None):
            self.collected_facts = collected_facts
            self.fail = False

        def _collect(self, module):
            if self.fail:
                raise CollectorFailure

            return dict(python={'a': 'b'})

    with Collector.fact_cache as cache:
        cache.clear()
        py_fact_collector = test_PythonFactCollector()

        assert not py_fact_collector.collected_facts


# Generated at 2022-06-23 01:36:09.560370
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)
    assert isinstance(PythonFactCollector.collect(), dict)

# Generated at 2022-06-23 01:36:12.399014
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-23 01:36:18.408172
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact = fact_collector.collect()
    assert fact['python']['version']['major'] == sys.version_info[0]
    if ('implementation' in dir(sys) and hasattr(sys.implementation, 'name')):
        assert fact['python']['type'] == sys.implementation.name
    else:
        try:
            assert fact['python']['type'] == sys.subversion[0]
        except AttributeError:
            assert fact['python']['type'] is None

# Generated at 2022-06-23 01:36:24.936449
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact = fact_collector.collect()
    assert fact['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert fact['python']['version_info'] == list(sys.version_info)
    assert fact['python']['executable'] == sys.executable
    assert fact['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:36:27.279761
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'
    assert PythonFactCollector()._fact_ids == set()


# Generated at 2022-06-23 01:36:38.257633
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()

    # Test whether collect method return type is dictionary.
    # We just verify keys in returned dictionary.
    result = python_collector.collect()
    assert isinstance(result, dict)

    # Test values in returned dictionary.
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info']

# Generated at 2022-06-23 01:36:41.916643
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()

    assert py_fc.name == 'python'
    assert isinstance(py_fc._fact_ids, set)


# Generated at 2022-06-23 01:36:46.702981
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Test facts_module.PythonFactCollector constructor'''
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:36:48.389815
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    n = PythonFactCollector()
    r = n.collect()

    print(r)

# Generated at 2022-06-23 01:36:57.037424
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
        }
    }

# Generated at 2022-06-23 01:36:58.508291
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:37:00.037668
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:37:02.082251
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f.name == 'python'
    assert len(f._fact_ids) == 0

# Generated at 2022-06-23 01:37:13.013323
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test collect method
    python_facts = PythonFactCollector(None).collect()
    assert 'python' in python_facts

    # Test version of Python

    if sys.version_info[0] < 3:
        assert python_facts['python']['version']['major'] == sys.version_info[0]
    else:
        assert python_facts['python']['version']['major'] == sys.version_info[0]

    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-23 01:37:20.670332
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    python_fact_collector = get_collector_instance(PythonFactCollector)
    python_fact_collector.collect()

    assert type(python_fact_collector.collect()) is dict
    assert 'version_info' in python_fact_collector.collect()['python']
    assert python_fact_collector.collect()['python']['executable'] is not None


# Generated at 2022-06-23 01:37:23.755219
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Unit test for constructor of class PythonFactCollector'''
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:37:32.918599
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import types
    #
    # Constructor test:
    #
    p = PythonFactCollector()
    assert(p)
    # print(p.name)
    #
    # Collect method test:
    #
    python_facts = p.collect()
    assert(python_facts)
    # print(json.dumps(python_facts))

    #
    # Verify version:
    #
    assert sys.version_info[0] == python_facts['python']['version']['major']
    assert sys.version_info[1] == python_facts['python']['version']['minor']
    assert sys.version_info[2] == python_facts['python']['version']['micro']

# Generated at 2022-06-23 01:37:36.103248
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    assert collector.collect()['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:37:41.574863
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_subversion = ('CPython', '', '')
    sys.subversion = python_subversion
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()
    assert python_facts['python']['type'] == 'CPython'



# Generated at 2022-06-23 01:37:43.679569
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x

# Generated at 2022-06-23 01:37:52.366940
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()

    assert facts == {
        'python': {
            'type': 'CPython',
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4],
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:38:02.306779
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    m_collected_facts = {}  # type: dict
    m = PythonFactCollector()
    m_ret = m.collect(collected_facts=m_collected_facts)
    assert type(m_ret) is dict
    assert 'python' in m_ret
    py_dict = m_ret['python']
    assert type(py_dict) is dict
    assert 'version' in py_dict
    assert 'version_info' in py_dict
    assert 'executable' in py_dict
    assert 'has_sslcontext' in py_dict
    assert 'type' in py_dict
    vdict = py_dict['version']
    assert type(vdict) is dict
    assert 'major' in vdict
    assert 'minor' in vdict
    assert 'micro' in vdict

# Generated at 2022-06-23 01:38:03.055842
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:38:05.176849
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert isinstance(x, PythonFactCollector)


# Generated at 2022-06-23 01:38:14.758446
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_facts = PythonFactCollector().collect()

    assert python_facts['python']['version'] == {
                                                 'major': sys.version_info[0],
                                                 'minor': sys.version_info[1],
                                                 'micro': sys.version_info[2],
                                                 'releaselevel': sys.version_info[3],
                                                 'serial': sys.version_info[4]
                                                }

    assert python_facts['python']['version_info'] == list(sys.version_info)

    assert python_facts['python']['executable'] == sys.executable

    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:38:25.034779
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector  = PythonFactCollector()
    fact_result = collector.collect()
    assert fact_result['python']['executable'] == sys.executable
    version_info = fact_result['python']['version']['version_info']
    assert version_info[0] == sys.version_info[0]
    assert version_info[1] == sys.version_info[1]
    assert version_info[2] == sys.version_info[2]
    assert version_info[3] == sys.version_info[3]
    assert version_info[4] == sys.version_info[4]
    minor = fact_result['python']['version']['minor']
    assert minor == sys.version_info[1]

# Generated at 2022-06-23 01:38:26.229669
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-23 01:38:27.932058
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:38:37.362865
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector

    # Create a PythonFactCollector object and call collect
    pyfc = PythonFactCollector()
    pyfc_output = pyfc.collect()
    pyfc_python_facts = pyfc_output['python']

    # Obtain Python facts using the Ansible module_utils.facts.collector API
    facts = collector.collect('all', 'python')
    python_facts = facts['python']
    del facts

    assert pyfc_python_facts['version'] == python_facts['version']
    assert pyfc_python_facts['version_info'] == python_facts['version_info']
    assert pyfc_python_facts['executable'] == python_facts['executable']
    assert pyfc_python_facts['has_sslcontext'] == HAS_SSLCONTEXT
    assert py

# Generated at 2022-06-23 01:38:38.494918
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:38:43.822986
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:38:46.533039
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert isinstance(pfc, PythonFactCollector)
    assert pfc.name == 'python'


# Generated at 2022-06-23 01:38:49.610037
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    c = PythonFactCollector()
    assert c.name is not None
    assert c._fact_ids is not None
    assert c._fact_ids == set()
    assert c.collect() is not None
    assert c.collect(module=None, collected_facts=None) is not None

# Generated at 2022-06-23 01:38:51.860967
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pF = PythonFactCollector()
    assert pF.name == 'python'
    assert pF._fact_ids == set()


# Generated at 2022-06-23 01:38:56.103625
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:38:58.388244
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    x._collect()

# Generated at 2022-06-23 01:39:02.416380
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:39:04.762457
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    collector = PythonFactCollector()
    collected_facts = collector.collect()
    assert collected_facts['python']['version_info'] == list(sys.version_info), "Ansible version is incorrect"

# Generated at 2022-06-23 01:39:07.910673
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector.collect()['python']

# Generated at 2022-06-23 01:39:16.227733
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    result = c.collect()

    assert type(result['python']['has_sslcontext']) == bool
    assert type(result['python']['version_info']) == list
    assert type(result['python']['version']['micro']) == int
    assert type(result['python']['version']['releaselevel']) == str
    assert type(result['python']['version']['serial']) == int
    assert type(result['python']['version']['major']) == int

# Generated at 2022-06-23 01:39:19.252788
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert py_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:39:28.931734
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    py_facts = pyfc.collect()

    assert type(py_facts['python']['version']['major']) is int
    assert type(py_facts['python']['version']['minor']) is int
    assert type(py_facts['python']['version']['micro']) is int
    assert type(py_facts['python']['version']['releaselevel']) is str
    assert type(py_facts['python']['version']['serial']) is int
    assert type(py_facts['python']['version_info']) is list
    assert type(py_facts['python']['version_info'][0]) is int
    assert type(py_facts['python']['version_info'][1]) is int