

# Generated at 2022-06-23 01:29:34.073564
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert python_fact.name == 'python'
    assert python_fact._fact_ids == set()


if __name__ == '__main__':
    test_PythonFactCollector()

# Generated at 2022-06-23 01:29:47.591515
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Requires pytest
    import test.units.modules.utils.facts as test_facts

    # Only run this test if we have SSLContext support
    if HAS_SSLCONTEXT:
        test_collector = test_facts.get_collector(PythonFactCollector)
        test_collector.populate()
        data = test_collector.get_facts()
        assert 'python' in data
        assert 'version' in data['python']
        assert 'version_info' in data['python']
        assert 'executable' in data['python']
        assert 'type' in data['python']
        assert 'has_sslcontext' in data['python']

# Generated at 2022-06-23 01:29:49.575886
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    assert p.collect()['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:29:59.706603
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts import collectors
    collectors.add_collector(PythonFactCollector())

    assert len(PythonFactCollector().collect()) == 1
    assert 'python' in PythonFactCollector().collect()
    assert 'version' in PythonFactCollector().collect()['python']
    assert sys.version_info[0] == PythonFactCollector().collect()['python']['version']['major']
    assert sys.version_info[1] == PythonFactCollector().collect()['python']['version']['minor']
    assert sys.version_info[2] == PythonFactCollector().collect()['python']['version']['micro']
    assert sys.version_info[3] == PythonFactCollector().collect()['python']['version']['releaselevel']

# Generated at 2022-06-23 01:30:06.686070
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts_dict = collector.collect()
    assert isinstance(facts_dict['python']["version_info"], list)
    assert facts_dict['python']['version_info'][0] == sys.version_info[0]
    assert isinstance(facts_dict['python']['version'], dict)
    assert isinstance(facts_dict['python']['has_sslcontext'], bool)
    assert isinstance(facts_dict['python']['executable'], str)
    if isinstance(sys.subversion, list):
        assert facts_dict['python']['type'] == sys.subversion[0]

# Generated at 2022-06-23 01:30:17.064352
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Make it possible to test this method standalone
    import sys
    sys.modules['ansible'] = type('module', (), {})()
    sys.modules['ansible.module_utils'] = type('module', (), {})()
    sys.modules['ansible.module_utils.facts'] = type('module', (), {})()
    import ansible.module_utils.facts.collector

    # Case 1:
    #   - sys.version_info is set
    #   - sys.executable is a string
    #   - sys.subversion is set
    # Result:
    #   - version_info is set to the value of sys.version_info
    #   - executable is set to the value of sys.executable
    #   - type is set to the value of sys.subversion[0]
    sys.version_info

# Generated at 2022-06-23 01:30:22.792959
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''
    Unit test for constructor of class PythonFactCollector
    '''

    # Instantiate PythonFactCollector and initialize the class variables
    python_fact_collector = PythonFactCollector()

    # Check the name and fact_vars
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()
    assert python_fact_collector._fact_class == dict

# Generated at 2022-06-23 01:30:26.588288
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert PythonFactCollector.name == 'python'
    assert collector.name == 'python'
    assert PythonFactCollector._fact_ids == set()
    assert collector._fact_ids == set()
    assert collector._fact_ids is not PythonFactCollector._fact_ids


# Generated at 2022-06-23 01:30:37.080081
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils import facts

    python_facts = PythonFactCollector(None, facts.Facts()).collect()['python']

    assert python_facts['version']['major'] == sys.version_info[0]
    assert python_facts['version']['minor'] == sys.version_info[1]
    assert python_facts['version']['micro'] == sys.version_info[2]
    assert python_facts['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['version']['serial'] == sys.version_info[4]

    assert python_facts['version_info'] == list(sys.version_info)
    assert python_facts['executable'] == sys.executable
    assert python_facts['has_sslcontext'] == HAS_SSLCON

# Generated at 2022-06-23 01:30:38.063458
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert python_fact.name == 'python'

# Generated at 2022-06-23 01:30:43.415866
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    result = py_collector.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'executable' in result['python']
    assert 'version_info' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-23 01:30:51.172847
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    py_fact_collector.collect()

    # Check that our Python version is correct
    assert py_fact_collector.collect().get('python', {}).get('version', {}).get('major') == sys.version_info[0]
    assert py_fact_collector.collect().get('python', {}).get('version', {}).get('minor') == sys.version_info[1]
    assert py_fact_collector.collect().get('python', {}).get('version', {}).get('micro') == sys.version_info[2]
    assert py_fact_collector.collect().get('python', {}).get('version', {}).get('releaselevel') == sys.version_info[3]

# Generated at 2022-06-23 01:30:54.023202
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()


# Generated at 2022-06-23 01:30:56.071408
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'
    assert 'python' in PythonFactCollector().collect()

# Generated at 2022-06-23 01:30:58.530185
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()
    assert hasattr(x, 'collect')


# Generated at 2022-06-23 01:31:02.671472
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Instantiate the class
    python_fact_collector = PythonFactCollector()

    # Assert the name of the class
    assert python_fact_collector.name == 'python'

    # Assert the fact_ids of the class
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:31:04.466671
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:31:16.372035
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector object
    p = PythonFactCollector(None)
    # Collect python facts
    facts = p.collect()

    # Assert that we have python facts
    assert 'python' in facts

    # Assert that we have the executable
    assert 'executable' in facts['python']

    # Assert that we have has_sslcontext
    assert 'has_sslcontext' in facts['python']

    # Assert that we have the version
    assert 'version' in facts['python']

    # Assert that we have the version_info
    assert 'version_info' in facts['python']

    # Assert that we have the type
    assert 'type' in facts['python']

    # Assert that the executable is str
    assert isinstance(facts['python']['executable'], str)

    # Ass

# Generated at 2022-06-23 01:31:22.648512
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    result = pc.collect()

    assert result['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-23 01:31:26.493118
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc.collect() == {'python': {'has_sslcontext': True, 'executable': '/usr/bin/python',
                                        'version_info': [2, 7, 5, 'final', 0],
                                        'version': {'releaselevel': 'final', 'micro': 5, 'minor': 7,
                                                    'major': 2, 'serial': 0}}}

# Generated at 2022-06-23 01:31:27.344883
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:31:30.397224
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()

    facts = c.collect()
    assert facts
    assert isinstance(facts, dict)
    assert facts['python']
    assert isinstance(facts['python'], dict)
    assert facts['python']['version']
    assert isinstance(facts['python']['version'], dict)
    assert facts['python']['version_info']
    assert isinstance(facts['python']['version_info'], list)
    assert facts['python']['executable']
    assert isinstance(facts['python']['executable'], basestring)

# Generated at 2022-06-23 01:31:33.822587
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test_collector = PythonFactCollector()
    assert test_collector.name == 'python'
    assert test_collector._fact_ids == set()

# Generated at 2022-06-23 01:31:36.897085
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:31:40.682825
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test_python_fact_collector = PythonFactCollector()
    assert test_python_fact_collector.name == 'python', "Collector name is wrong"
    assert isinstance(test_python_fact_collector._fact_ids, set), "_fact_ids should be a set"

# Generated at 2022-06-23 01:31:47.214366
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector(None)
    assert isinstance(pfc.collect(), dict)
    assert isinstance(pfc.collect()['python']['version'], dict)
    assert isinstance(pfc.collect()['python']['version_info'], list)
    assert isinstance(pfc.collect()['python']['executable'], str)
    assert isinstance(pfc.collect()['python']['has_sslcontext'], bool)
    assert isinstance(pfc.collect()['python']['type'], str) or pfc.collect()['python']['type'] == None

# Generated at 2022-06-23 01:31:57.039393
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-23 01:31:58.962816
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:32:00.977498
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    Test if the Python fact collector is created without any error.
    """
    collector = PythonFactCollector()
    return collector

# Generated at 2022-06-23 01:32:02.583785
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)


# Generated at 2022-06-23 01:32:07.027811
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import collections
    import mock

    # Create a mock module object
    module = mock.Mock()
    module.fail_json = mock.Mock(side_effect=Exception('fail_json error'))

    pfc = PythonFactCollector(module)

    # Test collect method with no facts
    pfc.collect(module=module)
    assert isinstance(pfc.collect(module=module), collections.MutableMapping)

# Generated at 2022-06-23 01:32:11.201392
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'python'
    assert fact_collector.collect() is not None

# Generated at 2022-06-23 01:32:18.037586
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = {
        'python': {
            'version': {
                'major': 3,
                'minor': 5,
                'micro': 0,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': list(sys.version_info),
            'executable': '/usr/bin/python3',
            'has_sslcontext': False,
            'type': 'CPython'
        }
    }
    assert facts == pc.collect()

# Generated at 2022-06-23 01:32:20.702336
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:32:28.553419
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'type': None,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    assert python_fact_collector.collect() == python_facts

# Generated at 2022-06-23 01:32:30.913610
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert facts is not None
    assert len(facts) > 0
    assert 'python' in facts

# Generated at 2022-06-23 01:32:39.568656
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    python_facts = {'python': {'executable': sys.executable,
                               'has_sslcontext': HAS_SSLCONTEXT,
                               'type': sys.subversion[0] if hasattr(sys, 'subversion') else sys.implementation.name,
                               'version': {'major': sys.version_info[0],
                                           'minor': sys.version_info[1],
                                           'micro': sys.version_info[2],
                                           'releaselevel': sys.version_info[3],
                                           'serial': sys.version_info[4]},
                               'version_info': list(sys.version_info)}}
    assert pfc.collect() == python_facts

# Generated at 2022-06-23 01:32:40.939726
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:32:50.001597
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    test_fact = python_fact.collect()
    assert test_fact['python']['version'] == {'major': sys.version_info[0],
                                              'minor': sys.version_info[1],
                                              'micro': sys.version_info[2],
                                              'releaselevel': sys.version_info[3],
                                              'serial': sys.version_info[4]}
    assert test_fact['python']['version_info'] == list(sys.version_info)
    assert test_fact['python']['executable'] == sys.executable
    assert test_fact['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert 'type' in test_fact['python']

# Generated at 2022-06-23 01:32:52.924907
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert sys.version_info[0] in fact_collector.collect()['python']['version'].values()

# Generated at 2022-06-23 01:33:00.607062
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['version']['major'] == sys.version_info[0], 'res: %s' % result
    assert result['python']['version']['minor'] == sys.version_info[1], 'res: %s' % result
    assert result['python']['version']['micro'] == sys.version_info[2], 'res: %s' % result
    assert result['python']['version']['releaselevel'] == sys.version_info[3], 'res: %s' % result
    assert result['python']['version']['serial'] == sys.version_info[4], 'res: %s' % result

# Generated at 2022-06-23 01:33:06.880596
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert sorted(python_fact_collector.collect().keys()) == ['python']
    assert 'version' in python_fact_collector.collect()['python']
    assert 'version_info' in python_fact_collector.collect()['python']
    assert 'executable' in python_fact_collector.collect()['python']


# Generated at 2022-06-23 01:33:09.020681
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc=PythonFactCollector()
    assert pfc.name == 'python'
    assert 'HAS_SSLCONTEXT' in globals()

# Generated at 2022-06-23 01:33:11.069559
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector.name == 'python'

# Generated at 2022-06-23 01:33:12.541351
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector is not None

# Generated at 2022-06-23 01:33:14.259629
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-23 01:33:19.103965
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert type(python_facts['python']['version']) == dict
    assert type(python_facts['python']['version_info']) == list
    assert type(python_facts['python']['executable']) == str

# Generated at 2022-06-23 01:33:28.989751
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS

# Generated at 2022-06-23 01:33:33.041324
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of FactsCollector
    fact_collector = PythonFactCollector()

    # Get the collect method of PythonFactCollector
    collect_method = fact_collector.collect

    # Call the method to generate the facts
    collect_method()

    # Check the facts were generated
    assert 'python' in fact_collector.collect()

# Generated at 2022-06-23 01:33:43.415510
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    collected_facts = {}
    ansible_facts = pfc.collect(collected_facts=collected_facts)
    assert 'python' in ansible_facts
    assert 'version' in ansible_facts['python']
    assert 'major' in ansible_facts['python']['version']
    assert 'minor' in ansible_facts['python']['version']
    assert 'micro' in ansible_facts['python']['version']
    assert 'releaselevel' in ansible_facts['python']['version']
    assert 'serial' in ansible_facts['python']['version']
    assert 'executable' in ansible_facts['python']
    assert 'type' in ansible_facts['python']

# Generated at 2022-06-23 01:33:45.696961
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()

    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:33:51.155271
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_obj = PythonFactCollector()
    test_obj.collect()
    python_facts = test_obj.collect()
    # test_obj.collect() raises AttributeError
    # if any of sys.version_info, sys.version, sys.executable
    # or sys.subversion do not exist
    assert isinstance(python_facts, dict)

# Generated at 2022-06-23 01:33:59.435215
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    obj = PythonFactCollector()
    facts = obj.collect()
    assert facts == {'python': {
      'has_sslcontext': HAS_SSLCONTEXT,
      'version': {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    },
      'version_info': list(sys.version_info),
      'executable': sys.executable,
      'type': sys.implementation.name}}

# Generated at 2022-06-23 01:34:08.313599
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    fact_data = fact_collector.collect()
    assert "python" in fact_data
    assert "version" in fact_data["python"]
    assert "major" in  fact_data["python"]["version"]
    assert "minor" in  fact_data["python"]["version"]
    assert "micro" in  fact_data["python"]["version"]
    assert "releaselevel" in  fact_data["python"]["version"]
    assert "serial" in  fact_data["python"]["version"]
    assert "version_info" in  fact_data["python"]


# Generated at 2022-06-23 01:34:11.084036
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == "python"
    assert len(python_facts._fact_ids) == 0


# Generated at 2022-06-23 01:34:20.970728
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    collector = PythonFactCollector()
    my_facts = collector.collect(collected_facts=dict())
    assert isinstance(my_facts, dict)
    assert type(my_facts['python']['version']) is dict
    assert type(my_facts['python']['version_info']) is list
    assert type(my_facts['python']['version_info'][0]) is int
    assert type(my_facts['python']['executable']) is str
    assert type(my_facts['python']['has_sslcontext']) is bool
    try:
        assert type(my_facts['python']['type']) is str
    except KeyError:
        pass

# Generated at 2022-06-23 01:34:22.194633
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'

# Generated at 2022-06-23 01:34:26.497477
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    python_facts = python_collector.collect()
    assert 'python' in python_facts
    python_facts = python_facts['python']
    assert 'version' in python_facts
    assert 'version_info' in python_facts
    assert 'executable' in python_facts
    assert 'type' in python_facts
    assert 'has_sslcontext' in python_facts

# Generated at 2022-06-23 01:34:28.637713
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector_class_obj = PythonFactCollector()
    assert python_fact_collector_class_obj.name is not None

# Generated at 2022-06-23 01:34:30.859156
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()

    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-23 01:34:36.119749
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Check if instance can be created
    collector = PythonFactCollector()

    # Check the name property
    assert collector.name == 'python'

    # Check the _fact_ids property
    assert collector._fact_ids == set()

    # Check if instance can be created with a module
    collector = PythonFactCollector(module=5)
    assert collector.module == 5

# Generated at 2022-06-23 01:34:39.332872
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()



# Generated at 2022-06-23 01:34:41.741390
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()

    assert len(result.keys()) == 1
    assert 'python' in result.keys()

    return

# Generated at 2022-06-23 01:34:44.361345
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  """ Unit test for method collect of class PythonFactCollector
  """
  fact_collector = PythonFactCollector()
  fact_collector.collect()
  assert fact_collector.name == 'python'

# Generated at 2022-06-23 01:34:50.695697
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts =  {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name if hasattr(sys, 'implementation') else sys.subversion[0],
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }
    assert PythonFactCollector().collect() == python_facts

# Generated at 2022-06-23 01:34:53.480234
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert "python" in python_fact_collector._fact_ids

# Generated at 2022-06-23 01:34:55.776943
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'

# Generated at 2022-06-23 01:34:59.969104
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None
    assert python_fact_collector.name == "python"
    assert len(python_fact_collector._fact_ids) == 0

# Generated at 2022-06-23 01:35:01.654839
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    o = PythonFactCollector()
    assert o.name == 'python'
    assert o._fact_ids == set()

# Generated at 2022-06-23 01:35:04.010945
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector.collect_fn_name == 'python.collect'
    assert collector.fact_ids == set()

# Generated at 2022-06-23 01:35:05.209690
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    py_fc.collect()

# Generated at 2022-06-23 01:35:12.617980
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    python_facts = facts['python']
    assert isinstance(python_facts, dict)
    assert 'type' in python_facts
    assert python_facts['type'] is not None
    assert 'version' in python_facts
    version = python_facts['version']
    assert isinstance(version, dict)
    assert isinstance(version['major'], int)
    assert isinstance(version['minor'], int)
    assert isinstance(version['micro'], int)
    assert isinstance(version['releaselevel'], str)
    assert isinstance(version['serial'], int)
    assert 'version_info' in python_facts

# Generated at 2022-06-23 01:35:22.823479
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector object
    pfc = PythonFactCollector()

    # Create a dictionary to validate that collect returns
    expected_result = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    # Check if type key exists in result

# Generated at 2022-06-23 01:35:27.045348
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    fact_collector = PythonFactCollector

    # Create a class instance
    pc = fact_collector()
    # Example of collected facts
    collected_facts = {'ansible_python_version': '2.6'}

    # Test method collect of class PythonFactCollector
    assert pc.collect(collected_facts=collected_facts)

# Generated at 2022-06-23 01:35:30.178871
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == "python"
    assert python_facts._fact_ids == set()


# Generated at 2022-06-23 01:35:35.413748
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()

    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:35:42.087100
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()
    assert 'python' in facts
    assert 'version' in facts["python"]
    assert 'type' in facts["python"]
    assert 'version_info' in facts["python"]
    assert 'executable' in facts["python"]
    assert 'has_sslcontext' in facts["python"]


# Generated at 2022-06-23 01:35:44.158360
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert 'PythonFactCollector' in repr(collector)
    assert 'python' in collector._fact_ids

# Generated at 2022-06-23 01:35:45.588984
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:35:47.077657
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:35:48.869100
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:35:55.105415
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    The method collect of the class PythonFactCollector is being tested here.
    In the below test data, we are checking the type and version of python
    interpreter and the values being passed as parameters to the module.
    '''
    assert PythonFactCollector().collect() == {'python':
        {'type': 'CPython',
         'version_info': [2, 7, 13, 'final', 0],
         'version': {'releaselevel': 'final', 'major': 2, 'minor': 7,
                     'micro': 13, 'serial': 0},
         'executable': '/usr/bin/python',
         'has_sslcontext': False}}

# Generated at 2022-06-23 01:36:00.539093
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

if __name__ == '__main__':
    # Unit test for class PythonFactCollector
    test_PythonFactCollector()

# Generated at 2022-06-23 01:36:10.709410
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect()."""

    from ansible.module_utils.facts import collector
    # Create a PythonFactCollector object.
    pfc = collector.python
    # Call method collect of PythonFactCollector object.
    # No parameters are passed.
    # Returned value is assigned to python_facts_collect
    # and contains Ansible Facts.
    python_facts = pfc.collect()
    assert type(python_facts) is dict
    assert len(python_facts) >= 1
    assert python_facts.get('python') is not None
    assert type(python_facts.get('python')) is dict
    py_ver_dict = python_facts['python']['version']
    assert py_ver_dict.get('major') is not None

# Generated at 2022-06-23 01:36:12.809626
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    result = fc.collect()
    assert result['python']['executable'].endswith('python')

# Generated at 2022-06-23 01:36:19.765850
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    result = pfc.collect()

    assert result
    assert 'python' in result
    assert 'version' in result['python']
    assert isinstance(result['python']['version'], dict)
    assert 'has_sslcontext' in result['python']
    assert isinstance(result['python']['has_sslcontext'], bool)

# Generated at 2022-06-23 01:36:23.027475
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()
    assert callable(python_collector.collect)

# Generated at 2022-06-23 01:36:34.134848
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    collected_facts = {}
    python_facts = python_collector.collect(collected_facts=collected_facts)

    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:36:35.736215
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()

    assert pfc.name == "python"
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:36:37.027638
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert hasattr(PythonFactCollector(), 'collect')
    assert hasattr(PythonFactCollector(), 'name')

# Generated at 2022-06-23 01:36:38.227307
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test PythonFactCollector constructor"""
    python_fc = PythonFactCollector()
    assert python_fc

# Generated at 2022-06-23 01:36:49.093497
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:36:50.988188
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    py = PythonFactCollector()
    assert py.name == 'python'

# Generated at 2022-06-23 01:36:56.237275
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test collect()
    """
    pfc = PythonFactCollector()
    assert hasattr(pfc, 'name')
    assert hasattr(pfc, '_fact_ids')
    assert hasattr(pfc, 'collect')
    assert isinstance(pfc.collect(),dict)

# Generated at 2022-06-23 01:36:58.138578
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = PythonFactCollector()
    assert module.name == 'python'
    assert module._fact_ids is not None

# Generated at 2022-06-23 01:37:02.778261
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_facts = PythonFactCollector()

    assert py_facts.name == 'python'
    assert py_facts._fact_ids == set()



# Generated at 2022-06-23 01:37:10.506470
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # make the module available for import
    sys.modules['ansible'] = object()

    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    # Initialize a PythonFactCollector instance
    pfc = PythonFactCollector()

    # Test when the module is None
    results = pfc.collect(module=None, collected_facts=None)
    assert isinstance(results, dict)
    assert 'python' in results
    assert isinstance(results['python'], dict)

# Generated at 2022-06-23 01:37:13.355327
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    with open('/dev/null') as fd:
        assert isinstance(PythonFactCollector(fd), PythonFactCollector)

# Generated at 2022-06-23 01:37:17.085076
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert isinstance(pfc._fact_ids, set)
    # Check if collect is defined to avoid pylint errors
    pfc.collect()

# Generated at 2022-06-23 01:37:19.521128
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
  p = PythonFactCollector()
  print(p.name)
  print(p._fact_ids)
  print(p.collect())

# Generated at 2022-06-23 01:37:29.761883
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Set-up mock module
    module = type('', (), {
        'params': {
            'gather_subset': [],
            'gather_timeout': 10,
            'filter': '*'
        }
    })()

    # Get collector
    collector = PythonFactCollector(module)

    # Check setup
    assert collector.name == 'python'
    assert collector._fact_ids == set()
    assert collector.priority == 10
    assert collector.module == module

    # Check that there are no errors with the collector
    facts = collector.collect()

# Generated at 2022-06-23 01:37:32.169262
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Create an instance of the PythonFactCollector
    python_fact_collector = PythonFactCollector()
    # Assert name of PythonFactCollector
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:37:34.092702
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert 'python' == pfc.name

# Generated at 2022-06-23 01:37:43.482293
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    expected_result = {'python' : {
        'version': {
            'major': 2,
            'minor': 7,
            'micro': 12,
            'releaselevel': 'final',
            'serial': 0
            },
        'version_info': [2, 7, 12, 'final', 0],
        'executable': u'/usr/bin/python',
        'has_sslcontext': True,
        'type': 'CPython'
        }
    }
    assert expected_result == collector.collect()

# Generated at 2022-06-23 01:37:47.767003
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test = PythonFactCollector()
    assert test.name == 'python'
    assert test.collect()['python'].keys() == ['version',
                                               'version_info',
                                               'executable',
                                               'has_sslcontext',
                                               'type']

# Generated at 2022-06-23 01:37:52.919048
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Calling method collect must set module._fact_ids
    # as well as return a dictionary of facts
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert 'python' in pfc._fact_ids
    assert isinstance(facts, dict)

# Generated at 2022-06-23 01:37:56.386074
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_module = sys.modules['ansible.module_utils.facts.collectors.python.PythonFactCollector']
    facts_obj = facts_module.PythonFactCollector()
    assert 'python' == facts_obj.name

# Generated at 2022-06-23 01:37:58.149128
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    result = c.collect()
    assert 'python' in result

# Generated at 2022-06-23 01:38:07.480978
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    output = p.collect()
    assert isinstance(output['python']['version']['major'], int)
    assert isinstance(output['python']['version']['minor'], int)
    assert isinstance(output['python']['version']['micro'], int)
    assert isinstance(output['python']['version']['releaselevel'], str)
    assert isinstance(output['python']['version']['serial'], int)
    assert isinstance(output['python']['version_info'], list)
    assert isinstance(output['python']['executable'], str)
    assert isinstance(output['python']['has_sslcontext'], bool)
    assert isinstance(output['python']['type'], str)

# Generated at 2022-06-23 01:38:16.740497
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import types
    import sys

    class MockModule():
        def __init__(self):
            self.params = {}

    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-23 01:38:24.172454
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc.collect(collected_facts={}) == {'python': {'version': {'major': 3, 'minor': 5, 'micro': 2,
                                                                 'releaselevel': 'final', 'serial': 0},
                                                        'version_info': [3, 5, 2, 'final', 0],
                                                        'executable': '/usr/bin/python3.5',
                                                        'has_sslcontext': True, 'type': None}}, \
        "Did not initialize the PythonFactCollector class correctly"

# Generated at 2022-06-23 01:38:30.749895
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Testing list and dict
    from facts.collectors.python import PythonFactCollector
    c = PythonFactCollector()
    module = None
    collected_facts = None
    results = c.collect(module, collected_facts)
    assert 'python' in results
    assert 'has_sslcontext' in results['python']
    assert 'version' in results['python']
    assert 'version_info' in results['python']
    assert 'executable' in results['python']
    assert 'type' in results['python']

# Generated at 2022-06-23 01:38:31.916957
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'

# Generated at 2022-06-23 01:38:41.065030
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ Test PythonFactCollector.collect method. """
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.python import PythonFactCollector
    from ansible.module_utils.facts.collector.python import HAS_SSLCONTEXT

    # Create a PythonFactCollector instance to test its collect method
    python_fact_collector = get_collector_instance(PythonFactCollector)

    # Create empty PythonFactCollector.collected_facts
    python_fact_collector.collect(collected_facts={})

    # Create expected Python fact

# Generated at 2022-06-23 01:38:42.821096
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    fact_collector_object = PythonFactCollector()

    assert fact_collector_object is not None
    assert fact_collector_object.name == 'python'
    assert not fact_collector_object._fact_ids

# Generated at 2022-06-23 01:38:53.505744
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # mock data
    class mock_ansible_module:
        def __init__(self):
            self.params = {}

    class mock_ansible_module_instance:
        def __init__(self):
            self.params = {
                'gather_subset': ['!all', '!min'],
                'gather_timeout': 10
            }

    import sys
    import types
    mock_ansible_module_instance.params = {
        'gather_subset': ['!all', '!min'],
        'gather_timeout': 10
    }
    mock_ansible_module_instance.fail_json = lambda self, msg: sys.exit(1)

    python_fact_collector = PythonFactCollector()

# Generated at 2022-06-23 01:38:56.882509
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert type(python_fact_collector) == PythonFactCollector
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:38:58.488468
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:39:09.490318
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    # Test that a dictionary is returned with the right key and the
    # version information of the version of python used to run the test.
    facts = collector.collect()
    assert type(facts) is dict
    assert facts.keys() == ['python']
    assert facts['python'].keys() == ['version', 'version_info', 'executable', 'type', 'has_sslcontext']
    assert facts['python']['version'].keys() == ['major', 'minor', 'micro', 'releaselevel', 'serial']
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version

# Generated at 2022-06-23 01:39:17.849865
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test method collect of class PythonFactCollector
    """
    # Create test data for method collect of class PythonFactCollector
    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-23 01:39:23.546023
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact = PythonFactCollector()
    collected_facts = py_fact.collect()
    assert collected_facts['python']['version']['major'] == 3
    assert collected_facts['python']['version_info'][0] == 3
    assert collected_facts['python']['has_sslcontext'] is True
    assert collected_facts['python']['type'] == 'CPython'

# Generated at 2022-06-23 01:39:31.838175
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test if all elements of the new facts are present
    result = PythonFactCollector().collect()
    assert set(result.keys()) == set([
        'python'
    ])
    assert set(result['python'].keys()) == set([
        'version',
        'version_info',
        'has_sslcontext',
        'executable',
        'type'
    ])
    assert set(result['python']['version'].keys()) == set([
        'major',
        'micro',
        'minor',
        'releaselevel',
        'serial'
    ])

    version_info = result['python']['version_info']
    version = result['python']['version']