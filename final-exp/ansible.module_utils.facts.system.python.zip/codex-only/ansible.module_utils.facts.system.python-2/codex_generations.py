

# Generated at 2022-06-23 01:29:32.769556
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert isinstance(collector.collect(), dict)

# Generated at 2022-06-23 01:29:40.181627
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    ret = pc.collect()
    assert(type(ret) == dict)
    assert('python' in ret)
    assert('version' in ret['python'])
    assert('major' in ret['python']['version'])
    assert('minor' in ret['python']['version'])
    assert('micro' in ret['python']['version'])
    assert('releaselevel' in ret['python']['version'])
    assert(ret['python']['version']['major'] == sys.version_info[0])
    assert(ret['python']['version']['minor'] == sys.version_info[1])
    assert(ret['python']['version']['micro'] == sys.version_info[2])

# Generated at 2022-06-23 01:29:50.829554
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = dict()
    python_fact_collector = PythonFactCollector()
    collected_facts = dict()
    # Test the returned value is a dict object
    assert isinstance(python_fact_collector.collect(module, collected_facts), dict)
    # Test the returned value has the collected value
    # This is a sample of the returned value:
    #    python: {
    #        type: 'CPython',
    #        version_info: [
    #            3,
    #            4,
    #            0,
    #            'final',
    #            0
    #        ],
    #        executable: '/usr/bin/python',
    #        version: {
    #            major: 3,
    #            minor: 4,
    #            micro: 0,
    #            releaselevel: 'final',

# Generated at 2022-06-23 01:29:52.898793
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = PythonFactCollector().collect()
    assert facts['python']
    assert facts['python'].get('type')

# Generated at 2022-06-23 01:29:58.757381
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p.collector == {'python': {'type': 'CPython', 'has_sslcontext': True, 'executable': '/usr/local/bin/python2.7', 'version_info': [2, 7, 6, 'final', 0], 'version': {'micro': 6, 'releaselevel': 'final', 'serial': 0, 'minor': 7, 'major': 2}}}

# Generated at 2022-06-23 01:30:07.166177
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    # Instantiate the module
    python_fact_collector = PythonFactCollector(module=module)

    # Collect python facts
    python_facts = python_fact_collector.collect()

    # Test to make sure we have all of the desired facts
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version

# Generated at 2022-06-23 01:30:16.590350
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.python import PythonFactCollector
    from ansible.module_utils.facts.collector.python import HAS_SSLCONTEXT

    # The name PythonFactCollector should match the filename for the
    # unit test to pass
    assert PythonFactCollector.name == 'python'
    # Get PythonFactCollector class
    python_collector = get_collector_instance(PythonFactCollector)

    # Test __init__ method
    assert python_collector.name == PythonFactCollector.name

    # Test collect() method

# Generated at 2022-06-23 01:30:26.531539
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-23 01:30:33.493749
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], str)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-23 01:30:35.268912
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f
    assert f.name == 'python'
    assert f._fact_ids == set(['python'])

# Generated at 2022-06-23 01:30:37.035270
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test = PythonFactCollector()
    assert test is not None
    assert test.name == 'python'

# Generated at 2022-06-23 01:30:39.106830
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert len(p._fact_ids) == 0

# Generated at 2022-06-23 01:30:40.286824
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    pf.collect()

# Generated at 2022-06-23 01:30:44.172784
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector.name == 'python'


# Generated at 2022-06-23 01:30:47.868225
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert type(python_fact_collector) == PythonFactCollector
    assert python_fact_collector._fact_ids == set()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:30:50.889392
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'

# Generated at 2022-06-23 01:31:00.478837
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = collector.collect()
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'major' in collected_facts['python']['version']
    assert 'minor' in collected_facts['python']['version']
    assert 'micro' in collected_facts['python']['version']
    assert 'releaselevel' in collected_facts['python']['version']
    assert 'serial' in collected_facts['python']['version']
    assert 'version_info' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'has_sslcontext' in collected_facts['python']
    assert 'type' in collected_facts['python']

# Generated at 2022-06-23 01:31:01.673061
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-23 01:31:03.053001
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector is not None

# Generated at 2022-06-23 01:31:08.095363
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    python_facts = facts['python']
    assert 'executable' in python_facts
    assert 'has_sslcontext' in python_facts
    assert 'version' in python_facts
    assert 'type' in python_facts

# Generated at 2022-06-23 01:31:09.283579
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x

# Generated at 2022-06-23 01:31:09.902137
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:31:18.513458
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Note: PythonFactCollector assumes it is being invoked from inside a python module, 
    # so we need to fake that up for the unit test.

    class FakeModule(object):
        def __init__(self, module_name):
            self.module_name = module_name
            self.fail_json = lambda **kwargs: False

    python_fact_collector = PythonFactCollector()
    module = FakeModule('foo')

    facts = python_fact_collector.collect(module)
    assert (facts['python']['version'])
    assert (facts['python']['version_info'])
    assert (facts['python']['executable'])
    assert ('type' in facts['python'])

# Generated at 2022-06-23 01:31:21.468710
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect(collected_facts=None)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)

# Generated at 2022-06-23 01:31:23.228296
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == "python"


# Generated at 2022-06-23 01:31:32.931357
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector_obj = PythonFactCollector()
    collected_facts = {}
    result = collector_obj.collect(collected_facts)
    expected_result = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:31:37.214252
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test collect() behavior of PythonFactCollector."""

    c = PythonFactCollector()
    result = c.collect()

    assert 'python' in result
    assert 'version' in result['python']
    assert result['python']['type'] in ['CPython', 'PyPy', 'IronPython', None]

# Generated at 2022-06-23 01:31:39.312445
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert len(x._fact_ids) == 0

# Generated at 2022-06-23 01:31:45.064903
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj.collected_facts == {}
    assert obj.priority == 80

    # Check if there is any method's name which startswith 'collect'
    # Return True if there is, otherwise False
    assert any(method for method in dir(obj) if method.startswith('collect'))
    assert not hasattr(obj, '_platform')

    assert obj.collect_platform_facts() == {}

# Generated at 2022-06-23 01:31:50.943241
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test with valid parameters
    x = PythonFactCollector()
    assert x.name == 'python'

    # Test with invalid parameters
    y = PythonFactCollector('fake')
    assert y.name == 'python'

# Generated at 2022-06-23 01:31:53.181855
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-23 01:32:03.000801
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    import sys

    # Create an instance of class PythonFactCollector
    python_fact_collector = PythonFactCollector()

    # dict that should be returned by collect method
    ans_dict = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'type': python_fact_collector._get_python_type()
        }
    }

    # compare collected

# Generated at 2022-06-23 01:32:07.444758
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert 'version_info' in collected_facts['python']

# Generated at 2022-06-23 01:32:10.867561
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert ('python' == fact_collector.name)
    assert ('python' in fact_collector._fact_ids)


# Generated at 2022-06-23 01:32:13.072414
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert isinstance(obj, PythonFactCollector)

# Generated at 2022-06-23 01:32:17.523812
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-23 01:32:27.312018
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instance the fact collector
    fact_collector = PythonFactCollector()

    # Get the python fact
    python = fact_collector.collect()

    # Assert that all the keys are present
    py_keys = [
        'python',
        'python.version',
        'python.version.releaselevel',
        'python.version.major',
        'python.version.minor',
        'python.version.micro',
        'python.version.serial',
        'python.version_info',
        'python.executable',
        'python.type',
        'python.has_sslcontext'
    ]

    for key in py_keys:
        assert key in python, "The key %s is not in the python fact" % key

    # Assert each key from python.version has the correct values

# Generated at 2022-06-23 01:32:29.927124
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector.python import PythonFactCollector
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-23 01:32:33.127177
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    # Check if python facts are present, other facts are not present and
    # no exception was raised
    assert 'python' in python_facts
    assert len(python_facts) == 1

# Generated at 2022-06-23 01:32:41.781293
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Returns a dictionary with the value of the specific
    Python version.
    """

    python_facts = PythonFactCollector().collect()
    try:
        assert(python_facts['python']['version']['major'] == sys.version_info[0])
        assert(python_facts['python']['version']['minor'] == sys.version_info[1])
        assert(python_facts['python']['version']['micro'] == sys.version_info[2])
        assert(python_facts['python']['version']['releaselevel'] == sys.version_info[3])
        assert(python_facts['python']['version']['serial'] == sys.version_info[4])
    except:
        print("Error in PythonFactCollector.collect()")
        return False
   

# Generated at 2022-06-23 01:32:45.385829
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    ansible_facts = {}
    ansible_facts['ansible_python_facts'] = python_fact.collect(module=None, collected_facts=ansible_facts)
    return ansible_facts


# Generated at 2022-06-23 01:32:46.501319
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']

# Generated at 2022-06-23 01:32:53.168259
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:33:00.044928
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None
    assert python_fact_collector.name == 'python'
    assert python_fact_collector.collect() == {'python': {'version': {'major': sys.version_info[0],
        'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]}, 'version_info': list(sys.version_info),
        'executable': sys.executable, 'has_sslcontext': HAS_SSLCONTEXT}}

# Generated at 2022-06-23 01:33:10.056351
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Tests that collecting facts from PythonFactCollector results
    as expected.
    """
    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.exec

# Generated at 2022-06-23 01:33:21.061609
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-23 01:33:31.937620
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect(module=None, collected_facts=None)
    assert isinstance(facts['python'], dict)
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version']['major'], int)
    assert isinstance(facts['python']['version']['minor'], int)
    assert isinstance(facts['python']['version']['micro'], int)
    assert isinstance(facts['python']['version']['releaselevel'], str)
    assert isinstance(facts['python']['version']['serial'], int)
    assert isinstance(facts['python']['version_info'], list)

# Generated at 2022-06-23 01:33:37.591623
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts_collector = PythonFactCollector()
    actual_collector_method_result = python_facts_collector.collect()
    from platform import python_implementation
    actual_implementation = python_implementation()
    expected_implementation = actual_collector_method_result['python']['type']
    assert actual_implementation == expected_implementation

# Generated at 2022-06-23 01:33:42.770076
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test if method collect of PythonFactCollector class returns data as expected"""
    python_fact_collector = PythonFactCollector()
    collected_facts = python_fact_collector.collect(module=None, collected_facts=None)
    assert(collected_facts['python']['version']['major'] == 3)
    assert(collected_facts['python']['version']['minor'] == 7)
    assert(collected_facts['python']['version']['micro'] == 4)
    assert(collected_facts['python']['version']['releaselevel'] == 'final')
    assert(collected_facts['python']['version']['serial'] == 0)
    assert(collected_facts['python']['version_info'] == [3, 7, 4, 'final', 0])

# Generated at 2022-06-23 01:33:51.679088
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python

# Generated at 2022-06-23 01:33:53.888776
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector(None, None)
    assert fc.name == 'python'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:33:56.127819
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    # The following line will fail if no 'name' attribute exists.
    assert f.name == 'python'

# Generated at 2022-06-23 01:33:58.974462
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert py_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:34:03.192476
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    Create a new instance of PythonFactCollector and check its properties
    """
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:34:08.504149
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set(['python'])

    # Call method collect
    python_fact_collector.collect()



# Generated at 2022-06-23 01:34:19.067374
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:34:24.106985
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # setup
    module = type('', (), {'run_command': {}})()
    module.run_command.return_value = (0, "2.7.14")
    python_fact_collector = PythonFactCollector()

    # exercise
    result = python_fact_collector.collect(module, {})

    # verify
    assert result['python']['version_info'] == [2, 7, 14, 'final', 0]

# Generated at 2022-06-23 01:34:33.443880
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create instance of class PythonFactCollector
    g = PythonFactCollector()

    # Invoke collect method of class PythonFactCollector instance
    # and check returned value
    facts = g.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert len(facts['python']) == 4
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert len(facts['python']['version']) == 5
    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version_info'], list)
    assert len(facts['python']['version_info']) == 5
    assert 'executable' in facts['python']
   

# Generated at 2022-06-23 01:34:35.657084
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert len(collector._fact_ids) == 0


# Generated at 2022-06-23 01:34:40.770783
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()

    # Test python fact collector name is proper
    assert python_facts.name == 'python'

    # Test python fact collector fact_ids are proper
    assert python_facts._fact_ids == set()

# Unit Test for method collect of PythonFactCollector class

# Generated at 2022-06-23 01:34:43.086948
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    res = PythonFactCollector()
    assert res.name == 'python'
    assert res.collect()['python']['version_info'][0] == sys.version_info[0]

# Generated at 2022-06-23 01:34:43.989713
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:34:46.151281
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Just test if the collect method returns a dict with the python fact
    c = PythonFactCollector()

    assert isinstance(c.collect(collected_facts=dict()), dict)

# Generated at 2022-06-23 01:34:49.273879
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Construct PythonFactCollector object instance
    pf_inst = PythonFactCollector()

    # Assert property 'name'
    assert pf_inst.name == 'python'

    # Assert property '_fact_ids'
    assert isinstance(pf_inst._fact_ids, set)

# Generated at 2022-06-23 01:34:53.762432
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector_object = PythonFactCollector()
    result = fact_collector_object.collect()
    assert result['python']['version_info'][0] == 3
    assert result['python']['version']['major'] == 3
    assert type(result) is dict

# Generated at 2022-06-23 01:34:59.025255
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert isinstance(facts['python'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert facts['python']['type'] in {'CPython', 'PyPy', None}

# Generated at 2022-06-23 01:35:01.510997
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:35:03.214807
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids is not None

# Generated at 2022-06-23 01:35:10.992237
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfactcol = PythonFactCollector()
    pyfacts = pyfactcol.collect()
    assert pyfacts['python']['version']['major'] == sys.version_info[0]
    assert pyfacts['python']['version']['minor'] == sys.version_info[1]
    assert pyfacts['python']['version']['micro'] == sys.version_info[2]
    assert pyfacts['python']['version']['releaselevel'] == sys.version_info[3]
    assert pyfacts['python']['version']['serial'] == sys.version_info[4]
    assert pyfacts['python']['version_info'] == list(sys.version_info)
    assert pyfacts['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:35:13.297177
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()



# Generated at 2022-06-23 01:35:17.339110
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Create the instance of class PythonFactCollector
    pfc = PythonFactCollector()

    # Assert that the private attributes of class PythonFactCollector
    # are set to the correct values
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:35:24.363127
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    results = c.collect(module=None, collected_facts=None)
    assert results == {'python': {'executable': '/usr/bin/python',
                                  'version': {'major': 2,
                                              'micro': 6,
                                              'minor': 7,
                                              'releaselevel': 'final',
                                              'serial': 0},
                                  'version_info': [2, 7, 6, 'final', 0],
                                  'type': None,
                                  'has_sslcontext': True}}

# Generated at 2022-06-23 01:35:27.125362
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-23 01:35:36.013691
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector.collect()
    assert python_facts['python']['version'] == {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:35:44.694803
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {
        'python': {
            'has_sslcontext': HAS_SSLCONTEXT,
            'version_info': [sys.version_info[x] for x in range(5)],
            'executable': sys.executable,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            }
        }
    }

# Generated at 2022-06-23 01:35:47.220582
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert(pf.name == 'python')
    assert(len(pf._fact_ids) == 0)
    assert(pf.collect()['python']['version']['releaselevel'] == 'final')

# Generated at 2022-06-23 01:35:55.331478
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    import ast
    py_info = PythonFactCollector().collect()
    assert py_info is not None
    assert 'python' in py_info
    assert 'version' in py_info['python']
    assert 'major' in py_info['python']['version']
    assert 'minor' in py_info['python']['version']
    assert 'micro' in py_info['python']['version']
    assert 'releaselevel' in py_info['python']['version']
    assert 'serial' in py_info['python']['version']
    assert 'version_info' in py_info['python']
    assert 'executable' in py_info['python']
    assert 'has_sslcontext' in py_info['python']
    assert platform.python_version_tuple()[0]

# Generated at 2022-06-23 01:36:07.320445
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set(['python'])

    # test the output
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-23 01:36:08.616891
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-23 01:36:09.198926
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert True

# Generated at 2022-06-23 01:36:17.131399
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    instance = PythonFactCollector(None, None)

    version = {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }

    assert instance.collect() == {
        'python': {
            'version': version,
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
        }
    }

# Generated at 2022-06-23 01:36:20.133025
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Constructor test
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:36:23.817777
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for method collect of class PythonFactCollector
    """
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts

# Generated at 2022-06-23 01:36:24.460599
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:36:26.778000
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()
    assert p.collect()

# Generated at 2022-06-23 01:36:29.542518
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Does an instance of the class PythonFactCollector exist?
    python_facts = PythonFactCollector()
    assert isinstance(python_facts, PythonFactCollector)


# Generated at 2022-06-23 01:36:31.668068
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'

# Generated at 2022-06-23 01:36:34.509710
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector.collect()['python']['version_info'][0] == sys.version_info[0]

# Generated at 2022-06-23 01:36:36.818743
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Arrange
    test_object = PythonFactCollector()

    # Assert
    assert test_object.name == 'python'

# Generated at 2022-06-23 01:36:45.512895
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test collect method of PythonFactCollector

    This method tests the collect method of the PythonFactCollector.
    It checks that the version number, version info and executable are
    returned correctly.
    """
    # Create PythonFactCollector object
    py_fact_collector = PythonFactCollector()
    # Execute collect method
    py_fact_collector.collect()
    # Get the redis facts
    py_facts = py_fact_collector.get_facts()

    # Check that Ansible version is correct
    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version

# Generated at 2022-06-23 01:36:47.895766
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector


# Generated at 2022-06-23 01:36:58.896896
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:37:01.387984
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()
    assert pyfc.name == 'python'

# Generated at 2022-06-23 01:37:08.587719
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collect_result = python_fact_collector.collect()
    assert collect_result['python']['version_info'] == list(sys.version_info)
    assert collect_result['python']['executable'] == sys.executable
    assert collect_result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:37:18.962571
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    py_facts = py_fc.collect()

    # check version
    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_facts['python']['version']['serial'] == sys.version_info[4]
    assert py_facts['python']['version_info'] == list(sys.version_info)
    assert py_facts['python']['executable'] == sys

# Generated at 2022-06-23 01:37:21.172984
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    input_obj = PythonFactCollector()
    assert input_obj.name == "python"
    assert not input_obj._fact_ids


# Generated at 2022-06-23 01:37:22.633974
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-23 01:37:32.138516
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test setup
    python_fact_collector = PythonFactCollector(None)
    if not HAS_SSLCONTEXT:
        test_python_facts = {
            'python': {
                'version': {
                    'major': sys.version_info[0],
                    'minor': sys.version_info[1],
                    'micro': sys.version_info[2],
                    'releaselevel': sys.version_info[3],
                    'serial': sys.version_info[4]
                },
                'version_info': list(sys.version_info),
                'executable': sys.executable,
                'has_sslcontext': HAS_SSLCONTEXT,
                'type': sys.implementation.name
            }
        }

# Generated at 2022-06-23 01:37:34.958624
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'
    assert 'python' not in pf._fact_ids

# Generated at 2022-06-23 01:37:44.916928
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = {'python':
    {'version':
        {'major': 2,
         'minor': 7,
         'micro': 12,
         'releaselevel': 'final',
         'serial': 0},
     'version_info': [2, 7, 12, 'final', 0],
     'executable': '/usr/bin/python2.7',
     'has_sslcontext': False,
     'type': 'CPython'}
    }
    #obj_instance = PythonFactCollector()
    #test_result = obj_instance.collect()
    #print(test_result)
    #assert test_result == result


# Generated at 2022-06-23 01:37:46.821961
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # This will raise an exception if constructor doesn't work
    assert(PythonFactCollector().name == 'python')

# Generated at 2022-06-23 01:37:50.940554
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert set(PythonFactCollector.collect().keys()) == set(['python'])

# Generated at 2022-06-23 01:37:58.591400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    bfc = PythonFactCollector()
    result = bfc.collect({}, {})
    assert result == {'python': {'type': 'CPython',
                                 'has_sslcontext': False,
                                 'version': {'major': 2,
                                             'minor': 7,
                                             'micro': 11,
                                             'releaselevel': 'final',
                                             'serial': 0},
                                 'version_info': [2, 7, 11, 'final', 0],
                                 'executable': '/usr/bin/python2.7'}}

# Generated at 2022-06-23 01:38:07.952734
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    collected_facts = {}
    expected_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:38:09.269698
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:38:10.283564
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p

# Generated at 2022-06-23 01:38:11.304491
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()


# Generated at 2022-06-23 01:38:13.036224
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:38:15.612929
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector.name, str)
    assert isinstance(python_fact_collector._fact_ids, set)


# Generated at 2022-06-23 01:38:25.690925
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create an instance of the class PythonFactCollector
    fact_collector = PythonFactCollector()

    # Call the method collect on the class PythonFactCollector
    facts = fact_collector.collect()

    # Check if the python version info is correct
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:38:28.939419
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert isinstance(python_collector._fact_ids, set)
    assert len(python_collector._fact_ids) == 0

# Generated at 2022-06-23 01:38:36.716888
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import get_collector_names

    # Get the list of collectors' names
    collector_names = []
    for collector_name in get_collector_names():
        collector_names.append(collector_name)

    # The list should contain PythonFactCollector
    assert 'python' in collector_names

    # Check that it is of the right class
    python_collector = Collector.get_collector('python')
    assert python_collector.__class__.__name__ == 'PythonFactCollector'


# Generated at 2022-06-23 01:38:40.078554
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''

    collector = PythonFactCollector()
    assert collector.collect() is not None

# Generated at 2022-06-23 01:38:42.674231
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:38:51.482452
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Arrange
    pfc = PythonFactCollector()

    # Act
    python_facts = pfc.collect()

    # Assert
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts

# Generated at 2022-06-23 01:39:00.120359
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test for Python 2
    if sys.version_info[0] == 2:
        assert PythonFactCollector().collect()['python']['type'] == 'CPython'
        assert PythonFactCollector().collect()['python']['version']['serial'] == sys.version_info[4]
    # Test for Python 3
    elif sys.version_info[0] == 3:
        assert PythonFactCollector().collect()['python']['type'] == 'CPython'
        assert PythonFactCollector().collect()['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:39:02.744487
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert 'python' in obj._fact_ids


# Generated at 2022-06-23 01:39:11.929709
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector

    system_collector = SystemCollector()
    network_collector = NetworkCollector()

    facts = Facts(dict(), dict(),
                  system_collector, network_collector,
                  [PythonFactCollector()])
    facts.populate()
    assert 'python' in facts.ansible_facts
    python_facts = facts.ansible_facts['python']

    assert isinstance(python_facts['version'], dict)
    assert isinstance(python_facts['version_info'], list)
    assert isinstance(python_facts['executable'], str)

# Generated at 2022-06-23 01:39:13.829127
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'

# Generated at 2022-06-23 01:39:24.483081
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = None
    collected_facts = None

    # instantiate the class
    obj = PythonFactCollector()

    # call method
    result = obj.collect(module, collected_facts)
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:39:29.943588
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    ''' Unit test for PythonFactCollector class'''
    py_fc = PythonFactCollector()
    assert py_fc.name == 'python'
    assert py_fc._fact_ids == set(['python'])
    assert type(py_fc) is PythonFactCollector


# Generated at 2022-06-23 01:39:37.370059
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    returned_facts = python_fact_collector.collect(collected_facts=collected_facts)

    assert returned_facts['python']
    assert returned_facts['python']['version']
    assert returned_facts['python']['version']['major'] == sys.version_info[0]
    assert returned_facts['python']['version']['minor'] == sys.version_info[1]
    assert returned_facts['python']['version']['micro'] == sys.version_info[2]
    assert returned_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert returned_facts['python']['version']['serial'] == sys.version_info[4]