

# Generated at 2022-06-23 01:29:34.059817
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-23 01:29:40.461354
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert isinstance(x,BaseFactCollector)


# Generated at 2022-06-23 01:29:43.136068
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set(['python'])

# Generated at 2022-06-23 01:29:46.727720
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import sys, random
    random.seed()

    # Test default constructor
    collector = PythonFactCollector()
    collector.collect()
    assert collector.name == 'python'
    assert collector._fact_ids == set()
    assert collector != None

# Generated at 2022-06-23 01:29:56.031052
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    python_facts = collector.collect()
    print(python_facts)
    print('Python version is: ' + str(python_facts['python']['version']))
    print('Python version info is: ' + str(python_facts['python']['version_info']))
    print('Python executable is: ' + str(python_facts['python']['executable']))
    print('Python has SSLContext: ' + str(python_facts['python']['has_sslcontext']))
    print('Python type is: ' + str(python_facts['python']['type']))

# Invoke test for method collect of class PythonFactCollector
if __name__ == '__main__':
    test_PythonFactCollector_collect()


# Generated at 2022-06-23 01:29:59.257316
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert type(python_fact_collector) == PythonFactCollector
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:30:08.277351
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils import basic

    facts = ansible_facts.AnsibleFacts(dict(), basic.AnsibleModule(
    ))
    collector = PythonFactCollector(module=None, facts=facts)
    collected_facts = collector.collect(module=None, collected_facts=None)


# Generated at 2022-06-23 01:30:13.745307
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    f = c.collect()
    assert isinstance(f, dict)
    assert 'python' in f
    assert 'version' in f['python']
    assert 'has_sslcontext' in f['python']
    assert 'version_info' in f['python']
    assert 'type' in f['python']
    assert isinstance(f['python']['type'], str)

# Generated at 2022-06-23 01:30:15.429206
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'


# Generated at 2022-06-23 01:30:25.589463
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        import ssl
        ssl_context_available = True
    except ImportError:
        ssl_context_available = False

    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['type'] == 'CPython'
    assert python_facts['python']['version_info'][0] == sys.version_info[0]
    assert python_facts['python']['version_info'][1] == sys.version_info[1]
    assert python_facts['python']['version_info'][2] == sys.version_info[2]
    assert python_facts['python']['version_info'][3] == sys.version_info[3]

# Generated at 2022-06-23 01:30:30.259915
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:30:38.000505
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': getattr(
                sys, 'implementation', {'name': getattr(
                    sys, 'subversion', [None])
            }).name
        }
    }

# Generated at 2022-06-23 01:30:48.233149
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    result = python_collector.collect()

    assert result == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-23 01:30:58.113301
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect"""
    # Set up
    python_collector = PythonFactCollector()
    # Execute
    python_facts = python_collector.collect()
    # Verify
    assert 'python' in python_facts
    assert python_facts['python']
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:31:00.613301
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    result = python_collector.collect()
    assert type(result) == dict
    assert 'python' in result

# Generated at 2022-06-23 01:31:02.386747
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:31:12.361146
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    result = py_fc.collect()
    version_info = result['python']['version_info']
    assert len(version_info) == 5
    assert version_info[0] == sys.version_info[0]
    assert version_info[1] == sys.version_info[1]
    assert version_info[2] == sys.version_info[2]
    assert version_info[3] == sys.version_info[3]
    assert version_info[4] == sys.version_info[4]

    version = result['python']['version']
    assert version['major'] == sys.version_info[0]
    assert version['minor'] == sys.version_info[1]
    assert version['micro'] == sys.version_info[2]


# Generated at 2022-06-23 01:31:14.992371
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert type(pfc._fact_ids) == set
    assert not pfc._fact_ids


# Generated at 2022-06-23 01:31:25.105870
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {
        'python': {
             'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
        }
    }

    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python

# Generated at 2022-06-23 01:31:26.467126
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:31:38.966845
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert python_facts.collect()['python']['version']['major'] == sys.version_info[0]
    assert python_facts.collect()['python']['version']['minor'] == sys.version_info[1]
    assert python_facts.collect()['python']['version']['micro'] == sys.version_info[2]
    assert python_facts.collect()['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts.collect()['python']['version']['serial'] == sys.version_info[4]
    assert python_facts.collect()['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:31:47.179107
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = collector.collect(
        module=None,
        collected_facts=None
    )

    assert collected_facts == {
        'python': {
            'type': 'CPython',
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'executable': sys.executable,
            'version_info': list(sys.version_info),
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:31:49.391766
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-23 01:31:50.984212
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:31:55.104348
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Check if we have SSLContext support
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:32:00.627612
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['type'] in ('CPython', 'PyPy', 'Jython', 'IronPython', None)

# Generated at 2022-06-23 01:32:02.088355
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    assert isinstance(fc.collect(), dict)


# Generated at 2022-06-23 01:32:06.444026
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector.has_deps() is False
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:32:17.630449
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instantiate object of class PythonFactCollector
    python_fact_collector_obj = PythonFactCollector()
    # Call method collect of PythonFactCollector object
    python_dict = python_fact_collector_obj.collect()
    # Assertion of data in return value of method collect
    assert isinstance(python_dict, dict)
    # Assertion for the value of the 'python' key in return value of method collect
    assert isinstance(python_dict['python'], dict)
    # Assertion for the value of the 'version' key in return value of method collect
    assert isinstance(python_dict['python']['version'], dict)
    # Assertion for the value of the 'major' key in 'version' key in return value of method collect

# Generated at 2022-06-23 01:32:27.440628
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts_under_test = PythonFactCollector()
    collected_facts = facts_under_test.collect()
    assert type(collected_facts) is dict
    assert 'python' in collected_facts.keys()
    assert type(collected_facts['python']) is dict
    assert 'version' in collected_facts['python'].keys()
    assert type(collected_facts['python']['version']) is dict
    assert 'major' in collected_facts['python']['version'].keys()
    assert type(collected_facts['python']['version']['major']) is int
    assert 'minor' in collected_facts['python']['version'].keys()
    assert type(collected_facts['python']['version']['minor']) is int
    assert 'micro' in collected_facts

# Generated at 2022-06-23 01:32:29.974536
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:32:40.469200
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        from ansible.module_utils.facts.collector import get_collector_instance
    except ImportError:
        from ansible.module_utils.facts.collectors import get_collector_instance

    # Test instantiation of fact collector
    fact_collector = get_collector_instance('python_fact_collector')
    assert isinstance(fact_collector, PythonFactCollector)

    # Test collect method of fact collector

# Generated at 2022-06-23 01:32:42.284410
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:32:43.540811
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector()

# Generated at 2022-06-23 01:32:48.915071
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    py_facts = py_fc.collect()

    assert 'python' in py_facts
    assert 'version' in py_facts['python']
    assert 'version_info' in py_facts['python']
    assert 'executable' in py_facts['python']
    assert 'has_sslcontext' in py_facts['python']
    assert 'type' in py_facts['python']

# Generated at 2022-06-23 01:32:58.056549
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # We add the python version in the fact_ids
    # to make sure it always exists
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:33:07.159416
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = collector.collect()
    assert collected_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-23 01:33:15.143629
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    expected_result = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
            'version': {
                'major': sys.version_info[0],
                'micro': sys.version_info[2],
                'minor': sys.version_info[1],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }
    assert result == expected_result

# Generated at 2022-06-23 01:33:16.693695
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-23 01:33:24.184889
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts['python']['version_info'][0] == sys.version_info[0]
    assert facts['python']['version_info'][1] == sys.version_info[1]
    assert facts['python']['version_info'][2] == sys.version_info[2]
    assert facts['python']['version_info'][3] == sys.version_info[3]
    assert facts['python']['version_info'][4] == sys.version_info[4]
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]

# Generated at 2022-06-23 01:33:25.052593
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector.collect()

# Generated at 2022-06-23 01:33:27.295863
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == "python"
    assert p._fact_ids == set()



# Generated at 2022-06-23 01:33:29.853735
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()

# Generated at 2022-06-23 01:33:31.796829
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert 'python' == python_fact_collector.name

# Generated at 2022-06-23 01:33:37.173883
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert isinstance(result['python'], dict)
    assert isinstance(result['python']['version'], dict)
    assert result['python']['version']['major'] >= 2
    assert result['python']['type'] == 'cpython'


# Generated at 2022-06-23 01:33:42.721332
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert type(python_facts['python']) == dict
    assert type(python_facts['python']['version']) == dict
    assert type(python_facts['python']['version']['major']) == int
    assert type(python_facts['python']['version']['minor']) == int
    assert type(python_facts['python']['version']['micro']) == int
    assert type(python_facts['python']['version']['releaselevel']) == str
    assert type(python_facts['python']['version']['serial']) == int
    assert type(python_facts['python']['version_info']) == list

# Generated at 2022-06-23 01:33:45.663409
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    assert facts is not None
    assert 'ansible_python' in facts


# Generated at 2022-06-23 01:33:50.317718
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    result = f.collect()

    assert isinstance(result, dict)
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']

# Generated at 2022-06-23 01:33:52.593176
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pc = PythonFactCollector()
    assert pc.name == 'python'
    assert pc._fact_ids == set()


# Generated at 2022-06-23 01:33:59.911939
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    version_keys = result['python']['version'].keys()
    assert 'major' in version_keys
    assert 'minor' in version_keys
    assert 'micro' in version_keys
    assert 'releaselevel' in version_keys
    assert 'serial' in version_keys
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']
    assert isinstance(result['python']['version_info'], list)

# Generated at 2022-06-23 01:34:02.689560
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:34:05.651876
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:34:16.904534
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Test facts with Python 2
    if sys.version_info.major == 2:
        assert PythonFactCollector().collect() == {
            'python': {
                'version': {
                    'major': 2,
                    'minor': 7,
                    'micro': 13,
                    'releaselevel': 'final',
                    'serial': 0
                },
                'version_info': [2, 7, 13, 'final', 0],
                'executable': '/usr/bin/python',
                'has_sslcontext': False
            }
        }

    # Test facts with Python 3

# Generated at 2022-06-23 01:34:24.466388
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:34:33.547506
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    python_fact_collector = PythonFactCollector()
    facts_dict = python_fact_collector.collect()

    assert 'python' in facts_dict

    assert 'version' in facts_dict['python']
    assert 'version_info' in facts_dict['python']
    assert 'executable' in facts_dict['python']
    assert 'type' in facts_dict['python']
    assert 'has_sslcontext' in facts_dict['python']

    assert 'major' in facts_dict['python']['version']
    assert 'minor' in facts_dict['python']['version']
    assert 'micro' in facts_dict['python']['version']
    assert 'releaselevel' in facts_dict['python']['version']
    assert 'serial' in facts_dict['python']['version']


# Generated at 2022-06-23 01:34:42.625333
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_test = PythonFactCollector()
    python_facts = python_test.collect()
    assert type(python_facts) is dict
    assert 'python' in python_facts
    python_dict = python_facts['python']
    assert type(python_dict) is dict
    assert 'version' in python_dict
    assert 'version_info' in python_dict
    assert 'executable' in python_dict
    assert 'has_sslcontext' in python_dict
    assert 'type' in python_dict
    version_dict = python_dict['version']
    assert type(version_dict) is dict
    assert 'major' in version_dict
    assert 'minor' in version_dict
    assert 'micro' in version_dict
    assert 'releaselevel' in version_dict
    assert 'serial' in version_dict
   

# Generated at 2022-06-23 01:34:43.159129
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:34:46.270309
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-23 01:34:47.723674
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:34:54.219530
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    mock_config = {
        'module_setup': False,
        'collect_subset': [],
        'default_facts_type_whitelist': ['python']
    }
    with pytest.raises(Exception) as e_info:
        python_fact_collector = PythonFactCollector(mock_config)
    assert "PythonFactCollector requires Ansible 2.7.10 or higher" in str(e_info.value)

# Generated at 2022-06-23 01:34:56.243028
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # No parameters to the constructor
    x = PythonFactCollector()

    assert x is not None

# Generated at 2022-06-23 01:35:04.338452
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_collection = PythonFactCollector()
    assert facts_collection == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:35:09.193857
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    facts = py_fact_collector.collect()
    assert len(facts) == 1
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-23 01:35:10.828574
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:35:13.495539
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:35:14.919295
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = PythonFactCollector()
    assert module.name == 'python'

# Generated at 2022-06-23 01:35:16.174391
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    o = PythonFactCollector()
    assert o is not None


# Generated at 2022-06-23 01:35:19.125920
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = {}
    python_collector = PythonFactCollector()
    result = python_collector.collect(None, collected_facts)
    return result

# Generated at 2022-06-23 01:35:20.872647
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'



# Generated at 2022-06-23 01:35:28.508906
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    import socket

    fc = PythonFactCollector()
    facts = {}
    fc.collect(collected_facts=facts)

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
   

# Generated at 2022-06-23 01:35:35.775318
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    myFactCollector = PythonFactCollector()
    result = myFactCollector.collect()
    assert result == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:35:39.812233
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    pf.collect()
    assert pf.name == 'python'
    assert pf.get_facts() == {}


# Generated at 2022-06-23 01:35:44.816781
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Unit test for method collect of class PythonFactCollector
    # if sys.version_info is a named tuple, it should have the correct attrs
    python_facts = PythonFactCollector().collect()
    version_info_attrs = ('major', 'minor', 'micro', 'releaselevel', 'serial')
    for attr in version_info_attrs:
        assert attr in python_facts['python']['version']

# Generated at 2022-06-23 01:35:46.932706
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert result is not None
    assert result['python'] is not None

# Generated at 2022-06-23 01:35:47.681351
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc

# Generated at 2022-06-23 01:35:48.979053
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:35:59.144224
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test that we correctly create the python fact
    """
    python_fact_collector = PythonFactCollector()

    ans_dict = {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': 'CPython'
    }}


# Generated at 2022-06-23 01:36:02.408536
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collectors import get_collector_instance
    collector = get_collector_instance('python')
    assert isinstance(collector, PythonFactCollector)


# Generated at 2022-06-23 01:36:09.883750
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts = PythonFactCollector().collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert 'type' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-23 01:36:18.496031
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:36:19.715556
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'

# Generated at 2022-06-23 01:36:21.225716
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:36:21.806751
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:36:25.839829
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test constructor of class PythonFactCollector
    """
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Unit test here

# Generated at 2022-06-23 01:36:36.979573
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # instantiate the collector
    c = PythonFactCollector()

    # make sure the returned facts are of the expected structure
    assert type(c.collect()) == dict
    assert type(c.collect()['python']) == dict
    assert type(c.collect()['python']['version']) == dict
    assert type(c.collect()['python']['version_info']) == list
    assert len(c.collect()['python']['version_info']) == 5
    assert type(c.collect()['python']['executable']) == str
    assert type(c.collect()['python']['has_sslcontext']) == bool

    # make sure the returned version is of the expected type and within expected range
    assert type(c.collect()['python']['version']['major']) == int
   

# Generated at 2022-06-23 01:36:41.209316
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Unit test for PythonFactCollector"""
    python_fc = PythonFactCollector()
    assert str(python_fc.name) == PythonFactCollector.name
    assert isinstance(python_fc._fact_ids, set)
    assert python_fc.collect()

# Generated at 2022-06-23 01:36:45.001333
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    result = pyfc.collect()

    assert 'python' in result
    assert result.get('python').get('version')
    assert result.get('python').get('version_info')
    assert result.get('python').get('executable')
    assert result.get('python').get('has_sslcontext')
    assert result.get('python').get('type')

# Generated at 2022-06-23 01:36:53.858931
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    print('Version Info:', pfc.collect()['python']['version_info'])
    print('Version Info:', pfc.collect()['python']['version']['major'])
    print('Version Info:', pfc.collect()['python']['version']['minor'])
    print('Version Info:', pfc.collect()['python']['version']['micro'])
    print('Version Info:', pfc.collect()['python']['version']['releaselevel'])
    print('Version Info:', pfc.collect()['python']['version']['serial'])
    print('Executable:', pfc.collect()['python']['executable'])

# Generated at 2022-06-23 01:37:02.668157
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Prepare test
    sys.implementation.name = 'cpython'
    sys.version_info = (3,6,0,'beta1',1)
    sys.subversion = ('CPython', '3.6.0b1', '15275-151-gf2cc732')
    sys.executable = '/usr/bin/python'
    del HAS_SSLCONTEXT

    # Test
    facts_collector = PythonFactCollector()
    facts = facts_collector.collect()

    # Check
    assert 'python' in facts
    assert facts['python']['type'] == 'CPython'
    assert facts['python']['version']['major'] == 3
    assert facts['python']['version']['minor'] == 6

# Generated at 2022-06-23 01:37:13.232967
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    collector = Collector()
    collector.add_collection(PythonFactCollector)
    result = collector.collect()

    assert 'python' in result.keys()
    assert 'version' in result['python'].keys()
    assert 'version_info' in result['python'].keys()
    assert 'executable' in result['python'].keys()
    assert 'has_sslcontext' in result['python'].keys()

    assert 'major' in result['python']['version'].keys()
    assert 'minor' in result['python']['version'].keys()
    assert 'micro' in result['python']['version'].keys()

# Generated at 2022-06-23 01:37:20.064896
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import PythonFactCollector

    facts_dict = {}
    fact_list = ['python']
    registry = FactCollector(
        fact_list, facts_dict, PythonFactCollector)
    registry.collect(module=None, collected_facts=None)
    assert 'python' in facts_dict
    assert facts_dict['python']['version']['major']



# Generated at 2022-06-23 01:37:25.769564
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for method collect method of class PythonFactCollector
    """
    python_fact_collector = PythonFactCollector()
    from ansible.module_utils.facts.collector import Collector
    collector_obj = Collector()
    result = python_fact_collector.collect(collector_obj)
    assert 'python' in result
    assert 'type' in result['python']
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-23 01:37:34.489422
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        has_sslcontext = True
    except ImportError:
        has_sslcontext = False

    python_info = sys.version_info

    try:
        type = sys.subversion[0]
    except AttributeError:
        try:
            type = sys.implementation.name
        except AttributeError:
            type = None


# Generated at 2022-06-23 01:37:46.386747
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # mock class PythonFactCollector
    class MockPythonFactCollector:
        _fact_ids = set()
        name = 'python'

        def collect(self, module=None, colletected_facts=None):
            python_facts = {}

            python_facts['python'] = {
                'version': {
                    'major': sys.version_info[0],
                    'minor': sys.version_info[1],
                    'micro': sys.version_info[2],
                    'releaselevel': sys.version_info[3],
                    'serial': sys.version_info[4]
                },
                'version_info': list(sys.version_info),
                'executable': sys.executable,
                'has_sslcontext': HAS_SSLCONTEXT
            }


# Generated at 2022-06-23 01:37:46.905010
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-23 01:37:51.413143
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts = PythonFactCollector()
    assert facts.name == "python"
    assert isinstance(facts.collect(), dict)
    assert facts.is_deprecated == False

# Generated at 2022-06-23 01:37:53.862532
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-23 01:37:57.610519
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert type(python_fact_collector) == PythonFactCollector
    assert python_fact_collector._fact_ids == set()
    assert python_fact_collector.name == 'python'


# Generated at 2022-06-23 01:37:59.766093
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'
    assert py_collector._fact_ids == set()

# Generated at 2022-06-23 01:38:01.091141
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-23 01:38:03.866207
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:38:05.444528
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x
    assert x.name == 'python'

# Generated at 2022-06-23 01:38:14.967090
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Try a series of versions and levels
    # Make sure the dictionary values correspond to what is expected
    # Based off of https://www.python.org/dev/peps/pep-0396/
    python_version_info_list = [
        (2, 7, 14, 'final', 0),
        (3, 4, 0, 'final', 0),
        (3, 5, 2, 'candidate', 1),
        (3, 6, 0, 'alpha', 2),
        (3, 7, 0, 'alpha', 4),
        # This version doesn't exist, but test anyway
        (4, 0, 0, '', 0),
    ]
    for version_info in python_version_info_list:
        version_info_type = [
            x for x in sys.version_info
        ]

# Generated at 2022-06-23 01:38:16.329956
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    c.collect()

# Generated at 2022-06-23 01:38:19.725197
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert len(py_fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:38:30.926059
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test whether method collect of class PythonFactCollector works
    as expected.
    """
    # Create a object of class PythonFactCollector to call the method
    # collect
    pf_collector = PythonFactCollector()

    # Call the method collect
    python_facts = pf_collector.collect()

    assert isinstance(python_facts, dict)
    assert 'python' in python_facts.keys()

    assert isinstance(python_facts['python'], dict)
    assert 'version' in python_facts['python'].keys()
    assert 'version_info' in python_facts['python'].keys()
    assert 'executable' in python_facts['python'].keys()
    assert 'has_sslcontext' in python_facts['python'].keys()

# Generated at 2022-06-23 01:38:40.664317
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()["python"]
    assert python_facts['version']['major'] == sys.version_info[0]
    assert python_facts['version']['minor'] == sys.version_info[1]
    assert python_facts['version']['micro'] == sys.version_info[2]
    assert python_facts['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['version']['serial'] == sys.version_info[4]
    assert hasattr(python_facts['version_info'], '__iter__')
    assert python_facts['executable'] == sys.executable

# Generated at 2022-06-23 01:38:41.101756
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:38:50.073319
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    x = p.collect()
    assert x['python']['version']['major'] == sys.version_info[0]
    assert x['python']['version']['minor'] == sys.version_info[1]
    assert x['python']['version']['micro'] == sys.version_info[2]
    assert x['python']['version']['releaselevel'] == sys.version_info[3]
    assert x['python']['version']['serial'] == sys.version_info[4]
    for i in range(0, 5):
        assert x['python']['version_info'][i] == sys.version_info[i]
    assert x['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:38:52.360300
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, PythonFactCollector)

# Generated at 2022-06-23 01:38:56.938341
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    # assert expected attributes exist
    assert python_collector.name == 'python'
    assert isinstance(python_collector._fact_ids, set)
    # Uncomment for debugging
    # print(python_collector)


# Generated at 2022-06-23 01:38:59.989785
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  fact_collector = PythonFactCollector()
  fact = fact_collector.collect()
  assert fact['python']['version_info'][0] == 3
  assert fact['python']['has_sslcontext']

# Generated at 2022-06-23 01:39:01.206857
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # TODO
    print("Running test_PythonFactCollector_collect()")

# Generated at 2022-06-23 01:39:11.058614
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert 'python' in sys.modules.keys()
    assert 'ansible.module_utils.facts.collector.python' in sys.modules.keys()
    assert 'ansible.module_utils.facts.collector.base' in sys.modules.keys()
    assert hasattr(sys.modules['ansible.module_utils.facts.collector.base'], 'BaseFactCollector')
    assert hasattr(sys.modules['ansible.module_utils.facts.collector.python'], 'PythonFactCollector')
    assert 'sys' in sys.modules.keys()
    assert 'sys.version_info' in dir(sys.modules['sys'])
    assert 'sys.executable' in dir(sys.modules['sys'])

# Generated at 2022-06-23 01:39:13.212298
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector

# Generated at 2022-06-23 01:39:18.911910
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    os_facts = PythonFactCollector()
    result = os_facts.collect()

    assert 'python' in result
    assert isinstance(result['python']['version']['major'], int)
    assert isinstance(result['python']['version']['minor'], int)
    # python 2.6 has no micro
    assert 'micro' in result['python']['version']
    assert isinstance(result['python']['version_info'], list)

# Generated at 2022-06-23 01:39:20.485010
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == "python"


# Generated at 2022-06-23 01:39:22.836107
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'
    assert pf._fact_ids == set()


# Generated at 2022-06-23 01:39:24.949178
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    _test = PythonFactCollector()
    assert _test.name == 'python'
    assert isinstance(_test.collect()['python'], dict)

# Generated at 2022-06-23 01:39:31.858857
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert isinstance(result['python']['has_sslcontext'], bool)


# Generated at 2022-06-23 01:39:34.891604
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PyFacts = PythonFactCollector()
    assert PyFacts.name == 'python'
