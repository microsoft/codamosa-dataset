

# Generated at 2022-06-23 01:29:32.435224
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x

# Generated at 2022-06-23 01:29:39.922442
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # create a instance of class PythonFactCollector
    python_fact_collector = PythonFactCollector()

    collected_facts = {}
    python_facts = python_fact_collector.collect(collected_facts=collected_facts)

    assert isinstance(python_facts, dict)
    assert isinstance(python_facts.get('python'), dict)

    python = python_facts['python']
    assert isinstance(python.get('version'), dict)
    assert isinstance(python.get('version_info'), list)
    assert isinstance(python.get('executable'), str)

    version = python['version']
    assert isinstance(version.get('major'), int)
    assert isinstance(version.get('minor'), int)
    assert isinstance(version.get('micro'), int)

# Generated at 2022-06-23 01:29:42.359195
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:29:52.035280
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['has_sslcontext'] == HAS_SSLCON

# Generated at 2022-06-23 01:29:54.888183
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Check if the class PythonFactCollector is instantiated as an object
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)


# Generated at 2022-06-23 01:29:56.576938
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    a = PythonFactCollector()
    assert isinstance(a, PythonFactCollector)

# Generated at 2022-06-23 01:30:05.703397
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import unittest
    import module_utils.facts.collector
    from sys import version_info

    class TestCollector(module_utils.facts.collector.BaseFactCollector):
        name = "dummy"

    class TestPythonFactCollectorClass(unittest.TestCase):
        def setUp(self):
            TestCollector._fact_ids = set()
            self.test_collector = TestCollector()

        def test_python_version_dots(self):
            self.assertEqual(PythonFactCollector.collect()['python']['version']['major'], version_info[0])
            self.assertEqual(PythonFactCollector.collect()['python']['version']['minor'], version_info[1])

# Generated at 2022-06-23 01:30:08.104385
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'

# Generated at 2022-06-23 01:30:10.923563
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Check that the Ctor works without any arguments
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None


# Generated at 2022-06-23 01:30:19.892154
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    if sys.version_info[0] < 3:
        from mock import patch
        from ansible.module_utils.facts.collector import BaseFactCollector
    else:
        from unittest.mock import patch
        from ansible.module_utils.facts.collector import BaseFactCollector


# Generated at 2022-06-23 01:30:21.299769
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-23 01:30:29.008442
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import json

    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], str)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)
   

# Generated at 2022-06-23 01:30:33.381321
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python = PythonFactCollector()
    python_facts = python.collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-23 01:30:36.048707
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:30:38.236442
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    my_obj = PythonFactCollector()
    assert my_obj
    assert my_obj.name == 'python'

# Generated at 2022-06-23 01:30:51.605313
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert 'python' in facts
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:30:57.664838
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert type(result['python']) is dict
    assert result['python']['type'] is not None
    assert result['python']['version'] is not None
    assert result['python']['version_info'] is not None
    assert result['python']['executable'] is not None
    assert result['python']['has_sslcontext'] is not None

# Generated at 2022-06-23 01:31:01.427282
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Create instance of class PythonFactCollector
    python_collector = PythonFactCollector()

    # Make sure it is instance of BaseFactCollector
    assert isinstance(python_collector, BaseFactCollector)

    # Check the name
    assert python_collector.name == 'python'

# Generated at 2022-06-23 01:31:03.755873
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()



# Generated at 2022-06-23 01:31:11.066087
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test PythonFactCollector.collect()
    """
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    # Make sure we get the executable name
    assert python_facts['python']['executable'] != ""
    # Make sure that version is not an empty python list
    assert len(python_facts['python']['version']) > 0
    # Make sure that version_info is not an empty python list
    assert len(python_facts['python']['version_info']) > 0



# Generated at 2022-06-23 01:31:14.081028
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:31:15.835042
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == "python"
    assert hasattr(obj, 'collect')

# Generated at 2022-06-23 01:31:17.005295
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:31:18.961403
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    my_obj = PythonFactCollector()
    assert my_obj.name == 'python'

# Generated at 2022-06-23 01:31:21.194694
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()
    assert 'python' in facts

# Generated at 2022-06-23 01:31:23.422294
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-23 01:31:32.806891
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    for fact in facts:
        assert fact == 'python'
        for key in facts['python'].keys():
            assert key in ['version', 'version_info', 'executable',
                           'has_sslcontext', 'type']
            if key == 'version':
                for sub_key in facts['python']['version'].keys():
                    assert sub_key in ['major', 'minor', 'micro',
                                       'releaselevel', 'serial']
            elif key == 'version_info':
                assert len(facts['python']['version_info']) == 5
                for sub_key in facts['python']['version_info']:
                    assert isinstance(sub_key, int)

# Generated at 2022-06-23 01:31:35.189495
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'
    assert isinstance(pf.collect(), dict)

# Generated at 2022-06-23 01:31:41.004158
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test for empty
    test_obj = PythonFactCollector()
    assert test_obj.name == 'python'
    assert test_obj._fact_ids == set()

    # Test for populated
    test_obj = PythonFactCollector('test_name', {'test_fact'})
    assert test_obj.name == 'test_name'
    assert test_obj._fact_ids == {'test_fact'}


# Generated at 2022-06-23 01:31:44.754701
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python', \
           'Test for python two fact collector failed'
    assert python_fact_collector._fact_ids == set(), \
           'Test for python two fact collector failed'

    return True

# Generated at 2022-06-23 01:31:56.130863
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instantiate the collector
    fact_collector = PythonFactCollector()

    # Call the method
    facts = fact_collector.collect()

    assert type(facts['python']) == type(dict())
    assert type(facts['python']['version']) == type(dict())
    assert type(facts['python']['version']['major']) == type(int())
    assert type(facts['python']['version']['minor']) == type(int())
    assert type(facts['python']['version']['micro']) == type(int())
    assert type(facts['python']['version']['releaselevel']) == type(str())
    assert type(facts['python']['version']['serial']) == type(int())

# Generated at 2022-06-23 01:32:04.426901
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    # check HAS_SSLCONTEXT
    assert fact_collector.facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    # check python version information
    assert fact_collector.facts['python']['version']['major'] == sys.version_info[0]
    assert fact_collector.facts['python']['version']['minor'] == sys.version_info[1]
    assert fact_collector.facts['python']['version']['micro'] == sys.version_info[2]
    assert fact_collector.facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-23 01:32:13.901100
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    result = python_collector.collect()

    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:32:19.011146
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollectorObj = PythonFactCollector()
    assert pythonFactCollectorObj.name == 'python'
    assert pythonFactCollectorObj._fact_ids == set()


# Generated at 2022-06-23 01:32:22.940374
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert type(pfc) == PythonFactCollector
    assert PythonFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:32:31.298376
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from collections import namedtuple

    module = namedtuple('module', ['params'])
    module.params = {}
    python_collector = PythonFactCollector(module=module)
    facts = python_collector.collect()

    assert 'python' in facts

# Generated at 2022-06-23 01:32:42.182373
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    facts_collector = get_collector_instance('python')
    python_facts = facts_collector.collect()

    assert python_facts is not None
    assert 'python' in python_facts
    python_dict = python_facts.get('python')
    assert python_dict is not None
    assert 'version' in python_dict
    python_version = python_dict.get('version')
    assert python_version is not None
    assert 'major' in python_version
    assert 'minor' in python_version
    assert 'micro' in python_version
    assert 'releaselevel' in python_version
    assert 'serial' in python_version
    assert 'version_info' in python_dict
    assert 'executable' in python_dict

# Generated at 2022-06-23 01:32:51.302734
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    python_obj = PythonFactCollector()
    collected_facts = {
        'ansible_python_version': {
        'major': builtins.__dict__['_python_version_info'][0],
        'micro': builtins.__dict__['_python_version_info'][2],
        'minor': builtins.__dict__['_python_version_info'][1],
        'releaselevel': builtins.__dict__['_python_version_info'][3],
        'serial': builtins.__dict__['_python_version_info'][4]
        }
    }
    expected = collected_facts

# Generated at 2022-06-23 01:32:52.663683
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc is not None

# Generated at 2022-06-23 01:32:59.685488
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()

    assert collector.collect() == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': sys.implementation.name
    }}

# Generated at 2022-06-23 01:33:01.995001
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == "python"
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:33:03.495864
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), BaseFactCollector)

# Generated at 2022-06-23 01:33:13.066507
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create instance of PythonFactCollector
    fact_collector = PythonFactCollector()

    # Call method collect of PythonFactCollector
    facts = fact_collector.collect()

    assert facts is not None
    assert type(facts) is dict
    assert 'python' in facts
    assert facts['python'] is not None
    assert type(facts['python']) is dict
    assert 'version' in facts['python']
    assert facts['python']['version'] is not None
    assert type(facts['python']['version']) is dict
    assert 'major' in facts['python']['version']
    assert facts['python']['version']['major'] is not None
    assert type(facts['python']['version']['major']) is int
    assert 'minor' in facts['python']['version']

# Generated at 2022-06-23 01:33:15.678709
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert hasattr(PythonFactCollector, 'name')
    assert hasattr(PythonFactCollector, 'collect')

# Generated at 2022-06-23 01:33:21.136294
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import ansible.module_utils.facts.collector
    py_col = ansible.module_utils.facts.collector.get_collector('python')

    facts = py_col.collect(collected_facts=dict())
    assert facts['python']['version']['releaselevel']
    assert facts['python']['executable']
    assert facts['python']['version_info']
    assert isinstance(facts['python']['version_info'], list)

# Generated at 2022-06-23 01:33:24.386279
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Checks if _fact_ids instance is created in class
    x = PythonFactCollector()
    assert x._fact_ids == set()
    del x


# Generated at 2022-06-23 01:33:33.465387
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    actual = PythonFactCollector().collect()
    expected = {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': 'CPython'
    }}
    if HAS_SSLCONTEXT:
        expected['python']['has_sslcontext'] = True

    assert actual == expected

# Generated at 2022-06-23 01:33:34.397622
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert('python' in PythonFactCollector().collect())

# Generated at 2022-06-23 01:33:44.331497
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    collected_facts = pyfc.collect()
    pyfact = collected_facts['python']

    # Check if all fields are in the fact
    for fact_name in ['version', 'version_info', 'executable', 'type']:
        assert fact_name in pyfact

    # Check if version_info is a list of integers
    ver_info = pyfact['version_info']
    assert isinstance(ver_info, list)
    assert (len(ver_info) == 5)
    for i in ver_info:
        assert isinstance(i, int)

    # Check if version_info is equal to the one returned by sys
    assert ver_info == list(sys.version_info)

    # Check if the executable is the same of the one returned by sys

# Generated at 2022-06-23 01:33:52.963057
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }
    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python

# Generated at 2022-06-23 01:33:59.589148
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = {'python': {'type': 'CPython',
                               'version_info': [2, 7, 6, 'final', 0],
                               'has_sslcontext': False,
                               'version': {'releaselevel': 'final',
                                           'micro': 0,
                                           'serial': 0,
                                           'major': 2,
                                           'minor': 7},
                               'executable': '/usr/bin/python'}}

    assert PythonFactCollector().collect() == python_facts

# Generated at 2022-06-23 01:34:02.260486
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:34:07.671345
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    facts = python_fact_collector.collect()
    assert facts['python']['version']
    assert facts['python']['version_info']
    assert facts['python']['executable']

# Generated at 2022-06-23 01:34:18.331365
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test with version_info 4-tuple
    collected_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    # Test with version_info 5-tuple
    if len(sys.version_info) == 5:
        collected_facts['python']['version']['build'] = sys.version_info[5]
       

# Generated at 2022-06-23 01:34:25.099267
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = dict(ansible_facts={'python': {'executable': '/usr/bin/python',
                                            'has_sslcontext': True,
                                            'type': 'CPython',
                                            'version': {'major': 2,
                                                        'micro': 7,
                                                        'minor': 10,
                                                        'releaselevel': 'final',
                                                        'serial': 0},
                                            'version_info': [2, 7, 10, 'final', 0]}})
    assert PythonFactCollector().collect() == result

# Generated at 2022-06-23 01:34:28.713832
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfactc = PythonFactCollector()
    assert pfactc.name == 'python'
    assert isinstance(pfactc._fact_ids, set) and len(pfactc._fact_ids) == 0


# Generated at 2022-06-23 01:34:30.129949
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'

# Generated at 2022-06-23 01:34:33.842816
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    assert python_collector.collect()['python']['version']['major'] == 2 or python_collector.collect()['python']['version']['major'] == 3

# Generated at 2022-06-23 01:34:40.401052
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    # Example of collected facts:
    # {
    #     'python': {
    #         'executable': '/usr/bin/python',
    #         'has_sslcontext': True,
    #         'type': 'CPython',
    #         'version': {
    #             'major': 2,
    #             'micro': 7,
    #             'minor': 9,
    #             'releaselevel': 'final',
    #             'serial': 0
    #         }
    #     }
    # }

# Generated at 2022-06-23 01:34:43.125166
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector is not None
    assert py_collector.name == 'python'
    assert py_collector._fact_ids == {'python'}

# Generated at 2022-06-23 01:34:44.548672
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test instantiation
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set(['python'])

# Generated at 2022-06-23 01:34:48.478632
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 15, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 15, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-23 01:34:50.591821
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c is not None

# Generated at 2022-06-23 01:35:00.703939
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import json
    python_facts = PythonFactCollector()
    result = python_facts.collect(module=None, collected_facts=None)
    assert isinstance(result, dict)
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-23 01:35:08.390963
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect()['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-23 01:35:12.361764
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Unit test for method `collect` of class PythonFactCollector
    """
    python_fact_collector = PythonFactCollector()
    try:
        python_fact_collector.collect()
    except Exception:
        assert False



# Generated at 2022-06-23 01:35:18.930521
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test collect method of PythonFactCollector
    """
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    # Get instance of PythonFactCollector
    fact_collector = PythonFactCollector(BaseFactCollector, 'python')

    # Call method collect
    collected_facts = fact_collector.collect()

    assert isinstance(collected_facts, dict)

# Generated at 2022-06-23 01:35:28.197652
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    from ansible.module_utils.facts import collector

    try:
        # Check if we have SSLContext support
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        HAS_SSLCONTEXT = True
    except ImportError:
        HAS_SSLCONTEXT = False

    # Initialize the collector
    fact_collector = PythonFactCollector(collector)

    # Collect data
    facts = fact_collector.collect()

    assert type(facts['python']['version']['major']) == int
    assert type(facts['python']['version']['minor']) == int
    assert type(facts['python']['version']['micro']) == int
    assert facts['python']['version']['releaselevel'] == 'final'


# Generated at 2022-06-23 01:35:29.914126
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()

# Generated at 2022-06-23 01:35:34.416250
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()



# Generated at 2022-06-23 01:35:42.822521
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert len(fact_collector._fact_ids) == 1
    assert 'python' in fact_collector._fact_ids

# Generated at 2022-06-23 01:35:46.620207
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()
    assert isinstance(PythonFactCollector._fact_ids, set)
    mod_facts = PythonFactCollector().collect()
    assert (mod_facts['python']['type'] == 'CPython')


# Generated at 2022-06-23 01:35:53.317578
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of the PythonFactCollector class
    python_collector = PythonFactCollector()

    # Get the python fact using method collect of the
    # PythonFactCollector class
    python_facts = python_collector.collect()

    # Check if the method collect of the PythonFactCollector class
    # works correctly
    assert isinstance(python_facts, dict), \
        'The python facts are not in a dictionary'

    # Check if the python fact has the expected keys
    expected_keys = ['python']
    for key in expected_keys:
        assert key in python_facts, \
            'The python facts do not have the expected key "%s"' \
            % key


# Generated at 2022-06-23 01:35:56.217233
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert "python" in facts

# vim: set et sw=4 ts=4  :

# Generated at 2022-06-23 01:35:59.040401
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:36:00.604525
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == "python"

# Generated at 2022-06-23 01:36:03.857853
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collection = PythonFactCollector()
    assert fact_collection.name == 'python'
    assert fact_collection._fact_ids == set()


# Generated at 2022-06-23 01:36:06.215874
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc.name == 'python'
    assert py_fc._fact_ids == set()


# Generated at 2022-06-23 01:36:07.611090
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    result = PythonFactCollector()
    assert result is not None

# Generated at 2022-06-23 01:36:12.983394
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    instance = PythonFactCollector()
    result = instance.collect()
    assert isinstance(result, dict)
    assert 'python' in result
    assert isinstance(result['python'], dict)
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']

# Generated at 2022-06-23 01:36:16.558474
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Get test fixture object
    f = PythonFactCollector()

    # Call method collect and get result
    result = f.collect(collected_facts=None)

    # Assert the method returns a dictionary
    assert isinstance(result, dict), 'The method PythonFactCollector.collect does not return a dict'

# Generated at 2022-06-23 01:36:18.743105
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.__doc__ is not None


# Generated at 2022-06-23 01:36:29.545150
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollectorInvalidCollectorError
    from ansible.module_utils.facts.collector.python import PythonFactCollector
    facts_collector = FactsCollector()

    # Create Python fact collector
    fact_collector_cls = PythonFactCollector()
    assert isinstance(fact_collector_cls, BaseFactCollector)
    assert issubclass(fact_collector_cls.__class__, BaseFactCollector)
    assert isinstance(fact_collector_cls, PythonFactCollector)
    assert issubclass(fact_collector_cls.__class__, PythonFactCollector)



# Generated at 2022-06-23 01:36:33.611777
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()

    python_facts = p.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-23 01:36:43.297339
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    randomfacts = {'ansible_test': 'random'}
    facts = collector.collect(collected_facts=randomfacts)
    assert isinstance(facts, dict)
    assert facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-23 01:36:46.657463
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_obj = PythonFactCollector()
    assert python_fact_obj.name == 'python'
    assert python_fact_obj != None

# Generated at 2022-06-23 01:36:48.766718
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()

    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:36:50.694768
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:37:01.999551
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleFailJson
    from ansible_collections.ansible.community.tests.unit.modules.utils import ModuleTestCase
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    from ansible_collections.ansible.community.plugins.module_utils import basic
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes


# Generated at 2022-06-23 01:37:06.891849
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert 'python' in result.keys()
    assert 'version' in result['python'].keys()
    assert 'version_info' in result['python'].keys()
    assert 'executable' in result['python'].keys()
    assert 'has_sslcontext' in result['python'].keys()
    assert 'type' in result['python'].keys()

# Generated at 2022-06-23 01:37:12.140982
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts.keys()
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-23 01:37:15.975022
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_obj = PythonFactCollector()
    test_obj.collect()
    collected_facts = {}
    collected_facts = test_obj.collect(collected_facts=collected_facts)
    assert collected_facts != {}

# Generated at 2022-06-23 01:37:26.472871
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors import default_collectors
    python_fact_collector = PythonFactCollector(default_collectors)
    actual = python_fact_collector.collect()
    expected = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:37:34.846614
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import get_collector_facts

    Collector.collectors = default_collectors
    facts = get_collector_facts(dict(), dict(), 'setup', ['python'], False)

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys

# Generated at 2022-06-23 01:37:40.070012
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()

    assert facts['python']['version']['major'] is not None
    assert facts['python']['version_info'] is not None
    assert facts['python']['executable'] is not None

# Generated at 2022-06-23 01:37:49.530196
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect() == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }}

# Generated at 2022-06-23 01:37:53.009839
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect()['python']['version']['major'] == 3
    assert f.collect()['python']['has_sslcontext'] is True


# Generated at 2022-06-23 01:38:01.066189
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test if PythonFactCollector.collect() works
    :return:
    """
    from ansible.module_utils.facts.collector import collector_get
    py_collector = collector_get('python')
    py_facts = py_collector.collect()
    assert 'python' in py_facts.keys()
    assert 'version' in py_facts['python'].keys()
    assert 'version_info' in py_facts['python'].keys()
    assert 'executable' in py_facts['python'].keys()
    assert 'has_sslcontext' in py_facts['python'].keys()

# Test if version info are valid

# Generated at 2022-06-23 01:38:08.400815
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ Tests for method collect of class PythonFactCollector """

    result = PythonFactCollector.collect()
    assert result is not None
    assert result['python'] is not None
    assert result['python']['version'] is not None
    assert result['python']['version']['major'] is not None
    assert result['python']['version']['minor'] is not None
    assert result['python']['version']['micro'] is not None
    assert result['python']['version']['releaselevel'] is not None
    assert result['python']['version']['serial'] is not None
    assert result['python']['version_info'] is not None
    assert result['python']['executable'] is not None

# Generated at 2022-06-23 01:38:13.408349
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert issubclass(PythonFactCollector, BaseFactCollector)
    assert PythonFactCollector.name == 'python'
    assert isinstance(PythonFactCollector._fact_ids, set)
    assert len(PythonFactCollector._fact_ids) == 0
    py_fact_collector = PythonFactCollector()
    assert isinstance(py_fact_collector, PythonFactCollector)


# Generated at 2022-06-23 01:38:15.768086
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert isinstance(python_facts.collect(), dict)



# Generated at 2022-06-23 01:38:23.083871
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    result = py_collector.collect()
    assert result['python']['type'] == 'CPython'
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert result['python']['version_info'][0] == sys.version_info[0]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:38:23.914472
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-23 01:38:27.406050
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test with missing arguments
    assert PythonFactCollector()

    # Test with all available arguments
    assert PythonFactCollector(namespace='namespace', ext_fact_chdir='ext_fact_chdir', collect_subset='all')

# Generated at 2022-06-23 01:38:29.290228
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test initialization
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:38:38.368716
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    py_facts = py_collector.collect()

    assert py_facts['python']['version']['major'] > 0
    assert py_facts['python']['version']['minor'] > 0
    assert py_facts['python']['version']['micro'] > 0
    assert py_facts['python']['version']['releaselevel'] in ('alpha', 'beta', 'candidate', 'final')
    assert isinstance(py_facts['python']['version']['serial'], int)
    assert py_facts['python']['version_info'] == list(sys.version_info)
    assert isinstance(py_facts['python']['executable'], basestring)

# Generated at 2022-06-23 01:38:42.244281
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], basestring)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)


# Generated at 2022-06-23 01:38:52.260324
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect(module=None, collected_facts=None)

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]

# vim: set expandtab shiftwidth=4 softtabstop=4:

# Generated at 2022-06-23 01:38:54.450533
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:38:58.108875
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None

if __name__ == '__main__':
    test_PythonFactCollector()

# Generated at 2022-06-23 01:39:07.884670
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fc = PythonFactCollector()
    result = python_fc.collect()

    assert result == {'python': {
        'has_sslcontext': HAS_SSLCONTEXT,
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'type': 'cpython'}}

# Generated at 2022-06-23 01:39:12.468171
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect() is not None

# Generated at 2022-06-23 01:39:20.807464
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector_facts = fact_collector.collect()
    assert 'python' in fact_collector_facts.keys()
    assert 'executable' in fact_collector_facts['python'].keys()
    assert 'type' in fact_collector_facts['python'].keys()
    assert 'version' in fact_collector_facts['python'].keys()
    assert 'version_info' in fact_collector_facts['python'].keys()
    assert 'has_sslcontext' in fact_collector_facts['python'].keys()

# Generated at 2022-06-23 01:39:28.733719
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # Set up a module and its arguments
    module = basic.AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list'),
            'gather_timeout': dict(default=10, type='int'),
            'filter': dict(default='*', required=False)
        }
    )

    # Collect facts
    # We cannot use TestAnsibleModule because we need to mock the collect
    # method of the PythonFactCollector class
    pfc = collector.PythonFactCollector()
    pfc.collect(module, {})

# Generated at 2022-06-23 01:39:32.895186
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.python_collector import PythonFactCollector
    pfc = PythonFactCollector()
    assert pfc.collect()