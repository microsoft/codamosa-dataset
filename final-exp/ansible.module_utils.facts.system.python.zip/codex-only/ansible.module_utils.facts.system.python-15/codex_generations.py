

# Generated at 2022-06-23 01:29:32.998950
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector_obj = PythonFactCollector('', None, {})
    assert isinstance(python_fact_collector_obj, PythonFactCollector)


# Generated at 2022-06-23 01:29:34.530162
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:29:42.234683
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:29:43.692347
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # No code to test here as it is just a class.
    pass

# Generated at 2022-06-23 01:29:51.249315
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert isinstance(python_facts['python']['version'], dict)
    assert 'version_info' in python_facts['python']
    assert isinstance(python_facts['python']['version_info'], list)
    assert 'executable' in python_facts['python']
    assert isinstance(python_facts['python']['executable'], str)
    assert 'type' in python_facts['python']

# Generated at 2022-06-23 01:30:00.771041
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()
    assert PythonFactCollector.collect()['python']['version']['major'] == sys.version_info[0]
    assert PythonFactCollector.collect()['python']['version']['minor'] == sys.version_info[1]
    assert PythonFactCollector.collect()['python']['version']['micro'] == sys.version_info[2]
    assert PythonFactCollector.collect()['python']['version']['releaselevel'] == sys.version_info[3]
    assert PythonFactCollector.collect()['python']['version']['serial'] == sys.version_info[4]
    assert PythonFactCollector.collect()['python']['version_info'] == list

# Generated at 2022-06-23 01:30:06.300953
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    collector = PythonFactCollector()

    python_facts = collector.collect(module=None, collected_facts=None)

    assert python_facts['python'] is not None

# Generated at 2022-06-23 01:30:08.888674
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collector import FactCollector
    collector = FactCollector('python')
    assert collector is not None

# Generated at 2022-06-23 01:30:10.455466
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-23 01:30:12.145941
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector()
    assert pythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:30:15.344818
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None
    assert python_fact_collector.name == "python"

# Generated at 2022-06-23 01:30:20.808865
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    sys.modules['ansible_collector'] = sys.modules['ansible.module_utils.facts.collector']
    from ansible.module_utils.facts.collector import PythonFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    f = PythonFactCollector(None, None)
    assert isinstance(f, BaseFactCollector)



# Generated at 2022-06-23 01:30:22.167438
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    python_collector.collect()

# Generated at 2022-06-23 01:30:30.914067
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = pc.collect()
    assert facts is not None
    assert 1 == len(facts)
    assert 'python' in facts
    for key in ['version', 'version_info', 'executable', 'has_sslcontext']:
        assert key in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 5 == len(facts['python']['version_info'])
    assert isinstance(facts['python']['version_info'], list)
    assert 'type' in facts['python']


# Generated at 2022-06-23 01:30:41.556382
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None)
    python_facts = collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python

# Generated at 2022-06-23 01:30:47.309398
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert facts['python']['version_info'] == list(sys.version_info)
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-23 01:30:59.552693
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
     pfc = PythonFactCollector()
     pf = pfc.collect()
     assert 'python' in pf, "python facts missing"

     assert 'type' in pf['python'], "python['type'] missing"
     assert 'version' in pf['python'], "python['version'] missing"
     assert 'version_info' in pf['python'], "python['version_info'] missing"
     assert 'executable' in pf['python'], "python['executable'] missing"
     assert 'has_sslcontext'in pf['python'], "python['has_sslcontext'] missing"
     assert 'major' in pf['python']['version'], "python['version']['major'] missing"

# Generated at 2022-06-23 01:31:09.474640
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    fact_dict = pfc.collect()
    assert fact_dict == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-23 01:31:11.946956
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()


# Generated at 2022-06-23 01:31:14.666289
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert len(pfc._fact_ids) == 0
    assert hasattr(pfc, 'collect')

# Generated at 2022-06-23 01:31:16.648040
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    module = None
    collected_facts = None
    assert fc.collect(module, collected_facts)

# Generated at 2022-06-23 01:31:18.655141
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()


# Generated at 2022-06-23 01:31:21.233427
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()
    assert pyfc.name == 'python'
    assert pyfc._fact_ids == set()

# Generated at 2022-06-23 01:31:30.834066
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector object
    pfc = PythonFactCollector()
    # Create a dictionary to collect the collected_facts
    collected_facts = {}
    # Execute collect method of the PythonFactCollector object
    new_facts = pfc.collect(collected_facts=collected_facts)
    # Verify that the returned type of the method is a dictionary
    assert type(new_facts) == dict

# Generated at 2022-06-23 01:31:39.438288
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    py_result = py_collector.collect()
    assert 'python' in py_result
    assert 'version' in py_result['python']
    assert isinstance(py_result['python']['version'], dict)
    assert 'version_info' in py_result['python']
    assert isinstance(py_result['python']['version_info'], list)
    assert 'executable' in py_result['python']
    assert 'has_sslcontext' in py_result['python']
    assert 'type' in py_result['python']

# Generated at 2022-06-23 01:31:42.244405
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert hasattr(python_fact_collector, "collect")
    assert callable(python_fact_collector.collect)


# Generated at 2022-06-23 01:31:44.247143
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Unit test to check the sslcontext import

# Generated at 2022-06-23 01:31:48.853718
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test the constructor of the PythonFactCollector class"""
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:31:51.854555
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector()
    assert pythonFactCollector.name == 'python'
    assert pythonFactCollector._fact_ids == set(['python'])


# Generated at 2022-06-23 01:32:01.607475
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None, None)

    py3_facts = collector.collect(None, None)
    assert py3_facts['python'] == {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'type': 'CPython',
        'has_sslcontext': HAS_SSLCONTEXT
    }

    assert 'CPython' in py3_facts['python']['type']

# Generated at 2022-06-23 01:32:12.882971
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
        }
    }


# Generated at 2022-06-23 01:32:14.635528
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'

# Generated at 2022-06-23 01:32:24.864855
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    from distutils.version import LooseVersion
    from ansible.module_utils.basic import AnsibleModule, env_fallback
    from ansible.module_utils.facts import timeout
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule({}, BytesIO(), 'fake')
    module.exit_json = lambda **x: x

    module.params['gather_timeout'] = timeout.DEFAULT_GATHER_TIMEOUT_VALUE

    # Mock AnsibleModule.run_command
    module.run_command = lambda **x: (0, module.params['gather_timeout'])
    module._socket_path = '/no/host.socket'

    version = LooseVersion(platform.python_version())
    PYTHON_TYPE = module.get_bin_path('python')

# Generated at 2022-06-23 01:32:29.976383
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''
    Unit test to test constructor of class PythonFactCollector
    '''
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-23 01:32:32.877760
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''
    Test constructor of class PythonFactCollector
    '''
    py_fact_collector = PythonFactCollector()

    assert py_fact_collector.name == 'python'


# Generated at 2022-06-23 01:32:41.586463
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = {}
    python_fact_collector = PythonFactCollector()
    collected_facts.update(python_fact_collector.collect())

    assert (len(collected_facts['python']) == 5)
    assert (collected_facts['python']['executable'] == \
        sys.executable)
    assert (collected_facts['python']['has_sslcontext'] == \
        HAS_SSLCONTEXT)
    assert (collected_facts['python']['version']['major'] == \
        sys.version_info[0])
    assert (collected_facts['python']['version']['minor'] == \
        sys.version_info[1])

# Generated at 2022-06-23 01:32:42.632045
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    tester = PythonFactCollector()
    assert tester

# Generated at 2022-06-23 01:32:50.696510
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector object
    python_fact_collector = PythonFactCollector()

    # Assert the execution of the method
    python_facts = python_fact_collector.collect()

    # Assert the result
    assert python_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
        }
    }

    # Additional assert, Python

# Generated at 2022-06-23 01:32:59.168770
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert facts['python']['version_info'][0] == sys.version_info[0]
    assert facts['python']['version_info'][1] == sys.version_info[1]
    assert facts['python']['version_info'][2] == sys.version_info[2]
    assert facts['python']['version_info'][3] == sys.version_info[3]
    assert facts['python']['version_info'][4] == sys.version_info[4]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-23 01:33:09.476597
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    result = python_collector.collect()

    print(result['python']['version_info'])
    print(result['python']['version']['major'])
    print(result['python']['version']['minor'])
    print(result['python']['version']['micro'])
    print(result['python']['version']['releaselevel'])
    print(result['python']['version']['serial'])
    print(result['python']['executable'])
    print(result['python']['type'])
    print(result['python']['has_sslcontext'])

# Run test
test_PythonFactCollector_collect()

# Generated at 2022-06-23 01:33:13.987512
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()
    assert PythonFactCollector.collect()['python']['version']['major'] == 3
    assert PythonFactCollector.collect()['python']['version']['minor'] >= 3
    assert PythonFactCollector.collect()['python']['version']['micro'] >= 0

# Generated at 2022-06-23 01:33:16.450321
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)


# Generated at 2022-06-23 01:33:18.184156
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact = PythonFactCollector()

    assert fact.name == 'python'
    assert fact._fact_ids == set()

# Generated at 2022-06-23 01:33:20.194721
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:33:29.857771
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  """
  Test if the collect method returns an expected dictionary when called
  """

  # Define the expected result
  expected_result = {
    'python': {
      'version': {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
      },
      'version_info': list(sys.version_info),
      'executable': sys.executable,
      'has_sslcontext': HAS_SSLCONTEXT,
      'type': sys.implementation.name if hasattr(sys, 'implementation') else None
    }
  }

  # Create a new PythonFactCollector instance and call method

# Generated at 2022-06-23 01:33:32.673421
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector
    assert fact_collector.name == 'python'


# Generated at 2022-06-23 01:33:34.524961
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-23 01:33:36.289204
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect(collected_facts=None)

# Generated at 2022-06-23 01:33:42.028397
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-23 01:33:43.864838
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()

    # This assertion ensures that the class constructor is working as expected.
    assert isinstance(p, BaseFactCollector)

# Generated at 2022-06-23 01:33:47.485284
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    assert py_collector.collect()['python']['version_info'] == list(sys.version_info)
    assert py_collector.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:33:50.172251
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    # _fact_ids is supposed to be empty
    assert not PythonFactCollector._fact_ids

# Generated at 2022-06-23 01:33:52.431001
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Check that facts of python version are present
# when run.

# Generated at 2022-06-23 01:33:53.026201
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-23 01:33:59.635524
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    python_facts = fact_collector.get_facts()
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], basestring)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-23 01:34:02.603810
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids is not None

# Generated at 2022-06-23 01:34:15.648675
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    fact = fc.collect()
    assert fact['python']['version']['major'] == sys.version_info[0]
    assert fact['python']['version']['minor'] == sys.version_info[1]
    assert fact['python']['version']['micro'] == sys.version_info[2]
    assert fact['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact['python']['version']['serial'] == sys.version_info[4]
    assert fact['python']['version_info'] == list(sys.version_info)
    assert fact['python']['executable'] == sys.executable

# Generated at 2022-06-23 01:34:26.105086
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    # Mock sys parameters
    sys.version_info = (2, 7, 14, 'final', 0)
    sys.executable = '/usr/bin/python'
    sys.subversion = ('CPython', '', '', '')
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-23 01:34:28.249670
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-23 01:34:31.017762
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:34:35.513973
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert isinstance(result, dict)
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-23 01:34:38.509691
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'


# Generated at 2022-06-23 01:34:45.992508
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    test = PythonFactCollector()
    facts = test.collect()

    assert facts['python']['version']['major'] == 3
    assert facts['python']['version']['minor'] == 6
    assert facts['python']['version']['micro'] == 4
    assert facts['python']['version']['releaselevel'] == 'final'
    assert facts['python']['version']['serial'] == 0
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] is True

# Generated at 2022-06-23 01:34:56.103716
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    try:
        major = sys.version_info[0]
    except AttributeError:
        major = None

    try:
        minor = sys.version_info[1]
    except AttributeError:
        minor = None

    try:
        micro = sys.version_info[2]
    except AttributeError:
        micro = None

    try:
        releaselevel = sys.version_info[3]
    except AttributeError:
        releaselevel = None

    try:
        serial = sys.version_info[4]
    except AttributeError:
        serial = None

    try:
        version_info = list(sys.version_info)
    except AttributeError:
        version_info = None

    try:
        executable = sys.executable
    except AttributeError:
        executable = None

   

# Generated at 2022-06-23 01:34:59.921863
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector(None, None)

    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:35:03.762911
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test creation of Python fact collector
    c = PythonFactCollector()
    assert isinstance(c, PythonFactCollector)
    assert isinstance(c, BaseFactCollector)
    assert c.name == 'python'
    assert c._fact_ids == set(['python'])



# Generated at 2022-06-23 01:35:05.927128
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test_PythonFactCollector = PythonFactCollector()
    assert test_PythonFactCollector.name == 'python'
    assert len(test_PythonFactCollector._fact_ids) == 0

# Generated at 2022-06-23 01:35:11.069218
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-23 01:35:16.840779
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    python_facts = python_fact_collector.collect(collected_facts=collected_facts)

    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-23 01:35:19.544760
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:35:27.559778
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    assert facts['python']['type'] == 'CPython'
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext']
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-23 01:35:31.514182
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector_obj = PythonFactCollector()
    result = PythonFactCollector_obj.collect()
    assert result
    assert 'python' in result
    assert 'version' in result['python']
    assert 'type' in result['python']

# Generated at 2022-06-23 01:35:40.958129
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert c.collect() == {'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-23 01:35:43.118806
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    res = pfc.collect()
    assert 'python' in res.keys()

# Generated at 2022-06-23 01:35:52.053685
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    result = python_collector.collect()

    assert result is not None
    assert type(result) is dict
    assert 'python' in result
    assert result['python']['executable'] is not None
    assert result['python']['version']['major'] is not None
    assert result['python']['version']['minor'] is not None
    assert result['python']['version']['micro'] is not None
    assert result['python']['version']['releaselevel'] is not None
    assert result['python']['version']['serial'] is not None
    assert result['python']['version_info'] is not None

    if sys.subversion:
        assert result['python']['type'] == sys.subversion[0]
    el

# Generated at 2022-06-23 01:35:56.395564
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()
    assert pfc._collection_functions == { }


# Generated at 2022-06-23 01:36:00.719536
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert hasattr(c, 'collect')
    assert hasattr(c, '_fact_ids')
    assert isinstance(c._fact_ids, set)
    assert len(c._fact_ids) == 0

# Generated at 2022-06-23 01:36:04.971683
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    pfc = PythonFactCollector()
    py_version = sys.version_info
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()
    assert pfc.collect()['python']['version'] == {'major': py_version[0],
                                                  'minor': py_version[1],
                                                  'micro': py_version[2],
                                                  'releaselevel': py_version[3],
                                                  'serial': py_version[4]}
    assert pfc.collect()['python']['version_info'] == list(py_version)
    assert pfc.collect()['python']['executable'] == sys.executable
    assert pfc.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:36:05.897066
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Instantiation of class PythonFactCollector
    pass

# Generated at 2022-06-23 01:36:07.586632
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:36:10.336067
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p.collect()['python']['version_info'][0] == sys.version_info[0]


# Generated at 2022-06-23 01:36:17.451124
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    assert fc.collect() == {'python': {'executable': sys.executable,
                                       'has_sslcontext': HAS_SSLCONTEXT,
                                       'type': 'CPython',
                                       'version': {'major': sys.version_info[0],
                                                   'minor': sys.version_info[1],
                                                   'micro': sys.version_info[2],
                                                   'releaselevel': sys.version_info[3],
                                                   'serial': sys.version_info[4]},
                                       'version_info': list(sys.version_info)}}

# Generated at 2022-06-23 01:36:20.967684
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    _d = p.collect()
    assert 'python' in _d



# Generated at 2022-06-23 01:36:32.114115
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    actual_python_facts = PythonFactCollector().collect()

# Generated at 2022-06-23 01:36:34.080990
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    results = collector.collect()
    assert 'python' in results

# Generated at 2022-06-23 01:36:43.338588
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert python_facts == {
                    'python': {
                        'version': {
                            'major': sys.version_info[0],
                            'minor': sys.version_info[1],
                            'micro': sys.version_info[2],
                            'releaselevel': sys.version_info[3],
                            'serial': sys.version_info[4]
                        },
                        'version_info': list(sys.version_info),
                        'executable': sys.executable,
                        'has_sslcontext': HAS_SSLCONTEXT,
                        'type': 'cpython'
                    }
                }

# Generated at 2022-06-23 01:36:53.265846
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    """
    Creates a PythonFactCollector object to call the method collect.
    Uses Python version information to create dictionary to compare with
    dictionary returned by method collect.
    """

    my_collector = PythonFactCollector()
    my_dict = my_collector.collect()

    # Check that all the fields have been created

# Generated at 2022-06-23 01:37:03.220926
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.python import PythonFactCollector as test_collector

    # Create a PythonFactCollector object
    facts_collector = test_collector()

    # Test facts_collector is PythonFactCollector object
    assert isinstance(facts_collector, test_collector)

    # Test facts_collector is instance of Collector class
    assert isinstance(facts_collector, Collector)

    # Test PythonFactCollector.name is 'python'
    assert facts_collector.name == 'python'

    # Test PythonFactCollector.collect returns dict
    assert isinstance(facts_collector.collect(), dict)

# Generated at 2022-06-23 01:37:12.258110
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    result = py_fc.collect()
    assert result == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'CPython'
        }
    }

# Generated at 2022-06-23 01:37:15.706463
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector.fact_ids == frozenset(['python'])


# Generated at 2022-06-23 01:37:24.638269
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create PythonFactCollector object
    f = PythonFactCollector()

    # Assert method collect returns the expected dictionary
    assert f.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:37:31.222707
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert "python" in python_facts
    assert "version" in python_facts["python"]
    assert isinstance(python_facts["python"]["version"], dict)
    assert "version_info" in python_facts["python"]
    assert isinstance(python_facts["python"]["version_info"], list)
    assert "executable" in python_facts["python"]

# Generated at 2022-06-23 01:37:42.197794
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    result = py_collector.collect()
    assert result == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-23 01:37:43.943178
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'

# Generated at 2022-06-23 01:37:46.536848
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == "python"
    assert pfc._fact_ids == set()


# Generated at 2022-06-23 01:37:49.451957
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert isinstance(fact_collector._fact_ids, set)
    assert isinstance(fact_collector.collect(), dict)


# Generated at 2022-06-23 01:37:52.135626
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'
    assert python._fact_ids == set()


# Generated at 2022-06-23 01:37:53.699101
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert py_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:37:55.899600
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector()
    assert pythonFactCollector.name == 'python'
    assert pythonFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:37:57.890019
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert isinstance(x, BaseFactCollector)
    assert x.name == 'python'


# Generated at 2022-06-23 01:38:07.195682
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    ret = pfc.collect()
    # The first version of Python 3 did not have the attribute sys.implementation.name
    if sys.version_info[0] < 3 or (sys.version_info[0] == 3 and sys.version_info[1] == 0):
        assert 'type' not in ret['python']
    else:
        assert 'type' in ret['python']
    assert 'version' in ret['python']
    assert 'major' in ret['python']['version']
    assert 'minor' in ret['python']['version']
    assert 'micro' in ret['python']['version']
    assert 'releaselevel' in ret['python']['version']
    assert 'serial' in ret['python']['version']

# Generated at 2022-06-23 01:38:16.521640
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    sys_version_info = tuple([1, 2, 3, 'final', 0])
    sys_executable = '/usr/bin/python'
    sys_subversion = ['CPython', 'CPython', 'CPython']
    sys_implementation = type('sys_implementation', (object,), {})()
    sys_implementation.name = 'CPython'

    sys_mock = type('sys', (object,), {})()
    sys_mock.version_info = sys_version_info
    sys_mock.executable = sys_executable
    sys_mock.subversion = sys_subversion
    sys_mock.implementation = sys_implementation

    fact_collector = PythonFactCollector()
    fact_collector._module_implementation = sys_mock
    facts = fact_collector

# Generated at 2022-06-23 01:38:25.506648
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Make sure that the PythonFactCollector collects the correct attributes.
    """
    fixture = PythonFactCollector()
    assert fixture.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'cpython'
        }
    }

# Generated at 2022-06-23 01:38:27.656853
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

    print(result)

# Generated at 2022-06-23 01:38:30.292322
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert len(pfc._fact_ids) == 0


# Generated at 2022-06-23 01:38:39.260487
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_collector = PythonFactCollector()
    test_collector.collect()
    assert test_collector.collected_facts == {'python': {'version': {'major': 2,
                                                                       'minor': 7,
                                                                       'micro': 13,
                                                                       'releaselevel': 'final',
                                                                       'serial': 0},
                                                          'version_info': [2, 7, 13, 'final', 0],
                                                          'executable': '/usr/bin/python',
                                                          'has_sslcontext': True,
                                                          'type': 'CPython'}}



# Generated at 2022-06-23 01:38:41.182620
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert isinstance(f, PythonFactCollector)

    assert f.name == 'python'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:38:43.547200
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    print("Testing constructor")
    test_pythonfactcollector = PythonFactCollector(None, None)
    assert test_pythonfactcollector is not None
    assert test_pythonfactcollector.name == 'python'
    assert test_pythonfactcollector._fact_ids == set()


# Generated at 2022-06-23 01:38:54.146352
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']['version']['major'] >= 2
    assert python_facts['python']['version']['minor'] >= 6
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert python_facts['python']['version']['releaselevel'] in ('beta',
                                                                 'candidate',
                                                                 'final', 'alpha')
    assert isinstance(python_facts['python']['version']['serial'], int)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)
    assert isinstance(python_facts['python']['version_info'], list)

# Generated at 2022-06-23 01:38:57.424876
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    o = PythonFactCollector()
    assert o.name == 'python'
    assert isinstance(o._fact_ids, set)
    assert o.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-23 01:38:58.445416
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-23 01:39:01.408192
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    instance = PythonFactCollector()
    assert isinstance(instance, PythonFactCollector)

# Generated at 2022-06-23 01:39:03.973110
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"


# Generated at 2022-06-23 01:39:11.560631
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert c.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 9, 'releaselevel': 'final', 'serial': 0},
                                       'version_info': [2, 7, 9, 'final', 0],
                                       'executable': '/usr/bin/python',
                                       'has_sslcontext': False,
                                       'type': 'CPython'}}

# Generated at 2022-06-23 01:39:12.866685
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:39:14.781119
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    res = PythonFactCollector()
    assert res.name == 'python'
    assert hasattr(res, 'collect')

# Generated at 2022-06-23 01:39:18.431624
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    pythonfact = PythonFactCollector()
    assert pythonfact is not None
    assert pythonfact._fact_ids == set()
    assert pythonfact.name == 'python'
    assert pythonfact._name == 'python'


# Generated at 2022-06-23 01:39:24.808051
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Unit test for PythonFactCollector'''

    # In python 3.6, there is no ssl context
    if sys.version_info[0] == 3 and sys.version_info[1] < 7:
        assert not HAS_SSLCONTEXT
        assert 'has_sslcontext' in PythonFactCollector().collect()['python']
    else:
        assert HAS_SSLCONTEXT
        assert 'has_sslcontext' not in PythonFactCollector().collect()['python']

# Generated at 2022-06-23 01:39:28.616992
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:39:31.737544
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'