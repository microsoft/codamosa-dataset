

# Generated at 2022-06-21 12:07:16.559348
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x + 1, Range(10))) == 10



# Generated at 2022-06-21 12:07:23.872499
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 10 + 1)
    assert list(r) == list(range(1, 11))
    r = Range(1, 10 + 1, 2)
    assert list(r) == list(range(1, 11, 2))
    r = Range(1, 11, 2)
    assert list(r) == list(range(1, 11, 2))
    r = Range(10)
    assert list(r) == list(range(10))
    r = Range(10, 20)
    assert list(r) == list(range(10, 20))
    r = Range(10, 20, 1)
    assert list(r) == list(range(10, 20))
    r = Range(10, 20, 2)
    assert list(r) == list(range(10, 20, 2))

# Generated at 2022-06-21 12:07:35.782130
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(10)) == list(range(10))
    assert list(Range(1, 10 + 1)) == list(range(1, 10 + 1))
    assert list(Range(1, 10 + 1, 2)) == list(range(1, 10 + 1, 2))
    assert list(Range(0, 10 + 1, 2)) == list(range(0, 10 + 1, 2))
    assert list(Range(0, 10, 2)) == list(range(0, 10, 2))
    assert list(Range(0, 10)) == list(range(0, 10))
    assert list(Range(0)) == list(range(0))
    assert list(Range(0, 0)) == list(range(0, 0))

    # Check the invalid cases

# Generated at 2022-06-21 12:07:46.073602
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(2, range(5))) == [[0, 1], [2, 3], [4]]
    assert list(chunk(7, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(5, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(10, range(5))) == [[0, 1, 2, 3, 4]]


# Generated at 2022-06-21 12:07:51.227776
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    x = MapList(lambda x: x, [1,2,3,4,5])
    assert len(x) == 5
    x = MapList(lambda x: x, [1,2,3,4,5,6,7,9,9,10,11,12,13,14,15,16,17,18])
    assert len(x) == 18



# Generated at 2022-06-21 12:07:52.924891
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x + 1, [1, 2, 3])[0] == 2


# Generated at 2022-06-21 12:07:54.537212
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    example = LazyList(range(10))
    assert len(example) == 10

# Generated at 2022-06-21 12:08:04.877074
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(-1, range(10))) == [[]]
    assert list(chunk(0, range(10))) == [[]]
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]

test_chunk()



# Generated at 2022-06-21 12:08:05.570699
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    return []


# Generated at 2022-06-21 12:08:09.325648
# Unit test for function take
def test_take():
    for _ in range(100):
        m = random.randint(0, 100)
        assert list(take(m, range(100))) == list(range(min(m, 100)))



# Generated at 2022-06-21 12:08:18.264082
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l1 = LazyList(range(10))
    try:
        len(l1)
    except TypeError:
        pass
    else:
        raise AssertionError("expected TypeError")
    for i in range(10):
        len(l1)
    return len(l1) == 10



# Generated at 2022-06-21 12:08:20.100594
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]



# Generated at 2022-06-21 12:08:27.367520
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(3, 10, 3)) == [3, 6, 9]
    assert list(Range(3, 10, 2)) == [3, 5, 7, 9]
    assert list(Range(3, 10, 1)) == [3, 4, 5, 6, 7, 8, 9]
    assert list(Range(9, 20, 5)) == [9, 14, 19]
    assert list(Range(0, -5, -1)) == [0, -1, -2, -3, -4]

# Generated at 2022-06-21 12:08:31.794572
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(3)
    assert len(r) == 3
    r = Range(10, 15)
    assert len(r) == 5
    r = Range(1, 10, 2)
    assert len(r) == 5
    r = Range(1, 100 * 11 * 2, 100 * 2)
    assert len(r) == 11


# Generated at 2022-06-21 12:08:38.314110
# Unit test for method __next__ of class Range

# Generated at 2022-06-21 12:08:40.053394
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    llist = LazyList(range(10000))
    for i in range(1, 10):
        assert len(llist) == 10000, f"__len__ broke at {i}"

# Generated at 2022-06-21 12:08:43.475381
# Unit test for method __next__ of class Range
def test_Range___next__():
    try:
        Range(1, 2, -1).__next__()
    except ValueError:
        pass
    else:
        assert False
    try:
        Range(-1).__next__()
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-21 12:08:44.603013
# Unit test for function drop
def test_drop():
    print(list(drop(3, range(10))))
test_drop()


# Generated at 2022-06-21 12:08:55.915447
# Unit test for function scanl
def test_scanl():
    # test addition
    assert list(scanl(operator.add,[1,2,3,4])) == [1,3,6,10]
    assert list(scanl(operator.add,[1,2,3,4],0)) == [0,1,3,6,10]

    # test multiplication
    assert list(scanl(operator.mul,[1,2,3,4])) == [1,2,6,24]
    assert list(scanl(operator.mul,[1,2,3,4],5)) == [5,5,10,20,60]

    # test append
    def func(x,y):
        return x.append(y)
    assert list(scanl(func,[1,2,3,4])) == [1,2,3,4]

# Generated at 2022-06-21 12:09:07.864584
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    def check_index(index: slice, seq: List[int]) -> None:
        assert list(LazyList(seq)[index]) == seq[index]

    def check_list(list_: List[int]) -> None:
        check_index(slice(0, len(list_) + 1), list_)
        if len(list_) > 0:
            check_index(slice(1, len(list_)), list_)
            check_index(slice(1, len(list_) - 1), list_)
            check_index(slice(1, len(list_), 2), list_)
            check_index(slice(None, -1, -1), list_)
        if len(list_) > 1:
            check_index(slice(1, -1), list_)

# Generated at 2022-06-21 12:09:14.083772
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    s = LazyList([0, 1, 2])
    len(s)


# Generated at 2022-06-21 12:09:17.398452
# Unit test for constructor of class Range
def test_Range():
    assert Range(0) == range(0)
    assert Range(1, 2) == range(1, 2)
    assert Range(1, 2, 3) == range(1, 2, 3)

# Generated at 2022-06-21 12:09:29.308982
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import pytest
    from . import ListTestCase
    from .list_test_mixin import TestList
    from .test_sext import test_list_append

    class TestLazyList(TestList, ListTestCase[LazyList[int], TestList]):
        @property
        def cls(self) -> type:
            return LazyList

        @property
        def test_data(self) -> Sequence[int]:
            return [1, 2, 3, 4]

        def test_append(self, test_data: Sequence[int], instance: LazyList[int]) -> None:
            # exhaust the iterable before appending to the list
            test_list_append(self, test_data, instance)


# Generated at 2022-06-21 12:09:32.218225
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lazy_list = LazyList([1, 2, 3, 4])
    for i in range(10):
        assert lazy_list[i] == i + 1


# Generated at 2022-06-21 12:09:36.080317
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for i in range(2):
        for j in range(2):
            for k in range(2):
                t = Range(*[i, j, k])
                assert t == list(Range(i, j, k))



# Generated at 2022-06-21 12:09:41.049189
# Unit test for constructor of class MapList
def test_MapList():
    try:
        MapList(1,2)
    except TypeError:
        print("Passed")
    else:
        print("Failed")
    try:
        MapList(lambda x: x, 1)
    except TypeError:
        print("Passed")
    else:
        print("Failed")


# Generated at 2022-06-21 12:09:45.344108
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert_equals(list(Range(0, 0)), [])
    assert_equals(list(Range(0, 1)), [0])
    assert_equals(list(Range(0, 10)), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

# Generated at 2022-06-21 12:09:57.150218
# Unit test for method __getitem__ of class MapList

# Generated at 2022-06-21 12:10:00.093996
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x: x * 3, [2, 3, 4])
    assert len(lst) == 3

# Generated at 2022-06-21 12:10:06.085046
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5,10))
    assert list(drop(15, range(10))) == []
    it = iter(range(10))
    assert list(drop(5, it)) == list(range(5, 10))
    assert list(it) == list(range(5, 10))



# Generated at 2022-06-21 12:10:20.739795
# Unit test for constructor of class Range
def test_Range():
    a = Range(1, 11, 2)
    assert a[0::2] == [1, 5, 9]
    
    b = Range(10)
    assert b[0::2] == [0, 2, 4, 6, 8]

    c = Range(1, 11)
    assert c[0::2] == [1, 3, 5, 7, 9]

# Generated at 2022-06-21 12:10:27.001269
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(0))) == []
    assert list(take(5, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(10))) == []
    assert list(take(0, range(0))) == []
    assert list(take(0, range(5))) == []



# Generated at 2022-06-21 12:10:36.118608
# Unit test for constructor of class LazyList
def test_LazyList():
    def fib():
        a = 0
        b = 1
        while True:
            a, b = b, a + b
            yield a
    fib_lazy_list = LazyList(fib())
    assert fib_lazy_list[20] == fib_lazy_list[19] + fib_lazy_list[18]
    assert fib_lazy_list[:20] == [1] + fib_lazy_list[:19]
    def gen_list(n):
        for i in range(n):
            yield i
    lazy_list_len = LazyList(gen_list(10))
    assert len(lazy_list_len) == 10
    try:
        len(fib_lazy_list)
        assert False
    except:
        assert True



# Generated at 2022-06-21 12:10:39.005752
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5


# Generated at 2022-06-21 12:10:45.993346
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(0, 4, 2)
    assert list(r) == [0, 2]
    assert list(r) == [0, 2]  # can iterate more than once

    r = Range(4)
    assert list(r) == [0, 1, 2, 3]
    assert list(r) == [0, 1, 2, 3]  # can iterate more than once


# Generated at 2022-06-21 12:10:48.556252
# Unit test for function drop_until
def test_drop_until():
    data = [10,13,12,14,15,1,16]
    assert list(drop_until(lambda x: x>10,data)) == [13,12,14,15,1,16]


# Generated at 2022-06-21 12:10:52.809919
# Unit test for method __next__ of class Range
def test_Range___next__():
    r1 = Range(10)
    assert isinstance(r1, Range)

    r2 = Range(1, 10 + 1)
    assert isinstance(r2, Range)

    r3 = Range(1, 11, 2)
    assert (isinstance(r3, Range))


# Generated at 2022-06-21 12:11:02.068770
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    import random
    import string

    f = lambda s: s + '!'
    test_list = [''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(1, 10))) for _ in range(random.randint(1, 10))]
    a = MapList(f, test_list)
    length_a = len(a)
    b = MapList(f, [])
    length_b = len(b)
    c = MapList(f, [''])
    length_c = len(c)
    d = MapList(f, [1, 2, 3, 4, 5])
    length_d = len(d)

    assert length_a == len(test_list)
    assert length_b == 0
    assert length_c == 1

# Generated at 2022-06-21 12:11:04.020606
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-21 12:11:08.850713
# Unit test for constructor of class MapList
def test_MapList():
    a = [(1,2), (2,3), (3,4)]
    ai = MapList(lambda x: x[1],a)
    assert(ai[0]==2)
    assert(ai[1]==3)
    assert(ai[2]==4)
    assert(len(ai)==3)

# Generated at 2022-06-21 12:11:21.229100
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    instance = LazyList(range(0, 10))
    try:
        len(instance)
        assert False, "We should have gotten a TypeError here"
    except TypeError:
        pass
    assert len(instance[:]) == 10



# Generated at 2022-06-21 12:11:31.271096
# Unit test for constructor of class Range
def test_Range():
    # Range(stop)
    assert list(Range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(0, 10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(0, 10, 2)) == [0, 2, 4, 6, 8]
    # Range(start, stop)
    assert list(Range(1, 10)) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(1, 11, 2)) == [1, 3, 5, 7, 9]
    # Range(start, stop, step)
    assert list(Range(2, 10, 2)) == [2, 4, 6, 8]

# Unit test

# Generated at 2022-06-21 12:11:32.706624
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    assert len(lst) == 10


# Generated at 2022-06-21 12:11:35.140095
# Unit test for function drop_until
def test_drop_until():
    lst = [2,4,6,8,10,12]
    assert list(drop_until(lambda x: x > 7, lst)) == [8,10,12]
test_drop_until()



# Generated at 2022-06-21 12:11:45.019009
# Unit test for function take
def test_take():
    assert list(take(-1, range(10))) == list()
    assert list(take(0, range(10))) == list()
    assert list(take(10, range(5))) == list(range(5))
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(3, [])) == list()
    assert list(take(3, [1])) == [1]
    assert list(take(3, [1,2])) == [1, 2]
    assert list(take(3, [1,2,3])) == [1, 2, 3]
    assert list(take(3, [1,2,3,4])) == [1, 2, 3]

# Generated at 2022-06-21 12:11:50.146749
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-21 12:11:55.522676
# Unit test for function scanr
def test_scanr():
    assert [*scanr(operator.add, [])] == []
    assert [*scanr(operator.add, [1])] == [1]
    assert [*scanr(operator.add, [1, 2, 3, 4])] == [10, 9, 7, 4]
    assert [*scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])] == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:12:01.379084
# Unit test for function chunk
def test_chunk():
    list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    list(chunk(-1, range(10))) == ValueError
    with pytest.raises(ValueError):
        list(chunk(-1, range(10)))



# Generated at 2022-06-21 12:12:04.248659
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert tuple(MapList(lambda x: x + 1, [1, 2, 3])) == (2, 3, 4)



# Generated at 2022-06-21 12:12:07.362794
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-21 12:12:26.654892
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    res, err = capture_stdout(dummy.dummy_test_1)
    expected = """
dummy
dummy
dummy
dummy
dummy
""".strip()
    assert res == expected, "Got:\n{}\nExpected:\n{}".format(res, expected)



# Generated at 2022-06-21 12:12:34.595422
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range(-5, 5):
        assert Range(10)[i] == range(10)[i]
        assert Range(10)[slice(None, None, 2)][i] == range(10)[slice(None, None, 2)][i]
        assert Range(10)[slice(0, None, 2)][i] == range(10)[slice(0, None, 2)][i]
        assert Range(10)[slice(1, None, 2)][i] == range(10)[slice(1, None, 2)][i]
        assert Range(10)[slice(None, -2, 2)][i] == range(10)[slice(None, -2, 2)][i]

# Generated at 2022-06-21 12:12:37.310877
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    a = [1, 2, 3, 4, 5]
    assert isinstance(MapList(lambda x: x * x, a).__iter__(), map)



# Generated at 2022-06-21 12:12:38.451858
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Auto-generated by Spyder.
    pass


# Generated at 2022-06-21 12:12:43.158326
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

test_split_by()



# Generated at 2022-06-21 12:12:51.291042
# Unit test for function drop
def test_drop():
    assert list(drop(1, [1, 2, 3])) == [2, 3]
    assert list(drop(2, [1, 2, 3])) == [3]
    assert list(drop(3, [1, 2, 3])) == []
    assert list(drop(4, [1, 2, 3])) == []
    assert list(drop(0, [1, 2, 3])) == [1, 2, 3]
    assert list(drop(0, [])) == []



# Generated at 2022-06-21 12:12:56.326903
# Unit test for method __len__ of class Range
def test_Range___len__():
    # Test for the constructor: Range.__init__(self, *args)
    test_case = [[5], [1, 6], [1, 7, 2]]
    test_ans = [5, 5, 3]
    for i, test in enumerate(test_case):
        r = Range(*test)
        # Test for method: __len__(self)
        assert len(r) == test_ans[i]



# Generated at 2022-06-21 12:12:58.266950
# Unit test for method __len__ of class Range
def test_Range___len__():
    range_obj = Range(1, 10, 2)
    assert len(range_obj) == 5


# Generated at 2022-06-21 12:13:03.945750
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(0, 10)
    assert r[0] == 0
    assert r[-1] == 9
    assert r[2:3] == [2]
    assert r[2:] == [2, 3, 4, 5, 6, 7, 8, 9]
    assert r[:2] == [0, 1]
    assert r[:-2] == [0, 1, 2, 3, 4, 5, 6, 7]
    assert r[::2] == [0, 2, 4, 6, 8]


# Generated at 2022-06-21 12:13:09.643442
# Unit test for constructor of class MapList
def test_MapList():
    func = lambda x: x + 1
    lst = [1, 2, 3, 4, 5]
    map_list = MapList(func, lst)
    assert(map_list == [2, 3, 4, 5, 6])
    return

test_MapList()


# Generated at 2022-06-21 12:13:40.864554
# Unit test for constructor of class LazyList
def test_LazyList():
    assert list(LazyList([2, 3, 4, 5])) == [2, 3, 4, 5]
    assert LazyList([2, 3, 4, 5])[2:4] == [4, 5]
    assert LazyList([2, 3, 4, 5])[1] == 3
    assert LazyList(range(10))[0] == 0
    assert LazyList(range(10))[-1] == 9
    assert LazyList(range(10))[:] == list(range(10))
    assert LazyList(range(10))[3:-3:2] == [3, 5]
    assert LazyList([-1, 1, -2, 2, -3, 3])[::-1][1:3][1] == -3

# Generated at 2022-06-21 12:13:44.563036
# Unit test for function scanl
def test_scanl():
    assert list(scanl(min, [1, 4, 4, -10, 0, 4, 2])) == [1, 1, 1, -10, -10, -10, -10]



# Generated at 2022-06-21 12:13:52.364623
# Unit test for constructor of class Range
def test_Range():
    r = Range(3,10,2)
    assert r.length == len(r) == 3
    assert list(r) == [3, 5, 7, 9]
    assert r[0] == r[-3] == 3 and r[1] == r[-2] == 5
    assert r[2] == r[-1] == 7 and r[3] == r[-0] == 9
    assert r[slice(1, 2)] == [5, 7, 9]
    assert r[slice(2, 4)] == [7, 9]
    assert r[slice(1, 4, 2)] == [5, 9]



# Generated at 2022-06-21 12:13:56.453509
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3])) == [1, 3, 6]
    assert list(scanl(operator.add, [1, 2, 3], 10)) == [10, 11, 13, 16]



# Generated at 2022-06-21 12:14:06.222302
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range(10):
        for j in range(i + 1, 10):
            for k in range(1, 10):
                r = Range(i, j, k)
                for l in range(len(r)):
                    assert r[l] == l * k + i
                    assert r[-l - 1] == (len(r) - l - 1) * k + i
                    assert r[:] == list(r)
                    assert r[:l] == [r[l] for l in range(l)]
                    assert r[l:] == [r[l] for l in range(l, len(r))]
                    assert r[l:j] == [r[l] for l in range(l, j)]

# Generated at 2022-06-21 12:14:13.442500
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x * x, a)[0] == 1
    assert MapList(lambda x: x * x, a)[1] == 4
    assert MapList(lambda x: x * x, a)[2] == 9
    assert MapList(lambda x: x * x, a)[3] == 16
    assert MapList(lambda x: x * x, a)[4] == 25
    assert list(MapList(lambda x: x * x, a)) == [1, 4, 9, 16, 25]



# Generated at 2022-06-21 12:14:18.358999
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(100))
    it = iter(lst)
    a = [next(it) for _ in range(20)]
    b = next(it)
    c = list(lst)
    d = list(it)
    assert a == lst[:20]
    assert b == lst[20]
    assert c == lst[:]
    assert d == lst[21:]



# Generated at 2022-06-21 12:14:19.962274
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    print(MapList(lambda x: x*x, [1,2]).__len__())

# Generated at 2022-06-21 12:14:29.426056
# Unit test for function scanl
def test_scanl():
    a = [1, 2, 3, 4, 5]
    assert list(scanl(lambda x, y: x + y, a)) == [1, 3, 6, 10, 15]
    assert list(scanl(lambda x, y: x + y, a, 0)) == [0, 1, 3, 6, 10, 15]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
test_scanl()



# Generated at 2022-06-21 12:14:38.761625
# Unit test for function drop_until
def test_drop_until():
    pred = lambda x: x % 2 != 0
    targets = [
        [[], [], []],
        [[0], [0, 1], [1]],
        [[0, 2], [0, 2, 3], [3]],
        [[2], [2, 4, 6], [4, 6]],
        [[1, 3], [1, 3, 4, 5, 6], [4, 5, 6]],
        [[1, 3, 5], [1, 3, 5, 6, 7, 8], [6, 7, 8]],
    ]
    for input, expected_drop, expected_rest in targets:
        drop = list(drop_until(pred, input))
        assert drop == expected_drop
        assert list(drop_until(pred, drop)) == expected_rest



# Generated at 2022-06-21 12:15:06.674288
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(1, 10 + 1)) == list(range(1, 10 + 1))
    assert list(Range(1, 10 + 1, 2)) == list(range(1, 10 + 1, 2))
    with pytest.raises(ValueError):
        Range('a', 10)
    with pytest.raises(ValueError):
        Range(1, 10, 'a')


# Generated at 2022-06-21 12:15:12.520515
# Unit test for constructor of class MapList
def test_MapList():
    ml = MapList(lambda x:x * x, range(5))
    assert len(ml) == 5
    assert ml[2] == 4
    assert [ml[i] for i in [1,3]] == [1,9]
    assert list(ml) == [0,1,4,9,16]


# Generated at 2022-06-21 12:15:17.206662
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    """Test for method __len__ of class LazyList"""
    for i in range(4):
        if i == 0:
            iterable = []
        else:
            iterable = range(i)
        obj = LazyList(iterable)
        assert len(obj) == i

# Generated at 2022-06-21 12:15:19.945107
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert isinstance(Range(10).__iter__(), Iterator)

# Generated at 2022-06-21 12:15:24.202855
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    # An instance of MapList
    # int -> int
    func = lambda x: x + 1
    # int list
    lst = [1, 2, 3]
    # MapList[int]
    ml = MapList(func, lst)
    assert len(ml) == 3


# Generated at 2022-06-21 12:15:32.196118
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, [])) == []
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(0, range(10))) == ValueError
    assert list(chunk(-1, range(10))) == ValueError



# Generated at 2022-06-21 12:15:41.473580
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, [])) == []
    assert list(chunk(3, [1, 2])) == [[1, 2]]
    assert list(chunk(3, [1, 2, 3, 4])) == [[1, 2, 3], [4]]
    assert list(chunk(3, [1, 2, 3, 4, 5])) == [[1, 2, 3], [4, 5]]



# Generated at 2022-06-21 12:15:46.876178
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert len(lst) == 10
    assert lst[5] == 6
    lst = LazyList(range(100))
    assert lst[0] == 0



# Generated at 2022-06-21 12:15:59.173624
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[0] == 0
    assert Range(10)[12] == 12
    assert Range(10)[:3] == [0, 1, 2]
    assert Range(10)[3:6] == [3, 4, 5]
    assert Range(10)[3:-1] == [3, 4, 5, 6, 7, 8]
    assert Range(10)[:5:2] == [0, 2, 4]
    assert Range(10)[:5:-2] == []
    assert Range(10)[5:2:-2] == [5, 3]
    assert Range(10, 15)[-1] == 14
    assert Range(10, 15)[2:5] == [12, 13, 14]
    assert Range(10, 15)[:5:2] == [10, 12, 14]

# Generated at 2022-06-21 12:16:05.118383
# Unit test for function take
def test_take():
    assert list(take(0, 'abc')) == []
    assert list(take(1, 'abc')) == ['a']
    assert list(take(2, 'abc')) == ['a', 'b']
    assert list(take(3, 'abc')) == ['a', 'b', 'c']
    assert list(take(4, 'abc')) == ['a', 'b', 'c']

