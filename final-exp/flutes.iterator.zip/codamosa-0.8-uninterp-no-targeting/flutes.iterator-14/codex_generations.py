

# Generated at 2022-06-21 12:07:24.034197
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import pytest
    from collections import Iterator
    from operator import getitem, methodcaller
    from .util import assert_equivalent, assert_equivalent_predicate

    iterable = range(10)

    lst_empty = LazyList(iterable)
    assert_equivalent(range(10), lst_empty)
    len(lst_empty)

    lst_half_1 = LazyList(iterable)
    for i in range(5):
        lst_half_1[i]
    assert_equivalent(range(10), lst_half_1)
    len(lst_half_1)

    lst_half_2 = LazyList(iterable)
    it = iter(lst_half_2)
    for _ in range(5):
        next(it)
   

# Generated at 2022-06-21 12:07:34.243737
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(0,10,1)
    assert r.val == 0
    assert next(r) == 0
    assert r.val == 1
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert r.val == 7
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    try:
        next(r)
        assert False
    except StopIteration as e:
        assert True
    assert r.val == 10

# Generated at 2022-06-21 12:07:44.918236
# Unit test for constructor of class MapList
def test_MapList():
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import lists
    from hypothesis.strategies import composite
    from collections import Counter
    from itertools import count

    # Test for constructor
    @composite
    def intmap(draw):
        l = draw(lists(integers()))
        return MapList(lambda x: x * 2, l)

    @given(intmap())
    def test_MapList_index(x):
        assert all(a == b for a, b in zip(x, map(lambda t: t * 2, x.list)))

    # Test for __getitem__

# Generated at 2022-06-21 12:07:55.749772
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from pytility import identity, times

    def test_case(n, expected_result):
        ll = LazyList(times(n, identity, 0))
        i = iter(ll)
        next_n = next(i, None)
        assert ll.list == []
        assert ll.exhausted is False
        assert i.index == 0
        assert next_n == 0
        assert ll.list == [0]
        assert ll.exhausted is False
        assert i.index == 1
        assert next(i) == 1
        assert ll.list == [0, 1]
        assert ll.exhausted is False
        assert i.index == 2
        assert list(i) == expected_result
        assert ll.list == list(range(n))
        assert ll.exhausted is True
        assert i.index

# Generated at 2022-06-21 12:08:06.332590
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def f(x : int) -> int:
        return x * x
    m = MapList(f, [1, 2, 3, 4, 5])
    assert m[0] == 1
    assert m[1] == 4
    assert m[2] == 9
    assert m[3] == 16
    assert m[4] == 25
    assert m[-1] == 25
    assert m[-2] == 16
    assert m[-3] == 9
    assert m[-4] == 4
    assert m[-5] == 1
    assert m[:2] == [1, 4]
    assert m[-1:] == [25]
    assert m[-2:-1] == [16]
    assert m[-5:-1] == [1, 4, 9, 16]

# Generated at 2022-06-21 12:08:13.800304
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(1, 11))
    assert lst[4] == 5
    assert lst[-1] == 10
    lst = LazyList(range(20, 100, 2))
    assert lst[9:11] == [42, 44]
    assert lst[-3:] == [92, 94, 96, 98]
    lst = LazyList(range(10))
    assert lst[10:20] == []
    assert list(lst) == list(range(10))

# Generated at 2022-06-21 12:08:15.912854
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3])
    assert lst[0] == 1
    assert len(lst) == 3



# Generated at 2022-06-21 12:08:20.282269
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    func = lambda x: x[::-1]
    lst = ['a', 'bcd', 'efg', 'hijkl']
    m = MapList(func, lst)
    assert list(m) == func(lst)



# Generated at 2022-06-21 12:08:30.103957
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    x = LazyList([1, 2, 3, 4, 5])
    y = list(LazyList([1, 2, 3, 4, 5]))
    assert y[0] == 1
    assert y[1] == 2
    assert y[2] == 3
    assert y[3] == 4
    assert y[4] == 5
    y = list(LazyList([1, 2, 3, 4, 5])[3:])
    assert y[0] == 4
    assert y[1] == 5
    y = list(LazyList([1, 2, 3, 4, 5])[:-2])
    assert y[0] == 1
    assert y[1] == 2
    assert y[2] == 3

# Generated at 2022-06-21 12:08:36.321478
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: (x + y, x - y), [(1, 2), (3, 4), (5, 6), (7, 8)])) == [(1, 2), (4, -1), (9, 5), (16, 11)]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]



# Generated at 2022-06-21 12:08:59.600613
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import pytest
    from common_utils.test_utils import compare_iterators

    ll = LazyList(range(1, 1000000))
    assert ll == list(range(1, 1000000))
    assert compare_iterators(ll, range(1, 1000000))

    ll = LazyList(range(1, 1000000))
    for x in ll:
        pass
    assert compare_iterators(ll, range(1, 1000000))

    ll = LazyList(range(5))
    assert compare_iterators(ll, range(5))
    assert next(ll) == 0
    assert hasattr(ll, "__next__")
    it = iter(ll)
    assert it is not ll
    assert compare_iterators(it, range(1, 5))

# Generated at 2022-06-21 12:09:06.417012
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:09:15.324673
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(10))) == [3, 4, 5, 6, 7, 8, 9]
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(-1, range(10))) == [i for i in range(10)]
    assert list(drop(-10, range(10))) == [i for i in range(10)]
    assert list(drop(-12, range(10))) == [i for i in range(10)]
test_drop()



# Generated at 2022-06-21 12:09:17.983870
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(10))
    assert list(ll) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 12:09:29.827690
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    import time

    # Case 1: get the first 1000 elements of a sequence
    print('CASE 1')
    print('Test for getting the first 1000 elements of a sequence:')
    a = list(range(10000))
    random.shuffle(a)
    lst = LazyList(a)
    t0 = time.time()
    b = 100 * [None]
    for i in range(100):
        b[i] = lst[i]
    t1 = time.time()
    print('Time needed:', t1 - t0, 'seconds')
    print()

    # Case 2: get a list of random indices of a sequence
    print('CASE 2')
    print('Test for getting a list of random indices of a sequence:')
    a = list(range(10000))
    random.sh

# Generated at 2022-06-21 12:09:41.121035
# Unit test for method __next__ of class Range
def test_Range___next__():
    import sys
    epsilon = sys.float_info.epsilon
    r = Range(0, 1, 0.1)
    assert abs(next(r) - 0) < epsilon
    assert abs(next(r) - 0.1) < epsilon
    assert abs(next(r) - 0.2) < epsilon
    assert abs(next(r) - 0.3) < epsilon
    assert abs(next(r) - 0.4) < epsilon
    assert abs(next(r) - 0.5) < epsilon
    assert abs(next(r) - 0.6) < epsilon
    assert abs(next(r) - 0.7) < epsilon
    assert abs(next(r) - 0.8) < epsilon

# Generated at 2022-06-21 12:09:52.504392
# Unit test for constructor of class Range
def test_Range():
    r = Range(5)
    assert list(r) == [0, 1, 2, 3, 4]
    r = Range(1, 6)
    assert list(r) == [1, 2, 3, 4, 5]
    r = Range(1, 6, 2)
    assert list(r) == [1, 3, 5]

    # Test indexing
    assert r[0] == 1
    assert r[1] == r[-4] == 3
    assert r[2] == r[-3] == 5
    assert r[3] == r[-2] == IndexError

    # Test slice
    assert r[::2] == [1, 5]
    assert r[-1:] == [5]
    assert r[1:4] == [3, 5]


# Generated at 2022-06-21 12:09:56.742967
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    """Test method __len__ of class LazyList."""
    lst = LazyList(range(10))
    with raises(TypeError):
        len(lst)
    lst.__getitem__(9)
    assert len(lst) == 10



# Generated at 2022-06-21 12:10:02.897131
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x % 2 == 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x % 2 == 1, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 10, range(10))) == []


# Generated at 2022-06-21 12:10:15.875828
# Unit test for constructor of class Range
def test_Range():
    def test_eq(a, b):
        print(f"Testing `{a}` and `{b}`...")
        assert a == b
        assert len(a) == len(b)
        assert all(x == y for x, y in zip(a, b))
    test_eq(Range(10), range(0, 10, 1))
    test_eq(Range(10, 0), range(10, 0, -1))
    test_eq(Range(10, 0, -1), range(10, 0, -1))
    test_eq(Range(0, 10), range(0, 10, 1))
    test_eq(Range(0, 10, 2), range(0, 10, 2))
    test_eq(Range(10, 0, -2), range(10, 0, -2))
    test

# Generated at 2022-06-21 12:10:34.908182
# Unit test for function split_by
def test_split_by():
    for empty_segments in (False, True):
        assert list(split_by(range(10), empty_segments, criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
        assert list(split_by(range(10), empty_segments, criterion=lambda x: x % 2 == 0)) == [[1], [3], [5], [7], [9]]
        assert list(split_by([], empty_segments)) == [[]] if empty_segments else []

        assert list(split_by(" Split by: ", empty_segments, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

# Generated at 2022-06-21 12:10:47.063949
# Unit test for function split_by
def test_split_by():
    for criterion in (lambda x: x % 3 == 0, lambda x: x % 5 == 0):
        for empty_segments in (True, False):
            for it in range(10):
                splitted = split_by(range(it), criterion=criterion, empty_segments=empty_segments)
                result = list(splitted)
                assert result == [list(i) for i in split_by(range(it), criterion=criterion, empty_segments=empty_segments)]
                assert all(len(group) == 2 for group in result)
                assert result == list(split_by(range(it+1), empty_segments=empty_segments, criterion=criterion))

# Generated at 2022-06-21 12:10:56.582995
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert isinstance(Range(1, 2).__iter__(), Iterator)
    assert list(Range(1, 2).__iter__()) == [1]
    assert isinstance(Range(1, 3).__iter__(), Iterator)
    assert list(Range(1, 3).__iter__()) == [1, 2]
    assert isinstance(Range(1, 4).__iter__(), Iterator)
    assert list(Range(1, 4).__iter__()) == [1, 2, 3]
    assert isinstance(Range(1, 5).__iter__(), Iterator)
    assert list(Range(1, 5).__iter__()) == [1, 2, 3, 4]
    assert isinstance(Range(1, 6).__iter__(), Iterator)

# Generated at 2022-06-21 12:11:00.013897
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(0, 10)
    assert list(r) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-21 12:11:10.406317
# Unit test for function split_by
def test_split_by():
    assert split_by(iterable=[], empty_segments=True, criterion=lambda x: x % 3 == 0) == [], \
        'Failed to split an empty iterable'
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]], \
        "Failed to split iterable by the criterion"
    assert split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0) == [[1, 2], [4, 5], [7, 8], []], \
        "Failed to split iterable with empty elements"

# Generated at 2022-06-21 12:11:12.305633
# Unit test for method __next__ of class Range
def test_Range___next__():
    r=Range(5,5,5)
    assert r.__next__()==5



# Generated at 2022-06-21 12:11:15.552910
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    a = LazyList(range(5))
    b = zip(a, range(5))
    assert list(b) == [(0, 0), (1, 1), (2, 2), (3, 3), (4, 4)]

# Generated at 2022-06-21 12:11:19.377391
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList([1, 2, 3])
    assert isinstance(lst, Sequence)
    assert lst[0] == 1
    assert lst[1] == 2
    assert lst[2] == 3
    assert lst[0] == 1



# Generated at 2022-06-21 12:11:29.369109
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda x, y: y + x, 'abcd')) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda x, y: y + x, [1, 2, 3, 4])) == [10, 9, 7, 4]
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4]
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, 'abcd', 'e')) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:11:33.085777
# Unit test for constructor of class LazyList
def test_LazyList():
    lazy_list = LazyList(range(5))
    assert len(lazy_list) == 5
    assert lazy_list[0] == 0
    assert lazy_list[-1] == 4
    assert lazy_list[0:5:2] == [0, 2, 4]
    assert len(lazy_list) == 5


# Generated at 2022-06-21 12:11:50.984431
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert lst[:3] == [0, 1, 2]
    assert lst[1] == 1
    assert lst[:2] == [0, 1]
    lst = LazyList(range(10))  # noqa


# Generated at 2022-06-21 12:11:55.299076
# Unit test for method __next__ of class Range
def test_Range___next__():
    tester = Range(0, 10, 2)
    assert next(tester) == 0
    assert next(tester) == 2
    assert next(tester) == 4
    assert next(tester) == 6
    assert next(tester) == 8
    with pytest.raises(StopIteration):
        next(tester)


# Generated at 2022-06-21 12:12:05.008151
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop(1, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop(10, range(5))) == []
    assert list(drop(10, [])) == []
    assert list(drop(10, [1])) == []
    try:
        list(drop(-1, range(10)))
        assert False, "Exception expected"
    except ValueError:
        pass



# Generated at 2022-06-21 12:12:13.776978
# Unit test for function take
def test_take():
    assert list(take(-1, range(1, 100))) == []
    assert list(take(0, range(1, 100))) == []
    assert list(take(1, range(1, 100))) == [0]
    assert list(take(5, range(1, 100))) == [0, 1, 2, 3, 4]
    assert list(take(100, range(1, 100))) == [i for i in range(99)]
    assert list(take(0, [])) == []
    assert list(take(1, [])) == []
    assert list(take(5, [])) == []


# Generated at 2022-06-21 12:12:24.352525
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Test range()
    rng = Range(3)
    for i, val in enumerate(rng):
        assert i == val
    assert i == 2
    with pytest.raises(StopIteration):
        next(rng)
    # Test range(pos)
    rng = Range(2)
    for i, val in enumerate(rng):
        assert i == val
    assert i == 1
    with pytest.raises(StopIteration):
        next(rng)
    # Test range(neg)
    rng = Range(-3)
    for i, val in enumerate(rng):
        assert i == val
    assert i == -3
    with pytest.raises(StopIteration):
        next(rng)
    # Test range(neg, neg)

# Generated at 2022-06-21 12:12:28.901462
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert len(r) == 10

    r = Range(1, 10 + 1)
    assert len(r) == 10

    r = Range(1, 11, 2)
    assert len(r) == 5

    r = Range(0, 100, 2)
    assert len(r) == 50



# Generated at 2022-06-21 12:12:38.912305
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from io import StringIO
    from unittest import TestCase, main

    class LazyList___iter__TestCase(TestCase):
        def setUp(self):
            self.file = StringIO("hello world")
            self.lst = LazyList(self.file)

        def test(self):
            self.assertEqual("".join(self.lst), "hello world")
            self.assertEqual("".join(self.lst), "hello world")
            self.file.seek(0)
            self.file.write("goodbye world")
            self.assertEqual("".join(self.lst), "goodbye world")

    main()

# Generated at 2022-06-21 12:12:40.099831
# Unit test for function drop
def test_drop():
    assert next(drop(5, range(1000000))) == 5



# Generated at 2022-06-21 12:12:48.096478
# Unit test for function drop_until
def test_drop_until():
    for i in range(1, 10):
        for j in range(10):
            assert take(i, drop_until(lambda x: x > j, range(10))) == [i for i in range(j + 1, 10) if i < j + i]
            assert next(drop_until(lambda x: x > j, range(10))) == j + 1
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]

# Generated at 2022-06-21 12:12:53.084918
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']


# Generated at 2022-06-21 12:13:03.206278
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator=".")) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                  ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]



# Generated at 2022-06-21 12:13:08.120029
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    i = iter(r)
    assert (i is r)
    assert ([x for x in range(10)] == [x for x in r])

# Generated at 2022-06-21 12:13:12.339340
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(5))
    assert list(lst.__iter__()) == list(range(5))
    assert list(lst.__iter__()) == list(range(5))



# Generated at 2022-06-21 12:13:14.143588
# Unit test for constructor of class MapList
def test_MapList():
    assert [10, 20, 30] == MapList(lambda x: x * 10, [1, 2, 3])



# Generated at 2022-06-21 12:13:21.263309
# Unit test for constructor of class Range
def test_Range():
    rng = Range(10)
    assert rng.l == 0
    assert rng.r == 10
    assert rng.step == 1
    assert rng.length == 10

    rng = Range(1, 10 + 1)
    assert rng.l == 1
    assert rng.r == 11
    assert rng.step == 1
    assert rng.length == 10

    rng = Range(1, 11, 2)
    assert rng.l == 1
    assert rng.r == 11
    assert rng.step == 2
    assert rng.length == 5


# Generated at 2022-06-21 12:13:23.875548
# Unit test for constructor of class LazyList
def test_LazyList():
    assert [] == list(LazyList([]))
    assert [1, 2] == list(LazyList(range(1, 3)))



# Generated at 2022-06-21 12:13:31.156235
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a'])) == ['a']
test_scanl()



# Generated at 2022-06-21 12:13:33.541719
# Unit test for constructor of class MapList
def test_MapList():
    try:
        MapList(lambda x: x, [0])
    except:
        raise TypeError('MapList constructor invalid')


# Generated at 2022-06-21 12:13:36.438534
# Unit test for method __next__ of class Range
def test_Range___next__():
    it=Range(1,5).__iter__()
    for i in range(4):
        assert(it.__next__()==i+1)
    assert(it.__next__()==1)

# Generated at 2022-06-21 12:13:48.439209
# Unit test for function scanl
def test_scanl():
    tests = [
        (
            lambda x, y: x + y, [1, 2, 3, 4], 0,
            [0, 1, 3, 6, 10]
        ),
        (
            lambda x, y: y + x, ["a", "b", "c", "d"], "",
            ["a", "ba", "cba", "dcba", "dcbadcba"]
        ),
        (
            lambda x: x, [1, 2, 3, 4], "",
            ["", 1, 2, 3, 4]
        ),
    ]
    for func, lists, initial, expected in tests:
        actual = list(scanl(func, lists, initial))
        assert actual == expected, f"scanl failed. Expected: {expected}. Actual: {actual}."
test_scanl()



# Generated at 2022-06-21 12:14:00.301029
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:14:01.986175
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == list(range(6, 10))

# Generated at 2022-06-21 12:14:09.889183
# Unit test for function drop_until
def test_drop_until():
    # test drop until the first element that is greater than 5
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    # test for an empty list
    assert list(drop_until(lambda x: x > 5, [])) == []
    # test for a list with only one element
    assert list(drop_until(lambda x: x > 5, [3])) == []
    # test for a list with repeated elements
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 5, 5, 6, 7])) == [6, 7]



# Generated at 2022-06-21 12:14:15.534737
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    xs = list(range(10))
    ys = LazyList(xs)
    assert xs == list(ys)  # iterating over ys exhausts the LazyList
    assert xs == list(ys)  # second iteration starts from the beginning again
    assert list(ys[1::2]) == list(ys[1::2])  # slice is memoized
    assert xs != list(ys)  # now the list is exhausted



# Generated at 2022-06-21 12:14:20.116943
# Unit test for constructor of class LazyList
def test_LazyList():
    it = iter([1, 2, 3])
    lst = LazyList(it)
    assert lst[0] == 1
    assert lst[2] == 3
    assert lst.list == [1, 2, 3]
    assert lst[:2] == [1, 2]
    assert lst[:] == [1, 2, 3]
    assert lst.exhausted
# End of unit test for constructor of class LazyList



# Generated at 2022-06-21 12:14:23.111014
# Unit test for function take
def test_take():
    print('test take')
    for _ in range(3):
        assert list(take(5, range(1000000))) == [0,1,2,3,4]


# Generated at 2022-06-21 12:14:25.078363
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(1, 11, 2)
    assert len(r) == 5

# Generated at 2022-06-21 12:14:29.183367
# Unit test for function drop
def test_drop():
    it = drop(1, [1,2,3,4,5])
    assert next(it) == 2
    assert all(list(take(3,it)) == [3,4,5])


# Generated at 2022-06-21 12:14:33.093240
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10, 2)
    assert next(r) == 1
    assert next(r) == 3
    assert next(r) == 5
    assert next(r) == 7
    assert next(r) == 9

# Generated at 2022-06-21 12:14:36.882658
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]


# Generated at 2022-06-21 12:14:52.526354
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Test __getitem__ with int index
    lst = LazyList(range(10))
    for i in range(10):
        assert lst[i] == i
    assert len(lst.list) == 10

    lst = LazyList("foobar", stop=4)
    for i in range(4):
        assert lst[i] == "foobar"[i]
    assert len(lst.list) == 4
    assert lst.exhausted

    # Test __getitem__ with slice object
    lst = LazyList("foobar", stop=4)
    assert lst[1:5] == "ooba"
    assert len(lst.list) == 4
    assert lst.exhausted


# Generated at 2022-06-21 12:14:55.003286
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    _test_Range___getitem__()
    print("Test passed")

# Generated at 2022-06-21 12:14:58.139227
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, range(100000000))) == list(scanl(operator.add, range(100000000), 0))



# Generated at 2022-06-21 12:15:00.821534
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    assert len(lst) == 10
    assert lst[0] == 0
    assert len(lst) == 10



# Generated at 2022-06-21 12:15:05.786028
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(0, 10, 2)
    assert next(r) == 0
    assert next(r) == 2
    assert next(r) == 4
    assert next(r) == 6
    assert next(r) == 8
    with pytest.raises(StopIteration):
        next(r)


# Generated at 2022-06-21 12:15:08.136546
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)
    for i, v in enumerate(r):
        assert i == v


# Generated at 2022-06-21 12:15:10.215460
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert MapList(lambda x: x*x, range(10))



# Generated at 2022-06-21 12:15:18.389499
# Unit test for method __len__ of class Range
def test_Range___len__():

    # Define global variables and functions
    T1 = [0]
    global T1
    T2 = [0]
    global T2
    
    
    # Initialize test context
    
    
    # Test
    global T1
    T1[0] = len(Range(0, 10, 1))
    global T2
    T2[0] = 10
    
    
    # Compare __len__ of Range with builtin range
    assert (T1[0] == T2[0])
    
    
    
    
    
    
    

# Generated at 2022-06-21 12:15:21.929078
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Test 1
    lst = []
    for i in Range(1, 6, 2):
        lst.append(i)
    assert lst == [1, 3, 5]

# Generated at 2022-06-21 12:15:25.488125
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    print(r[0], r[2], r[4])

# Generated at 2022-06-21 12:15:33.001334
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
	assert list(MapList(lambda x: x * x, [1, 2, 3])) == [1, 4, 9]

# Generated at 2022-06-21 12:15:44.019887
# Unit test for function scanr
def test_scanr():
    import operator
    assert list(scanr(operator.add, [])) == []
    assert list(scanr(operator.add, [1])) == [1]
    assert list(scanr(operator.add, [1, 2])) == [3, 1]
    assert list(scanr(operator.add, [1, 2, 3])) == [6, 3, 1]
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 6, 3, 1]

    assert list(scanr(operator.add, [], 10)) == [10]
    assert list(scanr(operator.add, [1], 10)) == [11, 10]
    assert list(scanr(operator.add, [1, 2], 10)) == [13, 12, 10]

# Generated at 2022-06-21 12:15:52.906731
# Unit test for constructor of class LazyList
def test_LazyList():
    arr=[1 for i in range(10)]
    a=LazyList(arr)
    b=iter(a)
    next(b)
    assert a.list==arr[:1]
    arr=[1 for i in range(10)]
    a=LazyList(arr)
    b=iter(a)
    next(b)
    next(b)
    assert a.list==arr[:2]
    arr=[1 for i in range(10)]
    a=LazyList(arr)
    assert len(a)==10


# Generated at 2022-06-21 12:16:02.582581
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    llist = LazyList(range(10))
    assert list(llist) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(llist) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    llist = LazyList(range(10))
    list(llist)
    assert list(llist) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(llist) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-21 12:16:08.235429
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 5)
    it = r.__iter__()
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    assert next(it) == 4
    assert_raises(StopIteration, next, it)
    assert_raises(StopIteration, next, it)


# Generated at 2022-06-21 12:16:12.002014
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(5))
    s = ""
    for x in lst:
        s += str(x)
    return s == "01234"


# Generated at 2022-06-21 12:16:19.322954
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    assert list(MapList(lambda x: x * x, a)) == [1, 4, 9, 16, 25]
    assert MapList(lambda x: x * x, a)[0] == 1
    assert MapList(lambda x: x * x, a)[2] == 9
    assert MapList(lambda x: x * x, a)[0:2] == [1, 4]
    assert MapList(lambda x: x * x, a)[1:] == [4, 9, 16, 25]



# Generated at 2022-06-21 12:16:25.884510
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    a = Range(1, 10 + 1)
    assert list(a) == list(range(1, 10 + 1))
    assert a[::2] == [1, 3, 5, 7, 9]
    assert a[2::2] == [3, 5, 7, 9]
    assert a[:3:2] == [1, 3]
    assert a[1:3] == [2, 3]
    assert a[3:] == [4, 5, 6, 7, 8, 9, 10]
    assert a[-1] == 10
    assert a[-2] == 9


# Generated at 2022-06-21 12:16:29.425883
# Unit test for function scanr
def test_scanr():
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:16:33.899785
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(1, 10)) == len(range(1, 10))
    assert len(Range(1, 10, 2)) == len(range(1, 10, 2))
    assert len(Range(1, 10)) == len(range(1, 10, 1))
    assert len(Range(10)) == len(range(10))
    