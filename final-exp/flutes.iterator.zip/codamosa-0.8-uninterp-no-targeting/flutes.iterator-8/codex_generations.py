

# Generated at 2022-06-21 12:07:25.684842
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    ml1 = MapList(lambda x: x * x, a)
    count = 0
    for i in ml1:
        assert i == a[count] * a[count]
        count += 1
    assert count == len(a)
    assert ml1[2] == a[2] * a[2]
    assert ml1[0:2] == [a[0] * a[0], a[1] * a[1]]
    assert ml1[0:2:1] == [a[0] * a[0], a[1] * a[1]]



# Generated at 2022-06-21 12:07:34.942247
# Unit test for function split_by
def test_split_by():
    assert [[1, 2], [4, 5], [7, 8]] == list(split_by(range(10), criterion=lambda x: x % 3 == 0))
    assert [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []] == \
        list(split_by(" Split by: ", empty_segments=True, separator='.'))
    try:
        list(split_by(range(10), criterion=lambda x: x % 3 == 0, separator='.'))
        assert False
    except ValueError:
        pass



# Generated at 2022-06-21 12:07:41.150892
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    q = MapList(lambda x: x * x, [10,20,30,40,50])
    t = [q[0],q[1],q[2],q[3],q[4]]
    if((t == [100, 400, 900, 1600, 2500]) == False):
        return False
    if((q[2] == 900) == False):
        return False
    return True

# Generated at 2022-06-21 12:07:43.628691
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11 + 1, 2)) == 6
    assert len(Range(0, -5, -1)) == 5
    assert len(Range(3, -3, -1)) == 6
    assert len(Range(3, -5, -1)) == 6

# Generated at 2022-06-21 12:07:54.580366
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, [])) == []
    assert list(chunk(2, [1])) == [[1]]
    assert list(chunk(2, [1, 2])) == [[1, 2]]
    assert list(chunk(2, [1, 2, 3])) == [[1, 2], [3]]
    assert list(chunk(2, [1, 2, 3, 4])) == [[1, 2], [3, 4]]

    assert list(chunk(0, range(10))) == []
    assert list(chunk(-1, range(10))) == []



# Generated at 2022-06-21 12:07:56.382634
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = range(1, 17, 3)
    rr = Range(1, 17, 3)
    assert len(r) == len(rr)
    for x, y in zip(r, rr):
        assert x == y

# Generated at 2022-06-21 12:07:59.792679
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-21 12:08:06.107970
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    xs = LazyList(range(100))
    assert len(xs) == 100
    assert xs[0] == 0
    assert xs[5] == 5
    assert xs[-1] == 99
    assert xs[:2] == [0,1]
    assert xs[5:10] == [5,6,7,8,9]
    assert xs[:10:2] == [0,2,4,6,8]
    assert list(xs) == list(range(100))



# Generated at 2022-06-21 12:08:16.694897
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [
        [0], [1], [2], [3], [4], [5], [6], [7], [8], [9]
    ]
    assert list(chunk(2, range(10))) == [
        [0, 1], [2, 3], [4, 5], [6, 7], [8, 9]
    ]
    assert list(chunk(3, range(10))) == [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], [9]
    ]

# Generated at 2022-06-21 12:08:21.791007
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from coding.list import LazyList
    from typing import Iterable
    try:
        _ = LazyList(()).__len__()
        assert False
    except TypeError:
        pass
    try:
        _ = LazyList(range(10)).__len__()
        assert False
    except TypeError:
        pass
    assert LazyList(range(10)).exhausted is False
    assert LazyList(range(10)).__len__() == 10
    assert LazyList(range(10)).exhausted is True


# Generated at 2022-06-21 12:08:37.258611
# Unit test for function chunk
def test_chunk():
    assert list(chunk(2, [])) == []
    assert list(chunk(2, [1, 2, 3])) == [[1, 2], [3]]
    assert list(chunk(2, [1, 2, 3, 4])) == [[1, 2], [3, 4]]
    assert list(chunk(3, [1, 2, 3])) == [[1, 2, 3]]
    assert list(chunk(3, [1, 2, 3, 4])) == [[1, 2, 3], [4]]



# Generated at 2022-06-21 12:08:40.519511
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(10))) == []
    assert list(take(10, range(3))) == [0, 1, 2]



# Generated at 2022-06-21 12:08:52.703799
# Unit test for constructor of class Range
def test_Range():
    import random
    for i in range(1000):
        start = random.randint(0, 10)
        end = random.randint(0, 10)
        if start > end:
            start, end = end, start
        if start == end:
            r = Range(start)
        else:
            r = Range(start, end)
        assert(r.l == start and r.r == end and r.step == 1)
        assert(r[0:1] == [start])
        assert(r[start - 1] == start - 1 and r[-1] == end - 1)
        assert(r[100] == end - 1 and r[-100] == start)
        if start == end:
            r = Range(start, end, 2)
            assert(r.step == 1)

# Generated at 2022-06-21 12:08:57.867499
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.sub, [0, 10, 20, 30], 40)) == [40, 30, 20, 10, 0]
    assert list(scanl(operator.sub, [])) == []
    assert list(scanl(operator.sub, [0])) == [0]
    assert list(scanl(operator.sub, [0, 0])) == [0, 0]
    assert list(scanl(operator.sub, [0, 1])) == [0, -1]



# Generated at 2022-06-21 12:09:05.185178
# Unit test for method __len__ of class Range
def test_Range___len__():
    for l in range(10, -10, -2):
        for r in range(10, -10, -2):
            for step in range(-2, 3):
                if step == 0:
                    continue
                rng = Range(l, r, step)
                assert len(rng) == (r - l) // step, f"__len__({l}, {r}, {step}) should be {(r - l) // step}"


# Generated at 2022-06-21 12:09:07.224771
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    iter_ = Range(10).__iter__()
    next(iter_)


# Generated at 2022-06-21 12:09:13.045215
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:09:21.976880
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by('Split by:', empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                               ['b', 'y', ':'], []]
    assert list(split_by('Split by:', empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'],
                                                                                ['b', 'y', ':']]
    assert list(split_by('', empty_segments=True, separator='.')) == [[]]

# Generated at 2022-06-21 12:09:31.062012
# Unit test for function take
def test_take():
    assert list(take(0, range(5))) == []
    assert list(take(1, range(5))) == [0]
    assert list(take(5, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(6, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(0))) == []
    assert list(take(1, range(0))) == []
    assert list(take(-1, range(0))) == []
    assert list(take(-1, range(5))) == []



# Generated at 2022-06-21 12:09:41.963340
# Unit test for constructor of class LazyList
def test_LazyList():
    from typing import SupportsInt

    print("test_LazyList")
    # Test case 1: Construct a LazyList and access its elements for the first time
    # Expected result: The iterable should be iterated to the requested indices.
    test_list_1 = LazyList(range(10000))
    test_list_1[0]
    test_list_1[9]
    test_list_1[65]
    test_list_1[-1]
    # Test case 2: Construct a LazyList and access its elements for the second time
    # Expected result: The iterable should not be iterated again.
    test_list_2 = LazyList(range(10000))
    test_list_2[0]
    test_list_2[9]
    test_list_2[65]
    test_

# Generated at 2022-06-21 12:09:51.525625
# Unit test for function take
def test_take():
    assert list(take(3, [1, 2, 3, 4, 5])) == [1, 2, 3]
    assert list(take(5, [1, 2, 3])) == [1, 2, 3]


# Generated at 2022-06-21 12:09:56.226465
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]



# Generated at 2022-06-21 12:09:59.605084
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    f = Range(0, 7)
    assert list(iter(f)) == [0, 1, 2, 3, 4, 5, 6]



# Generated at 2022-06-21 12:10:07.104548
# Unit test for function drop_until
def test_drop_until():
    source = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    predicate = lambda x: x <= 5
    output = list(drop_until(predicate, source))

    assert output == [6, 7, 8, 9]

    source = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    predicate = lambda x: x > 5
    output = list(drop_until(predicate, source))

    assert output == [6, 7, 8, 9]

    source = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    predicate = lambda x: x > 10
    output = list(drop_until(predicate, source))

    assert output == []



# Generated at 2022-06-21 12:10:15.872315
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    it = iter(r)
    assert it.__next__() == 0
    assert it.__next__() == 1
    assert it.__next__() == 2
    assert it.__next__() == 3
    assert it.__next__() == 4
    assert it.__next__() == 5
    assert it.__next__() == 6
    assert it.__next__() == 7
    assert it.__next__() == 8
    assert it.__next__() == 9
    assert it.__next__() == 10

# Generated at 2022-06-21 12:10:27.040552
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Test the method __next__ of class Range
    r1 = Range(5)
    assert isinstance(r1, Range)
    assert isinstance(r1, Sequence)
    r1 = Range(1, 5)
    assert isinstance(r1, Range)
    assert isinstance(r1, Sequence)
    r1 = Range(1, 5, 3)
    assert isinstance(r1, Range)
    assert isinstance(r1, Sequence)
    try:
        r1 = Range()
        assert False
    except ValueError:
        assert True
    try:
        r1 = Range(1, 3, 4, 5)
        assert False
    except ValueError:
        assert True
    r1 = Range(3)
    assert r1.__next__() == 0
    assert r1.__next__()

# Generated at 2022-06-21 12:10:33.159745
# Unit test for constructor of class LazyList
def test_LazyList():
    l = LazyList(range(100))
    l.__getitem__
    l.__len__
    l.__iter__
    l.__getitem__(0)
    l.__getitem__(1)
    l.__getitem__(10)
    l.__getitem__(100)
    l.__getitem__(-1)
    l.__getitem__(100)
    l.__getitem__(101)


# Generated at 2022-06-21 12:10:45.311962
# Unit test for method __getitem__ of class MapList

# Generated at 2022-06-21 12:10:47.980704
# Unit test for function drop_until
def test_drop_until():
    def pred_fn(x): return x > 5
    res = list(drop_until(pred_fn, range(10)))
    assert res == [6, 7, 8, 9]



# Generated at 2022-06-21 12:10:57.272882
# Unit test for function split_by
def test_split_by():
    # test split_by with criterion
    with pytest.raises(ValueError):
        list(split_by(range(10), criterion=lambda x: x % 3 == 0, separator=3))

    with pytest.raises(ValueError):
        list(split_by(range(10), criterion=lambda x: x % 3 == 0, separator=3))

    check1 = [[1, 2], [4, 5], [7, 8]]
    lst1 = list(split_by(range(10), criterion=lambda x: x % 3 == 0))
    assert lst1 == check1

    check2 = [[], [1, 2], [4, 5], [7, 8], []]

# Generated at 2022-06-21 12:11:12.676780
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    
    random.seed(111)

    a = [random.randint(0, 10) for _ in range(100)]
    funcs = [lambda x: x, lambda x: x * x, lambda x: 2 * x]
    for func in funcs:
        for start in range(len(a)):
            for stop in range(start, len(a)):
                for step in range(1, 10):
                    lst = MapList(func, a)
                    lst = lst[start: stop: step]
                    ref = [func(x) for x in a[start: stop: step]]
                    assert lst == ref



# Generated at 2022-06-21 12:11:19.540404
# Unit test for constructor of class MapList
def test_MapList():
    def add(xy):
        (x, y) = xy
        return x + y
    list1 = [1, 2, 3, 4, 5]
    list2 = MapList(add, list1)
    assert list2[0] == 2
    assert list1[0] == 1
    assert [2, 3, 4] == list2[:3]
    assert [1, 2, 3] == list1[:3]
    assert list2[0] == 2
    assert list1[0] == 1



# Generated at 2022-06-21 12:11:29.849617
# Unit test for function scanl
def test_scanl():
    from itertools import accumulate
    from operator import add
    from functools import reduce
    from random import randrange, seed

    seed(42)
    for _ in range(10):
        n = randrange(5, 15)
        lst = [randrange(0, 20) for _ in range(n)]
        assert list(scanl(add, lst)) == list(accumulate(lst))

        lst = [randrange(0, 20) for _ in range(n)]
        assert list(scanl(add, lst, 0)) == [0] + list(accumulate(lst))

        seed(42)
        lst = [randrange(0, 20) for _ in range(n)]
        acc = randrange(-10, 10)

# Generated at 2022-06-21 12:11:35.651433
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(5, range(10))) == list(range(5))
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(100, range(10))) == list(range(10))
    assert list(take(100, [])) == []
    assert list(take(100, [1])) == [1]

# You can test your code by running
from lab.check import check_test
check_test(test_take)


# Generated at 2022-06-21 12:11:37.055959
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__(): 
    pass

# Generated at 2022-06-21 12:11:39.794994
# Unit test for function take
def test_take():
    assert list(take(5, range(9))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(9))) == []
    assert list(take(1, range(9))) == [0]



# Generated at 2022-06-21 12:11:50.609128
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1,10)
    assert r[0] == 1
    assert r[-1] == 9
    assert r[2] == 3
    assert r[-2] == 8
    # assert r[-10] == 1  # error
    assert r[:] == [1,2,3,4,5,6,7,8,9]
    assert r[1:3] == [2,3]
    assert r[5:9] == [6,7,8,9]
    assert r[-5:-1] == [5,6,7,8]

    r = Range(1,10,3)
    assert r[0] == 1
    assert r[-1] == 7
    assert r[2] == 7
    assert r[-2] == 1
    # assert r[-10

# Generated at 2022-06-21 12:11:53.070519
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    ml = MapList(lambda i: a[i] * b[i], Range(len(a)))
    assert ml[0] == 2
    assert ml[1:3] == [6, 12]

# Generated at 2022-06-21 12:12:00.023271
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert( len(r) == 10 )
    r = Range(1, 10)
    assert( len(r) == 10 )
    r = Range(1, 10, 2)
    assert( len(r) == 5 )
    r = Range(1, 11, 2)
    assert( len(r) == 5 )
    r = Range(1, 11, 3)
    assert( len(r) == 4 )

#Unit test for method __getitem__ of class Range

# Generated at 2022-06-21 12:12:05.365101
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert list(Range(1,6))==[1, 2, 3, 4, 5]
    assert list(Range(1,6,2))==[1, 3, 5]
    assert list(Range(3,6,2))==[3, 5]
    assert list(Range(3,6,3))==[3]

# Generated at 2022-06-21 12:12:16.509969
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    test_list = [1, 2, 3]
    lazy_list = LazyList(test_list)
    assert lazy_list[0] == test_list[0]
    assert lazy_list[1] == test_list[1]
    assert lazy_list[-1] == test_list[-1]
    assert lazy_list[2] == test_list[2]
    assert lazy_list[0:2] == test_list[0:2]
    assert lazy_list[:] == test_list[:]


# Generated at 2022-06-21 12:12:18.221040
# Unit test for constructor of class MapList
def test_MapList():
    import bisect

    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert pos == 3, 'MapList\'s constructor is incorrect'


# Generated at 2022-06-21 12:12:19.600474
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x * x, [1, 2, 3])) == [1, 4, 9]

# Generated at 2022-06-21 12:12:23.204749
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    lst_list = MapList(lambda x: x * x, lst)
    lst_range = MapList(lambda i: lst[i] * lst[i], Range(len(lst)))
    for i in range(len(lst_list)):
        print(lst_list[i], lst_range[i])
    assert lst_list[1] == 4
    assert lst_range[1] == 4

# Generated at 2022-06-21 12:12:31.149556
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == len(range(10))
    assert len(Range(0, 10)) == len(range(10))
    assert len(Range(0, 10, 2)) == len(range(0, 10, 2))
    assert len(Range(0, 10, -1)) == 0
    assert len(Range(-10, -20)) == 0
    for l in range(10):
        for r in range(l, 10):
            for step in range(1, 10):
                assert len(Range(l, r, step)) == len(range(l, r, step))
                assert len(Range(l, r, -step)) == 0

# Generated at 2022-06-21 12:12:41.034002
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range = Range(10)
    assert(range[0] == 0)
    assert(range[1] == 1)
    assert(range[1:3] == [1, 2])
    assert(range[-1] == 9)
    assert(range[1:6:2] == [1, 3, 5])

    range = Range(1, 11, 2)
    assert(range[0] == 1)
    assert(range[1] == 3)
    assert(range[1:3] == [3, 5])
    assert(range[-1] == 9)
    assert(range[1:6:2] == [3, 7])

    range = Range(0, 10)
    assert(range[0] == 0)
    assert(range[1] == 1)

# Generated at 2022-06-21 12:12:53.209651
# Unit test for function split_by
def test_split_by():
    assert [] == list(split_by([], criterion=None, separator=None))
    assert [] == list(split_by('', criterion=None, separator=None))
    assert [] == list(split_by([], criterion=lambda x: x % 3 == 0))
    assert [] == list(split_by([], criterion=lambda x: x % 3 == 0,))
    assert [] == list(split_by(['a', 'b', 'c'], criterion=lambda x: x in 'ab'))
    assert [[1, 2], [4, 5], [7, 8]] == list(split_by(range(10), criterion=lambda x: x % 3 == 0))

# Generated at 2022-06-21 12:12:55.271553
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(10)) == 0
    with pytest.raises(StopIteration):
        next(Range(1))


# Generated at 2022-06-21 12:12:57.696356
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(1, 10, 1)
    assert r.__len__() == 10
    assert len(r) == 10

# Generated at 2022-06-21 12:13:01.956398
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert [i for i in LazyList([1, 2, 3, 4])] == [1, 2, 3, 4]
    assert [i for i in LazyList([])] == []
    assert [i for i in LazyList([1, 2, 3, 4])] == [i for i in [1, 2, 3, 4]]



# Generated at 2022-06-21 12:13:13.327332
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    _map_list_list = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert (_map_list_list[0] == 1)
    assert (_map_list_list[3] == 16)
    assert (_map_list_list[1 : 3 + 1] == [4, 9])
    assert (_map_list_list[2 : ] == [9, 16, 25])


# Generated at 2022-06-21 12:13:15.177717
# Unit test for constructor of class LazyList
def test_LazyList():
    d=LazyList([5,5])
    assert list(d)==[5,5]

# Generated at 2022-06-21 12:13:19.577211
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(1, 10 + 1)) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(Range(1, 11, 2)) == [1, 3, 5, 7, 9]



# Generated at 2022-06-21 12:13:32.147084
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Check the range
    assert list(Range(10)) == list(range(10))
    assert list(Range(1, 10 + 1)) == list(range(1, 10 + 1))
    assert list(Range(1, 11, 2)) == list(range(1, 11, 2))

    # Check the iteration
    r = Range(2, 6)
    assert next(r) == 2
    assert next(r) == 3
    assert r.val == 4
    with pytest.raises(StopIteration):
        next(r)

    # Check the indexing
    assert Range(10)[0] == 0
    assert Range(10)[-1] == 9
    assert Range(10)[1:5] == [1, 2, 3, 4]

# Generated at 2022-06-21 12:13:33.685068
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-21 12:13:36.130656
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(5))==0
    assert next(Range(3,6))==3
    assert next(Range(3,7,2))==3


# Generated at 2022-06-21 12:13:47.753656
# Unit test for constructor of class LazyList
def test_LazyList():
    class foo():
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __iter__(self):
            return self

        def __next__(self):
            try:
                return self.args[self.i]
            except IndexError:
                raise StopIteration
            finally:
                self.i += 1

        def __getitem__(self, idx):
            return self.args

        def __len__(self):
            return len(self.args)

    obj = foo(1, 2, 3, 4, 5)
    x = LazyList(obj)
    for _ in range(3):
        for _ in range(3):
            next(x)


# Generated at 2022-06-21 12:13:49.719896
# Unit test for function take
def test_take():
    assert list(take(3, [0, 1, 2, 3, 4])) == [0, 1, 2]



# Generated at 2022-06-21 12:14:01.716600
# Unit test for method __next__ of class Range
def test_Range___next__():
    for i in range(2):
        for args in [
            (1,),
            (1, 2,),
            (1, 2, 3,),
            (5,),
            (5, 6,),
            (5, 6, 7,),
        ]:
            if isinstance(args, Sequence):
                args = tuple(args)
            r = Range(*args)
            r_iter = iter(r)
            r_iter_ref = weakref.ref(r_iter)
            for i in range(100):
                if r_iter_ref() is None:
                    print(args)
                assert r_iter_ref() is not None
                assert id(r_iter_ref()) == id(iter(r))
                with raises(StopIteration):
                    next(r_iter)

# Generated at 2022-06-21 12:14:06.426080
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: x * x, [1,2,3])) == [1, 4, 9]
    assert [0, 1, 4, 9] == MapList(lambda x: x * x, [0, 1, 2, 3])[0:4]
    assert MapList(lambda x: x * x, [0, 1, 2, 3])[0] == 0


# Generated at 2022-06-21 12:14:14.058289
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-21 12:14:18.473062
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']


# Generated at 2022-06-21 12:14:22.527820
# Unit test for constructor of class LazyList
def test_LazyList():
    lazy_list = LazyList(range(10))
    assert lazy_list[1] == 1
    assert lazy_list[0] == 0
    assert lazy_list[1] == 1
    assert lazy_list[2] == 2
    assert len(lazy_list) == 10



# Generated at 2022-06-21 12:14:25.835259
# Unit test for function scanr
def test_scanr():
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:14:28.443267
# Unit test for function take
def test_take():
    assert list(take(5, range(100))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-21 12:14:32.293357
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList([0, 1, 2])
    assert a[1] == 1

    a = LazyList(range(5))
    list(a)
    assert a[1] == 1

# Generated at 2022-06-21 12:14:38.760692
# Unit test for method __next__ of class Range
def test_Range___next__():
    count = 0
    for i in Range(0, 10, 2):
        assert i == count
        count += 2
    for i in Range(0, 10):
        assert i == count
        count += 1
    for i in Range(10):
        assert i == count
        count += 1
    while True:
        try:
            next(Range(-1))
            assert False
        except StopIteration as e:
            # expected
            assert e is not None
            assert isinstance(e, StopIteration)
            break
    assert count == 11



# Generated at 2022-06-21 12:14:50.163425
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    func = '__next__'
    # Test 1
    test_obj = Range(0)
    try:
        iter_ = test_obj.__iter__()
        raise TestFailure("""(iter_,) = test_obj.__iter__()
Returns: {0}
Expected: TestFailure""".format(repr(iter_)))
    except TestFailure:
        pass
    # Test 2
    test_obj = Range(0, 10)
    try:
        iter_ = test_obj.__iter__()
        raise TestFailure("""(iter_,) = test_obj.__iter__()
Returns: {0}
Expected: TestFailure""".format(repr(iter_)))
    except TestFailure:
        pass
    # Test 3
    test_obj = Range(0, 10, 3)

# Generated at 2022-06-21 12:14:57.069949
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    is_empty_nothing = [list(scanr(lambda s, x: x + s, [])) == []]
    is_empty_empty: List[Sequence[Any]] = [list(scanr(lambda s, x: x + s, [], [])) == []]
    assert (is_empty_nothing + is_empty_empty) == [True, True]



# Generated at 2022-06-21 12:15:08.633135
# Unit test for method __next__ of class Range
def test_Range___next__():
    # check if the range is iterable
    # assert True # TODO: implement your test here
    L=[]
    for i in range(10):
        L.append(i)
    # test if the range is iterable
    R = Range(10)
    assert list(R) == L
    for i in range(10):
        assert next(R) == i
    with pytest.raises(StopIteration):
        next(R)
    # test if start and end are optional
    R = Range(10)
    assert list(R) == L
    R = Range(2, 12)
    assert list(R) == L
    # test if the step is optional
    L=[]
    for i in range(0,11,2):
        L.append(i)

# Generated at 2022-06-21 12:15:27.262064
# Unit test for constructor of class Range
def test_Range():
    r = Range(1, 11, 2)
    assert len(r) == 5
    assert r[0] == 1
    assert r[1] == r[6] == 3
    assert r[4] == 9
    assert r[5] == 11
    assert r[-1] == 11
    assert r[-2] == 9
    assert r[-5] == 1
    assert r[-6] == -1
    assert list(r[0:6:1]) == [1, 3, 5, 7, 9, 11]
    assert list(r[0:6:2]) == [1, 5, 11]
    assert list(r[10::-1]) == [11, 9, 7, 5, 3, 1]

# Generated at 2022-06-21 12:15:32.620374
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(2,6,2)
    assert r.__next__() == 2
    assert r.__next__() == 4
    assert r.__next__() == 6

    r = Range(2,2,2)
    try:
        r.__next__()
    except StopIteration:
        assert True


# Generated at 2022-06-21 12:15:43.729427
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert_eq(s.__getitem__(1),1)
    assert_ne(s.__getitem__(1),2)
    assert_is(s.__getitem__(1),1)
    assert_is_not(s.__getitem__(1),1.0)
    assert_false(s.__getitem__(1)==2)
    assert_false(s.__getitem__(1)!=1)
    assert_eq(s.__getitem__(1),1)
    assert_eq(s.__getitem__(1),1)
    assert_true(s.__getitem__(1)!=2)
    assert_true(s.__getitem__(1)==1)
    assert_not_is_instance(s.__getitem__(1),str)


# Generated at 2022-06-21 12:15:52.314720
# Unit test for constructor of class LazyList
def test_LazyList():
    """
    Tests the correct construction of the class LazyList.
    """
    assert_raises(TypeError, LazyList)
    assert_raises(TypeError, LazyList, 1, 2)
    assert_raises(TypeError, LazyList, [1, 2], [3, 4])
    assert_raises(TypeError, LazyList, tuple([1, 2]), tuple([3, 4]))
    empty_iter = iter(tuple())
    assert_raises(TypeError, LazyList, empty_iter)



# Generated at 2022-06-21 12:16:03.846940
# Unit test for function split_by
def test_split_by():
    # Test when criterion is given.
    assert list(split_by([], criterion=lambda _: False)) == [[]]
    assert list(split_by([True], criterion=lambda _: False)) == [[True]]
    assert list(split_by([True, False], criterion=lambda _: False)) == [[True], [False]]
    assert list(split_by([True, False, True, False], criterion=lambda _: False)) == [[True], [False], [True], [False]]
    assert list(split_by([False, False, False, False], criterion=lambda _: False)) == [[], [], [], []]
    assert list(split_by([True, False], criterion=lambda x: x)) == [[], [False]]

# Generated at 2022-06-21 12:16:08.730466
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(0)))==[]
    assert list(drop(1, range(1)))==[]
    assert list(drop(2, range(2)))==[]
    assert list(drop(3, range(3)))==[2]
    print("Function drop: Pass!")



# Generated at 2022-06-21 12:16:11.062040
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == list(range(6, 10))



# Generated at 2022-06-21 12:16:21.682758
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(0, 1, 1)) == 0
    assert next(Range(1, 2, 1)) == 1
    assert next(Range(0, 2, 1)) == 0
    assert next(Range(1, 3, 1)) == 1
    assert next(Range(0, 3, 1)) == 0
    assert next(Range(1, 4, 1)) == 1
    assert next(Range(0, 4, 1)) == 0
    assert next(Range(1, 5, 1)) == 1
    assert next(Range(0, 5, 1)) == 0
    assert next(Range(1, 6, 1)) == 1
    assert next(Range(0, 6, 1)) == 0
    assert next(Range(1, 7, 1)) == 1
    assert next(Range(0, 7, 1)) == 0

# Generated at 2022-06-21 12:16:32.161739
# Unit test for method __next__ of class Range
def test_Range___next__():
    a = Range(0, 2)
    b = Range(0, 2)
    assert a.__next__() == 0
    assert a.__next__() == 1
    assert b.__next__() == 0
    assert a.__next__() == StopIteration
    assert b.__next__() == 1
    assert b.__next__() == StopIteration
    c = Range(1, 5, 2)
    assert c.__next__() == 1
    assert c.__next__() == 3
    assert c.__next__() == StopIteration
    d = Range(5)
    assert d.__next__() == 0
    assert d.__next__() == 1
    assert d.__next__() == 2
    assert d.__next__() == 3
    assert d.__next__() == 4

# Generated at 2022-06-21 12:16:33.363156
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    _test_instance(iter(Range(10)), Iterator[int])


# Generated at 2022-06-21 12:16:45.480772
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:16:50.759431
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert Range(3).__len__() == 3
    assert Range(3, 4).__len__() == 1
    assert Range(3, 5).__len__() == 2
    assert Range(3, 5, 2).__len__() == 1
    assert Range(3, 5, 3).__len__() == 1
    assert Range(3, 6, 3).__len__() == 2

# Generated at 2022-06-21 12:16:53.089999
# Unit test for function drop_until
def test_drop_until():
  list_to_check = range(10)
  assert list(drop_until(lambda x: x > 5, list_to_check)) == [6,7,8,9]



# Generated at 2022-06-21 12:16:55.676959
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
