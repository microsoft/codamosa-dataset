

# Generated at 2022-06-21 12:06:59.368758
# Unit test for function take
def test_take():
    it=iter(range(1000))
    it1=take(10,it)
    assert it1==range(10)
    it2=take(10,it1)
    assert it2==[]


# Generated at 2022-06-21 12:07:05.711760
# Unit test for function split_by
def test_split_by():
    list(split_by("Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]



# Generated at 2022-06-21 12:07:12.305278
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda x, y: x*y, [2, 3, 4, 5])) == [2, 6, 24, 120]



# Generated at 2022-06-21 12:07:15.219328
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x * x, [1, 2, 3, 4, 5])) == 5
    with raises(Exception):
        len(MapList(lambda x: x * x, []))



# Generated at 2022-06-21 12:07:24.680072
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList([1, 2, 3, 4, 5, 6, 7])
    assert ll[2] == 3
    assert list(ll) == [1, 2, 3, 4, 5, 6, 7]

    assert ll[-1] == 7
    assert ll[-2] == 6
    assert ll[-3] == 5
    assert list(ll) == [1, 2, 3, 4, 5, 6, 7]

    assert ll[-6] == 2
    assert ll[-7] == 1
    assert list(ll) == [1, 2, 3, 4, 5, 6, 7]

    assert ll[:] == [1, 2, 3, 4, 5, 6, 7]
    assert list(ll) == [1, 2, 3, 4, 5, 6, 7]


# Generated at 2022-06-21 12:07:35.313201
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], '_')) == ['abcd_', 'bcd_', 'cd_', 'd_', '_']
    assert list(scanr(operator.mul, [1, 2, 3, 4], 1)) == [24, 24, 12, 4, 1]



# Generated at 2022-06-21 12:07:37.317934
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1, 2, 3])) == 3

# Generated at 2022-06-21 12:07:46.897338
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    class SuppressStopIteration(iter):
        def __init__(self, iterable):
            self.iter: Iterator[T] = iter(iterable)

        def __iter__(self):
            return self

        def __next__(self):
            return next(self.iter)

        def __len__(self):
            raise TypeError("__len__ is not available")

    def assert_iteration_matches(lst: LazyList[int], values: List[int]):
        iter_values = list(lst)
        assert iter_values == values
        lst = LazyList(SuppressStopIteration(iter_values))
        assert list(lst) == values

    assert_iteration_matches(LazyList([]), [])

# Generated at 2022-06-21 12:07:49.266490
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
  for i in range(1000000):
    assert list(LazyList(range(i))) == list(range(i))

# Generated at 2022-06-21 12:07:54.369401
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 0, range(-10,10))) == list(range(1,10))
    assert list(drop_until(lambda x: x > 1, range(0,10))) == list(range(2,10))
    assert list(drop_until(lambda x: x > -10, range(-10,10))) == list(range(-9,10))


# Generated at 2022-06-21 12:08:14.196542
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(0, 10, 2)
    assert list(r) == list(range(0, 10, 2))
    assert list(r) == list(r)
    r = Range(0, 10, 2)
    assert tuple(r) == tuple(range(0, 10, 2))
    assert tuple(r) == tuple(r)
    r = Range(0, 10, 2)
    a = set(r)
    b = set(r)
    assert a == b
    r = Range(0, 10, 2)
    assert min(r) == 0
    assert max(r) == 8


# Generated at 2022-06-21 12:08:25.680503
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    a = []
    for x in range(random.randint(1, 100)):
        a.append(random.randint(1, 10000))
    b = LazyList(a)
    assert a[:] == b[:]
    assert a[10:20] == b[10:20]
    assert a[100:] == b[100:]
    assert a[:100] == b[:100]
    assert a[::2] == b[::2]
    assert a[10:20:2] == b[10:20:2]
    assert a[100::2] == b[100::2]
    assert a[:100:2] == b[:100:2]

# Generated at 2022-06-21 12:08:28.184490
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    list_ = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    return len(list_) == 5

# Generated at 2022-06-21 12:08:33.963291
# Unit test for constructor of class Range
def test_Range():
    a = Range(5)
    b = Range(5, 10)
    c = Range(5, 10, 2)
    assert len(a) == 5
    assert len(b) == 5
    assert len(c) == 3
    assert a[1] == 1
    assert b[2] == 7
    assert c[-1] == 9
    assert a[1:3] == [1, 2]
    assert b[2:5] == [7, 8, 9]
    assert c[1:] == [7, 9]


# Generated at 2022-06-21 12:08:35.798459
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    unit_test = True
    assert unit_test == True

# Generated at 2022-06-21 12:08:44.565494
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10) 
    assert len(r)==10
    r = Range(1,10 + 1) 
    assert len(r)==10
    r = Range(1,11,2)  
    assert len(r)==5
    r = Range(10) 
    assert len(r)==10
    r = Range(1,10 + 1) 
    assert len(r)==10
    r = Range(1,11,2) 
    assert len(r)==5
    r = Range(10) 
    assert len(r)==10
    r = Range(1,10 + 1) 
    assert len(r)==10
    r = Range(1,11,2)  
    assert len(r)==5
    r = Range(10) 

# Generated at 2022-06-21 12:08:54.258202
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    data = [[0,1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10],[0,2,4,6,8,10],[1,3,5,7,9]]
    # data = [[0,1]]
    ans = ['ans1','ans2','ans3','ans4']
    for i in range(4):
        print('下面是第',i+1,'个答案')
        for s in data[i]:
            print(Range(0,s), end = " ")
        print("\n")


# Generated at 2022-06-21 12:08:56.156009
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    obj = Range(0, 12, 3)
    assert iter(obj) == obj



# Generated at 2022-06-21 12:08:57.882580
# Unit test for function drop
def test_drop():
    assert_equal(list(drop(5, range(1000000))), list(range(5, 1000000)))


# Generated at 2022-06-21 12:09:10.535166
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    tt = Range(10)
    assert list(tt) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert tt[0] == 0
    assert tt[9] == 9
    assert tt[-1] == 9
    assert tt[-10] == 0
    assert tt[-11] == 10
    assert tt[4:8] == [4, 5, 6, 7]
    assert tt[4:9:2] == [4, 6, 8]
    assert tt[-1:4:-1] == [9, 8, 7, 6]
    assert list(tt[:]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert tt[4:4] == []

# Generated at 2022-06-21 12:09:29.382036
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(10))) == []
    assert list(take(0, iter([]))) == []
    assert list(take(1, iter([]))) == []



# Generated at 2022-06-21 12:09:35.549500
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    import random
    lst = []
    rng = random.Random(123)
    for i in range(100):
        lst.append(rng.randrange(1000))
    a = MapList(lambda x: x * x, lst)
    b = []
    for i in a:
        b.append(i)
    assert b == [x * x for x in lst]



# Generated at 2022-06-21 12:09:41.968246
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x * 2, [[1, 2, 3], [2, 3, 4]])
    assert lst[0] == [2, 4, 6] and lst[-1] == [4, 6, 8] and lst[0:2] == [[2, 4, 6], [4, 6, 8]]
    assert lst[2:3] == [6, 8] and lst[-3:-1] == [4, 6, 8]

# Generated at 2022-06-21 12:09:48.398078
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)
    assert list(r) == list(range(10))
    assert r[0] == 0 and r[1] == 1 and r[2] == 2 and r[3] == 3 and r[4] == 4 and r[-1] == 9
    assert r[:] == list(range(10))
    assert r[:-1] == list(range(0, 9))
    assert r[1:4] == list(range(1, 4))
    assert r[::2] == list(range(0,10,2))

    r = Range(1, 11, 2)
    assert list(r) == list(range(1, 11, 2))

# Generated at 2022-06-21 12:09:54.494104
# Unit test for function split_by
def test_split_by():
    list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:09:57.655951
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    a = [1, 2, 3, 4, 5]
    map_list = MapList(lambda x: x * x, a)
    assert len(map_list) == 5
    return len(map_list)

# Generated at 2022-06-21 12:10:02.609658
# Unit test for function take
def test_take():
    from .test_utils import generate_test_cases
    from .test_utils import identity
    cases = generate_test_cases(test_take, [int, identity], [int, identity])
    for function, n, it, expected in cases:
        result = function(n, it)
        assert list(result) == expected



# Generated at 2022-06-21 12:10:07.475232
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    try:
        len(lst)
        assert False
    except TypeError:
        pass
    lst = list(lst)
    assert len(lst) == 10

# Generated at 2022-06-21 12:10:19.181977
# Unit test for constructor of class LazyList
def test_LazyList():
    # Test it works for empty list
    assert list(LazyList([])) == []
    # Test it works for list
    assert LazyList([1, 2, 3])[0:2] == [1, 2]
    assert LazyList([1, 2, 3])[1] == 2
    assert LazyList([1, 2, 3, 4])[-1] == 4
    # Test it is lazy
    assert tuple(LazyList(range(1000))[5:5:5]) == tuple(range(1000)[5:5:5])
    assert tuple(LazyList(range(1000))[5:6:5]) == tuple(range(1000)[5:6:5])
    assert tuple(LazyList(range(1000))[5:7:5]) == tuple(range(1000)[5:7:5])


# Generated at 2022-06-21 12:10:23.037981
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(3))
    it = iter(lst)
    assert next(it) == 0
    assert next(it) == 1


# Generated at 2022-06-21 12:10:31.122714
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([])) == 0
    assert len(LazyList(range(100))) == 100
    with pytest.raises(TypeError):
        len(LazyList(range(100, 200)))



# Generated at 2022-06-21 12:10:35.372687
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1,2,3,4,5], 0)) == [15, 14, 12, 9, 5, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']


# Generated at 2022-06-21 12:10:47.288827
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import sys
    import random
    import functools

    n = 10000

    def check_with_iterable(f):
        print("Testing with iterable:", type(f()).__name__)
        for i in range(100):
            # Get a random slice
            if random.randint(0, 10) == 0:
                # Empty slice
                start = 0
                stop = 0
                step = random.choice([None, 1, 2, 3, 4, 5, 10, 100, 1000])
            else:
                start = random.randint(-n, n)
                stop = random.randint(-n, n)
                step = random.choice([None, 1, 2, 3, 4, 5, 10, 100, 1000])
            # print(start, stop, step)

# Generated at 2022-06-21 12:10:52.089482
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:10:53.850841
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    l = MapList(lambda x: x*2, [1, 2, 3])
    assert len(l) == 3



# Generated at 2022-06-21 12:11:02.573588
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    try:
        scanl(operator.add, [1, 2, 3, 4], initial=0, unknown_arg=1)
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-21 12:11:12.949053
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, [0, 1, 2, 3, 4])) == [[0], [1], [2], [3], [4]]
    assert list(chunk(2, [0, 1, 2, 3, 4])) == [[0, 1], [2, 3], [4]]
    assert list(chunk(3, [0, 1, 2, 3, 4])) == [[0, 1, 2], [3, 4]]
    assert list(chunk(4, [0, 1, 2, 3, 4])) == [[0, 1, 2, 3], [4]]
    assert list(chunk(len([0]), [0, 1, 2, 3, 4])) == [[0, 1, 2, 3, 4]]
    assert list(chunk(3, [])) == []

# Generated at 2022-06-21 12:11:14.694465
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(1, 11, 2)
    assert r[2] == 5



# Generated at 2022-06-21 12:11:24.124985
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    cases = [
        { 'args': [{'parameter': lambda x: x*x, 'lst': [1,2,3]}], 'expectation': {'result': [1,4,9]} },
    ]
    for case in cases:
        args = case['args']
        expectation = case['expectation']
        obj = MapList(*args[0]['parameter'], *args[0]['lst'])
        result = obj.__getitem__(*args[1]['item'])
        if expectation['result'] != result:
            raise Exception(f'Failed test, got result: {result}')

    print(f'Passed {len(cases)}/{len(cases)} cases.')



# Generated at 2022-06-21 12:11:32.593274
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: x*2, [0, 1, 2])) == [0, 2, 4]
    assert MapList(lambda x: x*2, [0, 1, 2])[1] == 2
    assert MapList(lambda x: x*2, [0, 1, 2])[2] == 4
    assert MapList(lambda x: x*2, [0, 1, 2])[0:2] == [0, 2]
    assert MapList(lambda x: x*2, [0, 1, 2])[:] == [0, 2, 4]
    assert len(MapList(lambda x: x*2, [0, 1, 2])) == 3


# Generated at 2022-06-21 12:11:39.871228
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    names = ['David', 'John', 'Peter']
    m = MapList(len, names)
    assert isinstance(m[0], int)
    assert isinstance(m[0:1], list)
    assert m[0] == 5
    assert m[0:1] == [5]

# Generated at 2022-06-21 12:11:44.450718
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(0, range(10))) == []
    try:
        list(chunk(-1, range(10)))
        assert False
    except:
        assert True


# Generated at 2022-06-21 12:11:47.084846
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4, 0]


# Generated at 2022-06-21 12:11:56.235926
# Unit test for constructor of class Range
def test_Range():
    assert len(Range(3)) == 3
    assert len(Range(1, 3)) == 2
    assert len(Range(1, 5, 2)) == 2
    assert list(Range(3)) == [0, 1, 2]
    assert list(Range(1, 3)) == [1, 2]
    assert list(Range(1, 5, 2)) == [1, 3]
    assert list(Range(5, -1, -2)) == [5, 3, 1]
    assert list(Range(1, 5, -2)) == []
    assert list(Range(0, 5)[:3]) == [0, 1, 2]
    assert list(Range(0, 5)[3:]) == [3, 4]
    assert list(Range(5, -1, -2)[::-1]) == [5, 3, 1]

# Generated at 2022-06-21 12:12:08.469470
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_ = Range(10)
    assert isinstance(range_, MapList), "range_ is not MapList. "
    assert range_[0], "range_[0] is not a int. "
    assert range_[0] == 0, "range_[0] is not 0. "
    assert range_[9], "range_[9] is not a int. "
    assert range_[9] == 9, "range_[9] is not 9. "
    assert isinstance(range_[0:1], list), "range_[0:1] is not a list. "
    assert range_[0:1][0], "range_[0:1][0] is not a int. "

# Generated at 2022-06-21 12:12:18.040136
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for i in range(0, 10):
        for j in range(0, 10):
            for k in range(1, 10):
                expected = list(range(i, j, k))
                actual = list(Range(i, j, k))
                if expected != actual:
                    raise Exception("failure at (i, j, k) = ({}, {}, {})".format(i, j, k))
    for args in (0, 1, 10, 10, 3, 10, 3, -10, -3, -101, -100, -1, -101, -100, -3):
        expected = list(range(args))
        actual = list(Range(args))
        if expected != actual:
            raise Exception("failure at the args = {}".format(args))


# Generated at 2022-06-21 12:12:21.115176
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1,2,3,4]
    def sq(x):
        return x*x
    tp = MapList(sq,lst)
    assert tp[3] == 16
    assert tp[2:4] == [9,16]
    assert list(tp) == [1, 4, 9, 16]
    assert len(tp) == 4


# Generated at 2022-06-21 12:12:29.930868
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1, range(2))) == [[0], [1]]
    assert list(chunk(2, range(1))) == [[0]]
    assert list(chunk(2, range(0))) == []
    assert list(chunk(0, range(2))) == []
    assert list(chunk(3, range(12))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10, 11]]



# Generated at 2022-06-21 12:12:32.234596
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert True

# Generated at 2022-06-21 12:12:42.089726
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']

# Generated at 2022-06-21 12:12:50.163402
# Unit test for method __next__ of class Range
def test_Range___next__():
    for i in [Range(10), Range(1, 10 + 1), Range(1, 11, 2)]:
        for j in range(0, 10):
            assert i.__next__() == j
        try:
            i.__next__()
        except StopIteration:
            pass

# Generated at 2022-06-21 12:12:57.258572
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    result = (x for x in range(10))
    llst = LazyList(result)
    it1 = iter(llst)
    assert list(it1) == list(range(10))

    llst = LazyList(result)
    it1 = iter(llst)
    it2 = iter(llst)
    assert [next(it1) for _ in range(1, 5)] == [1, 2, 3, 4]
    assert [next(it2) for _ in range(1, 5)] == [1, 2, 3, 4]



# Generated at 2022-06-21 12:13:01.513186
# Unit test for function take
def test_take():
    for i in range(100):
        xs = list(take(i, [1, 2, 3]))
        assert len(xs) == min(i, 3)
        for x in xs:
            assert x in [1, 2, 3]
        ys = list(take(i, []))
        assert len(ys) == 0

# Generated at 2022-06-21 12:13:03.095823
# Unit test for function scanl
def test_scanl():
    print('testing scanl')
    print(list(scanl(operator.add, range(10))))
    print(list(scanl(operator.add, range(10), 0)))


# Generated at 2022-06-21 12:13:16.200918
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10, 15))
    # Test iteration
    assert list(lst) == list(range(10, 15))
    # Test iterating an exhausted list
    assert list(lst) == list(range(10, 15))
    # Test iterator
    assert list(iter(lst)) == list(range(10, 15))
    # Test iterating over an iterator
    assert list(iter(iter(lst))) == list(range(10, 15))
    # Test iterator exhaustion
    it = iter(lst)
    assert next(it) == 10
    assert next(it) == 11
    assert next(it) == 12
    assert next(it) == 13
    assert next(it) == 14
    with pytest.raises(StopIteration):
        next(it)
    # Test

# Generated at 2022-06-21 12:13:20.000558
# Unit test for function drop_until
def test_drop_until():
    for i in range(10):
        assert list(drop_until(lambda x: x > i, range(10))) == list(range(i + 1, 10))
        assert list(drop_until(lambda x: x >= i, range(10))) == list(range(i, 10))



# Generated at 2022-06-21 12:13:26.013335
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-21 12:13:32.756010
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(5))) == []
    assert list(drop(5, range(15))) == [5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    assert list(drop(5, list(range(5)))) == []
    assert list(drop(5, list(range(15)))) == [5, 6, 7, 8, 9, 10, 11, 12, 13, 14]


# Generated at 2022-06-21 12:13:44.011720
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8], []]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    a = " ".join(map(str, range(10)))

# Generated at 2022-06-21 12:13:50.169640
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by("Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], [
                                                                                     'b', 'y', ':'], []]



# Generated at 2022-06-21 12:14:00.255235
# Unit test for function drop_until
def test_drop_until():
    iterator = iter(range(10))
    n = 5
    assert list(drop_until(lambda x: x >= n, iterator)) == list(range(n, 10))



# Generated at 2022-06-21 12:14:09.469254
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda i: i * 2, range(10))[0] == 0
    assert MapList(lambda i: i * 2, range(10))[1] == 2
    assert MapList(lambda i: i * 2, range(10))[2] == 4
    assert MapList(lambda i: i * 2, range(10))[4] == 8
    assert MapList(lambda i: i * 2, range(10))[5] == 10
    assert MapList(lambda i: i * 2, range(10))[6] == 12
    assert MapList(lambda i: i * 2, range(10))[7] == 14
    assert MapList(lambda i: i * 2, range(10))[8] == 16
    assert MapList(lambda i: i * 2, range(10))[9] == 18
   

# Generated at 2022-06-21 12:14:12.985818
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 11, 2)
    assert [next(r) for _ in range(5)] == [1, 3, 5, 7, 9]
    with pytest.raises(StopIteration):
        next(r)


# Generated at 2022-06-21 12:14:15.703822
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    functools.reduce(lambda x, y: x + y, MapList(lambda x: x * 2, list(range(5)))) == sum(map(lambda x: x * 2, list(range(5))))

# Generated at 2022-06-21 12:14:21.408951
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from contextlib import redirect_stdout
    from io import StringIO
    import sys
    l = LazyList(range(10))
    s = StringIO()
    with redirect_stdout(s):
        retval = l.__len__()
    assert s.getvalue() == ""
    assert retval == 10
    assert isinstance(retval, int)


# Generated at 2022-06-21 12:14:28.069645
# Unit test for function drop
def test_drop():
    assert next(drop(5, range(5))) == 5
    assert next(drop(-1, range(5))) == 1
    with pytest.raises(ValueError, match="`n` should be non-negative"):
        next(drop(-1, range(2)))
    with pytest.raises(StopIteration):
        assert next(drop(20, range(5)))



# Generated at 2022-06-21 12:14:37.014814
# Unit test for function scanl
def test_scanl():
    # Problem 1
    def div_mod(m, n):
        return (m) // (n), (m) % (n)

    expect = [(0, 4), (0, 3), (0, 2), (0, 1)]
    result = scanl(div_mod, range(4, 0, -1))
    result = list(result)
    assert expect == result
    # Problem 2
    expect = [('', 'a'), ('a', 'b'), ('ab', 'c'), ('abc', 'd')]
    result = scanl(lambda s, x: s + x, ['a', 'b', 'c', 'd'])
    result = list(result)
    assert expect == result


# Generated at 2022-06-21 12:14:43.428875
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:14:48.638382
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    any_empty_sequence = []
    any_func = lambda x: x
    any_sequence_length = len(any_empty_sequence)
    any_MapList = MapList(any_func, any_empty_sequence)
    result = any_MapList.__len__()
    assert type(result) is int
    assert result == any_sequence_length


# Generated at 2022-06-21 12:14:50.884239
# Unit test for function drop_until
def test_drop_until():
    list(drop_until(lambda x: x > 5, range(10))) == list(range(6,10))

test_drop_until()



# Generated at 2022-06-21 12:15:05.213742
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(range(6))
    assert len(l) == 6
    assert len(l) == 6

# Generated at 2022-06-21 12:15:17.593782
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[0] == 0
    assert Range(10)[9] == 9
    assert Range(10)[-10] == 0
    assert Range(10)[-9] == 1
    assert Range(10, 20)[0] == 10
    assert Range(10, 20)[9] == 19
    assert Range(10, 20)[-10] == 10
    assert Range(10, 20)[-1] == 19
    assert Range(10, 20, 2)[0] == 10
    assert Range(10, 20, 2)[4] == 18
    assert Range(10, 20, 2)[-5] == 10
    assert Range(10, 20, 2)[-1] == 18
    assert Range(10)[1:2][0] == 1
    assert Range(10)[1:3][0] == 1

# Generated at 2022-06-21 12:15:23.280609
# Unit test for function take
def test_take():
    assert list(take(5, range(100))) == list(range(5))
    assert list(take(5, range(3))) == list(range(3))
    assert list(take(5, range(0))) == list([])
    assert list(take(0, range(100))) == list([])
test_take()



# Generated at 2022-06-21 12:15:36.436811
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

# Generated at 2022-06-21 12:15:41.165368
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert is_iterable_exhausted(Range(0))
    assert is_iterable_exhausted(Range(5, 10))
    assert is_iterable_exhausted(Range(5, 10, 2))


# Generated at 2022-06-21 12:15:43.943001
# Unit test for method __len__ of class Range
def test_Range___len__():
    _Range_instance = Range(1, 10, 1)
    _Range_instance.__len__()
    return None


# Generated at 2022-06-21 12:15:46.069357
# Unit test for function drop
def test_drop():
    it = iter(range(3))
    assert list(drop(2, it)) == [2]



# Generated at 2022-06-21 12:15:52.583735
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    def test(iterable):
        lst = LazyList(iterable)
        it = iter(lst)
        assert it is lst.__iter__()
        assert it is iter(it)
        assert it is lst.__iter__()
        assert it is iter(it)
    test([1, 2, 3])
    test([1, 2, 3, 4])
    test([])


# Generated at 2022-06-21 12:15:56.750222
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    lst = MapList(lambda x: x * x, a)
    for i in range(len(a)):
        assert lst[i] == a[i] * a[i]


# Generated at 2022-06-21 12:16:02.835448
# Unit test for function scanl
def test_scanl():
    """
    Test scanl
    """
    ls = [1,2,3,4]
    ans = [0,1,3,6,10]
    result = list(scanl(operator.add, ls, 0))
    assert result == ans, "scanl should return a list of the cumulative results of reducing the elements in the list"



# Generated at 2022-06-21 12:16:34.776057
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lazy_list = LazyList(range(20))
    assert type(lazy_list[0]) is int
    assert list(lazy_list[0:5]) == list(range(5))
    assert lazy_list[5] == 5


# Generated at 2022-06-21 12:16:38.584098
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = [1.0, -2.0, 3.0, -4.0]
    abs_lst = MapList(abs, lst)
    for i in range(4):
        assert len(abs_lst) == len(lst)



# Generated at 2022-06-21 12:16:41.594303
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(1000000))) == list(range(5, 1000000))
