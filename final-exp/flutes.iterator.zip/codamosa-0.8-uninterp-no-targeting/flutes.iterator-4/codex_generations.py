

# Generated at 2022-06-21 12:07:20.561993
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([0, 1, 2, 3, 4])
    assert lst[0] == 0  # test single item
    assert lst[-1] == 4
    assert lst[:3] == [0, 1, 2]  # test slicing
    assert lst[3:4] == [3]
    assert lst[3:] == [3, 4]
    assert lst[:6] == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 12:07:22.631932
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    x = [1,2,3,4]
    m = MapList(lambda x: x**2 , x)
    print(list(m))


# Generated at 2022-06-21 12:07:29.610969
# Unit test for constructor of class Range
def test_Range():
    cases = [
        [1, 2, 3],
        [1, 2, 3, 4],
        [1, 2, 3, 4, 5],
    ]
    for case in cases:
        print(case)
        assert Range(*case)[0] == case[0]
        assert Range(*case)[-1] == case[-1]
        assert Range(*case)[-2] == case[-2]


# Generated at 2022-06-21 12:07:37.992495
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda s, x: s + x, ['a', 'b', 'c', 'd'])) == ['dcba', 'cba', 'ba', 'a']



# Generated at 2022-06-21 12:07:46.469107
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(10)) == 0
    assert next(Range(10)) == 1
    assert next(Range(0, 10)) == 0
    assert next(Range(1, 10 + 1)) == 1
    assert next(Range(1, 10 + 1)) == 2
    assert next(Range(1, 11, 2)) == 1
    assert next(Range(1, 11, 2)) == 3
    with pytest.raises(StopIteration):
        next(Range(0, 0))
    with pytest.raises(StopIteration):
        next(Range(1, 1))
    with pytest.raises(StopIteration):
        next(Range(1, 1, -1))


# Generated at 2022-06-21 12:07:52.148951
# Unit test for constructor of class Range
def test_Range():
    r = Range(1, 10 + 1)
    assert r.l == 1
    assert r.r == 11
    assert r.step == 1
    r = Range(1, 11, 2)
    assert r.l == 1
    assert r.r == 11
    assert r.step == 2
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    assert r[1:4:3] == [3]
    assert r[-3:-1] == [5, 7]
    assert r[-1:] == [9]
    assert r[:-1] == [1, 3, 5, 7]
    assert r[::-1] == [9, 7, 5, 3, 1]



# Generated at 2022-06-21 12:07:55.330864
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert [i for i in Range(5)] == [0,1,2,3,4]
    assert [i for i in Range(1, 6)] == [1,2,3,4,5]
    assert [i for i in Range(1, 6, 2)] == [1,3,5]
    assert [i for i in Range(6, 0, -1)] == [6,5,4,3,2,1]


# Generated at 2022-06-21 12:08:00.402390
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x ** 2, lst)[2] == 9
    assert MapList(lambda x: x ** 2, lst)[:2] == [1, 4]



# Generated at 2022-06-21 12:08:11.778596
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    assert isinstance(r, Sequence)
    assert isinstance(r, Iterable)
    assert list(r) == list(range(10))
    assert list(r.__iter__()) == list(range(10))
    assert next(r) == 0
    assert list(r) == list(range(1, 10))
    assert list(r.__iter__()) == list(range(1, 10))
    r = Range(1, 11, 2)
    assert isinstance(r, Sequence)
    assert isinstance(r, Iterable)
    assert list(r) == list(range(1, 11, 2))
    assert list(r.__iter__()) == list(range(1, 11, 2))
    assert next(r) == 1

# Generated at 2022-06-21 12:08:17.385409
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    i = LazyList(range(10))
    assert list(i) == list(range(10))
    assert list(i) == list(range(10))  # should not re-iterate
    assert list(i) == list(range(10))  # should be idempotent
    i = LazyList(range(100000))
    assert list(take(10000, i)) == list(range(10000))
    assert list(i) == list(range(10000, 100000))

# Generated at 2022-06-21 12:10:19.135354
# Unit test for constructor of class LazyList
def test_LazyList():
    assert list(LazyList([1,2,3])) == [1,2,3]
    assert LazyList([1,2,3]).list == []
    assert isinstance(LazyListIterator, type)



# Generated at 2022-06-21 12:10:21.944863
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    # [R] = MapList<R>(func, lst)
    # lst<A>[0..len(lst)-1] -> R[0..len(lst)-1]
    for j in range(0, 10):
        a = random.sample(range(0, 10000), j);
        b = MapList(lambda x: x + 1, a)

        assert len(list(a)) == len(list(b))
        assert all(list(map(lambda x: x[0] + 1, zip(a, b))))

# Generated at 2022-06-21 12:10:30.758606
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    for i in range(0, len(a)):
        ml = MapList(lambda x: x, a)
        assert ml[i] == a[i]
    ml = MapList(lambda x: x, a)
    assert ml[:] == a
    assert ml[1:3] == a[1:3]
    assert ml[:3] == a[:3]
    assert ml[2:] == a[2:]
    assert ml[3:1:-1] == a[3:1:-1]
    assert ml[::2] == a[::2]
    assert ml[:0] == a[:0]
    assert ml[3::-1] == a[3::-1]

# Generated at 2022-06-21 12:10:35.128721
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import random
    random.seed(0)
    lst = list(range(10000000))
    random.shuffle(lst)
    lazy_lst = LazyList(lst)
    it = iter(lazy_lst)
    for i in range(len(lazy_lst)):
        assert next(it) == lazy_lst[i]


# Generated at 2022-06-21 12:10:47.246716
# Unit test for function take
def test_take():
    assert take(5, range(10)) == range(5)
    assert take(5, range(10)).__class__ == range
    assert take(5, iter(range(10))) == range(5)
    assert take(5, iter(range(10))) != range(5)
    assert take(5, iter(range(10))).__class__ == range
    assert take(5, iter(range(10)), ) == range(5)
    assert take(5, iter(range(10)), ).__class__ == range
    assert take(5, iter(range(10)), ).__class__ == range
    assert take(10, iter(range(5)), ) == range(5)
    assert take(10, iter(range(5)), ).__class__ == range

# Generated at 2022-06-21 12:10:56.730239
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    from pytest import raises
    # scanl should be equivalent to Haskell scanl, so we expect it to pass the test cases in the Haskell documentation.
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], '0')) == ['0', '01', '012', '0123', '01234']

# Generated at 2022-06-21 12:10:59.769949
# Unit test for function take
def test_take():
    result = take(5, range(1000000))
    assert result == [0, 1, 2, 3, 4]



# Generated at 2022-06-21 12:11:01.425638
# Unit test for function take
def test_take():
    assert(list(take(3, range(10))) == [0, 1, 2])
test_take()


# Generated at 2022-06-21 12:11:09.534157
# Unit test for method __len__ of class Range
def test_Range___len__():
    from sys import stdout
    from L_System import print_expectation

    print_expectation(
        expectation = "0",
        true_value = (len(Range(0))),
        file = stdout
    )
    print_expectation(
        expectation = "5",
        true_value = (len(Range(0, 5))),
        file = stdout
    )
    print_expectation(
        expectation = "5",
        true_value = (len(Range(0, 10, 2))),
        file = stdout
    )



# Generated at 2022-06-21 12:11:13.722143
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    try:
        list(chunk(0, range(10)))
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 12:11:27.283799
# Unit test for method __len__ of class Range
def test_Range___len__():
    # print(Range(10).__len__())
    assert Range(10).__len__() == 10



# Generated at 2022-06-21 12:11:31.136928
# Unit test for constructor of class MapList
def test_MapList():
    lst1 = [1, 2, 3, 4, 5]
    lst2 = MapList(lambda x: str(x), lst1)
    print(isinstance(lst2, list))
    print(lst2)

if __name__ == '__main__':
    test_MapList()

# Generated at 2022-06-21 12:11:32.853021
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    MapList([1,2,3,4], lambda x:x**2)
    [1, 4, 9, 16]

# Generated at 2022-06-21 12:11:41.312844
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    from random import uniform
    from statistics import stdev
    def compare_to_list(func, lst):
        '''
        Compare the output of MapList(func, lst) with [func(x) for x in lst].
        '''
        m = MapList(func, lst)
        c = [func(x) for x in lst]
        if m != c:
            raise RuntimeError
    for _ in range(100):
        n = int(uniform(0, 10**5))
        lst = [uniform(0, 10**6) for _ in range(n)]
        compare_to_list(lambda x: x, lst)
        compare_to_list(lambda x: int(x), lst)
        compare_to_list(lambda x: x + 1, lst)
       

# Generated at 2022-06-21 12:11:43.833279
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(list(LazyList(range(10)))) == 10



# Generated at 2022-06-21 12:11:48.245866
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    lst[10]  # force fetching first 10 elements
    assert all(x == y for x, y in zip(lst, range(10)))
    assert len(lst) == 10



# Generated at 2022-06-21 12:11:54.723450
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: s + x, ['a', 'b', 'c', 'd'])) == ['a', 'ab', 'abc', 'abcd']



# Generated at 2022-06-21 12:11:55.403472
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    return map(str, range(3))



# Generated at 2022-06-21 12:12:03.369995
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-21 12:12:06.953236
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    obj = LazyList("abc")
    it = obj.__iter__()
    assert isinstance(it, LazyList.LazyListIterator)
    assert it.index == 0

# Generated at 2022-06-21 12:12:22.143163
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(15, range(10))) == []

# Generated at 2022-06-21 12:12:31.657147
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    def assert_LazyList_equal(lst: LazyList[int], original: Iterable[int]) -> None:
        if len(lst) > 0:
            assert lst[0] == next(original)
        if len(lst) > 1:
            assert lst[1] == next(original)
            assert lst[-1] == original[-1]
        assert lst == list(original)

    assert_LazyList_equal(LazyList([]), [])
    assert_LazyList_equal(LazyList([1]), [1])
    assert_LazyList_equal(LazyList([1, 2, 3, 4]), [1, 2, 3, 4])

    lst1 = LazyList(take(5000, range(10000)))
    assert len(lst1) == 5000

# Generated at 2022-06-21 12:12:37.321551
# Unit test for function drop
def test_drop():
    assert [0,1,2] == list(drop(2,[2,3,4,5,6]))
    assert [1,2] == list(drop(1,(1,2)))
    assert [1] == list(drop(1,(1,)))
    assert [] == list(drop(2,(1,)))
    assert [] == list(drop(1, ()))
    return "Passed"



# Generated at 2022-06-21 12:12:46.948613
# Unit test for method __len__ of class Range
def test_Range___len__():
    print("*"*10, "Unit test for method __len__ of class Range", "*"*10)
    assert len(Range(0)) == 0
    assert len(Range(1)) == 1
    assert len(Range(1, 2)) == 1
    assert len(Range(2, 3)) == 1
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 10 + 1, 2)) == 5
    assert len(Range(0, 10 + 1, 3)) == 4
    print("-"*10, "Unit test for method __len__ of class Range passed!", "-"*10)
test_Range___len__()


# Generated at 2022-06-21 12:12:51.190591
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x, [])) == 0
    assert len(MapList(lambda x: x, [1, 2, 3])) == 3
    assert len(MapList(lambda x: x, [1, 2, 3, 4, 5])) == 5

# Generated at 2022-06-21 12:12:58.218099
# Unit test for method __next__ of class Range
def test_Range___next__():
    def check(start, stop, step):
        r = Range(start, stop, step)
        assert list(r) == list(range(start, stop, step))

    check(0, 10, 1)
    check(0, 10, 2)
    check(0, 10, 3)
    check(1, 10, 1)
    check(1, 10, 2)
    check(1, 10, 3)
    check(-10, 10, 1)
    check(-10, 10, 2)
    check(-10, 10, 3)
    check(-10, 10, -1)
    check(-10, 10, -2)
    check(-10, 10, -3)



# Generated at 2022-06-21 12:13:06.039323
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(stop=5)
    assert next(r) == 0
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert r.val == 5
    try:
        next(r)
        assert False
    except StopIteration:
        pass
    # Check if it is re-iterable
    r = Range(stop=5)
    for i in range(5):
        assert next(r) == i
    try:
        next(r)
        assert False
    except StopIteration:
        pass
    for i in range(5):
        assert next(r) == i

    r = Range(start=1, stop=5)
    assert next(r) == 1
    assert next(r) == 2

# Generated at 2022-06-21 12:13:11.273157
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert 3 == len(Range(5, 10, 2))
    assert 3 == len(Range(5, 11, 2))
    assert 2 == len(Range(5, 10, 3))
    assert 2 == len(Range(5, 11, 3))
    assert 2 == len(Range(5, 12, 3))

# Generated at 2022-06-21 12:13:21.195402
# Unit test for constructor of class LazyList
def test_LazyList():
    def gen():
        yield 1
        yield 2
        yield 3
    lst = LazyList(gen())
    assert lst[0] == 1
    assert lst[1] == 2
    assert lst[2] == 3
    assert list(lst[0:2]) == [1, 2]
    assert list(lst[0:3]) == [1, 2, 3]
    assert lst[-1] == 3
    assert lst[-2] == 2
    assert lst[-3] == 1
    assert list(lst) == [1, 2, 3]
    assert list(lst[0:1]) == [1]
    assert list(lst[0:0]) == []
    assert list(lst[0:-1]) == [1, 2]

# Generated at 2022-06-21 12:13:29.467194
# Unit test for function scanl
def test_scanl():
    it = split_by(scanl(lambda d, x: (x[0], x[1] + d[1]), [(0, 1), (1, 1), (2, 2), (3, 6), (4, 24), (5, 120)]),
                  criterion=lambda tup: tup[0] == 5)
    assert next(it) == [(0, 1), (1, 2), (2, 4), (3, 10), (4, 34), (5, 154)]
    assert not next(it)



# Generated at 2022-06-21 12:13:46.355355
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'x')) == ['x', 'xa', 'xab', 'xabc']



# Generated at 2022-06-21 12:13:48.683600
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]



# Generated at 2022-06-21 12:13:53.724885
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    def func(x): return x*x
    lst = [1, 2, 3, 4, 5]
    result = MapList(func, lst)
    assertResult = list(map(func, lst))
    for i in range(len(assertResult)):
        assert result[i] == assertResult[i]


# Generated at 2022-06-21 12:13:59.576033
# Unit test for constructor of class LazyList
def test_LazyList():
    for i in [1,2,3,4]:
        assert i == LazyList([1,2,3,4])[i]

    l1 = LazyList([1,2,3,4])
    assert l1[1:3][0] == l1[1]
    assert l1[1:3][1] == l1[2]



# Generated at 2022-06-21 12:14:08.885702
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[0:100] == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert r[0:100:2] == [1, 3, 5, 7, 9]
    assert r[::-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
    assert r[5:] == [6, 7, 8, 9, 10]
    assert r[:5] == [1, 2, 3, 4, 5]
    assert r[4:4] == []

# Generated at 2022-06-21 12:14:13.396158
# Unit test for constructor of class LazyList
def test_LazyList():
    def range_seq(n):
        for i in range(n):
            yield i
    l1 = LazyList(range_seq(100))
    assert l1[15] == 15
    assert len(l1) == 100
    # assert l1[100] == StopIteration

#__all__.append("LazyList")



# Generated at 2022-06-21 12:14:20.931492
# Unit test for function split_by
def test_split_by():
    # test criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    # test separator
    assert list(split_by("this is split by :", separator=':')) == [['t', 'h', 'i', 's', ' ', 'i', 's', ' ', 's', 'p', 'l', 'i', 't', ' ', 'b', 'y', ' '], []]
    # test criterion

# Generated at 2022-06-21 12:14:27.103848
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:14:30.205141
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(Range(5)) == list(range(5))
    assert list(Range(5)) == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 12:14:39.352777
# Unit test for constructor of class MapList
def test_MapList():
    # Initialization
    assert MapList(lambda x:x*x, [1, 2, 3, 4, 5]) == [1, 4, 9, 16, 25]
    # Get Item
    assert MapList(lambda x:x*x, [1, 2, 3, 4, 5])[0] == 1
    assert MapList(lambda x:x+x, [1, 2, 3, 4, 5])[4] == 10
    assert MapList(lambda x:x*x, [1, 2, 3, 4, 5])[4] == 25
    assert MapList(lambda x:x+x, [1, 2, 3, 4, 5])[-1] == 10
    assert MapList(lambda x:x*x, [1, 2, 3, 4, 5])[-1] == 25
    # Slice item


# Generated at 2022-06-21 12:14:45.439971
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    print(r[0], r[2], r[4])

# Generated at 2022-06-21 12:14:51.962219
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    assert list(r) == [1, 5, 9]
    try:
        r = Range(1, 11, -2)   # (start, end, step)
    except ValueError:
        print("Pass")

test_Range___next__()

 

# Generated at 2022-06-21 12:15:00.048226
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x:2*x,[1,2,3,4]) == [2,4,6,8]
    assert MapList(lambda x:1 if x % 3 == 0 else 0,Range(8)) == [0,0,1,0,0,1,0,0]
    assert MapList(lambda x:x % 3 == 0,[1,2,3,4,5,6,7,8]) == [False,False,True,False,False,True,False,False]


# Generated at 2022-06-21 12:15:12.368200
# Unit test for function scanr
def test_scanr():
    # test: list(scanr()) == reversed(list(scanl()))
    from random import randint
    from itertools import starmap
    from operator import add
    for _ in range(100):
        ls = [randint(-1000, 1000) for _ in range(randint(0, 100))]
        assert list(scanr(add, ls)) == list(reversed(list(scanl(add, ls))))
        assert list(scanr(add, ls, 0)) == list(reversed(list(scanl(add, ls, 0))))
        ls = [randint(-1000, 1000) for _ in range(randint(0, 100))]
        assert list(scanr(add, ls, -1)) == list(reversed(list(scanl(add, ls, -1))))



# Generated at 2022-06-21 12:15:14.765780
# Unit test for method __len__ of class Range
def test_Range___len__():
  range_exam = Range(1, 10, 1)
  val = range_exam.__len__()
  return val


# Generated at 2022-06-21 12:15:21.090748
# Unit test for function scanl
def test_scanl():
    from operator import add
    from functools import reduce
    from prettyprinter import pprint
    a = [1, 2, 3, 4]
    assert list(scanl(add, a)) == [1, 3, 6, 10]
    assert list(scanl(add, a, 0)) == [0, 1, 3, 6, 10]
    assert list(map(lambda x: reduce(add, x), split_by(scanl(add, a), empty_segments=True))) == [1, 4, 9, 16]


# Generated at 2022-06-21 12:15:24.038238
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(1000000))
    assert list(lst) == list(range(1000000))
    assert list(lst) == list(range(1000000))

# Generated at 2022-06-21 12:15:28.960671
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(2))) == [0, 1]



# Generated at 2022-06-21 12:15:33.137655
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(1, 10 + 1)
    assert r.__len__() == 10
    assert len(r) == 10
    r = Range(1, 11, 2)
    assert r.__len__() == 5
    assert len(r) == 5


# Generated at 2022-06-21 12:15:40.948193
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    obj = LazyList(range(10))
    assert obj[3] == 3
    assert obj[3: 6] == [3, 4, 5]
    assert obj[3: 6: 2] == [3, 5]
    with pytest.raises(TypeError):
        len(obj)

    obj = LazyList(range(10))
    with pytest.raises(IndexError):
        obj[10]
    assert len(obj) == 10



# Generated at 2022-06-21 12:16:29.365395
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-21 12:16:36.906591
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6,7,8,9]
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [1,2])) == []
    assert list(drop_until(lambda x: True, range(10))) == [0,1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: False, range(10))) == []
    assert list(drop_until(lambda x: False, [1,2,3])) == []

# A small helper function for testing if all elements satisfy a predicate.

# Generated at 2022-06-21 12:16:40.953607
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    test_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    lazy_list = LazyList(test_list)
    assert len(lazy_list) == len(test_list)
    for i in range(10):
        assert len(lazy_list[:i]) == i
test_LazyList___len__()



# Generated at 2022-06-21 12:16:51.242163
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x < 5, range(10))) == [0, 1, 2, 3, 4]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 5 and x > 3, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: True, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]