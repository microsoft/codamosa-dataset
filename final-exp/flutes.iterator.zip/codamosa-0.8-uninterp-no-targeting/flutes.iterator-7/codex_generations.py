

# Generated at 2022-06-21 12:07:26.600859
# Unit test for function chunk
def test_chunk():
    from keyword        import kwlist
    from collections    import deque
    from itertools      import cycle
    from random         import choice, shuffle, sample
    from hypothesis     import given, assume
    from hypothesis.strategies import integers, lists

    @given(integers(min_value=0, max_value=20), lists(integers(), min_size=0, max_size=10))
    def test(n, l):
        l = list(chunk(n, l))
        assert all(len(x) <= n for x in l)
        assert sum(map(len, l)) == len(l)
        assert sum(l, []) == l

    test()

    @given(integers(min_value=-1, max_value=-1))
    def test_with_negative(n):
        l = list

# Generated at 2022-06-21 12:07:31.838849
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:07:43.430652
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    #test for function __getitem__ in class Range
    r = Range(0, 10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[9] == 9
    assert r[10] == 0
    assert r[11] == 1
    assert r[20] == 0
    assert r[30] == 0
    r = Range(0, 10, 3)
    assert r[0] == 0
    assert r[1] == 3
    assert r[2] == 6
    assert r[3] == 9
    assert len(r) == 4
    r = Range(1, 11, 3)
    assert r[0] == 1
    assert r[1] == 4
    assert r[2] == 7
    assert r[3] == 10
    assert len(r) == 4

# Generated at 2022-06-21 12:07:50.086797
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x * x, [1, 2, 3])
    assert lst[0] == 1
    assert lst[1] == 4
    assert lst[2] == 9
    assert lst[:2] == [1, 4]
    assert list(lst) == [1, 4, 9]


# Generated at 2022-06-21 12:07:50.754505
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    pass

# Generated at 2022-06-21 12:08:01.203269
# Unit test for function scanl
def test_scanl():
    l = list(scanl(lambda a, b: a + b, list('abc')))
    assert l == ['a', 'ab', 'abc']
    l = list(scanl(lambda a, b: a * b, [1, 2, 3, 4]))
    assert l == [1, 2, 6, 24]
    l = list(scanl(lambda a, b: a + b, range(10), 0))
    assert l == [0, 0, 1, 3, 6, 10, 15, 21, 28, 36, 45]
    # Test empty list
    l = list(scanl(lambda a, b: a + b, []))
    assert l == []



# Generated at 2022-06-21 12:08:07.013032
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert list(MapList(lambda x: x * x, [1, 2, 3, 4])) == [1, 4, 9, 16]
    assert isinstance(MapList(lambda x: x * x, [1, 2, 3, 4])[0], int)
    assert MapList(lambda x: x * x, [1, 2, 3, 4])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3, 4])[:2] == [1, 4]

# Generated at 2022-06-21 12:08:17.884090
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    r = Range(1, 11, 2)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    assert r[0:4] == [1, 3, 5, 7]
    assert r[0:4:2] == [1, 5]
    assert r[-1] == 9
    #assert r[-1:4:-2] == [9, 5]
    #assert r[-1:4:2] == [9]

# Generated at 2022-06-21 12:08:20.816540
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList(range(10))
    l1 = iter(l)
    l2 = iter(l)
    assert list(l1) == list(range(10))
    assert list(l2) == list(range(10))



# Generated at 2022-06-21 12:08:27.724158
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 10, 2)
    
    assert isinstance(r.__iter__(), Iterator)
    iter_r = r.__iter__()
    assert all(next(iter_r) == i for i in [1, 3, 5, 7, 9])
    iter_r = r.__iter__()
    all(next(iter_r) for i in [])
    assert iter_r.__next__() == 1

# Generated at 2022-06-21 12:08:38.657393
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(0, range(10))) == ValueError
    assert list(chunk(-1, range(10))) == ValueError

test_chunk()



# Generated at 2022-06-21 12:08:39.857990
# Unit test for function drop
def test_drop():
    assert next(drop(5, range(1000000))) == 5



# Generated at 2022-06-21 12:08:47.694572
# Unit test for method __next__ of class Range
def test_Range___next__():
    obj = Range(1,10)
    assert next(obj) == 1
    assert next(obj) == 2
    assert next(obj) == 3
    assert next(obj) == 4
    assert next(obj) == 5
    assert next(obj) == 6
    assert next(obj) == 7
    assert next(obj) == 8
    assert next(obj) == 9
    assert next(obj) == 10
    try:
        obj = Range(1,10)
        next(obj)
        next(obj)
        next(obj)
        next(obj)
        next(obj)
        next(obj)
        next(obj)
        next(obj)
        next(obj)
        next(obj)
        next(obj)
    except StopIteration:
        assert True
    else:
        assert False


# Generated at 2022-06-21 12:08:51.779057
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for r in [range(0, 10, 1)]:
        for i in range(0, 10000):
            r_ = Range(r)
            assert [i for i in r_] == [i for i in r]

# Generated at 2022-06-21 12:08:54.562407
# Unit test for function chunk
def test_chunk():
    assert [x for x in chunk(3, range(10))] == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-21 12:08:56.357798
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x * x, [1, 2, 3])) == 3

# Generated at 2022-06-21 12:09:08.369124
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    #
    #
    #
    #
    R1 = Range(1, 10)
    print(len(R1))
    #
    #
    #
    #
    print(list(R1))
    #
    #
    #
    #
    print(R1[2:5])
    print(R1[:5])
    print(R1[3:])
    print(R1[::2])
    print(R1[-1], R1[-2], R1[-3])
    print(R1[1:4])
    print(R1[-3:-1])
    print(R1[-3:3])
    print(R1[-1:3])
    #
    #
    #
    #
    R2 = Range(5)

# Generated at 2022-06-21 12:09:11.681158
# Unit test for function chunk
def test_chunk():
    assert [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]] == list(chunk(3, range(10)))



# Generated at 2022-06-21 12:09:21.445932
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import random
    from .test_utils import random_sample

    val = random.choice([0, 2, 3])
    a = random.randint(1, 1000)
    b = random.randint(a, 1000)
    c = random.randint(1, 1000)
    len_a = (b - a) // c
    r = Range(a, b, c)
    for i in range(100):
        assert r[i] == a + c * i
        assert len(r[i]) == 1
        assert r[:i] == list(range(a, a + c * i, c))
        assert r[i:] == list(range(a + c * i, b, c))
        assert len(r[i:]) == len_a - i
        assert len(r[:i]) == i


# Generated at 2022-06-21 12:09:23.977703
# Unit test for constructor of class LazyList
def test_LazyList():
    assert list(LazyList(range(10))) == list(range(10))
    assert list(LazyList(range(10)).__iter__()) == list(range(10))
    assert list(LazyList(range(10)).__iter__()) == list(range(10))



# Generated at 2022-06-21 12:09:42.928164
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import operator
    lst = LazyList(range(10))
    assert lst[2] == 2
    assert lst[-1] == 9
    assert tuple(lst) == tuple(range(10))
    assert tuple(lst[3:6]) == (3, 4, 5)
    assert tuple(lst[3:-6:-1]) == (3, 2, 1, 0)

    lst2 = LazyList(operator.add(x, 1) for x in lst)
    assert lst2[1] == 3

    lst3 = LazyList(x for x in range(10))
    del lst3

# Generated at 2022-06-21 12:09:49.894741
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    import fy4a
    class A(fy4a.LazyList[int]):
        pass
    try:
        A([]).__len__()
    except:
        pass
    A([0]).__len__()
    try:
        A([0, 1])[0]
    except:
        pass
    A([0, 1])[1]
    A([0, 1]).__len__()



# Generated at 2022-06-21 12:10:01.299192
# Unit test for method __next__ of class Range
def test_Range___next__():
    """Unit test for method __next__ of class Range"""
    print("test_Range___next__", end = "")
    print(Range(3, 5))
    first = next(Range(3, 5))
    print(first)
    assert first == 3
    assert list(Range(2, 3)) == [2]
    assert list(Range(2, 3, 2)) == [2]
    assert list(Range(2, 4)) == [2, 3]
    assert list(Range(2, 6, 2)) == [2, 4]
    assert list(Range(2, 7, 2)) == [2, 4, 6]
    assert list(Range(0)) == []
    assert list(Range(1)) == [0]
    assert list(Range(2)) == [0, 1]
    assert list(Range(3))

# Generated at 2022-06-21 12:10:02.418602
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(2, 4 + 1)) == 3


# Generated at 2022-06-21 12:10:06.953027
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    lst = []
    for item in Range(10):
        lst.append(item)
    assert lst == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 12:10:10.384127
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    assert len(r) == 10
    i = 0
    for x in r:
        assert x == i
        i += 1

# Generated at 2022-06-21 12:10:13.023380
# Unit test for function scanl
def test_scanl():
    i = [1,2,3,4]
    assert list(scanl(operator.add, i)) == [1, 3, 6, 10]



# Generated at 2022-06-21 12:10:24.759246
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

    assert list(split_by([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]

# Generated at 2022-06-21 12:10:34.562187
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, [])) == []
    assert list(chunk(1, [1])) == [[1]]
    assert list(chunk(2, [1, 2])) == [[1, 2]]
    assert list(chunk(3, [1, 2])) == [[1, 2]]
    assert list(chunk(4, [1, 2, 3])) == [[1, 2, 3]]
    assert list(chunk(-1, [1, 2, 3])) == [[1, 2, 3]]
    assert list(chunk(0, [1, 2, 3])) == [[1, 2, 3]]
    assert list(chunk(1, [1, 2, 3])) == [[1], [2], [3]]
    assert list(chunk(2, [1, 2, 3]))

# Generated at 2022-06-21 12:10:46.847053
# Unit test for function chunk
def test_chunk():
    assert tuple(chunk(0, [])) == tuple()
    assert tuple(chunk(3, [])) == tuple()
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]

# Generated at 2022-06-21 12:10:55.137438
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, [])) == []
    assert list(chunk(1, [1, 2, 3])) == [[1], [2], [3]]


# Generated at 2022-06-21 12:10:58.929085
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:11:01.562791
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x, [1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-21 12:11:08.328984
# Unit test for function scanl
def test_scanl():
    from operator import add
    assert list(scanl(add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:11:09.352490
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x * x, Range(5))) == 5


# Generated at 2022-06-21 12:11:17.389498
# Unit test for function split_by
def test_split_by():
    list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    list(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[], [1, 2], [], [4, 5], [], [7, 8]]
    list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

# Tests for functions in this module

# Generated at 2022-06-21 12:11:19.272195
# Unit test for function drop
def test_drop():
   itr = iter(range(8))
   print(list(itr))

test_drop()


# Generated at 2022-06-21 12:11:26.587077
# Unit test for function drop
def test_drop():
    assert list(drop(0, [1,2,3,4])) == [1,2,3,4]
    assert list(drop(3, [1,2,3,4])) == [4]
    assert list(drop(5, [1,2,3,4])) == []
    assert list(drop(6, [1,2,3,4])) == []
    assert list(drop(3, [1])) == []
    assert list(drop(3, [])) == []
test_drop()



# Generated at 2022-06-21 12:11:31.180045
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5,10))
    assert list(drop(5, range(3,10))) == list(range(8,10))
    assert list(drop(5, range(5,10))) == list(range(10))
    assert list(drop(5, range(10,10))) == []


# Generated at 2022-06-21 12:11:42.027367
# Unit test for function split_by
def test_split_by():
    import random
    from pytest import raises

    def test_split_by_impl(iterable, criterion, empty_segments):
        assert list(split_by(iterable,
                             criterion=criterion,
                             empty_segments=empty_segments)) == [[x for x in iterable if not criterion(x)]]

    def test_split_by_impl_with_separator(iterable, criterion, empty_segments):
        separator = criterion
        assert list(split_by(iterable,
                             criterion=criterion,
                             empty_segments=empty_segments)) == [[x for x in iterable if x != separator]]


# Generated at 2022-06-21 12:11:51.307737
# Unit test for constructor of class Range
def test_Range():
    def check(r, r_expect):
        r_actual = Range(*r)
        if len(r_expect) == 1:
            assert len(r_actual) == r_expect[0]
        elif len(r_expect) == 2:
            assert len(r_actual) == (r_expect[1] - r_expect[0])
        else:
            assert len(r_actual) == 1 + (r_expect[1] - r_expect[0]) // r_expect[2]
        assert list(r_actual) == [r_expect[0] + r_expect[2] * i for i in range(len(r_actual))]
        for i in range(len(r_actual)):
            assert r_actual[i] == r_expect

# Generated at 2022-06-21 12:11:56.809320
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    for _ in range(10):
        lst = [randint(-1000, 1000) for _ in range(10)]
        for i in range(10):
            mapa = MapList(lambda x: 2 * x, lst)
            for j in range(len(lst)):
                assert mapa[j] == lst[j] * 2
                assert mapa[j] == lst[j] * 2
                assert mapa[j] == lst[j] * 2
            mapa = MapList(lambda x: x * x, lst)
            for j in range(len(lst)):
                assert mapa[j] == lst[j] * lst[j]
                assert mapa[j] == lst[j] * lst[j]
                assert mapa

# Generated at 2022-06-21 12:11:59.711253
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    obj = r[0:2:1]
    if obj != [0, 1]:
        return True
    return False


# Generated at 2022-06-21 12:12:05.007554
# Unit test for function drop
def test_drop():
    assert list(drop(-1, range(5))) == []
    assert list(drop(5, range(5))) == []
    assert list(drop(0, range(5))) == list(range(5))
    assert list(drop(3, range(5))) == list(range(3,5))
# test case for function drop
test_drop()



# Generated at 2022-06-21 12:12:11.406683
# Unit test for function split_by
def test_split_by():
    assert tuple(split_by(range(10), criterion=lambda x: x % 3 == 0)) == ((1, 2), (4, 5), (7, 8))
    assert tuple(split_by(" Split by: ", criterion=lambda x: x == '.', empty_segments=True)) == \
        (('S', 'p', 'l', 'i', 't'), ('b', 'y', ':'))



# Generated at 2022-06-21 12:12:15.026255
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(3))
    assert not lst.exhausted
    assert lst[1] == 1
    assert not lst.exhausted
    assert len(lst) == 3
    assert lst.exhausted



# Generated at 2022-06-21 12:12:17.747209
# Unit test for constructor of class LazyList
def test_LazyList():
    assert(list(LazyList(range(3))) == list(range(3)))
    assert(len(LazyList(range(0))) == 0)
    assert(len(LazyList(range(3))) == 3)



# Generated at 2022-06-21 12:12:25.709419
# Unit test for method __next__ of class Range
def test_Range___next__():
    print('test_Range___next__')
    r = Range(1,10+1)
    count = 1
    while True:
        try:
            result = r.__next__()
            if result != count:
                print('test failed at: ', result, '_should be: ', count)
            else:
                print('test passed at: ', result)
            count += 1
        except:
            break

# Generated at 2022-06-21 12:12:29.229810
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(operator.add, [1, 2, 3, 4, 5])
    assert len(lst) == 5
    lst = MapList(operator.add, [1, 2, 3, 4])
    assert len(lst) == 4

# Generated at 2022-06-21 12:12:33.484617
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 11)) == 10
    assert len(Range(0, 11, 2)) == 6


# Generated at 2022-06-21 12:12:44.577692
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    def tst():
        x = LazyList([1, 2, 3])
        while True:
            try:
                next(iter(x))
            except StopIteration:
                pass
            else:
                continue
            break
        return len(x) < 4
    assert tst()



# Generated at 2022-06-21 12:12:46.111909
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    pass


# Generated at 2022-06-21 12:12:48.714412
# Unit test for function drop
def test_drop():
    for i in range(-2, 3):
        assert list(drop(i, range(5))) == list(range(max(0, i), 5))


# Generated at 2022-06-21 12:12:56.609880
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    a = LazyList(range(100000))
    assert a[0] == 0
    assert a[-1] == 99999
    assert a[0:5] == [0, 1, 2, 3, 4]
    assert len(a) == 100000
    assert a == list(range(100000))
    assert a[30000:40000:2] == list(range(30000, 40000, 2))
    assert a[-10000:] == list(range(90000, 100000))
    assert a[0:1000] == range(1000)
    assert a[1000:2000] == range(1000, 2000)



# Generated at 2022-06-21 12:12:59.710625
# Unit test for function drop
def test_drop():
    import numpy as np
    a = np.array([1,2,3,4,5])
    b = np.array(list(drop(2, a)))
    assert all([np.array_equal(b, a[2:])])


# Generated at 2022-06-21 12:13:01.913205
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    for l in [range(3), [], list(range(-2, 3))]:
        assert len(MapList(lambda x: x + 1, l)) == len(l)

# Generated at 2022-06-21 12:13:14.143996
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(Range(0, 10)) == list(range(10))
    assert list(Range(1, 10)) == list(range(1, 10))
    assert list(Range(-100, 100, 10)) == list(range(-100, 100, 10))
    assert list(Range(-100, 100, 10)) == list(range(-100, 90))
    assert list(Range(-100, 90)) == list(range(-100, 90))
    assert list(Range(0, 50, 3)) == list(range(0, 50, 3))
    assert list(Range(0, 50, 4)) == list(range(0, 50, 4))
    assert list(Range(0, 50, 5)) == list(range(0, 50, 5))
    assert list(Range(0, 50, 6)) == list(range(0, 50, 6))

# Generated at 2022-06-21 12:13:16.267784
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:13:21.011610
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 11, 2)
    assert r.__next__() == 1
    assert r.__next__() == 3
    assert r.__next__() == 5
    assert r.__next__() == 7
    assert r.__next__() == 9
    try:
        r.__next__()
        assert False
    except:
        assert True


# Generated at 2022-06-21 12:13:32.814073
# Unit test for method __len__ of class Range
def test_Range___len__():
    print('Test __len__')
    for i in range(100):
        random_item = random.randint(0, len(range(100)) ** 2)
        assert len(Range(random_item)) == len(range(random_item)), 'Length of Range({0}) should be {1}'.format(random_item, len(range(random_item)))
        random_item = random.randint(0, len(range(100)) ** 2)
        assert len(Range(0, random_item)) == len(range(0, random_item)), 'Length of Range(0,{0}) should be {1}'.format(random_item, len(range(0, random_item)))
        random_item = random.randint(0, len(range(100)) ** 2)

# Generated at 2022-06-21 12:14:17.241245
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
  import unittest
  class Test__iter__(unittest.TestCase):
    def helper(self, func):
      return list(MapList(func, range(3)))
    def test_0(self):
      func = (lambda x: x * 0)
      expected = [0, 0, 0]
      actual = self.helper(func)
      self.assertEqual(actual, expected)
    def test_1(self):
      func = (lambda x: x * x)
      expected = [0, 1, 4]
      actual = self.helper(func)
      self.assertEqual(actual, expected)
    def test_2(self):
      func = (lambda x: x)
      expected = [0, 1, 2]
      actual = self.helper(func)

# Generated at 2022-06-21 12:14:29.486759
# Unit test for function chunk
def test_chunk():
    result = list(chunk(3, range(10)))
    assert result == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    result = list(chunk(3, range(9)))
    assert result == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    result = list(chunk(3, range(8)))
    assert result == [[0, 1, 2], [3, 4, 5], [6, 7]]
    result = list(chunk(3, range(7)))
    assert result == [[0, 1, 2], [3, 4, 5], [6]]
    result = list(chunk(3, range(6)))
    assert result == [[0, 1, 2], [3, 4, 5]]
    result = list

# Generated at 2022-06-21 12:14:32.966342
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([0, 1, 2])
    assert len(lst) == 3
    lst = LazyList(range(10))
    assert len(lst) == 10


# Generated at 2022-06-21 12:14:34.992963
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = iter(LazyList(range(10)))
    assert list(it) == list(range(10))


# Generated at 2022-06-21 12:14:38.126713
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_class = Range(10)
    for i in range(5):
        item=test_class[i]
        assert type(item) == int
        assert item == i
    assert test_class[5:10] == list(range(5, 10))





# Generated at 2022-06-21 12:14:46.597903
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    lst1 = [1, 2, 3, 4, 5]
    # Original list unchanged
    assert lst1[0] == 1
    assert lst1[1] == 2
    assert lst1[2] == 3
    # List returned by object equals to list returned by function
    ml = MapList(lambda x: x * x, lst1)
    lst2 = list(ml)
    assert lst2[0] == 1
    assert lst2[1] == 4
    assert lst2[2] == 9



# Generated at 2022-06-21 12:14:55.631014
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # 
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    # 
    assert isinstance(MapList(lambda i: a[i] * b[i], Range(len(a)))[0], int)
    assert isinstance(MapList(lambda i: a[i] * b[i], Range(len(a)))[1], int)
    assert isinstance(MapList(lambda i: a[i] * b[i], Range(len(a)))[2], int)
    assert isinstance(MapList(lambda i: a[i] * b[i], Range(len(a)))[3], int)
    assert isinstance(MapList(lambda i: a[i] * b[i], Range(len(a)))[4], int)
   

# Generated at 2022-06-21 12:15:01.653235
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    lst = [1, 2, 3, 4]
    it = MapList(lambda x: x * x, lst).__iter__()
    assert it.__next__() == 1
    assert it.__next__() == 4
    assert it.__next__() == 9
    assert it.__next__() == 16
    raises(StopIteration, 'it.__next__()')


# Generated at 2022-06-21 12:15:05.064048
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [9],
    ]


# Generated at 2022-06-21 12:15:10.723830
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(5, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(3, range(0))) == []


# Generated at 2022-06-21 12:15:54.842501
# Unit test for function drop_until
def test_drop_until():
    import random
    r = random.randint(0, 10)
    ret = drop_until(lambda x: x > r, range(10))
    assert all(i > r for i in ret)
    assert len(list(ret)) == 10 - r


# Generated at 2022-06-21 12:16:06.546838
# Unit test for function split_by

# Generated at 2022-06-21 12:16:08.730836
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r=Range(2, 3)
    r.__iter__()
    r.l

# Generated at 2022-06-21 12:16:13.784701
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(5))
    assert len(lst) == 5
    lst = LazyList(range(3))
    lst[1]
    assert len(lst) == 3
    lst = LazyList(range(3))
    assert len(lst) == 3



# Generated at 2022-06-21 12:16:14.435009
# Unit test for function drop
def test_drop():
    pass



# Generated at 2022-06-21 12:16:16.993011
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda e: e + 1, [1, 2, 3, 4])
    assert len(lst) == 4
    del lst


# Generated at 2022-06-21 12:16:19.858865
# Unit test for function drop
def test_drop():
    try:
        next(drop(-1, range(1000000)))
        assert False
    except ValueError as e:
        assert str(e) == "`n` should be non-negative"



# Generated at 2022-06-21 12:16:23.308562
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    c = MapList(lambda x: x*x, [1, 2, 3, 4, 5])
    # map(lambda x: x*x, [1, 2, 3, 4, 5])
    assert tuple(c) == (1, 4, 9, 16, 25)

# Generated at 2022-06-21 12:16:29.593128
# Unit test for method __getitem__ of class MapList

# Generated at 2022-06-21 12:16:31.341591
# Unit test for function drop_until
def test_drop_until():
    iterable = range(10)
    assert list(drop_until(lambda x: x > 5, iterable)) == list(filter(lambda x: x > 5, iterable))

