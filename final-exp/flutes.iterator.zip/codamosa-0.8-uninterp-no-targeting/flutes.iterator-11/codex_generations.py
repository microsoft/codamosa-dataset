

# Generated at 2022-06-21 12:07:32.448639
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    with pytest.raises(ValueError):
        assert list(take(-1, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(1, range(1000000))) == [0]



# Generated at 2022-06-21 12:07:36.107945
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-21 12:07:43.431014
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(3))
    iterator = lst.__iter__()
    assert isinstance(iterator, LazyList.LazyListIterator)
    assert iterator.list() is lst
    assert iterator.index == 0
    assert next(iterator) == 0
    assert iterator.index == 1
    assert next(iterator) == 1
    assert iterator.index == 2
    assert next(iterator) == 2
    assert iterator.index == 3
    assert next(iterator) == StopIteration
    assert iterator.index == 3



# Generated at 2022-06-21 12:07:47.112191
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x * x, [1, 2, 3])) == [1, 4, 9]

# Generated at 2022-06-21 12:07:54.153681
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [])) == []



# Generated at 2022-06-21 12:08:02.455080
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    l = MapList(lambda x: x + 1, [1, 2, 3, 4, 5])
    it = iter(l)
    assert next(it) == 2
    assert next(it) == 3
    assert next(it) == 4
    assert next(it) == 5
    assert next(it) == 6
    try:
        next(it)
        assert False, 'expected StopIteration'
    except StopIteration:
        pass
test_MapList___iter__()

# Generated at 2022-06-21 12:08:06.496634
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert (len(MapList(lambda i: None, [])) == 0)
    assert (len(MapList(lambda i: None, [1])) == 1)
    assert (len(MapList(lambda i: None, [1, 2, 3])) == 3)

# Generated at 2022-06-21 12:08:10.141424
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(range(10000))
    assert len(lst) == 10000
    assert lst[5000] == 5000
    assert list(lst[0:10]) == list(range(10))



# Generated at 2022-06-21 12:08:14.989291
# Unit test for function take
def test_take():
    assert list(take(10, range(15))) == list(range(10))
    assert list(take(-1, range(15))) == []
    assert list(take(15, range(15))) == list(range(15))
    assert list(take(16, range(15))) == list(range(15))
    assert list(take(0, range(15))) == []



# Generated at 2022-06-21 12:08:26.379928
# Unit test for function chunk
def test_chunk():
    lst = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(chunk(1, lst)) == [[1], [2], [3], [4], [5], [6], [7], [8], [9], [10]]
    assert list(chunk(2, lst)) == [[1, 2], [3, 4], [5, 6], [7, 8], [9, 10]]
    assert list(chunk(3, lst)) == [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10]]
    assert list(chunk(4, lst)) == [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10]]

# Generated at 2022-06-21 12:08:47.405934
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], '[+]')) == ['[+]a', 'b[+]', 'cd[+]', 'd']



# Generated at 2022-06-21 12:08:51.044385
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1, 2, 3])) == 3
    try:
        len(LazyList(iter([1, 2, 3])))
        assert False
    except TypeError:
        pass



# Generated at 2022-06-21 12:08:53.002366
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList([1, 2, 3])) == [1, 2, 3]


# Generated at 2022-06-21 12:08:56.106775
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(0, 10, 1)
    lst = []
    for i in r:
        lst.append(i)
    assert(lst == list(range(0, 10, 1)))

# Generated at 2022-06-21 12:09:00.588905
# Unit test for function scanl
def test_scanl():
    import operator
    assert list(scanl(operator.add, [1, 2, 3])) == [1, 3, 6]

    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c'])) == ['a', 'ba', 'cba']

    assert list(scanl(operator.add, [1, 2, 3], 10)) == [10, 11, 13, 16]

    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c'], 'x')) == ['x', 'xa', 'xba']



# Generated at 2022-06-21 12:09:03.952209
# Unit test for function drop
def test_drop():
    data = [1,2,3,4,5,6,7]
    expected = [3,4,5,6,7]
    result = list(drop(2, data))
    assert result == expected



# Generated at 2022-06-21 12:09:12.937536
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10, 20))
    assert list(lst) == list(range(10, 20))
    assert list(lst) == list(range(10, 20))
    lst = LazyList(range(20))
    assert list(lst) == list(range(20))
    assert list(lst) == list(range(20))
    lst = LazyList(range(20))
    assert list(lst.LazyListIterator(lst)) == list(range(20))

# Generated at 2022-06-21 12:09:19.819230
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, [1, 2, 3])) == []
    assert list(chunk(1, [1, 2, 3])) == [[1], [2], [3]]
    assert list(chunk(2, [1, 2, 3])) == [[1, 2], [3]]
    assert list(chunk(3, [1, 2, 3])) == [[1, 2, 3]]
    assert list(chunk(4, [1, 2, 3])) == [[1, 2, 3]]



# Generated at 2022-06-21 12:09:23.154244
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    s = MapList(lambda x: x * x, [1,2,3])
    assert list(s) == [1, 4, 9]


# Generated at 2022-06-21 12:09:33.770307
# Unit test for function take
def test_take():
    assert list(take(0, [])) == []
    assert list(take(0, [0, 1, 2])) == []
    assert list(take(1, [])) == []
    assert list(take(1, [0, 1, 2])) == [0]
    assert list(take(2, [])) == []
    assert list(take(2, [0, 1, 2])) == [0, 1]
    assert list(take(3, [])) == []
    assert list(take(3, [0, 1, 2])) == [0, 1, 2]
    assert list(take(4, [])) == []
    assert list(take(4, [0, 1, 2])) == [0, 1, 2]

# Generated at 2022-06-21 12:09:57.012265
# Unit test for constructor of class Range
def test_Range():
    r = Range(5)
    assert list(r) == [0,1,2,3,4]

    r = Range(0, 5)
    assert list(r) == [0,1,2,3,4]

    r = Range(0, 5, 1)
    assert list(r) == [0,1,2,3,4]



# Generated at 2022-06-21 12:10:06.420700
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    # Test for method __iter__() of class Range
    # Check that the list matches expected
    i = 0
    r = Range(10)
    expected = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for e in r:
        assert e == expected[i], "Unexpected result"
        i += 1
    r = Range(5, 14)
    expected = [5, 6, 7, 8, 9, 10, 11, 12, 13]
    i = 0
    for e in r:
        assert e == expected[i], "Unexpected result"
        i += 1
    r = Range(3, 17, 3)
    expected = [3, 6, 9, 12, 15]
    i = 0

# Generated at 2022-06-21 12:10:18.128990
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Test index access
    lazy_list = LazyList(range(100))
    assert lazy_list[50] == 50
    assert lazy_list[100] == 100
    assert lazy_list[-1] == 99
    with pytest.raises(IndexError):
        lazy_list[-101]
    with pytest.raises(IndexError):
        lazy_list[101]
    # Test slice access
    assert list(lazy_list[25:50]) == list(range(25, 50))
    assert list(lazy_list[-10:]) == list(range(90, 100))
    assert list(lazy_list[-10:99]) == list(range(90, 99))
    assert list(lazy_list[50:50]) == []

# Generated at 2022-06-21 12:10:28.349399
# Unit test for function chunk
def test_chunk():
    from test.util import TestCase
    from itertools import chain
    from random import randint
    t = TestCase()
    for _ in range(100):
        for n in range(1, 5):
            for xs in chain.from_iterable(
                    (list(range(xs)) + list(range(xs)) for xs in range(1, 5))):
                t.assertEqual(
                    list(chunk(n, xs)),
                    [list(xs[i:i+n]) for i in range(0, len(xs), n)])
    for _ in range(100):
        xs = [randint(-100, 100) for _ in range(randint(1, 100))]

# Generated at 2022-06-21 12:10:33.681557
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(1, range(10))) == [0]
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(20, range(10))) == list(range(10))


# Generated at 2022-06-21 12:10:38.826515
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:10:44.661753
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = LazyList(range(10))
    assert list(it) == list(range(10))
    it = LazyList(range(10))
    assert list(it[:5]) == list(range(5))
    assert list(it) == list(range(10))

# Generated at 2022-06-21 12:10:52.953440
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    XMapList = MapList(lambda x: x, [0, 1, 2, 3, 4])
    assert XMapList.__getitem__(0) == 0
    assert XMapList.__getitem__(1) == 1
    assert XMapList.__getitem__(2) == 2
    assert XMapList.__getitem__(3) == 3
    assert XMapList.__getitem__(4) == 4
    assert XMapList.__getitem__(slice(0, 3)) == [0, 1, 2]
    assert XMapList.__getitem__(slice(0, 1)) == [0]
    assert XMapList.__getitem__(slice(0, 2)) == [0, 1]

# Generated at 2022-06-21 12:11:00.155181
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    n = 1
    lst = LazyList(range(n))
    assert lst[0] == 0
    assert len(lst) == n
    assert lst != list(range(n))
    assert lst == list(range(n))
    n = 2
    lst = LazyList(range(n))
    assert lst[0] == 0
    assert lst[-1] == 1
    assert len(lst) == n
    assert lst != list(range(n))
    assert lst == list(range(n))
    i = iter(lst)
    assert next(i) == 0
    assert next(i) == 1
    assert i.index == 2
    assert list(i) == []
    i = iter(lst)

# Generated at 2022-06-21 12:11:01.893253
# Unit test for function drop
def test_drop():
    assert list(drop(1, range(1, 5))) == [2, 3, 4]



# Generated at 2022-06-21 12:11:21.730974
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    """Unit test for method __getitem__ of class Range"""
    test_case = [
        ([], 1, 2, 3),
        ([1, 2, 3, 4, 5], 1, 6, 1),
        ([1, 2, 3, 4, 5], 1, 6, 2),
        ([1, 3, 5], 1, 6, 2),
        ([1, 3], 1, 6, 2),
        ([1], 1, 6, 2),
        ([], 1, 6, 2),
    ]
    for expected, l, r, step in test_case:
        r = Range(l, r, step)
        assert r[:] == expected


from typing_extensions import Final

from .is_not_none import is_not_none
from .not_none import not_none
from .none import none

# Generated at 2022-06-21 12:11:31.726007
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x + 1, [1, 2, 3])[0] == 2
    assert MapList(lambda x: x + 1, [1, 2, 3])[1] == 3
    assert MapList(lambda x: x + 1, [1, 2, 3])[2] == 4
    assert MapList(lambda x: x + 1, [1, 2, 3])[-1] == 4
    assert MapList(lambda x: x + 1, [1, 2, 3])[-2] == 3
    assert MapList(lambda x: x + 1, [1, 2, 3])[-3] == 2
    assert MapList(lambda x: x + 1, [1, 2, 3])[1:3] == [3, 4]

# Generated at 2022-06-21 12:11:39.687395
# Unit test for function scanl
def test_scanl():
    import operator
    assert list(scanl(operator.add, [], 0)) == [0]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    with pytest.raises(ValueError):
        list(scanl(operator.add, [1, 2, 3, 4], '', 0))
    with pytest.raises(ValueError):
        list(scanl(operator.add, [1], '', 0))



# Generated at 2022-06-21 12:11:42.921070
# Unit test for function take
def test_take():
    l = [1, 2, 3, 4, 5]
    for n in range(0, len(l) + 1):
        assert list(take(n, l)) == l[:n]
    assert list(take(5, [])) == []
    assert list(take(0, [])) == []



# Generated at 2022-06-21 12:11:53.128027
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    test_cases = (
        ([], []),
        ([1], [1]),
        ([1, 2, 3, 4], [1, 2, 3, 4]),
        (iter([1, 2, 3, 4]), [1, 2, 3, 4]),
        (iter([1, 2]), [1, 2]),
        (iter([1]), [1]),
    )
    for param, expected in test_cases:
        with it.suppress_deprecation_warnings():
            output = LazyList(param)
            assert isinstance(output.__iter__(), LazyList.LazyListIterator)
            assert list(output) == expected
            assert isinstance(output.__iter__(), LazyList.LazyListIterator)
            assert list(output) == expected


# Generated at 2022-06-21 12:11:55.598613
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(iter(range(10)))) == 10
    assert len(LazyList(iter([]))) == 0
    assert len(LazyList(iter(range(1, 10 ** 9)))) == 10 ** 9 - 1



# Generated at 2022-06-21 12:12:02.737956
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # FIXME (test): Add unit tests
    # - should cover all edge cases,
    # - should be as minimal as possible,
    # - should be able to run as a script,
    # - should run in 100ms or less (Travis runs tests in parallel, so running longer than that could cause timeouts),
    # - tests the behaviour defined in the docstring.
    raise NotImplementedError


# Generated at 2022-06-21 12:12:04.798437
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[:5] == [0, 1, 2, 3, 4]


# Generated at 2022-06-21 12:12:11.584048
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    with pytest.raises(ValueError):
        list(chunk(0, range(8)))
test_chunk()



# Generated at 2022-06-21 12:12:19.658523
# Unit test for constructor of class Range
def test_Range():
    assert Range(0) == []
    assert Range(2) == [0, 1]
    assert Range(1, 5) == Range(4) == [0, 1, 2, 3]
    assert Range(1, 5, 2) == [1, 3]
    assert Range(1, 5, 3) == [1, 4]
    assert Range(1, 5, 4) == [1]
    assert Range(4, 2, -1) == [4, 3]
    assert Range(4, 2, -2) == [4]
    assert Range(4, 2, -3) == []
    assert Range(4, 2, 3) == []
    assert Range(5, 0, -1) == [5, 4, 3, 2, 1]
    assert Range(5, 0, -2) == [5, 3, 1]

# Generated at 2022-06-21 12:12:32.667093
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # test_LazyList___getitem__#slice#1
    assert list(LazyList(range(10))[5:]) == [5, 6, 7, 8, 9]
    # test_LazyList___getitem__#slice#2
    assert list(LazyList(range(10))[:5]) == [0, 1, 2, 3, 4]
    # test_LazyList___getitem__#slice#3
    assert list(LazyList(range(10))[5:10]) == [5, 6, 7, 8, 9]
    # test_LazyList___getitem__#slice#4
    assert list(LazyList(range(10))[0:5:2]) == [0, 2, 4]
    # test_LazyList___getitem__#slice#5
    assert list

# Generated at 2022-06-21 12:12:39.402437
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == [0, 1, 2]
    assert list(take(0, range(10))) == []
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(100, range(10))) == list(range(10))
    assert list(take(100, [1])) == [1]
    assert list(take(100, [])) == []
    try:
        take(-1, [])
        assert False
    except ValueError:
        pass



# Generated at 2022-06-21 12:12:43.591028
# Unit test for function take
def test_take():
    print("testing `take` ...")
    assert list(take(0, [])) == []
    assert list(take(0, [1, 2, 3])) == []
    assert list(take(10, [])) == []
    assert list(take(10, [1, 2, 3])) == [1, 2, 3]
test_take()



# Generated at 2022-06-21 12:12:46.688129
# Unit test for constructor of class MapList
def test_MapList():
    list1 = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    print(list1[3])



# Generated at 2022-06-21 12:12:49.559109
# Unit test for constructor of class Range
def test_Range():
    r = Range(1, 11, 2)
    assert r.l == 1
    assert r.r == 11
    assert r.step == 2
    assert r.val == 1
    assert r.length == 5



# Generated at 2022-06-21 12:12:58.515590
# Unit test for function split_by
def test_split_by():
    def is_int(x):
        try:
            int(x)
            return True
        except ValueError:
            return False

    assert list(split_by("Split by:", criterion=is_int)) == [
        ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']
    ]
    assert list(split_by("Split by: ", criterion=is_int, empty_segments=True)) == [
        [], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []
    ]
    assert list(split_by("Split by:", separator='.')) == [
        ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']
    ]

# Generated at 2022-06-21 12:13:05.982951
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, range(10))) == list(range(0, 55, 10))
    assert list(scanl(operator.add, range(10), 10)) == [10, 11, 13, 16, 20, 25, 31, 38, 46, 55]
    assert list(scanl(operator.add, range(10), 1)) == [1, 2, 4, 7, 11, 16, 22, 29, 37, 46]

    assert list(scanl(lambda s, x: x + s, range(10))) == list(range(9, -1, -1))
    assert list(scanl(lambda s, x: x + s, range(10), 100)) == [100, 99, 97, 94, 90, 85, 79, 72, 64, 55]

# Generated at 2022-06-21 12:13:17.562355
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert len(r) == 10

    r = Range(0, 10)
    assert len(r) == 10

    r = Range(0, 10, 2)
    assert len(r) == 5

    r = Range(0, 11, 2)
    assert len(r) == 6

    r = Range(0, 10, 3)
    assert len(r) == 4

    r = Range(0, 10, 4)
    assert len(r) == 3

    r = Range(10, 0, -1)
    assert len(r) == 10

    r = Range(10, 0, -2)
    assert len(r) == 5

    r = Range(11, 0, -2)
    assert len(r) == 6

    r = Range(10, 0, -3)


# Generated at 2022-06-21 12:13:24.397295
# Unit test for function drop_until
def test_drop_until():
    r"""Test cases for drop_until"""
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [1])) == []
    assert list(drop_until(lambda x: x > 5, [6])) == [6]
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6])) == [6]
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7])) == [6, 7]
    assert list(drop_until(lambda x: x > 1, [1, 2, 3, 4, 5, 6, 7])) == [2, 3, 4, 5, 6, 7]

# Generated at 2022-06-21 12:13:35.606755
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    _assertEqual(
        MapList(lambda x: x * x, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).__getitem__(7),
        49)

    _assertEqual(
        MapList(lambda x: x * x, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).__getitem__(
            slice(0, 7, 2)),
        [0, 4, 16, 36])

    _assertEqual(
        MapList(lambda x: x * x, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).__getitem__(
            slice(0, 7, 2)),
        [0, 4, 16, 36])

# Generated at 2022-06-21 12:13:50.265031
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    r = Range(2, 4)
    a = [r, 4, 5]

    # Unit test for method __iter__ of class MapList without index
    r = MapList(lambda x : x + 10, a)
    assert isinstance(r.__iter__(), Iterator)
    b = [12, 14, 15]
    assert list(r.__iter__()) == b

    # Unit test for method __iter__ of class MapList with index
    r = MapList(lambda i : a[i] + 10, [0, 1, 2])
    assert isinstance(r.__iter__(), Iterator)
    b = [12, 14, 15]
    assert list(r.__iter__()) == b



# Generated at 2022-06-21 12:13:53.600900
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1,2,3,4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-21 12:13:58.396567
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert lst[1] == 2 ** 2
    assert lst[:3] == [1, 2 ** 2, 3 ** 2]



# Generated at 2022-06-21 12:14:07.949090
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import random, sys
    for length in range(1000):
        for step in range(1, length + 1):
            for rand_st in range(100):
                r1 = list(range(rand_st, rand_st + length * step, step))
                r2 = Range(rand_st, rand_st + length * step, step)
                assert len(r1) == len(r2)
                idx_list = list(range(len(r1)))
                random.shuffle(idx_list)
                for idx in idx_list:
                    assert r1[idx] == r2[idx]
    # test slicing
    for length in range(sys.maxsize):
        for step in range(1, length + 1):
            r1 = list(range(length * step))

# Generated at 2022-06-21 12:14:12.834587
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]


# Generated at 2022-06-21 12:14:18.764438
# Unit test for constructor of class LazyList
def test_LazyList():
    it=iter([1,2,3])
    a=LazyList(it)
    assert a.iter
    assert not a.exhausted
    assert not a.list
    it=[]
    try:
        b=LazyList(it)
    except:
        pass
    it=range(3)
    b=LazyList(it)
    assert b.iter
    assert not b.exhausted
    assert not b.list
    it=range(100)
    c=LazyList(it)


# Generated at 2022-06-21 12:14:22.528091
# Unit test for constructor of class MapList
def test_MapList():
    f = lambda x: x * x
    lst = [1, 2, 3, 4]
    r = MapList(f, lst)
    assert r[1] == 4
    assert list(r) == [i * i for i in lst]



# Generated at 2022-06-21 12:14:29.309404
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda x, y: x + y, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:14:34.710737
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    a = LazyList(range(1, 100))
    b = a.__iter__()
    c = a.__iter__()
    assert next(b) == 1
    assert next(b) == 2
    assert next(c) == 1
    assert next(c) == 2
    assert next(b) == 3
    assert next(c) == 3


# Generated at 2022-06-21 12:14:40.692506
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList('123456789')
    assert len(a) == 9
    assert a[0] == '1'
    assert a[1] == '2'
    assert a[2] == '3'
    assert a[3] == '4'
    assert a[4] == '5'
    assert a[5] == '6'
    assert a[6] == '7'
    assert a[7] == '8'
    assert a[8] == '9'
    assert a[9] == '1'
    assert a[10] == '2'
    assert a[11] == '3'



# Generated at 2022-06-21 12:14:55.759417
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10, 2)
    assert r[0] == 1
    assert r[1] == 3
    assert r[2] == 5
    assert r[3] == 7
    assert r[4] == 9
    assert r[-1] == 9
    assert r[-2] == 7
    assert r[-3] == 5
    assert r[-4] == 3
    assert r[-5] == 1
    assert r[::2][0] == 1
    assert r[::2][1] == 5
    assert r[::2][2] == 9
    assert r[::-2][0] == 9
    assert r[::-2][1] == 5
    assert r[::-2][2] == 1
    assert r[::3][0] == 1

# Generated at 2022-06-21 12:15:07.299246
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    from unittest import TestCase
    from itertools import tee, islice

    def func(x):
        return 2 * x

    class Test(TestCase):
        def test_normal(self):
            a = [1, 2, 3]
            expected = [2, 4, 6]
            a_, expected_ = tee(a)
            result = MapList(func, a_)

            self.assertEqual(list(result), expected)
            self.assertEqual(list(result), list(expected_))

            result_ = tee(result, 1)[0]
            self.assertEqual(list(result_), expected)

        def test_slicing(self):
            a = [1, 2, 3]
            expected = [4, 6]

            a_, expected_ = tee(a)


# Generated at 2022-06-21 12:15:09.625081
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(1000))
    assert len(lst) == 1000



# Generated at 2022-06-21 12:15:18.472565
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3])
    it = iter(lst)
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    try:
        next(it)
        assert False
    except StopIteration:
        pass
    assert lst[0] == 1
    assert list(lst) == [1, 2, 3]
    assert list(iter(lst)) == [1, 2, 3]
    assert lst[1:] == [2, 3]
    assert len(lst) == 3


# Generated at 2022-06-21 12:15:27.584663
# Unit test for constructor of class MapList
def test_MapList():
    l = MapList(lambda i: i * i, [1, 2, 3, 4, 5])
    assert len(l) == 5
    assert l[0] == 1
    assert l[1] == 4
    assert l[2] == 9
    assert l[0] == 1
    assert l[1] == 4
    assert l[2] == 9
    assert l[-1] == 25
    assert l[4] == 25
    assert l[1:3] == [4, 9]
    assert l[3:5] == [16, 25]
    assert [i for i in l] == [1, 4, 9, 16, 25]
    assert [i for i in l] == [1, 4, 9, 16, 25]
    assert list(l) == [1, 4, 9, 16, 25]

# Generated at 2022-06-21 12:15:33.230219
# Unit test for function take
def test_take():
    assert list(take(10, range(1000))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(take(0, range(1000))) == []
    assert list(take(-1, range(1000))) == []
    assert list(take(1000, range(1000))) == list(range(1000))



# Generated at 2022-06-21 12:15:38.922820
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    from collections import Iterable
    from collections import Iterator

    r = Range(1, 5)
    i = r.__iter__()
    assert isinstance(i, Iterator)
    assert iter(i) is i
    assert list(r) == [1, 2, 3, 4]



# Generated at 2022-06-21 12:15:41.860091
# Unit test for method __len__ of class Range
def test_Range___len__():
    lst = [1, 2, 3, 4]
    r = Range(lst[0], lst[-1] + 1)
    print(len(r))
    return 0

# Generated at 2022-06-21 12:15:53.972124
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    LazyList([1,2,3,4]).__len__() == 4
    raises(TypeError, lambda: LazyList([1,2,3,4,5]).__len__())

    # Tests that method __len__ behaves like len when it is available
    a = LazyList([1,2,3,4])
    a.__len__() == 4
    a._fetch_until(None)
    a.__len__() == 4
test_LazyList___len__()

    # Tests that method __len__ raises TypeError for a depleted stream

# Generated at 2022-06-21 12:15:59.172676
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:16:28.914601
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-21 12:16:33.200261
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:16:35.393417
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    try:
        Range(1,10).__iter__()
    except StopIteration:
        return "Success"
    else:
        return "Failure"
  

# Generated at 2022-06-21 12:16:41.898119
# Unit test for constructor of class LazyList
def test_LazyList():
    from .test_util import Random

    it = Random(0).randint(0, 10, size=10)
    it_reduce = iter(it)
    ll = LazyList(it_reduce)
    assert next(it_reduce) == next(ll)
    assert ll[0] == it[0]
    assert ll[1] == it[1]
    assert ll[2] == it[2]
    assert ll[-1] == it[-1]
    assert next(it_reduce) == next(ll)
    assert ll[1:5] == it[1:5]



# Generated at 2022-06-21 12:16:51.969536
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x * x, lst) == [1, 4, 9, 16, 25]
    lst = [1, 2, 3, 4, 5]
    assert [x for x in MapList(lambda x: x * x, lst)] == [1, 4, 9, 16, 25]
    lst = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x * x, lst)[2] == 9
    lst = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x * x, lst)[:3] == [1, 4, 9]
    lst = [1, 2, 3, 4, 5]

# Generated at 2022-06-21 12:16:55.557452
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for start in [-1, 0, 1]:
        for stop in range(start, 3):
            for step in [1, 2]:
                r = Range(start, stop, step)
                for idx, expected in zip(range(len(r)), r):
                    assert r[idx] == expected

