

# Generated at 2022-06-21 12:07:16.004065
# Unit test for function scanl
def test_scanl():
    # See http://www.haskell.org/haskellwiki/Scan_for_details
    assert list(scanl(operator.add, [])) == []
    assert list(scanl(lambda s, x: x + s, ['a'])) == ['a']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [], 0)) == [0]
    assert list(scanl(operator.add, [1, 2, 3], 0)) == [0, 1, 3, 6]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]

# Generated at 2022-06-21 12:07:23.407522
# Unit test for constructor of class Range
def test_Range():
    assert Range(0, 0, 1) == []
    assert Range(0, 1, 1) == [0]
    assert Range(0, 4, 1) == [0, 1, 2, 3]
    assert Range(0, 4, 2) == [0, 2]
    assert Range(1, 5, 2) == [1, 3]
    assert Range(5, 1, -1) == [5, 4, 3, 2]
    assert Range(5, 1, -2) == [5, 3]
    assert Range(1, 5, -2) == []
    assert Range(0, 0, -1) == []
    assert Range(0, 1, -1) == []
    assert Range(0, 4, -1) == []


# Generated at 2022-06-21 12:07:35.098859
# Unit test for constructor of class Range
def test_Range():
    # no input
    with pytest.raises(ValueError):
        Range()
    # one input
    test = Range(1)
    assert test.l == 0
    assert test.r == 1
    assert test.step == 1
    assert test.val == 0
    assert test.length == 1
    # two input
    test = Range(2, 5)
    assert test.l == 2
    assert test.r == 5
    assert test.step == 1
    assert test.val == 2
    assert test.length == 3
    # three input
    test = Range(1, 7, 2)
    assert test.l == 1
    assert test.r == 7
    assert test.step == 2
    assert test.val == 1
    assert test.length == 3


# Generated at 2022-06-21 12:07:37.892196
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0,1,2,3,4]
test_take()



# Generated at 2022-06-21 12:07:46.074251
# Unit test for function scanl
def test_scanl():
    from operator import add, mul
    
    def sum_of_digit(s, c):
        return int(c) + s
        
    assert list(scanl(add, range(10), 0)) == [0, 1, 3, 6, 10, 15, 21, 28, 36, 45]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(sum_of_digit, ['1', '2', '3', '4'], 0)) == [0, 1, 3, 6, 10]



# Generated at 2022-06-21 12:07:56.470729
# Unit test for function split_by
def test_split_by():
    # TODO: add more tests
    assert list(split_by("", criterion=lambda x: x == "#")) == [[""]]
    assert list(split_by("", criterion=lambda x: x == "#", empty_segments=True)) == [[""], [""]]
    assert list(split_by("test", criterion=lambda x: x == "#")) == [list("test")]
    assert list(split_by("test", criterion=lambda x: x == "#", empty_segments=True)) == [[""], list("test"), [""]]
    assert list(split_by(" Split by: ", criterion=lambda x: x == " ")) == [[], list("Split"), [], list("by:"), []]

# Generated at 2022-06-21 12:07:59.901935
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    a = MapList(lambda i: i, [1, 2, 3, 4, 5])
    assert len(a) == 5


# Generated at 2022-06-21 12:08:08.074941
# Unit test for constructor of class MapList
def test_MapList():
    m=MapList(lambda x:x*2,[1,2,3,4])
    n=iter(m)
    assert m[0]==2
    assert m[1]==4
    assert (next(n)==2)
    assert (next(n)==4)
    assert len(m)==4
    assert m[2]==6
    assert m[-1]==8
    assert m[-4]==2
    assert next(n)==6
    assert next(n)==8
    assert m[1:]==[4, 6, 8]
    with pytest.raises(IndexError):
        m[4]
    with pytest.raises(IndexError):
        m[-5]

# Generated at 2022-06-21 12:08:09.325936
# Unit test for method __len__ of class Range
def test_Range___len__():
    pass


# Generated at 2022-06-21 12:08:14.106938
# Unit test for constructor of class MapList
def test_MapList():
    L = MapList(lambda x: x * x, [1, 2, 3, 4])
    assert L[0] == 1
    assert L[1] == 4
    assert L[-1] == 16
    assert L[2] == 9
    assert L[:2] == [1, 4]
    assert L[::2] == [1, 9]


# Generated at 2022-06-21 12:08:29.059280
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import itertools
    for start in range(-3, 4):
        for stop in range(-3, 4):
            for step in range(-3, 4):
                for idx in itertools.chain([slice(None)], range(start, stop, step), [slice(start, stop, step)]):
                    assert Range(start, stop, step)[idx] == range(start, stop, step)[idx]

# Generated at 2022-06-21 12:08:32.889733
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(1, 10 + 1)
    assert len(r) == 10
    assert list(r) == [1 + i for i in range(10)]
    r = Range(1, 11, 2)
    assert len(r) == 5
    assert list(r) == [1 + 2 * i for i in range(5)]

# Generated at 2022-06-21 12:08:40.103382
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3])
    assert list(lst) == [1, 2, 3]
    assert list(lst) == [1, 2, 3]  # even for multiple iterators
    assert list(iter(lst)) == [1, 2, 3]

    lst = LazyList(range(3))
    assert list(lst) == [0, 1, 2]
    assert list(lst) == [0, 1, 2]  # even for multiple iterators
    assert list(iter(lst)) == [0, 1, 2]

# Generated at 2022-06-21 12:08:41.945768
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(1_000_000))) == 1_000_000



# Generated at 2022-06-21 12:08:46.565640
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: x * x, [1, 2, 3])) == [1, 4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3])[:2] == [1, 4]
    assert len(MapList(lambda x: x * x, [1, 2, 3])) == 3



# Generated at 2022-06-21 12:08:47.046461
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    return



# Generated at 2022-06-21 12:08:53.688393
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    ls = LazyList(range(1000))
    for i in range(4):
        assert 0 == len(ls[i])
    assert 0 == len(ls[0:0])
    assert 1 == len(ls[0:1])
    assert 2 == len(ls[0:2])
    assert 3 == len(ls[0:3])
    assert 4 == len(ls[0:4])
    assert 1000 == len(ls)



# Generated at 2022-06-21 12:09:05.500333
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(0)) == []
    assert list(Range(2)) == [0, 1]
    assert list(Range(0, 2)) == [0, 1]
    assert list(Range(0, 3, 2)) == [0, 2]
    assert list(Range(0, 4, 2)) == [0, 2]
    assert list(Range(1, 4, 2)) == [1, 3]
    assert list(Range(2, 3, 2)) == [2]
    assert list(Range(1, 0, 2)) == []
    assert list(Range(1, 0, -2)) == [1]
    assert list(Range(3, 0, -2)) == [3, 1]
    assert list(Range(3, 1, -2)) == [3]


# Generated at 2022-06-21 12:09:07.492583
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]


# Generated at 2022-06-21 12:09:13.772558
# Unit test for constructor of class LazyList
def test_LazyList():
    import random

    for _ in range (100):
        lst = range(random.randint(100, 1000))
        lst2 = LazyList(lst)
        assert lst == lst2, "the original list and the lazy list are not equal"
    print("test passed")

if __name__ == "__main__":
    test_LazyList()



# Generated at 2022-06-21 12:09:29.496337
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert Range(1,10).__next__() == 1
    assert next(Range(1,10)) == 1
    assert Range(1,10).__next__() == 2
    assert next(Range(1,10)) == 3
    assert Range(1,10).__next__() == 4
    assert next(Range(1,10)) == 5
    assert Range(1,10).__next__() == 6
    assert next(Range(1,10)) == 7
    assert Range(1,10).__next__() == 8
    assert next(Range(1,10)) == 9
    assert Range(1,10).__next__() == 10
    # assert next(Range(1,10)) == 1

# Generated at 2022-06-21 12:09:33.717170
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    if hasattr(Range, '__iter__'):
        obj = Range(1, 10 + 1)
        assert [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] == list(obj)



# Generated at 2022-06-21 12:09:37.677019
# Unit test for method __next__ of class Range
def test_Range___next__():
    from unittest import TestCase
    import random
    TestCase().assertEqual(Range(10**7).__next__(), 0)
    TestCase().assertEqual(Range(10**7).__next__(), 1)
    TestCase().assertTrue(0 <= Range(10**7).__next__() <= 0)
    TestCase().assertTrue(0 <= Range(10**7).__next__() <= 1)

# Generated at 2022-06-21 12:09:43.811446
# Unit test for constructor of class LazyList
def test_LazyList():
    assert iter(LazyList([1,2,3,4])).__next__() == 1
    LazyList([1,2,3,4]).__iter__().__next__() == 1
    assert LazyList([1,2,3,4])[1] == 2
    assert LazyList([1,2,3,4])[:2] == [1,2]
    assert len(LazyList([1,2,3,4])) == 4


# Generated at 2022-06-21 12:09:49.740848
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1, 2])) == 2
    assert len(LazyList(iter([]))) == 0
    assert len(LazyList(range(100))) == 100
    assert len(LazyList(range(100))) == 100
    with pytest.raises(TypeError):
        len(LazyList(range(100000)))



# Generated at 2022-06-21 12:09:55.288285
# Unit test for function take
def test_take():
    assert (list(take(3, range(100))) == list(range(3)))
    assert (list(take(0, range(100))) == [])
    assert (list(take(100, range(100))) == list(range(100)))
    assert (list(take(100, range(10))) == list(range(10)))
# Test
test_take()



# Generated at 2022-06-21 12:10:01.397537
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(2, 3)) == 1
    assert len(Range(2, 2)) == 0
    assert len(Range(2, 3, 2)) == 1
    assert len(Range(3, 2, -2)) == 1
    with pytest.raises(TypeError):
        len(Range(2, 3, 0))



# Generated at 2022-06-21 12:10:13.887692
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x % 3 == 0, range(10))) == []

    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: False, [])) == []

    assert list(drop_until(lambda x: x % 2 == 0, range(10))) == [0]

# Generated at 2022-06-21 12:10:21.953309
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10,20)
    r1 = r[0]
    assert(r1==10)
    r2 = r[1]
    assert(r2==11)
    r3 = r[-1]
    assert(r3==19)
    l = r[1:3]
    assert(l==[11,12])
    l = r[1:-1]
    assert(l==[11,12,13,14,15,16,17,18])



# Generated at 2022-06-21 12:10:29.425809
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(10)
    r2 = Range(1, 10 + 1)
    r3 = Range(1, 11, 2)
    assert(r1[0] == 0)
    assert(r1[2] == 2)
    assert(r1[4] == 4)
    assert(r2[0] == 1)
    assert(r2[2] == 3)
    assert(r2[4] == 5)
    assert(r3[0] == 1)
    assert(r3[2] == 5)
    assert(r3[4] == 9)


# Generated at 2022-06-21 12:10:49.026783
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    mpl = MapList(lambda x: x * x, lst)
    assert len(mpl) == 5
    assert mpl[0] == 1
    assert mpl[1] == 4
    assert mpl[2] == 9
    assert mpl[3] == 16
    assert mpl[4] == 25
    assert [x for x in mpl] == [x * x for x in lst]
    assert [x for x in mpl[::2]] == [x * x for x in lst[::2]]

# Generated at 2022-06-21 12:10:50.871509
# Unit test for method __len__ of class Range
def test_Range___len__():  # lgtm [py/similar-function]
    assert _ <Range(10)>_.length == 10

# Generated at 2022-06-21 12:10:55.138221
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    x = LazyList(range(10))
    try:
        len(x)
        assert False, "__len__ should not be called"
    except TypeError:
        pass
    if len(list(x)) == 10:
        assert True
    else:
        assert False, "the sequence should have 10 elements"

# Generated at 2022-06-21 12:10:56.859346
# Unit test for constructor of class MapList
def test_MapList():
    with pytest.raises(ValueError):
        MapList(lambda x: x * 2, [1, 2])


# Generated at 2022-06-21 12:11:04.250402
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3]
    m = MapList(lambda x: x*2, a)
    assert(m[0] == 2)
    assert(m[1] == 4)
    assert(m[2] == 6)
    assert(m[:2] == [2,4])
    assert(m[1:] == [4,6])
    assert(m[:2:2] == [2])
    assert(m[1::2] == [4])


# Generated at 2022-06-21 12:11:14.649734
# Unit test for method __len__ of class Range
def test_Range___len__():
# Test 1
    try:
        import builtins, operator,gfapy.environment
        builtins.len = gfapy.environment.__dict__["len"]
        builtins.range = gfapy.environment.__dict__["range"]
        r = Range(10)
        builtins.len = gfapy.environment.__dict__["len"]
        builtins.range = gfapy.environment.__dict__["range"]
        if(len(r) == 10):
            print(str(len(r)) + " = 10")
        else:
            print(str(len(r)) + " != 10")
    except Exception as e:
        print("Unable to execute test_Range___len__:"+str(e))
# Test 2

# Generated at 2022-06-21 12:11:20.546692
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    actual = iter(LazyList([1,2, 3]))
    expected = iter([1,2, 3])
    try:
        assert actual.__next__() == expected.__next__()
        assert actual.__next__() == expected.__next__()
        assert actual.__next__() == expected.__next__()
    except StopIteration:
        return
    raise AssertionError('should have stopped')

# Generated at 2022-06-21 12:11:30.703765
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: str(x), [1,2,3,4,5])[1] == '2'
    assert MapList(lambda x: str(x), [1,2,3,4,5])[4] == '5'
    assert MapList(lambda x: str(x), [1,2,3,4,5])[:] == ['1','2','3','4','5']
    assert MapList(lambda x: str(x), [1,2,3,4,5])[1:3] == ['2','3']
    assert MapList(lambda x: str(x), [1,2,3,4,5])[1:3:2] == ['2']

# Generated at 2022-06-21 12:11:39.254825
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x <= 5, [1,2,3,4,5,6,7,1,2,3,4,5])) == [6,7,1,2,3,4,5]
    assert list(drop_until(lambda x: x <= 5, [1,2,3,4,5,5,5,5,5,5,5,5])) == [5,5,5,5,5,5,5]
    assert list(drop_until(lambda x: x <= 5, [5,5,5,5,5,5,5,5])) == [5,5,5,5,5,5,5]
    assert list(drop_until(lambda x: x <= 5, [1,2,3,4,5,6,7,8]))

# Generated at 2022-06-21 12:11:43.833386
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    data = [1, 2, 3]
    for item in range(2*len(data)):
        idx = item if item < len(data) else item - len(data)
        assert data[idx] == Range(len(data))[item]
    assert data == Range(len(data))[1:3]
    assert data == Range(len(data))[-2:-3:-1]
    assert data[::-1] == Range(len(data))[-1:0:-1]

# Generated at 2022-06-21 12:12:09.106013
# Unit test for method __next__ of class Range
def test_Range___next__():
    a = Range(10)
    assert a.__next__() == 0
    assert a.__next__() == 1
    assert a.__next__() == 2
    assert a.__next__() == 3
    assert a.__next__() == 4
    assert a.__next__() == 5
    assert a.__next__() == 6
    assert a.__next__() == 7
    assert a.__next__() == 8
    assert a.__next__() == 9
    assert_raises(StopIteration, lambda: a.__next__())
    a = Range(1, 10 + 1)
    assert a.__next__() == 1
    assert a.__next__() == 2
    assert a.__next__() == 3
    assert a.__next__() == 4
    assert a.__next

# Generated at 2022-06-21 12:12:16.993451
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
 for _ in range(10):
     try:
         m = MapList(lambda x:x*x,range(-5,5))
         assert m[0]==m(0)
         assert m[3]==m(3)
         assert m[-3]==m(-3)
         assert m[-1]==m(-1)
         assert m[10]==None
         assert m[:2]==m[:2]
         assert m[:0]==m[:0]
         assert m[:-1]==m[:-1]
         assert m[:-10]==m[:-10]
     except:
         pass

# Generated at 2022-06-21 12:12:18.833858
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert tuple(MapList(lambda x: x * x, [1, 2, 3, 4])) == (1, 4, 9, 16)


# Generated at 2022-06-21 12:12:21.343596
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    lst = MapList(lambda i: a[i] * b[i], Range(len(a)))
    assert lst == MapList(lambda i: a[i] * b[i], Range(len(a)))



# Generated at 2022-06-21 12:12:31.501976
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(3)
    assert r.__next__() == 0
    assert r.__next__() == 1
    assert r.__next__() == 2
    try:
        r.__next__()
    except StopIteration:
        assert True
    else:
        assert False
    r = Range(2, 3)
    assert r.__next__() == 2
    try:
        r.__next__()
    except StopIteration:
        assert True
    else:
        assert False
    r = Range(0, 2, 0)
    try:
        r.__next__()
    except ValueError:
        assert True
    else:
        assert False
    r = Range(0, 2, 2)
    assert r.__next__() == 0
    assert r.__next__() == 2

# Generated at 2022-06-21 12:12:41.182283
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert (Range(1, 10 + 1)[0] == 1)
    assert (Range(1, 10 + 1)[2] == 3)
    assert (Range(1, 10 + 1)[4] == 5)
    assert (Range(1, 10 + 1, 2)[0] == 1)
    assert (Range(1, 10 + 1, 2)[2] == 5)
    assert (Range(1, 10 + 1, 2)[4] == 9)
    assert (Range(1, 11, 2)[0] == 1)
    assert (Range(1, 11, 2)[2] == 5)
    assert (Range(1, 11, 2)[4] == 9)
    assert (Range(10)[0] == 0)
    assert (Range(10)[2] == 2)
    assert (Range(10)[4] == 4)
   

# Generated at 2022-06-21 12:12:49.117181
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], '!')) == ['!', '!a', '!ab', '!abc', '!abcd']
    for i in range(1, 5):
        assert list(scanl(operator.add, [], i)) == [i]



# Generated at 2022-06-21 12:12:58.326345
# Unit test for constructor of class LazyList
def test_LazyList():
    llist = LazyList(range(10000))
    assert len(llist) == 10000
    assert llist[0] == 0
    assert llist[-1] == 9999
    assert len(llist[::3]) == 10000 // 3
    assert list(llist[2:8:2]) == [2, 4, 6]
    assert llist[3:7:3] == [3, 6]
    assert llist[9::9] == list(range(0, 10000, 9))
    assert llist[::-1] == list(reversed(range(10000)))
    assert llist[::-2] == list(range(9999, -1, -2))
    assert llist[::4] == list(range(0, 10000, 4))

# Generated at 2022-06-21 12:13:06.094233
# Unit test for function split_by
def test_split_by():
    # Create a list of lists
    a = [[0, 1, 0, 3], [0], [0, 1, 0, 1, 0], [0, 1, 0]]
    # Test for tuple criterion
    for i in range(len(a)):
        result = split_by(a[i], criterion=lambda x: x == 0)
        assert list(result) == [[1, 3], [], [1, 1], [1]], \
            'Test failed. Expected {}, got {}'.format([[1, 3], [], [1, 1], [1]], list(result))
        result = split_by(a[i], criterion=lambda x: x == 0, empty_segments=True)

# Generated at 2022-06-21 12:13:17.602993
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    from functools import partial
    from typing import Callable, Tuple
    from itertools import count

    from comb_spec_searcher.exceptions import StrategyDoesNotApply
    from comb_spec_searcher.strategies.comb import CombStrategy

    def nothing_to_add(args):
        return []

    def add_one_thing(args):
        yield [0]

    def add_two_things(args):
        yield [0, 1]

    def add_three_things(args):
        yield [0, 1, 2]

    args = [None, nothing_to_add, add_one_thing, add_two_things, add_three_things]
    test_infinite_iteration(MapList, CombStrategy, args, count())



# Generated at 2022-06-21 12:13:37.445297
# Unit test for function take
def test_take():
    for i in range(21):
        assert list(take(i, range(100))) == list(range(i))
    assert not list(take(0, range(1)))
    try:
        list(take(-10, range(20)))
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-21 12:13:41.793951
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                  ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:13:43.665550
# Unit test for method __len__ of class Range
def test_Range___len__():
    lst = Range(3)
    assert len(lst) == 3

# Generated at 2022-06-21 12:13:48.876556
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-21 12:13:51.722024
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(10))) == []
    assert list(take(-1, range(10))) == []



# Generated at 2022-06-21 12:13:55.875317
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(5, 10)) == 5
    assert len(Range(1, 10, 2)) == 5
    assert len(Range(10, 1, -2)) == 5

# Generated at 2022-06-21 12:14:01.985146
# Unit test for function scanr
def test_scanr():
    assert list(scanl(lambda x,y: x-y, [1,2,3,4])) == list(scanr(lambda x,y: y-x, [4,3,2,1]))
    assert list(scanl(operator.add, [1,2,3,4,5] )) == list(scanr(operator.add, [1,2,3,4,5] ))[::-1]



# Generated at 2022-06-21 12:14:03.900940
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x + 1, [1,2,3,4])[2] == 4


# Generated at 2022-06-21 12:14:12.962191
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) \
        == [[], [1, 2], [], [4, 5], [], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) \
        == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

# Generated at 2022-06-21 12:14:14.273391
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x == "B", ["A", "B", "C"])) == ["B", "C"]



# Generated at 2022-06-21 12:14:46.680782
# Unit test for function take
def test_take():
    assert list(take(0, [])) == []
    assert list(take(0, [1,2,3])) == []
    assert list(take(1, [1,2,3])) == [1]
    assert list(take(3, [1,2,3])) == [1,2,3]
    assert list(take(5, [1,2,3])) == [1,2,3]
test_take()


# Generated at 2022-06-21 12:14:49.797563
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x * 2, [1, 2, 3, 4])) == 4
    assert len(MapList(lambda x: x * 2, [])) == 0



# Generated at 2022-06-21 12:14:54.479698
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    seq = MapList(lambda x: x + 1, [2, 3, 4])
    l = len(seq)
    assert l == 3, "length error: expected 3, got %s" % str(l)
    assert l == len(seq), "length error: expected %s, got %s" % (str(l), str(len(seq)))
    return "__len__ test passed"


# Generated at 2022-06-21 12:14:59.871237
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(0, range(9))) == []


# Generated at 2022-06-21 12:15:01.041835
# Unit test for constructor of class LazyList
def test_LazyList():
    LazyList(range(10))



# Generated at 2022-06-21 12:15:13.305964
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from . import iterate_until, take_until
    from .functional import iterate

    # __getitem__ with positive indices
    assert take_until(lambda x: x > 0, LazyList(iterate(lambda x: x * x, 2)))[1] == 4
    # __getitem__ with negative indices
    assert take_until(lambda x: x > 0, LazyList(iterate(lambda x: x * x, 2)))[-1] == 65536

    # __getitem__ with slices
    assert LazyList([1, 2, 3, 4, 5, 6])[0:2] == [1, 2]
    assert take_until(lambda x: x > 0, LazyList(iterate(lambda x: x * x, 2)))[1:3] == [4, 16]

# Generated at 2022-06-21 12:15:22.302926
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(0))[:]) == 0
    assert len(LazyList(range(2))[:]) == 2
    assert len(LazyList(range(100))[:]) == 100
    assert len(LazyList(range(100))[:50]) == 50
    assert len(LazyList(range(100))[50:]) == 50
    assert len(LazyList(range(100))[50:51]) == 1
    assert len(LazyList(range(100))[50:57:7]) == 2
    assert len(LazyList(range(100))[50::7]) == 15
    assert len(LazyList(range(100))[50:75:7]) == 3
    assert len(LazyList(range(100))[50:73:7]) == 3
   

# Generated at 2022-06-21 12:15:25.487993
# Unit test for method __len__ of class Range
def test_Range___len__():
    r1 = Range(1, 10)
    r2 = Range(10)
    r3 = Range(1, 11, 3)
    assert len(r1) == 9
    assert len(r2) == 10
    assert len(r3) == 4



# Generated at 2022-06-21 12:15:28.908810
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x, [])) == 0
    assert len(MapList(lambda x: x, [1, 2, 3])) == 3

# Generated at 2022-06-21 12:15:41.030898
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(10)
    assert(r1.l == 0)
    assert(r1.r == 10)
    assert(r1.step == 1)
    assert(r1.length == 10)
    assert(r1[0] == 0)
    assert(r1[1] == 1)
    assert(r1[9] == 9)
    assert(r1[-1] == 9)
    assert(list(r1[3:8]) == list(range(3, 8)))
    r2 = Range(1, 10 + 1)
    assert(r2.l == 1)
    assert(r2.r == 10 + 1)
    assert(r2.step == 1)
    assert(r2.length == 10)
    assert(r2[0] == 1)

# Generated at 2022-06-21 12:16:25.176227
# Unit test for function scanl

# Generated at 2022-06-21 12:16:28.679971
# Unit test for function drop
def test_drop():
    assert list(take(5, drop(5, range(10)))) == [5, 6, 7, 8, 9]
    assert list(drop(100, range(10))) == []


# Generated at 2022-06-21 12:16:35.049334
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda x, y: y * x, range(10), 1)) == [3628800, 362880, 40320, 5040, 720, 120, 24, 6, 2, 1]



# Generated at 2022-06-21 12:16:43.211953
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5, 6, 7]
    m = MapList(lambda x: x * x, a)
    assert m[2] == 9
    assert m[0] == 1
    assert m[1] == 4
    assert m[3] == 16
    assert m[-1] == 49
    assert m[-2] == 36
    assert m[-3] == 25
    assert m[2:5] == [9, 16, 25]
    assert m[2:5:2] == [9, 25]
    assert m[::-1] == [49, 36, 25, 16, 9, 4, 1]
    assert list(m) == [1, 4, 9, 16, 25, 36, 49]
    assert len(m) == 7

# Generated at 2022-06-21 12:16:48.458956
# Unit test for method __len__ of class Range
def test_Range___len__():
    print("Test __len__ of class Range ...")
    assert len(Range(10)) == 10
    assert len(Range(0, 10, 2)) == 5
    assert len(Range(0, 11, 2)) == 6
    assert len(Range(-10, 10)) == 20
    assert len(Range(-10, 10, 2)) == 10
    print("PASSED")
