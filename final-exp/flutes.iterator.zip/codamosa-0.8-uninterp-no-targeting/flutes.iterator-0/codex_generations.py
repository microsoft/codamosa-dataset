

# Generated at 2022-06-21 12:07:33.301713
# Unit test for constructor of class LazyList
def test_LazyList():
    class TestIter:
        def __init__(self, array):
            self.array = array
            self.idx = -1
        def __iter__(self):
            return self
        def __next__(self):
            self.idx += 1
            if self.idx == len(self.array):
                raise StopIteration
            else:
                return self.array[self.idx]
    test_array = [i for i in range(10)]
    ll = LazyList(TestIter(test_array))
    for exp, act in zip(test_array, iter(ll)):
        assert(exp == act)
    for exp, act in zip(test_array, iter(ll)):
        assert(exp == act)
    assert(len(ll) == len(test_array))

# Generated at 2022-06-21 12:07:44.489214
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    assert len(MapList(lambda x: x * x, a)) == 5
    assert MapList(lambda x: x * x, a)[2] == 9
    assert MapList(lambda x: x * x, a)[2:] == [9, 16, 25]
    assert MapList(lambda x: x * x, a)[:2] == [1, 4]
    assert MapList(lambda x: x * x, a)[:2] == [1, 4]
    assert list(MapList(lambda x: x * x, a)) == [1, 4, 9, 16, 25]

    assert len(MapList(lambda i: a[i], Range(0, 5, 2))) == 3

# Generated at 2022-06-21 12:07:48.996151
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    map_list = MapList(lambda x: x*x, [1, 2, 3, 4, 5])
    ans = []
    for e in map_list:
        ans.append(e)
    assert ans == [1, 4, 9, 16, 25]


# Generated at 2022-06-21 12:08:00.593281
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from typing import List, Callable
    from copy import copy
    from random import randint
    from functools import reduce
    from operator import mul
    from bisect import bisect_left

    def gen_random_integer_list(m: int, n: int, lenth: int) -> List[int]:
        lst = []
        for i in range(lenth):
            lst.append(randint(m, n))
        return lst

    n = 100
    lst = gen_random_integer_list(0, 10000, n)
    lst_copy = copy(lst)
    mp = MapList(lambda x : x * x, lst)


# Generated at 2022-06-21 12:08:04.876350
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(10))) == []
    assert list(take(5, [])) == []
    assert list(take(-1, range(10))) == []
    assert list(take(-100, range(10))) == []


# Generated at 2022-06-21 12:08:11.647879
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    from unittest import TestCase
    from itertools import islice
    from cases import TestCaseWithoutRequiredTypes as TC
    class Test(TC):
        def __init__(self, *args):
            super().__init__(*args)
            self.list = [0, 1, 2]
        def runTest(self):
            assert len(MapList(lambda x: x + 1, self.list)) == 3
    return Test('__len__').run()


# Generated at 2022-06-21 12:08:19.673937
# Unit test for function scanr
def test_scanr():
    assert (list(scanr(operator.add, [], [])) == [])
    assert (list(scanr(operator.add, [], 0)) == [0])
    assert (list(scanr(operator.add, [1, 2, 3], 0)) == [6, 5, 3, 0])
    assert (list(scanr(operator.add, [1, 2, 3])) == [6, 5, 3])
    assert (list(scanr(lambda x, y: x // y, [1, 2, 3], 0)) == [0, 0, 1, 0])
    assert (list(scanr(lambda x, y: x // y, [1, 2, 3])) == [1, 0, 1])



# Generated at 2022-06-21 12:08:24.159778
# Unit test for constructor of class MapList
def test_MapList():
    assert isinstance(MapList(lambda x: x * x, [1, 2, 3, 4]), Sequence[int]) is True
    assert isinstance(MapList(lambda x: x * x, [1, 2, 3, 4]), Sequence[str]) is False

# Generated at 2022-06-21 12:08:29.367636
# Unit test for constructor of class MapList
def test_MapList():
    m = MapList(lambda x: x * x, range(3))
    assert m[0] == 0
    assert m[1] == 1
    assert m[2] == 4
    assert m[-1] == 4
    assert list(m) == [0, 1, 4]
    assert m[0:2] == [0, 1]
    assert m[-2:] == [1, 4]



# Generated at 2022-06-21 12:08:32.422941
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    with raises(TypeError):
        MapList(lambda x: x, [1, 2, 3])[0]


# Generated at 2022-06-21 12:08:49.850300
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    from random import randint
    from hypothesis import given
    from hypothesis_strategies import integers, lists

    for length in range(100):
        a = [randint(0, 10) for _ in range(length)]
        assert len(MapList(lambda x: x + 1, a)) == len(a)

    @given(integers(), lists(integers()))
    def test_len(l, lst):
        assert len(MapList(lambda x: x + l, lst)) == len(lst)

    test_len()

# Generated at 2022-06-21 12:08:51.928406
# Unit test for constructor of class LazyList
def test_LazyList():
    assert LazyList([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-21 12:08:53.903970
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)
    assert next(r) == 0
    assert next(r) == 1


# Generated at 2022-06-21 12:08:58.314318
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]



# Generated at 2022-06-21 12:09:10.916123
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    import pytest
    assert [i for i in Range(0, 10)] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert [i for i in Range(1, 10)] == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert [i for i in Range(3, 7)] == [3, 4, 5, 6]
    assert [i for i in Range(5, 7)] == [5, 6]
    assert [i for i in Range(8, 10)] == [8, 9]
    assert [i for i in Range(10, 10)] == []
    assert [i for i in Range(0, 10, 2)] == [0, 2, 4, 6, 8]

# Generated at 2022-06-21 12:09:15.016861
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(5)) == 5
    assert len(Range(1, 10, 2)) == 5
    assert len(Range(0, 10, 3)) == 4
    assert len(Range(1, 10, 3)) == 3


# Generated at 2022-06-21 12:09:19.423547
# Unit test for function scanr
def test_scanr():
    assert scanr(lambda a, b: a + b, [1, 2, 3]) == [6, 5, 3, 0]
    assert scanr(lambda acc, item: item.upper() + acc, ['a', 'b', 'c', 'd']) == ['ABCD', 'BCD', 'CD', 'D']



# Generated at 2022-06-21 12:09:21.261332
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(range(100))
    assert len(l) == 100


# Generated at 2022-06-21 12:09:31.315995
# Unit test for constructor of class MapList
def test_MapList():
    list1 = [1, 2, 4]
    list2 = MapList(lambda x: x * x, list1)
    index = lambda x: list1.index(x)
    assert list2.length == len(list1)
    assert list2[0] == 1
    assert list2[1] == 4
    assert list2[2] == 16
    assert [1, 4, 16] == list2[0:2]
    assert [4, 16] == list2[1:3]
    assert [1, 4, 16] == list2[index(1):index(4)]
    assert [4, 16] == list2[index(2):index(4)]



# Generated at 2022-06-21 12:09:33.664304
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]


# Generated at 2022-06-21 12:09:58.058727
# Unit test for function take
def test_take():
    # take(n, iterable) -> ...
    #
    # Take the first n elements from an iterable.
    #
    # >>> list(take(5, range(1000000)))
    # [0, 1, 2, 3, 4]
    #
    # :param n: The number of elements to take.
    # :param iterable: The iterable.
    # :return: An iterator returning the first n elements from the iterable.

    assert [0, 1, 2, 3, 4] == list(take(5, range(1000000)))
    assert [] == list(take(0, range(10)))
    assert [0, 1, 2, 3, 4] == list(take(5, range(5)))
    assert [0, 1, 2, 3, 4] == list(take(5, range(-5)))
   

# Generated at 2022-06-21 12:10:05.145981
# Unit test for constructor of class MapList
def test_MapList():
    l = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert l[0] == 1
    assert l[1] == 4
    assert l[2] == 9
    assert l[3] == 16
    assert l[4] == 25
    assert list(l) == [1, 4, 9, 16, 25]
    assert [l[1], l[2]] == [4, 9]
    assert l[0:2] == [1, 4]
    assert l[2:4] == [9, 16]


# Generated at 2022-06-21 12:10:09.733906
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3])
    it = iter(lst)
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    with pytest.raises(StopIteration):
        next(it)

# Generated at 2022-06-21 12:10:11.614263
# Unit test for function drop
def test_drop():
    assert next(drop(1, range(10))) == 1



# Generated at 2022-06-21 12:10:23.712352
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print("test_Range___getitem__ is running")
    assert Range(5)[0] == 0
    assert Range(5)[1] == 1
    assert Range(5)[4] == 4
    assert Range(5)[4] == 4
    assert Range(5)[-1] == 4
    assert Range(5)[-2] == 3
    assert Range(5)[-5] == 0
    assert Range(5)[-6] == -1
    assert Range(5)[-7] == -2
    assert Range(5)[-10] == -5
    assert Range(5)[-11] == -6
    assert Range(5)[0:2] == [0, 1]
    assert Range(5)[0:1:2] == [0]
    assert Range(5)[-1:10] == [4]
    assert Range

# Generated at 2022-06-21 12:10:33.511179
# Unit test for constructor of class Range
def test_Range():
    range_1=range(1, 10 + 1)
    range_2=Range(1, 10 + 1)
    for i in range(0, 10):
        assert range_1[i] == range_2[i]
    assert len(range_1)==len(range_2)
    range_1 = range(1, 11, 2)
    range_2 = Range(1, 11, 2)
    for i in range(0, 5):
        assert range_1[i] == range_2[i]
    assert len(range_1) == len(range_2)
    range_1 = range(10)
    range_2 = Range(10)
    for i in range(0, 10):
        assert range_1[i] == range_2[i]
    assert len(range_1) == len

# Generated at 2022-06-21 12:10:36.626758
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert isinstance(LazyList(range(0))[0], int)
    assert isinstance(LazyList(range(0))[:], list)

# Generated at 2022-06-21 12:10:48.021124
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x < 0, [])) == []
    assert list(drop_until(lambda x: x < 0, [1, 2, 3])) == []
    assert list(drop_until(lambda x: x < 0, [-1, 2, 3])) == [-1, 2, 3]
    assert list(drop_until(lambda x: x > 5, [-1, 2, 3, 4, 5, 6, 3])) == [6, 3]
    assert list(drop_until(lambda x: x == 5, [-1, 2, 3, 4, 5, 6, 3])) == [5, 6, 3]
    assert list(drop_until(lambda x: x == 5, [-1, 2, 3, 5, 4, 6, 3])) == [5, 4, 6, 3]
   

# Generated at 2022-06-21 12:10:54.976150
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    f = lambda x: x + 1
    m = MapList(f, lst)
    assert m[0] == f(lst[0])
    assert m[-1] == f(lst[-1])
    assert m[1:3] == [f(i) for i in lst[1:3]]
    assert m[:-1] == [f(i) for i in lst[:-1]]
    assert m[::2] == [f(i) for i in lst[::2]]
    assert list(m) == [f(i) for i in lst]
    assert len(m) == len(lst)



# Generated at 2022-06-21 12:10:57.286456
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    obj = LazyList([1, 2, 3])
    assert len(obj) == 3
    assert obj.list == [1, 2, 3]
    assert obj.exhausted



# Generated at 2022-06-21 12:11:07.856849
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(map(lambda x: x, range(10)))) == 10
    assert len(LazyList(chain(range(3), range(3)))) == 6
    try:
        len(LazyList(chain(range(3), range(3,10))))
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-21 12:11:12.356864
# Unit test for function scanr
def test_scanr():
    def factorial(x): return scanr(operator.mul, range(1, x + 1), x)

    assert factorial(5) == [120, 120, 60, 20, 5]
    assert factorial(1) == [1]
    assert factorial(0) == []



# Generated at 2022-06-21 12:11:15.279706
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = iter(LazyList(range(10)))
    assert next(it) == 0
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3

# Generated at 2022-06-21 12:11:16.977263
# Unit test for method __len__ of class Range
def test_Range___len__():
    obj = Range(1,5+1)
    assert obj.__len__() == 5

# Generated at 2022-06-21 12:11:23.145490
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, range(1, 6))) == [1, 3, 6, 10, 15]
    assert list(scanl(operator.add, range(1, 6), 10)) == [10, 11, 13, 16, 20, 25]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-21 12:11:32.853952
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2, 3, 2, 4], criterion=lambda x: x == 2)) == [[1], [3], [4]]
    assert list(split_by([1, 2, 3, 2, 4], criterion=lambda x: x == 2, empty_segments=True)) == [[1], [], [3], [], [4]]
    assert list(split_by(" Split by: ", separator=' ')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by(" Split by: ", separator=' ', empty_segments=True)) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

# Generated at 2022-06-21 12:11:34.684768
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    x: LazyList[int] = LazyList([2,3,4,5])
    assert len(x) == 4



# Generated at 2022-06-21 12:11:39.174662
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    def test_LazyList___len__once(size: int):
        lst = LazyList(range(size))
        assert len(lst[:]) == size
        assert len(lst) == size

    for size in (0, 1, 2, 10, 100, 1000):
        test_LazyList___len__once(size)


# Generated at 2022-06-21 12:11:43.493351
# Unit test for function drop
def test_drop():
    from collections import deque
    assert deque(drop(2, range(10))) == deque(range(2,10))
    assert deque(drop(0, range(10))) == deque(range(10))
    assert deque(drop(10, range(10))) == deque([])
    assert deque(drop(11, range(10))) == deque([])
    assert deque(drop(-1, range(10))) == deque(range(10))



# Generated at 2022-06-21 12:11:45.484136
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(Range(0, 5, 2)) == [0, 2, 4]

# Generated at 2022-06-21 12:11:56.561931
# Unit test for constructor of class MapList
def test_MapList():
    lst_1 = [1, 2, 3, 4, 5]
    lst_2 = [2, 3, 4, 5, 6]

    assert MapList(lambda i: lst_1[i] * lst_2[i], Range(len(lst_1))) == [2, 6, 12, 20, 30]

# Generated at 2022-06-21 12:12:04.747577
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList([1, 2, 3, 4, 5])
    assert len(a) == 5
    assert a[0] == 1
    assert a[2] == 3
    assert a[-1] == 5
    assert list(a) == [1, 2, 3, 4, 5]
    b = LazyList(a)
    assert b[2] == 3
    assert len(b) == 5
    with pytest.raises(TypeError):
        len(LazyList(range(3)))



# Generated at 2022-06-21 12:12:15.647328
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from unittest import TestCase, main

    class TestMapList(TestCase):
        def test_indexing(self):
            for _ in range(1000):
                lst = [randint(-100, 100) for _ in range(100)]
                lst2 = MapList(lambda x: x * x, lst)
                for _ in range(100):
                    i = randint(len(lst))
                    self.assertEqual(lst2[i], lst[i] * lst[i])
                    j = randint(i)
                    k = randint(i, len(lst))

# Generated at 2022-06-21 12:12:17.115164
# Unit test for function drop
def test_drop():
    assert list(drop(1, range(10))) == list(range(1, 10))

# Generated at 2022-06-21 12:12:22.354490
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    a = Range(1, 10 + 1)
    b = a.__iter__()
    assert next(b) == 1
    assert next(b) == 2
    assert next(b) == 3


# Generated at 2022-06-21 12:12:27.421925
# Unit test for function drop
def test_drop():
    assert next(drop(5, range(1000000))) == 5
    assert next(drop(0, range(10))) == 0
    assert next(drop(-1, range(-1, 10))) == -1
    try:
        next(drop(-1, range(0)))
        assert False
    except ValueError:
        pass


# Generated at 2022-06-21 12:12:35.495153
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-21 12:12:40.007532
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    with pytest.raises(TypeError):
        next(drop_until(lambda x: x > 5, (1, 2, 3)))
    assert list(drop_until(lambda x: True, range(10))) == list(range(10))



# Generated at 2022-06-21 12:12:48.885608
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(5))
    assert list(lst) == [0, 1, 2, 3, 4]
    assert list(lst) == [0, 1, 2, 3, 4]
    assert list(lst) == [0, 1, 2, 3, 4]
    assert list(lst) == [0, 1, 2, 3, 4]
    assert list(lst) == [0, 1, 2, 3, 4]
    lst = LazyList(range(5))
    assert list(lst) == [0, 1, 2, 3, 4]
    assert list(lst) == [0, 1, 2, 3, 4]
    assert list(lst) == [0, 1, 2, 3, 4]

# Generated at 2022-06-21 12:12:52.832137
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test=Range(1,10)
    assert test[0]==1
    assert test[4]==5
    assert test[3]==4
    assert test[10]==10
    assert test[-1]==9

# Generated at 2022-06-21 12:13:14.633932
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) == []
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(0))) == []



# Generated at 2022-06-21 12:13:17.676747
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    dummy_func = lambda *args, **kwargs: None
    dummy_lst = [None]
    obj = MapList(dummy_func, dummy_lst)
    res = obj.__len__()


# Generated at 2022-06-21 12:13:24.466124
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(1, range(10))) == list(range(1, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(0, range(0))) == []
    assert list(drop(1, range(0))) == []
    assert list(drop(10, range(0))) == []
    assert list(drop(3, '0123456789')) == ['3', '4', '5', '6', '7', '8', '9']

# Generated at 2022-06-21 12:13:35.697660
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import itertools
    import random
    def test(idx, items):
        ll = LazyList(items)
        expected = list(items)
        assert ll[idx] == expected[idx]

    random.seed(0)
    for items in [range(100), itertools.cycle(range(100))]:
        for i in range(100):
            idx = random.randint(-10, 10)
            test(idx, items)
        for i in range(100):
            idx = random.randint(90, 110)
            test(idx, items)
        for i in range(100):
            start = random.randint(-10, 10)
            stop = random.randint(90, 110)
            step = random.randint(1, 10)

# Generated at 2022-06-21 12:13:47.754266
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
  # Checking __len__ using assert statements

  # Iterables with length below _MAX_LEN
  def _test_length_1():
    for iterable in [[0],
                     [0, 1],
                     range(500)]:
      list1 = LazyList(iterable)
      assert len(list1) == len(iterable)
  _test_length_1()

  # Iterables with length above _MAX_LEN
  def _test_length_2():
    for iterable in range(500, 1000), range(500, 1000, 2), range(500, 1000, 3), range(_MAX_LEN + 1, _MAX_LEN + 500):
      list1 = LazyList(iterable)
      assert len(list1) == len(iterable)
  _test_length_2()



# Generated at 2022-06-21 12:13:49.628157
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert_equal(len(Range(10)), 10)
    assert_equal(len(Range(1, 10 + 1)), 10)
    assert_equal(len(Range(1, 11, 2)), 5)

# Generated at 2022-06-21 12:13:51.453002
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        len(LazyList([0, 1, 2]))
    except TypeError:
        pass

# Generated at 2022-06-21 12:13:57.407388
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    if True:
        range_instance1 = Range(10)
        range_instance2 = Range(1, 10 + 1)
        range_instance3 = Range(1, 11, 2)
        print(range_instance3[0], range_instance3[2], range_instance3[4])
    return None


# Generated at 2022-06-21 12:14:01.391717
# Unit test for constructor of class LazyList
def test_LazyList():
    x = LazyList(range(5))
    assert isinstance(x[0], int)
    assert isinstance(x[3], int)
    assert isinstance(x[4], int)
    try:
        x[5]
        assert False
    except IndexError:
        pass



# Generated at 2022-06-21 12:14:10.800607
# Unit test for function scanl
def test_scanl():
    # Test different number of arguments
    assert list(scanl(lambda x, y: x + y, [0, 1, 2])) == [0, 1, 3]
    assert list(scanl(lambda x, y: x + y, [0, 1, 2], 0)) == [0, 0, 1, 3]
    assert list(scanl(lambda x, y: x + y, [0, 1, 2], 0, 0)) == [0, 0, 0, 1, 3]
    with pytest.raises(ValueError):
        list(scanl(lambda x, y: x + y, [0, 1, 2, 3], 0, 0, 0))

    # Test that initial value is used as the first element

# Generated at 2022-06-21 12:14:36.368853
# Unit test for constructor of class LazyList
def test_LazyList():
    l = LazyList(range(10))
    assert isinstance(l, LazyList)
    assert isinstance(iter(l), LazyList.LazyListIterator)


# Generated at 2022-06-21 12:14:38.466655
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert list(LazyList(range(10))) == list(range(10))
    assert list(LazyList(range(10))) == list(range(10))



# Generated at 2022-06-21 12:14:49.936606
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by([], empty_segments=True, separator='.')) == [[]]
    assert list(split_by([], False, separator='.')) == []

# Generated at 2022-06-21 12:14:54.593658
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    with pytest.raises(TypeError):
        len(LazyList(range(5)))
    assert len(LazyList(range(5)).__iter__()) == 5
    assert len(LazyList(range(5)).__getitem__(slice(None))) == 5
    assert len(LazyList(range(5)).__getitem__(slice(None, None))) == 5



# Generated at 2022-06-21 12:15:03.132603
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, range(10), 0)) == [0] + list(range(1, 10))
    assert list(scanl(operator.mul, range(1, 6))) == [1, 2, 6, 24, 120]
    assert list(scanl(lambda x, y: y + x, 'abc', '')) == ['', 'a', 'ba', 'cba']
    assert list(scanl(operator.add, [])) == []
    assert list(scanl(operator.add, [1, 2, 3])) == [1, 3, 6]



# Generated at 2022-06-21 12:15:07.600993
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    import pytest
    from random import randint
    for x in range(100):
        length = randint(100, 1000)
        lst = list(range(length))
        assert len(MapList(lambda x: x, lst)) == length

# Generated at 2022-06-21 12:15:12.998077
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    print(r[0], r[2], r[4])

# Generated at 2022-06-21 12:15:17.643824
# Unit test for function drop
def test_drop():
    import collections
    import random
    a = list(range(100))
    random.shuffle(a)
    c = collections.Counter(drop(random.randint(0, 100), a))
    assert c == collections.Counter(a[c.most_common()[0][0] + 1:])



# Generated at 2022-06-21 12:15:24.642479
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3], 0)) == [0, 1, 3, 6]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c'], '')) == ['', 'a', 'ba', 'cba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c'])) == ['a', 'ba', 'cba']



# Generated at 2022-06-21 12:15:36.896530
# Unit test for constructor of class Range
def test_Range():
    # Range will be list from 0 to 9.
    test_list = Range(10)
    assert len(test_list) == 10
    assert test_list[4] == 4
    assert test_list[0] == 0
    assert test_list[9] == 9
    assert test_list[-1] == 9
    assert test_list[-10] == 0

    # Range will be list from 1 to 10.
    test_list = Range(1,11)
    assert len(test_list) == 10
    assert test_list[4] == 5
    assert test_list[0] == 1
    assert test_list[9] == 10
    assert test_list[-1] == 10
    assert test_list[-10] == 1

    # Range will be list from 1 to 11 with step = 2.
   

# Generated at 2022-06-21 12:15:57.204107
# Unit test for function scanr
def test_scanr():
    import itertools
    assert list(scanr(operator.add, [1, 2, 3])) == [6, 5, 3, 1]
    assert list(scanr(operator.add, [1, 2, 3], 0)) == [6, 5, 3, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'f')) == ['abcd', 'bcd', 'cd', 'd', 'f']
    assert list(scanr(lambda s, x: x + s, [])) == []

# Generated at 2022-06-21 12:16:08.319307
# Unit test for constructor of class LazyList
def test_LazyList():
    x = LazyList(range(5))
    assert x[0] == 0
    assert len(x) == 5
    assert x[-1] == 4
    assert x[1:3] == [1, 2]
    assert x[-3:-1] == [2, 3]
    assert list(i for i in x) == [0, 1, 2, 3, 4]
    assert x[0] == 0
    assert len(x) == 5
    assert x[-1] == 4
    assert x[1:3] == [1, 2]
    assert x[-3:-1] == [2, 3]
    assert list(i for i in x) == [0, 1, 2, 3, 4]


# Generated at 2022-06-21 12:16:19.144441
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import random
    for _ in range(10):
        for i in random.sample(range(-10, 10), k=10):
            for start in random.sample(range(-10, 10), k=2):
                for stop in random.sample(range(-10, 10), k=2):
                    if start == stop:
                        continue
                    start, stop = min(start, stop), max(start, stop)
                    for step in random.sample(range(-10, 10), k=1):
                        if step == 0:
                            continue
                        arr = list(range(start, stop, step))
                        if stop in arr:
                            arr.append(stop)
                        res = Range(start, stop, step)
                        exp = arr[i]
                        act = res[i]

# Generated at 2022-06-21 12:16:21.635420
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    l = [1, 2, 3]
    m = MapList(lambda v: v * 2, l)
    for i in m:
        assert i % 2 == 0

# Generated at 2022-06-21 12:16:24.173877
# Unit test for function drop
def test_drop():
    l = [1,2,3,4]
    m = drop(2,l)
    assert (next(m) == 3)
    assert (next(m) == 4)



# Generated at 2022-06-21 12:16:29.844154
# Unit test for function scanr
def test_scanr():
    from operator import add
    assert list(scanr(add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:16:33.898520
# Unit test for constructor of class MapList
def test_MapList():
    a = MapList(lambda x: x + 10, [1, 2, 4, 6, 7])
    assert a[0] == 11
    b = MapList(lambda x: x + 10, range(10))
    assert len(b) == 10
    assert b[0] == 10
    assert b[1] == 11


# Generated at 2022-06-21 12:16:35.946373
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert LazyList(range(10))[3] == 3
    assert LazyList(range(10))[0:7] == list(range(7))



# Generated at 2022-06-21 12:16:43.641043
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r1 = Range(10)
    r2 = Range(1, 10 + 1)
    r3 = Range(1, 11, 2)
    print(r1[0], r1[-1])
    print(r2[0], r2[-1])
    print(r3[0], r3[-1])
    print(r3[:5])
    print(r3[:5:2])
    print(r3[1:5])
    print(r3[1:5:2])
    print(r3[::-1])
    print(r3[1:5:-1])
    print(r3[0:5:-1])
    print(r3[5:1:-1])
    print(r3[5:1:-2])

# Generated at 2022-06-21 12:16:49.826720
# Unit test for function take
def test_take():
    assert list(take(0, [1, 2, 3, 4, 5])) == []
    assert list(take(1, [1, 2, 3, 4, 5])) == [1]
    assert list(take(5, [1, 2])) == [1, 2]
    assert list(take(4, iter([1, 2, 3]))) == [1, 2, 3]
    assert list(take(0, iter([]))) == []

