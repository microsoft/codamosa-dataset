

# Generated at 2022-06-21 12:07:20.683535
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    len(LazyList([]))
    len(LazyList([1,2,3]))
    try:
        len(LazyList(range(10)))
        raise AssertionError
    except TypeError:
        pass
    try:
        len(LazyList(range(10))[:2])
        raise AssertionError
    except TypeError:
        pass
    len(LazyList(range(10))[:2].list)
    len(LazyList(range(10))[:4])
    len(LazyList(range(10))[:4].list)
    len(LazyList(range(10))[:7])
    len(LazyList(range(10))[:7].list)
    len(LazyList(range(10))[:])

# Generated at 2022-06-21 12:07:32.980517
# Unit test for constructor of class Range
def test_Range():
    if Range(10)[0] != 0:
        print(Range(10)[0])
        assert False
    if Range(1, 10 + 1)[0] != 1:
        print(Range(1,10 + 1)[0])
        assert False
    if Range(1, 11, 2)[0] != 1:
        print(Range(1, 11, 2)[0])
        assert False
    if Range(2, 14, 3)[2] != 8:
        print(Range(2, 14, 3)[2])
        assert False
    if Range(1, 11, 2)[3] != 7:
        print(Range(1, 11, 2)[3])
        assert False
    if Range(1, 11, 2)[-1] != 9:
        print(Range(1, 11, 2)[-1])
        assert False
   

# Generated at 2022-06-21 12:07:35.316375
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    with pytest.raises(TypeError):
        LazyList([1, 2, 3])[3]

# Generated at 2022-06-21 12:07:41.879307
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(1, 10+1)
    print(r[0], r[2], r[4])
    print(r[1:6])
    print(r[-4:-1])
    print(r[-5:-3])
    print(len(r))
if __name__ == '__main__':
    test_Range___len__()  # unit test
    print('Test passed')
 

# Generated at 2022-06-21 12:07:49.654680
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(-1, range(10))) == []
    assert list(chunk(1, range(10))) == [[x] for x in range(10)]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]

# Generated at 2022-06-21 12:07:51.685068
# Unit test for method __next__ of class Range
def test_Range___next__():
    with pytest.raises(StopIteration):
        next(Range(0))
    assert next(Range(1)) == 0
    assert next(Range(2, 3)) == 2
    assert next(Range(2, 4, 2)) == 2



# Generated at 2022-06-21 12:07:59.577307
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3, 4])
    
    assert lst[0] == 1
    assert lst[1] == 2
    assert lst[2] == 3
    assert lst[3] == 4
    assert lst[-1] == 4
    assert lst[:2] == [1, 2]
    assert lst[1:3] == [2, 3]
    assert lst[::2] == [1, 3]
    


# Generated at 2022-06-21 12:08:03.724123
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():

    def gen():
        for i in range(5):
            yield i

    lst = LazyList(gen())
    assert list(lst) == [0, 1, 2, 3, 4]
    assert list(lst) == [0, 1, 2, 3, 4]



# Generated at 2022-06-21 12:08:05.964122
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x: x * x, range(10))
    assert(len(lst) == 10)


# Generated at 2022-06-21 12:08:16.546495
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert getattr(Range(1,2,3).__next__, '__name__') == '__next__'
    assert getattr(next, '__name__') == '__next__'
    assert getattr((), '__next__', None) is None
    assert getattr(Range, '__next__', None) is None
    assert getattr(list.__add__, '__next__', None) is None
    assert getattr(Range(1,2,3).__next__, '__call__') is getattr(Range(1,2,3).__next__, '__next__')
    assert getattr(next, '__call__') is getattr(next, '__next__')
    assert getattr((), '__call__', None) is None

# Generated at 2022-06-21 12:08:40.265697
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for idx in Range(10):
        print(idx)

# Generated at 2022-06-21 12:08:47.937405
# Unit test for function drop
def test_drop():
    iterator = itertools.islice(itertools.count(), 2, 5)
    lazy_iterator = itertools.islice(drop(2, itertools.count()), 0, 3)
    assert list(iterator) == list(lazy_iterator), "test_drop_1 failed"
    iterator = itertools.islice(itertools.count(), 0, 0)
    lazy_iterator = itertools.islice(drop(2, itertools.count()), 0, 0)
    assert list(iterator) == list(lazy_iterator), "test_drop_2 failed"
    iterator = itertools.islice(itertools.count(), 0, 2)
    lazy_iterator = itertools.islice(drop(2, itertools.count()), 0, 2)
    assert list(iterator)

# Generated at 2022-06-21 12:08:51.205838
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 2)
    assert next(r) == 1
    with pytest.raises(StopIteration):
        next(r)



# Generated at 2022-06-21 12:08:58.096321
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect

    # Find index of the first element in `a` whose square is >= 10.
    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert 3 == pos

    # Find the first index `i` such that `a[i] * b[i]` is >= 10.
    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert 2 == pos



# Generated at 2022-06-21 12:09:01.651378
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # TODO: Implement test
    pass

    # Method __len__ of class LazyList calls private method _fetch_until
    # with given parameters (idx: Optional[int])

# Generated at 2022-06-21 12:09:07.704807
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(0, 10)
    assert r[1::2] == [1, 3, 5, 7, 9]
    assert r[-1] == 9
    assert r[slice(-1, None)] == [9]
    assert r[-10] == 0

if __name__ == "__main__":
    test_Range___getitem__()



# Generated at 2022-06-21 12:09:11.063464
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-21 12:09:11.916349
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(succ, range(5))) == len(range(5))

# Generated at 2022-06-21 12:09:15.006077
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    # Create an instance of the class
    obj = MapList(lambda x: x, [])

    # Get the length
    cls = MapList
    method = cls.__len__
    res = method(obj)

    # Assert the result
    assert res == 0


# Generated at 2022-06-21 12:09:23.016286
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Method 1: __getitem__(self, idx: int) -> T
    # Type: positive test cases
    assert isinstance(LazyList([1, 2, 3, 4])[0], int)
    assert LazyList([1, 2, 3, 4])[0] == 1
    assert LazyList([1, 2, 3, 4])[1] == 2
    assert LazyList([1, 2, 3, 4])[2] == 3
    assert LazyList([1, 2, 3, 4])[3] == 4
    # Type: negative test cases
    expect = None
    try:
        LazyList([1, 2, 3, 4])[4]
    except IndexError:
        expect = 'IndexError'
    assert expect == 'IndexError'

    # Method 1: __getitem__(self

# Generated at 2022-06-21 12:09:36.079394
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    oracle_fn = lambda x: list(range(*x))
    for args in itertools.product(*[[0, 1, 2, 3], range(4), [1, 2]]):
        try:
            r_range = Range(*args)
        except ValueError:
            continue
        assert oracle_fn(args) == list(r_range)

# Generated at 2022-06-21 12:09:41.030123
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:09:42.968893
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    x1 = []
    x2 = MapList(lambda x: x * x, x1)
    x3 = len(x2)


# Generated at 2022-06-21 12:09:54.752440
# Unit test for function take
def test_take():
    # basic usage
    assert list(take(0, range(10))) == []
    assert list(take(1, range(10))) == [0]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(20, range(10))) == list(range(10))

    # empty iterable
    assert list(take(0, [])) == []
    assert list(take(1, [])) == []
    assert list(take(10, [])) == []

    # negative n
    with pytest.raises(ValueError, match="should be non-negative"):
        list(take(-1, range(10)))

    # non-iterable

# Generated at 2022-06-21 12:09:56.233112
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    for obj in MapList(lambda x: x * x, [1, 2, 3, 4]):
        pass

# Generated at 2022-06-21 12:10:00.749310
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: -x, [-1, -2, -3])
    assert lst[0] == 1
    assert lst[2] == 3
    assert lst[-1] == 3
    assert lst[1:3] == [2, 3]

# Generated at 2022-06-21 12:10:07.168068
# Unit test for constructor of class Range
def test_Range():
    # test empty
    with pytest.raises(ValueError):
        Range()

    # test 1 parameter
    assert list(Range(0)) == []
    assert list(Range(1)) == [0]

    # test 2 parameters
    assert list(Range(0, 1)) == [0]
    assert list(Range(0, 2)) == [0, 1]

    # test 3 parameters
    assert list(Range(0, 1, 1)) == [0]
    assert list(Range(0, 2, 1)) == [0, 1]
    assert list(Range(0, 7, 3)) == [0, 3, 6]



# Generated at 2022-06-21 12:10:10.601355
# Unit test for function drop_until
def test_drop_until():
    xs = range(10)
    assert list(drop_until(lambda x: x > 5, xs)) == list(drop(6, xs))



# Generated at 2022-06-21 12:10:17.031716
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3, 4])
    assert lst[2] == 3
    lst = LazyList(range(10000000))
    # If __getitem__ is not lazy, this will run for a very long time:
    assert lst[2] == 3
    # If __getitem__ is not implemented properly, this will throw TypeError:
    assert len(lst) == 10000000

# Generated at 2022-06-21 12:10:19.672879
# Unit test for constructor of class LazyList
def test_LazyList():
    List1 = LazyList('lazy list')
    assert(list(List1) == ['l', 'a', 'z', 'y', ' ', 'l', 'i', 's', 't'])



# Generated at 2022-06-21 12:10:30.849056
# Unit test for function take
def test_take():
    assert list(take(10, range(20))) == list(range(10))



# Generated at 2022-06-21 12:10:34.289151
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10000))
    assert lst[3] == 3
    assert lst[9] == 9
    assert lst[10:15] == [10, 11, 12, 13, 14]
    assert lst[9] == 9



# Generated at 2022-06-21 12:10:41.070741
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:10:44.499256
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert (list(MapList(lambda x:x*x, [1, 2, 2, 3, 4])) == [1, 4, 4, 9, 16])

# Generated at 2022-06-21 12:10:46.855529
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    it = MapList(lambda x: x * x, lst)
    assert it[0] == 1
    assert it[2] == 9
    assert it[4] == 25

    assert it[0:5] == [1, 4, 9, 16, 25]
    assert it[3:] == [16, 25]


# noinspection PyPep8Naming

# Generated at 2022-06-21 12:10:56.582186
# Unit test for function scanl
def test_scanl():
    def list_scanl(func, iterable, *args):
        return list(scanl(func, iterable, *args))
    assert list_scanl(operator.add, [1, 2, 3, 4], 0) == [0, 1, 3, 6, 10]
    assert list_scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['a', 'ba', 'cba', 'dcba']
    assert list_scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'x') == ['x', 'xa', 'xab', 'xabc']

# Generated at 2022-06-21 12:11:04.250205
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    def check(func, obj):
        res = []
        for x in obj:
            res.append(x)
        assert res == [func(x) for x in obj.list]

    check(lambda x: x + 1, MapList(lambda x: x + 1, [1, 2, 3]))
    check(lambda x: x + 1, MapList(lambda x: x + 1, (1, 2, 3)))
    check(lambda x: x + 1, MapList(lambda x: x + 1, []))

# Generated at 2022-06-21 12:11:05.550904
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(1, 5)) == 4


# Generated at 2022-06-21 12:11:07.661237
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x*x, [1, 2, 3])) == 3

    # Test exceptions
    try:
        MapList(lambda x: x*x, [])(1)
        assert False
    except IndexError:
        pass



# Generated at 2022-06-21 12:11:08.851503
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    pass



# Generated at 2022-06-21 12:11:26.084138
# Unit test for method __next__ of class Range
def test_Range___next__():
    from itertools import chain
    # test constructor of class Range
    r = Range(10)
    assert r.step == 1 and r.l == 0 and r.r == 10 and r.val == 0, 'r = Range(10) should have step = 1, l = 0, r = 10, val = 0' 
    
    r = Range(1, 10+1)
    assert r.step == 1 and r.l == 1 and r.r == 10+1 and r.val == 1, 'r = Range(1, 10+1) should have step = 1, l = 1, r = 10+1, val = 1' 
    
    r = Range(1, 11, 2)

# Generated at 2022-06-21 12:11:28.495693
# Unit test for constructor of class LazyList
def test_LazyList():
    l1 = LazyList([1, 2, 3])
    l2 = LazyList((x for x in [1, 2, 3]))


# Generated at 2022-06-21 12:11:30.386245
# Unit test for constructor of class LazyList
def test_LazyList():
    t1 = list(range(10))
    t2 = LazyList(range(10))
    assert t1 == t2
    assert t1[5] == t2[5]
    assert t1[5:7] == t2[5:7]
    assert t1[7:] == t2[7:]


# Generated at 2022-06-21 12:11:41.982780
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    # __iter__ with 3 args
    range_it_1 = Range(1, 11, 2).__iter__()
    check_1 = True
    for i in range(6):
        check_1 = check_1 and range_it_1.__next__() == 1 + 2 * i
    assert check_1
    # __iter__ with 2 args
    range_it_2 = Range(1, 11).__iter__()
    check_2 = True
    for i in range(10):
        check_2 = check_2 and range_it_2.__next__() == 1 + i
    assert check_2
    # __iter__ with 1 arg
    range_it_3 = Range(11).__iter__()
    check_3 = True
    for i in range(11):
        check_3 = check_3

# Generated at 2022-06-21 12:11:46.438535
# Unit test for function scanr
def test_scanr():
    assert [10, 9, 7, 4, 0] == scanr(operator.add, [1, 2, 3, 4], 0)
    assert ['abcd', 'bcd', 'cd', 'd'] == scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])



# Generated at 2022-06-21 12:11:49.326891
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    
    # Set up
    func = lambda x: x * x
    lst = [1, 2, 3, 4, 5]
    m = MapList(func, lst)
    
    # Test
    result = lambda: [item for item in m]
    
    # Verify
    expected = lambda: [func(item) for item in lst]
    assert result() == expected()



# Generated at 2022-06-21 12:11:57.094517
# Unit test for function scanl
def test_scanl():
    def add(a, b): return a + b
    def mul(a, b): return a * b
    test_data = [1, 2, 3, 4, 5]
    assert list(scanl(add, test_data)) == list(scanl(add, test_data, 0))
    assert list(scanl(mul, test_data)) == list(scanl(mul, test_data, 1))
    assert list(scanl(add, test_data, 100)) == [100, 101, 103, 106, 110, 115]
    assert list(scanl(mul, test_data, 2)) == [2, 2, 4, 12, 48, 240]
    print('test_scanl passed')

test_scanl()


# Generated at 2022-06-21 12:12:02.737829
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    class Test1(MapList[str, int]):
        def __init__(self):
            super().__init__(lambda x: x, [])
    obj = Test1()
    idx = 0
    actual = obj.__getitem__(idx)
    expected = None
    assert actual == expected, f'expected: {expected}, actual: {actual}'


# Generated at 2022-06-21 12:12:05.558234
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(5, range(5))) == []



# Generated at 2022-06-21 12:12:09.156459
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    from math import sqrt
    lst = [1, 2, 3, 4, 5]
    assert len(MapList(sqrt, lst)) == len(lst)



# Generated at 2022-06-21 12:12:21.087226
# Unit test for method __next__ of class Range
def test_Range___next__():
    rng = range(3)
    assert next(rng) == 0
    assert next(rng) == 1
    assert next(rng) == 2
    assert next(rng) == 3

# Generated at 2022-06-21 12:12:31.368404
# Unit test for method __len__ of class Range
def test_Range___len__():
# Declare all variables
    obj = None
# Initialize type map
    obj = Range(1, 5 + 1)
    print("length of range is", len(obj))
    obj = Range(1, 5 + 1, 2)
    print("length of range is", len(obj))
    obj = Range(1, 5 + 1, 3)
    print("length of range is", len(obj))

    obj = Range(1, 2)
    print("length of range is", len(obj))
    obj = Range(1, 3)
    print("length of range is", len(obj))
    obj = Range(1, 4)
    print("length of range is", len(obj))
    obj = Range(1, 5)
    print("length of range is", len(obj))
    obj = Range(1, 6)
   

# Generated at 2022-06-21 12:12:34.556982
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import random
    for _ in range(10):
        lst = list(LazyList(range(random.randint(0, 20))))
        assert lst == list(range(len(lst)))

# Generated at 2022-06-21 12:12:39.551134
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:12:48.715813
# Unit test for function chunk
def test_chunk():
    assert list(chunk(10, range(13))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [10, 11, 12]]
    assert list(chunk(4, range(20))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9, 10, 11], [12, 13, 14, 15], [16, 17, 18, 19]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-21 12:12:52.663130
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3])[1:3] == [4, 9]

# Generated at 2022-06-21 12:13:01.001230
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x * x, [1, 2, 3, 4]).list == [1, 2, 3, 4]
    assert MapList(lambda x: x * x, [1, 2, 3, 4]).func(2) == 4
    assert MapList(lambda x: x * x, [1, 2, 3, 4])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3, 4])[1:3] == [4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3, 4])[2:2] == []
    assert len(MapList(lambda x: x * x, [1, 2, 3, 4])) == 4

# Generated at 2022-06-21 12:13:06.475045
# Unit test for constructor of class MapList
def test_MapList():
    func = lambda x: x + 1
    list = [1, 2, 3]
    map_list = MapList(func, list)
    assert map_list[0] == func(list[0])
    assert map_list[1] == func(list[1])
    assert map_list[2] == func(list[2])
    assert list(map_list) == [func(x) for x in list]
    assert len(map_list) == len(list)
    assert map_list[::-1] == [func(x) for x in list[::-1]]


# Generated at 2022-06-21 12:13:12.857213
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x : x + 1, [0, 1, 2, 3, 4])
    assert len(lst) == 5
    assert list(lst) == [1, 2, 3, 4, 5]
    assert lst[0: 2] == [1, 2]
    assert lst[-1] == 5



# Generated at 2022-06-21 12:13:21.943002
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]

# Generated at 2022-06-21 12:13:47.012645
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    # Type: (MapList[R], Callable[..., int]) -> Iterator[R]
    def _test_range(obj: MapList[R], len_: Callable[..., int]) -> Iterator[R]:
        sum = 0
        for i in obj:
            sum += i
        assert sum == len_() * (len_() - 1) / 2
        return obj

    assert _test_range(MapList(lambda x: x, Range(10)), len) == _test_range(MapList(lambda x: x, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), len)




# Generated at 2022-06-21 12:13:47.388404
# Unit test for function drop_until
def test_drop_until():
    pass



# Generated at 2022-06-21 12:13:49.174700
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import doctest
    doctest.run_docstring_examples(
        LazyList.__iter__,
        globals(),
        name="LazyList.__iter__"
    )



# Generated at 2022-06-21 12:13:54.234401
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(10))) == list(range(3, 10))
    assert list(drop(20, range(10))) == []
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(20, [])) == []


# Generated at 2022-06-21 12:13:57.609210
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-21 12:14:00.848227
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(range(10))
    assert isinstance(lst, LazyList)
    assert list(lst) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-21 12:14:05.411583
# Unit test for constructor of class LazyList
def test_LazyList():
    ll = LazyList([1, 2, 3])
    assert list(ll) == [1, 2, 3]

    class TestList(list):
        def __len__(self):
            raise ValueError()

    ll = LazyList(TestList([1, 2, 3]))
    assert next(iter(ll)) == 1
    assert list(ll) == [1, 2, 3]



# Generated at 2022-06-21 12:14:15.364803
# Unit test for constructor of class Range
def test_Range():
    ''' Unit test for Range class '''
    assert Range(10).r == 10
    assert Range(0, 10).r == 10
    assert Range(0, 10, 2).r == 10
    assert Range(0).step == 1
    assert Range(0, 10).step == 1
    assert Range(0, 10, 2).step == 2
    assert Range(10).l == 0
    assert Range(0, 10).l == 0
    assert Range(0, 10, 2).l == 0
    assert Range(10).length == 10
    assert Range(0, 10).length == 10
    assert Range(0, 10, 2).length == 5
    assert Range(10)[0] == 0
    assert Range(0, 10)[2] == 2
    assert Range(0, 10, 2)[4] == 8

# Generated at 2022-06-21 12:14:21.932818
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import io
    import pytest
    with open("lazy_list.py") as file:
        lines = LazyList(file)
        assert lines[0] == "from __future__ import annotations\n"
        assert isinstance(lines[1], str)
        assert lines[0:-1] == lines[:1000]
        with pytest.raises(TypeError, match="__len__"):
            len(lines)
        with pytest.raises(RuntimeError, match="no longer valid"):
            list(lines)
        lines[0:-1]  # force iterating over the whole file
        lines.list[0]
        assert lines[5] == lines[1000] == lines[10000] == "def __len__(self):\n"

# Generated at 2022-06-21 12:14:24.866218
# Unit test for function drop
def test_drop():
    for i in range(100):
        assert list(drop(i, range(100))) == list(range(i, 100))



# Generated at 2022-06-21 12:15:06.988606
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    import random
    def test(func, lst):
        lst = list(lst)
        random.shuffle(lst)
        lst = MapList(func, lst)
        assert len(lst) == len(lst.list)
    test(lambda x: x, [])
    test(lambda x: x, [1, 2, 3, 4, 5])
    test(lambda x: x * x, [1, 2, 3, 4, 5])


# Generated at 2022-06-21 12:15:11.833864
# Unit test for function take
def test_take():
    assert list(take(0, range(1, 10))) == []
    assert list(take(1, range(1, 10))) == [0]
    assert list(take(2, range(1, 10))) == [0, 1]
test_take()



# Generated at 2022-06-21 12:15:17.881878
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    from random import randint
    assert list(MapList(lambda x: x + 1, range(100))) == list(range(1, 101))
    assert list(MapList(lambda x: x + 1, range(100))) == list(range(1, 101))
    assert list(MapList(lambda x: x + 1, range(100))) == list(range(1, 101))


# Generated at 2022-06-21 12:15:27.386343
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    lst = list(range(10))
    for idx in range(10):
        assert lst[idx] == Range(10)[idx]
    for idx in range(10):
        assert lst[idx:10] == Range(10)[idx:10]
    for idx in range(10):
        assert lst[:idx] == Range(10)[:idx]
    for idx in range(10):
        assert lst[idx:idx + 1] == Range(10)[idx:idx + 1]
    for idx in range(10):
        assert lst[idx:idx] == Range(10)[idx:idx]

# Generated at 2022-06-21 12:15:31.013799
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(1, 10 + 1)
    assert len(r) == 10

    r = Range(1, 10 + 1, 2)
    assert len(r) == 5

# Generated at 2022-06-21 12:15:42.590160
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 11, 2)
    assert r[0] == 1
    assert r[1] == 3
    assert r[2] == 5
    assert r[-1] == 9
    assert r[-2] == 7
    assert r[-3] == 5
    with pytest.raises(IndexError):
        r[-4]
    with pytest.raises(IndexError):
        r[3]
    assert r[0:2] == [1, 3, 5]
    assert r[:2] == [1, 3, 5]
    assert r[1:] == [3, 5, 7, 9]
    assert r[1:-1] == [3, 5, 7]
    assert r[-3:-1] == [5, 7]

# Generated at 2022-06-21 12:15:50.144703
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(3,6)
    assert r.__len__() == 3
    r = Range(1, 5, 2)
    assert r.__len__() == 2
    #r = Range(-5, 5)
    #assert r.__len__() == 10
    r = Range(5, -5)
    assert r.__len__() == 0
    r = Range(5, -10, -3)
    assert r.__len__() == 2

# Generated at 2022-06-21 12:15:53.777406
# Unit test for method __next__ of class Range
def test_Range___next__():
    res: List[int] = []
    for x in Range(11):
        res.append(x)
    assert res == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


# Generated at 2022-06-21 12:16:01.565159
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], -42)) == [-42, -41, -39, -36]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:16:09.896962
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3], 4)) == [4, 5, 8, 11]
    assert list(scanl(operator.add, [1, 2, 3])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, 'abc')) == ['a', 'ba', 'cba', 'dcba']
