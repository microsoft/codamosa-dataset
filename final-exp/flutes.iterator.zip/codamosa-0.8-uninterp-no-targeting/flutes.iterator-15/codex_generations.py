

# Generated at 2022-06-21 12:07:44.638708
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:07:52.229851
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda s, x: x + s, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: s + x, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'cd', 'd', '']


# Generated at 2022-06-21 12:08:00.593397
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]

    assert list(MapList(lambda x: x * x, lst)) == [1, 4, 9, 16, 25]
    assert MapList(lambda x: x * x, lst)[2] == 9
    assert MapList(lambda x: x * x, lst)[::-1] == [25, 16, 9, 4, 1]
    assert MapList(lambda x: x * x, lst)[2:4] == [9, 16]

# Generated at 2022-06-21 12:08:03.202035
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]



# Generated at 2022-06-21 12:08:08.843856
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(range(10000))
    assert lst[4999] == 4999
    assert len(lst) == 10000
    assert list(lst) == list(range(10000))
    assert lst[:10] == list(range(10))
    assert lst[-5:] == list(range(9995, 10000))


# Generated at 2022-06-21 12:08:12.909100
# Unit test for constructor of class Range
def test_Range():
    r = Range(5)
    assert isinstance(r, Sequence)
    assert isinstance(r, Iterable)
    assert list(r) == [0, 1, 2, 3, 4]
    assert r[0] == 0
    assert r[4] == 4
    assert r[0:4] == [0, 1, 2, 3]
    assert r[-5] == 0
    assert r[-1] == 4
    assert r[1:3] == [1, 2]
    assert r[-3:] == [2, 3, 4]
    r = Range(1, 5)
    assert list(r) == [1, 2, 3, 4]
    assert r[0] == 1
    assert r[4] == 5
    assert r[0:4] == [1, 2, 3, 4]

# Generated at 2022-06-21 12:08:14.106448
# Unit test for function drop_until
def test_drop_until():
    assert True
    

# Generated at 2022-06-21 12:08:16.694539
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x, [])) == 0
    assert len(MapList(lambda x: x, [1, 2, 3])) == 3



# Generated at 2022-06-21 12:08:21.724044
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(map(len, scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']))) == [4, 3, 2, 1]



# Generated at 2022-06-21 12:08:25.917862
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10    # (start, end)
    assert len(Range(1, 11, 2)) == 5      # (start, end, step)


# Generated at 2022-06-21 12:08:34.279602
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3]
    f = lambda x: x * x
    m = MapList(f, a)
    for i in range(len(a)):
        assert m[i] == f(a[i])
    assert len(m) == len(a)

# Generated at 2022-06-21 12:08:37.099854
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-21 12:08:42.282677
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-21 12:08:45.211970
# Unit test for constructor of class Range
def test_Range():
    a = Range(1, 100, 2)
    assert len(a) == 50



# Generated at 2022-06-21 12:08:50.930189
# Unit test for constructor of class Range
def test_Range():
    # Case 1:
    Range(10)
    # Case 2:
    Range(1, 11)
    # Case 3:
    Range(1, 11, 2)
    # Case 4:
    with pytest.raises(ValueError):
        Range()
    # Case 5:
    with pytest.raises(ValueError):
        Range(1,10,11,12)

# Generated at 2022-06-21 12:08:57.372854
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]



# Generated at 2022-06-21 12:09:00.206538
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
  print('Running unit test for method __iter__ of class MapList:')
  lst = [1, 2, 3]
  func = lambda x: 2 * x
  map_list = MapList(func, lst)
  for i, x in enumerate(map_list):
    assert x == 2 * lst[i]
  print('All tests passed!')



# Generated at 2022-06-21 12:09:07.381704
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    def _for_slice(stop, start, step):
        s = slice(start, stop, step)
        l1 = list(Range(start, stop, step))
        l2 = Range(start, stop, step)[s]
        assert l1 == l2

    _for_slice(27, 0, 3)
    _for_slice(10, 2, 2)
    _for_slice(10, 0, 1)


# Generated at 2022-06-21 12:09:18.898078
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    total = 0
    for i in range(1000):
        total += i
        #          0 1  2  3  4  5  6  7  8   9   10 11  12
        lst = LazyList(range(5*i))
        # if (i % 333) == 0:
        #     print("len(lst) = {}".format(len(lst)))
        assert len(lst) == 5*i
        for j in range(5*i):
            x = lst[j]
            assert x == j, "lst[{}] should be {} but got {}".format(j, j, x)
        assert len(lst) == 5*i
        for j in range(5*i):
            x = lst[-j-1]
            assert x == 5*i-j

# Generated at 2022-06-21 12:09:30.551490
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4]
    b = [2, 3, 4, 5]
    c = MapList(lambda i: a[i] * b[i], range(len(a)))
    assert len(c) == 4
    assert c[0] == 2
    assert c[1] == 6
    assert c[2] == 12
    assert c[3] == 20
    assert list(c) == [2, 6, 12, 20]
    assert c[0:2] == [2, 6]
    assert c[1:] == [6, 12, 20]
    assert c[:3] == [2, 6, 12]
    assert c[::2] == [2, 12]
    assert c[::-1] == [20, 12, 6, 2]

# Generated at 2022-06-21 12:09:40.802875
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    for _ in range(100):  # 100 iterations to handle different random seeds
        ls = LazyList(range(random.randint(1, 100)))
        assert list(iter(ls)) == list(range(len(ls)))  # == list(range(len(ls))) == list(range(random.randint(1, 100)))

# Generated at 2022-06-21 12:09:46.551173
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)
    assert_equals(r.__next__(), 0)
    r = Range(1, 10 + 1)
    assert_equals(r.__next__(), 1)
    r = Range(1, 11, 2)
    assert_equals(r.__next__(), 1)
    try:
        r.__next__()
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-21 12:09:58.972703
# Unit test for constructor of class LazyList
def test_LazyList():
    # Create a lazy list.
    lazy_list = LazyList([i for i in range(300)])
    # Access for the first time.
    assert lazy_list[0] == 0
    # Access for the second time.
    assert lazy_list[0] == 0
    # Access a middle one.
    assert lazy_list[50] == 50
    # Access an out-of-bound element.
    assert lazy_list[299] == 299
    # Access a slice.

# Generated at 2022-06-21 12:10:01.856290
# Unit test for constructor of class LazyList
def test_LazyList():
    s = LazyList(i for i in range(10))
    assert len(s) == 10
    assert s[-1] == 9
    assert s[9:] == [9]
    assert sum(i for i in s) == 45
    assert sum(i for i in s[4::2]) == 20


# Generated at 2022-06-21 12:10:14.544000
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r1 = Range(1, 10+1, 2)
    assert r1[0] == 1
    assert r1[2] == 5
    assert r1[4] == 9
    assert r1[-1] == 9
    assert r1[-2] == 7
    assert r1[-4] == 3
    assert r1[:2] == [1, 3]
    assert r1[1:] == [3, 5, 7, 9]
    assert r1[:] == [1, 3, 5, 7, 9]
    assert r1[1:3] == [3, 5]
    assert r1[1:10:2] == [3, 5, 7, 9]
    assert r1[1:10:3] == [3, 7]

# Generated at 2022-06-21 12:10:19.698283
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:10:24.682938
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(2, range(10))) == list(range(2, 10))
    assert list(drop(100, range(10))) == []
    assert list(drop(100, range(0))) == []



# Generated at 2022-06-21 12:10:33.846697
# Unit test for constructor of class Range
def test_Range():
    assert Range(10)[0] == 0
    assert Range(0, 10)[0] == 0
    assert Range(0, 10)[-1] == Range(0, 10)[9]
    assert Range(0, 10, 2)[0] == 0
    assert Range(0, 10)[8:] == [8, 9]
    assert Range(1, 10)[::2][::-1] == [9, 7, 5, 3, 1]
    assert Range(0, -10, -3)[0] == 0

    def r(x):
        for i in Range(10):
            x += 1
        return x

    assert r(0) == 10
    assert r(1) == 10
    assert r(2) == 10


# Generated at 2022-06-21 12:10:38.261454
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lz = LazyList([1, 2, 3])
    try:
        len(lz)
        assert False
    except TypeError:
        assert True
    lz = next(iter(lz))
    assert len(lz) == 3



# Generated at 2022-06-21 12:10:48.060315
# Unit test for function drop_until
def test_drop_until():
    for i in range(10):
        x = random.randint(0, 10)
        assert all(y >= x for y in drop_until(lambda e: e >= x, range(10)))
    assert list(drop_until(lambda _: False, range(5))) == list(range(5))
    assert list(drop_until(lambda _: True, range(5))) == list(range(5))
    try:
        drop_until(lambda _: False, [])
        assert False
    except StopIteration:
        pass
    try:
        drop_until(lambda _: True, [])
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-21 12:11:07.326722
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:11:09.743003
# Unit test for constructor of class LazyList
def test_LazyList():
    it = LazyList(range(-5, 6))
    for i in range(10):
        assert i, it[i]


# Generated at 2022-06-21 12:11:19.482712
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    base_list = [1, 2, 3, 4, 5]

    class TestCase:
        def __init__(self, pass_by_list):
            self.pass_by_list = pass_by_list

        def __getitem__(self, idx):
            if self.pass_by_list:
                return base_list[idx]
            else:
                return base_list[idx]

    map_list = MapList(lambda x: x ** 3, TestCase(False))
    for idx in range(5):
        assert map_list[idx] == base_list[idx] ** 3
    for idx in range(5):
        assert map_list[idx] == base_list[idx] ** 3



# Generated at 2022-06-21 12:11:23.145443
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x * x, [1, 2, 3, 4])
    assert lst[1] == 4
    assert lst[:2] == [1, 4]
    assert lst[1:] == [4, 9, 16]


# Generated at 2022-06-21 12:11:30.034536
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)  # (start, end, step)
    assert([1, 3, 5, 7, 9] == list(r))
    r = list(r)
    assert([1, 3, 5, 7, 9] == r)
    r = Range(10)  # (end)
    r[r.length - 1] == 9
# Test for method __getitem__ of class Range

# Generated at 2022-06-21 12:11:36.362471
# Unit test for function chunk
def test_chunk():
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-21 12:11:38.221709
# Unit test for function take
def test_take():
    # Setup
    result = list(take(5, range(1000000)))
    # Verify
    assert result == list(range(5))



# Generated at 2022-06-21 12:11:43.978212
# Unit test for constructor of class Range
def test_Range():
    try:
        r = Range()
        assert False
    except Exception as e:
        assert type(e) == ValueError

    try:
        r = Range(1)
        assert r[0] == 1
    except Exception as e:
        assert False
    try:
        r = Range(1, 2)
        assert r[0] == 1 and r[1] == 2
    except Exception as e:
        assert False

    try:
        r = Range(1, 10, 3)
        assert r[0] == 1 and r[1] == 4 and r[2] == 7
    except Exception as e:
        assert False

# Generated at 2022-06-21 12:11:50.846263
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    print('Testing method __iter__ of class Range')
    from .test_helpers import check
    r = Range(3)
    for i in r:
        print(i)
    r = Range(1,5)
    for i in r:
        print(i)
    r = Range(0,10,2)
    for i in r:
        print(i)
    check(r)
    # TODO: implement more robust test cases
    return True

# Generated at 2022-06-21 12:11:53.253530
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = []
    for i in LazyList(range(1000000)):
        l.append(i)
    assert len(l) == 1000000


# Generated at 2022-06-21 12:12:01.930562
# Unit test for function drop
def test_drop():
    n = 5
    iterable = range(500)
    for i, x in enumerate(drop(n,iterable)):
        if i == 0:
            assert x == n
        else:
            assert x == n+i


# Generated at 2022-06-21 12:12:13.682066
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert str(LazyList([1, 2])) == "[1, 2]"
    assert list(LazyList([1, 2, 3, 4])) == [1, 2, 3, 4]
    assert list(LazyList(["hello", "world"])) == ["hello", "world"]

    lst = LazyList([1, 2])
    lst._fetch_until(1)
    assert str(lst) == "[1, 2]"

    lst = LazyList([1, 2])
    lst._fetch_until(2)
    assert str(lst) == "[1, 2]"

    lst = LazyList([1, 2])
    lst._fetch_until(3)
    assert str(lst) == "[1, 2]"


# Generated at 2022-06-21 12:12:21.211204
# Unit test for function scanl
def test_scanl():
    import operator
    # scanl
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    # scanl failure
    try:
        scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd', 'e'], initial=1)
        assert False
    except StopIteration:
        pass



# Generated at 2022-06-21 12:12:25.216360
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    m = MapList(lambda x: x, [1])
    assert len(m) == 1
    m = MapList(lambda x: x, [])
    assert len(m) == 0



# Generated at 2022-06-21 12:12:29.189769
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    x = LazyList(filter(None, repeat(1)))
    try:
        len(x)
    except TypeError:
        pass
    else:
        raise AssertionError("Expected len(LazyList(filter(None, repeat(1)))) to throw an exception")

# Generated at 2022-06-21 12:12:39.896791
# Unit test for method __next__ of class Range
def test_Range___next__():
    with pytest.raises(StopIteration):
        Range(0, 0).__next__()
    assert Range(0, 1).__next__() == 0
    assert Range(0, 2).__next__() == 0
    assert Range(0, 3).__next__() == 0
    assert Range(0, 4).__next__() == 0
    assert Range(0, 5).__next__() == 0
    assert Range(0, 6).__next__() == 0
    assert Range(0, 7).__next__() == 0
    assert Range(0, 8).__next__() == 0
    assert Range(0, 9).__next__() == 0
    assert Range(0, 10).__next__() == 0

# Generated at 2022-06-21 12:12:46.841635
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:12:56.537055
# Unit test for function scanl
def test_scanl():
    list1 = [1, 2, 3, 4]
    list2 = ['a', 'b', 'c', 'd']
    list3 = []

    assert list(scanl(operator.add, list1, 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, list1)) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, list2)) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, list3)) == []
    assert list(scanl(operator.add, list3, 0)) == [0]
    assert list(scanl(lambda x: x, list1)) == [1, 2, 3, 4]



# Generated at 2022-06-21 12:12:59.487768
# Unit test for constructor of class MapList
def test_MapList():
    lst = [0, 1, 2, 3, 4]
    assert MapList(lambda x: x * x, lst) == [0, 1, 4, 9, 16]
    assert MapList(lambda x: x + 1, lst) == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 12:13:01.068644
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10000))) == 10000

# Generated at 2022-06-21 12:13:16.803389
# Unit test for function drop
def test_drop():
    assert list(drop(1, range(10))) == list(range(1,10))
    assert list(drop(100, range(10))) == []
    assert list(drop(-3, range(10))) == []
    assert list(drop(0, range(10))) == list(range(10))


# Generated at 2022-06-21 12:13:24.520249
# Unit test for constructor of class Range
def test_Range():
    L = Range(-1, 5).__len__()
    assert L == 6
    range_slice_test = Range(10, 20, 2)
    assert range_slice_test[2:5] == [14, 16, 18]
    assert range_slice_test[3] == 16
    assert range_slice_test[-1] == 18
    assert range_slice_test[:-1] == [10, 12, 14, 16]
    assert range_slice_test[:] == [10, 12, 14, 16, 18]

# Generated at 2022-06-21 12:13:26.878590
# Unit test for constructor of class MapList
def test_MapList():
    r = range(10)
    assert list(MapList(lambda x: x * x, r)) == [x * x for x in r]
    assert MapList(lambda x: x * x, r)[0] == 0
    assert MapList(lambda x: x * x, r)[-1] == 81


# Generated at 2022-06-21 12:13:32.964422
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == [0, 1, 2]
    assert list(take(3, range(0))) == []
    assert list(take(-1, range(10))) == []
    with pytest.raises(ValueError) as e:
        take(-3, range(10))
    assert str(e.value) == "`n` should be non-negative"



# Generated at 2022-06-21 12:13:34.772814
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x, [1, 2, 3])[0] == 1
    

# Generated at 2022-06-21 12:13:42.062031
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert list(Range(0, 90, 2)) == list(range(0, 90, 2))
    assert Range(11)[10] == 10 and Range(5, 10)[1] == 6
    assert tuple(Range(0, 90, 2)[2:5]) == tuple(range(0, 90, 2)[2:5])
    assert tuple(Range(0, 90, 2)[-10:25:2]) == tuple(range(0, 90, 2)[-10:25:2])

# Generated at 2022-06-21 12:13:49.962670
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(10)
    r2 = Range(1, 10 + 1)
    r3 = Range(1, 11, 2)
    assert r1[0] == 0
    assert r2[0] == 1
    assert r3[0] == 1
    assert r1[2] == 2
    assert r2[2] == 3
    assert r3[2] == 5
    assert r1[4] == 4
    assert r2[4] == 5
    assert r3[4] == 9


# Generated at 2022-06-21 12:13:54.773033
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(3))
    assert next(lst.__iter__()) == 0
    assert next(lst.__iter__()) == 1
    assert next(lst.__iter__()) == 2
    assert next(lst.__iter__()) == 0
    assert next(lst.__iter__()) == 1
    assert next(lst.__iter__()) == 2
    lst = LazyList(range(3))
    assert list(lst) == [0, 1, 2]


# Generated at 2022-06-21 12:13:59.251010
# Unit test for constructor of class LazyList
def test_LazyList():
    from itertools import count
    
    a = LazyList(count(1))
    expected_result = [1,2,3,4,5]
    for i, item in enumerate(a):
        assert expected_result[i] == item


# Generated at 2022-06-21 12:14:03.733596
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 10 + 1, 2)) == 5
    with pytest.raises(TypeError) as ex:
        assert len(Range(1, 10 + 1, 2)) == 6
    assert '__len__' in str(ex.value)

# Generated at 2022-06-21 12:14:31.398878
# Unit test for method __next__ of class Range
def test_Range___next__():
    ""
    assert next(Range(0, 5)) == 0
    assert next(Range(0, 5)) == 1
    assert next(Range(0, 5)) == 2
    assert next(Range(0, 5)) == 3
    assert next(Range(0, 5)) == 4
    with pytest.raises(StopIteration):
        next(Range(0, 5))


# Generated at 2022-06-21 12:14:40.115223
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=lambda x: True)) == []
    assert list(split_by([], criterion=lambda x: False)) == [[]]
    assert list(split_by([1, 2, 3], criterion=lambda x: x == 1)) == [[2, 3]]
    assert list(split_by([1, 2, 3], criterion=lambda x: x == 2)) == [[1], [3]]
    assert list(split_by([1, 2, 3], criterion=lambda x: x == 3)) == [[1, 2]]
    assert list(split_by([1, 2, 3], criterion=lambda x: x % 2 == 0)) == [[1], [3]]
    assert list(split_by([1, 2, 3], criterion=lambda x: True)) == [[], []]

# Generated at 2022-06-21 12:14:50.931418
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    import string

    def test_slice(count):
        print(f"Testing slicing LazyList with {count} elements")
        random.seed(0)
        chars = string.ascii_letters + string.digits
        it = (random.choice(chars) for _ in range(count))
        ll = LazyList(it)
        assert ll[0] == 'k'
        assert ll[10] == 'V'
        assert ll[1:7] == ['m', 'h', 'N', '2', 'o', 'K']
        assert ll[3:3] == []
        assert ll[3:3:3] == []
        assert ll[:3] == ['k', 'm', 'h']

# Generated at 2022-06-21 12:15:01.472259
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import unittest
    import string
    
    # Assume a is ['a', 'b', 'c', 'd']
    # Assume func = lambda x: x * 2
    # Assume lst = MapList(func, a)
    class TestMethods(unittest.TestCase):
        def test_lst___getitem__(self):
            self.assertEqual(lst[0], 'aa')
            self.assertEqual(lst[1], 'bb')
            self.assertEqual(lst[2], 'cc')
            self.assertEqual(lst[3], 'dd')
            self.assertEqual(lst[1:3], ['bb', 'cc'])
            self.assertEqual(lst[1:6], ['bb', 'cc', 'dd'])
            self

# Generated at 2022-06-21 12:15:05.512065
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3], 0)) == [0, 1, 3, 6]
    assert list(scanl(operator.add, [1, 2, 3])) == [1, 3, 6]



# Generated at 2022-06-21 12:15:15.417521
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, range(1, 4), 0)) == [6, 5, 3, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']
    assert scanr(operator.add, [2, 3], 0) == [5, 2, 0]
    assert scanr(lambda s, x: x + s, ['d', 'c']) == ['dc', 'c']
    assert scanr(operator.add, [1]) == [1]



# Generated at 2022-06-21 12:15:18.432305
# Unit test for constructor of class MapList
def test_MapList():
    assert get_type_hints(MapList.__init__) == {
        'func': Callable[[T], R],
        'lst': Sequence[T],
        'return': None
    }


# Generated at 2022-06-21 12:15:26.008124
# Unit test for function chunk
def test_chunk():
    from ..test_utils import _is_iterable
    import random

    random.seed(0)

    x = list(range(10))
    random.shuffle(x)
    y = list(chunk(3, x))
    assert _is_iterable(y)

    x = list(range(10)) * 2
    random.shuffle(x)
    y = list(chunk(3, x))
    assert _is_iterable(y)

    x = []
    y = list(chunk(3, x))
    assert _is_iterable(y)



# Generated at 2022-06-21 12:15:29.258835
# Unit test for function drop
def test_drop():
    it = drop(10, range(100))
    try:
        while True:
            next(it)
    except StopIteration:
        pass



# Generated at 2022-06-21 12:15:40.602778
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, a)
    assert m[3] == 16
    assert m[:3] == [1, 4, 9]
    assert m[3:5] == [16, 25]
    assert m[3:] == [16, 25]
    assert m[:7:2] == [1, 9, 25]
    assert list(m) == [1, 4, 9, 16, 25]
    assert len(m) == 5
    assert m[-1] == 25
    assert m[-2:-4:-1] == [16, 9]
    assert m[:-2] == [1, 4, 9, 16]

# Generated at 2022-06-21 12:16:46.738511
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)         # (end)
    assert len(r) == 10
    r = Range(1, 10 + 1)  # (start, end)
    assert len(r) == 10
    r = Range(1, 11, 2)   # (start, end, step)
    assert len(r) == 5

# Generated at 2022-06-21 12:16:49.030502
# Unit test for function take
def test_take():
    import random
    assert [random.random() for _ in range(10)] == list(take(10, (random.random() for _ in range(100))))



# Generated at 2022-06-21 12:16:56.518788
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(0)) == []
    assert list(Range(-10)) == []
    assert list(Range(3)) == [0, 1, 2]
    assert list(Range(1, 3)) == [1, 2]
    assert list(Range(1, 10, 2)) == [1, 3, 5, 7, 9]
    assert list(Range(10, 3, -2)) == [10, 8, 6, 4]
    assert list(Range(3, 10, 4)) == [3, 7]
    assert list(Range(3, 10, -4)) == []
    assert list(Range(10, 3, 4)) == []


# Generated at 2022-06-21 12:17:05.633970
# Unit test for function chunk
def test_chunk():
    # Basic
    assert list(chunk(2, [1, 2, 3])) == [[1, 2], [3]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    # empty list
    assert list(chunk(5, [])) == []
    # n < 0
    with pytest.raises(ValueError):
        list(chunk(-1, [1, 2, 3]))
    # n = 0
    with pytest.raises(ValueError):
        list(chunk(0, [1, 2, 3]))
    # n = 1
    assert list(chunk(1, [1, 2, 3])) == [[1], [2], [3]]