

# Generated at 2022-06-21 12:07:29.004259
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    pair = Pair(1, 2)
    assert pair[0] == 1
    assert pair[1] == 2
    assert pair[-1] == 2
    assert pair[0:2] == [1, 2]
    assert pair[-2:] == [1, 2]


# Generated at 2022-06-21 12:07:36.943141
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [list(range(3)), list(range(3, 6)), list(range(6, 9)), [9]]
    assert list(chunk(1, range(10))) == list(map(lambda t: [t], range(10)))
    assert list(chunk(10, range(10))) == [list(range(10))]
    assert list(chunk(1, [])) == []
    assert list(chunk(10, [])) == []



# Generated at 2022-06-21 12:07:42.161860
# Unit test for function take
def test_take():
    l = range(10)
    l2 = list(take(4, l))
    assert_equal(l2, [0, 1, 2, 3])
    l3 = list(take(0, l))
    assert_equal(l3, [])
    l4 = list(take(1, l))
    assert_equal(l4, [0])



# Generated at 2022-06-21 12:07:45.911722
# Unit test for function drop
def test_drop():
    it = iter(range(1, 1000000))
    assert next(drop(5, it)) == 5
    assert next(drop(10000000, it)) == 0
    try:
        next(drop(100, it))
        assert False, "StopIteration not raised"
    except StopIteration:
        pass


# Generated at 2022-06-21 12:07:48.844282
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        len(LazyList([]))
        assert False, "Previous line should throw an exception"
    except TypeError:
        pass
    assert len(LazyList(range(10))) == 10



# Generated at 2022-06-21 12:07:53.059202
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x * x, a)[0] == 1
    assert MapList(lambda x: x * x, a)[2] == 9
    assert MapList(lambda x: x * x, a)[4] == 25


# Generated at 2022-06-21 12:07:54.664175
# Unit test for function take
def test_take():
    print(list(take(5, range(10))))  # [0, 1, 2, 3, 4]



# Generated at 2022-06-21 12:07:58.501949
# Unit test for constructor of class LazyList
def test_LazyList():
    gen = (x for x in range(3))
    lazy = LazyList(gen)
    assert list(lazy) == [0, 1, 2]



# Generated at 2022-06-21 12:08:03.381726
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:08:12.359971
# Unit test for constructor of class MapList
def test_MapList():
    from itertools import count
    lst = [1, 2, 3, 4, 5]
    lst_square = MapList(lambda x: x * x, lst)
    lst_cube = MapList(lambda x: x * x * x, lst)
    for i in count():
        try:
            assert lst_square[i] == lst[i] ** 2
            assert lst_cube[i] == lst[i] ** 3
        except IndexError:
            break
        assert lst_square[i] == next(lst_square)
        assert lst_cube[i] == next(lst_cube)
    # Expected behavior for starting index and ending index for MapList
    assert lst_square[:4] == [1, 4, 9, 16]
    assert lst_

# Generated at 2022-06-21 12:09:02.577374
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():

    source = [1, 2]
    lst = LazyList(source)

    assert next(lst.__iter__()) == 1
    assert next(lst.__iter__()) == 2
    assert next(lst.__iter__()) == 1
    assert next(lst.__iter__()) == 2
    assert next(lst.__iter__()) == 1
    assert next(lst.__iter__()) == 2



# Generated at 2022-06-21 12:09:05.076172
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(5)) == 5
    assert len(Range(10, 20, 2)) == 5

# Generated at 2022-06-21 12:09:07.112013
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    if str(Range(1, 2, 5)[1]) != '1':
        raise AssertionError

# Generated at 2022-06-21 12:09:08.250616
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x: x * x, [3, 10, 1, 5, 4])
    assert len(lst) == 5

# Generated at 2022-06-21 12:09:16.653700
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, range(10), 0)) == [45, 44, 42, 39, 35, 30, 24, 17, 9, 0]
    assert list(scanr(lambda a, b: a | b, [1, 2, 4, 8, 16])) == [31, 30, 28, 24, 16]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:09:18.768129
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 10 + 1)
    r = Range(1, 11, 2)
    r = Range(10)

# Generated at 2022-06-21 12:09:21.358853
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(100))
    for i, x in enumerate(lst):
        if i > 10:
            break
        assert x == i



# Generated at 2022-06-21 12:09:28.019104
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    test = [1,2,3,4,5,6]
    ml = MapList(lambda x: x + 1, test)
    val = 0
    for i, item in enumerate(ml):
        val += item - test[i] - 1
    if val != 0:
        raise AssertionError("sum is not zero, sum is " + str(val))
        return False
    return True


# Generated at 2022-06-21 12:09:39.312571
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)
    assert list(r) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert [r[i] for i in range(10)] == list(r)
    assert [r[i] for i in range(-10, 10)] == list(r)
    r = Range(2, 10)
    assert list(r) == [2, 3, 4, 5, 6, 7, 8, 9]
    assert [r[i] for i in range(8)] == list(r)
    assert [r[i] for i in range(-8, 0)] == list(r)
    r = Range(2, 10, 2)
    assert list(r) == [2, 4, 6, 8]
    assert [r[i] for i in range(4)]

# Generated at 2022-06-21 12:09:40.272310
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x // 2, [1, 2, 3, 4, 5])) == 5


# Generated at 2022-06-21 12:10:05.406435
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x // 3 == 0)) == [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    assert list(split_by(range(10), criterion=lambda x: x // 3 == 0, empty_segments=True)) == [[1, 2, 3], [], [4, 5, 6], [], [7, 8, 9]]


# Generated at 2022-06-21 12:10:17.021807
# Unit test for method __getitem__ of class MapList

# Generated at 2022-06-21 12:10:23.158138
# Unit test for method __next__ of class Range
def test_Range___next__():
    from builtins import range as builtin_range
    for n in [10, 100, 1000, 10000]:
        for k in [1, 2, 5, 7, 10, 50, 100, 500]:
            x = Range(n, k=k)
            y = builtin_range(n, k=k)
            for i in range(n):
                l = x.__next__()
                r = y.__next__()
                assert l == r

# Generated at 2022-06-21 12:10:26.264417
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    m = MapList(lambda x: x + 1, [1, 2, 3, 4, 5])
    assert list(m) == [2, 3, 4, 5, 6]
    assert list(m) == [2, 3, 4, 5, 6]

# Generated at 2022-06-21 12:10:34.976508
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def f(x):
        return x * x

    map_list = MapList(f, list(range(10)))
    assert map_list[0] == 0
    assert map_list[1] == 1
    assert map_list[2] == 4
    assert map_list[4] == 16
    assert map_list[9] == 81
    assert map_list[slice(0, 10, 2)] == [0, 4, 16, 36, 64]
    assert map_list[3:9:2] == [9, 25, 49, 81]
    assert map_list[::-1] == [81, 64, 49, 36, 25, 16, 9, 4, 1, 0]

# Generated at 2022-06-21 12:10:41.273252
# Unit test for function scanl
def test_scanl():
    import operator
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:10:51.085572
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range(100000):
        assert Range(100)[i] == i
        assert Range(100)[-i] == 100 - i
    for i in range(100000):
        start = random.randint(-100, 1000000)
        end = start + random.randint(0, 100000)
        r = Range(start, end)
        for i in range(100000):
            idx = random.randint(-100000, 100000)
            assert r[idx] == start + (idx % (end - start))
    for i in range(100000):
        start = random.randint(-100, 1000000)
        end = start + random.randint(0, 100000)
        r = Range(start, end, 2)

# Generated at 2022-06-21 12:10:59.042050
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList(range(10000))
    b = a[3:]
    c = a[4:5]
    d = a[-1]
    e = a[-2]
    f = a[:10]
    g = a[9000:9010]
    h = a[9005:]
    i = a[:3500]
    j = a[3500:]
    k = a[4500:5500]
    assert a[2] == 2

# Generated at 2022-06-21 12:11:04.020581
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:11:09.171699
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    class A(Range):
        def __init__(self, *args):
            super().__init__(*args)
    a = A(0, 10, 2)
    assert a[2] == 4
    assert a[-1] == 8
    assert a[-2] == 6
    assert a[0:3] == [0, 2, 4]
    assert a[0:-1] == [0, 2, 4, 6]
    assert a[0::2] == [0, 4, 8]
    assert a[0:4:2] == [0, 4]
    assert a[::-1] == [8, 6, 4, 2, 0]
    assert a[::-2] == [8, 4, 0]
    assert a[4:0:-1] == [6, 4, 2]

# Generated at 2022-06-21 12:11:19.271474
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    sut = MapList(lambda x: x * x, range(10))
    actual = len(sut)
    assert actual == 10, "len(MapList) should return the length of the wrapped list"
    pass



# Generated at 2022-06-21 12:11:21.862097
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert next(drop(5, range(5))) == StopIteration


# Generated at 2022-06-21 12:11:31.801195
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(100, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(10, range(0))) == []
    assert list(chunk(10, range(1))) == [[0]]
    assert list(chunk(10, range(2))) == [[0, 1]]



# Generated at 2022-06-21 12:11:42.144198
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(1, 5), criterion=lambda x: x % 2 == 0)) == [[1], [3]]
    assert list(split_by(range(1, 5), empty_segments=True, criterion=lambda x: x % 2 == 0)) == [[1], [], [3], []]
    assert list(split_by(range(1, 5), empty_segments=True, criterion=lambda x: x % 2 == 0)) == [[1], [], [3], []]
    assert list(split_by(" Split by: ", criterion=lambda x: x == ":")) == list(" Split by".split())
    assert list(split_by(" Split by: ", empty_segments=True, criterion=lambda x: x == ":")) == ["", " Split by", "", ""]

# Generated at 2022-06-21 12:11:52.694611
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from hypothesis import given
    from .test_utils import list_from_iterable_strategy
    from .strategies import integers
    from .strategies import arrays

    @given(integers(min_value=0), arrays(min_size=1), integers(min_value=0))
    def test_basic_slice(start, array, width):
        seq = LazyList(array)
        assert list(seq[start:start+width]) == array[start:start+width]

    @given(integers(min_value=0, max_value=100), integers(min_value=0, max_value=100))
    def test_slice_bounds(start, width):
        seq = LazyList(range(100))

# Generated at 2022-06-21 12:11:55.293269
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    test = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert (test[2] == 9)
    assert (test[0:3] == [1, 4, 9])
    assert (len(test) == 5)


# Generated at 2022-06-21 12:11:57.075064
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    m = [1, 2, 3]
    x = [4, 5, 6]
    mm = MapList(lambda m, x:m + x, m, x)
    assert mm.__len__() == 3



# Generated at 2022-06-21 12:12:06.137976
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'e')) == ['e', 'ea', 'eba', 'ecba', 'edcba']
    assert list(scanl(operator.add, [])) == []



# Generated at 2022-06-21 12:12:13.367911
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    import random

    def test(args):
        m = MapList(lambda x: x * x, args)
        result = len(m)
        assert result == len(args), "test failed"

    ns = [10, 100, 1000, 100000, 1000000]
    for n in ns:
        data = [random.randint(0, n) for _ in range(n)]
        test(data)
        test(range(n))



# Generated at 2022-06-21 12:12:23.491500
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10+1)
    assert r[0] == 1
    assert r[2:6:2] == [3, 5, 7, 9]
    r = Range(10)
    assert r[3:4] == [3]
    r = Range(2, 10, 4)
    assert r[0:6:2] == [2, 8]
    assert r[0:5:2] == [2, 6]
    assert r[1:10000] == [8]
    r = Range(10, 1, -3)
    assert r[2:3] == [7]
    assert r[0:5] == [10, 7, 4, 1]
    assert r[2:2] == []
    assert len(r) == 4
    assert r[-1] == 1

# Generated at 2022-06-21 12:12:41.277062
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(1000000))) == 1000000
    assert len(LazyList(range(1000000))[slice(500000, 500002)]) == 2



# Generated at 2022-06-21 12:12:43.468916
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10000))) == 10000



# Generated at 2022-06-21 12:12:47.877110
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(1000))
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert [x for x in lst] == list(range(1000))

# Generated at 2022-06-21 12:12:57.321865
# Unit test for constructor of class LazyList
def test_LazyList():
    assert list(LazyList(range(10))) == list(range(10))
    assert list(LazyList(LazyList(range(10)))) == list(range(10))
    assert list(LazyList(LazyList(range(10))[:3])) == list(range(3))
    assert list(LazyList(LazyList(range(10))[2:6])) == list(range(2, 6))
    assert list(LazyList(LazyList(range(10))[:5:2])) == list(range(0, 5, 2))
    assert list(LazyList(LazyList(range(10))[:3:2])) == list(range(0, 3, 2))

# Generated at 2022-06-21 12:13:04.868353
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]

    # test case 1:
    # find index of the first element in `a` whose square is >= 10.
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert a[pos * pos] >= 10

    # test case 2:
    # Find the first index `i` such that `a[i] * b[i]` is >= 10.
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert a[pos] * b[pos] >= 10


# Generated at 2022-06-21 12:13:17.077967
# Unit test for method __len__ of class Range
def test_Range___len__():
    def check(args):
        return len(Range(*args))
    assert check([]) == 0
    assert check([0]) == 0
    assert check([2, 0]) == 0
    assert check([0, 1, 2]) == 0
    assert check([0, 1, 3]) == 0
    assert check([1, 5]) == 4
    assert check([1, 6]) == 5
    assert check([1, 7]) == 6
    assert check([2, 5]) == 2
    assert check([2, 6]) == 3
    assert check([1, 5, 2]) == 2
    assert check([1, 6, 2]) == 3
    assert check([1, 7, 2]) == 4
    assert check([2, 5, 2]) == 1
    assert check([2, 6, 2]) == 2

# Generated at 2022-06-21 12:13:19.166832
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x: x * x, [1, 2, 3])
    assert len(lst) == 3, 'Function len returns incorrect result'



# Generated at 2022-06-21 12:13:29.115124
# Unit test for function chunk
def test_chunk():
    assert(list(chunk(2, range(1))) == [])
    assert(list(chunk(2, range(3))) == [[0, 1], [2]])
    assert(list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]])
    assert(list(chunk(2, range(5))) == [[0, 1], [2, 3], [4]])
    assert(list(chunk(-5, range(5))) == [[0, 1, 2, 3, 4]])


# Generated at 2022-06-21 12:13:32.344736
# Unit test for function drop
def test_drop():
    assert next(drop(5, range(10))) == 5
    assert sum(drop(5, range(10))) == 45
    assert sum(drop(5, range(10))) == 45


# Generated at 2022-06-21 12:13:38.366510
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[0] == 1
    assert MapList(lambda i: i + 1, [4, 4, 4, 4, 4])[1] == 2
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5, 6, 7, 8, 9])[1:5] == [4, 9, 16, 25]


# Generated at 2022-06-21 12:14:07.308734
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert len(r) == 10
    r = Range(0, 0)
    assert len(r) == 0
    r = Range(5, 5)
    assert len(r) == 0
    r = Range(5, 10)
    assert len(r) == 5
    r = Range(5, 10, 2)
    assert len(r) == 3
    r = Range(5, 10, 3)
    assert len(r) == 2
    r = Range(5, 12, 3)
    assert len(r) == 3

# Generated at 2022-06-21 12:14:10.975348
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert (list(LazyList(range(5))) == list(range(5)))
    assert (list(LazyList(range(5))[1:3]) == list(range(1, 3)))
    assert (list(LazyList(range(5))) == list(range(5)))

# Generated at 2022-06-21 12:14:15.619802
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(0, 10)) == list(range(10))
    assert list(Range(0, 10, 3)) == list(range(0, 10, 3))
    assert list(Range(3, 10)) == list(range(3, 10))
    assert list(Range(3, 10, 5)) == list(range(3, 10, 5))



# Generated at 2022-06-21 12:14:17.158280
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == [0, 1, 2]



# Generated at 2022-06-21 12:14:23.007183
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    assert hasattr(r, '__next__')
    assert iter(r) is r
    assert len(r) == 10
    assert next(r) == 0
    assert [next(r) for _ in r] == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    with raises(StopIteration):
        next(r)


# Generated at 2022-06-21 12:14:27.371167
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    lst = [1, 2, 3, 4, 5]
    assert list(MapList(lambda x: 3*x, lst)) == [3, 6, 9, 12, 15]

# Generated at 2022-06-21 12:14:29.989756
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 5, 1)
    assert list(iter(r)) == [1, 2, 3, 4]



# Generated at 2022-06-21 12:14:37.396704
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for k in range(1,7):
        for start in range(-k,k+1):
            for end in range(start,k+1):
                for step in range(1,k+1):
                    for i in range(-k,k+1):
                        r = Range(start,end,step)
                        rv = r[i]
                        v = start + step*i
                        if i < 0:
                            v = end + step*i
                        if i >= len(r):
                            v = start + step*(len(r)+i)
                        assert rv==v


# Generated at 2022-06-21 12:14:40.336828
# Unit test for method __len__ of class Range
def test_Range___len__():
    def test_cases():
        yield [Range(100), 100]
        yield [Range(10, 100), 90]
    for arg, expected in test_cases():
        # Setup
        obj = arg
        # Exercise
        actual = obj.__len__()
        # Verify
        assert actual == expected

# Generated at 2022-06-21 12:14:51.107953
# Unit test for function chunk
def test_chunk():
    assert list(chunk(2, (1, 2, 3))) == [[1, 2], [3]]
    assert list(chunk(2, (1, 2, 3, 4))) == [[1, 2], [3, 4]]
    assert list(chunk(3, ())) == []
    assert list(chunk(3, (1, 2, 3, 4))) == [[1, 2, 3], [4]]
    assert list(chunk(3, (1, 2, 3, 4, 5))) == [[1, 2, 3], [4, 5]]
    assert list(chunk(3, (1, 2, 3, 4, 5, 6))) == [[1, 2, 3], [4, 5, 6]]

# Generated at 2022-06-21 12:15:20.669064
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-21 12:15:24.161995
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList(range(5))
    b = iter(a)
    c = [next(b), next(b), next(b), next(b), next(b)]
    assert c == a


# Generated at 2022-06-21 12:15:27.409534
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    with raises(TypeError):
        MapList(lambda x: x, []).__len__()


# Generated at 2022-06-21 12:15:29.971415
# Unit test for function chunk
def test_chunk():
    t = [x for x in chunk(3, range(5))]
    assert t == [[0, 1, 2], [3, 4]]



# Generated at 2022-06-21 12:15:35.504939
# Unit test for constructor of class MapList
def test_MapList():
    lst = [0, 1, 2]
    assert list(MapList(lambda x: x, lst)) == [0, 1, 2]
    assert list(MapList(lambda x: x + 1, lst)) == [1, 2, 3]
    assert list(MapList(lambda x: x * x, lst)) == [0, 1, 4]



# Generated at 2022-06-21 12:15:45.515585
# Unit test for constructor of class LazyList
def test_LazyList():
    assert isinstance(LazyList([]), LazyList)
    assert isinstance(LazyList(iter([])), LazyList)
    assert isinstance(LazyList(range(10)), LazyList)
    assert isinstance(LazyList(x for x in range(10)), LazyList)
    assert isinstance(LazyList((1, 2, 3)), LazyList)
    assert isinstance(LazyList([1, 2, 3]), LazyList)
    assert isinstance(LazyList(set((1, 2, 3))), LazyList)
    assert isinstance(LazyList({1, 2, 3}), LazyList)
    assert isinstance(LazyList({1: 2, 3: 4, 5: 6}.keys()), LazyList)

# Generated at 2022-06-21 12:15:48.777502
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = [1, 2, 3]
    assert len(MapList(lambda x: x, lst)) == 3

# Generated at 2022-06-21 12:16:00.619963
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(10)) == list(range(10))
    assert list(Range(1, 10 + 1)) == list(range(1, 10 + 1))
    assert list(Range(1, 11, 2)) == list(range(1, 11, 2))

    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-4] == 6

    assert all(r[idx] == idx for idx in range(10))
    assert r[-1: 1: -2] == [9, 7, 5, 3]

# Generated at 2022-06-21 12:16:05.501716
# Unit test for function chunk
def test_chunk():
    assert list(chunk(2, [])) == []
    assert list(chunk(2, [1])) == [[1]]
    assert list(chunk(2, [1, 2])) == [[1, 2]]
    assert list(chunk(2, [1, 2, 3])) == [[1, 2], [3]]



# Generated at 2022-06-21 12:16:08.941510
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    range_ = Range(start=0, stop=10, step=1)
    assert [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] == list(range_)

# Generated at 2022-06-21 12:16:50.947371
# Unit test for function split_by
def test_split_by():
    # test criterion
    assert list(split_by([1,2,3,4,5,6], criterion=lambda x: x%3==0)) == [[1,2], [4,5]]
    assert list(split_by([1,3,3,4,5,6], criterion=lambda x: x%3==0)) == [[1], [4,5]]
    assert list(split_by([1,2,3,4,5,6], criterion=lambda x: x%3==0, empty_segments=True)) == [[1,2], [], [4,5]]
    # test separator
    assert list(split_by([1,2,3,4,5,6], separator=3)) == [[1,2], [4,5,6]]

# Generated at 2022-06-21 12:16:58.830966
# Unit test for method __len__ of class Range
def test_Range___len__():
    test_cases = [
        (0, 0, 1),
        (0, 0, 10),
        (10, 0, -1),
        (10, 0, -2),
        (1, 10, 1),
        (1, 10, 2),
        (1, 10, 3),
        (1, 10, 4),
        (1, 10, 5),
        (1, 10, 6),
        (1, 10, 7),
        (1, 10, 8),
        (1, 10, 9),
    ]
    for start, end, step in test_cases:
        r = Range(start, end, step)
        assert len(r) == (end - start) // step

# Generated at 2022-06-21 12:17:04.517824
# Unit test for constructor of class Range
def test_Range():
    assert len(Range(10)) == 10

    with pytest.raises(ValueError):
        Range()  # pylint: disable=E1120

    with pytest.raises(ValueError):
        Range(1, 2, 3, 4)  # pylint: disable=E1120

    with pytest.raises(ValueError):
        Range(1, 2, 0)  # pylint: disable=E1120
