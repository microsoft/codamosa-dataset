

# Generated at 2022-06-21 12:07:26.386482
# Unit test for function drop
def test_drop():
    iter1 = range(1000000)
    drop(5,iter1)
    drop(10,iter1)
    drop(5,iter1)
    drop(10,iter1)
    drop(5,iter1)
    drop(10,iter1)

test_drop()


# Generated at 2022-06-21 12:07:35.567372
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7])) == [6, 7]
    assert list(drop_until(lambda x: x > 5, [4, 5, 6, 7])) == [6, 7]



# Generated at 2022-06-21 12:07:44.958143
# Unit test for function scanl
def test_scanl():
    def f(x, y):
        return x + y
    def g(x, y):
        return x + y
    def h(x, y):
        return x + y
    def k(x, y):
        return x + y
    return scanl(f, [1])
    return scanl(f, [1, 2, 3], 0)
    return scanl(g, ['a'])
    return scanl(g, ['a', 'b', 'c'])
    return scanl(h, [1, 2, 3, 4, 5], 0)
    return scanl(k, ['a', 'b', 'c', 'd', 'e', 'f'])


# Generated at 2022-06-21 12:07:51.405129
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[0] == 0
    assert Range(10)[-1] == 9
    assert Range(10)[4] == 4
    assert Range(10)[1:4] == [1, 2, 3]
    assert Range(10)[4:1:-1] == [4, 3, 2]
    assert Range(10)[4:2:-1] == [4, 3]
    assert Range(1, 10)[0] == 1
    assert Range(1, 10)[-1] == 9
    assert Range(1, 10)[-2] == 8
    assert Range(1, 10)[1:4] == [2, 3, 4]
    assert Range(1, 10)[4:1:-1] == [5, 4, 3]
    assert Range(1, 10)[4:2:-1] == [5, 4]


# Generated at 2022-06-21 12:07:55.980445
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, range(10))) == [0, 1, 3, 6, 10, 15, 21, 28, 36, 45]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], -10)) == [-10, -9, -7, -4, -1]



# Generated at 2022-06-21 12:08:01.547887
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: 2 * x, [1, 2, 3, 4, 5])) == [2, 4, 6, 8, 10]
    assert MapList(lambda x: 2 * x, [1, 2, 3, 4, 5])[2:4] == [6, 8]


# Generated at 2022-06-21 12:08:03.553648
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    a = MapList(lambda x: 2 * x, [1, 2, 3])
    assert len(a) == 3

# Generated at 2022-06-21 12:08:14.372349
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    def __iter__(self):
        if self.exhausted:
            return iter(self.list)
        return self.LazyListIterator(self)

    class LazyList(Generic[T], Sequence[T]):
        # ...
        class LazyListIterator:
            def __init__(self, lst: 'LazyList[T]'):
                self.list = weakref.ref(lst)
                self.index = 0

            def __iter__(self):
                return self

            def __next__(self):
                try:
                    obj = self.list()[self.index]
                except IndexError:
                    raise StopIteration
                self.index += 1
                return obj

        def __init__(self, iterable: Iterable[T]):
            self.iter = iter(iterable)


# Generated at 2022-06-21 12:08:17.884471
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    '''
    Unit test for method __len__ of class MapList
    '''
    m = MapList(lambda x: x + 1, [])
    assert len(m) == 0

# Generated at 2022-06-21 12:08:19.888073
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = (MapList(int, [0, 0, 0]))
    assert lst.__len__() == 3



# Generated at 2022-06-21 12:08:40.191396
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5,10))
    assert list(drop(10, range(5))) == []
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(-1, range(10))) == list(range(10))
    assert list(drop(3, map(lambda x: x * x, range(10)))) == [9, 16, 25, 36, 49, 64, 81]
    assert list(drop(3, 'abcdefg')) == list('defg')
    assert list(drop(5, [1, 2, 3, 4])) == [1, 2, 3, 4]
    assert list(drop(5, [1, 2, 3, 4, 5, 6])) == [6]

# Generated at 2022-06-21 12:08:45.416457
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:08:50.840636
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert list(r[0:10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    r = Range(1, 10 + 1)
    assert list(r[:]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    r = Range(1, 10 + 1)
    assert list(r[:100]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    r = Range(1, 10 + 1)
    assert list(r[10:]) == []
    r = Range(1, 10 + 1)
    assert list(r[20:]) == []
    r = Range(1, 10 + 1)

# Generated at 2022-06-21 12:08:58.809515
# Unit test for constructor of class MapList
def test_MapList():
    a = [1,2,3,4,5]
    b = [2,3,4,5,6]
    assert len(MapList(lambda x: x * x, a)) == 5
    assert len(MapList(lambda i: a[i] * b[i], Range(len(a)))) == 5
    lst = MapList(lambda i: a[i] * b[i], Range(len(a)))
    assert lst[0] == 2
    assert lst[1] == 6
    assert lst[2] == 12
    assert lst[3] == 20
    assert lst[4] == 30
    assert lst[-5] == 2
    assert lst[-4] == 6
    assert lst[-3] == 12
    assert lst[-2] == 20

# Generated at 2022-06-21 12:08:59.468015
# Unit test for method __next__ of class Range
def test_Range___next__():
    pass

# Generated at 2022-06-21 12:09:05.500278
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:09:11.481085
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for start, stop, step in [(0, 10, 1), (10, 0, -1), (0, 10, 2)]:
        it = iter(Range(start, stop, step))
        for i in range(start, stop, step):
            assert next(it) == i
        with pytest.raises(StopIteration):
            next(it)

# Generated at 2022-06-21 12:09:14.294443
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x: x * x, [random.randint(0, 10) for _ in range(1000)])
    assert len(lst) == len(list(lst))
    assert len(lst) == len(list(lst))
test_MapList___len__()


# Generated at 2022-06-21 12:09:23.666887
# Unit test for function chunk
def test_chunk():
    # Basic usage
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    # n < 0
    try:
        list(chunk(-1, range(10)))
        assert False
    except ValueError:
        assert True
    # n == 0
    try:
        list(chunk(0, range(10)))
        assert False
    except ValueError:
        assert True
    # n == len(iterable)
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    # n > len(iterable)

# Generated at 2022-06-21 12:09:25.858976
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-21 12:09:43.574759
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    # Test cases
    # Test case 1
    nums = [1, 2, 3, 4, 5]
    transformed_nums = MapList(lambda num: num * num, nums)
    assert len(transformed_nums) == len(nums)

    # Test case 2
    nums = [1, 2, 3]
    transformed_nums = MapList(lambda num: num * num, nums)
    assert len(transformed_nums) == len(nums)

    # Test case 3
    nums = [1, 2, 3, 4, 5]
    transformed_nums = MapList(lambda num: num + num, nums)
    assert len(transformed_nums) == len(nums)

    # Test case 4
    nums = [1, 2, 3]
    transformed_

# Generated at 2022-06-21 12:09:45.800838
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList(range(3))
    assert list(l.__iter__()) == [0, 1, 2]



# Generated at 2022-06-21 12:09:46.866646
# Unit test for constructor of class LazyList
def test_LazyList():
    LazyList(range(5))


# Generated at 2022-06-21 12:09:55.862962
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, (1, 2, 3, 4))) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, 'abcd')) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(operator.add, 'abcde')) == [15, 14, 12, 9, 5, 0]
    assert list(scanr(operator.add, 'abcde', 100)) == [115, 114, 112, 109, 105, 100]



# Generated at 2022-06-21 12:10:01.822761
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:10:07.719920
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5
    assert len(Range(0, 10 - 1, -1)) == 10
    assert len(Range(3, -1, -1)) == 4



# Generated at 2022-06-21 12:10:19.699727
# Unit test for function split_by
def test_split_by():
    assert tuple(split_by([1, 2, 3, 4, 5, 6], criterion=lambda x: x % 3 == 0)) == ([1, 2], [4, 5], [])
    assert tuple(split_by([1, 2, 3, 4, 5, 6], empty_segments=True, criterion=lambda x: x % 3 == 0)) == \
           ([1, 2], [4, 5], [])
    assert tuple(split_by(range(10), criterion=lambda x: x % 3 == 0)) == ([1, 2], [4, 5], [7, 8])
    assert tuple(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) == \
           ([1, 2], [4, 5], [7, 8], [])

# Generated at 2022-06-21 12:10:26.158403
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(0, 7, 2)[0] == 0
    assert Range(0, 7, 2)[1] == 2
    assert Range(0, 7, 2)[-1] == 6
    assert Range(0, 7, 2)[-2] == 4
    assert Range(0, 7, 2)[::-1] == [6, 4, 2, 0]
    assert Range(0, 7, 2)[-5:5] == [0, 2, 4]



# Generated at 2022-06-21 12:10:34.745013
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([0, 1, 2, 3, 4, 5, 6, 7, 8])
    assert lst[:] == [0, 1, 2, 3, 4, 5, 6, 7, 8]
    assert lst[1:4] == [1, 2, 3]
    assert len(lst) == 9
    assert lst[1:3:2] == [1]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[:3] == [0, 1, 2]
    assert lst[::1] == [0, 1, 2, 3, 4, 5, 6, 7, 8]
    assert lst

# Generated at 2022-06-21 12:10:38.310585
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(100))
    for i, v in enumerate(lst):
        assert v == i
        assert len(lst.list) == i + 1

# Generated at 2022-06-21 12:10:51.980236
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    from unittest import TestCase

    from .__unused import TestCase
    from .test_method___iter__ import TestCase as TestCase_method___iter__

    class Case(TestCase_method___iter__[MapList[int], Iterator[int]], TestCase):
        def build_object(self) -> MapList[int]:
            return MapList(lambda x: x * x, [1, 2, 3])

    Case().run()

# Generated at 2022-06-21 12:10:53.242490
# Unit test for method __next__ of class Range
def test_Range___next__():
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-21 12:10:55.982294
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    l = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x*x, l)[1] == 4
    assert MapList(lambda x: x*x, l)[0:3] == [1, 4, 9]
    

# Generated at 2022-06-21 12:10:58.152875
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    insta = Range(1, 10, 2)
    instb = Range(1, 10, 2)
    insta = iter(insta)
    assert isinstance(insta, Iterator)

# Generated at 2022-06-21 12:11:09.533668
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():    
    l_0_to_10_slice0_1 = Range(0, 11, 1)[0:1]
    assert l_0_to_10_slice0_1 == [0]
    l_0_to_10_slice_6_end = Range(0, 11, 1)[6:]
    assert l_0_to_10_slice_6_end == [6, 7, 8, 9, 10]
    l_0_to_10_slice_10 = Range(0, 11, 1)[10]
    assert l_0_to_10_slice_10 == 10
    l_0_to_10_slice_neg_6 = Range(0, 11, 1)[-6]
    assert l_0_to_10_slice_neg_6 == 6
    l_0_to_10_slice_neg_

# Generated at 2022-06-21 12:11:13.363206
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1,2,3,4,5]
    x = MapList(lambda x: x * x, a)
    assert x[3] == 16
    assert x[-1] == 25
    assert x[0:2] == [1,4]

# Generated at 2022-06-21 12:11:20.749369
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, []) == []
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'e') == ['abcde', 'bcde', 'cde', 'de', 'e']



# Generated at 2022-06-21 12:11:24.135094
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(1,2)) == 1
    assert next(Range(1,2,2)) == 1
    with pytest.raises(StopIteration):
        next(Range(-1,1,2))



# Generated at 2022-06-21 12:11:25.974205
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    m = MapList(lambda x: x*x, [1, 2, 3, 4, 5])
    _compare_show(m[2], 9)
    _compare_show(m[-1], 25)
    _compare_show(m[0:2], [1, 4])

# Generated at 2022-06-21 12:11:29.497466
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(5, range(5))) == []
    assert list(drop(5, range(4))) == []



# Generated at 2022-06-21 12:11:37.890371
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[2] == 2
    assert lst[2] == 2  # should not be evaluated again
    assert lst[-1] == 9
    assert lst[:2] == [0, 1]
    assert lst[-1:] == [9]
    assert lst[-3:] == [7, 8, 9]



# Generated at 2022-06-21 12:11:44.824962
# Unit test for function chunk

# Generated at 2022-06-21 12:11:46.975568
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(map(int,Range(10))) == list(range(11))

# Generated at 2022-06-21 12:11:49.402765
# Unit test for method __next__ of class Range
def test_Range___next__():
    r=Range(1,10+1)
    for x in range(10):
        assert next(r) == x+1

# Generated at 2022-06-21 12:11:52.484844
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    m = MapList(lambda i: a[i] * a[i], Range(len(a)))
    assert m[0] == a[0] * a[0]
    assert m[2] == a[2] * a[2]
    assert m[4] == a[4] * a[4]
    assert m[-1] == a[-1] * a[-1]



# Generated at 2022-06-21 12:11:54.865010
# Unit test for method __next__ of class Range
def test_Range___next__():
    obj = Range(42)
    for i in range(40):
        assert next(obj) == i
    assert next(obj) == 42
    with pytest.raises(StopIteration):
        next(obj)
    with pytest.raises(StopIteration):
        next(obj)


# Generated at 2022-06-21 12:12:04.798881
# Unit test for function chunk
def test_chunk():
    for n in [1, 2, 3, 5, 10]:
        assert list(chunk(n, range(1 * n))) == [list(range(n))] * 1
        assert list(chunk(n, range(2 * n))) == [list(range(n))] * 2
        assert list(chunk(n, range(4 * n))) == [list(range(n))] * 4
    for n in [-3, -2, -1, 0]:
        with pytest.raises(ValueError):
            chunk(n, range(5))
# Test the function by running the pytest framework
test_chunk()



# Generated at 2022-06-21 12:12:15.686954
# Unit test for method __next__ of class Range
def test_Range___next__():
    def _test_Range___next__(
        t_range=None,
        t_range_after=None,
        t_range_next=None,
    ):
        t_range.__next__()
        assert (t_range == t_range_after)
        assert (t_range.__next__() == t_range_next)
    t_range = Range(0, 10, 2)
    t_range_after = Range(0, 10, 2)
    t_range_next = 2
    _test_Range___next__(
        t_range=t_range,
        t_range_after=t_range_after,
        t_range_next=t_range_next,
    )

    t_range = Range(1, 11, 2)

# Generated at 2022-06-21 12:12:18.397142
# Unit test for function take
def test_take():
    seq = range(10)
    actual = list(take(5, seq))
    expected = [0, 1, 2, 3, 4]
    assert actual == expected



# Generated at 2022-06-21 12:12:25.987972
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Test for non-empty iterator
    r = Range(1, 10)
    result = []
    for i in r:
        result.append(i)
    assert result == list(range(1, 10))

    # Test for empty iterator
    r = Range(0)
    result = []
    for i in r:
        result.append(i)
    assert result == []

# Generated at 2022-06-21 12:12:36.478573
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(20, range(10))) == list(range(10))



# Generated at 2022-06-21 12:12:39.649888
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5]) == [1, 4, 9, 16, 25]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2:4] == [9, 16]

# Generated at 2022-06-21 12:12:46.968720
# Unit test for function scanl
def test_scanl():
    from operator import add
    from functools import partial
    from itertools import accumulate

    assert list(accumulate(range(5), add)) == list(scanl(add, range(5)))

    assert list(accumulate('abc', partial(add, 's'))) == list(scanl(partial(add, 's'), 'abc'))

    assert [0, 1, 3, 6, 10] == list(scanl(add, range(5), 0))

    assert ['a', 'ba', 'cba', 'dcba'] == list(scanl(lambda s, x: x + s, 'abcd'))


# Generated at 2022-06-21 12:12:55.609598
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(3)
    assert len(r) == 3
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 2
    assert list(r) == [0, 1, 2]
    r = Range(1, 4)
    assert len(r) == 3
    assert r[0] == 1
    assert r[1] == 2
    assert r[2] == 3
    assert r[-1] == 3
    assert list(r) == [1, 2, 3]
    r = Range(1, 5, 2)
    assert len(r) == 2
    assert r[0] == 1
    assert r[1] == 3
    assert r[-1] == 3

# Generated at 2022-06-21 12:12:57.701916
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x, [1, 2, 3])) == 3


# Generated at 2022-06-21 12:13:05.637502
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    for lst in [[1, 2, 3, 4], range(10)]:
        assert isinstance(iter(LazyList(lst)), LazyList.LazyListIterator)
        assert isinstance(iter(iter(LazyList(lst))), LazyList.LazyListIterator)
        assert len(set(LazyList(lst))) == len(set(lst))
        assert set(LazyList(lst)) == set(lst)
        if len(lst) >= 4:
            assert LazyList(lst)[2] == lst[2]
            assert LazyList(lst)[2:4] == lst[2:4]
            assert LazyList(lst)[-1] == lst[-1]

# Generated at 2022-06-21 12:13:08.983240
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = [1, 2, 3, 4, 5]
    lst = MapList(lambda x: x * x, lst)
    assert len(lst) == 5



# Generated at 2022-06-21 12:13:14.273625
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:13:16.047356
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(100))
    assert len(lst[0:100]) == 100
    assert lst[0] == 0
    assert len(lst[0:10]) == 10
    assert lst[-1] == 99



# Generated at 2022-06-21 12:13:18.103705
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert isinstance(Range(0, 10)[0], int) and isinstance(Range(0, 10)[0], int)



# Generated at 2022-06-21 12:13:30.336787
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for n in range(11):
        for i in range(10):
            assert i * n == MapList(lambda x: x * n, range(10))[i]

    for n in range(11):
        for i in range(10):
            assert sum(range(i * n, i * n + n)) == sum(MapList(
                lambda x: x, range(i * n, i * n + n)))

# Generated at 2022-06-21 12:13:41.085699
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2, 3, 4, 5, 6], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5]]
    assert list(split_by([1, 2, 3, 4, 5], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5]]
    assert list(split_by([1, 2, 3, 4, 5], criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5]]
    assert list(split_by([1, 2, 3, 4, 5], criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5]]

# Generated at 2022-06-21 12:13:47.020221
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:13:53.823696
# Unit test for constructor of class LazyList
def test_LazyList():
    with pytest.raises(TypeError):
        len(LazyList(range(1)))
    lazyList = LazyList(range(100))
    assert lazyList[-1] == 99
    assert lazyList[30] == 30
    assert len(lazyList) == 100
    assert lazyList[:] == range(100)
    assert list(lazyList[50:]) == list(range(50, 100))
    assert list(lazyList[:30]) == list(range(30))
    assert list(lazyList[15:30]) == list(range(15, 30))



# Generated at 2022-06-21 12:14:04.219924
# Unit test for method __next__ of class Range
def test_Range___next__():
    from pytest import raises
    from . import fn
    from .core import Function
    from .core import IO
    from .core import Identity
    from .core import Monad
    from .core import MonadError
    from .core import Nothing
    from .core import Reader
    from .core import State
    from .core import Writer
    from .fp import todo
    from .fp import todo_m
    from .fp import todo_error
    from .fp import todo_error_m
    from .fp import identity
    from .fp import identity_m
    from .fp import identity_error
    from .fp import identity_error_m
    import builtins
    import typing
    # pylint: disable=import-error
    import hypothesis
    import hypothesis.strategies
    import pytest


# Generated at 2022-06-21 12:14:13.990049
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from nose.tools import assert_equal, assert_sequence_equal
    from .functional import identity

    assert_sequence_equal(list([]), [])
    assert_sequence_equal(list(LazyList(range(3))), [0, 1, 2])
    assert_sequence_equal(list(LazyList([])), [])
    assert_sequence_equal(list(LazyList(iter([1, 2, 3]))), [1, 2, 3])

    assert_equal(identity(list(LazyList(range(3)))), list(range(3)))

    assert_sequence_equal(list(iter(LazyList(range(3)))), [0, 1, 2])
    assert_sequence_equal(list(iter(LazyList(LazyList(range(3))))), [0, 1, 2])




# Generated at 2022-06-21 12:14:15.946221
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(5))) == list(range(5))
    assert list(drop(5, range(5))) == []
    assert list(drop(6, range(5))) == []



# Generated at 2022-06-21 12:14:20.422558
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(Range(10)) == list(range(10))
    assert list(Range(1, 10 + 1)) == list(range(1, 10 + 1))
    assert list(Range(1, 11, 2)) == list(range(1, 11, 2))

# Generated at 2022-06-21 12:14:33.092652
# Unit test for constructor of class LazyList
def test_LazyList():
    with pytest.raises(TypeError):
        len(LazyList([0, 1, 2, 3]))

    lst = LazyList([0, 1, 2, 3])
    for i in range(4):
        assert lst[i] == i
    for i in range(4, 8):
        with pytest.raises(IndexError):
            lst[i]

    expected_list = [0, 1, 2, 3]
    for x, y in zip(lst, expected_list):
        assert x == y
    for x, y in zip(lst, expected_list):
        assert x == y
    for x, y in zip(lst, expected_list):
        assert x == y

    assert lst[:2] == expected_list[:2]

# Generated at 2022-06-21 12:14:33.449815
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass



# Generated at 2022-06-21 12:14:55.626582
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5]) == [1, 4, 9, 16, 25]



# Generated at 2022-06-21 12:14:57.879285
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x + 1, [1, 2, 3])[2] == 4

# Generated at 2022-06-21 12:15:00.455239
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from .test_util import assert_iterable_equal
    assert_iterable_equal(LazyList([1, 2, 3]), [1, 2, 3])


# Generated at 2022-06-21 12:15:03.798008
# Unit test for method __len__ of class Range
def test_Range___len__():
    print("This is function test_Range___len__")
    assert len(Range(0, 8, 2)) == 4, "Test _Range__len__ failed."
    print("Test _Range__len__ passed.")

# Generated at 2022-06-21 12:15:08.968501
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    r"""Test method __iter__ of class LazyList"""
    list1 = LazyList(iter(range(100)))
    list2 = list(list1)
    assert all([x == y for x, y in zip(list2, range(100))])
test_LazyList___iter__()


# Generated at 2022-06-21 12:15:13.754092
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    """
    Test method __iter__ of class LazyList
    """
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert lst.list == list(range(10))


# Generated at 2022-06-21 12:15:22.665966
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)
    assert isinstance(r, Iterator)
    assert r.__next__() == 0
    assert r.__next__() == 1
    assert r.__next__() == 2
    assert r.__next__() == 3
    assert r.__next__() == 4
    assert r.__next__() == 5
    assert r.__next__() == 6
    assert r.__next__() == 7
    assert r.__next__() == 8
    assert r.__next__() == 9
    with pytest.raises(StopIteration):
        r.__next__()
    with pytest.raises(StopIteration):
        r.__next__()
    with pytest.raises(StopIteration):
        r.__next__()



# Generated at 2022-06-21 12:15:33.231417
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(2, [])) == []
    assert list(chunk(2, [1])) == [[1]]
    assert list(chunk(2, [1, 2])) == [[1, 2]]
    assert list(chunk(2, [1, 2, 3])) == [[1, 2], [3]]


# Generated at 2022-06-21 12:15:42.393376
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [3, 6, 5])) == [6, 5]
    assert list(drop_until(lambda x: x > 5, [5, 6, 5])) == [5, 6, 5]
    assert list(drop_until(lambda x: x > 5, [6, 5, 6])) == [6, 5, 6]



# Generated at 2022-06-21 12:15:54.222275
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(1, range(10))) == [0]
    assert list(take(4, range(10))) == [0, 1, 2, 3]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(100, range(10))) == list(range(10))
    assert list(take(0, 'abcdefg')) == []
    assert list(take(1, 'abcdefg')) == ['a']
    assert list(take(4, 'abcdefg')) == ['a', 'b', 'c', 'd']
    assert list(take(10, 'abcdefg')) == list('abcdefg')

# Generated at 2022-06-21 12:16:18.972698
# Unit test for method __next__ of class Range
def test_Range___next__():
    def f():
        r = Range(3)
        assert next(r) == 0
        assert next(r) == 1
        assert next(r) == 2
        from StopIteration import StopIteration
        try:
            next(r)
        except StopIteration:
            pass
        else:
            assert False
    f()


# Generated at 2022-06-21 12:16:21.100358
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    # Verify for value in {[],[0]}
    assert len(MapList(lambda x: x * x, [])) == 0



# Generated at 2022-06-21 12:16:23.348405
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]



# Generated at 2022-06-21 12:16:25.699975
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert sum(LazyList(range(10))) == 45
    assert sum(LazyList(range(10))) == 45
    assert sum(LazyList(range(10))) == 45

# Generated at 2022-06-21 12:16:35.712597
# Unit test for function drop
def test_drop():
    from itertools import chain
    from operator import itemgetter
    seq = [2, 3, 5, 7, 11, 13]
    for n in range(len(seq) + 1):
        assert list(drop(n, seq)) == seq[n:]
    assert list(drop(0, chain(seq, seq))) == seq * 2
    assert list(drop(1, range(100))) == list(range(1, 100))
    assert list(drop(1, (x for x in seq))) == seq[1:]
    assert list(drop(99, (x for x in seq))) == []
    assert list(drop(0, (x for x in seq))) == seq
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []

# Generated at 2022-06-21 12:16:36.507844
# Unit test for function drop_until
def test_drop_until():
    return drop_until(lambda x: x >= 3, range(10))



# Generated at 2022-06-21 12:16:41.205744
# Unit test for constructor of class Range
def test_Range():
    # start, stop, step
    assert Range(1, 10 + 1, 1) == range(1, 10 + 1, 1)
    assert Range(1, 11, 2) == range(1, 11, 2)
    assert Range(1, 10, 3) == range(1, 10, 3)
    assert Range(10) == range(10)
    assert Range(1, 10) == range(1, 10)


# Generated at 2022-06-21 12:16:47.541575
# Unit test for constructor of class MapList
def test_MapList():
    a = [2, 3, 5, 9]
    map_list = MapList(lambda x: x * x + 1, a)

    assert map_list[0] == 3
    assert map_list[1] == 10
    assert map_list[2] == 26

    assert map_list[0:1] == [3]
    assert map_list[0:4] == [3, 10, 26, 82]



# Generated at 2022-06-21 12:16:56.364508
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    test_cases = [
        {'input': (lambda x: x, a), 'output': (1, 2, 3, 4, 5), 'count': 5},
        {'input': (lambda x: x * x, a), 'output': (1, 4, 9, 16, 25), 'count': 5},
        {'input': (lambda i: a[i] * b[i], Range(len(a))), 'output': (2, 6, 12, 20, 30), 'count': 5},
    ]
    for test_case in test_cases:
        func, lst = test_case['input'], test_case['output']
        res = test_case['output']
        it = MapList

# Generated at 2022-06-21 12:17:03.023900
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from abc import ABC
    source = [1, 2, 3]
    lst = LazyList(source)
    assert list(lst) == source

    lst = LazyList(lst)
    assert list(lst) == source

    assert isinstance(lst.__iter__(), LazyList.LazyListIterator)
    assert not isinstance(lst.__iter__(), ABC)

    lst = LazyList(lst[0:1])
    assert list(lst) == [1]

