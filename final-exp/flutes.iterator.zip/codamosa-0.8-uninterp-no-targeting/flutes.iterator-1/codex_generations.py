

# Generated at 2022-06-21 12:07:26.630782
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    for x in MapList(lambda x: x * x, [1, 2, 3, 4, 5]):
        print(x, end=' ')



# Generated at 2022-06-21 12:07:30.171745
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']


# Generated at 2022-06-21 12:07:40.295531
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # initialization
    r = Range(1, 10 + 1)
    # test Range.__getitem__(idx)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    # test Range.__getitem__(slice)
    assert r[0:6:2] == [1, 5]
    assert r[2::2] == [5, 9]
    assert r[::2] == [1, 5, 9]
    assert r[3:-1:2] == [7]
    assert r[::-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]

# Generated at 2022-06-21 12:07:43.293243
# Unit test for constructor of class LazyList
def test_LazyList():
    test_list = list(range(10))
    test_result = LazyList(test_list)
    assert test_list == list(test_result)
    assert test_list == list(test_result)


# Generated at 2022-06-21 12:07:46.858864
# Unit test for function drop
def test_drop():
    assert list(drop(0, iter([1, 2, 3]))) == [1, 2, 3]
    assert list(drop(1, iter([1, 2, 3]))) == [2, 3]
    assert list(drop(3, iter([1, 2, 3]))) == []



# Generated at 2022-06-21 12:07:55.396411
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.mul, [], 'a')) == ['a']
    assert list(scanl(operator.mul, [1])) == [1]
    assert list(scanl(operator.mul, [], [])) == [None]



# Generated at 2022-06-21 12:08:04.232503
# Unit test for function split_by
def test_split_by():
    s = "Split by: "
    assert list(split_by(s, criterion=lambda c: c == ':', empty_segments=True)) == [['S', 'p', 'l', 'i', 't'], [' '],
                                                                                  ['b', 'y'], []]
    assert list(split_by(s, criterion=lambda c: c == ' ', empty_segments=True)) == [['S'], ['p'], ['l'], ['i'], ['t'],
                                                                                   [], ['b'], ['y'], [], []]



# Generated at 2022-06-21 12:08:06.170921
# Unit test for constructor of class Range
def test_Range():
    assert Range(1,10,2) == [1, 3, 5, 7, 9]


# Generated at 2022-06-21 12:08:17.165438
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import unittest
    class TestLazyList___iter__(unittest.TestCase):
        def test_LazyList___iter__(self):
            from .testing import assert_raises
            from .testing import assert_lists_equal
            from .testing import assert_raises
            from .testing import assert_lists_equal
            assert_raises(TypeError, iter, LazyList([]))
            assert_lists_equal(list(iter(LazyList([1, 2, 3]))), [1, 2, 3])
            assert_lists_equal(list(iter(LazyList([1, 2, 3]).__iter__())), [1, 2, 3])
            assert_lists_equal(list(iter(LazyList([1, 2, 3]).__iter__())), [1, 2, 3])

# Generated at 2022-06-21 12:08:23.610492
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import pytest
    from random import randint

    def func(x):
        return x + 1

    def check_element(a, idx):
        assert MapList(func, a)[idx] == a[idx] + 1

    def check_list(a):
        b = MapList(func, a)
        assert len(b) == len(a)
        for i in range(len(a)):
            assert b[i] == a[i] + 1

    a = [randint(-100, 100) for _ in range(100)]
    for param in (a, list(a)):
        for cnt in range(100):
            idx = randint(0, len(a) - 1)
            check_element(param, idx)
            check_element(tuple(param), idx)

# Generated at 2022-06-21 12:08:38.697716
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10, 12)
    res = []
    try:
        while True:
            res.append(next(r))
    except StopIteration:
        assert res == [10, 11]
    else:
        raise AssertionError("The range should have been exhausted")

# Generated at 2022-06-21 12:08:48.788164
# Unit test for constructor of class LazyList
def test_LazyList():
    l = LazyList([1, 4, 6, 8, 10, 12, 14, 16, 18 ])
    assert isinstance(l, LazyList)
    assert isinstance(l, Sequence)
    assert l[0] == 1
    assert l[3] == 8
    assert [item for item in l] == [1, 4, 6, 8, 10, 12, 14, 16, 18]
    assert l[-1] == 18
    # out of bound access
    assert l[9] is None
    assert l[10] is None
    assert l[100] is None
    # testing __iter__
    itr = l.__iter__()
    assert next(itr) == 1
    assert next(itr) == 4
    assert next(itr) == 6
    assert next(itr) == 8
   

# Generated at 2022-06-21 12:08:51.774627
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_obj = Range(1, 4, 1)
    assert next(range_obj) == 1
    assert next(range_obj) == 2


# Generated at 2022-06-21 12:08:53.683106
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    x = LazyList([0, 1, 2, 3, 4, 5])
    assert len(x) == 6



# Generated at 2022-06-21 12:09:01.385945
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    try:
        next(scanl(operator.add, [1, 2, 3, 4]))
        assert False, "scanl doesn't accept 0 args"
    except StopIteration:
        assert True


# Generated at 2022-06-21 12:09:07.863737
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4, 0]
    assert list(scanr(operator.add, [], 1)) == [1]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:09:10.375108
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)
    assert next(r) == 0
    assert next(r) == 1


# Generated at 2022-06-21 12:09:20.623279
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)
    assert list(r) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    r = Range(1, 10 + 1)
    assert list(r) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    r = Range(1, 11, 2)
    assert list(r) == [1, 3, 5, 7, 9]
    assert r[0] == 1
    assert r[3] == 7
    assert [r[i] for i in range(2)] == [1, 3]
    assert [r[i] for i in range(-2)] == [9, 7]
    assert [r[i] for i in range(0, 2)] == [1, 3]

# Generated at 2022-06-21 12:09:28.438668
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst.__iter__()) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    lst = LazyList(range(10000))
    assert list(lst.__iter__()) == list(range(10000))

    it = lst.__iter__()
    assert next(it) == 0
    assert list(it) == list(range(1, 10000))



# Generated at 2022-06-21 12:09:29.780504
# Unit test for function drop
def test_drop():
    # TODO: implement your tests here
    pass
# Test helper function

# Generated at 2022-06-21 12:09:54.338716
# Unit test for method __next__ of class Range
def test_Range___next__():

    ip = [[0,1,1]]
    temp_r = Range(0, 1, 1)
    ip_0 = 0
    r_0 = None
    ip_1 = 1
    r_1 = None
    ip_2 = 2
    r_2 = None

    r_0 = ip[ip_0][ip_1]
    r_2 = ip[ip_0][ip_2]
    r_1 = temp_r.__next__()

    assert r_0 == r_1
    assert r_0 == r_2



# Generated at 2022-06-21 12:09:59.851917
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10, 2)
    assert next(r) == 1
    assert next(r) == 3
    assert next(r) == 5
    assert next(r) == 7
    assert next(r) == 9
    try:
        next(r)
    except StopIteration:
        pass


# Generated at 2022-06-21 12:10:07.739377
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from random import randint
    from random import randrange
    from random import seed
    from random import shuffle
    from .check import check_LazyList
    from .check import check_number
    from .check import check_number_list
    from .check import check_property
    from .check import correct_type
    from .check import incorrect_type
    from .check import random_LazyList
    from .check import random_LazyList_iterable
    from .check import random_LazyList_iterable_end
    from .check import random_LazyList_iterable_start
    from .check import random_LazyList_iterable_start_end
    from .check import random_number
    from .check import random_number_list
    seed(0)

# Generated at 2022-06-21 12:10:10.384341
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList([1, 2, 3])) == [1, 2, 3]



# Generated at 2022-06-21 12:10:11.666129
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x: x, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert len(lst) == 10
test_MapList___len__()

# Generated at 2022-06-21 12:10:13.405213
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5
    assert len(Range(8, -5, -3)) == 4


# Generated at 2022-06-21 12:10:16.888799
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3, 4, 5, 6, 7, 8, 9])
#     try:
#         len(lst)
#     except TypeError:
#         pass
#     else:
#         raise AssertionError
    lst = LazyList(range(1000))
    assert lst[-1] == 999
    assert len(lst) == 1000

# Generated at 2022-06-21 12:10:23.142925
# Unit test for function scanl
def test_scanl():
    from operator import add
    from functools import reduce
    from random import randrange
    for _ in range(100):
        l = [randrange(10) for _ in range(10)]
        if not list(scanl(add, l)) == list(scanl(add, l, 0)):
            raise AssertionError()



# Generated at 2022-06-21 12:10:29.157884
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():

    # Sample data
    lst = [1, 2, 3, 4, 5]
    func = lambda x: str(x + 1)

    # Expected values
    expected_list = ['2', '3', '4', '5', '6']
    expected_length = 5

    # Function to be tested
    map_list = MapList(func, lst)

    # Tests
    list = []
    for x in map_list:
        list.append(x)
    assert list == expected_list
    assert len(map_list) == expected_length



# Generated at 2022-06-21 12:10:35.091772
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    assert [i for i in r] == list(range(10))

    r = Range(1, 10)
    assert [i for i in r] == list(range(1, 10))

    r = Range(-2, 2)
    assert [i for i in r] == list(range(-2, 2))

    r = Range(-2, 2, 2)
    assert [i for i in r] == list(range(-2, 2, 2))


# Generated at 2022-06-21 12:11:03.035480
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    instance = LazyList(Range(10))
    for x, y in zip(instance, Range(10)):
        assert x == y



# Generated at 2022-06-21 12:11:04.386891
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert type(iter(Range(1, 10))) == Range



# Generated at 2022-06-21 12:11:07.854483
# Unit test for function drop_until
def test_drop_until():
    iterable = [1,2,3,4,5,6,7,8,9,10]
    assert list(drop_until(lambda x: x > 5, iterable)) == [6,7,8,9,10]


# Generated at 2022-06-21 12:11:14.517224
# Unit test for function scanr
def test_scanr():
    # Passing all arguments
    assert list(scanr(lambda x, y: x + y, range(5), 0)) == [10, 8, 5, 1, 0]
    # Passing no arguments
    assert list(scanr(lambda x, y: x + y, range(5))) == [10, 8, 5, 1]
    # Passing too many arguments
    with pytest.raises(ValueError):
        list(scanr(lambda x, y: x + y, range(5), 1, 2))



# Generated at 2022-06-21 12:11:19.550778
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:11:27.236456
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    iterable = range(3)

    obj = LazyList(iterable)

    try:
        obj[0]
    except IndexError:
        pass
    else:
        assert False, "Expected IndexError"
    try:
        obj[1]
    except IndexError:
        pass
    else:
        assert False, "Expected IndexError"

    assert list(obj.__iter__()) == [0, 1, 2]

    obj = LazyList(iterable)
    assert list(obj.__iter__()) == [0, 1, 2]


# Generated at 2022-06-21 12:11:31.415326
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    result = [3, 5, 7, 9, 11]
    for i in MapList(lambda i: a[i] + b[i], Range(len(a))):
        assert i == result.pop(0)


# Generated at 2022-06-21 12:11:37.769004
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    assert len(m) == len(lst)
    assert m[0] == 1 * 1
    assert m[1] == 2 * 2
    assert m[2] == 3 * 3
    assert m[3] == 4 * 4
    assert m[4] == 5 * 5
    for i, x in enumerate(m):
        assert x == lst[i]*lst[i]

test_MapList()

# Generated at 2022-06-21 12:11:41.312927
# Unit test for method __next__ of class Range
def test_Range___next__():
    iterator = Range(1, 11, 2)
    assert next(iterator) == 1
    assert next(iterator) == 3
    assert next(iterator) == 5
    assert next(iterator) == 7
    assert next(iterator) == 9
    with pytest.raises(StopIteration):
        next(iterator)

# Generated at 2022-06-21 12:11:47.189004
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import pytest
    lst = list(range(20))
    lazy_list = LazyList(lst)
    assert isinstance(lazy_list[0], int)
    assert lazy_list[0] == lst[0]
    assert isinstance(lazy_list[1:3], list)
    with pytest.raises(TypeError):
        len(lazy_list)



# Generated at 2022-06-21 12:11:59.271775
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-21 12:12:05.818533
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    xs = LazyList(range(10))
    assert xs[4] == 4
    assert xs[4:7] == [4, 5, 6]
    assert xs[:7] == [0, 1, 2, 3, 4, 5, 6]
    assert xs[7:] == [7, 8, 9]
    assert len(xs) == 10
    assert list(xs) == list(range(10))


# Generated at 2022-06-21 12:12:16.462829
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from hypothesis import given
    from .strategies import (sequences, callables, integers_no_zero)
    # Add more strategies as required
    @given(sequences(elements=integers_no_zero()).flatmap(lambda x: callables(result=integers_no_zero()).map(lambda f: (f, x))), integers_no_zero())
    def test_MapList___getitem__Implementation(a, b):
        """
        Test __getitem__ is correct implementation
        """
        (func, lst) = a
        result = MapList(func, lst).__getitem__(b)
        assert len(result) == len(lst)
        for i in range(len(lst)):
            assert result[i] == func(lst[i])
        return

#

# Generated at 2022-06-21 12:12:25.935928
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    arg1 = []
    arg0 = Range(*arg1)
    retv = __iter__(arg0)
    func_name = sys._getframe().f_code.co_name
    func_args = (arg0,)
    result_type_str = "<class 'Range'>"
    assert type(retv).__name__ == result_type_str, \
        '{}(1) should return type {} but returned type {}'.format(func_name, result_type_str, type(retv).__name__)

# Generated at 2022-06-21 12:12:28.726317
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
test_chunk()



# Generated at 2022-06-21 12:12:36.662980
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:12:38.638638
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list_ = LazyList(range(10))
    assert len(list_) == 10


Range = LazyList



# Generated at 2022-06-21 12:12:40.497901
# Unit test for method __next__ of class Range
def test_Range___next__():
    range: Range = Range(0, 15 + 1)
    assert 0 == next(range)
    assert 1 == next(range)


# Generated at 2022-06-21 12:12:52.663942
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from hypothesis import given, strategies as st
    from itertools import chain, count
    from pprint import pprint

    def take(n: int, it: Iterator[T]) -> Iterable[T]:
        for i in range(n):
            try:
                yield next(it)
            except StopIteration:
                break

    @given(st.lists(st.integers()))
    def test(lst: List[int]):
        def take_min(a: int, b: int) -> int:
            if a is None:
                return b
            elif b is None:
                return a
            else:
                return min(a, b)


# Generated at 2022-06-21 12:12:58.598058
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:13:10.964456
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    pass

# Generated at 2022-06-21 12:13:18.594042
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(0, 5, 2)[0] == 0
    assert Range(0, 5, 2)[1] == 2
    assert Range(0, 5, 2)[2] == 4
    assert Range(0, 5, 2)[-1] == 4
    assert Range(0, 5, 2)[slice(0, 2)] == [0, 2]
    assert Range(0, 5, 2)[slice(None, None, -1)] == [4, 2, 0]
    with pytest.raises(IndexError):
        _ = Range(0, 5, 2)[2]


# Generated at 2022-06-21 12:13:22.621852
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    lst = [1, 2, 3]
    m = MapList(lambda x: x * x, lst)
    assert list(m) == [1, 4, 9]



# Generated at 2022-06-21 12:13:28.260233
# Unit test for function scanl
def test_scanl():
    assert [0, 1, 3, 6, 10] == list(scanl(operator.add, [1, 2, 3, 4], 0))
    assert ['a', 'ba', 'cba', 'dcba'] == list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']))

# Generated at 2022-06-21 12:13:31.884237
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3])
    if lst[0] == 1:
        print("_  __getitem__ test passed")
    else:
        print("_  __getitem__ test failed")

# Generated at 2022-06-21 12:13:39.055600
# Unit test for function split_by
def test_split_by():
    # type: () -> None
    for empty_segments in [False, True]:
        assert list(split_by(range(10), empty_segments=empty_segments, criterion=lambda x: x % 3 == 0)) \
                   == [[1, 2], [4, 5], [7, 8]]
        assert list(split_by(" Split by: ", empty_segments=True, separator='.')) \
                   == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:13:44.232765
# Unit test for constructor of class Range
def test_Range():
    assert Range(10) == range(10)
    assert Range(1, 10+1) == range(1, 11)
    assert Range(1, 11, 2) == range(1, 11, 2)
    assert Range(1, 11, -2) == range(1, 11, -2)

# Generated at 2022-06-21 12:13:49.309378
# Unit test for method __len__ of class MapList
def test_MapList___len__():

    l = MapList(lambda x:x, [])
    assert len(l) == 0
    l = MapList(lambda x:x, [1])
    assert len(l) == 1
    l = MapList(lambda x:x, [1, 2, 3])
    assert len(l) == 3
    None

# Generated at 2022-06-21 12:13:50.591680
# Unit test for constructor of class LazyList
def test_LazyList():
    assert LazyList(range(10)).list == []


# Generated at 2022-06-21 12:13:55.139516
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 5, 1)
    r.__init__(1, 5, 1)
    assert [r.__next__() for i in range(3)] == [1, 2, 3]


# Generated at 2022-06-21 12:14:02.681697
# Unit test for constructor of class LazyList
def test_LazyList():
    assert LazyList([1, 2, 3])[0] == 1



# Generated at 2022-06-21 12:14:04.860984
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5


# Generated at 2022-06-21 12:14:07.791257
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-21 12:14:13.899158
# Unit test for constructor of class Range
def test_Range():
    try:
        Range(1,2,3,4)
        assert False
    except:
        assert True
    try:
        Range()
        assert False
    except:
        assert True
    try:
        Range(1)
        assert False
    except:
        assert True
    try:
        Range(1,2)
        assert False
    except:
        assert True
    try:
        Range(1,2,3)
        assert False
    except:
        assert True



# Generated at 2022-06-21 12:14:18.590669
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x : x * 2, [1, 2, 3])) == [2, 4, 6]
    assert MapList(lambda x : x * 2, [1, 2, 3])[1] == 4
    assert MapList(lambda x : x * 2, [1, 2, 3])[1:3] == [4, 6]


# Generated at 2022-06-21 12:14:22.272365
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(1000000))
    assert lst[10] == 10
    assert isinstance(lst[10:20], list)
    assert lst[10:20:2] == [10, 12, 14, 16, 18]

# Generated at 2022-06-21 12:14:29.608077
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-21 12:14:36.003075
# Unit test for function scanl
def test_scanl():
    data = [0, 1, 3, 6, 10]
    result = list(scanl(operator.add, [1, 2, 3, 4], 0))
    assert data == result
    
    data = ['a', 'ba', 'cba', 'dcba']
    result = list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']))
    assert data == result
test_scanl()



# Generated at 2022-06-21 12:14:44.649944
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # type: () -> None
    import sys
    if sys.version_info >= (3, 7):
        # There was a bug in Python 3.7 and 3.8 where calling next on a sub-iterator didn't work
        # (see https://bugs.python.org/issue31720)
        return
    it = LazyList([1, 2, 3]).__iter__()
    next(it)
    next(it)
    assert next(it) == 3



# Generated at 2022-06-21 12:14:54.209063
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]

# Generated at 2022-06-21 12:15:10.279056
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == list(range(5))
    assert list(take(5, range(10))) != list(range(6))
    assert list(take(5, range(1, 10))) != list(range(5))



# Generated at 2022-06-21 12:15:16.000117
# Unit test for function scanl
def test_scanl():
    for n in range(4):
        assert list(scanl(operator.mul, [1] * (n + 1))) == [1] * (n + 1)
    assert list(scanl(operator.mul, [1, 2, 3, 4])) == [1, 2, 6, 24]
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.sub, [1, 2, 3, 4])) == [1, -1, -4, -8]

    assert list(scanl(operator.mul, [1, 2, 3, 4], 0)) == [0, 0, 0, 0, 0]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0))

# Generated at 2022-06-21 12:15:23.876817
# Unit test for function split_by
def test_split_by():
    # criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[], [1, 2], [], [4, 5], [], [7, 8], []]
    # separator
    assert list(split_by(" Split by: ", separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-21 12:15:36.649928
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(1))) == [0]
    assert list(drop(5, range(5))) == []
    assert list(drop(1, range(5))) == list(range(1,5))
# Test
test_drop()
# Test for 100 times
for _ in range(100):
    assert list(drop(random.randint(0, 10), range(random.randint(0, 10)))) == [i for i in range(random.randint(0, 10)) if i >= random.randint(0, 10)]
# Test for 100, 1000 times

# Generated at 2022-06-21 12:15:45.684968
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    with pytest.raises(ValueError):
        Range()
    with pytest.raises(ValueError):
        Range(1, 2, 3, 4)
    assert list(Range(1)) == [0]
    assert list(Range(1, 3)) == [1, 2]
    assert list(Range(1, 3, 2)) == [1]
    assert list(Range(1, 10, 10)) == [1]
    assert list(Range(10, 1, -1)) == [10, 9, 8, 7, 6, 5, 4, 3, 2]
    assert list(Range(3, 1, -1)) == [3, 2]
    assert list(Range(1, 3, -1)) == []

# Generated at 2022-06-21 12:15:46.784371
# Unit test for function scanl
def test_scanl():
    asse

# Generated at 2022-06-21 12:15:50.584000
# Unit test for function drop_until
def test_drop_until():

    assert list(drop_until(lambda x: x > 3, range(10))) == list(range(4, 10))
    assert list(drop_until(lambda x: x > 10, range(10))) == []



# Generated at 2022-06-21 12:15:52.178034
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    LazyList(range(100)).__len__()
Range = LazyList



# Generated at 2022-06-21 12:16:00.413960
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)         # (end)
    r1 = Range(1, 10 + 1)  # (start, end)
    r2 = Range(1, 11, 2)   # (start, end, step)
    print(r1[0], r1[2], r1[4])
    print(r2[0], r2[2], r2[4])
    print(r1[4])
    print(r1[0:4:2])
    print(r2[-1])



# Generated at 2022-06-21 12:16:10.327947
# Unit test for function drop
def test_drop():
    assert list(drop(3, [1, 2, 3, 4, 5])) == [4, 5]
    assert list(drop(3, [1, 2, 3, 4])) == [4]
    assert list(drop(0, [1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
    assert list(drop(1, [1, 2, 3, 4])) == [2, 3, 4]
    assert list(drop(1, [1, 2, 3])) == [2, 3]
    assert list(drop(1, [1, 2])) == [2]
    assert list(drop(1, [1])) == []
    assert list(drop(1, [])) == []



# Generated at 2022-06-21 12:16:35.392401
# Unit test for function take
def test_take():
    assert(list(take(5, range(1000000))) == [0, 1, 2, 3, 4])
test_take()



# Generated at 2022-06-21 12:16:40.742919
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(10))) == [3, 4, 5, 6, 7, 8, 9]
    assert list(drop(9, range(10))) == [9]
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(0, [])) == []

