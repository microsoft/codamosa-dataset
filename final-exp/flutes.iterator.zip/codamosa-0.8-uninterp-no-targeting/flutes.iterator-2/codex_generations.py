

# Generated at 2022-06-21 12:07:36.486331
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

test_split_by()



# Generated at 2022-06-21 12:07:41.782925
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(5)) == [0, 1, 2, 3, 4]
    assert list(Range(3, 6)) == [3, 4, 5]
    assert list(Range(3, 9, 2)) == [3, 5, 7]
    assert list(Range(3, 10, 2)) == [3, 5, 7, 9]


# Generated at 2022-06-21 12:07:47.156019
# Unit test for constructor of class LazyList
def test_LazyList():
    _iter = iter([1, 2, 3])
    test = LazyList(_iter)
    assert not test.exhausted
    assert len(test.list) == 0
    assert isinstance(test.iter, type(_iter))
    assert test.iter.__next__() == 1
    assert test.iter.__next__() == 2
    assert test.iter.__next__() == 3
    assert not test.exhausted
    return None



# Generated at 2022-06-21 12:07:52.747509
# Unit test for constructor of class LazyList
def test_LazyList():
    l = LazyList(range(1000))
    assert not l.exhausted
    assert len(l) == 1000
    assert l[9] == 9
    assert l[0] == 0
    assert l[999] == 999
    assert l.exhausted

### Ranges ###

# TODO: Support negative step
# TODO: Support arbitrary types as arguments (e.g. strings)

# Generated at 2022-06-21 12:08:01.351733
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    try:
        list(split_by(range(1)))
        assert False  # unreachable
    except ValueError:
        pass



# Generated at 2022-06-21 12:08:04.395348
# Unit test for function take
def test_take():
    for n in range(10):
        assert list(take(n, range(10))) == list(range(n))
    with pytest.raises(ValueError):
        list(take(-1, range(10)))



# Generated at 2022-06-21 12:08:10.866817
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3])
    it = iter(lst)
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    with pytest.raises(StopIteration):
        next(it)
    assert list(lst) == [1, 2, 3]
    for x, y in zip(lst, lst):
        assert x == y

# Generated at 2022-06-21 12:08:19.638339
# Unit test for function split_by
def test_split_by():
    assert(list(split_by(" Split by: ", empty_segments=True, separator='.'))
        == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []])
    assert(list(split_by(" Split by: ", empty_segments=False, separator='.'))
        == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']])
    assert(list(split_by(" Split by: ", empty_segments=False, criterion=lambda x: x.isupper()))
        == [[' ', ' ', ' ', ' ', ' '], ['b', 'y', ':', ' ']])

# Generated at 2022-06-21 12:08:24.994166
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 5)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    try:
        next(r)
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-21 12:08:31.391169
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(10))
    assert [1, 2, 3] == list(take(3, ll))
    assert [0, 1, 2, 3] == list(ll)
    assert [0, 1, 2, 3, 4] == list(ll)
    assert [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] == list(ll)
    assert [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] == list(ll)



# Generated at 2022-06-21 12:08:42.444856
# Unit test for function drop
def test_drop():
    test_iter = [1,2,3,4]
    assert [x for x in drop(1,test_iter)] == [2,3,4]
    assert [x for x in drop(2,test_iter)] == [3,4]
    assert [x for x in drop(4,test_iter)] == []
    assert [x for x in drop(5,test_iter)] == []



# Generated at 2022-06-21 12:08:52.145840
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import random
    for _ in range(10):
        for step in [1, 2, 3, -1, -2, -3]:
            for length in range(-1, 10):
                for idx in range(-2, length + 2):
                    r = Range(1, 1 + step * length, step)
                    if idx < 0:
                        idx += length + 1
                    if idx < 0 or idx >= length:
                        with pytest.raises(IndexError):
                            _ = r[idx]
                    else:
                        assert r[idx] == 1 + idx * step



# Generated at 2022-06-21 12:09:03.465017
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(2))) == [[0, 1]]

# Generated at 2022-06-21 12:09:07.621772
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: 10 * x, [1, 2, 3])[1] == 20
    assert MapList(lambda x: x, []) == []

# Generated at 2022-06-21 12:09:19.105156
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(2, [])) == []
    assert list(chunk(1, [1, 2, 3])) == [[1], [2], [3]]
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(2, [1, 2, 3])) == [[1, 2], [3]]
    assert list(chunk(3, [1, 2, 3])) == [[1, 2, 3]]

# Generated at 2022-06-21 12:09:21.406004
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(0, 5))) == [[0, 1, 2], [3, 4]]


# Generated at 2022-06-21 12:09:32.767939
# Unit test for method __iter__ of class Range
def test_Range___iter__():
  Range_0 = Range(7)
  Range__iterator_0 = Range_0.__iter__()
  for i_var in range(7):
    value_var = Range__iterator_0.__next__()
    assert type(value_var) is int
    assert value_var == i_var
  try:
    value_var = Range__iterator_0.__next__()
    assert False
  except:
    pass
  # Empty Range
  Range_1 = Range(0, 1, 2)
  Range__iterator_1 = Range_1.__iter__()
  try:
    value_var = Range__iterator_1.__next__()
    assert False
  except:
    pass
test_Range___iter__()


# Generated at 2022-06-21 12:09:38.844214
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    a = LazyList(range(1000))
    b = a[2:5]
    assert len(b) == 3
    assert list(b) == [2, 3, 4]
    assert len(b) == 3
    assert a[:5] == [0, 1, 2, 3, 4]
    assert len(a) == 1000
    assert list(a) == list(range(1000))



# Generated at 2022-06-21 12:09:44.338466
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]



# Generated at 2022-06-21 12:09:54.391241
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(1, range(10))) == [[x] for x in range(10)]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, [])) == []
    try:
        assert list(chunk(0, range(10)))
        assert False
    except ValueError:
        pass


# Generated at 2022-06-21 12:10:01.735434
# Unit test for function drop
def test_drop():
    assert list(drop(2, range(5))) == [2, 3, 4]



# Generated at 2022-06-21 12:10:06.411060
# Unit test for function chunk
def test_chunk():
    def list_all(it):
        return list(it)
    assert list_all(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-21 12:10:11.507283
# Unit test for method __next__ of class Range
def test_Range___next__():
    a = Range(1, 11, 2)
    assert a.__next__() == 1
    assert a.__next__() == 3
    assert a.__next__() == 5
    assert a.__next__() == 7
    assert a.__next__() == 9


# Generated at 2022-06-21 12:10:23.556658
# Unit test for function split_by
def test_split_by():
    iterable = range(20)
    criterion = lambda x: x % 3 == 0
    separator = b'\n'

    assert [[1, 2], [4, 5], [7, 8], [10, 11], [13, 14], [16, 17]] == list(split_by(iterable, criterion=criterion))
    assert [[], [1, 2], [4, 5], [7, 8], [10, 11], [13, 14], [16, 17], []] == list(split_by(iterable, empty_segments=True, criterion=criterion))


# Generated at 2022-06-21 12:10:24.706516
# Unit test for constructor of class LazyList
def test_LazyList():
    assert list(LazyList(range(10))) == list(range(10))



# Generated at 2022-06-21 12:10:33.204988
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from random import random
    from prettytable import PrettyTable
    from .util import all_equal, random_string

    def test(idx):
        lst = LazyList(range(int(random() * 100)))
        item = lst[idx]
        try:
            len(lst)
            assert False, "Expected an exception"
        except TypeError:
            pass

        # print(f"{lst}[{idx}] = {item}")

    for _ in range(1000):
        test(int(random() * 50))
        test(slice(int(random() * 50), int(random() * 50)))



# Generated at 2022-06-21 12:10:35.284952
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x*x, [1, 2, 3, 4])) == [1, 4, 9, 16]

# Generated at 2022-06-21 12:10:40.436031
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(0,10,2)
    r2 = Range(1,10 + 1)
    r3 = Range(1, 11,2)
    print(r1[0], r1[2], r1[4])
    print(r2)
    print(r3)



# Generated at 2022-06-21 12:10:49.037837
# Unit test for function split_by
def test_split_by():
    assert [[1, 2], [4, 5], [7, 8]] == list(split_by(range(10), criterion=lambda x: x % 3 == 0))
    assert [[], [1, 2, 3], [5], [7], [9, 0]] == list(split_by(range(10), criterion=lambda x: x in {4, 6, 8}))
    assert [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []] == \
        list(split_by(" Split by: ", criterion=lambda x: x == '.', empty_segments=True))



# Generated at 2022-06-21 12:10:51.178135
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    lst = list(range(10))
    mpl = MapList(lambda x: x * x, lst)
    assert list(mpl) == lst


# Generated at 2022-06-21 12:11:04.387148
# Unit test for method __getitem__ of class Range
def test_Range___getitem__(): 
    a = Range(1,11, 2)
    assert a[0]==1
    assert a[2]==5
    assert a[4]==9
    assert a[-1]==9

# Generated at 2022-06-21 12:11:07.125316
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    for x in range(10):
        m = MapList(lambda x: x * x, range(x))
        assert len(m) == x

# Generated at 2022-06-21 12:11:09.947342
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    take = iter([random.randrange(100) for _ in range(100)])
    assert len(MapList(lambda x: x, take)) == 100

# Generated at 2022-06-21 12:11:20.095638
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    import bisect

    def gt(x, y):
        return x > y

    lst = [1, 2, 3, 4, 5]
    f = lambda x: x * x
    m = MapList(f, lst)

    assert m[0] == f(lst[0])
    assert m[slice(1, 3)] == [f(lst[1]), f(lst[2])]
    assert m[slice(None, -1)] == [f(lst[0]), f(lst[1]), f(lst[2]), f(lst[3])]

    assert bisect.bisect_left(m, 10, hi=4) == 3
    assert bisect.bisect_left(m, 10, cmp=gt) == 1

    assert bisect.bisect

# Generated at 2022-06-21 12:11:30.325218
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    class A:
        pass
    assert len(MapList(lambda x: x, lst)) == len(lst)
    assert MapList(lambda x: x, lst) == list(lst)
    assert MapList(lambda x: x, []) == []
    assert MapList(lambda x: A(), lst) == [A()] * len(lst)
    assert MapList(lambda x: x + 10, lst) != list(lst)
    assert MapList(lambda x: x + 10, lst)[0] != lst[0]
    assert MapList(lambda x: [x, x], lst)[0] == lst[0]
    assert MapList(lambda x: [x, x], lst) != list(lst)

# Generated at 2022-06-21 12:11:41.941519
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[0] == 0
    assert Range(10)[5] == 5
    assert Range(10)[-1] == 9
    assert Range(10)[-5] == 5
    assert Range(10)[-10] == 0
    assert Range(1, 11, 2)[0] == 1
    assert Range(1, 11, 2)[5] == 11
    assert Range(1, 11, 2)[-1] == 9
    assert Range(1, 11, 2)[-5] == 3
    assert Range(1, 11, 2)[-10] == 1
    assert Range(1, 10)[0] == 1
    assert Range(1, 10)[9] == 10
    assert Range(1, 10)[-1] == 10
    assert Range(1, 10)[-10] == 1
    assert Range(10)[:0]

# Generated at 2022-06-21 12:11:43.654814
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(100))
    assert len(lst) == 100



# Generated at 2022-06-21 12:11:45.978193
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    mplst = MapList(lambda x: x * x, lst)
    assert mplst[0] == 1
    assert mplst[-1] == 25
    assert mplst[:3] == [1, 4, 9]



# Generated at 2022-06-21 12:11:55.597901
# Unit test for constructor of class LazyList
def test_LazyList():
    L1 = LazyList(range(1, 4))
    assert L1[0] == 1
    assert L1[1] == 2
    assert len(L1) == 3
    assert L1[0] == 1
    assert L1[1] == 2
    assert L1[2] == 3
    assert L1[0:2] == [1, 2]
    assert len(L1) == 3
    assert L1[0] == 1
    assert L1[1] == 2
    assert L1[2] == 3
    assert L1[0:2] == [1, 2]

    L2 = LazyList(range(1, 4))
    a = 0
    for i in L2:
        a += i
    assert a == 6
    assert len(L2) == 3
    assert L

# Generated at 2022-06-21 12:12:08.335328
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)
    assert list(r) == list(range(10))
    r = Range(1, 11)
    assert list(r) == list(range(1, 11))
    r = Range(1, 13, 2)
    assert list(r) == list(range(1, 13, 2))
    r = Range(1, 13)
    assert r[:] == list(range(1, 13))
    assert r[2: 7: 2] == list(range(2, 7, 2))
    assert r[0] == 1
    assert r[-1] == 12
    assert r[2] == 3
    assert r[-3] == 10
    try:
        r[100]
        assert False
    except IndexError:
        assert True

# Generated at 2022-06-21 12:12:15.021070
# Unit test for function take
def test_take():
    assert (list(take(5, range(10))) == [0, 1, 2, 3, 4])
    assert (list(take(5, range(1000000))) == [0, 1, 2, 3, 4])
    assert (list(take(0, range(10))) == [])
    # Test invalid input
    try:
        list(take(-1, range(10)))
    except ValueError:
        pass
test_take()



# Generated at 2022-06-21 12:12:19.224873
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Test with empty iterable
    lst = []
    func = lambda x: x ** 2
    map_list = MapList(func, lst)
    assert map_list[0:] == []

    # Test with non-empty iterable
    lst = [1, 2, 3, 4, 5]
    func = lambda x: x ** 2
    map_list = MapList(func, lst)
    assert map_list[0:2] == [1, 4]
    assert map_list[0] == 1
    assert map_list[4] == 25
    assert map_list[0:5:2] == [1, 9, 25]
    assert map_list[-5:] == [1, 4, 9, 16, 25]

# Generated at 2022-06-21 12:12:30.785767
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, (1, 2, 3))) == [6, 5, 3, 0]
    assert list(scanr(operator.mul, (1, 2, 3))) == [6, 2, 1]
    assert list(scanr(operator.add, (1, 2, 3), 0)) == [6, 5, 3, 0]
    assert list(scanr(operator.mul, (1, 2, 3), 1)) == [6, 2, 1]
    assert list(scanr(lambda x, y: (y, x), (1, 2, 3))) == [(3, 2), (2, 1), 1]
    assert list(scanr(lambda x, y: (x, y), (1, 2, 3))) == [(3, 2), 2, 1]

# Generated at 2022-06-21 12:12:38.523477
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(range(10))
    assert len(lst) == 10
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5] == 5
    assert lst[:7] == [0, 1, 2, 3, 4, 5, 6]
    assert lst[7] == 7
    assert lst[:9] == [0, 1, 2, 3, 4, 5, 6, 7, 8]
    assert lst[9] == 9
    assert lst[:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert lst[10] == 0
    assert lst[:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-21 12:12:40.967131
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList(range(10))
    assert [i for i in a] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-21 12:12:46.375552
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list_ = LazyList(range(10))
    try:
        len(list_)
        assert False, "Did not raise TypeError"
    except TypeError:
        pass
    list_[5]
    assert len(list_) == 10



# Generated at 2022-06-21 12:12:51.498476
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    args = [
        (1, [1, 2, 3], [1, 2, 3]),
        (lambda x: x * 2, [1, 2, 3], [2, 4, 6]),
    ]
    for func, lst, expected in args:
        ml = MapList(func, lst)
        assert list(ml) == expected



# Generated at 2022-06-21 12:12:59.418595
# Unit test for function split_by
def test_split_by():
    assert list(split_by([5, 4, 3, 2, 1, 5, 4, 3, 2, 1], criterion=lambda x: x == 5)) == [[4, 3, 2, 1], [4, 3, 2, 1]]
    assert list(split_by([5, 4, 3, 2, 1, 5, 4, 3, 2, 1], criterion=lambda x: x == 5, empty_segments=True)) == [[], [4, 3, 2, 1], [4, 3, 2, 1]]
    assert list(split_by(['a', 'b', 'a', 'b', 'a', 'b', 'a', 'b'], separator='a')) == [['b'], ['b'], ['b'], ['b']]

# Generated at 2022-06-21 12:13:05.195689
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    lst = MapList(lambda x: x * x, a)
    assert lst[0] == 1
    assert lst[1] == 4
    assert lst[2] == 9
    assert lst[3] == 16
    assert lst[4] == 25
    assert lst[1:4] == [4, 9, 16]
    assert lst[2:] == [9, 16, 25]


if __name__ == "__main__":
    test_MapList___getitem__()

# Generated at 2022-06-21 12:13:10.081183
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(Sequence[T]([1, 2, 3, 4, 5]))
    assert [1, 2, 3, 4, 5] == list(lst)
    assert [1, 2, 3, 4, 5] == list(lst)


# Generated at 2022-06-21 12:13:15.116834
# Unit test for method __len__ of class Range
def test_Range___len__():
    pass


# Generated at 2022-06-21 12:13:19.479687
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1,2,3,4,5]
    maplist = MapList(lambda x: x * x, lst)
    assert maplist == [1, 4, 9, 16, 25]
    assert maplist[0] == 1 and maplist[3] == 16 and maplist[-1] == 25

# Generated at 2022-06-21 12:13:22.509036
# Unit test for constructor of class LazyList
def test_LazyList():
    obj = LazyList(range(100))
    assert obj[1] == 1


# Generated at 2022-06-21 12:13:33.227173
# Unit test for function scanl
def test_scanl():
    assert [*scanl(operator.sub, range(5), 10)] == [10, 9, 7, 4, 0, -5]
    assert [*scanl(operator.sub, range(5))] == [0, -1, -3, -6, -10, -15]
    assert [*scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd', 'e'])] == ['a', 'ba', 'cba', 'dcba', 'edcba']
    assert [*scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd', 'e'], '')] == ['', 'a', 'ab', 'abc', 'abcd', 'abcde']



# Generated at 2022-06-21 12:13:35.193569
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    a = MapList(lambda x: x*2, [1,2,3])
    expected_list = [2, 4, 6]
    returned_list = [item for item in a]
    assert returned_list == expected_list

# Generated at 2022-06-21 12:13:47.244672
# Unit test for function take
def test_take():
    assert list(take(2, range(10))) == [0, 1]
    assert list(take(0, range(10))) == []
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(10000, range(10))) == list(range(10))
    assert list(take(10000, [])) == []
    assert list(take(20, [1, 4, 5, 6, 7])) == [1, 4, 5, 6, 7]
    assert list(take(1, [1, 4, 5, 6, 7])) == [1]
    assert list(take(2, [1, 4, 5, 6, 7])) == [1, 4]

# Generated at 2022-06-21 12:13:57.701545
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from itertools import count
    from unittest import TestCase

    class TestCaseClass(TestCase):
        def test_empty_list(self):
            lst = LazyList([])
            self.assertEqual(0, len(lst))
            self.assertEqual(0, len(lst))

        def test_finite_list(self):
            lst = LazyList(range(10))
            self.assertEqual(10, len(lst))
            self.assertEqual(10, len(lst))

        def test_invalid_on_infinite_list(self):
            lst = LazyList(count())
            with self.assertRaises(TypeError):
                len(lst)

    TestCaseClass.run('')



# Generated at 2022-06-21 12:13:59.845264
# Unit test for function take
def test_take():
    assert list(take(5,'hong')) == ['h', 'o', 'n', 'g']
test_take()



# Generated at 2022-06-21 12:14:02.596555
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert set(map(lambda x: x + 1, [1, 2, 3])) == set(MapList(lambda x: x + 1, [1, 2, 3]))


# Generated at 2022-06-21 12:14:10.041042
# Unit test for function take
def test_take():
    # Test with a non-empty iterable
    gen = take(3, range(5))
    assert list(gen) == [0, 1, 2]

    # Test with a non-empty iterable with length smaller than n
    gen = take(5, range(4))
    assert list(gen) == [0, 1, 2, 3]

    # Test with empty iterable
    gen = take(3, range(0))
    assert list(gen) == []

    # Test with negative input
    with pytest.raises(ValueError):
        gen = take(-3, range(3))



# Generated at 2022-06-21 12:14:14.556092
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    pass  # TODO

# Generated at 2022-06-21 12:14:16.956307
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:14:19.794472
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(0)) == 0
    assert len(Range(1)) == 1
    assert len(Range(2)[0:2]) == 2



# Generated at 2022-06-21 12:14:26.362842
# Unit test for function take
def test_take():
    import random
    def gen():
        while True:
            yield random.choice('abcdefghijklmnopqrstuvwxyz')
    g = gen()
    assert list(take(5, g)) == ['c', 't', 'g', 'd', 'x']
    assert list(take(5, g)) == ['m', 'z', 'v', 'y', 'q']



# Generated at 2022-06-21 12:14:37.014667
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    """Test for method __getitem__ of class Range"""

    r1 = Range(10)
    for i in range(10):
        assert(r1[i] == i)

    r2 = Range(1, 10+1)
    for i in range(1,10+1):
        assert(r2[i-1] == i)

    r3 = Range(1,11,2)
    for i in range(1,11,2):
        assert(r3[i-1] == i)

    assert(r3[0:2] == [1,3])
    assert(r3[0:3:2] == [1,5])
    assert(r3[0::3] == [1,7])

    assert(r3[-1:] == [9])

# Generated at 2022-06-21 12:14:44.444790
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList(range(3))
    assert(list(l) == [0, 1, 2])
    assert(list(l) == [0, 1, 2])
    l = LazyList(repeat(1))
    assert(list(take(10, l)) == [1] * 10)
    assert(list(take(10, l)) == [1] * 10)



# Generated at 2022-06-21 12:14:48.640214
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from mltk.tests import assert_equal
    l = LazyList(range(100))
    g = iter(l)
    for i in range(100):
        assert_equal(next(g), i)
    for i in range(100):
        assert_equal(next(g), i)

# Generated at 2022-06-21 12:14:50.492531
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(range(5))
    assert len(lst) == 5
    assert lst[0] == 0
    assert lst[-1] == 4
    assert list(lst) == list(range(5))



# Generated at 2022-06-21 12:14:53.505271
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert len(r) == 10
    r = Range(1, 11)
    assert len(r) == 10
    r = Range(1, 11, 4)
    assert len(r) == 3


# Generated at 2022-06-21 12:14:56.593274
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(1)) == 0
    assert next(Range(-1, 1)) == -1
    assert next(Range(0, 1, 2)) == 0



# Generated at 2022-06-21 12:15:05.117719
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x, [1])) == 1

# Generated at 2022-06-21 12:15:10.279425
# Unit test for function scanr
def test_scanr():
    assert next(drop(4, scanr(operator.add, [1, 2, 3, 4], 0))) == 10
    assert next(drop(3, scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']))) == 'abcd'



# Generated at 2022-06-21 12:15:20.607673
# Unit test for function split_by
def test_split_by():
    # Try criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]
    # Try separator
    assert list(split_by("Split by:", separator='.')) == [['S', 'p', 'l', 'i', 't', ' ', 'b', 'y', ':']]

# Generated at 2022-06-21 12:15:25.077776
# Unit test for function scanl
def test_scanl():
    from operator import add
    assert list(scanl(add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

# Generated at 2022-06-21 12:15:31.058486
# Unit test for constructor of class Range
def test_Range():
    r = Range(5, 7)
    assert r[:10] == [5, 6]
    r = Range(5, 7, 2)
    assert r[:10] == [5]
    r = Range(0, 10, 2)
    assert r[:10] == [0, 2, 4, 6, 8]


# Generated at 2022-06-21 12:15:33.442705
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list1 = LazyList([1, 2, 3, 4])
    list2 = LazyList([1, 2, 3, 4])
    try:
        print(len(list1))
    except TypeError as e:
        print(e)
    print(len(list(list2)))
test_LazyList___len__()



# Generated at 2022-06-21 12:15:36.748587
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda s, x: s + x, ['a', 'b', 'c', 'd'])) == [
        'a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:15:39.919804
# Unit test for function take
def test_take():
    t=take(4,range(1000000))
    assert len(list(t))==4


# Generated at 2022-06-21 12:15:41.519952
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList(range(10000))
    assert list(l[10:20]) == list(range(10, 20))

# Generated at 2022-06-21 12:15:44.694993
# Unit test for constructor of class LazyList
def test_LazyList():
    l = LazyList(range(1000))
    assert l[5] == 5
    assert list(l.__iter__()) == list(range(1000))



# Generated at 2022-06-21 12:16:04.322013
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    try:
        list(chunk(0, range(10)))
    except ValueError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 12:16:09.237093
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(1, 6))) == [1, 2, 3, 4, 5]
    assert list(drop(4, range(1, 6))) == [5]
    assert list(drop(5, range(1, 6))) == []
    assert list(drop(6, range(1, 6))) == []


# Generated at 2022-06-21 12:16:16.662627
# Unit test for function scanr
def test_scanr():
    sequence = [1, 2, 3, 4]
    assert scanr(operator.add, sequence, 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, sequence) == ['abcd', 'bcd', 'cd', 'd']
    sequence = ['a', 'b', 'c', 'd']
    assert scanr(lambda s, x: x + s, sequence) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:16:19.235079
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(1000000))) == list(range(5, 1000000))
    raises(ValueError, lambda: drop(-5, range(10)))



# Generated at 2022-06-21 12:16:20.870405
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(1000000))) == list(range(5, 1000000))



# Generated at 2022-06-21 12:16:23.062675
# Unit test for function take
def test_take():
    assert list(take(6, ['a','b','c','d','e','f'])) == ['a','b','c','d','e','f']
test_take()



# Generated at 2022-06-21 12:16:25.502433
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    '''
    Unit test for method __len__ of class MapList
    '''
    from inspect import signature

    assert signature(MapList.__len__).__annotations__['return'] == int



# Generated at 2022-06-21 12:16:35.280723
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from builtins import len as py_len
    from typing import Any

    py_list= [1, 2, 3, 4]
    lazy_list = LazyList[Any](iter(py_list))

    def test_before_exhausted():
        with pytest.raises(TypeError):
            _ = len(lazy_list)

    def test_exhausted():
        next(iter(lazy_list))
        next(iter(lazy_list))
        next(iter(lazy_list))
        next(iter(lazy_list))
        _ = len(lazy_list)

    test_before_exhausted()
    test_exhausted()
    assert len(lazy_list) == py_len(py_list)

# Generated at 2022-06-21 12:16:37.842010
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list = []
    for i in range(100):
      list.append(i)
    l = LazyList(list)
    assert len(l) == 100



# Generated at 2022-06-21 12:16:47.955866
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    x = MapList(lambda x: x*x, lst)
    assert len(x) == len(lst)
    assert x[0] == lst[0]*lst[0]
    assert x[1] == lst[1]*lst[1]
    assert x[2] == lst[2]*lst[2]
    assert x[3] == lst[3]*lst[3]
    assert x[4] == lst[4]*lst[4]



# Generated at 2022-06-21 12:17:07.167064
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']

