

# Generated at 2022-06-21 12:07:05.583398
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    it = lst.__iter__()
    assert it.__next__() == 0
    assert lst.list == [0]
    assert it.__next__() == 1
    assert lst.list == [0, 1]
    assert next(it) == 2
    assert lst.list == [0, 1, 2]



# Generated at 2022-06-21 12:07:07.225635
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-21 12:07:20.805869
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3])) == [1, 3, 6]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c'])) == ['a', 'ba', 'cba']
    assert list(scanl(operator.add, [1, 2, 3], 0)) == [0, 1, 3, 6]
    assert list(scanl(operator.add, [1, 2, 3], 4)) == [4, 5, 7, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c'], 'd')) == ['d', 'da', 'dba', 'dcba']
    assert list(scanl(operator.add, [])) == []

# Generated at 2022-06-21 12:07:33.204390
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from . import islice
    # Create a LazyList
    xs = LazyList(range(100))
    # Check the LazyList is not yet iterated
    assert len(xs.list) == 0
    # Check element access fetches the right elements
    assert xs[4] == 4
    assert len(xs.list) >= 5
    # Check slice access fetches the right elements
    assert xs[10:50:2] == list(range(10, 50, 2))
    assert len(xs.list) >= 50
    # Check element access at the end of the list
    assert xs[-1] == 99
    assert len(xs.list) == 100
    # Check the whole list can be fetched
    assert list(xs) == list(range(100))
    assert len(xs.list) == 100

# Generated at 2022-06-21 12:07:37.680144
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == [0, 1, 2]
    assert list(take(3, range(1))) == [0]
    assert list(take(3, range(0))) == []




# Generated at 2022-06-21 12:07:46.858835
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import pytest
    lst = LazyList([1, 2, 3, 4, 5, 6])
    assert lst[0] == 1
    assert lst[3] == 4
    assert lst[4] == 5
    assert lst[-1] == 6
    assert lst[::-1] == [6, 5, 4, 3, 2, 1]
    assert lst[::2] == [1, 3, 5]
    with pytest.raises(TypeError):
        len(lst)
    with pytest.raises(IndexError):
        lst[6]
    with pytest.raises(IndexError):
        lst[-7]
    with pytest.raises(TypeError):
        lst[1.1]



# Generated at 2022-06-21 12:07:49.206922
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-21 12:08:00.725638
# Unit test for function split_by

# Generated at 2022-06-21 12:08:09.696640
# Unit test for function split_by
def test_split_by():
    class DictWrapper:
        def __init__(self, data: dict):
            self.data = data
        def __eq__(self, other: 'DictWrapper') -> bool:
            return (type(self) is type(other)) and self.data == other.data

    def dict_wrapper_criterion(x: DictWrapper) -> bool:
        return x.data.get("key", None) == "value"

    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]

# Generated at 2022-06-21 12:08:12.785266
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    lst2 = lst[5:]
    assert lst2[0] == 5
test_LazyList___getitem__()



# Generated at 2022-06-21 12:08:25.387615
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    lst = []
    for i in range(10):
        x = 0
        for j in Range(i + 1):
            x += j
        lst.append(x)
    assert lst == list(range(1, 10 + 1))

# Generated at 2022-06-21 12:08:28.281273
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    def test_impl(x):
        return x * x
    m = MapList(test_impl, [1, 2, 3, 4, 5])
    for i in m:
        pass

# Generated at 2022-06-21 12:08:32.852864
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(3))) == [0, 1, 2]
    assert list(drop(1, range(3))) == [1, 2]
    assert list(drop(3, range(3))) == []
    assert list(drop(4, range(4))) == []
    assert list(drop(5, range(4))) == []
    assert list(drop(6, range(4))) == []



# Generated at 2022-06-21 12:08:40.060298
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(x for x in range(0, 10))
    assert not l.exhausted
    try:
        tmp = len(l)
    except TypeError:
        pass
    else:
        assert False

    for i in range(0, 5):
        assert l[i] == i

    try:
        tmp = len(l)
    except TypeError:
        pass
    else:
        assert False

    for i in range(5, 10):
        assert l[i] == i

    assert l.exhausted
    assert len(l) == 10



# Generated at 2022-06-21 12:08:45.464958
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:08:50.620424
# Unit test for function chunk
def test_chunk():
    assert tuple(chunk(2, range(6))) == ((0, 1), (2, 3), (4, 5))
    assert tuple(chunk(-1, range(6)))
    assert tuple(chunk(2, range(0))) == ()
    assert tuple(chunk(0, range(3))) == ((), (), ())



# Generated at 2022-06-21 12:08:55.154668
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    from builtins import int
    from typing import Dict, List
    from functools import reduce
    def func(self, param0: List[byte]) -> None:
        def Multiplication(x, y):
            return x * y
        data = MapList(lambda x: x + 1, [1, 2, 3])
        assert reduce(Multiplication, [2, 3, 4, 5]) == 120

# Generated at 2022-06-21 12:08:57.404530
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x * x, [1, 2, 3, 4, 5])) == [1, 4, 9, 16, 25]

# Generated at 2022-06-21 12:09:10.049961
# Unit test for constructor of class Range
def test_Range():
    x = Range(1, 6, 3)
    assert x[0] == 1
    assert type(x[0]) == int
    assert x[1] == 4
    assert type(x[1]) == int
    assert x[-1] == 4
    assert type(x[-1]) == int
    assert x[-2] == 1
    assert type(x[-2]) == int
    assert x[2] == StopIteration
    assert len(x) == 2
    assert len(x) == 2
    assert type(len(x)) == int
    assert x[0:1] == [1]
    assert type(x[0:1]) == list
    assert x[0:2] == [1, 4]
    assert type(x[0:2]) == list

# Generated at 2022-06-21 12:09:14.609458
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    data = LazyList(x for x in range(100) if x % 2 == 0)
    expt = []
    for i in range(30):
        expt.append(data[i])
    assert expt == list(range(0, 60, 2))



# Generated at 2022-06-21 12:09:26.770413
# Unit test for constructor of class Range
def test_Range():
    for i in range(3,4):
        c1 = Range(3)
        assert c1.length == 3
        assert c1[1] == 1
        c2 = Range(1,10)
        assert c2.length == 9
        assert c2[5] == 6
        c3 = Range(1,11,2)
        assert c3.length == 5
        assert c3[2] == 5


# Generated at 2022-06-21 12:09:28.987327
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3])
    assert list(lst) == [1, 2, 3]
    assert list(lst) == [1, 2, 3]
    assert list(lst) == [1, 2, 3]



# Generated at 2022-06-21 12:09:33.975767
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from hypothesis import given
    from hypothesis.strategies import lists, integers

    @given(lists(integers()))
    def test(x: List[int]) -> None:
        lst = LazyList(x)
        assert len(lst) == len(x)

    test()



# Generated at 2022-06-21 12:09:39.310939
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, [0, 1, 2])) == [[0], [1], [2]]
    assert list(chunk(3, [0, 1, 2])) == [[0, 1, 2]]
    assert list(chunk(3, [0, 1])) == [[0, 1]]
    assert list(chunk(3, [])) == []



# Generated at 2022-06-21 12:09:44.679986
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 1, [-1, 0, 1, 2, 3, 4])) == [2, 3, 4]
    assert list(drop_until(lambda x: x > 1, [])) == []
    assert list(drop_until(lambda x: x > 1, [1])) == []
    assert list(drop_until(lambda x: x > 1, [0, -1, 2])) == [2]



# Generated at 2022-06-21 12:09:56.490302
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert 0 == len(r)
    try:
        r[0]
        assert False, "Must throw TypeError"
    except TypeError:
        pass
    r = Range(1, 10 + 1)
    assert 10 == len(r)
    for i in range(10):
        assert i + 1 == r[i]
    for i in range(10):
        assert i + 1 == r[-i - 1]
    for i in range(0, 9, 2):
        assert i + 1 == r[i]
    for i in range(0, 9, 2):
        assert i + 1 == r[i]
    slices = [slice(i, j, k) for i in range(-2, 2) for j in range(-2, 2) for k in range(-2, 2)]


# Generated at 2022-06-21 12:09:58.933895
# Unit test for method __next__ of class Range
def test_Range___next__():
    """Unit test for method __next__ of class Range
    """
    # raise NotImplementedError



# Generated at 2022-06-21 12:10:07.297078
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(1, 10)
    r2 = Range(2, 3)
    assert r1.l == 1, "Error in r1.l"
    assert r1.r == 10, "Error in r1.r"
    assert r1.step == 1, "Error in r1.step"
    assert r1.val == 1, "Error in r1.val"
    assert r1.length == 9, "Error in r1.length"
    assert r2.l == 2, "Error in r2.l"
    assert r2.r == 3, "Error in r2.r"
    assert r2.step == 1, "Error in r2.step"
    assert r2.val == 2, "Error in r2.val"

# Generated at 2022-06-21 12:10:19.014830
# Unit test for function split_by
def test_split_by():
    # no criterion
    assert [list(x) for x in split_by(range(10))] == [[x] for x in range(10)]
    # criterion is not default
    assert [list(x) for x in split_by(range(10), criterion=lambda x: x % 3 == 0)] == [[1, 2], [4, 5], [7, 8]]
    # empty_segments is not default
    assert [list(x) for x in split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)] \
           == [[], [1, 2], [4, 5], [7, 8], []]
    # separator is not default:

# Generated at 2022-06-21 12:10:22.378813
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-21 12:10:41.841214
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    r = range(5)
    assert list(MapList(lambda x: x * x, a)) == [x * x for x in a]
    assert list(MapList(lambda idx: a[idx] * r[idx], range(5))) == [a[k] * r[k] for k in range(5)]



# Generated at 2022-06-21 12:10:48.741398
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
# Hide test_split_by from nosetests
del test_split_by



# Generated at 2022-06-21 12:10:52.940693
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(0))) == []



# Generated at 2022-06-21 12:10:54.886343
# Unit test for constructor of class LazyList
def test_LazyList():
    list = LazyList(range(10))
    assert isinstance(list, LazyList)
    assert isinstance(list, Sequence)


# Generated at 2022-06-21 12:11:00.248712
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(1, 10, 2)) == 4
    r2 = Range(0, 10)
    assert len(r2) == 10
    # Test if __len__ is lazy
    r3 = Range(0, 100)
    for i in r3:
        pass
    assert len(r3) == 100
    # Test invalid index
    assert len(Range(0, 0)) == 0
    assert len(Range(1, 0)) == 0
    assert len(Range(1, -1)) == 0
    assert len(Range(1, 1)) == 0
    assert len(Range(1, 2, -1)) == 0


# Generated at 2022-06-21 12:11:04.386921
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(range(1, 100))
    assert lst[3] == 4
    assert len(lst) == 99
    assert lst[92] == 93
    assert lst == list(range(1, 100))
    assert lst == range(1, 100)



# Generated at 2022-06-21 12:11:09.593251
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    class A(object):
        def __init__(self, x):
            self.x = x
        def __eq__(self, other):
            return isinstance(other, A) and (self.x == other.x)
    def test(lst):
        for i in range(len(lst)):
            for j in range(len(lst) - i):
                assert list(LazyList(lst)[:j]) == lst[:j]
                assert list(LazyList(lst)[j:]) == lst[j:]
                assert list(LazyList(lst)[i:j]) == lst[i:j]
                assert list(LazyList(lst)[j:i]) == lst[j:i]
    test([])
    test([1, 2, 3])
   

# Generated at 2022-06-21 12:11:14.160475
# Unit test for constructor of class Range
def test_Range():
    range1 = Range(1, 11, 2)
    range2 = Range(5, stop=None, step=5)
    range3 = Range(start=1, stop=10 + 1)
    range4 = Range(1)
    assert range1 == range2 == range3 == range4 == [1, 3, 5, 7, 9]


# Generated at 2022-06-21 12:11:21.551336
# Unit test for constructor of class Range
def test_Range():
    assert Range(10, 10) == []
    assert Range(0, 10, 3) == [0, 3, 6, 9]
    assert Range(-4, -4) == []
    assert Range(-4, -2) == [-4, -3]

    # out of bound: slice
    assert Range(-5, 5, 2)[5:] == [4]
    assert Range(-5, 5, 2)[:5] == [-4, -2, 0, 2]
    assert Range(-5, 5, 2)[2:5] == [2, 4]


# Generated at 2022-06-21 12:11:23.245472
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    ml = MapList(lambda x: x*x, range(100))
    assert len(ml) == 100



# Generated at 2022-06-21 12:11:36.581321
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    ml = MapList(lambda x: x * 2, range(10))
    assert len(ml) == 10



# Generated at 2022-06-21 12:11:40.888812
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-21 12:11:44.819021
# Unit test for function chunk
def test_chunk():
    iterable = list(range(10))
    expected = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    actual = list(chunk(3, iterable))
    assert actual == expected
test_chunk()



# Generated at 2022-06-21 12:11:47.408599
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = LazyList(range(5))
    for i in it:
        assert(i == it[i])



# Generated at 2022-06-21 12:11:56.409553
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    for idx in range(5):
        list(LazyList([1, 2, 3, 4, 5, 6, 7])[:idx])

    for idx in range(5):
        list(LazyList([1, 2, 3, 4, 5, 6, 7])[idx:])

    for idx in range(5):
        list(LazyList([1, 2, 3, 4, 5, 6, 7])[idx:7])

    for idx in range(5):
        list(LazyList([1, 2, 3, 4, 5, 6, 7])[idx:idx + 2])

    for idx in range(-5, 5):
        LazyList([1, 2, 3, 4, 5, 6, 7])[idx]


# Generated at 2022-06-21 12:11:59.659673
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(5))) == []
    assert list(drop(5, range(10))) == list(range(5,10))


# Generated at 2022-06-21 12:12:07.009537
# Unit test for function drop_until
def test_drop_until():
    # Test passing
    expected_output = [6, 7, 8, 9]
    actual_output = list(drop_until(lambda x: x > 5, range(10)))
    assert(actual_output == expected_output)
    # Test failing
    expected_output = [2, 3, 4, 5]
    actual_output = list(drop_until(lambda x: x > 5, range(10)))
    assert(actual_output != expected_output)



# Generated at 2022-06-21 12:12:17.030864
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # the iteration is only started after an index is accessed
    l = LazyList(range(10))
    assert len(l.list) == 0, "items should not be fetched without accessing them"
    assert l[2] == 2, "item is not fetched correctly"
    assert len(l.list) == 3, "wrong number of items fetched"
    assert l[-1] == 9, "item is not fetched correctly"
    assert len(l.list) == 10, "wrong number of items fetched"
    assert l[9] == 9, "item is not fetched correctly"
    assert len(l.list) == 10, "wrong number of items fetched"
    assert l[10:12] == [], "slice is not fetched correctly"

# Generated at 2022-06-21 12:12:23.648334
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [], 0)) == [0]
    assert list(scanr(operator.add, [1], 0)) == [1, 0]
    assert list(scanr(operator.add, [1, 2, 3], 0)) == [6, 3, 1, 0]



# Generated at 2022-06-21 12:12:27.602409
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(itertools.count())
    for _ in range(10):
        assert next(lst) == next(iter(lst))
    for _ in range(10):
        assert next(lst[0:]) == next(iter(lst))



# Generated at 2022-06-21 12:12:43.199125
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-21 12:12:50.884403
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(100000))
    assert l[-1] == l[9999] == 99999
    assert l[3:8] == list(range(3, 8))
    assert l[:3] == list(range(3))
    with pytest.raises(TypeError):
        len(l)
    assert len(list(l)) == 100000
    assert len(list(l)) == 100000
    assert len(l) == 100000



# Generated at 2022-06-21 12:12:56.574578
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(0, 10, 2))) == [6, 8]
    assert list(drop_until(lambda x: x > 5, range(0, 10, -1))) == []


# Generated at 2022-06-21 12:13:04.344937
# Unit test for constructor of class MapList
def test_MapList():
    # Test single value
    assert MapList(lambda x: x, [1, 2, 3, 4, 5])[0] == 1, 'Error: MapList does not work for single values'
    # Test slice
    assert MapList(lambda x: x, [1, 2, 3, 4, 5])[1:2] == [2], 'Error: MapList does not work for slices'
    # Test whole list
    assert MapList(lambda x: x, [1, 2, 3, 4, 5])[:] == [1, 2, 3, 4, 5], 'Error: MapList does not work for whole list'
    # Test for empty slice
    assert MapList(lambda x: x, [1, 2, 3, 4, 5])[1:1] == [], 'Error: MapList does not work for empty slices'
    # Test

# Generated at 2022-06-21 12:13:08.816546
# Unit test for constructor of class MapList
def test_MapList():
  test_map_list = MapList(lambda x:x*x, [1,2,3])
  assert list(test_map_list) == [1,4,9]


# Generated at 2022-06-21 12:13:14.964978
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from typing import Any
    lst = list(range(10))
    ll = LazyList(lst)
    assert hasattr(iter(ll), "__next__")
    # noinspection PyTypeChecker
    for i, x in enumerate(ll):
        assert x == lst[i]
    for i in range(10):
        assert ll[i] == lst[i]



# Generated at 2022-06-21 12:13:23.148941
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for r in Range(0, 10), Range(0, 10, 2), Range(5, -5):
        for i in range(0, len(r)):
            assert r[i] == i * r.step + r.l
        for i in range(-len(r), 0):
            assert r[i] == len(r) + i
        assert (i, j) == (r[i], r[j]) == (0, 4) == r[i:j] == r[i:j:1]
        assert (k, l) == (r[k], r[l]) == (5, 8) == r[k:l] == r[k:l:1]
        assert (m, n) == (r[m], r[n]) == (9, 1) == r[m:n:-1]

# Generated at 2022-06-21 12:13:34.210910
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)
    assert r.val == 0
    assert next(r) == 0
    assert next(r) == 1
    assert next(r) == 2
    raise_assert(StopIteration, next, r)

    r = Range(1, 10 + 1)
    assert r.val == 1
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    raise_assert(StopIteration, next, r)

    r = Range(1, 11, 2)
    assert r.val == 1
    assert next(r) == 1
    assert next(r) == 3
    assert next(r) == 5
    raise_assert(StopIteration, next, r)



# Generated at 2022-06-21 12:13:40.428272
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(' Split by: ', empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                  ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-21 12:13:44.510370
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    def func(x: int) -> int:
        return x ** 2

    lst = [1, 2, 3, 4, 5]
    assert list(MapList(func, lst)) == list(map(func, lst))

# Generated at 2022-06-21 12:14:07.420857
# Unit test for function take
def test_take():
    assert [0] == list(take(1, range(1)))
    assert [0, 1] == list(take(2, range(2)))


# Generated at 2022-06-21 12:14:16.583346
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    def test_valid_indices(start, stop, step, idx):
        r = Range(start, stop, step)
        r_idx = r[idx]
        r_idx_computed = start + step * idx
        assert r_idx == r_idx_computed

    test_valid_indices(10, 20, 1, 0)
    test_valid_indices(10, 20, 3, 2)
    test_valid_indices(10, 20, 3, 3)
    test_valid_indices(10, 20, 3, 4)
    test_valid_indices(10, 20, 3, -1)
    test_valid_indices(10, 20, 3, -2)
    test_valid_indices(10, 20, 3, -5)
    test_

# Generated at 2022-06-21 12:14:23.157438
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    assert isinstance(r, Iterator), "Range(10) should be an iterator"
    r = Range(1, 10 + 1)
    assert isinstance(r, Iterator), "Range(1, 10 + 1) should be an iterator"
    r = Range(1, 11, 2)
    assert isinstance(r, Iterator), "Range(1, 11, 2) should be an iterator"

# Generated at 2022-06-21 12:14:32.793638
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert LazyList(range(10))[0] == 0
    assert LazyList(range(10))[1] == 1
    assert LazyList(range(10))[-1] == 9
    assert LazyList(range(10))[9] == 9
    assert LazyList(range(10))[10] == 10
    assert LazyList(range(10))[3:9:2] == [3, 5, 7]
    with pytest.raises(IndexError):
        _ = LazyList(range(10))[10]



# Generated at 2022-06-21 12:14:36.773436
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:14:39.869227
# Unit test for constructor of class Range
def test_Range():
    range1 = Range(3)
    assert range1.l == 0
    assert range1.r == 3
    assert range1.step == 1
    range2 = Range(0, 10, 2)
    assert range2.l == 0
    assert range2.r == 10
    assert range2.step == 2



# Generated at 2022-06-21 12:14:50.072551
# Unit test for method __len__ of class Range
def test_Range___len__():
    # Iterable
    assert len(Range(1, 10)) == 9
    assert len(Range(0, 10, 2)) == 5
    assert len(Range(1, 10, 2)) == 4
    assert len(Range(2, 10, 2)) == 4
    assert len(Range(len([1, 2, 3]))) == 3
    assert len(Range(len([]))) == 0
    assert len(Range(0, -3)) == 0
    assert len(Range(0, -3, -1)) == 3
    # Iterator
    try:
        len(Range(1, 5))
    except TypeError:
        pass
    else:
        raise Exception("This line should not be reached")
test_Range___len__()


# Generated at 2022-06-21 12:14:57.742531
# Unit test for method __len__ of class Range
def test_Range___len__():
    # Test cases
    # case01:
    try:
        r = Range(0, 5)
        print(r)
        assert len(r) == 5

        r = Range(0, 1)
        assert len(r) == 1

        r = Range(5, 10)
        assert len(r) == 5
    except:
        traceback.print_exc(file=sys.stderr)

    # case02:
    try:
        r = Range(0, 0)
        print(r)
        assert len(r) == 0

        r = Range(5, 5)
        assert len(r) == 0

        r = Range(0, -5)
        assert len(r) == 0
    except:
        traceback.print_exc(file=sys.stderr)

    # case03:

# Generated at 2022-06-21 12:15:05.558107
# Unit test for function chunk
def test_chunk():
    """Test utility function chunk."""
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]
    assert list(chunk(16, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(0, range(10))) == ValueError



# Generated at 2022-06-21 12:15:08.179864
# Unit test for function drop
def test_drop():
    r"""Unit tests for function drop"""
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(15, range(10))) == []
    assert list(drop(15, [])) == []



# Generated at 2022-06-21 12:15:53.455195
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from mean_teacher.utils.iterators import LazyList

    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[4] == 4
    assert lst[4:7] == [4, 5, 6]



# Generated at 2022-06-21 12:16:00.972816
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(3))) == 3
    with pytest.raises(TypeError):
        len(LazyList((x for x in range(3))))
    assert len(iter(LazyList(range(3)))) == 3
    assert len(LazyList(range(3))[:]) == 3
    assert len(LazyList(range(3))[::]) == 3
    assert len(LazyList(range(3))[::2]) == 2

# Generated at 2022-06-21 12:16:09.071032
# Unit test for method __next__ of class Range
def test_Range___next__():
    it = iter(Range(1, 3))
    assert_true(next(it) == 1)
    assert_true(next(it) == 2)
    it = iter(Range(1, 3 + 1))
    assert_true(next(it) == 1)
    assert_true(next(it) == 2)
    assert_true(next(it) == 3)
    it = iter(Range(1, 3 + 1, 2))
    assert_true(next(it) == 1)
    assert_true(next(it) == 3)


# Generated at 2022-06-21 12:16:15.393934
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [], 0)) == [0]
    assert list(scanr(operator.add, [1, 2, 3], 0)) == [6, 5, 3, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-21 12:16:18.262401
# Unit test for function drop_until
def test_drop_until():
    def test_fail():
        list(drop_until(lambda x: x > 5, iter([4, 3, 2, 1, 0])))
    assert raises(StopIteration, test_fail)



# Generated at 2022-06-21 12:16:25.669211
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x + 1, [1, 2, 3, 4, 5])[1] == 3
    assert MapList(lambda x: x + 1, [1, 2, 3, 4, 5])[1:3] == [3, 4]
    try:
        MapList(lambda x: x + 1, [1, 2, 3, 4, 5])[:]
    except AssertionError:
        pass
    else:
        assert False, "Expected AssertionError"

# __pdoc__["__main__.MapList.__iter__"] = False
# __pdoc__["__main__.MapList.__len__"] = False

# Generated at 2022-06-21 12:16:28.969452
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert len(lst) == 5

# Generated at 2022-06-21 12:16:30.768275
# Unit test for function drop
def test_drop():
    assert list(drop(4, range(10))) == list(range(4, 10))

# Generated at 2022-06-21 12:16:38.229271
# Unit test for constructor of class LazyList
def test_LazyList():
    l = LazyList(range(1,2**14))
    assert(len(l) == l[-1]+1)
    assert(l[0] == 0)
    l[-1]
    assert(len(l) == l[-1]+1)
    assert(l[0] == 0)
    l[2**15]
    assert(len(l) == l[-1]+1)
    assert(l[0] == 0)
    l = LazyList(range(1, 2**14))
    assert(next(iter(l)) == 0)
    assert(len(l) == l[-1]+1)
    assert(l[0] == 0)
    l[-1]
    assert(len(l) == l[-1]+1)

# Generated at 2022-06-21 12:16:45.757857
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3], 0)) == [0, 1, 3, 6]
    assert list(scanl(lambda x, y: x * y, [1, 2, 3])) == [1, 2, 6]
    assert list(scanl(lambda x, y: x * y, [1, 2, 3, 4])) == [1, 2, 6, 24]

