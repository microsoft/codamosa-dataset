

# Generated at 2022-06-25 16:45:01.590622
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    result = Range.__getitem__(range_0, 0)
    print(result)


# Generated at 2022-06-25 16:45:07.594432
# Unit test for function drop_until
def test_drop_until():
    # Simple case
    list_0 = list(drop_until(lambda x: x > 2, range(10)))
    assert list_0 == [3, 4, 5, 6, 7, 8, 9]
    # Empty case
    list_1 = list(drop_until(lambda x: x > 20, range(10)))
    assert list_1 == []


# Generated at 2022-06-25 16:45:14.094219
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range()
    range_1 = Range()
    range_2 = Range()
    range_2.__next__()
    range_1.__next__()
    range_0.__next__()


# Generated at 2022-06-25 16:45:19.431120
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-25 16:45:25.339076
# Unit test for function take
def test_take():
    assert isinstance(take(5, range(5, 10)), iterator)
    assert list(take(5, range(5, 10))) == [5,6,7,8,9]
    assert list(take(5, range(10))) == [0,1,2,3,4]
    assert list(take(5, range(5))) == [0,1,2,3,4]
    



# Generated at 2022-06-25 16:45:35.254792
# Unit test for function take
def test_take():
    # case0: n = 0
    range_0 = Range(1)
    L0 = list(take(0, range_0))
    assert L0 == list()
    # case1: n = 5
    range_5 = Range(5)
    L1 = list(take(5, range_5))
    assert L1 == [0, 1, 2, 3, 4]
    # case2: n < 0
    range_2 = Range(2)
    try:
        L2 = list(take(-1, range_2))
    except ValueError:
        assert True
    except Exception:
        assert False
    else:
        assert False
    # case3: n > len(iterable)
    range_3 = Range(3)
    L3 = list(take(5, range_3))
    assert L

# Generated at 2022-06-25 16:45:46.202023
# Unit test for function split_by
def test_split_by():
    # split_by(iterable: Iterable[A], empty_segments: bool = False, criterion: Callable[[A], bool] = None, separator: A = None)
    test_arr_0 = range(10)
    test_criterion_0 = None
    test_separator_0 = None
    returned_var = list(split_by(test_arr_0, test_separator_0))

# Generated at 2022-06-25 16:45:51.589276
# Unit test for function drop
def test_drop():
    assert list(drop(1, range(3))) == [1, 2]
    assert list(drop(3, range(3))) == []
    assert list(drop(4, range(3))) == []
    assert list(drop(0, range(1))) == [0]
    assert list(drop(0, range(3))) == [0, 1, 2]


# Generated at 2022-06-25 16:45:55.418699
# Unit test for function take
def test_take():
    x = take(5, range(1000000))
    y = [0, 1, 2, 3, 4]
    assert type(x) == type(y), "Function failed: type(x) != type(y)"
    for i in range(len(y)):
        assert x[i] == y[i], "Function failed: x[i] != y[i]"


# Generated at 2022-06-25 16:46:01.216753
# Unit test for function drop_until
def test_drop_until():
    # Test 1: drop 0 elements
    arr = [1, 2, 3]
    result = list(drop_until(lambda x: x > 0, arr))
    assert result == arr

    # Test 2: drop non-zero elements
    result = list(drop_until(lambda x: x >= 0, arr))
    assert result == [1, 2, 3]

    # Test 3: drop all elements
    result = list(drop_until(lambda x: x > 10, arr))
    assert result == []


# Generated at 2022-06-25 16:46:15.022491
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1,2,1,2,1,2], criterion=lambda x: x == 1)) == [[2, 2], [2]]
    assert list(split_by(['hello','world','!'], criterion=lambda x: x == 'hello')) == [['world', '!']]


# Generated at 2022-06-25 16:46:18.097497
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst_0 = LazyList([4, 9, 6, 2, 5])
    lst_0.__getitem__(3)


# Generated at 2022-06-25 16:46:21.346909
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    range_1 = Range(1, 2, 3)
    assert range_0[0] == 0
    assert range_1[0] == 1
    assert range_1[1] == 2


# Generated at 2022-06-25 16:46:25.456001
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import random
    range_1 = Range()
    random.seed(0)
    for i in range(len(range_1)):
        assert range_1[i] == i


# Generated at 2022-06-25 16:46:29.600579
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert (split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]


# Generated at 2022-06-25 16:46:32.584180
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(0, 10))
    assert ll[0] == 0
    assert ll[5] == 5
    assert ll[9] == 9
    assert ll[10] == None

# Generated at 2022-06-25 16:46:36.005855
# Unit test for function drop_until
def test_drop_until():
    # range_0 = Range()
    # assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert True


# Generated at 2022-06-25 16:46:39.810690
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    actual_result = range_0[0]
    expected_result = 0
    assert expected_result == actual_result, f"expected: {expected_result}, actual: {actual_result}"


# Generated at 2022-06-25 16:46:47.407519
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda x: x
    lst = [1, 2, 3, 4, 5]
    map_list = MapList(func, lst)
    assert map_list[0] == 1
    assert map_list[1] == 2
    assert map_list[2] == 3
    assert map_list[3] == 4
    assert map_list[4] == 5
    assert map_list[2:3] == [3]


# Generated at 2022-06-25 16:46:53.014279
# Unit test for function chunk
def test_chunk():
    chunk_0 = chunk(3, range(10))
    chunk_1 = chunk(3, range(10))

    assert range(10) == range(10) and chunk_0 == chunk_1
    assert chunk_0 != range(10) and range(10) == chunk_1



# Generated at 2022-06-25 16:47:08.861336
# Unit test for function chunk
def test_chunk():

    # Test 1: n = 0
    try:
        list(chunk(0, range(10)))
    except ValueError:
        pass
    else:
        assert False

    # Test 2: n = -3
    try:
        list(chunk(-3, [1, 2, 3]))
    except ValueError:
        pass
    else:
        assert False

    # Test 3: n = 3
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    # Test 4: n = 3
    assert list(chunk(3, range(1, 10))) == [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    # Test 5: n = 3

# Generated at 2022-06-25 16:47:14.172074
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    list_0 = ArrayList()
    list_0.add(0)
    list_0.add(1)
    list_0.add(-1)
    int_0 = LazyList(list_0).__iter__().__next__()
    assert int_0  == 0
    
    


# Generated at 2022-06-25 16:47:24.716934
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Setup
    iterable_0 = (2, 1)
    lazy_list = LazyList(iterable_0)
    try:
        lazy_list_0 = len(lazy_list)
    except TypeError as e:
        pass
    else:
        raise AssertionError("TypeError not raised")
    list_0 = list(iterable_0)
    lazy_list = LazyList(iterable_0)
    lazy_list._fetch_until(None)
    try:
        lazy_list_0 = len(lazy_list)
    except TypeError:
        raise AssertionError("TypeError raised unexpectedly")
    else:
        assert lazy_list_0 == len(list_0)


# Generated at 2022-06-25 16:47:30.505922
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(iter(range(10)))) == list(range(10))
    assert list(LazyList(iter(range(10)))[0:]) == list(range(10))
    assert list(LazyList(iter(range(10)))[1:]) == list(range(1, 10))
    assert list(LazyList(iter(range(10)))[1:1]) == []


# Generated at 2022-06-25 16:47:35.086586
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    range_0 = Range()
    for i in range_0:
        assert lst[i] == i + 1
    range_1 = Range()
    for i in range_1:
        assert lst[i] == i + 1


# Generated at 2022-06-25 16:47:45.745354
# Unit test for function chunk
def test_chunk():
    l, n = range(10), 3
    assert list(chunk(n, l)) == [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [9]
    ]
    l, n = range(10), 5
    assert list(chunk(n, l)) == [
        [0, 1, 2, 3, 4],
        [5, 6, 7, 8, 9]
    ]
    l, n = range(10), 10
    assert list(chunk(n, l)) == [
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    ]
    l, n = range(10), 11

# Generated at 2022-06-25 16:47:57.822405
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(5, range(10))) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(2))) == [[0, 1]]

# Generated at 2022-06-25 16:48:00.512650
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Test case0, has exception
    try:
        test_case_0()
        print('Test case #1, succeed')
    except Exception as e:
        print('Test case #1, failed')


# Generated at 2022-06-25 16:48:03.522372
# Unit test for function drop_until
def test_drop_until():
    iterable = [0, 1, 2, 3, 4, 7, 6, 5]
    lst = drop_until(lambda x: x > 4, iterable)
    assert lst == [7, 6, 5], "Expected [7, 6, 5]"


# Generated at 2022-06-25 16:48:07.093676
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    assert isinstance(range_0.__iter__(), Iterator)
    assert isinstance(range_0.__iter__(), Iterator)


# Generated at 2022-06-25 16:48:22.713205
# Unit test for function drop_until
def test_drop_until():
    # Test for empty list
    l1 = drop_until(lambda x: x < 0, [])
    if len(list(l1)) != 0:
        raise ValueError("Function drop_until() produced an unexpected result")
    # Test for list with only one element
    l2 = drop_until(lambda x: x < 0, [-1])
    if len(list(l2)) != 1:
        raise ValueError("Function drop_until() produced an unexpected result")
    # Test for list with only one element that satisfies the predicate
    l3 = drop_until(lambda x: x < 0, [5])
    if len(list(l3)) != 0:
        raise ValueError("Function drop_until() produced an unexpected result")
    # Test for normal case

# Generated at 2022-06-25 16:48:23.983847
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList.__getitem__() == ""


# Generated at 2022-06-25 16:48:26.064516
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    list_0 = LazyList()
    assert list_0[0] is None
    assert list_0[2] is None


# Generated at 2022-06-25 16:48:28.459009
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    test_cases = [
    ]
    for test_case in test_cases:
        test_case()



# Generated at 2022-06-25 16:48:33.473553
# Unit test for function drop_until
def test_drop_until():
    values = [1,3,5,6,8,9,10,16]
    expected = [6,8,9,10,16]
    actual = list(drop_until(lambda x: x > 5, values))
    assert expected == actual



# Generated at 2022-06-25 16:48:44.619553
# Unit test for function split_by
def test_split_by():
    str_0 = "Split by: "
    assert split_by(str_0, separator='.') == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert split_by(str_0, True, separator='.') == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert split_by(str_0, criterion=lambda x: x != ':') == [['S', 'p', 'l', 'i', 't', 'b', 'y', ':']]

# Generated at 2022-06-25 16:48:47.300690
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    ml = MapList(lambda x: x + 1, [1, 2, 3, 4, 5])
    assert ml[2] == 4
    assert ml[0:4:2] == [2, 4]


# Generated at 2022-06-25 16:48:49.193387
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for (seq, flag, index) in [(Range(2), 'NONE', 0), (Range(5), 'NONE', 0), (Range(3), 'NONE', 0), (Range(0), 'NONE', 0), (Range(1), 'NONE', 0)]:
        print(seq[index])


# Generated at 2022-06-25 16:48:53.804603
# Unit test for function drop_until
def test_drop_until():
    iterator_0 = drop_until(lambda x: x > 5, range(10))
    assert isinstance(iterator_0, Iterator)
    print('passed test_drop_until')


# Generated at 2022-06-25 16:48:58.871658
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func_0 = lambda x : x * x
    lst_0 = Range(10)

    # Test 1
    mapList_0 = MapList(func_0, lst_0)
    mapList_0.__getitem__(3)

    # Test 2
    mapList_1 = MapList(func_0, lst_0)
    mapList_1.__getitem__(1)

# Generated at 2022-06-25 16:49:27.987378
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    it_0 = LazyList(iter(range(10)))
    a_0 = it_0[9]
    assert a_0 == 9
    a_1 = it_0[-1]
    assert a_1 == 9
    a_2 = it_0[:5]
    assert a_2 == [0, 1, 2, 3, 4]
    a_3 = it_0[:10]
    assert a_3 == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    a_4 = it_0[:11]
    assert a_4 == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    it_1 = LazyList(iter(range(10)))

# Generated at 2022-06-25 16:49:31.942467
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    v: LazyList[int] = LazyList(range(10))
    v._fetch_until(None)
    v[0]
    v[-1]
    v[1:10]


# Generated at 2022-06-25 16:49:35.767608
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    assert [0, 1] == range_0[0:2]
    assert [0, 1] == range_0[0:2]  # 2nd time: caching


# Generated at 2022-06-25 16:49:38.880364
# Unit test for function drop_until
def test_drop_until():
    array = [1,2,3,4,5,6,7,8,9,10]
    print(list(drop_until(lambda x: x > 6, array)))


# Generated at 2022-06-25 16:49:41.131154
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    list_0 = [1, 13, 13, 13, 13, 13]
    mapList_0 = MapList(sqrt, list_0)
    assert (mapList_0[4] == 13)
    mapList_0.__getitem__(4)


# Generated at 2022-06-25 16:49:44.154954
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    l = MapList(lambda el: el ** 2, [1, 2, 3, 4, 5])
    print(l[0], l[2], l[4])
    print(l[-1])
    print(l[0:3])
    print(l[1:])


# Generated at 2022-06-25 16:49:46.918617
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    assert list(drop_until(lambda x: x > 5, range_0)) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:49:51.128887
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # range_0 = Range(10)
    # list(range_0)
    # for _ in range(100):
    #     assert 0 <= random.randint(0, 9) < 10
    pass


# Generated at 2022-06-25 16:49:54.156426
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def test_0(param_0 = {}):
        m = MapList()
        m.__getitem__(param_0)
    test_0()


# Generated at 2022-06-25 16:49:58.050512
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    def pred_fn(element):
        if element == 5:
            return True
        return False
    filtered_iterable = drop_until(pred_fn, range_0)
    for element in filtered_iterable:
        print(element)
# End unit test


# Generated at 2022-06-25 16:50:10.383959
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    assert range_0[0] == 0
    assert range_0[1] == 1
    assert range_0[9] == 9
    assert range_0[0:1] == [0]
    assert range_0[1:3] == [1, 2]


# Generated at 2022-06-25 16:50:15.022788
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(10)
    range_3 = Range(1, 10 + 1)
    range_4 = Range(1, 11, 2)
    range_4[0]
    range_4[2]
    range_4[4]


# Generated at 2022-06-25 16:50:21.709821
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))
    print(list(drop_until(lambda x: x > 5, range(5))))
    print(list(drop_until(lambda x: x < 5, range(10))))
    #print(list(drop_until(lambda x: x , range(10))))
    print(list((drop_until(lambda x: x < 5, MapList(lambda x: x * x, range(10))))))

test_drop_until()
    

# Generated at 2022-06-25 16:50:29.724234
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda x: x * x
    lst = [1, 2, 3, 4, 5]
    r = MapList(func, lst)

    assert(r[0] == 1)
    assert(r[1] == 4)
    assert(r[2] == 9)
    assert(r[3] == 16)
    assert(r[4] == 25)
    assert(r[-5] == 1)
    assert(r[-1] == 25)
    assert(r[-2] == 16)
    assert(r[-3] == 9)

    assert(r[0: 2] == [1, 4])
    assert(r[2:] == [9, 16, 25])
    assert(r[: -2] == [1, 4])

# Generated at 2022-06-25 16:50:33.981881
# Unit test for function drop_until
def test_drop_until():
    # test 1: test normal case
    x = drop_until(lambda x: x > 5, range(10))
    assert list(x) == [6, 7, 8, 9]
    # test 2: test empty case
    x = drop_until(lambda x: x > 5, [])
    assert list(x) == []



# Generated at 2022-06-25 16:50:35.191483
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()


# Generated at 2022-06-25 16:50:37.654223
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range(-1, 10)
    print(range_1[0])
    return range_1[0]


# Generated at 2022-06-25 16:50:42.333508
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    logger.begin_test("test_MapList___getitem__")
    array = MapList(lambda x : x, [1, 2, 3])
    assert array[0] == 1
    logger.end_test("test_MapList___getitem__")

test_MapList___getitem__()


# Generated at 2022-06-25 16:50:47.896498
# Unit test for function drop_until
def test_drop_until():
    """
    Test function drop_until

    :return: None
    """
    # Input
    iterable = range(10)
    pred_fn = lambda x: x > 5
    # Expected Output
    # [6, 7, 8, 9]
    expected_output = [6, 7, 8, 9]
    # Run function
    output = list(drop_until(pred_fn, iterable))
    # Check the result
    assert output == expected_output
    # Print pass or fail
    print("Pass" if output == expected_output else "Fail")



# Generated at 2022-06-25 16:50:51.513918
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-25 16:51:11.134469
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    print('Testing of __getitem__ method of class MapList')

    lst_0 = MapList(lambda i: i, Range(5))

    try:
        assert lst_0[:3] == [0, 1, 2]
    except AssertionError:
        print('AssertionError raised on line number: ' +
              str(inspect.currentframe().f_lineno))
    except Exception:
        print('Exception raised on line number: ' +
              str(inspect.currentframe().f_lineno))

    try:
        assert lst_0[:1:-1] == [3, 2]
    except AssertionError:
        print('AssertionError raised on line number: ' +
              str(inspect.currentframe().f_lineno))

# Generated at 2022-06-25 16:51:19.294694
# Unit test for function drop_until
def test_drop_until():    
    seq_1 = range(10)
    for i in drop_until((lambda x: x > 5), seq_1):
        if (i < 6):
            raise ValueError(
                'The iterator should have dropped all the elements before 6')

    seq_2 = range(10)
    for i in drop_until((lambda x: x < 0), seq_2):
        if (i != 0):
            raise ValueError(
                'The iterator should not drop any elements when all the elements satisty the condition')

    print('drop_until test complete')


# Generated at 2022-06-25 16:51:21.560465
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    result = list(drop_until(lambda x: x == 2, range_0))
    return(result)


# Generated at 2022-06-25 16:51:24.883124
# Unit test for function drop_until
def test_drop_until():
    iter_0 = Range()
    iter_0 = list(iter_0)
    iter = drop_until(lambda x: x > 5, iter_0)
    assert list(iter) == [6, 7, 8, 9]
    
    

# Generated at 2022-06-25 16:51:32.683346
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    mapList_0 = MapList(lambda x: x, range_0)
    assert mapList_0[0] == 0
    assert mapList_0[0:4] == [0, 1, 2, 3]


# Generated at 2022-06-25 16:51:37.693053
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba'], \
        "Failed test for scanl"


# Generated at 2022-06-25 16:51:39.944806
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0.__getitem__()


# Generated at 2022-06-25 16:51:43.085577
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(6)
    assert range_0[1] == 1


# Generated at 2022-06-25 16:51:55.936493
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    assert list(drop_until((lambda x: x > 5), range_0)) == [6, 7, 8, 9]
    range_1 = Range(10)
    assert list(drop_until((lambda x: x > 5), range_1)) == [6, 7, 8, 9]
    range_2 = Range(start = 0, stop = 10)
    assert list(drop_until((lambda x: x > 5), range_2)) == [6, 7, 8, 9]
    range_3 = Range(start = 0, step = 1)
    assert list(drop_until((lambda x: x > 5), range_3)) == [6, 7, 8, 9]
    range_4 = Range(stop = 10, step = 1)

# Generated at 2022-06-25 16:51:59.429020
# Unit test for function drop_until
def test_drop_until():
    iterable = range(10)
    iterable = drop_until(lambda x: x > 5, iterable)
    biterable = [6, 7, 8, 9]

    assert list(iterable) == biterable



# Generated at 2022-06-25 16:52:13.330603
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    mapList_0 = MapList(None, range_0)
    int_0 = mapList_0[28]
    int_1 = mapList_0[44]
    int_2 = mapList_0[23]
    int_3 = mapList_0[3]
    int_4 = mapList_0[32]
    int_5 = mapList_0[30]
    int_6 = mapList_0[20]
    int_7 = mapList_0[7]
    int_8 = mapList_0[44]
    int_9 = mapList_0[42]
    int_10 = mapList_0[43]
    int_11 = mapList_0[15]
    int_12 = mapList_0[45]
    int_13 = map

# Generated at 2022-06-25 16:52:21.986072
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Declaration of variables
    __args = (1, 2)
    __expected = None

    # Call method with arguments
    range_0 = Range(__args)
    # print("Index 0 (1) = ")
    # print(range_0[0])
    # print("Index 1 (2) = ")
    # print(range_0[1])
    assert range_0[0] == __expected
    assert range_0[1] == __expected


# Generated at 2022-06-25 16:52:28.496990
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    #assert drop_until(lambda x: x > 5, range_0) == 6
    for i in drop_until(lambda x: x > 5, range_0):
        assert i > 5


# Generated at 2022-06-25 16:52:35.890325
# Unit test for function drop_until
def test_drop_until():
    for i in range(10, 0, -1):
        assert list(drop_until(lambda x: x > 5, range(i))) == list(range(6,i))
        assert list(drop_until(lambda x: x > -1, range(i))) == list(range(0,i))
    range_0 = Range()
    assert list(drop_until(lambda x: x > 5, range_0)) == list(range(6,1000000))

Range = Iterable[int]


# Generated at 2022-06-25 16:52:46.820534
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range(10)

# Generated at 2022-06-25 16:52:56.324735
# Unit test for function drop_until
def test_drop_until():
    print("test_drop_until")
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 0, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 50, range(0))) == []
    assert list(drop_until(lambda x: x > -1, range(0))) == []
    assert list(drop_until(lambda x: x > -1, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 0, range(1))) == [0]

# Generated at 2022-06-25 16:52:59.705406
# Unit test for function drop_until
def test_drop_until():
    # Function call
    test_iter = drop_until(lambda x: x > 5, range(10))
    print("Result: ", end = "")
    print(list(test_iter))



# Generated at 2022-06-25 16:53:03.489433
# Unit test for function drop_until
def test_drop_until():
    def test_case_0():
        range_0 = Range(0, 100, 1)
        even_range = drop_until(lambda x : x % 2 != 0 , range_0)
        for n in even_range:
            assert(n % 2 == 0)
    test_case_0()


# Generated at 2022-06-25 16:53:09.288140
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Test 0
    try:
        range_0 = Range()
        range_0.__getitem__(None)
    except TypeError as e:
        print("\033[1;31mTest 0 fails\033[0m")
        print("\033[1;31m" + str(e) + "\033[0m")
    else:
        print("\033[1;32mTest 0 passes\033[0m")



# Generated at 2022-06-25 16:53:18.362133
# Unit test for function drop_until
def test_drop_until():
    import random
    import itertools

    # set up a case with only one idx where f(x) is true
    seq = list(range(100))
    random.shuffle(seq)
    idx = random.randint(0, len(seq) - 1)
    seq[idx] = -1
    # generate random idx's
    idxs = random.sample(range(len(seq)), k=random.randint(10, 15))

    # test case 0: f(x) is always true
    print('Test case 0: f(x) is always true')
    range_0 = Range()
    seq_0 = list(itertools.chain.from_iterable([range_0, seq[idx:]]))

# Generated at 2022-06-25 16:53:43.076191
# Unit test for function drop_until
def test_drop_until():
    # Empty list case
    empty_List = []
    print(list(drop_until(lambda x: x > 5, empty_List)))

    # List with 1 item case
    one_item_list = [3]
    print(list(drop_until(lambda x: x > 5, one_item_list)))

    # List of integers case
    list_of_integers = [1, 2, 3, 4, 5, 6, 7]
    print(list(drop_until(lambda x: x > 5, list_of_integers)))

    # List of strings case
    list_of_strings = ["apple", "pear", "orange", "grape"]
    print(list(drop_until(lambda x: x == "orange", list_of_strings)))

    # List of mixed items case

# Generated at 2022-06-25 16:53:45.001638
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0.__getitem__(3)


# Generated at 2022-06-25 16:53:46.998622
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    mapList_0 = MapList(None, None)
    range_0.__getitem__(None)
    mapList_0.__getitem__(None)


# Generated at 2022-06-25 16:53:54.805764
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(10, 20, 4)
    map_list_0 = MapList(lambda x: x, range_0)
    int_0 = map_list_0[1]
    int_1 = map_list_0[2]
    int_2 = map_list_0[3]
    int_3 = map_list_0[4]
    # assert int_0 == int_1 == int_2 == int_3
    print(f"{int_0} {int_1} {int_2} {int_3}")


# Generated at 2022-06-25 16:54:02.221554
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 10)
    range_0_0 = range_0[0]
    range_0_1 = range_0[1]
    range_0_2 = range_0[2]
    range_0_3 = range_0[3]
    range_0_4 = range_0[4]
    range_0_5 = range_0[5]
    range_0_6 = range_0[6]
    range_0_7 = range_0[7]
    range_0_8 = range_0[8]
    range_0_9 = range_0[9]
    range_0_10 = range_0[10]
    range_0_11 = range_0[11]
    range_0_12 = range_0[12]
    range_0_

# Generated at 2022-06-25 16:54:06.344668
# Unit test for function drop_until
def test_drop_until():
    iterable = iter([0,1,2,3,4,5,6,7,8,9])
    predicate = lambda x : x > 5

    it = drop(5, range(10))

    print(it)


# Generated at 2022-06-25 16:54:07.170558
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    first_0 = MapList(range_0)


# Generated at 2022-06-25 16:54:11.197557
# Unit test for function drop_until
def test_drop_until():
    pred_fn = lambda x: x > 5
    iterable = range(10)
    print(list(drop_until(pred_fn, iterable)))
    # output: [6, 7, 8, 9]

test_drop_until()


# Generated at 2022-06-25 16:54:13.210493
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()

    assert drop_until(lambda x: x > 5, range(10))



# Generated at 2022-06-25 16:54:18.682040
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Case 0
    range_0 = Range(7)
    assert (range_0.__getitem__(7) is None)
    
    # Case 1
    range_1 = Range(1, 8)
    assert (range_1.__getitem__(3) == 4)
    
    # Case 2
    range_2 = Range(1, 9, 2)
    assert (range_2.__getitem__(1) == 3)


# Generated at 2022-06-25 16:54:35.711016
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range(10):
        range_0 = Range(i)
        assert range_0[0] == 0


# Generated at 2022-06-25 16:54:47.291223
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(10)

    # test for case in which func : param func for method __init__ is a lambda
    map_list_0 = MapList(lambda x: x * x, range_0)
    map_list_1 = MapList(lambda x: x * x, range_0)

    # test for case in which func : param func for method __init__ is a lambda
    map_list_3 = MapList(lambda x: x * x, range_0)
    map_list_3.__getitem__(2)

    # test for case in which func : param func for method __init__ is a lambda
    map_list_4 = MapList(lambda x: x * x, range_0)
    map_list_4.__getitem__(2)

    # test for case in which func : param func