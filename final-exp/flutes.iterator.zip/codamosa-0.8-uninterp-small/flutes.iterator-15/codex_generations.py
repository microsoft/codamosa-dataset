

# Generated at 2022-06-25 16:45:06.144827
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list_0 = LazyList(range_0)
    len_0 = list_0.__len__()
    assert(len_0 == int_0)

# The following class implements the interface Iterator

# Generated at 2022-06-25 16:45:13.559183
# Unit test for function split_by
def test_split_by():
    # Init
    type_0 = int
    container_0 = (1, 2, 3)
    container_1 = (0, 0.0)
    container_2 = ' '
    container_3 = (1, )
    container_4 = (1, 1, 2)
    iterator_0 = iter(container_0)
    iterator_1 = iter(container_1)
    iterator_2 = iter(container_2)
    iterator_3 = iter(container_3)
    iterator_4 = iter(container_4)
    # Function call
    ret_0 = list(split_by(container_0))
    ret_1 = list(split_by(container_1, True))
    ret_2 = list(split_by(container_2, True, criterion=(lambda x: True)))

# Generated at 2022-06-25 16:45:21.257929
# Unit test for method __getitem__ of class Range

# Generated at 2022-06-25 16:45:28.586835
# Unit test for function split_by
def test_split_by():
    split_by_0 = split_by(range(10), criterion = lambda x: x % 3 == 0)
    split_by_1 = split_by(" Split by: ", empty_segments = True, separator = '.')
    print(list(split_by_0))
    print(list(split_by_1))
    assert len(list(split_by_0)) == 3
    assert list(split_by_1) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-25 16:45:32.996886
# Unit test for function chunk
def test_chunk():
    print("in test_chunk")
    int_0 = 1
    range_0 = Range()
    assert list(chunk(int_0,range_0)) == list()
    int_1 = 2
    assert list(chunk(int_1,range_0)) == list()
    print("finish test_chunk")


# Generated at 2022-06-25 16:45:35.560560
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst_0 = LazyList([1, 2, 3])
    len_0 = len(lst_0)
    assert len_0 == 3


# Generated at 2022-06-25 16:45:38.389225
# Unit test for function chunk
def test_chunk():
    iter_0 = chunk(int_0, range_0)


# Generated at 2022-06-25 16:45:47.009152
# Unit test for function chunk
def test_chunk():
    chunk_0 = chunk(1, [])
    chunk_1 = chunk(1, [0, 1, 2, 3, 4])
    chunk_2 = chunk(0, [1, 2, 3, 4, 5])
    chunk_3 = chunk(3, range(10))
    chunk_4 = chunk(3, [0, 1, 2, 4, 5])
    chunk_5 = chunk(3, [0, 1, 2, 3, 5])
    assert list(chunk(1, [])) == []
    assert list(chunk(1, [0, 1, 2, 3, 4])) == [[0], [1], [2], [3], [4]]

# Generated at 2022-06-25 16:45:51.999960
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == ([0, 1, 3, 6, 10])
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == (['a', 'ba', 'cba', 'dcba'])



# Generated at 2022-06-25 16:45:57.452012
# Unit test for function split_by
def test_split_by():
    assert [[1, 2], [4, 5], [7, 8]] == list(split_by(range(10), criterion=lambda x: x % 3 == 0))
    assert [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []] == list(split_by(" Split by: ", empty_segments=True, separator='.'))



# Generated at 2022-06-25 16:46:17.042428
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(10000))
    assert l[9999] == 9999
    assert l[3] == 3
    assert l[0] == 0
    assert l[-1] == 9999
    assert l[-5] == 9995
    assert repr(l[:3] == [0, 1, 2])


# Generated at 2022-06-25 16:46:20.302722
# Unit test for function drop_until
def test_drop_until():
    my_list = [1,2,3,4,5]
    for x in drop_until(lambda x: x > 2, my_list):
        print(x)


# Generated at 2022-06-25 16:46:24.531257
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    print("Test passed!\n")


# Generated at 2022-06-25 16:46:27.651188
# Unit test for function drop_until
def test_drop_until():
    test_iterable = [1,2,3,4,5,6,7,8,9]
    test_pred = lambda x: x > 7
    result = drop_until(test_pred, test_iterable)
    print(result)
    assert result == [8, 9]


# Generated at 2022-06-25 16:46:36.325197
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect
    range_0 = Range()
    mapList_0 = MapList((lambda x: x * x), a)
    pos = bisect.bisect_left(mapList_0, 10)
    mapList_1 = MapList((lambda i: a[i] * b[i]), range_0)
    pos = bisect.bisect_left(mapList_1, 10)
    mapList_1 = MapList(lambda i: a[i] * b[i], range_0)
    pos = bisect.bisect_left(mapList_1, 10)


# Generated at 2022-06-25 16:46:39.392237
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    mapList_1 = MapList(range_0, lambda: range_0)
    range_2 = mapList_1[0]


# Generated at 2022-06-25 16:46:50.254597
# Unit test for function drop_until
def test_drop_until():
    ### Test range
    for case_id in range(3):
        if case_id == 0:
            input_iterable = []
            input_pred_fn = lambda x: x > 5
        if case_id == 1:
            input_iterable = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
            input_pred_fn = lambda x: x > 5
        if case_id == 2:
            input_iterable = [-1, -2, -3, -4, -5, -6, -7, -8, -9, -10]
            input_pred_fn = lambda x: x > 5

# Generated at 2022-06-25 16:47:01.523859
# Unit test for function drop_until
def test_drop_until():
    from itertools import islice
    from unittest import TestCase, main

    class TestDropUntil(TestCase):
        def test_0(self):
            ranges = range(10)
            actual = drop_until(lambda x: x > 5, ranges)
            expected = islice(ranges, 6, None)
            self.assertEqual(list(actual), list(expected))

        def test_1(self):
            ranges = range(10)
            actual = drop_until(lambda x: x > 15, ranges)
            expected = []
            self.assertEqual(list(actual), list(expected))

    main()
test_drop_until()


# Generated at 2022-06-25 16:47:03.445653
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))



# Generated at 2022-06-25 16:47:05.130889
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func_0 = MapList()
    idx_0 = func_0[0]


# Generated at 2022-06-25 16:47:21.455848
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range(8):
        if i == 4:
            # assert range_0[i] == 4, f"range_0[{i}] == 4 was expected, but got {range_0[i]}"
            assert range_0[i] == 4
        if i == 2:
            # assert range_0[i] == 2, f"range_0[{i}] == 2 was expected, but got {range_0[i]}"
            assert range_0[i] == 2
        if i == 6:
            # assert range_0[i] == 6, f"range_0[{i}] == 6 was expected, but got {range_0[i]}"
            assert range_0[i] == 6



# Generated at 2022-06-25 16:47:32.548527
# Unit test for function take
def test_take():
    # Case 1: call take(n, Range)
    range_obj = Range(10)
    rslt_1 = take(5, range_obj)
    assert list(rslt_1) == [0,1,2,3,4]

    # Case 2: call take(n, MapList)
    map_list_obj = MapList(range(10), lambda x: x*x)
    rslt_2 = take(5, map_list_obj)
    assert list(rslt_2) == [0, 1, 4, 9, 16]

    # Case 3: call take(n, list)
    list_obj = [0,1,2,3,4,5,6,7,8,9]
    rslt_3 = take(5, list_obj)
    assert list(rslt_3)

# Generated at 2022-06-25 16:47:39.436608
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():

    # Testing if the result == expected
    assert Range(0).__getitem__(0) == 0

    # Testing if the result == expected
    assert Range(1, 10).__getitem__(0) == 1

    # Testing if the result == expected
    assert Range(0, 10, 1).__getitem__(0) == 0

    # Testing if the result == expected
    assert Range(1, 10 + 1, 1).__getitem__(0) == 1

    # Testing if the result == expected
    assert Range(1, 10, 2).__getitem__(0) == 1

    # Testing if the result == expected
    assert Range(1, 11, 2).__getitem__(0) == 1

    # Testing if the result == expected
    assert Range(1, 11, 2).__getitem__(1) == 3



# Generated at 2022-06-25 16:47:40.638723
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    obj = MapList()
    s = slice(0, 1024, 1)
    idx = 0
    obj.__getitem__(idx)


# Generated at 2022-06-25 16:47:45.381929
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # make sure that they access item at the same index
    expected = list(range(10))
    result = list(Range(10))
    assert expected == result
    for i in range(10):
        assert Range(10)[i] == result[i]



# Generated at 2022-06-25 16:47:51.710496
# Unit test for function drop_until
def test_drop_until():
    # Test case 0
    range_0 = Range()
    # Call the function
    result_0 = drop_until(lambda x: x > 5, range_0)
    # Assert the expected result
    assert result_0 == [6, 7, 8, 9]

    # Test case 1
    range_1 = Range()
    # Call the function
    result_1 = drop_until(lambda x: x > 6, range_1)
    # Assert the expected result
    assert result_1 == [7, 8, 9]

    # Test case 2
    range_2 = Range()
    # Call the function
    result_2 = drop_until(lambda x: x > 7, range_2)
    # Assert the expected result
    assert result_2 == [8, 9]

    # Test case 3
    range_3

# Generated at 2022-06-25 16:47:53.575986
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    idx = 1
    range_0 = Range(1, 10 + 1)
    # assert range_0[idx] == 2


# Generated at 2022-06-25 16:48:00.584862
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(100, range(100))) == list(range(100))
    assert list(take(0, range(100))) == []
    assert list(take(101, range(100))) == list(range(100))
    assert list(take(100, iter([]))) == []
    assert list(take(0, iter([]))) == []
    assert list(take(101, iter([]))) == []


# Generated at 2022-06-25 16:48:03.988744
# Unit test for function take
def test_take():
    assert([*take(10, range(100))] == list(range(10)))
    assert([*take(10, range(5))] == list(range(5)))


# Generated at 2022-06-25 16:48:07.713786
# Unit test for function take
def test_take():
    range_0 = Range(1, 10)
    res = take(5, range_0)
    ans = [1, 2, 3, 4, 5]
    assert res == ans


# Generated at 2022-06-25 16:48:23.606421
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Iterator
    names = ['Graham', 'John', 'Terry', 'Eric', 'Terry', 'Michael']
    names = MapList(lambda name: 'Mr. ' + name, names)
    names = iter(names)
    assert next(names) == 'Mr. Graham'
    assert next(names) == 'Mr. John'
    assert next(names) == 'Mr. Terry'
    assert next(names) == 'Mr. Eric'
    assert next(names) == 'Mr. Terry'
    assert next(names) == 'Mr. Michael'

    # Slice
    names = ['Graham', 'John', 'Terry', 'Eric', 'Terry', 'Michael']
    names = MapList(lambda name: 'Mr. ' + name, names)

# Generated at 2022-06-25 16:48:35.027168
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    range_1 = Range(20)
    range_2 = Range(1, 21)
    range_3 = Range(1, 21, 2)
    assert range_0[0] == 0
    assert range_0[1] == 1
    assert range_0[2] == 2
    assert range_0[3] == 3
    assert range_0[4] == 4
    assert range_0[5] == 5
    assert range_0[6] == 6
    assert range_0[7] == 7
    assert range_0[8] == 8
    assert range_0[9] == 9
    assert range_0[10] == 10
    assert range_1[0] == 0
    assert range_1[1] == 1
    assert range_1[2] == 2

# Generated at 2022-06-25 16:48:39.688543
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Test 1
    num = 2
    test_str = "test"
    map_list_obj = MapList(lambda x: (x*x), [num, test_str])
    assert map_list_obj[0] == (4)
    assert map_list_obj[0] == (4)


# Generated at 2022-06-25 16:48:45.878965
# Unit test for function split_by
def test_split_by():
    # Use criterion = lambda x: x % 3 == 0
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    # Use separator = '.'
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-25 16:48:49.261721
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    test_MapList_list = [1, 2, 3, 4, 5]
    test_MapList_func = lambda x : x * x
    test_MapList_obj = MapList(test_MapList_func, test_MapList_list)


# Generated at 2022-06-25 16:48:50.248482
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert [Range(3)[0], Range(3)[1], Range(3)[2]] == [0, 1, 2]


# Generated at 2022-06-25 16:48:50.717851
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass


# Generated at 2022-06-25 16:48:56.366835
# Unit test for function drop_until
def test_drop_until():
    # Arrange
    iterable = range(10)
    pred_fn = lambda x: x > 5

    # Act
    actual = drop_until(pred_fn, iterable)

    # Assert
    expected = [6, 7, 8, 9]
    assert list(actual) == expected



# Generated at 2022-06-25 16:49:04.457531
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda a: a > 3, range(5,6))) == [5]
    assert list(drop_until(lambda a: a > 3, range(5,7))) == [5,6]
    assert list(drop_until(lambda a: a > 3, range(5,8))) == [5,6,7]
    assert list(drop_until(lambda a: a > 3, range(5,2,-1))) == [5,4,3]
    assert list(drop_until(lambda a: a > 3, range(5,-1,-1))) == [5,4,3]
    assert list(drop_until(lambda a: a > 3, range(5,-2,-1))) == [5,4,3,2]

# Generated at 2022-06-25 16:49:15.460445
# Unit test for function drop_until
def test_drop_until():
    # test_case_1
    iter_0 = iter(range(10))
    # Enable the debug mode.
    # In this mode, function drop_until will print debug message
    # by calling function drop_until_debug
    # after the condition if not pred_fn(item): is met.
    Range.enable_debug()
    result_0 = drop_until(lambda x: x > 5, iter_0)
    assert result_0 == [6, 7, 8, 9]
    # Disable the debug mode
    Range.disable_debug()
    # test_case_2
    iter_1 = iter([2, 3])
    result_1 = drop_until(lambda x: True, iter_1)
    assert result_1 == [2, 3]
    # test_case_3
    iter_2 = iter([])


# Generated at 2022-06-25 16:49:33.988265
# Unit test for function split_by
def test_split_by():
    # test_0: Test for criterion split
    iterable = range(10)
    expected = [[1,2],[4,5],[7,8]]
    actual = list(split_by(iterable, criterion=lambda x: x%3==0))
    assert len(actual) is len(expected)
    for e_list, a_list in zip(expected,actual):
        assert e_list == a_list
    # test_1: Test for separator split
    iterable = " Split by: "
    expected = [[],['S','p','l','i','t'],['b','y',':'],[]]
    actual = list(split_by(iterable, empty_segments=True, separator='.'))
    for e_list, a_list in zip(expected,actual):
        assert e_list == a_

# Generated at 2022-06-25 16:49:43.009269
# Unit test for function drop_until
def test_drop_until():
    print('drop_until test case')
    # Test case 0
    print('\tTest case 0')
    test_case_0()
    # Test case 1
    print('\tTest case 1')
    while True:
        try:
            drop_until(lambda: True, [])
        except TypeError:
            break

    drop_until(lambda: True, [1, 2, 3])

    # Test case 2
    print('\tTest case 2')
    drop_until(lambda: True, [2, 3, 4, 5, 6, 7, 8, 9, 10])


# Generated at 2022-06-25 16:49:48.102315
# Unit test for method __getitem__ of class MapList

# Generated at 2022-06-25 16:49:58.396264
# Unit test for function drop_until
def test_drop_until():
    assert [6, 7, 8, 9] == list(drop_until(lambda x: x > 5, range(10)))
    # print('test_case_0')
    # range_0 = Range()
    # print('range_0')
    # print(range_0)
    # print('range_0.take(2)')
    # print(range_0.take(2))
    # print('range_0.take(2).drop_until(lambda x: x > 1)')
    # print(range_0.take(2).drop_until(lambda x: x > 1))
    # print('type(range_0)')
    # print(type(range_0))
    # print('type(range_0.take(2))')
    # print(type(range_0.take(2)))
   

# Generated at 2022-06-25 16:50:02.392296
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range(10)
    print(list(drop_until(lambda x: x > 5, range_0)))
    print('\n')
    range_1 = Range(10)
    print(list(MapList(lambda x: x * 5, range_1)))
    


# Generated at 2022-06-25 16:50:05.208882
# Unit test for function drop_until
def test_drop_until():
    range_0 = list(drop_until(lambda x: x > 5, [1,2,3,4,5,6,7,8]))
    assert range_0 == [6,7,8]
    print(range_0)



# Generated at 2022-06-25 16:50:08.327122
# Unit test for function drop_until
def test_drop_until():
    range_1 = Range()
    for x in drop_until(lambda y: y > 5, range_1):
        if x > 10:
            raise Exception('test_case_0 fails')
    return True


# Generated at 2022-06-25 16:50:10.378033
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:50:21.151460
# Unit test for function drop_until
def test_drop_until():
    test_set = [1,2,3,4,5,6,7,8,9,10]
    # Test for boundary value
    assert list(drop_until(lambda x: x > 5, test_set)) == [6,7,8,9,10]
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x == 1, test_set)) == [1,2,3,4,5,6,7,8,9,10]
    # Randomly generated test case
    test_set = [randint(0,10) for i in range(0,10)]
    test_fn = lambda x: x > 5
    res_list = []
    flag = False
    for val in test_set:
        if flag:
            res

# Generated at 2022-06-25 16:50:24.492290
# Unit test for function drop_until
def test_drop_until():
    iterable_0 = range(1000)
    pred_fn_0 = lambda x: x > 5
    rr = drop_until(pred_fn_0, iterable_0)
    print(list(rr))

test_drop_until()



# Generated at 2022-06-25 16:50:40.144605
# Unit test for function drop_until
def test_drop_until():
    # Create iterable for testing
    it = range(10)
    # Create predicate function for testing
    pred_fn = lambda x: x > 5
    # Test whether the results are the same
    result = drop_until(pred_fn, it)
    assert list(result) == [6, 7, 8, 9] 


# Generated at 2022-06-25 16:50:47.105311
# Unit test for function drop_until
def test_drop_until():
    list_0 = []
    if __name__ == '__main__':
        for i in range(10):
            list_0.append(i)
    # print(list_0)
    list_1 = list(drop_until(lambda x: x > 5, list_0))
    # print(type(list_1))
    # print(list_1)
    if list_0[5] == list_1[0]:
        print("test_drop_until passed!")
    else:
        print("test_drop_until failed!")

test_drop_until()


# Generated at 2022-06-25 16:50:49.295602
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, Range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:50:55.323187
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(0, 0)                     # (start, end)
    range_1 = Range(0, 1)                     # (start, end)
    range_2 = Range(0, 1, 1)                  # (start, end, step)
    range_3 = Range(1, 2)                     # (start, end)
    range_4 = Range(1, 2, 1)                  # (start, end, step)
    range_5 = Range(1, 2, 2)                  # (start, end, step)
    range_6 = Range(2, 3)                     # (start, end)
    range_7 = Range(2, 3, 1)                  # (start, end, step)
    range_8 = Range(2, 3, 2)                  # (start, end, step)

# Generated at 2022-06-25 16:51:03.875242
# Unit test for function drop_until
def test_drop_until():
    # Test case 0
    print("Test case 0")
    range_0 = Range()
    if list(drop_until(lambda x: x > 5, range_0)) != [6, 7, 8, 9]:
        raise RuntimeError("Failed")

    # Test case 1
    print("Test case 1")
    range_1 = Range(1, 100)
    if list(drop_until(lambda x: x > 5, range_1)) != [6, 7, 8, 9]:
        raise RuntimeError("Failed")



# Generated at 2022-06-25 16:51:15.422168
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Necessary for this test
    from itertools import chain, cycle, islice

    # Initialize args
    func = lambda x: x
    lst = range(10)

    # Call the method
    test_instance = MapList(func, lst)
    assert test_instance[0] == 0
    assert test_instance[5] == 5
    assert test_instance[:5] == [0, 1, 2, 3, 4]
    assert test_instance[5:] == [5, 6, 7, 8, 9]
    assert test_instance[::2] == [0, 2, 4, 6, 8]
    assert test_instance[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-25 16:51:18.134832
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    if (not (isinstance(MapList.__getitem__, types.FunctionType))):
        fail_test(MapList, "__getitem__")


# Generated at 2022-06-25 16:51:27.667427
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    s = "abc"
    lst1 = MapList(lambda x: x + 1, s)
    lst2 = MapList(lambda x: x.upper(), s)

    assert lst1[0] == "b"
    assert lst2[0] == "A"

    assert lst1[-1] == "d"
    assert lst2[-1] == "C"

    assert len(lst1) == 3
    assert len(lst2) == 3

    assert lst1[0:1] == ["b"]
    assert lst2[0:1] == ["A"]

    assert lst1[-1:] == ["d"]
    assert lst2[-1:] == ["C"]

    assert list(lst1) == ["b", "c", "d"]
    assert list

# Generated at 2022-06-25 16:51:29.802682
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print("Testing method __getitem__")
    range_0 = Range(1, 1001, 1)
    assert_eq(range_0[100], 101)


# Generated at 2022-06-25 16:51:36.313386
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    map_list_0 = MapList([2, 3, 4, 5, 6], [2, 3, 4, 5, 6])
    map_list_1 = MapList([0, 0, 0, 0], [2, 3, 4, 5, 6])


# Generated at 2022-06-25 16:51:51.820159
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect



# Generated at 2022-06-25 16:51:57.037178
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    logger.info("Unit test for method __getitem__ of class Range")
    logger.info("Tested case 0")
    range_0 = Range(0)
    assert range_0[0] == 0
    logger.debug("Passed tested case 0")


# Generated at 2022-06-25 16:52:01.109684
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    first_5 = range_0[0:5]
    assert (list(drop_until(lambda x: x > 5, first_5)) == [6, 7, 8, 9])


# Generated at 2022-06-25 16:52:05.211104
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 10 + 1)
    range_1 = Range(1, 11, 2)
    range_2 = Range(4, 11, 2)
    range_3 = Range(0, 2 + 1)
    range_4 = Range(0, 2 + 1)
    range_5 = Range(0, 2)
    range_6 = Range(10)
    range_7 = Range(10)
    assert range_0[10 - 1] == 10
    assert range_0[10 - 1 + 1] == 11
    assert range_1[0] == 1
    assert range_2[2] == 5
    assert range_2[-1] == 11
    assert range_3[-1] == 2
    assert range_3[-2] == 1
    assert range_3[3] == 5


# Generated at 2022-06-25 16:52:11.853062
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:52:13.806802
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x:x>5, range(10))) == [6,7,8,9]


# Generated at 2022-06-25 16:52:19.879860
# Unit test for function drop_until
def test_drop_until():
    r = Range(0, 10)
    assert list(drop_until(lambda x: x > 5, r)) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:52:26.290665
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range()
    range_2 = Range(5)
    range_3 = Range(1, 4)
    range_4 = Range(1, 10, 2)

    for idx in range(10):
        assert range_2[idx] == idx
        assert range_3[idx] == idx + 1

    assert range_4[0] == 1
    assert range_4[1] == 3
    assert range_4[2] == 5
    assert range_4[3] == 7
    assert range_4[4] == 9

    assert range_4[1:3] == [3, 5]
    assert range_4[1:10:2] == [3, 7, 9]
    assert range_4[::2] == range_4[0:10:2]

    assert range

# Generated at 2022-06-25 16:52:30.819136
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Create an object of class MapList
    ml = MapList([1, 4, 9]) 
    print(ml[0])
    print(ml[1])
    print(ml[2])
    print(ml[3])


# Generated at 2022-06-25 16:52:33.678109
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(1)

    map_list = MapList(range_0, lambda x: x * x)
    assert map_list[0] == 1


# Generated at 2022-06-25 16:52:58.771069
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()


# Generated at 2022-06-25 16:53:02.156918
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    ml = MapList(lambda x: x * x, [1, 2, 3])
    assert ml[2] == 9
    assert ml[:2] == [1, 4]


# Generated at 2022-06-25 16:53:06.456008
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func_0 = lambda arg_0 : arg_0
    lst_0 = [ 1, 2, 3, 4 ]
    map_list_0 = MapList(func_0, lst_0)
    map_list_0[0]
    map_list_0[slice(0, 2, 1)]


# Generated at 2022-06-25 16:53:10.674773
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()

# Generated at 2022-06-25 16:53:11.686201
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()


# Generated at 2022-06-25 16:53:18.452877
# Unit test for function drop_until
def test_drop_until():
    list_0 = []
    # Call drop_until to drop elements until function my_greater_than_5 is satisfied.
    for i in drop_until(my_greater_than_5, range(10)):
        list_0.append(i)
    # Test the result of the drop_until.
    if list_0[0] != 6:
        raise RuntimeError()
    if list_0[1] != 7:
        raise RuntimeError()
    if list_0[2] != 8:
        raise RuntimeError()
    if list_0[3] != 9:
        raise RuntimeError()


# Generated at 2022-06-25 16:53:30.645070
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range = Range(10)
    assert(range[0] == 0)
    assert(range[1] == 1)
    assert(range[2] == 2)
    range = Range(0, 10, 1)
    assert(range[0] == 0)
    assert(range[1] == 1)
    assert(range[2] == 2)
    range = Range(0, 10, 2)
    assert(range[0] == 0)
    assert(range[1] == 2)
    assert(range[2] == 4)
    range = Range(1, 10, 2)
    assert(range[0] == 1)
    assert(range[1] == 3)
    assert(range[2] == 5)


# Generated at 2022-06-25 16:53:34.062615
# Unit test for function drop_until
def test_drop_until():
    result_1 = drop_until(lambda x: x > 5, range(10))
    assert list(result_1) == [6, 7, 8, 9]



# Generated at 2022-06-25 16:53:39.342990
# Unit test for function drop_until
def test_drop_until():
    # Test case 0
    print("Test case 0 :")
    iterator = take(10, drop_until(lambda x: x > 5, range(10)))
    print("Expected result: ")
    print("[6, 7, 8, 9]")
    print("Result of your drop_until: ")
    print(list(iterator))



# Generated at 2022-06-25 16:53:49.171616
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda x: x * x
    a = [1, 2, 3, 4, 5]
    map_list = MapList(func, a)
    map_list_0 = map_list[2:2:2]
    assert map_list_0 == []
    assert map_list[1] == 4
    b = [1, 2, 3, 4]
    map_list_1 = MapList(lambda i: a[i] * b[i], Range(len(a)))
    assert map_list_1[1:1:1] == []
    assert map_list_1[0:0:0] == []
    c = [1]
    assert MapList(lambda i: a[i] * c[i], Range(len(a)))[0] == 1

# Generated at 2022-06-25 16:54:14.330762
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]


# Generated at 2022-06-25 16:54:17.885435
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range(10):
        for j in range(10):
            for k in range(10):
                range_0 = Range(i, j, k)
                assert range_0.__getitem__(i) == (i)


# Generated at 2022-06-25 16:54:20.540303
# Unit test for function drop_until
def test_drop_until():
    assert(next(drop_until(lambda x: x > 5, range(10))) == 6)
    assert(next(drop_until(lambda x: x > 5, range(3))) == None)



# Generated at 2022-06-25 16:54:22.371960
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 1)
    assert range_0[0] == 1


# Generated at 2022-06-25 16:54:33.833839
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in Range(1, 10, 1):
        for j in Range(1, 10, 1):
            if i == j:
                print('Equal')
            else:
                print('Not equal')
    print('')
    for i in Range(1, 10, 1):
        for j in Range(1, 10, 1):
            if i == j:
                print('Equal')
            else:
                print('Not equal')
    print('')
    for i in Range(1, 10, 1):
        for j in Range(1, 10, 1):
            if i == j:
                print('Equal')
            else:
                print('Not equal')
    print('')

# Generated at 2022-06-25 16:54:47.187714
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(1, 2)
    range_2 = Range(1, 2, 3)
    range_3 = Range(-1, -2)
    range_4 = Range(-1, -2, -3)
    array_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
               30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51]