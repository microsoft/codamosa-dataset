

# Generated at 2022-06-25 16:45:01.010589
# Unit test for function drop
def test_drop():
    assert list(drop(3, (1,2,3,4,5,6))) == [4, 5, 6]
    assert list(drop(-1, (1,2,3,4,5,6))) == ValueError


# Generated at 2022-06-25 16:45:05.178855
# Unit test for function take
def test_take():
    i = 0
    for u in take(5, range(1000000)):
        assert u == i
        i += 1
    assert i == 5

test_take()



# Generated at 2022-06-25 16:45:10.291850
# Unit test for method __len__ of class Range

# Generated at 2022-06-25 16:45:21.560116
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range()
    v1 = range_0.__next__()
    v2 = range_0.__next__()
    v3 = range_0.__next__()
    v4 = range_0.__next__()
    v5 = range_0.__next__()
    v6 = range_0.__next__()
    v7 = range_0.__next__()
    v8 = range_0.__next__()
    v9 = range_0.__next__()
    v10 = range_0.__next__()
    v11 = range_0.__next__()
    v12 = range_0.__next__()
    v13 = range_0.__next__()
    v14 = range_0.__next__()
    v15 = range_0.__

# Generated at 2022-06-25 16:45:25.126182
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Setup
    range_0 = Range(1, 10, 1)
    # Exercise
    result_0 = LazyList(range_0).__len__()

    # Verify
    assert result_0 == 9



# Generated at 2022-06-25 16:45:30.186459
# Unit test for function drop
def test_drop():
    # generate a list from 0 to 10
    nums = [x for x in range(10)]
    # drop first 5 elements
    result = drop(5, nums)
    # check that drop function works
    for x in result:
        if x != 5:
            assert False, "drop function failed"
    assert True, "drop function passed"
    print("test_drop() passed")


# Generated at 2022-06-25 16:45:31.947231
# Unit test for method __len__ of class Range
def test_Range___len__():
    print('test_Range___len__')
    range_0 = Range(100)
    assert range_0.__len__() == 100


# Generated at 2022-06-25 16:45:33.765187
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    rand_range_0 = Range(random.Random(), int())
    rand_range_1 = Range(int(), random.Random(), random.Random())


# Generated at 2022-06-25 16:45:41.165413
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(2, [])) == []
    assert list(chunk(2, [1, 2])) == [[1, 2]]
    assert list(chunk(2, [1])) == [[1]]



# Generated at 2022-06-25 16:45:49.011223
# Unit test for function drop_until
def test_drop_until():
    assert len(list(drop_until(lambda x: x==0, range(10)))) == 1
    assert len(list(drop_until(lambda x: x==10, range(11)))) == 0
    assert len(list(drop_until(lambda x: x==100, range(10)))) == 0
    assert len(list(drop_until(lambda x: x>0, range(10)))) == 10


# Generated at 2022-06-25 16:46:16.866962
# Unit test for function split_by
def test_split_by():
    list1 = [1, 2]
    list2 = [4, 5]
    list3 = [7, 8]
    list_of_lists = [list1, list2, list3]
    criterion = lambda i: i % 3 == 0
    assert split_by(range(10), criterion=criterion) == list_of_lists
    separator = '.'
    list_of_lists = [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], [], ['']]
    str = " Split by: "
    assert split_by(str, empty_segments=True, separator=separator) == list_of_lists


# Generated at 2022-06-25 16:46:25.223021
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    # Test with no arguments
    lst_0 = LazyList(range_0)
    for i in range(15):
        assert lst_0[i] == i
    for i in range(15):
        assert lst_0[i] == i
    # Test with one argument
    lst_1 = LazyList(range_0)
    slice_0 = slice(0, 15)
    lst_0_0 = lst_1[slice_0]
    # If the following test fails, try un-wrapping the iteration to an explicit list
    assert len(lst_0_0) == 15
    assert lst_0_0[14] == 14
    assert lst_0_0[4] == 4
    for i in range(15):
        assert lst

# Generated at 2022-06-25 16:46:35.685701
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    def test_Range___getitem__0(self):
        idx = random.randint(0, 100) if (random.random() < 0.5) else random.randint(-100, 0)
        return self[idx]
    def test_Range___getitem__1(self):
        start = random.randint(0, 100) if (random.random() < 0.5) else random.randint(-100, 0)
        stop = random.randint(0, 100) if (random.random() < 0.5) else random.randint(-100, 0)
        step = random.randint(1, 10)
        return self[slice(start, stop, step)]

# Generated at 2022-06-25 16:46:40.318911
# Unit test for function take
def test_take():
    assert list(take(1, range(1, 100))) == list(range(1, 2))
    assert list(take(2, range(1, 100))) == list(range(1, 3))
    assert list(take(3, range(1, 100))) == list(range(1, 4))



# Generated at 2022-06-25 16:46:45.721752
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda x:x
    lst = []
    item = 'item'
    instance = MapList(func, lst)
    try:
        instance.__getitem__(item)
    except:
        pass
    else:
        raise Exception("Test case 0 failed")


# Generated at 2022-06-25 16:46:54.800828
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    from pytest import raises
    from convert_to_range_01 import test_case_0 as test_case_0
    test_case_0.range_0.__init__()
    a = None
    if a is None:
        a = 5
    assert test_case_0.range_0.__getitem__(a) == 5

# Generated at 2022-06-25 16:47:05.338271
# Unit test for function split_by
def test_split_by():
    print("----- Testing function 'split_by' -----")
    print("(case 1) split_by(range(10), criterion=lambda x: x % 3 == 0)")
    r1 = split_by(range(10), criterion=lambda x: x % 3 == 0)
    r1 = list(r1)
    a1 = [[1, 2], [4, 5], [7, 8]]
    assert r1 == a1
    print("Expected result:",a1)
    print("Actual result:",r1)
    print("(case 2) split_by(' Split by: ', empty_segments=True, separator='.')")
    r2 = split_by(" Split by: ", empty_segments=True, separator='.')
    r2 = list(r2)

# Generated at 2022-06-25 16:47:08.831709
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    try:
        range_1 = Range(0, 10)
        assert range_1[0] == 0
        assert range_1[1] == 1
        assert range_1[-1] == 9
        assert isinstance(range_1[2:4], list)
        assert range_1[2:4] == [2, 3]
        assert range_1[2:4:2] == [2]
        range_1[0] = 1
    except AssertionError as e:
        print('AssertionError: ' + str(e))


# Generated at 2022-06-25 16:47:14.170944
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    lazy_list_0 = LazyList(range_0)
    lazy_list_iterator_0 = LazyList.LazyListIterator
    assert isinstance(lazy_list_iterator_0(lazy_list_0), lazy_list_iterator_0)


# Generated at 2022-06-25 16:47:15.442459
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 10)
    assert range_0[0] == 1
    assert range_0[1] == 2
    assert range_0[9] == 10


# Generated at 2022-06-25 16:47:34.247186
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_1 = Range()
    # Valid slice indices
    range_1[-1:] # Valid slice indices
    range_1[:] # Valid slice indices
    range_1[2:2] # Valid slice indices
    range_1[3:3] # Valid slice indices
    # Invalid slice indices
    range_1[1:-1] # Invalid slice indices
    range_1[1:0] # Invalid slice indices
    range_1[2:0] # Invalid slice indices
    range_1[3:1] # Invalid slice indices
    range_1[-2:1] # Invalid slice indices



# Generated at 2022-06-25 16:47:40.744729
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst_0 = LazyList(range(5))
    it_0 = lst_0.__iter__()
    j = 0
    for i in it_0:
        assert i == j
        j = j + 1


# Generated at 2022-06-25 16:47:41.930668
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()


# Generated at 2022-06-25 16:47:45.341299
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(3)
    mapList_0 = MapList(range_0)
    mapList_0.__getitem__(0)


# Generated at 2022-06-25 16:47:46.818202
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert([1, 2, 3] == Range(1, 4)[:])


# Generated at 2022-06-25 16:47:52.663970
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    list_0 = LazyList(range(5))
    assert list_0._fetch_until(4) == None
    assert list_0.exhausted == True
    assert list_0.list == [0, 1, 2, 3, 4]
    assert list_0[1] == 1
    assert list_0[2] == 2


# Generated at 2022-06-25 16:47:58.218291
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    range_1 = Range(1, 10)
    res = list(drop_until(lambda x: x == 5, range_1))
    print(res)
    res_ref = [5, 6, 7, 8, 9]
    assert(res == res_ref)



# Generated at 2022-06-25 16:48:03.404917
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    range_0_iter = range_0.__iter__()
    assert next(range_0_iter) == 0
    assert next(range_0_iter) == 1
    assert next(range_0_iter) == 2


# Generated at 2022-06-25 16:48:06.023755
# Unit test for function drop_until
def test_drop_until():
    return drop_until(lambda x: x > 5, range(10))



# Generated at 2022-06-25 16:48:06.816697
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()



# Generated at 2022-06-25 16:48:22.880689
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert list(LazyList([1, 2, 3])[:]) == [1, 2, 3]
    assert list(LazyList(take(5, range(10**6)))[:]) == list(range(5))
    assert LazyList([1, 2, 3])[0] == 1
    assert LazyList([1, 2, 3])[0:1] == [1]
    assert LazyList([1, 2, 3])[0:2] == [1, 2]
    assert LazyList([1, 2, 3])[1] == 2
    assert LazyList([1, 2, 3])[1:2] == [2]
    assert LazyList([1, 2, 3])[1:3] == [2, 3]

# Generated at 2022-06-25 16:48:30.364376
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    list_0 = LazyList(range(5))
    assert list_0[-5] == 0, "method has wrong output"
    val = None
    try:
        val = list_0[5]
    except IndexError:
        pass
    assert val is None, "method has wrong output"
    val = None
    try:
        val = list_0[-6]
    except IndexError:
        pass
    assert val is None, "method has wrong output"
    assert list_0[1] == 1, "method has wrong output"
    assert list_0[-4] == 1, "method has wrong output"
    assert list_0[-2] == 3, "method has wrong output"


# Generated at 2022-06-25 16:48:32.822038
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    A = object
    b = MapList(dbl, A)
    c = b[0]


# Generated at 2022-06-25 16:48:44.170469
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    try:
        range_0.__getitem__(stop=0)
    except TypeError as e:
        print(e)
    range_0 = Range(start=0)
    try:
        range_0.__getitem__(stop=0)
    except TypeError as e:
        print(e)
    range_0 = Range(stop=10)
    try:
        range_0.__getitem__(stop=0)
    except TypeError as e:
        print(e)
    range_0 = Range(start=0, stop=10)
    try:
        range_0.__getitem__(stop=0)
    except TypeError as e:
        print(e)
    range_0 = Range(start=0, stop=10, step=1)

# Generated at 2022-06-25 16:48:48.835904
# Unit test for function scanl
def test_scanl():
    import operator
    print("Test scanl ...")
    assert(list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10])
    assert(list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba'])
    print("Pass tests!")

test_scanl()



# Generated at 2022-06-25 16:48:52.354873
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_1 = Range(-1, 1)
    range_2 = Range(-1, 1)
    range_3 = Range(-10, 1)


# Generated at 2022-06-25 16:48:56.382261
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    #range_0 = Range()

    assert (LazyList.__getitem__(range_0, 0) and True) == True


# Generated at 2022-06-25 16:49:01.778907
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert len(LazyList(range(10))[::2])== 5
    assert LazyList(range(10))[::2][0] == 0
    assert LazyList(range(10))[::2][4] == 8
    assert LazyList(range(10))[1::2][0] == 1
    assert LazyList(range(10))[1:5:2][1] == 3


# Generated at 2022-06-25 16:49:08.175448
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():

    # test_list = [0, 1, 1, 2, 3, 5, 8]
    test_list = list(range(10))

    for i, x in enumerate(LazyList(test_list)):
        assert x == test_list[i]

    lst = LazyList(test_list)
    for i in range(10):
        assert lst[i] == test_list[i]
        for j, x in enumerate(lst):
            assert x == test_list[j]


# Generated at 2022-06-25 16:49:13.349283
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range(3, 4)
    range_0._fetch_until(0)
    assert range_0._list == []
    assert range_0._exhausted == False


# Generated at 2022-06-25 16:49:29.160231
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    test_Range___getitem__.range_elem = range_0[0]

    def test_eq_0_1(this, that):
        return this == that


# Generated at 2022-06-25 16:49:34.311527
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range(1, 2, 3)
    map_0 = MapList(range_0, lambda x: x + x)
    assert map_0[-1] == 6


# Generated at 2022-06-25 16:49:41.014373
# Unit test for function drop_until
def test_drop_until():
    # drop_until(lambda x: x > 5, range(10))
    # assert(list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9])
    # list(drop_until(lambda x: x > 5, range(10)))

    assert(list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9])


# Generated at 2022-06-25 16:49:42.333450
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    test_case_0()


# Generated at 2022-06-25 16:49:44.793233
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    index_0 = 0
    result_0 = range_0[index_0]
    assert(result_0 == 0)



# Generated at 2022-06-25 16:49:46.621093
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    map_list_0 = MapList(lambda a: a ** 2, range_0)
    map_list_0[0]
    map_list_0[1]
    map_list_0[2]


# Generated at 2022-06-25 16:49:52.798336
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x == 5, range(5, 10))) == [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x >= 6, range(1, 10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x >= 10, range(1, 10))) == []



# Generated at 2022-06-25 16:49:57.124147
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    try:
        range_0 = Range()
        slice_1 = slice(0, 1000)
        range_0.__getitem__(slice_1)
        assert "range_0.__getitem__(slice_1)" not in globals()
    except:
        pass

# Generated at 2022-06-25 16:49:59.078277
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:50:03.480674
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(0)
    range_2 = Range(0, 1)
    range_3 = Range(0, 1, 1)
    assert range_0[0] == 0
    assert range_1[0] == 0
    assert range_2[0] == 0
    assert range_3[0] == 0


# Generated at 2022-06-25 16:50:19.695877
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    for i in range(10):
        range_0[i] = i
    for i in range(10):
        assert range_0[i] == i


# Generated at 2022-06-25 16:50:24.059019
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10) # (end)
    range_1 = Range(1, 10 + 1) # (start, end)
    range_2 = Range(1, 11, 2) # (start, end, step)
    print(range_2[0], range_2[2], range_2[4])


# Generated at 2022-06-25 16:50:30.528388
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    map_list_0 = MapList(range_0, range_0)
    range_1 = Range()
    map_list_0.func = range_1
    range_2 = Range()
    map_list_0.list = range_2
    range_0_0 = Range()
    assert len(map_list_0[range_0_0]) == len(range_0_0)
    range_0_1 = Range()
    assert len(map_list_0[range_0_1]) == len(range_0_1)
    range_0_2 = Range()
    assert len(map_list_0[range_0_2]) == len(range_0_2)
    range_0_3 = Range()

# Generated at 2022-06-25 16:50:33.023526
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    if (range_0.__getitem__(0) != 0):
        print("Test of __getitem__ failed")


# Generated at 2022-06-25 16:50:37.644550
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    method = Range.__getitem__
    # Test 0:
    range = Range()
    range = range[0:10]
    method = range.__getitem__
    # Test 1:
    input = 1
    expected = 1
    actual = method(input)
    assert expected == actual, "Expected {}, got {}".format(expected, actual)


# Generated at 2022-06-25 16:50:47.262523
# Unit test for function drop_until
def test_drop_until():
    assert drop_until(lambda x: x % 3 == 0, [1, 2, 3, 4, 5, 6]) == [3, 4, 5, 6]
    assert drop_until(lambda x: x % 3 == 0, [3, 4, 5, 6]) == [3, 4, 5, 6]
    assert drop_until(lambda x: x % 3 == 0, [4, 5, 6]) == [4, 5, 6]
    assert drop_until(lambda x: x % 3 == 0, [5, 6]) == [5, 6]
    assert drop_until(lambda x: x % 3 == 0, [6]) == [6]
    assert drop_until(lambda x: x % 3 == 0, [7]) == [7]

# Generated at 2022-06-25 16:50:53.911415
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 1, range(2, 3))) == [2]
    assert list(drop_until(lambda x: x > -1, range(1, 2))) == [1]
    assert list(drop_until(lambda x: x > 2, range(3, 4))) == [3]
    assert list(drop_until(lambda x: x > 1, range(2, 5))) == [2, 3, 4]
    assert list(drop_until(lambda x: x > 2, range(3, 6))) == [3, 4, 5]
    assert list(drop_until(lambda x: x > 1, range(2, 6))) == [2, 3, 4, 5]



# Generated at 2022-06-25 16:51:05.790758
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(1, 10 + 1)
    range_2 = Range(1, 11, 2)
    range_3 = Range(10)
    range_4 = Range(1, 11, 3)
    test_data.add(range_0, 0)
    test_data.add(range_1, 1)
    test_data.add(range_2, 2)
    test_data.add(range_3, 3)
    test_data.add(range_4, 4)
    assert test_data.get_rvalue(3) == range_3[2]
    assert test_data.get_rvalue(3) == range_3[-7]
    assert test_data.get_rvalue(4) == range_4[3]
    assert test_data

# Generated at 2022-06-25 16:51:07.247626
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0[int()]


# Generated at 2022-06-25 16:51:18.668569
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Call method __getitem__ of class LazyList to get item of the iterable
    range_0 = Range()
    assert range_0[0] == 0
    assert range_0[1] == 1
    assert range_0[2] == 2
    assert range_0[3] == 3
    # Call method __getitem__ of class LazyList to get item of the list
    plst = LazyList(range(4))
    assert plst[0] == 0
    assert plst[1] == 1
    assert plst[2] == 2
    assert plst[3] == 3
    # Call method __getitem__ of class LazyList to get item of the list
    # using negative index
    assert plst[-1] == 3
    assert plst[-2] == 2

# Generated at 2022-06-25 16:51:35.887139
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    count = 0
    for i in range(0, 10):
        a = Range(i)
        for j in range(0, i):
            if a[j] != j:
                count += 1



# Generated at 2022-06-25 16:51:47.133795
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    assert range_0[0] == 0
    assert range_0[4] == 4
    assert range_0[10] == 0
    assert range_0[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert range_0[0:10:2] == [0, 2, 4, 6, 8]
    assert range_0[-1:-11:-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert range_0[-1:-11:-2] == [9, 7, 5, 3, 1]
    assert range_0[0:10:0] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
   

# Generated at 2022-06-25 16:51:59.473512
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    empty_iterable = []
    non_empty_iterable = [0, 1, 2, 3, 4]
    non_empty_iterable_with_duplicates = [0, 1, 2, 0, 1, 2, 3, 4]

    # ###### Test 0 ######
    # Use an empty iterable and a negative index.
    # ####################
    try:
        lst = LazyList(empty_iterable)
        _ = lst[-1]
        assert False, "Accessing a negative index on an empty iterable should raise an AssertionError."
    except AssertionError:
        pass

    # ###### Test 1 ######
    # Use an empty iterable and a positive index.
    # ####################

# Generated at 2022-06-25 16:52:02.183230
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    index = 1
    value = 0
    mapList: MapList
    value = mapList[index]


# Generated at 2022-06-25 16:52:08.064824
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(0)
    range_0[0]
    range_0[1]
    range_0[2]
    range_0[3]
    range_0[4]
    range_0[6]
    range_0[7]
    range_0[8]
    range_0[9]
    range_0[3]
    range_0[2]
    range_0[1]
    range_0[0]
    range_0[0]


# Generated at 2022-06-25 16:52:10.459044
# Unit test for function drop_until
def test_drop_until():
    test_iter = [1, 2, 3, 4, 5, 6, 7, 8]
    test_iter = drop_until(lambda x: x > 5, test_iter)
    for i in test_iter:
        print("finally: " + str(i))



# Generated at 2022-06-25 16:52:12.824886
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(5, 6)
    item = range_0[0]
    assert(item == 5)


# Generated at 2022-06-25 16:52:24.110215
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert len(Range(10)) == 10
    assert Range(10)[0] == 0
    assert Range(10)[5] == 5
    assert Range(10)[10] == 10
    assert Range(0, 100, 10)[0] == 0
    assert Range(0, 100, 10)[1] == 10
    assert Range(0, 100, 10)[9] == 90
    assert Range(0, 100, 10)[10] == 100
    assert Range(0, 100, 10)[::-1][0] == 100
    assert Range(0, 100, 10)[::-1][9] == 10
    assert Range(0, 100, 10)[::-1][10] == 0
    assert Range(10)[-1] == 9
    assert Range(0, 100, 10)[-1] == 90

# Generated at 2022-06-25 16:52:36.395783
# Unit test for function drop_until
def test_drop_until():
    # Case 0: empty list
    range_0 = Range()
    expected = []
    actual = list(drop_until(lambda x: x >= 100, range_0))
    assert expected == actual

    # Case 1: drop all elements
    range_1 = Range()
    expected = []
    actual = list(drop_until(lambda x: x > 100, range_1))
    assert expected == actual

    # Case 2: drop no element
    range_2 = Range()
    expected = list(range(1000))
    actual = list(drop_until(lambda x: x < 1000, range_2))
    assert expected == actual

    # Case 3: drop some elements
    range_3 = Range()
    expected = list(range(500, 1000))

# Generated at 2022-06-25 16:52:38.606069
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 10)
    assert (range_0[0:6] == list(range(0, 6)))


# Generated at 2022-06-25 16:52:58.325668
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(1)
    range_2 = Range(1, 2)
    range_3 = Range(1, 4, 2)
    range_4 = Range(1, 10, 2)
    range_5 = Range(5, 10, 2)
    range_6 = Range(1, 10, 3)
    range_7 = Range(2, 10, 3)
    range_8 = Range(1, 10, 4)
    range_9 = Range(2, 10, 4)
    # Test range_0
    assert range_0[0] == 0
    assert range_0[0:1] == [0]
    assert range_0[0:2] == [0, 1]
    assert range_0[:1] == [0]
    # Test range_1


# Generated at 2022-06-25 16:53:01.356793
# Unit test for function drop_until
def test_drop_until():
    range_1 = Range(0)
    drop_until(lambda x: x > 5, range_1)
    drop_until(lambda x: x > 5, Range(0))



# Generated at 2022-06-25 16:53:11.116705
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(20)
    range_1 = Range(10, 20)
    range_2 = Range(10, 20, 2)
    assert range_0[0] == 0
    assert range_1[0] == 10
    assert range_2[0] == 10
    assert range_0[10] == 10
    assert range_1[10] == 20
    assert range_2[10] == 20
    assert range_0[20] == 20
    assert range_1[20] == 30
    assert range_2[20] == 30
    assert range_0[-1] == 19
    assert range_1[-1] == 19
    assert range_2[-1] == 19
    assert range_0[-20] == 0
    assert range_1[-20] == 0
    assert range_

# Generated at 2022-06-25 16:53:19.653232
# Unit test for function drop_until
def test_drop_until():
    print("Test drop_until function ...")
    # Case 0
    print("\tCase 0: ")
    range_0 = Range()
    drop_until(lambda x: x > 5, range_0)
    for i in range_0:
        print(i, end=" ")
    print()
    # Case 1
    print("\tCase 1: ")
    range_1 = Range(5, 8)
    drop_until(lambda x: x > 5, range_1)
    for i in range_1:
        print(i, end=" ")
    print()
    # Case 2
    print("\tCase 2: ")
    range_2 = Range(1, 100)
    drop_until(lambda x: x > 5, range_2)
    for i in range_2:
        print

# Generated at 2022-06-25 16:53:26.846517
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(11)
    range_1 = Range()
    range_2 = Range(1, 11)
    range_3 = Range(11, 1)
    range_4 = Range(11, 11, 1)
    range_5 = Range(11, 10, -1)
    range_6 = Range(11, 1, -1)


# Generated at 2022-06-25 16:53:30.214448
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print("Method __getitem__ of class Range")
    range_0 = Range()


# Generated at 2022-06-25 16:53:34.543434
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(10)
    map_list_0 = MapList(lambda x: range_0[int(x)], range_0)
    # Test case 0
    a = map_list_0[0]
    pass



# Generated at 2022-06-25 16:53:36.729007
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == list(range(6, 10))


# Generated at 2022-06-25 16:53:41.968875
# Unit test for function drop_until
def test_drop_until():
    lst_0 = list(drop_until(lambda x: x > 5, range(10)))
    assert(len(lst_0) == 4)
    assert(lst_0[0] == 6)
    assert(lst_0[1] == 7)
    assert(lst_0[2] == 8)
    assert(lst_0[3] == 9)


# Generated at 2022-06-25 16:53:46.055121
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(100))
    assert lst[3] == 3
    assert lst[3] == 3

    try:
        lst[100]
    except IndexError:
        pass
    else:
        assert False, "IndexError expected"


# Generated at 2022-06-25 16:54:19.176921
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    obj = range_0[0]
    obj = range_0[1]
    obj = range_0[2]
    obj = range_0[3]
    obj = range_0[4]
    obj = range_0[5]
    obj = range_0[6]
    obj = range_0[7]
    obj = range_0[8]
    obj = range_0[9]
    obj = range_0[10]
    obj = range_0[11]
    obj = range_0[10]
    obj = range_0[9]
    obj = range_0[8]
    obj = range_0[7]
    obj = range_0[6]
    obj = range_0[5]
    obj = range_0[4]
   

# Generated at 2022-06-25 16:54:20.140301
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()

# Generated at 2022-06-25 16:54:24.293795
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))
    print(list(drop_until(lambda x: x > 5, range(10))))
    print(list(drop_until(lambda x: x > 5, range(10))))
test_drop_until()



# Generated at 2022-06-25 16:54:26.172051
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range().__getitem__() == None


# Generated at 2022-06-25 16:54:38.204698
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    ml = MapList(500, [2, 3, 4, 5, 6])
    # ml is a MapList object
    # ml is a Sequence object
    range_0 = Range(5)
    # range_0 is a Range object
    # range_0 is a Sequence object
    range_1 = Range(5)
    # range_1 is a Range object
    # range_1 is a Sequence object
    assert range_0 == range_1
    assert range_0 == ml
    assert not ml != range_0
    assert not range_0 != range_1
    assert range_0 <= ml
    assert range_0 == ml
    assert not ml > range_0
    assert not range_0 > range_1
    assert not range_0 < ml
    assert range_0 == ml
    assert range_0 >= ml
    assert range