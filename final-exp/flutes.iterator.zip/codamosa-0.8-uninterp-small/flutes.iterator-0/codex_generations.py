

# Generated at 2022-06-25 16:45:09.317228
# Unit test for function drop_until
def test_drop_until():
    assert ([x for x in drop_until(lambda x: x > 5, range(10))] == [6, 7, 8, 9])

# This function is implemented in the second version of the LazyList, by using a Scanl. 
# It is used in the function merge.
# This function takes a function and two iterator and combine them together.
# f is the function that combine the two iterator, for example, zip.

# Generated at 2022-06-25 16:45:11.684187
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))



# Generated at 2022-06-25 16:45:21.975480
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2, 3, 4, 5], criterion=lambda x: x % 3 == 0)) \
        == [[1, 2], [4, 5]]
    assert list(split_by([1, 2, 3, 4, 5], criterion=lambda x: x % 3 == 0, empty_segments=True)) \
        == [[1, 2], [], [4, 5]]
    assert list(split_by("Split the input by colons.", separator=' ')) \
        == [['S', 'p', 'l', 'i', 't'], ['t', 'h', 'e'], ['i', 'n', 'p', 'u', 't'], ['b', 'y'], ['c', 'o', 'l', 'o', 'n', 's', '.']]

# Generated at 2022-06-25 16:45:24.287237
# Unit test for function take
def test_take():
    take(1, [0,1,2,3,4])
    take(-1, [0,1,2,3,4])



# Generated at 2022-06-25 16:45:29.480507
# Unit test for function chunk
def test_chunk():
    # TODO: change the range for 0, 1, 100
    for i in range(101):
        for j in range(101):
            if i >= j:
                continue
            num = i*i + j
            list_ = list(range(num))
            result = list(chunk(i, list_))
            if not check_chunk(result, i, num):
                raise Exception


# Generated at 2022-06-25 16:45:41.509460
# Unit test for function split_by
def test_split_by():
    # Test case 0
    # Expected output: [[],[1,2],[4,5],[7,8]]
    print(list(split_by(range(10), criterion=lambda x: x % 3 == 0)))
    # Test case 1
    # Expected output: [[],['S','p','l','i','t'],['b','y',':'],[]]
    print(list(split_by(' Split by: ',empty_segments=True,separator='.')))
    # Test case 2
    # Expected output: [[False, False, True, True, True, True, False, False], [False, False], []]
    print(list(split_by([False,False,True,True,True,True,False,False,False,False], criterion = lambda x: not x)))


# Generated at 2022-06-25 16:45:48.117049
# Unit test for function take
def test_take():
    print(take(0, [1, 2, 3, 4]))
    print(take(2, [1, 2, 3, 4]))
    print(take(5, [1, 2, 3, 4]))

test_take()

# Generated at 2022-06-25 16:45:51.936975
# Unit test for function drop_until
def test_drop_until():
    list_0 = [1, 2, 3, 4]
    test_fn = lambda x: x>3
    drop_until(test_fn, list_0)
    for item in list_0:
        if not test_fn(item):
            continue
        else:
            print(item)
            break



# Generated at 2022-06-25 16:45:54.505158
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:46:02.674843
# Unit test for function take
def test_take():
    # testing for well
    # test for n=0
    range_0 = Range()
    take_range_0 = take(0, range_0)
    assert len(list(take_range_0)) == 0

    # test for well behaved
    range_5 = Range(5)
    take_range_5 = take(5, range_5)
    assert len(list(take_range_5)) == 5
    
    # test for n > len(iterable)
    take_range_7 = take(7, range_5)
    assert len(list(take_range_7)) == 5

    # test for exception
    range_negative = Range(-1)
    try:
        take(-2, range_negative)
        assert False
    except ValueError:
        assert True
    


# Generated at 2022-06-25 16:46:25.327966
# Unit test for function take
def test_take():
    # Case 1: iterable is a list
    iterable = [1,2,3,4,5]
    assert list(take(2, iterable)) == [1,2]
    # Case 2: iterable is a dictionary
    iterable = {"a":1, "b": 2, "c": 3}
    assert list(take(2, iterable)) == [("a", 1), ("b", 2)]
    # Case 3: n is 0
    assert list(take(0, iterable)) == []
    # Case 4: n is greater than length of iterable
    n = 20
    assert list(take(20, iterable)) == [("a", 1), ("b", 2), ("c", 3)]
    # Case 5: iterable is empty
    assert list(take(2, range(0))) == []


# Generated at 2022-06-25 16:46:28.903231
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0,1,2,3,4]


# Generated at 2022-06-25 16:46:30.145165
# Unit test for function chunk
def test_chunk():
    assert list(chunk(-2, range(10))) == ValueError


# Generated at 2022-06-25 16:46:33.276046
# Unit test for function take
def test_take():
    n = 5
    iterable = range(1000000)
    list_0 = list(take(n, iterable))
    for i in list_0:
        assert i < n


# Generated at 2022-06-25 16:46:45.317849
# Unit test for function chunk

# Generated at 2022-06-25 16:46:54.748974
# Unit test for function split_by
def test_split_by():

    # Test first overload
    print(list(split_by(range(10), criterion=lambda x: x % 3 == 0)))
    print("\n")

    # Test second overload
    print(list(split_by(" Split by: ", empty_segments=True, separator='.')))
    print("\n")


# Generated at 2022-06-25 16:47:04.658825
# Unit test for function take
def test_take():
    assert([x for x in take(5, range(1000000))] == [0, 1, 2, 3, 4])

    # Test for n=0
    assert([x for x in take(0, range(1000000))] == [])

    # Test for n < 0
    try:
        take(-1, range(1000000))
        assert(False)
    except ValueError:
        assert(True)
        print('test passed')

    # Test for empty iterable
    assert([x for x in take(1, [])] == [])

    # Test for LazyList
    assert([x for x in take(5, LazyList(range(1000000)))] == [0, 1, 2, 3, 4])


# Generated at 2022-06-25 16:47:09.099702
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = iter(lazy_list)
    assert_equal(next(it), 1)
    assert_equal(next(it), 2)
    assert_equal(next(it), 3)
    assert_equal(next(it), 4)
    assert_equal(next(it), 5)
    assert_equal(next(it), 6)



# Generated at 2022-06-25 16:47:09.930727
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    pass


# Generated at 2022-06-25 16:47:13.466085
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    for (idx, val) in enumerate(LazyList(range(10000))):
        assert idx == val


# Generated at 2022-06-25 16:49:21.607599
# Unit test for function split_by
def test_split_by():
    l_0 = split_by(iterable, criterion=lambda x: x % 3 == 0)
    l_1 = split_by(" Split by: ", empty_segments=True, separator='.')



# Generated at 2022-06-25 16:49:34.063375
# Unit test for function drop
def test_drop():
    # Test 0
    range_0 = Range()
    print("Test 0:")
    print("Expected:")
    print("0\n1\n2\n3\n4\n")
    print("Actual:")
    for x in range_0:
        print(x)
    print("\n")
    # Test 1
    range_1 = Range()
    drop_1 = drop(5,range_1)
    print("Test 1:")
    print("Expected:")
    print("5\n6\n7\n8\n9\n")
    print("Actual:")
    for x in drop_1:
        print(x)
    print("\n")
    # Test 2
    range_2 = Range()
    drop_1 = drop(10,range_2)


# Generated at 2022-06-25 16:49:38.136815
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(100))) == list(range(100))
    assert list(drop(10, range(100))) == list(range(10, 100))
    assert list(drop(100, range(100))) == list()



# Generated at 2022-06-25 16:49:41.751600
# Unit test for function drop_until
def test_drop_until():
    it = drop_until(lambda x: x <= 2, [0, 1, 2])
    assert(next(it) == 2)
    assert(next(it) == None)


# Generated at 2022-06-25 16:49:52.273157
# Unit test for function drop
def test_drop():
    def try_drop(n, iterable, lst_have):
        try:
            it = drop(n, iterable)
            i = 0
            for elem in iterable:
                assert elem == lst_have[i]
                i += 1
            assert i == len(lst_have)
        except StopIteration:
            pass
    try_drop(1, range(10), [1, 2, 3, 4, 5, 6, 7, 8, 9])
    try_drop(0, [], [])
    try_drop(0, [1, 0, -2, 3], [1, 0, -2, 3])
    try_drop(10, [1, 0, 2], [])



# Generated at 2022-06-25 16:49:58.745335
# Unit test for function split_by
def test_split_by():
    list_0 = split_by(range(10), criterion=lambda x: x % 3 == 0)
    assert list_0 == [[1, 2], [4, 5], [7, 8]]

    list_1 = split_by(" Split by: ", empty_segments=True, separator='.')
    assert list_1 == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-25 16:50:02.489745
# Unit test for function drop_until
def test_drop_until():
    # test case 0
    iterable = range(10)
    pred_fn = lambda x: x > 5
    test_case_0 = drop_until(pred_fn, iterable)
    for item in test_case_0:
        print(item)


# Generated at 2022-06-25 16:50:07.023201
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert_equal(range_0[0], 0)
    assert_equal(range_0[1], 0)
    assert_equal(range_0[2], 0)
    assert_equal(range_0[3], 0)
    assert_equal(range_0[4], 0)
    assert_equal(range_0[5], 0)


# Generated at 2022-06-25 16:50:11.144078
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    # Test 0
    range_0 = Range()
    range_0._LazyList__fetch_until(None)
    # Test 1
    range_0 = Range(10)
    range_0._LazyList__fetch_until(None)


# Generated at 2022-06-25 16:50:12.651605
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(1000000))) == [5]


# Generated at 2022-06-25 16:50:23.027964
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    try:
        range_0 = Range()
    except ValueError:
        pass
    

# Generated at 2022-06-25 16:50:27.388325
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    res = 7
    num = 5
    lst = []
    for i in range(num):
        lst.append(res)
        res += 1
    all_good = True
    range_0 = Range(5)
    for i in range(num):
        if range_0[i] != lst[i]:
            all_good = False
            break
    assert all_good


# Generated at 2022-06-25 16:50:37.419161
# Unit test for function split_by
def test_split_by():
    print("Test case 0")
    r = list(split_by(" Split by: ", empty_segments=True, separator='.'))
    assert r == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    print("Test case 1")
    r = list(split_by(" Split by: ", separator='.'))
    assert r == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    print("Test case 2")
    r = list(split_by(" Split by: ", criterion=lambda x: x == '.'))
    assert r == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    print("Test case 3")
    r

# Generated at 2022-06-25 16:50:47.081970
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_117 = Range(0, 11)
    assert range_117[0] == 0
    assert range_117[1] == 1
    assert range_117[9] == 9
    assert range_117[10] == 10

    range_118 = Range(1, 11)
    assert range_118[0] == 1
    assert range_118[1] == 2
    assert range_118[9] == 10
    assert range_118[10] == 11

    range_120 = Range(0, 11, 2)
    assert range_120[0] == 0
    assert range_120[1] == 2
    assert range_120[4] == 8
    assert range_120[5] == 10

    range_121 = Range(1, 11, 2)
    assert range_121[0] == 1
    assert range_

# Generated at 2022-06-25 16:50:53.165539
# Unit test for function drop_until
def test_drop_until():
    def pred_fn(x):
        return x%2==0

    assert list(drop_until(pred_fn, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(pred_fn, range(11))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(drop_until(pred_fn, range(12))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]



# Generated at 2022-06-25 16:51:01.777521
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(100))
    assert lst[3] == 3
    assert lst[2:4] == [2, 3]
    assert lst[-4] == 96
    assert lst[-4:-2] == [96, 97]
    assert lst[-1] == 99
    assert lst[:2] == [0, 1]
    assert lst[3:] == list(range(3, 100))
    assert lst[-10:] == list(range(90, 100))
    assert lst[:] == list(range(100))


# Generated at 2022-06-25 16:51:13.767054
# Unit test for function split_by
def test_split_by():
    l = list(split_by(" Split by: ", empty_segments=True, separator='.'))
    assert l == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    l = list(split_by(" Split by: ", empty_segments=True, separator=' '))
    assert l == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    l = list(split_by(" Split by: ", empty_segments=False, separator=' '))
    assert l == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-25 16:51:23.954909
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(10)
    range_2 = Range(11, 10)
    range_3 = Range(10, 11)
    range_4 = Range(10, 11, -1)
    range_5 = Range(1, 11, 2)
    range_6 = Range(1, 11, 2)
    range_7 = Range(1, 11, 2)
    range_8 = Range(1, 11, 2)
    range_9 = Range(1, 11, 2)
    range_10 = Range(1, 11, 2)
    range_11 = Range(1, 11, 2)
    range_12 = Range(1, 11, 2)
    range_13 = Range(1, 11, 2)
    range_14 = Range(1, 11, 2)
    range

# Generated at 2022-06-25 16:51:32.048746
# Unit test for function split_by
def test_split_by():
    a = [1, 2, 3, 4]
    b = list(split_by(a, criterion=lambda x: x % 3 == 0))
    print(b)
    assert b == [[1, 2], [4]]
    c = [2, 3, 4, 5]
    d = list(split_by(c, criterion=lambda x: x % 3 == 0))
    print(d)
    assert d == [[2], [4, 5]]
    e = [1, 2, 3, 4]
    f = list(split_by(a, criterion=lambda x: x % 2 == 0))
    print(f)
    assert f == [[1, 3], [2], [4]]
    g = [2, 3, 4, 5]

# Generated at 2022-06-25 16:51:35.776544
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 6, 3)
    int_0 = range_0[0]
    int_1 = range_0[3]
    int_2 = range_0[-1]
    print(int_0, int_1, int_2)


# Generated at 2022-06-25 16:51:43.431377
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0 = Range(1, 1, 1)


# Generated at 2022-06-25 16:51:49.156089
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    arg_0 = Range()
    arg_1 = Range()
    arg_2 = Range()
    arg_3 = Range()
    arg_4 = Range()
    arg_5 = Range()
    arg_6 = Range()
    arg_7 = Range()
    arg_8 = Range()
    arg_9 = Range()
    arg_10 = Range()


# Generated at 2022-06-25 16:51:53.549933
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range(0, 10)
    lazy_list_0 = LazyList(range_0)
    for i in range(0, 10):
        assert(i == lazy_list_0[i])



# Generated at 2022-06-25 16:51:56.051112
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    rng0 = Range()
    obj0 = MapList(rng0)
    pass


# Generated at 2022-06-25 16:51:57.889501
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    list_0 = LazyList()
    item = list_0.__getitem__(0)



# Generated at 2022-06-25 16:51:59.018637
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_case_0()


# Generated at 2022-06-25 16:52:03.151148
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(100))
    ll[0]
    ll[10]
    # Note that the slice object is used by range, but the range class cannot be found.
    ll[slice(0, 10)]


# Generated at 2022-06-25 16:52:06.739002
# Unit test for function drop_until
def test_drop_until():
    iterable = [1,2,3,4,5]
    pred_fn = lambda x: x > 2
    result = drop_until(pred_fn, iterable)
    assert list(result) == [3,4,5]

test_drop_until()



# Generated at 2022-06-25 16:52:22.097775
# Unit test for function drop_until

# Generated at 2022-06-25 16:52:27.701722
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    i = 0
    it = iter(range_0)
    for x in it:
        assert x == i
        i += 1
        if i >= 100000:
            break


# Generated at 2022-06-25 16:52:36.673211
# Unit test for function drop_until
def test_drop_until():
    assert [x for x in drop_until(lambda x: x > 5, range(10))] == [6, 7, 8, 9]
    assert [x for x in drop_until(lambda x: x < 5, range(10))] == [5, 6, 7, 8, 9]

# Generated at 2022-06-25 16:52:38.830411
# Unit test for function drop_until
def test_drop_until():
    for i in range(10):
        print(next(drop_until(lambda x: x > 5, range(10))))


# Generated at 2022-06-25 16:52:41.522382
# Unit test for function drop_until
def test_drop_until():
    pred_fn = lambda x: x > 5
    iterable = range(1, 10)
    list(drop_until(pred_fn, iterable))




# Generated at 2022-06-25 16:52:45.605583
# Unit test for function drop_until
def test_drop_until():
    print("test_case_0")
    range1 = range(10)
    range1 = drop_until(lambda x: x > 5, range1)

    for i in range1:
        print(i)

test_drop_until()


# Generated at 2022-06-25 16:52:49.412449
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1)
    range_0._get_idx(1)
    range_0.__getitem__(1)
    range_0.__getitem__(1)
    range_0._get_idx(1)


# Generated at 2022-06-25 16:52:57.945991
# Unit test for function drop_until
def test_drop_until():
    def always_false(x):
        return False
    def always_true(x):
        return True
    def greater_than_10(x):
        return x > 10
    def greater_than_5(x):
        return x > 5

    data_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    data_1 = [0, 1, 15, -10, 20, 100]

    assert list(drop_until(greater_than_10, data_0)) == []
    assert list(drop_until(greater_than_5, data_0)) == [6, 7, 8, 9]
    assert list(drop_until(always_false, data_0)) == data_0
    assert list(drop_until(always_true, data_0)) == data_

# Generated at 2022-06-25 16:53:02.801810
# Unit test for function drop_until
def test_drop_until():
    # drop_until(pred_fn, iterable)
    x = list(drop_until(lambda a: a == 1, [0,0,0,1,1,1]))
    if x != [1,1,1]:
        print("Test failed!")
    else:
        print("Test passed!")


# Generated at 2022-06-25 16:53:08.150321
# Unit test for function drop_until
def test_drop_until():
    # Define a function to test drop_until
    def less_than_10(x):
        return x < 10

    # Expected output: [6, 7, 8, 9]
    print(list(drop_until(less_than_10, range(10))))
    # Expected output: []
    print(list(drop_until(less_than_10, range(10, 20))))


# Generated at 2022-06-25 16:53:17.543381
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(int(0), int(3), int(1))
    range_1 = Range(int(0), int(3), int(1))
    assert(range_0[int(0)] == range_1[int(0)])
    assert(range_0[int(1)] == range_1[int(1)])
    assert(range_0[int(2)] == range_1[int(2)])
    range_2 = Range(int(0))
    range_3 = Range(int(0))
    assert(range_2[int(0)] == range_3[int(0)])
    assert(range_2[int(1)] == range_3[int(1)])
    assert(range_2[int(2)] == range_3[int(2)])
    range_

# Generated at 2022-06-25 16:53:24.918516
# Unit test for function drop_until
def test_drop_until():
    for x in range(100):
        for y in range(100):
            if y <= x:
                assert list(drop_until(lambda e: e > y, range(x))) == list(range(y+1, x))
            else:
                assert list(drop_until(lambda e: e > y, range(x))) == []



# Generated at 2022-06-25 16:53:35.496942
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    val = 0
    test = Range()
    assert test[val] == 0


# Generated at 2022-06-25 16:53:43.213485
# Unit test for function scanl
def test_scanl():

    # scanl(operator.add, [1, 2, 3, 4], 0)
    # [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]

    # scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])
    # ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-25 16:53:49.665718
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0 = Range(2, 1)
    range_0 = Range(0, 1, -1)
    range_0 = Range(0, 1, 1)


# Generated at 2022-06-25 16:53:52.445956
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(0, 10 + 1)
    assert range_0[0] == 0
    assert range_0[2] == 2
    assert range_0[4] == 4


# Generated at 2022-06-25 16:53:57.131921
# Unit test for function drop_until
def test_drop_until():
    list_0 = [1,2,3,4,5,6,7,8,9,10]
    pred_fn = lambda x: x > 5
    iterable = list_0
    iterator = drop_until(pred_fn, iterable)
    result = [x for x in iterator]
    assert result == [6,7,8,9,10]




# Generated at 2022-06-25 16:54:00.352490
# Unit test for function drop_until
def test_drop_until():
    list_0 = []
    list_0.extend(map(lambda x: drop_until(lambda y: x < y, [1, 2, 3]), [1, 2, 3]))
    # print(list_0)


# Generated at 2022-06-25 16:54:02.128923
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    m = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert m[0] == 1
    assert m[-1] == 25
    assert m[1:3] == [4, 9]
    assert m[1:1] == []


# Generated at 2022-06-25 16:54:03.832652
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_case_0() #


# Generated at 2022-06-25 16:54:09.729434
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1)
    assert_equals(range_0[0], 1)
    range_1 = Range(1, 2)
    assert_equals(range_1[0], 1)
    range_2 = Range(1, 5, 2)
    assert_equals(range_2[0], 1)
    assert_equals(range_2[1], 3)



# Generated at 2022-06-25 16:54:10.705406
# Unit test for function drop_until
def test_drop_until():
    result = list(drop_until(lambda x: x > 5, range(10)))
    print(result)
    assert result == [6, 7, 8, 9]



# Generated at 2022-06-25 16:54:28.922104
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    def test_range___getitem___0():
        range_0 = Range(1, 1)

    def test_range___getitem___1():
        try:
            range_1 = Range(1, 1)
        except StopIteration:
            pass

    def test_range___getitem___2():
        range_0 = Range(1, 1)

    def test_range___getitem___3():
        try:
            range_1 = Range(1, 1)
        except StopIteration:
            pass

    def test_range___getitem___4():
        range_0 = Range(1, 1)

    def test_range___getitem___5():
        try:
            range_1 = Range(1, 1)
        except StopIteration:
            pass


# Generated at 2022-06-25 16:54:31.265951
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    pass



# Generated at 2022-06-25 16:54:37.440580
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10, 1)
    l = [1, 2, 3, 4, 5, 6, 7, 8, 9]

    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7

    assert r[0] == 1
    assert r[4] == 5
    assert r[9] == 10
# End of test case for method __getitem__
