

# Generated at 2022-06-25 16:45:09.317030
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    print(len(range_0[0:10]))


# Generated at 2022-06-25 16:45:12.072132
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x == 6, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-25 16:45:16.172106
# Unit test for function chunk
def test_chunk():
    # test case 0
    range_0 = Range()
    for chunk_0 in chunk(3, range_0):
        print(chunk_0)


# Generated at 2022-06-25 16:45:18.441701
# Unit test for function scanl
def test_scanl():
    print(scanl)
    x = list(scanl(lambda p, q: p + q, [3,4,5,6], 0))
    print(x)


# Generated at 2022-06-25 16:45:25.972173
# Unit test for function split_by
def test_split_by():
    # Test case 0
    # empty list
    if split_by([], criterion = lambda x: x % 3 == 0) is not iter([]):
        raise AssertionError("split_by: Test case 0: Wrong result")
    # separation criterion returns False
    # one empty group is returned
    if split_by([1, 2], empty_segments = True, criterion = lambda x: x % 3 == 0) is not iter([[1, 2]]):
        raise AssertionError("split_by: Test case 0: Wrong result")
    # separation criterion returns True
    # one empty group is returned
    if split_by([1, 2], empty_segments = True, separator = 1) is not iter([[], [2]]):
        raise AssertionError("split_by: Test case 0: Wrong result")


# Generated at 2022-06-25 16:45:29.226783
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst_0 = LazyList(range(10))
    assert lst_0[1] == 1
    assert lst_0[0] == 0
    assert lst_0[2] == 2


# Generated at 2022-06-25 16:45:31.715098
# Unit test for function chunk
def test_chunk():
    assert (list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]])


# Generated at 2022-06-25 16:45:33.876358
# Unit test for function drop
def test_drop():
    iterable = [1,2,3,4,5]
    ans = drop(2, iterable)
    print(ans is None)


# Generated at 2022-06-25 16:45:39.163403
# Unit test for function take
def test_take():
    test_0 = list(take(2, range(2)))
    assert test_0 == [0, 1]
    test_1 = list(take(3, [3, 2, 1]))
    assert test_1 == [3, 2, 1]


# Generated at 2022-06-25 16:45:47.369750
# Unit test for method __getitem__ of class LazyList

# Generated at 2022-06-25 16:46:05.215767
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0.__getitem__(0)
    range_0.__getitem__(0)


# Generated at 2022-06-25 16:46:14.626007
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    list_0 = []
    l_0 = LazyList(range(0))
    # var l_0 is used with static type: LazyList[int]
    # The static type of e_0 is int
    e_0 = (l_0[0])
    # The static type of r_0 is int
    r_0 = (list_0[0])
    assert(e_0 == r_0)
    assert((l_0[-1]) == (list_0[-1]))
    list_1 = []
    l_1 = LazyList(range(3))
    # var l_1 is used with static type: LazyList[int]
    # The static type of e_1 is int
    e_1 = (l_1[0])
    # The static type of r_1 is int

# Generated at 2022-06-25 16:46:16.842266
# Unit test for function drop
def test_drop():
    drop_0 = drop(1, range(3))
    for x in drop_0:
        print(x)


# Generated at 2022-06-25 16:46:20.533501
# Unit test for function drop
def test_drop():
    print(list(drop(5, range(10))))
    try:
        next(drop(20, range(10)))
        print("Test fail")
    except StopIteration:
        print("Test pass")


# Generated at 2022-06-25 16:46:22.643431
# Unit test for function drop
def test_drop():
    # function body starts here
    obj = drop(0, Range(3))
    print("obj = %s" % obj)
    # function body ends here



# Generated at 2022-06-25 16:46:30.215635
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # testing range from 0 to 10 excluding 10, by 2 (5 elements)
    range_0 = Range(0, 10, 2)
    # testing list of size 6
    list_test = [1, 2, 3, 4, 5, 6]

    # testing simple usage
    map_list_0 = MapList(lambda c_0: c_0 * c_0, range_0)
    assert map_list_0[0] == 0
    assert map_list_0[2] == 16
    assert map_list_0[4] == 36

    # testing slices
    map_list_0 = MapList(lambda c_1: c_1 * c_1, list_test)
    assert map_list_0[0:2] == [1, 4]

# Generated at 2022-06-25 16:46:41.238324
# Unit test for function split_by
def test_split_by():
    limit_0 = 2000
    range_0 = range(limit_0)
    lst_0 = list(range_0)
    ratio_0 = 100
    lst_1 = list(filter(lambda x: x % ratio_0 == 0, lst_0))
    result_0 = list(split_by(range_0, criterion=lambda y: y % ratio_0 == 0))
    print(result_0)
    print(lst_1)
    for i in range(len(lst_1)):
        assert(lst_1[i] == result_0[i][0])
    # Test with separator
    range_0 = range(limit_0)
    result_0 = list(split_by(range_0, criterion=lambda y: y == ratio_0))

# Generated at 2022-06-25 16:46:49.854111
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():

    print('\n****** test_Range___getitem__')
    # Initialize range_1 to (start, end, step)
    range_1 = Range(1, 11, 2)
    print(range_1[0], range_1[2], range_1[4])

    # Initialize range_2 to (stop)
    range_2 = Range(10)
    print(range_2)

    # Initialize range_3 to (start, end)
    range_3 = Range(1, 10 + 1)
    print(range_3[1:6:2])


# Generated at 2022-06-25 16:47:02.739374
# Unit test for function split_by
def test_split_by():
    # Group list into multiple lists depending on the specified criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]

    # Spliting by '' always gives the original list
    assert list(split_by('hello world')) == ['hello world']
    assert list(split_by(' hello world')) == [' hello world']
    assert list(split_by('hello world ')) == ['hello world ']
    assert list(split_by('hello world ', empty_segments=True)) == [[], 'hello world ']

    # Spliting by space
    assert list(split_by('hello world', separator=' ')) == ['hello', 'world']

# Generated at 2022-06-25 16:47:08.446536
# Unit test for function drop_until
def test_drop_until():
    iterator = drop_until(lambda x: x > 5, range(10))
    assert(list(iterator) == [6, 7, 8, 9])


# Generated at 2022-06-25 16:47:23.649712
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    l = []
    for i in range(0, 9):
        l.append(i)
    l1 = Range(3, 8).__getitem__(0)
    assert l[3] == l1
    l1 = Range(3, 8).__getitem__(1)
    assert l[4] == l1
    l1 = Range(3, 8).__getitem__(2)
    assert l[5] == l1
    l1 = Range(3, 8).__getitem__(3)
    assert l[6] == l1
    l1 = Range(3, 8).__getitem__(4)
    assert l[7] == l1
    l1 = Range(3, 8).__getitem__(5)
    assert l[7] == l1
    # __getitem__ with

# Generated at 2022-06-25 16:47:33.992154
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3, 4])
    assert lst[2] == 3
    assert lst[1] == 2
    assert lst[3] == 4
    assert lst[2] == 3

    lst = LazyList([1, 2, 3, 4, 5])
    assert lst[::2] == [1, 3, 5]
    assert lst[:-1:2] == [1, 3]
    assert lst[1:] == [2, 3, 4, 5]
    assert lst[:-1] == [1, 2, 3, 4]
    assert lst[::-1] == [5, 4, 3, 2, 1]
    assert lst[2:-1:2] == [3]



# Generated at 2022-06-25 16:47:40.746800
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]

# Generated at 2022-06-25 16:47:44.455537
# Unit test for function drop_until
def test_drop_until():
    iterable = range(10)
    print(list(drop_until(lambda x: x > 5, iterable)))

test_case_0()


# Generated at 2022-06-25 16:47:48.178008
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-25 16:47:53.282184
# Unit test for function split_by
def test_split_by():
    print(list(split_by(range(10), criterion=lambda x: x%3 == 0)))
    print(list(split_by(" Split by: ", empty_segments=True, separator='.')))
    print(list(split_by(" Split by: ", criterion = lambda x: x == '.')))



# Generated at 2022-06-25 16:48:00.817506
# Unit test for function drop_until
def test_drop_until():
    a = [0, 1, 2, 3, 4]
    assert list(drop_until(lambda x: x > 2, a)) == [3, 4]
    b = [0, 1, 2]
    assert list(drop_until(lambda x: x > 2, b)) == []
    assert list(drop_until(lambda x: x > 10, a)) == []
    c = []
    assert list(drop_until(lambda x: x > 2, c)) == []
    d = [0]
    assert list(drop_until(lambda x: x > 2, d)) == []



# Generated at 2022-06-25 16:48:04.101334
# Unit test for function drop_until
def test_drop_until():
    iterator = drop_until(lambda x: x > 5, range(10))
    assert next(iterator) == 6
    assert next(iterator) == 7
    assert next(iterator) == 8
    assert next(iterator) == 9
    try:
        next(iterator)
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-25 16:48:06.470085
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(13)


# Generated at 2022-06-25 16:48:14.757894
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    argument_0 = 1
    argument_1 = 2
    argument_2 = 3
    range_0 = Range(argument_0, argument_1, argument_2)
    argument_3 = Range(argument_0, argument_1, argument_2)
    variable_0 = MapList(argument_3, range_0)
    variable_1 = variable_0[argument_0]
    variable_2 = variable_0[argument_0:argument_1:argument_2]

test_MapList___getitem__()


# Generated at 2022-06-25 16:48:23.755733
# Unit test for function drop_until
def test_drop_until():
    is_not_odd = lambda x: x % 2 == 0
    assert list(drop_until(is_not_odd, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop_until(lambda _: False, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:48:30.695366
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Test case 0
    range_0 = Range()
    _x = LazyList(range_0)
    assert _x[0:4] == [0,1,2,3]
    # Test case 1
    range_0 = Range()
    _x = LazyList(range_0)
    assert _x[10:12] == [10, 11]
    # Test case 2
    range_0 = Range()
    _x = LazyList(range_0)
    assert _x[0] == 0
    # Test case 3
    range_0 = Range()
    _x = LazyList(range_0)
    assert _x[100] == 100


# Generated at 2022-06-25 16:48:42.617141
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(3)
    assert range_0[-1] == 2
    assert range_0[0] == 0
    assert range_0[1] == 1
    assert range_0[2] == 2
    assert range_0[-2] == 1
    assert range_0[-3] == 0
    assert range_0[1:] == [1, 2]
    assert range_0[0:1] == [0]
    assert range_0[2:2] == []
    assert range_0[:] == [0, 1, 2]
    assert range_0[1:3] == [1, 2]
    assert range_0[:0] == []
    assert range_0[:-1] == [0, 1]
    assert range_0[:-2] == [0]

# Generated at 2022-06-25 16:48:45.047581
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Check 0
    obj = MapList()
    # Check 1
    obj = MapList()
    # Check 2
    obj = MapList()


# Generated at 2022-06-25 16:48:47.489255
# Unit test for function drop_until
def test_drop_until():
    # range(5) = [0,1,2,3,4]
    assert test_case_0() == [6,7,8,9]
    print("Test case 0 passed")


# Generated at 2022-06-25 16:48:50.651226
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(3).__getitem__(2) == 2
    assert Range(1, 3).__getitem__(2) == 3
    assert Range(1, 5, 2).__getitem__(2) == 5
    assert Range(1, 8, 3)[4] == 10


# Generated at 2022-06-25 16:48:56.316487
# Unit test for function take
def test_take():
    take_1 = take(3, range(5))
    assert next(take_1) == 0
    assert next(take_1) == 1
    assert next(take_1) == 2
    try:
        next(take_1)
        assert False
    except StopIteration:
        pass



# Generated at 2022-06-25 16:49:04.399729
# Unit test for function split_by
def test_split_by():
    print('======Executing Unit test for function split_by')
    res = split_by(range(10), criterion=lambda x: x % 3 == 0)
    print(list(res))
    assert list(res) == [[1, 2], [4, 5], [7, 8]]
    res = split_by([9, 0, 8, 1, 7, 2, 6, 3, 5, 4], criterion=lambda x: x % 3 == 0)
    assert list(res) == [[9, 0], [8, 1], [7, 2], [6, 3], [5, 4]]
    res = split_by([9, 0, 8, 1, 7, 2, 6, 3, 5, 4], criterion=lambda x: x % 3 == 0, empty_segments=True)
    print(list(res))

# Generated at 2022-06-25 16:49:12.639790
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = list(range(100))
    lazy_list_0 = list(range(100))
    for i in range(0, 100, 2):
        assert lazy_list_0[i] == range_0[i]
    for i in range(1, 100, 2):
        assert lazy_list_0[i] == range_0[i]
    for i in range(100):
        assert lazy_list_0[i] == range_0[i]


# Generated at 2022-06-25 16:49:22.093181
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    try:
        range_0 = Range(0)
        range_0.__getitem__((1))
    except ValueError:
        pass
    try:
        range_0 = Range(0)
        range_0.__getitem__((1))
    except IndexError:
        pass
    range_0 = Range((2))
    range_0.__getitem__((0))
    range_0 = Range((2))
    range_0.__getitem__((1))
    range_0 = Range((2))
    range_0.__getitem__((1))
    range_0 = Range((2))
    range_0.__getitem__((0))
    range_0 = Range((2))
    range_0.__getitem__((0))
    range_0 = Range(1, (2))

# Generated at 2022-06-25 16:49:31.248791
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10000)
    for i in range(0, 5000):
        if range_0[i] != i:
            # Fail
            raise AssertionError("range_0[%d] = %d instead of %d" % (i, range_0[i], i))


# Generated at 2022-06-25 16:49:39.131819
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(0, 10, 1))
    ll[0]
    ll[-1]
    ll[0:2]
    try:
        ll[10]
        assert False
    except IndexError:
        pass
    try:
        ll[-10]
        assert False
    except IndexError:
        pass
    try:
        ll[0:10:2]
        assert False
    except TypeError:
        pass


# Generated at 2022-06-25 16:49:41.431702
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(10)
    range_1 = Range(1, 10 + 1)
    range_2 = Range(1, 11, 2)
    print(range_2[0], range_2[2], range_2[4], sep='\n')


# Generated at 2022-06-25 16:49:52.906657
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range()
    assert(len(range_1) == 0)
    range_2 = range_1[1:]
    assert(len(range_2) == 0)
    range_3 = Range(1, 1)
    assert(len(range_3) == 0)
    range_4 = range_3[1:]
    assert(len(range_4) == 0)
    range_5 = Range(1, 1, 2)
    assert(len(range_5) == 0)
    range_6 = range_5[1:]
    assert(len(range_6) == 0)
    range_7 = Range(0, 1)
    assert(len(range_7) == 1)
    range_8 = range_7[1:]
    assert(len(range_8) == 0)
   

# Generated at 2022-06-25 16:49:58.128488
# Unit test for function split_by
def test_split_by():
    test_list = [1,1,3,4,5,6,4,4,4,4,4,4,4]
    splitted_list = list(split_by(iterable=test_list, criterion=lambda x: x == 1))
    assert splitted_list == [[],[3, 4, 5, 6, 4, 4, 4, 4, 4, 4, 4]]


# Generated at 2022-06-25 16:50:02.356102
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    mapList = mapList_0 = MapList()
    int_0 = 0
    mapList_0.__getitem__(int_0)
    mapList_0.__init__(mapList.func, mapList.list)
    mapList_0.__getitem__(int_0)


# Generated at 2022-06-25 16:50:11.902506
# Unit test for function take
def test_take():
    assert list(take(10, range(100))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-25 16:50:22.084709
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    print("Test: method __getitem__")

    # Test 1: access via positive index
    range_0 = Range()
    len_0 = ((len(range_0)) if (len(range_0) >= 0) else 0)
    idx_0 = randint(0, len_0 - 1)
    val_0 = range_0[idx_0]
    assert val_0 == idx_0

    # Test 2: access via positive index
    range_1 = Range()
    len_1 = ((len(range_1)) if (len(range_1) >= 0) else 0)
    idx_1 = randint(0, len_1 - 1)
    val_1 = range_1[idx_1]
    assert val_1 == idx_1

    # Test 3: access via negative index

# Generated at 2022-06-25 16:50:24.533458
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    list_0 = LazyList(range_0)
    assert list_0[100] == 99
    assert len(list_0) == 64


# Generated at 2022-06-25 16:50:28.479939
# Unit test for function split_by
def test_split_by():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 16:50:41.748455
# Unit test for function split_by
def test_split_by():
    print('======== Test split_by ========')
    # Test case 1
    print('Test case 1:')
    array = [3, 1, 2, 5, 7, 6, 0]
    result = []
    for each in split_by(array, criterion=lambda x: x % 3 == 0):
        result.append(each)
    print('Input: {}, Output: {}'.format(array, result))

    # Test case 2:
    print('Test case 2:')
    array = [3, 1, 2, 5, 7, 6, 0]
    result = []
    for each in split_by(array, criterion=lambda x: x % 3 == 0, empty_segments=True):
        result.append(each)
    print('Input: {}, Output: {}'.format(array, result))

    # Test case 3

# Generated at 2022-06-25 16:50:44.844544
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(1, 10)
    map_list_0 = MapList(lambda x: x * x, range_0)
    map_list_0.__getitem__(0)



# Generated at 2022-06-25 16:50:54.598833
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-25 16:50:58.026741
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    func_0 = lambda i: range_0[i]
    list_0 = MapList(func_0, range_0)
    assert list_0[1] == 1


# Generated at 2022-06-25 16:50:59.092054
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass


# Generated at 2022-06-25 16:51:00.376674
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Setup
    range_0 = Range()
    # Assert
    assert(range_0.__getitem__(0) == 1)


# Generated at 2022-06-25 16:51:04.866371
# Unit test for function drop_until
def test_drop_until():
    c = [1,2,3,4,5]
    a = list(drop_until(lambda x: x > 4, c))
    # print("Test case 0", a)


# Generated at 2022-06-25 16:51:16.618203
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for _ in range(10):
        range_0 = Range(numpy.random.randint(MIN_RANGE, MAX_RANGE + numpy.random.randint(1, MAX_RANGE)))
        autoTester.check(type(range_0))
        autoTester.check(range_0.length)
        range_1 = Range(numpy.random.randint(MIN_RANGE, MAX_RANGE + numpy.random.randint(1, MAX_RANGE)), numpy.random.randint(MIN_RANGE, MAX_RANGE + numpy.random.randint(1, MAX_RANGE)))
        autoTester.check(type(range_1))
        autoTester.check(range_1.length)

# Generated at 2022-06-25 16:51:23.825614
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[0] == 0
    assert Range(10)[-1] == 9
    assert Range(10)[-10] == 0
    assert Range(1, 10 + 1)[0] == 1
    assert Range(1, 10 + 1)[-1] == 10
    assert Range(1, 10 + 1)[-10] == 1
    assert Range(0, 10 + 1, 2)[0] == 0
    assert Range(0, 10 + 1, 2)[-1] == 10
    assert Range(0, 10 + 1, 2)[-5] == 5



# Generated at 2022-06-25 16:51:26.910999
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for i in range(1):
        for j in range(i + 1, 5):
            list = Range(j - i)
            mlist = MapList(lambda x: x % i, iter(list))
            print(mlist[1])


# Generated at 2022-06-25 16:51:37.051091
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))
    print(list(drop_until(lambda x: x > 6, range(10))))
    print(list(drop_until(lambda x: x > 10, range(10))))
    print(list(drop_until(lambda x: x > 100, range(10))))


# Generated at 2022-06-25 16:51:38.596062
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range()[0] == range(0)[0]


# Generated at 2022-06-25 16:51:48.383479
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x == 2, [])) == []
    assert list(drop_until(lambda x: x == 2, [1, 2])) == [2]
    assert list(drop_until(lambda x: x == 1, [1, 2])) == [1, 2]
    assert list(drop_until(lambda x: x < 3, [1, 2])) == [1, 2]
    assert list(drop_until(lambda x: x < 3, [1, 2, 3, 4])) == [1, 2, 3, 4]
    assert list(drop_until(lambda x: x < 5, [1, 2, 3, 4, 5, 6])) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-25 16:52:01.599541
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    assert list(range_0[range_0]) == [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1]
    assert list(range_0[range_0]) == [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1]
    assert list(range_0[range_0]) == [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1]
    assert list(range_0[range_0]) == [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1]

# Generated at 2022-06-25 16:52:02.886473
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10)))


# Generated at 2022-06-25 16:52:09.574665
# Unit test for function split_by
def test_split_by():
    iterable = range(10)
    criterion = lambda x: x % 3 == 0
    result = split_by(iterable, criterion=criterion)
    assert list(result) == [[1, 2], [4, 5], [7, 8]]
    iterable = " Split by: "
    separator = '.'
    result = split_by(iterable, empty_segments=True, separator=separator)
    assert list(result) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    return True



# Generated at 2022-06-25 16:52:22.306221
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by(" Split by: ", empty_segments=False, separator=' ')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]


# Generated at 2022-06-25 16:52:31.318261
# Unit test for function drop_until
def test_drop_until():
    list0 = [0, 1, 2, 3, 4, 5, 6, 7, 8 ,9]
    print(list(drop_until(lambda x: x > 5, range(0, 10))))
    print(list(drop_until(lambda x: x > 100, range(0, 10))))
    print(list(drop_until(lambda x: x > 0, range(1, 10))))

test_drop_until()


# Generated at 2022-06-25 16:52:37.299630
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-25 16:52:46.866770
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(0, 1)
    range_1 = Range(0, 1)
    for i in range(4):
        for j in range(4):
            a = MapList(None, None)
            try:
                a.__getitem__(range_0)
            except:
                pass
            try:
                a.__getitem__(range_1)
            except:
                pass
        for j in range(4):
            a = MapList(None, None)
            try:
                a.__getitem__(range_1)
            except:
                pass
            try:
                a.__getitem__(range_0)
            except:
                pass

# Generated at 2022-06-25 16:53:08.045201
# Unit test for method __getitem__ of class Range

# Generated at 2022-06-25 16:53:17.470892
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 10, 1)
    range_1 = Range(1, 10, 1)
    range_2 = Range()
    range_3 = Range(1, 10, 1)
    range_4 = Range(1, 10, 1)
    range_5 = Range()
    if ((range_0[5]) == 6):
        sys.stdout.write(".")
    elif ((range_0[5]) == 5):
        sys.stdout.write("*")
    else:
        sys.stdout.write("F")
    if ((range_1[0]) == 1):
        sys.stdout.write(".")
    elif ((range_1[0]) == 0):
        sys.stdout.write("*")
    else:
        sys.stdout.write("F")
   

# Generated at 2022-06-25 16:53:23.694617
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda i: i
    lst = [1, 2, 3]
    assert MapList(func, lst)[0] == 1
    assert MapList(func, lst)[0:3] == [1, 2, 3]

# Generated at 2022-06-25 16:53:25.050448
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 16:53:30.133888
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x < 5, range(5))) == [0, 1, 2, 3, 4]


# Generated at 2022-06-25 16:53:30.931481
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass

# Generated at 2022-06-25 16:53:41.933781
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(1, 4).__getitem__(0) == 1
    assert Range(1, 4).__getitem__(1) == 2
    assert Range(1, 4).__getitem__(2) == 3
    assert Range(1, 4).__getitem__(-1) == 3
    assert Range(1, 4).__getitem__(-2) == 2
    assert Range(1, 4).__getitem__(-3) == 1
    assert Range(1, 4).__getitem__(-4) == 4
    assert Range(1, 4).__getitem__(0) == 1
    assert Range(1, 4).__getitem__(slice(2, 3)) == [2, 3]
    assert Range(-1, 2).__getitem__(slice(-2, 1)) == [-1, 0]
    assert Range

# Generated at 2022-06-25 16:53:44.783852
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print('Testing method __getitem__ of class Range ...')
    print(test_case_0())

test_Range___getitem__()

# Generated at 2022-06-25 16:53:53.578378
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Test case with index numerical
    test_Range___getitem__Numeral_0 = Range([1,10,1])
    print(test_Range___getitem__Numeral_0.__getitem__(1))
    print(test_Range___getitem__Numeral_0.__getitem__(2))
    print(test_Range___getitem__Numeral_0.__getitem__(3))

    # Test case with index slice

# Generated at 2022-06-25 16:53:57.846052
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # case 0
    range_0 = Range()

    assert range_0[0] == 0
    assert range_0[1] == 1
    assert range_0[10] == 10

    assert range_0[-1] == 9
    assert range_0[-3] == 7
    assert range_0[-10] == 0

    assert range_0[:5] == [0, 1, 2, 3, 4]
    assert range_0[2:-2] == [2, 3, 4, 5, 6, 7]
    assert range_0[-5:] == [5, 6, 7, 8, 9]
    assert range_0[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-25 16:54:08.692856
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Constructor test
    try:
        MapList()
        assert False, "Missing exception"
    except TypeError:
        pass

    # Function test for method __getitem__

    # Test 1
    def func_0(x_0: int) -> int:
        return x_0 * x_0

    a_0 = [1, 2, 3, 4, 5]
    map_list_0 = MapList(func_0, a_0)
    value_0 = map_list_0[0]
    assert value_0 == 1
    value_1 = map_list_0[1]
    assert value_1 == 4
    value_2 = map_list_0[2]
    assert value_2 == 9
    value_3 = map_list_0[3]
    assert value_3 == 16


# Generated at 2022-06-25 16:54:11.062516
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(1, 2, 1)[0] == 1
    assert Range(1, 2, 1)[_] == 1


# Generated at 2022-06-25 16:54:19.993737
# Unit test for function split_by
def test_split_by():
    # Test1: criterion is a function, no empty segments
    def test_fn(x: int):
        return True if x % 3 == 0 else False
    it_0 = split_by(range(10), criterion=test_fn)
    assert next(it_0) == [1,2]
    assert next(it_0) == [4,5]
    assert next(it_0) == [7,8]
    try:
        next(it_0)
        assert False
    except StopIteration:
        pass

    # Test2: criterion is a function, empty_segments is True
    it_1 = split_by(range(10), criterion=test_fn, empty_segments=True)
    assert next(it_1) == []
    assert next(it_1) == [1,2]
   

# Generated at 2022-06-25 16:54:25.475394
# Unit test for function drop_until
def test_drop_until():
    x = [1,2,3,4,5,6]
    y = []
    for i in range(7):
        y.append(1)
    assert(list(drop_until(lambda x: x > 5, x)) == [6])
    assert(list(drop_until(lambda x: x > 5, y)) != [6])


# Generated at 2022-06-25 16:54:29.433347
# Unit test for function drop_until
def test_drop_until():
    # Test case 0
    input0 = [1,2,3,4,5]
    output0 = drop_until(lambda x: x > 3, input0)
    expect0 = [4, 5]
    # Assert
    assert( [elem0 for elem0 in output0] == expect0)



# Generated at 2022-06-25 16:54:35.429695
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
