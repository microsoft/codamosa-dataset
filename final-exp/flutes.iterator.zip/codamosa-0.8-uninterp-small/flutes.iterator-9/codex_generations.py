

# Generated at 2022-06-25 16:45:33.328394
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print('test_Range___getitem__')
    range_0 = Range(0, 10, 1)
    range_0_slice = slice(0, 10, 1)
    print(range_0[range_0_slice])
    try:
        print(range_0[0.0])
        assert(False)
    except SystemError as error_0:
        print(error_0)
    range_0_slice = slice(0, 10, 2)
    print(range_0[range_0_slice])
    range_0_slice = slice(0, 10, 3)
    print(range_0[range_0_slice])
    range_0_slice = slice(0, 10, 4)
    print(range_0[range_0_slice])

# Generated at 2022-06-25 16:45:35.559750
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 16:45:39.628933
# Unit test for function drop_until
def test_drop_until():
    assert [x for x in drop_until(lambda x: x > 5, range(10))] == [6, 7, 8, 9]

# Unit tests for function split_by

# Generated at 2022-06-25 16:45:44.260874
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:45:46.801608
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range() 
    iter_0 = drop_until(lambda x: x > 5, range_0)
    print(list(iter_0))


# Generated at 2022-06-25 16:45:49.589751
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    assert range_0[0] == 0
    assert range_0[1] == 1


# Generated at 2022-06-25 16:45:52.085095
# Unit test for function chunk
def test_chunk():
    text = "abcd efg hijklmn"
    for n in range(3):
        # print(n)
        for chunk_ in chunk(n, text):
            print(chunk_)




# Generated at 2022-06-25 16:45:55.133512
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    range_1 = Range()
    lazy_list_0 = LazyList(range_0)
    lazy_list_1 = LazyList(range_1)
    assert lazy_list_0.__len__() == lazy_list_1.__len__()


# Generated at 2022-06-25 16:45:57.074072
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    entry_0 = Range()
    assert 0 in entry_0
    assert 1 in entry_0

# Generated at 2022-06-25 16:45:59.079375
# Unit test for function drop_until
def test_drop_until():
    assert(list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9])


# Generated at 2022-06-25 16:46:03.868909
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass


# Generated at 2022-06-25 16:46:11.952382
# Unit test for function drop_until
def test_drop_until():
    x = drop_until(lambda x: x > 5, range(10))
    assert x == range(6,10)
    x = list(drop_until(lambda x: x > 5, range(10)))
    assert x == list(range(6,10))
    x = drop_until(lambda x: x > 1, range(10))
    assert x == range(2,10)
    x = list(drop_until(lambda x: x > 1, range(10)))
    assert x == list(range(2,10))
    x = drop_until(lambda x: x > 15, range(10))
    assert x == range(10,10)
    x = list(drop_until(lambda x: x > 15, range(10)))
    assert x == list(range(10,10))

# Generated at 2022-06-25 16:46:15.385611
# Unit test for function take
def test_take():
    range_0 = Range(1, 10)
    lazy_list_0 = take(5, range_0)
    assert lazy_list_0.get() == [1, 2, 3, 4, 5]



# Generated at 2022-06-25 16:46:19.600079
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Assign
    range_0 = range(1, 3)
    lazy_list_1 = LazyList(range_0)
    int_0 = len(lazy_list_1)
    # Assert
    assert_equal(int_0, 2)


# Generated at 2022-06-25 16:46:26.434057
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    range_1 = Range(0, 20)
    range_2 = Range(0, 100)
    range_3 = Range(0, 200)
    # value = list(range_3)
    # print(value)
    lazy_list_0 = LazyList(range_0)
    lazy_list_1 = LazyList(range_1)
    lazy_list_2 = LazyList(range_2)
    lazy_list_3 = LazyList(range_3)
    lazy_list_0.__getitem__([])
    lazy_list_0.__getitem__([1])
    lazy_list_1.__getitem__([])
    lazy_list_1.__getitem__([100])
    # lazy_list_2.__getitem__([1])

# Generated at 2022-06-25 16:46:29.931076
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list_0 = ['', '']
    lazy_list_0 = LazyList(list_0)
    assert len(lazy_list_0) == 2


# Generated at 2022-06-25 16:46:33.880482
# Unit test for function drop_until
def test_drop_until():
    (v, actual) = ([3,4,5,6,7,8,9], drop_until(lambda x: x > 5, range(10)))
    assert(list(actual) == v)
    print('all passed')

test_drop_until()



# Generated at 2022-06-25 16:46:36.729490
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    lazyList_0 = LazyList(range_0)
    assert(len(lazyList_0) == len(range_0))


# Generated at 2022-06-25 16:46:48.546299
# Unit test for function chunk
def test_chunk():
    l = []
    list_0 = list(chunk(2, range(10)))
    assert list_0 == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    l = []
    list_1 = list(chunk(3, range(11)))
    assert list_1 == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10]]
    l = []
    list_2 = list(chunk(5, range(14)))
    assert list_2 == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9], [10, 11, 12, 13]]
    l = []
    list_3 = list(chunk(3, range(0)))
    assert list_3 == []


# Generated at 2022-06-25 16:46:50.529364
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    range_0.__getitem__(0)


# Generated at 2022-06-25 16:47:07.378418
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print("Start testing for method __getitem__ of class Range")
    #Test for index
    range_0 = Range(5)
    assert_equals(range_0[0], 0)
    print("Range__getitem__ 0 passed!")
    #Test for slice
    range_0 = Range(5)
    assert_equals(range_0[1:3], [1, 2])
    print("Range__getitem__ 1 passed!")
    #Test for index
    range_0 = Range(0, 5)
    assert_equals(range_0[0], 0)
    print("Range__getitem__ 2 passed!")
    #Test for index
    range_0 = Range(0, 5, 1)
    assert_equals(range_0[0], 0)

# Generated at 2022-06-25 16:47:17.305068
# Unit test for function take
def test_take():
    lst = [i for i in range(10)]
    itr = range(10)
    tst_lst = [i for i in take(5, lst)]
    tst_itr = [i for i in take(5, itr)]
    #print("test_lst = ", tst_lst)
    #print("test_itr = ", tst_itr)
    assert len(tst_itr) == 5
    assert len(tst_lst) == 5
    for i in range(5):
        assert tst_itr[i] == i
        assert tst_lst[i] == i
    return


# Generated at 2022-06-25 16:47:29.047990
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0 = Range(0)
    range_0 = Range(0, 0)
    range_0 = Range(0, 0, 0)
    range_0 = Range(0, 0, 0, 0)
    #1
    range_0.__getitem__()
    #2
    range_0.__getitem__([])
    #3
    range_0.__getitem__({})
    #4
    range_0.__getitem__(slice(0))

# Generated at 2022-06-25 16:47:37.320404
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    nums = [x * x for x in range_0]
    map_list_0 = MapList((lambda x : x * x), nums)
    assert map_list_0[0] == 0

    nums = [x * x for x in range_0]
    map_list_1 = MapList((lambda x : x * x), nums)
    assert map_list_1[4] == 16

    nums = [x * x for x in range_0]
    map_list_2 = MapList((lambda x : x * x), nums)
    assert map_list_2[2:4] == [4, 16]

    nums = [x * x for x in range_0]
    map_list_3 = MapList((lambda x : x * x), nums)
    assert map_list_

# Generated at 2022-06-25 16:47:46.321519
# Unit test for function take
def test_take():
    assert list(take(3, range(8))) == [0, 1, 2]
    assert list(take(10, [1, 2, 3])) == [1, 2, 3]
    assert list(take(10, (1, 2, 3))) == [1, 2, 3]



# Generated at 2022-06-25 16:47:47.144714
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    pass


# Generated at 2022-06-25 16:47:51.355014
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 11, 2)
    r_instance_0 = r[0]
    r_instance_1 = r[2]
    r_instance_2 = r[4]


# Generated at 2022-06-25 16:47:57.559407
# Unit test for function drop_until
def test_drop_until():
    itr = drop_until(lambda x: x > 5, range(10))
    lst = list(itr)
    print(lst)
    assert lst == [6,7,8,9], "[TEST] drop_until FAILED"
    print("[TEST] drop_until PASSED")

test_drop_until()


# Generated at 2022-06-25 16:48:02.615241
# Unit test for function take
def test_take():
    range_0 = Range(1, 10000)
    assert list(take(5, range_0)) == [0, 1, 2, 3, 4]


# Generated at 2022-06-25 16:48:06.024023
# Unit test for function drop
def test_drop():
    it = drop(0, range(5))
    i = 1
    for x in it:
        assert x == i
        i += 1


# Generated at 2022-06-25 16:48:19.205138
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    test_LazyList = LazyList()
    test_LazyList.list = [1, 2, 3, 4, 5]
    test_LazyList.iter = test_LazyList.list.__iter__()
    test_LazyList.exhausted = True
    assert test_LazyList[1] == test_LazyList.list[1]
    assert test_LazyList[1:4] == test_LazyList.list[1:4]


# Generated at 2022-06-25 16:48:21.660686
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
  lst = LazyList(range(1, 10))
  return lst.__len__() == 9


# Generated at 2022-06-25 16:48:23.798137
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    assert list(drop_until(lambda x: x > 5, range_0)) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:48:35.463429
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Case 0
    range_0 = Range()
    with raises(ValueError, match=r"Range should be called the same way as the builtin `range`"):
        test_case_0()

    # Case 1
    range_0 = Range(1)
    assert range_0[0] == 0
    with raises(IndexError, match=r"^1$"):
        range_0[1]

    # Case 2
    range_0 = Range(0, 1)
    assert range_0[0] == 0
    with raises(IndexError, match=r"^1$"):
        range_0[1]

    # Case 3
    range_0 = Range(0, 1, 1)
    assert range_0[0] == 0

# Generated at 2022-06-25 16:48:45.459945
# Unit test for function split_by
def test_split_by():
    """
    Tests the split_by function.
    """
    # Empty case
    assert list(split_by((), criterion=lambda x: True)) == []
    assert list(split_by((), criterion=lambda x: False)) == []
    assert list(split_by((), empty_segments=True, criterion=lambda x: True)) == [[]]
    assert list(split_by((), empty_segments=True, criterion=lambda x: False)) == []

    # Simple case
    assert list(split_by((1,2,3,4), criterion=lambda x: x % 2 == 0)) == [[1], [3]]
    assert list(split_by((1,2,3,4), criterion=lambda x: x % 2 == 1)) == [[2], [4]]

# Generated at 2022-06-25 16:48:56.560086
# Unit test for function drop_until
def test_drop_until():
    print("Test in {} started".format(__file__))
    # Test on a natural number
    it_0 = drop_until(lambda x: x > 5, range(10))
    assert next(it_0) == 6
    # Test on a float
    it_1 = drop_until(lambda x: x > 0.5, [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9])
    assert next(it_1) == 0.6
    # Test on a string
    it_2 = drop_until(lambda x: x[0] >= 'b', ['a', 'b', 'c', 'd', 'e', 'f'])
    assert next(it_2) == 'b'

# Generated at 2022-06-25 16:49:01.214384
# Unit test for function drop_until
def test_drop_until():
    list_0 = drop_until(lambda x: x > 5, range(10))
    list_1 = [6, 7, 8, 9]
    print (list_0)
    if list_0 == list_1:
        print("drop_until: PASS")
        return True
    else:
        print("drop_until: FAIL")
        return False



# Generated at 2022-06-25 16:49:08.031981
# Unit test for function drop_until
def test_drop_until():
    # Test code 1: 
    # Test if the function returns correct value after dropping until a certain value appears
    assert(list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9])

    # Test code 2: 
    # Test if the function returns correct value when no elements are dropped
    assert(list(drop_until(lambda x: x < 5, range(10))) == [])

    # Test code 3: 
    # Test if the function returns correct value when all elements are dropped
    assert(list(drop_until(lambda x: x < 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])


# Generated at 2022-06-25 16:49:14.467342
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    lazyList_0 = LazyList([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    lazyList_0._fetch_until(4)
    lazyList_0._fetch_until(4)
    #assertEqual(lazyList_0.__len__(), 10)

# Generated at 2022-06-25 16:49:16.736834
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(8)

    test_0 = range_0[4]
    assert test_0 == 4


# Generated at 2022-06-25 16:49:31.892197
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(-10, 100))) == list(drop_until(lambda x: x > 0, range(-10))) == list(drop_until(lambda x: x > 0, [])) == []


# Generated at 2022-06-25 16:49:38.349876
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from collections import namedtuple

    TestCase = namedtuple('TestCase', ['params', 'asserts'])

# Generated at 2022-06-25 16:49:39.538465
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()



# Generated at 2022-06-25 16:49:40.575666
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    pass


# Generated at 2022-06-25 16:49:44.882999
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # The length of a LazyList cannot be obtained before the iterable is depleted
    try:
        range_0 = Range()
        range_0.__len__()
        raise ValueError("The length of a LazyList cannot be obtained before the iterable is depleted")
    except TypeError:
        pass


# Generated at 2022-06-25 16:49:48.977779
# Unit test for function drop_until
def test_drop_until():
    actual = list(drop_until(lambda x: x > 5, range(10)))
    expected = [6, 7, 8, 9]
    assert actual == expected
# end of unit test


# Generated at 2022-06-25 16:49:50.435415
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0[0] = 0


# Generated at 2022-06-25 16:49:54.257015
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def func(a0: int) -> int:
        return a0
    a0 = 1
    a1 = Range(a0)
    obj = MapList(func, a1)
    obj.__getitem__(0)


# Generated at 2022-06-25 16:50:01.583189
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    values_0 = [('abc'), ('abc'), ('abc')]
    lst_0 = LazyList(values_0)
    values_1 = [(123.0), (123.0), (123.0)]
    lst_1 = LazyList(values_1)
    lst_2 = LazyList(values_1)
    range_0 = Range()
    range_1 = Range()
    range_2 = Range()
    range_3 = Range()
    assert lst_0.__len__() == 3
    assert len(lst_1) == len(lst_2)
    assert len(lst_2) == len(lst_2)
    lst_2[:]
    assert len(lst_2) == len(range_0)
    assert len(range_0)

# Generated at 2022-06-25 16:50:02.471087
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list_0 = LazyList()



# Generated at 2022-06-25 16:50:21.413557
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(5)
    try:
        range_0[5]
    except IndexError as e:
        print("IndexError is expected but not caught")
    range_1 = Range(5)
    try:
        range_1[-6]
    except IndexError as e:
        print("IndexError is expected but not caught")



# Generated at 2022-06-25 16:50:23.574852
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    dummy_range = Range()
    idx = 0
    range_5 = dummy_range[idx]


# Generated at 2022-06-25 16:50:25.010595
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range.__getitem__(Range(), 0) == 0


# Generated at 2022-06-25 16:50:32.370437
# Unit test for function drop_until
def test_drop_until():
    """test_drop_until"""
    a = [1,2,3,4,5]
    b = [2,4,6,8,10]

    c = drop_until(lambda x: x % 2 == 0, a)
    for i in c:
        print(i)

    d = drop_until(lambda x: x % 2 == 0, b)
    for i in d:
        print(i)


# Generated at 2022-06-25 16:50:35.290160
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(50)

    assert range_0[10] == 10 
    assert range_0[30] == 30 
    assert range_0[40] == 40 


# Generated at 2022-06-25 16:50:37.828800
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range(0, 100)
    ll_0 = LazyList(range_0)
    for i in range(100):
        assert ll_0[i] == i


# Generated at 2022-06-25 16:50:42.729530
# Unit test for function drop_until
def test_drop_until():
    def comp(n):
        return n > 5

    iterable = range(10)
    assert list(drop_until(comp, iterable)) == [6, 7, 8, 9]
    iterable = range(-10,0)
    assert list(drop_until(comp, iterable)) == []


# Generated at 2022-06-25 16:50:45.507617
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(5)
    range_0._get_idx(4)


# Generated at 2022-06-25 16:50:49.553978
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print("Running ", __name__,".test_Range___getitem__")
    range_0 = Range(0, 100, 1)
    if range_0[0] != 0:
        print("Test Case Failed for range_0[0]")
        return



# Generated at 2022-06-25 16:50:52.665272
# Unit test for function drop_until
def test_drop_until():
    # test case 0
    # assert drop_until(lambda x: x > 5, range(10)) == [6, 7, 8, 9]
    assert drop_until(lambda x: x > 5, range(10)) == [6, 7, 8, 9]



# Generated at 2022-06-25 16:51:20.562032
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    mapList_0 = MapList(0, 0)
    assert mapList_0.__getitem__(0) == 0


# Generated at 2022-06-25 16:51:26.012314
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == [
        'a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], initial='x')) == [
        'x', 'xa', 'xab', 'xabc', 'xabcd']


# Generated at 2022-06-25 16:51:29.218988
# Unit test for function drop_until
def test_drop_until():
    def is_empty(line):
        return len(line.strip()) == 0

    file = open("/usr/share/dict/words", "r")
    line_iter = drop_until(is_empty, file)
    assert next(line_iter).strip() == "A"
    assert next(line_iter).strip() == "a"
    assert next(line_iter).strip() == "aa"
    assert next(line_iter).strip() == "aal"
    assert next(line_iter).strip() == "aalii"
    assert next(line_iter).strip() == "aam"


# Generated at 2022-06-25 16:51:32.832633
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    __returned_0 = range_0.__getitem__(0)
    assert type(__returned_0) == int
    assert  0 == __returned_0


# Generated at 2022-06-25 16:51:34.849212
# Unit test for function drop_until
def test_drop_until():
    for x in drop_until(lambda x: x > 5, list(range(10))):
        print(x)
    return


# Generated at 2022-06-25 16:51:36.942246
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert (Range(1, 2)[0] == 1)
    assert (Range(3)[3] == 3)
    assert (Range(1, 2, 1)[1] == 2)


# Generated at 2022-06-25 16:51:46.818280
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    r = LazyList(range_0)
    r[3]
    r[50]
    r[3]
    r[4]
    r[4]
    r[4]
    r[4]
    r[4]
    r[4]
    # Multi-dimensional indexing
    r[[1, 2, 3, 4]]
    r[:, 0]
    r[:, 0]
    r[[1, 2, 3, 4]]
    r[:, 0]
    r[:, 0]
    r[:, 0]
    r[[1, 2, 3, 4]]
    r[:, 0]
    r[:, 0]


# Generated at 2022-06-25 16:51:49.429120
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    ll = LazyList(range(10))
    if len(ll) == 10:
        return 0
    else:
        return 1


# Generated at 2022-06-25 16:52:02.314151
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Init test case
    def __init__(iterable):
        self.iter = iter(iterable)
        self.exhausted = False
        self.list = []

    def __iter__(self):
        if self.exhausted:
            return iter(self.list)
        class LazyListIterator:
            def __init__(self, lst):
                self.list = weakref.ref(lst)
                self.index = 0
            def __iter__(self):
                return self
            def __next__(self):
                try:
                    obj = self.list()[self.index]
                except IndexError:
                    raise StopIteration
                self.index += 1
                return obj
        return LazyListIterator(self)


# Generated at 2022-06-25 16:52:10.707063
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()  # empty constructor
    range_0 = Range()  # empty constructor
    range_0 = Range()  # empty constructor
    range_0 = Range()  # empty constructor
    range_0 = Range()  # empty constructor
    range_0 = Range(10)  # (end)
    range_1 = range_0[0]
    range_2 = range_0[1]
    range_3 = range_0[3]
    range_0 = Range(1, 10 + 1)  # (start, end)
    range_1 = range_0[0]
    range_2 = range_0[1]
    range_3 = range_0[3]
    range_0 = Range(1, 11, 2)  # (start, end, step)
    range_1 = range_0

# Generated at 2022-06-25 16:52:43.980930
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    instance_0 = LazyList([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    instance_1 = LazyList(range(0, 10))


# Generated at 2022-06-25 16:52:54.210601
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    lst_0 = List[Range[int]]()
    range_0 = Range(0, 0)
    int_0 = range_0[0]
    list_0 = [lst_0, lst_0]
    range_0 = Range(0, 0)
    list_0 = range_0[0:0]
    list_0 = range_0[0:]
    range_0 = Range(0, 0)
    list_0 = range_0[0:0]
    list_0 = range_0[0:]
    range_0 = Range(0, 0)
    list_0 = range_0[0:0]
    list_0 = range_0[0:]
    range_0 = Range(0, 0)
    list_0 = range_0[0:0]
    list_0

# Generated at 2022-06-25 16:52:55.073975
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range()


# Generated at 2022-06-25 16:52:56.790785
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 2)
    tem_2 = range_0[0]
    assert tem_2 == 1, 'Failed test_Range___getitem__'


# Generated at 2022-06-25 16:53:02.419551
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    assertLazyListLen(10, range_0)
    assertLazyListLen(10, range(10), iterator=False)
    assertLazyListLen(10, range(10), iterator=True)
    try:
        assertLazyListLen(10, range(1), iterator=False)
    except AssertionError:
        return
    assert False


# Generated at 2022-06-25 16:53:05.905095
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    print('Testing method LazyList.__getitem__ ...', end='')
    list_0 = LazyList(i for i in range(100))
    for i in range(100):
        print(list_0[i], end=' ')
    print()


# Generated at 2022-06-25 16:53:09.558003
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x, [1, 2, 3, 4]).__getitem__(1) == 2
    assert MapList(lambda x: x, [1, 2, 3, 4]).__getitem__(-2) == 3


# Generated at 2022-06-25 16:53:14.760240
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    ____assertIn('LazyList', dir(range_0))
    ____assertIn('__len__', dir(range_0))
    assert(LazyList.__dict__['__len__'] is LazyList.__len__)
    try:
        len(range_0)
        assert(False)
    except TypeError as e:
        pass


# Generated at 2022-06-25 16:53:27.989748
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Construct list to test against
    test_str: List[str] = []
    for i in range(1, 10+1):
        test_str.append(str(i))

    failed: bool = False

    # Construct LazyList using iterable
    test_list: LazyList[str] = LazyList(test_str)

    # Test __len__
    try:
        len(test_list)
    except TypeError:
        pass
    else:
        failed = True
    assert not failed

    # Test __iter__
    test_iter: Iterator[str] = iter(test_list)
    for _ in range(2):
        i: int = 0
        for _ in test_iter:
            i += 1
        assert i == 10

    # Test __getitem__

# Generated at 2022-06-25 16:53:33.699522
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    class Dummy:
        def __iter__(self):
            for i in range(10):
                yield i

    r = LazyList(Dummy())
    assert len(r) == 10, 'Failed test_LazyList___len__'
