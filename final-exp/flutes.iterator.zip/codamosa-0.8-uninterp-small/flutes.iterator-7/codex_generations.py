

# Generated at 2022-06-25 16:45:30.060657
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    #assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]


# Generated at 2022-06-25 16:45:32.299541
# Unit test for function drop
def test_drop():
    stream = drop_until(lambda x: x >= 5, range(100))
    assert next(stream) == 5


# Generated at 2022-06-25 16:45:42.908080
# Unit test for function drop
def test_drop():
    elem_list = list(drop(5, range(10)))
    assert elem_list == [5, 6, 7, 8, 9]
    elem_list = list(drop(-1, range(10)))
    assert elem_list == []
    elem_list = list(drop(-1, []))
    assert elem_list == []
    elem_list = list(drop(0, range(10)))
    assert elem_list == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    elem_list = list(drop(10, range(10)))
    assert elem_list == []
    return "function drop is a success"


# Generated at 2022-06-25 16:45:51.376925
# Unit test for function chunk
def test_chunk():
    chunk_0 = chunk(3, range(10))
    chunk_1 = ([0, 1, 2], [3, 4, 5], [6, 7, 8], [9])
    for i, ch in enumerate(chunk_0):
        assert ch == chunk_1[i]
    chunk_2 = chunk(0, range(10))
    assert chunk_2 == None
    #assert chunk_2 == ValueError("`n` should be positive")


# Generated at 2022-06-25 16:45:57.639613
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_1 = Range(0)
    def fun_0(x_0: int) -> int :
        return range_1[x_0]
    range_2 = Range(0)
    range_3 = Range(1)
    def fun_1(x_0: int) -> int :
        return range_2[x_0]*range_3[x_0]
    range_4 = Range(0)
    range_5 = Range(1)
    range_6 = Range(2)
    def fun_2(x_0: int) -> int :
        return range_4[x_0]*range_5[x_0]*range_6[x_0]
    range_7 = Range(0)
    range_8 = Range(1)
    range_9 = Range(2)
   

# Generated at 2022-06-25 16:46:00.844605
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    assert type(range_0) is LazyList, "Object is not of class LazyList"
    n = len(range_0)
    assert False, "Unit test for method LazyList.__len__ failed"


# Generated at 2022-06-25 16:46:02.530993
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 16:46:11.958336
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print('Testing method __getitem__ of class Range')
    range_0 = Range(3)
    if range_0[2] is not 2:
        print('Method __getitem__ of class Range returned incorrect value')
    range_1 = Range(3)
    if range_1[3] is not None:
        print('Method __getitem__ of class Range returned incorrect value')
    range_2 = Range(3)
    if range_2[0] is not 0:
        print('Method __getitem__ of class Range returned incorrect value')
    range_3 = Range(3)
    if range_3[1] is not 1:
        print('Method __getitem__ of class Range returned incorrect value')
    range_4 = Range(3)

# Generated at 2022-06-25 16:46:12.495342
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    pass


# Generated at 2022-06-25 16:46:16.108631
# Unit test for function split_by
def test_split_by():
    result_list = list(split_by([1, 2, 3, 4, 5, 6, 7], criterion = lambda x : x % 3 == 0))
    assert result_list == [[1, 2], [4, 5], [7]]


# Generated at 2022-06-25 16:46:39.302418
# Unit test for function take
def test_take():
    assert list(take(5, range(75))) == [0,1,2,3,4]
    assert list(take(12, range(75))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    assert list(take(12, range(1))) == [0]
    assert list(take(0, range(12))) == []
    assert list(take(1, range(1))) == [0]
    assert list(take(1, range(0))) == []


# Generated at 2022-06-25 16:46:45.471661
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(5)
    range_2 = Range(5, 6)
    range_3 = Range(5, 7, 2)
    assert range_2[-1] == 5
    assert range_1[0] == 0
    assert range_0[0] == 0
    assert range_2[-1] == 5


# Generated at 2022-06-25 16:46:57.887864
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    c = 0
    while c < 100:
        x = random.randint(-100, 100)
        y = random.randint(-100, 100)
        z = random.randint(-10, 10)
        if z == 0:
            z = 1
        r1 = Range(x, y, z)
        i = random.randint(0, len(r1) - 1)
        print("Random Number = ", i, "len = ", len(r1) - 1)
        assert r1[i] == x + z * i
        c += 1



# Generated at 2022-06-25 16:46:59.723587
# Unit test for function take
def test_take():
    a = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    b = []
    b = take(3, a)
    assert b == [1, 2, 3]
    b = take(0, a)
    assert b == []
    b = take(-1, a)
    assert b == []


# Generated at 2022-06-25 16:47:01.216580
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range(20):
        test_case_0()

# Generated at 2022-06-25 16:47:03.943141
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    lazy_list_0 = LazyList(range_0)
    assert_equal(list(lazy_list_0), [])


# Generated at 2022-06-25 16:47:05.903411
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    assert len(range_0) == 3, "LazyList __len__ failed"



# Generated at 2022-06-25 16:47:09.848012
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    def temp_test_func():
        if 0 < range_0[_]:
            return "passed"
        else:
            return "failed"
    for _ in range_0:
        temp_test_func()
    return "done"


# Generated at 2022-06-25 16:47:13.411141
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    r0 = LazyList(range(100))
    for i in r0:
        print(i)


# Generated at 2022-06-25 16:47:24.832690
# Unit test for function drop_until
def test_drop_until():
    l1 = [1, 4, 5, 6, 7, 0]
    l2 = [-1, 3, 6, 7, 1, 0]
    l3 = [1, 2, 3, 4]
    l4 = [0, 0, 0, 0]
    l5 = [1, 2, 3, 4, 5, 4, 3, 2, 1, 0]
    l6 = [2, 3, 1, 5, 6, 4, 0, 5, 6, 7]
    l7 = [7, 6, 5, 4, 3, 2]
    assert list(drop_until(lambda x: x > 3, l1)) == [4, 5, 6, 7, 0]
    assert list(drop_until(lambda x: x > 0, l2)) == [3, 6, 7, 1, 0]
    assert list

# Generated at 2022-06-25 16:47:37.204030
# Unit test for function drop_until
def test_drop_until():
    assert(list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9])
    assert(list(drop_until(lambda x: x > 5, [])) == [])
    assert(list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5])) == [])
    assert(list(drop_until(lambda x: x > 0, [1, 2, 3, 4, 5])) == [1])
    assert(list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7, 8, 9])) == [6, 7, 8, 9])


# Generated at 2022-06-25 16:47:45.227610
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))
    print(list(drop_until(lambda x: x > 5, range(6, 11))))

test_drop_until()



# Generated at 2022-06-25 16:47:48.871162
# Unit test for function drop_until
def test_drop_until():
    input_0 = [4,3,2,1]
    output_0 = drop_until(lambda x: x == 3, input_0)
    expected_0 = [3,2,1]
    result = list(output_0)
    if result == expected_0:
        return True
    else:
        return False


# Generated at 2022-06-25 16:47:59.138744
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(0, 0, 1)
    range_2 = Range(0, 1, 1)
    range_3 = Range(0, 2, 1)
    range_4 = Range(0, 3, 1)
    expected = 0
    actual = range_0[0]
    assert actual == expected
    expected = 0
    actual = range_1[0]
    assert actual == expected
    expected = 0
    actual = range_2[0]
    assert actual == expected
    expected = 0
    actual = range_3[0]
    assert actual == expected
    expected = 1
    actual = range_4[1]
    assert actual == expected


# Generated at 2022-06-25 16:48:02.552785
# Unit test for function chunk
def test_chunk():
    list_0 = list(chunk(3, range(10)))
    assert list_0 == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-25 16:48:11.102453
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    """
    Test case for method __getitem__
    """
    # Test 0:
    range_0 = Range(10)
    """
    r = Range(10)
    """
    assert range_0[0] == 0
    assert range_0[1] == 1
    assert range_0[2] == 2
    assert range_0[3] == 3
    assert range_0[4] == 4

    # Test 1:
    range_0 = Range(1, 10 + 1)
    """
    r = Range(1, 10 + 1)
    """
    assert range_0[0] == 1
    assert range_0[1] == 2
    assert range_0[2] == 3
    assert range_0[3] == 4
    assert range_0[4] == 5

    # Test 2:

# Generated at 2022-06-25 16:48:21.954741
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) ==  [[], [], [], [], [], [], [], [], [], []]
    assert list(chunk(1, range(10))) ==  [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(2, range(10))) ==  [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(3, range(10))) ==  [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]

# Generated at 2022-06-25 16:48:24.538332
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    llist = LazyList(range_0)
    llist.__len__()



##########################
# Custom types           #
##########################

# Generated at 2022-06-25 16:48:31.693190
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    print("Running test LazyList___getitem__")
    range_0 = Range()
    assert(isinstance(range_0, LazyList))
    assert(range_0[0] == 0)
    assert(range_0[1] == 1)
    assert(range_0[2] == 2)
    assert(range_0[3] == 3)
    assert(range_0[4] == 4)
    assert(range_0[5] == 5)
    assert(range_0[6] == 6)
    assert(range_0[7] == 7)
    assert(range_0[8] == 8)
    assert(range_0[9] == 9)
    assert(range_0[10] == 10)
    assert(range_0[-10] == 0)

# Generated at 2022-06-25 16:48:34.921095
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # test case 0
    range_0 = Range()
    list_0 = range_0.__iter__()


# Generated at 2022-06-25 16:48:43.317923
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    test_item0 = drop_until(lambda x: x > 5, range_0)
    test_item1 = Iterator[int]
    assert isinstance(test_item0, test_item1)


# Generated at 2022-06-25 16:48:44.508860
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))


# Generated at 2022-06-25 16:48:47.639754
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = MapList(0)
    int_0 = range_0.__getitem__(1)
    tuple_0 = range_0.__getitem__((1, 2))
    print(int_0)
    print(tuple_0)


# Generated at 2022-06-25 16:48:49.590976
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    assert list(range_0[0:3]) == [0, 1, 2]


# Generated at 2022-06-25 16:48:52.276296
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(randint(0, 9), randint(0, 9))
    slice_0 = slice(randint(0, 9), randint(0, 9))
    assert list(range_0.__getitem__(slice_0)) == range_0[slice_0]


# Generated at 2022-06-25 16:49:02.479925
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    parm_passed_by_reference_0 = (('a'), ({'b': 'c'},))
    range_0 = Range()
    range_1 = Range()
    parm_passed_by_reference_1 = (('a'), ({'b': 'c'},))
    parm_passed_by_reference_2 = (('a'), ({'b': 'c'},))
    parm_passed_by_reference_3 = (('a'), ({'b': 'c'},))
    parm_passed_by_reference_4 = (('a'), ({'b': 'c'},))
    parm_passed_by_reference_5 = (('a'), ({'b': 'c'},))

# Generated at 2022-06-25 16:49:03.396446
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert False


# Generated at 2022-06-25 16:49:05.975037
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    obj = MapList()
    param0 = []
    i = 0
    res = obj.MapList__getitem__(param0, i)
    print("Expected: ")
    print("Received: "+ str(res))


# Generated at 2022-06-25 16:49:09.108347
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Create LazyList object
    range_0 = Range()

    try:
        range_0.__len__()
        assert False, "Expected an exception"
    except TypeError:
        pass
    except Exception:
        assert False, "Unexpected exception"



# Generated at 2022-06-25 16:49:15.000396
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():

    def _test_case_0():
        """
        Tests method __getitem__ with list of lists
        :return:
        """

        def map_list_on_range(x: int) -> int:
            return x * 2

        map_list_0 = MapList(map_list_on_range, r)
        assert map_list_0[0] == 0
        assert map_list_0[-1] == 18
        assert map_list_0[-2] == 16

    def _test_case_1():
        """
        Tests method __getitem__ with list of JsonNodes
        :return:
        """

        def map_list_on_json_nodes(x: JsonNode) -> int:
            return x.as_int(0)


# Generated at 2022-06-25 16:49:21.309904
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(-1, -2).__getitem__(0) == -1


# Generated at 2022-06-25 16:49:29.087545
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(range_0.length)
    range_2 = Range(0, range_1.length, 1)
    _range = Range(0, range_2.length, 1)
    for _ in range_2:
        _range = Range(0, _range.length, 1)
    _range = Range(0, _range.length, 1)



# Generated at 2022-06-25 16:49:36.767493
# Unit test for function drop_until
def test_drop_until():

    class SpecialString:
        def __init__(self, string):
            self.string = string

        def __str__(self):
            return self.string

    ss = SpecialString("Hello, world!")
    result = drop_until(lambda x: isinstance(x, SpecialString), [0, 1, 2, ss])
    assert next(result) == ss



# Generated at 2022-06-25 16:49:42.089252
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1)
    assert range_0[0] == 1 
    assert range_0[0:0] == [] 
    assert range_0[-1:0] == [1] 
    assert range_0[0:1] == [1] 
    assert range_0[-1] == 1 


# Generated at 2022-06-25 16:49:48.718067
# Unit test for function drop_until
def test_drop_until():
    import random
    for i in range(100):
        condition = random.randint(1, 100)
        l = [random.randint(1, 100) for _ in range(condition)]
        l2 = l
        l.extend([random.randint(1, 100) for _ in range(random.randint(1, 100))])
        assert(list(drop_until(lambda x: x == condition, l)) == l2)


# Generated at 2022-06-25 16:49:54.931378
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(10))
    assert l[0] == 0
    assert l[1] == 1
    assert l == [0, 1]
    assert l[1:4] == [1, 2, 3]
    assert l[5:] == [5, 6, 7, 8, 9]
    assert l == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-25 16:49:58.089785
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    LazyList_0 = LazyList(range_0)
    try:
        LazyList_0.__len__()
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 16:50:00.844259
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:50:01.700738
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert True


# Generated at 2022-06-25 16:50:08.037081
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    """Test getitem of class MapList."""
    try:
        map_list_0 = MapList(lambda x: x, [1, 3, 3, 5])
        assert map_list_0[3] == 5
        assert map_list_0[2] == 3
        assert map_list_0[0] == 1
    except Exception:
        error_type, error_instance, tb = sys.exc_info()
        traceback.print_exception(error_type, error_instance, tb)
        raise


# Generated at 2022-06-25 16:50:23.479790
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # range_0 = Range()
    # assert range_0[1] == [], "range_0[1] returned incorrect value"
    range_1 = Range(10)
    assert range_1[0] == 0, "range_1[0] returned incorrect value"
    range_2 = Range(1, 10 + 1)
    assert range_2[0] == 1, "range_2[0] returned incorrect value"
    range_3 = Range(1, 11, 2)
    assert range_3[0] == 1, "range_3[0] returned incorrect value"
    assert range_3[1] == 3, "range_3[1] returned incorrect value"
    assert range_3[2] == 5, "range_3[2] returned incorrect value"

# Generated at 2022-06-25 16:50:25.321202
# Unit test for function drop_until
def test_drop_until():
    try:
        print(list(drop_until(lambda x: x > 5, range(10))))
    except:
        print("fail")
    else:
        print("pass")


# Generated at 2022-06-25 16:50:30.255718
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    list_0 = LazyList(range(1, 10))
    iterator_0 = list_0.__iter__()
    for i in range(1, 10):
        iterator_0.__next__()


# Generated at 2022-06-25 16:50:38.742370
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    mylist_MapList = [1, 2, 3, 4]
    func_MapList = lambda x: x * x
    map_list_MapList = MapList(func_MapList, mylist_MapList)
    assert map_list_MapList[0] == 1
    assert map_list_MapList[1] == 4
    assert map_list_MapList[2] == 9
    assert map_list_MapList[3] == 16


# Generated at 2022-06-25 16:50:44.929904
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_1 = Range()
    print(len(range_1))


# Generated at 2022-06-25 16:50:46.741219
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    if not Range(100)[100] == 99:
        raise Exception("Test failed")



# Generated at 2022-06-25 16:50:49.535432
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:50:51.713571
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    #raise Exception(
    #    "Test not implemented: test_LazyList___len__"
    #)
    pass


# Generated at 2022-06-25 16:50:58.441773
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(0, 10)
    assert range_0[0] == 0
    assert range_0[1] == 1
    assert range_0[2] == 2
    assert range_0[3] == 3
    assert range_0[4] == 4
    assert range_0[5] == 5
    assert range_0[6] == 6
    assert range_0[7] == 7
    assert range_0[8] == 8
    assert range_0[9] == 9


# Generated at 2022-06-25 16:51:04.132439
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    i = LazyList()
    print('Iterating over an empty LazyList returned ', list(i))  # an empty list
    i = LazyList([1, 2, 3])
    print('Iterating over a LazyList returned ', list(i))  # should be [1, 2, 3]


# Generated at 2022-06-25 16:51:14.191242
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    try:
        range_0 = Range()
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-25 16:51:24.262036
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    from random import Random

    def __getitem__(self, item):
        def __getitem__(self, item):
            v = self.__getitem__(item)
            return v

    def __getitem__(self, item):
        def get(idx):
            def __getitem__(self, item):
                v = self.__getitem__(item)
                return v

            if idx >= self.length:
                raise IndexError('index out of range')
            item = self._get_idx(idx)
            return item

        if isinstance(item, slice):
            item.stop
            if item.stop > self.length:
                raise IndexError('index out of range')
            item.step
            ret = []

# Generated at 2022-06-25 16:51:28.496806
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    first = 1
    second = 2
    third = 3
    forth = 4
    iterable_0 = list((first, second, third, forth))
    lazy_list_0 = LazyList(iterable_0)
    # Call LazyList.__getitem__(lazy_list_0, 0)
    assert lazy_list_0[0] == first


# Generated at 2022-06-25 16:51:34.245004
# Unit test for function drop_until
def test_drop_until():
    itr = drop_until(lambda x: x > 5, range(10))
    assert next(itr) == 6
    assert next(itr) == 7
    assert next(itr) == 8
    assert next(itr) == 9
    raise StopIteration


# Generated at 2022-06-25 16:51:38.012491
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range(0, 20)
    list_0 = LazyList(range_0)
    iterator_0 = list_0.__iter__()
    for int_0 in range(0, 20):
        str_0 = iterator_0.__next__()
        assert str_0 == int_0
        str_0 = list_0[int_0]
        assert str_0 == int_0


# Generated at 2022-06-25 16:51:45.200341
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(x**2 for x in range(2))
    like_list = [0, 1, 4]

    # Test with int argument
    assert ll[0] == like_list[0]
    assert ll[1] == like_list[1]
    assert ll[2] == like_list[2]

    # Test with slice argument
    assert list(ll[:]) == like_list



# Generated at 2022-06-25 16:51:52.220680
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    iterator_0 = range_0.__iter__()
    range_1 = Range()
    iterator_1 = range_1.__iter__()
    int_0 = iterator_0.__next__()
    int_1 = iterator_1.__next__()
    int_2 = iterator_1.__next__()
    assert ((int_2 == 2) and (int_1 == 1) and (int_0 == 0))


# Generated at 2022-06-25 16:51:59.065429
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range(100)
    range_1 = LazyList(range_0)
    range_1 = range_1.take(10)
    range_2 = LazyList(range_0)
    range_2 = range_2.take(20)
    range_3 = LazyList(range_0)
    range_3 = range_3.take(30)


# Generated at 2022-06-25 16:52:02.491379
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    map_list_0 = MapList(None, None)
    with pytest.raises(IndexError):
        map_list_0.__getitem__(None)



# Generated at 2022-06-25 16:52:03.414663
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    pass


# Generated at 2022-06-25 16:52:24.284086
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range().__getitem__(None) == None
    assert Range().__getitem__(None) == None
    assert Range_0.__getitem__(None) == None
    assert Range_1.__getitem__(None) == None
    assert range_0.__getitem__(None) == None
    assert Range_4.__getitem__(None) == None
    assert Range_5.__getitem__(None) == None


# Generated at 2022-06-25 16:52:26.641208
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    result = Range()
    assert result == None, "Returned value is not equal to the expected value"


# Generated at 2022-06-25 16:52:30.153266
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0: Range
    range_0 = Range()
    # Make sure it can be iterated
    for value in range_0:
        pass


# Generated at 2022-06-25 16:52:31.316466
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    pass


# Generated at 2022-06-25 16:52:39.202044
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    llist_0 = LazyList(range(100))
    llist_1 = LazyList(range(100))
    llist_2 = LazyList(range(100))
    llist_3 = LazyList(range(100))
    llist_4 = LazyList(range(100))
    for i in llist_0:
        for j in llist_1:
            pass
        for j in llist_2:
            pass
        for j in llist_3:
            break
        for j in llist_4:
            pass

# Generated at 2022-06-25 16:52:43.318895
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range() 
    assert range_0[0] == 0, "method __getitem__ of class Range failed, line 93"
    assert range_0[1] == 1, "method __getitem__ of class Range failed, line 94"


# Generated at 2022-06-25 16:52:53.787238
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert LazyList([0, 1, 2])[0] == 0
    assert LazyList([0, 1, 2])[1] == 1
    assert LazyList([0, 1, 2])[2] == 2

    assert LazyList(['a', 'b', 'c'])[0] == 'a'
    assert LazyList(['a', 'b', 'c'])[-1] == 'c'
    assert LazyList(['a', 'b', 'c'])[1] == 'b'
    assert LazyList(['a', 'b', 'c'])[-2] == 'b'
    assert LazyList(['a', 'b', 'c'])[2] == 'c'

# Generated at 2022-06-25 16:52:54.412687
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()


# Generated at 2022-06-25 16:53:00.082205
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    iterator  = LazyList([1, 2, 3, 4, 5, 6]).__iter__()
    (iterator != None)
    (iterator.__next__() == 1)
    (iterator.__next__() == 2)
    (iterator.__next__() == 3)
    (iterator.__next__() == 4)
    (iterator.__next__() == 5)
    (iterator.__next__() == 6)
    (iterator.__next__() == None)


# Generated at 2022-06-25 16:53:09.829417
# Unit test for function drop_until
def test_drop_until():
    from typing import Iterable
    from typing import List
    from typing import Callable
    from typing import Any

    # The parameters for the function.
    pred_fn: Callable[[Any], bool]
    iterable: Iterable[Any]
    # The return type of the function.
    ret: Iterable[Any]

    # If the type of the parameter is wrong, the type checker should complain.
    # E.g., if you are passing an int instead of a function to the parameter.

    # The parameter and return type is the same
    def f(x: Any) -> Any:
        pass

    pred_fn = f
    c = drop_until(pred_fn, iterable)
    assert c is not None

    iterable = [1, 2, 3]
    pred_fn = lambda x: x == 1

# Generated at 2022-06-25 16:54:06.332315
# Unit test for function drop_until
def test_drop_until():
    # Case 0: negative drop number
    # Case 1: positive drop number

    # Case 2: negative predicate value
    # Case 3: positive predicate value

    # Case 4: not drop items
    assert list(drop_until(lambda x: x > 1, range(10))) == [2, 3, 4, 5, 6, 7, 8, 9]
    # Case 5: drop items

    pass



# Generated at 2022-06-25 16:54:12.343707
# Unit test for function scanl
def test_scanl():
    array_0 = range(1,5)
    array_1 = array_0
    array_2 = [0,1,3,6]
    assert array_1 == array_2
    array_3 = range(1,5)
    array_4 = array_3
    array_5 = ['a','ba','cba','dcba']
    assert array_4 == array_5



# Generated at 2022-06-25 16:54:15.121073
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range(0, 10)
    lazy_list_0 = LazyList(range_0)
    assert isinstance(lazy_list_0.__len__(), int)



# Generated at 2022-06-25 16:54:22.373297
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__(0)
    range_0.__getitem__

# Generated at 2022-06-25 16:54:27.457527
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    int_1 = range_0[0]
    int_2 = range_0[0]
    int_3 = range_0[0]
    int_4 = range_0[0]
    int_5 = range_0[0]
    int_6 = range_0[0]


# Generated at 2022-06-25 16:54:28.080566
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass

# Generated at 2022-06-25 16:54:31.057827
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([0, 1, 2, 3])) == 4


# Generated at 2022-06-25 16:54:34.803764
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_case_0()
    test_case_1()
