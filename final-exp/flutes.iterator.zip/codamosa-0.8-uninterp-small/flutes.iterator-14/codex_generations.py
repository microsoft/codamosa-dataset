

# Generated at 2022-06-25 16:45:09.317015
# Unit test for function split_by
def test_split_by():
    print('test_split_by')
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-25 16:45:13.692095
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    assert range_0[0] == 0
    assert range_0[1] == 1
    assert range_0[2] == 2
    assert range_0[-2] == 8


# Generated at 2022-06-25 16:45:21.035814
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert LazyList(range(10)).__len__() == 10
    try:
        LazyList(range(10)).__getitem__(0)
    except IndexError as e:
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-25 16:45:28.887371
# Unit test for function drop
def test_drop():
    from itertools import islice
    assert list(drop(-1, range(5))) == list(islice(range(5), -1, None))
    assert list(drop(0, range(5))) == list(islice(range(5), 0, None))
    assert list(drop(3, range(5))) == list(islice(range(5), 3, None))
    assert list(drop(5, range(5))) == list(islice(range(5), 5, None))
    assert list(drop(6, range(5))) == list(islice(range(5), 5, None))



# Generated at 2022-06-25 16:45:32.154035
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range('a', 'b')
    for arg_0 in range_0:
        for arg_1 in range_0:
            print(arg_0)
            print(arg_1)


# Generated at 2022-06-25 16:45:33.191426
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0[0] = 10



# Generated at 2022-06-25 16:45:34.173660
# Unit test for function take
def test_take():
    range_0 = Range()


# Generated at 2022-06-25 16:45:35.570435
# Unit test for method __next__ of class Range
def test_Range___next__():
    try:
        Range().__next__()
        assert False, "No exception thrown"
    except StopIteration:
        pass


# Generated at 2022-06-25 16:45:46.363936
# Unit test for method __getitem__ of class MapList

# Generated at 2022-06-25 16:45:51.686826
# Unit test for function drop
def test_drop():
    print("test_drop()")
    assert [x for x in drop(0, range(10))] == [x for x in range(10)]
    assert [x for x in drop(5, range(10))] == [x for x in range(5, 10)]
    assert [x for x in drop(20, range(10))] == []
    print("passed")



# Generated at 2022-06-25 16:46:09.004557
# Unit test for function drop_until
def test_drop_until():
    # Case 1: the predicate is always satisfied
    def pred(x): return x > 0
    drop_until_range = drop_until(pred, range(1000000))
    next_0 = next(drop_until_range)
    assert 0 == next_0

    # Case 2: the predicate is never satisfied
    drop_until_range = drop_until(pred, range(-1000000, 0))
    try:
        next(drop_until_range)
        assert False
    except StopIteration:
        pass



# Generated at 2022-06-25 16:46:14.618660
# Unit test for function take
def test_take():
    lst = Range(10)
    target = [0,1,2,3,4,5,6,7,8,9]
    for idx, item in enumerate(take(10, lst)):
        assert(item == target[idx])


# Generated at 2022-06-25 16:46:22.328761
# Unit test for function scanl
def test_scanl():
    print("testing function: scanl")
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4, 5])) == [1, 3, 6, 10, 15]
    assert list(scanl(operator.add, [])) == []


# Generated at 2022-06-25 16:46:31.475192
# Unit test for function drop_until
def test_drop_until():
    list_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    pred_fn = lambda item: item > 5
    iterable = list_0
    # drop_until(pred_fn, iterable)
    iter_0 = drop_until(pred_fn, iterable)
    for item in iter_0:
        print(item)



# Generated at 2022-06-25 16:46:42.647189
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x:x>5,range(10))) == [6,7,8,9]
    assert list(drop_until(lambda x:x>5,range(10))) == [6,7,8,9]
    assert list(drop_until(lambda x:x>0,range(10))) == [1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x:x>10,range(10))) == []
    assert list(drop_until(lambda x:x>0,range(1))) == []
    assert list(drop_until(lambda x:x>-1,range(1))) == [0]
    assert list(drop_until(lambda x:x>-1,range(0))) == []



# Generated at 2022-06-25 16:46:51.907268
# Unit test for function take
def test_take():
    test_input_1 = [[[0, 1, 2, 3, 4], 0], [[0, 1, 2, 3, 4], 2], [[0, 1, 2, 3, 4, 5], -1], [[0, 1, 2, 3, 4, 5], 1], [[0, 1, 2, 3, 4, 5], 5]]
    test_output_1 = [[], [0, 1], [], [0], [0, 1, 2, 3, 4]]
    def test_take_0(input_1, output_1):
        assert list(take(input_1[1], input_1[0])) == output_1
    for i, o in zip(test_input_1, test_output_1):
        test_take_0(i, o)


# Generated at 2022-06-25 16:46:54.607920
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 11, 2)   # (start, end, step)
    print(r[0], r[2], r[4])


# Generated at 2022-06-25 16:46:59.188512
# Unit test for function take
def test_take():
    assert len(list(take(5, range(1000000)))) == 5
    assert len(list(take(5, range(-1000000)))) == 0
    assert len(list(take(-5, range(1000000)))) == 0
    assert len(list(take(5, range(-1000000)))) == 0


# Generated at 2022-06-25 16:47:01.856183
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    


# Generated at 2022-06-25 16:47:09.259761
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range(0, 10, 10)
    llist_0 = LazyList(range_0)
    llist_1 = llist_0._LazyList__iter__()
    assert llist_1 is not None


# Generated at 2022-06-25 16:47:22.743632
# Unit test for function scanl
def test_scanl():
    for separator in range(0, 8):
        assert scanl(operator.add, [0, 1, 2, 3, 4]) == [0, 1, 3, 6, 10]
        assert scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['a', 'ba', 'cba', 'dcba']
        assert scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z') == ['z', 'za', 'zab', 'zabc', 'zabcd']


# Generated at 2022-06-25 16:47:27.420376
# Unit test for function drop_until
def test_drop_until():
    print("---Testing for drop_until---")
    expected = [3,4,5]
    actual = list(drop_until(lambda x: x > 2, range(10)))
    assert actual == expected
    print("---Test case 0: pass---")


# Generated at 2022-06-25 16:47:36.410534
# Unit test for function drop_until
def test_drop_until():
    from itertools import count
    import numpy as np
    from typing import Union

    def safe_divide(a, b):
        if a is None:
            return None
        if b == 0:
            return None
        return a/b

    def safe_mean(xs):
        if sum(1 if x is None else 0 for x in xs) > 0:
            return None
        return sum(xs) / len(xs)

    Range = TypeVar('Range', bound=Union[int, float])
    def window(xs: Sequence[Range], w: int) -> Iterator[List[Range]]:
        if w < 1:
            raise ValueError("Window size should be at least 1")
        if len(xs) <= w:
            yield list(xs)

# Generated at 2022-06-25 16:47:47.326752
# Unit test for function drop_until
def test_drop_until():
    l = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for n in range(10):
        for a in range(n):
            it = drop_until(lambda x: x > n, l[:-a])
            b = next(it, None)
            assert b == n
            assert list(it) == l[n - a:]
        it = drop_until(lambda x: x > n, l[:-n])
        b = next(it, None)
        assert b == n
        assert list(it) == []


# Generated at 2022-06-25 16:47:52.869422
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    list_0 = LazyList(range_0)
    list_0._fetch_until(((len(range_0)) - (1)))
    assert list_0[((len(range_0)) - (1))] == ((len(range_0)) - (1))


# Generated at 2022-06-25 16:48:00.123004
# Unit test for function scanl
def test_scanl():
    list_0 = range(10)

    list_1 = []

    for item in scanl(lambda acc, x: x + acc, list_0):
        list_1.append(item)
    print(list_1)

    list_2 = []

    for item in scanl(operator.add, list_0, 0):
        list_2.append(item)
    print(list_2)

    print(list_1 == list_2)

test_case_0()
test_scanl()



# Generated at 2022-06-25 16:48:02.721410
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert list(MapList(lambda x: x * x, [1, 2, 3, 4, 5])) == [1, 4, 9, 16, 25]


# Generated at 2022-06-25 16:48:07.835612
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Test 0
    range_0 = Range()
    # Test 1
    range_1 = Range()
    # Test 2
    range_2 = Range()
    # Test 3
    range_3 = Range()
    # Test 4
    range_4 = Range()
    # Test 5
    range_5 = Range()


# Generated at 2022-06-25 16:48:09.866883
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(4)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3


# Generated at 2022-06-25 16:48:18.584741
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    print("\nTesting method __getitem__")
    list_0_0_0 = LazyList(map(lambda __x: lambda __y: lambda: 3 + 4 * __y, scanl(lambda __x, __y: __y + 1, range(0), 0)))
    list_0_0_1 = LazyList(map(lambda __x: lambda __y: lambda: 3 + 4 * __y, scanl(lambda __x, __y: __y + 1, range(0), 0)))
    range_0 = list_0_0_0[3 : 0]
    list_0_1 = list_0_0_1[-1]
    range_1 = list_0_0_0[0 : 0]


# Generated at 2022-06-25 16:48:27.723526
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # A test case
    list_instance_0 = LazyList(range_0)
    # A call to __len__ method of list_instance_0
    __call__tmp_0 = len(list_instance_0)
    # A call to __len__ method of list_instance_0
    __call__tmp_1 = len(list_instance_0)
    assert __call__tmp_0 == __call__tmp_1


# Generated at 2022-06-25 16:48:32.713459
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 9, 1)
    assert range_0[0] == 1
    assert range_0[1] == 2
    assert range_0[8] == 9
    assert range_0[-1] == 9


# Generated at 2022-06-25 16:48:39.820454
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    """Test that LazyList.__iter__ returns an iterator over all items in the list.

    :return: None
    """
    # Create list containing even numbers
    lazy_list_0 = LazyList(map(lambda x: 2 * x, range(10)))
    # Loop over list and check that each of the returned items are even
    for item in lazy_list_0:
        assert item % 2 == 0


# Generated at 2022-06-25 16:48:41.683377
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    assert range_0[0] == 0


# Generated at 2022-06-25 16:48:44.878180
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst[:5]) == [0, 1, 2, 3, 4]
    assert list(lst) == list(range(10))


# Generated at 2022-06-25 16:48:52.225171
# Unit test for function drop_until
def test_drop_until():
    l = range(10)
    l2 = list(l)
    # Check that it works with a predicate that is true for a prefix of the iterable
    list(drop_until(lambda x: x > 5, l))
    assert list(drop_until(lambda x: x > 5, l2)) == l2[6:]
    # Check that it works with a predicate that is true for one element of the iterable
    list(drop_until(lambda x: x == 7, l))
    assert list(drop_until(lambda x: x == 7, l2)) == l2[7:]
    # Check that it works with a predicate that is true for no element of the iterable
    list(drop_until(lambda x: x == 100, l))
    assert list(drop_until(lambda x: x == 100, l2)) == []


# Generated at 2022-06-25 16:48:54.003376
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_case_0()

# Generated at 2022-06-25 16:48:57.684046
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_2 = Range()
    range_2 = Range()
    range_1 = Range()
    range_1 = Range()
    range_0 = Range()
    range_2 = Range()
    range_1 = Range()



# Generated at 2022-06-25 16:49:07.396549
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    (int_1, Range_2, int_3, int_4, int_5, Range_6) = (0, Range(0, 10, 1), 0, 10, 1, Range(0, 10, 1))
    (int_7, int_8, int_9, int_10, int_11) = (0, 0, 10, 1, 0)
    try:
        (Range_6.step, int_10, int_11) = (10000, 10, 9)
        (int_1, int_3, int_4, int_9) = (Range_2[int_11], 0, 10, 100)
        if (int_1 == Range_6[int_10]):
            (int_1, int_8) = (0, 0)
    except:
        pass

# Generated at 2022-06-25 16:49:12.747924
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        assert (LazyList([]).__len__() == 0)
        assert (LazyList([1, 2, 3]).__len__() == 3)
    except TypeError:
        assert True


# Generated at 2022-06-25 16:49:19.663163
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    """
    Returns the ith element of the range.
    """
    range_0 = Range()
    s = range_0[0]


# Generated at 2022-06-25 16:49:29.229022
# Unit test for function drop_until
def test_drop_until():
    for item in drop_until(lambda x: x > 5, range(10)):
        print(item)
    print("----next test----")
    for item in drop_until(lambda x: x > 5, Range(10)):
        print(item)
    print("----next test----")
    for item in drop_until(lambda x: x > 5, Range(10, 100)):
        print(item)
    print("----next test----")
    for item in drop_until(lambda x: x > 5, Range(10, 100, 10)):
        print(item)
    print("----next test----")
    for item in drop_until(lambda x: x > 500, (x*x for x in range(10))):
        print(item)
    print("----next test----")

# Generated at 2022-06-25 16:49:32.218533
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(3)
    value_0 = range_0[0]
    expected_0 = 0
    assert value_0 == expected_0


# Generated at 2022-06-25 16:49:33.168953
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert 1 == 1


# Generated at 2022-06-25 16:49:42.382634
# Unit test for function drop_until
def test_drop_until():
    print("----- Test drop_until")
    drop_until_range = Range(start=2, end=10)
    range_s = drop_until(lambda x: x > 5, drop_until_range)
    print("The drop_until range is [%s]" % ([i for i in range_s]))

    drop_until_range = Range(start=2, end=10)
    range_s = drop_until(lambda x: x > 50, drop_until_range)
    print("The drop_until range is [%s]" % ([i for i in range_s]))




# Generated at 2022-06-25 16:49:45.672679
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    range_ = drop_until(lambda x: x > 5, range_0)
    next(range_) # 6
    next(range_) # 7
    next(range_) # 8
    next(range_) # 9
    # End of a test


# Generated at 2022-06-25 16:49:50.183110
# Unit test for function drop_until
def test_drop_until():
    f = lambda x: x > 5
    iterable = range(10)
    if list(drop_until(f, iterable)) != [6, 7, 8, 9]:
        raise AssertionError("drop_until test failed")



# Generated at 2022-06-25 16:49:59.674098
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func_0 = lambda x: x
    lst_0 = [1, 2, 3, 4, 5]
    mapList_0 = MapList(func_0, lst_0)
    r_0 = mapList_0[2]
    if(not callable(func_0)):
        func_0 = (lambda o, x: o.__getitem__(x))
        lst_0 = (lambda o, x: o.__getitem__(x))
    if(((not (lst_0 == [])) and (not (lst_0 == [1, 2, 3]))) or (not callable(lst_0))):
        lst_0 = (lambda o, x: o.__getitem__(x))

# Generated at 2022-06-25 16:50:05.583682
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for _ in range(2):
        for _ in range(1):
            for _ in range(2):
                for _ in range(2):
                    for _ in range(1):
                        range_0 = test_case_0()
                        try:
                            print(range_0)
                        except Exception as exc:
                            print(exc)
                        try:
                            print(range_0)
                        except Exception as exc:
                            print(exc)

if __name__ == '__main__':
    test_Range___getitem__()

# Generated at 2022-06-25 16:50:11.419334
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range(10)
    value = 10
    result = range_1.__getitem__(0)
    print(result)
    # result = 10
    assert(result == value)
    range_1 = Range(1, 11, 2)
    value = 9
    result = range_1.__getitem__(4)
    print(result)
    # result = 9
    assert(result == value)


# Generated at 2022-06-25 16:50:19.126258
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(10)
    mapList_0 = MapList(list.__getitem__, range_0)
    assert mapList_0[9] == 9


# Generated at 2022-06-25 16:50:29.076585
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    assert Range().__getitem__(0) == 0
    assert Range().__getitem__(1) == 1
    assert Range().__getitem__(2) == 2
    assert Range().__getitem__(3) == 3
    assert Range().__getitem__(4) == 4
    assert Range().__getitem__(5) == 5
    assert Range().__getitem__(6) == 6
    assert Range().__getitem__(7) == 7
    assert Range().__getitem__(8) == 8
    assert Range().__getitem__(9) == 9
    assert Range().__getitem__(-1) == 9
    assert Range().__getitem__(-2) == 8
    assert Range().__getitem__(-3) == 7

# Generated at 2022-06-25 16:50:30.345429
# Unit test for function drop_until
def test_drop_until():
    a = range(1, 100)
    b = drop_until(lambda x: x > 2, a)
    print(next(b))


# Generated at 2022-06-25 16:50:40.402385
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 0, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 100, range(10))) == []
    try:
        list(drop_until([], range(10)))
        assert False
    except TypeError:
        pass
    try:
        list(drop_until(lambda x: x > 10, range(10)))
        assert False
    except StopIteration:
        pass
    assert list(drop_until(lambda x: x > 0, [])) == []

# Generated at 2022-06-25 16:50:45.247220
# Unit test for function drop_until
def test_drop_until():
    # Initialize test variables
    test_list = list(range(10))
    test_value = 5
    # Call and test drop_until
    result = drop_until(lambda x: x > test_value, test_list)
    assert result == list(range(test_value+1, len(test_list)))



# Generated at 2022-06-25 16:50:49.295343
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass


# Generated at 2022-06-25 16:50:52.571916
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]

test_case_0()
test_drop_until()


# Generated at 2022-06-25 16:50:55.394785
# Unit test for function drop_until
def test_drop_until():
    #return
    if (drop_until(lambda x: x > 5, range(10)))!=[6,7,8,9]:
        raise Exception("wrong answer")


# Generated at 2022-06-25 16:51:06.095915
# Unit test for function drop_until
def test_drop_until():
    # list(drop_until(lambda x: x > 5, range(10)))
    first = False
    second = False
    third = False
    iterable = range(10)
    for x in iterable:
        if not first and x > 5:
            first = True
            # test that execution continues to the next iteration
            assert third == False
            assert second == False
        if not second and x > 7:
            second = True
            # test that execution continues to the next iteration
            assert third == False
        if not third and x > 9:
            assert False # Should not enter here
        else:
            third = True
    assert first == True
    assert second == True
    assert third == False



# Generated at 2022-06-25 16:51:08.832015
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0[0]
    range_0[0:1]
    range_0[0:1:1]


# Generated at 2022-06-25 16:51:25.587770
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range(10)
    assert range_1[0] == 0
    assert range_1[1] == 1
    assert range_1[2] == 2
    assert range_1[3] == 3
    assert range_1[4] == 4
    assert range_1[5] == 5
    assert range_1[6] == 6
    assert range_1[7] == 7
    assert range_1[8] == 8
    assert range_1[9] == 9
    range_2 = Range(1, 11)
    assert range_2[0] == 1
    assert range_2[1] == 2
    assert range_2[2] == 3
    assert range_2[3] == 4
    assert range_2[4] == 5
    assert range_2[5] == 6
   

# Generated at 2022-06-25 16:51:33.008321
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    range_1 = Range(1,10+1)
    range_2 = Range(1, 11, 2)
    assert range_0[0] == 0
    assert range_0[5] == 5
    assert range_1[0] == 1
    assert range_1[4] == 5
    assert range_2[0] == 1
    assert range_2[2] == 5
    assert range_2[4] == 9
    assert range_0[:0] == []
    assert range_0[:5] == [0, 1, 2, 3, 4]
    assert range_0[5:] == [5, 6, 7, 8, 9]
    assert range_0[1:5] == [1, 2, 3, 4]


# Generated at 2022-06-25 16:51:44.533258
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range(0, 10)
    assert range_1.__getitem__(0) == 0
    assert range_1.__getitem__(1) == 1
    assert range_1.__getitem__(2) == 2
    assert range_1.__getitem__(3) == 3
    assert range_1.__getitem__(4) == 4
    assert range_1.__getitem__(5) == 5
    assert range_1.__getitem__(6) == 6
    assert range_1.__getitem__(7) == 7
    assert range_1.__getitem__(8) == 8
    assert range_1.__getitem__(9) == 9

test_Range___getitem__()


# Generated at 2022-06-25 16:51:51.517699
# Unit test for function drop_until
def test_drop_until():
    assert drop_until(lambda x: x > 5, range(10)) == [6, 7, 8, 9]
    assert drop_until(lambda x: x > 5, range(10)) == [6, 7, 8, 9]
    assert drop_until(lambda x: x > 5, range(10)) == [6, 7, 8, 9]
    assert drop_until(lambda x: x > 5, range(10)) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:52:03.762150
# Unit test for function drop_until
def test_drop_until():
    # sample test case 1
    range_1 = list(range(10))
    result_1 = list(drop_until(lambda x: x > 5, range_1))
    assert result_1 == [6, 7, 8, 9]

    range_2 = [7, 8, 9, 10, 11]
    result_2 = list(drop_until(lambda x: x > 1, range_2))
    assert result_2 == [7, 8, 9, 10, 11]

    range_3 = [0]
    result_3 = list(drop_until(lambda x: x % 2 == 0, range_3))
    assert result_3 == [0]
    # your tests
    range_4 = list(range(10))
    result_4 = list(drop_until(lambda x: x < 5, range_4))

# Generated at 2022-06-25 16:52:07.301827
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(0, 3)
    print(range_0)
    print(range_0[0])
    print(range_0[0:3])
    for i in range(3):
        print(range_0[i])


# Generated at 2022-06-25 16:52:12.593715
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=lambda x: x % 3 == 0)) == []
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [
        [1, 2],
        [4, 5],
        [7, 8],
    ]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [
        [],
        [1, 2],
        [4, 5],
        [7, 8],
        [],
    ]


# Generated at 2022-06-25 16:52:20.981416
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    try:
        range_0 = Range()
    except Exception as e:
        print("Failed to execute method: \n{}".format(traceback.format_exc()))
    else:
        try:
            range_0.__getitem__()
        except Exception as e:
            print("Failed to execute method: \n{}".format(traceback.format_exc()))
        else:
            print("PASS")


# Generated at 2022-06-25 16:52:31.621759
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(5, 2)
    range_0._get_idx(1)
    range_0.__getitem__(2)
    range_0.__getitem__(Range.__getitem__.__annotations__)
    range_0.__getitem__(1)
    range_0.__getitem__(3)
    range_0.__getitem__(0)
    range_0.__getitem__(1)


# Generated at 2022-06-25 16:52:39.156567
# Unit test for function drop_until
def test_drop_until():
    assert drop_until(lambda x : x > 3, range(5)) == [4]
    assert drop_until(lambda x : x > 5, range(5)) == []
    assert drop_until(lambda x : x == 4, range(5)) == [4]
    assert drop_until(lambda x : x < 0, range(5)) == list(range(5))
    assert drop_until(lambda x : x > 10, range(5)) == []
    assert drop_until(lambda x : x == 5, range(5)) == []


# Generated at 2022-06-25 16:52:52.690478
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))


# Generated at 2022-06-25 16:52:55.138843
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_cases = [
        {
            "name": "__getitem__()_case_0",
            "range": Range(),
            "idx": 0,
            "return_value": 0
        },
    ]
    for test_case in test_cases:
        assert test_case["range"][test_case["idx"]] == test_case["return_value"]
    pass


# Generated at 2022-06-25 16:53:01.183033
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 1, range(10))) == [2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 0, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x % 2 == 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-25 16:53:06.100035
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range()
    try:
        rf = r.__getitem__
    except:
        rf = r.__getitem__
    try:
        rl = [i for i in range_0]
        assert [rf(i) for i in range_0] == rl
    except AssertionError as e:
        raise AssertionError(str(e))


# Generated at 2022-06-25 16:53:09.330005
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(1, 2)
    map_list_0 = MapList(lambda x: x, range_0)
    print(map_list_0.__getitem__(0))


# Generated at 2022-06-25 16:53:18.386471
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    idx = 0
    range_0 = Range()
    value_0 = range_0._get_idx(idx)
    idx = 0
    range_1 = Range(0)
    value_1 = range_1._get_idx(idx)
    idx = 0
    range_2 = Range(0, 0)
    value_2 = range_2._get_idx(idx)
    idx = 0
    range_3 = Range(0, 0, 0)
    value_3 = range_3._get_idx(idx)
    idx = 1
    range_4 = Range(1)
    value_4 = range_4._get_idx(idx)
    idx = 1
    range_5 = Range(1, 1)
    value_5 = range_

# Generated at 2022-06-25 16:53:24.000872
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    result = range_0[(int(uniform(0, 50)))]
    assert(result >= 0 and result <= 50)


# Generated at 2022-06-25 16:53:27.478108
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range(0, 3)
    it = drop_until(lambda x: x == 2, range_0)
    assert next(it) == 2
    assert list(it) == []


# Generated at 2022-06-25 16:53:31.270720
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(1, 10)
    mapList_0 = MapList(range_0)


# Generated at 2022-06-25 16:53:33.751416
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0.__getitem__(0)

# Generated at 2022-06-25 16:54:33.561682
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def __getitem__(self, item):
        if isinstance(item, int):
            return self.func(self.list[item])
        return [self.func(x) for x in self.list[item]]

    func_0 = lambda x: x * x

    lst_0 = [1, 2, 3, 4, 5, 6]
    obj_0 = MapList(func_0, lst_0)

    ret_0 = __getitem__(obj_0, 7)
    assert ret_0 == 49



# Generated at 2022-06-25 16:54:37.160571
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func_0 = lambda x : x * x
    list_0 = [2, 3, 4, 5, 6]
    obj_0 = MapList(func_0, list_0)
    assert 2 == obj_0[0]
    assert 5 == obj_0[1]
    assert 10 == obj_0[2]
    assert 13 == obj_0[3]


# Generated at 2022-06-25 16:54:39.350296
# Unit test for function drop_until
def test_drop_until():
    input_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    print(list(drop_until(lambda x: x > 5, input_list)))
    
