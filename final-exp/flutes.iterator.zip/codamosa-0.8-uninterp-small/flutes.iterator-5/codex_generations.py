

# Generated at 2022-06-25 16:45:06.145029
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range(3)
    range_1 = LazyList(range_0)
    len_0 = len(range_1)
    assert len_0 == 3


# Generated at 2022-06-25 16:45:07.163903
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range(10)
    for _ in range(10):
        next(range_0)


# Generated at 2022-06-25 16:45:12.278422
# Unit test for function chunk
def test_chunk():
  # print('test_chunk')
  lst = list(chunk(3, range(10)))
  lst_expected = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
  # print(lst)
  assert lst == lst_expected

test_chunk()

# test_case_0()

# Generated at 2022-06-25 16:45:22.524990
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():

    # Test: default
    # Configuration:
    range_0 = MapList()
    # Expected outcome:
    assert range_0 == [], "Wrong output"

    # Test: empty list
    # Configuration:
    def func(x):
        return x
    range_0 = MapList(func, [])
    # Expected outcome:
    assert range_0 == [], "Wrong output"

    # Test: empty list
    # Configuration:
    func = lambda x: x
    range_0 = MapList(func, [])
    # Expected outcome:
    assert range_0 == [], "Wrong output"

    # Test: empty list
    # Configuration:
    range_0 = MapList(lambda x: x, [])
    # Expected outcome:

# Generated at 2022-06-25 16:45:24.913595
# Unit test for function take
def test_take():
    try:
        x = take(5, range(1000000))
    except:
        print("An exception occurred")



# Generated at 2022-06-25 16:45:30.304892
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lazy_list_0 = LazyList(range(24))
    # Access the first 10 element of the lazy list
    for i in range(10):
        assert lazy_list_0[i] == i
    assert lazy_list_0[23] == 23
    # Access the first 10 element of the lazy list
    for i in range(10):
        assert lazy_list_0[-(i+1)] == 23-i


# Generated at 2022-06-25 16:45:35.035156
# Unit test for function drop_until
def test_drop_until():
    range_10 = Range(10)
    res = drop_until(lambda x: x > 10, range_10)
    assert len(list(res)) == 0
    range_10 = Range(10)
    res = drop_until(lambda x: x > 5, range_10)
    assert len(list(res)) == 4


# Generated at 2022-06-25 16:45:39.494883
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(3))
    assert len(lst[0:2]) == 2
    assert lst[2] == 2
    assert len(lst) == 3


# Generated at 2022-06-25 16:45:42.087536
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([0, 1, 2, 3])
    assert len(lst) == 4


# Generated at 2022-06-25 16:45:44.393251
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lazy_list_0 = LazyList(range(10))
    if (lazy_list_0.__len__() != 10):
        raise RuntimeError


# Generated at 2022-06-25 16:45:56.382779
# Unit test for function drop_until
def test_drop_until():
    # Test case 0
    range_0 = Range()
    # r, range_0 = drop_until(lambda x: x)
    # print(r)
    # r == [6, 7, 8, 9]
    return drop_until(lambda x: x, range(10))


# Generated at 2022-06-25 16:45:57.286795
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()



# Generated at 2022-06-25 16:45:59.576117
# Unit test for function drop
def test_drop():
    resor = drop(5, range(1000000))
    content = resor.__next__()
    assert content == 5
    resor.close()


# Generated at 2022-06-25 16:46:01.512454
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0[0]
    range_0[0:1]
    range_0[0:1:1]


# Generated at 2022-06-25 16:46:04.187252
# Unit test for function take
def test_take():
    print(list(take(5, range(1000000))))


# Generated at 2022-06-25 16:46:07.238355
# Unit test for function take
def test_take():
    range_0 = Range(0, 10)
    print("The first 5 element for the range [0,10) is: ", list(take(5, range_0)))


# Generated at 2022-06-25 16:46:16.108460
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    callable_1 = lambda x : x * 8
    map_list_0 = MapList(callable_1, range_0)
    map_list_0.__getitem__((slice(0, None, 1)))
    map_list_0.__getitem__(3.3)
    map_list_0.__getitem__(-3)


# Generated at 2022-06-25 16:46:20.241735
# Unit test for function drop_until
def test_drop_until():
    list_A = drop_until(lambda x: x > 5, range(10))
    list_A0 = []
    for data in list_A:
        list_A0.append(data)
    assert list_A0 == [6,7,8,9]


# Generated at 2022-06-25 16:46:24.515617
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Test case 0
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_0 = LazyList(list_1)
    list_2 = list_0
    assert list_2.exhausted == False
    try:
        len(list_3)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 16:46:34.654868
# Unit test for function drop_until
def test_drop_until():
    # look for first value that is True
    elements = [False, False, True, False, True, True, True]
    result = drop_until(lambda x: x, elements)
    assert(list(result) == [True, False, True, True, True])

    # look for first string that starts with 'p'
    elements = ["un", "deux", "trois", "quatre", "ctinq", "py", "sxix"]
    result = drop_until(lambda x: x[0] == 'p', elements)
    assert(list(result) == ["py", "sxix"])


# Generated at 2022-06-25 16:46:57.835539
# Unit test for function split_by
def test_split_by():
    input_0 = Range()
    output_0 = list(split_by(input_0, criterion=lambda x : x % 3 == 0))
    assert output_0 == [[1,2],[4,5],[7,8]]

    input_1 = " Split by: "
    output_1 = list(split_by(input_1, empty_segments=True, separator=':'))
    assert output_1 == [[],['S', 'p', 'l', 'i', 't'],['b', 'y', ' '], []]




# Generated at 2022-06-25 16:47:07.570048
# Unit test for function split_by
def test_split_by():
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []

    list_1 = list(split_by(range(10), criterion=lambda x: x % 3 == 0))
    list_2 = list(split_by(" Split by: ", empty_segments=True, separator='.'))

    print("Result of list_1: {}".format(list_1))
    print("Result of list_2: {}".format(list_2))
    assert list_1 == [[1, 2], [4, 5], [7, 8]]
    assert list_2 == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-25 16:47:09.633561
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    with raises(TypeError):
        mapList = MapList(lambda x: x, [])
        mapList.__getitem__()


# Generated at 2022-06-25 16:47:16.065991
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by:", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y'],[]]



# Generated at 2022-06-25 16:47:27.871220
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import unittest
    import random
    from hypothesis import given, strategies as st

    class TestRange(unittest.TestCase):
        @given(random.randint(-100, 100))
        def test_range_with_only_one_argument(self, pos):
            i1 = Range(pos)[random.randint(0, pos - 1)]
            i2 = range(pos)[random.randint(0, pos - 1)]
            self.assertEqual(i1, i2)
        
        @given(random.randint(-100, 100), random.randint(-100, 100))
        def test_range_with_start_and_stop_arguments(self, start, end):
            expected = []
            for i in range(start, end):
                expected.append(i)

            actual = []
           

# Generated at 2022-06-25 16:47:31.236505
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(4)[0] == 0
    assert Range(1, 6)[0] == 1
    assert Range(0, 8, 3)[0] == 0
    assert Range(6)[-1] == 5


# Generated at 2022-06-25 16:47:34.075572
# Unit test for function split_by
def test_split_by():
    assert([[]], split_by(range(10), criterion=lambda x: x > 10, ))
    assert([], split_by(range(10), criterion=lambda x: x > 10, ))



# Generated at 2022-06-25 16:47:35.745535
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(4)[1] == 1
    assert Range(4)[2] == 2
    assert Range(4)[3] == 3


# Generated at 2022-06-25 16:47:43.736758
# Unit test for function split_by
def test_split_by():
    # case 1
    print(list(split_by(' Split by: ', empty_segments=True, separator='.')))
    # case 2
    print(list(split_by(range(10), criterion=lambda x: x % 3 == 0)))



# Generated at 2022-06-25 16:47:47.359590
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range(0, 4)
    assert range_1[0] == 0
    assert range_1[1] == 1
    assert range_1[2] == 2
    assert range_1[3] == 3
    assert range_1[4] == 4

# Generated at 2022-06-25 16:47:58.025704
# Unit test for function take
def test_take():
    take_0 = take(5, range(1000000))
    # print(take_0)
    assert(take_0 == [0, 1, 2, 3, 4]), "Test case failed."

# Additional functionality tests

# Generated at 2022-06-25 16:48:03.404634
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    inp_0 = [0, 1, 2, 3]
    inp_1 = 3
    out = 3
    res = MapList(lambda x: x, inp_0)[inp_1]
    assert (res == out)


# Generated at 2022-06-25 16:48:07.283135
# Unit test for function take
def test_take():
    # test code here
    take_0 = take(3, range(10))
    print(list(take_0))
    take_1 = take(10, range(3))
    print(list(take_1))



# Generated at 2022-06-25 16:48:11.661070
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    if(range_0[0] != 0):
        print('Index error when using Range')


# Generated at 2022-06-25 16:48:22.204943
# Unit test for function take
def test_take():
    new_list = list(take(10, Range()))
    assert new_list == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    new_list = list(take(0, Range()))
    assert new_list == []
    new_list = list(take(10, Range(3, 10)))
    assert new_list == [3, 4, 5, 6, 7, 8, 9]
    new_list = list(take(10, Range(2, 10, 3)))
    assert new_list == [2, 5, 8]
    new_list = list(take(10, LazyList(lambda: 1)))
    assert new_list == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

# Generated at 2022-06-25 16:48:30.339984
# Unit test for function split_by
def test_split_by():
    # Test case 1: two adjacent elements satisfy the criterion
    list_0 = [1, 2, 3, 4, 5, 6, 7, 8]
    list_1 = split_by(list_0, criterion = lambda x: x % 3 == 0)
    list_2 = [[1, 2], [4, 5], [7, 8]]
    assert (list_1 == list_2)
    # Test case 2: two non-adjacent elements satisfy the criterion
    list_0 = [1, 2, 3, 4, 5, 6, 7, 8]
    list_1 = split_by(list_0, criterion = lambda x: x % 2 == 0)
    list_2 = [[1, 3], [5, 7]]
    assert (list_1 == list_2)
    # Test case 3: separator
    string_0

# Generated at 2022-06-25 16:48:42.083334
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(0), criterion=lambda x: x % 3 == 0)) == []
    assert list(split_by(range(1), criterion=lambda x: x % 3 == 0)) == [[0]]
    assert list(split_by(range(6), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5]]
    assert list(split_by(range(3), criterion=lambda x: x % 3 == 0)) == [[0]]
    assert list(split_by(range(4), criterion=lambda x: x % 3 == 0)) == [[1], [2]]
    assert list(split_by(range(7), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5]]


# Generated at 2022-06-25 16:48:45.919919
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    instance = Range()
    # Testing slice
    result = instance.__getitem__(slice(None, None, None))
    assert isinstance(result, list)
    # Testing integer
    result = instance.__getitem__(-66)
    assert isinstance(result, int)


# Generated at 2022-06-25 16:48:52.861627
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(9)
    test_case_0()
    test_case_Range___getitem__0(range_0)
    test_case_Range___getitem__1(range_0)
    test_case_Range___getitem__2(range_0)
    test_case_Range___getitem__3(range_0)
    test_case_Range___getitem__4(range_0)
    test_case_Range___getitem__5(range_0)
    test_case_Range___getitem__6(range_0)
    test_case_Range___getitem__7(range_0)
    test_case_Range___getitem__8(range_0)
    test_case_Range___getitem__9(range_0)
    test_case_Range___getitem__10

# Generated at 2022-06-25 16:48:58.950706
# Unit test for function take
def test_take():
    t = (1,2,3,4,5)
    assert [1,2,3,4,5] == list(take(5,t))
    assert [1,2,3,4] == list(take(4,t))
    assert [1,2,3] == list(take(3,t))
    assert [1,2] == list(take(2,t))
    assert [1] == list(take(1,t))


# Generated at 2022-06-25 16:49:05.154277
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 2, 1)
    assert range_0[0] == 1
    assert range_0[1] == 2
    try:
        assert range_0[2] == 3
    except AssertionError:
        pass
    else:
        assert False
    try:
        assert range_0[-1] == 0
    except AssertionError:
        pass
    else:
        assert False


# Generated at 2022-06-25 16:49:06.491030
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(4)
    assert range_0[2] == 2


# Generated at 2022-06-25 16:49:12.992483
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range()
    range_1 = Range(1, 2)
    range_2 = Range(1, 2, 3)
    
    assert range_0[2] == 2
    try:
        range_0[2] = 3
    except Exception as e:
        print(e)
    assert range_0[:4] == [0, 1, 2, 3]
    try:
        range_0[::] = [3, 2, 4, 1, 0]
    except Exception as e:
        print(e)
    assert range_0[-4:-1] == [4, 5, 6]
    assert range_1[1] == 1
    try:
        range_1[1] = 3
    except Exception as e:
        print(e)

# Generated at 2022-06-25 16:49:22.315308
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(-2, -8, -2)
    assert range_0[1] == -4
    assert range_0[-1] == -6
    assert range_0[0] == -2
    assert range_0[2] == -6
    assert range_0[-2] == -4
    assert range_0[3] == -8
    assert range_0[-3] == -6
    assert range_0[1:0] == [-4]
    assert range_0[-1:0] == [-6]
    assert range_0[0:1] == [-2]
    assert range_0[2:0] == [-6]
    assert range_0[-2:0] == [-4]
    assert range_0[3:0] == [-8]
    assert range_

# Generated at 2022-06-25 16:49:29.657507
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(5)
    mapList_0 = MapList(lambda x: x * x * x, range_0)
    assert mapList_0[2] == 8
    assert mapList_0[1] == 1
    assert mapList_0[3] == 27
    assert mapList_0[0] == 0
    assert mapList_0[4] == 64

# Generated at 2022-06-25 16:49:41.368386
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    sr = Range(2, 10)
    try:
        assert(all([sr[i] == i for i in range(2, 10)]))
        assert(all([sr[i] == i for i in range(2, 10, 2)]))
        assert(all([sr[i] == i for i in range(2, 10, 3)]))
        assert(all([sr[i] == i for i in range(10, 2, -1)]))
        assert(all([sr[i] == i for i in range(10, 2, -2)]))
        assert(all([sr[i] == i for i in range(10, 2, -3)]))
    except:
        assert(False)


# Generated at 2022-06-25 16:49:44.793830
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range(10)
    assert range_1[0] == 0
    assert range_1[9] == 9
    assert range_1[-1] == 9
    assert range_1[-10] == 0


# Generated at 2022-06-25 16:49:56.505451
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    arg_0 = [0, 1, 2]
    arg_1 = [0, 1, 2]
    arg_2 = [0, 1, 2]
    arg_3 = [0, 1, 2]
    arg_4 = [0, 1, 2]
    arg_5 = [0, 1, 2]
    arg_6 = [0, 1, 2]
    arg_7 = [0, 1, 2]
    arg_8 = [0, 1, 2]
    arg_9 = [0, 1, 2]
    arg_10 = [0, 1, 2]
    arg_11 = [0, 1, 2]
    arg_12 = [0, 1, 2]
    arg_13 = [0, 1, 2]
    arg_14 = [0, 1, 2]
    arg_15

# Generated at 2022-06-25 16:50:02.928807
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
   range_0 = Range()
   range_1 = Range(None)
   range_2 = Range(None, None)
   range_3 = Range(None, None, None)
   range_4_0 = range_0[None]
   range_5_0 = range_1[None]
   range_6_0 = range_2[None]
   range_7_0 = range_3[None]
   del range_0
   del range_1
   del range_2
   del range_3


# Generated at 2022-06-25 16:50:12.816724
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    test_cases = [
        {
            "input": {
                "item": (),
            },
            "exception": TypeError,
            "intermediate": {
                "operator.add": None
            },
            "output": None,
        },
        {
            "input": {
                "item": (),
            },
            "exception": TypeError,
            "intermediate": {
                "operator.add": None
            },
            "output": None,
        },
        {
            "input": {
                "item": (),
            },
            "exception": TypeError,
            "intermediate": {
                "operator.add": None
            },
            "output": None,
        }
    ]
    for test_case in test_cases:
        func = test_case.get("intermediate").get

# Generated at 2022-06-25 16:50:18.784200
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    mapList_0 = MapList()
    mapList_0.__getitem__(range_0)
    mapList_0.__getitem__(slice_0)


# Generated at 2022-06-25 16:50:25.375742
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from itertools import permutations
    from typing import List, Tuple

    print('\n==== Testing MapList.__getitem__() ====')

    @overload
    def test_MapList___getitem___0(func: Callable[[int], int], a: List[int],
                                   item: int) -> Tuple[int, int]: ...

    @overload
    def test_MapList___getitem___1(func: Callable[[int], int], a: List[int],
                                   item: slice) -> Tuple[int, List[int]]: ...

    def test_MapList___getitem___0(func: Callable[[int], int], a: List[int],
                                   item: int) -> Tuple[int, int]:
        map_list_0 = Map

# Generated at 2022-06-25 16:50:36.953616
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    assert range_0.__getitem__(0) == 0
    range_1 = Range(5)
    assert range_1.__getitem__(0) == 0
    assert range_1.__getitem__(1) == 1
    assert range_1.__getitem__(2) == 2
    assert range_1.__getitem__(3) == 3
    assert range_1.__getitem__(4) == 4
    range_2 = Range(1, 5)
    assert range_2.__getitem__(0) == 1
    assert range_2.__getitem__(1) == 2
    assert range_2.__getitem__(2) == 3
    assert range_2.__getitem__(3) == 4

# Generated at 2022-06-25 16:50:46.806262
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range(9)
    range_2 = Range(0, 8)
    range_3 = Range(0, 9, 1)
    range_4 = Range(0, 8, 2)
    range_5 = Range(0, 9, 2)
    range_6 = Range(0, 8, -1)
    range_7 = Range(0, 8, -2)
    range_8 = Range(0, 9, -2)
    range_9 = Range(0, -1, -2)
    range_10 = Range(0, -1)
    range_11 = Range(7, 0, -1)
    range_12 = Range(7, 0, -2)
    range_13 = Range(9, 0, -2)

# Generated at 2022-06-25 16:50:48.192938
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_case_0()


# Generated at 2022-06-25 16:50:51.047984
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(0, 0)

    mapList_0 = MapList(lambda i: 0, range_0)

    int_0 = mapList_0[0]


# Generated at 2022-06-25 16:50:56.058244
# Unit test for function scanl
def test_scanl():
    import operator
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-25 16:51:08.066601
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # range_0 = Range()
    test_0 = Range(0)
    test_1 = Range(0, 1)
    test_2 = Range(0, 1, 1)
    test_3 = Range(0, 1, 2)
    test_4 = Range(0, 1, -1)
    test_5 = Range(0, 1, -2)
    test_6 = Range(0, -1)
    test_7 = Range(0, -1, -1)
    test_8 = Range(0, -1, 1)
    test_9 = Range(0, -1, 2)
    test_10 = Range(0, -1, -2)
    test_11 = Range(0, -1, -3)
    test_12 = Range(1)

# Generated at 2022-06-25 16:51:12.455415
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def func_0() -> Callable[[int], int]:
        def temp_0(x: int) -> int:
            return int(x)
        return temp_0
    map_list_0 = MapList(func_0(), list_0)


# Generated at 2022-06-25 16:51:14.607389
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    result = range_0[0]
    assert result == 0


# Generated at 2022-06-25 16:51:18.342847
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    pass


# Generated at 2022-06-25 16:51:21.784262
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    my_mapList_0 = MapList(lambda x: x*x, [1, 2, 3, 4, 5])
    if (my_mapList_0[2] == 9):
        return 0
    else:
        return 1


# Generated at 2022-06-25 16:51:30.541010
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(4)
    lst_0 = []
    lst_1 = []
    lst_0.append(1)
    lst_0.append(2)
    lst_0.append(3)
    lst_0.append(4)
    lst_0.append(5)
    lst_1.append(range_0)
    lst_1.append(range_0)
    lst_1.append(range_0)
    lst_1.append(range_0)
    lst_1.append(range_0)
    map_lst_0 = MapList(lambda i: i, lst_0)
    map_lst_1 = MapList(lambda i: i, lst_1)

# Generated at 2022-06-25 16:51:42.221753
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    '''
    test exception cases
    '''
    try :
        range_0 = Range(1, 10, -1)
        range_0[0]
    except ValueError as expected:
        print("Expected: ValueError")
    try :
        range_0 = Range(0)
        range_0[3]
    except IndexError as expected:
        print("Expected: IndexError")
    try :
        range_0 = Range(0)
        range_0[-1]
    except IndexError as expected:
        print("Expected: IndexError")
    try :
        range_0 = Range()
        range_0[3]
    except TypeError as expected:
        print("Expected: TypeError")

# Generated at 2022-06-25 16:51:50.697940
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func_0 = lambda x: x
    list_0 = List[MapList]
    list_1 = List[int]
    mapList_0 = MapList(func_0, list_0)
    mapList_1 = MapList(func_0, list_1)
    length = mapList_0.__len__()
    slice_0 = mapList_0.__getitem__(slice(0, length, 1))
    func_1 = lambda x: mapList_0.__getitem__(x)
    mapList_2 = MapList(func_1, slice_0)
    mapList_3 = MapList(func_0, mapList_2)
    mapList_3.__getitem__(length)
    mapList_3.__getitem__(length + 1)
    mapList_0.__

# Generated at 2022-06-25 16:52:03.239881
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for n in [0, 1, 2, 3, 4, 5]:
        for q in [0, 1, 2, 3, 4, 5]:
            iterable = list(range(n + 4))
            r = Range(q, n + q)
            assert r.step == 1
            assert r.l == q
            assert r.r == n + q
            assert len(iterable) == n + 4
            assert len(r) == n
            assert list(r) == iterable[q: n + q]

            for i in range(n):
                assert r[i] == iterable[q + i]

            for i in [-n, -n + 1, -1]:
                assert r[i] == iterable[q + n + i]


# Generated at 2022-06-25 16:52:10.623423
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = range(10, 15)
    r0 = Range(10, 15, 1)

    assert r0[0] == 10
    assert r0[2] == 12
    assert r0[3] == 13
    assert r0[-1] == 14

    assert r0[:2] == [10, 11]
    assert r0[1:3] == [11, 12]
    assert r0[:3:2] == [10, 12]
    assert r0[::2] == [10, 12, 14]
    assert r0[::-1] == [14, 13, 12, 11, 10]
    assert r0[-3:] == [12, 13, 14]


# Generated at 2022-06-25 16:52:13.927682
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # range_2 = Range(100)
    range_3 = Range(1,10)
    assert(isinstance(range_3[0], int))
    # assert(isinstance(range_3[1:3], list))


# Generated at 2022-06-25 16:52:25.211255
# Unit test for method __getitem__ of class Range

# Generated at 2022-06-25 16:52:30.818652
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    range_1 = Range(1, 11, 2)
    range_2 = Range(1, 10)
    int_0 = range_0[0]
    int_1 = range_1[10]
    int_2 = range_2[9]

# Generated at 2022-06-25 16:52:37.221342
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    """
    Test __getitem__
    """
    range_0 = Range(5, 7)
    print(range_0[2])
test_case_0()

test_Range___getitem__()

# Generated at 2022-06-25 16:52:40.391313
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    range_0 = Range(1, 2)
    mapList_0 = MapList((lambda x : x - 1), range_0)
    mapList_0[0]
    mapList_0[1]


# Generated at 2022-06-25 16:52:41.601582
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()


# Generated at 2022-06-25 16:52:52.427183
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():

    # Test case for Range#__getitem__
    samples = [
        [0, 1, 2, 3, 4],
        [0, 2, 4],
        [0, 2, 4, 6, 8],
        [-10, -7, -4, -1, 2, 5, 8],
        [-10, -3, 4, 11, 18],
    ]
    for sample in samples:
        for i in range(0, sample[-1] + 1):
            assert Range(sample[0], sample[-1] + 1)[i] == sample[i]
        for i in range(-sample[-1], 0):
            assert Range(sample[0], sample[-1] + 1)[i] == sample[i]

    # Test case for Range#__getitem__

# Generated at 2022-06-25 16:52:59.519567
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(100)
    assert range_0.__getitem__(0) == 0
    range_1 = Range(100)
    assert range_1.__getitem__(1) == 1
    range_2 = Range(100)
    assert range_2.__getitem__(2) == 2
    range_3 = Range(100)
    assert range_3.__getitem__(3) == 3
    range_4 = Range(100)
    assert range_4.__getitem__(4) == 4
    range_5 = Range(100)
    assert range_5.__getitem__(5) == 5
    range_6 = Range(100)
    assert range_6.__getitem__(6) == 6
    range_7 = Range(100)
    assert range_7.__

# Generated at 2022-06-25 16:53:09.287814
# Unit test for method __getitem__ of class Range

# Generated at 2022-06-25 16:53:12.145687
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    print('Testing MapList.__getitem__')
    # Create a MapList object
    m = MapList()
    # Test the MapList.__getitem__ method
    m.__getitem__()


# Generated at 2022-06-25 16:53:14.282438
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    index = 0
    actual = range_0[index]
    expected = 0
    assert actual == expected


# Generated at 2022-06-25 16:53:16.946232
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    try:
        range_0.__getitem__(0)
    except Exception:
        assert False


# Generated at 2022-06-25 16:53:22.705844
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Test unit
    range_0 = Range()
    try:
        range_0.__getitem__('fB')
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-25 16:53:42.534797
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda x: x * x
    lst = [1, 2, 3, 4, 5]
    map_list_0 = MapList(func, lst)
    map_list_0.__getitem__(0)
    assert 4 == map_list_0.__getitem__(1)
    map_list_0.__getitem__(1)
    assert 25 == map_list_0.__getitem__(4)



# Generated at 2022-06-25 16:53:48.763910
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    lst2 = [2, 3, 4, 5, 6]
    test = MapList(lambda x: x * x, lst)
    test2 = MapList(lambda i: lst[i] * lst2[i], Range(len(lst)))
    return test[0] == 1 and test[2] == 9 and test[-1] == 25 and test[1:3] == [4, 9] and test2[0] == 2 and test2[2] == 24 and test2[-1] == 30 and test2[1:3] == [6, 16]


# Generated at 2022-06-25 16:53:53.038313
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    obj = Range(5)
    assert obj[0] == 0
    assert obj[-1] == 4
    assert obj[::-1][0] == 4
    assert obj[::2][0] == 0

    obj = Range(10, 20)
    assert obj[0] == 10
    assert obj[-1] == 19
    assert obj[::-1][0] == 19
    assert obj[::2][0] == 10

    obj = Range(10, 20, 2)
    assert obj[0] == 10
    assert obj[-1] == 18
    assert obj[::-1][0] == 18
    assert obj[::2][0] == 10

    obj = Range(20, 10, -1)
    assert obj[0] == 20
    assert obj[-1] == 11

# Generated at 2022-06-25 16:53:56.270141
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x, [1, 2, 3])[1] == 2
    assert MapList(lambda x: x, [1, 2, 3])[0:3] == [1, 2, 3]


# Generated at 2022-06-25 16:53:59.226931
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1,10,1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[9] == 10
    assert r[2:3] == [3]
    assert r[1:5] == [2,3,4,5]
    assert r[4:10] == [5,6,7,8,9,10]
    assert r[9:10] == [10]
    assert r[10:10] == []


# Generated at 2022-06-25 16:54:03.003306
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    assert range_0[-10] == 0
    range_1 = Range(1, 10 + 1)
    assert range_1[-10] == 1
    range_2 = Range(1, 11, 2)
    assert range_2[-10] == 1
    assert range_2[0] == 1
    assert range_2[2] == 5
    assert range_2[4] == 9


# Generated at 2022-06-25 16:54:04.263517
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    t = Range(10)
    t[0] = 1
    assert(t[0] == 1)


# Generated at 2022-06-25 16:54:09.998000
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 11, 2)
    assert range_0.__getitem__(0) == 1
    assert range_0.__getitem__(1) == 3
    assert range_0.__getitem__(2) == 5
    assert range_0.__getitem__(3) == 7
    assert range_0.__getitem__(4) == 9


# Generated at 2022-06-25 16:54:19.370354
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_1 = Range()
    range_2 = Range(1,1)
    range_3 = Range(0,2)
    range_4 = Range(1,2)
    range_5 = Range(1,3)
    range_6 = Range(0,3)
    range_7 = Range(1,3,1)
    range_8 = Range(3)
    range_9 = Range(0,3,1)
    range_10 = Range(0,4,1)
    range_11 = Range(4)
    range_12 = Range(0,4,2)
    range_13 = Range(0,5,1)
    range_14 = Range(5)
    range_15 = Range(0,5,2)

# Generated at 2022-06-25 16:54:28.748213
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    expected__getitem__: List[int] = []
    actual__getitem__: List[int] = []

    a: List[int] = []
    test__getitem__: MapList[int] = MapList(lambda x: x * x, a)

    # test __getitem__
    for i in range(len(a)):
        actual__getitem__.append(test__getitem__[i])
    if expected__getitem__ != actual__getitem__:
        print('  Test failed')
    else:
        print('  Test successful')
    print('  Expected:', expected__getitem__)
    print('  Actual:  ', actual__getitem__)

