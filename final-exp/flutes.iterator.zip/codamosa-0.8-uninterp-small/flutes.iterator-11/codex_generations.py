

# Generated at 2022-06-25 16:45:13.518205
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    iterator_0 = range_0.__iter__()
    try:
        while True:
            iterator_value_1 = iterator_0.__next__()
            value_0 = iterator_value_1
    except StopIteration:
        pass
    lis = []
    iterator_1 = range_0.__iter__()
    try:
        while True:
            iterator_value_1 = iterator_1.__next__()
            value_0 = iterator_value_1
            lis.append(value_0)
    except StopIteration:
        pass
    # assert lis == list(range(0))
    # assert lis == list(range(0))
    range_1 = Range()
    iterator_2 = range_1.__iter__()

# Generated at 2022-06-25 16:45:18.111488
# Unit test for function drop
def test_drop():
    iterator_0 = take(5, range(42))
    iterator_1 = drop(1, iterator_0)
    assert next(iterator_1) == 1
    assert next(iterator_1) == 2
    assert next(iterator_1) == 3


# Generated at 2022-06-25 16:45:25.200794
# Unit test for function scanl
def test_scanl():
    range_0 = Range()
    iterator_0 = range_0.__iter__()
    items_0 = []
    try:
        for x in scanl(operator.add, range_0, 0):
            items_0.append(x)
    except StopIteration:
        pass
    if items_0 != [0, 1, 3, 6, 10]:
        raise Exception("Test failed")
    mapList_0 = MapList(range_0)
    iterator_1 = mapList_0.__iter__()
    items_1 = []
    try:
        for x in scanl(lambda s, x: x + s, range_0):
            items_1.append(x)
    except StopIteration:
        pass

# Generated at 2022-06-25 16:45:27.881021
# Unit test for function drop_until
def test_drop_until():
    list_0 = drop()
    if list_0 == [0, 1, 2]:
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-25 16:45:31.804956
# Unit test for function drop
def test_drop():
    lst = [1, 2, 3]
    lst_1 = drop(2, lst)
    print(lst_1)
    # lst_1 = take(1, lst_1)
    # print(lst_1)


test_drop()


# Generated at 2022-06-25 16:45:33.422416
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range()
    iterator_0 = range_0.__iter__()
    iterator_0.__next__()


# Generated at 2022-06-25 16:45:44.948674
# Unit test for function drop_until
def test_drop_until():
    # Test case 1
    iterator_0 = drop_until(lambda x: x > 5, range(10))
    assert next(iterator_0) == 6

    # Test case 2
    iterator_1 = drop_until(lambda x: x > -1, range(10))
    assert next(iterator_1) == 0

    # Test case 3
    iterator_2 = drop_until(lambda x: x > 0, range(10))
    assert next(iterator_2) == 1

    # Test case 4
    iterator_3 = drop_until(lambda x: x > 1, range(10))
    assert next(iterator_3) == 2

    # Test case 5
    iterator_4 = drop_until(lambda x: x > 3, range(10))
    assert next(iterator_4) == 4

    # Test case 6
    iterator

# Generated at 2022-06-25 16:45:51.270648
# Unit test for function split_by
def test_split_by():
    actual = list(split_by(" Split by: ", empty_segments=True, separator='.'))
    expected = [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert actual == expected, f'actual={actual} expected={expected}'
    actual = list(split_by(range(10), criterion=lambda x: x % 3 == 0))
    expected = [[1, 2], [4, 5], [7, 8]]
    assert actual == expected, f'actual={actual} expected={expected}'


# Generated at 2022-06-25 16:45:54.558159
# Unit test for function drop
def test_drop():
    range_0 = Range()
    iterator_0 = range_0.__iter__()
    res = take(3, drop(2, iterator_0))
    res = list(res)
    assert res == [2, 3, 4]


# Generated at 2022-06-25 16:45:57.412060
# Unit test for function split_by
def test_split_by():
    list_0 = []
    list_0 = split_by(list_0, criterion=None)
    list_1 = []
    list_1 = split_by(list_1, criterion=None)


# Generated at 2022-06-25 16:46:22.744908
# Unit test for function drop_until
def test_drop_until():
    def test_int():
        test_data = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [9, 10, 11],
            [12, 13, 14],
            [15, 16, 17],
        ]

        def pred(x):
            assert isinstance(x, int)
            return x >= 5
        # print(test_data)
        iterator = drop_until(pred, test_data)
        # list(iterator)
        # print(list(iterator))
        assert list(iterator) == [
            [3, 4, 5],
            [6, 7, 8],
            [9, 10, 11],
            [12, 13, 14],
            [15, 16, 17],
        ]

    def test_string():
        test

# Generated at 2022-06-25 16:46:24.234373
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range()
    range_0.__next__()


# Generated at 2022-06-25 16:46:25.165494
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    pass


# Generated at 2022-06-25 16:46:32.583883
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list_0 = LazyList()
    try:
        list_0._fetch_until(None)
    except AttributeError:
        pass
    str_0 = ''
    list_0.append(str_0)
    int_0 = list_0.__len__()
    list_0.append(str_0)
    int_0 = list_0._fetch_until(None)


# Generated at 2022-06-25 16:46:36.370406
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    print("Test: __iter__ of class LazyList")
    l = LazyList(range(100))
    counter = 0
    for x in l:
        assert x == counter
        counter += 1
    assert counter == 100


# Generated at 2022-06-25 16:46:47.191217
# Unit test for function drop_until
def test_drop_until():
    print("Testing function drop_until(pred_fn, iterable)")
    assert(list(drop_until(lambda x: x > 5 , range(10))) == [6, 7, 8, 9])
    assert(list(drop_until(lambda x: x > 5 , list(range(10)))) == [6, 7, 8, 9])
    assert(list(drop_until(lambda x: x > 5 , tuple(range(10)))) == [6, 7, 8, 9])
    assert(list(drop_until(lambda x: x > 5 , {1, 2, 3, 4, 5, 6, 7, 8, 9, 10})) == [6, 7, 8, 9, 10])



# Generated at 2022-06-25 16:46:53.392814
# Unit test for function drop_until
def test_drop_until():
    def positive(x):
        if x >= 0:
            return True
        else:
            return False
    range_0 = Range()
    print(list(drop_until(positive, range_0)))

# Range object definition

# Generated at 2022-06-25 16:46:56.523092
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    actual = range_0[0, 0]
    expected = 0
    assert actual == expected, f'Expected: {expected}, actual: {actual}'


# Generated at 2022-06-25 16:47:01.660580
# Unit test for function drop_until
def test_drop_until():
    it_0 = iter(drop_until(lambda x: x == 3, [1,2,3,4,5]))
    #print('Next: ', next(it_0))
    assert str(iter(range(4)))==str(it_0)
    #print('Next: ', next(it_0))
    print('Passed')


# Generated at 2022-06-25 16:47:03.991601
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    

# Generated at 2022-06-25 16:47:10.871043
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # test the iterator returned by the method  __iter__ is Iterator[int]
    # return_value_0 = None
    Range_instance = Range()
    return_value_0 = Range_instance.__iter__()
    return return_value_0


# Generated at 2022-06-25 16:47:23.367509
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range(10)
    assert range_0.__next__() == 0
    assert range_0.val == 1
    range_0.step += 1
    assert range_0.__next__() == 1
    assert range_0.val == 2
    range_0.step -= 1
    assert range_0.__next__() == 2
    assert range_0.val == 3
    assert range_0.__next__() == 3
    assert range_0.val == 4
    assert range_0.__next__() == 4
    assert range_0.val == 5
    assert range_0.__next__() == 5
    assert range_0.val == 6
    assert range_0.__next__() == 6
    assert range_0.val == 7
    assert range_0.__next__()

# Generated at 2022-06-25 16:47:26.635072
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range()
    range_0.__init__(10)
    for _ in range(10):
        __next__(range_0)



# Generated at 2022-06-25 16:47:29.376814
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    try:
        MapList(None, None)[0]
        assert False, "Should have thrown AssertionError"
    except AssertionError:
        pass


# Generated at 2022-06-25 16:47:31.946320
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range(0)
    assert range_0.__next__() == 0
    assert range_0.__next__() == 0


# Generated at 2022-06-25 16:47:33.351118
# Unit test for method __next__ of class Range

# Generated at 2022-06-25 16:47:43.225066
# Unit test for function chunk
def test_chunk():
    assert list(range(10)) == list(chunk(1, range(10)))
    assert list(chunk(0, range(10))) == [[]]*10
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]

# Function take
# ================================================================================================

# Generated at 2022-06-25 16:47:47.818355
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    range_1: LazyList[int] = LazyList(range_0)
    range_2: Iterator[int] = range_1.__iter__()
    assert type(range_2) is LazyList.LazyListIterator


# Generated at 2022-06-25 16:47:59.532795
# Unit test for method __len__ of class LazyList

# Generated at 2022-06-25 16:48:02.600923
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, [1,2,3,4,5,6,7,8,9,10])))


# Generated at 2022-06-25 16:48:10.364112
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Create the input data
    data_0 = [1, 2, 3, 4, 5]

    # Create an instance of LazyList
    lazy_list = LazyList(data_0)

    # Evaluate the result
    #res = lazy_list[None]
    try:
        lazy_list[None]
    except:
        print('test_LazyList___getitem__: Pass')
        return
    print('test_LazyList___getitem__: Failed')



# Generated at 2022-06-25 16:48:13.117959
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range_0:
        print(i, end = ' ')
    print()
    print(range_0[2])
    print(range_0[-1])

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 16:48:19.317978
# Unit test for function drop_until
def test_drop_until():
    expected_output = [3, 4, 5]
    def greater_than_two(x):
        if x > 2:
            return True
        else:
            return False
    actual_output = list(drop_until(greater_than_two, [0, 1, 2, 3, 4, 5]))
    assert expected_output == actual_output

test_case_0()
test_drop_until()

# Generated at 2022-06-25 16:48:22.946453
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    iterator = range(6).__iter__()
    ll = LazyList(iterator)
    iterator.__next__()
    assert ll[0] == 0
    assert ll.__len__() == 6
    assert ll[5] == 5


# Generated at 2022-06-25 16:48:28.508446
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(0, 0, 1)
    assert range_0[0] == 0
    range_1 = Range(-1, 1, 1)
    assert range_1[0] == -1
    assert range_1[2] == 1
    range_2 = Range(0, 10, 2)
    assert range_2[4] == 8
    range_4 = Range(0, 10, 2)
    assert range_4[4] == 8
    assert range_4[-5] == 0


# Generated at 2022-06-25 16:48:36.070641
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    range_0.__getitem__(item = 0)
    range_0 = Range(start = 0, step = 1)
    range_0.__getitem__(item = 0)
    range_0 = Range(start = 1, stop = 9 + 1, step = 1)
    range_0.__getitem__(item = 0)


# Generated at 2022-06-25 16:48:41.996730
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = take(5, Range())
    range_1 = take(5, Range())
    range_2 = take(5, Range())
    range_3 = take(5, Range())
    range_4 = take(5, Range())
    print(range_0)
    print(range_1)
    print(range_2)
    print(range_3)
    print(range_4)


# Generated at 2022-06-25 16:48:50.369633
# Unit test for function drop_until
def test_drop_until():

    # Test 1
    # Expected result: [5, 6, 7, 8, 9]
    result1 = list(drop_until(lambda x: x > 4, range(10)))
    assert(result1 == [5, 6, 7, 8, 9])

    # Test 2
    # Expected result: []
    result2 = list(drop_until(lambda x: x > 0, range(0, 0)))
    assert(result2 == [])

    # Test 3
    # Expected result: ['b', 'c', 'd', 'e', 'f']
    result3 = list(drop_until(lambda x: x is not 'a', ['a', 'b', 'c', 'd', 'e', 'f']))
    assert(result3 == ['b', 'c', 'd', 'e', 'f'])



# Generated at 2022-06-25 16:48:54.726077
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range(1)
    lazy_list_0 = LazyList(range_0)
    int_0 = lazy_list_0[0]


# Generated at 2022-06-25 16:49:02.634840
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    iter_ = LazyList(iter([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]))
    list_ = []
    for i in iter_:
        list_.append(i)
    assert list_ == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-25 16:49:12.302597
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # Test that iterator created by the method __iter__ of class LazyList is equal to the iterable passed to the
    # constructor of class LazyList
    iterable = (x for x in range(3))
    lazy_list = LazyList(iterable)
    assert iter(lazy_list) == iterable


# Generated at 2022-06-25 16:49:16.327714
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range(1, 10)
    y = range_0.__next__()
    y = range_0[y]
    y = range_0.__next__()
    y = range_0[y]



# Generated at 2022-06-25 16:49:22.975669
# Unit test for method __next__ of class Range
def test_Range___next__():
    """
    Test if method __next__ of Range is working properly

    """
    # Instantiate Range object
    r = Range(1, 10 + 1, 2)
    # Check if __next__() of Range object is working properly
    assert r.__next__() == 1
    assert r.__next__() == 3
    assert r.__next__() == 5
    assert r.__next__() == 7
    assert r.__next__() == 9
    try:
        #exception catching test
        r.__next__()
    except StopIteration:
        return True
    return False


# Generated at 2022-06-25 16:49:35.044858
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from typing import Iterator
    def test_method_itself(l: LazyList[T]) -> Iterator[T]:
        return l.__iter__()

    test_iterable = iter([])
    l = LazyList(test_iterable)
    result_iterator = test_method_itself(l)

    # check that result iterator matches expected type
    assert isinstance(result_iterator, Iterator)

    # check that the result matches the expected value
    result_value = list(result_iterator)
    expected_value = []
    assert result_value == expected_value

    test_iterable = iter([0])
    l = LazyList(test_iterable)
    result_iterator = test_method_itself(l)

    # check that result iterator matches expected type

# Generated at 2022-06-25 16:49:42.672879
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Test case 0
    print("Testing LazyList.__len__ on case 0 ...")
    range_0 = LazyList(Range())
    expectedResult_0 = 0
    try:
        actualResult_0 = range_0.__len__()
    except Exception as actualException_0:
        print("Exception occurred: ", str(actualException_0))
        print("Test case 0 failed.")
        print()
        return
    print("Test case 0 passed.\n")
    return;


# Generated at 2022-06-25 16:49:44.383476
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    lst = LazyList(range_0)


# Generated at 2022-06-25 16:49:47.831999
# Unit test for method __next__ of class Range
def test_Range___next__():
    counter = 0
    for x in Range(1,17,2):
        assert x % 2 == 1
        counter += 1
    assert counter == 8


# Generated at 2022-06-25 16:49:53.444953
# Unit test for function drop_until
def test_drop_until():
    # imporving the implementation of range object
    # range_0 = Range()
    range_0 = range(100)
    target_list = list(drop_until(lambda x: x % 7 == 0, range_0))
    assert target_list[0] == 7
    assert target_list[-1] == 98
    assert len(target_list) == 14



# Generated at 2022-06-25 16:49:54.490025
# Unit test for method __next__ of class Range
def test_Range___next__():
    for item in Range():
        break


# Generated at 2022-06-25 16:50:00.724973
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(0, 100, 5)
    assert r[0] == 0
    assert r[1] == 5
    assert r[-1] == 95
    assert r[-2] == 90
    assert r[:] == list(range(0, 100, 5))
    assert r[-3:] == list(range(10, 100, 5))
    assert r[2::2] == [r[2], r[4], r[6], r[8], r[10]]
    assert r[:20:3] == [0, 15, 30, 45, 60]

test_Range___getitem__()


# Generated at 2022-06-25 16:50:18.885815
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    assert range_0[1] == 1
    assert range_0[-1] == -1
    assert range_0[:] == [0]
    assert range_0[1:1] == []
    assert range_0[1:] == []
    assert range_0[:2] == [0, 1]
    assert range_0[1:2] == [1]
    assert range_0[-1:1] == []
    assert range_0[-2:2] == [0, 1]
    assert range_0[-1::] == [-1]
    assert range_0[-2::] == [-1, 0]
    assert range_0[1::] == []
    assert range_0[:2:3] == [0]

# Generated at 2022-06-25 16:50:31.276385
# Unit test for function drop_until
def test_drop_until():
    iterable = range(10)
    pred_fn = lambda x: x > 5
    def test_fn():
        return drop_until(pred_fn, iterable)
    expected_iterator = [6, 7, 8, 9]
    counter = 0
    for i in test_fn():
        if i != expected_iterator[counter]:
            print("test case 0 failed.")
            return
        counter += 1
    print("test case 0 passed.")

test_drop_until()

# class Range:
#     def __init__(self, start: int = 0, end: Optional[int] = None, step: int = 1):
#         self.start = start
#         # self.end = end
#         # self.step = step
#
#     def __iter__(self):
#         return next(self.start

# Generated at 2022-06-25 16:50:36.557639
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1, 50, 1)
    assert range_0[0] == 1
    assert range_0[1] == 2
    assert range_0[8] == 9
    assert range_0[9] == 10
    assert range_0[10] == 11
    assert range_0[49] == 50
    assert range_0[50] == 51


# Generated at 2022-06-25 16:50:37.350029
# Unit test for method __next__ of class Range
def test_Range___next__():
    pass


# Generated at 2022-06-25 16:50:39.793719
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range()
    try:
        next(range_0)
    except Exception as e:
        pass


# Generated at 2022-06-25 16:50:48.638818
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-25 16:50:50.026366
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert True


# Generated at 2022-06-25 16:51:00.516686
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from copy import copy
    from sys import getsizeof
    from unittest import TestCase
    from itertools import chain, cycle, repeat
    class Test(TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_case_0(self):
            l1 = LazyList(range(100))
            for i in range(100):
                self.assertEqual(i, l1[i])
            self.assertRaises(IndexError, lambda: l1[100])
            self.assertEqual(range(50, 90), l1[50:90])
            self.assertRaises(TypeError, lambda: l1[::2])
            l2 = LazyList([])
            self.assertRaises(IndexError, lambda: l2[500])


# Generated at 2022-06-25 16:51:03.776902
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(100)
    assert range_0[91] == 91


# Generated at 2022-06-25 16:51:07.975397
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lazy_list_1 = LazyList(range(1000000))
    lazy_list_1[0]
    lazy_list_1[9]
    lazy_list_1[999999]
    lazy_list_1[3:8]



# Generated at 2022-06-25 16:51:58.473343
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass


# Generated at 2022-06-25 16:52:07.798749
# Unit test for method __getitem__ of class Range

# Generated at 2022-06-25 16:52:09.838200
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    lazy_list_0 = LazyList(range_0)
    lazy_list_0.__iter__()


# Generated at 2022-06-25 16:52:18.988610
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range(10):
        for j in range(10):
            for k in range(2, 10):
                range_1 = Range(i, j, k)
        range_2 = Range(i, j)
    range_3 = Range(i)

    try:
        range_3[-1]
    except IndexError:
        pass

    try:
        range_3[1]
    except IndexError:
        pass


# Generated at 2022-06-25 16:52:22.026253
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range(0)
    assert range_0.__next__() == 0


# Generated at 2022-06-25 16:52:32.975076
# Unit test for method __next__ of class Range
def test_Range___next__():
    Range_0 = Range(0, 10)
    Range_1 = Range(0, 10, 1)
    Range_2 = Range(0, 10, 0)
    Range_3 = Range(0, 10, 1)
    Range_4 = Range(0, 10, 0)
    assert Range_0.__next__() == 0
    assert Range_1.__next__() == 0
    assert Range_2.__next__() == 0
    assert Range_3.__next__() == 0
    assert Range_4.__next__() == 0


# Generated at 2022-06-25 16:52:38.467508
# Unit test for function drop_until
def test_drop_until():
    data = [1,2,3,4,5,6,7,8,9]
    def odd(x): 
        return bool(x % 2 == 1)
    print(list(drop_until(odd, data)))


test_case_0()
test_drop_until()

# split_by :: (a -> Bool) -> [a] -> [[a]]

# Generated at 2022-06-25 16:52:49.265135
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from typing import TypeVar
    @overload
    def foo(case: None) -> None: ...
    @overload
    def foo(case: int) -> None: ...
    def foo(case):
        a = LazyList([1])
        if (len(a) > 0):
            pass
        else:
            pass
        b = LazyList([1,2,3,4,5,6,7,8,9,10])
        if (len(b) > 0):
            pass
        if (len(b) == 10):
            pass
        else:
            pass
        c = LazyList([None])
        if (len(c) != 0):
            pass
        else:
            pass
        d = LazyList([1,2,3])

# Generated at 2022-06-25 16:52:52.645340
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range()
    int_0 = range_0.__next__()
    range_0 = Range()
    int_1 = range_0.__next__()
    assert int_0 == int_1


# Generated at 2022-06-25 16:52:55.640629
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList([1,2,3])
    it = iter(l)

    assert(next(it) == 1)
    assert(next(it) == 2)
    assert(next(it) == 3)


# Generated at 2022-06-25 16:53:37.109018
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert False


# Generated at 2022-06-25 16:53:49.822223
# Unit test for function drop_until
def test_drop_until():
    chunk = chunk(2, range(10))
    assert next(chunk) == [0, 1]
    assert next(chunk) == [2, 3]
    assert next(chunk) == [4, 5]
    assert next(chunk) == [6, 7]
    assert next(chunk) == [8, 9]
    try:
        next(chunk)
        assert False
    except StopIteration:
        pass

    x = drop_until(lambda x: True, range(5))
    assert next(x) == 0
    assert next(x) == 1
    assert next(x) == 2
    assert next(x) == 3
    assert next(x) == 4
    try:
        next(x)
        assert False
    except StopIteration:
        pass

    y = drop_until

# Generated at 2022-06-25 16:53:54.762005
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    list_0 = []
    iterator = range_0.__iter__()
    for i in range(0, 10):
        list_0.append(iterator.__next__())
    assert tuple(list_0) == (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)


# Generated at 2022-06-25 16:53:58.535810
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Test arguments
    test_arguments = [0]
    # Initialize instance
    range_0 = Range()
    # Return type
    return_type = int
    # Run method with arguments
    result = range_0.__getitem__(test_arguments[0])
    assert(type(result) == return_type)


# Generated at 2022-06-25 16:53:59.308876
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range()


# Generated at 2022-06-25 16:54:00.408589
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    assert range_0[0] == 0
    assert range_0[2] == 2
    assert range_0[4] == 4


# Generated at 2022-06-25 16:54:05.244387
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    range_0 = Range()
    lazy_list_0 = LazyList(range_0)
    for _ in range(10):
        assert_true(isinstance(next(iter(lazy_list_0)), int))


# Generated at 2022-06-25 16:54:10.194968
# Unit test for function drop_until
def test_drop_until():
    a = drop_until(lambda x: x > 3,[1,2,3,4,5,6,7,8,9,10])
    assert a != [1,2,3,4,5,6,7,8,9,10]
    assert a == [4,5,6,7,8,9,10]


# Generated at 2022-06-25 16:54:11.787151
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList()) == 0


# Generated at 2022-06-25 16:54:12.897316
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
