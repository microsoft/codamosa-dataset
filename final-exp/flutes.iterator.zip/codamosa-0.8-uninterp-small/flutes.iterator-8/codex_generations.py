

# Generated at 2022-06-25 16:45:06.145080
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_0 = Range()
    assert range_0.__next__() == 0


# Generated at 2022-06-25 16:45:17.863301
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    from operator import eq
    from operator import ge
    from operator import itemgetter
    from operator import le
    from operator import lt
    from operator import ne
    from utils import all
    from utils import any
    from utils import compose
    from utils import concat
    from utils import curry
    from utils import curry_with
    from utils import drop
    from utils import drop_until
    from utils import filter
    from utils import flatten
    from utils import head
    from utils import interleave
    from utils import last
    from utils import length
    from utils import map
    from utils import pipe
    from utils import range
    from utils import reduce
    from utils import reverse
    from utils import skip
    from utils import split_by

# Generated at 2022-06-25 16:45:21.440572
# Unit test for function drop
def test_drop():
    # Test 1, drop 5 elements from a range
    for x in drop(5, range(10)):
        print(x)
    # Test 2, drop 5 elements from a LazyList
    for x in drop(5, LazyList(lambda: range(10))):
        print(x)



# Generated at 2022-06-25 16:45:25.339027
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2:4] == [9, 16]


# Generated at 2022-06-25 16:45:28.713241
# Unit test for function split_by
def test_split_by():
    print(list(split_by(range(10), criterion=lambda x: x % 3 == 0)))
    print(list(split_by(" Split by: ", empty_segments=True, separator='.')))
    return



# Generated at 2022-06-25 16:45:33.135735
# Unit test for function take
def test_take():
    take_0 = take(1, range(10))
    take_1 = [x for x in take_0]
    assert take_1 == [0]
    take_2 = take(2, range(10, 100))
    take_3 = [x for x in take_2]
    assert take_3 == [10, 11]


# Generated at 2022-06-25 16:45:34.305528
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    if condition:
        result = range_0.__getitem__(item)
        assert result == expected


# Generated at 2022-06-25 16:45:36.770653
# Unit test for function drop
def test_drop():
    if not drop(5, range(1000000)) == 5:
        raise ValueError("Test Failed")



# Generated at 2022-06-25 16:45:43.236838
# Unit test for function chunk
def test_chunk():
    print("Testing chunk function")
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(5, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(0, range(5))) == ValueError
    print("Pass test_chunk")


# Generated at 2022-06-25 16:45:49.029995
# Unit test for function split_by
def test_split_by():
    print(list(split_by(range(10), criterion=lambda x: x % 3 == 0)))
    print(list(split_by(" Split by: ", empty_segments=True, separator='.')))

test_case_0()
test_split_by()


# Generated at 2022-06-25 16:46:17.031970
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))
    print(list(drop_until(lambda x: x > 5, range(10))))

# Generated at 2022-06-25 16:46:21.387180
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Create an instance of LazyList with an iterable
    x = LazyList(range(10000000))
    # Get the length of instance
    x_len = len(x)
    # Assert the length of the iterable vs the length of LazyList
    assert x_len == 10000000


# Generated at 2022-06-25 16:46:26.328995
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    expected = 10
    from random import randint
    iterable = [randint(0, 1000) for _ in range(expected)]
    lst = LazyList(iterable)
    actual = len(lst)
    assert actual == expected, 'actual: {}'.format(actual)


# Generated at 2022-06-25 16:46:31.884987
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-25 16:46:33.769886
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert LazyList([3, 8, 7, 5]).__len__() == 4


# Generated at 2022-06-25 16:46:39.075618
# Unit test for function drop
def test_drop():
    # Setup
    it = drop(0, range(10))
    expected = list(range(10))

    # Exercise
    result = list(it)

    # Verify
    assert result == expected, "Should be {}, but is {}".format(expected, result)

    # Cleanup - none necessary
    # Teardown - none necessary


# Generated at 2022-06-25 16:46:42.331485
# Unit test for function drop_until
def test_drop_until():
    list_0 = []
    def pred_fn(item):
        if item > 5:
            return True
        return False
    drop_until(pred_fn, range_0)
    pass


# Generated at 2022-06-25 16:46:50.147193
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    start = random.randint(0, 10)
    end = start + random.randint(1, 10)
    lst = list(range(start, end))
    mpl = MapList(lambda i: -i, lst)
    for _ in range(10):
        idx = random.randint(0, len(lst) - 1)
        assert mpl[idx] == -lst[idx]
        assert mpl[(idx, idx + 1)] == [-j for j in lst[(idx, idx + 1)]]


# Generated at 2022-06-25 16:46:54.906613
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    assert(list(drop_until(lambda x : x > 5, range_0)) == [6,7,8,9,10])


# Generated at 2022-06-25 16:47:05.470982
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(1,1)
    range_1 = Range(1,1)
    range_2 = Range(1,10)
    range_3 = Range(1,1)
    range_4 = Range(1,10)
    range_5 = Range(1,1)
    range_6 = Range(1,10)
    range_7 = Range(1,1)
    range_8 = Range(1,10)
    range_9 = Range(1,1)
    range_10 = Range(1,10)
    range_11 = Range(1,1)
    range_12 = Range(1,10)
    range_13 = Range(1,1)
    range_14 = Range(1,10)
    range_15 = Range(1,1)

# Generated at 2022-06-25 16:47:17.200764
# Unit test for function drop_until
def test_drop_until():
    list_0 = list(drop_until(lambda x: x > 5, range(10)))
    print(list_0)
    print(list_0[0])
    assert(list_0[0] == 6)
    assert(list_0[1] == 7)
    assert(list_0[2] == 8)
    assert(list_0[3] == 9)


# Generated at 2022-06-25 16:47:18.262041
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert False  # FIXME


# Generated at 2022-06-25 16:47:21.347490
# Unit test for function drop_until
def test_drop_until():
    l = drop_until(lambda x: x < 0, range(0, 10))
    print(next(l))
    print(next(l))


# Generated at 2022-06-25 16:47:23.913161
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([])) == 0
    assert len(LazyList([1, 2])) == 2


# Generated at 2022-06-25 16:47:25.117117
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    pass # TODO


# Generated at 2022-06-25 16:47:28.535981
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    iterator = drop_until(lambda x: len(x) >= 4, range_0)
    assert next(iterator) == (0, 1, 2, 3)


# Generated at 2022-06-25 16:47:32.248398
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 10, range(10))) == []

test_case_0()
test_drop_until()


# Generated at 2022-06-25 16:47:34.899130
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    with pytest.raises(TypeError) as exception:
        test_case_0()
    assert str(exception.value) == "Range() takes 1 positional argument but 0 were given"


# Generated at 2022-06-25 16:47:43.909344
# Unit test for function drop_until
def test_drop_until():
    one_to_ten = range(10)
    one_to_ten_iter = iter(one_to_ten)
    one_to_ten_drop = drop_until(lambda x: x >= 5, one_to_ten_iter)
    assert next(one_to_ten_drop) == 5
    assert next(one_to_ten_drop) == 6
    assert next(one_to_ten_drop) == 7
    assert next(one_to_ten_drop) == 8
    assert next(one_to_ten_drop) == 9


# Generated at 2022-06-25 16:47:51.484304
# Unit test for function drop_until
def test_drop_until():
    test_cases = [
        ((lambda x: x > 10, range(15)), [11, 12, 13, 14]),
        ((lambda x: x < 0, range(15)), []),
        ((lambda x: x > 0, range(15)), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]),
        ((lambda x: x == 0, range(-5, 10)), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]),
        ((lambda x: x > 0, range(0)), []),
        ((lambda x: x < 0, range(0)), [])
    ]
    for (pred_fn, iterable), ans in test_cases:
        list_seq = list(drop_until(pred_fn, iterable))

# Generated at 2022-06-25 16:47:56.507084
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert range(0, 10, 2)[0] == Range(0, 10, 2)[0]


# Generated at 2022-06-25 16:48:00.559797
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(0)
    range_1 = Range(0, 1)
    range_2 = Range(0, 1, 1)
    range_3 = Range()
    range_4 = Range(1, 11, 2)
    range_5 = Range(0, 10, 1)
    range_6 = Range(1, 10, 1)
    range_7 = Range(0, 1, 1)
    range_8 = Range(1, 10, 1)
    range_9 = Range(0, 10, 1)
    range_10 = Range(1, 10, 1)
    range_11 = Range(0, 10, 1)
    range_12 = Range(1, 10, 1)
    range_13 = Range(0, 10, 1)
    range_14 = Range(1, 10, 1)
   

# Generated at 2022-06-25 16:48:06.389825
# Unit test for function drop
def test_drop():
    # Test cases for drop
    range_0 = Range(10, 100)
    take_0 = take(90, range_0)
    drop_0 = drop(10, take_0)
    assert_equal(next(drop_0), 10)
    return


# Generated at 2022-06-25 16:48:09.928168
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_case_0()


# Generated at 2022-06-25 16:48:15.807910
# Unit test for function drop_until
def test_drop_until():
    tmp = drop_until(lambda x: x > 5, range(10))
    assert [6, 7, 8, 9] == list(tmp)



# Generated at 2022-06-25 16:48:23.283820
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda i: i * i, range(5))[3] == 9
    assert MapList(lambda i: i * i, range(5))[-2] == 9
    assert MapList(lambda i: i * i, range(5))[:2] == [0, 1]
    assert MapList(lambda i: i * i, range(5))[-2:5] == [4, 9, 16]
    assert MapList(lambda i: i * i, range(5))[::2] == [0, 4, 16]
    assert MapList(lambda i: i * i, range(5))[1::2] == [1, 9]


# Generated at 2022-06-25 16:48:27.417713
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    assert len(LazyList(range_0)) == -1
    for i in range(-10, 0):
        try:
            len(LazyList(range(i)))
        except TypeError:
            pass
    assert len(LazyList(range(10))) == 10


# Generated at 2022-06-25 16:48:31.229423
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()

    assert (range_0[0] == 0)
    assert (range_0[-1] == 0)
    assert (range_0[:] == [0])


# Generated at 2022-06-25 16:48:41.009871
# Unit test for function drop_until
def test_drop_until():
    # Test case 1
    range_1 = Range()
    drop_until_1 = drop_until(lambda x:x > 5, range_1)
    print(list(drop_until_1))

    # Test case 2
    range_2 = Range(100, 5, False)
    drop_until_2 = drop_until(lambda x: x < 90, range_2)
    print(list(drop_until_2))

    # Test case 3
    drop_until_3 = drop_until(lambda x: x > 6, range(10))
    print(list(drop_until_3))

test_drop_until()



# Generated at 2022-06-25 16:48:45.960278
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    map_list_0 = MapList([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], lambda x: x)
    assert (map_list_0[0] == 1)
    assert (map_list_0[1] == 1)
    assert (map_list_0[2] == 1)
    assert (map_list_0[3] == 1)

# Generated at 2022-06-25 16:48:54.203958
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    range_0 = Range()
    lst = LazyList(range_0)

    # Call the real function
    len(lst)


# Generated at 2022-06-25 16:49:01.838867
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = LazyList(range(0))
    a = range_0[0]
    b = range_0[1]


# Generated at 2022-06-25 16:49:07.021415
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range()
    range_2 = Range()
    range_3 = Range()
    range_4 = Range()
    range_5 = Range()
    range_6 = Range()
    range_7 = Range()
    range_8 = Range()
    range_9 = Range()
    range_10 = Range()
    range_11 = Range()
    range_12 = Range()
    range_13 = Range()
    range_14 = Range()
    range_15 = Range()
    range_16 = Range()
    range_17 = Range()
    range_18 = Range()
    range_19 = Range()
    range_20 = Range()
    range_21 = Range()
    range_22 = Range()
    range_23 = Range()
    range_24 = Range()
    range_25 = Range()

# Generated at 2022-06-25 16:49:10.918034
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    print(__name__)

    class MapList_0(MapList):
        def __init__(self, func, lst):
            pass

    # Create an object of class 'MapList' with argument 'func' and argument 'lst'
    obj = MapList(func, lst)

    # Call method __getitem__ with argument idx
    obj.__getitem__(idx)


# Generated at 2022-06-25 16:49:16.933629
# Unit test for function drop_until
def test_drop_until():
    items = range(10)
    assert list(drop_until(lambda x: x > 5, items)) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 0, items)) == items
    assert list(drop_until(lambda x: x == 10, items)) == []


# Generated at 2022-06-25 16:49:20.348530
# Unit test for function drop_until
def test_drop_until():
    iterable = range(10)
    pred_fn = lambda x: x > 5
    drop_iter = drop_until(pred_fn, iterable)
    print(list(drop_iter))


# Generated at 2022-06-25 16:49:32.084105
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

    # get an element
    value_0 = range_0[0]
    expected_value_0 = 0
    assert value_0 == expected_value_0

    # get a slice
    value_1 = range_0[4:]
    expected_value_1 = [4, 5, 6, 7, 8, 9, 10]
    assert value_1 == expected_value_1

    # get multiple elements
    value_3 = range_0[1, 2, 3]
    expected_value_3 = (1, 2, 3)
    assert value_3 == expected_value_3


# Generated at 2022-06-25 16:49:35.496875
# Unit test for function drop_until
def test_drop_until():
    # assertion error due to signed int
    assert(list(drop_until(lambda x: x == 0, range(-5, 5))) == range(0, 5))



# Generated at 2022-06-25 16:49:40.477575
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    is_correct = True
    range_0 = Range(10, 21, 2)
    for x in range(0, 5):
        if (range_0[x] != 10 + 2 * x):
            is_correct = False
    if (is_correct == False):
        raise AssertionError


# Generated at 2022-06-25 16:49:52.060516
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range().__getitem__(0) == Range()[0]
    assert Range()[-1] == Range()[len(Range()) - 1]
    assert Range()[int(0)] == Range()[0]
    assert Range()[0:5] == Range()[:5]
    assert Range()[-5:] == Range()[len(Range()) - 5:]
    assert Range()[:5:2] == Range()[0:5:2]
    assert Range()[5::-2] == Range()[5:len(Range()) - 1:-2]
    assert Range()[5::2] == Range()[5:len(Range()):2]
    assert Range()[::2] == Range()[0:len(Range()):2]

# Generated at 2022-06-25 16:50:06.281817
# Unit test for function drop_until
def test_drop_until():
    test_case_id = 0
    success = 0
    total_case_num = 2

    # Test case 0
    if list(drop_until(lambda x: x > 4, range(10))) == [5, 6, 7, 8, 9]:
        success += 1

    # Test case 1
    if list(drop_until(lambda x: x > 0, range(10))) == range(1, 10):
        success += 1

    print("[drop_until] Passed %d cases out of %d." %(success, total_case_num))



# Generated at 2022-06-25 16:50:16.873683
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    assert [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] == list(range_0[:])
    assert [2, 3, 4] == list(range_0[2:5])

# Generated at 2022-06-25 16:50:21.704560
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        range_0 = Range()
        print("Testing: LazyList.__len__")
        if len(range_0) != 10:
            raise Exception("assert failed")
    except Exception as e:
        print("----")
        print("TEST FAILED: " + str(e))
        return 1
    return 0


# Generated at 2022-06-25 16:50:33.228958
# Unit test for function drop_until
def test_drop_until():
    # Test case 0
    pred_fn_0 = lambda x: x > 5
    iterable_0 = range(10)
    expected_0 = [6, 7, 8, 9]
    actual_0 = list(drop_until(pred_fn_0, iterable_0))
    assert actual_0 == expected_0

    # Test case 1
    pred_fn_1 = lambda x: x > 0
    iterable_1 = range(10)
    expected_1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    actual_1 = list(drop_until(pred_fn_1, iterable_1))
    assert actual_1 == expected_1

    # Test case 2
    pred_fn_2 = lambda x: x < 10

# Generated at 2022-06-25 16:50:37.257464
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a0 = [x for x in range(5)]
    m0 = MapList(lambda x: x, a0)

    assert m0[0] == a0[0]
    assert m0[1] == a0[1]
    assert m0[2] == a0[2]
    assert m0[3] == a0[3]
    assert m0[4] == a0[4]
    assert m0[-1] == a0[-1]
    assert m0[-2] == a0[-2]

    m1 = MapList(lambda x: x * x, a0)

    assert m1[0] == a0[0] * a0[0]
    assert m1[1] == a0[1] * a0[1]
    assert m1[2] == a

# Generated at 2022-06-25 16:50:40.048249
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    assert [6, 7, 8, 9] == list(drop_until(lambda x : x > 5, range_0))


# Generated at 2022-06-25 16:50:44.280779
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Testing
    range_0 = Range()
    # Testing
    range_1 = Range(0, 200)
    # Testing
    range_2 = Range(0, 100)
    # Testing
    range_3 = Range(5, 0, -1)


# Generated at 2022-06-25 16:50:49.623078
# Unit test for function drop_until
def test_drop_until():
    # Positive test case
    testcase_0 = drop_until(lambda x: x > 5, range(10))
    assert (list(testcase_0) == [6, 7, 8, 9])
    # Negative test case
    testcase_1 = drop_until(lambda x: x < 5, range(10))
    assert (list(testcase_1) == [])



# Generated at 2022-06-25 16:50:51.459425
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    it = LazyList(range(1000000))
    Assert(len(it) == 1000000)


# Generated at 2022-06-25 16:50:53.744181
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-25 16:51:15.078980
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(10)
    range_1 = Range(100)
    range_2 = Range(10, 20)
    range_3 = Range(100, 200)
    range_4 = Range(0, 50, 5)
    range_5 = Range(0, 60, 6)

    range_0_0 = range_0[0]
    range_0_1 = range_0[9]
    range_0_2 = range_0[10] # Should fail!

    range_1_0 = range_1[0]
    range_1_1 = range_1[99]
    range_1_2 = range_1[100] # Should fail!

    range_2_0 = range_2[0]
    range_2_1 = range_2[9]

# Generated at 2022-06-25 16:51:25.192968
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    from datetime import datetime, timedelta
    from src.util.misc import Range, __getitem__
    def test_Range___getitem___0(self):
        range_0 = Range(2, 44, 2)
        assert __getitem__(range_0, 39) == 77
    def test_Range___getitem___1(self):
        range_0 = Range(-9, -7)
        assert __getitem__(range_0, 0) == -9
    def test_Range___getitem___2(self):
        range_0 = Range()
        assert __getitem__(range_0, 0) == 0
    def test_Range___getitem___3(self):
        range_0 = Range(1)
        assert __getitem__(range_0, 0) == 1

# Generated at 2022-06-25 16:51:33.288392
# Unit test for function drop_until
def test_drop_until():
    list_0 = list(range(10))
    list_1 = list(drop_until(lambda x: x > 5, list_0))
    if list_1 == [6, 7, 8, 9]:
        print('test success.')
    else:
        print('test failure.')

test_case_0()



# Generated at 2022-06-25 16:51:39.573406
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    obj = LazyList(range(10))
    assert obj[2] == 2
    assert obj[-1] == 9
    assert obj[:3] == [0, 1, 2]
    assert obj[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert obj[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]


# Generated at 2022-06-25 16:51:48.764395
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(100)[(100)] == 99
    assert Range(100)[(10)] == 9
    assert Range(100)[(0)] == 0
    assert Range(100)[(-1)] == 99
    assert Range(100)[(0)] == 0
    assert Range(100)[(-10)] == 90
    assert Range(10)[(10)] == 9
    assert Range(10)[(0)] == 0
    assert Range(10)[(-1)] == 9
    assert Range(10)[(0)] == 0
    assert Range(10)[(-10)] == 0
    assert Range(1, 100)[(100)] == 99
    assert Range(1, 100)[(10)] == 9
    assert Range(1, 100)[(0)] == 1
    assert Range(1, 100)[(-1)] == 99
    assert Range(1, 100)[(0)]

# Generated at 2022-06-25 16:51:50.864224
# Unit test for function drop_until
def test_drop_until():
    range_0 = Range()
    list(drop_until(lambda x: x > 5, range_0))



# Generated at 2022-06-25 16:52:01.605204
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print('Testing __getitem__ method of class Range')
    range_0 = Range()
    range_1 = Range(5)
    range_2 = Range(5,5)
    range_3 = Range(5,5,5)
    assert range_0[0] == 0
    assert range_1[0] == 0
    assert range_1[1] == 1
    assert range_1[2] == 2
    assert range_1[3] == 3
    assert range_1[4] == 4
    assert range_2[0] == 5
    assert range_3[0] == 5
    print('Testing complete')


# Generated at 2022-06-25 16:52:10.234362
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for l in (1, 100, 1000):
        for r in (l + 1, 200, 10000):
            for step in (1, 2, 10):
                if step + l >= r:
                    continue
                assert Range(l, r, step).__getitem__(0) == l
                assert Range(l, r, step).__getitem__(1) == l + step
                assert Range(l, r, step).__getitem__(-1) == r - step
                assert Range(l, r, step).__getitem__(slice(0, 2)) == [l, l + step]
                assert Range(l, r, step).__getitem__(slice(-1, None)) == [r - step]

# Generated at 2022-06-25 16:52:12.698552
# Unit test for function drop_until
def test_drop_until():
    assert [10, 11, 12, 13] == list(drop_until(lambda x: x > 5, range(10)))



# Generated at 2022-06-25 16:52:24.029099
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Test case 0
    range_0 = Range(5)
    ret_0 = range_0[1]
    assert ret_0 == range_0[1]
    ret_0 = range_0[1:2]
    assert ret_0 == range_0[1:2]

    # Test case 1
    map_0 = MapList({'a': 1, 'b': 2, 'c': 3}, lambda x: x[0])
    ret_1 = map_0[1:2]
    assert ret_1 == map_0[1:2]
    ret_1 = map_0[1:3]
    assert ret_1 == map_0[1:3]

    # Test case 2

# Generated at 2022-06-25 16:52:39.463622
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass


# Generated at 2022-06-25 16:52:50.370268
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():

    # Test MapList.__getitem__
    assert [0, 1, 4, 9] == MapList(lambda x: x ** 2, range(4))[:4]
    assert [0, 1, 4, 9] == MapList(lambda x: x ** 2, range(4))[:4]
    assert [0, 1, 4, 9] == MapList(lambda x: x ** 2, range(4))[:4]
    assert [0, 1, 4, 9] == MapList(lambda x: x ** 2, range(4))[:4]
    assert [0, 1, 4, 9] == MapList(lambda x: x ** 2, range(4))[:4]
    assert [0, 1, 4, 9] == MapList(lambda x: x ** 2, range(4))[:4]

# Generated at 2022-06-25 16:52:51.485894
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass


# Generated at 2022-06-25 16:52:53.143842
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(0, 10)
    range_1 = Range(1, 10, 1)
    assert range_0[0] == 0
    assert range_0[-1] == 0
    assert range_1[1] == 1

# Generated at 2022-06-25 16:52:55.370444
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert(LazyList.__getitem__(LazyList(map(lambda x: x, range(10))), 0) == 0)
    assert(LazyList.__getitem__([], 0) == 0)
    assert(LazyList.__getitem__(MapList(range(10), lambda x: x), 0) == 0)


# Generated at 2022-06-25 16:53:02.245898
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    a = LazyList([1, 2, 3])
    assert a[0] is 1
    assert a[1] is 2
    assert a[2] is 3
    assert a[0:2] == [1, 2]
    assert a[:2] == [1, 2]
    assert a[:] == [1, 2, 3]
    assert a[0:-1] == [1, 2]
    assert list(a) == [1, 2, 3]
    try:
        a[3]
        assert False
    except(IndexError):
        ()


# Generated at 2022-06-25 16:53:10.941692
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()
    range_0.__getitem__(0)
    range_0.__getitem__(1)
    range_0.__getitem__(2)
    range_0.__getitem__(3)
    range_0.__getitem__(4)
    range_0.__getitem__(5)
    range_0.__getitem__(6)
    range_0.__getitem__(7)
    range_0.__getitem__(8)
    range_0.__getitem__(9)
    range_0.__getitem__(10)
    range_0.__getitem__(11)


# Generated at 2022-06-25 16:53:12.820275
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range()
    yes_no = range_0[-3]


# Generated at 2022-06-25 16:53:16.975553
# Unit test for function drop_until
def test_drop_until():
    print(list(drop_until(lambda x: x > 5, range(10))))
    print(list(drop_until(lambda x: x > 50, range(10))))
    print(list(drop_until(lambda x: x > 5, [2, 3, 4, 5, 6, 7, 8, 9, 10])))


# Generated at 2022-06-25 16:53:19.121590
# Unit test for function drop_until
def test_drop_until():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]

# Generated at 2022-06-25 16:53:55.479090
# Unit test for function drop_until
def test_drop_until():
    seq0 = tuple(range(10))
    seq1 = tuple(range(10))

    if (drop_until(lambda x: x > 5, seq0) != range(6, 10)):
        print("Error in drop_until")
        return False
    
    if (drop_until(lambda x: True, seq1) != range(10)):
        print("Error in drop_until")
        return False
        
    return True



# Generated at 2022-06-25 16:54:02.580719
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():

    # Initialize the test iterable
    test_iter = iter([1, 2, 3, 4])

    # Initialize the LazyList and access the test iterable
    lazy_list = LazyList(test_iter)
    lazy_list.list
    lazy_list[0]
    lazy_list[1]
    lazy_list[2]

    # Test for getitem taking int
    assert (lazy_list[0] == 1)
    assert (lazy_list[1] == 2)
    assert (lazy_list[3] == 4)

    # Test for getitem taking slice
    assert (lazy_list[0:2] == [1, 2])
    assert (lazy_list[2:4] == [3, 4])

# Generated at 2022-06-25 16:54:04.850028
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(0, 1)
    try:
        range_0.__getitem__(0)
        assert False
    except TypeError:
        pass

    try:
        range_0.__getitem__(0.0)
        assert False
    except TypeError:
        pass


# Generated at 2022-06-25 16:54:06.648766
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[9] == 9
    assert Range(10)[3] == 3


# Generated at 2022-06-25 16:54:07.574350
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    range_0 = Range()


# Generated at 2022-06-25 16:54:18.078939
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_0 = Range(14)
    range_0 = Range(3, 10)
    range_0 = Range(3, 10, 4)
    range_0 = Range(3, 11)
    range_0 = Range(2, 9, 3)
    range_0 = Range(2, 10, 3)
    range_0 = Range(3, 11, 4)
    range_0 = Range(3, 12, 4)
    range_0 = Range(2, 10)
    range_0 = Range(2, 11)
    range_0 = Range(2, 9)
    try:
        assert range_0[0] == 2
    except AssertionError:
        raise AssertionError("index 0")
    try:
        assert range_0[4] == 10
    except AssertionError:
        raise

# Generated at 2022-06-25 16:54:21.953433
# Unit test for function drop_until
def test_drop_until():
    L = [1,2,3,4,2,3,4,5]
    L_new = drop_until(lambda x: x < 2, L)
    assert list(L_new) == [2,3,4,2,3,4,5], "Error in drop_until"


# Generated at 2022-06-25 16:54:25.373764
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(10))
    l[10]
    l[10]
    l[-1]
    l[-1]
    l[0:10]


# Generated at 2022-06-25 16:54:37.276644
# Unit test for function drop_until
def test_drop_until():
    # test small dataset
    input1 = [1,2,3,4,5,6,7]
    expected1 = [6,7]
    actual1 = list(drop_until(lambda x : x > 5, input1))
    assert actual1 == expected1, "The result is not right, we expect: " + str(expected1) + " but got: " + str(actual1)
    # test large dataset
    input2 = [i for i in range(1000000000)]
    expected2 = [i for i in range(500000, 1000000000)]
    actual2 = list(take(5000000, drop_until(lambda x: x > 500000, input2)))
    assert actual2 == expected2, "The result is not right, we expect: " + str(expected1) + " but got: " + str(actual2)