

# Generated at 2022-06-23 17:27:20.161747
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 10, range(10))) == []



# Generated at 2022-06-23 17:27:29.567090
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], '')) == ['', 'a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:27:31.170829
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(20))[12:]) == list(range(12, 20))



# Generated at 2022-06-23 17:27:33.403543
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(1000000))) == list(range(5, 1000000))



# Generated at 2022-06-23 17:27:35.844800
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    List_list = [1]
    pass


# Generated at 2022-06-23 17:27:44.645181
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(None, [])) == []
    assert list(drop_until(lambda x: True, [])) == []
    assert list(drop_until(lambda x: False, [1, 2])) == [1, 2]
    assert list(drop_until(lambda x: False, [1, 2, 3, 4])) == [1, 2, 3, 4]



# Generated at 2022-06-23 17:27:55.174102
# Unit test for function split_by
def test_split_by():
    import pytest
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    with pytest.raises(ValueError):
        list(split_by(" Split by: ", empty_segments=False, separator='.', criterion=lambda x: False))
    with pytest.raises(ValueError):
        list(split_by(" Split by: ", empty_segments=False, criterion=lambda x: False))

# Generated at 2022-06-23 17:27:57.549040
# Unit test for constructor of class Range
def test_Range():
    print("Testing unit test in py_utils.extras")
    pass
test_Range()


# Generated at 2022-06-23 17:28:03.202991
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    def test_case(func, lst):
        assert list(MapList(func, lst)) == list(map(func, lst))
    test_case(lambda x: 2*x, [])
    test_case(lambda x: 2*x, [1, 2, 3, 4, 5])

# Generated at 2022-06-23 17:28:09.160235
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    with pytest.raises(TypeError):
        iter(Range(1, 1))
    assert_equal(list(iter(Range(1, 2))), [1])
    assert_equal(list(iter(Range(1, 10 + 1, 3))), [1, 4, 7, 10])


# Generated at 2022-06-23 17:28:14.475535
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, 'abcd')) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:28:21.657191
# Unit test for constructor of class Range
def test_Range():
    assert Range(4)[0]==0
    assert Range(4)[1]==1
    assert Range(4)[2]==2
    assert Range(4)[3]==3
    try:
        Range(4)[4]
        assert False
    except:
        assert True
    assert Range(4)[-1]==3
    try:
        Range(4)[-5]
        assert False
    except:
        assert True
    assert Range(0,4)[0]==0
    assert Range(0,4)[1]==1
    assert Range(0,4)[2]==2
    assert Range(0,4)[3]==3
    try:
        Range(0,4)[4]
        assert False
    except:
        assert True
    assert Range(0,4)[-1]==3

# Generated at 2022-06-23 17:28:31.021229
# Unit test for function scanl
def test_scanl():
    lst = [1, 2, 3, 4]
    op = operator.add
    assert list(scanl(op, lst)) == list(scanl(op, lst, 0)) == [1, 3, 6, 10]
    assert list(scanl(op, lst, 1)) == [1, 2, 3, 4, 5]
    assert list(scanl(op, scanl(op, lst, 1))) == [1, 2, 3, 4, 5, 5]
    assert list(scanl(op, scanl(op, lst, 1), 1)) == [1, 2, 3, 4, 5, 6]
    assert list(scanl(op, scanl(op, lst, 1), 2)) == [1, 2, 3, 4, 5, 5, 7]

# Generated at 2022-06-23 17:28:36.424822
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    for it in [
        (1, 2, 3),
        (x for x in [1, 2, 3]),
    ]:
        lst = LazyList(it)
        assert list(it) == list(lst)

# Generated at 2022-06-23 17:28:43.321604
# Unit test for function scanr
def test_scanr():
    seq = [1,2,3,4]
    r = scanr(lambda s, x: x + s, seq)
    assert r == [10,9,7,4,0]
    r = scanr(lambda s, x: x + s, seq, 0)
    assert r == [10,9,7,4,0]
    r = scanr(lambda s, x: x + s, seq, 10)
    assert r == [20,19,17,14,10]



# Generated at 2022-06-23 17:28:55.040232
# Unit test for function chunk
def test_chunk():
    assert_equal(list(chunk(3, range(10))), [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]])
    assert_equal(list(chunk(3, range(9))), [[0, 1, 2], [3, 4, 5], [6, 7, 8]])
    assert_equal(list(chunk(3, range(8))), [[0, 1, 2], [3, 4, 5], [6, 7]])
    assert_equal(list(chunk(3, range(7))), [[0, 1, 2], [3, 4, 5], [6]])
    assert_equal(list(chunk(3, range(6))), [[0, 1, 2], [3, 4, 5]])

# Generated at 2022-06-23 17:29:07.887977
# Unit test for constructor of class Range
def test_Range():
    assert Range(2) == [0,1]
    assert Range(1,3) == [1,2]
    assert Range(1,3,2) == [1]
    assert Range(3,1,-1) == [3,2]
    assert Range(0,-2,-1) == [0,-1]
    assert Range(-4,4) == [-4,-3,-2,-1,0,1,2,3]
    assert Range(0,4,2) == [0,2]
    assert Range(-3,3) == [-3,-2,-1,0,1,2]
    assert Range(4) == range(4)
    assert Range(1,4) == range(1,4)
    assert Range(10,21,2) == range(10,21,2)

# Generated at 2022-06-23 17:29:20.265465
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[], [1, 2], [], [4, 5], [], [7, 8], []]
    assert list(split_by(" Split by: ", separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:29:29.389977
# Unit test for function drop_until
def test_drop_until():
    def test_case(input, expected_output, predicate):
        assert list(drop_until(predicate, input)) == expected_output

    test_case(range(10), [6, 7, 8, 9], lambda x: x > 5)
    test_case([], [], lambda x: x > 0)
    test_case([1, 2], [1, 2], lambda x: x > 0)
    test_case([1, 2], [2], lambda x: x > 1)



# Generated at 2022-06-23 17:29:40.203573
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(0, 11, 2)
    assert [r[i] for i in range(0, 11, 2)] == [0, 2, 4, 6, 8, 10]
    assert r[2:4] == [4, 6]
    assert [r[i] for i in range(-1, -4, -1)] == [10, 8, 6]
    assert r[-2:] == [8, 10]
    assert [r[i] for i in range(0, 5, 2)] == [0, 4, 8]
    assert r[4:0:-2] == [8, 4, 0]
    assert [r[i] for i in range(5, 0, -2)] == [10, 6, 2]



# Generated at 2022-06-23 17:29:51.284335
# Unit test for function scanl
def test_scanl():
    r"""Test for the function scanl."""
    # Test for different number of arguments
    with pytest.raises(TypeError, match=r"^scanl\(\): expected at most 2 arguments, got 3$"):
        iter(scanl(lambda a, b: a, [], 0, 1))
    with pytest.raises(ValueError, match=r"^Too many arguments$"):
        iter(scanl(lambda a, b: a, [], 0, 0))
    # Test for different types of arguments
    with pytest.raises(TypeError, match=r"^scanl\(\): 'r' is an invalid keyword argument for this function$"):
        iter(scanl(lambda a, b: a, [], r=0))

# Generated at 2022-06-23 17:30:03.046589
# Unit test for function drop_until
def test_drop_until():
    assert drop_until(lambda x: x > 4, range(5)) == [5]
    assert drop_until(lambda x: x > 4, range(6)) == [5, 6]
    assert drop_until(lambda x: x > 4, range(6)) == [5, 6]
    assert drop_until(lambda x: x > 6, range(6)) == []
    def take10(it):
        return take(10, it)
    def take10_until(pred):
        return take10(drop_until(pred, itertools.count()))
    assert take10_until(lambda x: x > 0) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-23 17:30:12.275620
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: x, [1, 2, 3])) == [1, 2, 3]
    assert list(MapList(lambda x: x * x, [1, 2, 3])) == [1, 4, 9]
    assert list(MapList(lambda x: x ** 3, [1, 2, 3])) == [1, 8, 27]
    assert MapList(lambda x: x * x, [1, 2, 3])[1:] == [4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3])[:2] == [1, 4]
    assert MapList(lambda x: x * x, [1, 2, 3])[::-1] == [9, 4, 1]


# Generated at 2022-06-23 17:30:13.467411
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    for i in MapList(lambda x: x * x, range(5)):
        pass



# Generated at 2022-06-23 17:30:22.782954
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    import typing
    import itertools

    if not isinstance(LazyList[str].__getitem__, typing.Callable):
        raise TypeError('Method __getitem__ is not a function')

    if not isinstance(LazyList[int].__getitem__, typing.Callable):
        raise TypeError('Method __getitem__ is not a function')

    if not isinstance(LazyList[LazyList[int]].__getitem__, typing.Callable):
        raise TypeError('Method __getitem__ is not a function')


# Generated at 2022-06-23 17:30:27.429319
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(6, range(5))) == []
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(100, [])) == []
    assert list(drop(100, list(range(3)))) == []



# Generated at 2022-06-23 17:30:34.271411
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    from random import randrange
    def check_with_step_1(n):
        assert list(range(n)) == list(Range(n))
    def check_with_arbitrary_step(n, m):
        assert list(range(n, n + m)) == list(Range(n, n + m))
    for i in range(100):
        l = randrange(1, 10000)
        check_with_step_1(l)
        check_with_arbitrary_step(l, randrange(1, 1000))
    # Test StopIteration
    it = iter(Range(1))
    next(it)
    with pytest.raises(StopIteration):
        next(it)



# Generated at 2022-06-23 17:30:39.532362
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    s = MapList(lambda x: x + 2, [0, 1, 2, 3, 4])
    assert len(s) == 5


# Generated at 2022-06-23 17:30:49.488822
# Unit test for function drop
def test_drop():
    assert list(drop(1, range(10))) == List[T](range(1,10))
    assert list(drop(2, range(10))) == List[T](range(2,10))
    assert list(drop(3, range(10))) == List[T](range(3,10))
    assert list(drop(4, range(10))) == List[T](range(4,10))
    assert list(drop(5, range(10))) == List[T](range(5,10))
    assert list(drop(6, range(10))) == List[T](range(6,10))
    assert list(drop(7, range(10))) == List[T](range(7,10))
    assert list(drop(8, range(10))) == List[T](range(8,10))

# Generated at 2022-06-23 17:31:02.611453
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x >= 3, range(10))) == [3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x >= 3, range(10))) == [3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x >= 10, range(10))) == []
    assert list(drop_until(lambda x: x >= 11, range(10))) == []
    assert list(drop_until(lambda x: x >= 9, range(10))) == [9]
    assert list(drop_until(lambda x: x >= 9, range(11))) == [9, 10]
    assert list(drop_until(lambda x: x >= 10, range(11))) == [10]

# Generated at 2022-06-23 17:31:10.960869
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from . import TestCase
    xs = LazyList([1, 2, 3, 4, 5])
    xslen = len(xs)
    self = TestCase()
    self.assertEqual(xslen, 5)
    self.assertEqual(xs[0], 1)
    self.assertEqual(xs[1], 2)
    self.assertEqual(xs[0:3], [1, 2, 3])
    with self.assertRaises(IndexError):
        xs[5]


# Generated at 2022-06-23 17:31:21.370138
# Unit test for constructor of class Range
def test_Range():
    '''
    This function tests the constructor of class Range.
    '''
    with pytest.raises(ValueError):
        Range()
    with pytest.raises(ValueError):
        Range(1, 2, 3, 4)
    assert Range(10)[0] == 0
    assert Range(10)[2] == 2
    assert Range(1, 10+1)[0] == 1
    assert Range(1, 10+1)[2] == 3
    assert Range(1, 11, 2)[0] == 1
    assert Range(1, 11, 2)[2] == 5



# Generated at 2022-06-23 17:31:24.224842
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5


# Generated at 2022-06-23 17:31:28.022650
# Unit test for function drop_until
def test_drop_until():
    it = list(range(10))
    assert list(drop_until(lambda x: x > 5, it)) == it[6:]
    assert list(drop_until(lambda x: x < 1, it)) == []
    assert list(drop_until(lambda x: x > 10, it)) == it

test_drop_until()



# Generated at 2022-06-23 17:31:31.076649
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x + 1, [1, 2, 3])) == 3


# Generated at 2022-06-23 17:31:42.635273
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for _ in range(MAX_TEST_CASES):
        n = random.randrange(1,MAX_TEST_LIST_LEN)
        lst = [random.random() for _ in range(n)]
        func = random.choice([lambda x: x, lambda x: x * 100, lambda x: int(x), lambda x: x > 0])
        x = random.randrange(n)
        slice_ = slice(random.randrange(n), random.randrange(x, n + 1), random.randrange(1, 10))
        if DEBUG:
            print(f"MapList(func = {func.__name__}, lst = {lst}, item = {x})\n\n")
        assert MapList(func, lst)[x] == func(lst[x])

# Generated at 2022-06-23 17:31:46.908951
# Unit test for function scanl
def test_scanl():
    assert _test_scan(scanl, scanr)



# Generated at 2022-06-23 17:31:51.126603
# Unit test for constructor of class MapList
def test_MapList():
    a = [1,2,3,4,5]
    b = [2,3,4,5,6]
    ml = MapList(lambda i: a[i]*b[i], Range(len(a)))
    assert ml[2] == (a[2]*b[2])

# Generated at 2022-06-23 17:31:57.952725
# Unit test for method __len__ of class Range
def test_Range___len__():
    for input_ in range(-10, 10):
        assert len(Range(input_)) == input_

    for input_ in range(-10, 10):
        assert len(Range(input_, 100)) == 100 - input_

    for input_ in range(-10, 10):
        assert len(Range(input_, 100, 2)) == (100 - input_) // 2

    for input_ in range(-10, 10):
        assert len(Range(input_, 100, -2)) == input_ // 2


# Generated at 2022-06-23 17:32:02.974502
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    assert len(lst) == 10
    try:
        len(LazyList(range(10)))
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-23 17:32:08.276042
# Unit test for function take
def test_take():
    assert list(take(0, range(1))) == []
    assert list(take(5, range(5))) == list(range(5))
    assert list(take(5, range(10))) == list(range(5))
    assert list(take(5, [])) == []
    assert list(take(float('inf'), [])) == []

    with pytest.raises(ValueError):
        take(-1, range(1))



# Generated at 2022-06-23 17:32:19.172308
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(2, range(9))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8]]
    assert list(chunk(1, range(9))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8]]
    assert list(chunk(0, range(9))) == ValueError
    assert list(chunk(-1, range(9))) == ValueError



# Generated at 2022-06-23 17:32:27.296186
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from collections.abc import Iterable
    from collections import namedtuple
    from typing import List
    from typing_extensions import Literal

    T = TypeVar('T')

    class StrIterable(Iterable[str]):
        @overload
        def __iter__(self) -> Iterator[str]: ...

        @overload
        def __iter__(self) -> Iterator[Tuple[Literal[1], List[int]]]: ...

        def __iter__(self):
            yield '1'
            yield '2'
            yield '3'
            yield '4'
            yield '5'
            yield '6'

    class StrList(List[str]):
        @overload
        def __getitem__(self, idx: int) -> str: ...


# Generated at 2022-06-23 17:32:37.784392
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Test lazylist[int] on a finite list
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[5] == 5
    assert lst[0:10:2] == list(range(0, 10, 2))
    assert lst[-1:0:-1] == list(range(9, 0, -1))

    # Test lazylist[int] on an infinite list
    lst = LazyList(itertools.count(0))
    assert lst[0] == 0
    assert lst[10] == 10
    assert lst[0:20:2] == list(range(0, 20, 2))

# Generated at 2022-06-23 17:32:48.620658
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from random import randint
    from typing import Iterator
    from .functional import compose

    def fetch_until_pos(idx):
        def method(self):
            if self.exhausted:
                raise IndexError()
            try:
                while len(self.list) <= idx:
                    self.list.append(next(self.iter))
                return self.list[idx]
            except StopIteration:
                self.exhausted = True
                raise IndexError()

        return method

    def fetch_until_neg(idx):
        def method(self):
            if self.exhausted:
                raise IndexError()

# Generated at 2022-06-23 17:32:57.731805
# Unit test for method __next__ of class Range
def test_Range___next__():
    # When step > 0, start < end.
    range1 = Range(1, 10, 2)
    next_val = 1
    while next_val <= range1.r:
        assert next(range1) == next_val
        next_val += 2

    # When step < 0, start > end.
    range2 = Range(10, 1, -2)
    next_val = 10
    while next_val >= range2.r:
        assert next(range2) == next_val
        next_val -= 2

    with pytest.raises(StopIteration):
        next(range1)
    with pytest.raises(StopIteration):
        next(range2)
test_Range___next__()

# Generated at 2022-06-23 17:33:00.618690
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    iter_obj = iter(lst)
    assert isinstance(iter_obj, LazyList.LazyListIterator)


# Generated at 2022-06-23 17:33:04.606509
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = iter([1, 2, 3])
    lst = LazyList(it)
    assert list(lst) == [1, 2, 3]
    assert list(lst) == [1, 2, 3]
    assert list(lst) == [1, 2, 3]

# Generated at 2022-06-23 17:33:08.544904
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(range(10))
    assert len(l) == 10



# Generated at 2022-06-23 17:33:14.465628
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from itertools import count
    a = LazyList(count(1, 3))
    print(a[:10:2] == [1, 7, 13, 19, 25, 31])
    print(a[0] == 1)
    print(a[-1] == 91)
    print(a[1:3] == [4, 7])

# Generated at 2022-06-23 17:33:18.173646
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(10))
    for i, x in enumerate(ll):
        assert ll[i] == i
        assert ll[i] is x
    assert list(ll) == list(range(10))
    assert ll[1:3] == [1, 2]
    for i, x in enumerate(ll):
        assert ll[i] == i

# Generated at 2022-06-23 17:33:24.477903
# Unit test for function take
def test_take():
    data = range(10)
    test_cases = [(0, []), (1, [0]), (3, [0, 1, 2]), (10, data)]
    
    for n, expected in test_cases:
        actual = list(take(n, data))
        assert actual == expected



# Generated at 2022-06-23 17:33:33.049441
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # If a sequence is exhausted, we should be able to iterate over the list over and over again.
    iterable = range(10)
    lst = LazyList(iterable)
    lst[-1]
    # If the list was created from an iterable, we should not be able to iterate over it more than once.
    iterable = range(10)
    lst = LazyList(iterable)
    it1 = iter(lst)
    try:
        it2 = iter(lst)
        pytest.fail("The second iter should raise an error.")
    except TypeError:
        pass
    # If the list was created from an iterable, we should not be able to iterate over it again after exhaustive
    # iteration.
    iterable = range(10)

# Generated at 2022-06-23 17:33:37.130913
# Unit test for constructor of class LazyList
def test_LazyList():
    from collections import deque
    from itertools import count
    import pytest
    a = deque([])
    for i in range(5):
        a.append(i)
    b = LazyList(a)
    assert b[1] == 1
    assert b[1] == 1
    assert b[2:3] == [2]
    assert b[2:3] == [2]

    with pytest.raises(TypeError):
        len(b)


# Generated at 2022-06-23 17:33:41.687054
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:33:53.221066
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    def identity(x):
        return x


    # Test on a normal list
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    bi = iter(b)
    c = MapList(lambda x: x, a)
    di = iter(c)
    assert [x for x in c] == a
    assert [x for x in c] == a
    assert [x for x in c] == a
    assert [x for x in c] == a
    assert [x for x in c] == a
    assert [x for x in c] == a
    assert [x for x in c] == a
    assert [x for x in c] == a
    assert [x for x in c] == a
    assert [x for x in c] == a

# Generated at 2022-06-23 17:33:55.960860
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-23 17:34:02.191711
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    assert list(MapList(lambda x: x * x, a)) == [1, 4, 9, 16, 25]
    assert list(MapList(lambda x: x + 1, a)) == [2, 3, 4, 5, 6]
    assert list(MapList(lambda i: a[i] + i, Range(len(a)))) == [1, 3, 5, 7, 9]

    assert MapList(lambda x: x * x, a)[0] == 1
    assert MapList(lambda x: x * x, a)[1] == 4
    assert MapList(lambda x: x * x, a)[2] == 9
    assert MapList(lambda x: x * x, a)[3] == 16

# Generated at 2022-06-23 17:34:10.702212
# Unit test for function drop
def test_drop():
    # Test positive n
    assert list(drop(3, [0, 1, 2, 3, 4])) == [3, 4]

    # Test 0
    assert list(drop(0, [0, 1, 2, 3, 4])) == [0, 1, 2, 3, 4]

    # Test negative
    with pytest.raises(ValueError):
        list(drop(-3, [0, 1, 2, 3, 4]))

    # Test empty iterable
    assert list(drop(3, [])) == []



# Generated at 2022-06-23 17:34:14.799226
# Unit test for constructor of class Range
def test_Range():
    # test constructor
    assert list(Range(3, 7)) == [3, 4, 5, 6]
    assert Range(3, 7).length == 4
    assert Range(3, 7, 2).length == 2


# Generated at 2022-06-23 17:34:16.679392
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)

# Generated at 2022-06-23 17:34:20.059504
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    lst = list(Range(1, 10 + 1))
    assert lst == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# Show documentation for method __iter__ of class Range
print(Range.__iter__.__doc__)
# Test __next__ method

# Generated at 2022-06-23 17:34:23.329107
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(4))) == [0, 1, 2, 3]


# Generated at 2022-06-23 17:34:33.591015
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)
    assert list(r) == list(range(10))
    r = Range(1, 10 + 1)
    assert list(r) == list(range(1, 10 + 1))
    r = Range(1, 11, 2)
    assert list(r) == list(range(1, 11, 2))

    assert r[0] == 1
    assert r[1] == 3
    assert r[2] == 5
    assert r[-1] == 9
    assert r[-2] == 7
    assert r[-3] == 5

    assert r[3:5] == [7, 9]
    assert r[:5] == [1, 3, 5, 7, 9]
    assert r[5:] == [11]

# Generated at 2022-06-23 17:34:41.333783
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(5))) == 5
    assert len(LazyList(range(5))) == 5
    assert LazyList(range(5))[2] == 2
    assert len(LazyList(range(5))) == 5
    assert len(LazyList([1, 2, 3])) == 3
    assert LazyList([1, 2, 3])[-1] == 3
    assert len(LazyList([1, 2, 3])) == 3
    assert list(LazyList([1, 2, 3])) == [1, 2, 3]
    assert len(LazyList([1, 2, 3])) == 3



# Generated at 2022-06-23 17:34:47.709593
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    result1 = LazyList([1, 2, 3])[0]
    print(result1)
    result2 = LazyList([1, 2, 3])[-2:]
    print(result2)
    result3 = LazyList([1, 2, 3])[0:2]
    print(result3)

# Generated at 2022-06-23 17:34:58.458004
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(1, 10)) == 1
    assert next(Range(1, 10)) == 2
    assert next(Range(1, 10, 2)) == 1
    assert next(Range(1, 10, 2)) == 3
    assert next(Range(1, 11, 2)) == 1
    assert next(Range(1, 11, 2)) == 3
    assert next(Range(2)) == 0
    assert next(Range(2)) == 1
    assert next(Range(2, 5)) == 2
    assert next(Range(2, 5)) == 3
    assert next(Range(2, 5, 2)) == 2
    assert next(Range(2, 5, 2)) == 4
    try:
        assert next(Range(5))
    except StopIteration:
        pass


# Generated at 2022-06-23 17:35:04.143197
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    m = MakeMapList([1, 2, 3, 4, 5], lambda x: x * x)
    assert m[0] == 1
    assert m[-1] == 25
    assert isinstance(m[:], list)
    assert m[1:3] == [4, 9]
    assert m[2:100:2] == [9, 25]
    assert m[-100:100:2] == [1, 9, 25]

# Generated at 2022-06-23 17:35:11.621752
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(0)) == 0
    assert len(Range(0, 10)) == 10
    assert len(Range(0, 10, 2)) == 5
    assert len(Range(0, 10, 3)) == 4
    assert len(Range(1, 10)) == 9
    assert len(Range(1, 10, 2)) == 5
    assert len(Range(1, 10, 3)) == 4
    assert len(Range(10, 1, -1)) == 10
    assert len(Range(10, 1, -2)) == 5
    assert len(Range(10, 1, -3)) == 4


# Generated at 2022-06-23 17:35:18.488352
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(5), criterion=lambda x: x % 2 == 1)) == [[0, 2, 4]]
    assert list(split_by(range(5), criterion=lambda x: x % 2 == 1, empty_segments=True)) == [[], [0, 2, 4]]
    assert list(split_by(range(6), criterion=lambda x: x % 2 == 1)) == [[0, 2, 4], []]
    assert list(split_by(range(6), criterion=lambda x: x % 2 == 1, empty_segments=True)) == [[], [0, 2, 4], []]
    assert list(split_by("xyxyx", empty_segments=True, separator='y')) == [['x'], ['x', 'x'], []]



# Generated at 2022-06-23 17:35:23.507621
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    lst = []
    for i in Range(2, -2, -1):
        lst.append(i)
    assert lst == [2, 1, 0, -1]
    for i in Range(1, 100, 2):
        assert i % 2 == 1

# Generated at 2022-06-23 17:35:31.877197
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9

    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10

    r = Range(1, 11, 2)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    assert r[-1] == 9

    r = Range(1, 11, 3)
    assert r[0] == 1
    assert r[2] == 7
    assert r[4] == 1
    assert r[-1] == 7


# Generated at 2022-06-23 17:35:34.805162
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 0, range(5))) == [1, 2, 3, 4]
    assert list(drop_until(lambda x: x < 0, range(5))) == []



# Generated at 2022-06-23 17:35:37.359409
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(range(10))
    assert len(lst) == 10
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[1:3] == [1, 2]



# Generated at 2022-06-23 17:35:41.121383
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList(range(10))
    assert not hasattr(a, '_exhausted')
    assert len(a) == 10
    assert hasattr(a, '_exhausted')
    assert a._exhausted



# Generated at 2022-06-23 17:35:46.450035
# Unit test for function drop
def test_drop():
    x=drop(2,range(10))
    assert next(x) == 2
    assert next(x) == 3
    assert next(x) == 4
    assert next(x) == 5
    assert next(x) == 6
    assert next(x) == 7
    assert next(x) == 8
    assert next(x) == 9


# Generated at 2022-06-23 17:35:52.449262
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    # Case 1: Iteration of empty list
    t1 = MapList(lambda x: x + 1, [])
    assert next(iter(t1), None) is None
    # Case 2: Iteration of list with elements
    t2 = MapList(lambda x: x + 1, [1, 2, 3])
    assert list(iter(t2)) == [2, 3, 4]

# Generated at 2022-06-23 17:35:55.958023
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(Range(1,2)) == list(range(1,2))


# Generated at 2022-06-23 17:36:01.683261
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    items = [(1, 0), (2, 0), (3, 0), (4, 0), (5, 0)]
    m_items = MapList(lambda x: x[0], items)
    assert [1, 2, 3, 4, 5] == [x for x in m_items]

# Generated at 2022-06-23 17:36:04.324359
# Unit test for function drop
def test_drop():
    it = drop(0, range(10))
    assert next(it) == 0
    it = drop(3, range(10))
    assert next(it) == 3
    it = dro

# Generated at 2022-06-23 17:36:08.614272
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(0)) == 0
    assert len(Range(5)) == 5
    assert len(Range(1, 11)) == 10
    assert len(Range(0, 11, 3)) == 4
    assert len(Range(1, 11, 3)) == 4
    assert len(Range(0, 12, 3)) == 4
    assert len(Range(1, 12, 3)) == 4

# Generated at 2022-06-23 17:36:12.766995
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random

    random.seed(0)
    n = random.randrange(5, 16)
    lst = [random.randrange(10, 101) for _ in range(n)]
    expected = [x[-1] for x in lst if len(x) > 1]
    actual = MapList(lambda x: x[-1], lst)
    assert actual == expected
    assert actual[0::2] == expected[0::2]



# Generated at 2022-06-23 17:36:17.766837
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
test_scanl()



# Generated at 2022-06-23 17:36:20.617706
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(3))) == 3



# Generated at 2022-06-23 17:36:30.643982
# Unit test for function scanl
def test_scanl():
    # Test scanl without initial value
    actual = list(scanl(operator.add, [1, 2, 3, 4]))
    expected = [1, 3, 6, 10]
    assert actual == expected
    # Test scanl with initial value
    actual = list(scanl(operator.add, [1, 2, 3, 4], 0))
    expected = [0, 1, 3, 6, 10]
    assert actual == expected
    # Test string accumulation
    actual = list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']))
    expected = ['a', 'ba', 'cba', 'dcba']
    assert actual == expected
    # Test mixing both
    actual = list(scanl(lambda x, y: [x, y], range(5)))

# Generated at 2022-06-23 17:36:35.092110
# Unit test for function drop
def test_drop():
    assert len(list(drop(10, range(1, 100000)))) == len(list(range(11, 100000)))
    assert list(drop(10, range(1, 100000))) == list(range(11, 100000))



# Generated at 2022-06-23 17:36:38.636938
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    class __TestClass:
        def __init__(self):
            pass

    obj = __TestClass()
    with raises(RuntimeError):
        obj.__iter__()
        

# Generated at 2022-06-23 17:36:40.828557
# Unit test for function drop
def test_drop():
    for i in range(10):
        assert list(drop(i, range(10))) == list(range(i, 10))



# Generated at 2022-06-23 17:36:46.765752
# Unit test for method __next__ of class Range
def test_Range___next__():

    # case 1:
    #   start = 0
    #   stop = 10
    #   step = 2
    #   expect = [0, 2, 4, 6, 8]
    print(Range(0, 10, 2).__next__())
    print(Range(0, 10, 2).__next__())
    print(Range(0, 10, 2).__next__())
    print(Range(0, 10, 2).__next__())
    print(Range(0, 10, 2).__next__())

# Generated at 2022-06-23 17:36:49.216218
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    lst = [1, 2, 3, 4, 5]
    mappedList = MapList(lambda x: x * x, lst)
    assert list(mappedList.__iter__()) == list(map(lambda x: x * x, lst))

# Generated at 2022-06-23 17:36:56.514430
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:37:00.164761
# Unit test for method __next__ of class Range
def test_Range___next__():
    it = iter(Range(4))
    for value,expected in zip(it, [0,1,2,3]):
        assert value == expected, f"Got value: {value}, Expected: {expected}"


# Generated at 2022-06-23 17:37:09.449825
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(10))
    assert ll[0] == 0
    assert len(ll.list) == 1
    assert ll[-1] == 9
    assert len(ll.list) == 2
    assert ll[7:] == [7, 8, 9]
    assert len(ll) == 10
    assert ll[7:3] == []
    assert len(ll) == 10
    assert ll[-10:7] == [0, 1, 2, 3, 4, 5, 6]
    assert len(ll) == 10
    assert ll[7:-10:-1] == [7, 6, 5, 4, 3, 2, 1, 0]
    assert len(ll) == 10
    assert ll[7:7] == []
    assert len(ll) == 10

# Generated at 2022-06-23 17:37:16.277195
# Unit test for function scanl
def test_scanl():
    res = list(scanl(operator.add, [1, 2, 3, 4], 0))
    assert res == [0, 1, 3, 6, 10]
    res2 = list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']))
    assert res2 == ['a', 'ba', 'cba', 'dcba']
test_scanl()

