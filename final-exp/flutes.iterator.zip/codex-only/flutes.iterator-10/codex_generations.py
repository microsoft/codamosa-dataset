

# Generated at 2022-06-23 17:27:23.678086
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda s, x: x * s, [1, 2, 3, 4], 1)) == [24, 12, 4, 1]


# Generated at 2022-06-23 17:27:28.340709
# Unit test for constructor of class LazyList
def test_LazyList():
    l = LazyList(iter([1, 2, 3, 4]))
    assert l[0] == 1
    assert l[2] == 3
    assert l[1:3] == [2, 3]


# Generated at 2022-06-23 17:27:32.925016
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
test_take()



# Generated at 2022-06-23 17:27:38.115057
# Unit test for function drop
def test_drop():
    assert list(drop(0, [1, 2, 3])) == [1, 2, 3]
    assert list(drop(3, [1, 2, 3])) == []
    assert list(drop(4, [1, 2, 3])) == []



# Generated at 2022-06-23 17:27:47.965113
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) != [7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) != [6, 7, 8, 9, 10]
    assert list(drop_until(lambda x: x > 5, range(10))) != [6, 7, 8, 9, 11]


# Generated at 2022-06-23 17:27:55.483033
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert sum(lst) == 45
    assert list(lst) == list(range(10))

    lst = LazyList(range(10))
    assert sum(lst) == 45
    assert list(lst) == list(range(10))

    it = iter(lst)
    assert sum(it) == 45
    assert sum(lst) == 45



# Generated at 2022-06-23 17:28:07.291084
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert list(Range(0, 3)) == [0, 1, 2]
    assert Range(0, 3)[0:1] == [0]
    assert Range(0, 3)[0:5] == [0, 1, 2]
    assert Range(0, 3)[0:2] == [0, 1]
    assert Range(0, 3)[0:3] == [0, 1, 2]
    assert Range(0, 3)[0:4] == [0, 1, 2]
    assert Range(0, 3)[0:5] == [0, 1, 2]
    assert Range(0, 3)[:] == [0, 1, 2]
    assert Range(0, 3)[0:] == [0, 1, 2]
    assert Range(0, 3)[:0] == []

# Generated at 2022-06-23 17:28:11.575418
# Unit test for function take
def test_take():
    for i in range(5):
        assert list(take(i, range(10))) == list(range(i))



# Generated at 2022-06-23 17:28:17.236896
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        len(LazyList([]))
    except TypeError:
        pass
# All tests are executed when module is imported
get_all_tests = lambda: [x for (x, y) in globals().items() if x.startswith('test_') and callable(y)]
for test in get_all_tests():
    globals()[test]()


Range = LazyList[int]



# Generated at 2022-06-23 17:28:26.954706
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(0, 10, 1)) == 10
    assert len(Range(10)) == 10
    assert len(Range(0)) == 0
    assert len(Range(10, -1, -1)) == 11
    assert len(Range(-20, -30, -1)) == 10
    assert len(Range(-10, -20, -2)) == 5
    assert len(Range(-10, -20, 2)) == 0
    assert len(Range(0, 1, 1)) == 1
    assert len(Range(0, 2, 1)) == 2
    assert len(Range(0, 0, 1)) == 0


# Generated at 2022-06-23 17:28:38.362480
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from itertools import count

    def check_iterator(lst, count_to):
        def iterator_generator():
            iterator = iter(lst)
            while True:
                try:
                    yield next(iterator)
                except StopIteration:
                    break
        it = iterator_generator()
        for i in range(count_to):
            assert next(it) == i
        try:
            next(it)
        except StopIteration:
            pass
        else:
            raise AssertionError("Iterator exhausted early")

    lst_1 = LazyList(range(5))
    check_iterator(lst_1, len(lst_1))

    lst_2 = LazyList(range(3))
    check_iterator(lst_2, 2)

# Generated at 2022-06-23 17:28:45.152837
# Unit test for function drop
def test_drop():
    # Test with finite sequence
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    # Test with infinite sequence
    it = drop(5, iter(range(10)))
    # Calling take() should return the remaining elements
    assert list(take(3, it)) == [5, 6, 7]
    # Calling take() again should return the remaining elements as well
    assert list(take(3, it)) == [8, 9]
    # Calling take() again should return nothing
    assert not list(take(3, it))


# Generated at 2022-06-23 17:28:49.479546
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))  # Make sure the iterator won't change after exhaust


# Generated at 2022-06-23 17:28:52.859118
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst1 = LazyList(range(10))
    lst2 = LazyList(range(10))
    assert lst1[2] == 2
    assert lst1[3] == 3
    assert lst1[0] == 0
    assert list(lst1) == list(range(10))
    assert list(lst2[:-2]) == list(range(8))
    assert list(lst2[2:]) == list(range(2, 10))



# Generated at 2022-06-23 17:29:05.604004
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    it = LazyList([1, 2, 3, 4])
    assert it[-1] == 4
    assert it[0] == 1
    assert it[1] == 2
    try:
        it[-5]
        assert False
    except IndexError:
        pass
    try:
        it[4]
        assert False
    except IndexError:
        pass
    try:
        it[5]
        assert False
    except IndexError:
        pass
    assert it[:] == [1, 2, 3, 4]
    assert it[2:5] == [3, 4]
    assert it[3:3] == []
    assert it[:10] == [1, 2, 3, 4]
    assert it[:-1] == [1, 2, 3]
    assert it[:-10] == []

# Generated at 2022-06-23 17:29:09.965602
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1,11,2)
    assert next(r) == 1
    assert next(r) == 3
    assert next(r) == 5
    assert next(r) == 7
    assert next(r) == 9

    for i in range(1,11,2):
        assert next(r) == i



# Generated at 2022-06-23 17:29:14.982985
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(1000000))
    assert len(lst) != len(list(lst))

# Generated at 2022-06-23 17:29:24.007698
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(range(1, 4))
    assert lst[0] == 1
    assert next(iter(lst)) == 1
    assert next(iter(lst)) == 2
    assert next(iter(lst)) == 3
    assert lst[:] == [1, 2, 3]
    assert lst[1:] == [2, 3]
    assert next(iter(lst)) == 1
    assert len(lst) == 3
    lst2 = LazyList(range(4))
    assert len(lst2) == 4
    assert lst2[-1] == 3
    assert lst2[1:3] == [1, 2]
    assert lst2[:2] == [0, 1]
    assert lst2[:] == [0, 1, 2, 3]

# Generated at 2022-06-23 17:29:35.780587
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(5)) == [0, 1, 2, 3, 4]
    assert list(Range(1, 5)) == [1, 2, 3, 4]
    assert list(Range(1, 6, 2)) == [1, 3, 5]
    assert list(Range(0, 0)) == []
    assert Range(0, 0)[0] == 0
    assert Range(0, 0)[0:0] == []
    assert Range(-1, -1)[0] == -1
    assert Range(-1, -1)[0:0] == []
    assert Range(-1, -1)[-1] == -1
    assert Range(-1, -1)[-1:0] == []
    assert Range(-1, -1)[-1:0] == []
    assert Range(10)[0] == 0
    assert Range

# Generated at 2022-06-23 17:29:42.984160
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList(range(10000))
    assert isinstance(iter(l), LazyList.LazyListIterator)
    assert sum(l) == sum(l)
    assert sum(l) == sum(l)
    assert sum(l) == sum(l)
    print("Successfully passed unit test for method __iter__ of class LazyList")
test_LazyList___iter__()

# Generated at 2022-06-23 17:29:52.472859
# Unit test for function scanr
def test_scanr():
    def function(a, b): return a + b
    assert scanr(function, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(function, [1, 2, 3, 4]) == [10, 9, 7, 4, 1]
    assert scanr(function, []) == []
    assert scanr(function, [1], 2) == [3, 2]
    assert scanr(function, [1], 0) == [1, 0]

    def function(a, b): return b + a
    assert scanr(function, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']

# Generated at 2022-06-23 17:29:59.990676
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = map(lambda x: x**3, range(10))
    ll = LazyList(l)
    with pytest.raises(TypeError):
        len(ll)
    ll2 = LazyList([])
    assert len(ll2) == 0
    assert len(ll2[:]) == 0
    ll3 = LazyList(range(10))
    ll3[9]
    assert len(ll3) == 10


# Generated at 2022-06-23 17:30:05.562633
# Unit test for constructor of class LazyList
def test_LazyList():
    ll = LazyList(range(1, 100, 2))
    assert ll[7] == 15
    assert len(ll) == 50
    assert ll[:10] == list(range(1, 20, 2))
    assert ll[9] == 19

if __name__ == '__main__':
    test_LazyList()



# Generated at 2022-06-23 17:30:08.048449
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    it = iter(r)

    assert isinstance(it, Range)
    assert list(it) == list(range(10))


# Generated at 2022-06-23 17:30:20.292226
# Unit test for function scanl
def test_scanl():
    # Test with initial value
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    # Test without initial value
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    # Test empty iterable:
    assert list(scanl(operator.add, range(0))) == []
    # Test currying:
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == list(scanl(lambda x, y: y + x, ['a', 'b', 'c', 'd']))
    # Test function application order

# Generated at 2022-06-23 17:30:22.218450
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    """
    Unit test for method __len__ of class MapList
    """
    for length in range(1, 5):
        lst = [1] * length
        for func in [lambda x: x + 1, lambda x: x]:
            assert len(MapList(func, lst)) == length

# Generated at 2022-06-23 17:30:31.198633
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # supports indexing and slicing
    r = Range(10)
    assert r[0] == 0
    assert r[-1] == 9
    assert r[2:5] == [2, 3, 4]
    assert r[:5] == [0, 1, 2, 3, 4]
    assert r[-5:] == [5, 6, 7, 8, 9]

    r = Range(10, 20)
    assert r[0] == 10
    assert r[-1] == 19
    assert r[2:5] == [12, 13, 14]
    assert r[:5] == [10, 11, 12, 13, 14]
    assert r[-5:] == [15, 16, 17, 18, 19]

    r = Range(1, 100, 2)
    assert r[0] == 1


# Generated at 2022-06-23 17:30:42.783802
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    m = MapList(lambda x: x * x, [1, 2, 3])
    assert m[0] == 1
    assert m[1] == 4
    assert m[2] == 9
    assert m[-1] == 9
    assert m[-2] == 4
    assert m[-3] == 1
    assert m[0:1] == [1]
    assert m[0:3] == [1, 4, 9]
    assert m[0:5] == [1, 4, 9, 16, 25]
    assert m[0:0] == []
    assert m[1:1] == []
    assert m[1:2] == [4]
    assert m[2:2:1] == []
    assert m[2:2:-1] == [9]

# Generated at 2022-06-23 17:30:53.715654
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(2))) == 2
    with pytest.raises(TypeError):
        len(LazyList(range(2))) > 0



# Generated at 2022-06-23 17:30:56.025002
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert isinstance(iter(Range(1, 10 + 1)), Iterator)



# Generated at 2022-06-23 17:30:57.487232
# Unit test for function drop_until
def test_drop_until():
    list(drop_until(lambda x: x > 5, range(10)))


# Generated at 2022-06-23 17:31:07.037591
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    with pytest.raises(TypeError) as excinfo:
        list(scanl("foo", [1, 2, 3]))
    assert 'scanl() missing 1 required positional argument: \'iterable\'' in str(excinfo.value)
    with pytest.raises(ValueError):
        list(scanl(operator.add, [1], 2, 3))
    with pytest.raises(StopIteration):
        next(scanl(operator.add, []))



# Generated at 2022-06-23 17:31:12.590339
# Unit test for method __next__ of class Range
def test_Range___next__():
    print("test Range.__next__:", end="")
    try:
        r = Range(10)
        for i in range(10):
            assert next(r) == i
        assert StopIteration == type(next(r))
    except AssertionError:
        print("Method __next__ of class Range failed")
        return False
    else:
        print("Method __next__ of class Range passed")
        return True



# Generated at 2022-06-23 17:31:24.895219
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    ml = MapList(lambda x: x * x, a)
    assert (ml[0] == ml[3] == ml[4] == 1)
    assert (ml[1] == ml[2] == 4)
    assert (ml[0:2] == [1, 4])
    assert (ml[2:] == [16, 25])
    assert (ml.index(9) == 2)
    assert (ml.index(25) == 4)
    try:
        ml.index(1)
        assert (False)
    except ValueError:
        pass
    a = [1, 3, 3, 4, 6, 6]
    ml = MapList(lambda x: x * x, a)
    assert (ml.index(4, 3) == 3)

# Generated at 2022-06-23 17:31:31.544781
# Unit test for function scanl
def test_scanl():
    scanl_test = [0, 1, 3, 6, 10]
    assert scanl(operator.add, [1, 2, 3, 4], 0) == scanl_test
    assert scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['a', 'ba', 'cba', 'dcba']
    
test_scanl()



# Generated at 2022-06-23 17:31:40.872626
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    print("Test Range.__iter__")
    for test_case in [
            (list(Range(10)), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]),
            (list(Range(10, 20)), [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]),
            (list(Range(10, 20, 2)), [10, 12, 14, 16, 18]),
            (list(Range(20, 10, -2)), [20, 18, 16, 14, 12]),
    ]:
        assertEqual(test_case[0], test_case[1])


# Generated at 2022-06-23 17:31:50.649369
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(7)[1] == Range(0, 7, 1)[1]
    assert Range(5)[-1] == Range(0, 5, 1)[-1]
    assert Range(5, 10)[-1] == Range(5, 10, 1)[-1]
    assert Range(2, 10, 2)[-1] == Range(2, 10, 2)[-1]
    assert Range(2, 10, 2)[1:6:2] == Range(2, 10, 2)[1:6:2]
    assert Range(4)[::-1] == Range(0, 4, 1)[::-1]
    assert Range(2, 10)[::-1] == Range(2, 10, 1)[::-1]

# Generated at 2022-06-23 17:31:51.983220
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(range(10))
    assert len(l) == 10



# Generated at 2022-06-23 17:31:56.321480
# Unit test for method __next__ of class Range
def test_Range___next__():
    for i in range(2):
        for n in range(1, 10):
            with pytest.raises(StopIteration):
                for j in range(n):
                    next(Range(0))
            for j in range(n):
                assert next(Range(n)) == j
            for j in range(1, n):
                assert next(Range(1, n)) == j
            for j in range(1, n + 1, 2):
                assert next(Range(1, n, 2)) == j

# Generated at 2022-06-23 17:32:08.431788
# Unit test for constructor of class Range
def test_Range():
    # Range(stop)
    r1 = Range(2)
    assert len(r1) == 2
    assert list(r1) == [0, 1]
    assert r1[0] == 0 and r1[1] == 1
    assert r1[0:2] == [0, 1]
    # Range(start, stop)
    r2 = Range(1, 10)
    assert len(r2) == 9
    assert list(r2) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r2[0] == 1 and r2[1] == 2
    assert r2[0:3] == [1, 2, 3]
    # Range(start, stop, step)
    r3 = Range(0, 9, 3)
    assert len(r3)

# Generated at 2022-06-23 17:32:10.720380
# Unit test for constructor of class LazyList
def test_LazyList():
    assert LazyList(range(10)) == range(10)


# Generated at 2022-06-23 17:32:15.855398
# Unit test for constructor of class MapList
def test_MapList():
    lst = MapList(lambda x: x, [1, 2, 3])
    assert len(lst) == 3
    assert lst[0] == 1
    assert lst[1] == 2
    assert lst[2] == 3

test_MapList()



# Generated at 2022-06-23 17:32:19.223461
# Unit test for function take
def test_take():
    for n in range(10):
        for length in range(10):
            result = list(take(n, range(length)))
            assert len(result) == min(n, length)



# Generated at 2022-06-23 17:32:27.319941
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.a = Range(1, 10 + 1)
            self.b = Range(3, 8)
            self.c = Range(3)

        def test_regular(self):
            self.assertEqual(2, self.a[1])
            self.assertEqual(2, self.b[0])

        def test_negative(self):
            self.assertEqual(10, self.a[-1])
            self.assertEqual(5, self.b[-3])
            self.assertEqual(2, self.c[-1])

        def test_slice(self):
            self.assertEqual([1, 2, 3], self.a[:3])
            self.assertEqual

# Generated at 2022-06-23 17:32:33.641704
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    if __name__ == '__main__':
        l1 = MapList(lambda x : x * x, [1, 2, 3, 4, 5])
        l2 = [1, 4, 9, 16, 25]
        for i in range(len(l2)):
            assert l1[i] == l2[i], "Fail"


# Generated at 2022-06-23 17:32:46.384701
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(Range(10)) == list(range(10))
    assert list(Range(1, 10 + 1)) == list(range(1, 10 + 1))
    assert list(Range(1, 11, 2)) == list(range(1, 11, 2))
    assert list(Range(1, 11, -1)) == list(range(1, 11, -1))
    assert list(Range(1, 11, -2)) == list(range(1, 11, -2))
    assert list(Range(1, 11, 4)) == list(range(1, 11, 4))
    assert list(Range(1, 11, -3)) == list(range(1, 11, -3))
    assert list(Range(1, 11, 0)) == list(range(1, 11, 0))

# Generated at 2022-06-23 17:32:56.683553
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zba', 'zcba', 'zdcba']
    assert list(scanl(operator.floordiv, range(1, 4), 1)) == [1, 0, 0, 0]  # 1 // 1 // 2 // 3 == 0



# Generated at 2022-06-23 17:33:00.917899
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(100))
    i = iter(ll)
    a = next(i)
    b = next(i)
    assert ll[2] == 2
    assert i.index == 2
    assert ll[-1] == 99



# Generated at 2022-06-23 17:33:04.173813
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(5))) == 5
    try:
        len(LazyList(range(5)).__iter__())
        assert False
    except Exception as e:
        assert type(e) == TypeError



# Generated at 2022-06-23 17:33:12.845908
# Unit test for constructor of class MapList
def test_MapList():
    l = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert len(l) == 5, "Length of list incorrect."
    assert len(range(*slice(None, len(l)).indices(len(l)))) == 5, "Length of list incorrect."
    assert l[3] == 16, "Indexing incorrect."
    assert l[slice(None, len(l))] == [1, 4, 9, 16, 25], "Slicing incorrect."
    assert l[slice(None, 1)] == [1], "Slicing incorrect."
    assert l[slice(1, 2)] == [4], "Slicing incorrect."

# Generated at 2022-06-23 17:33:19.290350
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    with pytest.raises(ValueError):
        list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 0, 1))



# Generated at 2022-06-23 17:33:25.986249
# Unit test for function drop
def test_drop():
    try:
        list(drop(-1, range(10)))
        assert False
    except ValueError:
        pass
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(3, range(10))) == list(range(3,10))
    assert list(drop(10, range(10))) == []



# Generated at 2022-06-23 17:33:33.046645
# Unit test for constructor of class MapList
def test_MapList():
    def square(x):
        return x * x

    lst = MapList(square, [1, 2, 3])
    assert len(lst) == 3
    assert lst[0] == 1
    assert lst[1] == 4
    assert lst[2] == 9

# Generated at 2022-06-23 17:33:44.852268
# Unit test for function split_by
def test_split_by():
    # Test case 1: criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[], [1, 2], [], [4, 5],
                                                                                             [], [7, 8], []]
    # Test case 2: separator
    assert list(split_by(" Split by: ", separator='.')) == [[' ', 'S', 'p', 'l', 'i', 't', ' ', 'b', 'y', ':', ' ']]

# Generated at 2022-06-23 17:33:52.448085
# Unit test for function scanr
def test_scanr():
    # Test 1
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4]
    # Test 2
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    # Test 3
    assert list(scanr(operator.add, range(10), 1)) == [45, 44, 42, 39, 35, 30, 24, 17, 9, 0, 1]



# Generated at 2022-06-23 17:34:02.292160
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(1, 8), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7]]
    assert list(split_by([-1, 0, 1, 2, 3, 4, 5, 6, 7], criterion=lambda x: x % 3 == 0)) == [[-1, 0], [1, 2], [4, 5], [7]]
    assert list(split_by(range(1, 8), criterion=lambda x: x % 5 == 0)) == [[1, 2, 3, 4], [6, 7]]
    assert list(split_by(range(1, 5), criterion=lambda x: x % 7 == 0)) == [[1, 2, 3, 4]]

# Generated at 2022-06-23 17:34:10.501107
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(0, 0, 1)) == 0
    assert len(Range(0, 1, 1)) == 1
    assert len(Range(0, 1, 2)) == 1
    assert len(Range(0, 2, 2)) == 1
    assert len(Range(0, 3, 2)) == 2
    assert len(Range(0, 2, 1)) == 2
    assert len(Range(1, 3, 1)) == 2
    assert len(Range(2, 10, 2)) == 4

# Generated at 2022-06-23 17:34:18.122541
# Unit test for constructor of class LazyList
def test_LazyList():
    l1 = LazyList(range(0, 10))
    for i in range(10):
        assert l1[i] == i
    for i in l1:
        assert i < 10
    assert l1[:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert l1[:10:2] == [0, 2, 4, 6, 8]
    assert l1[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]



# Generated at 2022-06-23 17:34:22.715295
# Unit test for constructor of class MapList
def test_MapList():
    class Foo:
        def __init__(self, i):
            self.i = i
        def __str__(self):
            return '{}: {}'.format(self.__class__.__name__, self.i)
        def __repr__(self):
            return '{}({})'.format(self.__class__.__name__, self.i)
    f_list = [Foo(i) for i in range(1, 10)]
    s_list = MapList(lambda f: str(f), f_list)
    assert(s_list[1] == "Foo: 1")


# Generated at 2022-06-23 17:34:27.194415
# Unit test for function drop
def test_drop():
    print("-" * 50)
    print("Testing drop")
    n = 4
    assert list(take(n, drop(n, range(4)))) == [4, 5, 6]
    print("Passed!")



# Generated at 2022-06-23 17:34:29.890440
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    with pytest.raises(TypeError):
        iter(MapList(lambda x: x * x, [])) == None

# Generated at 2022-06-23 17:34:34.721769
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, [])) == []
test_chunk()



# Generated at 2022-06-23 17:34:38.425611
# Unit test for constructor of class LazyList
def test_LazyList():
    lazy_list1 = LazyList(range(3))
    lazy_list2 = LazyList([1, 2, 3])
    assert isinstance(lazy_list1, LazyList)
    assert isinstance(lazy_list2, LazyList)


# Generated at 2022-06-23 17:34:41.737043
# Unit test for function take
def test_take():
    assert list(take(-1, range(10))) == []
    assert list(take(0, range(10))) == []
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(20, range(10))) == list(range(10))
test_take()

# Generated at 2022-06-23 17:34:50.666684
# Unit test for function drop
def test_drop():
    
    assert list(drop(0, range(5))) == list(range(5))
    assert list(drop(2, range(5))) == [2, 3, 4]
    
    try:
        list(drop(-5, range(5)))
        raise AssertionError()
    except ValueError:
        pass
    
    assert list(drop(5, range(5))) == []
    assert list(drop(10, range(5))) == []
    
    assert list(drop(1, [])) == []
    assert list(drop(10, [])) == []


# Generated at 2022-06-23 17:34:56.280971
# Unit test for function scanl
def test_scanl():
   assert list(scanl(operator.add,[1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
   assert list(scanl(lambda s, x: x + s,['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-23 17:35:05.973831
# Unit test for constructor of class Range
def test_Range():
    a = Range(5)
    assert a.length == 5
    assert a.l == 0
    assert a.r == 5
    assert a.step == 1

    a = Range(5, 20)
    assert a.length == 15
    assert a.l == 5
    assert a.r == 20
    assert a.step == 1

    a = Range(5, 20, 2)
    assert a.length == 7
    assert a.l == 5
    assert a.r == 20
    assert a.step == 2

    a = Range(5, 10, 2)
    assert a.length == 2
    assert a.l == 5
    assert a.r == 10
    assert a.step == 2

    a = Range(0, 0, 2)
    assert a.length == 0
    assert a.l == 0
   

# Generated at 2022-06-23 17:35:14.945012
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Test case 1
    # Test case 1.1
    try:
        r = Range(2, 5)
        assert next(r) == 0
    except:
        assert False
    # Test case 1.2
    try:
        r = Range(0, 5)
        assert next(r) == 0
    except:
        assert False
    # Test case 2
    # Test case 2.1
    try:
        r = Range(0, 5)
        for i in range(5):
            next(r)
        next(r)
    except StopIteration:
        pass
    except:
        assert False
    # Test case 2.2

# Generated at 2022-06-23 17:35:20.359314
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert len(r) == 10
    r = Range(1, 10 + 1)
    assert len(r) == 10
    r = Range(1, 11, 2)
    assert len(r) == 5
    assert len(list(r)) == 5



# Generated at 2022-06-23 17:35:25.322736
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:35:28.282648
# Unit test for function chunk
def test_chunk():
  chunks = chunk(3, range(10))
  #print(list(chunks))
  assert list(chunks) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-23 17:35:40.424915
# Unit test for function scanl
def test_scanl():
    from operator import add
    from random import randint, shuffle
    assert list(scanl(add, [])) == []
    assert list(scanl(add, [1])) == [1]
    assert list(scanl(add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    for _ in range(100):
        vec = [randint(-100, 100) for _ in range(randint(1, 10))]

# Generated at 2022-06-23 17:35:45.501708
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import random

    it = iter(range(100))
    for _ in range(100):
        n = random.randint(0, 10)
        assert list(take(n, it)) == list(take(n, LazyList(range(100))))
    assert list(it) == list(LazyList(range(100)))



# Generated at 2022-06-23 17:35:50.746998
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    l = range(10)
    ml = MapList(lambda x: x % 2, l)
    assert ml[0] == 0
    assert ml[2] == 0
    assert ml[-1] == 1
    assert len(ml) == 10
    assert ml[1:3] == [1, 0]
    assert ml[5:] == [1, 0, 1, 0, 1]


# Generated at 2022-06-23 17:35:54.501773
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(10, range(5))) == []
    try:
        drop(-1, range(5))
        assert False
    except ValueError:
        pass


# Generated at 2022-06-23 17:36:06.455389
# Unit test for constructor of class Range
def test_Range():
    # Range(stop)
    assert list(Range(0)) == []
    assert list(Range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(10)) == list(range(10))

    # Range(start, stop)
    assert list(Range(1, 10)) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(1, 10)) == list(range(1, 10))
    
    # Range(start, stop, step)
    assert list(Range(1, 11, 2)) == [1, 3, 5, 7, 9]
    assert list(Range(1, 11, 2)) == list(range(1, 11, 2))
    
test_Range()

# Generated at 2022-06-23 17:36:17.727372
# Unit test for function split_by
def test_split_by():
    # Empty case, separator
    assert list(split_by("", separator=5)) == list(split_by("", separator=5, criterion=lambda x: x == 5)) == []
    assert list(split_by("", empty_segments=True, separator=5)) == []

    # Empty case, criterion
    def always_true(x: Any) -> bool:
        return True
    assert list(split_by("", criterion=always_true)) == []
    assert list(split_by("", empty_segments=True, criterion=always_true)) == [[]]
    assert list(split_by("", empty_segments=False, criterion=always_true)) == []

    # Non-empty case, separator

# Generated at 2022-06-23 17:36:24.690011
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:36:28.728286
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x * y, [1, 2, 3])) == [1, 2, 6]
    assert list(scanl(lambda x, y: x * y, [1, 2, 3], 1)) == [1, 1, 2, 6]



# Generated at 2022-06-23 17:36:33.570007
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    x = MapList(lambda x: x * x, [2, 3, 4, 5, 6])
    assert x[0] == 4
    assert x[-1] == 36
    assert x[2:4] == [16, 25]

# Generated at 2022-06-23 17:36:37.437336
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    def f(x): return x + 1
    lst = MapList(f, [1, 2, 3, 4])
    assert len(lst) == 4


# Generated at 2022-06-23 17:36:43.147118
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    a = LazyList(range(10))
    assert list(a) == list(range(10))
    assert list(a) == list(range(10))  # test if the same iterator behaves correctly
    a = LazyList(range(10))
    b = iter(a)
    assert list(b) == list(range(10))
    assert list(a) == list(range(10))  # the original list should not be exhausted by the iterator

# Generated at 2022-06-23 17:36:44.071290
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    pass



# Generated at 2022-06-23 17:36:49.085162
# Unit test for function take
def test_take():
    assert list(take(0, range(1000000))) == []
    assert list(take(1, ())) == []
    assert list(take(5, range(1000000))) == list(range(5))
    assert list(take(1000000, range(5))) == list(range(5))



# Generated at 2022-06-23 17:36:59.073214
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(-1, range(10))) == []
    assert list(chunk(3, [])) == []



# Generated at 2022-06-23 17:37:03.754364
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(5)
    assert(r[2] == 2)
    assert(r[-2] == 3)
    assert(r[:2] == [0, 1])
    assert(r[2:] == [2, 3, 4])
    assert(r[1:4:2] == [1, 3])
    assert(r[::-1] == [4, 3, 2, 1, 0])



# Generated at 2022-06-23 17:37:07.901992
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 10, 2)
    assert list(r) == [1, 3, 5, 7, 9]
    assert list(r) == [1, 3, 5, 7, 9]


# Generated at 2022-06-23 17:37:12.405777
# Unit test for function take
def test_take():
    assert list(take(-1, range(10))) == []
    assert list(take(0, range(10))) == []
    assert list(take(1, range(10))) == [0]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(100, range(10))) == list(range(10))



# Generated at 2022-06-23 17:37:19.980945
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    v = MapList(lambda x: x * 2, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

    # check __getitem__ is working correctly
    assert v[0] == 2
    assert v[1] == 4
    assert v[2] == 6
    assert v[3] == 8
    assert v[4] == 10
    assert v[5] == 12
    assert v[6] == 14
    assert v[7] == 16
    assert v[8] == 18
    assert v[9] == 20
    assert v[:2] == [2, 4]
    assert v[:0] == []
    assert v[:-1] == [2, 4, 6, 8, 10, 12, 14, 16, 18]