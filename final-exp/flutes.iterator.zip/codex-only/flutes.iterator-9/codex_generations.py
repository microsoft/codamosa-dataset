

# Generated at 2022-06-23 17:27:24.682208
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(10))
    assert list(ll) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(ll[:]) == list(ll)
    assert list(ll[::2]) == [0, 2, 4, 6, 8]
    assert list(ll[2:4]) == [2, 3]
    assert list(ll[3:8:3]) == [3, 6]
    assert ll[0] == 0
    assert ll[5] == 5
    assert ll[9] == 9

# Generated at 2022-06-23 17:27:30.982175
# Unit test for function scanr
def test_scanr():
    def test1(func, expected):
        xs = [1, 2, 3, 4]
        assert scanr(func, xs) == expected
        return True

    assert test1(operator.add, [10, 9, 7, 4, 0])
    assert test1(lambda s, x: x + s, ['abcd', 'bcd', 'cd', 'd'])
    return True

test_scanr()


# Generated at 2022-06-23 17:27:38.546711
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(3))) == [0, 1, 2]
    assert list(drop(1, range(3))) == [1, 2]
    assert list(drop(2, range(3))) == [2]
    assert list(drop(3, range(3))) == []
    assert list(drop(4, range(3))) == []
    assert list(drop(5, range(3))) == []
    assert list(drop(-1, range(3))) == [0, 1, 2]
    assert list(drop(-2, range(3))) == [0, 1, 2]
    assert list(drop(-3, range(3))) == [0, 1, 2]
    assert list(drop(-4, range(3))) == [0, 1, 2]

# Generated at 2022-06-23 17:27:43.100572
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0,1,2], [3,4,5], [6,7,8], [9]]
test_chunk()



# Generated at 2022-06-23 17:27:52.203794
# Unit test for function take
def test_take():
    # Test n=0
    assert list(take(0, range(10))) == []
    # Test n > 0
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    # Test n < 0
    try:
        take(-1, [])
        assert False
    except ValueError:
        assert True
    # Test iteration exhaustion
    assert list(take(100, [1])) == [1]
    assert list(take(1, [1])) == [1]
    assert list(take(0, [1])) == []
test_take()



# Generated at 2022-06-23 17:27:56.832140
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(3, range(10))) == list(range(3, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(-1, range(10))) == []
    assert list(drop(10, range(-10, 10))) == list(range(-5, 10))



# Generated at 2022-06-23 17:28:01.298692
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    l = [[1, 2, 3], [4, 5, 6]]
    assert len(MapList(sum, l)) == len(l)


# Generated at 2022-06-23 17:28:04.782159
# Unit test for function drop_until
def test_drop_until():
    """Test the drop_until() function"""
    iterable = range(10)
    func = lambda x: x > 5
    assert list(drop_until(func, iterable)) == [6, 7, 8, 9]


# Generated at 2022-06-23 17:28:07.024134
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]


# Generated at 2022-06-23 17:28:12.628719
# Unit test for function scanl
def test_scanl():
    # First parameter is the function to apply
    func = lambda s, x: x + s
    # Second parameter is the list of elements to iteratively apply the function to.
    iterable = ['a', 'b', 'c', 'd']
    # Third parameter is the initial value for the accumulator. If not supplied, the first element in the list is used.
    init = 0
    result = list(scanl(func, iterable))
    print(result)



# Generated at 2022-06-23 17:28:13.943023
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(100))) == 100



# Generated at 2022-06-23 17:28:25.108911
# Unit test for constructor of class Range
def test_Range():
    assert Range(10)[0] == 0
    assert Range(10)[-1] == 9
    assert Range(1, 10)[0] == 1
    assert Range(1, 10)[-1] == 9
    assert Range(1, 5, 2)[0] == 1
    assert Range(1, 7, 2)[-1] == 5
    assert Range(1, 7, 2)[1] == 3
    assert Range(1, 7, 2)[-2] == 3
    assert Range(1, 7, 2)[1:3] == [3, 5]
    assert Range(1, 7, 2)[:-1] == [1, 3, 5]
    assert Range(1, 5, 1)[::2] == [1, 3]
    assert Range(5)[: : -1] == [4, 3, 2, 1, 0]


# Generated at 2022-06-23 17:28:29.587267
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    f = lambda x: x + 1
    ml = MapList(f, a)
    assert ml[0] == 2
    assert ml[-1] == 6
    assert ml[1:] == [3, 4, 5, 6]
    assert ml[1:4:2] == [3, 5]

# Generated at 2022-06-23 17:28:33.749390
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([])
    with pytest.raises(TypeError):
        len(lst)
    lst = LazyList([1, 2, 3])
    assert len(list(lst)) == len(lst)



# Generated at 2022-06-23 17:28:41.499279
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    lst = [8, 3, 7, 2]

    # Test with identity
    res = list(MapList(identity, lst))
    assert res == lst

    # Test with square
    res = list(MapList(lambda x: x * x, lst))
    assert res == [64, 9, 49, 4]

    # Test with square of even numbers
    res = list(MapList(lambda x: x * x if x % 2 == 0 else 0, lst))
    assert res == [64, 0, 0, 4]

# Generated at 2022-06-23 17:28:45.705489
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    len(lst)
    with pytest.raises(TypeError):
        len(lst)


# Generated at 2022-06-23 17:28:57.076841
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():

    assert MapList(lambda x: x % 2, [0, 1, 0, 2, 1])(3) == 2
    assert MapList(lambda x: x * 2, [1, 2, 3, 4, 5])([1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert MapList(lambda x: x * 2, [1, 2, 3, 4, 5])([1, 2, 3]) == [2, 4, 6]
    assert MapList(lambda x: x * 2, [1, 2, 3, 4, 5])(1) == 2
    assert MapList(lambda x: x * 2, [1, 2, 3, 4, 5])([0, 1, 2]) == [2, 4, 6]

# Generated at 2022-06-23 17:29:09.534002
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    # Test with non-negative arguments
    # Input assertion
    # Test normal case
    it = Range(3).__iter__()
    # Test __iter__ when the iterable has not been exhausted
    assert next(it) == 0
    assert next(it) == 1
    assert next(it) == 2
    # Test __iter__ when the iterable has been exhausted
    try:
        next(it)
        assert False
    except StopIteration:
        pass
    # Test with negative arguments
    # Input assertion
    # Test normal case
    it = Range(1, 1, -1).__iter__()
    # Test __iter__ when the iterable has not been exhausted
    assert next(it) == 1
    # Test __iter__ when the iterable has been exhausted

# Generated at 2022-06-23 17:29:14.828658
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = LazyList(range(10**6))
    for i in range(5):
        assert i == it.__iter__().__next__()

# Generated at 2022-06-23 17:29:20.525104
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:29:24.124770
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(0, 2)
    count = 0
    for i in r:
        count += 1
        assert i == count - 1
        assert count <= 2
    assert count == 2

# Generated at 2022-06-23 17:29:27.831772
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-23 17:29:32.918853
# Unit test for method __next__ of class Range
def test_Range___next__():
    x = Range(0, 4, 1)
    assert x.__next__() == 0
    assert x.__next__() == 1
    assert x.__next__() == 2
    assert x.__next__() == 3
    try:
        assert x.__next__() == 4
    except StopIteration:
        assert True
    else:
        assert False



# Generated at 2022-06-23 17:29:41.593355
# Unit test for function split_by
def test_split_by():
    for sep in ["a", 1, (1,)]:
        result = list(split_by(["a", "b", "c", "d", "a", "e", "f", "a"], separator=sep))
        assert result == [["b", "c", "d"], ["e", "f"]]
        result = list(split_by(["a", "b", "c", "d", "a", "e", "f", "a"], separator=sep,
                               empty_segments=True))
        assert result == [[], ["b", "c", "d"], ["e", "f"], []]
        result = list(split_by(["b", "c", "d", "e", "f", "a"], separator=sep))

# Generated at 2022-06-23 17:29:45.245764
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(1, 10)) == 9
    assert len(Range(1, 100, 4)) == 24
    assert len(Range(5, 0, -1)) == 5


# Generated at 2022-06-23 17:29:51.242156
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lazy_list = LazyList(range(5))
    assert lazy_list[2] == 2
    assert lazy_list[2:] == [2, 3, 4]
    assert lazy_list[-2:] == [3, 4]
    assert lazy_list[-1:] == [4]
    assert lazy_list[:3] == [0, 1, 2]
    assert lazy_list[:0] == []
    assert lazy_list == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 17:29:57.579316
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    def testfunc():
        list_gen = gen.Gen_list()
        func = next(list_gen)
        list = next(list_gen)
        iter = MapList(func, list).__iter__()
        assert isinstance(iter, Iterator) and all(MapList(func, list)[i] == iter.__next__() for i in range(len(list)))
    for i in range(100):
        testfunc()


# Generated at 2022-06-23 17:30:04.616891
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for i in range(10):
        r = Range(i)
        assert list(r) == list(range(i))
        l = list(r)
        i1 = iter(r)
        i2 = iter(r)
        assert i1 is not i2
        assert list(i1) == l
        assert list(i2) == l
test_Range___iter__()


# Generated at 2022-06-23 17:30:13.160099
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    l = MapList(lambda x: x*x, a)
    assert len(l) == len(a)

    # test single indexing
    assert l[-1] == a[-1]*a[-1]
    assert l[-5] == a[-5]*a[-5]
    assert l[0] == a[0]*a[0]
    assert l[4] == a[4]*a[4]

    # test multiple indexing
    assert l[:3] == [x*x for x in a[:3]]
    assert l[-3:] == [x*x for x in a[-3:]]

# Generated at 2022-06-23 17:30:22.324693
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=lambda x: x == 3)) == []
    assert list(split_by([], separator=3)) == []
    assert list(split_by([3], criterion=lambda x: x == 3)) == [[]]
    assert list(split_by([3], separator=3)) == [[]]
    assert list(split_by([1, 2, 3, 4], criterion=lambda x: x == 3)) == [[1, 2], [4]]
    assert list(split_by([1, 2, 3, 4], separator=3)) == [[1, 2], [4]]
    assert list(split_by([0, 1, 2, 3, 4], criterion=lambda x: x == 3)) == [[0, 1, 2], [4]]

# Generated at 2022-06-23 17:30:25.354926
# Unit test for function scanl
def test_scanl():
    expected = [0, 1, 3, 6, 10]
    actual = list(scanl(operator.add, [1, 2, 3, 4], 0))
    assert expected == actual



# Generated at 2022-06-23 17:30:32.362499
# Unit test for constructor of class Range
def test_Range():
    r = Range(1, 10, 2)
    assert r.l == 1
    assert r.r == 10
    assert r.step == 2
    assert r[0] == 1
    assert r[len(r)-1] == 9
    assert len(r) == (9 - 1) // 2 + 1
    assert r[1] == 3
    assert r[-1] == 9
    assert r[:] == list(range(1, 10, 2))
    assert next(iter(r)) == 1
    assert len(r[0:100]) == len(r)

if __name__ == "__main__":
    test_Range()

# Generated at 2022-06-23 17:30:42.397949
# Unit test for method __next__ of class Range
def test_Range___next__():
    x = Range(10)
    # Unit test for method __next__ of class Range
    print('Testing __next__ of Range')
    assert [next(x) for i in range(10)] == list(range(10))
    x = Range(10, 15)
    assert [next(x) for i in range(5)] == list(range(10, 15))
    x = Range(10, 15, 2)
    assert [next(x) for i in range(3)] == list(range(10, 15, 2))
    x = Range(10, 15, 2)
    try:
        next(x)
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-23 17:30:49.037836
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst: List[int] = [0, 1, 2, 3, 4, 5]
    assert MapList(lambda x: x * x, lst)[1] == 1
    assert MapList(lambda x: x * x, lst)[-3] == 4
    assert MapList(lambda x: x * x, lst)[1:4] == [1, 4, 9]
    assert MapList(lambda x: x * x, lst)[1::2] == [1, 9, 25]

# Generated at 2022-06-23 17:31:01.400057
# Unit test for method __next__ of class Range
def test_Range___next__():
    import unittest
    class test_Range___next___TestCase(unittest.TestCase):
        def test_should_raise_StopIteration_after_end_index(self):
            r = Range(1, 3)
            self.assertEqual(next(r), 1)
            self.assertEqual(next(r), 2)
            with self.assertRaises(StopIteration):
                next(r)
        def test_should_support_negative_step(self):
            r = Range(10, 0, -1)
            self.assertEqual(next(r), 10)
            self.assertEqual(next(r), 9)
    unittest.main(module="test_Range", exit=False)

# Generated at 2022-06-23 17:31:07.786778
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

test_scanl()



# Generated at 2022-06-23 17:31:13.024499
# Unit test for method __next__ of class Range
def test_Range___next__():
    range1 = Range(10)
    iter1 = iter(range1)
    val = 0
    while True:
        try:
            val = next(iter1)
        except StopIteration:
            assert val == 9
            break
        assert val == range1[val]



# Generated at 2022-06-23 17:31:20.745524
# Unit test for constructor of class Range
def test_Range():
    for i in range(0, 4):
        assert Range(i) == [0] * i
        assert Range(i, 0) == []
        assert Range(1, i) == list(range(1, i))
        assert Range(1, i, 2) == list(range(1, i, 2))
    assert Range(0, 0) == []
    assert Range(1, 0) == []


# Generated at 2022-06-23 17:31:28.738521
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x**2, [1,2,3,4,5,6] )
    assert lst[0] == 1
    assert lst[1] == 4
    assert lst[5] == 36
    assert [x for x in lst[1:5]] == [4,9,16,25]
    assert lst[0::2] == [1, 9, 25]
    assert lst[1::2] == [4, 16, 36]
    assert lst[::-1] == [36, 25, 16, 9, 4, 1]
    assert lst[-4:4:-1] == [16, 9, 4]
test_MapList___getitem__()

# Generated at 2022-06-23 17:31:35.715170
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList([1, 2, 3]).__iter__()) == [1, 2, 3]
    assert list(LazyList([1, 2, 3]).__iter__()) == [1, 2, 3]
    assert list(LazyList([1, 2, 3]).__iter__()) == [1, 2, 3]



# Generated at 2022-06-23 17:31:47.344739
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for expected, idx in [
        ([1, 4, 9], slice(0, 3, None)),
        ([2, 3, 5], slice(1, 3, None)),
        ([1, 4, 9], slice(0, 3, 1)),
        ([2, 5], slice(1, 4, 2)),
        ([1, 4, 9], slice(None, 3, None)),
        ([1, 2, 4], slice(0, None, 2)),
        ([2, 3, 5, 6], slice(None, None, None)),
        (1, 0),
        (9, 2),
        (2, 1)]:
        actual = MapList(lambda x: x ** 2, [1, 2, 3, 4, 5])[idx]

# Generated at 2022-06-23 17:31:50.865268
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    pytest.assume(isinstance(Range(1), Iterable))
    pytest.assume(not isinstance(Range(1), Iterator))
    pytest.assume(isinstance(Range(1).__iter__(), Iterator))

# Generated at 2022-06-23 17:31:52.099373
# Unit test for method __len__ of class Range
def test_Range___len__():
    print(len(Range(1, 3)))


# Generated at 2022-06-23 17:31:53.986408
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(1000000)))[0] == 5


# TODO: Write tests

# Generated at 2022-06-23 17:32:02.260310
# Unit test for constructor of class MapList
def test_MapList():
    l = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert(l[0] == 1)
    assert(l[1] == 4)
    assert(l[-1] == 25)
    assert(l[1:3] == [4, 9])
    assert(len(l) == 5)
    assert(list(l) == [1, 4, 9, 16, 25])



# Generated at 2022-06-23 17:32:09.961551
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(1, 10))
    assert lst[0] == 1
    assert len(lst) == 9
    assert lst[-1] == 9
    assert len(lst) == 9
    assert list(lst[::2]) == [1, 3, 5, 7, 9]
    assert len(lst) == 9
    assert list(lst[5:]) == [6, 7, 8, 9]
    assert len(lst) == 9
    assert list(lst) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert len(lst) == 9
test_LazyList___getitem__()



# Generated at 2022-06-23 17:32:22.182958
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.mul, [1, 2, 3, 4])) == [1, 1, 2, 6]
    assert list(scanl(operator.mul, [1, 2, 3, 4], 1)) == [1, 1, 2, 6]
    assert list(scanl(operator.mul, [2, 3, 4])) == [2, 6, 24]
    assert list(scanl(operator.mul, [2, 3, 4], 1)) == [1, 2, 6, 24]
    assert list(scanl(operator.mul, [])) == []
    assert list(scanl(operator.mul, [], 1)) == [1]

# Generated at 2022-06-23 17:32:26.788929
# Unit test for constructor of class Range
def test_Range():
    range_test = Range(0, 5)
    range_test = Range(0, 5, 1)
    range_test = Range(0)
    try:
        range_test = Range()
        assert False
    except ValueError:
        pass


# Generated at 2022-06-23 17:32:30.321482
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(-10, 10)) == 20
    assert len(Range(-10, 10, 2)) == 10
    assert len(Range(-10, 10, 3)) == 7


# Generated at 2022-06-23 17:32:34.945231
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    MapList(lambda x: x * x, a)
    MapList(lambda i: a[i] * b[i], Range(len(a)))

# Generated at 2022-06-23 17:32:46.521118
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(10, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(10, [])) == []
    assert list(chunk(0, [])) == []
test_chunk()


# Generated at 2022-06-23 17:32:49.929926
# Unit test for method __next__ of class Range
def test_Range___next__():
    try:
        r = Range(5)
        for i in range(5):
            assert r.__next__() == i
    except:
        assert False

# Generated at 2022-06-23 17:32:52.869446
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    assert [next(r) for _ in range(10)] == list(range(1, 10 + 1))

# Generated at 2022-06-23 17:32:55.809087
# Unit test for function drop_until
def test_drop_until():
    a = list(range(2, 10))
    b = list(drop_until(lambda x: x >= 5, a))
    assert b == [5, 6, 7, 8, 9]



# Generated at 2022-06-23 17:33:01.489582
# Unit test for function drop
def test_drop():
    assert list(drop(2, range(10))) == [2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop(0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop(10, range(10))) == []
# Test for function drop



# Generated at 2022-06-23 17:33:10.107377
# Unit test for function drop
def test_drop():
    assert list(drop(-1, [1,2,3,4])) == [1,2,3,4]
    assert list(drop(0, [1,2,3,4])) == [1,2,3,4]
    assert list(drop(1, [1,2,3,4])) == [2,3,4]
    assert list(drop(2, [1,2,3,4])) == [3,4]
    assert list(drop(3, [1,2,3,4])) == [4]
    assert list(drop(4, [1,2,3,4])) == []
    assert list(drop(5, [1,2,3,4])) == []
    assert list(drop(-1, [])) == []

# Generated at 2022-06-23 17:33:14.343285
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
test_chunk()



# Generated at 2022-06-23 17:33:20.347255
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda s, x: x + str(s), [])) == []
    assert list(scanl(lambda s, x: x + str(s), [1])) == [1]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'e')) == ['e', 'ea', 'eba', 'ebca', 'ebcda']
    assert list(scanl(operator.add, range(5))) == [0, 1, 3, 6, 10]



# Generated at 2022-06-23 17:33:26.275055
# Unit test for function scanl
def test_scanl():
    lst = [1, 2, 3, 4, 5]
    sum_iter = scanl(lambda acc, x: acc + x, lst)
    assert list(sum_iter) == [1, 1 + 2, 1 + 2 + 3, 1 + 2 + 3 + 4, 1 + 2 + 3 + 4 + 5]



# Generated at 2022-06-23 17:33:34.008833
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-23 17:33:35.588447
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10


# Generated at 2022-06-23 17:33:41.044718
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    list_list = [ [], [1, 2, 3], [1, 2, 3, 4, 5, 6] ]
    for list_list_list_list in list_list:
        for list_list_list in list_list_list_list:
            assert len(MapList(lambda x: x * x, list_list_list)) == len(list_list_list)


# Generated at 2022-06-23 17:33:45.760908
# Unit test for constructor of class LazyList
def test_LazyList():
    assert len(LazyList(range(10))) == 10
    assert LazyList(range(10))[:5] == list(range(5))
    assert LazyList(range(10))[5] == 5



# Generated at 2022-06-23 17:33:56.955228
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(5, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(10, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(5, [])) == []
    assert list(chunk(5, [1, 2, 3, 4])) == [[1, 2, 3, 4]]
    assert list(chunk(0, range(5))) == []
    with pytest.raises(ValueError):
        assert list(chunk(-1, range(5))) == []



# Generated at 2022-06-23 17:34:00.690538
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    _func = str
    _lst = [1, -2, 3, -4, 5]

    actual = MapList(_func, _lst).__len__()
    expected = 5
    _assert_equals(actual, expected)



# Generated at 2022-06-23 17:34:04.600374
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    from fractions import Fraction

    lst = MapList(Fraction, [1, 2, 0, 1, 2, 3, 4])
    assert len(lst) == 7

# Generated at 2022-06-23 17:34:09.027154
# Unit test for constructor of class LazyList
def test_LazyList():
    iterable = ["a", "b", "c"]
    lazy_list = LazyList(iterable)
    assert iterable == lazy_list
    for i in range(len(iterable)):
        assert iterable[i] == lazy_list[i]


# Generated at 2022-06-23 17:34:11.498885
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(1, 3 + 1)[1: 2: 1] == [2]


# Generated at 2022-06-23 17:34:16.309740
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:34:20.547706
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    global check_context_dict
    try:
        assert len(MapList(lambda x: x * x, [1, 2, 3])) == 3
        assert all(isinstance(x, int) for x in MapList(lambda x: x * x, [1, 2, 3]))
        assert all(isinstance(x, int) for x in MapList(lambda x: x * x, [1, 2, 3]).__iter__())
    except Exception as e:
        check_context_dict['test_MapList___iter__'] = str(e)

# Generated at 2022-06-23 17:34:30.433137
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    # Test of instance MapList(<function <lambda> at 0x7f5d75e5f840>, [1, 2, 3, 4, 5])
    assert len(MapList(lambda elem: elem, [1, 2, 3, 4, 5])) == 5


    # Test of instance MapList(<function <lambda> at 0x7f5d75e5f840>, [1, 2, 3, 4, 5])
    assert len(MapList(lambda elem: elem * elem, [1, 2, 3, 4, 5])) == 5




# Generated at 2022-06-23 17:34:38.209876
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(0))) == 0
    try:
        len(LazyList(range(1)))
    except TypeError:
        pass
    else:
        raise AssertionError('Expected TypeError')
    # Test for infinite iterator
    try:
        len(LazyList(itertools.count()))
    except TypeError:
        pass
    else:
        raise AssertionError('Expected TypeError')

# Generated at 2022-06-23 17:34:40.506387
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    r = Range(1,10 + 1)
    assert r[0] == 1
    r = Range(1,11,2)
    assert r[0] == 1

# Generated at 2022-06-23 17:34:51.149561
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    try:
        split_by(range(10), criterion=lambda x: x % 3 == 0, separator=0)
    except ValueError:
        pass
    try:
        split_by(range(10))
    except ValueError:
        pass



# Generated at 2022-06-23 17:34:56.949368
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(3,3)) == [3]
    assert list(Range(3,3,1)) == [3]
    assert list(Range(3,3,2)) == [3]
    assert list(Range(3,2)) == []
    assert list(Range(3,2,1)) == []
    assert list(Range(3,2,2)) == []


# Generated at 2022-06-23 17:35:00.585410
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x * x, [1, 2, 3])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3])[1:3] == [4, 9]


# Generated at 2022-06-23 17:35:12.884465
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import pytest
    from hypothesis import given
    import hypothesis.strategies as st

    @given(st.lists(st.integers()))
    def test_LazyList___getitem___with_slice(xs):
        lst = LazyList(xs)
        for start in range(-1, len(xs) + 1):
            for stop in range(start, len(xs) + 1):
                for step in [-2, -1, 1, 2]:
                    with pytest.raises(TypeError) as exc_info:
                        len(lst[start:stop:step])
                    assert "__len__ is not available" in str(exc_info.value)
                for step in [None]:
                    ys = xs[start:stop:step]
                    zs = lst[start:stop:step]


# Generated at 2022-06-23 17:35:14.554803
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x * 2, range(3))) == [0, 2, 4]

# Generated at 2022-06-23 17:35:19.806509
# Unit test for constructor of class LazyList
def test_LazyList():
    x = range(10)
    a = LazyList(x)
    assert not a.exhausted
    assert isinstance(a.iter, type(x))
    assert len(a.list) == 0
    # given an empty iterable
    x = iter(range(0))
    a = LazyList(x)
    assert a.exhausted
    assert a.iter is None
    assert len(a.list) == 0


# Generated at 2022-06-23 17:35:23.869605
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-23 17:35:32.096374
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[-1] == Range(10)[1] == Range(10)[9] == 9
    assert Range(10)[0] == Range(10)[-10] == 0
    assert Range(10)[1:5:2] == [1, 3]
    assert Range(10)[1:5][2] == 3
    assert Range(10)[:5] == [0, 1, 2, 3, 4]
    assert Range(10)[5:] == [5, 6, 7, 8, 9]
    assert Range(10)[:5:2] == [0, 2, 4]
    assert Range(10)[5::-1] == [5, 4, 3, 2, 1, 0]
    assert Range(10)[5:10:11] == []

# Generated at 2022-06-23 17:35:41.747027
# Unit test for function split_by
def test_split_by():
    assert list(split_by("a;b;c;d", separator=';')) == [['a'], ['b'], ['c'], ['d']]
    assert list(split_by("", separator=';')) == []
    assert list(split_by(";", empty_segments=True, separator=';')) == [[], []]
    assert list(split_by(";;", empty_segments=True, separator=';')) == [[], [], []]
    assert list(split_by("a", separator=';')) == [['a']]
    assert list(split_by("a;", separator=';')) == [['a'], []]

# Generated at 2022-06-23 17:35:52.058758
# Unit test for constructor of class Range
def test_Range():
    assert(Range(10)[2] == 2)
    assert(Range(1, 10 + 1)[2] == 3)
    assert(Range(1, 11, 2)[2] == 5)
    assert(list(Range(10)) == list(range(10)))
    assert(list(Range(1, 10 + 1)) == list(range(1, 10 + 1)))
    assert(list(Range(1, 11, 2)) == list(range(1, 11, 2)))
    assert(len(Range(10)) == 10)
    assert(len(Range(1, 10 + 1)) == 10)
    assert(len(Range(1, 11, 2)) == 5)

# Generated at 2022-06-23 17:36:00.881001
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

test_split_by()


# Generated at 2022-06-23 17:36:02.819158
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(5, 10))) == [5, 6, 7, 8, 9]



# Generated at 2022-06-23 17:36:04.669158
# Unit test for constructor of class LazyList
def test_LazyList():
  for i in LazyList(range(100)):
    print(i)


# Generated at 2022-06-23 17:36:09.939703
# Unit test for constructor of class LazyList
def test_LazyList():
    with pytest.raises(TypeError):
        LazyList(None)
    assert list(LazyList(range(1000))) == list(range(1000))
    assert list(LazyList(["a", "b", "c"])) == ["a", "b", "c"]



# Generated at 2022-06-23 17:36:19.018097
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    list = LazyList([1, 2, 3])

    list_iter = iter(list)

    # Check that we got a LazyListIterator
    assert isinstance(list_iter, LazyList.LazyListIterator)

    # Check that the iterator is a weak reference to the list
    assert list_iter.list() is list

    # Check that it can iterate
    assert list(list) == [1, 2, 3]

    # Check that accessing the list only allows us to iterate once,
    # and that it is not impacted by the iterator
    assert list(list) == [1, 2, 3]
    assert list(list_iter) == [1, 2, 3]

    # Check that the iterator exhausts the iterable
    assert list.exhausted



# Generated at 2022-06-23 17:36:26.959271
# Unit test for constructor of class LazyList
def test_LazyList():
    iterable = list(range(100))
    lst = LazyList(iterable)
    assert lst[0] == 0
    assert lst[-1] == 99
    assert list(lst[10:20]) == list(range(10, 20))
    # Test iterator
    assert list(iter(lst[:10])) == list(range(10))
    assert list(iter(lst[::5])) == list(range(0, 100, 5))



# Generated at 2022-06-23 17:36:37.588885
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    """
    Testing method __iter__ with the following cases:
        [0, 5]:
            testing the call of __iter__ on the range [0, 5).
        [0, 5):
            testing the call of __iter__ on the range [0, 5).
        [0, 5, 2]:
            testing the call of __iter__ on the range [0, 5) with step = 2.
        [2, 5, 2]:
            testing the call of __iter__ on the range [2, 5) with step = 2.
        [0, 5, -1]:
            testing the call of __iter__ on the range [0, 5) with step = -1.
        [2, 5, -2]:
            testing the call of __iter__ on the range [2, 5) with step = -2.
    """

    test_range_

# Generated at 2022-06-23 17:36:40.006615
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    map_list = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert len(map_list) == 5


# Generated at 2022-06-23 17:36:48.272880
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [])) == []
    assert list(scanl(lambda x, y: x + y, [1, 2])) == [1, 3]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3], -1)) == [-1, 0, 3, 6]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3], -1, -2)) == [-1, 0, 3, 6]
    assert list(scanl(lambda x, y: x + y, [], -1)) == [-1]
    assert list(scanl(lambda x, y: x + y, ['a', 'b'], 'x')) == ['x', 'xa', 'xab']



# Generated at 2022-06-23 17:36:53.065119
# Unit test for method __next__ of class Range
def test_Range___next__():
    rng = Range(0, 10, 2)
    assert next(rng) == 0
    assert next(rng) == 2
    assert next(rng) == 4
    assert next(rng) == 6
    assert next(rng) == 8
    with pytest.raises(StopIteration):
        next(rng)
    with pytest.raises(StopIteration):
        next(rng)

# Generated at 2022-06-23 17:36:58.433391
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(1, 100000))
    lst[0]
    assert lst[-1] == 99999
    assert lst[500] == 501
    assert isinstance(lst[:], list)
    assert lst[:] == list(range(1, 100000))



# Generated at 2022-06-23 17:36:59.639120
# Unit test for constructor of class LazyList
def test_LazyList():
    assert LazyList(range(10)) is not None
    return

# Generated at 2022-06-23 17:37:01.256081
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    seq = range(4)
    for i in range(4):
        assert next(MapList(abs, seq)) == i



# Generated at 2022-06-23 17:37:12.974867
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    class LegalCases(TestCase):
        def test_int(self):
            self.assertListEqual(MapList(lambda x: x * x, [1, 2, 3, 4, 5])[::-1], [25, 16, 9, 4, 1])
            self.assertListEqual(MapList(lambda i: i * i, Range(10))[::-1], list(map(lambda x: x * x, range(10)))[::-1])
        def test_slice(self):
            self.assertListEqual(MapList(lambda x: x * x, [1, 2, 3, 4, 5])[::2], [1, 9, 25])

# Generated at 2022-06-23 17:37:21.885566
# Unit test for function scanl
def test_scanl():
    for test in [
        (operator.add, [1, 2, 3, 4], 0, [0, 1, 3, 6, 10]),
        (lambda s, x: x + s, ['a', 'b', 'c', 'd'], ['a', 'ba', 'cba', 'dcba'])
    ]:
        assert list(scanl(*test[:-1])[-len(test[-1]):]) == test[-1], 'Fail on: {}'.format(test)

