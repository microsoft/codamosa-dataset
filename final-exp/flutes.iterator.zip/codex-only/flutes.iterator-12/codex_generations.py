

# Generated at 2022-06-23 17:27:28.806514
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(5))
    assert list(lst) == [0, 1, 2, 3, 4]
    assert list(lst) == [0, 1, 2, 3, 4]
    assert list(LazyList(range(0))) == []
    assert list(LazyList([1, 2, 3, 4])[:3]) == [1, 2, 3]
    assert list(LazyList([1, 2, 3, 4])[:3]) == [1, 2, 3]
    assert list(LazyList([1, 2, 3, 4])[:-1]) == [1, 2, 3]
    assert list(LazyList([1, 2, 3, 4])[:-1]) == [1, 2, 3]

# Generated at 2022-06-23 17:27:30.827950
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList(range(10))
    assert a[5] == 5
    assert a[20] == 9


# Generated at 2022-06-23 17:27:33.937642
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(5, 15)) == 10
    assert len(Range(5, 15, 2)) == 5
    assert len(Range(5, 15, -1)) == 0
    assert len(Range(5, 15, 0)) == 0

# Generated at 2022-06-23 17:27:37.819685
# Unit test for constructor of class LazyList
def test_LazyList():
    x = LazyList(range(10))
    #print("Hello")
    print("Testing `__init__` of class LazyList")
    assert isinstance(x, LazyList)
    assert isinstance(x, Sequence)


# Generated at 2022-06-23 17:27:41.140556
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    # range_1 = Range(10)
    # # YOUR CODE HERE
    # raise NotImplementedError()
    pass


# Generated at 2022-06-23 17:27:51.208864
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by("Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    try:
        list(split_by("Split by: ", empty_segments=True))
    except Exception as e:
        assert "Exactly one of `criterion` and `separator` should be specified" in str(e)

# Generated at 2022-06-23 17:27:59.744422
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    class Test:
        def __init__(self, val, *args):
            self.val = val
            self.args = args

        def test(self, arg):
            arg(*self.args)

    for obj in [None, True, False, 1, 1.0, '1', (1, 1.0, '1'), [1, 1.0, '1'], {1, 1.0, '1'}, {1: 1, 1.0: 1.0, '1': '1'}]:
        r = MapList(lambda x: [x, x], [obj] * 2)
        assert list(r) == [[obj, obj]] * 2

        t = Test(obj)
        r = MapList(t.test, [[]] * 2, [[1], [1, 2]])
        assert list(r)

# Generated at 2022-06-23 17:28:07.976962
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 2, [1, 2, 3, 4, 5])) == [3, 4, 5]
    assert list(drop_until(lambda x: x > 2, [1, 2, 2, 4])) == [4]
    assert list(drop_until(lambda x: x > 2, [1, 2, 2, 2])) == []
    assert list(drop_until(lambda x: x > 2, [])) == []


# Generated at 2022-06-23 17:28:15.443894
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-23 17:28:19.862351
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1,2,3], 0) == [6, 5, 3, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:28:30.130456
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(1))) == []
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]

# Generated at 2022-06-23 17:28:39.936693
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8], []]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:28:47.183095
# Unit test for function take
def test_take():
    assert list(take(0, range(42))) == []
    assert list(take(1, range(42))) == [0]
    assert list(take(42, range(42))) == list(range(42))
    assert list(take(100, range(42))) == list(range(42))
    assert list(take(0, "abc")) == []
    assert list(take(1, "abc")) == ["a"]
    assert list(take(2, "abc")) == ["a", "b"]
    assert list(take(3, "abc")) == ["a", "b", "c"]
    assert list(take(4, "abc")) == ["a", "b", "c"]



# Generated at 2022-06-23 17:28:59.300534
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    it = iter([1,2,3,4])
    lst = LazyList(it)
    assert lst[0] == 1
    assert lst[1] == 2
    assert lst[-1] == 4
    assert lst[2:3] == [3]
    assert lst[2:] == [3, 4]
    assert lst[:2] == [1, 2]
    assert lst[:] == [1, 2, 3, 4]
    assert lst[3:3] == []
    assert lst[3:-1] == []
    assert lst[-3:3] == [2, 3]

    assert list(it) == []  # the iterable has been consumed
    assert lst == [1,2,3,4]

# Generated at 2022-06-23 17:29:06.499465
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)
    assert (r == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    r = Range(1, 10 + 1)
    assert (r == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    r = Range(1, 11, 2)
    assert (r == [1, 3, 5, 7, 9])


# Generated at 2022-06-23 17:29:11.416463
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    test_cases = [
        [0, range(10)],
        [10, range(10)],
    ]
    for expected, iterable in test_cases:
        with test(iterable, expected):
            # Test it directly
            assert_equal(len(LazyList(iterable)), expected)

            # Test it indirectly via the List constructor
            assert_equal(List(iterable), list(iterable))

# Generated at 2022-06-23 17:29:16.881136
# Unit test for function drop
def test_drop():
    for n in range(5):
        for xs in [[], [1], [1, 2], [1, 2, 3]]:
            xs = iter(xs)
            assert list(drop(n, xs)) == list(xs)[n:]


# Generated at 2022-06-23 17:29:24.963769
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[8] == 9
    assert r[-1] == 10
    assert r[-2] == 9
    assert [r[0], r[2], r[4], r[6]] == [1, 3, 5, 7]
    assert r[:4] == [1, 2, 3, 4]
    assert r[4:] == [5, 6, 7, 8, 9, 10]
    assert r[1:6] == [2, 3, 4, 5, 6]
    assert r[:6:2] == [1, 3, 5]
    assert r[1:6:2] == [2, 4, 6]
    assert r[::2] == [1, 3, 5, 7, 9]

# Generated at 2022-06-23 17:29:30.324705
# Unit test for function chunk
def test_chunk():
    assert list(chunk(2, [])) == []
    assert list(chunk(2, [1, 2, 3])) == [[1, 2], [3]]
    assert list(chunk(1, [1, 2, 3])) == [[1], [2], [3]]



# Generated at 2022-06-23 17:29:35.990035
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = MapList(lambda x: x * x, [1, 2, 3, 4])
    assert a[2] == 9
    assert a[2] == 9
    assert list(a[1:3]) == [4, 9]
    assert list(a[1:3]) == [4, 9]



# Generated at 2022-06-23 17:29:39.828111
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    # Test with a normal sequence
    lst = list(range(10))
    m = MapList(lambda x: x ** 2, lst)
    assert len(m) == len(lst)
    # Test with an infinite iterator
    assert Iterable(lambda: xrange(10)).map(lambda x: x ** 2).__len__() == 10

# Generated at 2022-06-23 17:29:47.522631
# Unit test for function take
def test_take():
    assert list(take(0, range(1, 5))) == []
    assert list(take(5, range(1, 5))) == [1, 2, 3, 4]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(10, range(11))) == list(range(11))
    assert list(take(10, range(6))) == list(range(6))



# Generated at 2022-06-23 17:29:51.443016
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-23 17:29:54.903546
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

test_scanl()



# Generated at 2022-06-23 17:30:05.964780
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    import numpy as np
    import random
    if __name__ != "__main__":
        return
    n = random.randint(1, 1000)
    lst = [random.randint(1, 10000) for _ in range(n)]
    print(lst)
    print(list(MapList(lambda x: x * 2, lst)))
    print(list(MapList(lambda x: x // 10, lst)))
    print(list(MapList(lambda x: x / 1000, lst)))
    print(list(MapList(lambda x: np.sqrt(x), lst)))

test_MapList___iter__()


# Generated at 2022-06-23 17:30:13.943462
# Unit test for constructor of class LazyList

# Generated at 2022-06-23 17:30:16.072769
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:30:25.444881
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(10)) == [0,1,2,3,4,5,6,7,8,9]
    assert list(Range(1,11,2)) == [1,3,5,7,9]
    assert list(Range(1,11)) == [1,2,3,4,5,6,7,8,9,10]
    assert Range(0,10)[0] == 0
    assert Range(0,10)[-1] == 9
    assert Range(1,11,2)[0] == 1
    assert Range(1,11,2)[0] == 1
    assert Range(0,10)[2:5] == [2,3,4]
    assert Range(0,10)[:5] == [0,1,2,3,4]

# Generated at 2022-06-23 17:30:27.451329
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(4))) == [0, 1, 2, 3]



# Generated at 2022-06-23 17:30:33.542677
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x >= 3, range(10))) == [3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: True, range(10))) == list(range(10))
    assert list(drop_until(lambda x: False, range(10))) == []
    assert list(drop_until(lambda x: x == 'a', 'banana')) == ['a', 'n', 'a', 'n', 'a']
    assert list(drop_until(lambda x: x == 'a', '')) == []
    assert list(drop_until(lambda x: x == 'v', 'apple')) == []



# Generated at 2022-06-23 17:30:39.949523
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: x * 2, [1, 2, 3])) == [2, 4, 6]
    assert MapList(lambda x: x * 2, [1, 2, 3])[2] == 6
    assert MapList(lambda x: x * 2, [1, 2, 3])[0:2] == [2, 4]


# Generated at 2022-06-23 17:30:42.878236
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    if not LazyList([1, 2, 3]).__getitem__(0) == 1:
        raise Exception("expected True, got False")


# Generated at 2022-06-23 17:30:46.913407
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']


# Generated at 2022-06-23 17:30:50.685756
# Unit test for constructor of class LazyList
def test_LazyList():
    arr = [0, 1, 2]
    LazyArr = LazyList(arr)
    for i in range(3):
        assert LazyArr[i] == i



# Generated at 2022-06-23 17:30:59.190402
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [list(range(10))]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
test_chunk()



# Generated at 2022-06-23 17:31:03.628435
# Unit test for method __len__ of class MapList
def test_MapList___len__():
       for _ in range(10):
              _len = random.randint(-10, 10)
              _lst = random.choices([random.randint(-10, 10) for _ in range(_len)])
              assert len(MapList(_lst)) == _len



# Generated at 2022-06-23 17:31:13.753258
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(5)[0] == 0
    assert Range(5)[1] == 1
    assert Range(5)[2] == 2
    assert Range(5)[3] == 3
    assert Range(5)[4] == 4
    assert Range(5, 10)[0] == 5
    assert Range(5, 10)[1] == 6
    assert Range(5, 10)[2] == 7
    assert Range(5, 10)[3] == 8
    assert Range(5, 10)[4] == 9
    assert Range(5, 10, 2)[0] == 5
    assert Range(5, 10, 2)[1] == 7
    assert Range(5, 10, 2)[2] == 9
    assert Range(5, 10, 2)[:0] == []
    assert Range(5, 10, 2)[:1] == [5]


# Generated at 2022-06-23 17:31:20.833312
# Unit test for function take
def test_take():
    assert list(take(5, range(0))) == []
    assert list(take(5, range(1))) == [0]
    assert list(take(5, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
test_take()



# Generated at 2022-06-23 17:31:28.412885
# Unit test for function drop
def test_drop():
    # Test if drop works as specified
    assert list(drop(2, [1,2,3,4])) == [3,4]
    # Test if drop works even if n is larger than length of iterable
    assert list(drop(3, [1,2])) == []
    # Test if drop works for n = 0
    assert list(drop(0, [1,2,3])) == [1,2,3]
    # Test if drop works for n = -1
    try:
        drop(-1, [1,2,3])
    except ValueError:
        print("drop works for n = -1")



# Generated at 2022-06-23 17:31:34.620549
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    for i in range(len(lst)):
        assert m[i] == lst[i] * lst[i]


# Generated at 2022-06-23 17:31:36.448213
# Unit test for constructor of class LazyList
def test_LazyList():
    x = LazyList(range(10))
    for i in x:
        print(i)



# Generated at 2022-06-23 17:31:39.750248
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList(iter([1,2,3,4]))
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3
    assert a[3] == 4

# Generated at 2022-06-23 17:31:46.803705
# Unit test for function drop
def test_drop():
    it = drop(5, range(10))
    assert next(it) == 5
    assert next(it) == 6
    assert list(it) == [7, 8, 9]
    it = drop(0, range(10))
    assert next(it) == 0
    assert next(it) == 1
    assert list(it) == [2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-23 17:31:56.440717
# Unit test for method __len__ of class Range
def test_Range___len__():
    from itertools import count
    from functools import reduce
    from operator import mul
    r = Range(1, 10)
    n = len(r)
    for i in range(1, 10):
        assert len(r[:i]) == i
        assert len(r[i:]) == n - i
        assert len(r) == n
    r = Range(0, 10)
    n = len(r)
    for i in range(1, 10):
        assert len(r[:i]) == i
        assert len(r[i:]) == n - i
        assert len(r) == n
    r = Range(0)
    n = len(r)
    for i in range(0, 10):
        assert len(r[:i]) == i

# Generated at 2022-06-23 17:32:03.507901
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, range(1))) == [[0]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]



# Generated at 2022-06-23 17:32:09.510134
# Unit test for constructor of class Range
def test_Range():
    print("Test range(n)")
    assert Range(10) == range(10)
    print("Test range(n) with indexing")
    assert Range(10)[0] == range(10)[0]
    print("Test range(start, end)")
    assert Range(1, 10+1) == range(1, 10+1)
    print("Test range(start, end) with indexing")
    assert Range(1, 10+1)[0] == range(1, 10+1)[0]
    print("Test range(start, end, step)")
    assert Range(1, 11, 2) == range(1, 11, 2)
    print("Test range(start, end, step) with indexing")
    assert Range(1, 11, 2)[0] == range(1, 11, 2)[0]
    print

# Generated at 2022-06-23 17:32:16.722363
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-23 17:32:19.736396
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-23 17:32:23.565228
# Unit test for method __next__ of class Range
def test_Range___next__():
    range_object = Range(4)
    dict_copy = dict(range_object.__dict__)
    range_object.__next__()
    assert range_object.__dict__ == dict_copy, 'Body of Range.__next__() has been modified'

# Generated at 2022-06-23 17:32:31.163149
# Unit test for constructor of class MapList
def test_MapList():
    # [1, 3, 9]
    assert MapList(lambda x: x * x, MapList(lambda x: x + x, Range(5))) == [1, 3, 9]
    # [1, 3, 9]
    assert MapList(lambda x: x * x, Range(3)) == [1, 3, 9]
    # [1, 3, 9]
    assert MapList(lambda x: x * x, [1, 2, 3]) == [1, 3, 9]

# Generated at 2022-06-23 17:32:36.501549
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5,10))
    assert list(drop(0, range(10))) == list(range(0,10))
    assert list(drop(10, range(10))) == []
    try:
        assert list(drop(-1, range(10)))
        assert False
    except ValueError:
        pass


# Generated at 2022-06-23 17:32:47.068912
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    import bisect
    lst = [random.randrange(1, 10) for _ in range(1000)]
    f = lambda x: x % 100
    mapped = MapList(f, lst)
    for i in range(1000):
        assert f(lst[i]) == mapped[i]
        assert [f(item) for item in lst[i:i + 5]] == mapped[i:i + 5]
        assert [f(item) for item in lst[i:i + 5:2]] == mapped[i:i + 5:2]
    assert [f(item) for item in lst] == list(mapped)
    bisect.bisect_left(mapped, 85)



# Generated at 2022-06-23 17:32:50.647984
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    try:
        test_MapList___getitem___L1
    except NameError:
        class test_MapList___getitem___L1():
            def __getitem__(self, idx: int) -> R:
                pass
    try:
        test_MapList___getitem___L2
    except NameError:
        class test_MapList___getitem___L2(test_MapList___getitem___L1):
            def __getitem__(self, idx: slice) -> List[R]:
                pass
    # check that subclassing is possible
    class _(test_MapList___getitem___L2, MapList[R]):
        pass



# Generated at 2022-06-23 17:32:55.034362
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, [2, 3, 4, 5])) == [[2, 3, 4], [5]]
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]
    assert list(chunk(2, [2, 3, 4, 5, 6, 7])) == [[2, 3], [4, 5], [6, 7]]
    assert list(chunk(0, [2, 3, 4, 5, 6, 7])) == ValueError


# Generated at 2022-06-23 17:33:05.409771
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for _ in range(10):
        lst = [random.randrange(10) for _ in range(10)]
        lst2 = MapList(lambda x: x * 10, lst)
        for i in range(10):
            assert lst2[i] == lst[i] * 10
            assert lst2[i:i + 1] == [lst[i] * 10]
            assert lst2[i:i + 2] == [lst[i] * 10, lst[i + 1] * 10]
        assert lst2[:] == [x * 10 for x in lst]
        assert lst2[::2] == [x * 10 for x in lst[::2]]

# Generated at 2022-06-23 17:33:12.409156
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    for iterable in [[1, 2, 3], [], [1]]:
        lst = LazyList(iterable)
        with pytest.raises(TypeError):
            len(lst)
        iter(lst)
        assert len(lst) == len(iterable)

# Generated at 2022-06-23 17:33:18.605552
# Unit test for function drop_until
def test_drop_until():
    assert tuple(drop_until(lambda x: x > 3, [0, 1, 2, 3, 4, 5])) == (4, 5)
    assert tuple(drop_until(lambda x: x > 3, [])) == ()
    assert tuple(drop_until(lambda x: x > 3, [0, 1, 2, 3, 3, 3])) == ()
    assert tuple(drop_until(lambda x: x > 3, [4, 5, 6, 7])) == (4, 5, 6, 7)
    assert tuple(drop_until(lambda x: x > 3, [0, 1, 2, 3, 3, 3, 4, 5])) == (4, 5)



# Generated at 2022-06-23 17:33:26.514729
# Unit test for function scanl
def test_scanl():
    def add(acc, x):
        return acc + x

    def concat(s, x):
        return x + s

    assert list(scanl(add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(concat, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:33:39.766342
# Unit test for constructor of class Range
def test_Range():
    assert Range(0,10,1)[1]==1
    assert Range(0,10,1)[2]==2
    assert Range(0,10,1)[-1]==9
    assert Range(1,10,1)[4]==5
    assert Range(1,11,1)[-1]==10
    assert Range(1,10,2)[2]==5
    assert Range(1,11,2)[-1]==9
    assert Range(10)[9]==9
    assert Range(1,10)[-1]==9
    assert Range(1,11,2)[-1]==9
    assert Range(1,10)[9]==9
    assert Range(1,10)[-1]==9
    assert Range(1,10)[-2]==8

# Generated at 2022-06-23 17:33:45.293624
# Unit test for function take
def test_take():
    assert list(take(10, range(100))) == list(range(10))
    assert list(take(0, range(100))) == []
    assert list(take(100, range(10))) == list(range(10))
    assert list(take(-1, range(10))) == []


# Generated at 2022-06-23 17:33:55.092013
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from typing import List

    # Test 1
    list_1: List[int] = [1, 2]
    lst = LazyList(list_1)
    assert(lst.__len__() == 2)

    # Test 2
    lst = LazyList(range(1, 10))
    assert(lst.__len__() == 9)

    # Test 3
    lst = LazyList(range(1, 10))
    lst[9]
    assert(lst.__len__() == 10)

    # Test 4
    try:
        lst = LazyList(range(1, 10))
        assert(lst.__len__() == 10)
    except TypeError:
        pass
    else:
        assert(False)




# Generated at 2022-06-23 17:33:57.421239
# Unit test for method __next__ of class Range
def test_Range___next__():
    test_Range = Range(10)
    index = 0
    while True:
        try:
            print(test_Range.__next__())
        except:
            break
        index += 1


# Generated at 2022-06-23 17:33:58.064594
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
  pass

# Generated at 2022-06-23 17:34:01.452506
# Unit test for method __next__ of class Range
def test_Range___next__():
    it = Range(3, 6)  # (start, end)
    assert next(it) == 3
    assert next(it) == 4
    assert next(it) == 5
    assert_raises(StopIteration, next, it)



# Generated at 2022-06-23 17:34:07.338896
# Unit test for function take
def test_take():
    for i in range(10):
        for j in range(10):
            assert list(take(i, range(j))) == list(range(min(i, j)))
    assert list(take(-1, range(5))) == []
    assert list(take(1, [])) == []



# Generated at 2022-06-23 17:34:16.805853
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    tmplist1 = list()
    tmplist2 = list()
    tmplist3 = list()
    tmplist3.append(6)
    tmplist3.append(9)
    tmplist3.append(12)
    tmplist3.append(15)
    tmplist3.append(18)
    tmplist2.append(MapList(squared_func, tmplist1))
    tmplist1.append(1)
    tmplist1.append(2)
    tmplist1.append(3)
    tmplist1.append(4)
    tmplist1.append(5)
    assert tmplist2[0] == tmplist3

# Generated at 2022-06-23 17:34:19.338614
# Unit test for method __next__ of class Range
def test_Range___next__():
    # test __next__: iterator should work properly
    r = Range(1, 10 + 1)
    assert list(r) == list(range(1, 10 + 1))
    r = Range(1, 11, 2)
    assert list(r) == list(range(1, 11, 2))

# Generated at 2022-06-23 17:34:32.181975
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, range(5))) == [10, 9, 7, 4, 0]
    assert list(scanr(operator.add, range(5), initial=100)) == [115, 115, 112, 108, 103]
    assert scanr(operator.add, [1, 2, 3], initial=100) == [106, 103, 101]
    assert scanr(operator.add, [1, 2, 3]) == [6, 5, 3]
    assert list(scanr(lambda s, x: s + [x], [1, 2, 3])) == [[1, 2, 3], [2, 3], [3]]

# Generated at 2022-06-23 17:34:37.133211
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
test_scanl()



# Generated at 2022-06-23 17:34:44.055925
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(12)
    assert isinstance(r[0], int)
    assert isinstance(r[0:10], list)
    assert len(r[0:10]) == 10
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[-10:10] == [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    assert r[0:10:2] == [0, 2, 4, 6, 8, 10]
    assert r[::2] == [0, 2, 4, 6, 8, 10]
    assert r[1:-1] == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert r[-1:-10:-1]

# Generated at 2022-06-23 17:34:45.011605
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    pass

# Generated at 2022-06-23 17:34:54.082392
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0,
                         empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

test_split_by()



# Generated at 2022-06-23 17:35:02.028949
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-23 17:35:07.347102
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(5, 11, 2)) == 5
    with pytest.raises(StopIteration):
        list(Range(5, 11, 2)) == [5, 7, 9]
        next(Range(5, 11, 2))


# Generated at 2022-06-23 17:35:18.803020
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[:] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert Range(1, 10)[:] == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert Range(1, 10, 2)[:] == [1, 3, 5, 7, 9]
    assert Range(10)[0: 10: 1] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert Range(1, 10)[0: 10: 1] == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert Range(1, 10, 2)[0: 10: 1] == [1, 3, 5, 7, 9]

# Generated at 2022-06-23 17:35:25.353531
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lazy_lst = LazyList([1, 2])
    assert list(lazy_lst) == [1, 2]
    assert list(lazy_lst) == [1, 2]
    lazy_lst = LazyList(x for x in range(10 ** 7))
    assert list(islice(lazy_lst, 100)) == list(range(100))


# Generated at 2022-06-23 17:35:33.242609
# Unit test for method __next__ of class Range
def test_Range___next__():
    '''
    Function to test method __next__ of class Range
    '''
    from builtins import range
    from random import randint
    r = Range(randint(0, 1000), randint(0, 1000), randint(1, 100))
    l = list(r)
    assert l == [i for i in range(*(3 if randint(0, 1) == 0 else 2) * (r.l, r.r, r.step))]


# Generated at 2022-06-23 17:35:38.652318
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, range(10))) == [[i] for i in range(10)]
    assert list(chunk(2, range(10))) == [[i, i + 1] for i in range(0, 10, 2)]
    assert list(chunk(3, range(10))) == [[i, i + 1, i + 2] for i in range(0, 10, 3)]



# Generated at 2022-06-23 17:35:43.636589
# Unit test for constructor of class LazyList
def test_LazyList():
    x = iter([1, 2, 3, 4, 5, 6])
    a = LazyList(x)
    assert len(a.list) == 0
    assert a.exhausted == False
    assert a.iter == x
    try:
        assert a[2] == 3
    except TypeError:
        print("Type Error")


# Generated at 2022-06-23 17:35:54.614631
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    for lst in [range(10), range(0), {1, 2, 3, 4, 5}]:
        lazy_lst = LazyList(lst)
        assert len(lazy_lst) == len(lst)

    lazy_lst = LazyList(range(10))
    # Check if an empty __len__ method would be called again
    assert len(lazy_lst) == len(range(10))

    lazy_lst = LazyList(range(10))
    lazy_lst._fetch_until(5)
    # Check if an empty __len__ method would be called again
    assert len(lazy_lst) == len(range(10))
# Test for __getitem__ for LazyList
# (The unit test below is designed to test the entire functionality of this class. It is

# Generated at 2022-06-23 17:36:02.614403
# Unit test for function scanl
def test_scanl():
    l = [1, 2, 3]
    l2 = [1, -1, 0, 1]
    assert list(scanl(lambda x, y: x + y, l2)) == list(scanl(lambda x, y: x - y, l))
    l3 = [1, 2, 4]
    assert list(scanl(lambda x, y: x * y, l3)) == [1, 2, 4, 8]



# Generated at 2022-06-23 17:36:07.280379
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1,2,3,4], 0) == [10,9,7,4,0]
    assert scanr(lambda s, x: x+s, ['a','b','c','d']) == ['abcd', 'bcd', 'cd', 'd']
# Test for scanr
test_scanr()


# Generated at 2022-06-23 17:36:10.825630
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l: LazyList[int] = LazyList(iter(range(10)))
    assert len(l) == 10


# Generated at 2022-06-23 17:36:13.200174
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    myClass = MapList(lambda: 0, [0, 0, 0])
    myClass.__len__()



# Generated at 2022-06-23 17:36:16.175880
# Unit test for function take
def test_take():
    it = take(5, range(1000000))
    assert(next(it)==0)
    assert(next(it)==1)
    assert(next(it)==2)
    assert(next(it)==3)
    assert(next(it)==4)
    try:
        next(it)
        assert(False)
    except StopIteration:
        pass



# Generated at 2022-06-23 17:36:22.382593
# Unit test for function drop
def test_drop():
    i = iter(range(10))
    k = drop(1, i)
    assert next(k) == 1
    assert list(k) == list(range(1, 9))
    try:
        next(k)
        assert False, "drop should be exhausted"
    except StopIteration:
        pass



# Generated at 2022-06-23 17:36:24.797129
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    # TODO: implement unit test of 'MapList.__len__'
    raise NotImplementedError


# Generated at 2022-06-23 17:36:32.406379
# Unit test for constructor of class Range
def test_Range():
    with pytest.raises(ValueError):
        Range()
    with pytest.raises(ValueError):
        Range(1,2,3,4)
    assert list(Range(1)) == [0]
    assert list(Range(1,2)) == [1]
    assert list(Range(1,2,3)) == [1]
    assert list(Range(2,1,3)) == []
    assert list(Range(2,4,3)) == [2]
    assert list(Range(4,1,3)) == []
    assert list(Range(4,2,3)) == [4]
    assert list(Range(1,6,3)) == [1,4]
    assert list(Range(1,8,3)) == [1,4,7]

# Generated at 2022-06-23 17:36:36.601581
# Unit test for function take
def test_take():
    a = range(1000)
    b = take(1000, a)
    for i in range(1000):
        assert a[i] == b[i]



# Generated at 2022-06-23 17:36:45.391171
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(2, 5)
    i = iter(r)
    assert type(i) == Range
    assert next(i) == 2
    assert next(i) == 3
    assert next(i) == 4
    with pytest.raises(StopIteration):
        i.__next__()
    assert list(Range(5)) == [0, 1, 2, 3, 4]
    assert list(Range(1, 5)) == [1, 2, 3, 4]
    assert list(Range(1, 5, 2)) == [1, 3]
    assert list(Range(5, 0, -1)) == [5, 4, 3, 2, 1]
    assert list(Range(5, 0, -2)) == [5, 3, 1]

# Generated at 2022-06-23 17:36:49.862144
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:37:01.536511
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s if x % 2 else s, [1, 2, 3, 4])) == [1, 3, 3, 7]
    assert list(scanl(lambda s, x: x + s, [1, 2, 3, 4])) == [1, 3, 6, 10]



# Generated at 2022-06-23 17:37:09.287478
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
test_scanl()



# Generated at 2022-06-23 17:37:14.205900
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]

    with pytest.raises(ValueError):
        list(chunk(0, range(10)))
    with pytest.raises(ValueError):
        list(chunk(-1, range(10)))



# Generated at 2022-06-23 17:37:19.834049
# Unit test for constructor of class MapList
def test_MapList():
    lst = MapList(lambda x: x + 1, [1,2,3,4,5])
    assert (lst[1] == 2)
    assert (lst[-1] == 6)
    assert (lst[0:3][-1] == 4)
    assert (list(lst) == [2, 3, 4, 5, 6])