

# Generated at 2022-06-23 17:27:20.032444
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(100))
    assert sum(i ** 2 for i in lst) == sum(i ** 2 for i in range(100))

# Generated at 2022-06-23 17:27:25.268120
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(2, "abcd")) == [["a", "b"], ["c", "d"]]
    assert list(chunk(10, "abcd")) == [["a", "b", "c", "d"]]
    assert list(chunk(3, [1,2])) == [[1,2]]



# Generated at 2022-06-23 17:27:34.193073
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    try:
        r[0]
    except:
        print("Fail instance initialization. Check input argument.")
    try:
        r = Range(1, 10 + 1)
    except:
        print("Fail instance initialization. Check input argument.")
    try:
        r = Range(1, 11, 2)
    except:
        print("Fail instance initialization. Check input argument.")
    try:
        r[0]
    except:
        print("Fail implementation of method __getitem__. Check input argument.")
    try:
        r[2]
    except:
        print("Fail implementation of method __getitem__. Check input argument.")
    try:
        r[4]
    except:
        print("Fail implementation of method __getitem__. Check input argument.")

# Generated at 2022-06-23 17:27:45.118202
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zab', 'zabc']
    


# Generated at 2022-06-23 17:27:51.139379
# Unit test for function drop
def test_drop():
    assert list(drop(-5, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop(-1, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop(0, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop(1, range(5))) == [1, 2, 3, 4]
    assert list(drop(2, range(5))) == [2, 3, 4]
    assert list(drop(3, range(5))) == [3, 4]
    assert list(drop(4, range(5))) == [4]
    assert list(drop(5, range(5))) == []
    assert list(drop(6, range(5))) == []



# Generated at 2022-06-23 17:27:55.686703
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_instance = Range(1, 10+1)
    result_slice = range_instance[0:6]
    assert str(result_slice) == "[1, 2, 3, 4, 5]"
    assert isinstance(result_slice, list)
    result_single = range_instance[2]
    assert result_single == 3
    assert isinstance(result_single, int)

# Generated at 2022-06-23 17:28:02.316972
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    rng = Range(0, 10, 2)
    assert rng[1] == 2
    assert rng[-1] == 8
    assert rng[:2] == [0, 2]
    assert rng[::2] == [0, 4, 8]

# Generated at 2022-06-23 17:28:07.134758
# Unit test for constructor of class MapList
def test_MapList():
    import bisect

    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert pos == 3

    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2

# Generated at 2022-06-23 17:28:14.799627
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    list1 = LazyList(range(10))
    first_five = list(take(5, list1))
    assert first_five == list(range(5))

    # Trigger materialization of the rest of the elements
    list(list1)
    assert list1.exhausted and len(list1) == 10
    assert list1[5] == 5



# Generated at 2022-06-23 17:28:17.236410
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:28:25.492484
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(1, 10)
    r2 = Range(1, 10, 2)
    r3 = Range(10)
    assert [1, 3, 5, 7, 9] == [r2[i] for i in range(5)]
    assert [1, 3, 5, 7, 9] == [r1[i] for i in range(5)]
    assert [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] == [r3[i] for i in range(10)]

# Generated at 2022-06-23 17:28:34.672106
# Unit test for function take
def test_take():
  it = take(5, range(1000000))
  for x, y in zip(it, range(5)):
    if (x != y):
        assert 0
  it = take(0, range(1000000))
  if (len(list(it)) != 0):
    assert 0
  it = take(5, [])
  if (len(list(it)) != 0):
    assert 0
  print('\ntest_take passed\n')

#test_take()


# Generated at 2022-06-23 17:28:44.896861
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 11, 2)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    assert r[-1] == 9
    assert r[-3] == 5
    assert r[-5] == 1
    assert r[-6] == 9
    assert r[-7] == 5
    assert r[-2:5:2] == [5, 9]
    assert r[:5:2] == [1, 5, 9]
    assert r[0:5:2] == [1, 5, 9]
    assert r[:6:2] == [1, 5, 9]
    assert r[::2] == [1, 5, 9]
    assert r[2:5] == [5, 9]

# Generated at 2022-06-23 17:28:52.497681
# Unit test for function chunk
def test_chunk():
    assert list(chunk(2, range(10))) == [(0, 1), (2, 3), (4, 5), (6, 7), (8, 9)]
    assert list(chunk(3, range(10))) == [(0, 1, 2), (3, 4, 5), (6, 7, 8), (9,)]
    assert list(chunk(6, range(6))) == [(0, 1, 2, 3, 4, 5)]
    assert list(chunk(6, [])) == []



# Generated at 2022-06-23 17:28:56.167707
# Unit test for function chunk
def test_chunk():
    from itertools import count
    assert list(chunk(3, count(0)))[0] == [0, 1, 2]
    assert list(chunk(3, count(0))[1]) == [3, 4, 5]



# Generated at 2022-06-23 17:28:59.347584
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x + 1, [1, 2, 3])) == [2, 3, 4]

# Generated at 2022-06-23 17:29:04.332979
# Unit test for function scanl
def test_scanl():
    """
    Tests scanl function
    Returns: Boolean value indicating test success or failure
    """
    assert len(list(scanl(operator.add, [1, 2, 3, 4], 0))) == 5
    assert len(list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']))) == 4
    assert len(list(scanl(operator.add, [1, 2, 3, 4]))) == 4

    try:
        list(scanl(operator.add, [1, 2, 3, 4], 0, 0))
        return False
    except ValueError:
        return True


# Generated at 2022-06-23 17:29:12.924192
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Set up state
    a = [1, 2, 3, 4, 5]
    obj = MapList(lambda x: x * x, a)

    # Test the method
    assert obj[0] == 1
    assert obj[1] == 4
    assert obj[2] == 9
    assert obj[3] == 16
    assert obj[4] == 25
    assert obj[-4] == 4
    assert obj[-3] == 9
    assert obj[-2] == 16
    assert obj[-1] == 25
    assert obj[:] == [1, 4, 9, 16, 25]
    assert obj[:2] == [1, 4]
    assert obj[:4] == [1, 4, 9, 16]
    assert obj[1:3] == [4, 9]

# Generated at 2022-06-23 17:29:18.194676
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert LazyList(range(10)).__len__() == 10



# Generated at 2022-06-23 17:29:22.155147
# Unit test for constructor of class LazyList
def test_LazyList():
    test_LazyList = LazyList(range(5))
    assert test_LazyList._fetch_until(5) == None
    assert test_LazyList._fetch_until(-1) == None
    assert test_LazyList._fetch_until(None) == None



# Generated at 2022-06-23 17:29:33.335719
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [2, 3, 4, 5, 6], 1)) == [1, 3, 6, 10, 15, 21]
    assert list(scanl(operator.mul, [2, 3, 4, 5, 6])) == [2, 6, 24, 120, 720]
    assert list(scanl(operator.mul, [2], 3)) == [3, 6]
    assert list(scanl(operator.mul, range(20), 1)) == (
        [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    
#test_scanl()

# Generated at 2022-06-23 17:29:34.924916
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(1000000))) == list(range(5, 1000000))



# Generated at 2022-06-23 17:29:40.768897
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(0))) == 0

    with raises(TypeError):
        assert len(LazyList(range(1))) == 1

# Generated at 2022-06-23 17:29:51.621630
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Test for slice
    assert Range(5)[:2] == [0, 1]
    assert Range(5, 10)[:2] == [5, 6]
    assert Range(5, 10, 3)[:2] == [5, 8]
    assert Range(10, 5, -3)[:2] == [10, 7]
    assert Range(10, 5, -3)[2:4] == [4, 1]
    # Test for index
    # test__getitem__(self: Any, idx: int) -> Any
    assert Range(5)[2] == 2
    assert Range(5, 10)[2] == 7
    assert Range(5, 10, 3)[2] == 11
    assert Range(10, 5, -3)[2] == 1

# Generated at 2022-06-23 17:29:54.610053
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = iter([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    lazy_list = LazyList(it)
    assert list(lazy_list) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-23 17:29:57.688711
# Unit test for function drop
def test_drop():
    r"""
    >>> list(drop(2, [1,2,3,4]))
    [3, 4]
    """



# Generated at 2022-06-23 17:30:07.826448
# Unit test for function scanl
def test_scanl():
    for iterable in (range(10), "abc", []):
        for initial in ('a', None):
            for func in (lambda x, y: y + x, lambda x, y: x - y):
                expected = [func(acc, x) for (acc, x) in zip(scanl(func, iterable, initial), iterable)]
                if initial is None:
                    acc = next(iterable)
                else:
                    acc = initial
                for (actual, x) in zip(scanl(func, iterable, acc), iterable):
                    assert actual == expected.pop(0)
                    acc = func(acc, x)


# Generated at 2022-06-23 17:30:16.381237
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]



# Generated at 2022-06-23 17:30:18.394421
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = range(10)
    ll = LazyList(l)
    assert list(ll) == list(l)



# Generated at 2022-06-23 17:30:22.726235
# Unit test for constructor of class MapList
def test_MapList():
    lst = MapList(lambda x: x*x, [1,2,3,4,5])
    assert lst[2] == 9
    lst = MapList(lambda x: x*x, range(1,6))
    assert lst[2] == 9
    lst = MapList(lambda x: x*x, range(0))
    assert len(lst) == 0
    lst = MapList(lambda x: x*x, range(10, 0, -1))
    assert len(lst) == 10
    lst = MapList(lambda x: x*x, range(10))
    assert lst[2:4] == [4, 9]

# Test for constructor of class MapList
lst = MapList(lambda x: x*x, [1,2,3,4,5])

# Generated at 2022-06-23 17:30:29.354117
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(0, 10, 2)) == 5
    r = Range(0, 100)
    assert len(r) == 100
    assert len(r) == 100
    # Exception thrown
    assert_raises(TypeError, lambda: len(Range(-10, 10)))
    assert_raises(TypeError, lambda: len(Range(-10, 10, 2)))
    assert_raises(TypeError, lambda: len(Range(0, 10, 0)))
    assert_raises(TypeError, lambda: len(Range(0, 10, 2)))


# Generated at 2022-06-23 17:30:30.949024
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    """
    Test case for method __len__ of class LazyList
    """
    pass



# Generated at 2022-06-23 17:30:35.266392
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    with pytest.raises(TypeError):
        (MapList(lambda i: i, [1, 2, 3]))
        MapList(lambda i: i, [1, 2, 3])
        len(None)
        pass

# Generated at 2022-06-23 17:30:47.032763
# Unit test for function drop
def test_drop():
    assert list(drop(2, range(5)))  == [2, 3, 4]
    assert list(drop(2, (3,)))     == [3]
    assert list(drop(2, [3]))      == [3]
    assert list(drop(2, (i for i in (3,)))) == [3]
    assert list(drop(0, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop(-1, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop(5, [])) == []
    assert list(take(0, [])) == []
    assert list(drop(5, [3])) == []
    assert list(drop(3, range(1))) == []

# Generated at 2022-06-23 17:30:54.048023
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    l = MapList(lambda i: a[i] * b[i], Range(len(a)))
    pos = bisect.bisect_left(l, 10)
    assert(pos == 2)



# Generated at 2022-06-23 17:31:05.307507
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[i] for i in range(10)]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]
    assert list(chunk(5, range(10))) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]

# Generated at 2022-06-23 17:31:14.126956
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(20))

    l[0]
    assert l.list == [0]
    l[0:3]
    assert l.list == [0, 1, 2]
    l[0]
    assert l.list == [0, 1, 2]
    l[10]
    assert l.list == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    l[-1]
    assert l.list == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
    l[-5:-2]

# Generated at 2022-06-23 17:31:24.496523
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [0, 1, 2, 3], 0)) == [6, 5, 3, 0, 0]
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], '0')) == ['abcd', 'bcd', 'cd', 'd', '0']



# Generated at 2022-06-23 17:31:26.050043
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    a = MapList(lambda x: 0, [1, 2, 3])
    assert len(a) == 3

# Generated at 2022-06-23 17:31:28.530600
# Unit test for function take
def test_take():
    assert list(take(3, range(100)))==[0, 1, 2]
# Code for debugging
#test_take()



# Generated at 2022-06-23 17:31:37.619322
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b',
                                                                                                                 'y',
                                                                                                                 ':'],
                                                                                []]


# Generated at 2022-06-23 17:31:48.675432
# Unit test for function split_by
def test_split_by():
    it = iter(range(10))
    assert [(1, 2), (4, 5), (7, 8)] == list(split_by(it, criterion=lambda x: x % 3 == 0))
    it = iter(range(10))
    assert [(1, 2), (4, 6, 8)] == list(split_by(it, criterion=lambda x: x % 3 == 0, empty_segments=True))
    it = iter(range(10))
    assert [(1, 2), (4, 5), (7, 8)] == list(split_by(it, separator=3))
    it = iter(range(10))
    assert [(1, 2), (4, 6, 8)] == list(split_by(it, separator=3, empty_segments=True))
    it = iter(range(10))
   

# Generated at 2022-06-23 17:31:58.933905
# Unit test for function scanr
def test_scanr():
    t1 = [1, 2, 3, 4, 5]
    t2 = [5, 4, 3, 2, 1]
    assert list(scanr(operator.mul, t1)) == t2
    assert list(scanr(lambda a, b: b + a, t1)) == t2
    assert list(scanr(operator.mul, t1, 1)) == t2
    assert list(scanr(lambda a, b: b + a, t1, '')) == t2
    assert list(scanr(operator.mul, t1, 2)) == [10, 8, 6, 4, 2]
    assert list(scanr(lambda a, b: b + a, t1, '')) == ['abcde', 'bcde', 'cde', 'de', 'e']

# Generated at 2022-06-23 17:32:09.740180
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def func1(x):
        return x * x
    def func2(i):
        return a[i] + b[i]
    a = [1, 2, 3, 4]
    b = [5, 6, 7, 8]
    assert MapList(func1, a)[0] == 1
    assert MapList(func1, a)[1] == 4
    assert MapList(func1, a)[2] == 9
    assert MapList(func1, a)[3] == 16
    assert MapList(func1, a)[:] == [1, 4, 9, 16]
    assert MapList(func1, a)[0:2] == [1, 4]
    assert MapList(func2, Range(len(a)))[0] == 6

# Generated at 2022-06-23 17:32:22.179895
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda x,y: x+y, [1,2,3,4,5])) == [list(reversed(scanl(lambda x,y: x+y, [1,2,3,4,5])))]
    assert list(scanr(lambda x,y: x+y, [1,2,3,4,5], 0)) == [list(reversed(scanl(lambda x,y: x+y, [1,2,3,4,5], 0)))]
    assert list(scanr(lambda x,y: x+y, [1,2,3,4,5], 10)) == [list(reversed(scanl(lambda x,y: x+y, [1,2,3,4,5], 10)))]



# Generated at 2022-06-23 17:32:23.255470
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert(MapList(lambda x: x * x, [1, 2, 3]))

# Generated at 2022-06-23 17:32:26.207136
# Unit test for function drop
def test_drop(): 
    actual = list(drop(30, range(100)))
    expect = list(range(30,100))
    assert actual == expect
 

# Generated at 2022-06-23 17:32:34.534049
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(5))
    assert list(ll) == [0, 1, 2, 3, 4]
    assert list(ll) == [0, 1, 2, 3, 4]
    assert list(ll.__iter__()) == [0, 1, 2, 3, 4]
    ll = LazyList(range(0))
    assert list(ll) == []
    assert list(ll) == []
    assert list(ll.__iter__()) == []


# Generated at 2022-06-23 17:32:45.337363
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(7, range(10))) == [[0, 1, 2, 3, 4, 5, 6], [7, 8, 9]]
    assert list(chunk(0, range(10))) == ValueError
    assert list(chunk(-9, range(10))) == ValueError


# Generated at 2022-06-23 17:32:53.154415
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[2] == 2
    assert lst[0:3] == [0, 1, 2]
    assert lst[8:10] == [8, 9]
    assert lst[8:] == [8, 9]
    assert lst[:8] == [0, 1, 2, 3, 4, 5, 6, 7]
    assert lst[:] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert lst[2::2] == [2, 4, 6, 8]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-23 17:33:01.810536
# Unit test for method __next__ of class Range
def test_Range___next__():
    s = Range(-3, 3)
    assert next(s) == -3
    assert next(s) == -2
    assert next(s) == -1
    assert next(s) == 0
    assert next(s) == 1
    assert next(s) == 2
    raises(StopIteration, lambda: next(s))

    s = Range(0, 10, 2)
    assert next(s) == 0
    assert next(s) == 2
    assert next(s) == 4
    assert next(s) == 6
    assert next(s) == 8
    raises(StopIteration, lambda: next(s))

    s = Range(10)
    assert next(s) == 0
    assert next(s) == 1
    assert next(s) == 2
    assert next(s) == 3
    assert next

# Generated at 2022-06-23 17:33:07.786327
# Unit test for method __next__ of class Range
def test_Range___next__():
    for _ in range(10000):
        l = random.randint(0, 100)
        r = random.randint(0, 100)
        step = random.randint(0, 10)
        if l > r:
            l, r = r, l
        if step == 0:
            step = 1
        r = range(l, r, step)
        d = list(r)
        for _ in range(10000):
            assert next(r) == d.pop(0)



# Generated at 2022-06-23 17:33:10.461064
# Unit test for function chunk
def test_chunk():
    result = list(chunk(3, range(10)))
    assert result == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
test_chunk()



# Generated at 2022-06-23 17:33:15.529826
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    iterable = range(5)
    lst = LazyList(iterable)
    assert list(iter(lst)) == list(iterable)
    lst._fetch_until(len(lst) - 1)
    assert list(iter(lst)) == list(iterable)


# Generated at 2022-06-23 17:33:21.591785
# Unit test for constructor of class LazyList
def test_LazyList():
    class TestIterable:
        def __init__(self, test_list: List[int]):
            self.test_list = test_list
            self.it = iter(test_list)
            self.exhausted = False

        def __iter__(self):
            if self.exhausted:
                raise TypeError("__iter__ is not available after the iterable is depleted")
            return self

        def __next__(self):
            try:
                res = next(self.it)
            except StopIteration:
                self.exhausted = True
                raise StopIteration
            return res

    def test_iter(test_iterable: TestIterable):
        test_lst = LazyList(test_iterable)
        assert isinstance(test_lst, Sequence)

# Generated at 2022-06-23 17:33:31.425855
# Unit test for function split_by
def test_split_by():
    assert list(split_by("Split by: ", empty_segments=True, separator='.')) == \
        [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by("Split by: ", empty_segments=False, separator='.')) == \
        [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == \
        [[1, 2], [4, 5], [7, 8]]

# Generated at 2022-06-23 17:33:36.441292
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = MapList(lambda x: x * x, [1, 2, 3, 4, 5]) # instantiate MapList
    assert a[0] == 1
    assert a[2:4] == [9, 16]
    try:
        a[5]
        assert False
    except IndexError:
        assert True

# Generated at 2022-06-23 17:33:41.836942
# Unit test for function take
def test_take():
    assert list(take(10, range(100))) == list(range(10))
    assert list(take(10, range(5))) == list(range(5))
    assert list(take(100, range(5))) == list(range(5))
    assert list(take(100, [])) == []
    with pytest.raises(ValueError):
        list(take(-1, range(100)))



# Generated at 2022-06-23 17:33:48.448175
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4]
    obj = MapList(lambda x: x ** 2, lst)
    assert obj[0] == 1
    assert obj[2] == 9
    assert obj[:2] == [1, 4]
    assert list(obj[1:]) == [4, 9, 16]
    assert obj[::-1] == [16, 9, 4, 1]



# Generated at 2022-06-23 17:33:59.302054
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(1, 4)[0] == 1
    assert Range(1, 4)[1] == 2
    assert Range(1, 4)[2] == 3
    assert Range(1, 6, 2)[0] == 1
    assert Range(1, 6, 2)[1] == 3
    assert Range(1, 6, 2)[2] == 5
    assert Range(1, 4)[-1] == 3
    assert Range(1, 4)[-2] == 2
    assert Range(1, 4)[-3] == 1
    assert Range(1, 6, 2)[-1] == 5
    assert Range(1, 6, 2)[-2] == 3
    assert Range(1, 6, 2)[-3] == 1
    assert Range(1, 4)[slice(0, 2)] == [1, 2]

# Generated at 2022-06-23 17:34:04.522218
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3])[3] == None
    assert MapList(lambda x: x * x, [1, 2, 3])[:2] == [1, 4]
    assert MapList(lambda x: x * x, [1, 2, 3])[1:2] == [4]
    assert MapList(lambda x: x * x, [1, 2, 3])[2:] == [9]

# Generated at 2022-06-23 17:34:10.008926
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:34:13.152127
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    def foo(x: int) -> int:
        return x + 1

    assert len(MapList(foo, [1, 2, 3])) == 3

# Generated at 2022-06-23 17:34:18.142650
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(iter(range(10)))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-2] == 8
    assert lst[4] == 4
    assert lst[4] == 4
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[2:8:3] == [2, 5]
    assert lst[2:8:-2] == []
    with pytest.raises(TypeError):
        len(lst)



# Generated at 2022-06-23 17:34:19.696327
# Unit test for method __next__ of class Range
def test_Range___next__():
    test = Range(0,10,2)
    for i in range(0,10,2):
        assert next(test) == i


# Generated at 2022-06-23 17:34:29.784108
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    a = LazyList([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    it = iter(a)
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    assert next(it) == 4
    assert next(it) == 5
    assert next(it) == 6
    assert next(it) == 7
    assert next(it) == 8
    assert next(it) == 9
    assert next(it) == 10
    assert len(a) == 10



# Generated at 2022-06-23 17:34:32.104619
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5


# Generated at 2022-06-23 17:34:35.994126
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    with pytest.raises(ValueError):
        list(take(-5, range(10)))


# Generated at 2022-06-23 17:34:43.495528
# Unit test for function drop_until
def test_drop_until():
    iterable = list(range(10))
    # Test case 1
    iterator = drop_until(lambda x: x < 3, iterable)
    assert next(iterator) == 3
    assert list(iterator) == [4, 5, 6, 7, 8, 9]
    # Test case 2
    iterator = drop_until(lambda x: x > 5, iterable)
    assert list(iterator) == [6, 7, 8, 9]
    # Test case 3
    iterator = drop_until(lambda x: x > 13, iterable)
    assert list(iterator) == []
    # Test case 4
    iterator = drop_until(lambda x: x == 1, iterable)
    assert list(iterator) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    # Test case 5

# Generated at 2022-06-23 17:34:46.555121
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:34:49.263240
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    len(MapList(lambda x: x, []))


# Generated at 2022-06-23 17:34:54.768235
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def func(x):
        return x * 3
    lst = [1, 2, 3, 4, 5]
    obj = MapList(func, lst)
    assert obj[1] == 2 * 3
    assert obj[1:3] == [2 * 3, 3 * 3]



# Generated at 2022-06-23 17:35:00.977641
# Unit test for function take
def test_take():
    assert list(take(0, [])) == []
    assert list(take(1, [])) == []
    assert list(take(0, [1])) == []
    assert list(take(1, [1])) == [1]
    assert list(take(2, [1])) == [1]
    assert list(take(1, (x * x for x in range(10)))) == [0]



# Generated at 2022-06-23 17:35:12.925023
# Unit test for function chunk
def test_chunk():
    assert [(0, 1, 2), (3, 4, 5), (6, 7), (8, 9)] == \
        list(chunk(3, range(10)))
    assert [] == list(chunk(3, []))
    assert [(0, 1, 2), (3, 4, 5), (6, 7), (8, 9)] == \
        list(chunk(3, range(10)))
    assert [(0, 1), (2, 3), (4, 5)] == \
        list(chunk(2, range(6)))
    assert [(0, 1), (2, 3), (4, 5)] == \
        list(chunk(2, range(6)))
    assert [(0, 1), (2, 3)] == \
        list(chunk(2, range(4)))

# Generated at 2022-06-23 17:35:19.234592
# Unit test for function drop_until
def test_drop_until():
    test_iterable = list(range(10))
    assert list(drop_until(lambda x: x > 5, test_iterable)) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 7, test_iterable)) == [8, 9]
    assert list(drop_until(lambda x: False, test_iterable)) == test_iterable
    test_iterable = list(range(0, 1000, 10))
    assert list(drop_until(lambda x: x > 26, test_iterable)) == [30, 40, 50, 60, 70, 80, 90]
    assert list(drop_until(lambda x: x > 55, test_iterable)) == [60, 70, 80, 90]

# Generated at 2022-06-23 17:35:23.403233
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0,1,2], [3,4,5], [6,7,8], [9]]
test_chunk()
    
    

# Generated at 2022-06-23 17:35:28.282870
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:35:29.189975
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    pass

# Generated at 2022-06-23 17:35:33.160870
# Unit test for method __len__ of class Range
def test_Range___len__():
    check_equal(0, len(Range(0)))
    check_equal(10, len(Range(0, 10)))
    check_equal(5, len(Range(0, 10, 2)))
    check_equal(0, len(Range(1, 0, -1)))
    check_equal(10, len(Range(10, 1, -1)))
    check_equal(6, len(Range(10, -4, -2)))


# Generated at 2022-06-23 17:35:39.872529
# Unit test for function drop
def test_drop():
    for i in range(10):
        assert list(drop(i, range(10))) == list(range(i, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(100, range(10))) == []



# Generated at 2022-06-23 17:35:42.873787
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    print("Testing method __iter__ of class Range")
    r = Range(1, 10 + 1)  # (start, end)
    assert list(r) == list(range(1, 10 + 1))
    print("Passed")

# Generated at 2022-06-23 17:35:53.188682
# Unit test for function split_by
def test_split_by():
    def check(case, expected):
        actual = list(split_by(case, criterion=lambda x: x % 3 == 0))
        assert actual == expected
    check(range(10), [[1, 2], [4, 5], [7, 8]])
    check(range(21), [[1, 2], [4, 5], [7, 8], [10, 11], [13, 14], [16, 17], [19, 20]])
    check(" Split by: ", [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []], True)
    check("", [], True)
    check("a", [['a']], True)



# Generated at 2022-06-23 17:36:06.201605
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    from unittest import TestCase, main

    class Test_Range___iter__(TestCase):
        def test_default(self):
            with self.assertRaises(TypeError):
                next(Range())

        def test_negative(self):
            with self.assertRaises(TypeError):
                next(Range(1, -2))

        def test_zero_step(self):
            with self.assertRaises(TypeError):
                next(Range(1, 2, 0))

        def test_end(self):
            self.assertEqual(list(Range(10)), list(range(10)))

        def test_start_end(self):
            self.assertEqual(list(Range(5, 10)), list(range(5, 10)))


# Generated at 2022-06-23 17:36:13.302200
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList([1, 2, 3, 4])
    try:
        l.__len__()
        assert False, "__len__ should raise an exception when the iterable is not depleted"
    except TypeError:
        pass

    # This will dep
    for _ in l:
        pass
    assert l.__len__() == 4
test_LazyList___len__()



# Generated at 2022-06-23 17:36:16.204371
# Unit test for function scanl
def test_scanl():
    data = [1,2,3,4]
    result = scanl(lambda s, x: x + s, data)
    assert list(result) == [1,3,6,10]

# Generated at 2022-06-23 17:36:28.526361
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    for _ in range(1000):
        a = (random.randint(0, 5), random.randint(0, 5))
        b = MapList(lambda x: x * 2, range(a[0], a[1] + 1))
        assert b[random.randint(0, len(b) - 1)] == 2 * random.randint(a[0], a[1])
        assert b[:] == [x * 2 for x in range(a[0], a[1] + 1)]
        assert b[random.randint(0, len(b) - 1): random.randint(0, len(b) - 1)] == [x * 2 for x in range(a[0], a[1] + 1)]


# Generated at 2022-06-23 17:36:38.151920
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == \
           [[], [1, 2], [4, 5], [7, 8], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=False)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == \
           [[], [1, 2], [4, 5], [7, 8], []]

# Generated at 2022-06-23 17:36:41.943551
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(1)) == 1
    assert len(Range(1, 2 + 1)) == 2
    assert len(Range(1, 10 + 1, 2)) == 5


# Generated at 2022-06-23 17:36:52.326033
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for i in range(100):
        lst = MapList(lambda x: x * x, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        for j in range(10):
            assert lst[j] == j + 1
            assert lst[j] == lst[j]

    for i in range(100):
        lst = MapList(lambda x: x * x, range(1, 11))
        for j in range(10):
            assert lst[j] == (j + 1) ** 2

    for i in range(100):
        lst = MapList(lambda x: x * x * x, range(1, 11))
        for j in range(10):
            assert lst[j] == (j + 1) ** 3


# Generated at 2022-06-23 17:36:59.458895
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-23 17:37:04.795501
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from nose.tools import raises
    from pyhcl.common import LazyList
    assert LazyList("abcd")[:].__len__() == 4
    assert LazyList(range(1000))[:].__len__() == 1000
    assert LazyList("abcdef").__len__() == 6
    @raises(TypeError)
    def test():
        LazyList("abc")[:].__len__()
    test()


# Generated at 2022-06-23 17:37:08.256839
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == list(range(5))
    assert list(take(20, range(10))) == list(range(10))


take.__doc__ = dedent(take.__doc__)



# Generated at 2022-06-23 17:37:14.146865
# Unit test for function chunk
def test_chunk():
    for n in range(4):
        for xs in [range(n * k, (n + 1) * k) for k in range(1, 4)]:
            assert list(chunk(n, xs)) == [list(xs[i:i + n]) for i in range(0, len(xs), n)]
            assert list(chunk(n, xs)) == list(chunk(n, iter(xs)))



# Generated at 2022-06-23 17:37:23.733718
# Unit test for constructor of class LazyList
def test_LazyList():
    my_iter = range(50)
    my_lazy_list = LazyList(my_iter)
    print(type(my_lazy_list))
    print(type(my_lazy_list[0]), my_lazy_list[0])
    print(type(my_lazy_list[0:5]), my_lazy_list[0:5])
    print(type(my_lazy_list[0:-1]), my_lazy_list[0:-1])
    print(type(my_lazy_list[:]), my_lazy_list[:])
# test_LazyList()

