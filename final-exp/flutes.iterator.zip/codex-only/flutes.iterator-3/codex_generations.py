

# Generated at 2022-06-23 17:27:18.603629
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda i: i
    lst = [5, 6, 7]
    obj = MapList(func, lst)
    assert obj[0] == 5
    assert obj[2] == 7
    assert obj[1:3] == [6, 7]
    assert obj[2:] == [7]
    assert obj[1] == 6
    assert obj[0:2] == [5, 6]
    assert obj[0:3:2] == [5, 7]



# Generated at 2022-06-23 17:27:23.206064
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ret_list = ['a', 'b', 'c']
    for i, x in enumerate(LazyList(ret_list)):
        assert ret_list[i] == x
    for i, x in enumerate(LazyList(ret_list)):
        assert ret_list[i] == x



# Generated at 2022-06-23 17:27:25.878468
# Unit test for function take
def test_take():
    assert list(take(0, ["foo", "bar"])) == []
    assert list(take(1, ["foo", "bar"])) == ["foo"]
    assert list(take(2, ["foo", "bar"])) == ["foo", "bar"]



# Generated at 2022-06-23 17:27:28.806125
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for i, val in enumerate(Range(1,11)):
        assert i + 1 == val


# Generated at 2022-06-23 17:27:36.176371
# Unit test for method __len__ of class Range
def test_Range___len__():
    for _ in range(50):
        RN = 10
        r = Range(RN)
        if len(r) != RN:
            print(len(r))
            return False
        for m in range(10):
            LN = random.randint(1, RN - 1)
            r = Range(LN, RN)
            if len(r) != RN - LN:
                print(len(r))
                return False
        for m in range(10):
            LN = random.randint(1, RN - 1)
            r = Range(LN, RN, random.randint(-LN, LN))
            if len(r) != RN - LN if r.step > 0 else (LN - 1) // (-r.step) + 1:
                print(len(r))
                return False
   

# Generated at 2022-06-23 17:27:48.594417
# Unit test for constructor of class Range
def test_Range():
    # Range(stop)
    r0 = Range(10)
    assert r0.l == 0
    assert r0.r == 10
    assert r0.step == 1
    assert r0.val == 0
    assert r0.length == 10

    # Range(start, stop)
    r1 = Range(1, 10 + 1)
    assert r1.l == 1
    assert r1.r == 10 + 1
    assert r1.step == 1
    assert r1.val == 1
    assert r1.length == 10

    # Range(start, end, step)
    r2 = Range(1, 10 + 1, 2)
    assert r2.l == 1
    assert r2.r == 10 + 1
    assert r2.step == 2
    assert r2.val == 1

# Generated at 2022-06-23 17:27:56.127758
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = [4, 2, 1, 2, 4]
    assert len(MapList(lambda x: x % 2, lst)) == len(lst)
    assert len(MapList(lambda x: x % 2, lst)[:2]) == 2
    assert len(MapList(lambda x: x % 2, lst)[:-1]) == len(lst) - 1
    assert len(MapList(lambda x: x % 2, lst)[::2]) == len(lst) // 2

# Generated at 2022-06-23 17:27:58.598697
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(3))
    assert 0 == l[0]
    assert 2 == l[1]
    assert 2 == l[-1]
    assert [2, 0] == l[-2:0:-1]



# Generated at 2022-06-23 17:28:03.291706
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 5)
    for i in range(1, 5):
        assert i == next(r)
    try:
        next(r)
        raise AssertionError("should raise StopIteration")
    except StopIteration:
        pass


# Generated at 2022-06-23 17:28:06.243400
# Unit test for constructor of class MapList
def test_MapList():
    lst = MapList(lambda x: x + 1, [1, 2, 3, 4, 5])
    assert list(lst) == [2, 3, 4, 5, 6]
    assert lst[:2] == [2, 3]


# Generated at 2022-06-23 17:28:18.032684
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList(range(10**8))
    assert(len(a) == 10**8)
    assert(a[-1] == 10**8 - 1)
    assert(a[-2] == 10**8 - 2)
    assert(a[0] == 0)
    assert(a[1] == 1)
    a = LazyList(range(10**8))
    assert(a[:5] == [0, 1, 2, 3, 4])

# Generated at 2022-06-23 17:28:29.185467
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x == "b", ["a", "b", "c"])) == ["b", "c"]
    assert list(drop_until(lambda x: x > -1, range(-1, 2))) == [0, 1]
    assert list(drop_until(lambda x: x > 1000, range(10))) == []
    assert list(drop_until(lambda x: x > 10, list(range(10)))) == []
    assert list(drop_until(lambda x: x > 0, list())) == []
    assert list(drop_until(lambda x: x > 0, list())) == []
    assert list(drop_until(lambda x: x == 100, list()))

# Generated at 2022-06-23 17:28:35.161720
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10, 20)
    print(r[-1:3:3])
    print(r[1:3])
    print(r[0])
    print(r[-1:3:3])
    print(r[-1])
    print(r[-1:3:2])
    print(r[:])
    print(r[::2])

# Generated at 2022-06-23 17:28:40.785252
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
test_scanl()



# Generated at 2022-06-23 17:28:45.248345
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
test_chunk()



# Generated at 2022-06-23 17:28:56.726901
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import unittest
    from unittest.mock import Mock, patch

    class TestLazyList(unittest.TestCase):
        def test_exhausted(self):
            lst = LazyList([1, 2, 3])
            self.assertSequenceEqual(list(lst), [1, 2, 3])
            mock = Mock()
            with patch.object(lst, "iter", mock):
                with patch.object(lst, "list", mock):
                    self.assertSequenceEqual(list(lst), [1, 2, 3])

        def test_not_exhausted(self):
            lst = LazyList(range(10))
            self.assertSequenceEqual(list(lst), list(range(10)))

# Generated at 2022-06-23 17:29:06.499701
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 5)
    assert [1, 2, 3, 4] == list(r)
    assert [1, 2, 3, 4] == list(r)  # verify that multiple calls to __iter__ are supported
    # Only support range with positive step.
    r = Range(1, 5, 2)
    assert [1, 3] == list(r)
    r = Range(5, -5, -1)
    assert [5, 4, 3, 2, 1, 0, -1, -2, -3, -4] == list(r)



# Generated at 2022-06-23 17:29:09.324543
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == list(range(6, 10))
    assert list(drop_until(lambda x: x > 5, range(5))) == []



# Generated at 2022-06-23 17:29:09.857930
# Unit test for method __next__ of class Range
def test_Range___next__():
    pass

# Generated at 2022-06-23 17:29:17.299195
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']

# Generated at 2022-06-23 17:29:22.955326
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[5] == 5
    assert Range(0, 5)[2] == 2
    try:
        assert Range(5)[5]
    except StopIteration:
        pass
    assert Range(0, 5)[-1] == 4
    assert Range(0, 5, 2)[1] == 2
    assert Range(0, 5)[1:3] == [1, 2]
    assert Range(0, 5)[::2] == [0, 2, 4]

# Generated at 2022-06-23 17:29:32.104602
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(iter(range(3)))
    assert list(lst) == [0, 1, 2]
    assert list(lst) == [0, 1, 2]
    assert list(lst) == [0, 1, 2]

    lst = LazyList(iter(range(100000)))
    assert next(lst) == 0
    assert list(lst) == list(range(1, 100000))
    assert list(lst) == list(range(100000))
    
test_LazyList___iter__()

# Generated at 2022-06-23 17:29:38.206919
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, a)
    for i in range(len(a)):
        assert m[i] == a[i] * a[i]

    # Test slicing
    assert m[1:3] == list(map(lambda x: x * x, a[1:3]))
    assert m[1:4:2] == list(map(lambda x: x * x, a[1:4:2]))



# Generated at 2022-06-23 17:29:46.315922
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    import bisect
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    # Find the first index `i` such that `a[i] * b[i]` is >= 10.
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2
    pos = bisect.bisect_left(range(10, 20), 10)
    assert pos == 10

# Generated at 2022-06-23 17:29:54.497863
# Unit test for function drop_until
def test_drop_until():
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:  # pragma: no cover
        from hypothesis import given
        import hypothesis.strategies as st
        from hypothesis.stateful import RuleBasedStateMachine, invariant, precondition, rule, requires, invariant

        class TestDropUntil(RuleBasedStateMachine):
            """
            Test drop_until
            """

            @invariant()
            def check_drop_until(self):
                for i in range(len(self.expected)):
                    assert drop_until(self.pred_fn, self.data[:i]) == self.expected[i]

            @rule()
            def set_pred_fn(self):
                self.pred_fn = lambda x: x > 5


# Generated at 2022-06-23 17:29:58.011623
# Unit test for function drop
def test_drop():
    assert next(drop(5, range(10))) == 5
    assert next(drop(11, range(10))) == 10
    assert not list(drop(1, []))


# Generated at 2022-06-23 17:30:09.418588
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x % 2 == 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x % 2 == 1, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 1, [10, 0, 1, 2, 3, 4])) == [1, 2, 3, 4]
    assert list(drop_until(lambda x: True, [1, 2, 3, 4])) == [1, 2, 3, 4]
    assert list(drop_until(lambda x: True, [])) == []
    assert list(drop_until(lambda x: True, [0])) == [0]

# Generated at 2022-06-23 17:30:18.527090
# Unit test for function scanl
def test_scanl():
    func = operator.add
    iterable = [1, 2, 3, 4]
    expected = [0, 1, 3, 6, 10]
    assert list(scanl(func, iterable, 0)) == expected
    assert list(scanl(func, iterable)) == expected[1:]

    func = lambda s, x: x + s
    iterable = ['a', 'b', 'c', 'd']
    expected = ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(func, iterable)) == expected
test_scanl()



# Generated at 2022-06-23 17:30:23.417217
# Unit test for method __len__ of class Range
def test_Range___len__():
    range_ = Range(1, 0, -1)
    assert len(range_) == range_.r - range_.l

    range_ = Range(101)
    assert len(range_) == range_.r - range_.l

    range_ = Range(1, 11, 2)
    assert len(range_) == range_.r - range_.l
    return

# Generated at 2022-06-23 17:30:31.162469
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    print('test_LazyList___getitem__... ', end='')
    lst = LazyList(range(1000))
    assert 0 == lst[0]
    assert 1 == lst[1]
    assert 2 == lst[2]
    assert 3 == lst[3]
    assert 999 == lst[999]
    assert 999 == len(lst)
    assert [0, 1, 2, 3, 4, 5] == lst[:6]
    assert len(lst) == 1000
    assert [990, 991, 992, 993, 994, 995, 996, 997, 998, 999] == lst[990:]
    print('Pass')



# Generated at 2022-06-23 17:30:39.375218
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x * x, [1, 2, 3])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3])[3] == 16
    assert MapList(lambda x: x * x, [1, 2, 3])[4] == 25

# Generated at 2022-06-23 17:30:41.961114
# Unit test for constructor of class Range

# Generated at 2022-06-23 17:30:50.896280
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Test_Range___next__ should behave like Range(10)[0]
    assert next(Range(10)) == 0
    # Test_Range___next__ should behave like Range(1,11,2)[1]
    assert next(Range(1,11,2)) == 1
    # Test_Range___next__ should behave like Range(1,10 + 1)[1]
    assert next(Range(1,10 + 1)) == 1
    # Test_Range___next__ should behave like Range(1,10 + 1)[2]
    assert next(Range(1,10 + 1)) == 2
    # Test_Range___next__ should behave like Range(1,10 + 1)[3]
    assert next(Range(1,10 + 1)) == 3
    # Test_Range___next__ should behave like Range(1,10 + 1)[4]


# Generated at 2022-06-23 17:31:03.507770
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-23 17:31:08.543591
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    str_to_len = MapList(str.__len__, Range(10))
    assert isinstance(str_to_len, MapList)
    assert list(str_to_len) == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]


# Generated at 2022-06-23 17:31:17.284851
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']
    assert scanr(operator.add, [1, 2, 3, 4]) == [10, 9, 7, 4]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], '') == ['abcd', 'bcd', 'cd', 'd']
    assert scanr(lambda s, x: x + s, [], 0) == [0]



# Generated at 2022-06-23 17:31:22.845606
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(10))
    assert list(ll) == list(range(10))
    assert list(ll) == list(range(10))  # iterate twice


# Generated at 2022-06-23 17:31:31.116316
# Unit test for method __next__ of class Range
def test_Range___next__():
    def check(numbers: List[int], expected: List[int]) -> None:
        actual = []
        r = Range(100)
        for _ in range(numbers[0]):
            actual.append(next(r))
        assert actual == expected
    check([0], [])
    check([1], [0])
    check([2], [0, 1])
    check([3], [0, 1, 2])
    check([4], [0, 1, 2, 3])
    check([5], [0, 1, 2, 3, 4])
    check([6], [0, 1, 2, 3, 4, 5])
    check([7], [0, 1, 2, 3, 4, 5, 6])
    check([8], [0, 1, 2, 3, 4, 5, 6, 7])


# Generated at 2022-06-23 17:31:42.686141
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    s = [random.randint(0, 100) for _ in range(1000)]
    def is_power_of_2(x):
        return x > 0 and (x & (x - 1)) == 0

    lst = LazyList(s)
    idx_set = set(range(1000))
    while len(idx_set) > 0:
        i = random.choice(list(idx_set))
        idx_set.remove(i)
        if is_power_of_2(i):
            assert lst._fetch_until(i) is None
            assert lst.list[i] == s[i]
        else:
            assert lst[i] == s[i]
    assert lst._fetch_until(None) is None
    assert lst.ex

# Generated at 2022-06-23 17:31:54.948016
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_list = []
    m = 0
    while m<=5:
        m+=1
        try:
            test_list.append(eval(open('Range___getitem__test_string.txt', 'r').read()))
        except Exception as e:
            return 'Expression: ' + open('Range___getitem__test_string.txt', 'r').read() + '\nError: ' + str(e)
    if not all([abs(test_list[i]-test_list[i+1])<=1 for i in range(len(test_list)-1)]):
        return 'Expression: ' + open('Range___getitem__test_string.txt', 'r').read()
    return 'All tests passed'
# Generated test string

# Generated at 2022-06-23 17:31:58.471866
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    maplist = MapList(lambda x: x * x, lst)
    for i in range(5):
        assert maplist[i] == lst[i] ** 2
        s = maplist[:]
        assert len(s) == 5
        for j in range(5):
            assert s[j] == lst[j] ** 2
    maplist1 = MapList(lambda x: x, lst)
    assert maplist1[:] == lst

# Generated at 2022-06-23 17:32:04.750458
# Unit test for function split_by
def test_split_by():
    actual = list(split_by(" Split by: ", empty_segments=True, separator='.'))
    expected = [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert actual == expected



# Generated at 2022-06-23 17:32:09.346923
# Unit test for function scanr
def test_scanr():
    lis = [1, 2, 3, 4]
    assert list(scanr(operator.add, lis, 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
test_scanr()



# Generated at 2022-06-23 17:32:22.134745
# Unit test for function drop_until
def test_drop_until():
    list1 = list(drop_until(lambda x: x>5, [2,3,4,5,6,7,8,9,10]))
    assert list1 == [6,7,8,9,10]
    list2 = list(drop_until(lambda x: x>10, [2,3,4,5,6,7,8,9,10]))
    assert list2 == []
    list3 = list(drop_until(lambda x: x>3, [2,3,4,5,6,7,8,9,10]))
    assert list3 == [4,5,6,7,8,9,10]
    list4 = list(drop_until(lambda x: x>5, range(1,10)))
    assert list4 == [6,7,8,9]
   

# Generated at 2022-06-23 17:32:30.863751
# Unit test for function scanl
def test_scanl():
    seq = [1, 2, 3, 4]
    fn = lambda s, x: s + x
    assert list(scanl(fn, seq)) == [1, 3, 6, 10]
    assert list(scanl(fn, seq, 1000)) == [1000, 1001, 1003, 1006, 1010]
    assert list(scanl(fn, [0], 1000)) == [1000]
    assert list(scanl(fn, [0], 0)) == [0, 0]
    assert next(scanl(fn, [])) is None



# Generated at 2022-06-23 17:32:35.417033
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x: x, [])
    assert lst.__len__() == 0
    lst = MapList(lambda x: x, [0, 1, 2, 3, 4, 5])
    assert lst.__len__() == 6


# Generated at 2022-06-23 17:32:40.107805
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    _l = []
    for _x in Range(1, 10 + 1):
        _l.append(_x)
    assert _l == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]



# Generated at 2022-06-23 17:32:50.074721
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    try:
        import tensorflow as tf
    except ImportError:
        return
    t = tf.constant([4, 7, 1, 3])

    tl = MapList(lambda x: x.numpy(), t)
    assert tl[0] == 4
    assert tl[-1] == 3
    assert tl[:] == [4, 7, 1, 3]
    assert tl[:2] == [4, 7]
    assert tl[2:] == [1, 3]
    assert tl[::2] == [4, 1]
    assert tl[1::2] == [7, 3]
    assert tl[-2:] == [1, 3]
    assert tl[-3::-1] == [7, 4]

# Generated at 2022-06-23 17:33:00.166213
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Test for method __next__ of class Range, default constructor
    r = Range(10)
    if not r.__next__() == 0:
        raise ValueError("__next__ failed, did not start at 0")
    i = 0
    while i < 10:
        if not r.__next__() == i:
            raise ValueError("__next__ failed", r, i)
        i += 1
    try:
        r.__next__()
        raise ValueError("__next__ failed, no StopIteration")
    except StopIteration:
        pass
    # Test for method __next__ of class Range, constructor 1arg
    r = Range(10)
    if not r.__next__() == 0:
        raise ValueError("__next__ failed", r, 0)
    i = 0

# Generated at 2022-06-23 17:33:01.585691
# Unit test for constructor of class LazyList
def test_LazyList():
    iter = [1, 2, 3]
    lst = LazyList(iter)
    assert lst.iter == iter


# Generated at 2022-06-23 17:33:06.315672
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']
test_scanr()

########################################################################################################################


# Generated at 2022-06-23 17:33:09.816107
# Unit test for function scanr
def test_scanr():
    assert [10, 9, 7, 4, 0] == list(scanr(operator.add, [1, 2, 3, 4], 0))
    assert ['abcd', 'bcd', 'cd', 'd'] == list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']))



# Generated at 2022-06-23 17:33:14.960804
# Unit test for constructor of class Range
def test_Range():
    assert [x for x in Range(10)] == list(range(10))
    assert [x for x in Range(1, 10 + 1)] == list(range(1, 10 + 1))
    assert [x for x in Range(1, 11, 2)] == list(range(1, 11, 2))


# Generated at 2022-06-23 17:33:19.417659
# Unit test for function scanl
def test_scanl():
    import operator
    import functools
    l = [1, 2, 3, 4]
    expected_result = [
        0,
        1,
        3,
        6,
        10
    ]
    assert(list(scanl(operator.add, l, 0)) == expected_result)
    assert(list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba'])



# Generated at 2022-06-23 17:33:24.244407
# Unit test for constructor of class LazyList
def test_LazyList():
    import time
    a = LazyList(range(1000000))
    start = time.time()
    assert len(a) == 1000000
    duration = time.time() - start
    print(f"Length of a in {duration} seconds")



# Generated at 2022-06-23 17:33:27.008978
# Unit test for constructor of class Range
def test_Range():
    assert Range(10)[:10] == list(range(0, 10))
    assert Range(2, 10, 2)[:10] == list(range(2, 10, 2))

# Generated at 2022-06-23 17:33:35.763546
# Unit test for method __next__ of class Range
def test_Range___next__():
    r1 = Range(10)
    assert [next(r1) for i in range(10)] == list(range(10))
    r2 = Range(1, 10 + 1)
    assert [next(r2) for i in range(10)] == list(range(1, 10 + 1))
    r3 = Range(1, 11, 2)
    assert [next(r3) for i in range(5)] == list(range(1, 11, 2))



# Generated at 2022-06-23 17:33:40.407946
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)
    assert list(r) == list(range(10))

    r = Range(1, 11)
    assert list(r) == list(range(1, 11))

    r = Range(1, 11, 2)
    assert list(r) == list(range(1, 11, 2))


# Generated at 2022-06-23 17:33:44.800384
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x == "a", "hello")) == list("ello")
    assert list(drop_until(lambda x: x == "a", "nope")) == []



# Generated at 2022-06-23 17:33:47.852695
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x * x, [1, 2, 3, 4, 5])) == [1, 4, 9, 16, 25]
    assert list(MapList(lambda i: i, Range(10))) == list(range(10))

# Generated at 2022-06-23 17:33:59.110923
# Unit test for constructor of class Range
def test_Range():
    # test with one argument
    range1=Range(10)
    assert len(range1)==10
    assert range1._get_idx(0)==0
    assert range1[0]==0
    assert range1[1]==1
    assert range1[9]==9
    assert range1[-1]==9
    assert range1[-2]==8
    assert range1.step==1
    assert list(range1)==list(range(10))
    assert range1[:1]==[0]
    assert range1[2:-2]==[2,3,4,5,6,7]
    assert range1[2:6]==[2,3,4,5]
    assert range1[1:6:2]==[1,3,5]

    # test with two

# Generated at 2022-06-23 17:33:59.525714
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    pass

# Generated at 2022-06-23 17:34:03.123526
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:34:06.910154
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 11, 2)
    l = list(r)
    assert l == [1, 3, 5, 7, 9]



# Generated at 2022-06-23 17:34:09.621023
# Unit test for function drop
def test_drop():
    assert [1 for x in drop(5, range(10))] == [1,2,3,4,5,6,7,8,9]
test_drop()



# Generated at 2022-06-23 17:34:19.392652
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    true_lst = [1, 2, 3, 4, 5]
    lazy_lst = LazyList(true_lst)
    assert lazy_lst[2] == 3
    assert lazy_lst[:2] == [1, 2]
    assert lazy_lst[-1] == 5
    assert lazy_lst[3:5] == [4, 5]
    assert lazy_lst[3:-1] == [4]
    assert lazy_lst[-3:] == [3, 4, 5]
    assert lazy_lst[6:] == []
    assert lazy_lst[6:8] == []
    assert lazy_lst[:1] == [1]
    assert lazy_lst[:0] == []
    assert lazy_lst[-1:] == [5]
   

# Generated at 2022-06-23 17:34:32.182332
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4, 5], 0)) == [15, 14, 12, 9, 5, 0]
    assert list(scanr(lambda s, x: x + s[0], [1, 2, 3, 4, 5], 0)) == [15, 14, 12, 9, 5, 0]
    assert list(scanr(lambda s, x: x + s[0], [1, 2, 3, 4, 5])) == [15, 14, 12, 9, 5]
    assert list(scanr(operator.add, [1, 2, 3, 4, 5])) == [15, 14, 12, 9, 5]

# Generated at 2022-06-23 17:34:40.566734
# Unit test for function drop_until
def test_drop_until():
    a = drop_until(lambda x: x > 5, range(10))
    b = drop_until(lambda x: x > 5, range(10))
    print(list(a))
    next(b)
    # print(list(b))
    # print(list(b))
    # print(list(b))
    # print(list(drop_until(lambda x: x > 5, range(10))))
    # a = drop_until(lambda x: x > 5, range(10))
    # print(list(a))
    # print(list(a))
    # print(list(a))
    # print(list(a))

# test_drop_until()



# Generated at 2022-06-23 17:34:50.489890
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList([1, 2, 3, 4])
    try:
        len(lst)
        assert False
    except TypeError:
        pass
    assert list(lst) == [1, 2, 3, 4]
    assert lst[0] == 1
    assert lst[1] == 2
    try:
        lst[5]
        assert False
    except IndexError:
        pass
    assert lst[-1] == 4
    assert lst[:] == [1, 2, 3, 4]
    assert lst[1:3] == [2, 3]



# Generated at 2022-06-23 17:34:56.652665
# Unit test for method __next__ of class Range
def test_Range___next__():
    l = 0
    r = 10
    rng = Range(l, r)
    item = rng.__next__()
    while item < r:
        assert l <= item < r
        item = rng.__next__()
    try:
        rng.__next__()
        raise AssertionError("Range should return ValueError in the end when calling __next__")
    except StopIteration:
        pass

# Generated at 2022-06-23 17:35:03.091558
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4]
    assert list(scanr(lambda s, x: s + x, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:35:06.627751
# Unit test for method __next__ of class Range
def test_Range___next__():
    if False: pass
    else:
        for i in range(4):
            for j in range(4):
                for k in range(-2, 3):
                    r = Range(i, j + 1, k)
                    assert [x for x in r] == list(range(i, j + 1, k))



# Generated at 2022-06-23 17:35:09.486000
# Unit test for function chunk
def test_chunk():
    x = list(chunk(3, range(10)))
    y = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert x == y


# Generated at 2022-06-23 17:35:13.537829
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert [1, 2, 3, 4, 5] == list(Range(1, 6))
    assert [1, 2, 3, 4, 5] == list(range(1, 6))
    assert ['hello', 'world!'] == list(Range(2))
    assert ['hello', 'world!'] == list(range(2))


# Generated at 2022-06-23 17:35:18.866231
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
test_chunk()



# Generated at 2022-06-23 17:35:23.506202
# Unit test for function split_by
def test_split_by():
    it = split_by(["a", "b", "b", "c", "c", "c"], criterion=lambda x: x == "b")
    assert list(it) == [["a"], [], ["c", "c", "c"]]



# Generated at 2022-06-23 17:35:31.846448
# Unit test for function chunk
def test_chunk():
    assert_equal(
        list(chunk(3, range(10))),
        [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    )
    assert_equal(list(chunk(3, range(9))), [[0, 1, 2], [3, 4, 5], [6, 7, 8]])
    assert_equal(list(chunk(3, range(8))), [[0, 1, 2], [3, 4, 5], [6, 7]])
    assert_equal(list(chunk(3, range(0))), [])
    assert_equal(list(chunk(3, range(1))), [[0]])
    assert_equal(list(chunk(3, range(2))), [[0, 1]])



# Generated at 2022-06-23 17:35:34.409851
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-23 17:35:40.734657
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:35:52.901985
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 10)) == [10, 11, 13, 16, 20]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

# Generated at 2022-06-23 17:35:58.009530
# Unit test for function scanr
def test_scanr():
    m = scanr(operator.add, [0, 1, 2, 3, 4, 5], 0)
    print(m)
    assert m == [15, 14, 12, 9, 5, 0]



# Generated at 2022-06-23 17:36:07.357592
# Unit test for function scanl
def test_scanl():
    tests = [
        {'func': lambda x, y: x+y, 'list': [1,2,3,4], 'acc': 0},
        {'func': lambda x, y: x+y, 'list': ['a','b','c','d'], 'acc': ''},
        {'func': lambda x, y: y+x, 'list': ['a','b','c','d'], 'acc': ''},
    ]
    for test in tests:
        assert list(scanl(test['func'], test['list'], test['acc'])) == [test['acc']] + [test['func'](test['acc'], x) for x in test['list']]



# Generated at 2022-06-23 17:36:15.805627
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert list(MapList(lambda x: x + 2, [0, 1, 2, 3])) == [2, 3, 4, 5]
    assert MapList(lambda x: x + 2, [0, 1, 2, 3])[0] == 2
    assert MapList(lambda x: x + 2, [0, 1, 2, 3])[:4] == [2, 3, 4, 5]
    assert MapList(lambda x: x + 2, [0, 1, 2, 3])[2:] == [4, 5]


# Generated at 2022-06-23 17:36:20.724895
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    m = MapList(lambda x: x * 2, [1, 2, 3, 4])
    assert len(m) == 4
    assert m[0] == 2
    assert list(m) == [2, 4, 6, 8]

# Generated at 2022-06-23 17:36:23.235000
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert 6 == len(Range(5, 20, 2))
test_Range___len__()

# Generated at 2022-06-23 17:36:35.154395
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert [Range(10)[i] for i in range(-10, 11)] == [0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9,0]
    assert [Range(10)[i] for i in range(-len(Range(10)), len(Range(10)) + 1)] == [0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9,0]
    assert list(Range(10)[slice(0, 1, 1)]) == [0]
    assert list(Range(10)[slice(0, 1)]) == [0]

# Generated at 2022-06-23 17:36:38.040991
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-23 17:36:49.881893
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    import copy
    random.seed(0)

    # The following list contains 1000 random positive integers, each
    # in the range 0 to 50.
    lst = []
    for i in range(1000):
        lst.append(random.randint(0, 50))

    # Test __getitem__ at random indices.
    for i in range(100):
        idx = random.randint(0, len(lst) - 1)
        assert lst[idx] == MapList(lambda x: x, lst)[idx]

        # Test __getitem__ at random slices.
        for _ in range(100):
            slice_ = random.randint(0, len(lst) - 1)
            step = random.randint(1, 10)

# Generated at 2022-06-23 17:36:55.642371
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(1, 10 + 1)) == range(1, 10 + 1)
    assert list(Range(10)) == range(10)
    assert list(Range(1, 11, 2)) == range(1, 11, 2)


# Generated at 2022-06-23 17:36:58.683190
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-23 17:36:59.672508
# Unit test for function take
def test_take():
    assert list(take(2, range(10))) == [0, 1]


# Generated at 2022-06-23 17:37:03.814333
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
test_scanl()



# Generated at 2022-06-23 17:37:05.552842
# Unit test for function drop
def test_drop():
    assert list(drop(3, [1, 2, 3, 4, 5])) == [4, 5]



# Generated at 2022-06-23 17:37:18.208379
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from random import randint
    from unittest import TestCase, main

    class LazyList___getitem__Tests(TestCase):
        def test_get_item_by_index(self):
            for _ in range(100):
                lst = LazyList(range(randint(0, 100)))
                for i in range(len(lst)):
                    self.assertEqual(lst[i], i)

        def test_get_item_by_slice(self):
            for _ in range(100):
                lst = LazyList(range(randint(0, 100)))
                slc = slice(*sorted(randint(0, i) for i in range(len(lst) + 2)))