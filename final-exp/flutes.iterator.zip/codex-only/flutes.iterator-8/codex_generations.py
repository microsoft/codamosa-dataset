

# Generated at 2022-06-23 17:27:25.186343
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], '')) == ['abcd', 'bcd', 'cd', 'd', '']
    assert list(scanr(operator.add, [1, 2, 3, 4], initial=0)) == [10, 9, 7, 4, 0]

# Generated at 2022-06-23 17:27:29.396596
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    data = [item for item in range(10)]
    range_ = Range(1, 10 + 1)
    for idx in range(10):
        assert data[idx] == range_[idx]

# Generated at 2022-06-23 17:27:36.569602
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]

# Generated at 2022-06-23 17:27:44.237556
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4]
    b = MapList(int, a)
    assert (b[0] == 1)
    assert (b[1] == 2)
    assert (b[2] == 3)
    assert (b[3] == 4)
    for i in range(4):
        assert (b[i] == a[i])

# Generated at 2022-06-23 17:27:47.711259
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(10))) == list(range(10))
    assert list(LazyList([])) == []


# Generated at 2022-06-23 17:27:48.916678
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(iter(Range(2))) == [0, 1]

# Generated at 2022-06-23 17:27:53.450927
# Unit test for function drop
def test_drop():
    r=drop(5, range(1000000))
    for i in range(5,10):
        print(next(r))
        
test_drop()


# Generated at 2022-06-23 17:28:03.036444
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for r in [Range(1, 10 + 1), Range(1, 10 + 1, 2), Range(0)]:
        it = iter(r)
        for i in range(len(r)):
            assert next(it) == r[i]
        with pytest.raises(StopIteration):
            next(it)

# Generated at 2022-06-23 17:28:11.413050
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l1 = LazyList([1, 2, 3, 4, 5, 6])
    l2 = LazyList([1, 2, 3, 4, 5, 6])
    assert l1[:4] == [1, 2, 3, 4]
    assert l1[0] == 1
    assert l1[1] == 2
    assert l1[-5] == 2
    assert l1[1:3] == [2, 3]
    assert l2[:4] == [1, 2, 3, 4]
    assert l2[0] == 1
    assert l2[1] == 2
    assert l2[-5] == 2
    assert l2[1:3] == [2, 3]



# Generated at 2022-06-23 17:28:17.467969
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    with no_print:
        import random
        import bisect
        for i in range(1000):
            lst = [random.randint(-100, 100) for _ in range(10)]
            assert len(MapList(lambda x: x + 10, lst)) == len(lst)
            assert len(MapList(lambda x: x + 10, lst)) == bisect.bisect_left(MapList(lambda x: x + 100, lst), 1000)



# Generated at 2022-06-23 17:28:27.352365
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(5, 15)
    assert r[0] == 5
    assert r[-1] == 14
    assert r[1:2] == [6]
    assert r[1:] == [6, 7, 8, 9, 10, 11, 12, 13, 14]
    assert r[:2] == [5, 6]
    assert r[:-1] == [5, 6, 7, 8, 9, 10, 11, 12, 13]
    assert r[::2] == [5, 7, 9, 11, 13]
    assert r[::-1] == [14, 13, 12, 11, 10, 9, 8, 7, 6, 5]



# Generated at 2022-06-23 17:28:32.883386
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 3, range(10))) == [4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 3, range(4))) == []
    assert list(drop_until(lambda x: x > 3, [])) == []



# Generated at 2022-06-23 17:28:36.518162
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    rng = Range(10)
    ml = MapList(lambda x: x + 10, rng)
    for i, x in enumerate(ml):
        assert i + 10 == x


# Generated at 2022-06-23 17:28:39.285233
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(100)
    assert r[0] == 0 and r[50] == 50 and r[-1] == 99


# Generated at 2022-06-23 17:28:43.939610
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    # @lru_cache(maxsize=None)
    def test_result() -> Iterator[int]:
        # result = iter(Range(1, 10))
        result = Range(1, 10).__iter__()
        return result

    expected_result: Iterator[int] = iter(range(1, 10))

    assert expected_result == test_result()

# Generated at 2022-06-23 17:28:51.145616
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)
    assert list(r) == list(range(10))
    r = Range(10, 20)
    assert list(r) == list(range(10, 20))
    r = Range(10, 20, 2)
    assert list(r) == list(range(10, 20, 2))
    r = Range(10, 20, -2)
    assert list(r) == []
# Test Range
test_Range___next__()

# Generated at 2022-06-23 17:28:53.361110
# Unit test for function drop
def test_drop():
    for v, k in zip(drop(5, range(1000000)), range(5, 1000000)):
        assert v == k



# Generated at 2022-06-23 17:28:56.769848
# Unit test for method __len__ of class Range
def test_Range___len__():
    import pytest

    with pytest.raises(ValueError):
        len(Range())
    assert len(Range(1)) == 1
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 10 + 1, 1)) == 10
    assert len(Range(3, 10 + 1, 2)) == 4
    assert len(Range(10, 1, -1)) == 10
    assert len(Range(1, 10 + 1, -1)) == 0


# Generated at 2022-06-23 17:29:02.543240
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.mul, [1,2,3,4])) == [24,12,4,1]
    assert list(scanr(operator.mul, [1,2,3,4], 10)) == [720,120,20,2]
    assert list(scanr(operator.add, [1,2,3,4], 10)) == [20,19,17,14]
    assert list(scanr(operator.add, [1,2,3,4])) == [10,9,7,4]
    assert list(scanr(operator.mul, [1,2,3])) == [6,3,1]
    assert list(scanr(operator.mul, [1,2,3], 10)) == [60,30,2]

# Generated at 2022-06-23 17:29:05.409615
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x[0] + x[1], [[1, 2], [3, 4], [5, 6], [7, 8]])
    return (lst[0], lst[1], lst[2], lst[3])

# Generated at 2022-06-23 17:29:10.117308
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(1, range(10))) == list(range(1, 10))
    assert list(drop(9, range(10))) == list(range(9, 10))
    assert list(drop(10, range(10))) == []
# test_drop()


# Generated at 2022-06-23 17:29:22.078337
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda a, b: a + b, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda a, b: a + b, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda a, b: a + b, [], 0)) == [0]
    assert list(scanl(lambda s, x: x + s, [], 'a')) == ['a']



# Generated at 2022-06-23 17:29:33.574102
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    class _LazyList___len__FakeSequence:
        def __init__(self, length: int) -> None:
            self.length = length
        def __len__(self) -> int:
            return self.length
    # test when the lazy list has been fully realized
    for length in range(6):
        assert LazyList(_LazyList___len__FakeSequence(length)).__len__() == length
    # test when the lazy list has not been fully realized
    for length in range(6):
        lst = LazyList(_LazyList___len__FakeSequence(length))
        for i in range(length - 1):
            lst[i]
        with pytest.raises(TypeError):
            lst.__len__()


# Generated at 2022-06-23 17:29:36.618290
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a_lst = LazyList(range(100))
    with pytest.raises(TypeError):
        len(a_lst)
    assert len(a_lst[:]) == 100



# Generated at 2022-06-23 17:29:43.437432
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    def tester(func):
        def test(lst):
            it = MapList(func, lst).__iter__()
            return list(it)
        return test
    check_against_builtin(tester(lambda x: 2 * x), [1, 2, 3, 4, -10, 0])
    check_against_builtin(tester(len), ["aa", "bbbb", "ccc", "d"])
    check_against_builtin(tester(lambda x: 2 * x + len("")), ["a", "bbbb", "cc", ""])
    check_against_builtin(tester(lambda x: 2 * x + len("b")), ["a", "bbbb", "cc", ""])



# Generated at 2022-06-23 17:29:47.435969
# Unit test for constructor of class MapList
def test_MapList():
    list_ = [1, 2, 3]
    # use lambda to create a function
    test = MapList(lambda x: x + 1, list_)
    print(test)
    print(test[0])
    for i in test: print(i)



# Generated at 2022-06-23 17:29:49.046552
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(10)))
    assert list(drop(10, range(3))) == []



# Generated at 2022-06-23 17:29:52.729637
# Unit test for function drop_until
def test_drop_until():
    range_size = 10
    big_range = range(range_size + 1)
    for i in range(range_size + 1):
        result = list(drop_until(lambda x: x > i, big_range))
        expected = list(range(i + 1, range_size + 1))
        assert result == expected



# Generated at 2022-06-23 17:29:58.010799
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    assert isinstance(MapList(lambda x: [foo, bar], a), list)
    assert isinstance(MapList(lambda x: [foo, bar], a), MapList)
    assert isinstance(MapList(lambda x: [foo, bar], a), Sequence)


# Generated at 2022-06-23 17:30:02.727708
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    """
    Test method __iter__ of class Range
    """
    r = Range(1, 10 + 1)
    assert isinstance(iter(r), Iterator)
    l = list(r)
    assert l == list(range(1, 10 + 1))

# Generated at 2022-06-23 17:30:05.970517
# Unit test for function chunk
def test_chunk():
    assert list(chunk(123, [1, 2, 3])) == [[1, 2, 3]]
    assert list(chunk(123, [])) == []


# Generated at 2022-06-23 17:30:07.313061
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    obj = MapList(func=lambda x: x * x, lst=[1, 2, 3, 4, 5])
    assert list(obj) == [1, 4, 9, 16, 25]


# Generated at 2022-06-23 17:30:20.084278
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(1, range(10))) == list(range(1,10))
    assert list(drop(2, range(10))) == list(range(2,10))
    assert list(drop(3, range(10))) == list(range(3,10))
    assert list(drop(4, range(10))) == list(range(4,10))
    assert list(drop(5, range(10))) == list(range(5,10))
    assert list(drop(6, range(10))) == list(range(6,10))
    assert list(drop(7, range(10))) == list(range(7,10))
    assert list(drop(8, range(10))) == list(range(8,10))
    assert list

# Generated at 2022-06-23 17:30:21.601452
# Unit test for method __len__ of class Range
def test_Range___len__():
    obj = Range(10)
    assert obj.__len__() == 10


# Generated at 2022-06-23 17:30:23.330831
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    len(lst) == 10



# Generated at 2022-06-23 17:30:31.880885
# Unit test for function split_by
def test_split_by():
    criterion = lambda x: x > 5
    assert list(split_by(range(10), criterion=criterion)) == [[0, 1, 2, 3, 4, 5], [7, 8, 9]]
    assert list(split_by(range(10), criterion=criterion, empty_segments=True)) == [[0, 1, 2, 3, 4, 5], [], [7, 8, 9]]
    assert list(split_by(range(10), criterion=lambda x: x == 5)) == [[0, 1, 2, 3, 4], [6, 7, 8, 9]]
    assert list(split_by(range(10), criterion=lambda x: x == 5, empty_segments=True)) == [[0, 1, 2, 3, 4], [], [6, 7, 8, 9]]

    separator = '.'


# Generated at 2022-06-23 17:30:43.814436
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

# Generated at 2022-06-23 17:30:46.548222
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    lst = list(range(10))
    assert list(MapList(lambda x: x * 2, lst)) == list(map(lambda x: x * 2, lst))


# Generated at 2022-06-23 17:30:59.395456
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range = Range(10)
    assert_equal(range[0], 0, err_msg="range[0]")
    assert_equal(range[1], 1, err_msg="range[1]")
    assert_equal(range[2], 2, err_msg="range[2]")
    assert_equal(range[3], 3, err_msg="range[3]")
    assert_equal(range[4], 4, err_msg="range[4]")
    assert_equal(range[5], 5, err_msg="range[5]")
    assert_equal(range[6], 6, err_msg="range[6]")
    assert_equal(range[7], 7, err_msg="range[7]")
    assert_equal(range[8], 8, err_msg="range[8]")

# Generated at 2022-06-23 17:31:04.838302
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
#test_scanl()


# Generated at 2022-06-23 17:31:07.592703
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-23 17:31:17.742055
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(3, [])) == []
    assert list(chunk(3, [1])) == [[1]]
    assert list(chunk(3, [1, 2])) == [[1, 2]]
    assert list(chunk(3, [1, 2, 3])) == [[1, 2, 3]]
    assert list(chunk(3, [1, 2, 3, 4])) == [[1, 2, 3], [4]]

# Generated at 2022-06-23 17:31:25.827553
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2, 3, 4, 5, 6], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:31:30.539835
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    obj = Range(10)
    for x in range(0, 10):
        assert next(obj) == x
    with pytest.raises(StopIteration):
        next(obj)

test_Range___iter__()


# Generated at 2022-06-23 17:31:33.893722
# Unit test for function drop_until
def test_drop_until():
    lst = list(drop_until(lambda x: x > 3, range(10)))
    assert lst[0] == 4
    assert len(lst) == 6



# Generated at 2022-06-23 17:31:37.438012
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)

# Generated at 2022-06-23 17:31:42.538603
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    from bisect import bisect_left
    import numpy as np
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    pos = bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))),10)
    assert pos == 2


# Generated at 2022-06-23 17:31:55.200611
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random

    a = [random.randint(0, 100) for _ in range(10)]
    print(a)
    print(list(MapList(lambda x: x + 100, a)))
    print(list(MapList(lambda x: x + 100, a[0:0])))
    print(list(MapList(lambda x: x + 100, a[5:])))
    print(list(MapList(lambda x: x + 100, a[:5])))
    print(list(MapList(lambda x: x + 100, a[3:6])))
    print(MapList(lambda x: x + 100, a)[:])
    print(MapList(lambda x: x + 100, a)[::-1])
    print(MapList(lambda x: x + 100, a)[0])

# Generated at 2022-06-23 17:32:07.405879
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x == 3)) == [[0, 1, 2], [4, 5, 6, 7, 8, 9]]
    assert list(split_by(range(10), criterion=lambda _: False)) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(split_by(range(10), criterion=lambda x: x > 5)) == [[0, 1, 2, 3, 4, 5], [6, 7, 8, 9]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: False, empty_segments=True)) == [[]]

# Generated at 2022-06-23 17:32:11.651940
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    _r = Range(3)
    assert(_r[-1] == 2)
    assert(_r[1:1].__len__() == 0)
    assert(_r[1:2][0] == 1)


# Generated at 2022-06-23 17:32:19.585114
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, range(4))) == [[0], [1], [2], [3]]
    assert list(chunk(2, range(4))) == [[0, 1], [2, 3]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(4, range(4))) == [[0, 1, 2, 3]]
    assert list(chunk(3, [])) == []


# Generated at 2022-06-23 17:32:25.500565
# Unit test for method __len__ of class Range
def test_Range___len__():
    for i in range(-100,100,10):
        for j in range(-100,100,10):
            for k in range(-100,100,10):
                if k == 0: continue
                r = Range(i,j,k)
                try:
                    assert(len(r) == ((j-i)//k))
                except:
                    print("Failed when input is :","i=",i,"j=",j,"k=",k)

test_Range___len__()


# Generated at 2022-06-23 17:32:34.146555
# Unit test for function drop_until
def test_drop_until():
    iterable = range(10)
    assert list(drop_until(lambda x: x > 5, iterable)) == list(range(6, 10))
    assert list(drop_until(lambda x: x < 5, iterable)) == []
    assert list(drop_until(lambda x: x == 5, iterable)) == [5]
    assert list(drop_until(lambda x: x < -1, iterable)) == list(range(0, 10))
    assert list(drop_until(lambda x: x > 9, iterable)) == []



# Generated at 2022-06-23 17:32:36.963528
# Unit test for function drop
def test_drop():
    a = [0, 1, 2, 3, 4]
    assert list(drop(3, a)) == [3, 4]
    assert list(drop(0, a)) == a
    assert not list(drop(5, a))



# Generated at 2022-06-23 17:32:40.163586
# Unit test for method __len__ of class Range
def test_Range___len__():
    len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5

# Generated at 2022-06-23 17:32:50.111251
# Unit test for constructor of class Range
def test_Range():
    assert Range(10)[0] == 0
    assert Range(10)[1] == 1
    assert Range(10)[-1] == 9
    assert Range(10)[-2] == 8
    assert Range(10)[-10] == 0
    assert Range(1, 10)[0] == 1
    assert Range(1, 11)[0] == 1
    assert Range(1, 10, 2)[0] == 1
    assert Range(1, 11, 2)[0] == 1
    assert Range(1, 10, -1)[0] == 1
    assert Range(1, 10, -2)[0] == 1
    assert Range(1, 11, -2)[0] == 1
    assert Range(1, 10)[9] == 10
    assert Range(1, 11)[9] == 10

# Generated at 2022-06-23 17:32:56.149633
# Unit test for method __len__ of class Range
def test_Range___len__():
    import random
    for _ in range(50):
        l = random.randint(0, 10)
        r = random.randint(0, 10)
        if l > r:
            l, r = r, l
        step = random.randint(1, 10)
        assert l == Range(l, r, step)[0]
        assert (r - l) / step == len(Range(l, r, step))

# Generated at 2022-06-23 17:33:00.375322
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList(range(10))
    assert [0, 1, 2, 3, 4] == list(take(5, l))
    assert [5, 6, 7, 8, 9] == list(l)

# Generated at 2022-06-23 17:33:06.231586
# Unit test for function take
def test_take():
    assert list(take(0, [1, 2, 3])) == []
    assert list(take(1, [1, 2, 3])) == [1]
    assert list(take(2, [1, 2, 3])) == [1, 2]
    assert list(take(3, [1, 2, 3])) == [1, 2, 3]
    assert list(take(4, [1, 2, 3])) == [1, 2, 3]


# Generated at 2022-06-23 17:33:09.978727
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
test_chunk()



# Generated at 2022-06-23 17:33:14.504033
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    with pytest.raises(TypeError):
        _ = len(LazyList(range(10)))
    assert len(LazyList(range(10))) == 10
    assert len(LazyList([])) == 0



# Generated at 2022-06-23 17:33:19.486249
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:33:23.444413
# Unit test for constructor of class MapList
def test_MapList():
    items = [1, 2, 3, 4, 5]
    try:
        MapList(lambda x: x * x, items)
    except:
        return False
    return True

# Generated at 2022-06-23 17:33:32.462833
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from nose.tools import assert_list_equal, assert_equal, assert_raises

    # simple example
    lst = LazyList(range(10))
    for i, x in zip(range(5), lst):
        assert_equal(i, x)
    assert_equal(0, len(lst.list))
    for i, x in zip(range(5), lst):
        assert_equal(i + 5, x)
    assert_equal(10, len(lst.list))

    # __next__ completes before __len__ is called
    lst = LazyList(range(10))
    it = iter(lst)
    assert_equal(0, next(it))
    assert_equal(1, next(it))
    assert_raises(TypeError, lambda: len(lst))


# Generated at 2022-06-23 17:33:37.615427
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda x,y: x+y, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a','b','c','d'])) == ['abcd','bcd','cd','d']
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']

# Generated at 2022-06-23 17:33:39.810973
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    try:
        Range(1, 2, 0)
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-23 17:33:46.415223
# Unit test for function chunk
def test_chunk():
    assert [list(x) for x in chunk(0, range(10))] == []
    assert [list(x) for x in chunk(1, range(10))] == [[i] for i in range(10)]
    assert [list(x) for x in chunk(3, range(10))] == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-23 17:33:52.185612
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:33:58.299796
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    import random
    import unittest

    class TestLazyList__len__(unittest.TestCase):
        def test_exhausted(self):
            n = random.randint(0, 100)
            xs = LazyList(range(n))
            self.assertEqual(len(xs), n)
            with self.assertRaises(TypeError):
                len(xs)

    unittest.main()

    test_LazyList___len__()
    test_LazyList___len__()


# Generated at 2022-06-23 17:34:00.848474
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    import random
    def rand(x):
        return random.randint(0,100)
    a = MapList(rand,range(10))
    b = MapList(rand,range(10))
    assert(a==b)
    assert(len(a)==10)

# Generated at 2022-06-23 17:34:01.539192
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__(): pass

# Generated at 2022-06-23 17:34:09.533589
# Unit test for function scanl
def test_scanl():
    import operator
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    # Test when list is empty
    assert list(scanl(operator.add, [], 0)) == [0]



# Generated at 2022-06-23 17:34:13.104395
# Unit test for method __len__ of class MapList
def test_MapList___len__(): 
    with pytest.raises(NotImplementedError) as e:
        MapList(0, 0).__len__()
    assert e.value.args[0] == 'Not implemented'

# Generated at 2022-06-23 17:34:20.059870
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x * x, a) == [1, 4, 9, 16, 25]
    assert sum(MapList(lambda x: x * x, a)) == 55
    assert sum(MapList(lambda x: x * x, a[:3])) == 14
    assert sum(MapList(lambda x: x * x, a[2:])) == 50
    assert sum(MapList(lambda x: x * x, a[::2])) == 30
    assert sum(MapList(lambda x: x * x, a[1::2])) == 25


# Generated at 2022-06-23 17:34:32.475774
# Unit test for function chunk
def test_chunk():
    for n in range(5):
        assert list(chunk(n, [])) == []
        assert list(chunk(n, range(n))) == [[x] for x in range(n)]
        assert list(chunk(n, range(3*n))) == [[x]*n for x in range(3)]
        assert list(chunk(n, range(3*n+1))) == [[x]*n for x in range(3)] + [[3*n]]
        assert list(chunk(n, range(3*n+2))) == [[x]*n for x in range(3)] + [[3*n], [3*n+1]]

# Generated at 2022-06-23 17:34:41.585549
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert [x for x in LazyList([1, 2, 3])] == [1, 2, 3]  # exhaust the iterable
    assert [x for x in LazyList([1, 2, 3])] == [1, 2, 3]  # use the cached list
    assert list(LazyList([1, 2, 3])) == [1, 2, 3]  # call __iter__ explicitly
    assert [x for x in LazyList([1, 2, 3])[:10]] == [1, 2, 3]  # get some elements
    assert [x for x in LazyList([1, 2, 3])[10:]] == []  # get all elements
    assert [x for x in LazyList([1, 2, 3])[:]] == [1, 2, 3]  # can use ":"
# Unit test

# Generated at 2022-06-23 17:34:43.916107
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for i in Range(0, 10):
        print(i)


# Generated at 2022-06-23 17:34:46.454238
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]



# Generated at 2022-06-23 17:34:58.063837
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, [])) == []
    assert list(scanl(lambda s, x: x + s, [], "z")) == ["z"]
    try:
        list(scanl(None, []))
    except TypeError:
        pass

# Generated at 2022-06-23 17:35:03.689080
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    _method_called_times = [0]
    class TestStubRange(Range):
        def __init__(self, *args):
            self.l = 0
            self.r = 4
            self.step = 1
            self.val = self.l
            self.length = (self.r - self.l) // self.step
        def __iter__(self) -> Iterator[int]:
            _method_called_times[0] += 1
            return Range(self.l, self.r, self.step)
        def __next__(self) -> int:
            if self.val >= self.r:
                raise StopIteration
            result = self.val
            self.val += self.step
            return result
    stub_range = TestStubRange()

# Generated at 2022-06-23 17:35:11.579164
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    # ___iter___(self) -> Iterator[R]
    # Check if functions match their specifications
    mpl = MapList(int, ['1', '2', '3', '4', '5'])
    ite = mpl.__iter__()
    assert isinstance(ite, Iterator)
    assert next(ite) == 1
    assert next(ite) == 2
    assert next(ite) == 3
    assert next(ite) == 4
    assert next(ite) == 5
    try:
        next(ite)
        assert False, "Expected StopIteration exception"
    except:
        pass

# Generated at 2022-06-23 17:35:12.843030
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    it = Range(10).__iter__()
    assert it is not None

# Generated at 2022-06-23 17:35:16.241497
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:35:26.151881
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    
    with pytest.raises(ValueError):
        list(split_by(" Split by: "))
        
    with pytest.raises(ValueError):
        list(split_by(" Split by: ", criterion=lambda x:1 , separator='.'))
        

# Generated at 2022-06-23 17:35:30.534304
# Unit test for function drop_until
def test_drop_until():
    predicate = lambda x: x > 5
    true_iterator = iter(range(10))
    false_iterator = range(10)
    yield from drop_until(predicate, true_iterator)
    yield from drop_until(predicate, false_iterator)
    assert list(true_iterator) == [6, 7, 8, 9]
    assert list(false_iterator) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:35:33.547502
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10))==10
    assert len(Range(1, 11))==10
    return True



# Generated at 2022-06-23 17:35:36.688291
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass


# Generated at 2022-06-23 17:35:40.576278
# Unit test for function drop
def test_drop():
    it=drop(5,range(10))
    assert next(it) == 5
    assert next(it) == 6
    assert next(it) == 7
    assert next(it) == 8
    assert next(it) == 9


# Generated at 2022-06-23 17:35:51.957897
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # init
    func_ = lambda idx: a[idx] * b[idx] if idx is not None else None
    a = [1, 2, 3]
    b = [5, 4, 3]
    lst = MapList(func_, a)
    # act
    actual = lst[1]
    # assert
    assert actual == 8

    # init
    func_ = lambda idx: a[idx] * b[idx] if idx is not None else None
    a = [1, 2, 3]
    b = [5, 4, 3]
    lst = MapList(func_, a)
    # act
    actual = lst[0]
    # assert
    assert actual == 5

    # init
    func_ = lambda idx: a[idx] * b

# Generated at 2022-06-23 17:36:01.314426
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda x: x // 2
    lst = [3, 2, 5, 4, 6, 1]
    m = MapList(func, lst)
    assert [m[i] for i in range(len(lst))] == list(m)
    assert m[:] == [func(x) for x in lst]
    assert m[1:4] == [func(x) for x in lst[1:4]]


# Generated at 2022-06-23 17:36:10.299978
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # case 1:
    r = Range(10)
    assert r[0] == r.l
    assert r[-10] == r.l
    assert r[-1] == r.r - 1
    r = Range(1, 10 + 1)
    assert r[0] == r.l
    assert r[-10] == r.l
    assert r[-1] == r.r - 1
    r = Range(1, 11, 2)
    assert r[0] == r.l
    assert r[-6] == r.l
    assert r[-1] == r.r - 1

    # case 2:
    r = Range(10)
    assert r[0:3] == [0, 1, 2]
    assert r[-2:-1] == [8]

# Generated at 2022-06-23 17:36:14.008438
# Unit test for function scanl
def test_scanl():
    func = lambda s, x: x + s
    assert list(scanl(func, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-23 17:36:25.169756
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    data = [1, 2, 3, 4, 5]
    lst = MapList(lambda x: x * x, data)

    assert lst[0] == lst[1] == 1
    assert lst[2] == 3
    assert lst[3] == 4
    assert lst[4] == 5

    assert lst[:5] == [1, 1, 3, 4, 5]
    assert lst[1:4] == [1, 3, 4]
    assert lst[::2] == [1, 3, 5]

    assert lst[-1] == 5
    assert lst[-2] == 4



# Generated at 2022-06-23 17:36:32.588551
# Unit test for method __len__ of class Range
def test_Range___len__():
    # Check case __init__(self, start: int, stop: int)
    i0_start = random.randint(-100, 100)
    i0_stop = random.randint(-100, 100)
    i0_range = Range(i0_start, i0_stop)
    i0_expected_length = ((i0_stop - i0_start) // 1)
    i0_length = len(i0_range)
    assert (i0_length == i0_expected_length), "test 0: expected {}, got {}".format(i0_expected_length, i0_length)

    # Check case __init__(self, stop: int)
    i1_stop = random.randint(-100, 100)
    i1_range = Range(i1_stop)
    i1_expected_length

# Generated at 2022-06-23 17:36:36.706315
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5


# Generated at 2022-06-23 17:36:38.026051
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1, 2, 3])) == 3


# Generated at 2022-06-23 17:36:46.878362
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lls = LazyList(range(1000))
    assert lls[0] == 0
    assert lls[1] == 1
    assert lls[10] == 10
    assert len(lls) == 1000
    assert lls[-1] == 999
    assert lls[5:50:5] == [5, 10, 15, 20, 25, 30, 35, 40, 45]
    assert lls[50:5:-5] == [50, 45, 40, 35, 30, 25, 20, 15, 10]
    assert lls[25:30:2] == [25, 27, 29]

# Generated at 2022-06-23 17:36:54.019108
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(-1, range(10))) == []
    assert list(chunk(8, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7], [8, 9]]

# END Unit test for function chunk


# Generated at 2022-06-23 17:36:57.724447
# Unit test for function drop
def test_drop():
    lst = [1, 2, 3, 4, 5]
    assert list(drop(3, lst)) == [4, 5]
    assert list(drop(6, lst)) == []



# Generated at 2022-06-23 17:36:59.879042
# Unit test for function drop_until
def test_drop_until():
    for i in range(-10, 10):
        assert list(drop_until(lambda x: x > 0, range(i))) == list(filter(lambda x: x > 0, range(i)))



# Generated at 2022-06-23 17:37:03.987111
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range = Range(10)         # (end)
    # range = Range(1, 10 + 1)  # (start, end)
    # range = Range(1, 11, 2)   # (start, end, step)
    print(range[0], range[2], range[4])
    print(range[:], range[:5], range[2:5])


# Generated at 2022-06-23 17:37:09.404279
# Unit test for function drop_until
def test_drop_until():
    # test 1
    print(list(drop_until(lambda x: x > 5, range(10))))
    # test 2
    print(list(drop_until(lambda x: x > 5, range(3))))



# Generated at 2022-06-23 17:37:11.689522
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    """Tests that __iter__ works as expected."""
    assert list(MapList(lambda x: x*2, [1, 2, 3])) == [2, 4, 6]

# Generated at 2022-06-23 17:37:23.818865
# Unit test for function split_by
def test_split_by():
    # Testing criterion
    assert list(split_by(range(12), criterion=lambda x: x % 3 == 0)) == [[1,2],[4,5],[7,8],[10,11]]
    # Testing separator
    assert list(split_by(range(12), separator=3)) == [[0,1,2],[4,5,6],[7,8,9],[10,11]]
    # Testing empty_segments
    assert list(split_by(range(12), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1,2], [], [4,5], [], [7,8], [], [10,11]]