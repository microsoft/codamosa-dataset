

# Generated at 2022-06-23 17:27:24.533137
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    n = random.randrange(0, 100)
    arr = list(range(n))
    lst = LazyList(arr)

    for i in range(n):
        assert lst[i] == arr[i]
    if n > 0:
        assert lst[-1] == arr[-1]

    assert lst[:2] == arr[:2]
    assert lst[1:3] == arr[1:3]
    assert lst[n-2:] == arr[n-2:]
    assert lst[:] == arr[:]

    if n > 0:
        assert lst[::2] == arr[::2]
    assert lst[1::2] == arr[1::2]

# Generated at 2022-06-23 17:27:34.115485
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2, 3, 4, 5, 6, 7, 8], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    try:
        list(split_by([]))
    except ValueError:
        pass
    else:
        assert False, "Accepted `split_by` with neither `criterion` nor `separator`"
    try:
        list(split_by([], criterion=lambda x: False, separator=None))
    except ValueError:
        pass

# Generated at 2022-06-23 17:27:46.609352
# Unit test for method __next__ of class Range
def test_Range___next__():
    it = Range(2, 1)
    try:
        next(it)
        assert False
    except StopIteration:
        pass
    r = Range(1, 1)
    try:
        next(r)
        assert False
    except StopIteration:
        pass
    r = Range(1, 2)
    assert next(r) == 1
    try:
        next(r)
        assert False
    except StopIteration:
        pass
    r = Range(2, 3)
    assert next(r) == 2
    try:
        next(r)
        assert False
    except StopIteration:
        pass
    r = Range(1, 10)
    assert [next(r) for _ in range(9)] == [i for i in range(1, 10)]

# Generated at 2022-06-23 17:27:56.135609
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by([], empty_segments=True)) == [[]]
    assert list(split_by([4, '4'], criterion=lambda x: x > 1)) == [[], [4], ['4']]
    assert list(split_by([4, '4'], criterion=lambda x: x > 1, empty_segments=True)) == [[], [4], [], ['4']]

# Generated at 2022-06-23 17:28:03.425753
# Unit test for constructor of class Range
def test_Range():
    for constructor in (
            lambda start, end: Range(start, end + 1),
            lambda start, end: Range(start, end, 2),
            lambda start, end: Range(end - start)
    ):
        r1 = constructor(0, 10)
        r2 = constructor(0, 20)
        assert r1[0] == r1[-10] == r2[0] == r2[-20] == 0
        assert r1[1] == r1[-9] == r2[1] == r2[-19] == 1
        assert r1[2] == r1[-8] == r2[2] == r2[-18] == 2
        assert r1[3] == r1[-7] == r2[3] == r2[-17] == 3

# Generated at 2022-06-23 17:28:11.921979
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    'Unit test for method __iter__ of class Range'
    import random
    import itertools
    for _ in range(10):
        t1 = random.randint(1, 10)
        t2 = random.randint(t1, 10)
        t3 = random.randint(1, 5)
        for _ in range(3):
            r = Range(t1, t2, t3)
            i = -42
            for v in r:
                assert v == i
                i += t3
            assert i == t2



# Generated at 2022-06-23 17:28:14.434223
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(operator.add(1), [0, 1, 2])) == [1, 2, 3]


# Generated at 2022-06-23 17:28:21.206551
# Unit test for function drop_until
def test_drop_until():
    a = [1, 2, 3, 4, 5, 6]
    b = [1, 2, 3, 4, 5, 6, 7]
    c = [2, 3, 4, 5, 6]
    d = [1, 9999, 2, 3, 4, 5, 6]
    assert list(drop_until(lambda x: x > 5, a)) == [6]
    assert list(drop_until(lambda x: x > 5, b)) == [6, 7]
    assert list(drop_until(lambda x: x > 5, c)) == [2, 3, 4, 5, 6]
    assert list(drop_until(lambda x: x > 5, d)) == [9999, 2, 3, 4, 5, 6]



# Generated at 2022-06-23 17:28:24.257228
# Unit test for function drop
def test_drop():
    for n in range(0, 20):
        for i in range(100):
            assert len(list(drop(n, range(i)))) == max(i - n, 0)


# Generated at 2022-06-23 17:28:28.484866
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 10 + 1)
    assert list(r) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(r) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-23 17:28:38.763693
# Unit test for constructor of class Range
def test_Range():
    # Range default case: Range(10)
    assert Range(10) == range(10)
    # Range single parameter case: Range(1,10)
    assert Range(1,10) == range(1,10)
    # Range triple parameter case: Range(1,10,step = 2)
    assert Range(1,10,2) == range(1,10,2)
    # Test __iter__()
    assert Range(1,10,2) == [1,3,5,7,9]
    # Test __next__()
    r = Range(1,10,2)
    assert r.__next__() == 1
    r.next()
    assert r.__next__() == 3
    # Test __len__()
    r = Range(1,10,2)

# Generated at 2022-06-23 17:28:40.068717
# Unit test for function scanl
def test_scanl():
    return assertEqual(list(scanl(operator.add, [1, 2, 3, 4], 0)), [0,1,3,6,10])



# Generated at 2022-06-23 17:28:42.983815
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x * x, range(5))) == [0, 1, 4, 9, 16]
    assert list(MapList(lambda x: x * x, [])) == []


# Generated at 2022-06-23 17:28:47.867466
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [3, 2, 1])) == [3, 5, 6]
    assert list(scanl(operator.mul, [3, 2, 1])) == [3, 6, 6]
    sum_list, product_list = scanl(operator.add, [3, 2, 1]), scanl(operator.mul, [3, 2, 1])
    assert isinstance(sum_list, Iterator)
    assert isinstance(product_list, Iterator)



# Generated at 2022-06-23 17:28:50.485842
# Unit test for method __len__ of class Range
def test_Range___len__():
    with testing.Tester() as t:
        r = Range(1, 10)
        t.assertEqual(10, len(r))

# Generated at 2022-06-23 17:29:02.370509
# Unit test for function scanl
def test_scanl():
    #List comprehension
    x = [1,2,3]
    y = 0
    assert [0,1,3,6] == list(scanl(lambda s, x: x + s, x, y))
    assert [1,2,4,7] == list(scanl(lambda s, x: x + s, x))
    assert [1,2,6,24] == list(scanl(lambda s, x: x * s, x))
    assert [1,2,4,12] == list(scanl(lambda s, x: x * s, x, y))
    assert ["1","21","321","4321"] == list(scanl(lambda s, x: str(x) + s, x, y))

# Generated at 2022-06-23 17:29:06.597430
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    with pytest.raises(TypeError):
        x: LazyList[int] = LazyList(range(1))
        x.__len__()
    assert len(LazyList(range(1))) == 1



# Generated at 2022-06-23 17:29:12.949603
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)                  # (end)
    print(r[0], r[2], r[4])        # (start, end)
    r = Range(1, 10+1)
    print(r[0], r[2], r[4])        # (start, end, step)
    r = Range(1, 11, 2)
    print(r[0], r[2], r[4])

try:
    from collections.abc import Mapping, MutableMapping
except ImportError:
    from collections import Mapping, MutableMapping
# For pytest doctest
del Mapping
del MutableMapping



# Generated at 2022-06-23 17:29:21.301077
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, range(1, 6))) == [10, 9, 7, 4, 0]
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:29:33.376315
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    def check(lst, index, expected):
        result = LazyList(lst)[index]
        assert result == expected, f"Got {result}, expected {expected}"

    check(list(range(100)), 0, 0)
    check(list(range(100)), 99, 99)
    check(list(range(100)), 100, IndexError)
    check(list(range(100)), -1, 99)
    check(list(range(0))[::-1], 0, IndexError)
    check(list(range(0))[::-1], -1, IndexError)

    check(lst=list(range(5)), index=slice(3), expected=list(range(3)))

# Generated at 2022-06-23 17:29:43.756393
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from pyx.utils import chunk
    from pyx.utils.iterator import take, drop, drop_until, split_by, scanl, scanr
    from pyx.utils.iterator import LazyList

    # Taken from: https://gist.github.com/GillesArcas/5776725
    def isprime(num: int) -> bool:
        """Returns True if the number is prime
        else False."""
        if num == 0 or num == 1:
            return False
        for x in range(2, num):
            if num % x == 0:
                return False
        else:
            return True

    LazyListPrimes = LazyList(filter(isprime, map(lambda x: x * x, count(1))))

    # Test if it can be used with indexing

# Generated at 2022-06-23 17:29:52.908286
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    with pytest.raises(TypeError, match="__len__ is not available before the iterable is depleted"):
        len(LazyList(range(10)))
    assert list(LazyList(range(10))) == list(range(10))
    assert LazyList(range(10))[1] == 1
    assert LazyList(range(10))[-1] == 9
    assert list(LazyList(range(10))[1:3]) == [1, 2]
    assert list(LazyList(range(10))[1:1]) == []
    assert list(LazyList(range(10))[1:]) == list(range(1, 10))
    assert list(LazyList(range(10))[2::2]) == list(range(2, 10, 2))

# Generated at 2022-06-23 17:29:55.486795
# Unit test for function drop_until
def test_drop_until():
    it = drop_until(lambda x: x > 5, range(10))
    assert(next(it) == 6)
    assert(next(it) == 7)



# Generated at 2022-06-23 17:30:06.012092
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 1, [1,2,3,4,5])) == [2,3,4,5]
    assert list(drop_until(lambda x: x == 3, [1,2,3,4,5])) == [3,4,5]
    assert list(drop_until(lambda x: x == 0, [1,2,3,4,5])) == []
    assert list(drop_until(lambda x: x == 1, [-3,-2,-1,0,1,2,3,4,5])) == [1,2,3,4,5]


# Generated at 2022-06-23 17:30:06.909164
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    map_list = MapList(None, None)
    len(map_list)


# Generated at 2022-06-23 17:30:09.965563
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(0, 5)
    assert next(r) == 0
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4

# Generated at 2022-06-23 17:30:20.699047
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    import string
    rng = random.Random()
    rng.seed(1234567890)
    # Create a list of random strings with length within [16, 32)
    large_list = [''.join([rng.choice(string.ascii_letters) for _ in range(16, rng.randint(32, 96))])
                  for _ in range(rng.randint(16, 128))]
    # Create a lazy list from the list
    lazy_list = LazyList(large_list)
    # Check if LazyList is actually lazy
    lazy_list._fetch_until(0)
    assert len(lazy_list) == len(large_list), \
        "LazyList is not actually lazy!"
    # Check if method __getitem__ of class LazyList works
   

# Generated at 2022-06-23 17:30:22.783129
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    count = 0
    for _ in LazyList(range(2)):
        count += 1
        break
    assert count == 1

# Generated at 2022-06-23 17:30:25.141337
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList([1,2,3])
    assert isinstance(l, LazyList)
    assert len(l) == 3



# Generated at 2022-06-23 17:30:32.964362
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Test cases for method Range.__getitem__
    # Input arguments:
    #   self = <__main__.Range object at 0x2fd58c8>
    #   idx = 0

    # Test case 1 (normal):
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    print([(0, 1), (2, 5), (4, 9)])
    print([(0, r[0]), (2, r[2]), (4, r[4])])
  
    # Test case 2 (exception):
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end

# Generated at 2022-06-23 17:30:36.708401
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    a = LazyList(range(0, 1))
    b = iter(a)
    assert next(b) == 0
    assert next(b, None) is None


# Generated at 2022-06-23 17:30:44.797827
# Unit test for constructor of class MapList
def test_MapList():
    d = [1, 2, 3, 4, 5]
    cp = MapList(lambda x: x, d)
    cp[1] = 2
    cp[2] = 3
    cp[3] = 4
    assert cp[1] == 2
    assert cp[2] == 3
    assert cp[3] == 4
    assert cp[0] == 1
    assert cp[4] == 5
    cp = MapList(lambda x: x, d)
    assert cp[0:2] == [1, 2]
    assert cp[2:4] == [3, 4]



# Generated at 2022-06-23 17:30:57.034455
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from typing import Iterator, List, Tuple
    from random import Random
    
    def _test_equal(iterator: Iterator[int], correct_result: List[int]) -> None:
        result = list(iterator)
        assert result == correct_result, "Result: {}\nExpected: {}".format(
            result, correct_result)

    rng = Random(2)
    for _ in range(100):
        lst = []
        for _ in range(rng.randint(1, 100)):
            lst.append(rng.randint(0, 100))
        ll = LazyList(lst)
        _test_equal(ll.__iter__(), lst)

# Generated at 2022-06-23 17:31:05.900930
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from typing import Tuple
    from itertools import count
    import random
    lst = LazyList(count(1))
    last_idx = random.randint(10, 999)
    try:
        x = lst[last_idx]
    except IndexError:
        pass
    len_lst = len(lst)
    assert x == last_idx + 1
    assert len_lst == last_idx + 1
    assert lst[-1] == last_idx + 1
    assert lst[2: 10: 2] == list(range(3, 11, 2))
test_LazyList___getitem__()

# Generated at 2022-06-23 17:31:08.674831
# Unit test for function scanr
def test_scanr():
    l = list(range(10))
    assert list(scanr(operator.add, l)) == [45, 44, 42, 39, 35, 30, 24, 17, 9, 0]



# Generated at 2022-06-23 17:31:10.950412
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    obj = Range(0, 10, 2)
    assert(list(obj) == list(range(0, 10, 2)))
    assert(next(obj) == 0)
    iter_obj = iter(obj)
    assert(next(iter_obj) == 2)
    iter_obj = iter(obj)
    assert(next(iter_obj) == 4)


# Generated at 2022-06-23 17:31:23.448357
# Unit test for constructor of class LazyList
def test_LazyList():
    from collections import deque
    L = LazyList(deque([0, 1, 2, 3, 4, 5]))
    assert list(L) == [0, 1, 2, 3, 4, 5]
    assert L[2:] == [2, 3, 4, 5]
    assert L[:2] == [0, 1]
    assert L[::-1] == [5, 4, 3, 2, 1, 0]
    assert L[-1] == 5
    assert L[:] == [0, 1, 2, 3, 4, 5]
    assert len(L) == 6
    try:
        len(deque())
    except TypeError:
        pass
    else:
        raise AssertionError("len(deque()) should fail")

# Generated at 2022-06-23 17:31:28.702208
# Unit test for constructor of class MapList
def test_MapList():
    for lst in ([1, 2], []):
        lst = MapList(lambda x: x + 1, lst)
        assert len(lst) == len(lst.list)
        assert all(map(lambda x: x[0] == x[1], zip(lst, map(lambda x: x + 1, lst.list))))
        assert tuple(lst) == tuple(map(lambda x: x + 1, lst.list))



# Generated at 2022-06-23 17:31:41.097342
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    def check(item, result):
        assert item == result, "item: {}, result: {}".format(item, result)

    r = Range(1, 4)
    check(r[0], 1)
    check(r[1], 2)
    check(r[-1], 3)

    r = Range(0, 10, 2)
    check(r[0], 0)
    check(r[1], 2)
    check(r[2], 4)

    check(r[:], [0, 2, 4, 6, 8])
    check(r[:3], [0, 2, 4])
    check(r[:100], [0, 2, 4, 6, 8])
    check(r[1:3], [2, 4])
    check(r[:3:2], [0, 4])

# Generated at 2022-06-23 17:31:43.309630
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList([])) == 0
    assert len(LazyList(range(1000000))) == 1000000
    with pytest.raises(TypeError):
        len(LazyList(range(1)))



# Generated at 2022-06-23 17:31:55.366827
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[1, 2], [], [4, 5], [], [
        7, 8]]
    assert list(split_by("Split by:", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], [
        'b', 'y', ':'], []]

# Generated at 2022-06-23 17:32:03.098108
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_ = Range(1, 10 + 1) 
    for i in range(10):
        try:
            assert range_.__getitem__(i) == i + 1
        except AssertionError:
            print('Expected {}, but got {}'.format(i + 1, range_.__getitem__(i)))
            print(traceback.format_exc())
            return False
    return True


# Generated at 2022-06-23 17:32:10.593959
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Test for positive indices
    lst = LazyList(range(10))
    for i in range(10):
        assert lst[i] == i
        assert list(lst) == list(range(i + 1))

    # Test for negative indices
    lst = LazyList(range(10))
    for i in range(-10, 0):
        assert lst[i] == i + 10
        assert list(lst) == list(range(10 + i + 1))

    # Test for slicing
    lst = LazyList(range(10))
    for i in range(10):
        assert lst[:i] == list(range(i))
        assert list(lst) == list(range(i))

# Generated at 2022-06-23 17:32:18.429572
# Unit test for method __next__ of class Range
def test_Range___next__():
    for x in [1, 2, 3, 4]:
        assert x == Range(x).__next__()
    for i, x in enumerate(Range(1, 10 + 1)):
        assert x == i + 1
    for i, x in enumerate(Range(2, 12, 2)):
        assert x == i * 2 + 2
    try:
        Range(3).__next__()
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-23 17:32:22.925094
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: 2*x, [1,2,3])[0] == 2
    assert MapList(lambda x: 2*x, [1,2,3])[1] == 4
    assert MapList(lambda x: 2*x, [1,2,3])[2] == 6

# Generated at 2022-06-23 17:32:28.946402
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:32:32.320686
# Unit test for constructor of class LazyList
def test_LazyList():
    from .iterable import tolist

    lazy_list = LazyList(range(1000000))
    assert tolist(lazy_list) == list(range(1000000))


# Generated at 2022-06-23 17:32:36.466778
# Unit test for constructor of class MapList
def test_MapList():
    l = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert l[3] == 16
    assert l[2:4] == [9, 16]
    assert list(l) == [1, 4, 9, 16, 25]

# Generated at 2022-06-23 17:32:37.494507
# Unit test for constructor of class LazyList
def test_LazyList():
    a=LazyList([1,2,3,4,5])


# Generated at 2022-06-23 17:32:42.945259
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3]
    mpl = MapList(lambda x: x + 1, lst)
    assert list(mpl) == [x + 1 for x in lst]
    assert mpl[0] == 2
    assert mpl[0:3] == [x + 1 for x in lst]


# Generated at 2022-06-23 17:32:46.196114
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for v in [Range(10), Range(1, 11), Range(1, 11, 2)]:
        for idx, x in enumerate(v):
            assert x == idx


# Generated at 2022-06-23 17:32:48.179745
# Unit test for constructor of class LazyList
def test_LazyList():
    it = range(100)
    lazy_it = LazyList(it)
    test.equal(lazy_it[0], 0)



# Generated at 2022-06-23 17:32:50.029482
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    pass

    #self._fetch_until(None)



# Generated at 2022-06-23 17:33:00.134874
# Unit test for constructor of class LazyList
def test_LazyList():
    assert LazyList([0, 1, 2])[1] == 1
    assert list(LazyList([0, 1, 2])) == [0, 1, 2]
    assert list(LazyList([0, 1, 2])[:2]) == [0, 1]
    assert LazyList([0, 1, 2])[2] == 2
    assert LazyList([0, 1, 2])[:3] == [0, 1, 2]
    assert LazyList([0, 1, 2])[:4] == [0, 1, 2]
    assert LazyList([0, 1, 2])[:3] == [0, 1, 2]

# Generated at 2022-06-23 17:33:05.317958
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for lst in [MapList, MapList[str], MapList[str, list]]:
        assert lst(str.upper, 'abc') == ['A', 'B', 'C']
        assert lst(str.upper, 'abc')[1] == 'B'
        assert lst(str.upper, 'abc')[0:2] == ['A', 'B']


# Generated at 2022-06-23 17:33:09.830854
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3, 4, 5])
    assert len(list(lst)) == len(list(lst))  # repeated __iter__ should yield the same sequence

# Generated at 2022-06-23 17:33:15.607372
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from utils import MapList

    assert MapList(lambda x: x * x, [1, 2, 3])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3])[-1] == 9
    assert MapList(lambda x: x * x, [1, 2, 3])[1:3] == [4, 9]


# Generated at 2022-06-23 17:33:27.662528
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 0, list(range(10))[::-1])) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(1, 10, 2))) == [6, 8]
    assert list(drop_until(lambda x: x > 5, range(0, 10, 2))) == []
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 4, 3, 2, 1, 6])) == [6]
    assert list(drop_until(lambda x: x > 5, [])) == []



# Generated at 2022-06-23 17:33:28.849672
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    pass


# Generated at 2022-06-23 17:33:32.965192
# Unit test for function drop
def test_drop():
    lst = [1,2,3,4,5,6]
    assert drop(1, lst) == [2,3,4,5,6]
    assert drop(3, lst) == [4,5,6]
    assert drop(7, lst) == []
    # my_iter = (x for x in lst)
    # assert drop(3, my_iter) == [4,5,6]


# Generated at 2022-06-23 17:33:35.081882
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    mlist = MapList(lambda x: x, [])
    assert len(mlist) == 0

# Generated at 2022-06-23 17:33:37.377819
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    a = LazyList(range(5))
    assert list(iter(a)) == list(range(5))

# Generated at 2022-06-23 17:33:44.851544
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    tester = Range(10)
    assert list(tester) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    tester = Range(1, 10 + 1)
    assert list(tester) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    tester = Range(1, 11, 2)
    assert list(tester) == [1, 3, 5, 7, 9]

# Generated at 2022-06-23 17:33:54.522609
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # test case 1
    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert pos == 3

    # test case 2
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2


# Generated at 2022-06-23 17:33:57.584694
# Unit test for method __len__ of class Range
def test_Range___len__():
    print(Range(10, 100, 5) == range(10, 100, 5))
    print(len(Range(10, 100, 5)) == len(range(10, 100, 5)))


# Generated at 2022-06-23 17:34:00.482151
# Unit test for constructor of class Range
def test_Range():
    assert Range(0, 4, 1) == list(range(0, 4, 1))
    assert Range(1, 5, 1) == list(range(1, 5, 1))
    assert Range(1, 6, 2) == list(range(1, 6, 2))
    assert Range(3) == list(range(3))


# Generated at 2022-06-23 17:34:11.989148
# Unit test for constructor of class Range
def test_Range():
    r = Range(stop=10)
    assert r[0] == 0
    assert r[-1] == 9
    assert len(r) == 10
    assert isinstance(r, Sequence)
    assert list(r) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(r[3:7]) == [3, 4, 5, 6]
    assert list(r[3:]) == [3, 4, 5, 6, 7, 8, 9]
    assert list(r[:7]) == [0, 1, 2, 3, 4, 5, 6]
    assert list(r[3::2]) == [3, 5, 7, 9]
    assert list(r[:7:2]) == [0, 2, 4, 6]


# Generated at 2022-06-23 17:34:18.702725
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda a, b: a + b, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, [1, 2, 3])) == [1, 3, 6]
test_scanl()



# Generated at 2022-06-23 17:34:20.876304
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert len(r) == 10
    r = Range(1, 10 + 1)
    assert len(r) == 10
    r = Range(1, 11, 2)
    assert len(r) == 5

# Generated at 2022-06-23 17:34:32.749175
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(1, 10)) == list(range(1, 10))
    assert list(Range(1, 10, 2)) == list(range(1, 10, 2))
    assert list(Range(10)) == list(range(10))
    assert list(Range()) == list(range(0))
    assert len(Range(10)) == 10
    assert len(Range(1, 10)) == 9
    assert len(Range(1, 10, 2)) == 5
    assert Range(1, 10)[0] == 1
    assert Range(1, 10)[1] == 2
    assert Range(1, 10)[-1] == 9
    assert Range(1, 10)[-2] == 8
    assert Range(1, 10)[0:2] == [1, 2]

# Generated at 2022-06-23 17:34:36.536965
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert tuple(Range(1, 5, 2)) == (1, 3)
    assert list(Range(1, 5, 2)) == [1, 3]
    assert list(Range(5)[1:5:2]) == [1, 3]


# Generated at 2022-06-23 17:34:42.578045
# Unit test for constructor of class MapList
def test_MapList():
    #This is a set of unit tests for the constructor of class MapList
    def f(x):
        return x+3
    def g(x):
        return 2*x
    def h(x):
        return x**2
    a = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    l = MapList(f, a)
    assert l[2] == 5
    l = MapList(g, a)
    assert l[2] == 4
    l = MapList(h, a)
    assert l[3] == 9


# Generated at 2022-06-23 17:34:47.677579
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from unittest.mock import MagicMock, call
    from . import filter
    lst = LazyList(filter(lambda x: x != 3, [1, 2, 3, 4]))
    assert list(lst) == [1, 2, 4]
    lst = LazyList([1, 2, 3, 4])
    assert list(iter(lst)) == [1, 2, 3, 4]
    lst = LazyList([1, 2, 3, 4])
    assert list(lst.__iter__()) == [1, 2, 3, 4]
    lst = LazyList([1, 2, 3, 4])
    lst.__next__ = MagicMock()
    assert list(iter(lst)) == [1, 2, 3, 4]
    assert lst.__next__

# Generated at 2022-06-23 17:34:58.472661
# Unit test for function split_by
def test_split_by():
    # Test separator
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    with pytest.raises(ValueError):
        list(split_by(" Split by: ", empty_segments=True, separator='.', criterion=(lambda x: x == '.')))
    with pytest.raises(ValueError):
        list(split_by(" Split by: ", empty_segments=True, criterion=(lambda x: x == '.')))

    # Test criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]

# Generated at 2022-06-23 17:35:03.402975
# Unit test for constructor of class MapList
def test_MapList():
    # range(index)
    assert (MapList(lambda x: x + 1, [0,1,2,3,4,5])[2] == 3)
    # range(index1:index2)
    assert (MapList(lambda x: x + 1, [0,1,2,3,4,5])[2:4] == [3,4])
    # range(index1:index2:index3)
    assert (MapList(lambda x: x + 1, [0,1,2,3,4,5])[2:4:2] == [3])

# Generated at 2022-06-23 17:35:06.819775
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from .test_util import assert_eq
    lst = LazyList(range(1000000))
    assert_eq(lst[-1], 999999)
    assert_eq(lst[500000], 500000)
    assert_eq(lst[-10:], list(range(999990, 1000000)))

# Generated at 2022-06-23 17:35:19.334814
# Unit test for method __len__ of class Range
def test_Range___len__():
    class Test_Range___len___Callable:

        def __init__(self, expected_result, length):
            self.expected_result = expected_result
            self.length = length

        def __call__(self, object, *args, **kwargs):
            assert object.__len__() == self.expected_result
            assert len(object) == self.expected_result
            assert object.__len__() == self.length
            assert len(object) == self.length


# Generated at 2022-06-23 17:35:29.693108
# Unit test for function chunk
def test_chunk():
    assert list(chunk(10, range(9))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(2, range(9))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8]]
    assert list(chunk(1, range(9))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8]]
    assert list(chunk(0, range(9))) == []
    assert list(chunk(9, range(9))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8]]

# Generated at 2022-06-23 17:35:35.971470
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    import random
    for _ in range(100):
        l = random.randint(0, 100)
        r = random.randint(l, 100)
        step = random.randint(0, 5)
        r1 = Range(l, r, step)
        r2 = range(l, r, step)
        assert list(r1) == list(r2)

# Generated at 2022-06-23 17:35:41.389060
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert isinstance(lst[-1], int)
    assert isinstance(lst[:], list)
    assert lst[-1] == 9 and lst[:3] == [0, 1, 2]
    assert lst[:] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-23 17:35:51.039576
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3])
    assert lst[0:2] == [1, 2]
    assert lst[:] == [1, 2, 3]
    assert lst[1:3] == [2, 3]
    assert lst[-1] == 3
    assert lst[2:2] == []
    with pytest.raises(IndexError):
        _ = lst[3]
    with pytest.raises(IndexError):
        _ = lst[3:4]
    with pytest.raises(TypeError):
        len(lst)



# Generated at 2022-06-23 17:35:56.097869
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(100, range(10))) == []
    assert list(drop(-5, range(10))) == []
    with pytest.raises(ValueError):
        list(drop(-100, range(10))) == []


# Generated at 2022-06-23 17:35:59.516216
# Unit test for function drop
def test_drop():
    gen = drop(1, (1,))
    try:
        next(gen)
    except StopIteration:
        return
    assert False


# Generated at 2022-06-23 17:36:05.609372
# Unit test for method __len__ of class Range
def test_Range___len__():
    # FIXME: The testing is insufficient
    for mod in [True, False]:
        for start, end, step in [(1, 100, 2), (0, 100, 2), (1, 101, 2), (-1, 100, 1), (1, 100, -1)]:
            r = Range(start, end, step)
            if mod:
                r.__len__()
            else:
                len(r)


# Generated at 2022-06-23 17:36:10.124543
# Unit test for function scanr
def test_scanr():
    """
    Try whether the negative case in scanr works.
    """
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]



# Generated at 2022-06-23 17:36:13.096497
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = LazyList(range(10))
    assert list(it) == list(range(10))
    assert list(it) == list(range(10))



# Generated at 2022-06-23 17:36:20.654878
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-10] == 0
    assert r[-11] == 0
    with raises(IndexError) as _ex:
        r[10]
    r = Range(2, 6)
    assert r[0] == 2
    assert r[1] == 3
    assert r[2] == 4
    assert r[3] == 5
    assert r[-1] == 5
    assert r[-2] == 4
    assert r[-3] == 3
    assert r[-4] == 2
    with raises(IndexError) as _ex:
        r[4]
    with raises(IndexError) as _ex:
        r[-5]
    r

# Generated at 2022-06-23 17:36:23.173865
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: 2 * x, [1, 2, 3])) == 3

# Generated at 2022-06-23 17:36:25.169309
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(_iter(Range(1, 10 + 1))) == list(range(1, 10 + 1))

# Generated at 2022-06-23 17:36:28.747106
# Unit test for constructor of class LazyList
def test_LazyList():
    l = LazyList(range(100))
    assert len(l) == 100
    assert l[8] == 8
    assert l[-1] == 99
    assert l[-2] == 98



# Generated at 2022-06-23 17:36:33.684892
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x + 2, [])) == []
    assert list(MapList(lambda x: x + 2, [1])) == [3]
    assert list(MapList(lambda x: x + 2, [1, 2, 3, 4])) == [3, 4, 5, 6]


# Generated at 2022-06-23 17:36:39.673177
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    range1 = Range(1, 5)
    n = 0
    for i in range1:
        assert (n == 0 and i == 1) or (n == 1 and i == 2) or \
               (n == 2 and i == 3) or (n == 3 and i == 4) or \
               (n == 4 and i == 5)
        n += 1



# Generated at 2022-06-23 17:36:41.387781
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(1000000))) == list(range(1000000))



# Generated at 2022-06-23 17:36:50.727577
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[x for x in range(3)], [x for x in range(3, 6)], [x for x in
                                                                                          range(6, 9)], [9]]

    assert list(chunk(0, range(10))) == []

    assert list(chunk(10, range(10))) == [list(range(10))]

    assert list(chunk(10, range(5))) == [list(range(5))]



# Generated at 2022-06-23 17:36:56.516848
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    x0 = int()
    x1 = MapList(lambda x: x * x, range(10))
    x2 = x1.__len__()
    x3 = int(10)
    x4 = x2 == x3
    return x4

# Generated at 2022-06-23 17:36:58.090429
# Unit test for constructor of class Range
def test_Range():
    print(list(Range(10)))
    print(list(Range(1, 10 + 1)))
    print(list(Range(1, 11, 2)))


# Generated at 2022-06-23 17:37:08.933097
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    check(
        MapList(lambda x: x, [10, 20, 30, 40, 50])[1],
        20,
    )

    check(
        MapList(lambda x: x, [10, 20, 30, 40, 50])[1:3],
        [20, 30],
    )

    check(
        MapList(lambda x: x, [10, 20, 30, 40, 50])[:3],
        [10, 20, 30],
    )

    check(
        MapList(lambda x: x, [10, 20, 30, 40, 50])[3:],
        [40, 50],
    )

    check(
        MapList(lambda x: x, [10, 20, 30, 40, 50])[:],
        [10, 20, 30, 40, 50],
    )



# Generated at 2022-06-23 17:37:17.552773
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(3)
    assert next(r) == 0
    assert next(r) == 1
    assert next(r) == 2
    with pytest.raises(StopIteration):
        next(r)
    r = Range(1, 10 + 1)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    r = Range(1, 11, 2)
    assert next(r) == 1
    assert next(r) == 3
    assert next(r) == 5
