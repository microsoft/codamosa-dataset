

# Generated at 2022-06-23 17:27:19.549922
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList(range(10))
    b = list(a)
    assert len(a) == 10
    assert len(b) == 10
    assert a == b
    c = LazyList(iter(lambda: None, None))
    assert len(c) == 0


# Generated at 2022-06-23 17:27:21.370804
# Unit test for method __len__ of class Range
def test_Range___len__():
  range1 = Range(1, 5)
  assert len(range1) == 4


# Generated at 2022-06-23 17:27:25.391144
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [10, 20, 30, 40, 50]
    for idx in range(len(lst)):
        assert MapList(lambda x: x + 1, lst)[idx] == lst[idx] + 1

    assert MapList(lambda x: x + 1, lst)[0:3] == [x + 1 for x in lst[0:3]]


# Generated at 2022-06-23 17:27:28.034602
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x, []) == []
    assert MapList(lambda x: x, ['a', 'b', 'c']) == ['a', 'b', 'c']
    assert MapList(lambda x: x + 'a', ['a', 'b', 'c']) == ['aa', 'ba', 'ca']


# Generated at 2022-06-23 17:27:31.923911
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(20))) == list(range(5,20))


# Generated at 2022-06-23 17:27:34.443770
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:27:36.304229
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x * x, [1, 2, 3, 4, 5])) == 5



# Generated at 2022-06-23 17:27:38.395996
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList(range(21))
    a[0]



# Generated at 2022-06-23 17:27:49.836073
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[0] == 0
    assert Range(-5, 5)[-1] == 4
    assert Range(-5, 5, 2)[-1] == -3
    assert Range(-5, 5, 2)[0:3] == [-5, -3, -1]
    assert Range(5)[-1] == 4
    assert Range(5)[-6] == -1
    assert Range(5)[6] == -1
    assert (
        Range(-5, 5, 2)[-3:] == [-3, -1, 1]
        or Range(-5, 5, 2)[-3:] == [1, -3, -1]
    )
    assert Range(-5, 5, 2)[-6:] == [-5, -3, -1, 1, 3]

# Generated at 2022-06-23 17:27:53.917291
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    # Test Range.__iter__(self)
    # Iterable
    r1=Range (10)
    assert isinstance (iter (r1), Range)
    # Iterable
    r2=Range (0, 10)
    assert isinstance (iter (r2), Range)
    # Iterable
    r3=Range (0, 10, 2)
    assert isinstance (iter (r3), Range)

# Generated at 2022-06-23 17:27:59.592461
# Unit test for function drop
def test_drop():
	assert list(drop(5,range(10)))== [5,6,7,8,9,]
	assert list(drop(0,range(10)))== list(range(10))
	assert list(drop(10,range(10)))== []
	assert list(drop(2,['a','b','c']))==['c']
	assert list(drop(-2,['a','b','c']))==[]



# Generated at 2022-06-23 17:28:02.190445
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))



# Generated at 2022-06-23 17:28:06.656657
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Test __len__ of class LazyList
    lst = LazyList(range(3))
    # LazyList's __len__ raises ValueError before all elements are consumed
    assert_raises(TypeError, len, lst)
    # consume all elements
    list(lst)
    # LazyList's __len__ should not raise ValueError any more
    assert len(lst) == 3
    assert isinstance(lst, Sequence)
    assert list(lst) == [0, 1, 2]
    lst = LazyList(range(10))
    assert len(lst[:2]) == 2
    assert len(lst[:0]) == 0



# Generated at 2022-06-23 17:28:16.082129
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(0, 5).__getitem__(slice(0, 2)) == [0, 1]
    assert Range(1, 5 + 1).__getitem__(slice(2, 3)) == [3]
    assert Range(1, 11, 2).__getitem__(slice(1, 4)) == [3, 5, 7]
    #
    assert Range(0, 5).__getitem__(slice(None)) == [0, 1, 2, 3, 4]
    assert Range(1, 5 + 1).__getitem__(slice(None)) == [1, 2, 3, 4, 5]
    assert Range(1, 11, 2).__getitem__(slice(None)) == [1, 3, 5, 7, 9]
    #

# Generated at 2022-06-23 17:28:22.059037
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect
    lst1 = [1, 2, 3, 4, 5]
    lst2 = [1, 4, 9, 16, 25]
    lst3 = [5]
    obj1 = MapList(lambda x: x * x, lst1)
    # print(obj1[1])
    # assert obj1[0] == lst2[0]
    # assert bisect.bisect_left(obj1, 10) == 3
    # assert obj1[1:] == lst2[1:]
    assert obj1[:1] == lst2[:1]



# Generated at 2022-06-23 17:28:30.096983
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1, ["A", "B", "C"])) == [["A"], ["B"], ["C"]]
    assert list(chunk(3, ["A", "B", "C"])) == [["A", "B", "C"]]
    assert list(chunk(4, ["A", "B", "C"])) == [["A", "B", "C"]]
    assert list(chunk(0, range(10))) == []



# Generated at 2022-06-23 17:28:33.800838
# Unit test for constructor of class LazyList
def test_LazyList():
    # Test construct a LazyList object
    lazy_list = LazyList(range(10))
    assert isinstance(lazy_list, LazyList)


# Unit tests for __getitem__

# Generated at 2022-06-23 17:28:40.401464
# Unit test for function scanr
def test_scanr():
    a = ['a', 'b', 'c', 'd']
    expected = ['abcd', 'bcd', 'cd', 'd']
    actual = scanr(lambda s, x: x + s, a)
    assert actual == expected

    a = [1, 2, 3, 4]
    expected = [10, 9, 7, 4, 0]
    actual = scanr(operator.add, a, 0)
    assert actual == expected



# Generated at 2022-06-23 17:28:44.245555
# Unit test for constructor of class Range
def test_Range():
    assert Range(1, 10+1) == [1,2,3,4,5,6,7,8,9,10]



# Generated at 2022-06-23 17:28:51.001057
# Unit test for function drop
def test_drop():
    assert tuple(drop(5, range(100))) == tuple(range(5, 100, 1))
    assert tuple(drop(5, range(5))) == tuple()
    assert tuple(drop(-5, range(100))) == tuple(range(100, 0, -1))
    assert tuple(drop(0, range(100))) == tuple(range(100))
    assert tuple(drop(1000000000, range(100))) == tuple()


# Generated at 2022-06-23 17:28:56.726873
# Unit test for constructor of class Range
def test_Range():
    array = list(Range(1, 6, 2))
    assert array == [1, 3, 5]
    array = list(Range(1, 6))
    assert array == [1, 2, 3, 4, 5]
    array = list(Range(6))
    assert array == [0, 1, 2, 3, 4, 5]
    assert array == [0, 1, 2, 3, 4, 5]



# Generated at 2022-06-23 17:29:02.371287
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3])
    assert len(lst) == 3
    assert list(lst) == [1, 2, 3]
    lst = LazyList(repeat(1))
    with pytest.raises(TypeError):
        len(lst)


# Generated at 2022-06-23 17:29:06.174550
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda s, x: s + x, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:29:13.750426
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert list(Range(5)[0:5:2]) == [0, 2, 4]
    assert list(Range(1, 4)[0:3:2]) == [1, 3]
    assert list(Range(1, 8, 2)[0:3:2]) == [1, 5]
    assert list(Range(1, 10, 3)[1:4:2]) == [4, 7]
    assert list(Range(1, 9, 4)[0:4:3]) == [1, 9]
    assert list(Range(0, 8)[-2:]) == [6, 7]
    assert list(Range(1, 9, 4)[-4:]) == [1, 5, 9]
    assert list(Range(1, 9, 4)[-5:-2]) == [1, 5, 9]
test_Range___getitem

# Generated at 2022-06-23 17:29:19.092820
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    with AssertError(TypeError("__len__ is not available before the iterable is depleted")):
        len(MapList(lambda x: x, range(10)))

    with AssertError(TypeError("__len__ is not available before the iterable is depleted")):
        len(MapList(lambda x: x, LazyList(range(10))))



# Generated at 2022-06-23 17:29:25.830944
# Unit test for method __next__ of class Range
def test_Range___next__():
    def test_range(r: Range):
        n = r.__next__
        while True:
            yield n()
    # end def test_range
    def test_next(iterable: Iterable):
        n = iter(iterable).__next__
        while True:
            yield n()
    # end def test_next


# Generated at 2022-06-23 17:29:31.418418
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(3, range(10))) == [0, 1, 2]
    assert list(take(0, range(10))) == []
    assert list(take(-3, range(10))) == []
    assert list(take(5, ())) == []



# Generated at 2022-06-23 17:29:41.155579
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert (Range(10)[0]==0 and Range(10)[2]==2 and Range(10)[4]==4)
    assert (Range(1, 10 + 1)[0]==1 and Range(1, 10 + 1)[2]==3 and Range(1, 10 + 1)[4]==5)
    assert (Range(1, 11, 2)[0]==1 and Range(1, 11, 2)[4]==9)
    assert (Range(1, 11, 2)[0:2]==[1, 3])
    assert (Range(1, 11, 2)[0:2:3]==[1])
    assert (Range(1, 100, 2)[-3:-1]==[97, 99])

# Generated at 2022-06-23 17:29:49.710921
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():

    try:
        len(LazyList(range(0)))
    except Exception as e:
        assert type(e) is TypeError, 'Exception not raised: TypeError'


    try:
        len(LazyList(range(1)))
    except Exception as e:
        assert type(e) is TypeError, 'Exception not raised: TypeError'


    assert len(LazyList(range(10))) == 10, 'Failed for range(10)'


    assert len(LazyList(range(10, 10))) == 0, 'Failed for range(10, 10)'



# Generated at 2022-06-23 17:29:51.007412
# Unit test for method __next__ of class Range
def test_Range___next__():
    x = Range(1, 2, 1)
    assert x.__next__() == 1


# Generated at 2022-06-23 17:30:02.997229
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(0, 10)
    assert len(r1) == 10
    assert r1.l == 0
    assert r1.r == 10
    assert r1.step == 1
    assert all([(i == r1[i]) for i in range(10)])
    assert all([(i == next(r1)) for i in range(10)])

    r2 = Range(0, 10, 2)
    assert len(r2) == 5
    assert r2.l == 0
    assert r2.r == 10
    assert r2.step == 2
    assert all([(2 * i == r2[i]) for i in range(5)])
    assert all([(2 * i == next(r2)) for i in range(5)])

    r3 = Range(1, 10, 2)


# Generated at 2022-06-23 17:30:08.449603
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    from pysnark.utils.easy_test import assert_equals
    n = 2
    d = {i: i*10 for i in range(n)}
    v = [d.get(i) for i in range(n)]
    assert_equals(len(v), len(MapList(lambda x: d.get(x), range(n))))


# Generated at 2022-06-23 17:30:11.257766
# Unit test for function drop
def test_drop():
    xs = list(range(100))
    assert list(drop(0, xs)) == xs
    assert list(drop(10, xs)) == xs[10:]
    assert list(drop(1000, xs)) == []


# Generated at 2022-06-23 17:30:14.949868
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    res = MapList(lambda i: a[i] * b[i], Range(len(a)))
    assert res[2] == 24
    assert res[3] == 35
    assert res[3:] == [35, 45]
    assert res[:-1] == [6, 12, 24, 35]


# Generated at 2022-06-23 17:30:22.782978
# Unit test for constructor of class LazyList
def test_LazyList():
    #list(LazyList([1, 2, 3, 4]).iter)
    #LazyList([1, 2, 3, 4])[:2][0]
    assert LazyList([1, 2, 3, 4])[:2][0] == 1
    assert list(LazyList([1, 2, 3, 4]).iter) == [1, 2, 3, 4]
    assert LazyList(['a', 'b', 'c', 'd'])[:2][0] == 'a'
    assert list(LazyList(['a', 'b', 'c', 'd'])) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-23 17:30:25.785897
# Unit test for function drop_until
def test_drop_until():
    # TODO: check that iterating too far doesn't exhaust the iterator
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:30:33.692853
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1])) == [1]
    assert list(scanl(operator.add, [])) == []
    assert list(scanl(operator.add, [1, 2, 3, 4], initial=0)) == [0, 1, 3, 6, 10]

# Generated at 2022-06-23 17:30:39.562302
# Unit test for constructor of class Range
def test_Range():
    r = Range(1,10,2)
    assert r[0] == 1
    assert r[2] == 5
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    r = Range(1,10)
    assert r[0] == 1
    assert r[2] == 3

# Generated at 2022-06-23 17:30:45.630511
# Unit test for method __len__ of class Range
def test_Range___len__():
    print('test_Range___len__..')
    r = Range(10)
    assert len(r) == 10
    r = Range(5, 20)
    assert len(r) == 15
    r = Range(5, 20, 3)
    assert len(r) == 5
    r = Range(-20, -5)
    assert len(r) == 15
    r = Range(-20, -5, 3)
    assert len(r) == 5


# Generated at 2022-06-23 17:30:56.393997
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    class Iterable:
        def __init__(self):
            self.idx = 0
            self.value = 'a'

        def __iter__(self):
            return self

        def __next__(self):
            self.idx += 1
            return self.value * self.idx

    it = Iterable()
    llist = LazyList(it)
    for idx, item in enumerate(llist):
        assert item == 'a' * (idx + 1)
        if idx >= 2:
            break
    for item in llist:
        assert item == 'a' * (idx + 1)
        idx += 1

# Generated at 2022-06-23 17:31:06.472864
# Unit test for function split_by
def test_split_by():
    a = [1, 2, 3, 4]
    assert list(split_by(a, criterion=lambda x: x % 3 == 0)) == [[1, 2], [4]]
    assert list(split_by(a, criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4]]

    b = ['a', 'b', 'a', 'b', 'c']
    assert list(split_by(b, criterion=lambda x: x == 'a')) == [['b'], ['b', 'c']]
    assert list(split_by(b, criterion=lambda x: x == 'a', empty_segments=True)) == [['b'], [], ['b', 'c']]


# Generated at 2022-06-23 17:31:14.639346
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    x = MapList(lambda x: x + 2, [1, 2, 3])
    assert isinstance(x, MapList)
    assert x[0] == 1 + 2
    assert x[1] == 2 + 2
    assert x[2] == 3 + 2
    assert x[-1] == 3 + 2
    assert isinstance(x[0:2], List)
    assert [y for y in x] == [1 + 2, 2 + 2, 3 + 2]
    assert [y for y in x[0:2]] == [1 + 2, 2 + 2]

# Generated at 2022-06-23 17:31:16.654055
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    pass



# Generated at 2022-06-23 17:31:22.532121
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList([1, 2, 3])
    try:
        len(a)
    except TypeError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 17:31:28.034361
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: True, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: False, range(10))) == []
    assert list(drop_until(lambda x: True, [])) == []
    assert list(drop_until(lambda x: False, [])) == []



# Generated at 2022-06-23 17:31:39.835776
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    import random
    import unittest

    class TestMapList(unittest.TestCase):
        def test_map(self):
            lst = [random.randint(0, 50) for _ in range(random.randint(0, 50))]
            m = MapList(lambda x: x + 1, lst)
            for i in range(len(lst)):
                self.assertEqual(m[i], lst[i] + 1)
            self.assertEqual(len(m), len(lst))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestMapList)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-23 17:31:48.129871
# Unit test for function drop_until
def test_drop_until():
    from types import GeneratorType
    from itertools import islice, count
    assert drop_until(lambda x: x > 5, range(10)) == islice(count(), 6, None)
    assert list(drop_until(lambda x: x > 5, range(10))) == list(islice(count(), 6, None))
    assert isinstance(drop_until(lambda x: x > 5, range(10)), GeneratorType)
    assert isinstance(list(drop_until(lambda x: x > 5, range(10))), list)



# Generated at 2022-06-23 17:31:52.606820
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:31:55.428130
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    seq = MapList(lambda i: i * 2, [1, 2, 3])
    assert seq[0] == 2
    assert seq[1] == 4
    assert seq[2] == 6
    assert seq[-1] == 6
    assert seq[-3] == 2
    assert seq[-4] == 2
    pass


# Generated at 2022-06-23 17:31:59.386435
# Unit test for method __next__ of class Range
def test_Range___next__():
    x=Range(1,3)
    assert x.__next__() == 1
    assert x.__next__() == 2
    assert x.__next__() == 3
    assert x.__next__() == 4



# Generated at 2022-06-23 17:32:08.613062
# Unit test for function split_by
def test_split_by():
    groups = list(split_by('-:', empty_segments=False, separator='-'))
    assert len(groups) == 2
    assert groups[0] == ['.', ':']
    assert groups[1] == []

    groups = list(split_by('-:', empty_segments=True, separator='-'))
    assert len(groups) == 3
    assert groups[0] == []
    assert groups[1] == ['.', ':']
    assert groups[2] == []

    groups = list(split_by('-:', empty_segments=False, criterion=lambda x: x in '-:'))
    assert len(groups) == 2
    assert groups[0] == ['.']
    assert groups[1] == []


# Generated at 2022-06-23 17:32:17.499024
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    n = 200
    lst = LazyList(range(n))
    assert lst[-1] == n - 1
    assert lst[10:20:2] == [10, 12, 14, 16, 18]
    assert lst[:10:3] == list(range(0, 10, 3))
    assert lst[n - 3:] == list(range(n - 3, n))
    assert lst[n - 3:] == list(range(n - 3, n))



# Generated at 2022-06-23 17:32:20.151231
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    # Test the method __iter__
    # Add your code here
    assert True # TODO: implement your test here


# Generated at 2022-06-23 17:32:25.757395
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range0 = Range(10)
    print(range0[0],range0[2],range0[4])
    range1 = Range(1, 10 + 1)  # (start, end)
    range2 = Range(1, 11, 2)   # (start, end, step)
    print(range2[0], range2[2], range2[4])

    # __getitem__(self, idx: slice) -> List[int]: ...
    print(range2[0:2])


# Generated at 2022-06-23 17:32:33.641660
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, range(3))[1] == 1
    assert MapList(lambda x: x * x, range(3))[1:2] == [1]
    assert MapList(lambda x: x * x, range(3))[0:2] == [0, 1]
    assert MapList(lambda x: x * x, range(10))[0 :: 2] == [0, 4, 16, 36, 64]



# Generated at 2022-06-23 17:32:36.606975
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    from .test_py_util import assertIteratorEqual

    assertIteratorEqual(iter(Range(5)), range(5))
    assertIteratorEqual(iter(Range(0, 10, 2)), range(0, 10, 2))


# Generated at 2022-06-23 17:32:42.612046
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[9] == 9
    assert r[-1] == 9
    with pytest.raises(IndexError):
        r[10]
    with pytest.raises(IndexError):
        r[-11]
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[9] == 10
    assert r[-1] == 10
    with pytest.raises(IndexError):
        r[10]
    with pytest.raises(IndexError):
        r[-11]
    r = Range(1, 11, 2)
    assert r[0] == 1
    assert r[4] == 9
    assert r[-1] == 9

# Generated at 2022-06-23 17:32:46.245608
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:32:53.656887
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(10))
    assert ll[0] == 0
    assert ll[1] == 1
    assert ll[3] == 3

    ll = LazyList(range(10))
    assert ll[-1] == 9
    assert ll[-2] == 8
    assert ll[-5] == 5

    ll = LazyList(range(10))
    assert ll[2:4] == [2, 3]
    assert ll[7:10] == [7, 8, 9]

    ll = LazyList(range(10))
    assert ll[:3] == [0, 1, 2]
    assert ll[7:] == [7, 8, 9]

    ll = LazyList(range(10))
    assert ll[::2] == [0, 2, 4, 6, 8]

# Generated at 2022-06-23 17:32:59.821534
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]

########################################################################################################################


# Generated at 2022-06-23 17:33:08.887160
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(lst) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(lst) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    lst = LazyList(range(10))
    for i, x in enumerate(lst):
        assert i == x
    lst = LazyList(range(10))
    it = iter(lst)
    for i, x in enumerate(lst):
        assert i == x
    it = iter(lst)
    it2 = iter(it)
    assert it is it

# Generated at 2022-06-23 17:33:16.848023
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(range(5))
    print(lst[2])
    assert lst[2] == 2
    print(lst[4])
    assert lst[4] == 4
    print(lst[2:-1])
    assert lst[2:-1] == [2, 3]
    print(lst[:])
    assert lst[:] == [0,1,2,3,4]
    print(list(lst))
    assert lst[:] == [0,1,2,3,4]
    assert lst[:] == list(lst)



# Generated at 2022-06-23 17:33:28.721512
# Unit test for constructor of class Range
def test_Range():
    assert Range(0, 1, 2) == [0]
    assert Range(1, 0, 2) == []
    assert Range(0, 2, 2) == [0, 2]
    assert Range(0, 3, 2) == [0, 2, 4]
    assert Range(0, 4, 2) == [0, 2, 4, 6]
    assert Range(0, 5, 2) == [0, 2, 4, 6, 8]
    assert Range(0, 6, 2) == [0, 2, 4, 6, 8, 10]
    assert Range(0, 7, 2) == [0, 2, 4, 6, 8, 10, 12]
    assert Range(0, 8, 2) == [0, 2, 4, 6, 8, 10, 12, 14]
    assert Range(0, 9, 2)

# Generated at 2022-06-23 17:33:39.175545
# Unit test for constructor of class LazyList
def test_LazyList():
    x = LazyList(range(10))
    assert x[0] == 0
    assert x[5] == 5
    assert x[8] == 8
    assert x[:5] == [0, 1, 2, 3, 4]
    assert x[2:8] == [2, 3, 4, 5, 6, 7]
    assert x[:] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    assert list(x) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert x[-1] == 9
    assert x[-3:] == [7, 8, 9]
    assert len(x) == 10



# Generated at 2022-06-23 17:33:44.097634
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst=LazyList(range(10))
    with pytest.raises(TypeError):
        len(lst)

    lst=LazyList(iter(range(10)))
    with pytest.raises(TypeError):
        len(lst)

# Generated at 2022-06-23 17:33:53.906378
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    with pytest.raises(ValueError, match='Exactly one of `criterion` and `separator` should be specified'):
        assert list(split_by(" Split by: ", empty_segments=True, separator='.', criterion=lambda x: x==0)) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

# Generated at 2022-06-23 17:34:00.482442
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Test with a simple lambda
    def compute_diff(num):
        return num - 2
    lst = [0, 1, 2, 3, 4, 5]
    mapped_list = MapList(compute_diff, lst)
    assert mapped_list[3] == compute_diff(lst[3])
    assert mapped_list[4] == compute_diff(lst[4])
    assert mapped_list[5] == compute_diff(lst[5])


# Generated at 2022-06-23 17:34:08.281875
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3], 0)) == [6, 5, 3, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c'])) == ['abc', 'bc', 'c']
    assert list(scanr(operator.add, [1, 2, 3, 4, 5], 0)) == [15, 14, 12, 9, 5, 0]



# Generated at 2022-06-23 17:34:11.275493
# Unit test for function split_by
def test_split_by():
    import doctest
    doctest.testmod(verbose=True)
test_split_by()



# Generated at 2022-06-23 17:34:15.764986
# Unit test for function take
def test_take():
    assert list(take(5, range(10))), [0, 1, 2, 3, 4]
    assert list(take(5, range(20))), [0, 1, 2, 3, 4]
    assert list(take(5, range(2))), [0, 1]



# Generated at 2022-06-23 17:34:18.167870
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:34:30.244146
# Unit test for function split_by
def test_split_by():
    import unittest
    import itertools
    for empty_segments in (False, True):
        for criterion in (
            lambda x: x % 3 == 0,
            lambda x: x % 4 == 0,
            lambda x: x < 2,
        ):
            test_case = unittest.TestCase(methodName='test_split_by')
            test_case.assertEqual(
                list(split_by(range(10), criterion=criterion, empty_segments=empty_segments)),
                list(split_by(iter(range(10)), criterion=criterion, empty_segments=empty_segments))
            )

# Generated at 2022-06-23 17:34:37.418366
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    import pytest
    ll = LazyList(range(1000000))
    with pytest.raises(TypeError):
        len(ll)
    for idx in range(10):
        ll[idx]
    with pytest.raises(TypeError):
        len(ll)
    # without the context manager, the next line would cause an infinite loop
    with pytest.raises(StopIteration):
        while True:
            next(ll)



# Generated at 2022-06-23 17:34:38.693425
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        len(LazyList([]))
    except TypeError:
        return
    assert False



# Generated at 2022-06-23 17:34:41.188578
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(3, range(5))) == [0, 1, 2]



# Generated at 2022-06-23 17:34:53.778956
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x == 'a', [])) == []
    assert list(drop_until(lambda x: x == 'a', ['a'])) == ['a']
    assert list(drop_until(lambda x: x == 'a', ['b', 'b', 'b', 'a'])) == ['a']
    assert list(drop_until(lambda x: x == 'a', ['b', 'b', 'b', 'b', 'b', 'b'])) == []
    assert list(drop_until(lambda x: x == 10, range(10))) == []
    assert list(drop_until(lambda x: x == 20, range(20, 30))) == [20, 21, 22, 23, 24, 25, 26, 27, 28, 29]

# Generated at 2022-06-23 17:35:00.181596
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:35:12.843463
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(1, 11)) == list(Range(1, 11, 1)) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(Range(1, 11, 2)) == [1, 3, 5, 7, 9]
    assert list(Range(0, -10, -2)) == [0, -2, -4, -6, -8]
    assert list(Range(1, 10, 0)) == [1, 1, 1, 1, 1, 1, 1, 1, 1]
    assert list(Range(1, 10, -1)) == []

    assert Range(10)[2] == 2

# Generated at 2022-06-23 17:35:16.689400
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:35:22.893552
# Unit test for constructor of class Range
def test_Range():
    r=Range(3)
    assert len(r) == 3
    r = Range(1,10)
    assert len(r) == 9
    r = Range(1,11,2)
    assert len(r) == 5
    r = Range(1,11,3)
    assert len(r) == 3


# Generated at 2022-06-23 17:35:31.457920
# Unit test for function split_by
def test_split_by():
    # criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) \
           == [[], [1, 2], [], [4, 5], [], [7, 8], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True, separator=None)) \
           == [[], [1, 2], [], [4, 5], [], [7, 8], []]

    # separator

# Generated at 2022-06-23 17:35:41.421589
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [])) == []
    assert list(scanl(lambda x, y: x + y, [1])) == [1]
    assert list(scanl(lambda x, y: x + y, [1, 2])) == [1, 3]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3])) == [1, 3, 6]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]


# Generated at 2022-06-23 17:35:53.228755
# Unit test for constructor of class LazyList
def test_LazyList():
    mock_iterable = [1, 3, 5, 7]
    mock_list = [i * 2 for i in mock_iterable]
    lst = LazyList(mock_iterable)
    assert lst.list == []
    lst._fetch_until(2)
    assert lst.list == mock_iterable[:3]
    lst._fetch_until(None)
    assert lst.list == mock_iterable
    assert list(lst) == mock_list
    assert lst[:] == mock_list
    assert lst[1:3] == mock_list[1:3]
    assert lst[-1] == 9
    assert lst[10:] == []
    assert len(mock_iterable) == 4
    assert len(lst) == 4


# Generated at 2022-06-23 17:36:02.720781
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from itertools import count
    lazy = LazyList(count(1))
    assert lazy[8] == 9
    assert lazy[-4] == 7
    assert lazy[2:4] == [3, 4]
    assert lazy[-4:-2] == [7, 8]
    assert lazy[2:4] == [3, 4]
    assert lazy[-4:-2] == [7, 8]
    assert lazy[-4:-2] == [7, 8]

# Generated at 2022-06-23 17:36:06.066938
# Unit test for constructor of class LazyList
def test_LazyList():
    ll = LazyList(range(10))
    assert ll[0] == 0
    assert ll[1] == 1
    assert len(ll) == 10
    assert list(ll) == list(range(10))


# Generated at 2022-06-23 17:36:13.906833
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList([1, 2, 3])
    assert len(a) == 3

    a = LazyList([1, 2, 3])
    a[:]=[4,5,6]
    assert len(a) == 3

    b = LazyList(range(3))
    assert len(b) == 3

    b = LazyList(range(3))
    b[:]=[4,5,6]
    assert len(b) == 3



# Generated at 2022-06-23 17:36:24.269608
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import lists
    instances = integers().flatmap(lambda n: integers(min_value=0, max_value=n).map(lambda k: (k, n)))
    @given(instances, lists(integers()))
    def test(instance, lst):
        assert len(MapList(lambda x: x, lst)) == len(lst), "len(MapList(lst)) should be the same as len(lst)"
    test()


# Generated at 2022-06-23 17:36:32.176128
# Unit test for constructor of class MapList
def test_MapList():
    unit_test_lst = [4,2,5,6,7,9,10]
    unit_test_func = lambda x: x**2
    unit_test_lst2 = MapList(unit_test_func, unit_test_lst)

    assert [16, 4, 25, 36, 49, 81, 100] == unit_test_lst2.__getitem__(slice(0, 7, 1)), "slice test failed"
    assert [16, 4, 25] == unit_test_lst2.__getitem__(slice(0, 3, 1)), "slice test 2 failed"
    assert [16, 4, 9] == unit_test_lst2.__getitem__(slice(0, 4, 3)), "slice test 3 failed"
    assert 16 == unit_test_lst2.__get

# Generated at 2022-06-23 17:36:40.738201
# Unit test for constructor of class LazyList
def test_LazyList():
    class IdentityIterator:
        def __init__(self):
            self.id = 0
        def __iter__(self):
            return self
        def __next__(self):
            self.id += 1
            return self.id
    it = IdentityIterator()
    test_lazy_list = LazyList(it)
    assert test_lazy_list.list == [], "should be empty"
    assert test_lazy_list.exhausted == False, "should not be exhausted"
    assert it.id == 0, "should not have been iterated"



# Generated at 2022-06-23 17:36:47.691460
# Unit test for constructor of class MapList
def test_MapList():
    from collections import Iterator

    lst = [1, 2, 3, 4, 5]
    wrapped = MapList(lambda x: x * x, lst)

    for i in range(len(lst)):
        assert wrapped[i] == lst[i] ** 2

    for i, j in enumerate(wrapped):
        assert i == j

    assert isinstance(wrapped, Iterator)



# Generated at 2022-06-23 17:36:55.471999
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2], criterion=lambda x: x % 3 == 0)) == [[1, 2]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    with pytest.raises(ValueError):
        list(split_by(range(10), criterion=lambda x: x % 3 == 0, separator=1))

# Generated at 2022-06-23 17:37:01.218216
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(0, 10)) == 10
    assert len(Range(10, 20, 2)) == 5
    assert len(Range(0, 20, 2)) == 10
    assert len(Range(0, 20, 3)) == 7
    assert len(Range(0, -10, -1)) == 10



# Generated at 2022-06-23 17:37:08.061046
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    i = range(10, 12, 1)
    for j in range(0, 2, 1):
        assert getattr(i, '__iter__')()[j].__eq__(Range(10, 12, 1)[j])

# Generated at 2022-06-23 17:37:19.024217
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert list(Range(0, 10, 2)) == [0, 2, 4, 6, 8]
    assert list(Range(0, 10, 2)[:]) == [0, 2, 4, 6, 8]
    assert list(Range(0, 10, 2)[:2]) == [0, 2]
    assert list(Range(0, 10, 2)[-2:]) == [6, 8]
    assert list(Range(0, 10, 2)[::2]) == [0, 4, 8]
    assert list(Range(0, 10, 2)[::-1]) == [8, 6, 4, 2, 0]
    assert list(Range(0, 10, 2)[-5::-1]) == [0, 2, 4, 6, 8]