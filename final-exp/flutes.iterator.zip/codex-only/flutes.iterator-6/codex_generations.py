

# Generated at 2022-06-23 17:27:28.565915
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for _ in range(20):
        r = random.randrange(2, 20)
        items = Range(r)
        assert len(items) == r
        for i in range(r):
            assert items[i] == i
        assert items[1] == 1
        assert items[-1] == r - 1
        assert items[1:10] == list(range(1, 10))
        assert items[:10] == list(range(10))
        assert items[1:] == list(range(1, r))
        assert items[::2] == list(range(0, r, 2))
        assert items[5::2] == list(range(5, r, 2))
        assert items[2:5] == list(range(2, 5))

# Generated at 2022-06-23 17:27:31.870783
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList([1, 2, 3])

    assert ll[0] == 1
    assert (1, 2) == (ll[0], ll[1])

    assert ll[:] == [1, 2, 3]
    assert isinstance(ll[1:], list)

    assert ll[-1] == 3
    assert ll[1:3] == [2, 3]

    with pytest.raises(TypeError):
        len(ll)



# Generated at 2022-06-23 17:27:33.174332
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert tuple(MapList(lambda x: x ** 2, [1, 2, 3, 4, 5])) == (1, 4, 9, 16, 25)

# Generated at 2022-06-23 17:27:46.615701
# Unit test for method __iter__ of class Range

# Generated at 2022-06-23 17:27:47.330062
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
  pass

# Generated at 2022-06-23 17:27:55.890365
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    max_idx = 10
    l = LazyList(range(max_idx + 1))
    l[3]
    assert l[3] == 3
    assert l[max_idx] == max_idx
    assert l[max_idx + 1] == max_idx
    assert l[-1] == max_idx
    assert isinstance(l[-1], int)
    assert isinstance(l[3:5], list)
    assert l[3:5] == [3, 4]
    assert isinstance(l[4:], list)
    assert l[4:] == list(range(4, max_idx + 1))
    assert isinstance(l[:4], list)
    assert l[:4] == list(range(4))

# Generated at 2022-06-23 17:28:06.340363
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    import itertools
    import random
    import unittest

    random.seed(1)

    class TestMapList___iter__(unittest.TestCase):

        def test_random_list(self):
            for _ in range(50):
                lst = [random.randrange(10 ** 6) for _ in range(random.randrange(100))]
                func = lambda x: -x
                expected = list(map(func, lst))
                self.assertEqual([val for val in MapList(func, lst)], expected)

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-23 17:28:15.198068
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:28:18.719059
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10)
    assert r[0] == 1
    assert r[2] == 3
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[4:6] == [5, 6]



# Generated at 2022-06-23 17:28:24.008817
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(-1, range(10))) == []



# Generated at 2022-06-23 17:28:28.650548
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList([1, 2, 3, 4, 5])
    assert lst[3] == 4
    assert not hasattr(lst, 'exhausted')
    assert lst[-1] == 5
    assert lst.exhausted
    assert lst[4] == 5



# Generated at 2022-06-23 17:28:38.901320
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl((lambda x, y: x + y), [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl((lambda x, y: x + y), [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    with pytest.raises(ValueError):
        list(scanl(operator.add, [1, 2, 3, 4], 0, 1))



# Generated at 2022-06-23 17:28:49.877884
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x in [0, 3, 6, 9])) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by([0, 1, 2], empty_segments=True)) == [[], [0], [1], [2], []]
    assert list(split_by([0, 0, 0], empty_segments=True)) == [[], [], [], [], []]
    assert list(split_by([0, 0, 0], empty_segments=False)) == [[], []]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:28:52.197078
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    global l
    global l1
    l = list(range(100))
    l1 = list(Range(100))
    assert l == l1

# Generated at 2022-06-23 17:28:55.582717
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList(LazyList(range(10000)))
    assert lst[0] == 0
    assert len(lst) == 10000
    assert lst[-1] == 9999



# Generated at 2022-06-23 17:29:00.681863
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(0, 10)
    assert r == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[2:6] == [2, 3, 4, 5]
    assert r[-1] == 9


# Generated at 2022-06-23 17:29:11.127435
# Unit test for function chunk
def test_chunk():
    assert list(chunk(2, range(8))) == [[0, 1], [2, 3], [4, 5], [6, 7]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(5, range(2))) == [[0, 1]]
    assert list(chunk(5, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(1, range(5))) == [[0], [1], [2], [3], [4]]
    assert list(chunk(2, range(1))) == [[0]]
    assert list(chunk(0, range(5))) == ValueError



# Generated at 2022-06-23 17:29:17.195491
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(4))
    ll.__getitem__.cache_clear()
    assert list(ll.__iter__()) == [0, 1, 2, 3]
    assert list(ll.__iter__()) == [0, 1, 2, 3]


# Generated at 2022-06-23 17:29:25.090349
# Unit test for function split_by
def test_split_by():
    # criterion
    assert list(split_by(['a', 'bc', 'd', 'e'], criterion=lambda x: len(x) == 1)) == [['bc'], ['e']]
    assert list(split_by(['a', 'bc', 'd', 'e'], criterion=lambda x: len(x) == 1, empty_segments=True)) == [[], ['bc'], [], ['e']]
    # separator
    assert list(split_by(['a', 'b', 'c', 'd', 'e'], 'd')) == [['a', 'b', 'c'], ['e']]
    assert list(split_by(['a', 'd', 'd', 'e'], 'd')) == [['a'], [], ['e']]

# Generated at 2022-06-23 17:29:31.462885
# Unit test for constructor of class LazyList
def test_LazyList():
    assert list(LazyList(range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    mylist = LazyList(range(5))
    assert list(mylist) == [0, 1, 2, 3, 4]
    # after list exhaust, iterable is unusable
    assert list(mylist) == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 17:29:36.027429
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(0, 100, 2)
    r = Range(1, 10 + 1)  # (start, end)
    print(r[5:7])
if __name__ == "__main__":
    test_Range___getitem__()


# Generated at 2022-06-23 17:29:43.662043
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll1 = LazyList(range(1000))
    assert ll1[:-1] == list(range(999))
    assert ll1[-1] == 999
    assert ll1[-2] == 998
    assert ll1[999] == 999
    assert len(ll1) == 1000
    assert ll1.list == list(range(1000))
    ll2 = LazyList(range(1000))
    assert ll2[999] == 999
    assert ll2[-1] == 999
    assert ll2[998] == 998
    assert ll2[999:1000] == [999]
    assert len(ll2) == 1000
    assert ll2.list == list(range(1000))
    ll3 = LazyList(range(1000))
    assert ll3[100] == 100

# Generated at 2022-06-23 17:29:50.361861
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(10)
    assert [x for x in r1] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    r2 = Range(1, 10 + 1)
    assert [x for x in r2] == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    r3 = Range(1, 11, 2)
    assert [x for x in r3] == [1, 3, 5, 7, 9]


# Generated at 2022-06-23 17:29:56.855530
# Unit test for constructor of class Range
def test_Range():
    r = Range(1,100)
    assert(len(r) == 99)
    r = Range(0,100,5)
    assert(len(r) == 20)
    assert(r[0] == 0)
    assert(r[5] == 25)
    assert(r[19] == 95)
    assert(r[-1] == 95)
    assert(r[:] == [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95])
    assert(r[0:5] == [0, 5, 10, 15, 20])
    assert(r[0:6] == [0, 5, 10, 15, 20, 25])

# Generated at 2022-06-23 17:30:08.582520
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    x = MapList(lambda x: x, [])
    x = MapList(lambda x: x, [0])
    x = MapList(lambda x: x, [0, 1])
    x = MapList(lambda x: x, [0, 1, 2])
    x = MapList(lambda x: x, [0, 1, 2, 3])

    for x in MapList(lambda x: x, []):
        pass
    for x in MapList(lambda x: x, [0]):
        pass
    for x in MapList(lambda x: x, [0, 1]):
        pass
    for x in MapList(lambda x: x, [0, 1, 2]):
        pass
    for x in MapList(lambda x: x, [0, 1, 2, 3]):
        pass

# Unit

# Generated at 2022-06-23 17:30:14.022835
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    r"""
    Tests method __iter__
    """
    arr = LazyList(range(100))
    i = 0
    for x in arr:
        assert x == i
        i += 1



# Generated at 2022-06-23 17:30:17.601151
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(-l, -r, -step)
    assert next(r) == -start
    assert next(r) == -start+2
    assert next(r) == -start+4
    with pytest.raises(StopIteration):
        next(r)


# Generated at 2022-06-23 17:30:19.608117
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(0, 10, 4)) == len(Range(0, 4)) == len(Range(4)) == 3



# Generated at 2022-06-23 17:30:23.656608
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 5 + 1, 2)) == 3
    assert len(Range(5, 1, -2)) == 3
    assert len(Range(5, 5, 1)) == 0

# Generated at 2022-06-23 17:30:27.115696
# Unit test for constructor of class LazyList
def test_LazyList():
  x = LazyList([1,2,3,4,5])
  assert x[2] == 3
  assert x[4] == 5
  assert len(x) == 5
  assert list(x) == [1,2,3,4,5]


# Generated at 2022-06-23 17:30:34.518566
# Unit test for constructor of class Range
def test_Range():
    assert [1, 5, 9] == [i for i in Range(1, 11, 4)]
    assert [1, 5, 9] == Range(1, 11, 4)[:]
    assert [1, 5, 9] == Range(1, 11, 4)[:3]
    assert [] == Range(1, 11, 4)[3:]
    assert [len(Range(1, 11, 4))] == Range(1, 11, 4)[-1:]
    assert [1, 9] == Range(1, 11, 4)[:2:2]
    assert True == range(10) == Range(10)
    assert True == range(1, 11) == Range(1, 11)
    assert True == range(1, 11, 2) == Range(1, 11, 2)

# Generated at 2022-06-23 17:30:46.954550
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
  assert Range(10)[1] == 1
  assert Range(0, 9)[1] == 1
  assert Range(0, 9, 2)[1] == 2
  assert Range(10)[-1] == 9
  assert Range(0, 9)[-1] == 8
  assert Range(0, 9, 2)[-1] == 8
  assert Range(10)[2:7] == [2, 3, 4, 5, 6]
  assert Range(0, 9)[2:7] == [2, 3, 4, 5, 6]
  assert Range(0, 9, 2)[2:7] == [4, 6, 8]
  assert Range(10)[5:] == [5, 6, 7, 8, 9]
  assert Range(0, 9)[5:] == [5, 6, 7, 8]

# Generated at 2022-06-23 17:30:49.375890
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    LazyList([1]).__len__()  # works if it doesn't raise an exception



# Generated at 2022-06-23 17:31:00.363810
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[3] == 3
    assert lst.list == [0, 1, 2, 3]
    assert lst[-7] == 3
    assert lst.list == [0, 1, 2, 3]
    assert lst[2:4] == [2, 3]
    assert lst.list == [0, 1, 2, 3]
    assert lst[-8:-6] == [2, 3]
    assert lst.list == [0, 1, 2, 3]
    assert lst[:] == list(range(10))
    assert lst.list == list(range(10))



# Generated at 2022-06-23 17:31:04.798270
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    print(r[0], r[2], r[4])


# Generated at 2022-06-23 17:31:11.563529
# Unit test for constructor of class Range
def test_Range():
    my_range = Range(1, 101)
    assert my_range[5] == 6
    assert my_range[-1] == 100
    assert isinstance(my_range[99], int)
    assert my_range[0:10:2] == [1, 3, 5, 7, 9]
    assert my_range[10:20:2] == [21, 23, 25, 27, 29]
    assert my_range[0:100] == [i for i in range(101)]

# Generated at 2022-06-23 17:31:23.814578
# Unit test for function split_by
def test_split_by():
    assert list(split_by("Split by: ", empty_segments=True, separator=' ')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=True, separator=' ')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator=' ')) == [['S', 'p', 'l', 'i', 't'],
                                                                                  ['b', 'y', ':']]

# Generated at 2022-06-23 17:31:29.078069
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    with pytest.raises(ValueError):
        list(scanr(lambda x: x + 1, [1, 2, 3, 4], 5))



# Generated at 2022-06-23 17:31:35.366345
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    import random
    def f(x):
        return x + 1
    l = [random.randint(-100, 100) for _ in range(100)]
    ml = MapList(f, l)
    assert all(x == y for x, y in zip(l, ml))

# Generated at 2022-06-23 17:31:40.937748
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for i in range(2):
        if i == 0:
            m = MapList(lambda x: x+1, [1, 2])
            assert m[0] == 2
            assert m[1] == 3
            assert m[-1] == 3
            assert m[-2] == 2
            assert m[-3] < 0
        elif i == 1:
            m = MapList(lambda x:x+1, [1, 2, 3])
            assert m[0: 0] == []
            assert m[0: 1] == [2]
            assert m[0: 2] == [2, 3]
            assert m[0: 3] == [2, 3, 4]
            assert m[0: 4] == [2, 3, 4]

# Generated at 2022-06-23 17:31:49.105802
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(3))) == [0, 1, 2]
    assert list(LazyList(range(3))) == [0, 1, 2]
    assert list(LazyList(range(3))) == [0, 1, 2]
    assert list(LazyList(range(3))[0:]) == [0, 1, 2]
    assert list(LazyList(range(3))[0:]) == [0, 1, 2]
    assert list(LazyList(range(3))[0:]) == [0, 1, 2]

# Generated at 2022-06-23 17:31:51.596157
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-23 17:31:58.841139
# Unit test for function chunk
def test_chunk():
    assert chunk(2, range(10)) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert chunk(3, range(10)) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert chunk(10, range(10)) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert chunk(0, range(10)) == []
    assert chunk(-1, range(10)) == []



# Generated at 2022-06-23 17:32:04.035574
# Unit test for function chunk
def test_chunk():
    c = chunk(3, range(10))
    assert list(c) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, ())) == []


# Generated at 2022-06-23 17:32:08.775470
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    iterable = range(100)
    lst = LazyList(iterable)
    it = iter(lst)
    assert len(list(take(10, it))) == 10
    assert len(list(it)) == 90
    assert list(lst)[-1] == 99
    assert list(lst)[-2] == 98
    assert list(lst)[-3] == 97



# Generated at 2022-06-23 17:32:15.181596
# Unit test for function take
def test_take():
    print("test_take")
    a = [i for i in range(100)]
    b = [i for i in take(10, a)]
    c = [i for i in range(10)]
    print(b)
    print(c)
    assert b == c
test_take()


# Generated at 2022-06-23 17:32:17.442748
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1,6,2)
    assert(list(r) == [1,3,5])


# Generated at 2022-06-23 17:32:26.538602
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    with TestRun.step("Setup"):
        lst = [1, 2, 3, 4, 5]
        map_list = MapList(lambda x: x * x, lst)

    with TestRun.step("Test for __getitem__ for a single item"):
        TestRun.LOGGER.info(f"Test __getitem__ for {lst}")
        TestRun.LOGGER.info(f"List: {lst}")
        TestRun.LOGGER.info(f"MapList: {map_list}")
        for idx in range(len(lst)):
            TestRun.LOGGER.info(f"Index {idx} of MapList returns {map_list[idx]}")

# Generated at 2022-06-23 17:32:34.326751
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    iterable_a = iter([10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    ll_a = LazyList(iterable_a)
    try:
        len(ll_a)
    except Exception as err:
        assert(str(err) == "__len__ is not available before the iterable is depleted")
    else:
        assert(False)

    iterable_b = iter([10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    ll_b = LazyList(iterable_b)
    assert(len(ll_b[:]) == 10)

    iterable_c = iter([10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    ll_c = LazyList(iterable_c)


# Generated at 2022-06-23 17:32:42.372500
# Unit test for constructor of class Range
def test_Range():
    range1 = Range(1, 10)
    range2 = Range(10)
    range3 = Range(1, 10, 1)
    range4 = Range(1, 10, 2)
    range5 = Range(2, 10, 1)
    range6 = Range(2, 10, 2)
    assert range1 == range2 == range3
    assert range1 != range4
    assert range5 != range6
    assert range5 != range1



# Generated at 2022-06-23 17:32:44.908754
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]


# Generated at 2022-06-23 17:32:56.595843
# Unit test for method __getitem__ of class LazyList

# Generated at 2022-06-23 17:33:01.532464
# Unit test for method __len__ of class Range
def test_Range___len__():
    print('---Testing method __len__ of class Range---')
    assert len(Range(10)) == 10
    assert len(Range(1, 11, 2)) == 5
    assert len(Range(1, 10)) == 9
    assert len(Range(1, 9)) == 8
    assert len(Range(0, 0)) == 0


# Generated at 2022-06-23 17:33:06.273572
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from hungry_penguin.func import take, map
    lst = LazyList([1, 2, 3])
    assert list(take(2, lst)) == [1, 2]
    assert list(take(2, lst)) == [1, 2]
    assert list(take(2, map(lambda x: x + 1, lst))) == [2, 3]



# Generated at 2022-06-23 17:33:17.274544
# Unit test for constructor of class LazyList
def test_LazyList():
    x = LazyList(range(5))
    assert isinstance(x, LazyList)
    assert isinstance(x, Sequence)
    assert not isinstance(x, Iterable)
    assert isinstance(x.iter, iter)
    assert not x.exhausted
    assert x.list == []
    try:
        assert len(x)
        assert False
    except TypeError as e:
        assert str(e) == "__len__ is not available before the iterable is depleted"
    assert x[0] == 0
    assert x.list == [0]
    assert x[1] == 1
    assert x.list == [0, 1]
    assert x[2] == 2
    assert x.list == [0, 1, 2]
    assert x[3] == 3

# Generated at 2022-06-23 17:33:19.590801
# Unit test for constructor of class LazyList
def test_LazyList():
    list = LazyList([1,2,3])
    assert list == [1,2,3]
    assert list[1] == 2
    assert list[0:2] == [1,2]
    print("PASS")
test_LazyList()



# Generated at 2022-06-23 17:33:22.963259
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)
    assert next(r) == 0
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    with pytest.raises(StopIteration):
        next(r)



# Generated at 2022-06-23 17:33:26.551413
# Unit test for constructor of class LazyList
def test_LazyList():
    list1 = LazyList(range(3))
    assert isinstance(list1, LazyList) == True
    assert isinstance(list1, Sequence) == True
    assert isinstance(list1, Iterator) == False


# Generated at 2022-06-23 17:33:34.776516
# Unit test for function split_by
def test_split_by():
    from itertools import chain
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]

# Generated at 2022-06-23 17:33:46.200487
# Unit test for function split_by
def test_split_by():
    assert list(split_by('a b c', empty_segments=True, separator=' ')) == [['a'], ['b'], ['c']]
    assert list(split_by('a b c', empty_segments=False, separator=' ')) == [['a'], ['b'], ['c']]

    assert list(split_by('a b c', empty_segments=True, criterion=lambda x: x in {'a', 'b', 'c'})) == [[], [], []]
    assert list(split_by('a b c', empty_segments=False, criterion=lambda x: x in {'a', 'b', 'c'})) == []

    assert list(split_by('a b c', criterion=lambda x: x == 'b')) == [['a'], ['c']]


# Generated at 2022-06-23 17:33:58.010585
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([])
    try:
        len(lst)
    except TypeError:
        pass
    else:
        raise AssertionError("Expected a TypeError")
    lst = LazyList(chunk(3, range(10)))
    assert len(lst) == 4
    lst = LazyList(range(10))
    assert len(lst) == 10
    lst = LazyList(range(4))
    assert len(lst) == 4
    try:
        for _ in range(4):
            next(iter(lst))
    except StopIteration:
        pass
    else:
        raise AssertionError("The iterator should be depleted")
    assert len(lst) == 4

# Generated at 2022-06-23 17:34:01.094156
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def func(x):
        return x * 3
    lst = List[int]((1, 2, 3))
    map_list = MapList(func, lst)
    assert map_list.__getitem__(0) == 3

# Generated at 2022-06-23 17:34:12.324280
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(0, 10, 3), criterion=lambda x: x % 3 == 0)) == [[], [], [], []]
    assert list(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[], [1, 2], [], [4, 5], [], [7, 8], []]
    assert list(split_by([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 8], criterion=lambda x: x % 3 == 0)) == [[1, 4, 1, 5, 9, 2], [6, 5], [5, 8]]

# Generated at 2022-06-23 17:34:14.129932
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert list(LazyList(range(10))) == list(range(10))



# Generated at 2022-06-23 17:34:18.122707
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda acc, x: acc + x, (1, 2, 3), 0)) == [0, 1, 3, 6]
    assert list(scanl(lambda acc, x: x + acc, ('a', 'b', 'c'))) == ['a', 'ba', 'cba']



# Generated at 2022-06-23 17:34:23.789502
# Unit test for function drop
def test_drop():
    iterable = range(10)
    for n in range(10):
        assert list(drop(n, iterable)) == list(iterable[n:])
        assert list(drop(n, iterable)) == list(iterable[n:])
    for n in range(10):
        for iterable in (range(n), range(n, 10), range(10, 20)):
            assert list(drop(n, iterable)) == list(iterable)
    for n in range(10):
        for iterable in (range(n), range(n, 10), range(10, 20)):
            assert list(drop(n, iterable)) == list(iterable)
    with pytest.raises(ValueError, match="n is negative"):
        drop(-1, [1])

# Generated at 2022-06-23 17:34:30.093981
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    c = [i * j for i, j in zip(a, b)]
    assert [c[i] for i in [0, 2, 4]] == MapList(lambda i: a[i] * b[i], Range(len(a)))[[0, 2, 4]]


# Generated at 2022-06-23 17:34:37.960955
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert_equal(Range(1, 2).__next__(), 1)
    assert_equal(Range(1, 2).__next__(), 1)
    assert_raises(StopIteration, Range(1, 2).__next__)
    assert_equal(Range(1, 10 + 1).__next__(), 1)
    assert_equal(Range(1, 10 + 1).__next__(), 2)
    assert_equal(Range(1, 10 + 1).__next__(), 3)
    assert_equal(Range(1, 11, 2).__next__(), 1)
    assert_equal(Range(1, 11, 2).__next__(), 3)
    assert_equal(Range(1, 11, 2).__next__(), 5)
    assert_raises(StopIteration, Range(1, 11, 2).__next__)

# Generated at 2022-06-23 17:34:39.467727
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    map_list = MapList(lambda x: x, [1, 2, 3, 4, 5])
    assert len(map_list) == 5



# Generated at 2022-06-23 17:34:41.190461
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, range(3), 0)) == [0, 0, 1, 3]



# Generated at 2022-06-23 17:34:47.972739
# Unit test for constructor of class Range
def test_Range():
    assert [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] == list(Range(10))
    assert [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] == list(Range(1, 11))
    assert [0, 2, 4, 6, 8] == list(Range(0, 9, 2))

# Generated at 2022-06-23 17:34:56.399541
# Unit test for function chunk
def test_chunk():
    # Check that expected values are correctly generated
    assert list(chunk(2, [1, 2, 3, 4, 5])) == [[1, 2], [3, 4], [5]]
    assert list(chunk(3, [1, 2, 3, 4, 5])) == [[1, 2, 3], [4, 5]]
    # Check that an error is correctly generated for n <= 0
    with pytest.raises(ValueError):
        list(chunk(0, [1, 2, 3, 4, 5]))


# Generated at 2022-06-23 17:35:06.079706
# Unit test for function split_by
def test_split_by():
    assert [[]] == list(split_by([], criterion=lambda x: x < 0))
    assert [[]] == list(split_by([], criterion=lambda x: x < 0, empty_segments=True))

    assert [[1, 2]] == list(split_by([1, 2], criterion=lambda x: x < 0))
    assert [[1, 2]] == list(split_by([1, 2], criterion=lambda x: x < 0, empty_segments=True))

    assert [[1, 2], [4, 5, 6]] == list(split_by([1, 2, 3, 4, 5, 6], criterion=lambda x: x % 3 == 0))

# Generated at 2022-06-23 17:35:14.405652
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda x: x * x

    # Test indexing with positive integers
    lst = [1, 2, 3, 4, 5]
    map_list = MapList(func, lst)
    for i in range(len(lst)):
        assert lst[i] * lst[i] == map_list[i]

    # Test indexing with negative integers
    for i in range(-len(lst), 0):
        assert lst[i] * lst[i] == map_list[i]

    # Test indexing with a slice
    for n in range(len(lst) + 1):
        assert list(map(func, lst[:n])) == map_list[:n]



# Generated at 2022-06-23 17:35:17.319472
# Unit test for constructor of class LazyList
def test_LazyList():
    with open('test_text.txt') as f:
        a = LazyList(f)
        for it in a:
            print(it)



# Generated at 2022-06-23 17:35:19.153733
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    m = MapList(None, None)
    i = iter(m)


# Generated at 2022-06-23 17:35:21.032911
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10

# Generated at 2022-06-23 17:35:25.082797
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, range(1, 5))) == [10, 9, 7, 4]
    assert list(scanr(lambda s, x: x + s, 'abcd')) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:35:29.040366
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 5, iter([4, 3, 2, 1, 0]))) == []
    assert list(drop_until(lambda x: x > 42, range(10))) == []


# Generated at 2022-06-23 17:35:32.843105
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([0, 1, 2])
    assert list(lst) == [0, 1, 2]



# Generated at 2022-06-23 17:35:37.116197
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(5))) == []


# Generated at 2022-06-23 17:35:43.605790
# Unit test for function scanr
def test_scanr():
    from operator import add
    try:
        assert scanr(add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
        assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']
    except AssertionError:
        print('test_scanr() fails')
        raise
# test_scanr()



# Generated at 2022-06-23 17:35:47.073715
# Unit test for constructor of class MapList
def test_MapList():
    my_list = [0,1,2,3,4]
    MapList(lambda x:x*x, my_list)
    MapList(lambda x:x*x, (0,1,2,3,4))

# Generated at 2022-06-23 17:35:53.857734
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 0, range(0, -10, -1))) == []
    assert list(drop_until(lambda x: x > 5, range(0, -10, -1))) == list(range(5, -10, -1))



# Generated at 2022-06-23 17:36:06.329678
# Unit test for function scanl

# Generated at 2022-06-23 17:36:12.120325
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    #assert isinstance(r, collections.abc.Iterable)
    assert isinstance(r, Iterable)
    assert not isinstance(r, str)
    assert isinstance(r, (list, str))
    assert not isinstance(r, str)

# Generated at 2022-06-23 17:36:17.919228
# Unit test for function scanl
def test_scanl():
    assert list(miscutil.scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(miscutil.scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(miscutil.scanl(lambda s, x: x + s, [])) == []



# Generated at 2022-06-23 17:36:27.371804
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)
    assert r.step == 1
    assert r.l == 0
    assert r.r == 10
    assert r.length == 10

    r = Range(1, 10 + 1)
    assert r.step == 1
    assert r.l == 1
    assert r.r == 10 + 1
    assert r.length == 10

    r = Range(1, 11, 2)
    assert r.step == 2
    assert r.l == 1
    assert r.r == 11
    assert r.length == 5



# Generated at 2022-06-23 17:36:37.588057
# Unit test for constructor of class Range
def test_Range():
    assert Range(0, 1).l == 0, "__init__: error in initialization"
    assert Range(0, 1).r == 1, "__init__: error in initialization"
    assert Range(0, 1).step == 1, "__init__: error in initialization"
    assert Range(0, 10, 2).r == 10, "__init__: error in initialization"
    assert Range(0, 10, 2).step == 2, "__init__: error in initialization"
    assert Range(4, 10).l == 4, "__init__: error in initialization"
    assert Range(4, 10).r == 10, "__init__: error in initialization"
    assert Range(4, 10).step == 1, "__init__: error in initialization"


# Generated at 2022-06-23 17:36:38.923886
# Unit test for function drop
def test_drop():
    assert next(drop(5,range(1000000))) == 5
    
    

# Generated at 2022-06-23 17:36:43.897687
# Unit test for function scanr
def test_scanr():
    it = range(4)
    for a, b in zip(scanr(operator.add, it), [6, 5, 3, 0]):
        assert a == b
    it = 'abcd'
    for a, b in zip(scanr(lambda s, x: x + s, it), ['dcba', 'cba', 'ba', 'a']):
        assert a == b



# Generated at 2022-06-23 17:36:52.499974
# Unit test for function chunk
def test_chunk():
    assert list(chunk(5, range(10))) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(10, [])) == []
    assert list(chunk(0, range(10))) == []
    try:
        list(chunk(-1, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7]]
    except ValueError:
        pass
    else:
        raise Exception("should raise ValueError")



# Generated at 2022-06-23 17:36:58.080803
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Case 1: Get a single element
    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2



# Generated at 2022-06-23 17:36:59.710769
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    obj = Range(0, 10, 1)
    iter(obj)
    # We will just test that the method doesn't crash



# Generated at 2022-06-23 17:37:10.909010
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(0, 10, 1)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-10] == 0
    assert r[-9] == 1
    assert r[-8] == 2
    assert r[-7] == 3
    assert r[-6] == 4
    assert r[-5] == 5
    assert r[-4] == 6
    assert r[-3] == 7
    assert r[-2] == 8
    assert r[-1]

# Generated at 2022-06-23 17:37:14.506113
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    x = Range(10)
    x_it = iter(x)
    assert_equal(list(x_it), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

# Generated at 2022-06-23 17:37:19.052626
# Unit test for constructor of class MapList
def test_MapList():
    lst = MapList(lambda x: x * x, [1,2,3,4,5,6,7,8,9,10])
    assert lst[2] == 9
    assert lst[:5] == [1, 4, 9, 16, 25]
    assert lst[::2] == [1, 9, 25, 49, 81]
