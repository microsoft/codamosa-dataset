

# Generated at 2022-06-23 17:27:25.722325
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    from types import GeneratorType
    from collections.abc import Iterable, Iterator
    from test_fixtures import unittest
    import typing

    class Test(unittest.TestCase):
        def test_Range___iter__(self):
            r = Range(1, 10, 2)
            # check whether __iter__ returns an Iterable
            self.assertIsInstance(r.__iter__(), Iterable)
            # check whether __iter__ returns an Iterator
            self.assertIsInstance(r.__iter__(), Iterator)
            # check whether __iter__ returns a Generator
            self.assertIsInstance(r.__iter__(), typing.Generator)

    unittest.main()

# Generated at 2022-06-23 17:27:29.758091
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    for _ in range(100):
        length = random.randrange(1, 1000)
        ll = LazyList(range(length))
        for i in range(length):
            assert next(iter(ll)) == i



# Generated at 2022-06-23 17:27:31.056230
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    LazyList(range(10)).__len__()



# Generated at 2022-06-23 17:27:39.999260
# Unit test for constructor of class LazyList
def test_LazyList():
    l = LazyList(range(10000))
    assert(l[0] == 0)
    assert(l[-1] == 9999)
    assert(l[:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

# Generated at 2022-06-23 17:27:46.888594
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for start, stop, step in [
            (10,None,1), (1,10+1,1), (1,11,2)
            ]:
        r = Range(start, stop, step)
        it1 = iter(r)
        it2 = iter(r)
        assert next(it1) == next(it2)

# Generated at 2022-06-23 17:27:53.163997
# Unit test for method __next__ of class Range
def test_Range___next__():
    # 1 element
    assert_eq(next(Range(0)),0)
    # 2 elements
    assert_eq(next(Range(0,2)),0)
    assert_eq(next(Range(0,2)),1)
    # 3 elements
    assert_eq(next(Range(0,2,2)),0)
    assert_eq(next(Range(0,2,2)),1)
    # 4 elements
    assert_eq(next(Range(1,2,2)),1)
    assert_eq(next(Range(1,3,2)),1)

# Generated at 2022-06-23 17:27:59.457146
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(sqrt, [9, 16, 25])) == 3


# Generated at 2022-06-23 17:28:06.792842
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(100))

    # Length is not yet available
    with pytest.raises(TypeError):
        len(lst)

    # Generate 20 items
    assert list(take(20, lst)) == list(range(20))

    # Length is still not available
    with pytest.raises(TypeError):
        len(lst)

    # Generate another 10 items
    assert list(take(10, lst)) == list(range(10, 20))

    # Check that getitem is working
    assert list(lst[20:40]) == list(range(20, 40))

    # Enumerate remaining items
    assert len(lst) == 100
    assert list(lst) == list(range(100))

    # Check that getitem raises an IndexError

# Generated at 2022-06-23 17:28:10.358215
# Unit test for function drop
def test_drop():
    for n in [0, 1, 2, 3]:
        it = list(drop(n, []))
        assert not it, f"Expected empty list after dropping {n} elements from an empty iterable, found {it}"
    print("Passed test_drop")



# Generated at 2022-06-23 17:28:19.192241
# Unit test for function split_by
def test_split_by():
    """Unit test for function split_by"""
    # Criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == \
           [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) == \
        [[], [1, 2], [4, 5], [7, 8], []]
    # Separator
    assert list(split_by(" Split by: ", separator='.')) == \
        [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-23 17:28:29.105784
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]


# Generated at 2022-06-23 17:28:39.152495
# Unit test for method __next__ of class Range
def test_Range___next__():
    x = Range(11)
    assert x.val == 0
    assert x.__next__() == 0
    assert x.val == 1

    x = Range(11)
    assert x.val == 0
    x.__next__()
    assert x.val == 1
    x.__next__()
    assert x.val == 2
    x.__next__()
    assert x.val == 3

    # Test for the first use of __next__ after depositing iterables
    x = Range(5)
    assert x.val == 0
    list(x)
    assert x.val == 0
    list(x)
    assert x.val == 0
    list(x)
    assert x.val == 0
    list(x)
    assert x.val == 0
    list(x)
    assert x.val

# Generated at 2022-06-23 17:28:41.985203
# Unit test for constructor of class LazyList
def test_LazyList():
    a = iter(range(5))
    b = LazyList(a)
    assert b[2] == 2
    assert (b[0:2] == [0, 1])



# Generated at 2022-06-23 17:28:54.583034
# Unit test for function split_by
def test_split_by():
    assert split_by([1, 2, 4, 5, 7, 8], criterion=lambda x: x % 3 == 0) == \
        ([1, 2], [4, 5], [7, 8])
    assert split_by(' Split by: ', empty_segments=True, separator='.') == \
        ([], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], [])
    assert split_by(' Split by: ', empty_segments=True, separator='') == \
        (['S', 'p', 'l', 'i', 't', ' ', 'b', 'y', ':', ' '],)

# Generated at 2022-06-23 17:29:07.369820
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(0, 10)
    for i in range(10):
        assert r[i] == i
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[:5] == [0, 1, 2, 3, 4]
    assert r[::2] == [0, 2, 4, 6, 8]
    assert r[-1] == 9
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert r[5:2:-1] == [5, 4, 3]
    assert r[-6:-3] == [4, 5, 6]
    assert r[-3:-6:-1]

# Generated at 2022-06-23 17:29:10.475273
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    from math import sqrt
    xs = [1, 2, 3, 4]
    ys = [sqrt(x) for x in xs]
    assert list(MapList(lambda x: sqrt(x), xs)) == ys

# Generated at 2022-06-23 17:29:19.257018
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert len(r) == 10
    r = Range(1, 10 + 1)
    assert len(r) == 10
    r = Range(1, 11, 2)
    assert len(r) == 5
    assert range(10) == Range(10)
    assert range(1, 10 + 1) == Range(1, 10 + 1)
    assert range(1, 11, 2) == Range(1, 11, 2)



# Generated at 2022-06-23 17:29:25.089999
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert list(LazyList(range(10))) == list(LazyList(range(10)).__iter__()) == list(range(10))
    assert list(LazyList(range(10))) == list(LazyList(range(10)).__iter__()) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    try:
        LazyList(range(10)).__len__()
    except:
        assert True
    else:
        assert False
    l = LazyList(range(10))
    l[0]
    assert l.__len__() == 10

# Generated at 2022-06-23 17:29:32.142679
# Unit test for function scanl
def test_scanl():
    # Test scanl without initial value
    list_ = list(scanl(lambda x, y: x + y, [0, 1, 2, 3, 4]))
    assert list_ == [0, 1, 3, 6, 10]
    # Test scanl with initial value
    list_ = list(scanl(lambda x, y: x + y, [0, 1, 2, 3, 4], 1))
    assert list_ == [1, 2, 4, 7, 11]



# Generated at 2022-06-23 17:29:36.620330
# Unit test for function drop
def test_drop():
    assert list(drop(3, [1,2,3,4,5])) == [4, 5]
    assert list(drop(0, [1,2,3,4,5])) == [1,2,3,4,5]
    assert list(drop(10, [1,2,3,4,5])) == []

# Generated at 2022-06-23 17:29:46.360687
# Unit test for constructor of class Range
def test_Range():
    r = Range(10)
    assert(r[0] == 0)
    assert(r[1] == 1)
    assert(r[9] == 9)
    r = Range(1, 10 + 1)
    assert(r[0] == 1)
    assert(r[1] == 2)
    assert(r[8] == 9)
    r = Range(1, 11, 2)
    assert(r[0] == 1)
    assert(r[1] == 3)
    assert(r[4] == 9)
    assert(r[5] == 11)
    try:
        r[0] = 1
        raise AssertionError()
    except TypeError as e:
        pass



# Generated at 2022-06-23 17:29:54.502399
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(5, 10, 2)) == [5, 7, 9]
    assert list(Range(10)) == list(range(10))
    assert list(Range(0, 10, 2)) == [0, 2, 4, 6, 8]
    assert list(Range(1, 11, 2)) == [1, 3, 5, 7, 9]
    assert list(Range(0, 10, -1)) == []
    assert list(Range(0, -10, -1)) == [0, -1, -2, -3, -4, -5, -6, -7, -8, -9]
    assert list(Range(0)) == []
    assert list(Range(1, 0)) == []
    assert list(Range(1, 0, -1)) == [1]

# Generated at 2022-06-23 17:30:02.201678
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    assert len(MapList(lambda x: x * x, a)) == 5
    assert a[2] == 3 and (MapList(lambda x: x * x, a))[2] == 9
    assert MapList(lambda i: a[i] * b[i], Range(len(a)))[3] == 20



# Generated at 2022-06-23 17:30:11.958054
# Unit test for function take
def test_take():
    assert list(take(0, [1, 2, 3])) == []
    assert list(take(1, [1, 2, 3])) == [1]
    assert list(take(2, [1, 2, 3])) == [1, 2]
    assert list(take(3, [1, 2, 3])) == [1, 2, 3]
    assert list(take(100, [1, 2, 3])) == [1, 2, 3]
    assert list(take(0, [])) == []
    assert list(take(1, [])) == []
    assert list(take(100, [])) == []
    assert list(take(0, (1, 2, 3))) == []
    assert list(take(1, (1, 2, 3))) == [1]

# Generated at 2022-06-23 17:30:17.274043
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([])) == 0
    assert len(LazyList(range(3))) == 3
    assert len(LazyList(range(1000))) == 1000
    assert len(LazyList(x for x in range(1000))) == 1000
    assert len(LazyList(x for x in range(10000))) == 10000
# End unit test for method __len__ of class LazyList


# Generated at 2022-06-23 17:30:22.904005
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert list(Range(5, 10)) == [5, 6, 7, 8, 9]
    assert list(Range(0, 10, 2)) == [0, 2, 4, 6, 8]
    assert Range(-5, 5)[0::2] == [-5, -3, -1, 1, 3]
    assert Range(5, -5, -1)[1::2] == [4, 2, 0, -2]
    assert Range(5, -5, -2)[2:-2] == [1, -1]

# Generated at 2022-06-23 17:30:25.183803
# Unit test for function drop
def test_drop():
    """
    >>> list(drop(5, range(10)))
    [5, 6, 7, 8, 9]
    """
    pass



# Generated at 2022-06-23 17:30:33.012213
# Unit test for function chunk
def test_chunk():
    assert tuple(chunk(3, range(10))) == ((0, 1, 2), (3, 4, 5), (6, 7, 8), (9,))
    assert tuple(chunk(3, range(2))) == ((0, 1),)
    assert tuple(chunk(3, range(5))) == ((0, 1, 2), (3, 4))
    assert tuple(chunk(3, range(2))) == ((0, 1),)
    assert tuple(chunk(3, range(1))) == ((0,),)
    assert tuple(chunk(3, range(0))) == ()
    assert tuple(chunk(0, range(10))) == ()
    assert tuple(chunk(-1, range(10))) == ()

# Generated at 2022-06-23 17:30:39.117375
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    x = LazyList(range(5))
    for i, j in enumerate(x):
        assert i == j
        break
    for i, j in enumerate(x):
        assert i == j
        break
    for i, j in enumerate(x):
        assert i == j
        break


# Generated at 2022-06-23 17:30:41.723880
# Unit test for constructor of class LazyList
def test_LazyList():
    for _ in range(100):
        lst = list(range(100))
        random.Random(0).shuffle(lst)
        lazy = LazyList(lst)
        assert lazy == lst



# Generated at 2022-06-23 17:30:53.531889
# Unit test for constructor of class MapList
def test_MapList():
    # Test basic pytest constructor
    assert len(MapList(len, [])) == 0
    assert len(MapList(len, [[], [], []])) == 3

    assert MapList(lambda a: a, []) == []
    assert MapList(lambda a: a, [[], [], []]) == [[], [], []]
    assert MapList(lambda a: a + 1, [[1], [2, 3], [4]]) == [[2], [3, 4], [5]]

    # test getitem constructor
    assert MapList(lambda a: a + 1, [1, 2, 3])[0] == 2
    assert MapList(lambda a: a + 1, [1, 2, 3])[2] == 4
    assert MapList(lambda a: a + 1, [1, 2, 3])[3] == None

# Generated at 2022-06-23 17:30:58.890667
# Unit test for function chunk
def test_chunk():
    for n in range(1, 10):
        for seq in [range(100), [], [1], [1, 2], [1, 2, 3], [1, 2, 3, 4]]:
            assert list(chunk(n, seq)) == list(map(lambda x: list(x), partition(n, len(seq), seq)))



# Generated at 2022-06-23 17:31:07.641522
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        len(LazyList(range(10)))
    except TypeError:
        pass
    else:
        assert False, "TypeError is not raised when __len__ is called before the iterable is depleted"
test_LazyList___len__()


# Generated at 2022-06-23 17:31:14.153516
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    for _f in [
        ([1, 2, 3], (lambda x : x + 1), [2, 3, 4]),
        ([1, 2, 3], (lambda x : x + 1), range(3, 6))
    ]:
        a = MapList(_f[1], _f[0])
        b = _f[2]
        try:
            assert next(a) == next(b)
        except StopIteration:
            assert False

# Generated at 2022-06-23 17:31:20.408101
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    # TODO: fix this
    # assert list(MapList(lambda x: x*x, [1, 2, 3])) == [1, 4, 9]
    # assert list(MapList(lambda x: x.upper(), ['a', 'b', 'c'])) == ['A', 'B', 'C']
    pass

# Generated at 2022-06-23 17:31:28.598052
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x>=5, [1, 2, 3, 4, 5, 6, 7, 8, 9])) == [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x>=5, [1, 5, 2, 3, 4, 5, 6, 7, 8, 9])) == [5, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x>=5, [1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 8, 9])) == [5, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 17:31:36.114145
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(2)
    for x in r:
        assert isinstance(x, int)
    r = Range(1, 10, 2)
    for x in r:
        assert isinstance(x, int)
    # Make sure __iter__() is idempotent
    for x, y in zip(r, r):
        assert x == y


# Generated at 2022-06-23 17:31:47.657843
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x*2, [1,2,3])[2] == 6
    assert MapList(lambda x: x*2, [1,2,3])[1] == 4
    assert MapList(lambda x: x*2, [1,2,3])[1:] == [4, 6]
    assert MapList(lambda x: x*2, [1,2,3])[3:] == [6]
    assert MapList(lambda x: x*2, [1,2,3])[1:3] == [4, 6]
    assert MapList(lambda x: x*2, [1,2,3])[1:3:2] == [4]

# Generated at 2022-06-23 17:31:51.211115
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(10)) == list(range(10))
    assert list(Range(1, 11)) == list(range(1, 11))
    assert list(Range(1, 11, 2)) == list(range(1, 11, 2))

# Generated at 2022-06-23 17:31:52.602191
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert isinstance(drop(5, range(10)), Iterator)



# Generated at 2022-06-23 17:32:04.885350
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    c = [5, 6, 7, 8, 9]

    lst = MapList(lambda i: a[i] * b[i], Range(len(a)))

    assert lst[0] == 2
    assert lst[1] == 6
    assert lst[2] == 12
    assert lst[3] == 20
    assert lst[4] == 30
    assert lst[-1] == 30

    assert lst[0:2] == [2, 6]
    assert lst[1:4] == [6, 12, 20]
    assert lst[-2:] == [20, 30]

# Generated at 2022-06-23 17:32:10.100345
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    a = LazyList(range(10))
    assert len(a) == 10
    assert a[0] == 0
    assert a[:2] == [0, 1]
    assert a[-1] == 9
    assert a[-2] == 8
    assert a[-3] == 7
    assert a[:-2] == [0, 1, 2, 3, 4, 5, 6, 7]
    assert a[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert a[::2] == [0, 2, 4, 6, 8]
    assert a[2:4] == [2, 3]
    assert a[4:-1] == [4, 5, 6, 7, 8]


# Generated at 2022-06-23 17:32:22.268898
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], '')) == ['abcd', 'bcd', 'cd', 'd', '']

    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]

# Generated at 2022-06-23 17:32:24.987391
# Unit test for function drop
def test_drop():
    for i in drop(0, [1,2,3,4]):
        print(i)
        assert i == 1


# Generated at 2022-06-23 17:32:30.959916
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(100))
    assert (l[3:10] == [3, 4, 5, 6, 7, 8, 9])
    assert (l[0] == 0)
    assert (l[-1] == 99)
    assert (l[-10:] == list(range(90, 100)))
    assert len(l) == 100

# Generated at 2022-06-23 17:32:33.995366
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-23 17:32:37.359427
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList([0, 1, 2, 3])) == [0, 1, 2, 3]

# Generated at 2022-06-23 17:32:45.053832
# Unit test for function chunk
def test_chunk():
    assert [list(x) for x in chunk(3, range(10))] == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert [list(x) for x in chunk(3, range(4))] == [[0, 1, 2], [3]]
    assert [list(x) for x in chunk(0, range(10))] == ValueError
    assert [list(x) for x in chunk(-3, range(10))] == ValueError



# Generated at 2022-06-23 17:32:46.040721
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4] )[2] == 9


# Generated at 2022-06-23 17:32:55.415815
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    """
    Test for method __iter__ of class LazyList
    """
    l = LazyList(range(1000))
    l_0 = l[0]
    l_1 = l[1]
    l_0_plus_1 = l[0] + 1
    l_1_plus_1 = l[1] + 1
    l_500 = l[500]
    assert (l_0 == 0)
    assert (l_1 == 1)
    assert (l_500 == 500)
    assert (l_0_plus_1 == 1)
    assert (l_1_plus_1 == 2)



# Generated at 2022-06-23 17:33:00.911420
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:33:08.247633
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    ml=MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert ml[0]==1
    assert ml[1]==4
    assert ml[2]==9
    assert ml[3]==16
    assert ml[4]==25
    assert ml[-1]==25
    assert ml[-2]==16
    assert ml[-3]==9
    assert ml[-4]==4
    assert ml[-5]==1
    assert ml[1:3]==[4,9]
    assert ml[-3:-1]==[9,16]


# Generated at 2022-06-23 17:33:13.485841
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10, 2)
    assert r.__next__() == 1
    assert r.__next__() == 3
    assert r.__next__() == 5
    assert r.__next__() == 7
    assert r.__next__() == 9


# Generated at 2022-06-23 17:33:17.360671
# Unit test for constructor of class Range
def test_Range():
    assert Range(1, 10 + 1) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert Range(1, 11, 2) == [1, 3, 5, 7, 9]
    ##assert Range(10)[-1] == 9
    ##assert Range(1, 10 + 1)[-1] == 10



# Generated at 2022-06-23 17:33:26.322052
# Unit test for function chunk
def test_chunk():
    assert chunk(3,"abcdefghi") == [['a', 'b', 'c'],['d', 'e', 'f'],['g', 'h', 'i']]
    assert chunk(5,"abcdefghi") == [['a', 'b', 'c','d','e'],['f', 'g', 'h', 'i']]
    assert chunk(8,"abcdefghi") == [['a', 'b', 'c','d','e', 'f', 'g', 'h'],['i']]



# Generated at 2022-06-23 17:33:29.940517
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(Range(10)) == list(range(10))
    assert list(Range(1, 10 + 1)) == list(range(1, 10 + 1))
    assert list(Range(1, 11, 2)) == list(range(1, 11, 2))


# Generated at 2022-06-23 17:33:31.681543
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(10))
    assert list(l) == list(range(10))
    assert list(l) == list(range(10))
    assert list(l[:]) == list(range(10))
    assert list(l) == list(range(10))

# Generated at 2022-06-23 17:33:39.175312
# Unit test for function drop
def test_drop():
    assert list(drop(n = 0, iterable = range(10))) == list(drop(n = 0, iterable = range(10)))
    assert list(drop(n = 0, iterable = range(10))) == list(range(10))
    assert list(drop(n = 5, iterable = range(10))) == list(range(5,10))
    assert list(drop(n = 10, iterable = range(10))) == list()
    assert list(drop(n = 15, iterable = range(10))) == list()


# Generated at 2022-06-23 17:33:41.780292
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:33:47.443321
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    expectedValue = [(0, 1), (2, 3), (4, 5), (6, 7), (8, 9)]
    actualValue = [pair for pair in itertools.zip_longest(
        list(range(0, 10, 2)), list(Range(0, 10, 2)))]
    assert expectedValue == actualValue


# Generated at 2022-06-23 17:33:52.266091
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    l = list(Range(-8, -3))
    assert l[0] == -8 and l[-1] == -3
l = list(Range(-8, -3))
assert l[0] == -8 and l[-1] == -3


# Generated at 2022-06-23 17:33:58.150806
# Unit test for constructor of class LazyList
def test_LazyList():
    assert list(LazyList(iter([]))) == []
    assert list(LazyList(range(10))) == list(range(10))
    ll = LazyList(range(10))
    ll[2]
    ll[6]
    assert list(ll) == list(range(10))
    ll = LazyList(range(10))
    ll[-1]
    ll[-6]
    assert list(ll) == list(range(10))
    ll = LazyList(range(10))
    with pytest.raises(ValueError):
        ll[1:0]


# Generated at 2022-06-23 17:34:01.343169
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    # Test with normal range
    r = range(3)
    assert type(r) is range
    assert list(Range(3)) == list(r)

    # Test with reversed range
    r = range(5, 0, -2)
    assert type(r) is range
    assert list(Range(5, 0, -2)) == list(r)
    assert Range(5, 0, -2)[2] == r[2]

# Generated at 2022-06-23 17:34:07.234232
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:34:15.941364
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3], 4)) == [4, 5, 8]
    assert list(scanl(operator.add, [1, 2, 3])) == [1, 3, 6]
    assert list(scanl(lambda s, y: s + y, ['a', 'b', 'c'], 'd')) == ['d', 'da', 'dab', 'dabc']
    assert list(scanl(lambda s, y: s + y, ['a', 'b', 'c'])) == ['a', 'ab', 'abc']
    assert list(scanl(lambda s, y: s * y, [2, 3, 4])) == [2, 6, 24]



# Generated at 2022-06-23 17:34:18.253618
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    v = Range(10, 13)
    for e in iter(v):
        assert e == next(v)

# Generated at 2022-06-23 17:34:21.023995
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert 5 == len(Range(5))
    assert 5 == len(Range(0, 5))
    assert 5 == len(Range(0, 5, 1))
    assert 3 == len(Range(0, 8, 2))
    assert 8 == len(Range(3, 0, -1))
    assert 11 == len(Range(0, -12, -1))

# Generated at 2022-06-23 17:34:30.289717
# Unit test for constructor of class MapList
def test_MapList():
    lst_A = [1, 2]
    lst_B = [1, 2]
    func = lambda x: [x]

    result = MapList(func, lst_A+lst_B)
    assert result[0] == func(1)
    assert result[1] == func(2)
    assert result[2] == func(1)
    assert result[3] == func(2)
    assert result[:] == [func(1), func(2), func(1), func(2)]



# Generated at 2022-06-23 17:34:35.949613
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():

    func = lambda x:x**2
    lst = [1, 2, 3]

    map_list = MapList(func, lst)
    x_gen = [v for v in map_list]
    x_exp = [func(v) for v in lst]
    assert x_gen == x_exp

# Generated at 2022-06-23 17:34:42.442031
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = iter(LazyList([]))
    assert next(it) == StopIteration
    assert next(it) == StopIteration
    it = iter(LazyList([1]))
    assert next(it) == 1
    assert next(it) == StopIteration
    it = iter(LazyList([1, 2]))
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == StopIteration
    it = iter(LazyList([1, 2]))
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == StopIteration

# Generated at 2022-06-23 17:34:48.531580
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    len(r)
    r = Range(1, 10 + 1)
    len(r)
    r = Range(1, 11, 2)
    len(r)
    r = Range(1, 1)
    len(r)
    r = Range(1, 2, -1)
    len(r)

# Generated at 2022-06-23 17:34:50.222921
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    i = Range(1, 5)
    return i[3]


# Generated at 2022-06-23 17:34:57.688348
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    print(r[0], r[2], r[4])
    assert len(r) == 5, "len of Range is 5"
    r1 = Range(1, 10 + 1, 2)
    assert len(r1) == 5, "len of Range is 5 with negative step"


if __name__ == '__main__':
    test_Range___len__()

# Generated at 2022-06-23 17:35:01.021313
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 10)
    count = 0
    for x in r:
        if x != count+1:
            print("error")
        count += 1
    if count != 9:
        print("error")

# Generated at 2022-06-23 17:35:08.345460
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def func(x):
        return x * x
    lst = [1, 2, 3, 4, 5]
    map_lst = MapList(func, lst)
    assert map_lst[0] == 1
    assert map_lst[-1] == 25
    assert map_lst[1:4] == [4, 9, 16]



# Generated at 2022-06-23 17:35:15.472088
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from itertools import count
    lst = LazyList(count())
    assert lst[0] == 0
    assert lst[50] == 50
    assert lst[:5] == list(range(5))
    assert lst[50:] == list(range(50, 100))
    assert lst[:100:2] == list(range(0, 100, 2))

test_LazyList___getitem__()



# Generated at 2022-06-23 17:35:19.644462
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    # Case 1:
    try:
        len(lst)
        raise Exception("__len__ should fail if the iterable is not depleted")
    # Case 2:
    except TypeError:
        pass
    for x in lst:
        pass
    assert len(lst) == 10

# Generated at 2022-06-23 17:35:24.414787
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1, 4, 5])) == 3


    class AlwaysError(Iterable[int]):
        def __iter__(self):
            raise ValueError
    assert raises(TypeError, lambda: len(LazyList(AlwaysError())))



# Generated at 2022-06-23 17:35:36.350952
# Unit test for constructor of class MapList
def test_MapList():
    import pytest
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5, 6, 7, 8, 9])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5, 6, 7, 8, 9])[1:6] == [4, 9, 16, 25, 36]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5, 6, 7, 8, 9])[-2:] == [64, 81]
    assert next(MapList(lambda x: x * x, [1, 2, 3, 4, 5, 6, 7, 8, 9])) == 1

# Generated at 2022-06-23 17:35:40.224723
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    true = [1, 2, 3, 4, 5]
    l = MapList(lambda x: x, true)
    ans = l.__iter__()
    assert list(ans) == true
test_MapList___iter__()

# Generated at 2022-06-23 17:35:47.781120
# Unit test for function drop
def test_drop():
    assert list(drop(-1, range(1))) == [] # Test n < 0
    assert list(drop(1, range(1))) == [] # Test n >= len(range(1))
    assert list(drop(2, range(1))) == [] # Test n > len(range(1))
    assert list(drop(0, range(1))) == [0] # Test n == 0
    assert list(drop(1, range(2))) == [1] # Test n == 1
    assert list(drop(1, range(3))) == [1, 2] # Test n == 2



# Generated at 2022-06-23 17:35:57.433463
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    rng = Range(3, 7)
    assert rng[slice(0, 3)] == [3, 4, 5]
    assert rng[slice(0, 3, 2)] == [3, 5]
    assert rng[slice(1, 3)] == [4, 5]
    assert rng[slice(1, 3, 2)] == [4]
    assert rng[slice(1, -1)] == [4, 5]
    assert rng[slice(1, -2)] == [4]
    assert rng[slice(1, -2, 2)] == []
    assert rng[slice(1, -3, 2)] == [4]
    assert rng[slice(2, -2, 2)] == []
    assert rng[slice(2, -3, 2)] == []

# Generated at 2022-06-23 17:36:00.886221
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    assert [5, 9, 13, 17, 21] == MapList(lambda x: x * x, a)


# Generated at 2022-06-23 17:36:06.291894
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-23 17:36:13.351238
# Unit test for function drop_until
def test_drop_until():
    data = range(11)
    assert list(range(6,11))  == list(drop_until(lambda x: x>=5, data))
    assert list(range(0,11))  == list(drop_until(lambda x: x<0, data))
    assert list(range(11))  == list(drop_until(lambda x: x>11, data))
test_drop_until()



# Generated at 2022-06-23 17:36:18.689273
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda x, y: x * y, [1, 2, 3, 4])) == [24, 12, 4, 1]
    assert list(scanr(lambda x, y: x * y, [1, 2, 3, 4], 0)) == [24, 12, 4, 1, 0]
    assert list(scanr(lambda x, y: x + y, [1, 2, 3, 4])) == [10, 9, 7, 4]
    assert list(scanr(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda x, y: x + y, [])) == []
    assert list(scanr(lambda x, y: x + y, [], 42)) == [42]

# Generated at 2022-06-23 17:36:30.109932
# Unit test for method __next__ of class Range
def test_Range___next__():
    global Range
    reload(sys.modules["autograder.utils.itertools"])
    from autograder.utils.itertools import Range
    # Implicit test 1: Try to iterate over an empty range
    try:
        iterator = iter(Range(2) if random.random() > .5 else Range(2, 2))
        empty_range = next(iterator)
        raise ValueError("An empty range should be StopIterated!")
    except StopIteration:
        ()

    for test_case in range(100):
        rng = Range(random.randint(1, 10))
        for _ in range(len(rng)):
            next(rng)

# Generated at 2022-06-23 17:36:35.367778
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(3)
    r_iter = r.__iter__()
    assert next(r_iter) == 0
    assert next(r_iter) == 1
    assert next(r_iter) == 2
    try:
        next(r_iter)
        assert False, 'expected StopIteration exception'
    except StopIteration:
        pass


# Generated at 2022-06-23 17:36:39.028939
# Unit test for function drop_until
def test_drop_until():
    iterable = range(10)
    for n in range(10):
        pred_fn = lambda x: x >= n
        assert list(drop_until(pred_fn, iterable)) == list(iterable)[n:]



# Generated at 2022-06-23 17:36:47.597116
# Unit test for function scanl
def test_scanl():
    for xs, ys in [
        [[1, 2, 3, 4], [0, 1, 3, 6, 10]],
        [['a', 'b', 'c', 'd'], ['a', 'ba', 'cba', 'dcba']],
        [['a', 'b', 'c', 'd'], ['a', 'ba', 'cba', 'dcba']],
        [[], []],
        [[1], [1]],
        [range(100), range(100)],
        [range(101), range(101)],
    ]:
        target = list(scanl(operator.add, xs, initial=0))
        expected = ys
        assert target == expected
        target = list(scanl(operator.add, xs))

# Generated at 2022-06-23 17:36:51.068064
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    assert MapList(lambda i: a[i] * b[i], range(len(a)))[2] == 10

# Generated at 2022-06-23 17:36:57.176375
# Unit test for function take
def test_take():
    # Cannot use list(take(3, [4, 5])) for doctest, because the type is not inferred as List[int].
    assert list(take(3, [4, 5])) == [4, 5]
    assert list(take(-3, [4, 5])) == []



# Generated at 2022-06-23 17:37:07.294330
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random

    def get_random_ints(n, seed=None):
        random.seed(seed)
        r = random.Random()
        for _ in range(n):
            yield r.randint(1, 6)

    def test_value(func, lst):
        mapped_list = MapList(func, lst)
        assert all([func(x) == mapped_list[i] for i, x in enumerate(lst)])
        assert all([func(x) == y for x, y in zip(lst, mapped_list)])

    def test_slice(func, lst, *, start, end, step):
        mapped_list = MapList(func, lst)
        slice_ = slice(start, end, step)
        assert [func(x) for x in lst[slice_]]

# Generated at 2022-06-23 17:37:09.399686
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert LazyList(range(10))[2] == 2
    assert LazyList(range(10))[3:5] == [3, 4]



# Generated at 2022-06-23 17:37:17.778118
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'e')) == ['abcde', 'bcde', 'cde', 'de', 'e']

