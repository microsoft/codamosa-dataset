

# Generated at 2022-06-23 17:27:14.802527
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        MapList(lambda x: x, [1, 2, 3, 4]).__len__()


# Generated at 2022-06-23 17:27:20.550527
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from types import GeneratorType
    from types import BuiltinFunctionType
    from types import BuiltinMethodType
    # method of class MapList called with 0 argument(s)
    # returns a generator
    assert isinstance(MapList(lambda a,b: a+b, [])(), GeneratorType)
    # method of class MapList called with 0 argument(s)
    # returns a generator
    assert isinstance(MapList(lambda a: a+1, [])(), GeneratorType)
    # method of class MapList called with 0 argument(s)
    # returns a generator
    assert isinstance(MapList(lambda : None, [])(), GeneratorType)
    # method of class MapList called with 0 argument(s)
    # returns a generator

# Generated at 2022-06-23 17:27:30.828601
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import numpy as np
    import random
    r = Range(10, 20, 1)
    expected = [i for i in range(10, 20)]
    assert expected == r[:]
    assert expected == r[0:len(r)]
    assert expected == r[0:]
    assert expected == r[:len(r)]
    assert expected == r[:]
    assert expected == r[::]
    assert expected == r[len(r):0:-1]
    assert expected == list(reversed(r))

    r = Range(10, 20, 1)
    assert expected == r[::1]
    assert expected == r[::-1]
    assert expected == list(reversed(r))
    random.seed(1234)
    step = random.randrange(2, 10)

# Generated at 2022-06-23 17:27:35.041116
# Unit test for constructor of class LazyList
def test_LazyList():
    import random
    for i in range(100):
        limit = random.randint(100, 1000)
        iter = (random.randint(0, 100) for _ in range(limit))
        lst = LazyList(iter)
        for i in range(limit):
            assert lst[i] == lst[:i].pop()
            assert len(lst[:i]) == i
        assert len(lst) == limit
    return True



# Generated at 2022-06-23 17:27:46.202385
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    x = LazyList([1, 2, 3])
    y = list(x)
    assert y == [1, 2, 3]
    # Test that we can iterate multiple times
    y = list(x)
    assert y == [1, 2, 3]
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3
    z0 = iter(x)
    z1 = iter(x)
    assert next(z0) == 1
    assert next(z1) == 1
    assert next(z0) == 2
    assert next(z1) == 2
    assert next(z0) == 3
    assert next(z1) == 3
    with pytest.raises(StopIteration):
        next(z0)

# Generated at 2022-06-23 17:27:54.875542
# Unit test for function chunk
def test_chunk():
    # chunk(0, [1, 2, 3])
    with pytest.raises(ValueError):
        list(chunk(0, [1, 2, 3]))
    # chunk(0, [])
    with pytest.raises(ValueError):
        list(chunk(0, []))
    # chunk(2, [1, 2, 3])
    eq_(list(chunk(2, [1, 2, 3])), [[1, 2], [3]])
    # chunk(2, [1, 2, 3])
    eq_(list(chunk(2, Range(1, 3))), [[1, 2], [3]])
    # chunk(2, [])
    eq_(list(chunk(2, [])), [])
    # chunk(2, [1, 2])

# Generated at 2022-06-23 17:28:04.120634
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(10)) == 0
    assert next(Range(1, 10)) == 1
    with pytest.raises(StopIteration):
        next(Range(0))
    assert next(Range(1, 11, 2)) == 1
    assert next(Range(1, 10, 2)) == 1
    with pytest.raises(StopIteration):
        next(Range(0, 10, 2))


# Generated at 2022-06-23 17:28:14.698950
# Unit test for function split_by
def test_split_by():
    lines = ["SPAM Spam spam SPAM", "Spam Spam Spam SPAM", "SPAM Spam Spam Spam"]
    assert list(split_by(lines, criterion=lambda s: s.startswith("SPAM"))) \
           == [["SPAM Spam spam SPAM"], ["Spam Spam Spam SPAM"], ["SPAM Spam Spam Spam"]]
    assert list(split_by(lines, criterion=lambda s: s.startswith("SPAM"), empty_segments=True)) \
           == [[], ["SPAM Spam spam SPAM"], ["Spam Spam Spam SPAM"], ["SPAM Spam Spam Spam"]]

# Generated at 2022-06-23 17:28:16.882519
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    class ExhaustIter:
        def __iter__(self):
            while True:
                yield 1
    assert len(LazyList(ExhaustIter())) == 1



# Generated at 2022-06-23 17:28:24.069107
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(1, range(10))) == [0]
    assert list(take(-1, range(10))) == []
    assert list(take(0, range(10))) == []
    assert list(take(10, range(2))) == [0, 1]
    assert list(take(0, [])) == []


# Generated at 2022-06-23 17:28:30.180297
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]



# Generated at 2022-06-23 17:28:33.719770
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        len(LazyList(range(100)))
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-23 17:28:44.299001
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(0, 3)
    assert r1[0] == 0 and r1[1] == 1 and r1[2] == 2 and r1[3] == 3
    r2 = Range(0, 11, 2)
    assert r2[0] == 0 and r2[1] == 2 and r2[2] == 4 and r2[3] == 6 and r2[4] == 8 and r2[5] == 10
    r3 = Range(4)
    assert r3[0] == 0 and r3[1] == 1 and r3[2] == 2 and r3[3] == 3 and r3[4] == 4
    try:
        r1[5]
    except IndexError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-23 17:28:55.492248
# Unit test for constructor of class LazyList
def test_LazyList():
    import random
    import time

    rand_seq, rand_lst = random.sample(range(100, 200), 5), []
    # rand_seq and rand_lst should have 5 elements, ranging from 100 to 199
    assert (len(rand_seq) == len(rand_lst) and len(rand_seq) == 5)

    start = time.clock()
    print('Testing LazyList constructor with %d elements, with indices %s' % (len(rand_seq), rand_seq))
    for idx, item in enumerate(rand_seq):
        rand_lst.append(idx)
    assert (rand_lst == list(range(5))), "Unexpected list generated"
    end = time.clock()
    print('Sequential access to list takes %.4f seconds' % (end - start))



# Generated at 2022-06-23 17:29:08.303729
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # assert TypeError in tt.assert_raises(TypeError, lambda: Range(1, 2, 3)[1.0])
    assert Range(1, 11, 2)[0] == 1
    assert Range(2)[1] == 1
    assert Range(1, 2)[1] == 1
    assert Range(1, 2, 3)[1] == 1
    assert Range(1, 11, 2)[1] == 3
    assert Range(2)[2] == 2
    assert Range(1, 2)[2] == 2
    assert Range(1, 2, 3)[2] == 2
    assert Range(1, 11, 2)[2] == 5
    assert Range(2)[3] == 3
    assert Range(1, 2)[3] == 3
    assert Range(1, 2, 3)[3] == 3

# Generated at 2022-06-23 17:29:20.846363
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    s = LazyList(range(8))
    assert s[0] == 0
    assert s[1] == 1
    assert s[2] == 2
    assert s[3] == 3
    assert s[5] == 5
    assert s[-1] == 7
    assert s[1.0] == 1
    try:
        s[10]
        assert False
    except IndexError:
        pass
    # Ensure the iterable is only iterated up to the accessed indices
    s = LazyList(range(10))
    assert s[::2] == [0, 2, 4, 6, 8]
    assert s[-2:] == [8, 9]
    assert s[2:-2] == [2, 3, 4, 5, 6, 7]

# Generated at 2022-06-23 17:29:33.010196
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x == 5)) == [[0, 1, 2, 3, 4], [6, 7, 8, 9]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x == 0)) == [[1, 2, 3, 4, 5, 6, 7, 8, 9]]

# Generated at 2022-06-23 17:29:35.364956
# Unit test for method __next__ of class Range
def test_Range___next__():
    a = Range(0, 10, 1)
    assert(a.__next__() == 0)
    assert(a.__next__() == 1)

# Generated at 2022-06-23 17:29:46.139910
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert list(Range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(0, 10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(1, 10)) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(Range(1, 10, 2)) == [1, 3, 5, 7, 9]
    assert list(Range(1, 10, -1)) == []
    assert list(Range(10, 1, -1)) == [10, 9, 8, 7, 6, 5, 4, 3, 2]
    assert list(Range(10, 1, 1)) == []

# Generated at 2022-06-23 17:29:51.497552
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():

    ############################
    # Setup test objects
    ############################
    # List
    lst = [1, 2, 3, 4]

    # Function
    def func(x):
        return x * 2

    ############################
    # Run test
    ############################
    # Call function under test
    mlst = MapList(func, lst)
    result = mlst[2]

    ############################
    # Compare results
    ############################
    expected = 6
    assert result == expected



# Generated at 2022-06-23 17:29:57.750510
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList([1, 2, 3, 4])) == [1, 2, 3, 4]
    assert list(LazyList([1, 2, 3, 4]).__iter__()) == [1, 2, 3, 4]
    assert list(LazyList([1, 2, 3, 4]).__iter__().__iter__()) == [1, 2, 3, 4]
    assert list(LazyList([1, 2, 3, 4])[:]) == [1, 2, 3, 4]
    assert list(LazyList([1, 2, 3, 4])[1:3]) == [2, 3]
    assert list(LazyList([1, 2, 3, 4])[1:]) == [2, 3, 4]

# Generated at 2022-06-23 17:30:03.046657
# Unit test for method __len__ of class Range
def test_Range___len__():
    r1 = Range(3)
    assert(len(r1) == 3)
    r2 = Range(10, 20)
    assert(len(r2) == 10)
    r3 = Range(10, 20, 2)
    assert(len(r3) == 5)

# Generated at 2022-06-23 17:30:10.483248
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    if len(sys.argv) > 1:
        return

    r = Range(10)   # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)

    print(r[0], r[2], r[4])
    print(r[-1], r[-2])
    print(r[1:4])
    print(r[4:])
    print(r[:4])
    print(r[:])

# Generated at 2022-06-23 17:30:12.993941
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    items = list(range(1000))
    lazy = LazyList(items)


# Generated at 2022-06-23 17:30:15.085913
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[9] == 9

# Generated at 2022-06-23 17:30:16.773825
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10)
    print(r.__next__())


# Generated at 2022-06-23 17:30:18.787779
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(0, 1)) == 1
    assert len(Range(1, 11, 2)) == 5

# Generated at 2022-06-23 17:30:23.218113
# Unit test for constructor of class Range
def test_Range():
    l1 = list(range(10))
    l2 = list(Range(10))
    assert l1 == l2

    l1 = list(range(1, 10 + 1))
    l2 = list(Range(1, 10 + 1))
    assert l1 == l2

    l1 = list(range(1, 11, 2))
    l2 = list(Range(1, 11, 2))
    assert l1 == l2


# Generated at 2022-06-23 17:30:31.817502
# Unit test for constructor of class Range
def test_Range():
    start = 0
    end = 10
    step = 1
    r = Range(start, end+1, step)
    for i in r:
        assert i == start
        start += 1
        if start > end:
            break
    l = list(r[2:len(r)-1])
    assert l == [2,3,4,5,6,7,8]
    l = list(r[-10:0:-2])
    assert l == [0,2,4,6,8]
    l = list(r[-1:1:-1])
    assert l == [9,8,7,6,5,4,3]
    l = list(r[1:])
    assert l == [1,2,3,4,5,6,7,8,9]

# Generated at 2022-06-23 17:30:43.779436
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from datetime import datetime
    from random import randint, shuffle

    print("Test 1")
    a = [randint(0, 10 ** 9) for _ in range(1000000)]
    for i in range(0, len(a)):
        assert MapList(str, a)[i] == str(a[i])
    for i in range(-len(a), 0):
        assert MapList(str, a)[i] == str(a[i])
    for i in range(-len(a) // 2, len(a) // 2):
        assert MapList(str, a)[i] == str(a[i])
    for i in range(0, len(a), 10):
        assert MapList(str, a)[i] == str(a[i])

    print("Test 2")

# Generated at 2022-06-23 17:30:49.712670
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    data = ['a', 'b', 'c', 'd', 'e', 'f']
    def give_data():
        yield from data
    lst = LazyList(give_data())
    lsti = lst.__iter__()
    assert isinstance(lsti, LazyList.LazyListIterator)
    assert lsti.list() is lst
    assert list(lsti) == data



# Generated at 2022-06-23 17:30:56.239629
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    a = [1, 2, 3, 4, 5]
    ans = [1, 4, 9, 15]
    b = MapList(lambda x: a[x] * a[x], Range(0, len(a), 2))
    assert list(b) == ans
    assert len(b) == len(ans)

# Generated at 2022-06-23 17:31:06.416132
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    def test_Range___getitem__1():
        r = Range(100)
        assert r[0] == 0
        assert r[50] == 50
        assert r[-1] == 99

        assert r[0:5] == [0, 1, 2, 3, 4]
        assert r[-5:-1] == [95, 96, 97, 98]
        assert r[-5:5] == r[:5]

        # [0, 100)
        r = Range(100, 101)
        # [0, 100)
        assert r[0] == 0
        assert r[50] == 50
        assert r[-1] == 99

        assert r[0:5] == [0, 1, 2, 3, 4]
        assert r[-5:-1] == [95, 96, 97, 98]

# Generated at 2022-06-23 17:31:12.191816
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-23 17:31:22.770338
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3, 4])

    new_list = list(lst)
    assert list(new_list) == [1, 2, 3, 4]
    assert list(new_list) == [1, 2, 3, 4]
    assert list(lst) == [1, 2, 3, 4]

    new_list = list(LazyList([1, 2, 3, 4]))
    assert list(new_list) == [1, 2, 3, 4]
    assert list(new_list) == [1, 2, 3, 4]
    assert list(lst) == [1, 2, 3, 4]


# Generated at 2022-06-23 17:31:24.227508
# Unit test for function take
def test_take():
    e=take(5, range(1000000))
    assert e==range(5)

# Generated at 2022-06-23 17:31:28.859299
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
test_split_by()



# Generated at 2022-06-23 17:31:32.925258
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: 2 * x, [1, 2, 3, 4])) == [2, 4, 6, 8]


# Generated at 2022-06-23 17:31:40.917325
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)
    assert next(r) == 0
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    try:
        next(r)
        raise AssertionError  # function should raise exception here
    except StopIteration:
        pass

# Generated at 2022-06-23 17:31:45.441394
# Unit test for constructor of class LazyList
def test_LazyList():
    from itertools import count, islice
    print(LazyList(count(1, 2)))
    L1 = LazyList(count(1,2))

# Generated at 2022-06-23 17:31:50.006804
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(10)) == [i for i in range(10)]
    assert list(Range(1, 10+1)) == [i for i in range(1, 10+1)]
    assert list(Range(1, 11, 2)) == [i for i in range(1, 11, 2)]


# Generated at 2022-06-23 17:31:59.842262
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(1000))
    # print(ll[5])
    assert ll[5] == 5

    ll = LazyList(range(1000))
    assert ll[5:10] == [5, 6, 7, 8, 9]

    ll = LazyList(range(1000))
    assert ll[0:2] == [0, 1]

    ll = LazyList(range(1000))
    assert ll[-1] == 999

    ll = LazyList(range(1000))
    assert ll[:] == list(range(1000))

    ll = LazyList(range(1000))
    assert ll[1000:] == []

    with pytest.raises(TypeError):
        len(ll)



# Generated at 2022-06-23 17:32:06.878680
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Create the object
    r = Range(10)
    assert [i for i in r] == [0,1,2,3,4,5,6,7,8,9]
    r = Range(1, 10 + 1)
    assert [i for i in r] == [1,2,3,4,5,6,7,8,9,10]
    r = Range(1, 11, 2)
    assert [i for i in r] == [1,3,5,7,9]

# Generated at 2022-06-23 17:32:17.442714
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(0, 12, 3)
    r2 = Range(4)
    r3 = Range(-4)
    r4 = Range(-4, -1)
    r5 = Range(4, 3)
    r6 = Range(4, 3, -1)
    r7 = Range(4, 6, -1)
    assert len(r) == len(range(0, 12, 3))
    assert len(r2) == 4
    assert len(r3) == 0
    assert len(r4) == 0
    assert len(r5) == 0
    assert len(r6) == 1
    assert len(r7) == 0

# Generated at 2022-06-23 17:32:25.411125
# Unit test for constructor of class Range
def test_Range():
    assert Range(0, 10, 1).__len__() == 10
    assert Range(0, 10, 1)[1] == 1
    assert Range(0, 10, 1)[0] == 0
    assert Range(1, 10, 2)[4] == 9
    assert Range(1, 10, 2).__len__() == 5
    assert Range(1, 10, 2)[0] == 1
    assert Range(1, 10, 2)[1] == 3
    assert Range(0, 10, 3)[2] == 6


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-23 17:32:29.551770
# Unit test for function drop_until
def test_drop_until():
    it = iter(range(-1, 10, 2))
    gen = drop_until(lambda x: x > 0, it)
    assert next(gen) == 1
    assert list(gen) == list(range(3, 10, 2))



# Generated at 2022-06-23 17:32:31.914376
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList([-1, 2, 3, 4, 5])) == [-1, 2, 3, 4, 5]

# Generated at 2022-06-23 17:32:36.168476
# Unit test for constructor of class MapList
def test_MapList():
    assert [2, 4, 6] == MapList(lambda x: x * 2, [1, 2, 3])[0:3]
    assert [6, 12, 18] == MapList(lambda x: x * 3, [2, 4, 6])[2:]



# Generated at 2022-06-23 17:32:43.650208
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: x * x, [1, 2, 3, 4, 5])) == [1, 4, 9, 16, 25]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[0:5] == [1, 4, 9, 16, 25]



# Generated at 2022-06-23 17:32:44.800858
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:32:51.691949
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    assert next(r) == 10
    try:
        next(r)
    except StopIteration:
        pass
    else:
        raise AssertionError("`next(r)` should raise `StopIteration`")


# Generated at 2022-06-23 17:32:54.267975
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10)) == 9
    assert len(Range(1, 11, 2)) == 5


# Generated at 2022-06-23 17:33:04.706665
# Unit test for constructor of class Range
def test_Range():
    assert tuple(Range(1)) == (0,)
    assert tuple(Range(0, 1)) == (0,)
    assert tuple(Range(0, 2)) == (0, 1)
    assert tuple(Range(0, 3)) == (0, 1, 2)
    assert tuple(Range(0, 10, 2)) == (0, 2, 4, 6, 8)
    assert tuple(Range(0, -10, -2)) == (0, -2, -4, -6, -8)

test_Range()

# Determine if an object is subscriptable
# https://stackoverflow.com/questions/2612802/how-to-clone-or-copy-a-list-in-python

# Generated at 2022-06-23 17:33:09.937770
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == list(range(5))
    assert list(take(0, range(1000000))) == []
    assert list(take(-1, range(1000000))) == []



# Generated at 2022-06-23 17:33:14.771028
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert a[0] == 1
    assert a[-1] == 25
    assert a[1:3] == [4, 9]


# Generated at 2022-06-23 17:33:15.949285
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 17:33:17.595596
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x + 100, range(5))) == [100, 101, 102, 103, 104]



# Generated at 2022-06-23 17:33:23.258493
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    class A:
        def __iter__(self):
            yield 1
            yield 2
            yield 3
    a = A()
    a_len = LazyList(a)
    assert len(a_len) == 3
test_LazyList___len__()




# Generated at 2022-06-23 17:33:26.088598
# Unit test for function scanr
def test_scanr():
    assert list(scanr(lambda a, b: a - b, [1, 2, 3, 4])) == [2, -1, -5, -10]



# Generated at 2022-06-23 17:33:33.096376
# Unit test for function take
def test_take():
    assert list(take(5, range(100))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(5))) == []



# Generated at 2022-06-23 17:33:36.441096
# Unit test for constructor of class MapList
def test_MapList():
    print(*MapList(lambda x:x*x, [1,2,3]))
    assert MapList(lambda x:x*x, [1,2,3]) == [1,4,9]

# Generated at 2022-06-23 17:33:47.616728
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    global range
    range = Range
    assert Range(10)[:5] == [0, 1, 2, 3, 4]
    assert Range(10)[-5:] == [5, 6, 7, 8, 9]
    assert Range(10)[::2] == [0, 2, 4, 6, 8]
    assert Range(10)[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert Range(10)[0] == 0
    assert Range(10)[1] == 1
    assert Range(10)[-1] == 9
    assert Range(10)[-2] == 8
    assert Range(1,10)[-1] == 9
    assert Range(1,10)[-2] == 8
    assert Range(1,10, 2)[-1] == 9
   

# Generated at 2022-06-23 17:33:50.447075
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    iter_ = Range(10).__iter__()
    assert isinstance(iter_, Iterator)

# Generated at 2022-06-23 17:33:55.055481
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    import operator
    a = MapList(operator.add, range(5, 10))
    b = [e for e in a]
    print('b =', b)
    assert b == [5, 6, 7, 8, 9]



# Generated at 2022-06-23 17:33:57.630775
# Unit test for function chunk
def test_chunk():
    from itertools import islice

    assert list(islice(chunk(2, 'abcdef'), 3, 4)) == [['e', 'f']]



# Generated at 2022-06-23 17:34:05.092049
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)         # (end)
    assert r[0] == 0
    assert r[1] == 1
    assert list(r[:-1]) == [0, 1, 2, 3, 4, 5, 6, 7, 8]
    r = Range(1, 10 + 1)  # (start, end)
    assert r[0] == 1
    assert r[1] == 2
    assert list(r[:-1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    r = Range(1, 11, 2)   # (start, end, step)
    assert r[0] == 1
    assert r[1] == 3
    assert list(r[:-1]) == [1, 3, 5, 7, 9]
test_Range___getitem__()



# Generated at 2022-06-23 17:34:10.176371
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:34:14.658495
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                  ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:34:21.365849
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[i] for i in range(10)]
    assert list(chunk(10, range(10))) == [list(range(10))]
    assert list(chunk(3, [])) == []



# Generated at 2022-06-23 17:34:30.974312
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():

    lst = LazyList(range(10))
    assert hasattr(lst, '__len__')
    assert isinstance(lst, Sequence)
    assert len(lst) == 10
    assert isinstance(lst[0], int)
    assert isinstance(lst[4:7], list)
    assert isinstance(lst[-1], int)

    bad_lst = LazyList(range(5))
    try:
        len(bad_lst)
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-23 17:34:40.489461
# Unit test for constructor of class MapList
def test_MapList():
    lst = [1, 2, 3, 4, 5]
    map_list = MapList(lambda x: x * x, lst)
    for i in range(len(lst)):
        assert map_list[i] == lst[i] * lst[i]
    
    lst1 = [1, 2, 3, 4, 5]
    lst2 = [2, 3, 4, 5, 6]
    map_list2 = MapList(lambda i: lst1[i] * lst2[i], Range(len(lst1)))
    for i in range(len(lst1)):
        assert map_list2[i] == lst1[i] * lst2[i]


# Generated at 2022-06-23 17:34:46.413632
# Unit test for function drop
def test_drop():
    a = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop(3, a)) == [3, 4, 5, 6, 7, 8, 9]
    assert list(drop(14, a)) == []

# Generated at 2022-06-23 17:34:54.146495
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(1, 5))) == [1, 2, 3, 4]
    assert list(drop(1, range(1, 5))) == [2, 3, 4]
    assert list(drop(4, range(1, 5))) == []
    assert list(drop(5, range(1, 5))) == []
    assert list(drop(6, range(1, 5))) == []



# Generated at 2022-06-23 17:35:00.585447
# Unit test for constructor of class Range
def test_Range():
    r = Range(1, 10, 2)
    assert len(r) == 5
    assert len(r[:]) == 5
    assert next(r) == 1
    assert r[0] == 1
    assert r[1] == 3
    assert r[-1] == 9
    assert list(r[:]) == [1, 3, 5, 7, 9]



# Generated at 2022-06-23 17:35:06.745880
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(10))) == list(range(3, 10))
    assert list(drop(100, range(10))) == []
    assert list(drop(0, range(10))) == list(range(10))


# Generated at 2022-06-23 17:35:10.922210
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[3] == 16



# Generated at 2022-06-23 17:35:17.093551
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ls = LazyList(range(5))
    assert list(ls) == [0, 1, 2, 3, 4]
    ls = LazyList(range(5))
    assert list(ls) == [0, 1, 2, 3, 4]
    assert list(ls) == [0, 1, 2, 3, 4]
    ls = LazyList([])
    assert list(ls) == []


# Generated at 2022-06-23 17:35:19.287568
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(iter(Range(4))) == [0, 1, 2, 3]

# Generated at 2022-06-23 17:35:28.450333
# Unit test for function drop
def test_drop():
    """
    >>> list(drop(0, [1,2,3,4]))
    [1, 2, 3, 4]
    >>> list(drop(1, [1,2,3,4]))
    [2, 3, 4]
    >>> list(drop(2, [1,2,3,4]))
    [3, 4]
    >>> list(drop(3, [1,2,3,4]))
    [4]
    >>> list(drop(4, [1,2,3,4]))
    []
    >>> list(drop(5, [1,2,3,4]))
    []
    """
    pass



# Generated at 2022-06-23 17:35:30.293719
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    pass

# Generated at 2022-06-23 17:35:41.069051
# Unit test for function chunk
def test_chunk():
    # Test empty iterable
    assert list(chunk(1, [])) == []
    assert list(chunk(2, [])) == []
    
    # Test iterable with one element
    assert list(chunk(1, [1])) == [[1]]
    assert list(chunk(2, [1])) == [[1]]

    # Test iterable with multiple elements
    assert list(chunk(1, [1, 2, 3, 4])) == [[1], [2], [3], [4]]
    assert list(chunk(2, [1, 2, 3, 4])) == [[1, 2], [3, 4]]
    assert list(chunk(3, [1, 2, 3, 4])) == [[1, 2, 3], [4]]

# Generated at 2022-06-23 17:35:42.985106
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: x * x, [1, 2, 3])) == [1, 4, 9]



# Generated at 2022-06-23 17:35:45.459406
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-23 17:35:47.483525
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(5))
    for x in lst:
        for y in lst:
            assert x == y

# Generated at 2022-06-23 17:35:53.313093
# Unit test for constructor of class MapList
def test_MapList():
    a = [0, 1, 2, 3, 4]
    ma = MapList(lambda x: x * x, a)
    assert ma[2] == 4
    assert ma[2:4] == [4, 9]
    assert list(ma) == [0, 1, 4, 9, 16]
    assert len(ma) == 5
    assert all(x == y for x, y in zip(ma, map(lambda x: x * x, a)))

# Generated at 2022-06-23 17:36:00.055764
# Unit test for constructor of class LazyList
def test_LazyList():
    list_1 = [10, 20, 30, 40]
    lazy_list_1 = LazyList(list_1)
    assert len(lazy_list_1) == len(list_1)
    assert lazy_list_1[0] == list_1[0]



# Generated at 2022-06-23 17:36:05.236525
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x-y, [1, 2, 3, 4])) == [1, -1, -4, -8]
    assert list(scanl(lambda x, y: x-y, [1, 2, 3, 4], 0)) == [0, 1, -1, -4, -8]



# Generated at 2022-06-23 17:36:10.924689
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0,1,3,6,10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a','ba','cba','dcba']



# Generated at 2022-06-23 17:36:18.312347
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x * x, a) == [1, 4, 9, 16, 25]
    assert MapList(lambda x: x * x, a)[3] == 16
    assert MapList(lambda x: x * x, a)[:3] == [1, 4, 9]
    assert enumerate(MapList(lambda i: a[i] * a[i] - a[i], Range(len(a)))) == [(0, 0), (1, 2), (4, 14), (9, 36), (16, 64)]



# Generated at 2022-06-23 17:36:21.561118
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert list(Range(1, 10, 4)[0:]) == [1, 5, 9]


# Generated at 2022-06-23 17:36:35.024389
# Unit test for function split_by
def test_split_by():
    assert list(split_by([])) == []
    assert list(split_by([1, 2, 3])) == [[1], [2], [3]]
    assert list(split_by([1, 2, 3], empty_segments=True)) == [[1], [2], [3]]
    assert list(split_by([1, 2, 3], empty_segments=True, criterion=lambda x: x % 2 == 0)) \
        == [[1], [3]]
    assert list(split_by([1], criterion=lambda x: x % 2 == 0)) == [[1]]
    assert list(split_by([1, 2, 3], criterion=lambda x: x % 2 == 0)) == [[1], [3]]

# Generated at 2022-06-23 17:36:40.621765
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[9] == 9
    assert lst[4:10:2] == [4, 6, 8]
    assert lst[9] == 9
    assert lst[8] == 8



# Generated at 2022-06-23 17:36:43.013216
# Unit test for function drop
def test_drop():
    for n in range(10):
        print(n)
        assert list(drop(5, range(10))) == list(range(5,10))


# Generated at 2022-06-23 17:36:44.514554
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    return



# Generated at 2022-06-23 17:36:50.641815
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    # Test when len is defined and when it's not
    lst = [1, 2, 3]
    def f(x): return x * x
    map_list = MapList(f, lst)
    assert len(lst) == len(map_list)
    map_list = MapList(f, LazyList(lst))
    assert len(lst) == len(map_list)



# Generated at 2022-06-23 17:36:57.176164
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(Range(5)) == list(range(5))
    assert list(Range(1, 5 + 1)) == list(range(1, 5 + 1))
    assert list(Range(1, 5 + 1, 2)) == list(range(1, 5 + 1, 2))
    # TODO: Test empty range


# Generated at 2022-06-23 17:36:58.239955
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10, 'Test failed'


# Generated at 2022-06-23 17:37:03.988448
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    a = LazyList(map(int, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))
    assert a[0] == 1
    assert a[1] == 2
    assert a[5] == 6
    assert isinstance(a, Sequence)
    assert isinstance(a, Iterable)
    a = LazyList(range(100, 200))
    assert a[:] == list(range(100, 200))
    list(a)
    assert a[:] == list(range(100, 200))



# Generated at 2022-06-23 17:37:12.471500
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(5, range(10))) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]

