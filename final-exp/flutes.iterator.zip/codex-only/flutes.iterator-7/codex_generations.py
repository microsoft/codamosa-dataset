

# Generated at 2022-06-23 17:27:24.497901
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    x = LazyList(range(1, 10**8))
    assert x[0] == 1
    assert x[8] == 9
    assert list(x) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    x = LazyList(range(1, 10**8))
    assert list(x[-1:]) == [9]
    assert list(x[:1]) == [1]
    assert list(x[2:4]) == [3, 4]
    assert list(x[4:-4]) == [5, 6]

# Generated at 2022-06-23 17:27:48.044482
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    length = len(MapList(lambda a: a, []))
    return length


# Generated at 2022-06-23 17:27:55.916193
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from io import StringIO
    import sys
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        import pytest
        pytest.main(['-s', '--tb=no', 'tests/test_lazylist.py'])
        output = out.getvalue().strip()
    finally:
        sys.stdout = saved_stdout
    print(output)



# Generated at 2022-06-23 17:28:07.111157
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(5)) == 5
    assert len(Range(1, 5)) == 4
    assert len(Range(1, 10, 2)) == 5
    assert len(Range(0, -5, -1)) == 5
    try:
        len(Range(0, 0, 0))
    except ValueError as e:
        assert str(e) == "Length of the range is not defined (step is 0)"
    else:
        raise AssertionError("The range should be undefined")
    try:
        len(Range(1, 1, 0))
    except ValueError as e:
        assert str(e) == "Length of the range is not defined (step is 0)"
    else:
        raise AssertionError("The range should be undefined")

# Generated at 2022-06-23 17:28:13.548051
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    with pytest.raises(TypeError):
        MapList(lambda x: x[0], [])[1]
    assert MapList(lambda x: x, [1, 2, 3])[1:2] == [2]


# Generated at 2022-06-23 17:28:19.786722
# Unit test for constructor of class MapList
def test_MapList():
    a = [0, 1, 2, 3, 4]
    assert MapList(lambda x: x % 2, a) == [0, 1, 0, 1, 0]
    assert MapList(lambda x: x % 2, a)[2] == 0
    assert len(MapList(lambda x: x % 2, a)) == 5
    assert MapList(lambda x: x % 2, a)[3:5] == [1, 0]
    assert MapList(lambda x: x, a) == a

# Type alias for a sorted list with insertion at an index, deletion at an index, or deletion of a value
SortedListInt = Union[int, slice, int]



# Generated at 2022-06-23 17:28:22.756574
# Unit test for method __len__ of class Range
def test_Range___len__():
    # case 1: basic test
    r = Range(2, 10, 2)
    assert len(r) == 4
    # end of test_Range___len__


# Generated at 2022-06-23 17:28:27.896210
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(10, range(5))) == []
    assert list(drop(0, range(5))) == list(range(5))
    assert list(drop(-1, range(5))) == list(range(5))



# Generated at 2022-06-23 17:28:38.545781
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    # Test with range(1, 10 + 1)
    r = Range(1, 10 + 1)
    for i, j in zip(r, range(1, 10 + 1)):
        assert (int(i) == int(j))
    # Test with range(1, 11, 2)
    r = Range(1, 11, 2)
    for i, j in zip(r, range(1, 11, 2)):
        assert (int(i) == int(j))
    # Test with range(10)
    r = Range(10)
    for i, j in zip(r, range(10)):
        assert (int(i) == int(j))
    # Test with range(5, 10)
    r = Range(5, 10)

# Generated at 2022-06-23 17:28:41.732199
# Unit test for function scanl
def test_scanl():
    def f(a, b):
        return a + b
    assert list(scanl(f, [])) == []
    assert list(scanl(f, [], 5)) == [5]
    assert list(scanl(f, [1,2,3])) == [1,1+2,1+2+3]

test_scanl()



# Generated at 2022-06-23 17:28:47.098808
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    """Test that __len is not available when the iterable is not exhausted. """
    lazy = LazyList(range(100))
    try:
        len(lazy)
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-23 17:28:52.522983
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x * x, list(range(10)))[:]) == [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]
    assert list(MapList(lambda x: x * x, list(range(10)))[3:5]) == [9, 16]

# Generated at 2022-06-23 17:28:55.242150
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    iterable = list(range(5))
    lst = LazyList(iterable)
    assert list(iter(lst)) == iterable


# Generated at 2022-06-23 17:29:02.814679
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert(len(MapList(lambda x: x, [])) == 0)
    assert(len(MapList(lambda x: x + 1, [1, 2, 3])) == 3)
    assert(len(MapList(lambda x: x, [])) == 0)
    assert(len(MapList(lambda x: x + 1, [1, 2, 3])) == 3)

# Generated at 2022-06-23 17:29:04.591696
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, range(1, 10))) == list(scanl(lambda x, y: x + y, range(1, 10), 0))


# Generated at 2022-06-23 17:29:06.669020
# Unit test for constructor of class LazyList
def test_LazyList():
    assert list(LazyList(range(100))) == list(range(100))


# Generated at 2022-06-23 17:29:09.269731
# Unit test for method __len__ of class Range
def test_Range___len__():
    result = len(Range(5, 10))
    assert 5 == result
    result = len(Range(10, 5, -1))
    assert 5 == result


# Generated at 2022-06-23 17:29:22.100973
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def func(x: int) -> int:
        return x * 2
    lst = MapList(func, [1, 2, 3])
    assert lst[0] == 2
    assert lst[1] == 4
    assert lst[2] == 6
    assert lst[-1] == 6
    assert lst[2:] == [6]
    assert lst[1:3] == [4, 6]
    assert lst[0:4:2] == [2, 6]
    assert lst[:3:2] == [2, 6]

    def func(x: int) -> str:
        return str(x * 3)
    lst = MapList(func, [1, 2, 3, 4])
    assert lst[:3] == ['3', '6', '9']
   

# Generated at 2022-06-23 17:29:29.724024
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:29:32.225720
# Unit test for constructor of class LazyList
def test_LazyList():
    assert LazyList([1,2,3]).list == [1,2,3]
    assert LazyList(range(10)).list == list(range(10))


# Generated at 2022-06-23 17:29:33.968758
# Unit test for function take
def test_take():
    assert list(take(5, range(1000))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 17:29:41.194572
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(0, 10)) == 10
    assert len(Range(0, 10, 2)) == 5
    assert len(Range(5, 10, 2)) == 3
    assert len(Range(-5, 10, 2)) == 8
    assert len(Range(-5, 10, -2)) == 0
    assert len(Range(5, -10, -2)) == 8
    assert len(Range(5, -5, -2)) == 5
from typing import Union, overload, TypeVar

from .composition import compose



T = TypeVar('T')


# Generated at 2022-06-23 17:29:44.174757
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    for ListType in [list, tuple, LazyList, MapList]:
        def helper(L):
            assert len(L) == 5
        helper(MapList(len, [
            [1, 2, 3],
            (),
            dict(),
            {'a': 0},
            'abcde',
        ]))
test_MapList___len__()


# Generated at 2022-06-23 17:29:52.170423
# Unit test for function split_by
def test_split_by():
    assert (list(split_by(range(10), criterion=lambda x: x % 3 == 0))
            == [[1, 2], [4, 5], [7, 8]])
    assert (list(split_by(" Split by: ", empty_segments=True, separator='.'))
            == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []])
    assert (list(split_by(" Split by: ", empty_segments=False, separator='.'))
            == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']])



# Generated at 2022-06-23 17:30:04.601834
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(0, 10)[0:10:1] == Range(0,10)[slice(0,10,1)]
    assert Range(0, 10)[10] == Range(0,10)[10:]
    assert Range(0, 10)[2] == Range(0,10)[2:3]
    assert Range(0, 10)[2:2:1] == Range(0,10)[slice(2,2,1)]
    assert Range(0, 10)[6] == Range(0,10)[6:7]
    assert Range(0, 10)[7] == Range(0,10)[7:8]
    assert Range(0, 10)[9] == Range(0,10)[9:10]
    assert Range(0, 10)[-10] == Range(0,10)[:10]

# Generated at 2022-06-23 17:30:09.786266
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from functools import reduce
    from operator import add
    lst = LazyList(range(100))
    it = lst.__iter__()
    for i in range(10):
        assert next(it) == i
    assert [x + 5 for x in it] == list(range(10, 100))
    assert reduce(add, lst) == sum(range(100))



# Generated at 2022-06-23 17:30:14.633030
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: False, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: True, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 10, range(10))) == []



# Generated at 2022-06-23 17:30:19.307507
# Unit test for function drop
def test_drop():
    assert list(drop(0, [1, 2, 3])) == [1, 2, 3]
    assert list(drop(1, [1, 2, 3])) == [2, 3]
    assert list(drop(2, [1, 2, 3])) == [3]
    assert list(drop(3, [1, 2, 3])) == []


# Generated at 2022-06-23 17:30:27.803131
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert list(Range(0)) == []
    assert list(Range(3)) == [0, 1, 2]
    assert list(Range(0, 3)) == [0, 1, 2]
    assert list(Range(-3, 3)) == [-3, -2, -1, 0, 1, 2]
    assert list(Range(-2, 3, -1)) == []
    assert list(Range(0, 10, 2)) == [0, 2, 4, 6, 8]
    assert list(Range(0, 10, -2)) == []
    assert list(Range(0, -10, -2)) == [0, -2, -4, -6, -8]

# Generated at 2022-06-23 17:30:30.443774
# Unit test for method __len__ of class Range
def test_Range___len__():
    for i in range(5,0,-1):
        assert len(Range(i, 0, -1)) == i
tests["Range"]["__len__"].append(test_Range___len__)


# Generated at 2022-06-23 17:30:39.691683
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1, range(10))) == [[x] for x in range(10)]
    assert list(chunk(10, range(10))) == [[x for x in range(10)]]

    with pytest.raises(ValueError):
        list(chunk(0, range(10)))
    with pytest.raises(ValueError):
        list(chunk(-1, range(10)))



# Generated at 2022-06-23 17:30:42.407287
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    @overload
    def test_MapList___iter__(func: Callable[[T], R], lst: Sequence[T]) -> Iterator[R]: ...





# Generated at 2022-06-23 17:30:55.259167
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    import pytest
    from hypothesis import given
    from .strategies import iterables
    iterable = iterables(int)
    test_subject = LazyList(iterable)
    with pytest.raises(TypeError, match="__len__ is not available before the iterable is depleted"):
        len(test_subject)


# Generated at 2022-06-23 17:30:58.326629
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it = LazyList(range(10))
    assert list(it) == list(range(10))
    assert list(it) == list(range(10))
    assert list(it.__iter__()) == list(range(10))
    assert list(it.__iter__()) == list(range(10))


# Generated at 2022-06-23 17:31:05.116262
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst=MapList(lambda x,y:x+y,[1,2],[3,4])
    assert lst[0]==4
    assert lst[1]==6
    assert lst.list[0]==1
    assert lst.list[1]==2
    assert lst.list[2]==3
    assert lst.list[3]==4


# Generated at 2022-06-23 17:31:07.724067
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    with pytest.raises(TypeError):
        len(LazyList([]))
    assert len(LazyList([1, 2, 3])) == 3



# Generated at 2022-06-23 17:31:13.327050
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:31:18.308490
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    for iterable in permutations(range(3)):
        lst = MapList(lambda x: x * 2, iterable)
        assert list(lst.__iter__()) == list(iterable)

# Generated at 2022-06-23 17:31:20.165164
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(2))) == 2
    

# Generated at 2022-06-23 17:31:25.813264
# Unit test for constructor of class MapList
def test_MapList():
    import unittest
    class TestMapList(unittest.TestCase):
        def test_constructor(self):
            self.assertTrue(MapList(lambda x: x, [1, 2]) == [1, 2])
            self.assertTrue(MapList(lambda x: x, [1, 2])[1:3] == [2])
    unittest.main()

# Generated at 2022-06-23 17:31:27.660609
# Unit test for function take
def test_take():
    a = list(range(50))
    print(list(take(5, a)))



# Generated at 2022-06-23 17:31:35.040081
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 10, range(10))) == []
    assert list(drop_until(lambda x: x > -1, range(10))) == list(range(10))



# Generated at 2022-06-23 17:31:41.793676
# Unit test for function chunk
def test_chunk():
    l_chunk = list(chunk(5, range(5)))
    assert l_chunk[0] == list(range(5))
    assert len(l_chunk) == 1

    l_chunk = list(chunk(2, range(5)))
    assert l_chunk[0] == [0, 1]
    assert l_chunk[1] == [2, 3]
    assert l_chunk[2] == [4]
    assert len(l_chunk) == 3



# Generated at 2022-06-23 17:31:51.118847
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        LazyList([0, 1, 2]).__len__()
    except TypeError as e:
        if str(e) == "__len__ is not available before the iterable is depleted":
            print('Passed test')
        else:
            print('Failed test')
    else:
        print('Failed test')
test_LazyList___len__()


# Generated at 2022-06-23 17:31:56.937411
# Unit test for method __len__ of class Range
def test_Range___len__():

    test_cases = [
        {'desc': 'zero-arg constructor', 'args': [()], 'expected': 0},
        {'desc': 'one-arg constructor', 'args': [([5],)], 'expected': 5},
        {'desc': 'two-arg constructor', 'args': [([0, 10],)], 'expected': 10},
        {'desc': 'three-arg constructor', 'args': [([0, 100, 10],)], 'expected': 10},
        {'desc': 'three-arg constructor with negative step', 'args': [([0, -10, -1],)], 'expected': 10},
    ]

    for test_case in test_cases:
        assert len(Range(*test_case['args'])) == test_case['expected']


# Generated at 2022-06-23 17:32:01.789014
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1, 2, 3])) == 3

    with pytest.raises(TypeError):
        len(LazyList(range(1000000)))



# Generated at 2022-06-23 17:32:06.026847
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    try:
        assert r[0] == 1
        assert r[2] == 3
        assert r[4] == 5
    except:
        import traceback
        traceback.print_exc()
        raise AssertionError

# Generated at 2022-06-23 17:32:10.414120
# Unit test for method __len__ of class Range
def test_Range___len__():
    print('Test Range.__len__()')

    r = Range(1, 10 + 1)
    print(r.__len__() == 10)
    print(Range(1, 10 + 1).__len__() == 10)

    r = Range(1, 11, 2)
    print(r.__len__() == 5)
    print(Range(1, 11, 2).__len__() == 5)

# Generated at 2022-06-23 17:32:16.503673
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:32:24.625097
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    print("Test of method __len__ of class MapList")
    lst = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert len(lst) == 5
    assert list(lst) == [1, 4, 9, 16, 25]
    lst = MapList(lambda x: f'{x}!', [1, 2, 3, 4, 5])
    assert len(lst) == 5
    assert list(lst) == ['1!', '2!', '3!', '4!', '5!']
test_MapList___len__()

# Generated at 2022-06-23 17:32:30.237416
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3])
    assert len(lst) == 3

    lst = LazyList(i for i in range(int(1e6)))
    try:
        len(lst)
    except Exception:
        pass
    assert len(lst) == int(1e6)



# Generated at 2022-06-23 17:32:35.976886
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    s = LazyList(range(10))
    assert s[1] == 1
    assert len(s) == 10
    assert s[-1] == 9
    test_list = list(range(100, 110))
    assert s[slice(100, 110)] == test_list
    assert len(s) == 110
    assert s[slice(120,130)] == []



# Generated at 2022-06-23 17:32:43.084757
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, [])) == []

    try:
        list(chunk(-1, range(10)))
        assert False
    except ValueError:
        pass


# Generated at 2022-06-23 17:32:52.016683
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from unittest.case import TestCase
    from hamcrest import assert_that, is_, calling, raises
    import operator
    from itertools import count

    class TestLazyList___getitem__(TestCase):
        def test_positive_index(self):
            self.assertThat(LazyList(range(10))[5], is_(5))

        def test_negative_index(self):
            self.assertThat(LazyList(range(10))[-5], is_(5))

        def test_slice_stop(self):
            self.assertThat(LazyList(range(10))[3:8], is_([3, 4, 5, 6, 7]))


# Generated at 2022-06-23 17:32:53.741923
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    iterable = (x for x in range(10))
    lst = LazyList(iterable)
    assert list(lst) == list(iterable)


# Generated at 2022-06-23 17:33:01.515158
# Unit test for function drop
def test_drop():
    n = int(input())
    s = iter([int(x) for x in input().split()])
    m = int(input())
    x,y = 0,0
    i = drop(n,s)
    x = next(i)
    y = next(i)
    print(f"element1: {x}")
    print(f"element2: {y}")
    print(f"sum: {x+y}")
#test_drop()



# Generated at 2022-06-23 17:33:05.715371
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x: x * x, [1, 2, 3, 4, 5])) == 5
    assert len(MapList(lambda x: x * x, Range(5))) == 5
    assert len(MapList(lambda x: x * x, [])) == 0


# Generated at 2022-06-23 17:33:15.572569
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    from .LazyList import LazyList
    from .Range import Range
    from .Sequence import Sequence
    from .take import take
    from .tail import tail
    range_instance = Range(1,11)
    range_iter = range_instance.__iter__()

# Generated at 2022-06-23 17:33:27.699837
# Unit test for function split_by
def test_split_by():
    test_list = [0, 1, 2, 3, 0, 4, 5]
    test_pred = lambda x: x == 0
    for i, chunk in enumerate(split_by(test_list, True, criterion=test_pred)):
        if i == 0:
            assert chunk == []
        elif i == 1:
            assert chunk == [1, 2, 3]
        elif i == 2:
            assert chunk == []
        elif i == 3:
            assert chunk == [4, 5]
        else:
            assert False

    for i, chunk in enumerate(split_by(test_list, criterion=test_pred)):
        if i == 0:
            assert chunk == [1, 2, 3]
        elif i == 1:
            assert chunk == [4, 5]

# Generated at 2022-06-23 17:33:30.660505
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(10, 20 + 1)) == 10
    assert len(Range(10, 20 + 1, 2)) == 5


# Generated at 2022-06-23 17:33:33.371699
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(5)
    r.val = -1
    assert list(r) == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 17:33:38.788339
# Unit test for constructor of class MapList
def test_MapList():
    assert MapList(lambda x: x * x, []) == []
    assert MapList(lambda x: x * x, [1]) == [1]
    assert MapList(lambda x: x * x, [1, 2]) == [1, 4]
    assert MapList(lambda x: x * x, [1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-23 17:33:43.568340
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    if not isinstance(Range([1, 2, 3])[1], int): raise Exception("class Range.__getitem__ is failed")
    if not isinstance(Range([1, 2, 3])[0:2], list): raise Exception("class Range.__getitem__ is failed")
    if Range([1, 2, 3])[0] != 1: raise Exception("class Range.__getitem__ is failed")
    if len(Range([1, 2, 3])[0:2]) != 2: raise Exception("class Range.__getitem__ is failed")
test_Range___getitem__()


# Generated at 2022-06-23 17:33:53.882639
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Test whether it works on a list of indices. (Python 3.2 or newer)
    p = pytest.importorskip("pathlib")
    listdir = p.Path("tests/testdir").glob("**/*")

# Generated at 2022-06-23 17:33:55.717407
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:34:01.910404
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(1, range(9))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8]]



# Generated at 2022-06-23 17:34:05.896272
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Test for TypeError
    try:
        len(LazyList(range(0)))
    except TypeError as e:
        assert type(e) is TypeError


# Generated at 2022-06-23 17:34:08.216888
# Unit test for function drop
def test_drop():
    it = drop(10, range(20))
    assert next(it) == 10


# Generated at 2022-06-23 17:34:15.914263
# Unit test for function chunk
def test_chunk():
    assert(list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]])
    assert(list(chunk(-3, range(10))) == [])
    assert(list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]])
    assert(list(chunk(3, [])) == [])



# Generated at 2022-06-23 17:34:19.730913
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']

test_scanr()

# Generated at 2022-06-23 17:34:29.101450
# Unit test for function scanr
def test_scanr():
    assert scanr(lambda x, y: x + y, [1, 2, 3, 4]) == [10, 9, 7, 4]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']
    assert scanr(lambda x, y: x + y, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]



# Generated at 2022-06-23 17:34:37.416133
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[1, 2], [], [4, 5], [], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator=' ')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    # scenario when empty iterable is passed
    assert list(split_by([])) == []
    assert list(split_by({})) == []
    assert list(split_by(list())) == []
    assert list

# Generated at 2022-06-23 17:34:41.071504
# Unit test for method __next__ of class Range
def test_Range___next__():
    # type: () -> None
    assert next(Range(0)) == 0
    assert next(Range(0, 1)) == 0
    assert next(Range(0, 5, 2)) == 0
    with pytest.raises(StopIteration):
        next(Range(0, 0))
    with pytest.raises(StopIteration):
        next(Range(0, 1, -1))


# Generated at 2022-06-23 17:34:44.716611
# Unit test for function drop
def test_drop():
    lst = list(range(10))
    it = drop(3, lst)
    assert next(it) == lst[3]



# Generated at 2022-06-23 17:34:55.954883
# Unit test for function chunk
def test_chunk():
    assert tuple(chunk(3, range(10))) == ((0, 1, 2), (3, 4, 5), (6, 7, 8), (9,))
    assert tuple(chunk(3, range(9))) == ((0, 1, 2), (3, 4, 5), (6, 7, 8))
    assert tuple(chunk(3, range(8))) == ((0, 1, 2), (3, 4, 5), (6, 7))
    assert tuple(chunk(3, range(7))) == ((0, 1, 2), (3, 4, 5), (6,))
    assert tuple(chunk(3, range(6))) == ((0, 1, 2), (3, 4, 5))
    assert tuple(chunk(3, range(5))) == ((0, 1, 2), (3, 4))


# Generated at 2022-06-23 17:35:01.136392
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:35:10.186333
# Unit test for constructor of class MapList
def test_MapList():
    def double(x):
        return 2*x
    lst = [1, 2, 3, 4, 5]
    assert(MapList(double, lst)[0] == 2)
    assert(MapList(double, lst)[4] == 10)
    assert(MapList(double, lst)[1:3] == [4, 6])
    assert(MapList(double, lst)[:3] == [2, 4, 6])
    assert(MapList(double, lst)[::2] == [2, 6, 10])



# Generated at 2022-06-23 17:35:15.502218
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4, 5], 0)) == [0, 1, 3, 6, 10, 15]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

test_scanl()



# Generated at 2022-06-23 17:35:24.885102
# Unit test for function take
def test_take():
  assert(list(take(3,range(10))) == [0,1,2])
  assert(list(take(0,range(10))) == [])
  #assert(list(take(-1,range(10))) == [])
  assert(list(take(11,range(10))) == [0,1,2,3,4,5,6,7,8,9])
  assert(list(take(100,range(10))) == [0,1,2,3,4,5,6,7,8,9])
  assert(list(take(0,range(0))) == [])


# Generated at 2022-06-23 17:35:32.905504
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(0)) == []
    assert list(Range(1)) == [0]
    assert list(Range(0, 1, 2)) == [0]
    assert list(Range(0, 2, 2)) == [0, 2]
    assert list(Range(0, 3, 2)) == [0, 2]
    assert list(Range(0, 4, 2)) == [0, 2]
    assert list(Range(0, 5, 2)) == [0, 2, 4]
    assert list(Range(7, 2, -1)) == [7, 6, 5, 4, 3]
    assert list(Range(2, 8, 2)) == [2, 4, 6]

    assert Range(0)[0:0] == []
    assert Range(0, 1)[:] == [0]

# Generated at 2022-06-23 17:35:39.616869
# Unit test for function take
def test_take():
    assert list(take(10, range(20))) == list(range(10))
    assert list(take(20, range(20))) == list(range(20))
    assert list(take(40, range(20))) == list(range(20))



# Generated at 2022-06-23 17:35:49.287521
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(1, 10))
    assert list(lst) == list(range(1, 10))
    assert list(lst) == list(range(1, 10))  # check idempotence

    lst = LazyList(range(10))
    assert next(lst) == 0
    assert list(lst) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert next(lst) == 1
    assert list(lst) == [2, 3, 4, 5, 6, 7, 8, 9]
    assert list(take(5, lst)) == [3, 4, 5, 6, 7]
    assert list(lst) == [6, 7, 8, 9]

    lst = LazyList([1, 2, 3])

# Generated at 2022-06-23 17:35:55.040754
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    assert list(iter(r)) == list(iter(r))
    r = Range(1, 10 + 1)
    assert list(iter(r)) == list(iter(r))
    r = Range(1, 11, 2)
    assert list(iter(r)) == list(iter(r))



# Generated at 2022-06-23 17:36:06.847426
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, range(10), 0)) == [45, 44, 42, 39, 35, 30, 24, 17, 9, 0]

# Generated at 2022-06-23 17:36:16.452008
# Unit test for method __len__ of class Range
def test_Range___len__():
    for (l,r,step) in [(a,b,c) for a in range(-10,10) for b in range(-10,10) for c in range(-10,10)]:
        range1 = Range(l,r,step)
        len1 = len(range1)
        range2 = range(l,r,step)
        len2 = len(range2)
        if len1 != len2:
            raise AssertionError('range1.__len__() != range2.__len__() for range1 = Range(l,r,step) and range2 = range(l,r,step)')


# Generated at 2022-06-23 17:36:22.807292
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:36:26.138904
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    ml = MapList(lambda x: 2 * x, [1, 2, 3])
    assert len(ml) == 3

# Generated at 2022-06-23 17:36:33.815057
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from operator import add
    xs = list(range(10000))
    s = xs[-1] * 2 + 1

    for i in range(5):
        lst = LazyList(xs)
        sum_lst1 = sum(lst)

        lst = LazyList(xs)
        sum_lst2 = scanl(add, lst)[-1]
        assert sum_lst1 == sum_lst2

        assert lst[-1] == s

# Generated at 2022-06-23 17:36:44.639253
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    class Test:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs


# Generated at 2022-06-23 17:36:55.106554
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from nose.tools import assert_equal
    from builtins import range

    l = [1, 2, 3, 4]
    m = MapList(lambda x: x + 1, l)
    assert_equal(m[0], 2)
    assert_equal(m[2], 4)
    assert_equal(m[-1], 5)
    assert_equal(m[:2], [2, 3])
    assert_equal(m[::2], [2, 4])
    assert_equal(m[1::2], [3, 5])

    m = MapList(lambda _: None, [])
    with pytest.raises(IndexError):
        m[0]
    with pytest.raises(IndexError):
        m[3]

    m = MapList(lambda i: l[i], range(3))

# Generated at 2022-06-23 17:37:04.258441
# Unit test for function split_by
def test_split_by():
    assert      list(split_by(range(0, 10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert      list(split_by(range(0, 10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[], [1, 2], [4, 5], [7, 8], []]
    assert      list(split_by(' Split by: ', separator='.', empty_segments=True)) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:37:09.475068
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    l = [1, 2, 3, 4, 5]
    assert list(MapList(lambda x: x * x, l)) == list(map(lambda x: x * x, l))


# Generated at 2022-06-23 17:37:11.723211
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    seq = range(100000)
    elems = LazyList(seq)
    assert list(elems.__iter__()) == list(seq)