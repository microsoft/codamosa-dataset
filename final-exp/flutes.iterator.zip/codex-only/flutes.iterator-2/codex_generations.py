

# Generated at 2022-06-23 17:27:25.079341
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    list = [1, 2, 3, 4]
    slice = [0, 1, 2, 3]
    assert list[:] == slice[:]
    assert list[:2] == slice[:2]
    assert list[0:2] == slice[0:2]
    assert list[1:2] == slice[1:2]
    assert list[-2:2] == slice[-2:2]
    assert list[:2:1] == slice[:2:1]
    assert list[1:3:1] == slice[1:3:1]
    assert list[:4:2] == slice[:4:2]
    assert list[0::1] == slice[0::1]
    assert list[::-1] == slice[::-1]
    assert list[2::-1] == slice

# Generated at 2022-06-23 17:27:29.587193
# Unit test for function drop
def test_drop():
    L = list(drop(2,range(10)))
    assert (L==[2,3,4,5,6,7,8,9]), "drop(2,range(10)) should be [2,3,4,5,6,7,8,9] but got %s"%L



# Generated at 2022-06-23 17:27:34.407422
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5,6,7,8,9]
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(10, range(10))) == []
    
test_drop()

# Generated at 2022-06-23 17:27:40.042313
# Unit test for constructor of class MapList
def test_MapList():
    a = [1,2,3,4,5]
    lst = MapList(lambda x: x*x, a)
    b = list(lst)
    assert(len(b) == len(a))
    for i in range(len(b)):
        assert(b[i] == a[i]*a[i])


# Generated at 2022-06-23 17:27:45.715309
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=lambda x: False)) == []
    assert list(split_by([], criterion=lambda x: True)) == [[]]
    assert list(split_by([True, False, True], criterion=lambda x: x)) == [[], [False], []]



# Generated at 2022-06-23 17:27:48.429620
# Unit test for method __len__ of class Range
def test_Range___len__():
    # Setup
    r = Range(0)
    expected_result = 0
    # Test
    actual_result = len(r)
    # Verify
    assert actual_result == expected_result


# Generated at 2022-06-23 17:27:56.087370
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    a = LazyList([1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert a[:4] == [1, 2, 3, 4]
    assert a[4:] == [5, 6, 7, 8, 9]
    assert a[3:3] == []
    assert a[1::2] == [2, 4, 6, 8]
    assert a[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1]


# Generated at 2022-06-23 17:28:02.861345
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    ml = MapList(lambda x: x, [1,2,3])
    assert ml[0] == 1
    assert ml[1] == 2
    assert ml[2] == 3
    assert ml[-1] == 3
    assert ml[0:1] == [1]


# Generated at 2022-06-23 17:28:09.680234
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    print(r[0], r[2], r[4])


if __name__ == '__main__':
    test_Range___next__()

# Generated at 2022-06-23 17:28:13.517605
# Unit test for function drop
def test_drop():
    assert next(drop(5,range(10))) == 5
    assert next(drop(10,range(10))) == None
    assert next(drop(0,range(10))) == 0


# Generated at 2022-06-23 17:28:19.247624
# Unit test for function scanr
def test_scanr():
    def rev_add(x, y):
        return y + x

    assert scanr(rev_add, [1, 2, 3]) == [1, 3, 6]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c']) == ['abc', 'bc', 'c']
    assert scanr(rev_add, [1, 2, 3], 0) == [1, 3, 6, 10]
    assert scanr(rev_add, [1, 2, 3], '0') == ['1', '21', '321', '0321']

test_scanr()



# Generated at 2022-06-23 17:28:22.933427
# Unit test for function drop
def test_drop():
    it = drop(2, range(10))
    assert next(it) == 2
    assert next(it) == 3
    for i in it:
        if i not in range(4, 10):
            assert False == True


# Generated at 2022-06-23 17:28:31.709616
# Unit test for constructor of class Range
def test_Range():
    # test [start, end)
    assert Range(1, 4)[0] == 1
    assert Range(1, 4)[1] == 2
    assert Range(1, 4)[2] == 3
    assert len(Range(1, 4)) == 3

    # test [start, end, step)
    assert Range(1, 4, 2)[0] == 1
    assert Range(1, 4, 2)[1] == 3
    assert len(Range(1, 4, 2)) == 2

    # test [start, end, step)
    assert Range(1, 5, 2)[0] == 1
    assert Range(1, 5, 2)[1] == 3
    assert len(Range(1, 5, 2)) == 2

    # test [start, end)
    assert Range(1, 4)[0] == 1

# Generated at 2022-06-23 17:28:40.401460
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len([]) == 0
    assert len([0]) == 1
    assert len(list(range(10))) == 10

    r = Range(1, 10 + 1)
    assert len(r) == 10
    assert len(r[-5:]) == 5
    assert len(r[:]) == 10

    r = Range(1, 10 + 1, 2)
    assert len(r) == 5
    assert len(r[-3:]) == 3
    assert len(r[:]) == 5



# Generated at 2022-06-23 17:28:48.700771
# Unit test for method __len__ of class Range
def test_Range___len__():
    lst = Range(1, 100)
    assert len(lst) == 99
    assert len(Range(-10, 10)) == 20
    assert len(Range(-10, 11)) == 21
    assert len(Range(-10, -1)) == 9
    assert len(Range(-10, -2)) == 9
    assert len(Range(1, 2)) == 1
    assert len(Range(1, 3)) == 2



# Generated at 2022-06-23 17:28:51.439629
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList(range(1000))
    assert hasattr(a.__len__, '__call__')
    assert len(a) == 1000

# Generated at 2022-06-23 17:28:54.165597
# Unit test for function drop
def test_drop():
    assert [6, 7, 8, 9] == list(drop(5, range(10)))
    assert [] == list(drop(5, range(4)))



# Generated at 2022-06-23 17:28:55.400627
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:29:08.213373
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    class Counter(Iterator[int]):
        def __init__(self, n: int):
            self.n = n

        def __iter__(self):
            return self

        def __next__(self):
            if self.n == 0:
                raise StopIteration
            self.n -= 1
            return self.n

        def next(self):
            return self.__next__()
    def my_function_1(x):
        return x + 1
    def my_function_2(x):
        return not x
    def my_function_3(x):
        return x + 1
    a = Counter(7)
    b = MapList(my_function_1, a)
    c = MapList(my_function_2, a)
    d = MapList(my_function_3, a)


# Generated at 2022-06-23 17:29:20.710909
# Unit test for function split_by
def test_split_by():
    assert list(split_by('Split by: ', criterion=lambda x: x == ' ')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by('Split by: ', criterion=lambda x: x == ' ')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by('Split by: ', criterion=lambda x: x == ' ')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by('Split by: ', criterion=lambda x: x == ' ')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-23 17:29:32.919373
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    res = Range(-5, 7, 2)[1:5:2]
    assert res == [-1, 1, 3]

    res = Range(-5, 7, 2)[:]
    assert res == [-5, -3, -1, 1, 3, 5]

    res = Range(-5, 7, 2)[2:2]
    assert res == []

    res = Range(-5, 7, 2)[0]
    assert res == -5

    res = Range(-5, 7, 2)[5]
    assert res == 3

    res = Range(-5, 7, 2)[-1]
    assert res == 5

    res = Range(-5, 7, 2)[4:3]
    assert res == []

    res = Range(-5, 7, 2)[4:4]
    assert res == []


# Generated at 2022-06-23 17:29:43.177731
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    """
    Test method __iter__ of class LazyList

    """

    import random

    class Counter:
        def __init__(self, current=0, step=1):
            self.current = current
            self.step = step

        def __iter__(self):
            return self

        def __next__(self):
            self.current += self.step
            return self.current

    def test_iter(lst):
        for x in lst:
            assert isinstance(x, int)

    lst = LazyList(Counter(0, 3))
    random.seed(0)
    for _ in range(10):
        test_iter(lst)
        test_iter(lst)
        test_iter(lst)

# Generated at 2022-06-23 17:29:49.234303
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    _func = globals()["func"]
    _lst = globals()["lst"]
    _obj = MapList(_func, _lst)
    _result = _obj.__iter__()
    print(list(_result))



# Generated at 2022-06-23 17:29:54.499456
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1, 2, 3, 4, 5])) == 5
    assert len(LazyList(range(100))) == 100
    assert len(LazyList(map(lambda x: x ** 2, range(100)))) == 100
    def gen():
        yield from range(100)
    assert len(LazyList(gen())) == 100
    assert len(LazyList(LazyList(range(100)))) == 100
    assert len(LazyList(chunk(2, LazyList(range(100))))) == 50



# Generated at 2022-06-23 17:30:02.629343
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    assert MapList(lambda x: x * x, a)[3] == 16
    assert MapList(lambda i: a[i] * b[i], Range(len(a)))[2] == 18
    assert MapList(lambda x: x * x, a)[:-1] == [1, 4, 9, 16, 25]



# Generated at 2022-06-23 17:30:07.417781
# Unit test for constructor of class Range
def test_Range():
    r = Range(1, 10, 2)
    assert type(r) is Range
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    assert type(r[4:]) == list
    assert r[4:] == [9, 7, 5, 3, 1]

# Generated at 2022-06-23 17:30:15.836452
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Set up
    l = Range(10)
    lslice = l[0:10]
    lslice_value = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    lvalue = l[6]
    lvalue_value = 6
    # Procedure
    # Assert
    assert lslice == lslice_value
    assert lvalue == lvalue_value


# Generated at 2022-06-23 17:30:24.606699
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [])) == []
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 10)) == [10, 11, 13, 16, 20]
    assert list(scanl(lambda s, x: s + x, [])) == []
    assert list(scanl(lambda s, x: s + x, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

# Generated at 2022-06-23 17:30:29.590614
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(2, [1, 2, 3])) == [1, 2]
    assert list(take(10, [1, 2, 3])) == [1, 2, 3]
    assert list(take(-2, [1, 2, 3])) == []



# Generated at 2022-06-23 17:30:33.392626
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3, 4, 5, 6, 7])
    assert lst[1] == 2
    assert lst[1:3] == [2, 3]
    assert lst[2] == 3
    with pytest.raises(StopIteration): lst[10]
    assert lst[10:] == [3, 4, 5, 6, 7]



# Generated at 2022-06-23 17:30:40.513244
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    import __main__
    import random
    import random
    random.seed(1)
    for _ in range(100):
        l = random.randrange(0, 1000)
        r = random.randrange(l, 1000)
        step = random.randrange(1, 10)
        result = list(Range(l, r, step))
        assert eval_in_main(result, __main__.__dict__, globals())



# Generated at 2022-06-23 17:30:49.763360
# Unit test for constructor of class Range
def test_Range():
    # Range(10)
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    # Range(1, 10 + 1)
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    # Range(1, 11, 2)
    r = Range(1, 11, 2)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9

if __name__ == '__main__':
    # test the range implementation
    test_Range()

# Generated at 2022-06-23 17:31:02.872946
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    with pytest.raises(TypeError) as err:
        len(LazyList([0, 1, 2]))
    assert isinstance(err.value, TypeError)
    assert str(err.value) == "__len__ is not available before the iterable is depleted"
    with pytest.raises(TypeError) as err:
        len(LazyList(range(5)))
    assert isinstance(err.value, TypeError)
    assert str(err.value) == "__len__ is not available before the iterable is depleted"

    assert LazyList([0, 1, 2])[0] == 0
    assert LazyList([0, 1, 2, 3, 4])[-1] == 4
    assert LazyList([0, 1, 2, 3, 4])[-2] == 3
    assert Lazy

# Generated at 2022-06-23 17:31:13.385032
# Unit test for function chunk
def test_chunk():
    test(chunk(0, range(10)), [])
    test(chunk(1, range(10)), [[x] for x in range(10)])
    test(chunk(10, range(1, 10)), [[1, 2, 3, 4, 5, 6, 7, 8, 9]])
    test(chunk(10, range(10)), [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]])
    test(chunk(10, range(11)), [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [10]])
    test(chunk(10, range(15)), [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [10, 11, 12, 13, 14]])



# Generated at 2022-06-23 17:31:25.450316
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    test_value_0 = MapList(lambda x : {x : [x, x]}, [1, 2, 3, 4, 5])
    expected_0 = [{1 : [1, 1]}, {2 : [2, 2]}, {3 : [3, 3]}, {4 : [4, 4]}, {5 : [5, 5]}]
    actual_0 = list(test_value_0)
    try:
        assert expected_0 == actual_0
    except AssertionError:
        print("Test #1 failed: Expected:", expected_0, ", Actual:", actual_0)
    try:
        test_value_0
    except NameError:
        pass
    else:
        del test_value_0
    try:
        expected_0
    except NameError:
        pass

# Generated at 2022-06-23 17:31:27.798425
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4]
    b = MapList(lambda x: x, a)
    assert a == b



# Generated at 2022-06-23 17:31:40.525759
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
  import random
  import bisect, numpy

  for _ in range(100):
    a = [random.randint(0, 100) for _ in range(100)]
    pos = a.index(min(a))
    assert bisect.bisect_left(MapList(lambda x: abs(x % 10 - 10), a), 0) == pos, 'Fail!'
    assert bisect.bisect_left(MapList(lambda i: a[i] * a[i], Range(len(a))), 10) == pos, 'Fail!'
    assert bisect.bisect_left(MapList(lambda i: a[i] * a[i], numpy.arange(len(a))), 10) == pos, 'Fail!'



# Generated at 2022-06-23 17:31:46.172788
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1, 2, 3, 4])) == 4
    assert len(LazyList(x for x in [1, 2, 3, 4])) == 4
test_LazyList___len__.__test__ = False  # Disable nose test collection



# Generated at 2022-06-23 17:31:49.660215
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(5)).__iter__()) == [0, 1, 2, 3, 4]
    assert list(LazyList(range(5)).__iter__()) == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 17:31:57.999049
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, range(2))) == [[0], [1]]
    assert list(chunk(2, range(2))) == [[0, 1]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(1, range(3))) == [[0], [1], [2]]
    assert list(chunk(2, range(3))) == [[0, 1], [2]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(4, range(3))) == [[0, 1, 2]]



# Generated at 2022-06-23 17:32:01.945578
# Unit test for function take
def test_take():
    assert [0, 1, 2, 3, 4] == [x for x in take(5, range(1000000))]

test_take()



# Generated at 2022-06-23 17:32:04.885453
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = range(10)
    assert type(r) is not Range
    r = Range(10)
    assert type(r) is Range
    assert type(iter(r)) is Range


# Generated at 2022-06-23 17:32:06.974336
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:32:08.965959
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1, 2, 3])) == 3
    assert len(LazyList(range(0))) == 0



# Generated at 2022-06-23 17:32:16.220380
# Unit test for constructor of class MapList
def test_MapList():
    import pytest

    def getTest(func: Callable[[T], R], lst: Sequence[T]):
        rst = MapList(func, lst)
        assert rst == [func(i) for i in lst]

    lst = [1, 2, 3, 4]
    func = lambda x: x * x
    getTest(func, lst)



# Generated at 2022-06-23 17:32:24.894167
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3])[0:1] == [1]
    assert MapList(lambda x: x * x, [1, 2, 3])[2:3] == [9]
    assert MapList(lambda x: x * x, [1, 2, 3])[1:3] == [4, 9]

# Generated at 2022-06-23 17:32:30.416821
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: x * 2, range(5))) == [0, 2, 4, 6, 8]
    assert MapList(lambda x: x * 2, range(5))[3] == 6
    assert MapList(lambda x: x * 2, range(5))[2:4] == [4, 6]


# Generated at 2022-06-23 17:32:31.966835
# Unit test for constructor of class LazyList
def test_LazyList():
    LazyList([1, 2, 3, 4, 5])



# Generated at 2022-06-23 17:32:41.955715
# Unit test for function take
def test_take():
    assert([*take(3, [1, 2, 3, 4, 5])] == [1, 2, 3])
    assert([*take(2, [1, 2, 3, 4, 5])] == [1, 2])
    assert([*take(6, [1, 2, 3, 4, 5])] == [1, 2, 3, 4, 5])
    assert([*take(0, [1, 2, 3, 4, 5])] == [])
    assert([*take(0, [])] == [])
    assert([*take(2, [])] == [])
    assert([*take(3, range(100, 104))] == [100, 101, 102])

test_take()



# Generated at 2022-06-23 17:32:51.198967
# Unit test for constructor of class LazyList
def test_LazyList():
    # Type hints
    lst: LazyList[int] = LazyList(range(10))
    lst = LazyList([i * i for i in range(10) if i % 3 == 1])
    lst = LazyList(iter(range(10)))

    # Access elements
    assert lst[:] == range(10)
    assert lst[0] == 0
    assert lst[0:3] == [0, 1, 2]
    assert lst[-2:] == [8, 9]

    # Iterate over elements
    assert list(lst) == list(range(10))
    lst = LazyList(range(100))
    assert list(lst[0:10]) == list(range(10))

# Generated at 2022-06-23 17:32:59.483508
# Unit test for method __len__ of class Range
def test_Range___len__():
    import numpy as np
    # See if method __len__ correctly calculate the lenght of the range
    r = Range(1, 11, 2)
    assert r.__len__() == 5
    assert len(r) == 5
    """
    Another test to see if method __len__ correctly calculate the lenght of the range
    """
    r = Range(1, 10 + 1)
    assert r.__len__() == 10
    assert len(r) == 10
    """
    Another test to see if method __len__ correctly calculate the lenght of the range
    """
    r = Range(10)
    assert r.__len__() == 10
    assert len(r) == 10



# Generated at 2022-06-23 17:33:08.625870
# Unit test for constructor of class MapList
def test_MapList():
    from hypothesis import given, strategies as st
    from operator import mul
    from itertools import count

    @given(st.integers(), st.lists(st.integers(min_value=0), min_size=0, unique=True))
    def check_map_list(s, arr):
        ml = MapList(lambda x: x * s, arr)
        assert len(ml) == len(arr)
        assert list(ml) == [x * s for x in arr]
        if len(arr) > 0:
            all(ml[i] == arr[i] * s for i in range(len(arr)))
            assert ml[:2] == list(map(lambda x: x * s, arr[:2]))

# Generated at 2022-06-23 17:33:16.601153
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']) ) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 's')) == ['s', 'sa', 'sba', 'scba', 'sdcba']
    
    
    
    



# Generated at 2022-06-23 17:33:26.321596
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert list(MapList(lambda x: x * x, [1, 2, 3, 4, 5])) == [1, 4, 9, 16, 25]
    assert list(MapList(lambda x: x * x, [1, 2, 3, 4, 5])[:]) == [1, 4, 9, 16, 25]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-1] == 25


# Generated at 2022-06-23 17:33:30.855896
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
test_scanl()



# Generated at 2022-06-23 17:33:38.663795
# Unit test for function drop_until
def test_drop_until():
    # None of the elements satisfy the predicate
    assert list(drop_until(lambda x: x > 5, range(5))) == []

    # One of the elements satisfies the predicate
    assert list(drop_until(lambda x: x > 5, range(5, 10))) == list(range(5, 10))

    # All of the elements satisfy the predicate
    assert list(drop_until(lambda x: x > -1, range(5))) == list(range(5))

    # The iterable is empty
    assert list(drop_until(lambda x: x > 5, [])) == []



# Generated at 2022-06-23 17:33:44.902812
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(0, 10)) == 10
    assert len(Range(0, 10, 3)) == 4
    assert len(Range(0, 11, 3)) == 4
    assert len(Range(0, 12, 3)) == 4
    assert len(Range(1, 11, 3)) == 4


# Generated at 2022-06-23 17:33:53.259573
# Unit test for function scanl
def test_scanl():

    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]

test_scanl()


# Generated at 2022-06-23 17:33:59.875113
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.mul, range(1, 5))) == [1, 2, 6, 24]
    assert list(scanl(operator.mul, range(1, 5), 10)) == [10, 10, 20, 60, 240]
    assert list(scanl(lambda x, y: x[0] + y, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:34:03.837766
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert MapList(lambda x: x, [1, 2, 3]).__len__() == 3
    assert MapList(lambda x: x, []).__len__() == 0
    assert MapList(lambda x: x, [1, 2, 3]).__len__() == len([1, 2, 3])
    assert MapList(lambda x: x, []).__len__() == len([])

# Generated at 2022-06-23 17:34:06.629209
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import doctest
    doctest.run_docstring_examples(LazyList.__iter__, globals(), verbose=True)



# Generated at 2022-06-23 17:34:08.627755
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0:2] == [0, 1]

# Generated at 2022-06-23 17:34:15.723336
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(4, [1, 2, 3, 4, 5])) == [[1, 2, 3, 4], [5]]
    assert list(chunk(0, [1])) == ValueError
    assert list(chunk(1, [])) == []


# Generated at 2022-06-23 17:34:18.590281
# Unit test for function drop
def test_drop():
    def f():
        yield from range(100)
    assert next(drop(10, f())) == 10
    assert next(drop(100, f())) == 100
    assert next(drop(200, f())) == Exception



# Generated at 2022-06-23 17:34:31.225981
# Unit test for constructor of class Range
def test_Range():
    assert Range(0, 10, 2) == Range(0, 10, 2)
    assert Range(0, 10, 2) != Range(0, 10, 1)
    assert Range(0, 10, 2) != Range(0, 10, 3)
    assert Range(0, 10, 2) != Range(0, 11, 3)
    assert Range(0, 10, 2) != Range(1, 10, 2)
    assert Range(0, 10, 2) != Range(0, 11, 3)
    assert Range(0, 10, 2) != Range(1, 11, 3)
    assert Range(0, 10, 2) != Range(1, 11, 4)
    assert Range(0, 10, 2) != Range(1, 12, 4)
    assert Range(0, 10, 2) != Range(1, 13, 4)

# Generated at 2022-06-23 17:34:36.491062
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]

# Generated at 2022-06-23 17:34:41.124655
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    """
    Test for the method __len__ of class LazyList
    """
    x = LazyList(range(10))
    try:
        len(x)
    except TypeError: pass
    else: print("TypeError expected")
    while 1:
        try:
            next(x.__iter__())
        except StopIteration:
            break
    assert len(x) == 10



# Generated at 2022-06-23 17:34:46.603023
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    l = [1, 2, 3, 4, 5]
    assert [x * 2 for x in l] == MapList(lambda x: x * 2, l)[:], "Test without slice"
    assert [x * 2 for x in l] == MapList(lambda x: x * 2, l)[0:], "Test without stop"
    assert [2 * x for x in l[1:4]] == MapList(lambda x: x * 2, l)[1:4], "Test with regular slice"
    assert [2 * x for x in l[:4]] == MapList(lambda x: x * 2, l)[:4], "Test without start"
    assert [2 * x for x in l[:-1]] == MapList(lambda x: x * 2, l)[:-1], "Test with negative stop"

# Generated at 2022-06-23 17:34:55.731881
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    a = LazyList(range(10))
    assert a[4] == 4
    assert a[8] == 8
    assert a[-2] == 8
    assert a[:5] == list(range(5))
    assert a[3:9] == list(range(3, 9))
    assert len(a) == 10
    b = LazyList(range(10))
    assert b[-1] == 9
    assert len(b) == 10
    c = LazyList(range(10))
    assert c[5] == 5
    assert c[:5] == list(range(5))
    assert len(c) == 10


# Generated at 2022-06-23 17:35:04.184515
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, [])) == []
    assert list(chunk(0, range(10))) == []
    assert list(chunk(-1, range(10))) == []
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]



# Generated at 2022-06-23 17:35:12.352123
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']
    assert scanr(operator.add, [1, 2, 3, 4], initial=0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], initial='') == ['abcd', 'bcd', 'cd', 'd', '']



# Generated at 2022-06-23 17:35:20.818863
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    # Initialize the list of items to test.
    items = range(10, 28)
    # Initialize the expected result.
    expected_result = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27]
    # Initialize the test object.
    obj = MapList(lambda x: x, items)
    # Create the iterator.
    iterator = iter(obj)
    # Iterate over the iterator.
    result = [item for item in iterator]
    # Check the result.
    assert result == expected_result

# Generated at 2022-06-23 17:35:24.594821
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    assert isinstance(Range(1, 2, 3).__iter__(), Iterator)
    assert isinstance(Range(1, 2).__iter__(), Iterator)
    assert isinstance(Range(1).__iter__(), Iterator)

# Generated at 2022-06-23 17:35:32.540753
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    if 'Range' not in globals():
        return
    ok = True

# Generated at 2022-06-23 17:35:33.960070
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert len(r) == 10



# Generated at 2022-06-23 17:35:39.022458
# Unit test for function split_by
def test_split_by():
    assert list(split_by(["a", "b", "", "c"], empty_segments=True, separator="")) == [["a", "b"], [], ["c"]]


# Generated at 2022-06-23 17:35:44.628364
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1,10)
    it = iter(r)
    assert type(it) is Range
    assert list(it) == [1,2,3,4,5,6,7,8,9]
    it = iter(r)
    assert list(it) == [1,2,3,4,5,6,7,8,9]



# Generated at 2022-06-23 17:35:48.928234
# Unit test for function drop_until
def test_drop_until():
    for i in range(10):
        assert list(drop_until(lambda x: x > i, range(10))) == range(i + 1, 10)
        assert list(drop_until(lambda x: x > i, range(i))) == []
    assert list(drop_until(lambda x: x > 100, range(10))) == []



# Generated at 2022-06-23 17:35:57.561139
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    def test_Range___iter__(a1: Any):
        ret: List[int] = []
        for a2 in a1:
            ret.append(a2)
        return ret
    setattr(Range.__iter__, '__annotations__', {})
    assert test_Range___iter__(Range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert test_Range___iter__(Range(1, 10 + 1)) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert test_Range___iter__(Range(1, 11, 2)) == [1, 3, 5, 7, 9]

# Generated at 2022-06-23 17:36:04.670743
# Unit test for constructor of class MapList
def test_MapList():
    lst = [2,1,5,9,9]
    x = MapList(lambda x : x ** 2, lst)
    assert (x[3]==9 ** 2)
    assert (x[-1]==x[-1]==x[4]==9 ** 2)
    assert ([2,1,5,81,81] == list(x))
    assert (list(lst) == [2,1,5,9,9])


# Generated at 2022-06-23 17:36:16.161069
# Unit test for function split_by

# Generated at 2022-06-23 17:36:26.249903
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import pytest
    import riptable as rt

    x = rt.arange(10)
    assert all(rt.LazyList(x)[i] == x[i] for i in rt.arange(10))

    x = rt.arange(10)
    assert all(rt.LazyList(x)[rt.arange(10)] == x[rt.arange(10)])

    x = rt.arange(10)
    assert all(rt.LazyList(x)[0:4] == x[0:4])



# Generated at 2022-06-23 17:36:29.102528
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    map_list = MapList(lambda x: x * x, [1, 2, 3])
    assert len(map_list) == 3


# Generated at 2022-06-23 17:36:33.639102
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: False, range(10))) == list(range(10))
    assert list(drop_until(lambda x: False, [])) == []



# Generated at 2022-06-23 17:36:36.239495
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(5))) == 5

# Generated at 2022-06-23 17:36:40.727732
# Unit test for constructor of class MapList
def test_MapList():
    actual = [1, 2, 3]
    lst = MapList(lambda x: x * 2, actual)
    for i, x in enumerate(lst):
        assert x == actual[i] * 2
    assert lst[1] == actual[1] * 2
    assert lst[1:2] == [actual[1] * 2]


# Generated at 2022-06-23 17:36:44.193734
# Unit test for method __len__ of class Range
def test_Range___len__():
    # arrange
    from builtins import range as _range

    a = list(range(10))
    b = Range(10)

    # act
    c = len(a)
    d = len(b)

    # assert
    assert c == d


# Generated at 2022-06-23 17:36:48.175759
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:36:53.503754
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    data = [1, 2, 3, 4, 5]
    mp_list = MapList(lambda x: x * x, data)

    assert mp_list[0] == 1
    assert mp_list[1] == 4
    assert mp_list[2] == 9

    assert mp_list[0:4] == [1, 4, 9, 16]
    assert mp_list[1:4:2] == [4, 16]
    
test_MapList___getitem__()



# Generated at 2022-06-23 17:37:05.008839
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(20))
    assert len(lst.list) == 0
    assert all(i == j for i, j in zip(lst, range(20)))
    assert len(lst) == 20
    assert all(i == j for i, j in zip(lst, range(20)))
    assert all(lst[i] == i for i in range(20))
    assert len(lst) == 20
    assert all(i == j for i, j in zip(lst, range(20)))
    assert lst[-1] == 19
    assert len(lst) == 20
    assert all(i == j for i, j in zip(lst, range(20)))
    assert lst[-1] == 19
    assert len(lst) == 20

# Generated at 2022-06-23 17:37:10.666191
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    for iterable, length in [
        ([], 0),
        ([1, 2, 3], 3),
        (range(10000), 10000)
    ]:
        lst = LazyList(iterable)
        assert len(lst) == length



# Generated at 2022-06-23 17:37:19.022838
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    import unittest
    import random
    class test_MapList___iter__TestCase(unittest.TestCase):
        def test_random(self):
            '''
            Randomly generate test cases.
            '''
            try:
                N = random.randint(1, 100)
                lst = list(range(N))
                func = lambda x: x + 1
                p = MapList(func, lst)
            except Exception:
                self.assertTrue(False)
    return test_MapList___iter__TestCase