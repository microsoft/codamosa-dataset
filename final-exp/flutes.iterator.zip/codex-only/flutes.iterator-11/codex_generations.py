

# Generated at 2022-06-23 17:27:24.245391
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    global class_MapList_instance_func_class_List_instance_lst_0
    class_MapList_instance_func_class_List_instance_lst_0 = MapList(int, [1, 2, 3])
    assert type(class_MapList_instance_func_class_List_instance_lst_0.__iter__()) == type(iter([]))
    assert list(class_MapList_instance_func_class_List_instance_lst_0.__iter__()) == [1, 2, 3]


# Generated at 2022-06-23 17:27:29.826522
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x >= 3, [1, 2, 3])) == [3]
    assert list(drop_until(lambda x: x >= 3, [1, 2, 4, 3])) == [4, 3]
    assert list(drop_until(lambda x: x >= 3, [1, 2])) == []



# Generated at 2022-06-23 17:27:32.539156
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3]
    map_list = MapList(lambda x: x * x, a)
    assert map_list[2] == 9
    assert map_list[0:1] == [1]


# Generated at 2022-06-23 17:27:45.833236
# Unit test for constructor of class Range

# Generated at 2022-06-23 17:27:46.836357
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-23 17:27:48.755194
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    for i in MapList(lambda x: x * x, [1, 2, 3]):
        print (i)



# Generated at 2022-06-23 17:27:53.153000
# Unit test for method __len__ of class Range
def test_Range___len__():
    r = Range(10)
    assert len(r) == 10
    r = Range(1, 10 + 1)
    assert len(r) == 10
    r = Range(1, 11, 2)
    assert len(r) == 5



# Generated at 2022-06-23 17:27:59.710245
# Unit test for function scanr
def test_scanr():
    def test_impl(func, list_, init):
        it = scanr(func, list_, init)
        assert list(it) == scanr(func, list_, init)
        assert list(it) == scanr(func, list_, init)  # check that it can be consumed twice

    test_impl(operator.add, [1, 2, 3], 0)
    test_impl(operator.add, [1, 2, 3, 4], 0)
    test_impl(operator.add, [1, 2, 3], 100)
    test_impl(operator.add, [1, 2, 3, 4], 100)
    test_impl(lambda a, b: a * b, [1, 2, 3, 4], 1)

# Generated at 2022-06-23 17:28:02.693115
# Unit test for function drop
def test_drop():
    it = list(range(10))
    assert take(3, drop(5, it)) == [5, 6, 7]
    assert take(3, drop(20, it)) == []



# Generated at 2022-06-23 17:28:03.661993
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = range(1000)
    assert len(MapList(lambda x: x * x, lst)) == 1000


# Generated at 2022-06-23 17:28:06.771025
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    dummy_iterable = range(10)
    dummy_iter = iter(dummy_iterable)
    dummy_iterable_iterator = dummy_iter.__iter__()
    # Make sure that the method we are testing has been called
    assert dummy_iterable_iterator is not None


# Generated at 2022-06-23 17:28:16.115684
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(1, range(0))) == []

# Generated at 2022-06-23 17:28:19.597191
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(0))) == []
    assert list(take(0, range(1))) == []
    assert list(take(0, range(0))) == []
    

# Generated at 2022-06-23 17:28:24.013712
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3])
    try:
        len(lst)
        assert False, "__len__ should raise TypeError"
    except TypeError:
        pass
    lst[100]
    len(lst) == 101


# Generated at 2022-06-23 17:28:31.661839
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'x')) == ['x', 'xa', 'xab', 'xabc', 'xabcd']
    try:
        scanl(operator.add, [1, 2, 3, 4], 0, 1)
        assert False
    except ValueError:
        pass



# Generated at 2022-06-23 17:28:38.010184
# Unit test for constructor of class Range
def test_Range():
    assert list(Range(10)) == [i for i in range(10)]
    assert list(Range(1, 10 + 1)) == [i for i in range(1, 10 + 1)]
    assert list(Range(1, 11, 2)) == [i for i in range(1, 11, 2)]



# Generated at 2022-06-23 17:28:46.686056
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1,10,2)
    for i in range(1,10,2):
        assert r[int(i/2)] == i
    for i in range(0,10,2):
        assert r[int(-i/2)] == (i+1)
r = Range(1,10,2)
assert r[int(1/2)] == 1
assert r[int(3/2)] == 3
assert r[int(5/2)] == 5
assert r[int(7/2)] == 7
assert r[int(9/2)] == 9
assert r[int(0/2)] == 1
assert r[int(-1/2)] == 2
assert r[int(-3/2)] == 4
assert r[int(-5/2)] == 6
assert r[int(-7/2)] == 8


# Generated at 2022-06-23 17:28:49.479498
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    results = []
    for i in LazyList(range(10)):
        results.append(i)
    return results



# Generated at 2022-06-23 17:28:50.890045
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    import pytest
    lst = LazyList(range(2))
    with pytest.raises(TypeError):
        len(lst)

# Generated at 2022-06-23 17:28:55.492439
# Unit test for function take
def test_take():
    assert list(take(0, range(100))) == []
    assert list(take(5, range(100))) == [0, 1, 2, 3, 4]
    assert list(take(10, "abcdefg")) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']

test_take()



# Generated at 2022-06-23 17:29:05.500141
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    a = Range(10)
    b = Range(1, 10 + 1)
    c = Range(1, 11, 2)
    print(list(a))
    print(list(b))
    print(list(c))
    assert list(a) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(b) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(c) == [1, 3, 5, 7, 9]

# Generated at 2022-06-23 17:29:10.484298
# Unit test for constructor of class Range
def test_Range():
    assert Range(1, 4).__init__(1, 4) == [1, 2, 3]
    assert Range(1, 4).__init__(1, 4, 2) == [1, 3]
    assert Range(4).__init__(4) == [0, 1, 2, 3]
    assert Range(4).__init__(4) == list(range(4))



# Generated at 2022-06-23 17:29:22.703481
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    # Method to test: __iter__
    ##############################################################################################################
    import operator
    from collections import defaultdict
    from typing import DefaultDict, Iterable, Iterator, Sequence, Tuple, TypeVar

    T = TypeVar('T')
    J = TypeVar('J')

    # (Tested function, expected result, arguments)

# Generated at 2022-06-23 17:29:29.838045
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']

test_scanr()



# Generated at 2022-06-23 17:29:31.896052
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(3))
    assert list(lst) == [0, 1, 2]



# Generated at 2022-06-23 17:29:37.550690
# Unit test for constructor of class MapList
def test_MapList():
    a = MapList(lambda x: 2 * x, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert a[0] == 2
    assert a[1] == 4
    assert a[2] == 6
    assert a[5] == 12
    assert a[9] == 20
    assert len(a) == 10
    assert list(a) == [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]

# Generated at 2022-06-23 17:29:42.520315
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    import pytest
    from .features import feature_import_module_not_in_all_cases
    if feature_import_module_not_in_all_cases:
        import random
    for n in range(100):
        n = n + 1
        if feature_import_module_not_in_all_cases:
            l = random.sample(range(100), n)
        else:
            l = list(range(n))
        assert len(MapList(lambda x: x, l)) == n



# Generated at 2022-06-23 17:29:53.043564
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(3)
    assert(r[0] == 0)
    assert(r[1] == 1)
    assert(r[2] == 2)
    with raises(IndexError):
        r[3]

    r = Range(1, 5, 2)
    assert(r[0] == 1)
    assert(r[1] == 3)
    with raises(IndexError):
        r[2]

    r = Range(1, 10, 2)
    assert(r[-1] == 9)
    assert(r[0] == 1)
    assert(r[1] == 3)
    assert(r[2] == 5)
    assert(r[3] == 7)
    assert(r[4] == 9)
    with raises(IndexError):
        r[5]


# Generated at 2022-06-23 17:29:59.936637
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    l = list(range(10))
    r = Range(10)
    for i in range(10):
        assert l[i] == r[i]
        assert l[-i] == r[-i]
    for i in range(10):
        assert l[i:i + 3] == r[i:i + 3]
        assert l[-i:i] == r[-i:i]

# Generated at 2022-06-23 17:30:10.483243
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import itertools

    # test __getitem__(int)
    lst = LazyList(range(5))
    assert lst[3] == 3
    assert lst[-1] == 4
    # test when the iterable runs out
    lst = LazyList(itertools.repeat(1))
    assert lst[0] == 1
    assert lst[1] == 1
    assert lst[2] == 1
    with pytest.raises(IndexError):
        lst[3]
    # test when the iterable is empty
    lst = LazyList([])
    with pytest.raises(IndexError):
        lst[0]

    # test __getitem__(slice)
    lst = LazyList(range(5))

# Generated at 2022-06-23 17:30:15.879267
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 'c', 'aabccddeeff')) == ['c', 'c', 'd', 'd', 'e', 'e', 'f', 'f']



# Generated at 2022-06-23 17:30:19.235485
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    #case0:
    #  return: length of this[int]
    test_MapList = MapList(lambda x: x * x, [1, 2, 3, 4, 5]);
    assert test_MapList.__len__() == 5;
    #case1:
    #  return: length of this[slice]
    lst = [1, 2, 3, 4, 5];
    test_MapList = MapList(lambda x: x * x, lst);
    test_MapList_slice = test_MapList[:5];
    assert len(test_MapList_slice) == 5;


# Generated at 2022-06-23 17:30:21.179582
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
test_LazyList___len__()



# Generated at 2022-06-23 17:30:24.142776
# Unit test for constructor of class MapList
def test_MapList():
    from random import randint
    a = [randint(1, 10) for i in range(10)]
    a = sorted(a)
    print(a)
    b = [None for i in range(10)]
    for i in range(1, 10):
        b[i] = a[i] * a[i - 1]
    print(b)
    c = MapList(lambda x: a[x] * a[x - 1], Range(1, 10))
    print(c)
    assert b == c


# Generated at 2022-06-23 17:30:32.336889
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], empty_segments=True)) == [[]]
    assert list(split_by([], empty_segments=False)) == []
    assert list(split_by([1, 2, 3], empty_segments=True)) == [[1, 2, 3]]
    assert list(split_by([1, 2, 3], empty_segments=False)) == [[1, 2, 3]]
    assert list(split_by([1, 2, 3], criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], []]
    assert list(split_by([1, 2, 3], criterion=lambda x: x % 3 == 0, empty_segments=False)) == [[1, 2], [], []]

# Generated at 2022-06-23 17:30:37.461279
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():    
    l = LazyList(range(10))
    assert isinstance(l[0], int)
    assert isinstance(l[-1], int)
    assert isinstance(l[:], list)
    assert isinstance(l[::-1], list)



# Generated at 2022-06-23 17:30:39.902101
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert li

# Generated at 2022-06-23 17:30:44.341806
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:30:49.028173
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-23 17:30:58.691207
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import operator
    import random
    import sys

    # test __getitem__ with integer index
    lazy_list = LazyList(range(1000000))
    assert len(lazy_list.list) == 0  # pylint: disable=no-member
    assert lazy_list[0] == 0
    assert len(lazy_list.list) == 1  # pylint: disable=no-member
    assert lazy_list[10] == 10
    assert len(lazy_list.list) == 11  # pylint: disable=no-member
    assert lazy_list[-1] == 999999
    assert len(lazy_list.list) == 1000000  # pylint: disable=no-member
    assert lazy_list[-1] == 999999

# Generated at 2022-06-23 17:31:06.751571
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert (Range(10)[0] == 0)
    assert (Range(10)[5] == 5)
    assert (Range(10)[-1] == 9)
    assert (Range(10)[-5] == 5)
    assert (Range(10, 11)[0] == 10)
    assert (Range(10, 11)[-1] == 10)
    assert (Range(10, 11, 2)[2] == 16)
    assert (Range(10, 11, 2)[-1] == 10)
    assert (Range(10, 11, -2)[2] == -16)
    assert (Range(10, 11, -2)[-1] == 10)



# Generated at 2022-06-23 17:31:09.985368
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
   pass # TODO


# Generated at 2022-06-23 17:31:12.155731
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList(range(10))
    a = list(l)
    b = list(l)
    assert a == b

# Generated at 2022-06-23 17:31:17.375618
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(0, 10)) == 10
    assert len(Range(5, 10)) == 5
    assert len(Range(0, 10, 2)) == 5
    assert len(Range(5, 10, 2)) == 3



# Generated at 2022-06-23 17:31:27.423438
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['abcdz', 'bcde', 'cdz', 'de', 'z']
    assert list(scanr(lambda a, b: a - b, [1, 2, 3, 4, 5], 0)) == [3, 2, -4, -7, -11, -16]

# Generated at 2022-06-23 17:31:30.208803
# Unit test for method __len__ of class Range
def test_Range___len__():
    # Test for various cases of r.__len__()
    pass

# Generated at 2022-06-23 17:31:41.717919
# Unit test for constructor of class Range
def test_Range():
    # testing Range(stop)
    r = Range(5)
    assert len(r) == 5
    assert list(r) == [0, 1, 2, 3, 4]
    assert r[2] == 2
    assert r[-1] == 4
    assert r[2:4] == [2, 3]
    with pytest.raises(TypeError):
        len(r)
    # testing Range(start, stop)
    r = Range(3,8)
    assert len(r) == 5
    assert list(r) == [3, 4, 5, 6, 7]
    assert r[2] == 5
    assert r[-1] == 7
    assert r[2:4] == [5, 6]
    # testing Range(start, stop, step)

# Generated at 2022-06-23 17:31:47.344054
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    print(r[0], r[2], r[4])


# Generated at 2022-06-23 17:31:54.905886
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]



# Generated at 2022-06-23 17:32:05.010042
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 0, [1, 2, -1, 4, -5])) == [1, 2, -1, 4, -5]
    assert list(drop_until(lambda x: x > 0, [1, 2, 0, 4, -5])) == [1, 2, 0, 4, -5]
    assert list(drop_until(lambda x: x > 0, [1, 2, 0, 0, -5])) == [1, 2, 0, 0, -5]
    assert list(drop_until(lambda x: x > 0, [1, 2, 0, -1, -5])) == [1, 2, 0, -1, -5]

# Generated at 2022-06-23 17:32:07.109352
# Unit test for constructor of class LazyList
def test_LazyList():
    size = 10000
    x = sum(LazyList(range(size)))
    assert(x == (size-1)*size/2)



# Generated at 2022-06-23 17:32:11.500980
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    x = LazyList(range(1000))
    assert sum(x) == (0 + 999) * 999 / 2
    # Unlike other sequences, repeated iteration is supported
    assert sum(x) == (0 + 999) * 999 / 2



# Generated at 2022-06-23 17:32:18.532439
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:32:23.691864
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    seq = MapList(lambda x: x * x, a)
    assert seq[1] == 2 * 2
    assert seq[2:5] == [3 * 3, 4 * 4, 5 * 5]
    assert list(seq) == [1 * 1, 2 * 2, 3 * 3, 4 * 4, 5 * 5]

# Generated at 2022-06-23 17:32:35.779222
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    x = LazyList(iter([1, 2, 3]))
    assert x[0] == 1
    x = LazyList(iter([1, 2, 3]))
    assert x[-1] == 3
    x = LazyList(iter([1, 2, 3]))
    assert x[1] == 2
    assert x[100] == 3
    assert x[0:100] == [1, 2, 3]
    x = LazyList(iter([1, 2, 3]))
    assert [e for e in x] == [1, 2, 3]
    assert list(x) == [1, 2, 3]
    x = LazyList(iter([1, 2, 3]))
    assert list(x)[1] == 2
    x = LazyList(iter([1, 2, 3]))

# Generated at 2022-06-23 17:32:40.161975
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    assert len(MapList(lambda x:x, [])) == 0
    assert len(MapList(lambda x:x, [1])) == 1
    assert len(MapList(lambda x:x, [1, 2, 3])) == 3

# Generated at 2022-06-23 17:32:42.810977
# Unit test for method __next__ of class Range
def test_Range___next__():
    input_data = [Range(100), Range(0, 100), Range(1, 10, 2), Range(0, 10, 2), Range(10, 0, -2),
                  Range(10, -10, -2)]
    for r in input_data:
        it = iter(r)
        for i in it:
            assert i == next(it)



# Generated at 2022-06-23 17:32:51.814212
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    """
    Test method ``__getitem__`` of class LazyList.
    """
    iterable = range(1000)
    lst1 = LazyList(iterable)
    assert isinstance(lst1, LazyList)
    assert lst1[:5] == [0, 1, 2, 3, 4]
    assert lst1[:5] == [0, 1, 2, 3, 4]  # list should not be accessed twice
    assert lst1[-5:] == [995, 996, 997, 998, 999]
    assert lst1[12] == 12
    assert lst1[10:12] == [10, 11]
    assert lst1[-1:] == [999]
    assert lst1[-2:] == [998, 999]

# Generated at 2022-06-23 17:32:54.771353
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    assert MapList(lambda x: x * x, a) == [1, 4, 9, 16, 25]
    assert MapList(lambda i: a[i] * b[i], Range(len(a))) == [2, 6, 12, 20, 30]



# Generated at 2022-06-23 17:32:55.196798
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    pass

# Generated at 2022-06-23 17:33:05.759780
# Unit test for function drop_until
def test_drop_until():
    def _inner_test_drop_until(pred_fn, iterable, expected):
        assert list(drop_until(pred_fn, iterable)) == expected
    _inner_test_drop_until(lambda x: True, [], [])
    _inner_test_drop_until(lambda x: True, [1, 2, 3], [1, 2, 3])
    _inner_test_drop_until(lambda x: x > 2, [1, 2, 3], [3])
    _inner_test_drop_until(lambda x: x > 5, [1, 2, 3, 4, 5], [])
    _inner_test_drop_until(lambda x: x <= 2, [1, 2, 3, 4, 5], [3, 4, 5])



# Generated at 2022-06-23 17:33:17.276064
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # Iteration
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    lst = LazyList(range(10))
    assert list(lst)[:5] == list(range(5))
    assert list(lst)[5:] == list(range(5, 10))
    assert list(lst) == list(range(10))
    # Indexing and indexing with slicing
    lst = LazyList(range(10))
    assert list(lst)[:5] == list(range(5))
    assert list(lst)[5:] == list(range(5, 10))

# Generated at 2022-06-23 17:33:27.659203
# Unit test for constructor of class Range
def test_Range():
    r1 = Range(10)
    r1_list = [i for i in r1]
    assert r1_list == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] 

    r2 = Range(1, 10 + 1)
    r2_list = [i for i in r2]
    assert r2_list == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    r3 = Range(1, 11, 2)
    r3_list = [i for i in r3]
    assert r3_list == [1, 3, 5, 7, 9]



# Generated at 2022-06-23 17:33:36.715667
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    fail_list = [
        ([], 0),
        ([False, True], 2),
        (["a", "b", "c"], 3),
        ([5, 5.5, 6.5], 3),
        ([(9), [10], {11}], 3)
    ]
    for i in range(len(fail_list)):
        exp_len = len(fail_list[i][0])
        assert len(MapList((lambda x: x), fail_list[i][0])) == exp_len
        

# Generated at 2022-06-23 17:33:45.055140
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(1, 10)
    assert all(x == y for x, y in zip(r, range(1, 10)))
    r = Range(1, 10, 2)
    assert all(x == y for x, y in zip(r, range(1, 10, 2)))
    assert all(x == y for x, y in zip(Range(-9, 9), range(-9, 9)))
    assert all(x == y for x, y in zip(Range(-9, 9, 2), range(-9, 9, 2)))



# Generated at 2022-06-23 17:33:47.734829
# Unit test for function chunk
def test_chunk():
    # TODO: Implement full unit tests for this function
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]



# Generated at 2022-06-23 17:33:55.381111
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(10))
    assert l.__getitem__(0) == 0
    assert l.__getitem__(1) == 1
    assert l.__getitem__(2) == 2
    assert l.__getitem__(slice(0, 2)) == [0, 1]
    assert l.__getitem__(slice(2, 3)) == [2]
    assert l.__getitem__(slice(2, 4)) == [2, 3]
    assert l.__getitem__(slice(3, 4)) == [3]



# Generated at 2022-06-23 17:33:57.584848
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-23 17:34:01.054573
# Unit test for method __next__ of class Range
def test_Range___next__():
    x = Range(1, 10)
    assert_equal(next(x), 1)
    assert_equal(next(x), 2)
    for i in range(8):
        next(x)
    assert_raises(StopIteration, next, x)



# Generated at 2022-06-23 17:34:01.691699
# Unit test for method __len__ of class MapList
def test_MapList___len__():return True

# Generated at 2022-06-23 17:34:12.753347
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(100)) == 100
    range1 = Range(10)
    assert len(range1) == 10
    assert range1[-1] == 9
    assert range1[1:3] == [1, 2]
    assert range1[1:] == range1[1:]
    range1 = Range(0, 100)
    assert len(range1) == 100
    assert range1[-1] == 99
    assert range1[1:3] == [1, 2]
    assert range1[1:] == range1[1:]
    range1 = Range(0, 100, 10)
    assert len(range1) == 10
    assert range1[-1] == 90
    assert range1[1:3] == [10, 20]
    assert range1[1:] == range1[1:]
    range

# Generated at 2022-06-23 17:34:16.431439
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print("Testing Range.__getitem__...")
    a = Range(0, 100, 2)
    for i in range(0, 100, 2):
        assert a[i // 2] == i
assert test_Range___getitem__()
# Unit test

# Generated at 2022-06-23 17:34:18.318072
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    Range()
    Range(436)
    Range(436, 439+1)
    Range(436, 439+1, 3)


# Generated at 2022-06-23 17:34:22.760782
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3, 4, 5, 6, 7, 8, 9])
    for i in range(3):
        assert lst[i] == i + 1
        assert len(lst.list) == i + 1
    assert lst[:] == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert len(lst) == 9
    assert lst[0:3] == [1, 2, 3]
    assert len(lst.list) == 3



# Generated at 2022-06-23 17:34:29.630085
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    assert list(r) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    r = Range(5, 10)
    assert list(r) == [5, 6, 7, 8, 9]
    r = Range(1, 10, 2)
    assert list(r) == [1, 3, 5, 7, 9]


# Generated at 2022-06-23 17:34:37.358425
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(operator.add, [1, 2, 3, 4])) == [10, 9, 7, 4, 1]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    assert list(scanr(operator.add, [])) == []

test_scanr()



# Generated at 2022-06-23 17:34:43.679302
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[4:6] == [4, 5]
    assert r[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert r[:3] == [0, 1, 2]
    assert r[0:9:2] == [0, 2, 4, 6, 8]
    assert r[1:9:2] == [1, 3, 5, 7]
    assert r[5:5] == []
    assert r[-3:-3] == []
    assert r[-3:-5] == []

    r = Range(1, 11, 3)

# Generated at 2022-06-23 17:34:50.621797
# Unit test for function scanl
def test_scanl():
    t1 = [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == t1
    assert list(scanl(operator.add, [1, 2, 3, 4])) == t1
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-23 17:34:53.939802
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = MapList(lambda x: x * x, range(10))
    assert len(lst) == 10

# Generated at 2022-06-23 17:35:02.186720
# Unit test for function drop_until
def test_drop_until():
    from .function import identity
    from .iterable import zip
    from .testing import assert_equal

    arr = ["first", "second", "third", "fourth", "fifth"]
    f = drop_until(lambda s: s.startswith("f"), arr)
    assert_equal(f, zip(arr, ["first", "fourth", "fifth"]))
    assert_equal(f, zip(arr, ["first", "fourth", "fifth"]))
    f = drop_until(identity, [])
    assert_equal(f, [])



# Generated at 2022-06-23 17:35:06.113308
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(0, 10 + 1)
    
    autogen_expected = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    autogen_given = []
    for x in r:
        autogen_given.append(x)
    assert autogen_expected == autogen_given



# Generated at 2022-06-23 17:35:08.006128
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for i in Range(1, 10, 1):
        print(i)



# Generated at 2022-06-23 17:35:11.790708
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(20, range(10))) == []



# Generated at 2022-06-23 17:35:14.082891
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    mpl = MapList(lambda x: x ** 2, list(range(10)))
    for i, x in enumerate(mpl):
        assert x == i ** 2

# Generated at 2022-06-23 17:35:19.945303
# Unit test for function drop_until
def test_drop_until():
    from typing import cast
    from queue import Queue
    from threading import Thread
    from time import time, sleep
    from random import random

    N = 20
    T = 10

    q = Queue()

    def putter(q: Queue[float]):
        for i in range(N):
            sleep(random())
            q.put(time())
            sleep(random())
            q.put(time())

    def getter(q: Queue[float]):
        def is_valid(t: float) -> bool:
            t = cast(float, t)
            return t > T

        queue = drop_until(is_valid, q)
        for item in queue:
            t = cast(float, item)
            assert t > T
            print(t)


# Generated at 2022-06-23 17:35:23.092526
# Unit test for function scanr
def test_scanr():
    assert scanr(operator.add, [1, 2, 3, 4], 0) == [10, 9, 7, 4, 0]
    assert scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:35:31.591097
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    with pytest.raises(ValueError):
        assert list(split_by(" Split by: ", empty_segments=True, criterion=lambda x: x % 3 == 0,separator='.'))



# Generated at 2022-06-23 17:35:34.587307
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(1000))
    assert len(lst) == 1000
    assert lst[:10] == list(range(10))
    assert lst[100] == 100



# Generated at 2022-06-23 17:35:39.181558
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3], 0)) == [0, 1, 3, 6]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c'], 'd')) == list('dbcba')



# Generated at 2022-06-23 17:35:40.084567
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    pass

# Generated at 2022-06-23 17:35:43.832962
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    for n in range(0, 30):
        r = Range(n)
        for i, x in enumerate(r):
            assert x == i
test_Range___iter__()


# Generated at 2022-06-23 17:35:47.270504
# Unit test for constructor of class LazyList
def test_LazyList():
    iterable = [1,2,3]
    a = LazyList(iterable)

    import pytest
    with pytest.raises(TypeError):
        len(a)
    assert list(a) == [1, 2, 3]



# Generated at 2022-06-23 17:35:57.084861
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[-10] == 0
    assert r[4] == 4
    assert r[4:] == [4, 5, 6, 7, 8, 9]
    assert r[:4] == [0, 1, 2, 3]
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[-10] == 1
    assert r[4] == 5
    assert r[4:] == [5, 6, 7, 8, 9, 10]
    assert r[:4] == [1, 2, 3, 4]
    r = Range(1, 10 + 1, 2)
    assert r[0] == 1
    assert r[-10] == 1
    assert r[4] == 9
    assert r

# Generated at 2022-06-23 17:36:07.817483
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    test_vals = [
        ([0], 0),
        ([1, 2], [1, 2]),
        ([1, 2, 3], [1, 2, 3]),
        ([4, 5], [4, 5]),
        ([4, 5, 6], [4, 6]),
        ([4, 5, 7], [4, 5, 7]),
        ([4, 5, 6, 7], [4, 6]),
        ([-5, -4, -3], [-5, -4, -3]),
        ([-5, -4, -3, -2], [-5, -3]),
    ]
    for i, (args, expected) in enumerate(test_vals):
        actual = Range(*args)

# Generated at 2022-06-23 17:36:13.148451
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([])) == 0
    assert len(LazyList(range(1))) == 1
    assert len(LazyList(range(10))) == 10
    try:
        len(LazyList(range(10**10)))
        assert False
    except TypeError:
        pass



# Generated at 2022-06-23 17:36:15.017671
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList([1, 2, 3])
    assert len(a) == 3


# Generated at 2022-06-23 17:36:17.647059
# Unit test for function drop
def test_drop():
    assert list(drop(10, range(1, 11))) == list(range(11, 21))
    assert list(drop(1, range(1, 11))) == list(range(2, 11))



# Generated at 2022-06-23 17:36:19.451997
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    pass # currently no test

# Generated at 2022-06-23 17:36:30.383010
# Unit test for constructor of class MapList
def test_MapList():
    from itertools import accumulate
    from functools import partial

    lst = [1, 2, 3, 4]
    assert list(MapList(lambda x: x + 1, lst)) == [2, 3, 4, 5]
    assert list(MapList(partial(pow, 2), lst)) == [1, 4, 9, 16]
    assert list(MapList(lambda x: x * x, lst)) == [1, 4, 9, 16]
    assert list(MapList(lambda x: x * x, (x * x for x in lst))) == [1, 16, 81, 256]
    assert list(accumulate(MapList(lambda x: x * x, lst), lambda a, b: a * b)) == [1, 4, 36, 576]

    idx = 3

# Generated at 2022-06-23 17:36:36.082932
# Unit test for function chunk
def test_chunk():
    l = list(chunk(3, range(10)))
    try:
        assert l == [[0,1,2],[3,4,5],[6,7,8],[9]]
    except:
        raise Exception(l)
test_chunk()



# Generated at 2022-06-23 17:36:41.205012
# Unit test for function chunk
def test_chunk():
    assert list(chunk(2, range(5))) == [[0, 1], [2, 3], [4]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(5, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(5, [])) == []



# Generated at 2022-06-23 17:36:48.335539
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    test_cases = [
        (None, {'lst': ([],)}),
        (0, {'lst': [1, 2, 3, 4, 5]}),
        (5, {'lst': [1, 2, 3, 4, 5]}),
    ]
    for expected, args in test_cases:
        try:
            assert MapList(lambda x: x, **args).__len__() == expected
        except AssertionError as e:
            print(f'ERROR: For `MapList(lambda x: x, **{args}).__len__()` expected: {expected}, got: {MapList(lambda x: x, **args).__len__()}')
            raise e



# Generated at 2022-06-23 17:36:53.348368
# Unit test for function scanl
def test_scanl():
    list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]


# Generated at 2022-06-23 17:37:04.075193
# Unit test for constructor of class Range
def test_Range():
    range_slice = Range(1, 10 + 1)
    range_slice2 = Range(1, 11, 2)
    range_slice[0:5] == Range(1, 6)
    range_slice[0:5:2] == Range(1, 6, 2)
    range_slice[::-1] == Range(10, 0, -1)
    range_slice[1] == 2
    range_slice2[1] == 3
    range_slice2[1:2] == [3]
    range_slice2[1:4:2] == [3, 7]
    range_slice2[1:4:3] == [3]
    range_slice2[1:4] == [3, 7, 5]

# Generated at 2022-06-23 17:37:10.431845
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(1, 10))) == [6, 7, 8, 9]
test_drop_until.test = True



# Generated at 2022-06-23 17:37:22.933073
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    try:
        range0=Range(0)
        print('range0 Test Successful')
    except:
        print('range0 Test Failed')
    try:
        range1=Range(1, 10 + 1)
        print('range1 Test Successful')
    except:
        print('range1 Test Failed')
    try:
        range2=Range(1, 11, 2)
        print('range2 Test Successful')
    except:
        print('range2 Test Failed')
    try:
        print(range2[0], range2[2], range2[4])
        print('range3 Test Successful')
    except:
        print('range3 Test Failed')

# def test_Range___getitem__():
#     range0=Range(0)
#     range1=Range(1, 10 + 1)
#