

# Generated at 2022-06-23 17:27:19.308961
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList([0, 1, 2, 3, 4, 5])
    assert len(a) == 6
    assert a.list == [0, 1, 2, 3, 4, 5]



# Generated at 2022-06-23 17:27:23.715155
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    r = Range(10)
    assert list(r) == list(range(10))
    r = Range(1, 10 + 1)
    assert list(r) == list(range(1, 10 + 1))
    r = Range(1, 11, 2)
    assert list(r) == list(range(1, 11, 2))

# Generated at 2022-06-23 17:27:28.377685
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    obj = Range(1, 100, 2)
    cnt = 0
    for i in obj:
        assert i == obj[cnt]
        cnt += 1
    assert cnt == obj.__len__()

# Generated at 2022-06-23 17:27:30.403556
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    map_list = MapList(lambda x: x, [1, 2, 3])
    assert len(map_list) == 3



# Generated at 2022-06-23 17:27:33.080044
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 2, range(10))) == list(range(3, 10))



# Generated at 2022-06-23 17:27:36.534569
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x, lst)
    assert len(m) == len(lst)

# Generated at 2022-06-23 17:27:44.082469
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    n = 100
    lst = [random.randint(1,20) for i in range(n)]
    def func(x):
        return len(str(x))
    mapList = MapList(func, lst)
    for i in range(n):
        assert mapList[i] == mapList.__iter__().__next__()
    return True


# Generated at 2022-06-23 17:27:55.201049
# Unit test for constructor of class LazyList
def test_LazyList():
    lst = LazyList([0, 1, 2])
    assert list(lst) == [0, 1, 2]
    lst = LazyList(range(0, 10))
    assert lst[0:5] == lst[0:5] == lst[0:5] == lst[0:5] == [0, 1, 2, 3, 4]
    assert lst[0:5] == [0, 1, 2, 3, 4]
    assert lst[2:4] == lst[2:4] == lst[2:4] == lst[2:4] == [2, 3]
    assert lst[2:4] == [2, 3]
    assert lst[4:4] == []

# Generated at 2022-06-23 17:28:02.773889
# Unit test for function scanl
def test_scanl():
    def scanl_test(func: Callable[[int, int], int], iterable: List[int], initial: int) -> List[int]:
        return list(scanl(func, iterable, initial))

    assert scanl_test(operator.add, [], 0) == [0]
    assert scanl_test(operator.add, [1, 2, 3, 4], 0) == [0, 1, 3, 6, 10]
    assert scanl_test(lambda s, x: x + s, ['a', 'b', 'c', 'd']) == ['a', 'ba', 'cba', 'dcba']
    assert scanl_test(operator.mul, [2, 3, 4, 5], 1) == [1, 2, 6, 24, 120]


# Generated at 2022-06-23 17:28:11.332317
# Unit test for constructor of class MapList
def test_MapList():
    from decimal import Decimal
    print(MapList(Decimal, [1, 2, 3]).list)
    print(MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:])
    print(MapList(lambda x: x, [1, 2, 3, 4, 5])[1:])
    a = [1, 2, 3, 4]
    b = MapList(lambda x: x * x, a)
    c = MapList(lambda x: int(x), b)
    d = MapList(lambda x: x * x, c)
    print(b[3])
    print(c[3])
    print(d[3])


# Generated at 2022-06-23 17:28:16.839909
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    iterable = range(1, 6)
    map_list = MapList(lambda x: x * x, iterable)
    from operator import mul
    from functools import reduce
    assert reduce(mul, map_list, 1) == reduce(mul, iterable, 1)
    for i, j in zip(map_list, iterable):
        assert i == j * j

# Generated at 2022-06-23 17:28:20.404839
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
test_drop_until()



# Generated at 2022-06-23 17:28:30.403750
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]
    try:
        assert False, "split_by should raise error when both criterion and separator are specified"
        list(split_by(range(10), criterion=lambda x: x % 3 == 0, separator=4))
    except ValueError:
        pass

# Generated at 2022-06-23 17:28:34.385188
# Unit test for function take
def test_take():
    assert isinstance(take(1, range(1)), Iterator)
    assert list(take(3, range(10))) == [0,1,2]


# Generated at 2022-06-23 17:28:44.492536
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print(Range(10)[0])
    print(Range(10)[1])
    print(Range(10)[2])
    print(Range(10)[-1])
    print(Range(10)[:3])
    print(Range(10)[3:])
    print(Range(10)[::2])
    print(Range(1, 11, 2)[0])
    print(Range(1, 11, 2)[1])
    print(Range(1, 11, 2)[2])
    print(Range(1, 11, 2)[-1])
    print(Range(1, 11, 2)[:3])
    print(Range(1, 11, 2)[3:])
    print(Range(1, 11, 2)[::2])
# Hidden test for method __getitem__ of class Range

# Generated at 2022-06-23 17:28:49.637572
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    input_list = list(range(10))
    ll = LazyList(input_list)
    ll_iter = ll.__iter__()
    assert_equal(input_list, list(ll_iter))
    assert_equal(input_list, list(ll_iter))

# Generated at 2022-06-23 17:29:00.386724
# Unit test for constructor of class MapList
def test_MapList():
    def check(lst, func):
        assert list(MapList(func, lst)) == [func(x) for x in lst]
        assert MapList(func, lst)[0] == func(lst[0])
        assert MapList(func, lst)[-1] == func(lst[-1])
        assert MapList(func, lst)[0:3] == [func(x) for x in lst[0:3]]

    lst = []
    func = lambda x: x + 1
    check(lst, func)
    lst = [1, 2, 3]
    check(lst, func)
    lst = [1, 2, 3, 4, 5, 6]
    check(lst, func)

# Generated at 2022-06-23 17:29:11.196284
# Unit test for constructor of class Range
def test_Range():
    try:
        Range()
    except ValueError:
        pass
    try:
        Range(1, 2, 3, 5)
    except ValueError:
        pass
    range_1 = Range(2)
    range_2 = Range(1, 3)
    range_3 = Range(1, 6, 2)
    assert next(range_1) == 0
    assert next(range_2) == 1
    assert next(range_3) == 1
    assert next(range_1) == 1
    assert next(range_2) == 2
    assert next(range_3) == 3
    try:
        next(range_1)
    except StopIteration:
        pass
    try:
        next(range_2)
    except StopIteration:
        pass

# Generated at 2022-06-23 17:29:15.929827
# Unit test for function drop_until
def test_drop_until():
    a = range(10)
    b = drop_until(lambda x: x>5, a)
    for i in range(7):
        assert next(b) == i+6


# Generated at 2022-06-23 17:29:19.552624
# Unit test for method __len__ of class Range
def test_Range___len__():
    test_cases = [(Range(10), 10), (Range(1, 10 + 1), 10), (Range(1, 11, 2), 5)]
    for r, expected in test_cases:
        assert len(r) == expected


# Generated at 2022-06-23 17:29:24.732415
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(5))
    assert len(lst) == 5
    assert lst[0] == 0
    lst = LazyList(range(5))
    assert list(lst) == list(range(5))
    lst = LazyList(range(5))
    assert lst[3] == 3
    lst = LazyList(range(5))
    assert lst[0:2] == [0, 1]
    lst = LazyList(range(5))
    assert lst[-1] == 4
    lst = LazyList(range(5))
    assert lst[-3:] == [2, 3, 4]
    lst = LazyList(range(5))
    assert lst[:] == list(range(5))



# Generated at 2022-06-23 17:29:33.171120
# Unit test for function drop_until
def test_drop_until():
    data = [2, 3, 5, 7, 11, 13]
    assert list(drop_until(lambda x: x % 2 == 0, data)) == [2, 3, 5, 7, 11, 13]
    assert list(drop_until(lambda x: x > 10, data)) == [11, 13]
    assert list(drop_until(lambda x: x < 0, data)) == [2, 3, 5, 7, 11, 13]
    assert list(drop_until(lambda x: False, data)) == [2, 3, 5, 7, 11, 13]



# Generated at 2022-06-23 17:29:36.602123
# Unit test for function drop
def test_drop():
    x = drop(3, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert next(x) == 4
    assert next(x) == 5
    assert next(x) == 6
    assert next(x) == 7



# Generated at 2022-06-23 17:29:41.867669
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    l1 = [False, True, False]
    l2 = [0, 1, 0]
    l3 = [False, False, True]
    m = MapList(lambda b: int(b), l1)
    assert list(m) == l2
    m = MapList(lambda x: bool(x), l2)
    assert list(m) == l1
    m = MapList(lambda b: not b, l1)
    assert list(m) == l3

# Generated at 2022-06-23 17:29:48.451015
# Unit test for method __iter__ of class Range
def test_Range___iter__():
    a = Range(5, 10 + 1)  # (start, end)
    i = iter(a)
    assert next(i) == 5
    assert next(i) == 6
    assert next(i) == 7
    assert next(i) == 8
    assert next(i) == 9
    assert next(i) == 10
    try:
        next(i)
        assert False, "No exception raised"
    except StopIteration:
        pass


# Generated at 2022-06-23 17:29:50.676880
# Unit test for method __next__ of class Range
def test_Range___next__():
    for range_obj in [Range(10), Range(1, 11), Range(1, 30, 3)]:
        assert list(range_obj) == list(range(*range_obj._range))

# Generated at 2022-06-23 17:29:52.517222
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]



# Generated at 2022-06-23 17:30:04.934017
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from .._testutil import result_of
    from .. import LazyList

    # Straightforward usage of __getitem__
    assert result_of(lambda: LazyList([]).__getitem__(0)) == IndexError
    assert result_of(lambda: LazyList([1, 2, 3]).__getitem__(0)) == 1
    assert result_of(lambda: LazyList([1, 2, 3]).__getitem__(1)) == 2
    assert result_of(lambda: LazyList([1, 2, 3]).__getitem__(2)) == 3
    assert result_of(lambda: LazyList([1, 2, 3]).__getitem__(-1)) == 3
    assert result_of(lambda: LazyList([1, 2, 3]).__getitem__(-2)) == 2
    assert result_

# Generated at 2022-06-23 17:30:07.133438
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    test_iter = range(10)
    obj = LazyList[int](test_iter)
    assert len(obj) == 10


# Generated at 2022-06-23 17:30:07.925622
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    ml = MapList(lambda x: x, [1, 2, 3])
    assert len(ml) == 3


# Generated at 2022-06-23 17:30:15.109563
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Create an instance of the class `MapList`
    obj = MapList(lambda i: i * 2, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    # Return the object for the specified index
    assert obj[4] == 8
    # Return the slice object
    assert obj[2:7] == [4, 6, 8, 10, 12]
    assert obj[:7:3] == [0, 6, 12]
    assert obj[::-1] == [18, 16, 14, 12, 10, 8, 6, 4, 2, 0]
    assert obj[7:2:-1] == [14, 12, 10, 8, 6]
    # Test for negative indices
    assert obj[-1] == 18
    assert obj[-3:] == [14, 16, 18]

# Generated at 2022-06-23 17:30:17.448542
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 11)) == 10
    assert len(Range(1, 11, 2)) == 5



# Generated at 2022-06-23 17:30:21.753064
# Unit test for function drop
def test_drop():
    # Test negative n
    with pytest.raises(Exception):
        next(drop(-1, [0, 1, 2]))
    # Test empty iterable
    assert next(drop(2, [])), None
    # Test positive n
    assert next(drop(2, [0, 1, 2, 3, 4])) == 2


# Generated at 2022-06-23 17:30:23.837961
# Unit test for function drop
def test_drop():
    assert [i for i in drop(5, range(0, 9))] == list(range(5, 9))
test_drop()



# Generated at 2022-06-23 17:30:31.558962
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    for xs in range(1, 10):
        for ys in range(1, 10):
            for zs in range(1, 10):
                l = list(range(xs))
                ll = LazyList(l)
                X = list(islice(ll, ys))
                assert l[:ys] == X
                Y = list(islice(ll, zs))
                assert l[ys:ys + zs] == Y
                Z = list(ll)
                assert l[ys + zs:] == Z
                assert l == X + Y + Z

# Generated at 2022-06-23 17:30:35.834773
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(0, 1)
    assert r.__next__() == 0
    counter = 0
    for i in r:
        counter += 1
    assert counter == 1
    assert list(r) == [0]

# Generated at 2022-06-23 17:30:45.768616
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.mul, [1, 2, 3, 4])) == [1, 2, 6, 24]
    assert list(scanl(lambda s, x: x + s, [])) == []
    assert list(scanl(lambda s, x: x + s, [], 1)) == [1]



# Generated at 2022-06-23 17:30:52.747707
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert len(r) == 10
    assert list(r) == list(range(10))
    assert r[2] == 2
    assert r[-2] == 8
    assert r[-1] == 9
    assert r[0] == 0
    assert r[-10] == 0
    assert r[9] == 9
    assert r[-11] == 0
    assert r[slice(1, 5)] == [1, 2, 3, 4]
    assert r[slice(0, 6, 2)] == [0, 2, 4]
    assert r[slice(1, 10, 2)] == [1, 3, 5, 7, 9]
    assert r[slice(9, -1, -2)] == [9, 7, 5, 3, 1]

# Generated at 2022-06-23 17:31:04.353259
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(-2, 3, 2)
    assert(r[0] == -2)
    assert(r[1] == 0)
    assert(r[2] == 2)
    r = Range(0, 20, 4)
    assert(r[2] == 8)
    assert(r[1:3] == [4, 8])
    assert(r[2:100] == [8, 12, 16])
    assert(r[1:7:2] == [4, 12, 20])
    assert(r[1:3:3] == [4])
    assert(r[0:3:3] == [0, 12])
    assert(r[0:4:-2] == [])
    assert(r[::-1] == [20, 16, 12, 8, 4, 0])

# Generated at 2022-06-23 17:31:13.828789
# Unit test for function scanl
def test_scanl():
    import operator
    import pytest
    with pytest.raises(ValueError, match='Too many arguments'):
        scanl(lambda x, y: x, [1, 2, 3], 4, 5)
    assert list(scanl(lambda x, y: x + y, [1, 2, 3])) == [1, 3, 6]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3], 0)) == [0, 1, 3, 6]
    assert list(scanl(operator.mul, [1, 2, 3, 4])) == [1, 2, 6, 24]
    assert list(scanl(lambda x, y: x + y, [])) == []
    assert list(scanl(lambda x, y: x + y, [], 0)) == [0]



# Generated at 2022-06-23 17:31:23.692792
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    R = Range(3)
    Ra = Range(1, 2)
    Rb = Range(1, 4, 2)
    Rc = Range(3, 0, -1)
    Rd = Range(3, 0, -1)
    assert R[0] == 0 and R[-1] == 2
    assert Ra[0] == 1 and Ra[-1] == 1
    assert Rb[0] == 1 and Rb[-1] == 3
    assert Rc[0] == 3 and Rc[-1] == 0
    assert Rd[0] == 3 and Rd[-1] == 0


# Generated at 2022-06-23 17:31:31.247280
# Unit test for constructor of class Range
def test_Range():
    # empty argument list
    success = False
    try:
        r = Range()
    except ValueError:
        success = True
    assert success

    # too many arguments
    success = False
    try:
        r = Range(1, 2, 3, 4)
    except ValueError:
        success = True
    assert success

    # one argument
    r = Range(10)
    assert list(r) == list(range(10))

    # two arguments
    r = Range(1, 10 + 1)
    assert list(r) == list(range(1, 10 + 1))

    # three arguments
    r = Range(1, 11, 2)
    assert list(r) == list(range(1, 11, 2))
# End of unit test for constructor of class Range


# Generated at 2022-06-23 17:31:43.192787
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(100000))
    assert lst.list == []
    assert lst[0] == 0
    assert lst.list == [0]
    assert lst[1:4] == [1, 2, 3]
    assert lst.list == [0, 1, 2, 3]
    assert lst[0] == 0
    assert lst[-1] == 3
    assert lst[-1] == 3
    assert lst.list == [0, 1, 2, 3]
    assert lst[-1] == 3
    assert lst[-2] == 2
    assert lst.list == [0, 1, 2, 3]
    assert lst[-2] == 2
    assert lst[-2] == 2

# Generated at 2022-06-23 17:31:55.365032
# Unit test for function drop_until
def test_drop_until():
    a = [1,2,3,4,5,6,7,8,9,10]
    b = [(1,2),(1,3),(1,4),(2,2),(2,4),(2,5),(2,6)]
    c = [0,0,0,1,2,3,4,5,6,7,8]
    it1 = drop_until(lambda x: x > 5, a)
    it2 = drop_until(lambda x: x[1] > 4, b)
    it3 = drop_until(lambda x: x > 0, c)
    assert next(it1) == 6
    assert next(it2) == (2,5)
    assert next(it3) == 1
    assert next(it3) == 2
    assert next(it3)

# Generated at 2022-06-23 17:31:58.229641
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    for i in MapList(lambda x: x * x, [1, 2, 3, 4, 5]):
        pass
    return


# Generated at 2022-06-23 17:32:04.123424
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(10))) == []
    with pytest.raises(ValueError, match=r"n should be non-negative"):
        take(-1, range(10))


# Generated at 2022-06-23 17:32:05.969006
# Unit test for function drop
def test_drop():
    assert next(drop(5, range(10))) == 5
    assert next(drop(-1, range(10))) == AttributeError
    try:
        assert next(drop(11, range(10))) # Should be StopIteration
    except StopIteration:
        pass
test_drop()



# Generated at 2022-06-23 17:32:12.148485
# Unit test for function scanr
def test_scanr():
    from functools import reduce
    from operator import add
    assert list(scanl(add, [])) == []
    assert list(scanl(add, [1, 2, 3])) == [1, 3, 6]
    assert list(scanl(add, [1, 2, 3], 10)) == [10, 11, 13, 16]
    assert list(scanr(add, [])) == []
    assert list(scanr(add, [1, 2, 3])) == [6, 5, 3, 0]
    assert list(scanr(add, [1, 2, 3], 10)) == [16, 14, 11, 10]

# Generated at 2022-06-23 17:32:21.247011
# Unit test for constructor of class Range
def test_Range():
    lst = list(Range(0, 1, 2))
    assert lst == [0], "Test Range(0, 1, 2) failed"

    lst = list(Range(1, 10 + 1))
    assert lst == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], "Test Range(1, 10+1) failed"

    lst = list(Range(1, 11, 2))
    assert lst == [1, 3, 5, 7, 9], "Test Range(1, 11, 2) failed"


# Generated at 2022-06-23 17:32:26.253804
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    a = list(range(random.randint(100, 200)))
    b = LazyList(a)
    for i in range(len(a)):
        assert a[i] == b[i]
    for i in range(len(a)):
        assert a[:i] == b[:i]

# Generated at 2022-06-23 17:32:37.336884
# Unit test for constructor of class MapList
def test_MapList():
    l = [1,2,3,4,5]
    f = lambda x: x+1
    m = MapList(f,l)
    assert(len(m)==len(l))
    assert(m[0]==f(l[0]))
    assert(m[2]==f(l[2]))
    assert(m[-1]==f(l[-1]))
    assert(list(m[1:3])==[f(l[1]),f(l[2])])
    assert(list(m[-2:-1])==[f(l[-2])])
    assert(list(m[:])==[f(i) for i in l])
    try:
        m[5]
        assert(False)
    except:
        pass

# Generated at 2022-06-23 17:32:48.345071
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(3, range(1, 0, -1))) == [[1]]
    assert list(chunk(3, range(1, -1, -1))) == []
    assert list(chunk(0, range(10))) == []
    assert list(chunk(-1, range(10))) == []
    assert list(chunk(5, [])) == []
    try:
        list(chunk(-1, range(10)))
        assert False
    except ValueError:
        pass



# Generated at 2022-06-23 17:32:51.629337
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    t1 = MapList(lambda x: x * 2, (1, 2, 3))
    t2 = MapList(lambda x: x * 2, (1, 2, 3))
    for iterator1, iterator2 in zip(t1, t2):
        assert iterator1 == iterator2


# Generated at 2022-06-23 17:33:01.026128
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for r in [Range(10), Range(1, 10+1), Range(1, 11, 2)]:
        assert(r[0] == 1)
        assert(r[2] == 5)
        assert(r[4] == 9)
        assert(r[-1] == 9)
        assert(r[9] == 10)
        assert(r[10] == 11)
        assert(r[-3] == 7)
        assert(r[-11] == 1)
        assert(r[-12] == 0)
        assert(r[5:8] == [6, 7, 8])
        assert(r[5:11] == [6, 7, 8, 9, 10])
        assert(r[5:] == [6, 7, 8, 9, 10])

# Generated at 2022-06-23 17:33:05.798843
# Unit test for constructor of class MapList
def test_MapList():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    assert MapList(lambda a, b: a * b, zip(a, b))[2] == 12
    assert MapList(lambda a, b: a * b, zip(a, b))[:2] == [2, 6]



# Generated at 2022-06-23 17:33:14.541712
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(10))== 0
    assert next(Range(0,10))== 0
    assert next(Range(0,10,2))== 0
    assert next(Range(11))== 0
    assert next(Range(0,11))== 0
    assert next(Range(0,11,2))== 0
    assert next(Range(10,0, -1))== 10
    assert next(Range(11,0, -1))== 11
    assert next(Range(2, 3))== 2
    assert next(Range(2, 3, 1))== 2
    assert next(Range(2, 3, 2))== 2
    assert next(Range(2, 3, 3))== 2


# Generated at 2022-06-23 17:33:16.594353
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    m = MapList(lambda x: x * 2, [1, 2, 3])
    assert len(m) == 3

# Generated at 2022-06-23 17:33:27.049942
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    with pytest.raises(ValueError, match='Too many arguments'):
        list(scanl(operator.add, [1, 2, 3, 4], 0, 1))
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4])) == [1, 3, 6, 10]



# Generated at 2022-06-23 17:33:29.613199
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(take(5, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(5))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-23 17:33:37.612242
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-23 17:33:46.159066
# Unit test for function drop_until
def test_drop_until():
    assert [] == list(drop_until(lambda _: True, []))
    assert [] == list(drop_until(lambda _: False, []))

    assert [1] == list(drop_until(lambda _: True, [1, 2, 3]))
    assert [] == list(drop_until(lambda _: False, [1, 2, 3]))

    assert [3] == list(drop_until(lambda x: x > 2, range(10)))
    assert [1, 2, 3] == list(drop_until(lambda x: x == 0, range(10)))



# Generated at 2022-06-23 17:33:51.429801
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert isinstance(iter(lst), LazyList.LazyListIterator)

    assert list(lst) == list(range(10))
    assert list(lst[:]) == list(range(10))


# Generated at 2022-06-23 17:33:59.510343
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(2, [])) == []
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(3, [1])) == [[1]]
    assert list(chunk(3, [1, 2])) == [[1, 2]]
    assert list(chunk(3, [1, 2, 3])) == [[1, 2, 3]]
test_chunk()



# Generated at 2022-06-23 17:34:10.050069
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[0] == 0
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[:7] == [0, 1, 2, 3, 4, 5, 6]
    assert lst[:7] == [0, 1, 2, 3, 4, 5, 6]
    assert list(lst) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-23 17:34:16.269289
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(1, [])) == []
    assert list(chunk(0, range(8))) == []



# Generated at 2022-06-23 17:34:20.240426
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0] 
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd'] 

# Generated at 2022-06-23 17:34:28.600209
# Unit test for constructor of class Range
def test_Range():
    try:
        range1 = Range(2,4,"a")
    except ValueError:
        assert True
    else:
        assert False
    try:
        range1 = Range()
    except ValueError:
        assert True
    else:
        assert False
    try:
        range1 = Range(2,4,5,6)
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 17:34:30.887193
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(100000000))) == 100000000
    assert len(LazyList([])) == 0

# Generated at 2022-06-23 17:34:40.982382
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import unittest

    t = unittest.TestCase()
    for start, end, step in [(0, 1, 1), (0, 10, 1), (10, 0, -1), (-10, 0, 1), (0, 10, 2), (0, -10, -2)]:
        r = Range(start, end, step)
        t.assertEqual(list(range(start, end, step)), list(r[:]))
        t.assertEqual(list(range(start, end, step)), list(r[0:]))
        t.assertEqual(list(range(start, end, step)), list(r[:10]))
        t.assertEqual(list(range(start, end, step)), list(r[0:10]))

# Generated at 2022-06-23 17:34:43.040143
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    assert list(MapList(lambda x: x * x, [1, 2, 3, 4, 5])) == [1, 4, 9, 16, 25]
    assert list(MapList(lambda x: x * x, [])) == []

# Generated at 2022-06-23 17:34:48.434005
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(5))
    it = iter(lst)
    assert next(it) == 0
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    assert next(it) == 4
    assert next(it, None) is None

# Generated at 2022-06-23 17:34:55.161647
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert list(MapList(lambda i: i * i, range(10))) == [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]
    assert MapList(lambda i: i * i, range(10))[3] == 9
    assert MapList(lambda i: i * i, range(10))[::2] == [0, 4, 16, 36, 64]



# Generated at 2022-06-23 17:35:01.022438
# Unit test for function drop
def test_drop():
    # Case 1: n is 0
    assert list(drop(0, range(10))) == list(range(10))

    # Case 2: n is positive
    assert list(drop(5, range(10))) == list(range(5,10))

    # Case 3: n is negative
    with pytest.raises(ValueError):
        list(drop(-1, range(10)))



# Generated at 2022-06-23 17:35:07.237788
# Unit test for constructor of class MapList
def test_MapList():
    assert list(MapList(lambda x: x * x, range(10))) == list(map(lambda x: x * x, range(10)))
    assert MapList(lambda x: x * x, [0, 1, 2, 3])[1:3] == [1, 4]


# Generated at 2022-06-23 17:35:12.082473
# Unit test for function scanr
def test_scanr():
    def f(s, x): return x + s
    assert list(scanr(f, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:35:16.959819
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']
    return



# Generated at 2022-06-23 17:35:21.775007
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(-1, range(1000000))) == []


# Generated at 2022-06-23 17:35:26.760368
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    def func(x):
        return x * x

    def test_func_for_slice(func, slice_, expected):
        assert MapList(func, range(10))[slice_] == expected

    test_func_for_slice(func, 2, 4)
    test_func_for_slice(func, 3, 9)
    test_func_for_slice(func, -1, 81)
    test_func_for_slice(func, 2, 4)
    test_func_for_slice(func, 2, 4)
    test_func_for_slice(func, 2, 4)

# Generated at 2022-06-23 17:35:31.862357
# Unit test for function split_by
def test_split_by():

    list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    if criterion is None:
        criterion = lambda x: x == separator
    group = []
    for x in iterable:
        if not criterion(x):
            group.append(x)
        else:
            if len(group) > 0 or empty_segments:
                yield group
            group = []
    if len(group) > 0 or empty_segments:
        yield group


# Generated at 2022-06-23 17:35:34.804872
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    obj = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert([-1, 0, 1, 4] == obj[slice(-1, 4, 2)])


# Generated at 2022-06-23 17:35:38.870851
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    import random
    length = random.randint(2, 20)
    gen = (random.uniform(1, 10) for _ in range(length))
    lst = LazyList(gen)
    for i in range(length):
        assert len(lst) == length



# Generated at 2022-06-23 17:35:41.943205
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1,10+1)
    for i in r:
        print(i)

if __name__ == "__main__":
    test_Range___getitem__()


# Generated at 2022-06-23 17:35:45.961375
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    tester = createTester(lambda x:x, 1, 2, 3)
    for x in tester:
        yield lambda: x == 1
        yield lambda: x == 2
        yield lambda: x == 3

# Generated at 2022-06-23 17:35:48.420469
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList(range(100000000))
    i = 0
    for x in l:
        i += 1
        if i > 3:
            break



# Generated at 2022-06-23 17:35:55.183423
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                  ['b', 'y', ':'], []]


# Generated at 2022-06-23 17:35:59.642998
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 7, range(10))) == [8, 9]
    assert list(drop_until(lambda x: x > 10, range(10))) == []

    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [3,2,3])) == []
    assert list(drop_until(lambda x: x > 5, [7, 6, 5, 4, 3, 2, 1])) == [6, 5, 4, 3, 2, 1]

# Generated at 2022-06-23 17:36:01.801159
# Unit test for constructor of class LazyList
def test_LazyList():
    with pytest.raises(TypeError):
        len(LazyList(range(10)))


# Generated at 2022-06-23 17:36:03.286686
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    LazyList(range(10)).__len__()



# Generated at 2022-06-23 17:36:06.537734
# Unit test for method __next__ of class Range
def test_Range___next__():
    if Path("..\\src\\test_Range___next__.py").is_file():
        os.chdir("..")
    from src.test_Range___next__ import test_Range___next__
    test_Range___next__()


# Generated at 2022-06-23 17:36:12.526013
# Unit test for function scanr
def test_scanr():
    assert list(scanr(operator.add, [1, 2, 3, 4], 0)) == [10, 9, 7, 4, 0]
    assert list(scanr(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['abcd', 'bcd', 'cd', 'd']



# Generated at 2022-06-23 17:36:15.550623
# Unit test for function take
def test_take():
    assert list(take(0, range(1))) == []
    assert list(take(1, range(1))) == [0]
    assert list(take(3, range(1))) == [0]



# Generated at 2022-06-23 17:36:21.396573
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(1, range(10))) == [0]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(1000, range(10))) == list(range(10))


# Generated at 2022-06-23 17:36:31.031729
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(100), criterion=lambda x: x % 3 == 0)) == \
        [[1, 2], [4, 5], [7, 8], [10, 11], [13, 14], [16, 17], [19, 20], [22, 23], [25, 26], [28, 29], [31, 32], [34, 35],
         [37, 38], [40, 41], [43, 44], [46, 47], [49, 50], [52, 53], [55, 56], [58, 59], [61, 62], [64, 65], [67, 68],
         [70, 71], [73, 74], [76, 77], [79, 80], [82, 83], [85, 86], [88, 89], [91, 92], [94, 95], [97, 98]]

# Generated at 2022-06-23 17:36:38.815723
# Unit test for method __len__ of class MapList
def test_MapList___len__():
    from typing import List

    import random
    from hypothesis import given, strategies

    @given(strategies.lists(strategies.integers()))
    def test(lst: List[int]):
        mapper = lambda x: 2 * x + 1
        print(lst, mapper)
        mlst = MapList(mapper, lst)
        assert len(mlst) == len(lst), "The length doesn't match"

    test()



# Generated at 2022-06-23 17:36:50.453639
# Unit test for function split_by
def test_split_by():
    assert list(split_by("", empty_segments=True)) == [[]]
    assert list(split_by("", empty_segments=False)) == []
    assert list(split_by(" ", empty_segments=True)) == [[], []]
    assert list(split_by(" ", empty_segments=False)) == []
    assert list(split_by("abc", empty_segments=True)) == [['a', 'b', 'c']]
    assert list(split_by("abc", empty_segments=False)) == [['a', 'b', 'c']]
    assert list(split_by("a b c", empty_segments=True)) == [['a'], ['b'], ['c']]

# Generated at 2022-06-23 17:37:02.437032
# Unit test for constructor of class LazyList
def test_LazyList():
    a = LazyList(range(2))
    b = LazyList(range(2))
    assert a==b
    assert not a is b
    assert a.__str__() == b.__str__()
    assert a.__repr__() == b.__repr__()
    assert a.__hash__() == b.__hash__()
    assert not a.__eq__(range(2)) #test invariant
    c = LazyList(range(1))
    assert not a == c
    assert not a.__str__() == c.__str__()
    assert not a.__repr__() == c.__repr__()
    assert not a.__hash__() == c.__hash__()


# Generated at 2022-06-23 17:37:07.484652
# Unit test for method __iter__ of class MapList
def test_MapList___iter__():
    list = list(MapList(lambda i: i * 2, Range(1, 10, 2)))
    assert(list == [2, 6, 10, 14, 18])


# Generated at 2022-06-23 17:37:14.431995
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] == r[:]
    r = Range(1, 10 + 1)
    assert [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] == r[:]
    r = Range(1, 11, 2)
    assert [1, 3, 5, 7, 9] == r[:]
    assert [0, 2, 4, 6, 8] == r[:5]
    assert [0, 2, 4] == r[:3]
    assert [1, 3, 5, 7, 9] == r[10:20:2]
    assert [5] == r[5:6]
    assert [] == r[5:5]