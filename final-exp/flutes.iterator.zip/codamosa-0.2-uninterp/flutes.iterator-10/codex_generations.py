

# Generated at 2022-06-17 18:27:57.151480
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zba', 'zcba', 'zdcba']



# Generated at 2022-06-17 18:28:05.259100
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(-1, range(1000000))) == []
    assert list(take(5, [])) == []
    assert list(take(5, [1, 2, 3])) == [1, 2, 3]
    assert list(take(0, [1, 2, 3])) == []
    assert list(take(-1, [1, 2, 3])) == []


# Generated at 2022-06-17 18:28:12.964454
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

# Generated at 2022-06-17 18:28:22.559378
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    assert len(lst) == 10
    assert lst[5] == 5
    assert len(lst) == 10
    assert lst[9] == 9
    assert len(lst) == 10
    assert lst[10] == 10
    assert len(lst) == 10
    assert lst[11] == 11
    assert len(lst) == 11
    assert lst[-1] == 11
    assert len(lst) == 11
    assert lst[-2] == 10
    assert len(lst) == 11
    assert lst[-11] == 1
    assert len(lst) == 11
    assert lst[-12] == 0
    assert len(lst) == 12
    assert lst[-13] == -1


# Generated at 2022-06-17 18:28:33.163058
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(-1, range(1000000))) == []
    assert list(take(5, [])) == []
    assert list(take(5, [1, 2, 3])) == [1, 2, 3]
    assert list(take(5, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])) == [1, 2, 3, 4, 5]
    assert list(take(5, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11])) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 18:28:43.416446
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10

# Generated at 2022-06-17 18:28:55.987092
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:29:04.761448
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(10, range(10))) == []
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(5))) == []
    assert list(drop(5, range(0))) == []
    assert list(drop(0, range(0))) == []
    assert list(drop(-1, range(10))) == []
    assert list(drop(-1, range(0))) == []



# Generated at 2022-06-17 18:29:16.009778
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:29:28.098551
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))

# Generated at 2022-06-17 18:29:44.873846
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:29:51.203036
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:30:02.941024
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:30:13.027107
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:30:22.714189
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:30:34.142871
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1] == 4
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[3] == 16
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[4] == 25
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-1] == 25

# Generated at 2022-06-17 18:30:41.301301
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]

# Generated at 2022-06-17 18:30:54.445955
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:31:02.111781
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:31:14.740516
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]

# Generated at 2022-06-17 18:31:31.355057
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[1:5] == [1, 2, 3, 4]
    assert lst[1:5:2] == [1, 3]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-17 18:31:42.449458
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-4] == 6
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:31:48.493073
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:31:58.524810
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:32:10.118494
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:21.086190
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    import string
    from itertools import count
    from functools import reduce
    from operator import add

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def random_list(length):
        return [random_string(random.randint(1, 10)) for _ in range(length)]

    def random_iterable(length):
        return (random_string(random.randint(1, 10)) for _ in range(length))

    def random_index(length):
        return random.randint(0, length - 1)

    def random_slice(length):
        return slice(random.randint(0, length - 1), random.randint(0, length - 1))


# Generated at 2022-06-17 18:32:33.092870
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7, 8, 9])) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [6, 7, 8, 9])) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [5, 6, 7, 8, 9])) == [6, 7, 8, 9]

# Generated at 2022-06-17 18:32:43.341325
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:49.300834
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[1:3] == [1, 2]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]

# Generated at 2022-06-17 18:32:54.591752
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-17 18:33:09.678321
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 10
    assert r[11] == 10
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:4] == [0, 4, 8]
    assert r[0:10:5] == [0, 5]

# Generated at 2022-06-17 18:33:21.310369
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:26.229141
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[9] == 9
    assert r[10] == 10
    assert r[11] == 11
    assert r[-11] == -1
    assert r[-12] == -2
    assert r[-20] == -10
    assert r[-21] == -11
    assert r[-22] == -12
    assert r[-30] == -20
    assert r[-31] == -21
    assert r[-32] == -22
    assert r[-40] == -30
    assert r[-41] == -31

# Generated at 2022-06-17 18:33:37.451283
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:49.607178
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:34:02.415952
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:11.568203
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:21.676772
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:2] == [0, 1]
    assert lst[2:] == [2, 3, 4, 5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[-1::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-17 18:34:32.623668
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(4))) == []
    assert list(drop_until(lambda x: x > 5, range(3))) == []
    assert list(drop_until(lambda x: x > 5, range(2))) == []
    assert list(drop_until(lambda x: x > 5, range(1))) == []
    assert list(drop_until(lambda x: x > 5, range(0))) == []

# Generated at 2022-06-17 18:34:42.807017
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:35:03.939121
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-17 18:35:13.977117
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from itertools import islice
    from bisect import bisect_left
    from operator import add
    for _ in range(100):
        n = randint(1, 100)
        a = [randint(1, 100) for _ in range(n)]
        b = [randint(1, 100) for _ in range(n)]
        c = [randint(1, 100) for _ in range(n)]
        d = [randint(1, 100) for _ in range(n)]
        e = [randint(1, 100) for _ in range(n)]
        f = [randint(1, 100) for _ in range(n)]
        g = [randint(1, 100) for _ in range(n)]

# Generated at 2022-06-17 18:35:25.062030
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:31.677610
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from itertools import count
    from bisect import bisect_left
    for _ in count():
        n = randint(1, 10)
        a = [randint(1, 10) for _ in range(n)]
        b = [randint(1, 10) for _ in range(n)]
        pos = bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
        assert pos == bisect_left(MapList(lambda x: x * x, a), 10)
        assert pos == bisect_left(MapList(lambda x: x * x, b), 10)
        assert pos == bisect_left(MapList(lambda i: a[i] * b[i], Range(len(b))), 10)
        assert pos

# Generated at 2022-06-17 18:35:39.294887
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-17 18:35:50.723364
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[1:4] == [1, 2, 3]
    assert lst[1:4:2] == [1, 3]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-17 18:36:03.279635
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[0:2] == [0, 1]
    assert lst[1:3] == [1, 2]
    assert lst[-1:1] == []
   

# Generated at 2022-06-17 18:36:14.424896
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:36:24.886045
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:35.394332
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:3] == [0, 1, 2]
    assert r[3:6] == [3, 4, 5]
    assert r[6:9] == [6, 7, 8]
    assert r[9:12] == [9]
    assert r[-1:12] == [9]
    assert r[-1:11] == [9]
    assert r[-1:10] == [9]
    assert r[-1:9]

# Generated at 2022-06-17 18:36:55.153191
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 10
    assert r[11] == 10
    assert r[12] == 10
    assert r[0:2] == [0, 1]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:4] == [0, 4, 8]
    assert r[0:10:5] == [0, 5]
   

# Generated at 2022-06-17 18:37:05.946901
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:37:17.847460
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:3] == [1, 2, 3]
    assert r[2:5] == [3, 4, 5]
    assert r[-3:-1] == [8, 9]
    assert r[-5:-2] == [6, 7, 8]
    assert r[0:10:2] == [1, 3, 5, 7, 9]
    assert r[1:10:2] == [2, 4, 6, 8, 10]

# Generated at 2022-06-17 18:37:28.722628
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))