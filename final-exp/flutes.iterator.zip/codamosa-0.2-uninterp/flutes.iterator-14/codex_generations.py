

# Generated at 2022-06-17 18:27:45.433449
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))



# Generated at 2022-06-17 18:27:56.062442
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(1))) == [0]
    assert list(take(5, range(0))) == []
    assert list(take(0, range(5))) == []
    assert list(take(0, range(0))) == []
    assert list(take(5, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(6))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(7))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(8))) == [0, 1, 2, 3, 4]

# Generated at 2022-06-17 18:28:05.833983
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:3] == [1, 2, 3]
    assert r[2:5] == [3, 4, 5]
    assert r[-3:-1] == [8, 9]
    assert r[-5:-2] == [6, 7, 8]
    assert r[0:10:2] == [1, 3, 5, 7, 9]
    assert r[1:10:2] == [2, 4, 6, 8, 10]

# Generated at 2022-06-17 18:28:13.471667
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(5, range(0))) == []
    assert list(take(0, range(5))) == []
    assert list(take(0, range(0))) == []
    assert list(take(-1, range(5))) == []
    assert list(take(-1, range(0))) == []
    assert list(take(5, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(6))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(7))) == [0, 1, 2, 3, 4]

# Generated at 2022-06-17 18:28:19.138210
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 10
    assert r[11] == 10
    assert r[0:10] == list(range(10))
    assert r[0:10:2] == list(range(0, 10, 2))
    assert r[-10:-1] == list(range(0, 9))
    assert r[-10:-1:2] == list(range(0, 9, 2))
    assert r[-1:0] == []
    assert r[-1:0:2] == []
    assert r[-1:-10]

# Generated at 2022-06-17 18:28:30.648850
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == -1
    assert r[-12] == -2
    assert r[-20] == -10
    assert r[-21] == -11
    assert r[-22] == -12
    assert r[-30] == -20
    assert r[-31] == -21
    assert r[-32] == -22
    assert r[-40] == -30
    assert r[-41] == -31
    assert r[-42] == -32
    assert r

# Generated at 2022-06-17 18:28:39.436183
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(5, range(5))) == []
    assert list(drop(0, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop(-1, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop(5, [])) == []
    assert list(drop(0, [])) == []
    assert list(drop(-1, [])) == []



# Generated at 2022-06-17 18:28:46.045871
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[-10] == 1
    assert r[-11] == 1
    assert r[-12] == 1
    assert r[-13] == 1
    assert r[-14] == 1
    assert r[-15] == 1
    assert r[-16] == 1
    assert r[-17] == 1
    assert r[-18] == 1
    assert r[-19] == 1
    assert r[-20] == 1
    assert r[-21] == 1
    assert r[-22] == 1


# Generated at 2022-06-17 18:28:57.545592
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(0, range(3))) == []
    assert list(take(5, [])) == []
    assert list(take(0, [])) == []
    assert list(take(-1, range(3))) == []
    assert list(take(-1, [])) == []
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]

# Generated at 2022-06-17 18:29:06.078841
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    assert next(r) == 10
    try:
        next(r)
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-17 18:29:31.563933
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[2:5] == [2, 3, 4]
    assert lst[2:5:2] == [2, 4]
    assert lst[::-1] == list(range(9, -1, -1))
    assert lst[::-2] == list(range(9, -1, -2))
    assert lst[-1:0:-1] == list(range(9, 0, -1))
    assert lst[-1:0:-2] == list(range(9, 0, -2))
    assert lst[-1::-1] == list(range(9, -1, -1))

# Generated at 2022-06-17 18:29:39.933257
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:29:48.618641
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[0:3] == [0, 1, 2]
    assert lst[3:6] == [3, 4, 5]
    assert lst[6:9] == [6, 7, 8]
    assert lst[9:12] == [9]
    assert lst[-3:] == [7, 8, 9]
    assert lst[-6:-3] == [4, 5, 6]
    assert lst[-9:-6] == [1, 2, 3]
    assert lst[-12:-9] == [0, 1, 2]

# Generated at 2022-06-17 18:30:01.486035
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:2] == [1, 2]
    assert r[2:4] == [3, 4]
    assert r[4:6] == [5, 6]
    assert r[-1:-3] == [10, 9]
    assert r[-3:-5] == [8, 7]
    assert r[-5:-7] == [6, 5]
    assert r[0:2:2] == [1]
    assert r[2:4:2] == [3]

# Generated at 2022-06-17 18:30:12.741133
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[-11] == 0
    assert lst[-12] == 0
    assert lst[-13] == 0
    assert lst[-14] == 0

# Generated at 2022-06-17 18:30:21.449486
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]
    assert lst[::-4] == [9, 5, 1]

# Generated at 2022-06-17 18:30:30.075864
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5
    assert len(Range(1, 10, 2)) == 5
    assert len(Range(10, 1, -2)) == 5
    assert len(Range(10, 1, -1)) == 10
    assert len(Range(1, 10, -1)) == 0
    assert len(Range(1, 10, -2)) == 0
    assert len(Range(1, 10, -3)) == 3
    assert len(Range(1, 10, 3)) == 3
    assert len(Range(1, 10, 2)) == 5
    assert len(Range(1, 10, 3)) == 3
    assert len(Range(1, 10, 4)) == 2
    assert len

# Generated at 2022-06-17 18:30:39.974955
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:30:49.455460
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zba', 'zcba', 'zdcba']
    assert list(scanl(lambda s, x: x + s, [])) == []
    assert list(scanl(lambda s, x: x + s, [], 'z')) == ['z']



# Generated at 2022-06-17 18:30:57.157364
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:31:16.817748
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 10
    assert r[11] == 10
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[-1:0:-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1]
    assert r[-1:0:-2] == [9, 7, 5, 3, 1]

# Generated at 2022-06-17 18:31:25.974711
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-1] == 25
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:3] == [4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[:3] == [1, 4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[3:] == [16, 25]

# Generated at 2022-06-17 18:31:37.388951
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [5])) == []
    assert list(drop_until(lambda x: x > 5, [6])) == [6]
    assert list(drop_until(lambda x: x > 5, [5, 6])) == [6]
    assert list(drop_until(lambda x: x > 5, [6, 5])) == [6]
    assert list(drop_until(lambda x: x > 5, [5, 6, 7])) == [6, 7]

# Generated at 2022-06-17 18:31:46.420898
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:31:51.558860
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-100] == 0
    assert r[-1000] == 0
    assert r[0:2] == [0, 1]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:32:00.014063
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(0, range(10))) == []

# Generated at 2022-06-17 18:32:06.723850
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-17 18:32:18.517853
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:32:29.015790
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[1:5] == [1, 2, 3, 4]
    assert lst[1:5:2] == [1, 3]
    assert lst[5:1:-2] == [5, 3]
    assert lst[5:1:-2] == [5, 3]

# Generated at 2022-06-17 18:32:40.904487
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    assert m[0] == 1
    assert m[1] == 4
    assert m[-1] == 25
    assert m[1:3] == [4, 9]
    assert m[1:3:2] == [4]
    assert m[::-1] == [25, 16, 9, 4, 1]
    assert m[::2] == [1, 9, 25]
    assert m[::-2] == [25, 9, 1]
    assert m[1::-2] == [4, 1]
    assert m[1::2] == [4, 16]
    assert m[1::-1] == [4, 3, 2, 1]
    assert m

# Generated at 2022-06-17 18:32:57.527674
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:08.888792
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:33:21.055988
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:33:25.952603
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[:3] == [1, 4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2:4] == [9, 16]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-2:] == [16, 25]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-2:-1] == [16]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-2:0] == []

# Generated at 2022-06-17 18:33:37.303603
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:33:49.562245
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[-11] == 0
    assert lst[-12] == 0
    assert lst[-13] == 0
    assert lst[-14] == 0
    assert lst[-15] == 0
   

# Generated at 2022-06-17 18:33:57.292802
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[:5] == [0, 1, 2, 3, 4]
    assert r[2:5] == [2, 3, 4]
    assert r[2:5:2] == [2, 4]
    assert r[-5:-2] == [5, 6, 7]
    assert r[-5:-2:2] == [5, 7]
    assert r[-5:5] == [5, 6, 7, 8, 9]
    assert r[-5:5:2] == [5, 7]

# Generated at 2022-06-17 18:34:07.279137
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[3] == 3
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]
    assert lst[::-4] == [9, 5, 1]

# Generated at 2022-06-17 18:34:14.777640
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[3] == 3
    assert lst[4] == 4
    assert lst[5] == 5
    assert lst[6] == 6
    assert lst[7] == 7
    assert lst[8] == 8
    assert lst[9] == 9
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3

# Generated at 2022-06-17 18:34:23.611560
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:45.071775
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[12] == 0
    assert r[0:2] == [0, 1]
    assert r[0:3] == [0, 1, 2]
    assert r[0:4] == [0, 1, 2, 3]
    assert r[0:5] == [0, 1, 2, 3, 4]

# Generated at 2022-06-17 18:34:57.580052
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[0:2] == [0, 1]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:10] == [0]
    assert r[0:10:11] == [0]
    assert r[0:10:12] == []
    assert r[0:10:0] == []
    assert r[0:10:-1] == []

# Generated at 2022-06-17 18:35:10.266224
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 10
    assert r[11] == 10
    assert r[12] == 10
    assert r[0:3] == [0, 1, 2]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:35:16.957788
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == -1
    assert r[-12] == -2
    assert r[-20] == -10
    assert r[10] == 10
    assert r[11] == 11
    assert r[20] == 20
    assert r[-1:0] == []
    assert r[-1:1] == [9]
    assert r[-1:2] == [9, 10]
    assert r[-1:10] == [9, 10]
    assert r[-1:11] == [9, 10, 11]

# Generated at 2022-06-17 18:35:27.161083
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:39.513370
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by(" Split by: ", empty_segments=False, separator=' ')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]


# Generated at 2022-06-17 18:35:50.925962
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0
    assert r[-23] == 0
    assert r[-24] == 0
    assert r

# Generated at 2022-06-17 18:36:03.564619
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:2] == [1, 2]
    assert r[2:4] == [3, 4]
    assert r[4:6] == [5, 6]
    assert r[-1:-3] == []
    assert r[-3:-1] == [8, 9]
    assert r[-5:-3] == [6, 7]
    assert r[0:2:2] == [1]
    assert r[2:4:2] == [3]

# Generated at 2022-06-17 18:36:13.313527
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:2] == [0, 1]
    assert lst[2:4] == [2, 3]
    assert lst[-3:] == [7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]

# Generated at 2022-06-17 18:36:23.314357
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:36:55.247925
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:37:06.015428
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:37:18.295753
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[1:3] == [2, 3]
    assert r[1:6:2] == [2, 4, 6]
    assert r[1:6:3] == [2, 5]
    assert r[1:6:4] == [2, 6]
    assert r[1:6:5] == [2]
    assert r[1:6:6] == []
    assert r[1:6:7] == []
    assert r[1:6:8] == []

# Generated at 2022-06-17 18:37:24.361341
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    c = [3, 4, 5, 6, 7]
    d = [4, 5, 6, 7, 8]
    e = [5, 6, 7, 8, 9]
    f = [6, 7, 8, 9, 10]
    g = [7, 8, 9, 10, 11]
    h = [8, 9, 10, 11, 12]
    i = [9, 10, 11, 12, 13]
    j = [10, 11, 12, 13, 14]
    k = [11, 12, 13, 14, 15]
    l = [12, 13, 14, 15, 16]
    m = [13, 14, 15, 16, 17]