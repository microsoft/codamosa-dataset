

# Generated at 2022-06-17 18:27:50.882413
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:27:59.542350
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:28:09.313940
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(1, range(10))) == [0]
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(100, range(10))) == list(range(10))
    assert list(take(0, [])) == []
    assert list(take(1, [])) == []
    assert list(take(5, [])) == []
    assert list(take(10, [])) == []
    assert list(take(100, [])) == []
    assert list(take(0, [1, 2, 3])) == []

# Generated at 2022-06-17 18:28:20.819834
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:28:30.994398
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(-1, range(1000000))) == []
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(5, [])) == []
    assert list(take(5, ())) == []
    assert list(take(5, [1, 2, 3])) == [1, 2, 3]
    assert list(take(5, (1, 2, 3))) == [1, 2, 3]
    assert list(take(5, {1, 2, 3})) == [1, 2, 3]

# Generated at 2022-06-17 18:28:40.586579
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    assert next(r) == 10
    try:
        next(r)
    except StopIteration:
        pass
    else:
        raise AssertionError("StopIteration not raised")

# Generated at 2022-06-17 18:28:54.644250
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:29:05.781368
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:29:16.865272
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:29:29.138188
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:29:54.381668
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:30:05.687870
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:12] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:0] == []

# Generated at 2022-06-17 18:30:10.763614
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(10, range(10))) == []
    assert list(drop(100, range(10))) == []
    assert list(drop(-1, range(10))) == []



# Generated at 2022-06-17 18:30:17.755414
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    import bisect
    for _ in range(100):
        a = [random.randint(0, 100) for _ in range(100)]
        b = [random.randint(0, 100) for _ in range(100)]
        for i in range(100):
            pos = bisect.bisect_left(MapList(lambda x: x * x, a), i)
            assert pos == bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), i)


# Generated at 2022-06-17 18:30:22.519117
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:3] == [1, 4]


# Generated at 2022-06-17 18:30:33.969727
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(10))) == [3, 4, 5, 6, 7, 8, 9]
    assert list(drop(0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop(10, range(10))) == []
    assert list(drop(100, range(10))) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(100, [])) == []
    assert list(drop(0, [1, 2, 3])) == [1, 2, 3]
    assert list(drop(1, [1, 2, 3])) == [2, 3]

# Generated at 2022-06-17 18:30:41.209897
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))

# Generated at 2022-06-17 18:30:54.393658
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:31:04.879656
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    assert MapList(lambda x: x * x, a)[0] == 1
    assert MapList(lambda x: x * x, a)[2] == 9
    assert MapList(lambda x: x * x, a)[-1] == 25
    assert MapList(lambda x: x * x, a)[1:3] == [4, 9]
    assert MapList(lambda x: x * x, a)[1:4:2] == [4, 16]
    assert MapList(lambda x: x * x, a)[::-1] == [25, 16, 9, 4, 1]
    assert MapList(lambda x: x * x, a)[::-2] == [25, 9, 1]

# Generated at 2022-06-17 18:31:10.583858
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:31:22.079250
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zba', 'zcba', 'zdcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [])) == []

# Generated at 2022-06-17 18:31:31.587625
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:5] == [1, 2, 3, 4, 5]
    assert r[:5] == [1, 2, 3, 4, 5]
    assert r[5:] == [6, 7, 8, 9, 10]
    assert r[::2] == [1, 3, 5, 7, 9]
    assert r[::-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]

# Generated at 2022-06-17 18:31:42.621675
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[1:4] == [1, 2, 3]
    assert lst[1:5] == [1, 2, 3, 4]

# Generated at 2022-06-17 18:31:48.614844
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    import string
    import itertools
    import operator
    from functools import reduce
    from collections import Counter

    def random_string(length: int) -> str:
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def random_list(length: int) -> List[str]:
        return [random_string(random.randint(1, 10)) for _ in range(length)]

    def random_iterable(length: int) -> Iterable[str]:
        return iter(random_list(length))

    def random_lazy_list(length: int) -> LazyList[str]:
        return LazyList(random_iterable(length))


# Generated at 2022-06-17 18:31:58.626530
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    assert m[0] == 1
    assert m[1] == 4
    assert m[2] == 9
    assert m[3] == 16
    assert m[4] == 25
    assert m[-1] == 25
    assert m[-2] == 16
    assert m[-3] == 9
    assert m[-4] == 4
    assert m[-5] == 1
    assert m[:] == [1, 4, 9, 16, 25]
    assert m[1:3] == [4, 9]
    assert m[:3] == [1, 4, 9]
    assert m[1:] == [4, 9, 16, 25]

# Generated at 2022-06-17 18:32:10.280748
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [])) == []
    assert list(scanl(operator.add, [1, 2, 3, 4], initial=0)) == [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [], initial=0)) == [0]

# Generated at 2022-06-17 18:32:21.214812
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:33.426262
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10, 2)
    assert r[0] == 1
    assert r[1] == 3
    assert r[2] == 5
    assert r[-1] == 9
    assert r[-2] == 7
    assert r[-3] == 5
    assert r[-4] == 3
    assert r[-5] == 1
    assert r[-6] == -1
    assert r[-7] == -3
    assert r[-8] == -5
    assert r[-9] == -7
    assert r[-10] == -9
    assert r[-11] == -11
    assert r[-12] == -13
    assert r[-13] == -15
    assert r[-14] == -17
    assert r[-15] == -19


# Generated at 2022-06-17 18:32:43.473366
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:55.325927
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[1:3] == [1, 2]
    assert lst[1:3] == [1, 2]
    assert lst[1:3] == [1, 2]
    assert lst[1:3] == [1, 2]
    assert lst[1:3] == [1, 2]
    assert lst[1:3] == [1, 2]
    assert lst[1:3] == [1, 2]
    assert lst[1:3] == [1, 2]
    assert lst[1:3] == [1, 2]
    assert lst[1:3] == [1, 2]

# Generated at 2022-06-17 18:33:07.817251
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:20.488611
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]

# Generated at 2022-06-17 18:33:27.521718
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[3:7] == [3, 4, 5, 6]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]

# Generated at 2022-06-17 18:33:38.763864
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[5:8] == [5, 6, 7]
    assert lst[5:8:2] == [5, 7]
    assert lst[5:8:-2] == []
    assert lst[5:8:-1] == []
    assert lst[5:8:1] == [5, 6, 7]
    assert lst[5:8:0] == []
    assert lst[5:8:None] == [5, 6, 7]
    assert lst[5:8:1.0] == [5, 6, 7]
    assert lst[5:8:1.1] == [5, 6, 7]
    assert l

# Generated at 2022-06-17 18:33:49.991089
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    import string
    import time
    import unittest

    class TestCase(unittest.TestCase):
        def test_getitem(self):
            def gen_random_string(length: int) -> str:
                return ''.join(random.choice(string.ascii_letters) for _ in range(length))

            def gen_random_strings(n: int, min_length: int, max_length: int) -> Iterator[str]:
                for _ in range(n):
                    yield gen_random_string(random.randint(min_length, max_length))


# Generated at 2022-06-17 18:34:02.690205
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:34:14.479274
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:34:16.971363
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect
    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert pos == 3
    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2


# Generated at 2022-06-17 18:34:24.812102
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, range(5, 10))) == [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5, 6))) == []
    assert list(drop_until(lambda x: x > 5, range(5, 5))) == []
    assert list(drop_until(lambda x: x > 5, range(5, 4))) == []
    assert list(drop_until(lambda x: x > 5, range(5, 3))) == []

# Generated at 2022-06-17 18:34:35.001679
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:44.159082
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    assert m[0] == 1
    assert m[-1] == 25
    assert m[1:3] == [4, 9]
    assert m[::-1] == [25, 16, 9, 4, 1]
    assert m[::2] == [1, 9, 25]
    assert m[1:4:2] == [4, 16]
    assert m[::-2] == [25, 9, 1]
    assert m[1:4:-2] == []
    assert m[4:1:-2] == [16, 4]
    assert m[4:0:-2] == [16, 4]
    assert m[4:-1:-2] == []
   

# Generated at 2022-06-17 18:34:57.149894
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:2] == [1, 2]
    assert r[2:4] == [3, 4]
    assert r[4:6] == [5, 6]
    assert r[-1:-3] == []
    assert r[-3:-1] == [8, 9]
    assert r[-5:-3] == [6, 7]
    assert r[0:10:2] == [1, 3, 5, 7, 9]

# Generated at 2022-06-17 18:35:09.633459
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import operator
    import random
    from itertools import count
    from typing import List, Tuple

    def test_case(lst: List[int], idx: int, expected: int) -> None:
        lst = LazyList(lst)
        assert lst[idx] == expected

    def test_case_slice(lst: List[int], idx: slice, expected: List[int]) -> None:
        lst = LazyList(lst)
        assert lst[idx] == expected

    def test_case_slice_random(lst: List[int], idx: slice, expected: List[int]) -> None:
        lst = LazyList(lst)
        assert lst[idx] == expected


# Generated at 2022-06-17 18:35:21.646300
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[0:3] == [0, 1, 2]
    assert r[2:5] == [2, 3, 4]
    assert r[-3:-1] == [7, 8]
    assert r[-3:0] == []
    assert r[-3:1] == [7]
    assert r[-3:2] == [7, 8]
    assert r[-3:3] == [7, 8, 9]
    assert r[-3:4] == [7, 8, 9]

# Generated at 2022-06-17 18:35:29.912793
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[3] == 3
    assert lst[4] == 4
    assert lst[5] == 5
    assert lst[6] == 6
    assert lst[7] == 7
    assert lst[8] == 8
    assert lst[9] == 9
    assert lst[10] == 10
    assert lst[11] == 11
    assert lst[12] == 12
    assert lst[13] == 13
    assert lst[14] == 14
    assert lst[15] == 15
    assert lst[16] == 16
    assert lst[17] == 17

# Generated at 2022-06-17 18:35:41.559073
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:54.940676
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[0:3] == [0, 1, 2]
    assert r[:3] == [0, 1, 2]
    assert r[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert r[3:10] == [3, 4, 5, 6, 7, 8, 9]
    assert r[3:10:2] == [3, 5, 7, 9]
    assert r[3:10:3] == [3, 6, 9]
    assert r[3:10:4] == [3, 7]

# Generated at 2022-06-17 18:36:06.064357
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[3] == 3
    assert lst[4] == 4
    assert lst[5] == 5
    assert lst[6] == 6
    assert lst[7] == 7
    assert lst[8] == 8
    assert lst[9] == 9
    assert lst[10] == 10
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3

# Generated at 2022-06-17 18:36:14.497649
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(6))) == [6]
    assert list(drop_until(lambda x: x > 5, range(7))) == [6, 7]
    assert list(drop_until(lambda x: x > 5, range(8))) == [6, 7, 8]
    assert list(drop_until(lambda x: x > 5, range(9))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]

# Generated at 2022-06-17 18:36:20.033542
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from itertools import count
    from bisect import bisect_left
    from operator import add
    from functools import reduce
    from typing import List, Callable, Iterable, Iterator, Sequence, Tuple, TypeVar, Generic, overload
    from collections.abc import Sequence
    from weakref import WeakKeyDictionary
    from typing import TypeVar, Generic, Callable, Iterable, Iterator, Sequence, List, overload
    from collections.abc import Sequence
    from functools import reduce
    from operator import add
    from random import randint
    from itertools import count
    from bisect import bisect_left
    from typing import List, Callable, Iterable, Iterator, Sequence, Tuple, TypeVar, Generic, overload
    from collections.abc import Sequence
    from weakref import WeakKeyDictionary

# Generated at 2022-06-17 18:36:36.936831
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    assert m[0] == 1
    assert m[1] == 4
    assert m[2] == 9
    assert m[3] == 16
    assert m[4] == 25
    assert m[-1] == 25
    assert m[-2] == 16
    assert m[-3] == 9
    assert m[-4] == 4
    assert m[-5] == 1
    assert m[:] == [1, 4, 9, 16, 25]
    assert m[1:3] == [4, 9]
    assert m[1:4:2] == [4, 16]
    assert m[::-1] == [25, 16, 9, 4, 1]


# Generated at 2022-06-17 18:36:48.379792
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[1:5] == [2, 3, 4, 5]
    assert r[1:5:2] == [2, 4]
    assert r[5:1:-1] == [6, 5, 4, 3]
    assert r[5:1:-2] == [6, 4]
    assert r[5::-2] == [6, 4, 2]
    assert r[:5] == [1, 2, 3, 4, 5]
    assert r[5:] == [6, 7, 8, 9, 10]

# Generated at 2022-06-17 18:36:58.303354
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:37:07.608119
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[3] == 3
    assert lst[4] == 4
    assert lst[5] == 5
    assert lst[6] == 6
    assert lst[7] == 7
    assert lst[8] == 8
    assert lst[9] == 9
    assert lst[10] == 10
    assert lst[11] == 11
    assert lst[12] == 12
    assert lst[13] == 13
    assert lst[14] == 14
    assert lst[15] == 15
    assert lst[16] == 16
    assert lst[17] == 17

# Generated at 2022-06-17 18:37:14.436047
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-1] == 25
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:3] == [4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:-1] == [4, 9, 16]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[:-1] == [1, 4, 9, 16]
   

# Generated at 2022-06-17 18:37:25.404632
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(6))) == [6]
    assert list(drop_until(lambda x: x > 5, range(7))) == [6, 7]
    assert list(drop_until(lambda x: x > 5, range(8))) == [6, 7, 8]
    assert list(drop_until(lambda x: x > 5, range(9))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]

