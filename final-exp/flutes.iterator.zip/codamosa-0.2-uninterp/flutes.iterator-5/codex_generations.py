

# Generated at 2022-06-17 18:27:45.433345
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    assert next(r) == 10
    with pytest.raises(StopIteration):
        next(r)

# Generated at 2022-06-17 18:27:54.229313
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:27:59.587604
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    assert next(r) == 10
    try:
        next(r)
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-17 18:28:09.313654
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10

# Generated at 2022-06-17 18:28:11.632414
# Unit test for method __next__ of class Range
def test_Range___next__():
    # Test for method __next__ (line 605)
    r = Range(0, 10)
    for i in range(10):
        assert r.__next__() == i
    try:
        r.__next__()
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-17 18:28:18.107464
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:28:29.942415
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList(range(10))
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10
    assert len(a) == 10

# Generated at 2022-06-17 18:28:41.568146
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    import bisect
    for _ in range(100):
        a = [random.randint(0, 100) for _ in range(10)]
        a.sort()
        for i in range(10):
            assert bisect.bisect_left(MapList(lambda x: x * x, a), i * i) == i
        for i in range(10):
            assert bisect.bisect_left(MapList(lambda x: x * x, a), i * i + 1) == i + 1
        for i in range(10):
            assert bisect.bisect_left(MapList(lambda x: x * x, a), i * i + 2) == i + 1

# Generated at 2022-06-17 18:28:55.203278
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[1:4] == [2, 3, 4]
    assert r[1:4:2] == [2, 4]
    assert r[4:1:-1] == [5, 4, 3]
    assert r[4:1:-2] == [5, 3]
    assert r[::-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
    assert r[::-2] == [10, 8, 6, 4, 2]

# Generated at 2022-06-17 18:29:05.292779
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(20, range(10))) == []
    assert list(drop(-1, range(10))) == []
    assert list(drop(-10, range(10))) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(10, [])) == []
    assert list(drop(-1, [])) == []
    assert list(drop(-10, [])) == []



# Generated at 2022-06-17 18:29:37.969656
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:29:47.166366
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]

# Generated at 2022-06-17 18:30:00.339368
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:30:12.603012
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(5, range(2))) == [0, 1]
    assert list(take(5, range(0))) == []
    assert list(take(5, range(-1))) == []
    assert list(take(5, range(-2))) == []
    assert list(take(5, range(-3))) == []
    assert list(take(5, range(-4))) == []
    assert list(take(5, range(-5))) == []
    assert list(take(5, range(-6))) == []
    assert list(take(5, range(-7))) == []
    assert list(take(5, range(-8))) == []
    assert list

# Generated at 2022-06-17 18:30:21.358555
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:30:32.801683
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[1:5] == [1, 2, 3, 4]
    assert r[2:5] == [2, 3, 4]
    assert r[3:5] == [3, 4]
   

# Generated at 2022-06-17 18:30:44.777442
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    from itertools import count
    from typing import List

    def test_case(lst: List[int], idx: int) -> None:
        lst_lazy = LazyList(lst)
        assert lst_lazy[idx] == lst[idx]
        assert lst_lazy[idx:] == lst[idx:]

    for _ in range(100):
        lst = [random.randint(0, 100) for _ in range(random.randint(0, 100))]
        idx = random.randint(0, len(lst))
        test_case(lst, idx)

    lst_lazy = LazyList(count())
    assert lst_lazy[:10] == list(range(10))
    assert lst_

# Generated at 2022-06-17 18:30:51.603478
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[:5] == [1, 2, 3, 4, 5]
    assert r[2:5] == [3, 4, 5]
    assert r[2:5:2] == [3, 5]
    assert r[-5:-2] == [6, 7, 8]
    assert r[-5:-2:2] == [6, 8]
    assert r[-5::2] == [6, 8, 10]
    assert r[::2] == [1, 3, 5, 7, 9]

# Generated at 2022-06-17 18:31:04.165195
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:31:15.684784
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]
    assert lst[::-4] == [9, 5, 1]
   

# Generated at 2022-06-17 18:31:31.175619
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:31:42.271945
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:31:48.274696
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [])) == []
    assert list(scanl(operator.add, [1, 2, 3, 4], initial=0)) == [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [], initial=0)) == [0]

# Generated at 2022-06-17 18:31:58.025961
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:3] == [1, 2, 3]
    assert r[0:6:2] == [1, 3, 5]
    assert r[-1:-6:-2] == [10, 8, 6]
    assert r[-1:0:-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2]
    assert r[-1:0:-2] == [10, 8, 6, 4, 2]

# Generated at 2022-06-17 18:32:09.507166
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:20.584784
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zab', 'zabc', 'zabcd']
    assert list(scanl(lambda s, x: x + s, [])) == []
    assert list(scanl(lambda s, x: x + s, [], 'z')) == ['z']

# Generated at 2022-06-17 18:32:24.611020
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-17 18:32:36.657356
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[:5] == [1, 2, 3, 4, 5]
    assert r[5:] == [6, 7, 8, 9, 10]
    assert r[1:5] == [2, 3, 4, 5]
    assert r[1:5:2] == [2, 4]
    assert r[5:1:-2] == [6, 4]
    assert r[::-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]

# Generated at 2022-06-17 18:32:45.592507
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:32:57.528525
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zba', 'zcba', 'zdcba']
    assert list(scanl(lambda s, x: x + s, [])) == []
    assert list(scanl(lambda s, x: x + s, [], 'z')) == ['z']

# Generated at 2022-06-17 18:33:21.229550
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[3] == 3
    assert lst[4] == 4
    assert lst[5] == 5
    assert lst[6] == 6
    assert lst[7] == 7
    assert lst[8] == 8
    assert lst[9] == 9
    assert lst[10] == 10
    assert lst[11] == 11
    assert lst[12] == 12
    assert lst[13] == 13
    assert lst[14] == 14
    assert lst[15] == 15
    assert lst[16] == 16
    assert lst[17] == 17

# Generated at 2022-06-17 18:33:28.074194
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[1:5] == [1, 2, 3, 4]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]

# Generated at 2022-06-17 18:33:39.217780
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:49.227485
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zab', 'zabc', 'zabcd']



# Generated at 2022-06-17 18:33:53.888030
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []



# Generated at 2022-06-17 18:34:01.888669
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[12] == 0
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:34:11.174375
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [])) == []
    assert list(scanl(operator.add, [], 0)) == [0]
    assert list(scanl(operator.add, [], 1, 2, 3)) == [1]
    assert list(scanl(operator.add, [1], 2, 3)) == [1]

# Generated at 2022-06-17 18:34:21.519308
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:32.428836
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(10))
    assert l[0] == 0
    assert l[1] == 1
    assert l[2] == 2
    assert l[-1] == 9
    assert l[-2] == 8
    assert l[-3] == 7
    assert l[-4] == 6
    assert l[-5] == 5
    assert l[-6] == 4
    assert l[-7] == 3
    assert l[-8] == 2
    assert l[-9] == 1
    assert l[-10] == 0
    assert l[-11] == 0
    assert l[-12] == 0
    assert l[-13] == 0
    assert l[-14] == 0
    assert l[-15] == 0
    assert l[-16] == 0


# Generated at 2022-06-17 18:34:42.642276
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:34:58.019392
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:10.629516
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:23.089325
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[-1:] == [9]
    assert lst[-2:] == [8, 9]


# Generated at 2022-06-17 18:35:29.008319
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zab', 'zabc', 'zabcd']



# Generated at 2022-06-17 18:35:40.970608
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:54.827995
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:05.979356
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:2] == [1, 2]
    assert r[2:4] == [3, 4]
    assert r[4:6] == [5, 6]
    assert r[-1:-3] == []
    assert r[-3:-1] == [8, 9]
    assert r[-5:-3] == [6, 7]
    assert r[0:10:2] == [1, 3, 5, 7, 9]

# Generated at 2022-06-17 18:36:14.430023
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:36:24.882214
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:35.393971
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:54.571083
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[0:10] == list(range(10))
    assert lst[0:5] == list(range(5))

# Generated at 2022-06-17 18:37:05.219103
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:37:16.949986
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:37:24.047884
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(6))) == [6]
    assert list(drop_until(lambda x: x > 5, range(7))) == [6, 7]
    assert list(drop_until(lambda x: x > 5, range(8))) == [6, 7, 8]
    assert list(drop_until(lambda x: x > 5, range(9))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]

