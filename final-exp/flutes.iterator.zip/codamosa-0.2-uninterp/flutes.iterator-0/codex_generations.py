

# Generated at 2022-06-17 18:27:59.369836
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:28:08.597025
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:28:15.710915
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(1))) == [0]
    assert list(take(5, range(0))) == []
    assert list(take(5, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(6))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(7))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(8))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(9))) == [0, 1, 2, 3, 4]

# Generated at 2022-06-17 18:28:26.497679
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:2] == [1, 2]
    assert r[2:4] == [3, 4]
    assert r[4:6] == [5, 6]
    assert r[-1:-3:-1] == [10, 9]
    assert r[-3:-5:-1] == [8, 7]
    assert r[-5:-7:-1] == [6, 5]
    assert r[0:2:2] == [1]
    assert r[2:4:2] == [3]
   

# Generated at 2022-06-17 18:28:29.224765
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5


# Generated at 2022-06-17 18:28:41.360910
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    try:
        list(split_by(" Split by: ", empty_segments=True))
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError")
    try:
        list(split_by(" Split by: ", criterion=lambda x: x == '.', separator='.'))
    except ValueError:
        pass

# Generated at 2022-06-17 18:28:55.163541
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:28:57.472255
# Unit test for method __len__ of class Range
def test_Range___len__():
    assert len(Range(10)) == 10
    assert len(Range(1, 10 + 1)) == 10
    assert len(Range(1, 11, 2)) == 5


# Generated at 2022-06-17 18:29:00.027423
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(-1, range(1000000))) == []



# Generated at 2022-06-17 18:29:11.994103
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:29:44.205847
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[-1:-3:-1] == [9, 8]

# Generated at 2022-06-17 18:29:51.640905
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect
    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert pos == 3
    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2


# Generated at 2022-06-17 18:30:03.125662
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:30:07.589307
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:2] == [1, 2]
    assert r[2:4] == [3, 4]
    assert r[4:6] == [5, 6]
    assert r[-1:-3] == []
    assert r[-3:-1] == [8, 9]
    assert r[-5:-3] == [6, 7]
    assert r[0:2:2] == [1]
    assert r[2:4:2] == [3]

# Generated at 2022-06-17 18:30:17.332004
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))

# Generated at 2022-06-17 18:30:23.738850
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(10))) == list(range(10))
    assert list(LazyList(range(10)).__iter__()) == list(range(10))
    assert list(LazyList(range(10)).__iter__()) == list(range(10))
    assert list(LazyList(range(10)).__iter__()) == list(range(10))

# Generated at 2022-06-17 18:30:35.055211
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert lst[:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert lst[:20] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:30:47.396335
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:30:55.704916
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect
    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert pos == 3
    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2


# Generated at 2022-06-17 18:31:05.521990
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[0] == 0
    assert Range(10)[-1] == 9
    assert Range(10)[2] == 2
    assert Range(10)[-3] == 7
    assert Range(10)[:3] == [0, 1, 2]
    assert Range(10)[:0] == []
    assert Range(10)[:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert Range(10)[:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert Range(10)[:20] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert Range(10)[3:] == [3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:31:17.154052
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(10))) == list(range(3, 10))
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(-1, range(10))) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(10, [])) == []



# Generated at 2022-06-17 18:31:26.328748
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    assert MapList(lambda x: x * x, a)[0] == 1
    assert MapList(lambda x: x * x, a)[2] == 9
    assert MapList(lambda x: x * x, a)[4] == 25
    assert MapList(lambda i: a[i] * b[i], Range(len(a)))[0] == 2
    assert MapList(lambda i: a[i] * b[i], Range(len(a)))[2] == 12
    assert MapList(lambda i: a[i] * b[i], Range(len(a)))[4] == 30
    assert MapList(lambda x: x * x, a)[0:2] == [1, 4]


# Generated at 2022-06-17 18:31:33.675727
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]
    assert lst[::-4] == [9, 5, 1]
   

# Generated at 2022-06-17 18:31:44.040296
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:31:56.124118
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(0, [1, 2, 3])) == [1, 2, 3]
    assert list(drop(1, [1, 2, 3])) == [2, 3]
    assert list(drop(2, [1, 2, 3])) == [3]
    assert list(drop(3, [1, 2, 3])) == []

# Generated at 2022-06-17 18:32:05.800273
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:4] == [0, 4, 8]
    assert r[0:10:5] == [0, 5]

# Generated at 2022-06-17 18:32:17.730254
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Test for method __getitem__ of class MapList
    # Tests for indexing
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    m = MapList(lambda i: a[i] * b[i], Range(len(a)))
    assert m[0] == 2
    assert m[1] == 6
    assert m[2] == 12
    assert m[3] == 20
    assert m[4] == 30
    assert m[-1] == 30
    assert m[-2] == 20
    assert m[-3] == 12
    assert m[-4] == 6
    assert m[-5] == 2
    assert m[0:2] == [2, 6]

# Generated at 2022-06-17 18:32:28.461391
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[12] == 0
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:12] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r

# Generated at 2022-06-17 18:32:32.445815
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2:4] == [9, 16]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-1] == 25
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-2:] == [16, 25]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[::-1] == [25, 16, 9, 4, 1]

# Generated at 2022-06-17 18:32:42.910228
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[12] == 0
    assert r[0:1] == [0]
    assert r[0:2] == [0, 1]
    assert r[0:3] == [0, 1, 2]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
   

# Generated at 2022-06-17 18:32:58.761364
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[-3:] == [7, 8, 9]
    assert lst[-3:-1] == [7, 8]
    assert lst[-3:1] == [7, 8]
    assert lst[-3:0] == []
    assert lst[-3:-3] == []
    assert lst[-3:-4] == []
    assert lst[-3:-5] == []


# Generated at 2022-06-17 18:33:09.793110
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]
    assert lst[::-4] == [9, 5, 1]
   

# Generated at 2022-06-17 18:33:21.308928
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:28.127884
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert lst[0] == 1
    assert lst[2] == 9
    assert lst[-1] == 25
    assert lst[1:3] == [4, 9]
    assert lst[2:] == [9, 16, 25]
    assert lst[:2] == [1, 4]
    assert lst[::2] == [1, 9, 25]
    assert lst[::-1] == [25, 16, 9, 4, 1]
    assert lst[::-2] == [25, 9, 1]
    assert lst[::-3] == [25, 4]
    assert lst[::-4] == [25]

# Generated at 2022-06-17 18:33:34.945040
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2:4] == [9, 16]


# Generated at 2022-06-17 18:33:42.207791
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[0:10] == list(range(10))
    assert lst[0:9] == list(range(9))

# Generated at 2022-06-17 18:33:51.070747
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, range(5, 10))) == [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5, 6))) == [5]
    assert list(drop_until(lambda x: x > 5, range(5, 5))) == []
    assert list(drop_until(lambda x: x > 5, range(5, 4))) == []



# Generated at 2022-06-17 18:34:02.903670
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:4] == [0, 4, 8]

# Generated at 2022-06-17 18:34:11.913806
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    from itertools import count

    def random_int_generator():
        while True:
            yield random.randint(0, 100)

    def random_int_generator_with_stop():
        for i in count():
            if i == 100:
                break
            yield random.randint(0, 100)

    def random_int_generator_with_stop_at_end():
        for i in count():
            if i == 100:
                break
            yield random.randint(0, 100)
        yield random.randint(0, 100)

    def random_int_generator_with_stop_at_end_and_start():
        for i in count():
            if i == 100:
                break
            yield random.randint(0, 100)

# Generated at 2022-06-17 18:34:21.965172
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(4))) == []
    assert list(drop_until(lambda x: x > 5, range(3))) == []
    assert list(drop_until(lambda x: x > 5, range(2))) == []
    assert list(drop_until(lambda x: x > 5, range(1))) == []
    assert list(drop_until(lambda x: x > 5, range(0))) == []

# Generated at 2022-06-17 18:34:36.145655
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:34:45.179445
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]

# Generated at 2022-06-17 18:34:57.599509
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:10.275196
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:16.983463
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[-11] == 0
    assert lst[-12] == 0
    assert lst[-13] == 0
    assert lst[-14] == 0
    assert lst[-15] == 0
   

# Generated at 2022-06-17 18:35:27.196835
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:32.761250
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    for _ in range(100):
        lst = [random.randint(0, 100) for _ in range(random.randint(0, 100))]
        m = MapList(lambda x: x * x, lst)
        for i in range(len(lst)):
            assert m[i] == lst[i] * lst[i]
        for i in range(len(lst)):
            assert m[i:i + 1] == [lst[i] * lst[i]]
        for i in range(len(lst)):
            assert m[i:i + random.randint(1, len(lst) - i)] == [x * x for x in lst[i:i + random.randint(1, len(lst) - i)]]

# Generated at 2022-06-17 18:35:45.177503
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[0:3] == [0, 1, 2]
    assert lst[-3:] == [7, 8, 9]
    assert lst[-3:-1] == [7, 8]
    assert lst[-3:0] == []
    assert lst[-3:1] == [7]
    assert lst[-3:2] == [7, 8]
    assert lst[-3:3] == [7, 8, 9]
    assert lst[-3:4] == [7, 8, 9]

# Generated at 2022-06-17 18:35:56.469320
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:07.105653
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:25.681890
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[2:5] == [2, 3, 4]
    assert lst[-5:-2] == [5, 6, 7]
    assert lst[-5:] == [5, 6, 7, 8, 9]
    assert lst[-5:5] == [5, 6, 7, 8, 9]
    assert lst[-5:4] == [5, 6, 7, 8]
   

# Generated at 2022-06-17 18:36:36.024556
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:36:47.247917
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-4] == 6
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[0:2] == [0, 1]
    assert r[2:4] == [2, 3]
    assert r[4:6] == [4, 5]
    assert r[-1:-3] == [9, 8]
    assert r[-3:-5] == [7, 6]
    assert r[-5:-7] == [5, 4]
    assert r[-10:-12] == [0, 1]

# Generated at 2022-06-17 18:36:57.562520
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:37:04.176973
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-4] == 6
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:37:16.210575
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:37:23.624909
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-4] == 6
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0