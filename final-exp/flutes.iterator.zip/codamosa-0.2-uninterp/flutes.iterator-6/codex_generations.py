

# Generated at 2022-06-17 18:27:47.731632
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    try:
        list(split_by(" Split by: ", empty_segments=True, criterion=lambda x: x == '.', separator='.'))
        assert False
    except ValueError:
        pass
    try:
        list(split_by(" Split by: ", empty_segments=True))
        assert False
    except ValueError:
        pass



# Generated at 2022-06-17 18:27:58.490354
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(2, [])) == []
    assert list(drop(0, [1])) == [1]
    assert list(drop(1, [1])) == []
    assert list(drop(2, [1])) == []
    assert list(drop(0, [1, 2])) == [1, 2]
    assert list(drop(1, [1, 2])) == [2]
   

# Generated at 2022-06-17 18:28:08.693797
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:2] == [1, 2]
    assert r[2:4] == [3, 4]
    assert r[4:6] == [5, 6]
    assert r[-1:-3] == [10, 9]
    assert r[-3:-5] == [8, 7]
    assert r[-5:-7] == [6, 5]
    assert r[0:2:2] == [1]
    assert r[2:4:2] == [3]

# Generated at 2022-06-17 18:28:20.667734
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:28:30.915393
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(5, [])) == []
    assert list(take(5, [1, 2, 3])) == [1, 2, 3]
    assert list(take(5, [1, 2, 3, 4, 5, 6])) == [1, 2, 3, 4, 5]
    assert list(take(5, [1, 2, 3, 4, 5, 6, 7])) == [1, 2, 3, 4, 5]
    assert list(take(5, [1, 2, 3, 4, 5, 6, 7, 8])) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 18:28:42.486288
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(5, [])) == []
    assert list(take(5, [1, 2, 3])) == [1, 2, 3]
    assert list(take(5, [1, 2, 3, 4, 5, 6])) == [1, 2, 3, 4, 5]
    assert list(take(5, [1, 2, 3, 4, 5, 6, 7])) == [1, 2, 3, 4, 5]
    assert list(take(5, [1, 2, 3, 4, 5, 6, 7, 8])) == [1, 2, 3, 4, 5]

# Generated at 2022-06-17 18:28:55.521998
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    assert len(lst) == 10
    assert lst[0] == 0
    assert len(lst) == 10
    assert lst[1] == 1
    assert len(lst) == 10
    assert lst[2] == 2
    assert len(lst) == 10
    assert lst[3] == 3
    assert len(lst) == 10
    assert lst[4] == 4
    assert len(lst) == 10
    assert lst[5] == 5
    assert len(lst) == 10
    assert lst[6] == 6
    assert len(lst) == 10
    assert lst[7] == 7
    assert len(lst) == 10
    assert lst[8] == 8

# Generated at 2022-06-17 18:29:06.917504
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))

# Generated at 2022-06-17 18:29:17.831301
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(5, range(3))) == list(range(3))
    assert list(drop(3, range(3))) == list(range(3))
    assert list(drop(0, range(3))) == list(range(3))
    assert list(drop(1, range(3))) == list(range(1, 3))
    assert list(drop(2, range(3))) == list(range(2, 3))
    assert list(drop(3, range(3))) == []

# Generated at 2022-06-17 18:29:30.091783
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(10, range(10))) == []
    assert list(drop(100, range(10))) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(2, [])) == []
    assert list(drop(0, [1])) == [1]
    assert list(drop(1, [1])) == []
    assert list(drop(2, [1])) == []
    assert list(drop(0, [1, 2])) == [1, 2]

# Generated at 2022-06-17 18:30:16.260318
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-4] == 6
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:30:28.469773
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6])) == [6]
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7])) == [6, 7]
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7, 8])) == [6, 7, 8]

# Generated at 2022-06-17 18:30:38.405402
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:4] == [1, 4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-2:] == [16, 25]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-2:-1] == [16]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-2:-1:-1] == []
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-1:1:-1]

# Generated at 2022-06-17 18:30:49.193772
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(4))) == []
    assert list(drop_until(lambda x: x > 5, range(3))) == []
    assert list(drop_until(lambda x: x > 5, range(2))) == []
    assert list(drop_until(lambda x: x > 5, range(1))) == []
    assert list(drop_until(lambda x: x > 5, range(0))) == []

# Generated at 2022-06-17 18:30:57.095772
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:31:06.468290
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:31:16.993662
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:31:26.155551
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:31:37.772656
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:4] == [0, 4, 8]
    assert r[0:10:5] == [0, 5]

# Generated at 2022-06-17 18:31:46.580686
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zba', 'zcba', 'zdcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [])) == []

# Generated at 2022-06-17 18:32:07.267775
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(6))) == [6]
    assert list(drop_until(lambda x: x > 5, range(7))) == [6, 7]
    assert list(drop_until(lambda x: x > 5, range(8))) == [6, 7, 8]
    assert list(drop_until(lambda x: x > 5, range(9))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-17 18:32:19.002693
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:29.957286
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:41.429255
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:44.835348
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []



# Generated at 2022-06-17 18:32:51.556506
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[5:7] == [5, 6]
    assert lst[5:7:2] == [5]
    assert lst[7:5:-1] == [7, 6]
    assert lst[7:5:-2] == [7]
    assert lst[5:7:-1] == []
    assert lst[5:7:-2] == []

# Generated at 2022-06-17 18:33:01.316023
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:33:10.982118
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 10
    assert r[11] == 10
    assert r[0:10] == list(range(10))
    assert r[0:10:2] == list(range(0, 10, 2))
    assert r[-10:-1] == list(range(0, 9))
    assert r[-10:-1:2] == list(range(0, 9, 2))
    assert r[-10:10] == list(range(10))

# Generated at 2022-06-17 18:33:21.559261
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]

# Generated at 2022-06-17 18:33:26.402882
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    import bisect
    a = [random.randint(0, 10) for _ in range(10)]
    b = [random.randint(0, 10) for _ in range(10)]
    c = [random.randint(0, 10) for _ in range(10)]
    d = [random.randint(0, 10) for _ in range(10)]
    e = [random.randint(0, 10) for _ in range(10)]
    f = [random.randint(0, 10) for _ in range(10)]
    g = [random.randint(0, 10) for _ in range(10)]
    h = [random.randint(0, 10) for _ in range(10)]
    i = [random.randint(0, 10) for _ in range(10)]
   

# Generated at 2022-06-17 18:33:42.082572
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:55.003029
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[-1::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-17 18:33:59.630403
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:2] == [0, 1]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:0] == []
    assert r[0:1] == [0]
    assert r[0:0:1] == []
   

# Generated at 2022-06-17 18:34:06.017338
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:34:17.968451
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[0:3] == [0, 1, 2]
    assert lst[-3:] == [7, 8, 9]
    assert lst[-3:-1] == [7, 8]
    assert lst[-3:0] == []
    assert lst[-3:1] == [7]
    assert lst[-3:2] == [7, 8]
    assert lst[-3:3] == [7, 8, 9]
    assert lst[-3:4] == [7, 8, 9]

# Generated at 2022-06-17 18:34:22.102571
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    assert m[0] == 1
    assert m[1] == 4
    assert m[2] == 9
    assert m[3] == 16
    assert m[4] == 25
    assert m[-1] == 25
    assert m[-2] == 16
    assert m[-3] == 9
    assert m[-4] == 4
    assert m[-5] == 1
    assert m[0:2] == [1, 4]
    assert m[1:3] == [4, 9]
    assert m[2:4] == [9, 16]
    assert m[3:5] == [16, 25]

# Generated at 2022-06-17 18:34:32.877758
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[2:5] == [2, 3, 4]
    assert lst[-5:-2] == [5, 6, 7]
    assert lst[-5:] == [5, 6, 7, 8, 9]
    assert lst[-5:5] == [5, 6, 7, 8, 9]
    assert lst[-5:4] == [5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:34:43.004683
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[5] == 5
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0
    assert r[-30] == 0
    assert r[-31] == 0
    assert r[-32] == 0
    assert r[-40] == 0
    assert r[-41] == 0
    assert r[-42] == 0
    assert r[-50] == 0
    assert r[-51] == 0
    assert r[-52] == 0
    assert r

# Generated at 2022-06-17 18:34:56.782551
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[0:5] == [0, 1, 2, 3, 4]
    assert lst[5:10] == [5, 6, 7, 8, 9]
    assert lst[5:10:2] == [5, 7, 9]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]

# Generated at 2022-06-17 18:35:08.976917
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:13.674838
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[1::2] == [1, 3, 5, 7, 9]
    assert lst[5::-1] == [5, 4, 3, 2, 1, 0]

# Generated at 2022-06-17 18:36:23.700289
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-10] == 0
    assert lst[-11] == 0
    assert lst[-20] == 0
    assert lst[-100] == 0
    assert lst[0:1] == [0]
    assert lst[0:2] == [0, 1]
    assert lst[1:3] == [1, 2]
    assert lst[1:4] == [1, 2, 3]
    assert lst[1:5] == [1, 2, 3, 4]

# Generated at 2022-06-17 18:36:34.702384
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:44.760468
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:36:56.302734
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-2] == 9
    assert r[-4] == 7
    assert r[0:4] == [1, 2, 3, 4]
    assert r[0:4:2] == [1, 3]
    assert r[4:0:-1] == [5, 4, 3, 2]
    assert r[4:0:-2] == [5, 3]
    assert r[0:10:3] == [1, 4, 7, 10]
    assert r[1:10:3] == [2, 5, 8]

# Generated at 2022-06-17 18:37:06.879439
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    from itertools import count
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import lists

    @given(lists(integers()))
    def test_LazyList___getitem__(lst):
        lst = LazyList(lst)
        for i in range(len(lst)):
            assert lst[i] == lst[i]
        assert lst[:] == lst[:]
        assert lst[:len(lst)] == lst[:len(lst)]
        assert lst[:len(lst) + 1] == lst[:len(lst) + 1]
        assert lst[:len(lst) - 1] == lst[:len(lst) - 1]

# Generated at 2022-06-17 18:37:18.766244
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))