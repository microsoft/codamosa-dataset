

# Generated at 2022-06-17 18:27:55.982779
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3])
    assert len(lst) == 3
    lst = LazyList(range(1000000))
    assert len(lst) == 1000000
    lst = LazyList(range(1000000))
    assert len(lst) == 1000000
    lst = LazyList(range(1000000))
    assert len(lst) == 1000000
    lst = LazyList(range(1000000))
    assert len(lst) == 1000000
    lst = LazyList(range(1000000))
    assert len(lst) == 1000000
    lst = LazyList(range(1000000))
    assert len(lst) == 1000000
    lst = LazyList(range(1000000))
    assert len(lst) == 1000000

# Generated at 2022-06-17 18:28:03.416879
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(5, range(5))) == []
    assert list(drop(5, [])) == []
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(-5, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5, 10))



# Generated at 2022-06-17 18:28:11.465669
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:28:18.010285
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:28:24.693932
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(5, [])) == []
    assert list(take(0, [])) == []
    assert list(take(-1, range(1000000))) == []
    assert list(take(-1, [])) == []
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list

# Generated at 2022-06-17 18:28:35.068920
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(0))) == []
    assert list(chunk(0, range(10))) == []
    assert list(chunk(-1, range(10))) == []
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]


# Generated at 2022-06-17 18:28:40.497891
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []



# Generated at 2022-06-17 18:28:54.604498
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:29:05.731921
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:29:11.096807
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(-1, range(1000000))) == []
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(5, [])) == []


# Generated at 2022-06-17 18:29:37.199317
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    assert next(r) == 10
    try:
        next(r)
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-17 18:29:39.828429
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    assert MapList(lambda i: a[i] * b[i], Range(len(a)))[2] == 24
    assert MapList(lambda i: a[i] * b[i], Range(len(a)))[2:4] == [24, 40]


# Generated at 2022-06-17 18:29:46.321534
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    assert next(r) == 10
    try:
        next(r)
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-17 18:29:50.613761
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    for i in range(10):
        assert next(r) == i + 1
    try:
        next(r)
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-17 18:29:57.213487
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10, 2)
    assert next(r) == 1
    assert next(r) == 3
    assert next(r) == 5
    assert next(r) == 7
    assert next(r) == 9
    try:
        next(r)
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-17 18:30:07.618244
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:5] == [1, 2, 3, 4, 5]
    assert r[:5] == [1, 2, 3, 4, 5]
    assert r[5:] == [6, 7, 8, 9, 10]
    assert r[::2] == [1, 3, 5, 7, 9]
    assert r[::-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]

# Generated at 2022-06-17 18:30:15.612002
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[1:4] == [2, 3, 4]
    assert r[1:4:2] == [2, 4]
    assert r[4:1:-1] == [5, 4, 3]
    assert r[4:1:-2] == [5, 3]
    assert r[::-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
    assert r[::-2] == [10, 8, 6, 4, 2]

# Generated at 2022-06-17 18:30:28.219353
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:30:38.222776
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[3:5] == [3, 4]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]

# Generated at 2022-06-17 18:30:46.622273
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1, 10 + 1)
    assert next(r) == 1
    assert next(r) == 2
    assert next(r) == 3
    assert next(r) == 4
    assert next(r) == 5
    assert next(r) == 6
    assert next(r) == 7
    assert next(r) == 8
    assert next(r) == 9
    assert next(r) == 10
    try:
        next(r)
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-17 18:31:19.849802
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:31:22.504956
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-17 18:31:31.861468
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3, 4, 5])
    assert lst[0] == 1
    assert lst[1] == 2
    assert lst[-1] == 5
    assert lst[-2] == 4
    assert lst[2:4] == [3, 4]
    assert lst[:3] == [1, 2, 3]
    assert lst[3:] == [4, 5]
    assert lst[::2] == [1, 3, 5]
    assert lst[::-1] == [5, 4, 3, 2, 1]
    assert lst[::-2] == [5, 3, 1]
    assert lst[1:3:2] == [2]
    assert lst[1:3:-1] == []
    assert lst

# Generated at 2022-06-17 18:31:42.832943
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[0:5] == [0, 1, 2, 3, 4]
    assert lst[5:10] == [5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:31:48.801800
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:31:58.208301
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:5] == [1, 2, 3, 4, 5]
    assert r[0:5:2] == [1, 3, 5]
    assert r[5:0:-1] == [6, 5, 4, 3, 2]
    assert r[5:0:-2] == [6, 4, 2]
    assert r[5::-1] == [6, 5, 4, 3, 2, 1]
    assert r[5::-2] == [6, 4, 2]

# Generated at 2022-06-17 18:32:09.732771
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:20.753915
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 10
    assert r[11] == 10
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:4] == [0, 4, 8]
    assert r[0:10:5] == [0, 5]

# Generated at 2022-06-17 18:32:32.832635
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'x')) == ['x', 'xa', 'xab', 'xabc', 'xabcd']
    assert list(scanl(lambda s, x: x + s, [])) == []
    assert list(scanl(lambda s, x: x + s, [], 'x')) == ['x']

# Generated at 2022-06-17 18:32:37.666643
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []



# Generated at 2022-06-17 18:32:59.305452
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[12] == 0
    assert r[0:2] == [0, 1]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:33:10.202421
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))
    assert list(drop_until(lambda x: x > 5, range(10))) == list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:20.834036
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from random import randint
    from itertools import count
    for _ in range(1000):
        n = randint(0, 1000)
        lst = LazyList(count())
        for i in range(n):
            assert lst[i] == i
        assert lst[n] == n
        assert lst[n + 1] == n + 1
        assert lst[n + 2] == n + 2
        assert lst[n + 3] == n + 3
        assert lst[n + 4] == n + 4
        assert lst[n + 5] == n + 5
        assert lst[n + 6] == n + 6
        assert lst[n + 7] == n + 7
        assert lst[n + 8] == n + 8

# Generated at 2022-06-17 18:33:27.821670
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:33:39.001692
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:3] == [0, 1, 2]
    assert lst[3:6] == [3, 4, 5]
    assert lst[6:] == [6, 7, 8, 9]
    assert lst[:] == list(range(10))
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2


# Generated at 2022-06-17 18:33:50.069426
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:02.685767
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(0, 10, 2)
    assert r[0] == 0
    assert r[1] == 2
    assert r[-1] == 8
    assert r[-2] == 6
    assert r[0:2] == [0, 2]
    assert r[-2:-1] == [6]
    assert r[-2:2] == [6]
    assert r[-2:3] == [6, 8]
    assert r[-2:4] == [6, 8]
    assert r[-2:5] == [6, 8]
    assert r[-2:6] == [6, 8]
    assert r[-2:7] == [6, 8]
    assert r[-2:8] == [6, 8]

# Generated at 2022-06-17 18:34:14.471505
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:24.524688
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:34:34.779680
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:35:14.776428
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]
    assert lst[::-4] == [9, 5, 1]

# Generated at 2022-06-17 18:35:25.447442
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[0:3] == [0, 1, 2]
    assert lst[3:6] == [3, 4, 5]
    assert lst[6:9] == [6, 7, 8]
    assert lst[9:12] == [9]
    assert lst[-3:] == [7, 8, 9]
    assert lst[-6:-3] == [4, 5, 6]
    assert lst[-9:-6] == [1, 2, 3]
    assert lst[-12:-9] == [0, 1, 2]
    assert lst[-12:-15] == []


# Generated at 2022-06-17 18:35:37.224909
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[::2] == [1, 3, 5, 7, 9]
    assert r[::-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
    assert r[3:6] == [4, 5, 6]
    assert r[3:6:2] == [4, 6]
    assert r[3:6:-1] == []
    assert r[6:3:-1] == [7, 6, 5]

# Generated at 2022-06-17 18:35:49.395756
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(4))) == []
    assert list(drop_until(lambda x: x > 5, range(3))) == []
    assert list(drop_until(lambda x: x > 5, range(2))) == []
    assert list(drop_until(lambda x: x > 5, range(1))) == []
    assert list(drop_until(lambda x: x > 5, range(0))) == []

# Generated at 2022-06-17 18:35:57.325939
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:07.722290
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[2:5] == [2, 3, 4]
    assert lst[-5:-2] == [5, 6, 7]
    assert lst[-5:5] == [5, 6, 7, 8, 9]
    assert lst[-5:5:2] == [5, 7, 9]
    assert lst[-5:5:-2] == []

# Generated at 2022-06-17 18:36:15.915086
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:36:23.568146
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[12] == 0
    assert r[0:3] == [0, 1, 2]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]

# Generated at 2022-06-17 18:36:34.572623
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[1:5] == [1, 2, 3, 4]
    assert lst[-5:-1] == [5, 6, 7, 8]
    assert lst[-5:] == [5, 6, 7, 8, 9]
    assert lst[-5:5] == [5, 6, 7, 8]
    assert lst[-5:4] == [5, 6, 7]
   

# Generated at 2022-06-17 18:36:40.882959
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]
    assert lst[::-3] == [9, 6, 3, 0]
    assert lst[::-4] == [9, 5, 1]

# Generated at 2022-06-17 18:37:18.489611
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(10))
    assert l[0] == 0
    assert l[1] == 1
    assert l[-1] == 9
    assert l[-2] == 8
    assert l[:5] == [0, 1, 2, 3, 4]
    assert l[5:] == [5, 6, 7, 8, 9]
    assert l[2:5] == [2, 3, 4]
    assert l[-5:-2] == [5, 6, 7]
    assert l[-5:-2:2] == [5, 7]
    assert l[-5:-2:-1] == []
    assert l[-5:-2:-2] == []
    assert l[-5:-2:1] == [5, 6, 7]

# Generated at 2022-06-17 18:37:29.073488
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[:] == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert r[:5] == [1, 2, 3, 4, 5]
    assert r[5:] == [6, 7, 8, 9, 10]
    assert r[2:5] == [3, 4, 5]
    assert r[-5:-2] == [6, 7, 8]
    assert r[-2:-5] == []