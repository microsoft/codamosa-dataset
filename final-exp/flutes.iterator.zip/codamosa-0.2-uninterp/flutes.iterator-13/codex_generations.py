

# Generated at 2022-06-17 18:27:53.674774
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:28:03.548944
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10

# Generated at 2022-06-17 18:28:11.571345
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:28:18.086812
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:28:22.603354
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(1, range(10))) == list(range(1, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(10, [])) == []
    assert list(drop(11, [])) == []
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(1, range(10))) == list(range(1, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list

# Generated at 2022-06-17 18:28:33.267866
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    for _ in range(100):
        lst = [random.randint(0, 100) for _ in range(random.randint(0, 100))]
        m = MapList(lambda x: x * x, lst)
        for i in range(len(lst)):
            assert m[i] == lst[i] * lst[i]
        for i in range(len(lst)):
            assert m[i:i + 1] == [lst[i] * lst[i]]
        for i in range(len(lst)):
            assert m[i:i + 2] == [lst[i] * lst[i], lst[i + 1] * lst[i + 1]]

# Generated at 2022-06-17 18:28:43.208139
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:28:55.882431
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:29:07.396181
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[:0] == []
    assert lst[:1] == [0]
    assert lst[1:1] == []
    assert lst[1:2] == [1]

# Generated at 2022-06-17 18:29:18.217112
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:29:47.088632
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(6))) == [6]



# Generated at 2022-06-17 18:30:00.337510
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:30:12.697772
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3])
    assert len(lst) == 3
    lst = LazyList(range(10))
    assert len(lst) == 10
    lst = LazyList(range(10))
    lst[0]
    assert len(lst) == 10
    lst = LazyList(range(10))
    lst[:5]
    assert len(lst) == 10
    lst = LazyList(range(10))
    lst[:5]
    lst[5]
    assert len(lst) == 10
    lst = LazyList(range(10))
    lst[:5]
    lst[5:]
    assert len(lst) == 10
    lst = LazyList(range(10))
   

# Generated at 2022-06-17 18:30:20.585283
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    assert m[0] == 1
    assert m[1] == 4
    assert m[-1] == 25
    assert m[1:3] == [4, 9]
    assert m[1:3:2] == [4]
    assert m[::-1] == [25, 16, 9, 4, 1]
    assert m[:] == [1, 4, 9, 16, 25]
    assert m[::2] == [1, 9, 25]
    assert m[::-2] == [25, 9, 1]


# Generated at 2022-06-17 18:30:32.148107
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[1::2] == [1, 3, 5, 7, 9]
    assert lst[3:1:-1] == [3, 2]
    assert lst[3:1:-2] == [3]

# Generated at 2022-06-17 18:30:40.302888
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from itertools import count
    from bisect import bisect_left
    from math import sqrt
    for _ in count():
        n = randint(0, 100)
        a = [randint(0, 100) for _ in range(n)]
        b = [randint(0, 100) for _ in range(n)]
        pos = bisect_left(MapList(lambda x: x * x, a), 10)
        assert pos == bisect_left(map(lambda x: x * x, a), 10)
        pos = bisect_left(MapList(lambda i: a[i] * b[i], Range(n)), 10)
        assert pos == bisect_left(map(lambda i: a[i] * b[i], range(n)), 10)
        pos = bisect

# Generated at 2022-06-17 18:30:54.303285
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10
    assert len(lst) == 10

# Generated at 2022-06-17 18:31:04.842042
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(5, [])) == []
    assert list(take(5, [1, 2, 3])) == [1, 2, 3]
    assert list(take(5, [1])) == [1]
    assert list(take(5, [1, 2])) == [1, 2]
    assert list(take(5, [1, 2, 3, 4])) == [1, 2, 3, 4]

# Generated at 2022-06-17 18:31:15.730309
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'z')) == ['z', 'za', 'zba', 'zcba', 'zdcba']
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(operator.add, [])) == []

# Generated at 2022-06-17 18:31:22.347381
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[0:2] == [0, 1]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:31:40.687868
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    try:
        list(split_by(range(10), criterion=lambda x: x % 3 == 0, separator='.'))
        assert False
    except ValueError:
        pass
    try:
        list(split_by(range(10)))
        assert False
    except ValueError:
        pass
test_split_by()



# Generated at 2022-06-17 18:31:54.745981
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))

# Generated at 2022-06-17 18:31:56.543888
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))



# Generated at 2022-06-17 18:32:01.574064
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[12] == 0
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:32:13.868898
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:3] == [1, 4]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:3:2] == [1]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[:3] == [1, 4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[3:] == [16, 25]

# Generated at 2022-06-17 18:32:23.494916
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))

# Generated at 2022-06-17 18:32:35.780124
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:3] == [0, 1, 2]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[1:3] == [1, 2]
    assert lst[-3:] == [7, 8, 9]
    assert lst[-3:-1] == [7, 8]
    assert lst[-3:0] == []
    assert lst[-3:1] == [7]
    assert lst[-3:2] == [7, 8]

# Generated at 2022-06-17 18:32:45.052921
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:3] == [1, 4]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-1] == 25
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-3:-1] == [9, 16]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[:] == [1, 4, 9, 16, 25]

# Generated at 2022-06-17 18:32:56.444679
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:08.314369
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))

# Generated at 2022-06-17 18:33:22.946085
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from itertools import count
    from bisect import bisect_left
    from functools import reduce
    from operator import mul
    from typing import List, Callable, Iterable, Iterator, Sequence, Tuple, TypeVar
    from typing_extensions import Literal
    from typing import overload
    from typing import Generic
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar
    from typing import TypeVar

# Generated at 2022-06-17 18:33:29.324268
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:33:39.770423
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    assert m[0] == 1
    assert m[2] == 9
    assert m[4] == 25
    assert m[-1] == 25
    assert m[-3] == 9
    assert m[-5] == 1
    assert m[1:3] == [4, 9]
    assert m[3:] == [16, 25]
    assert m[:2] == [1, 4]
    assert m[::2] == [1, 9, 25]
    assert m[::-1] == [25, 16, 9, 4, 1]
    assert m[-2::-2] == [9, 1]

# Generated at 2022-06-17 18:33:50.549325
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:3] == [1, 2, 3]
    assert r[2:5] == [3, 4, 5]
    assert r[-3:-1] == [8, 9]
    assert r[-5:-2] == [6, 7, 8]
    assert r[0:10:2] == [1, 3, 5, 7, 9]
    assert r[2:10:2] == [3, 5, 7, 9]
    assert r[-3:10:2] == [8]

# Generated at 2022-06-17 18:34:02.730000
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:09.203346
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 10, range(10))) == []
    assert list(drop_until(lambda x: x > -1, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > -1, [])) == []



# Generated at 2022-06-17 18:34:20.472700
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-20] == 0
    assert r[0:4] == [0, 1, 2, 3]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:20] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
   

# Generated at 2022-06-17 18:34:32.280601
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:34:42.558616
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:56.744174
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[0:2] == [0, 1]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:0] == []
    assert r[0:1] == [0]
    assert r[0:0:1] == []

# Generated at 2022-06-17 18:35:12.315989
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[3:7] == [3, 4, 5, 6]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2] == [9, 7, 5, 3, 1]

# Generated at 2022-06-17 18:35:24.364161
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 10
    assert r[11] == 10
    assert r[12] == 10
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:4] == [0, 4, 8]

# Generated at 2022-06-17 18:35:29.185254
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    for _ in range(100):
        lst = [random.randint(0, 100) for _ in range(random.randint(0, 100))]
        ml = MapList(lambda x: x * x, lst)
        for _ in range(100):
            idx = random.randint(0, len(lst) - 1)
            assert ml[idx] == lst[idx] * lst[idx]
            assert ml[idx:idx + 1] == [lst[idx] * lst[idx]]
            assert ml[idx:idx + 2] == [lst[idx] * lst[idx], lst[idx + 1] * lst[idx + 1]]

# Generated at 2022-06-17 18:35:41.016411
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[12] == 0
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:35:51.743026
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:04.382772
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:5] == [1, 2, 3, 4, 5]
    assert r[0:5:2] == [1, 3, 5]
    assert r[5:0:-2] == [6, 4, 2]
    assert r[5:0:-2] == [6, 4, 2]
    assert r[5:0:-2] == [6, 4, 2]
    assert r[5:0:-2] == [6, 4, 2]

# Generated at 2022-06-17 18:36:13.762672
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:4] == [0, 4, 8]
    assert r[0:10:5] == [0, 5]

# Generated at 2022-06-17 18:36:23.792232
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert lst[::-2]

# Generated at 2022-06-17 18:36:34.901391
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    c = [3, 4, 5, 6, 7]
    d = [4, 5, 6, 7, 8]
    e = [5, 6, 7, 8, 9]
    f = [6, 7, 8, 9, 10]
    g = [7, 8, 9, 10, 11]
    h = [8, 9, 10, 11, 12]
    i = [9, 10, 11, 12, 13]
    j = [10, 11, 12, 13, 14]
    k = [11, 12, 13, 14, 15]
    l = [12, 13, 14, 15, 16]
    m = [13, 14, 15, 16, 17]

# Generated at 2022-06-17 18:36:45.019225
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5])) == []
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6])) == [6]
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7])) == [6, 7]

# Generated at 2022-06-17 18:37:01.053032
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[0:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[:] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert lst[::2] == [0, 2, 4, 6, 8]
    assert lst[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-17 18:37:09.408531
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-1] == 25
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:3] == [4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:5:2] == [4, 16]

# Generated at 2022-06-17 18:37:19.728463
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:5] == list(range(5))
    assert lst[5:] == list(range(5, 10))
    assert lst[::-1] == list(range(9, -1, -1))
    assert lst[::2] == list(range(0, 10, 2))
    assert lst[::-2] == list(range(9, -1, -2))
    assert lst[::3] == list(range(0, 10, 3))
    assert lst[::-3] == list(range(9, -1, -3))

# Generated at 2022-06-17 18:37:30.248306
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:5:2] == [0, 2, 4]
    assert r[5:0:-1] == [5, 4, 3, 2, 1]
    assert r[5:0:-2] == [5, 3, 1]
    assert r[5:0:-3] == [5, 2]
    assert r[5:0:-4] == [5]
   