

# Generated at 2022-06-17 18:28:07.007609
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(5, range(5))) == []
    assert list(drop(0, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop(-1, range(5))) == [0, 1, 2, 3, 4]
    assert list(drop(5, range(0))) == []
    assert list(drop(0, range(0))) == []
    assert list(drop(-1, range(0))) == []
    assert list(drop(5, [])) == []
    assert list(drop(0, [])) == []
    assert list(drop(-1, [])) == []



# Generated at 2022-06-17 18:28:09.473061
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []



# Generated at 2022-06-17 18:28:16.158269
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(5, [])) == []
    assert list(take(5, [1, 2, 3])) == [1, 2, 3]
    assert list(take(0, [])) == []
    assert list(take(0, [1, 2, 3])) == []
    assert list(take(-1, [])) == []
    assert list(take(-1, [1, 2, 3])) == []
    assert list(take(-1, range(1000000))) == []


# Generated at 2022-06-17 18:28:23.958776
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:28:31.385549
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(1, range(10))) == list(range(1, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(10, [])) == []
    assert list(drop(11, [])) == []



# Generated at 2022-06-17 18:28:42.641688
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:28:55.598931
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:29:05.830872
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))
    assert list(lst) == list(range(10))


# Generated at 2022-06-17 18:29:16.948881
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(10))) == 10

# Generated at 2022-06-17 18:29:29.239280
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from itertools import count
    from bisect import bisect_left

    def random_list(n):
        return [randint(0, 10 ** 9) for _ in range(n)]

    def random_list_with_duplicates(n):
        return [randint(0, 10) for _ in range(n)]

    def random_list_with_duplicates_and_zeros(n):
        return [randint(0, 10) for _ in range(n)] + [0] * randint(0, n)

    def random_list_with_duplicates_and_zeros_and_negatives(n):
        return [randint(-10, 10) for _ in range(n)] + [0] * randint(0, n)


# Generated at 2022-06-17 18:29:47.712527
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:30:00.381076
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[0:2] == [0, 1]
    assert lst[2:4] == [2, 3]
    assert lst[-2:-1] == [8]
    assert lst[-2:] == [8, 9]
    assert lst[-1:] == [9]
    assert lst[-1:-2] == []
    assert lst[-1:-3] == []
    assert lst[-3:-1] == [7, 8]
    assert lst[-3:] == [7, 8, 9]

# Generated at 2022-06-17 18:30:12.602118
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:30:21.359305
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:30:29.855849
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    try:
        list(split_by(" Split by: ", empty_segments=True))
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-17 18:30:35.647701
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(6))) == [6]
    assert list(drop_until(lambda x: x > 5, range(7))) == [6, 7]



# Generated at 2022-06-17 18:30:47.750436
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]

# Generated at 2022-06-17 18:30:59.915809
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[-1] == 9
    assert r[1:3] == [1, 2]
    assert r[:3] == [0, 1, 2]
    assert r[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert r[::2] == [0, 2, 4, 6, 8]
    assert r[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert r[::-2] == [9, 7, 5, 3, 1]
    assert r[-2::-2] == [8, 6, 4, 2, 0]
    assert r[-2:3:-2] == [8, 6, 4]
    assert r

# Generated at 2022-06-17 18:31:08.429110
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:0] == []
    assert r[0:1] == [0]

# Generated at 2022-06-17 18:31:18.317051
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
    assert r[0:2] == [0, 1]
    assert r[0:3] == [0, 1, 2]
    assert r[0:4] == [0, 1, 2, 3]
    assert r[0:5] == [0, 1, 2, 3, 4]
   

# Generated at 2022-06-17 18:31:41.783924
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0
   

# Generated at 2022-06-17 18:31:55.200607
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[0:2] == [0, 1]
    assert r[0:3] == [0, 1, 2]
    assert r[0:4] == [0, 1, 2, 3]
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:6] == [0, 1, 2, 3, 4, 5]

# Generated at 2022-06-17 18:32:00.415859
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:32:12.748196
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:3] == [0, 1, 2]
    assert r[3:0] == []
    assert r[3:3] == []
    assert r[3:4] == [3]
    assert r[3:5] == [3, 4]
    assert r[3:6] == [3, 4, 5]
    assert r[3:7] == [3, 4, 5, 6]

# Generated at 2022-06-17 18:32:22.712268
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0
    assert r[-30] == 0
    assert r[-31] == 0
    assert r[-32] == 0
    assert r[-40] == 0
    assert r[-41] == 0
    assert r[-42] == 0
    assert r[-50] == 0
    assert r[-51] == 0
    assert r[-52] == 0
    assert r

# Generated at 2022-06-17 18:32:34.877497
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[-11] == 0
    assert lst[-12] == 0
    assert lst[-13] == 0
    assert lst[-14] == 0

# Generated at 2022-06-17 18:32:40.532570
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-17 18:32:54.301549
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:07.297392
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:33:19.402705
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[2:5] == [2, 3, 4]
    assert lst[-5:] == [5, 6, 7, 8, 9]
    assert lst[-5:-2] == [5, 6, 7]
    assert lst[-5:-5] == []
    assert lst[-5:5] == []
    assert lst[-5:5:2] == []
    assert lst

# Generated at 2022-06-17 18:33:36.385993
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 10
    assert r[11] == 10
    assert r[0:2] == [0, 1]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:4] == [0, 4, 8]
    assert r[0:10:5] == [0, 5]
    assert r[0:10:6] == [0, 6]
    assert r

# Generated at 2022-06-17 18:33:42.648041
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

# Generated at 2022-06-17 18:33:53.143592
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[0] == 1
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[2] == 9
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[-1] == 25
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:3] == [4, 9]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:-1] == [4, 9, 16]
    assert MapList(lambda x: x * x, [1, 2, 3, 4, 5])[1:5:2] == [4, 16]

# Generated at 2022-06-17 18:34:04.137159
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-1] == 9
    assert r[-3] == 7
    assert r[-5] == 5
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[-13] == 0
    assert r[-14] == 0
    assert r[-15] == 0
    assert r[-16] == 0
    assert r[-17] == 0
    assert r[-18] == 0
    assert r[-19] == 0
    assert r[-20] == 0
    assert r[-21] == 0
    assert r[-22] == 0

# Generated at 2022-06-17 18:34:12.697417
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[-1] == 9
    assert lst[:3] == [0, 1, 2]
    assert lst[3:7] == [3, 4, 5, 6]
    assert lst[7:] == [7, 8, 9]
    assert lst[-3:] == [7, 8, 9]
    assert lst[-3:-1] == [7, 8]
    assert lst[-3:0] == []
    assert lst[-3:1] == [0]
    assert lst[-3:2] == [0, 1]
    assert lst[-3:3] == [0, 1, 2]
    assert lst

# Generated at 2022-06-17 18:34:18.759411
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    from typing import List
    from typing import TypeVar
    from typing import Union
    from typing import overload
    from typing import Sequence
    from typing import Callable
    from typing import Generic
    from typing import Iterator
    from typing import Any
    from typing import Type
    from typing import Tuple
    from typing import Optional
    from typing import cast
    from typing import Dict
    from typing import Set
    from typing import FrozenSet
    from typing import Mapping
    from typing import MutableMapping
    from typing import MappingView
    from typing import MutableSequence
    from typing import Deque
    from typing import ByteString
    from typing import List
    from typing import AbstractSet
    from typing import Iterable
    from typing import Generator
    from typing import ContextManager
    from typing import IO
    from typing import TextIO


# Generated at 2022-06-17 18:34:30.702681
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:41.825070
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:34:56.475549
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:10:2] == [0, 2, 4, 6, 8]
    assert r[0:10:3] == [0, 3, 6, 9]
    assert r[0:10:10] == [0]
    assert r[0:10:11] == []
    assert r[0:10:0] == []

# Generated at 2022-06-17 18:35:08.773959
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(6))) == [6]
    assert list(drop_until(lambda x: x > 5, range(7))) == [6, 7]
    assert list(drop_until(lambda x: x > 5, range(8))) == [6, 7, 8]
    assert list(drop_until(lambda x: x > 5, range(9))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]

# Generated at 2022-06-17 18:35:28.215162
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'x')) == ['x', 'xa', 'xab', 'xabc', 'xabcd']
    assert list(scanl(lambda s, x: x + s, [])) == []
    assert list(scanl(lambda s, x: x + s, [], 'x')) == ['x']

# Generated at 2022-06-17 18:35:40.527849
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3
    assert lst[-8] == 2
    assert lst[-9] == 1
    assert lst[-10] == 0
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:35:54.746677
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from bisect import bisect_left
    for _ in range(100):
        n = randint(1, 100)
        a = [randint(0, 100) for _ in range(n)]
        a.sort()
        for i in range(n):
            assert bisect_left(MapList(lambda x: x * x, a), a[i] * a[i]) == i
            assert bisect_left(MapList(lambda x: x * x, a), a[i] * a[i] - 1) == i
            assert bisect_left(MapList(lambda x: x * x, a), a[i] * a[i] + 1) == i + 1

# Generated at 2022-06-17 18:36:05.887634
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:14.361224
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[-1] == 10
    assert r[-3] == 8
    assert r[-5] == 6
    assert r[0:2] == [1, 2]
    assert r[2:4] == [3, 4]
    assert r[4:6] == [5, 6]
    assert r[-1:-3] == [10, 9]
    assert r[-3:-5] == [8, 7]
    assert r[-5:-7] == [6, 5]
    assert r[0:2:2] == [1]
    assert r[2:4:2] == [3]

# Generated at 2022-06-17 18:36:19.418628
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-17 18:36:30.961782
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))

# Generated at 2022-06-17 18:36:41.456730
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[3] == 3
    assert lst[4] == 4
    assert lst[5] == 5
    assert lst[6] == 6
    assert lst[7] == 7
    assert lst[8] == 8
    assert lst[9] == 9
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[-6] == 4
    assert lst[-7] == 3

# Generated at 2022-06-17 18:36:54.590835
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], 'e')) == ['e', 'ea', 'eba', 'ecba', 'edcba']
    assert list(scanl(lambda s, x: x + s, [])) == []
    assert list(scanl(lambda s, x: x + s, [], 'e')) == ['e']

# Generated at 2022-06-17 18:37:05.258701
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-10] == 0
    assert r[-11] == 0
    assert r[-12] == 0
    assert r[10] == 0
    assert r[11] == 0
    assert r[12] == 0
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[0:11] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 18:37:23.398496
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(10)))