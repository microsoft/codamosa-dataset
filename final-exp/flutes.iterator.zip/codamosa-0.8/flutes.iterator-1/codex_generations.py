

# Generated at 2022-06-11 21:37:24.238394
# Unit test for function drop_until
def test_drop_until():
    pred_fn = lambda x: x > 5
    iterable = range(10)
    ret = list(drop_until(pred_fn, iterable))
    assert ret == [6, 7, 8, 9]



# Generated at 2022-06-11 21:37:31.520597
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    
    for i in range(2):
        for l in range(2):
            
            if l == 0:
                value = 999
            else:
                value = [0, 1, 2, 3]
            
            if i == 0:
                test = Range(value)
            else:
                test = Range(0, value + 1)
            
            if l == 0:
                assert value == test[0], "test_Range___getitem___error1"
            
            else:
                assert value == test[0 : value + 1], "test_Range___getitem___error2"


# Generated at 2022-06-11 21:37:34.710827
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Arrange
    import random

    rand_len = random.randint(0, 128)
    rand_list = [random.randint(0, 128) for _ in range(rand_len)]

    # Act
    map_list = MapList(lambda x: x * x, rand_list)

    # Assert
    assert (map_list[:] == [x * x for x in rand_list])
    assert all(x == map_list[i] for i, x in enumerate(map_list))
    assert (map_list[2:6] == [4, 9, 16, 25])

# Generated at 2022-06-11 21:37:37.795617
# Unit test for function take
def test_take():
    it = iter(range(10))
    assert list(take(5, it)) == [0, 1, 2, 3, 4]
    assert list(it) == [5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:37:48.227935
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    #### Range.__getitem__(item)
    #### Range.[item]
    r = Range(5)
    # val = r[x]
    assert r[0] == 0
    assert r[4] == 4
    # val = r[x:y]
    assert r[0:1] == [0]
    assert r[2:4] == [2, 3]
    assert r[0:4:1] == [0, 1, 2, 3]
    # val = r[x:y:z]
    assert r[0:-1] == [0, 1, 2, 3]
    # val = r[x:]
    assert r[1:] == [1, 2, 3, 4]
    # val = r[:y]
    assert r[:3] == [0, 1, 2]

# Generated at 2022-06-11 21:37:56.859771
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    from unittest import TestCase
    def check_positive_slice(lst, start, end, step):
        end = end if end is not None else len(lst)
        slice = lst[start:end:step]
        expected = list(range(start, end, step))
        assert len(slice) == len(expected)
        assert slice == expected
    def check_negative_slice(lst, start, end, step):
        end = end if end is not None else len(lst)
        slice = lst[start:end:step]
        expected = list(range(start, end, step))
        assert len(slice) == len(expected)
        assert slice == expected
    def check_single_item_access(lst, index):
        assert lst[index] == index

# Generated at 2022-06-11 21:38:07.105518
# Unit test for function split_by
def test_split_by():
    # Either criterion or separator must be given
    with pytest.raises(ValueError):
        _ = list(split_by([]))

    # Empty segments can be returned according to the flag
    assert list(split_by([], empty_segments=False)) == []
    assert list(split_by([], empty_segments=True)) == [[]]

    assert list(split_by(["Split", "by", ":"], criterion=lambda x: x == ':')) == [["Split", "by"]]
    assert list(split_by(["Split", "by", ":"], empty_segments=True, criterion=lambda x: x == ':')) == [["Split", "by"], []]


# Generated at 2022-06-11 21:38:09.619340
# Unit test for function take
def test_take():
    assert(list(take(3, [1, 2, 3, 4])) == [1, 2, 3])
    assert(list(take(3, [1, 2])) == [1, 2])


# Generated at 2022-06-11 21:38:14.640062
# Unit test for function drop
def test_drop():
    assert list(take(5, drop(0, range(10)))) == [0, 1, 2, 3, 4]
    assert list(take(5, drop(5, range(10)))) == [5, 6, 7, 8, 9]
    with pytest.raises(ValueError):
        drop(-1, [])



# Generated at 2022-06-11 21:38:17.716938
# Unit test for function chunk
def test_chunk():
    assert [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]] == list(chunk(3, range(10)))
test_chunk()


# Generated at 2022-06-11 21:38:37.030535
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]

test_split_by()



# Generated at 2022-06-11 21:38:43.837999
# Unit test for function take
def test_take():
    # Test take with a positive `n`
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    # Test take with a negative `n`
    try:
        take(-5, range(5))
    except ValueError as e:
        assert str(e) == "`n` should be non-negative"
    # Test take with an empty iterable
    assert list(take(5, [])) == []



# Generated at 2022-06-11 21:38:48.189716
# Unit test for function take
def test_take():
    assert list(take(5, range(100))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(5))) == list(range(5))
    assert list(take(0, range(5))) == []
    assert list(take(0, [])) == []


# Generated at 2022-06-11 21:38:55.777397
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(4, 12))) == [6, 7, 8, 9, 10, 11]
    assert list(drop_until(lambda x: True, range(10))) == list(range(10))
    assert list(drop_until(lambda x: False, range(10))) == list(range(10))



# Generated at 2022-06-11 21:39:02.412420
# Unit test for function split_by
def test_split_by():
    # pylint: disable=fixme
    # TODO: replace this with unittest
    # criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == \
        [[1, 2], [4, 5], [7, 8]]
    # separator
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == \
        [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:39:14.923740
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(2))) == [0, 1]
    assert list(take(5, range(1))) == [0]
    assert list(take(5, range(0))) == []
    assert list(take(5, [])) == []

    it = iter(range(5))
    assert list(it) == [0, 1, 2, 3, 4]
    assert list(it) == []

    it = iter(range(5))
    assert list(take(2, it)) == [0, 1]
    assert list(it) == [2, 3, 4]
    assert list(it) == []

    it = iter(range(5))

# Generated at 2022-06-11 21:39:23.771275
# Unit test for function take
def test_take():
    assert list(take(2, [1, 2, 3])) == [1, 2]
    assert list(take(2, range(5))) == [0, 1]
    assert list(take(20, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(5))) == []
    assert list(take(0, [])) == []
    assert list(take(2, [])) == []
    try:
        # Negative n is invalid
        list(take(-1, range(5)))
        raise AssertionError("Negative `n` should not be accepted")
    except ValueError:
        pass



# Generated at 2022-06-11 21:39:29.731722
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, range(0, -10, -1))) == [-6, -7, -8, -9]
    assert list(drop_until(lambda x: x is None, [1, 2, 3, 4, None])) == [None]
    assert list(drop_until(lambda x: x is None, [1, 2, 3, 4, 1])) == []
    assert list(drop_until(lambda x: x is None, [])) == []
# Test for class LazyList

# Generated at 2022-06-11 21:39:39.236897
# Unit test for function drop_until
def test_drop_until():
    import pytest

    [x, y, z] = drop_until(lambda x: x > 1, [0, 1, 2, 3])
    assert x == 2
    assert y == 3
    assert z == 4
    [x, y, z] = drop_until(lambda x: x > 0, [0, 1, 2, 3])
    assert x == 1
    assert y == 2
    assert z == 3
    [x, y, z] = drop_until(lambda x: x > -1, [0, 1, 2, 3])
    assert x == 0
    assert y == 1
    assert z == 2
    with pytest.raises(ValueError):
        list(drop_until(lambda x: x < 0, [0, 1, 2, 3]))



# Generated at 2022-06-11 21:39:51.494094
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Check method __getitem__ of class MapList
    # Create instance of class MapList with argument 'func' and argument 'lst'
    func = lambda x: x * x
    lst = [1, 2, 3, 4, 5]
    __DUMMY_0 = lst
    inst_ = MapList(func, lst)
    # Check attribute 'list' -- INITIAL VALUE
    assert inst_.list == lst
    # Check attribute 'func' -- INITIAL VALUE
    assert inst_.func == func

# Generated at 2022-06-11 21:40:28.063510
# Unit test for function take
def test_take():
    def take(n, iterable):
        return list(take(n, iterable))
    assert take(0, range(1, 5)) == []

    assert take(5, range(1, 5)) == [1, 2, 3, 4]



# Generated at 2022-06-11 21:40:31.342975
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3, 4])
    assert lst[1] == 2
    assert len(lst) == 4
    assert lst[0] == 1

# Generated at 2022-06-11 21:40:39.652891
# Unit test for function split_by
def test_split_by():
    print("Testing function 'split_by'...", end="")
    def is_even(num):
        return num % 2 == 0
    assert list(split_by([1, 2, 3, 4, 5], criterion=is_even)) == [[1, 3, 5]]
    assert list(split_by([], criterion=is_even)) == [[]]
    assert list(split_by([1, 1, 1, 1], criterion=is_even)) == [[], [], [], []]
    assert list(split_by([1, 1, 1, 1], criterion=is_even, empty_segments=True)) == [[], [], [], [], []]
    assert list(split_by([1, 2, 3, 4, 5], criterion=is_even, empty_segments=True)) == [[1, 3, 5], []]

# Generated at 2022-06-11 21:40:46.690350
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x < 5, [])) == []
    assert list(drop_until(lambda x: x > 5, (i for i in [7, 8]))) == [7, 8]
    assert list(drop_until(lambda x: x > 5, [4, 5, 6, 7])) == [5, 6, 7]



# Generated at 2022-06-11 21:40:51.150706
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import itertools
    from utils_test import int_range
    # The __getitem__ of this class is tested in method test_list_access
    for i, x in enumerate(LazyList(itertools.chain(int_range(0, 100), int_range(10, 20)))):
        pass
    assert i == 18

# Generated at 2022-06-11 21:41:02.110041
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    import operator
    import pickle
    random.seed(0)
    a = range(100)
    b = LazyList(a)
    assert operator.eq(a, b)
    c = b[:50]
    assert operator.eq(c, a[:50])
    assert operator.eq(a, b)
    c = b[:55]
    assert operator.eq(c, a[:55])
    assert operator.eq(a, b)
    c = b[:0]
    assert operator.eq(c, [])
    assert operator.eq(a, b)
    for i in range(100):
        j = random.randrange(100)
        assert a[j] == b[j]
        assert operator.eq(a, b)

# Generated at 2022-06-11 21:41:09.265851
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator=' ')) == [[],
                                                                                 ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:41:17.338876
# Unit test for function split_by
def test_split_by():
    # criterion
    assert list(split_by([1, 2, 4, 5, 7, 8], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(['a', 'b', 'c', 'e'], criterion=lambda x: x == 'd')) == [['a', 'b', 'c', 'e']]
    # empty_segments=True
    assert list(split_by([1, 2, 4, 5, 7, 8], criterion=lambda x: x % 3 == 0, empty_segments=True)) \
        == [[1, 2], [], [4, 5], [7, 8], []]

# Generated at 2022-06-11 21:41:26.171788
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    list1 = LazyList(range(10))
    assert list(list1) == list(range(10))
    assert list1[1] == 1
    assert list(list1) == list(range(10))

    list2 = LazyList(range(10))
    assert list(LazyList.LazyListIterator(list2)) == list(range(10))
    assert list2[1] == 1
    assert list(list2) == list(range(10))

    list3 = LazyList(range(10))
    assert list(list3) == list(range(10))
    assert list(list3) == list(range(10))

    list4 = LazyList(range(10))
    it = LazyList.LazyListIterator(list4)

# Generated at 2022-06-11 21:41:33.376716
# Unit test for function drop_until
def test_drop_until():
    expected_output = [6, 7, 8, 9]
    result = drop_until(lambda x: x > 5, range(10))
    assert next(result) == 6
    assert list(result) == expected_output
    result = drop_until(lambda x: x < 5, range(10))
    assert list(result) == list(range(10))
    result = drop_until(lambda x: x == 10, range(10))
    assert list(result) == []



# Generated at 2022-06-11 21:41:55.860221
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:41:59.405717
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(10))
    for i, j in enumerate(ll):
        if i < 5:
            assert j == i
        else:
            assert j == i + 10
            break

# Generated at 2022-06-11 21:42:07.097355
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 0, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 10, range(10))) == []
    assert list(drop_until(lambda x: x > 0, map(lambda x: -x, range(10)))) == []



# Generated at 2022-06-11 21:42:12.066229
# Unit test for function take
def test_take():
    it = take(3, [1,2,3,4])
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    with pytest.raises(StopIteration):
        next(it)



# Generated at 2022-06-11 21:42:14.487206
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: str(x), [1, 2, 3])[1] == "2"


# Generated at 2022-06-11 21:42:23.417037
# Unit test for function take
def test_take():
    import random
    for _ in range(10):
        n = random.randrange(1, 1000)
        src = list(range(1000))
        dst = list(take(n, src))
        assert len(dst) == n
        assert src[:n] == dst
    src = [1, 2, 3]
    assert list(take(-1, src)) == []
    assert list(take(0, src)) == []
    assert list(take(1, src)) == [1]
    assert list(take(2, src)) == [1, 2]
    assert list(take(3, src)) == [1, 2, 3]
    assert list(take(10, src)) == [1, 2, 3]



# Generated at 2022-06-11 21:42:27.337414
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    ll = LazyList(range(10))
    with pytest.raises(TypeError):
        len(ll)
    next(iter(ll))
    with pytest.raises(TypeError):
        len(ll)
    list(ll)
    assert len(ll) == 10

# Generated at 2022-06-11 21:42:37.338183
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x == 1, [])) == []
    assert list(drop_until(lambda x: x == 1, [1, 2, 3])) == [1, 2, 3]
    assert list(drop_until(lambda x: x == 2, [1, 2, 3])) == [2, 3]
    assert list(drop_until(lambda x: x == 1, [0])) == []
    assert list(drop_until(lambda x: x == 2, [0])) == []
    assert list(drop_until(lambda x: x == 1, [0, 1, 1, 2])) == [1, 1, 2]
    assert list(drop_until(lambda x: x == 2, [0, 1, 2, 2])) == [2, 2]



# Generated at 2022-06-11 21:42:46.469817
# Unit test for function drop_until
def test_drop_until():
    # General case
    assert list(drop_until(lambda x: x>5, range(10))) == [6,7,8,9]
    # Empty list
    assert list(drop_until(lambda x: x>5, [])) == []
    # All elements satisfying predicate
    assert list(drop_until(lambda x: x<10, range(10))) == [0,1,2,3,4,5,6,7,8,9]
    # None satisfying predicate
    assert list(drop_until(lambda x: x>10, range(10))) == []



# Generated at 2022-06-11 21:42:52.811059
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
        ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:43:36.547839
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3, 4, 5])
    assert list(lst) == [1, 2, 3, 4, 5]
    assert list(lst) == [1, 2, 3, 4, 5]
    lst = LazyList(range(10000))
    assert list(lst) == [i for i in range(10000)]
    assert list(lst) == [i for i in range(10000)]



# Generated at 2022-06-11 21:43:40.021365
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    x = LazyList(range(10))
    assert x[0] == 0
    assert x[1] == 1
    assert len(x) == 10



# Generated at 2022-06-11 21:43:46.747515
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=lambda x: x % 3 == 0)) == []
    assert list(split_by(range(10))) == list(range(10))
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]
    assert list(split_by(list(range(10)), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]

# Generated at 2022-06-11 21:43:57.408392
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    idx = 0
    x1 = Range(0, 10, 1)
    assert x1[idx] == idx
    idx = 3
    assert x1[idx] == idx
    idx = 2
    x1 = Range(0, idx, 1)
    assert x1[idx] == idx
    idx = 3
    x1 = Range(0, idx, 1)
    assert x1[idx] == idx
    idx = 2
    assert x1[-idx] == idx
    idx = 3
    assert x1[-idx] == idx
    idx = 2
    x1 = Range(0, 10, 1)

# Generated at 2022-06-11 21:44:08.541464
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from .consume import collect
    assert collect(LazyList(range(5))[2:]) == [2, 3, 4]
    assert collect(LazyList(range(5))[::-1]) == [4, 3, 2, 1, 0]
    with pytest.raises(NotImplementedError):
        LazyList(range(5))[-1]
    with pytest.raises(TypeError):
        len(LazyList(range(5)))
    l = LazyList(range(5))
    l_ref = l
    assert l[:3] == [0, 1, 2]
    l = l_ref
    assert l[:3] == [0, 1, 2]

# Generated at 2022-06-11 21:44:10.341604
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:44:15.746488
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == list(range(3))
    assert list(take(3, range(2))) == list(range(2))
    assert list(take(3, range(0))) == list(range(0))
    assert list(take(-1, range(10))) == list(range(-1))
    assert list(take(-1, range(2))) == list(range(-1))
    assert list(take(-1, range(0))) == list(range(-1))

#Unit test for function chunk

# Generated at 2022-06-11 21:44:24.696538
# Unit test for function drop_until
def test_drop_until():
    import hypothesis
    from hypothesis import strategies
    from .base import hypothesis_settings
    hypothesis.settings.register_profile('ci', hypothesis_settings)
    hypothesis.settings.load_profile('ci')

    @hypothesis.given(
        len_lst=strategies.integers(min_value=1, max_value=10),
        predicate=strategies.integers(min_value=0, max_value=9),
        lst=strategies.lists(elements=strategies.integers(),
                             min_size=0, max_size=10, unique=True))
    def test_drop_until_0(len_lst, predicate, lst):
        from .base import identity
        lst = lst[:len_lst]

# Generated at 2022-06-11 21:44:31.608953
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    vals = list(range(10000))
    it = iter(vals)
    lst = LazyList(iter(vals))
    assert next(it) == next(lst)
    assert next(it) == next(lst)
    assert next(it) == next(lst)
    assert next(it) == next(lst)
    assert list(it) == list(lst)
    assert list(lst) == list(iter(lst))
    assert list(lst) == list(iter(lst))



# Generated at 2022-06-11 21:44:38.608492
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[3] == 3
    assert Range(1, 10+1)[3] == 4
    assert Range(1, 11, 2)[3] == 7
    assert Range(10)[-1] == 9
    assert Range(10)[slice(0,5)] == [0, 1, 2, 3, 4]
    assert Range(10)[slice(0,9,2)] == [0, 2, 4, 6, 8]

###############################################################################
