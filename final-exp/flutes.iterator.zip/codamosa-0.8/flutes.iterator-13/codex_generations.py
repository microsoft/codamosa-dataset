

# Generated at 2022-06-11 21:37:24.238379
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by("Split by: ", separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by("Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(range(2, 10), criterion=lambda x: x % 3 == 0)) == [[4, 5], [7, 8]]

# Generated at 2022-06-11 21:37:31.455681
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, (1, 2, 3, 4, 5, 6))) == [[1, 2, 3], [4, 5, 6]]
    assert list(chunk(3, (1, 2, 3, 4, 5, 6, 7))) == [[1, 2, 3], [4, 5, 6], [7]]
    assert list(chunk(2, ())) == []
    assert list(chunk(2, (1,))) == [[1]]
    assert list(chunk(0, range(1))) == []
    assert list(chunk(-1, range(1))) == []


# Generated at 2022-06-11 21:37:37.528381
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 4 == 0)) == [[1, 2, 3], [5, 6, 7]]
    assert list(split_by(range(10), criterion=lambda x: x % 4 == 0, empty_segments=True)) == [[], [1, 2, 3], [], [5, 6, 7], []]
    assert list(split_by(range(10), criterion=lambda x: x % 4 == 1, empty_segments=True)) == [[0], [2, 3], [], [6, 7], []]
    assert list(split_by(range(10), criterion=lambda x: x % 4 == 2, empty_segments=True)) == [[0, 1], [3], [], [7], []]

# Generated at 2022-06-11 21:37:45.844737
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # Test LazyList iterating in two ways
    it = iter(LazyList([1, 2, 3]))
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    with pytest.raises(StopIteration):
        next(it)
    it = LazyList([1, 2, 3]).__iter__()
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    with pytest.raises(StopIteration):
        next(it)

# Generated at 2022-06-11 21:37:48.611959
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(range(10))
    assert len(l) == 10
    with pytest.raises(TypeError):
        len(LazyList([1, 2, 3]))



# Generated at 2022-06-11 21:37:54.390328
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                  ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]



# Generated at 2022-06-11 21:38:05.864868
# Unit test for function drop_until
def test_drop_until():
    # empty list
    list_empty = []
    assert list(drop_until(lambda x: x > 5, list_empty)) == []

    # all elements in the list satisfies the predicate
    list_all = [1, 1, 1, 1]
    assert list(drop_until(lambda x: x > 0, list_all)) == [1, 1, 1, 1]

    # some of the elements in the list satisfies the predicate
    list_some = [1, 2, 3, 4, 5]
    assert list(drop_until(lambda x: x > 3, list_some)) == [4, 5]

    # no elements in the list satisfies the predicate
    list_none = [1, 2, 3, 4, 5]
    assert list(drop_until(lambda x: x > 10, list_none)) == []

# Test

# Generated at 2022-06-11 21:38:09.657955
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(0, 11, 3)) == 0
    assert next(Range(0, 11, 3)) == 3
    assert next(Range(0, 11, 3)) == 6
    assert next(Range(0, 11, 3)) == 9
    assert pytest.raises(StopIteration, next, Range(0, 11, 3))

# Generated at 2022-06-11 21:38:20.486128
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [
        [0],
        [1],
        [2],
        [3],
        [4],
        [5],
        [6],
        [7],
        [8],
        [9],
    ]
    assert list(chunk(3, range(10))) == [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [9],
    ]
    assert list(chunk(10, range(10))) == [
        list(range(10)),
    ]
    assert list(chunk(100, range(10))) == [
        list(range(10)),
    ]



# Generated at 2022-06-11 21:38:24.516352
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(1,6,2)
    assert next(r) == 1
    assert next(r) == 3
    assert next(r) == 5
    try:
        next(r)
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-11 21:39:12.444569
# Unit test for function take
def test_take():
    assert list(take(3, [])) == []
    assert list(take(3, [1, 2])) == [1, 2]
    assert list(take(3, [1, 2, 3])) == [1, 2, 3]
    assert list(take(5, [1, 2, 3])) == [1, 2, 3]



# Generated at 2022-06-11 21:39:23.847371
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=lambda x: x % 3 == 0)) == []
    assert list(split_by([1, 2, 3, 4, 5], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == \
           [[1, 2], [], [4, 5], [], [7, 8], [], []]

# Generated at 2022-06-11 21:39:36.167476
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for cls in [Range, range]:
        assert isinstance(cls(1), Sequence)
        assert cls(1) == [0]
        assert cls(2) == [0, 1]
        assert cls(1, 2) == [1]
        assert cls(1, 3) == [1, 2]
        assert cls(1, 4) == [1, 2, 3]
        assert cls(1, 4, 2) == [1, 3]
        assert cls(1, 5, 2) == [1, 3]
        assert cls(1, 6, 2) == [1, 3, 5]
        assert cls(1, 7, 2) == [1, 3, 5]
        assert cls(1, 8, 2) == [1, 3, 5, 7]
        assert cl

# Generated at 2022-06-11 21:39:41.678436
# Unit test for function split_by
def test_split_by():
    import random
    import string
    import re
    for _ in range(100):
        for n in range(1, 10):
            lst = random.choices(range(10), k=n)
            for empty_segments in [True, False]:
                it1 = split_by(lst, empty_segments, criterion=lambda x: x % 3 == 0)
                it2 = iter(re.split(r"3", "".join(map(str, lst)), n if empty_segments else 1))
                for t1, t2 in zip(it1, it2):
                    lst2 = list(map(int, list(t2)))

# Generated at 2022-06-11 21:39:51.735490
# Unit test for function take
def test_take():
    # Test: take(0, iterable)
    assert list(take(0, [1, 2, 3])) == []
    # Test: take(n, None)
    assert list(take(10, None)) == []
    # Test: take(n, iterable)
    assert list(take(2, [1, 2, 3, 4, 5])) == [1, 2]
    assert list(take(10, [1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
    assert list(take(10, [])) == []
    # Test: take (negative)
    with pytest.raises(ValueError):
        list(take(-1, [1, 2, 3, 4]))



# Generated at 2022-06-11 21:39:54.364940
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(500))
    len_lst = len(lst)
    assert 500 == len_lst
test_LazyList___len__()



# Generated at 2022-06-11 21:39:57.762156
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 10, range(10))) == []



# Generated at 2022-06-11 21:40:03.461934
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(range(10))
    with pytest.raises(TypeError):
        n = len(l)
    l._fetch_until(None)
    assert len(l) == 10
    l = LazyList(range(10))
    l._fetch_until(5)
    with pytest.raises(TypeError):
        n = len(l)

# Generated at 2022-06-11 21:40:07.639150
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:40:10.370401
# Unit test for function drop
def test_drop():
    try:
        next(drop(5, range(10)))
    except StopIteration:
        return False
    else:
        return True

# Generated at 2022-06-11 21:40:48.687174
# Unit test for function take
def test_take():
    # test normal case
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    # test n = 0
    assert list(take(0, range(1, 10))) == []
    # test n > len(iterable)
    assert list(take(50, range(10))) == list(range(10))
    # test negative n
    try:
        list(take(-1, range(10)))
        assert False
    except ValueError:
        pass


# Generated at 2022-06-11 21:40:59.191978
# Unit test for function drop_until
def test_drop_until():
    iterable = list(range(10))
    try:
        assert(list(drop_until(lambda x: x > 5, iterable)) == [6, 7, 8, 9])
        assert(list(drop_until(lambda x: x > 5, iter(iterable))) == [6, 7, 8, 9])
        assert(list(drop_until(lambda x: x > 5, iterable[0:4])) == [])
        assert(list(drop_until(lambda x: x > -1, iterable[0:4])) == [0, 1, 2, 3])
        assert(list(drop_until(lambda x: x > 5, iter([1, 3, 5]))) == [])
    except Exception:
        raise

# Generated at 2022-06-11 21:41:10.256622
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    for n in range(10):
        for k in range(10):
            lst = LazyList(range(n))
            assert list(lst) == list(range(n))
            lst = LazyList(range(n))
            assert list(lst[:k]) == list(range(k))
            lst = LazyList(range(n))
            assert list(lst[k:]) == list(range(k, n))
            lst = LazyList(range(n))
            assert list(lst[k:n - k]) == list(range(k, n - k))
            lst = LazyList(range(n))
            assert list(lst[None:None:k]) == list(range(0, n, k))
            lst = LazyList(range(n))


# Generated at 2022-06-11 21:41:13.372402
# Unit test for function take
def test_take():
    st = [1,2,3,4,5]
    result = list(take(3, st))
    assert result == [1,2,3]
    st = []
    result = list(take(3, st))
    assert result == []


# Generated at 2022-06-11 21:41:17.352469
# Unit test for function chunk
def test_chunk():
    v = list(chunk(3,range(10)))
    assert v == [[0,1,2],[3,4,5],[6,7,8],[9]]
test_chunk()



# Generated at 2022-06-11 21:41:19.052657
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5,6,7,8,9]



# Generated at 2022-06-11 21:41:26.729023
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(-1, range(10))) == []
    assert list(chunk(10, [])) == []
    assert list(chunk(10, ())) == []



# Generated at 2022-06-11 21:41:37.801002
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]

# Generated at 2022-06-11 21:41:48.670239
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from hypothesis import given
    from hypothesis.strategies import lists
    from .strategies import iterables
    lst = LazyList([1, 2, 3])
    assert isinstance(lst.__iter__(), LazyList.LazyListIterator)
    assert list(lst.__iter__()) == [1, 2, 3]
    assert list(lst.__iter__()) == [1, 2, 3]
    assert list(lst.__iter__()) == [1, 2, 3]
    lst = LazyList(iter([1, 2, 3, 4]))
    assert list(lst.__iter__()) == [1, 2, 3, 4]
    assert list(lst.__iter__()) == [1, 2, 3, 4]

# Generated at 2022-06-11 21:41:52.055329
# Unit test for function drop_until
def test_drop_until():
    lst = range(10)
    assert list(drop_until(lambda x: x > 5, lst)) == list(drop(6, lst))


LazyList = Iterable[A]



# Generated at 2022-06-11 21:42:17.245913
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    with pytest.raises(ValueError):
        list(chunk(0, range(10)))



# Generated at 2022-06-11 21:42:24.433544
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(100))
    iter1 = lst.__iter__()
    iter2 = lst.__iter__()
    seq_iter = iter(lst)
    next(lst)  # fetch an element to make the iterable iterated
    assert lst[1] == seq_iter.__next__() == iter1.__next__() == iter2.__next__()



# Generated at 2022-06-11 21:42:26.086469
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:42:29.355774
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10, 2)
    print(r[0], r[2], r[4])
    print(r[:-1], r[0:3], r[2], r[-3:-1])



# Generated at 2022-06-11 21:42:32.736402
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
test_take()



# Generated at 2022-06-11 21:42:34.756244
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:42:43.259290
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(5, [])) == []
    assert list(take(5, (i for i in range(10) if i % 2 == 0))) == [0, 2, 4, 6, 8]



# Generated at 2022-06-11 21:42:48.287830
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == list(range(6, 10))
    assert list(drop_until(lambda x: x % 2 == 0, range(10))) == list(range(0, 10, 2))
    assert list(drop_until(lambda x: x % 2 == 1, range(10))) == list(range(1, 10, 2))



# Generated at 2022-06-11 21:42:57.565207
# Unit test for function chunk
def test_chunk():
    test_cases = []

    def test_chunk_case(n, iterable, expected):
        test_cases.append(lambda self: self.assertEqual(list(chunk(n, iterable)), expected))

    test_chunk_case(3, range(10), [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]])
    test_chunk_case(1, range(10), [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]])
    test_chunk_case(0, range(10), [])
    test_chunk_case(3, [], [])

    with self_test(test_cases): pass



# Generated at 2022-06-11 21:43:01.902446
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(5))) == list(range(5))
    assert list(drop(5, range(5))) == []
    assert list(drop(-1, range(5))) == list(range(5))
    assert list(drop(1, [])) == []



# Generated at 2022-06-11 21:43:54.526455
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, [])) == []
    assert list(chunk(1, [])) == []
    assert list(chunk(3, [])) == []
    assert list(chunk(0, range(3))) == [[]] * 3
    assert list(chunk(1, range(3))) == [[0], [1], [2]]
    assert list(chunk(2, range(3))) == [[0, 1], [2]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(4, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
# Test case: chunk(0, range(3))
# Uncomment the following line to generate test

# Generated at 2022-06-11 21:44:06.959317
# Unit test for function chunk

# Generated at 2022-06-11 21:44:09.928899
# Unit test for function drop
def test_drop():
    assert list(drop(1, [])) == []
    assert list(drop(0, [1, 2, 3])) == [1, 2, 3]
    assert list(drop(2, [1, 2, 3])) == [3]



# Generated at 2022-06-11 21:44:17.199560
# Unit test for function drop_until
def test_drop_until():
    try:
        drop_until(lambda x: x>10, range(100))
    except :
        pass
    assert list(drop_until(lambda x: x>5, range(10)))==[6,7,8,9]
    assert list(drop_until(lambda x: x>0, range(10)))==[1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: x>0, range(-10,1)))==[1,0]
    assert list(drop_until(lambda x: x<0, range(-10,0)))==[]
    assert list(drop_until(lambda x: x<0, range(0,10)))==[]

# Generated at 2022-06-11 21:44:21.268534
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    for my_LazyList in [LazyList([]),
                        LazyList([0, 1]),
                        LazyList([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])]:
        assert len(my_LazyList) == my_LazyList[:]

# Generated at 2022-06-11 21:44:24.155295
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-11 21:44:29.331098
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for i in range(0, 2):
        for k in range(-2, 3):
            for j in range(0, 5):
                pos = list(range(10))[k:j]
                val = list(map(lambda x: x * 2, pos))
                assert MapList(lambda x: x * 2, pos) == val
    for i in range(0, 2):
        for k in range(0, 10):
            assert MapList(lambda x: x * 2, list(range(10)))[k] == k * 2


# Generated at 2022-06-11 21:44:34.369592
# Unit test for function drop
def test_drop():
    from itertools import count
    assert sum(take(10, drop(1, count()))) == 45
    try:
        assert list(drop(10, count())) == list(range(10))
    except MemoryError:
        print("drop is implemented correctly")
test_drop()



# Generated at 2022-06-11 21:44:37.661082
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]

test_chunk()



# Generated at 2022-06-11 21:44:45.996883
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(5, range(10))) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]
    assert list(chunk(6, range(10))) == [[0, 1, 2, 3, 4, 5], [6, 7, 8, 9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(-1, range(10))) == []
test_chunk()



# Generated at 2022-06-11 21:46:09.423306
# Unit test for method __len__ of class LazyList
def test_LazyList___len__(): pass



# Generated at 2022-06-11 21:46:18.162052
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    L = LazyList(range(0))
    L = LazyList(range(1))
    L = LazyList(range(2))
    r = False
    try:
        L[2]
    except IndexError:
        r = True
    test.assert_(r, "__getitem__ failed")
    L = LazyList(range(10))
    L[2]
    r = False
    try:
        L[20]
    except IndexError:
        r = True
    test.assert_(r, "__getitem__ failed")

# Generated at 2022-06-11 21:46:25.797877
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x < 0, range(10))) == list(range(10))
    assert list(drop_until(lambda x: x > 5, range(-5, 10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x < 0, range(-5, 10))) == []



# Generated at 2022-06-11 21:46:27.261574
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert (len(LazyList([1,2,3])) == 3)



# Generated at 2022-06-11 21:46:37.580140
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10) == list(Range(10))
    assert Range(1, 11) == list(Range(1, 11))
    assert Range(1, 11, 2) == list(Range(1, 11, 2))
    assert len(Range(10)) == 10
    assert len(Range(1, 11)) == 10
    assert len(Range(1, 11, 2)) == 5
    assert Range(10)[0] == 0
    assert Range(10)[1] == 1
    assert Range(10)[2] == 2
    assert Range(1, 11)[0] == 1
    assert Range(1, 11)[1] == 2
    assert Range(1, 11)[2] == 3
    assert Range(1, 11, 2)[0] == 1
    assert Range(1, 11, 2)[1] == 3

# Generated at 2022-06-11 21:46:39.599740
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(range(10))
    assert len(l) == 10



# Generated at 2022-06-11 21:46:47.520473
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([])) == 0
    assert len(LazyList([1])) == 1
    assert len(LazyList([1, 2, 3])) == 3
    assert len(LazyList([1, 2, 3])[:1]) == 1
    assert len(LazyList([1, 2, 3])[:2]) == 2
    assert len(LazyList([1, 2, 3])[1:]) == 2
    assert len(LazyList([1, 2, 3])[:-1]) == 2
    assert len(LazyList(range(3))) == 3
    assert len(LazyList([1, 2, 3])[:]) == 3
    assert len(LazyList([1, 2, 3])[::-1]) == 3

# Generated at 2022-06-11 21:46:56.828862
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import hypothesis.strategies as st
    from hypothesis import given

    @given(st.integers(min_value=0, max_value=100))
    def test_range_getitem(val):
        r = Range(val)
        assert r[val - 1] == val - 1
        assert r[range(val)] == list(range(val))
        assert r[slice(0, val, 4)] == list(range(0, val, 4))
        assert r[slice(0, val + 1, 2)] == list(range(0, val + 1, 2))
