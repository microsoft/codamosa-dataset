

# Generated at 2022-06-11 21:37:34.162584
# Unit test for function take
def test_take():
    x = take(4, range(10))
    for i, xi in enumerate(x):
        assert i == xi
    x = take(2, range(10))
    for i, xi in enumerate(x):
        assert i == xi
    assert list(take(0, range(10))) == []
    assert list(take(10, range(10))) == list(range(10))
test_take()



# Generated at 2022-06-11 21:37:39.635338
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-11 21:37:46.162312
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    if 0:
        r=Range(10)         # (end)
        r=Range(1, 10 + 1)  # (start, end)
        r=Range(1, 11, 2)   # (start, end, step)
        print(r[0], r[2], r[4])
    pass
if __name__ == "__main__":
    test_Range___getitem__()


# Generated at 2022-06-11 21:37:55.531680
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import pytest
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[-3] == 7
    assert r[9] == 9
    assert r[:2] == [0, 1]
    assert r[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert r[:6:2] == [0, 2, 4]
    assert r[1::2] == [1, 3, 5, 7, 9]
    assert r[5:1:-1] == [5, 4, 3, 2]
    assert r[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    assert r[5:5] == []
   

# Generated at 2022-06-11 21:38:06.147526
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert(Range(10)[0] == 0)
    assert(Range(10)[1] == 1)
    assert(Range(10)[9] == 9)
    try:
        assert(Range(10)[10] == 10)
        assert(False)
    except IndexError:
        pass
    try:
        assert(Range(10)[-1] == 9)
        assert(False)
    except IndexError:
        pass
    try:
        assert(Range(5)[5] == 10)
        assert(False)
    except IndexError:
        pass
    #
    assert(Range(0, 10)[0] == 0)
    assert(Range(0, 10)[1] == 1)
    assert(Range(0, 10)[9] == 9)

# Generated at 2022-06-11 21:38:10.528692
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
	# Argument type: int
	# Arguments for MapList:
	# - func = <function <lambda> at 0x7fadbae54f28>
	# - lst = [1, 2, 3, 4, 5]
	obj = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
	value = obj[2]
	return value == 9

# Generated at 2022-06-11 21:38:12.920249
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_value = Range(3, 6)
    assert test_value[0] == 3
    assert test_value[2] == 5


# Generated at 2022-06-11 21:38:15.524791
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:38:17.884636
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x * x, [1, 2, 3, 4])
    assert lst[0] == 1
    assert lst[1] == 4
    assert lst[2] == 9
    assert isinstance(lst[0], int)
    assert lst[0:3] == [1, 4, 9]


# Generated at 2022-06-11 21:38:25.012346
# Unit test for function split_by
def test_split_by():
    a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    b = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(split_by(a, separator=0)) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]]
    assert list(split_by(a, criterion=lambda x: x % 2 == 0)) == \
           [[1], [3], [5], [7], [9]]
    assert list(split_by(b, criterion=lambda x: x % 3 == 0)) == \
           [[1, 2], [4, 5], [7, 8]]

# Generated at 2022-06-11 21:38:44.488424
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    
    r = Range(3, 6)
    
    assert (r[0] == 3)
    assert (r[1] == 4)
    assert (r[2] == 5)
    assert (r[-3] == 3)
    assert (r[-2] == 4)
    assert (r[-1] == 5)
    assert (r[:] == [3, 4, 5])
    assert (r[::-1] == [5, 4, 3])
    assert (r[::2] == [3, 5])
    assert (r[::-2] == [5, 3])
    assert (r[1:3:1] == [4, 5])

# Generated at 2022-06-11 21:38:47.825695
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by:. ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                  ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:38:51.834452
# Unit test for function take
def test_take():
    actual = list(take(5, range(10)))
    # print(actual)
    assert actual == [0,1,2,3,4]


# Generated at 2022-06-11 21:39:02.412896
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    '''
    Test method __getitem__ of class Range
    '''
    assert Range(10)[0] == 0
    assert Range(10)[1] == 1
    assert Range(10)[2] == 2
    assert Range(10)[3] == 3
    assert Range(10)[4] == 4
    assert Range(10)[5] == 5
    assert Range(10)[6] == 6
    assert Range(10)[7] == 7
    assert Range(10)[8] == 8
    assert Range(10)[9] == 9
    assert Range(0, 10, 2)[0] == 0
    assert Range(0, 10, 2)[1] == 2
    assert Range(0, 10, 2)[2] == 4
    assert Range(0, 10, 2)[3] == 6

# Generated at 2022-06-11 21:39:08.182048
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']



# Generated at 2022-06-11 21:39:15.068953
# Unit test for function split_by
def test_split_by():
    l1 = list(split_by(range(10), criterion=lambda x: x % 3 == 0))
    assert l1 == [[1, 2], [4, 5], [7, 8]]
    l2 = list(split_by(" Split by", empty_segments=True, separator=' '))
    assert l2 == [[], ['S', 'p', 'l', 'i', 't', 'b', 'y'], []]



# Generated at 2022-06-11 21:39:17.956398
# Unit test for function drop
def test_drop():
    assert list(take(10, drop(5, range(100)))) == list(range(5, 15))



# Generated at 2022-06-11 21:39:25.986092
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[9] == 9
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[3:6] == [3, 4, 5]
    assert lst[6:2:-1] == [6, 5, 4]

# Generated at 2022-06-11 21:39:37.688237
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x * y, range(1, 5))) == [1, 1, 2, 6, 24]
    assert list(scanl(lambda x, y: x - y, range(1, 5), 0)) == [0, -1, -3, -6, -10]
    assert list(scanl(lambda x, y: x + y, range(1, 5), initial=0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda x, y: x - y, range(1, 5))) == [1, 0, -2, -5, -9]
    assert list(scanl(lambda x, y: y - x, range(1, 5))) == [1, 2, -1, -5, -11]

# Generated at 2022-06-11 21:39:49.735333
# Unit test for function split_by
def test_split_by():
    assert list(split_by(' Split by: ')) == [
        ['S', 'p', 'l', 'i', 't'],
        ['b', 'y', ':'],
    ]
    assert list(split_by(' Split by: ', empty_segments=True)) == [
        [],
        ['S', 'p', 'l', 'i', 't'],
        ['b', 'y', ':'],
        [],
    ]
    assert list(split_by(' Split by: ', separator='.')) == [
        ['S', 'p', 'l', 'i', 't'],
        ['b', 'y', ':'],
    ]

# Generated at 2022-06-11 21:39:56.954213
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-11 21:40:06.411433
# Unit test for function split_by
def test_split_by():
    # First test case
    def test_case(lst, criterion, empty_segments):
        lst = split_by(lst, criterion=criterion, empty_segments=empty_segments)
        expected = [list(drop_until(criterion, lst))[i::2] for i in (0, 1)]
        assert list(lst) == expected

    for criterion in (lambda x: x % 3 == 0, lambda x: x > 2):
        for empty_segments in (True, False):
            for lst in (range(32), [1, 2, 3, 10, 4]):
                yield test_case, lst, criterion, empty_segments
    # Second test case

# Generated at 2022-06-11 21:40:08.445349
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == list(range(6, 10))



# Generated at 2022-06-11 21:40:18.705871
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[-1] == 10
    assert r[::2] == [1, 3, 5, 7, 9]
    assert r[1:] == [2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert r[::-2] == [10, 8, 6, 4, 2]
    assert r[-2:] == [9, 10]
    assert r[::-1] == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
    assert r[1:3] == [2, 3]
    assert r[3:1] == []
    assert r[:3] == [1, 2, 3]

# Generated at 2022-06-11 21:40:21.434345
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    args = (5,5,5,5,5,5)
    r = utils.Range(*args)
    assert(r.__getitem__(None) == 5)


# Generated at 2022-06-11 21:40:28.415083
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    print("Test MapList.__getitem__")
    print("Testing with object LazyIntSequenceOverFiniteIterable")
    obj = LazyIntSequenceOverFiniteIterable([0, 1, 2, 3, 4], [])
    print("obj.__getitem__(None) == None")
    print(obj.__getitem__(None) == None)
    print("obj.__getitem__(0) == 0")
    print(obj.__getitem__(0) == 0)
    print("obj.__getitem__(4) == 4")
    print(obj.__getitem__(4) == 4)
    print("obj.__getitem__(-1) == 4")
    print(obj.__getitem__(-1) == 4)

# Generated at 2022-06-11 21:40:36.058992
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 2, [])) == []
    assert list(drop_until(lambda x: x > 2, range(10))) == [3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 20, range(10))) == []
    assert list(drop_until(lambda x: x > 3, [1, 2, 3, 4, 5])) == [4, 5]
    assert list(drop_until(lambda x: x < 5, range(5, 10))) == []


# Generated at 2022-06-11 21:40:42.983530
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Test: [(), (), (), (), (), (), (), (), (), (), (), ()]
    print(Range(11)[:])
    # Test: [(), (), (), (), (), (), (), (), (), (), (), ()]
    print(Range(1, 11 + 1)[:])
    # Test: [(), (), (), (), (), (), (), (), (), (), (), ()]
    print(Range(1, 11, 1)[:])
    # Test: []
    print(Range(0)[:])
    # Test: []
    print(Range(10, 0)[:])
    # Test: []
    print(Range(10, 10)[:])
    # Test: []
    print(Range(10, 0, -1)[:])
    # Test: [(), (), (), (), (), (), (), (), (), ()]
    print(Range(0, 10)[:])
    #

# Generated at 2022-06-11 21:40:47.434335
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(1, range(10))) == list(range(1, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(10000, range(10))) == []


# Generated at 2022-06-11 21:40:55.243112
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(6)
    try:
        r[0]
        return False
    except:
        pass
    r = Range(0, 6, 1)
    if len(r) != 6:
        return False
    try:
        r[0]
        return False
    except:
        pass

    # case 1
    if r[2] != 2:
        return False

    # case 2
    if r[-1] != 5:
        return False

    # case 3
    if r[-6] != 0:
        return False

    # case 4
    if r[-7] != 0:
        return False

    # case 5
    if r[-6:] != [0, 1, 2, 3, 4, 5]:
        return False

    # case 6

# Generated at 2022-06-11 21:41:22.681676
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[-1] == 9
    assert lst[:3] == [0, 1, 2]
    assert lst[2:] == [2, 3, 4, 5, 6, 7, 8, 9]
    assert lst[-3:] == [7, 8, 9]
    assert lst[:] == list(range(10))
    lst2 = LazyList(range(1000))
    assert lst2[:3] == [0, 1, 2]

# Generated at 2022-06-11 21:41:25.000750
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    llist = LazyList(range(10))
    assert llist[1] == 1
    assert llist[:3] == [0, 1, 2]
    assert llist[5] == 5


# Generated at 2022-06-11 21:41:36.318697
# Unit test for function take
def test_take():
    assert take(3, [1, 2, 3, 4, 5]) == [1, 2, 3]
    assert take(0, [1, 2, 3, 4, 5]) == []
    assert take(100, [1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert take(3, iter([1, 2, 3, 4, 5])) == [1, 2, 3]
    assert take(0, iter([1, 2, 3, 4, 5])) == []
    assert take(100, iter([1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
    assert take(5, range(5)) == [0, 1, 2, 3, 4]


# Generated at 2022-06-11 21:41:46.827799
# Unit test for function drop_until
def test_drop_until():
    from functools import partial
    from hypothesis import assume, given, settings
    import hypothesis.strategies as st
    import itertools

    def drop_until_mutable_list(pred_fn, lst):
        pred_fn_ref = weakref.ref(pred_fn)
        if not lst or pred_fn(lst[0]):
            return lst
        return drop_until_mutable_list(pred_fn_ref, lst[1:])

    def drop_until_equal(pred_fn, iterable):
        return list(drop_until(pred_fn, iterable))

    def drop_until_equal_by_mutate(pred_fn, it):
        prefix = list(itertools.islice(it, 1, None))


# Generated at 2022-06-11 21:41:57.439319
# Unit test for function take
def test_take():
    import random
    assert list(take(0, range(100))) == []
    assert list(take(1, range(100))) == [0]
    assert list(take(5, range(100))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(5))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(3))) == [0, 1, 2]
    assert list(take(20, range(100))) == list(range(100))
    assert list(take(0, range(100))) == []

    with pytest.raises(ValueError):
        list(take(-1, range(100)))

    l = list(range(100))
    random.shuffle(l)
    assert list(take(0, l)) == []
   

# Generated at 2022-06-11 21:42:03.975565
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [0, 1, 2]
    r = MapList(lambda x: x * x, lst)
    assert r[0] == 0
    assert r[1] == 1
    assert r[0] == 0
    assert r[2] == 4
    assert r[1] == 1
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 4

    assert r[0:3] == [0, 1, 4]


# Generated at 2022-06-11 21:42:08.104233
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[1:3] == [1, 2]
    assert r[1:9:2] == [1, 3, 5, 7]
test_Range___getitem__()

# Generated at 2022-06-11 21:42:12.272758
# Unit test for function drop_until
def test_drop_until():
    l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(drop_until(lambda x: x > 5, l)) == [6, 7, 8, 9, 10]


# Generated at 2022-06-11 21:42:22.857439
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import inspect
    from typing import Union

# Generated at 2022-06-11 21:42:31.043400
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    list1 = ["1", "2", "3", "4", "5"]
    list2 = [64, 25, 36, 49, 81, 100]
    list3 = [1, 4, 9, 16, 25, 36, 49]
    list3 = range(1,10)
    list3 = [1, 2, 3, 4, 5, 6, 7, 8, 9]

    list1 = [int(x) for x in list1]
    list2 = [x**2 for x in list2]
    list3 = [x**2 for x in list3]

    list1 = MapList(lambda x:x**2, list1)
    list2 = MapList(lambda x:x**2, list2)
    list3 = MapList(lambda x:x**2, list3)


# Generated at 2022-06-11 21:42:40.041019
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 10, range(10, 20))) == [11, 12, 13, 14, 15, 16, 17, 18, 19]
    assert list(drop_until(lambda x: x > 10, range(10, 0, -1))) == []



# Generated at 2022-06-11 21:42:45.618098
# Unit test for function take
def test_take():
    assert list(take(-1, ['a', 'b', 'c'])) == []
    assert list(take(10, ['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert list(take(3, ['a', 'b', 'c'])) == ['a', 'b', 'c']



# Generated at 2022-06-11 21:42:52.765805
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random

    def generate_random_ints(n=math.inf, m=0, M=1 << 32):
        while n > 0:
            yield random.randint(m, M)
            n -= 1

    n = 1 << 18
    ints = LazyList(generate_random_ints(n))
    assert len(ints) == n
    assert ints[n - 1] == ints[-1]
    assert ints[:n - 1] == ints[:-1]

# Generated at 2022-06-11 21:42:59.688561
# Unit test for function scanl
def test_scanl():
    import pytest
    # Test with initial
    assert list(scanl(operator.add, [1, 2, 3], 0)) == [0, 1, 3, 6]
    assert list(scanl(lambda x, y: x + y, [], 0)) == [0]
    assert list(scanl(lambda x, y: x + y, [], "")) == [""]
    # Test without initial
    assert list(scanl(operator.add, [1, 2, 3])) == [1, 3, 6]
    assert list(scanl(operator.add, [])) == []
    assert list(scanl(lambda x, y: x + y, ['A', 'B'])) == ['A', 'AB']
    assert list(scanl(lambda x, y: x + y, ['A'])) == ['A']

# Generated at 2022-06-11 21:43:05.686307
# Unit test for function take
def test_take():
    assert list(take(5, range(10)))==[0,1,2,3,4]
    assert list(take(0, range(10)))==[]
    assert list(take(11, range(10)))==range(10)
    assert list(take(5, range(0)))==[]
    assert list(take(5, range(1)))==[0]


# Generated at 2022-06-11 21:43:12.250266
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 10, range(10))) == []
    assert list(drop_until(lambda x: x == True, [False, False, True, True, True])) == [True, True, True]



# Generated at 2022-06-11 21:43:21.898802
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[]]
    assert list(split_by([1, 2], empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[1, 2]]
    assert list(split_by([3, 1, 2], empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[], [1, 2]]
    assert list(split_by([1, 2, 3, 4], empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[1, 2], [4]]

# Generated at 2022-06-11 21:43:25.547932
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    ml = MapList(lambda x: x * x, a)
    assert ml[2] == 9
    assert ml[0:2] == [1, 4]



# Generated at 2022-06-11 21:43:33.556471
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:43:40.909620
# Unit test for function drop_until
def test_drop_until():
    data = [1,2,3,4,5,6,7,8,9,10]
    new_data = drop_until(lambda x: x > 5, data)
    for item in new_data:
        print(item)

if __name__ == "__main__":
    print("-----Testing drop_until function-----")
    test_drop_until()
    print("-----Function drop_until is tested-----")



# Generated at 2022-06-11 21:44:04.989638
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    a = [1, 2, 3, 4, 5]
    map_list = MapList(lambda x: x * x, a)
    assert map_list[0] == 1
    assert map_list[1] == 4
    assert map_list[-1] == 25
    assert map_list[:] == [1, 4, 9, 16, 25]
    assert map_list[2:5] == [9, 16, 25]
    assert map_list[2:5:2] == [9, 25]
    assert map_list[::-1] == [25, 16, 9, 4, 1]


# Generated at 2022-06-11 21:44:14.052488
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(0, 12, 3)[3] == 9
    assert Range(0, 12, 3)[-1] == 9
    assert Range(0, 12, 3)[-4] == 0
    assert Range(0, 12, 3)[-5] == -3
    assert Range(0, 12, 3)[5:6] == [15]
    assert Range(0, 12, 3)[-5:-1] == [0, 3, 6, 9]
    assert Range(0, 10)[1:3] == [1, 2]
    assert Range(0, 10)[3:3] == []
    assert Range(0, 10)[-1:1] == []
    assert Range(0, 10)[1:1] == []
    assert Range(0, 10)[::3] == [0, 3, 6, 9]
    assert Range

# Generated at 2022-06-11 21:44:24.151230
# Unit test for function split_by

# Generated at 2022-06-11 21:44:34.769607
# Unit test for function split_by
def test_split_by():
    for criterion, x in [(lambda x: x % 3 == 0, range(10)),
                         (None, 'Split by '),
                         (None, list('Split by!')),
                         (None, list(range(10)))]:
        if criterion is None:
            criterion = lambda x: x == ' '
        assert list(split_by(x, criterion=criterion)) == [list(y) for y in split_by(x, criterion=criterion)]
        assert list(split_by(x, empty_segments=True, criterion=criterion)) == \
            [list(y) for y in split_by(x, empty_segments=True, criterion=criterion)]
        assert list(split_by(x, separator=' ')) == [list(y) for y in split_by(x, separator=' ')]
       

# Generated at 2022-06-11 21:44:38.046693
# Unit test for function drop_until
def test_drop_until():
    iterable = range(10)
    for n in range(10):
        assert list(drop_until(lambda x: x > n, iterable)) == list(range(n + 1, 10))



# Generated at 2022-06-11 21:44:40.080647
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]


# Generated at 2022-06-11 21:44:44.008834
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-11 21:44:50.209120
# Unit test for function take
def test_take():
    for n in range(5):
        assert list(take(n, (0, 1, 2, 3, 4, 5))) == [0, 1, 2, 3, 4][:n]
    assert list(take(5, (0, 1, 2))) == [0, 1, 2]
    assert list(take(0, (0, 1, 2))) == []
    assert list(take(-1, (0, 1, 2))) == [0, 1, 2]



# Generated at 2022-06-11 21:44:53.646672
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: True, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: False, range(10))) == []



# Generated at 2022-06-11 21:45:06.343325
# Unit test for function drop_until
def test_drop_until():
    def fn(x): return x > 5
    lst = list(range(10))
    assert lst == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(fn, lst)) == [6, 7, 8, 9]
    assert list(drop_until(fn, [])) == []
    assert list(drop_until(fn, (x for x in lst))) == [6, 7, 8, 9]
    # fn always False
    def fn(x): return False
    assert list(drop_until(fn, lst)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # fn always True
    def fn(x): return True

# Generated at 2022-06-11 21:46:19.482866
# Unit test for function drop_until
def test_drop_until():
    data = range(1000)
    for i in range(1000):
        assert list(drop_until(lambda x: x > i, data)) == data[i:]



# Generated at 2022-06-11 21:46:30.994856
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2, 3, 4], criterion=lambda x: x % 2 == 0)) == [[1, 3]]
    assert list(split_by([1, 2, 3, 4], criterion=lambda x: x % 2 == 0, empty_segments=True)) == [[1], [3]]
    assert list(split_by([1, 2, 0, 3, 4], criterion=lambda x: x % 2 == 0)) == [[1], [3]]
    assert list(split_by([1, 2, 0, 0, 3, 4], criterion=lambda x: x % 2 == 0)) == [[1], [], [3]]

# Generated at 2022-06-11 21:46:36.172163
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9

    assert Range(1, 11, 2)[:3] == [1, 3, 5]
    assert Range(1, 11, 2)[1::2] == [3, 7]


# Generated at 2022-06-11 21:46:42.645924
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    d = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert all(d[i] == (i + 1) * (i + 1) for i in range(5))
    assert d[-1] == 25
    assert d[1:3] == [4, 9]


# Generated at 2022-06-11 21:46:53.834289
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from math import pi
    from typing import Any
    from lztools import LazyList
    from dataclasses import dataclass
    from math import sqrt
    @dataclass
    class Pair:
        first: Any
        second: Any
        def __round__(self, ndigits: int = 0) -> 'Pair':
            return Pair(round(self.first, ndigits), round(self.second, ndigits))
    N = 10**5
    def fibonacci_sequence():
        a, b = 0, 0
        while True:
            yield a
            a, b = b, a + b
    def even_fibonacci_sequence():
        for x in fibonacci_sequence():
            if x % 2 == 0:
                yield x