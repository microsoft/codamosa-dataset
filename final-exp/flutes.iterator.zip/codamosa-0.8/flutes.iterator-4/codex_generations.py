

# Generated at 2022-06-11 21:37:33.649261
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from itertools import count
    from operator import mul
    from random import randint

    for _ in range(1000):
        start = randint(1, 1000)
        end = randint(start + 1, 1000)
        list1 = range(start, end)
        list2 = LazyList(list1)
        for i in range(end):
            assert list1[i] == list2[i]
    for _ in range(1000):
        start = randint(1, 1000)
        end = randint(start + 1, 1000)
        slice1 = slice(randint(start, end - 1), randint(start, end - 1))
        slice2 = LazyList(range(start, end))[slice1]
        assert list(range(*slice1.indices(end))) == slice2

# Generated at 2022-06-11 21:37:36.080023
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-11 21:37:44.448563
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > -1, [int(1e9)])) == [int(1e9)]
    assert list(drop_until(lambda x: x > 1, [1, 0, 1, 1, 0])) == [0, 1, 1, 0]
    assert list(drop_until(lambda x: x > 1, range(5))) == list(range(5))
    assert list(drop_until(lambda x: x > 1, [])) == []
    assert list(drop_until(lambda x: x > 1, [1, 2, 1, 2])) == [2, 1, 2]

# Generated at 2022-06-11 21:37:46.533566
# Unit test for function take
def test_take():
    assert list(take(5, range(100))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:37:55.808861
# Unit test for function drop_until
def test_drop_until():
    from hypothesis import given
    from hypothesis.strategies import integers, lists
    @given(lists(integers()))
    def test(xs):
        assert list(drop_until(lambda _: False, xs)) == xs
        assert list(drop_until(lambda _: True,  xs)) == xs
        assert list(drop_until(lambda x: x < 0, xs)) == xs
        assert list(drop_until(lambda x: x > 0, xs)) == drop_until(lambda x: x > 0, xs)
        if not xs:
            return
        assert list(drop_until(lambda x: x == xs[0], xs)) == xs

# Generated at 2022-06-11 21:37:58.203054
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-11 21:38:05.783911
# Unit test for function take
def test_take():
    assert list(take(2, [1, 2, 3])) == [1, 2]
    assert list(take(3, range(10))) == list(range(3))
    assert list(take(100, range(10))) == list(range(10))
    assert list(take(0, range(10))) == []
    assert list(take(10, [])) == []
    assert list(take(10, [1])) == [1]
    assert list(take(10, [1, 2])) == [1, 2]

test_take()



# Generated at 2022-06-11 21:38:17.042356
# Unit test for function drop
def test_drop():
    it = drop(0, [])
    assert(next(it, None) is None)
    it = drop(0, [3])
    assert(next(it) == 3)
    it = drop(1, [])
    assert(next(it, None) is None)
    it = drop(1, [3])
    assert(next(it, None) is None)
    it = drop(2, [])
    assert(next(it, None) is None)
    it = drop(2, [3])
    assert(next(it, None) is None)
    it = drop(3, [3])
    assert(next(it, None) is None)
    it = drop(3, [5, 3])
    assert(next(it, None) is None)

# Generated at 2022-06-11 21:38:23.173395
# Unit test for function take
def test_take():
    from .testing import assert_iterator_equals
    assert_iterator_equals(list(range(1000)), take(1000, range(1000000)))
    assert_iterator_equals(list(range(1000)), take(1000, iter(range(1000000))))
    assert_iterator_equals(list(range(1000)), take(1000, Range(1000000)))
    assert_iterator_equals(list(range(1000)), take(1000, MapList(lambda x: x, range(1000000))))
    assert_iterator_equals([], take(1000, []))



# Generated at 2022-06-11 21:38:30.193628
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

test_split_by()



# Generated at 2022-06-11 21:38:40.229927
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[1] == 1
    assert list(lst) == list(range(10))
    lst = LazyList(range(10))
    assert list(lst[:3]) == [0, 1, 2]
    assert list(lst) == list(range(10))



# Generated at 2022-06-11 21:38:49.335915
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect

    # Find index of the first element in `a` whose square is >= 10.
    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert(pos == 3)

    # Find the first index `i` such that `a[i] * b[i]` is >= 10.
    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert(pos == 2)


# Generated at 2022-06-11 21:38:57.008431
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:39:01.859974
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == [0, 1, 2]
    assert list(take(10, range(3))) == [0, 1, 2]
    assert list(take(0, range(3))) == []
    assert list(take(0, [])) == []
    with pytest.raises(ValueError):
        list(take(-3, range(10)))
test_take()



# Generated at 2022-06-11 21:39:14.383015
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    class TestSequence:
        def __len__(self):
            raise TypeError("Sequence count is not available")

        def __getitem__(self, idx):
            if idx < 3:
                return idx
            raise IndexError("List index out of range")

    lst = LazyList(TestSequence())
    # lst.__len__()
    with pytest.raises(TypeError):
        len(lst)
    # lst[0]
    assert lst[0] == 0
    # lst.__len__()
    with pytest.raises(TypeError):
        len(lst)
    # lst[2]
    assert lst[2] == 2
    # lst.__len__()
    assert len(lst) == 3
    # lst[

# Generated at 2022-06-11 21:39:18.363205
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    # Type: Callable[[LazyList[int]], int]
    x = LazyList(range(3))
    assert x.__len__() == 3



# Generated at 2022-06-11 21:39:20.465825
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList([1, 2, 3, 4, 5])
    assert len(list(ll.__iter__())) == 5


# Generated at 2022-06-11 21:39:25.571982
# Unit test for function drop_until
def test_drop_until():
    # Test for dropping elements until the first negative number is encountered
    assert (list(drop_until(lambda x: x < 0, list(range(3)) + [0, 0, -1, 2, 3] + list(range(5, 8)))) ==
            [0, -1, 2, 3, 5, 6, 7])



# Generated at 2022-06-11 21:39:28.732453
# Unit test for function take
def test_take():
    assert list(take(3, [1,2,3,4,5])) == list(take(3, range(5)))
    

# Generated at 2022-06-11 21:39:35.741697
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    r1 = list(r)
    r2 = r[:]
    assert r1 == r2
    r1 = list(r[1:5])
    r2 = r[1:5]
    assert r1 == r2
    assert len(r1) == 4
    assert len(r2) == 4
    assert r[4] == 5
    assert r[-1] == 10


# Generated at 2022-06-11 21:39:47.290359
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    for i in range(10):
        assert lst[i] == i


# Generated at 2022-06-11 21:39:50.875408
# Unit test for function take
def test_take():
    assert list(take(3, range(6))) == [0, 1, 2]
    assert list(take(-2, range(6))) == []
    assert list(take(6, range(6))) == list(range(6))
    assert list(take(6, range(3))) == list(range(3))
    assert list(take(0, range(6))) == []

test_take()


# Generated at 2022-06-11 21:39:56.607831
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert [r[i] for i in range(10)] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    r = Range(1, 11, 2)
    assert [r[i] for i in range(5)] == [1, 3, 5, 7, 9]
    r = Range(2, 9, 3)
    assert [r[i] for i in range(3)] == [2, 5, 8]

# Generated at 2022-06-11 21:40:04.618126
# Unit test for function split_by

# Generated at 2022-06-11 21:40:12.078732
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(0))) == []
    assert list(drop(0, range(1))) == [0]
    assert list(drop(1, range(1))) == []
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(100, range(10))) == []



# Generated at 2022-06-11 21:40:14.864737
# Unit test for function drop_until
def test_drop_until():
    l_list = [10, 20, 30, 40]
    def check(x):
        return x%10 == 0
    assert list(drop_until(check, l_list)) == l_list



# Generated at 2022-06-11 21:40:20.216352
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert list(LazyList(range(100))[5:10]) == [5, 6, 7, 8, 9]
    assert LazyList(range(100))[5] == 5
    with pytest.raises(TypeError):
        len(LazyList(range(100)))
    assert len(LazyList(range(100))) == 100



# Generated at 2022-06-11 21:40:22.182813
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-11 21:40:24.408741
# Unit test for function drop_until
def test_drop_until():
    assert tuple(drop_until(lambda x: x > 5, range(10))) == (6, 7, 8, 9)


# Generated at 2022-06-11 21:40:30.072017
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(1))) == [0]
    assert list(take(0, range(10))) == []
    assert list(take(5, [])) == []
    assert list(take(-5, range(10))) == []



# Generated at 2022-06-11 21:40:50.568514
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:40:58.244740
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(1, range(10))) == [0]
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(100, range(10))) == list(range(10))
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(11, range(10))) == list(range(10))
    assert list(take(0, [])) == []
    assert list(take(1, [])) == []
    assert list(take(10, [])) == []


# Generated at 2022-06-11 21:40:59.951770
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert [1, 4, 9] == [i ** 2 for i in range(3)]

# Generated at 2022-06-11 21:41:05.601488
# Unit test for function take
def test_take():
    assert list(take(5, [])) == []
    assert list(take(0, range(100))) == []
    assert list(take(5, range(100))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(5))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:41:08.595473
# Unit test for function drop
def test_drop():
    a = range(100)
    b = list(drop(90, a))
    assert b == [90, 91, 92, 93, 94, 95, 96, 97, 98, 99]



# Generated at 2022-06-11 21:41:11.410814
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    try:
        MapList(None, None).__getitem__(0)
    except NotImplementedError:
        pass
    except Exception:
        assert False
    # TODO: implement other tests

# Generated at 2022-06-11 21:41:15.810356
# Unit test for function drop_until
def test_drop_until():
    f = lambda x: x >= 0
    assert list(drop_until(f, range(-10, 10))) == list(range(0, 10))
    assert list(drop_until(f, range(10))) == list(range(10))
    assert list(drop_until(f, range(-10))) == []
    assert list(drop_until(None, range(-10))) == list(range(-10))



# Generated at 2022-06-11 21:41:24.960228
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    print('-' * 64)
    print('testing method __getitem__ of class MapList')

    from random import randint
    from copy import deepcopy
    from random import shuffle

    for n in range(1, 8):
        for _ in range(1000):
            a = [randint(1, 1000000000) for _ in range(n)]
            for i in range(n + 1):
                for j in range(i, n + 1):
                    x = [a[k] * 2 for k in range(i, j)]
                    m = MapList(lambda x: x * 2, a)
                    try:
                        assert x == m[i: j]
                    except AssertionError:
                        print('TEST FAILED!')
                        print('x =', x)
                        print('m =', deepcopy(m))
                       

# Generated at 2022-06-11 21:41:33.010213
# Unit test for function drop_until
def test_drop_until():
    assert [6, 7, 8, 9] == list(drop_until(lambda x: x > 5, range(10)))
    assert [] == list(drop_until(lambda x: x > 5, range(10, 11)))
    assert [1,2,3] == list(drop_until(lambda x: x > 0, range(1, 10)))
    assert [] == list(drop_until(lambda x: x > 0, []))
    assert [] == list(drop_until(lambda x: x > 0, range(0, 0)))



# Generated at 2022-06-11 21:41:36.070472
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(5))) == list(range(5))
    assert list(drop(3, range(5))) == list(range(3, 5))



# Generated at 2022-06-11 21:42:04.866807
# Unit test for function drop_until
def test_drop_until():
    lst = range(10)
    fn = lambda x: x > 5
    it = drop_until(fn, lst)
    assert list(it) == list(dropwhile(fn, lst))


# Generated at 2022-06-11 21:42:07.056029
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    for val in [0,1,2,3,4,5]:
        assert len(LazyList(range(val))) == val

# Generated at 2022-06-11 21:42:08.838043
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10


# Generated at 2022-06-11 21:42:12.466297
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(100, range(10))) == []
    try:
        list(drop(-5, range(10)))
    except ValueError:
        pass
    else:
        raise AssertionError("negative index")


# Generated at 2022-06-11 21:42:16.790053
# Unit test for function drop
def test_drop():
    items = list(drop(20, range(100)))
    assert items == list(range(20, 100))
    assert len(items) == 80
    
    

# Generated at 2022-06-11 21:42:22.083985
# Unit test for function drop
def test_drop():
    print(repr(list(drop(0, range(10)))))
    print(repr(list(drop(1, range(10)))))
    print(repr(list(drop(2, range(10)))))
    print(repr(list(drop(5, range(10)))))
    print(repr(list(drop(10, range(10)))))
    print(repr(list(drop(11, range(10)))))

# Generated at 2022-06-11 21:42:26.832528
# Unit test for function drop
def test_drop():
    seq = [2, 3, 1, 4, 6]
    res = drop(3, seq)
    assert next(res) == 1
    assert list(res) == [4, 6]
    res = drop(0, seq)
    assert list(res) == seq
    res = drop(6, seq)
    assert not list(res)



# Generated at 2022-06-11 21:42:35.487532
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    test.equal(r[0], 1)
    test.equal(r[2], 5)
    test.equal(r[4], 9)
    test.equal(r[3:5], [7, 9])
    test.equal(r[-3], 5)
    test.equal(r[-5:-3], [1, 3])
    test.equal(r[-1], 9)


# Generated at 2022-06-11 21:42:48.405010
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], empty_segments=True, criterion=lambda x: x)) == [[]]
    assert list(split_by([1, 2, 3], empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[1, 2], [], []]
    assert list(split_by([1, 2, 3], empty_segments=False, criterion=lambda x: x % 3 == 0)) == [[1, 2]]
    assert list(split_by([1, 2, 3], empty_segments=True, separator=3)) == [[1, 2], []]
    assert list(split_by([1, 2, 3], empty_segments=False, separator=3)) == [[1, 2]]

# Generated at 2022-06-11 21:42:52.766372
# Unit test for function take
def test_take():
    assert list(take(5, range(1000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(-1, range(3))) == []

