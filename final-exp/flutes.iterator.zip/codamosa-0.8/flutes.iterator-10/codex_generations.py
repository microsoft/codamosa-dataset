

# Generated at 2022-06-11 21:37:40.459279
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(Range(4)) == 0
    assert next(Range(1, 5)) == 1
    assert next(Range(1, 6, 2)) == 1
    with pytest.raises(StopIteration):
        Range(0).__next__()
    with pytest.raises(StopIteration):
        Range(0, 100, 2).__next__()
    with pytest.raises(StopIteration):
        Range(1, 0).__next__()
    with pytest.raises(StopIteration):
        Range(1, 0, 2).__next__()


# Generated at 2022-06-11 21:37:49.608579
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, range(10))) == [[x] for x in range(10)]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]
    assert list(chunk(5, range(10))) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]

# Generated at 2022-06-11 21:37:53.992446
# Unit test for function chunk
def test_chunk():
    assert isinstance(chunk(3, range(10)), Iterator)
    assert list(chunk(3, range(10))) == [[0, 1, 2],[3, 4, 5],[6, 7, 8],[9]]
    with pytest.raises(ValueError):
        list(chunk(0, range(10)))


# Generated at 2022-06-11 21:37:56.194282
# Unit test for method __next__ of class Range
def test_Range___next__():
    pass


# Generated at 2022-06-11 21:38:06.518048
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    _test_Range___getitem__(lambda x: x[6], 6)
    _test_Range___getitem__(lambda x: x[6:10:2], 6, 10, 2)
    _test_Range___getitem__(lambda x: x[:8:4], 8, 4)
    _test_Range___getitem__(lambda x: x[5:], 5)
    _test_Range___getitem__(lambda x: x[::3], 3)
    _test_Range___getitem__(lambda x: x[:], 10)
    _test_Range___getitem__(lambda x: x[-10], -10)
    _test_Range___getitem__(lambda x: x[-1:5:-1], -1, 5, -1)

# Generated at 2022-06-11 21:38:10.846591
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    with pytest.raises(ValueError):
        list(chunk(0, range(10)))
    with pytest.raises(ValueError):
        list(chunk(-4, range(10)))
# Test lazy evaluation

# Generated at 2022-06-11 21:38:15.965131
# Unit test for method __next__ of class Range
def test_Range___next__():
    i = 0
    t = 0
    while i < 1000:
        with pytest.raises(StopIteration):
            while next(Range(10)) != 10:
                t = next(Range(100))
            t = next(Range(100))
        i = i + 1
    assert t == 100


# Generated at 2022-06-11 21:38:18.026642
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:38:25.063854
# Unit test for function chunk

# Generated at 2022-06-11 21:38:32.626922
# Unit test for function drop_until
def test_drop_until():
    l = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 4, l)) == [5, 6, 7, 8, 9]
    l = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 40, l)) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
test_drop_until()



# Generated at 2022-06-11 21:38:41.656823
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    for i in LazyList(range(10)):
        assert i == len(LazyList(range(10)).list)



# Generated at 2022-06-11 21:38:51.182994
# Unit test for method __next__ of class Range
def test_Range___next__():
    for start, end, step in ((0, 10, 1), (0, 10, 2), (1, 11, 2)):
        idx = 0
        for val in Range(start, end, step):
            assert val == start + idx * step
            idx += 1
        assert idx == (end - start) // step
    r = Range(0, 20, 4)
    for idx in range(20):
        assert r[idx] == idx * 4
    assert len(r) == 5
    assert r[1::2] == [4, 12]
    assert r[:3] == [0, 4, 8]
    assert r[-1:] == [16]
    assert r[-2:-1] == [12]
    assert r[:] == [0, 4, 8, 12, 16]


# Generated at 2022-06-11 21:38:58.626702
# Unit test for function drop
def test_drop():
    # Exception of drop with incorrect n
    try:
        it = drop(-5, range(1000000))
    except ValueError:
        pass
    # Exception of drop with wrong iterable
    try:
        it = drop(5, 'range(1000000)')
    except TypeError:
        pass
    # Correct usage
    assert next(drop(5, range(1000000))) == 5



# Generated at 2022-06-11 21:39:02.032635
# Unit test for function split_by
def test_split_by():
    assert list(split_by([])) == []
    assert list(split_by(["", "", ""])) == [[""], [""], [""]]
    assert list(split_by(["", "", "", "ab"], empty_segments=True)) == [[], [""], [""], ["ab"]]



# Generated at 2022-06-11 21:39:07.653180
# Unit test for function take
def test_take():
    import random
    for i in range(100):
        l = [random.randint(1,10) for _ in range(i)]
        n = random.randint(1,i+1)
        ll = list(take(n, l))
        assert len(ll) <= n
        assert ll == l[:len(ll)]



# Generated at 2022-06-11 21:39:17.613229
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 10, [])) == []
    assert list(drop_until(lambda x: x > 10, [1, 1, 1])) == []
    assert list(drop_until(lambda x: x > 10, [11, 1, 1])) == [11, 1, 1]
    assert list(drop_until(lambda x: x > 10, [1, 1, 1, 11, 1])) == [11, 1]
    assert list(drop_until(lambda x: x > 10, [1, 11, 1, 1])) == [11, 1, 1]
    assert list(drop_until(lambda x: x > 10, [1, 1, 1, 11])) == [11]

# Generated at 2022-06-11 21:39:20.936528
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList((n for n in range(10)))
    assert lst[1] == 1
    assert lst[5:10] == [5, 6, 7, 8, 9]
    lst = LazyList((n for n in range(10)))
    assert lst[1] == 1
    assert lst[-2:] == [8, 9]
    lst = LazyList((n for n in range(10)))
    assert lst[0] == lst[0]

# Generated at 2022-06-11 21:39:26.862633
# Unit test for function drop
def test_drop():
    assert list(drop(3, [1, 2, 3, 4, 5, 6])) == [4, 5, 6]
    assert list(drop(5, [1, 2, 3, 4, 5, 6])) == [6]
    assert list(drop(0, [1, 2, 3, 4, 5, 6])) == [1, 2, 3, 4, 5, 6]
    assert list(drop(3, range(10))) == [3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:39:29.848604
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:39:35.698961
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    ml = MapList(lambda x: x + 1, [1, 2, 3, 4])
    assert ml[0] == 2
    assert ml[1] == 3
    assert ml[1:3] == [3, 4]
    assert ml[0:3:2] == [2, 4]
    assert ml[::2] == [2, 4]


# Generated at 2022-06-11 21:40:16.744765
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    nested = (range(3), range(3), range(3))
    flattened = LazyList(nested)
    assert list(flattened) == [0, 0, 0, 1, 1, 1, 2, 2, 2]
    assert list(flattened) == [0, 0, 0, 1, 1, 1, 2, 2, 2]
    assert list(flattened) == [0, 0, 0, 1, 1, 1, 2, 2, 2]
    flattened_short = LazyList(range(3))
    assert list(flattened_short) == [0, 1, 2]
    assert list(flattened_short) == [0, 1, 2]
    assert list(flattened_short) == [0, 1, 2]

# Generated at 2022-06-11 21:40:19.457580
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r=Range(1,10+1)
    r=Range(1,11,2)
    print(r[0], r[2], r[4])

# Generated at 2022-06-11 21:40:25.403828
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    """
    This function is used to test the method :py:func:`__iter__` of the class :py:class:`LazyList`.
    """
    iter_list:List[int] = [1,2,3,4,5,6,7,8,9,10]
    lazy_list:LazyList[int] = LazyList(iter_list)
    for i in lazy_list:
        assert i == iter_list.pop(0)
    assert len(iter_list) == 0

# Generated at 2022-06-11 21:40:28.291488
# Unit test for function drop
def test_drop():
    assert list(drop(1,range(4)))==[1, 2, 3]
    assert list(drop(10,range(4)))==[]
test_drop()



# Generated at 2022-06-11 21:40:34.494101
# Unit test for function drop_until
def test_drop_until():
    from .test_utils import assert_iterator_equals
    assert_iterator_equals(drop_until(lambda x: x > 5, range(10)), (6, 7, 8, 9))
    assert_iterator_equals(drop_until(lambda x: x == -1, range(10)), ())
    assert_iterator_equals(drop_until(lambda x: x > 10, range(10)), ())


# Generated at 2022-06-11 21:40:38.327540
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from itertools import islice
    l = LazyList(range(1000000))
    assert isinstance(l[4:], List)
    assert islice(l, 4, None, 3) == islice(range(1000000), 4, None, 3)



# Generated at 2022-06-11 21:40:48.102270
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=lambda x: False)) == []
    assert list(split_by([0], criterion=lambda x: False)) == [[0]]
    assert list(split_by([0], criterion=lambda x: True)) == [[]]
    assert list(split_by([0], empty_segments=True, criterion=lambda x: False)) == [[0]]
    assert list(split_by([0], empty_segments=True, criterion=lambda x: True)) == [[], []]

    assert list(split_by([0, 0], criterion=lambda x: x == 0)) == [[], []]
    assert list(split_by([0, 0], empty_segments=True, criterion=lambda x: x == 0)) == [[], [], []]

# Generated at 2022-06-11 21:40:58.670751
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from typing import Iterator
    from .util import subtest_context
    from .data import arithmetic_progression, fibonacci
    from .test_data import DictDataSource

    def _test_sub(lst: Sequence[int], first: int, last: Optional[int]) -> None:
        if last is None:
            last = first
        else:
            last += 1
        with subtest_context(f"first={first}, last={last - 1}"):
            lst1 = LazyList(lst)
            assert isinstance(lst1[first], int)
            assert isinstance(lst1[last - 1], int)
            with pytest.raises(IndexError):
                lst1[last]
            with pytest.raises(IndexError):
                lst1[last + 1]
           

# Generated at 2022-06-11 21:41:09.674133
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for i in range(-2, 3):
        assert list(MapList(lambda x: x * 2, [1, 2, 3, 4, 5]))[i] == [1, 2, 3, 4, 5][i] * 2
        assert list(MapList(lambda x: x * 2, [1, 2, 3, 4, 5]))[i:] == [1, 2, 3, 4, 5][i:] * 2
        assert list(MapList(lambda x: x * 2, [1, 2, 3, 4, 5]))[:i] == [1, 2, 3, 4, 5][:i] * 2

# Generated at 2022-06-11 21:41:12.732351
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    prop = LazyList(range(10))
    assert prop == list(range(10))
    assert prop == list(prop.__iter__())
    assert prop == list(prop)



# Generated at 2022-06-11 21:41:39.272189
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)         # (end)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[2:5] == [2,3,4]
    r = Range(1, 10 + 1)  # (start, end)
    assert r[0] == 1
    assert r[1] == 2
    assert r[-1] == 10
    assert r[2:5] == [3,4,5]
    r = Range(1, 11, 2)   # (start, end, step)
    assert r[0] == 1
    assert r[1] == 3
    assert r[-1] == 9
    assert r[2:5] == [5,7,9]


# Generated at 2022-06-11 21:41:41.705667
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    lst = Range(10)[0:9:1]
    print(lst)


# Generated at 2022-06-11 21:41:51.855842
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    """test __getitem__ method of class MapList"""
    # define test parameters
    lst = [ 1, 2, 3, 4, 5, 6]
    func = lambda i: i*3
    instance = MapList(func, lst)

    # test method
    # idx = 3
    # assert isinstance(instance.__getitem__(idx),instance.__getitem__(idx).__class__), "__getitem__ returned wrong type"
    # assert instance.__getitem__(idx) == lst[idx]*3, "__getitem__ returned wrong value"
    # idx = slice(1,5,2)
    # assert isinstance(instance.__getitem__(idx),list), "__getitem__ returned wrong type"
    # assert instance.__getitem__(idx

# Generated at 2022-06-11 21:41:58.656961
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert(r[0] == 0)
    assert(r[-1] == 9)
    r = Range(1, 10 + 1)
    assert(r[0] == 1)
    assert(r[-1] == 10)
    r = Range(1, 11, 2)
    assert(r[0] == 1)
    assert(r[-1] == 9)
    assert(r[1:3] == [3, 5])



# Generated at 2022-06-11 21:42:02.044240
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


# Generated at 2022-06-11 21:42:06.357625
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    cnt = [0]
    def f():
        cnt[0] += 1
        yield cnt[0]
    ll = LazyList(f())
    assert ll[0] == 1
    assert cnt[0] == 1
    assert ll[2] == 3
    assert cnt[0] == 3

# Generated at 2022-06-11 21:42:13.143737
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect
    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert pos == 3
    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2

# Generated at 2022-06-11 21:42:21.745982
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    obj = LazyList([1, 2, 3, 4, 5])
    assert obj._fetch_until(3) == None
    assert list(obj._fetch_until(3)) == [1, 2, 3, 4, 5]
    obj = LazyList([1, 2, 3, 4, 5])
    with pytest.raises(TypeError) as excinfo:
        obj._fetch_until(3)
    assert isinstance(excinfo.value, TypeError)
    assert str(excinfo.value) == "__len__ is not available before the iterable is depleted"

# Generated at 2022-06-11 21:42:27.107461
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    class Iter:
        def __init__(self, vals):
            self.vals = vals

        def __iter__(self):
            return iter(self.vals)

    lst = LazyList(Iter(range(100)))
    assert len(lst) == 100
    del lst.vals
    assert len(lst) == 100



# Generated at 2022-06-11 21:42:34.244362
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    import random
    import pytest
    class RandomList(LazyList[int]):
        def __init__(self, n: int):
            super().__init__(iter(random.randint, -1))
            self._n = n

        def __len__(self):
            return self._n
    assert len(RandomList(0)) == 0
    with pytest.raises(TypeError):
        len(RandomList(1))
    assert len(RandomList(10)[:10]) == 10



# Generated at 2022-06-11 21:43:06.277278
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList([1,2,3])) == 3

# Generated at 2022-06-11 21:43:13.125705
# Unit test for function split_by
def test_split_by():
    test_cases = [
        ((range(10),), {'criterion': lambda x: x % 3 == 0}, [[1, 2], [4, 5], [7, 8]]),
        ((" Split by: ",), {'separator': '.', 'empty_segments': True}, [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]),
    ]
    for args, kwargs, expected in test_cases:
        assert expected == list(split_by(*args, **kwargs))
test_split_by()



# Generated at 2022-06-11 21:43:24.244081
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # An iterator is returned, which iterate the elements in the order they are inserted.
    assert list(LazyList([1, 2, 3])) == [1, 2, 3]
    # The iterator is re-usable.
    assert list(LazyList([1, 2, 3])) == list(LazyList([1, 2, 3]))
    # A slice is allowed as an argument to the iter() built-in function.
    assert list(iter(LazyList([1, 2, 3]), 2)) == [1]
    # An exception is raised if the iterable is depleted before the iterator is exhausted.
    with raises(StopIteration):
        assert list(iter(LazyList([1, 2, 3]), 4)) == [1, 2, 3]

# Generated at 2022-06-11 21:43:26.931176
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 11)
    assert r[1:4:2] == [3, 5] and r[-1] == 10 and r[1:] == [2, 3, 4, 5, 6, 7, 8, 9, 10]



# Generated at 2022-06-11 21:43:38.377822
# Unit test for function drop_until
def test_drop_until():
    my_list = [1, 2, 3, 4, 5, 6]
    my_iter = drop_until(lambda x: x > 4, my_list)

    assert next(my_iter) == 5
    assert next(my_iter) == 6
    try:
        next(my_iter)
        raise AssertionError("should raise StopIteration")
    except StopIteration:
        pass
    assert list(drop_until(lambda x: x > 4, [])) == []
    assert list(drop_until(lambda x: x > 4, [4, 5, 6])) == [5, 6]
    
test_drop_until()

# Generated at 2022-06-11 21:43:44.873094
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():

    # test for indices
    def _test_indices(lst: List[int]) -> None:
        x = LazyList(lst)
        for i, y in enumerate(lst):
            assert x[i] == y
        assert isinstance(x, LazyList)
        assert x.list == lst

    _test_indices([])
    _test_indices([1, 2, 3])

    # test for slices
    def _test_slices(lst: List[int]) -> None:
        x = LazyList(lst)
        y = list(x)
        assert isinstance(y, list)
        assert y == lst

    _test_slices([])
    _test_slices([1, 2, 3])

    # test for negative indices

# Generated at 2022-06-11 21:43:50.290695
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    """Method __getitem__ of class LazyList."""
    result = LazyList(range(5))[0]
    assert result == 0
    result = LazyList(range(5))[:3]
    assert result == [0, 1, 2]
test_LazyList___getitem__()

# Generated at 2022-06-11 21:43:53.330958
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import operator
    import random
    for _ in range(10):
        n = random.randint(0, 100)
        lst = LazyList(range(n))
        assert list(lst) == list(range(n))
        assert [i * j for i, j in zip(lst, lst)] == list(map(operator.mul, range(n), range(n)))

# Generated at 2022-06-11 21:43:58.463362
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    class Test:
        def __init__(self, ret):
            self.ret = ret
        def __getitem__(self, i):
            return self.ret

    m = MapList(lambda x: x + 2, Test(2))
    assert m[0] == 4



# Generated at 2022-06-11 21:44:02.887504
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(1))) == []



# Generated at 2022-06-11 21:44:38.685963
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 3, range(10))) == [4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 3, range(10))) == list(itertools.dropwhile(lambda x: x <= 3, range(10)))
    assert list(drop_until(lambda x: x > -1, range(10))) == list(range(10))
    assert list(drop_until(lambda x: x > 10, range(10))) == []
    assert list(drop_until(lambda x: x > 10, [])) == []
test_drop_until()



# Generated at 2022-06-11 21:44:48.126404
# Unit test for function split_by
def test_split_by():
    # Use try-except to avoid mypy and pyre false positives
    try:
        assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
        assert list(split_by(" Split by: ", separator='.')) == [['S', 'p', 'l', 'i', 't', 'b', 'y', ':']]
        assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    except Exception:
        traceback.print_exc()
        assert False



# Generated at 2022-06-11 21:44:55.499688
# Unit test for function split_by
def test_split_by():
    list(split_by("", criterion=lambda x: x == ".")) == [[]]
    list(split_by(" Split by: ", criterion=lambda x: x == ".")) == [['S', 'p', 'l', 'i', 't', ' ', 'b', 'y', ':', ' ']]
    list(split_by(" Split by: ", empty_segments=True, criterion=lambda x: x == ".")) == [[], ['S', 'p', 'l', 'i', 't', ' ', 'b', 'y', ':', ' '], []]
    list(split_by(" Split by: ", criterion=lambda x: x in ".:")) == [['S', 'p', 'l', 'i', 't', ' ', 'b', 'y'], []]

# Generated at 2022-06-11 21:45:02.015657
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 11, 2)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    assert r[-1] == 9
    assert r[-2] == 7
    assert r[-3] == 5
    assert r[-4] == 3
    assert r[-5] == 1



# Generated at 2022-06-11 21:45:08.479471
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x>5, range(10))) == [6,7,8,9]
    assert list(drop_until(lambda x: x>1 and (x-1)%4 == 0, range(10))) == [4,8]
    assert list(drop_until(lambda x: x>=10, range(10))) == []
    assert list(drop_until(lambda x: x==1, [])) == []
    assert list(drop_until(lambda x: x>0, range(-10, 10))) == [0]

# Generated at 2022-06-11 21:45:13.107415
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    lst = list(l)
    assert lst == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-11 21:45:19.987911
# Unit test for function drop
def test_drop():
    assert take(3, drop(0, range(10))) == [0, 1, 2]
    assert take(3, drop(1, range(10))) == [1, 2, 3]
    assert take(3, drop(10, range(10))) == []
    assert take(3, drop(11, range(10))) == []
    assert take(3, drop(-1, range(10))) == [0, 1, 2]

# Generated at 2022-06-11 21:45:25.997897
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:45:29.725957
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x ** 2, [1, 2, 3, 4, 5])[3] == 16
    assert MapList(lambda x: x ** 2, [1, 2, 3, 4, 5])[0:5] == [1, 4, 9, 16, 25]


# Generated at 2022-06-11 21:45:34.153144
# Unit test for function drop
def test_drop():
    try:
        for i in range(20):
            list(drop(i, [0, 1, 2, 3, 4]))
    except Exception as e:
        assert False
    try:
        list(drop(-1, [0, 1, 2, 3, 4]))
        assert False
    except ValueError:
        pass
