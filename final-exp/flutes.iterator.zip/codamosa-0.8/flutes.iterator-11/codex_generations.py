

# Generated at 2022-06-11 21:37:24.238380
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(10))) == range(10)
    assert list(take(1, range(1000000))) == [0]
    assert list(take(10, range(100000))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(take(0, range(10))) == []
    assert list(take(0, range(0))) == []
    assert list(take(1, [])) == []
    assert list(take(0, [])) == []
    assert list(take(0, [])) == []
    assert list(take(10, [])) == []

# Generated at 2022-06-11 21:37:26.214231
# Unit test for function take
def test_take():
    a = [1, 2, 3]
    assert list(take(2, a)) == [1, 2]



# Generated at 2022-06-11 21:37:32.433473
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[],
                                                                                  ['S', 'p', 'l', 'i', 't'],
                                                                                  ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2],
                                                                         [4, 5],
                                                                         [7, 8]]



# Generated at 2022-06-11 21:37:42.514459
# Unit test for function split_by
def test_split_by():
    # criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[], [1, 2], [], [4, 5], [], [7, 8], []]
    assert list(split_by(range(3), criterion=lambda x: x % 3 == 0)) == [[1, 2]]
    assert list(split_by(range(3), empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[], [1, 2], []]
    assert list(split_by([], criterion=lambda x: x % 3 == 0)) == []

# Generated at 2022-06-11 21:37:50.455302
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(2)[1] == 1
    assert Range(2)[0] == 0
    assert Range(2)[-1] == 1
    assert Range(2)[-2] == 0
    assert Range(4)[0] == 0
    assert Range(4)[1] == 1
    assert Range(4)[2] == 2
    assert Range(4)[3] == 3
    assert Range(4)[-1] == 3
    assert Range(4)[-2] == 2
    assert Range(4)[-3] == 1
    assert Range(4)[-4] == 0
    assert Range(0, 5)[0] == 0
    assert Range(0, 5)[1] == 1
    assert Range(0, 5)[2] == 2
    assert Range(0, 5)[3] == 3

# Generated at 2022-06-11 21:37:54.304813
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[-1] == 9
    assert len(r[2:5]) == 3
    assert r[-1:5] == [9]
    assert r[::2] == [0, 2, 4, 6, 8]


# Generated at 2022-06-11 21:37:58.052129
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-11 21:38:01.546563
# Unit test for function drop
def test_drop():
    for n in range(10):
        it = list(range(10))
        res = list(map(lambda x: x[0], zip(drop(n, it), it[n:])))
        assert res == it[n:]



# Generated at 2022-06-11 21:38:04.090108
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:38:13.300150
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    m = MapList(lambda x: x*x, [1, 2, 3, 4, 5])
    assert (m[1] == 4)
    assert (m[0] * m[1] == 4)
    assert (m[1:] == [4, 9, 16, 25])
    assert (m[1:4] == [4, 9, 16])
    assert (m[:4] == [1, 4, 9, 16])
    assert (m[2:1:-1] == [9])
    assert (m[:0:-1] == [25, 16, 9, 4, 1])
    assert (m[::-1] == [25, 16, 9, 4, 1])
    assert (m[::2] == [1, 9, 25])

# Generated at 2022-06-11 21:38:19.208448
# Unit test for function take
def test_take():
    assert list(take(3, [4, 5, 6, 7])) == [4, 5, 6]



# Generated at 2022-06-11 21:38:26.232592
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(100))
    assert isinstance(l[1:3], list)
    assert l[0] == 0
    assert l[1] == 1
    assert l[0:9] == list(range(9))
    assert l[99] == 99
    assert l[100] == 99
    import pytest
    with pytest.raises(TypeError):
        len(l)



# Generated at 2022-06-11 21:38:31.338012
# Unit test for method __getitem__ of class MapList

# Generated at 2022-06-11 21:38:39.680537
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0]== 0
    assert r[1]== 1
    assert r[2]== 2
    assert r[3]== 3
    assert r[4]== 4
    assert r[5]== 5
    assert r[6]== 6
    assert r[7]== 7
    assert r[8]== 8
    assert r[9]== 9
    assert r[10]== 10
    assert r[0:10]== [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert r[:5]== [0, 1, 2, 3, 4]
    assert r[5:]== [5, 6, 7, 8, 9]
    assert r[::2]== [0, 2, 4, 6, 8]

# Generated at 2022-06-11 21:38:46.854604
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[-1] == 9
    assert [Range(10)[i] for i in range(-10, 10)] == list(Range(10))
    assert Range(10)[2:4] == [2, 3]
    assert Range(1, 10, 2)[2:4] == [5, 7]
    assert Range(1, 10, 2)[-2:] == [7, 9]
    assert Range(1, 10, 2)[:-1] == [1, 3, 5, 7]

# Generated at 2022-06-11 21:39:00.001793
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from typing import Iterable, List, Tuple

    def test(lst: Iterable[int], idx: int, expected: int) -> None:
        lz = LazyList(lst)
        assert lz[idx] == expected
        assert lz.list == [expected]
        if idx == 0:
            assert not lz.exhausted
        else:
            assert lz.exhausted

    test(range(10), 0, 0)
    test(range(10), 9, 9)
    test(range(10), 10, 0)

    def test_slice(lst: Iterable[int], slice_: slice, expected: List[int]) -> None:
        lz = LazyList(lst)
        assert lz[slice_] == expected
        assert lz.list == expected



# Generated at 2022-06-11 21:39:02.238727
# Unit test for function take
def test_take():
    t = take(5, range(1000000))
    # print(t)
    assert list(t) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:39:06.466984
# Unit test for function take
def test_take():
    for n in range(-10, 10):
        for l in [range(10), range(1000), range(1000000), range(10000000)]:
            assert list(take(n, l)) == list(l)[:n]



# Generated at 2022-06-11 21:39:10.669770
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(100))
    assert len(lst) == 100
    lst = LazyList(range(-100, 100))
    assert len(lst) == 200



# Generated at 2022-06-11 21:39:18.999095
# Unit test for function drop
def test_drop():
    # drop()
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(0, [1])) == [1]
    assert list(drop(1, [1])) == []
    assert list(drop(0, [1, 2, 3])) == [1, 2, 3]
    assert list(drop(1, [1, 2, 3])) == [2, 3]
    assert list(drop(2, [1, 2, 3])) == [3]
    assert list(drop(3, [1, 2, 3])) == []
    assert list(drop(4, [1, 2, 3])) == []

    # drop(n, iterable)
    assert list(drop(0, range(0))) == []

# Generated at 2022-06-11 21:39:38.613852
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[9] == 9
    assert r[-1] == 9

    r = Range(10, 20)
    assert r[9] == 19
    r = Range(10, 20, 2)
    assert r[3] == 16
    assert len(r) == 5

    r = Range(10)
    assert r[0:5] == [0, 1, 2, 3, 4]
    assert r[3:9] == [3, 4, 5, 6, 7, 8]
    assert r[-1:10] == [9]
    assert r[3:3] == []
    assert len(r) == 10

    r = Range(10, 20)

# Generated at 2022-06-11 21:39:50.807758
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == list(range(5))
    assert list(take(5, range(100))) == list(range(100))
    assert list(take(0, range(100))) == []
    assert list(take(5, [])) == []
    assert list(take(0, [])) == []
    assert list(take(-1, [])) == []
    assert list(take(-1, range(100))) == []
    assert list(take(10, take(5, range(100)))) == list(range(5))
    assert list(take(5, take(10, range(100)))) == list(range(5))
    assert list(take(5, take(10, take(5, range(100))))) == list(range(5))
# Test for function all

# Generated at 2022-06-11 21:39:54.485904
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == list(range(5))
    assert list(take(-1, range(1000000))) == []
    try:
        list(take(-1, range(1000000)))
        assert False
    except ValueError:
        pass



# Generated at 2022-06-11 21:39:59.996710
# Unit test for function take
def test_take():
    assert list(take(0, [])) == []
    assert list(take(0, range(10))) == []
    assert list(take(1, range(1000000))) == [0]
    assert list(take(3, range(3))) == list(range(3))
    assert list(take(3, range(10))) == list(range(3))



# Generated at 2022-06-11 21:40:05.058389
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import pytest
    def test_func(iterable):
        assert [_ for _ in iter(LazyList(iterable))] == [_ for _ in iterable]
    
    test_func(list(range(10)))
    test_func(tuple(range(10)))
    test_func(range(10))
    test_func(range(10, 0, -1))



# Generated at 2022-06-11 21:40:08.985700
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lz = LazyList(range(100))
    assert lz[25] == 25
    assert lz[15:30] == list(range(15, 30))
    assert lz[:10] == list(range(10))



# Generated at 2022-06-11 21:40:14.637863
# Unit test for function take
def test_take():
    assert take(0, range(0)) == iter([])
    assert take(0, range(1)) == iter([])
    assert take(1, range(1)) == iter(range(1))
    assert take(1, range(2)) == iter(range(1))
    assert take(2, range(2)) == iter(range(2))
    assert take(2, range(3)) == iter(range(2))



# Generated at 2022-06-11 21:40:20.128616
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:40:26.839754
# Unit test for function take
def test_take():
    assert(list(take(-1, range(10))) == [])
    assert(list(take(0, range(10))) == [])
    assert(list(take(1, range(10))) == [0])
    assert(list(take(2, range(10))) == [0, 1])
    assert(list(take(10, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert(list(take(100, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert(list(take(100, [])) == [])


# Generated at 2022-06-11 21:40:30.775233
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    _99 = object()

# Generated at 2022-06-11 21:41:27.933792
# Unit test for function split_by
def test_split_by():
    # Test the criterion-based version
    assert list(split_by(range(5), criterion=lambda x: x > 2)) == [[0, 1, 2], [4]]
    assert list(split_by(range(5), criterion=lambda x: x >= 3)) == [[0, 1, 2], []]
    assert list(split_by([], criterion=lambda x: x >= 3)) == [[]]

    # Test separator-based version
    assert list(split_by(' Split by: ', separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y']]
    assert list(split_by(' Split by: ', separator='.', empty_segments=True)) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y']]


# Generated at 2022-06-11 21:41:32.838813
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    a = 1
    b = 10
    c = 2
    r = Range(a, b, c)
    assert r[0] == a
    assert r[::2][0] == a
    assert r[3] == 7
    assert r[::-2][0] == b - c

# Generated at 2022-06-11 21:41:41.169621
# Unit test for function split_by
def test_split_by():
    a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(split_by(a, criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8], [10]]
    assert list(split_by(a, criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8], [],
                                                                                     [10], []]
    assert list(split_by(a, criterion=lambda x: x % 2 != 0)) == [[2, 4, 6, 8, 10]]
    assert list(split_by(a, criterion=lambda x: x % 2 == 0)) == [[1, 3, 5, 7, 9]]
    assert list

# Generated at 2022-06-11 21:41:47.007568
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10, 15))
    assert list(lst) == [10, 11, 12, 13, 14]
    assert list(lst) == [10, 11, 12, 13, 14]  # consumed again
    assert list(lst) == [10, 11, 12, 13, 14]  # consumed again
    assert list(lst) == [10, 11, 12, 13, 14]  # consumed again


# Generated at 2022-06-11 21:41:57.582276
# Unit test for function drop_until
def test_drop_until():
    it = list(range(10))
    assert list(drop_until(lambda x: x > 5, it)) == [6, 7, 8, 9]
    it = list(range(10))
    assert list(drop_until(lambda x: x > 10, it)) == []
    it = list(range(10))
    assert list(drop_until(lambda x: x > 0, it)) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    it = list(range(10))
    assert list(drop_until(lambda x: x < 0, it)) == list(it)
    it = list(range(10))
    assert list(drop_until(lambda x: x == 7, it)) == [7, 8, 9]
    it = list(range(10))

# Generated at 2022-06-11 21:42:02.375868
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x < 5, range(10))) == [0, 1, 2, 3, 4]
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5))) == []



# Generated at 2022-06-11 21:42:05.031822
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    next(drop_until(lambda x: x > 5, range(10)))



# Generated at 2022-06-11 21:42:07.851107
# Unit test for function drop_until
def test_drop_until():
    for i in range(10):
        assert list(drop_until(lambda x: x > i, range(10))) == list(range(i + 1, 10))

# Feature test for function drop_until

# Generated at 2022-06-11 21:42:15.701942
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 0, [])) == []
    assert list(drop_until(lambda x: x > 0, [1, 2, 3])) == [1, 2, 3]
    assert list(drop_until(lambda x: x > 0, [-1, -2, -3])) == []
    assert list(drop_until(lambda x: x > 0, [-1, 0, -3])) == []
    assert list(drop_until(lambda x: x > 0, [-1, 0, -3, 2, 5])) == [2, 5]
    assert list(drop_until(lambda x: x > 0, [-1, -2, 0, -3, 2, 5])) == [2, 5]



# Generated at 2022-06-11 21:42:23.903797
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [7, 8, 9, 10])) == [7, 8, 9, 10]
    assert list(drop_until(lambda x: x > 5, [3, 4, 5, 6, 7])) == [6, 7]
    assert list(drop_until(lambda x: x > 5, [3, 4, 5])) == []
test_drop_until()



# Generated at 2022-06-11 21:42:46.125548
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda x: x * x
    lst = [1, 2, 3]
    map_list = MapList(func, lst)
    assert map_list[1] == 4
    assert map_list[0:2] == [1, 4]


# Generated at 2022-06-11 21:42:46.624309
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__(): pass



# Generated at 2022-06-11 21:42:57.017221
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert (list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) ==
            [[1, 2, 3], [], [4, 5, 6], [], [7, 8, 9]])
    assert (list(split_by("Split by:", empty_segments=True, separator=' ')) ==
            [['S', 'p', 'l', 'i', 't'], [], ['b', 'y', ':'], []])
    assert next(split_by(range(10), criterion=lambda x: False)) == []

# Generated at 2022-06-11 21:43:08.470520
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    def fn(x: int) -> int:
        return x * x
    lst = list(range(100))
    random.shuffle(lst)
    ml = MapList(fn, lst)
    for _ in range(100):
        idx = random.randint(0, len(lst) - 1)
        assert ml[idx] == fn(lst[idx])
        idx = random.randint(0, len(lst))
        assert list(ml[:idx]) == list(map(fn, lst[:idx]))
        idx = random.randint(0, len(lst))
        assert list(ml[idx:]) == list(map(fn, lst[idx:]))

# Generated at 2022-06-11 21:43:12.974269
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(1000))
    assert((lst[5] == 5))
    assert((len(lst) == 1000))
    assert((lst[5:10] == [5, 6, 7, 8, 9]))
    assert((lst[-10:] == list(range(990, 1000))))
    assert((list(lst) == list(range(1000))))



# Generated at 2022-06-11 21:43:17.985790
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(LazyList(range(10000)))
    lst = LazyList(iter(lst))
    sum1 = sum(lst)
    lst = LazyList(iter(lst))
    sum2 = sum(lst)
    assert sum1 == sum2



# Generated at 2022-06-11 21:43:21.617766
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    LazyList([1, 2, 3, 4]).__len__()
    LazyList(['a', 'b', 'c']).__len__()

Range = LazyList



# Generated at 2022-06-11 21:43:25.332648
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    try:
        assert len(lst) == 10
    except TypeError:
        pass
    lst._fetch_until(None)
    assert len(lst) == 10

# Generated at 2022-06-11 21:43:33.295546
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-11 21:43:41.771810
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    llst = LazyList([1, 2, 3, 4])
    it = iter(llst)
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    llst = LazyList([1, 2, 3, 4])
    assert list(iter(llst)) == [1, 2, 3, 4]
    assert list(iter(llst)) == [1, 2, 3, 4]
    assert list(llst) == [1, 2, 3, 4]

# Generated at 2022-06-11 21:44:09.389248
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]

test_split_by()

# Generated at 2022-06-11 21:44:16.860802
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(1, 10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by([3], criterion=lambda x: x % 3 == 0)) == [[]]
    assert list(split_by([3, 1], criterion=lambda x: x % 3 == 0)) == [[], [1]]
    assert list(split_by([1, 3], criterion=lambda x: x % 3 == 0)) == [[1], []]

# Generated at 2022-06-11 21:44:25.746925
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-10] == 0

    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[8] == 9
    assert r[-1] == 10
    assert r[-9] == 2

    r = Range(1, 11, 3)
    assert r[0] == 1
    assert r[2] == 7
    assert r[-1] == 10
    assert r[-3] == 4

    r = Range(1, 11, 3)
    assert r[1:4] == [4, 7, 10]
    assert r[3:3] == []
    assert r[3:2] == []

# Generated at 2022-06-11 21:44:32.711929
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2])
    assert len(lst) == 2
    lst = LazyList([1, 2])
    lst[0]
    assert len(lst) == 2
    lst = LazyList([])
    assert len(lst) == 0
    assert len(LazyList(range(10))) == 10

    try:
        len(LazyList([1, 2, 3]))
        assert False
    except TypeError:
        pass



# Generated at 2022-06-11 21:44:40.214790
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    with pytest.raises(ValueError):
        split_by(range(10), criterion=lambda x: x % 3 == 0, separator=':')


# Generated at 2022-06-11 21:44:45.732093
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == list(range(6, 10))
    assert list(drop_until(lambda x: x > 5, range(6))) == list(range(6))
    assert list(drop_until(lambda x: x > 5, [5, 6, 7])) == [6, 7]
    assert list(drop_until(lambda x: x > 8, [5, 6, 7])) == []
    assert list(drop_until(lambda x: x > 5, [5, 7, 6])) == [7, 6]
    assert list(drop_until(lambda x: x > 5, range(10))[0:4]) == [6, 7, 8, 9]


# Generated at 2022-06-11 21:44:53.380884
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) \
        == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator=' ')) \
        == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by("Split by:", empty_segments=True, criterion=lambda x: x.isspace())) \
        == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]



# Generated at 2022-06-11 21:45:04.260287
# Unit test for function split_by
def test_split_by():
    for n in [
        -1,
        -10,
        -100,
    ]:
        with pytest.raises(ValueError):
            list(split_by([1], n, criterion=lambda _: True))
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:45:06.343476
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r=Range(10)
    print(r[0],r[2],r[4])
    print(r[1:3])

# Generated at 2022-06-11 21:45:18.314741
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert (
        list(split_by(" Split by: ", empty_segments=True, separator='.'))
        == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    )
    try:
        split_by('', criterion=lambda x: x == ' ', separator='')
        assert False, "Duplicate parameter specification should fail"
    except ValueError:
        pass
    try:
        split_by('', criterion=lambda x: x == ' ')
        assert False, "Missing parameter should fail"
    except ValueError:
        pass



# Generated at 2022-06-11 21:46:13.158412
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    dummy = LazyList(range(5))
    del dummy.iter
    assert len(dummy) == 5


# Generated at 2022-06-11 21:46:21.205415
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8], []]


# Generated at 2022-06-11 21:46:27.352693
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from operator import add
    from itertools import count
    assert list(take(10, LazyList(count()))) == list(take(10, count()))
    assert list(take(10, LazyList(map(add, count(), count())))) == [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]

# Generated at 2022-06-11 21:46:37.637298
# Unit test for function drop_until
def test_drop_until():
    # Positive case with normal input
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    # Positive case with empty iterator
    assert list(drop_until(lambda x: x > 5, range(0))) == []
    # Positive case with empty iterator
    assert list(take(10, drop_until(lambda x: x > 5, range(0)))) == []
    # Positive case with input of one element
    assert list(drop_until(lambda x: x > 5, range(1))) == []
    # Positive case with input of one element
    assert list(drop_until(lambda x: x > 5, range(10,11))) == [10]
    # Positive case with input of one element

# Generated at 2022-06-11 21:46:44.127345
# Unit test for function drop_until
def test_drop_until():
    a = [1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: x > 5, a)) == [6,7,8,9]
    assert list(drop_until(lambda x: x == 6, a)) == [6,7,8,9]
    assert list(drop_until(lambda x: x == 10, a)) == []
test_drop_until()



# Generated at 2022-06-11 21:46:54.744346
# Unit test for function drop_until
def test_drop_until():
    gt = drop_until(lambda x: x > 5, range(10))
    assert list(gt) == [6, 7, 8, 9]
    gt = drop_until(lambda x: x > 5, range(10))
    assert list(gt) == [6, 7, 8, 9]
    gt = drop_until(lambda x: x > 5, [])
    assert list(gt) == []
    gt = drop_until(lambda x: x > 5, [1])
    assert list(gt) == [1]
    gt = drop_until(lambda x: x > 5, [1, 7])
    assert list(gt) == [7]
    gt = drop_until(lambda x: x > 5, [7, 1])
    assert list(gt) == [7, 1]
    g