

# Generated at 2022-06-11 21:37:16.223585
# Unit test for function drop
def test_drop():
    assert next(drop(5,range(10000))) == 5


# Generated at 2022-06-11 21:37:21.443425
# Unit test for function take
def test_take():
    assert list(take(3, [1, 2, 3, 4, 5])) == [1, 2, 3]
    assert list(take(100, [1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
    assert list(take(1, [])) == []
    assert list(take(-1, [])) == []
test_take()



# Generated at 2022-06-11 21:37:30.573533
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[0] == 0
    assert Range(10)[-1] == 9
    assert Range(1, 10)[0] == 1
    assert Range(1, 10)[-1] == 9
    assert Range(10)[0:10] == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert Range(10)[0:10:2] == [0, 2, 4, 6, 8]
    assert Range(10)[0:10:3] == [0, 3, 6, 9]
    assert Range(10)[0:10:-1] == []
    assert Range(10)[0:10:-2] == []



# Generated at 2022-06-11 21:37:36.853815
# Unit test for function split_by
def test_split_by():
    lst = [0, 1, 0, 2, 0, 3]
    assert list(split_by(lst, criterion=lambda x: x == 0)) == [[1], [2], [3]]
    assert list(split_by(lst, empty_segments=True, criterion=lambda x: x == 0)) == [[1], [], [2], [], [3], []]
    assert list(split_by(lst, separator=0)) == [[1], [2], [3]]
    assert list(split_by(lst, empty_segments=True, separator=0)) == [[1], [], [2], [], [3], []]


# Generated at 2022-06-11 21:37:40.686788
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from nose_parameterized import parameterized

    @parameterized.expand([
        (list(range(10)), 10),
        (range(20), 20),
    ])
    def check_len(obj, expected_len):
        assert len(LazyList(obj)) == expected_len

# Generated at 2022-06-11 21:37:42.445354
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(10000000000))
    result = list(iter(ll))
    assert result == [0]



# Generated at 2022-06-11 21:37:47.142049
# Unit test for function take
def test_take():
    for n in range(10):
        assert list(take(n, range(1000))) == list(range(n))
    assert list(take(10, range(5))) == list(range(5))
    try:
        take(-1, range(10))
    except ValueError:
        pass
    else:
        assert False
test_take()



# Generated at 2022-06-11 21:37:56.703261
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    '''
    This is a automatically generated unit test for method __getitem__ of class MapList
    '''
    lst = [2, 3, 4, 5, 6]
    lst_inst = MapList(lambda x: x*x, lst)
    assert lst_inst[0] == 4
    assert lst_inst[1] == 9
    assert lst_inst[2] == 16
    assert lst_inst[3] == 25
    assert lst_inst[4] == 36
    assert lst_inst[-1] == 36
    assert lst_inst[-2] == 25
    assert lst_inst[-3] == 16
    assert lst_inst[-4] == 9
    assert lst_inst[-5] == 4
    assert lst_inst[0:0]

# Generated at 2022-06-11 21:38:06.948386
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(8), criterion=lambda x: x % 2 == 0)) == [[1], [3], [5], [7]]
    assert list(split_by(range(8), criterion=lambda x: x % 2 == 0, empty_segments=True)) == [[], [1], [], [3], [], [5], [], [7], []]
    assert list(split_by(range(8), separator=0)) == [[1, 2, 3, 4, 5, 6, 7]]
    assert list(split_by(range(8), separator=0, empty_segments=True)) == [[], [1, 2, 3, 4, 5, 6, 7], []]

# Generated at 2022-06-11 21:38:11.980980
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

# Generated at 2022-06-11 21:38:40.780337
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    """ Test for method __iter__ of class LazyList"""
    # Test for method __iter__ of class LazyList
    from itertools import cycle
    from random import randrange, shuffle
    li = list(range(20))
    ll = iter(LazyList(li))
    assert li == list(ll)
    shuffle(li)
    ll = iter(LazyList(li))
    assert li == list(ll)
    li = list(range(20))
    ll = iter(LazyList(li))
    i = 0
    for x in ll:
        assert x == li[i]
        i += 1
    assert i == 20
    li = list(range(20))
    ll = iter(LazyList(cycle(li)))
    i = 0

# Generated at 2022-06-11 21:38:45.800801
# Unit test for function drop_until
def test_drop_until():
    from random import randint
    from statistics import mean
    from tests.utility import list_equal

    for i in range(100):
        for l in chunk(10, range(1000)):
            list_equal(
                drop_until(lambda x: x > mean(l), l),
                l[randint(0, len(l) - 1):]
            )



# Generated at 2022-06-11 21:38:50.283565
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1, range(2))) == [[0], [1]]
    assert list(chunk(0, range(10))) == ValueError



# Generated at 2022-06-11 21:39:02.215420
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=None)) == []
    assert list(split_by([], criterion=None, separator=None)) == []
    assert list(split_by([], criterion=None, separator=1)) == []
    assert list(split_by([1], criterion=None)) == [[1]]
    assert list(split_by([1], criterion=None, separator=None)) == [[1]]
    assert list(split_by([1], criterion=None, separator=1)) == [[]]
    assert list(split_by([1, 2, 3], criterion=lambda x: x < 2)) == [[3]]
    assert list(split_by([1, 2, 3], criterion=lambda x: x < 2, separator=None)) == [[3]]

# Generated at 2022-06-11 21:39:14.733309
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=True, criterion=lambda x: x == ':')) == [[' ', 'S', 'p', 'l',
                                                                                                'i', 't', ' ', 'b',
                                                                                                'y', ' '], [],
                                                                                               [' ']]

# Generated at 2022-06-11 21:39:19.536433
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list_examples = [
        [],
        [1,2,3],
        [4,5]
    ]
    for example in list_examples:
        print(len(LazyList(example)))
test_LazyList___len__()


# Generated at 2022-06-11 21:39:24.139550
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(24, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(take(24, range(3))) == [0, 1, 2]



# Generated at 2022-06-11 21:39:26.863614
# Unit test for function take
def test_take():
    assert list(take(10, range(0))) == []
    assert list(take(10, range(1))) == [0]
    assert list(take(3, range(10))) == [0, 1, 2]
    assert list(take(-3, range(10))) == []



# Generated at 2022-06-11 21:39:38.194435
# Unit test for function split_by
def test_split_by():
    assert list(split_by("Split-by-hyphen", criterion=lambda x: x == '-')) == [["S", "p", "l", "i", "t"], ['b', 'y'], []]
    assert list(split_by("Split-by-hyphen", criterion=lambda x: x == '-' and len(x) > 0)) == [["S", "p", "l", "i", "t"], ['b', 'y'], []]
    assert list(split_by("Split-by-hyphen", criterion=lambda x: x == '-', empty_iterables=True)) == [["S", "p", "l", "i", "t"], ['b', 'y'], []]

# Generated at 2022-06-11 21:39:42.740804
# Unit test for function drop
def test_drop():
    is_func_returns_true = 0
    for i in drop(0, range(1, 10)):
        assert i >= 1
        is_func_returns_true += 1
    assert is_func_returns_true == 9


# Generated at 2022-06-11 21:40:05.230724
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        #print(list(LazyList(range(10000))))
        print(len(LazyList(range(10000))))
    except:
        pass
    try:
        print(len(LazyList(range(1000000))))
    except TypeError:
        print('__len__ is not available before the iterable is depleted')



# Generated at 2022-06-11 21:40:14.668312
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # test for method __getitem__ of class MapList with arguments (int)
    # Mock the necessary methods
    class MockSequence:
        def __init__(self, lst):
            self.lst = lst
        def __len__(self):
            return len(self.lst)
        def __getitem__(self, item):
            return self.lst[item]

    # Mock the necessary methods
    class MockCallable:
        def __init__(self, lst):
            self.lst = lst
        def __call__(self, item):
            return self.lst[item]
    mocklst = MockSequence([1, 2, 3])
    mockfunc = MockCallable([10, 20, 30])

    # Call the main function

# Generated at 2022-06-11 21:40:19.681756
# Unit test for function chunk
def test_chunk():
    import types
    import unittest
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_stdout():
        old = sys.stdout
        yield StringIO()
        sys.stdout = old

    def chunk_test(n: int, iterable: Iterable, expected: List[List]):
        assert list(chunk(n, iterable)) == expected, \
            f"chunk({n}, {iterable}) should be {expected}, not {list(chunk(n, iterable))}"

    class Tests(unittest.TestCase):

        def test_chunk(self):
            chunk_test(0, [], [])
            chunk_test(1, [1, 2, 3], [[1], [2], [3]])

# Generated at 2022-06-11 21:40:20.876620
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(100))) == 100

# Generated at 2022-06-11 21:40:26.900324
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[3] == 3
    assert lst[-1] == 9
    assert lst[-2] == 8
    assert lst[-3] == 7
    assert lst[-4] == 6
    assert lst[-5] == 5
    assert lst[20] == 9



# Generated at 2022-06-11 21:40:30.073202
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(10))) == list(range(10))
    assert list(LazyList(range(1000000))) == list(range(1000000))

# Generated at 2022-06-11 21:40:38.238502
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(1000000))
    assert isinstance(lst, LazyList)
    assert isinstance(lst, Sequence)
    assert not hasattr(lst, "__len__")
    assert isinstance(lst[:], List)
    assert len(lst[:]) == 1000000
    assert len(lst) == 1000000
    assert isinstance(lst[9], int)
    assert lst[9] == 9
    assert isinstance(lst[:10], List)
    assert len(lst[:10]) == 10
    assert lst[:10] == list(range(10))
    assert lst[5:10] == list(range(5, 10))
    assert lst[0:10:2] == [0, 2, 4, 6, 8]


# Generated at 2022-06-11 21:40:48.071739
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(5, range(10))) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]

# Generated at 2022-06-11 21:40:55.169311
# Unit test for function drop
def test_drop():
    assert len(list(drop(3, range(7)))) == 4
    assert list(drop(3, range(7))) == [3, 4, 5, 6]
    assert len(list(drop(9999, range(7)))) == 0
    assert list(drop(9999, range(7))) == []
    assert len(list(drop(-1, range(7)))) == 7
    assert list(drop(-1, range(7))) == [0, 1, 2, 3, 4, 5, 6]
    assert len(list(drop(7, range(7)))) == 0
    assert list(drop(7, range(7))) == []
    assert len(list(drop(8, range(7)))) == 0
    assert list(drop(8, range(7))) == []


# Generated at 2022-06-11 21:40:59.705095
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    it_a = LazyList(range(10))
    it_b = iter(it_a)

    # iterate over it_b ad infinitum
    while True:
        try:
            next(it_b)
        except StopIteration:
            break

    assert it_a.list == list(range(10))



# Generated at 2022-06-11 21:41:13.998294
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert all(x == y for x, y in zip(lst, range(10)))
test_LazyList___getitem__()
del test_LazyList___getitem__



# Generated at 2022-06-11 21:41:19.176154
# Unit test for function drop
def test_drop():
    seq = range(5)
    assert list(drop(0, seq)) == list(seq)
    assert list(drop(-1, seq)) == list(seq)
    assert list(drop(4, seq)) == [4]
    assert list(drop(5, seq)) == []
    assert list(drop(6, seq)) == []


# Generated at 2022-06-11 21:41:23.631760
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, range(5))) == []
    assert list(drop_until(lambda x: x > 5, range(5, 10))) == [5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:41:26.482993
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(5))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:41:34.985028
# Unit test for function drop
def test_drop():
    import random
    iterable = [random.randint(1, 10) for _ in range(10)]
    assert list(drop(0, iterable)) == iterable
    assert list(drop(1, iterable)) == iterable[1:]
    assert list(drop(2, iterable)) == iterable[2:]
    assert list(drop(10, iterable)) == []
    assert list(drop(random.randint(0, 10), iterable)) == iterable[random.randint(0, 10):]


# Generated at 2022-06-11 21:41:44.433852
# Unit test for function take
def test_take():
    assert list(take(0, range(1))) == []
    assert list(take(1, range(1))) == [0]
    assert list(take(2, range(1))) == [0]
    assert list(take(1, [])) == []
    assert list(take(0, [])) == []
    assert list(take(-1, [])) == ValueError
    assert list(take(0, range(2))) == []
    assert list(take(1, range(2))) == [0]
    assert list(take(2, range(2))) == [0, 1]
    assert list(take(3, range(2))) == [0, 1]



# Generated at 2022-06-11 21:41:49.619033
# Unit test for function chunk
def test_chunk():
    assert [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]] == list(chunk(3, range(10)))
    assert [] == list(chunk(0, range(10)))
    with raises(ValueError):
        chunk(-1, range(10))
    with raises(ValueError):
        chunk(1.5, range(10))



# Generated at 2022-06-11 21:41:51.963322
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    i = LazyList(range(100))
    assert len(list(i)) == 100


# Generated at 2022-06-11 21:42:00.225728
# Unit test for function drop
def test_drop():
    import unittest

    class TestDrop(unittest.TestCase):

        def test_negative_n(self):
            with self.assertRaises(ValueError):
                drop(-1, range(10))

        def test_zero_n(self):
            self.assertSequenceEqual(list(drop(0, range(10))), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

        def test_positive_n(self):
            self.assertSequenceEqual(list(drop(5, range(10))), [5, 6, 7, 8, 9])

    unittest.main()



# Generated at 2022-06-11 21:42:07.806811
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x * y, [1, 2, 3, 4])) == [1, 2, 6, 24]
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 100)) == [100, 101, 103, 106, 110]
    
    # The following test will fail because the initial value is not specified.
    # assert list(scanl(lambda x, y: x + y, range(1, 10))) == [9, 10, 12, 15, 19, 24, 30, 37, 45]


# Generated at 2022-06-11 21:43:41.651010
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2, 3, 4, 5, 6, 7, 8, 9], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], criterion=lambda x: x % 5 == 0)) == [[1, 2, 3, 4], [6, 7, 8, 9]]
    assert list(split_by([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8], [], [10]]


# Generated at 2022-06-11 21:43:43.620517
# Unit test for function drop_until
def test_drop_until():
    fn = drop_until(lambda x: x > 5, range(10))
    assert list(fn) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:43:54.199923
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
        ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=True, separator=' ')) == [['S', 'p', 'l', 'i', 't'],
        ['b', 'y', ':']]



# Generated at 2022-06-11 21:44:04.989565
# Unit test for function take
def test_take():
    assert list(take(0, range(15))) == []
    assert list(take(1, range(15))) == [0]
    assert list(take(2, range(15))) == [0, 1]
    assert list(take(5, range(15))) == [0, 1, 2, 3, 4]
    assert list(take(10, range(15))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(take(20, range(15))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]


# Generated at 2022-06-11 21:44:10.012453
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:44:14.313752
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(1))) == 1
    assert len(LazyList(range(3))) == 3
    assert len(LazyList([])) == 0
    assert len(LazyList(iter(range(3)))) == 3
    with pytest.raises(TypeError):
        len(LazyList(range(1, 3)))


# Generated at 2022-06-11 21:44:16.762048
# Unit test for function chunk
def test_chunk():
    print(list(chunk(3, range(10))))
    print(chunk(3, range(10)))


# Generated at 2022-06-11 21:44:20.795048
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x == 0, range(5))) == [0]
    assert list(drop_until(lambda x: x == 0, range(2))) == []
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:44:24.751794
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(10))
    try:
        len(lst)
    except TypeError as e:
        assert str(e) == "__len__ is not available before the iterable is depleted"


# Generated at 2022-06-11 21:44:26.547178
# Unit test for function drop_until
def test_drop_until():
    assert isinstance(drop_until(lambda x: x>3, range(4)), Iterator)
test_drop_until()



# Generated at 2022-06-11 21:45:45.802342
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x==3, [1,2,3,4,5])) == [3,4,5]


# Generated at 2022-06-11 21:45:50.060189
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3])
    it = iter(lst)
    assert next(it) == 1
    assert next(it) == 2
    assert next(it) == 3
    with pytest.raises(StopIteration):
        next(it)

# Generated at 2022-06-11 21:45:57.266451
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6,7,8,9]
    assert list(drop_until(lambda x: x < 5, range(10))) == [0,1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: x > 10, range(10))) == [0,1,2,3,4,5,6,7,8,9]



# Generated at 2022-06-11 21:46:01.959403
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    import pytest
    from .list import len

    iterable = range(10)

    lazy_list = LazyList(iterable)
    with pytest.raises(TypeError):
        len(lazy_list)

    len(list(lazy_list))
    assert len(lazy_list) == 10
# End test



# Generated at 2022-06-11 21:46:05.950229
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    a = LazyList(range(10))
    for i, x in enumerate(a):
        assert i == x
    assert len(a) == 10
    assert all(i == x for i, x in enumerate(a))



# Generated at 2022-06-11 21:46:08.636417
# Unit test for function drop_until
def test_drop_until():
    it = drop_until(lambda x: x > 3, range(10))
    list(it)
    list(it)



# Generated at 2022-06-11 21:46:16.623883
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect
    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert pos == 3

    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2



# Generated at 2022-06-11 21:46:18.330423
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    list_ = LazyList(range(100))
    assert list_.list == []
    assert list_.exhausted == False
    list_.__len__()


# Generated at 2022-06-11 21:46:20.863819
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList([0, 1, 2, 3, 4])) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:46:29.245279
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    arr = iter(range(100))
    lst = LazyList(arr)
    for i in range(30):
        assert lst[i] == i
    assert lst[:30] == list(range(30))
    arr = iter(range(100))
    lst = LazyList(arr)
    assert lst[:30:3] == list(range(0, 30, 3))
    assert lst[30] == 30
    with pytest.raises(TypeError):
        len(lst)

