

# Generated at 2022-06-11 21:37:20.516090
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert [r[1],r[2],r[3]] == [1,2,3]
    assert [r[2:4],r[:4],r[6:8],r[::2],r[-2::]] == [[2, 3], [0, 1, 2, 3], [6, 7], [0, 2, 4, 6, 8], [8, 9]]


# Generated at 2022-06-11 21:37:31.109831
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 1, 2, 1, 2, 1, 2, 3, 4, 5])) == [[1, 1, 2, 1, 2, 1, 2, 3, 4, 5]]
    assert list(split_by([1, 1, 2, 1, 2, 1, 2, 3, 4, 5], empty_segments=True)) == [[], [1, 1, 2, 1, 2, 1, 2, 3, 4, 5]]
    assert list(split_by([1, 1, 2, 1, 2, 1, 2, 3, 4, 5], criterion=lambda x: x % 3 == 1)) == [[2], [2], [4, 5]]

# Generated at 2022-06-11 21:37:35.891819
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    v = range(1, 7)
    r = Range(1, 7)
    assert type(v) == type(r)
    assert type(v[3]) == type(r[3])
    assert type(v[1:4]) == type(r[1:4])
    assert v[3] == r[3]
    assert v[1:4] == r[1:4]
    assert v[-1] == r[-1]
    assert v[-3:] == r[-3:]
    assert v[:3] == r[:3]
    assert v[:-1] == r[:-1]


# Generated at 2022-06-11 21:37:38.636494
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        len(LazyList([1, 2, 3]))
    except Exception:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-11 21:37:44.668468
# Unit test for function chunk
def test_chunk():
    n=3
    for i in range(10):
        assert next(chunk(n,range(i))) == list(range(min(i,n)))
    try:
        next(chunk(0,range(10)))
        assert False
    except ValueError:
        pass


# Generated at 2022-06-11 21:37:54.565103
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert len(r) == 10
    assert r[8:] == [8,9]
    r = Range(1, 10+1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert len(r) == 10
    assert r[8:] == [9,10]
    r = Range(1, 10, 2)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    assert len(r) == 5
    assert r[2:] == [5,7,9]


# Generated at 2022-06-11 21:38:01.044195
# Unit test for function take
def test_take():
    assert(list(take(3, 'abcdefg')) == ['a', 'b', 'c'])

# PRACTICE: Define function drop
#
# drop(n, iterable):
# Drops the first n elements from iterable and returns a new iterator
#
# Example:
#   > list(drop(2, 'abcdef'))
#   ['c','d','e','f']
#

# Generated at 2022-06-11 21:38:04.380369
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 10, range(10))) == []



# Generated at 2022-06-11 21:38:07.944361
# Unit test for function drop
def test_drop():
    a = [1,2,3,4,5]
    for i, j in zip(drop(2, a), [3,4,5]):
        assert i == j



# Generated at 2022-06-11 21:38:13.987701
# Unit test for function drop
def test_drop():
    it = list(range(1000))
    # test that dropping 0 elements yields the iterator itself
    assert not (drop(0, it))
    # test that dropping 8 elements yields '8 ... 999'
    assert (drop(8, it) == list(range(8, 1000)))
    # test that dropping more elements than the iterator contains yields no elements
    assert not (drop(1001, it))


# Generated at 2022-06-11 21:38:23.841476
# Unit test for function drop
def test_drop():
    print(next(drop(5, range(1000000))))
    print(next(drop(5, range(1000000))))
    print(next(drop(5, range(1000000))))



# Generated at 2022-06-11 21:38:31.546249
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=lambda x: x)) == []
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:38:39.809172
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    """
    __iter__ は次の3パターンを満たすことをテストする

    1. リストの途中まででイテレーションが終了した場合
    2. リストの先頭からイテレーションが終了した場合
    3. 長さ0のリストの場合
    """

    # 1. リストの途中まででイテレーションが終了した場合
    lst = LazyList(range(4))
    it = iter(lst)

# Generated at 2022-06-11 21:38:45.620283
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:38:52.432441
# Unit test for function chunk
def test_chunk():
    import random
    # Generate some random positive integers.
    r = [random.randint(1, 1000) for _ in range(100)]
    for i in range(100):
        n = random.randint(1, 10)
        chunked = list(chunk(n, r))
        # Check that each chunk is of length <= n.
        assert all(len(x) <= n for x in chunked)
        # Check that the concatenation of all chunks is equivalent to the original iterable.
        assert sum(len(x) for x in chunked) == len(r)
        assert list(sum(chunked, [])) == r



# Generated at 2022-06-11 21:38:58.200856
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    array = [1, 2, 3]
    lazy_list = LazyList(array)
    i = 0
    while True:
        try:
            x, y = next(lazy_list)
            assert array[i] == x
            assert array[i] == y
        except StopIteration:
            break
        i += 1

# Generated at 2022-06-11 21:39:03.238962
# Unit test for function chunk
def test_chunk():
    r"""Test for :py:func:`chunk`"""
    from .misc import eq
    eq(list(chunk(3, range(10))), [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]])
    eq(list(chunk(3, range(7))), [[0, 1, 2], [3, 4, 5], [6]])
    eq(list(chunk(3, range(2))), [[0, 1]])
    eq(list(chunk(3, range(0))), [])



# Generated at 2022-06-11 21:39:10.250229
# Unit test for function drop
def test_drop():
    arr1 = [1,2,3,4,5]
    assert tuple(drop(0, arr1)) == (1,2,3,4,5)
    assert tuple(drop(2, arr1)) == (3,4,5)
    assert tuple(drop(5, arr1)) == ()
    assert tuple(drop(10, arr1)) == ()


# Generated at 2022-06-11 21:39:12.096264
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    l = LazyList(range(10))
    assert list(l) == list(range(10))


# Generated at 2022-06-11 21:39:23.771761
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [1])) == []
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6])) == [6]
    assert list(drop_until(lambda x: x > 7, [])) == []
    assert list(drop_until(lambda x: x > 7, [1])) == []
    assert list(drop_until(lambda x: x > 7, [1, 2, 3, 4, 5, 6])) == []

# Generated at 2022-06-11 21:39:43.746802
# Unit test for function take
def test_take():
    i = iter(range(10))
    assert list(take(3, i)) == [0, 1, 2]
    assert list(take(3, i)) == [3, 4, 5]
    assert list(take(3, i)) == [6, 7, 8]
    assert list(take(3, i)) == [9]
    assert list(take(3, i)) == []



# Generated at 2022-06-11 21:39:51.494967
# Unit test for function drop
def test_drop():
    l = [1,2,0,1,2]
    i = iter(l)
    drop(0,i)
    assert next(i) == 1
    drop(1,i)
    assert next(i) == 0
    drop(2,i)
    assert next(i) == 2
    drop(2,i)
    assert next(i) == 1
    drop(3,i)
    with pytest.raises(StopIteration):
        drop(0,i)
        next(i)


# Generated at 2022-06-11 21:39:53.788121
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:39:57.887732
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
        iterable = range(10)
        lazy_list = LazyList(iterable)
        with pytest.raises(TypeError, match="__len__ is not available before the iterable is depleted"):
            len(lazy_list)


# Generated at 2022-06-11 21:40:07.123561
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import doctest
    from typing import List
    from .helpers import random_int_list
    from itertools import islice

    def _random_int_list(*args, **kwargs) -> List[int]:
        ls = random_int_list(*args, **kwargs)
        ls.append(None)  # adds a None to randomly terminate iteration
        return ls

    T = TypeVar('T')

    def _gen_random_LazyList(T: Callable[[], T]) -> LazyList[T]:
        return LazyList(islice(iter(T), random.randint(0, 5)))

    def _assert_LazyList(xs, fn):
        xs = fn(xs)
        assert len(xs) == len(list(xs))


# Generated at 2022-06-11 21:40:11.843051
# Unit test for function drop_until
def test_drop_until():
    # Test 1
    l = drop_until(lambda x: x > 5, range(10))
    assert l.__next__() == 6
    assert l.__next__() == 7

    # Test 2
    l = drop_until(lambda x: x > 10, range(10))
    with pytest.raises(StopIteration):
        l.__next__()



# Generated at 2022-06-11 21:40:13.458007
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = list(LazyList(range(100)))
    assert lst == list(range(100))



# Generated at 2022-06-11 21:40:15.584923
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == [0, 1, 2]



# Generated at 2022-06-11 21:40:20.393801
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(1, 5))) == [[1, 2, 3], [4]]
    assert list(chunk(3, [])) == []


# Generated at 2022-06-11 21:40:25.003032
# Unit test for function drop_until
def test_drop_until():
    xs = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    ys = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    for i in range(0, len(xs)):
        zs = list(drop_until(lambda x: x > i, xs))
        assert zs == ys[i:]



# Generated at 2022-06-11 21:40:47.943885
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import sqlite3
    import sys

    # Test case 1
    lst = LazyList(range(10))
    assert lst[0] == 0
    assert lst[4] == 4
    assert lst[6] == 6
    assert lst[10] == 9

    # Test case 2
    lst = []
    lst = LazyList(lst)
    try:
        lst[0]
    except IndexError:
        pass
    else:
        raise AssertionError("Exception not raised")

    # Test case 3
    lst = LazyList(range(10))
    assert lst[-1] == 9
    assert lst[-2] == 8

    # Test case 4
    lst = LazyList(range(10))

# Generated at 2022-06-11 21:40:49.853551
# Unit test for function take
def test_take():
    assert list(take(0, range(1000))) == []
    assert list(take(5, range(5))) == list(range(5))



# Generated at 2022-06-11 21:40:59.745840
# Unit test for function split_by
def test_split_by():
    L = list(split_by([1, 2, 3, 4, 5, 6, 7, 8, 9], criterion=lambda x: x % 3 == 0))
    assert L == [[1, 2], [4, 5], [7, 8]]

    L = list(split_by([1, 2, 3, 4, 5, 6, 7, 8, 9], criterion=lambda x: x % 3 == 0, empty_segments=True))
    assert L == [[1, 2], [4, 5], [7, 8], []]

    L = list(split_by([1, 2, 3, 4, 5, 6, 7, 8, 9], criterion=lambda x: x % 3 == 0, empty_segments=True))
    assert L == [[1, 2], [4, 5], [7, 8], []]

    L = list

# Generated at 2022-06-11 21:41:08.530557
# Unit test for function split_by
def test_split_by():
    def assert_split_by(iterable, criterion, expected):
        actual = split_by(iterable, criterion=criterion)
        assert list(actual) == expected,\
            f"{list(iterable)} should be split by criterion {criterion} into {expected}, but got {list(actual)}"

    assert_split_by([], lambda x: x % 3 == 0, [])
    assert_split_by(['a'], lambda x: x % 3 == 0, [['a']])
    assert_split_by(['b', 'a'], lambda x: x % 3 == 0, [['b', 'a']])
    assert_split_by(['c', 'b', 'a'], lambda x: x % 3 == 0, [['c'], ['b', 'a']])
    assert_split_

# Generated at 2022-06-11 21:41:14.262390
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: False, range(10))) == list(range(10))
    assert list(drop_until(lambda x: True, range(10))) == list(range(1,10))



# Generated at 2022-06-11 21:41:24.338385
# Unit test for function split_by
def test_split_by():
    # Test split_by(iterable, criterion)
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 != 0)) == [[0], [3], [6], [9]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0) == [[1, 2], [4, 5], [7, 8]])
    assert list(split_by(range(10), criterion=lambda x: x % 3 != 0) == [[0], [3], [6], [9]])
    # Test split_by(iterable, criterion, empty_segments)

# Generated at 2022-06-11 21:41:34.502147
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(-1, range(3))) == []
    assert list(chunk(0, range(3))) == []
    assert list(chunk(1, range(3))) == [[0], [1], [2]]
    assert list(chunk(2, range(3))) == [[0, 1], [2]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(100, range(3))) == [[0, 1, 2]]



# Generated at 2022-06-11 21:41:37.122614
# Unit test for function drop
def test_drop():
    assert next(drop(5, range(1000000))) == 5
    assert [1,2,3,4] == list(take(4,drop(1, range(1,6))))


# Generated at 2022-06-11 21:41:43.712753
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) \
        == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) \
        == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:41:53.271709
# Unit test for function take
def test_take():
    l = list(take(5, range(1000000)))
    assert l == [0, 1, 2, 3, 4]
    l = list(take(5, range(1)))
    assert l == [0]
    l = list(take(5, range(0)))
    assert l == []
    l = list(take(5, range(-1)))
    assert l == []
    l = list(take(1, range(0)))
    assert l == []
    l = list(take(0, range(1)))
    assert l == []
    
    
    myList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    take(5, myList)

test_take()


# Generated at 2022-06-11 21:42:25.830005
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[i] for i in range(10)]
    assert list(chunk(3, range(10))) == [[i, i+1, i+2] for i in range(0, 10, 3)]



# Generated at 2022-06-11 21:42:32.590906
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    _it = iter([1, 2, 3, 4, 5])
    _lst = LazyList(_it)
    assert _lst[0] == 1
    assert _lst[1] == 2
    assert _lst[2:5] == [3, 4, 5]
    assert _lst[2] == 3
    assert _lst[1:5] == [2, 3, 4, 5]



# Generated at 2022-06-11 21:42:37.754070
# Unit test for function split_by
def test_split_by():
    assert [[1, 2], [4, 5], [7, 8]] == list(split_by([1, 2, 3, 4, 5, 6, 7, 8, 9], criterion=lambda x: x % 3 == 0))
    assert [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []] == list(split_by(" Split by: ", empty_segments=True, separator='.'))



# Generated at 2022-06-11 21:42:47.620828
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst_0_to_100 = LazyList(range(100))
    assert list(lst_0_to_100) == list(range(100))
    assert list(lst_0_to_100) == list(range(100))

    lst_0_to_100 = LazyList(range(100))
    lst = []
    for x in lst_0_to_100:
        lst.append(x)
        if len(lst) == 50:
            break
    for x in lst_0_to_100:
        lst.append(x)
    assert lst == list(range(100))



# Generated at 2022-06-11 21:42:50.199919
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]


test_drop_until()

# Generated at 2022-06-11 21:42:55.246437
# Unit test for function drop
def test_drop():
    res = drop(5, range(10))
    assert next(res) == 5
    assert next(res) == 6
    assert next(res) == 7
    assert next(res) == 8
    assert next(res) == 9
    with pytest.raises(StopIteration):
        next(res)
# Test for error cases

# Generated at 2022-06-11 21:43:00.341830
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, [1, 2, 3])) == [[1], [2], [3]]
    assert list(chunk(-1, [1, 2, 3])) == [[1, 2, 3]]
    assert list(chunk(0, [1, 2, 3])) == [[1, 2, 3]]



# Generated at 2022-06-11 21:43:07.678157
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'],
                                                                                ['b', 'y', ':']]



# Generated at 2022-06-11 21:43:15.351984
# Unit test for function drop_until
def test_drop_until():
    def test_case(_in, _out):
        assert list(drop_until(lambda x: x == 10, _in)) == _out
    test_case([], [])
    test_case([1], [])
    test_case([1, 10], [10])
    test_case([1, 2, 3, 10], [10])
    test_case([9, 10], [10])
    test_case([10, 11, 12], [10, 11, 12])
    test_case([9, 10, 11, 12], [10, 11, 12])
    test_case([11, 9, 10, 11, 12], [11,9, 10, 11, 12])
    print("Test pass")
test_drop_until()


# Generated at 2022-06-11 21:43:21.837816
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    class InfiniteIter:
        def __iter__(self):
            return self
        def __next__(self):
            # On Python 2.x, infinity is available as inf.
            return float('inf')
    lazy_list = LazyList(InfiniteIter())
    try:
        len(lazy_list)
    except TypeError:
        pass
    except Exception as e:
        print('Exception:', e)

test_LazyList___len__()


# Generated at 2022-06-11 21:45:03.288330
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
  def count_elem(lst):
    return len(list(lst))
  lst = LazyList(range(10))
  assert count_elem(lst) == 10



# Generated at 2022-06-11 21:45:09.119305
# Unit test for function drop
def test_drop():
    yield lambda: assert_equal(
        list(drop(0, range(10))), list(range(10))
    )
    yield lambda: assert_equal(
        list(drop(5, range(10))), list(range(5, 10))
    )
    yield lambda: assert_equal(
        list(drop(10, range(10))), []
    )
    yield lambda: assert_equal(
        list(drop(15, range(10))), []
    )
    yield lambda: raises(
        ValueError, lambda: list(drop(-5, range(10)))
    )



# Generated at 2022-06-11 21:45:17.713434
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Arrange
    lst = [1, 2, 3, 4, 5]

    # Act
    map_list = MapList(lambda x: x * x, lst)

    # Assert
    assert map_list[2] == 9
    assert map_list[0:2] == [1, 4]

    lst_2 = [2, 3, 4, 5, 6]
    map_list_2 = MapList(lambda i: lst[i] * lst_2[i], Range(5))
    assert map_list_2[2] == 12



# Generated at 2022-06-11 21:45:22.924296
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(2, range(10))) == list(range(2, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(20, range(10))) == []



# Generated at 2022-06-11 21:45:28.642549
# Unit test for function drop
def test_drop():
    assert list(drop(2, [0, 1, 2, 3, 4, 5])) == [2, 3, 4, 5]
    assert list(drop(100, [0, 1, 2, 3, 4, 5])) == []
    assert list(drop(2, [])) == []
    assert list(drop(-2, [0, 1, 2, 3, 4, 5])) == [0, 1, 2, 3, 4, 5]




# Generated at 2022-06-11 21:45:36.728915
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    def test(n):
        lst_1 = LazyList(range(n))
        lst_2 = LazyList(range(n))
        for i, x in enumerate(lst_1):
            assert x == i
            if i >= sum(range(n)):
                break
        for i, x in enumerate(lst_2):
            assert x == i
            if i >= sum(range(n)):
                break

    test(0)
    test(1)
    test(2)
    test(10)



# Generated at 2022-06-11 21:45:48.957851
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_data = [(1,1),(1,2),(1,3),(1,4),(1,1),(2,2),(2,3),(2,4),(2,1),(3,2),(3,3),(3,4),(3,1),(4,2),(4,3),(4,4),(4,1)]
    for i in range(1, 5):
        r = Range(i)
        for j in range(1, 5):
            expected = test_data.pop(0)
            if expected[0] == i:
                print(f"should return: {expected[1]}")
                print(f"answer: {r[j]}")
                assert r[j] == expected[1]


# Generated at 2022-06-11 21:46:00.686981
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random
    a = [random.randint(-100, 100) for i in range(10)]
    m = MapList(lambda x: x ** 2, a)
    for i in range(len(a)):
        assert m[i] == a[i] ** 2
    for i in range(len(a) // 2, len(a)):
        assert m[i] == a[i] ** 2
    for i in range(len(a)):
        assert m[i:i + 1] == [a[i] ** 2]
    assert m[::2] == [x ** 2 for x in a[::2]]
    assert m[1:5:2] == [x ** 2 for x in a[1:5:2]]
    assert m[-1] == a[-1] ** 2
# Unit test

# Generated at 2022-06-11 21:46:13.380488
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print_result = True
    print_expected = True
    try:
        import common
        common.print_result = print_result
        common.print_expected = print_expected
        from common import TestInput
    except ModuleNotFoundError:
        import sys
        sys.path.append('..')
        import common
        common.print_result = print_result
        common.print_expected = print_expected
        from common import TestInput
    test_inputs = []

# Generated at 2022-06-11 21:46:24.235663
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    a: LazyList[int] = LazyList(range(2, 3))
    b: LazyList[int] = LazyList(range(3, 5))
    c: LazyList[int] = LazyList(range(5, 6))
    d: LazyList[int] = LazyList(range(500, 1000))
    e: LazyList[int] = LazyList(range(1000, 2000))
    f: LazyList[int] = LazyList(range(2, 3))
    g: LazyList[int] = LazyList(range(3, 5))
    h: LazyList[int] = LazyList(range(5, 6))
    i: LazyList[int] = LazyList(range(500, 1000))