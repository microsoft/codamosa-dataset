

# Generated at 2022-06-11 21:37:27.568144
# Unit test for method __next__ of class Range
def test_Range___next__():
    r = Range(0, 10)
    assert len(r) == 10
    assert list(r) == list(range(10))
    assert r[1] == 1



# Generated at 2022-06-11 21:37:34.011006
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    from iteration_utilities import LazyList
    from pytest import raises

    # Test that the iterable is not iterated beyond the specified index.
    assert list(LazyList(range(1000))[:5]) == list(range(5))

    # Test that LazyList of an exhausted iterable behaves the same as a list.
    assert list(LazyList(range(5))) == list(range(5))

    # Test that LazyList is not callable directly
    with raises(TypeError):
        LazyList(range(1000))()

    # Test that LazyList is callable after conversion to list
    assert list(LazyList(range(1000))[:5]()) == list(range(5))

# Generated at 2022-06-11 21:37:43.241177
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import lists
    from itertools import cycle
    from random import randint
    
    
    @given(integers())
    def test_len_list(arg):
        list_ex = [1, 2, 3, 4, 5]
        list_test = LazyList(list_ex)
        assert len(list_test) == len(list_ex)
        assert len(list_test[:]) == len(list_ex)
    
    
    @given(lists(integers()))
    def test_len_random_list(arg):
        list_ex = [1, 2, 3, 4, 5]
        list_test = LazyList(arg)
        assert len(list_test) == len(arg)

# Generated at 2022-06-11 21:37:48.148937
# Unit test for function chunk
def test_chunk():
    assert list(chunk(2, range(5))) == [[0, 1], [2, 3], [4]]
    assert list(chunk(4, range(2))) == [[0, 1]]
    assert list(chunk(1, range(2))) == [[0], [1]]
    try:
        list(chunk(0, range(1)))
        assert False
    except ValueError:
        pass



# Generated at 2022-06-11 21:37:55.119868
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import random

    r = Range(5, 10)
    for _ in range(100):
        i = random.randint(0, 4)
        assert r[i] == 5 + i
    for _ in range(100):
        i = random.randint(-4, -1)
        assert r[i] == 10 + i
    assert list(r) == [5, 6, 7, 8, 9]
    assert list(r[:3]) == [5, 6, 7]
    assert list(r[-3:]) == [7, 8, 9]


# Generated at 2022-06-11 21:38:05.982774
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(0, 10))) == [[]]
    assert list(chunk(3, range(1, 10))) == [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    assert list(chunk(3, range(2, 10))) == [[2, 3, 4], [5, 6, 7], [8, 9]]
    assert list(chunk(3, range(3, 10))) == [[3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(4, 10))) == [[4, 5, 6], [7, 8, 9]]

# Generated at 2022-06-11 21:38:10.669950
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    from typing import Sequence, Sized
    from .utils import isinstance_generic

    lst = LazyList([1, 2, 3])
    assert not isinstance(lst, Sized)
    assert not isinstance_generic(lst, Sequence)

    iter(lst)
    assert isinstance(lst, Sized)
    assert isinstance_generic(lst, Sequence)
    assert len(lst) == 3



# Generated at 2022-06-11 21:38:17.356760
# Unit test for function drop
def test_drop():
    assert list(drop(1, range(1))) == []
    assert list(drop(0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop(3, range(10))) == [3, 4, 5, 6, 7, 8, 9]
    assert list(drop(10, range(1))) == []
    assert list(drop(11, range(1))) == []


# Generated at 2022-06-11 21:38:20.407334
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(1000000)))==list(range(5,1000000))
    assert list(drop(0, range(1000000)))==list(range(1000000))
test_drop()


# Generated at 2022-06-11 21:38:29.204345
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x % 2 == 0, range(5, 10))) == [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(5, 10))) == [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 12, range(5, 10))) == list(range(5, 10))
    assert list(drop_until(lambda x: False, range(5, 10))) == list(range(5, 10))



# Generated at 2022-06-11 21:38:46.374289
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:38:53.788579
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import sys
# Python 3.8
if sys.version_info[0] == 3 and sys.version_info[1] >= 8:
    from random import randint
    a = []
    for i in range(100):
        a.append(randint(0, 99))
    b = LazyList(a)
    for i in range(100):
        assert b[i] == a[i]
    assert b[1:3] == a[1:3]
    assert b[-2:-1] == a[-2:-1]
    assert b[1:] == a[1:]
    assert b[:3] == a[:3]
    assert b[:] == a[:]

# Generated at 2022-06-11 21:38:58.541347
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    LL = LazyList([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert LL[3: -2] == [4, 5, 6, 7, 8]
    assert len(LL) == 10
test_LazyList___getitem__()



# Generated at 2022-06-11 21:39:00.188083
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:39:12.102344
# Unit test for function drop

# Generated at 2022-06-11 21:39:22.538541
# Unit test for function drop_until
def test_drop_until():
    # get the first value, discard the rest
    gen = drop_until(lambda x : x == 0, map(abs, range(-5, 5)))
    assert next(gen) == 0
    assert list(gen) == []
    
    # get the last value, discard the rest
    gen = drop_until(lambda x : x == 0, map(abs, range(-5, 5)))
    assert next(gen) == 0
    assert list(gen) == []

    # drop 2 values between [0, 1)
    gen = drop_until(lambda x: x >= 1, map(abs, range(-5, 2)))
    assert list(gen) == [1.0, 1.0]



# Generated at 2022-06-11 21:39:28.088829
# Unit test for method __next__ of class Range
def test_Range___next__():
    a=1
    b=10
    c=2
    r = Range(a, b, c)
    print(next(r))
    print(next(r))
    print(next(r))
    print(next(r))
    print(next(r))
    print(next(r))
    print(next(r))
    print(next(r))


# Generated at 2022-06-11 21:39:38.708721
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[3:5] == [3, 4]
    assert r[3:7:2] == [3, 5]
    assert r[-1] == 9
    assert r[0:2] == [0, 1]
    assert r[:4] == [0, 1, 2, 3]
    assert r[4:] == [4, 5, 6, 7, 8, 9]
    assert r[::2] == [0, 2, 4, 6, 8]
    assert r[5:1:-1] == [5, 4, 3, 2]
    assert r[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# Generated at 2022-06-11 21:39:50.807440
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=False, separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by(" Split by: ", empty_segments=True, criterion=lambda x: x == '.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

# Generated at 2022-06-11 21:39:58.737713
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(0))) == 0
    assert len(LazyList(range(1))) == 1
    assert len(LazyList(range(2))) == 2
    assert len(LazyList(range(3))) == 3
    assert len(LazyList(range(4))) == 4
    assert len(LazyList(range(5))) == 5
    assert len(LazyList(range(6))) == 6
    assert len(LazyList(range(7))) == 7
    assert len(LazyList(range(8))) == 8
    assert len(LazyList(range(9))) == 9
    assert len(LazyList(range(10))) == 10
    assert len(LazyList(range(11))) == 11
    assert len(LazyList(range(12))) == 12

# Generated at 2022-06-11 21:40:15.987336
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[5] == 5
    assert lst[5] == 5  # re-access
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[3:] == [3, 4, 5, 6, 7, 8, 9]
    assert lst[3::2] == [3, 5, 7, 9]
    assert lst[:5] == [0, 1, 2, 3, 4]  # cached


# Generated at 2022-06-11 21:40:25.403128
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    a = Range(10)
    assert a[0] == 0
    assert a[1] == 1
    assert a[9] == 9
    assert a[10] == 0
    assert a[11] == 1
    assert a[-1] == 9
    assert a[-10] == 0
    assert a[-11] == 9
    assert a[5:8] == [5, 6, 7]
    assert a[5:8:2] == [5, 7]
    assert a[5:8:-1] == []
    assert a[8:5] == []
    assert a[8:5:-1] == [8, 7, 6]
    assert a[8:5:-2] == [8, 6]
    assert a[8:5:2] == []

# Generated at 2022-06-11 21:40:29.560384
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2])
    assert lst[0] == 1
    assert lst[1] == 2
    assert lst[-1] == 2
    assert len(lst) == 2


# Generated at 2022-06-11 21:40:38.021662
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range = Range(0, 2)
    if not range[0] == range[-2]:
        raise AssertionError("first element of range should be equal to last element of range if we take the last two elements of range")
    if not range[0] == 0:
        raise AssertionError("first element of range should be 0")
    if not range[-1] == 1:
        raise AssertionError("last element of range should be 1")
    if not range[-2] == 0:
        raise AssertionError("last element of range should be 0 if we take the last two elements of range")
    if not range[-3] == 0:
        raise AssertionError("last element of range should be 0 if we take the last three elements of range")
    if not range[-4] == 0:
        raise Assert

# Generated at 2022-06-11 21:40:40.077506
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    for x in range(10):
        assert len(LazyList(range(x))) == x, f"LazyList(range({x})).__len__() failed"

# Generated at 2022-06-11 21:40:50.063480
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    it = iter([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    lst = LazyList(it)
    assert lst[3] == 4
    assert lst[len(lst) - 1] == 10
    assert lst[-1] == 10
    assert lst[-2] == 9
    assert next(iter(lst)) == 1
    assert next(it) == 11
    assert list(lst) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(it) == []
    assert lst[:2] == [1, 2]
    assert lst[2:] == [3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-11 21:40:54.046446
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Unit test for method __getitem__ of class MapList
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    l = MapList(lambda i: a[i] * b[i], Range(len(a)))
    assert l[2] == 24
    assert l[0:3] == [2, 12, 24]

# Generated at 2022-06-11 21:41:01.152341
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, [])) == []
    assert list(chunk(2, [])) == []
    assert list(chunk(0, [])) == []

test_chunk()



# Generated at 2022-06-11 21:41:07.091819
# Unit test for function drop_until
def test_drop_until():
    a = range(10)
    assert(drop_until(lambda x: x > 5, a) == filter(lambda x: x > 5, a))
    assert(drop_until(lambda x: x < 0, a) == filter(lambda x: x < 0, a))
    assert(drop_until(lambda x: x > 10, a) == filter(lambda x: x > 10, a))
    assert(drop_until(lambda x: x < 100, a) == filter(lambda x: x < 100, a))
test_drop_until()


# Generated at 2022-06-11 21:41:10.129307
# Unit test for function drop
def test_drop():
    iterable = range(10)
    n = 5
    it = iter(iterable)
    it = iter(drop(n, iterable))
    assert next(it) == 5



# Generated at 2022-06-11 21:41:25.583396
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    try:
        len(LazyList([0]))
        raise AssertionError("Expecting TypeError")
    except TypeError:
        pass
    assert len(LazyList([])) == 0
    assert len(LazyList(range(1000))) == 1000
    assert len(LazyList(range(1000))) == 1000  # call twice



# Generated at 2022-06-11 21:41:35.610689
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 10, range(10))) == []
    assert list(drop_until(lambda x: x > 10, range(10))) == []
    assert list(drop_until(lambda x: x > -1, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:41:46.610535
# Unit test for function split_by
def test_split_by():
    # Function split_by(iterable, empty_segments, criterion)
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[], [1, 2], [], [4, 5], [], [7, 8], []]
    with pytest.raises(ValueError):
        assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, separator=1))

# Generated at 2022-06-11 21:41:52.742298
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-11 21:42:03.108128
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, [1, 2, -1, 3, 5, 8, -2, 6, 10, -3])) == [8, -2, 6, 10, -3]
    assert list(drop_until(lambda x: x < 0, [1, 2, -1, 3, 5, 8, -2, 6, 10, -3])) == [-1, 3, 5, 8, -2, 6, 10, -3]
    assert list(drop_until(lambda x: x is None, [1, 2, None, 3, 5, 8, -2, 6, 10, -3])) == [None, 3, 5, 8, -2, 6, 10, -3]

# Generated at 2022-06-11 21:42:05.635908
# Unit test for function drop_until
def test_drop_until():
    for n in range(100):
        assert list(drop_until(lambda x: x > n, range(100))) == list(range(n+1, 100))



# Generated at 2022-06-11 21:42:07.844308
# Unit test for function chunk
def test_chunk():
    for s in ["", "a", "ab", "abc", "abcd"]:
        assert list(chunk(3, s)), list(chunk(3, s))

# Generated at 2022-06-11 21:42:14.004393
# Unit test for function take
def test_take():
    test_num = 9
    i = 1
    while i < test_num:
        n = randint(0, 9)
        lst = list(range(n))
        taken = list(take(n, lst))
        assert taken == lst[:n], f"take({n}, {lst}) == {taken} but not {lst[:n]}"
        i += 1
    print("Pass!")
#test_take()


# Generated at 2022-06-11 21:42:22.827524
# Unit test for function drop_until
def test_drop_until():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    is_even = lambda x: x % 2 == 0
    is_positive = lambda x: x >= 0
    is_ten = lambda x: x == 10
    assert list(drop_until(is_even, data)) == [0, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(drop_until(is_positive, data)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(drop_until(is_ten, data)) == [10]



# Generated at 2022-06-11 21:42:24.381792
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10)))


# Generated at 2022-06-11 21:43:05.958232
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-11 21:43:07.312292
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(100))) == 100

# Generated at 2022-06-11 21:43:15.913224
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=True, separator=" ")) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=True, criterion=lambda x: x in " .:")) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y'], [' '], []]

# Generated at 2022-06-11 21:43:27.352074
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # Case 1: the iterable is depleted before iteration
    lst = LazyList([1])
    assert list(lst) == [1]
    assert list(lst) == [1]  # LazyList is iterable multiple times

    # Case 2: the iterable is not depleted during the first iteration
    lst2 = LazyList(range(100))
    assert list(lst2) == list(range(100))
    assert list(lst2) == list(range(100))  # LazyList is iterable multiple times

    # Case 3: the iterable is not depleted until the second iteration
    lst3 = LazyList(itertools.count(0))
    assert list(lst3) == list(range(100))
    assert list(lst3) == list(range(100, 200))
#

# Generated at 2022-06-11 21:43:38.908109
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect

    # Find index of the first element in `a` whose square is >= 10.
    a = [1, 2, 3, 4, 5]
    pos = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    assert pos == 3

    # Find the first index `i` such that `a[i] * b[i]` is >= 10.
    b = [2, 3, 4, 5, 6]
    pos = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    assert pos == 2


# Generated at 2022-06-11 21:43:46.456378
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(1000000))
    it = iter(lst)
    assert next(it) == 0
    assert next(it) == 1
    assert next(it) == 2
    it2 = iter(lst)
    assert next(it2) == 0
    assert next(it2) == 1
    assert next(it2) == 2
    assert next(it) == 3
    assert next(it2) == 3
    assert next(it) == 4
    assert next(it2) == 4
    assert next(it) == 5
    assert next(it2) == 5
    assert next(it) == 6
    assert next(it2) == 6
    assert next(it) == 7
    assert next(it2) == 7
    assert next(it) == 8



# Generated at 2022-06-11 21:43:57.228123
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import random
    
    lst = LazyList(range(10))
    print(len(lst)) # error
    lst[0] # 1
    lst[9] # 10
    print(len(lst)) # error
    lst[8] # 9
    print(len(lst)) # 10
    lst[100] # IndexError
    lst[-100] # IndexError
    lst.list # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    print(len(lst)) # 10
    lst[-1] # 9
    print(len(lst)) # 10
    

# Generated at 2022-06-11 21:44:09.288489
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from os import urandom
    from random import choice
    from string import ascii_letters

    random_string = ''.join(urandom(choice(range(5000))) for _ in range(5000))
    lst = LazyList(random_string)

    assert len(lst) == 5000
    assert lst[-1] == random_string[-1]
    assert lst[:2000] == list(random_string[:2000])
    assert lst[3:20] == list(random_string[3:20])
    assert lst[-20:-2] == list(random_string[-20:-2])
    assert lst[-22:-20] == list(random_string[-22:-20])
    assert lst[-20:-22] == []

# Generated at 2022-06-11 21:44:10.985699
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    x = sum(LazyList(range(10)))
    assert x == 45



# Generated at 2022-06-11 21:44:15.481184
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    r = Range(1, 10 + 1)
    r = Range(1, 11, 2)
    assert(r[0] == 1)
    assert(r[2] == 5)
    assert(r[4] == 9)
# End test



# Generated at 2022-06-11 21:46:03.175080
# Unit test for function drop_until
def test_drop_until():
    """
    >>> l = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    >>> assert list(drop_until(lambda x: x > 5, l)) == [6, 7, 8, 9]
    >>> assert list(drop_until(lambda x: x < 5, l)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    >>> assert list(drop_until(lambda x: x < 0, l)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    >>> assert list(drop_until(lambda x: x > 9, l)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    """
    pass



# Generated at 2022-06-11 21:46:11.744110
# Unit test for function scanl
def test_scanl():
    import operator
    assert list(scanl(operator.add, [1, 2, 3, 4])) == [1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]



# Generated at 2022-06-11 21:46:13.803534
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[2] == lst[1] + 1

# Generated at 2022-06-11 21:46:25.517028
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from datetime import datetime
    from random import randint
    from typing import Sequence

    def random_iterable(limit: int) -> Sequence[float]:
        # Generate a random iterable whose length is between 1 and limit.
        # The iterable can be infinite.
        for i in range(randint(1, limit)):
            yield randint(1, 10)
        if randint(0, 1):
            while True:
                yield randint(1, 10)

    # Use a very large number to test the case where the original iterable is infinite.
    max_length = 100000

    start = datetime.now()
    for _ in range(100):
        lst = LazyList(random_iterable(max_length))
        length = randint(0, max_length)

# Generated at 2022-06-11 21:46:29.154234
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def f(x):
        return 2*x + 1

    a = MapList(f, [1, 2, 3, 4, 5])
    assert a[:2] == [3, 5]
    assert a[1] == 5


# Generated at 2022-06-11 21:46:37.073052
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    try:
        list(split_by(" Split by: ", empty_segments=True))
    except Exception as err:
        assert isinstance(err, ValueError)
test_split_by()

# Generated at 2022-06-11 21:46:46.438625
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from .functools import compose
    from .string import split
    from .numbers import fibonacci

    def test_list_syntax(lst: Sequence[int], func: Callable[[int], int]) -> None:
        assert isinstance(lst, MapList)
        assert isinstance(func, MapList)
        assert lst[0] == func(0)

# Generated at 2022-06-11 21:46:48.055306
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    Range(10)



# Generated at 2022-06-11 21:46:52.081732
# Unit test for function drop_until
def test_drop_until():
    l = [1, 2, 3, 4, 5, 6, 7]
    assert list(drop_until(lambda x: x > 5, l)) == [6, 7]
    assert next(drop_until(lambda x: x > 5, iter(l))) == 6



# Generated at 2022-06-11 21:46:59.288808
# Unit test for function split_by