

# Generated at 2022-06-11 21:37:14.019588
# Unit test for function drop
def test_drop():
    result = list(itertools.islice(drop(5, range(10)), 5))
    assert result == [5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:37:23.466261
# Unit test for function drop
def test_drop():
    with pytest.raises(StopIteration):
        next(drop(0, []))
    with pytest.raises(StopIteration):
        next(drop(1, []))
    assert next(drop(0, [1, 2, 3])) == 1
    assert next(drop(1, [1, 2, 3])) == 2
    assert next(drop(2, [1, 2, 3])) == 3
    with pytest.raises(StopIteration):
        next(drop(3, [1, 2, 3]))
    with pytest.raises(StopIteration):
        next(drop(4, [1, 2, 3]))
    assert list(drop(0, [1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-11 21:37:30.364127
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1,2,3,4])) == [1,3,6,10]
    assert list(scanl(operator.add, [1,2,3,4], 0)) == [0,1,3,6,10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-11 21:37:32.852941
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(6, "spam")) == ["spam"]


# Generated at 2022-06-11 21:37:41.768669
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, [])) == []
    assert list(chunk(3, [1])) == [[1]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(1, range(9))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8]]
    assert list(chunk(-1, range(9))) == ValueError



# Generated at 2022-06-11 21:37:44.332906
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x >= 5, range(10))) == [5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:37:49.018861
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: True, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
test_drop_until()



# Generated at 2022-06-11 21:37:51.083325
# Unit test for function take
def test_take():
    assert list(take(3, range(5))) == [0, 1, 2]
    

# Generated at 2022-06-11 21:37:54.227256
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3, 4])
    assert list(lst) == [1, 2, 3, 4]
    assert list(lst) == [1, 2, 3, 4]



# Generated at 2022-06-11 21:38:00.943292
# Unit test for function chunk
def test_chunk():
    for n in range(3):
        assert list(chunk(n, range(10))) == []

    assert list(chunk(5, range(10))) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]
    assert list(chunk(7, range(10))) == [[0, 1, 2, 3, 4, 5, 6], [7, 8, 9]]



# Generated at 2022-06-11 21:38:20.246051
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    def test(l, r, step, idx):
        res = list(Range(l, r, step)[idx])
        expected = [l + step * i for i in range(*idx.indices(len(Range(l, r, step))))]
        return res == expected
    l = 0
    r = 11
    step = 1
    idx = slice(4, 10, 2)
    assert test(l, r, step, idx)

# Generated at 2022-06-11 21:38:30.279419
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(1, range(10))) == [0]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(20, range(10))) == list(range(10))
    assert list(take(-1, range(10))) == []
    assert list(take(-1, [])) == []
    assert list(take(0, (1,))) == []
    assert list(take(1, (1,))) == [1]
    assert list(take(2, (1,))) == [1]


# Generated at 2022-06-11 21:38:32.886104
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [])) == []



# Generated at 2022-06-11 21:38:37.757202
# Unit test for function take
def test_take():
    try:
        x = take(-1,range(10))
        raise AssertionError("take should fail on negative n")
    except:
        pass
    assert list(take(0, range(10))) == []
    assert list(take(3, range(10))) == [0,1,2]
    assert list(take(500, range(10))) == list(range(10))
    assert list(take(0, iter([]))) == []


# Generated at 2022-06-11 21:38:41.853681
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x < 5, range(10))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:38:51.312316
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from random import randint
    from unittest.mock import MagicMock
    from unittest import TestCase


# Generated at 2022-06-11 21:39:00.041478
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(100000))
    lst = LazyList(lst)
    lst = LazyList(lst)
    assert lst[5] == 5
    assert all(x == y for x, y in zip(lst[5:10], range(5, 10)))
    assert all(x == y for x, y in zip(lst, range(100000)))
    assert all(x == y for x, y in zip(lst, LazyList(range(100000))))

# Generated at 2022-06-11 21:39:07.298712
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [0, 1, 2, 3, 4, 5])) == []
    assert list(drop_until(lambda x: x > 5, [6, 7, 8, 9])) == [6, 7, 8, 9]


# Generated at 2022-06-11 21:39:15.668840
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 0, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 6, range(10))) == [7, 8, 9]
    assert list(drop_until(lambda x: x > -1, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 9, range(10))) == []


# Generated at 2022-06-11 21:39:20.595330
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r_1 = Range(10)

    assert r_1[0] == 0
    assert r_1[5] == 5
    assert r_1[-1] == 9
    assert r_1[3:6] == [3, 4, 5]
    assert r_1[:10:2] == [0, 2, 4, 6, 8]
    assert r_1[::-1] == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

    r_2 = Range(1, 10 + 1)

    assert r_2[0] == 1
    assert r_2[4] == 5
    assert r_2[10] == 11
    assert r_2[-1] == 10

    r_3 = Range(1, 11, 2)


# Generated at 2022-06-11 21:39:37.254469
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert list(itertools.islice(LazyList(range(100)), 5)) == [0, 1, 2, 3, 4]
    assert list(itertools.islice(LazyList(range(100)), 10, 15)) == [10, 11, 12, 13, 14]
    assert list(LazyList(range(100))[10:15]) == [10, 11, 12, 13, 14]
    assert list(LazyList(range(100))[::2]) == list(range(0, 100, 2))
    assert list(LazyList(range(100))[50:-1]) == list(range(50, 99))



# Generated at 2022-06-11 21:39:42.118732
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == [0, 1, 2]
    assert list(take(5, "")) == []
    assert list(take(10, "ABCD")) == ["A", "B", "C", "D"]



# Generated at 2022-06-11 21:39:48.472074
# Unit test for function drop_until
def test_drop_until():
    import unittest
    import random

    class TestCase(unittest.TestCase):
        def test(self):
            l = list(sorted(random.sample(range(10000), 10000)))
            for i in range(len(l)):
                left = l[:i]
                right = l[i:]
                assert list(drop_until(lambda x: x >= i, left)) == right
    unittest.main()



# Generated at 2022-06-11 21:39:52.629723
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == [0, 1, 2]
    assert list(take(1, range(0))) == []
    assert list(take(0, range(10))) == []
    assert list(take(10, range(10))) == list(range(10))



# Generated at 2022-06-11 21:39:55.801927
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) \
           == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:40:00.119819
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(10))) == []
    assert list(take(5, range(3))) == [0, 1, 2]
    assert list(take(5, [])) == []



# Generated at 2022-06-11 21:40:07.355324
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(0))) == []
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(9))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(11))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10]]



# Generated at 2022-06-11 21:40:09.639769
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3])
    assert len(lst) == 3, "__len__ method of LazyList class failed"

# Generated at 2022-06-11 21:40:13.661730
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1, 2)
    print(r[0], r[2], r[4])
    print(r[-1], r[-3], r[-5])
    print(r[slice(0, None)])
    print(r[slice(0, None, 2)])
    print(r[slice(1, None)])
    print(r[slice(2, None)])
    print(r[slice(None, None)])



# Skip the first ``n`` elements of an iterable, then take the next ``k`` elements and apply ``func`` to each,
# and return a list of the results.

# Generated at 2022-06-11 21:40:16.856471
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-11 21:40:29.345802
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == list(range(5))
    assert list(take(0, range(1000000))) == []
    assert list(take(10, range(5))) == list(range(5))
    assert list(take(-5, range(5))) == []



# Generated at 2022-06-11 21:40:34.494351
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]



# Generated at 2022-06-11 21:40:40.809159
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-11 21:40:51.446554
# Unit test for function split_by
def test_split_by():
    assert list(split_by('', separator='.')) == [[]]

    # Test for criterion
    assert list(split_by(range(1, 10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[], [1, 2], [], [4, 5], [],
                                                                                              [7, 8], []]
    # Test for separator
    assert list(split_by('.', empty_segments=True, separator='.')) == [[], [], [], []]
    assert list(split_by('..', empty_segments=True, separator='.')) == [[], [], []]

# Generated at 2022-06-11 21:41:02.173052
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(20, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(take(5, 'hello')) == ['h', 'e', 'l', 'l', 'o']
    assert list(take(1, (1,))) == [1]
    assert list(take(1, [])) == []
    assert list(take(1, ())) == []

    # ValueError
    with pytest.raises(ValueError):
        take(-1, range(10))
    with pytest.raises(ValueError):
        take(-1, 'hello')

# Generated at 2022-06-11 21:41:13.037915
# Unit test for function chunk
def test_chunk():
    import z3
    l = z3.IntVector('l', 4)
    s = z3.Solver()
    l0 = z3.IntVector('l0', 4)
    l1 = z3.IntVector('l1', 4)
    l2 = z3.IntVector('l2', 4)
    l3 = z3.IntVector('l3', 4)

# Generated at 2022-06-11 21:41:23.765591
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until((lambda x: x > 5), range(10))) == [6, 7, 8, 9]
    assert list(drop_until((lambda x: x > 5), map(str, range(10)))) == ['6', '7', '8', '9']
    it = iter(range(10))
    assert list(drop_until((lambda x: x > 5), it)) == [6, 7, 8, 9]
    assert list(drop_until((lambda x: x > 5), it)) == []
    it = iter(range(10))
    assert list(drop_until((lambda x: x > 100), it)) == []
    assert list(it) == list(range(10))
    it = iter(range(10))
    assert list(drop_until((lambda x: x > 9), it)) == []


# Generated at 2022-06-11 21:41:34.985004
# Unit test for function take
def test_take():
    # return correct value for number n elements
    n = 5
    assert list(take(n, range(1000000))) == [0, 1, 2, 3, 4]
    n = 25
    assert list(take(n, range(1000000))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
    # return empty list for n = 0
    n = 0
    assert list(take(n, range(1000000))) == []
    # throw exception if n < 0
    n = -1
    with pytest.raises(ValueError):
        list(take(n, range(1000000)))

# Generated at 2022-06-11 21:41:38.358756
# Unit test for function drop_until
def test_drop_until():
    from itertools import accumulate
    from operator import add
    arr = range(10)
    assert list(drop_until(lambda x: x>5, arr)) == list(accumulate(arr, add))[6:]
test_drop_until()

# Generated at 2022-06-11 21:41:42.948448
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(2))) == []
    assert next(drop(3, range(3))) == 2
    assert next(drop(3, range(4))) == 3
    assert next(drop(3, range(5))) == 3


# Generated at 2022-06-11 21:42:05.044569
# Unit test for function drop_until
def test_drop_until():
    l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(drop_until(lambda x: x > 5, l)) == [6, 7, 8, 9, 10]
    assert list(drop_until(lambda x: x % 3 == 0, l)) == [3, 4, 5, 6, 7, 8, 9, 10]
    assert list(drop_until(lambda x: x == 1, l)) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(drop_until(lambda x: x > 10, l)) == []


# Generated at 2022-06-11 21:42:11.914921
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
test_chunk()



# Generated at 2022-06-11 21:42:16.120356
# Unit test for function split_by
def test_split_by():
    assert list(split_by([0, 1, 2, 3, 4, 5], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5]]
    assert list(split_by([0, 1, 2, 3, 4, 5], criterion=lambda x: x % 3 == 0, empty_segments=True)) \
           == [[], [1, 2], [4, 5]]
    assert list(split_by(" Split by: ", empty_segments=True, separator=' ')) \
           == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:42:18.053868
# Unit test for function drop_until
def test_drop_until():
    data = list(drop_until(lambda x: x > 5, range(10)))
    assert list(data) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:42:20.307139
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    range_1 = Range(1, 10, 2)
    #assert [range_1[0], range_1[1], range_1[2]] == [1, 3, 5]
    #assert [range_1[-1], range_1[-2],  range_1[-3]] == [9, 7, 5]


# Generated at 2022-06-11 21:42:25.269656
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    def f():
        yield 1
        yield 2
        yield 3
    ll = LazyList(f())
    assert isinstance(ll.__iter__(), LazyList.LazyListIterator)



# Generated at 2022-06-11 21:42:29.536591
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10000))
    assert lst[-1] == 9999
    assert len(lst[:]) == 10000
    # the following line is only possible because __getitem__ doesn't raise IndexError
    # and therefore the iterable gets exhausted
    assert len(lst) == 10000
    with pytest.raises(TypeError):
        len(LazyList(range(10000)))



# Generated at 2022-06-11 21:42:32.538743
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == list(range(5))



# Generated at 2022-06-11 21:42:37.034974
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    with pytest.raises(ValueError):
        list(take(-1, range(1000000))) == []



# Generated at 2022-06-11 21:42:43.470311
# Unit test for function drop
def test_drop():
    for i in range(5):
        for j in range(5):
            assert list(drop(i, range(j))) == list(range(i, j))
    assert list(drop(5, range(5))) == []
    assert list(drop(5, range(10))) == list(range(5, 10))



# Generated at 2022-06-11 21:43:16.943477
# Unit test for function take
def test_take():
    x = list(take(1, [1, 2, 3]))
    assert x[0] == 1
    x = list(take(2, [1, 2, 3]))
    assert x[0] == 1
    assert x[1] == 2
    x = list(take(3, [1, 2, 3]))
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3


# Generated at 2022-06-11 21:43:25.778552
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    index_range = Range(-2,2)
    assert(index_range[0] == -2)
    assert(index_range[1] == -1)
    assert(index_range[2] == 0)
    assert(index_range[3] == 1)

    index_range = Range(0,3)
    assert(index_range[0] == 0)
    assert(index_range[1] == 1)
    assert(index_range[2] == 2)

    index_range = Range(0,3,2)
    assert(index_range[0] == 0)
    assert(index_range[1] == 2)

    index_range = Range(0,4,2)
    assert(index_range[0] == 0)
    assert(index_range[1] == 2)

# Generated at 2022-06-11 21:43:34.943292
# Unit test for function split_by
def test_split_by():
    assert [list(x) for x in split_by(" Split by: ", empty_segments=True, separator='.')] == \
        [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert [list(x) for x in split_by(range(10), criterion=lambda x: x % 3 == 0)] == \
        [[1, 2], [4, 5], [7, 8]]



# Generated at 2022-06-11 21:43:38.945361
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    def test_iter(lst):
        assert lst[0:2] == lst[0:1] + lst[1:2]
        assert lst[[0, 2]] == [lst[0], lst[2]]

    test_iter(LazyList(range(1000)))
    test_iter(LazyList([1, 2]))
    test_iter(LazyList(range(0)))
    test_iter(LazyList(range(1)))



# Generated at 2022-06-11 21:43:44.987577
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList([1, 2, 3])
    iter1 = iter(lst)
    iter2 = lst.__iter__()
    assert next(iter1) == 1
    assert next(iter2) == 1
    assert next(iter1) == 2
    assert next(lst) == 2
    assert next(iter1) == 3
    assert next(lst) == 3
    assert next(iter1) == StopIteration
    with raises(StopIteration):
        next(lst)
    assert isinstance(lst, Sequence)



# Generated at 2022-06-11 21:43:56.306890
# Unit test for function split_by
def test_split_by():
    assert list(split_by([0, 1, 2, 3])) == [[1, 2, 3]]
    assert list(split_by([0, 1, 2, 3], separator=0)) == [[1, 2, 3]]
    assert list(split_by([0, 1, 2, 3], criterion=lambda x: x < 3)) == [[1, 2], [3]]
    assert list(split_by([0, 1, 2, 3], empty_segments=True)) == [[], [1, 2, 3]]
    assert list(split_by([0, 1, 2, 3], empty_segments=True, separator=0)) == [[], [1, 2, 3]]

# Generated at 2022-06-11 21:44:08.221620
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10)))==[6,7,8,9]
    assert list(drop_until(lambda x: x < 5, range(10)))==[0,1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: x == 2, range(10)))==[2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: x == 0, range(10)))==[0,1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: x == 9, range(10)))==[9]
    assert list(drop_until(lambda x: x == 10, range(10)))==[]
#

# Generated at 2022-06-11 21:44:16.228013
# Unit test for function split_by
def test_split_by():
    lst = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert list(split_by(lst, criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5, 6], [7, 8, 9], [10]]
    assert list(split_by(lst, criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5, 6], [],
                                                                                      [7, 8, 9], [10], []]
    assert list(split_by(lst, separator=5)) == [[1, 2, 3, 4], [6, 7, 8, 9, 10]]

# Generated at 2022-06-11 21:44:19.950685
# Unit test for function drop_until
def test_drop_until():
    a = range(10)
    b = [5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, a)) == b
    assert list(drop_until(lambda x: x > b[0], a)) == b



# Generated at 2022-06-11 21:44:28.918613
# Unit test for function drop_until
def test_drop_until():
    from random import randint
    from .testutil import is_long_running, consume
    for i in range(100):
        # Generate a random list of ints
        arr = [randint(0, 5) for _ in range(100)]
        # Run the test
        it = iter(arr)
        result = drop_until(lambda x: x > 1, it)
        assert consume(result) == [x for x in arr if x > 1]
    if is_long_running():
        # Run a more expensive test
        arr = list(range(10000))
        it = iter(arr)
        result = drop_until(lambda x: x < 100, it)
        assert consume(result) == [x for x in arr if x < 100]



# Generated at 2022-06-11 21:46:41.434760
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:46:53.021714
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print('# Unit test for method __getitem__ of class Range')

# Generated at 2022-06-11 21:47:02.331840
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # getitem
    def myfunc(x): return x + 1
    m = MapList(myfunc, [2,3,4,5,6])
    assert m[0] == 3
    assert m[1] == 4
    assert m[2] == 5
    assert m[-1] == 7
    assert m[-2] == 6
    assert m[1:4] == [4,5,6]
    assert m[:] == [3,4,5,6,7]
    assert m[:3] == [3,4,5]
    assert m[2:] == [5,6,7]