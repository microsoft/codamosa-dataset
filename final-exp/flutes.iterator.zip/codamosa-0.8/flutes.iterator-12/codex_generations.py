

# Generated at 2022-06-11 21:37:27.731665
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # TODO: Fix
    lst = Range(10)
    for idx in range(0, 10):
        assert lst[idx] == idx
    for idx in range(0, 10, 2):
        assert lst[idx] == idx



# Generated at 2022-06-11 21:37:29.431239
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([10])
    assert lst.__len__() == 1

# Generated at 2022-06-11 21:37:32.719394
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Test positive cases
    a = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, a)
    assert m[0] == 1
    assert m[1] == 4
    assert m[-1] == 25
    assert m[1:4] == [4, 9, 16]
    # Test negative cases
    try:
        print(m[10])
    except IndexError as e:
        pass
    else:
        assert False, 'Expected IndexError'


# Generated at 2022-06-11 21:37:42.611994
# Unit test for function split_by
def test_split_by():
    # One criterion
    assert [[1, 2], [3, 4]] == list(split_by([1, 2, 3, 4], criterion=lambda x: x > 2))

    # Separator
    assert [['a', 'b', 'c'], ['d', 'e', 'f']] == list(split_by(['a', 'b', 'c', '.', '.', 'd', 'e', 'f'], separator='.'))

    # Empty segments
    assert [['a', 'b', 'c'], [], ['d', 'e', 'f'], []] == list(split_by(['a', 'b', 'c', '.', '.', 'd', 'e', 'f', '.'],
                                                                     separator='.', empty_segments=True))



# Generated at 2022-06-11 21:37:50.525798
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for i in range(0, 10, 1):
        assert (MapList(lambda x: x, [1, 2, 3, 4, 5])[i] == (1, 2, 3, 4, 5)[i])
    for i in range(0, 10, 1):
        assert (MapList(lambda x: x, [1, 2, 3, 4, 5])[i] == (1, 2, 3, 4, 5)[i])
    for i in range(0, 10, 1):
        assert (MapList(lambda x: x, [1, 2, 3, 4, 5])[i] == (1, 2, 3, 4, 5)[i])

# Generated at 2022-06-11 21:37:52.738623
# Unit test for function drop
def test_drop():
    for i in range(10):
        for x in drop(i, range(10)):
            print(x)


# Generated at 2022-06-11 21:38:05.365472
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    a = Range(1, 20 + 1, 2)
    assert a[0] == 1
    assert a[2] == 5
    assert a[-1] == 21
    assert a[-3] == 17
    assert a[0:0] == []
    assert a[0:1] == [1]
    assert a[-2:-1] == [19]
    assert a[2:-2] == [5, 7, 9, 11, 13, 15, 17]
    assert a[0:100] == [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21]
    assert a[-100:100] == [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21]

# Generated at 2022-06-11 21:38:09.655373
# Unit test for function drop_until
def test_drop_until():
    it = range(10)
    assert list(drop_until(lambda x: x > 5, it)) == list(range(6, 10))
    it = range(10)
    assert list(drop_until(lambda x: x > 10, it)) == []



# Generated at 2022-06-11 21:38:20.486124
# Unit test for function take
def test_take():
    a = [5, 3, 0, 12]
    b = take(2, a)

    assert(a == [5, 3, 0, 12])
    assert(list(b) == [5, 3])
    assert(a == [5, 3, 0, 12])

    b = take(4, a)

    assert(a == [5, 3, 0, 12])
    assert(list(b) == [5, 3, 0, 12])
    assert(a == [5, 3, 0, 12])

    b = take(0, a)

    assert(a == [5, 3, 0, 12])
    assert(list(b) == [])
    assert(a == [5, 3, 0, 12])

    b  = take(100, a)


# Generated at 2022-06-11 21:38:30.991975
# Unit test for function drop
def test_drop():
    # Simple case
    assert list(drop(3, range(10))) == [3,4,5,6,7,8,9]
    # Non-positive case
    assert list(drop(0, range(10))) == [0,1,2,3,4,5,6,7,8,9]
    # Over-bound case
    assert list(drop(11, range(10))) == []
    # Negative case
    try:
        assert False == True
        assert list(drop(-1, range(10))) == []
    except ValueError:
        assert True == True
    # Directly use range as input
    assert list(drop(3, range(0,10,2))) == [6,8]



# Generated at 2022-06-11 21:38:48.275125
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    lst = [1]
    lst = lst * 1000
    count = 0
    for i in Range(len(lst)):
        count = count + lst[i]
    assert count == sum(lst)
    lst = [1]
    lst = lst * 1000
    count = 0
    for i in Range(0, len(lst)):
        count = count + lst[i]
    assert count == sum(lst)
    lst = [1]
    lst = lst * 1000
    count = 0
    for i in Range(0, len(lst), 2):
        count = count + lst[i]
    assert count == sum(lst[0::2])
    lst = [1]
    lst = lst * 1000
    count = 0


# Generated at 2022-06-11 21:38:55.825777
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']

test_scanl()



# Generated at 2022-06-11 21:38:57.584635
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(1000000))) == 1000000

# Generated at 2022-06-11 21:39:00.645448
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, [])) == []
    assert list(take(0, range(1000000))) == []

# Generated at 2022-06-11 21:39:12.779421
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    class TestIterable:
        def __init__(self):
            self.__it = iter([1, 2, 3, 4, 5, 6])
        def __iter__(self):
            return self.__it
        def __len__(self):
            raise TypeError()
    tests = [
        [(0,), 1],
        [(1,), 2],
        [(-2,), 5],
        [slice(0, 3), [1, 2, 3]],
        [slice(0, -1), [1, 2, 3, 4, 5]],
        [slice(-2, None), [5, 6]],
    ]
    for test in tests:
        obj = LazyList(TestIterable())
        assert obj[test[0]] == test[1]

# Generated at 2022-06-11 21:39:17.545288
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)         # (end)
    r = Range(1, 10 + 1)  # (start, end)
    r = Range(1, 11, 2)   # (start, end, step)
    # print(r[0], r[2], r[4])
    # print(r[1:4])
    # print(r[:4])
    # print(r[4:])
    # print(r[-3])
    # print(r[-4:-2])
    # print(r[-2:])
    # print(r[0:10:2])
    # print(r[::3])
    # print(r[::-1])
    # print(r[::-2])
    # print(r[5:1:-2])
    # print(r[2

# Generated at 2022-06-11 21:39:19.024395
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1,11,2)
    print(r[0:5:2])
    #print(r[-1])


# Generated at 2022-06-11 21:39:24.283404
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(" Split by: ", empty_segments=True, criterion=lambda x: x == ' ')) == [[], ['S'], ['p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-11 21:39:31.151323
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, '')) == []
    assert list(take(5, [])) == []
    assert list(take(0, range(1000000))) == []
    assert list(take(-1, range(1000000))) == []

test_take()



# Generated at 2022-06-11 21:39:38.442926
# Unit test for function drop_until
def test_drop_until():
    list1 = list(range(10))
    list2 = list(drop_until(lambda x: x > 5, list1))
    assert list1[6:] == list2
    list3 = list(drop_until(lambda x: x > -1, list1))
    assert list1 == list3
    list4 = list(drop_until(lambda x: x > 100, list1))
    assert not list4
    list5 = list(drop_until(lambda x: x > -1, []))
    assert not list5
# test_drop_until()



# Generated at 2022-06-11 21:39:55.727845
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(range(1000))
    try:
        l.__len__()
    except:
        pass
    for x in l:
        pass
    assert l.__len__() == len(l.list)



# Generated at 2022-06-11 21:40:05.501157
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    def test_slice(lst, slice_, expected):
        actual = lst[slice_]
        assert isinstance(actual, list), "Slice must return a list"
        assert actual == expected, "Slice must return {}".format(expected)

    test_slice(LazyList(range(10))[::2], slice(0, 4, 2), [0, 4, 8])
    test_slice(LazyList(range(10))[::-1], slice(None, None, -1), list(range(10)))
    test_slice(LazyList(range(10))[::-2], slice(3, None, -2), [3, 1])
    test_slice(LazyList(range(10))[::-1], slice(None, 2, -1), [9, 8])

# Generated at 2022-06-11 21:40:13.175469
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    test_cases = [
        (Range(0), [0]),
        (Range(1, 1), []),
        (Range(1, 2), [1]),
        (Range(1, 5), [1, 2, 3, 4]),
        (Range(1, 6, 2), [1, 3, 5]),
        (Range(5, 1, -2), [5, 3]),
        (Range(1, -3, -1), [1, 0, -1, -2]),
    ]
    for test_case in test_cases:
        exp_result = test_case[1]
        for i, expected in enumerate(exp_result):
            result = test_case[0][i]
            assert result == expected
        for i, expected in enumerate(exp_result[::-1]):
            result = test_

# Generated at 2022-06-11 21:40:23.360111
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by("", empty_segments=True, separator='')) == [[], []]
    assert list(split_by("", empty_segments=False, separator='')) == [(), ]


# Generated at 2022-06-11 21:40:33.870084
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    from unittest import TestCase, main

    class MapList___getitem__(TestCase):
        def test_1(self):
            def func(x):
                return x * x

            a = [1, 2, 3, 4, 5]
            ml = MapList(func, a)

            self.assertEqual(ml[0], 1)
            self.assertEqual(ml[1], 4)
            self.assertEqual(ml[-1], 25)
            self.assertEqual(ml[:2], [1, 4])
            self.assertEqual(ml[1:3], [4, 9])
            self.assertEqual(ml[:], [1, 4, 9, 16, 25])

    main()



# Generated at 2022-06-11 21:40:44.358416
# Unit test for function split_by
def test_split_by():
    assert list(split_by([])) == []
    assert list(split_by((1, 2, 3, 4), lambda x: x % 2 == 0)) == [[1, 3]]

# Generated at 2022-06-11 21:40:53.600683
# Unit test for function drop_until
def test_drop_until():
    x = range(10)
    assert list(drop_until(lambda x: x > 5, x)) == [6,7,8,9]
    assert list(drop_until(lambda x: x > 10, x)) == []
    assert list(drop_until(lambda x: x > 0 and x < 5, x)) == [1,2,3,4,6,7,8,9]
    assert list(drop_until(lambda x: x < 0, x)) == [0,1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: x == 0, x)) == [0,1,2,3,4,5,6,7,8,9]

# Generated at 2022-06-11 21:40:56.987533
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(0))
    assert len(lst) == 0
    lst = LazyList(range(10))
    assert len(lst) == 10



# Generated at 2022-06-11 21:41:00.654750
# Unit test for function drop_until
def test_drop_until():
    for expected, actual in zip(range(5, 10), drop_until(lambda x: x > 5, range(10))):
        assert expected == actual, 'Error in function drop_until'
test_drop_until()



# Generated at 2022-06-11 21:41:04.640933
# Unit test for function take
def test_take():
    def _test(n, seq):
        assert list(take(n, seq)) == seq[:n]

    _test(0, [])
    _test(100, [])
    _test(0, list(range(100)))
    _test(100, list(range(100)))
test_take()



# Generated at 2022-06-11 21:41:21.907359
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    t = MapList(lambda x: x*x, [1,2,3,4,5])
    assert t[0] == 1
    assert t[1] == 4
    assert t[2] == 9
    assert t[3] == 16
    assert t[4] == 25
    assert t[-1] == 25
    assert t[0:3] == [1, 4, 9]
    assert t[2:5] == [9, 16, 25]



# Generated at 2022-06-11 21:41:27.000513
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by("Split by:", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:41:30.760340
# Unit test for function take
def test_take():
    data = [str(i) for i in range(100)]
    for n in [0, 5, 100, 1000]:
        assert list(take(n, data)) == list(data[:n])



# Generated at 2022-06-11 21:41:34.105304
# Unit test for function drop
def test_drop():
    it = drop(5, range(10))
    for i in range(1, 5):
        assert next(it) == i+5
    for i in it:
        assert False



# Generated at 2022-06-11 21:41:36.318343
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:41:46.828811
# Unit test for function drop_until
def test_drop_until():
    l = list(range(10))
    assert list(drop_until(lambda x: x < 5, l)) == l
    assert list(drop_until(lambda x: x >= 5, l)) == l[5:]
    assert list(drop_until(lambda x: x > 5, l)) == l[6:]
    assert list(drop_until(lambda x: x == 5, l)) == l[5:]
    assert list(drop_until(lambda x: x == 4, l)) == l[4:]
    assert list(drop_until(lambda x: x == 3, l)) == l[3:]
    assert list(drop_until(lambda x: x == 2, l)) == l[2:]
    assert list(drop_until(lambda x: x == 1, l)) == l[1:]

# Generated at 2022-06-11 21:41:57.435452
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import collections

    student_answers = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
    student_answers = collections.deque(student_answers)
    student_answers = MapList(lambda x: x - 2, student_answers)
    assert(student_answers[0] == 1)
    assert(student_answers[-1] == 18)
    student_answers = MapList(lambda x: x - 2, student_answers)
    assert(student_answers[0] == -1)
    assert(student_answers[-1] == 16)

# Generated at 2022-06-11 21:42:07.076320
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    func = lambda x: x * x
    lst = [1, 2, 3, 4, 5]
    m = MapList(func, lst)
    n = len(m)

    # sequence
    assert m[0] == func(lst[0])
    assert m[n - 1] == func(lst[n - 1])
    assert m[n:n] == []
    assert m[:] == [func(x) for x in lst]
    assert m[0:n:2] == [func(x) for x in lst[0:n:2]]
    import sys
    assert m[sys.maxsize:sys.maxsize:sys.maxsize] == []
    assert m[n:0] == []
    assert m[n:0:2] == []

# Generated at 2022-06-11 21:42:15.831099
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import random
    for start in range(10):
        for end in range(start, start + 10):
            for step in range(1, 10):
                r = Range(start, end + 1, step)
                l = list(range(start, end, step))
                assert (len(r) == len(l)), "len(Range({}, {}, {})) = {} but len(list) = {}".format(start, end, step, len(r), len(l))

# Generated at 2022-06-11 21:42:26.753247
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    class LazyList(Generic[A], Sequence[A]):
        def __init__(self, iterable: Iterable[A]):
            self.iterable = iterable
            self.flag = False
        def test_LazyList__init__():
            try:
                ret = LazyList(1)
            except TypeError:
                pass
            else:
                assert False, "TypeError expected"
            ret = LazyList(range(0))
            assert isinstance(ret, LazyList), "unexpected type"
        def __iter__(self) -> Iterator[A]:
            return iter(self.iterable)
        def test___iter__(self):
            ret = self.__iter__()

# Generated at 2022-06-11 21:42:53.631193
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(3), criterion=lambda x: x == 1)) == [[0], [2]]
    assert list(split_by(range(3), criterion=lambda x: x == 1, empty_segments=True)) == [[], [0], [2], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", separator='.')) == [['S', 'p', 'l', 'i', 't', ' ', 'b', 'y', ':'], []]

# Generated at 2022-06-11 21:42:55.531208
# Unit test for function drop
def test_drop():
    for i in drop(2,[1,2,3,4,5]):
        print(i)
test_drop()


# Generated at 2022-06-11 21:43:06.954915
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2, 3, 4, 4, 5, 6, 7, 7], criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7]]
    assert list(split_by([1, 3, 3, 5, 6, 7, 7], criterion=lambda x: x % 3 == 0)) == [[1], [5], [7]]
    assert list(split_by([1, 3, 3, 5, 6, 7, 7], criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1], [], [5], [], [7]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]

# Generated at 2022-06-11 21:43:12.078224
# Unit test for function drop_until
def test_drop_until():
    list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    list(drop_until(lambda x: x < 4, range(10))) == [4, 5, 6, 7, 8, 9]
    try:
        list(drop_until(lambda x: x > 5, []))
        assert False
    except StopIteration:
        pass



# Generated at 2022-06-11 21:43:18.563316
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x < 5, range(10))) == []
    assert list(drop_until(lambda x: x < 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:43:26.806172
# Unit test for method __getitem__ of class Range

# Generated at 2022-06-11 21:43:32.789521
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
    ll = LazyList(lst)
    for x in ll:
        pass
    assert len(ll) == len(lst)

# Generated at 2022-06-11 21:43:40.704956
# Unit test for function drop_until
def test_drop_until():
    test_list = [11,12,13,14,15,16]
    test_result = drop_until(lambda x: x > 13, test_list)
    if list(test_result) != [14,15,16]:
        raise AssertionError()
    for item in test_result:
        if (isinstance(item,int) != True):
            raise AssertionError()
    print("Test for drop_until is passed.")
test_drop_until()

# Generated at 2022-06-11 21:43:43.497897
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    x = LazyList(range(10))
    try:
        len(x)
        assert False
    except TypeError as e:
        assert str(e) == "__len__ is not available before the iterable is depleted"
    else:
        assert False

# Generated at 2022-06-11 21:43:55.788364
# Unit test for function split_by
def test_split_by():
    assert list(split_by([1, 2, 3, 0, 4, 5, 0, 6, 7, 0], criterion=lambda x: x == 0)) == [[1, 2, 3], [4, 5], [6, 7]]
    assert list(split_by([1, 2, 3, 0, 4, 5, 0, 6, 7, 0], criterion=lambda x: x == 0, empty_segments=True)) == [[1, 2, 3], [], [4, 5], [], [6, 7], []]
    assert list(split_by(" Split by: ", criterion=lambda x: x == '.', empty_segments=True)) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]

# Generated at 2022-06-11 21:44:10.762611
# Unit test for function take
def test_take():
    from random import randint
    for _ in range(100):
        n = randint(0, 100)
        actual = take(n, range(1000))
        expected = range(n)
        assert list(actual) == list(expected)



# Generated at 2022-06-11 21:44:16.159840
# Unit test for function take
def test_take():
    # Testing "take" function
    # Test 0
    assert list(take(3, [])) == [], "Failed test 0"
    # Test 1
    assert list(take(3, range(1))) == [0], "Failed test 1"
    # Test 2
    assert list(take(3, range(1, 100))) == [1, 2, 3], "Failed test 2"
    # Test 3
    assert list(take(3, range(10, 100))) == [10, 11, 12], "Failed test 3"

test_take()



# Generated at 2022-06-11 21:44:19.573553
# Unit test for function take
def test_take():
    assert list(take(0, range(100))) == []
    assert list(take(100, range(100))) == list(range(100))
    assert list(take(1000, range(100))) == list(range(100))



# Generated at 2022-06-11 21:44:26.483912
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    ## @var map_list_obj : MapList<int>
    map_list_obj = MapList(lambda x : x*x, [1,2,3,4,5])
    print (map_list_obj[1])
    print (map_list_obj[2:4])
    ## @var slice : slice
    slice = slice(1,4,2)
    print (map_list_obj[slice])
    print (map_list_obj[::2])

# Generated at 2022-06-11 21:44:32.312511
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:44:42.151242
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import builtins
    lst = list(builtins.range(5))
    m = MapList(lambda x: x + 1, lst)
    assert m[0] == 1
    assert m[1] == 2
    assert m[2] == 3
    assert m[3] == 4
    assert m[4] == 5
    assert m[-1] == 5
    assert m[-2] == 4
    assert m[-3] == 3
    assert m[-4] == 2
    assert m[-5] == 1
    assert m[:] == [1, 2, 3, 4, 5]
    assert m[:3] == [1, 2, 3]
    assert m[-3:] == [3, 4, 5]
    assert m[:-1] == [1, 2, 3, 4]


# Generated at 2022-06-11 21:44:52.550671
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1, "Item index 0 should be 1"
    assert r[2] == 3, "Item index 2 should be 3"
    assert r[4] == 5, "Item index 4 should be 5"
    try:
        r[10]
    except:
        assert True, "Index out of range"
    r = Range(1, 11, 2)
    assert r[0] == 1, "Item index 0 should be 1"
    assert r[2] == 5, "Item index 2 should be 5"
    assert r[4] == 9, "Item index 4 should be 9"
    try:
        r[5]
    except:
        assert True, "Index out of range"


# Generated at 2022-06-11 21:44:59.712298
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == list(range(5))
    assert list(take(3, [])) == []
    assert list(take(-3, [1,2,3,4])) == []
    assert list(take(0, [1,2,3,4])) == []
test_take()


# Generated at 2022-06-11 21:45:07.429871
# Unit test for function split_by
def test_split_by():
    actual = list(split_by(range(10), criterion=lambda x: x % 3 == 0))
    expected = [[1, 2], [4, 5], [7, 8]]
    assert actual == expected

    actual = list(split_by(" Split by: ", empty_segments=True, separator='.'))
    expected = [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert actual == expected

    try:
        list(split_by(range(10)))
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-11 21:45:16.483300
# Unit test for function take
def test_take():
    assert list(take(10, range(100))) == list(range(10))
    assert list(take(10, range(3))) == list(range(3))
    assert list(take(0, range(100))) == []
    assert list(take(0, [4, 5, 6])) == []
    assert list(take(1, [4, 5, 6])) == [4]
    assert list(take(5, [4, 5, 6])) == [4, 5, 6]
    return 'test_take passes'

print(test_take())



# Generated at 2022-06-11 21:46:10.572606
# Unit test for function drop_until
def test_drop_until():
    for pre, post in [([], []),
                      ([0], [0]),
                      ([0, 1, 2, 3], [3]),
                      ([0, 1, 2, 3, 4, 5], [5]),
                      ([0, 1, 2, 3, 4, 5, 6], [6]),
                      ([6, 5, 4], [6, 5, 4])]:
        it = drop_until(lambda x: x > 3, iter(pre))
        assert list(it) == post



# Generated at 2022-06-11 21:46:14.566511
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:46:19.994351
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert list(LazyList([])) == []
    assert list(LazyList([1, 2, 3])) == [1, 2, 3]
    lst = LazyList(range(1000))
    assert len(lst) == 1000
    assert lst[:100] == list(range(100))
    assert len(lst) == 1000



# Generated at 2022-06-11 21:46:31.437017
# Unit test for function drop_until
def test_drop_until():
    # Test basic functionality
    lst = [0, 1, 2, 3]
    assert list(drop_until(lambda x: x > 0, lst)) == lst[1:]
    assert list(drop_until(lambda x: x > 2, lst)) == lst[3:]
    # Test if the iterator is correct
    assert list(drop_until(lambda x: x > 0, LazyList.from_iter(lst))) == lst[1:]
    # Test empty list
    lst = []
    assert list(drop_until(lambda x: x > 0, lst)) == lst
    # Test predicate never satisfied
    lst = [0, 0, 0]
    assert list(drop_until(lambda x: x > 0, lst)) == lst[2:]
# Test the function
test_drop_

# Generated at 2022-06-11 21:46:37.106925
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    x = LazyList(range(5))
    assert x.list == []
    assert x.exhausted is False
    assert list(x) == [0, 1, 2, 3, 4]
    assert x.list == [0, 1, 2, 3, 4]
    assert x.exhausted is True
    assert list(x) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:46:44.344548
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    print("Test MapList.__getitem__")
    lst = MapList(lambda x: x * x, range(10))
    assert lst[0] == 0
    assert lst[2] == 4
    assert lst[-1] == 81
    assert lst[1:5] == [1, 4, 9, 16]
    assert list(lst) == [x * x for x in range(10)]
    print("Test passed")

test_MapList___getitem__()


# Generated at 2022-06-11 21:46:45.828019
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(10))) == 10



# Generated at 2022-06-11 21:46:54.805998
# Unit test for function drop_until
def test_drop_until():
    from collections import namedtuple

    Case = namedtuple('Case', ['name', 'data', 'fn', 'expected'])
    cases = [
        Case('all false', [1, 2, 3], lambda x: False, []),
        Case('all true', [1, 2, 3], lambda x: True, [1, 2, 3]),
        Case('1 false', [1, 2, 3], lambda x: x != 2, [2, 3]),
        Case('1 true', [1, 2, 3], lambda x: x == 2, [2]),
    ]
    for case in cases:
        assert list(drop_until(case.fn, case.data)) == case.expected

