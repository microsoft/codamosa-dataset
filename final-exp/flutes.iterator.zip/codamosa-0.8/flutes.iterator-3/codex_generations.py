

# Generated at 2022-06-11 21:37:31.596252
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:37:34.945039
# Unit test for function scanl
def test_scanl():
    """
    >>> list(scanl(operator.add, [1,2,3,4], 0))
    [0, 1, 3, 6, 10]
    >>> list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']))
    ['a', 'ba', 'cba', 'dcba']
    """


# Generated at 2022-06-11 21:37:42.136446
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3])
    assert lst[0] == 1
    assert lst[1] == 2
    assert lst[-1] == 3
    assert lst[-2] == 2
    assert lst[1:3] == [2, 3]
    assert lst[1:] == [2, 3]
    assert lst[:1] == [1]
    assert lst[1:100] == [2, 3]
    assert lst[1:1000] == [2, 3]
    assert lst[:] == [1, 2, 3]



# Generated at 2022-06-11 21:37:47.506661
# Unit test for function take
def test_take():
    take(10, []) == []
    take(10, [1, 2, 3]) == [1, 2, 3]
    take(0, [1, 2, 3]) == []
    take(3, [1, 2, 3]) == [1, 2, 3]
    take(5, [1, 2, 3]) == [1, 2, 3]
    take(1, range(1000000)) == [0]



# Generated at 2022-06-11 21:37:50.388962
# Unit test for function take
def test_take():
    L = [1, 3, 4, 5, 6]
    a = take(3, L)
    assert a == [1, 3, 4]


# Generated at 2022-06-11 21:37:53.623263
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    @overload
    def __len__(self: LazyList[T]) -> int: ...

    assert LazyList.__len__.__doc__ == LazyList.__len__.__annotations__['return'].__doc__


# Generated at 2022-06-11 21:38:05.746398
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():

    ll = LazyList(range(10))
    ll_iter = ll.__iter__()
    assert isinstance(ll_iter, LazyList.LazyListIterator)
    assert ll_iter.list() == ll
    assert ll_iter.index == 0
    iterator: LazyList.LazyListIterator = iter(ll)
    assert next(iterator) == 0
    assert iterator.index == 1
    assert next(iterator) == 1
    assert next(iterator) == 2
    assert next(iterator) == 3
    assert iterator.index == 4
    assert ll == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert ll == list(range(10))
    assert isinstance(iter(ll), LazyList.LazyListIterator)

# Generated at 2022-06-11 21:38:08.239173
# Unit test for function take
def test_take():
    it = take(5, LazyList(range(1000000)))
    assert next(it) == 0
    assert next(it) == 1

# Generated at 2022-06-11 21:38:09.734528
# Unit test for function take
def test_take():
    assert list(take(5, range(10))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:38:15.476931
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(5, range(1, 6))) == [1, 2, 3, 4, 5]
    assert list(take(5, range(1, 4))) == [1, 2, 3]



# Generated at 2022-06-11 21:38:41.261148
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7, 8, 9])) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: len(x) > 2, ['', '1', '12', '123', '1234', '12345', '123456'])) == ['123', '1234', '12345', '123456']



# Generated at 2022-06-11 21:38:46.829603
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(5, range(1))) == [0]
    assert list(take(3, range(0))) == []
    assert list(take(0, range(1))) == []
    assert list(take(0, range(0))) == []
    assert list(take(-1, range(1))) == []
    assert list(take(-1, range(0))) == []
    assert list(take(5, iter([3, 1, 4, 1, 5]))) == [3, 1, 4, 1, 5]



# Generated at 2022-06-11 21:38:49.921556
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10000000)))[:2] == [6, 7]
test_drop_until()



# Generated at 2022-06-11 21:39:00.165773
# Unit test for function chunk
def test_chunk():
    print('Testing function chunk')
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]
    assert list(chunk(0, range(10))) == ValueError
    #assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
test_chunk()


# Generated at 2022-06-11 21:39:05.817302
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(-10, 0))) == []
    assert list(drop_until(lambda x: x > -5, range(-10, 0))) == [-5, -4, -3, -2, -1]



# Generated at 2022-06-11 21:39:16.788305
# Unit test for function take
def test_take():
    assert list(take(3, range(10))) == [0, 1, 2]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(0, range(10))) == []
    assert list(take(10, [])) == []
    assert list(take(3, "12345")) == ["1", "2", "3"]
    assert list(take(10, "12345")) == list("12345")
    assert list(take(0, "12345")) == []
    assert list(take(10, "")) == []
    assert list(take(3, {1, 2, 3, 4, 5})) == [1, 2, 3]

# Generated at 2022-06-11 21:39:24.426432
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []
    with pytest.raises(ValueError):
        list(drop_until(lambda x: x > 5, range(-10,1)))
    with pytest.raises(TypeError):
        list(drop_until(lambda x: x > 5, [1,2,3]))

test_drop_until()



# Generated at 2022-06-11 21:39:36.925835
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(7))) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunk(3, range(6))) == [[0, 1, 2], [3, 4, 5]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(3, range(4))) == [[0, 1, 2], [3]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(1))) == [[0]]
    assert list(chunk(3, range(0))) == []

# Generated at 2022-06-11 21:39:47.514611
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, range(5))) == [[x] for x in range(5)]
    assert list(chunk(2, range(5))) == [[0, 1], [2, 3], [4]]
    assert list(chunk(3, range(5))) == [[0, 1, 2], [3, 4]]
    assert list(chunk(4, range(5))) == [[0, 1, 2, 3], [4]]
    assert list(chunk(5, range(5))) == [[0, 1, 2, 3, 4]]
    assert list(chunk(6, range(5))) == [[0, 1, 2, 3, 4]]



# Generated at 2022-06-11 21:39:53.897472
# Unit test for function take
def test_take():
    assert [x for x in take(-1, [])] == []
    assert [x for x in take(0, [])] == []
    assert [x for x in take(1, [])] == []

    assert [x for x in take(1, range(1))] == [0]
    assert [x for x in take(2, range(1))] == [0]
    assert [x for x in take(3, range(1))] == [0]

    assert [x for x in take(1, range(2))] == [0]
    assert [x for x in take(2, range(2))] == [0, 1]
    assert [x for x in take(3, range(2))] == [0, 1]


# Generated at 2022-06-11 21:40:14.681656
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert list(MapList(lambda x: x * 2, [1, 2, 3, 4])) == [2, 4, 6, 8]


# Generated at 2022-06-11 21:40:20.528863
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    l = LazyList(range(15))
    # let's check if the list is truncated correctly
    assert len(l) == 15
    assert len(l) == 15 # the second time should be fast
    # let's check if the list is shortened correctly
    assert len(l[:6]) == 6
    assert len(l[1:6]) == 5
    assert len(l[6:]) == 9

# Generated at 2022-06-11 21:40:30.510661
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    '''
    Test __getitem__ method of class Range
    '''
    test_list = [1,2,3,4,5]
    test_range = Range(1, 6, 1)
    assert test_list[1:] == test_range.__getitem__(slice(1, None, None))
    assert test_list[:2] == test_range.__getitem__(slice(None, 2, None))
    assert test_list[:] == test_range.__getitem__(slice(None, None, None))
    assert test_list[::2] == test_range.__getitem__(slice(None, None, 2))
    assert test_list[::-1] == test_range.__getitem__(slice(None, None, -1))
    return True

# Generated at 2022-06-11 21:40:36.150959
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, [1,2,3])) == [[1], [2], [3]]
    assert list(chunk(2, [1,2,3,4,5])) == [[1,2],[3,4],[5]]
    assert list(chunk(3, [1,2,3,4,5,6,7])) == [[1,2,3],[4,5,6],[7]]



# Generated at 2022-06-11 21:40:46.690494
# Unit test for function chunk
def test_chunk():
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]
    assert list(chunk(3, [1])) == [[1]]
    assert list(chunk(3, [1, 2])) == [[1, 2]]
    assert list(chunk(3, [1, 2, 3])) == [[1, 2, 3]]
    assert list(chunk(3, [1, 2, 3, 4])) == [[1, 2, 3], [4]]
    assert list(chunk(3, [1, 2, 3, 4, 5])) == [[1, 2, 3], [4, 5]]

# Generated at 2022-06-11 21:40:54.945580
# Unit test for function chunk
def test_chunk():
    assert list(chunk(1, range(1))) == [[0]]
    assert list(chunk(2, range(2))) == [[0, 1]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(1, range(0))) == []
    assert list(chunk(2, range(1))) == [[0]]
    assert list(chunk(2, range(2))) == [[0, 1]]
    assert list(chunk(2, range(3))) == [[0, 1], [2]]
    assert list(chunk(3, range(3))) == [[0, 1, 2]]
    assert list(chunk(4, range(4))) == [[0, 1, 2, 3]]

# Generated at 2022-06-11 21:40:57.761245
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    a=Range(0, 11, 2)
    print(a[0])
    print(a[2])
    print(a[4])



# Generated at 2022-06-11 21:41:08.689946
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import random
    import itertools
    r = random.Random(0)
    for max_i in range(1, 1000):
        for start in range(1000):
            for _ in range(10):
                l = Range(0, max_i)
                # Break up i into chunks and use these chunks to slice l
                i = r.randint(0, max_i - 1)
                chunks = [i]
                while (chunks[-1] > 0):
                    chunks.append(r.randint(0, chunks[-1]))
                assert l[i] == list(l)[i]
                assert len(l[i:i + 1]) == 1
                assert l[i:i + 1][0] == list(l)[i]
                assert l[i:i] == []

# Generated at 2022-06-11 21:41:11.554053
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(10)).__iter__()) == list(range(10))

# Generated at 2022-06-11 21:41:15.492789
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    s = LazyList(range(100000))
    assert s[0] == 0
    assert s[-1] == 99999
    assert len(s[3:]) == 99997
    assert s[-1] == 99999
    assert len(s[:]) == 100000
    assert s[-1] == 99999


# Generated at 2022-06-11 21:42:22.120958
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    l = MapList(lambda x: x * 3, [1, 2, 3, 4, 5, 6])
    assert l[1] == 6 and l[3] == 12 and l[5] == 18
    assert l[0:3] == [3, 6, 9] and l[3:6] == [12, 15, 18]
    assert l[0:6:2] == [3, 9, 15]
    assert l[::-1] == [18, 15, 12, 9, 6, 3]

# Generated at 2022-06-11 21:42:23.146872
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a = LazyList(range(1000000))
    assert len(a) == 1000000

# Generated at 2022-06-11 21:42:31.212973
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    class TestIterable(Iterable):
        def __iter__(self):
            yield 1
            yield 2
            yield 3
            yield 4
            yield 5

    for l in [LazyList(range(10)), LazyList(TestIterable())]:
        assert list(l) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        assert list(l) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]  # the iterable was depleted, so the second time
        assert list(l) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]  # the iterable was depleted, so the second time

# Generated at 2022-06-11 21:42:38.926200
# Unit test for function split_by
def test_split_by():
    assert list(split_by('Split by: ', separator=' ')) == [['Split'], ['by:']]
    assert list(split_by('Split by: ', empty_segments=True, separator=' ')) == [[], ['Split'], ['by:'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) \
        == [[], [1, 2], [], [4, 5], [], [7, 8], []]



# Generated at 2022-06-11 21:42:49.510171
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    @package.itertools.counted
    def f():
        yield 1
        yield 2
        yield 3
    lst = package.LazyList(f())
    with pytest.raises(TypeError, match="__len__ is not available"):
        len(lst)
    lst[2]
    with pytest.raises(TypeError, match="__len__ is not available"):
        len(lst)
    lst[3]
    len(lst)  # should work now
    with pytest.raises(TypeError, match="__len__ is not available"):
        len(lst)
    lst[5]
    len(lst)  # should work now
    # The final length of the list is not necessarily predictable, since the list is lazy and we don't know when
   

# Generated at 2022-06-11 21:42:53.195848
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList([1, 2, 3, 4])
    assert len(lst) == 4
    lst = LazyList(range(100))
    assert len(lst) == 100



# Generated at 2022-06-11 21:42:57.335166
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    it = iter(lst)
    assert next(it) == 0
    assert next(it) == 1

    lst = LazyList(range(10))
    it = iter(lst)
    assert next(it) == 0
    assert list(it) == list(range(1, 10))


# Generated at 2022-06-11 21:43:04.279587
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    # test_1
    l = LazyList(range(10))
    l2 = list(iter(l))
    assert l2 == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    # test_2
    l = LazyList(range(10))
    l2 = list(iter(l))
    assert l2 == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:43:05.777046
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    pass



# Generated at 2022-06-11 21:43:14.826924
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert LazyList(list(range(4)))[2] == 2
    assert LazyList(list(range(4)))[777] == 3
    assert LazyList(list(range(4)))[10] == 3
    assert LazyList(list(range(4)))[-1] == 3
    assert LazyList(list(range(4)))[-2] == 2
    assert LazyList(list(range(4)))[-3] == 1
    assert LazyList(list(range(4)))[-4] == 0
    assert LazyList(list(range(4)))[-5] == -1

    assert LazyList(list(range(4)))[1:2] == [1]
    assert LazyList(list(range(4)))[-7:-5] == [0, 1]


# Generated at 2022-06-11 21:43:51.908927
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    __tracebackhide__ = True
    lst = LazyList(range(100))
    assert list(lst) == list(range(100))

# Generated at 2022-06-11 21:43:59.049485
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(10)[0] == 0
    assert Range(10)[2] == 2
    assert Range(10)[-1] == 9
    assert Range(10)[::-1][0] == 9
    assert [(x,y) for (x,y) in Range(10)[::-1]] == [(5,5),(6,4),(7,3),(8,2),(9,1),(9,0)]
    assert Range(10)[3:8][0] == 3
    assert Range(10)[3:8][4] == 7
    assert Range(10)[3:8][-1] == 7
    assert Range(10)[3:8][::-1][4] == 3

# Generated at 2022-06-11 21:44:10.538965
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Test if the method can handle slice object as argument
    r = Range(1, 9)
    assert r[:4] == [1, 2, 3, 4]
    # Test if the method can handle negative index as argument
    assert r[-1] == 8
    # Test if the method can handle invalid index as argument
    try:
        r[-10]
        assert False, "Should throw IndexError"
    except IndexError:
        pass
    try:
        r[10]
        assert False, "Should throw IndexError"
    except IndexError:
        pass
    # Test if the method behaves like range() when the argument is slice object
    r = Range(1)
    assert r[:] == [1, 2, 3]
    r = Range(1, 10)

# Generated at 2022-06-11 21:44:13.132869
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(4))
    for x, y in zip(lst, range(4)):
        assert x == y
    assert list(lst) == list(range(4))

# Generated at 2022-06-11 21:44:21.253516
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    x = LazyList(i for i in range(4))
    assert len(x) == 4
    assert (x[0], x[1], x[2], x[3]) == (0, 1, 2, 3)
    y = LazyList(range(4))
    assert len(y) == 4
    assert (y[0], y[1], y[2], y[3]) == (0, 1, 2, 3)
    z = LazyList([0, 1, 2, 3])
    assert len(z) == 4
    assert (z[0], z[1], z[2], z[3]) == (0, 1, 2, 3)



# Generated at 2022-06-11 21:44:25.988417
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']


# Generated at 2022-06-11 21:44:31.651385
# Unit test for function split_by
def test_split_by():
    list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]


# Generated at 2022-06-11 21:44:41.752176
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[1] == 1
    assert r[9] == 9
    assert r[-1] == 9
    try:
        r[10]
        assert False, "IndexError is supposed to be thrown"
    except IndexError:
        pass
    try:
        r[-11]
        assert False, "IndexError is supposed to be thrown"
    except IndexError:
        pass

    r = Range(10, 20)
    assert r[0] == 10
    assert r[1] == 11
    assert r[9] == 19
    assert r[-1] == 19
    try:
        r[10]
        assert False, "IndexError is supposed to be thrown"
    except IndexError:
        pass

# Generated at 2022-06-11 21:44:48.534211
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(4, range(3))) == [[0, 1, 2]]
    assert list(chunk(0, range(10))) == ValueError


# Generated at 2022-06-11 21:44:53.580146
# Unit test for function drop_until
def test_drop_until():
    assert [2, 3, 4, 5, 6] == list(drop_until(lambda x: x > 1, range(10)))
    assert [] == list(drop_until(lambda x: x > 0, []))
    assert [2] == list(drop_until(lambda x: x > 1, [1, 2]))
    assert [1, 2] == list(drop_until(lambda x: x > 0, [1, 2]))

