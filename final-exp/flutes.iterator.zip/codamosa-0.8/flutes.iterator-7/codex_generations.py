

# Generated at 2022-06-11 21:37:47.421179
# Unit test for function drop
def test_drop():
    print("Testing test_drop")
    assert list(drop(5, range(1000000))) == list(*range(5,1000000))
    try:
        assert list(drop(-5, range(1000000)))
    except ValueError as err:
        print(err)
    assert list(drop(0, range(1000000))) == list(range(0,1000000))
    assert list(drop(65535, range(1000000))) == list(range(65535,1000000))
    print("Done testing test_drop")


# Generated at 2022-06-11 21:37:56.378193
# Unit test for function chunk
def test_chunk():
    assert list(chunk(0, range(10))) == []
    assert list(chunk(1, range(10))) == [[i] for i in range(10)]
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(10, range(10))) == [[i for i in range(10)]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(4, range(10))) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]

# Generated at 2022-06-11 21:38:06.689836
# Unit test for function chunk
def test_chunk():
    assert list(chunk(2, range(10))) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1000, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(0, range(10))) == []
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    assert list(chunk(10, [])) == []

# Generated at 2022-06-11 21:38:13.816950
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert list(Range(10)[2:5]) == list(range(2, 6))
    assert list(Range(0, 10)[3:5]) == list(range(3, 6))
    assert list(Range(1, 10 + 1)[4:7]) == list(range(5, 8))
    assert list(Range(1, 11)[4:7]) == list(range(5, 8))
    assert list(Range(1, 11, 2)[4:7]) == list(range(5, 8, 2))
    assert list(Range(-1, -11, -1)[4:7]) == list(range(-6, -9, -1))
    assert Range(10)[2] == 2
    assert Range(0, 10)[3] == 3
    assert Range(1, 10 + 1)[4] == 5

# Generated at 2022-06-11 21:38:23.085775
# Unit test for function scanl
def test_scanl():
    assert list(scanl(lambda x, y: x + y, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, [])) == []
    with pytest.raises(StopIteration):
        next(scanl(lambda s, x: x + s, []))
    assert list(scanl(lambda s, x: x + s, [1])) == [1]
    assert list(scanl(lambda s, x: x + s, [], 0)) == [0]

# Generated at 2022-06-11 21:38:28.442078
# Unit test for function take
def test_take():
    assert list(take(0, range(10))) == []
    assert list(take(2, range(10))) == [0, 1]
    assert list(take(10, range(10))) == list(range(10))
    assert list(take(20, range(10))) == list(range(10))



# Generated at 2022-06-11 21:38:37.205682
# Unit test for function take
def test_take():
    assert list(take(1, range(1000000))) == [0]
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(0, range(1000000))) == []
    assert list(take(1000000, range(1000000))) == list(range(1000000))
    assert list(take(1, "ab")) == ["a"]
    assert list(take(2, "ab")) == ["a", "b"]
    assert list(take(0, "ab")) == []
    assert list(take(2, "a")) == ["a"]
    assert list(take(1, [])) == []
    assert list(take(0, [])) == []
    assert list(take(1, (1,))) == [1]
    # test 0
    assert list

# Generated at 2022-06-11 21:38:48.189526
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(10))
    assert type(ll[0]) is int # Test that the element is retrieved lazily.
    assert type(ll[-1]) is int # Test indexing from the end.
    assert list(ll[:4]) == [0, 1, 2, 3] # Test slicing.
    assert list(ll[:-1]) == [0, 1, 2, 3, 4, 5, 6, 7, 8] # Test slicing from the end.
    assert list(ll) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] # Test iterating.
    assert ll[4:4] == [] # Test getting an empty slice.
    assert list(ll[-13:13]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-11 21:38:54.958900
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x % 3 == 0, (1, 2, 3, 4, 5, 6))) == [3, 4, 5, 6]


# Generated at 2022-06-11 21:38:56.489136
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:39:25.870828
# Unit test for function take
def test_take():
    assert list(take(0, "abcd")) == []
    assert list(take(2, "abcd")) == ["a", "b"]
    assert list(take(100, "abcd")) == ["a", "b", "c", "d"]
    with pytest.raises(ValueError):
        list(take(-1, "abcd"))



# Generated at 2022-06-11 21:39:36.675120
# Unit test for function chunk
def test_chunk():
    expected = [[0, 1], [2, 3], [4, 5], [6], [7], [8], [9]]

    actual = list(chunk(2, range(10)))
    assert actual == expected

    actual = list(chunk(2, take(10, range(1000))))
    assert actual == expected

    actual = list(chunk(7, range(10)))
    assert actual == [[0, 1, 2, 3, 4, 5, 6], [7, 8, 9]]

    try:
        chunk(-1, [])
        assert False
    except ValueError:
        pass
    try:
        chunk(0, [])
        assert False
    except ValueError:
        pass



# Generated at 2022-06-11 21:39:42.022290
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(1, range(10))) == list(range(1,10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []



# Generated at 2022-06-11 21:39:50.013293
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    with pytest.raises(ValueError):
        list(drop(-1, range(10)))
    with pytest.raises(StopIteration):
        list(drop(5, range(5)))
    with pytest.raises(StopIteration):
        list(drop(6, range(5)))



# Generated at 2022-06-11 21:39:55.190854
# Unit test for function drop
def test_drop():
    assert ([i for i in drop(3,range(5))] == [3,4])
    assert ([i for i in drop(0,range(5))] == [0,1,2,3,4])
    assert ([i for i in drop(5,range(5))] == [])
    try:
        drop(-5, range(5))
        assert False
    except:
        assert True



# Generated at 2022-06-11 21:39:57.226993
# Unit test for function drop
def test_drop():
    assert list(drop(50, range(100))) == [i for i in range(50, 100)]



# Generated at 2022-06-11 21:40:02.924660
# Unit test for function take
def test_take():
    assert list(take(3, (1, 2, 3, 4, 5))) == [1, 2, 3]
    assert list(take(3, (1,))) == [1]
    assert list(take(3, ())) == []
    assert list(take(0, (1, 2, 3, 4, 5))) == []
    assert list(take(0, ())) == []


# Generated at 2022-06-11 21:40:12.527159
# Unit test for function split_by
def test_split_by():
    assert(list(split_by(range(10), criterion=lambda x: x % 3 == 0))
           == [[1, 2], [4, 5], [7, 8]])
    assert(list(split_by(" Split by: ", empty_segments=True, separator='.'))
           == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []])
    assert(list(split_by(range(10), criterion=lambda x: x % 3 == 0))
           == [[1, 2], [4, 5], [7, 8]])



# Generated at 2022-06-11 21:40:22.655259
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    def test(a,b,c,d,e,f,g,h,i,j,k):
        '''
        >>> test(1,2,3,4,5,6,7,8,9,10,11)
        '''
        l = LazyList(iter([a,b,c,d,e,f,g,h,i,j,k]))
        assert l[-5:] == [f,g,h,i,j]
        assert l[-11:] == [a,b,c,d,e,f,g,h,i,j]
        assert l[-15:] == [a,b,c,d,e,f,g,h,i,j]
        assert l[-5:] == [f,g,h,i,j]

# Generated at 2022-06-11 21:40:25.481256
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    it = LazyList(range(100))
    xs = list(it)
    assert len(xs) == 100
    assert len(xs) == len(it)



# Generated at 2022-06-11 21:40:48.577723
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(5), criterion=lambda x: x % 2 == 0)) == [[1], [3]]
    assert list(split_by(range(5), criterion=lambda x: x % 2 == 0, empty_segments=True)) == [[1], [3], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0, empty_segments=True)) == [[1, 2], [], [4, 5], [], [7, 8]]

# Generated at 2022-06-11 21:40:52.401686
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    self = LazyList([])
    self.exhausted = True
    self.list = []
    self_result = self.__len__()
    assert isinstance(self_result, int)
    assert self_result == 0


# Generated at 2022-06-11 21:41:03.644617
# Unit test for function split_by
def test_split_by():
    # Require that the type checker can infer the type of empty_segments
    assert isinstance(split_by("abcdefg", criterion=lambda x: x == 'g', empty_segments=True), Iterator[List[str]])
    assert list(split_by("abcdefg", criterion=lambda x: x == 'g', empty_segments=True)) == [['a', 'b', 'c', 'd', 'e', 'f'], []]
    assert list(split_by("abcdefg", criterion=lambda x: x == 'g', empty_segments=False)) == [['a', 'b', 'c', 'd', 'e', 'f']]

# Generated at 2022-06-11 21:41:07.520137
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[6] == 7
    assert r[8] == 9

# Generated at 2022-06-11 21:41:11.609916
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    test_output = ['a', 'b', 'c']
    test_object = LazyList(test_output)
    assert list(test_object) == test_output
    # Test iterating over the same LazyList multiple times
    assert list(test_object) == test_output


# Generated at 2022-06-11 21:41:16.746731
# Unit test for function take
def test_take():
    import numpy as np
    n = np.random.randint(1, 100)
    xs = np.random.rand(n)
    assert np.all(list(take(n, xs)) == xs)
    assert np.all(list(take(n - 1, xs)) == xs[:-1])
    assert np.all(list(take(1, xs)) == xs[:1])
    assert list(take(0, xs)) == []
    assert list(take(1, [])) == []



# Generated at 2022-06-11 21:41:22.319578
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()


# Generated at 2022-06-11 21:41:27.771685
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    tests = [
        ([0, 1, 2], [0, 1, 2]),
        ([0, 0, 1, 2], [0, 1, 2]),
        ([1, 2], [1, 2]),
        ([], []),
    ]
    for case, expected in tests:
        lst = LazyList(case)
        result = list(lst)
        assert result == expected
        assert lst.list == result


# Generated at 2022-06-11 21:41:38.414507
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for i in range(1,4):
        for j in range(1,4):
            for k in range(1,4):
                for l in range(-4,4):
                    for m in range(-4,4):
                        for n in range(-4, 4):
                            for o in range(-4,4) :
                                if i + j <= k:
                                    continue
                                if l < m and l + n <= m + o and l + n <= k:
                                    continue
                                if l >= m and l + n >= m + o and l + n >= 0:
                                    continue
                                if l >= m and l + n >= 0 and l + n >= m + o:
                                    continue
                                if l < m and l + n <= k and l + n <= m + o:
                                    continue
                               

# Generated at 2022-06-11 21:41:46.648895
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import bisect
    a = [1, 2, 3, 4, 5]
    pos1 = bisect.bisect_left(MapList(lambda x: x * x, a), 10)
    pos2 = bisect.bisect_left(MapList(lambda i: a[i] * b[i], Range(len(a))), 10)
    b = [2, 3, 4, 5, 6]
    assert(pos1 == 3)
    assert(pos2 == 2)
    return

test_MapList___getitem__()

# Generated at 2022-06-11 21:42:07.197792
# Unit test for function take
def test_take():
    r"""Test for function take.

    .. code:: python

        >>> l1 = [i for i in range(5)]
        >>> l2 = [i for i in range(3)]
        >>> print(list(take(5, l1)) == l1)
        True
        >>> print(list(take(3, l1)) == l2 + [0] * 2)
        True
        >>> print(list(take(0, l1)) == [])
        True
        >>> print(list(take(-1, l1)) == [])
        ValueError: `n` should be non-negative
    """
    l1 = [i for i in range(5)]
    l2 = [i for i in range(3)]
    assert list(take(5, l1)) == l1

# Generated at 2022-06-11 21:42:12.974925
# Unit test for function drop
def test_drop():
    import random
    for _ in range(100):
        n = random.randint(0, 100)
        iterable = list(range(n))
        result = list(drop(n, iterable))
        assert result == []
        for i in range(n):
            result = list(drop(i, iterable))
            assert result == iterable[i:]



# Generated at 2022-06-11 21:42:17.557071
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    it = iter(lst)
    assert list(it) == list(range(10))
    assert lst.exhausted is True


# Generated at 2022-06-11 21:42:19.404063
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert list(iter(lst)) == list(lst)

# Generated at 2022-06-11 21:42:30.204759
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import operator
    import random
    import string
    import sys

    if sys.version_info < (3,5):
        for _ in range(10):
            l = list(range(random.randint(50, 70)))
            ll = LazyList(l)
            idx = random.randint(0, len(l))
            assert l[:idx] == ll[:idx]
            idx = random.randint(0, len(l))
            assert l[-idx:] == ll[-idx:]
            idx = random.randint(0, len(l))
            assert l[idx:idx + random.randint(10, 15)] == ll[idx:idx + random.randint(10, 15)]
            assert ll[5] == l[5]
            assert ll

# Generated at 2022-06-11 21:42:33.188597
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(10))
    assert list(ll) == range(10)



# Generated at 2022-06-11 21:42:40.682084
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    import operator
    assert Range(10) == list(range(10))
    assert Range(3, 10) == list(range(3, 10))
    assert Range(1, 11, 2) == list(range(1, 11, 2))
    r = Range(10)
    assert [r[i] for i in range(10)] == list(range(10))
    r = Range(3, 10)
    assert [r[i] for i in range(3, 10)] == list(range(3, 10))
    r = Range(1, 11, 2)
    assert [r[i] for i in range(1, 11, 2)] == list(range(1, 11, 2))
    r = Range(10)
    assert r[0:10:1] == list(range(10))

# Generated at 2022-06-11 21:42:44.909773
# Unit test for function take
def test_take():
    assert list(take(5, tuple('abcdefghijklmnopqrstuvwxyz')))==['a', 'b', 'c', 'd', 'e']
    assert list(take(-1, tuple('abcde')))==[]


# Generated at 2022-06-11 21:42:48.914005
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    ll = LazyList(range(2))
    assert iter(ll) is iter(ll)  # check if the same iterator is returned

    assert not ll.exhausted
    assert list(ll) == [0, 1]
    assert list(ll) == [0, 1]
    assert ll.exhausted


# Generated at 2022-06-11 21:42:55.369723
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst1 = LazyList([1, 2, 3, 4, 5])
    assert lst1[:2] == [1, 2]
    assert lst1[1] == 2
    assert lst1[:2] == [1, 2]
    assert lst1[2:] == [3, 4, 5]
    assert lst1[:2] == [1, 2]
    assert lst1[:] == [1, 2, 3, 4, 5]



# Generated at 2022-06-11 21:43:11.438402
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(0, range(10))) == list(range(10))



# Generated at 2022-06-11 21:43:21.271165
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    import random
    import string

    SEED = 42
    random.seed(SEED)
    N = 10000
    ITER_COUNT = 10

    lst = LazyList(random.choices(string.ascii_letters, k=N))

    for _ in range(ITER_COUNT):
        index_list = list(random.sample(range(N), k=N // 4))

        for index in index_list:
            char = lst[index]
            assert char == random.choices(string.ascii_letters, k=1)[0]

    assert len(lst) == N

    for index, char in enumerate(lst):
        assert char == random.choices(string.ascii_letters, k=1)[0]


# Generated at 2022-06-11 21:43:23.823379
# Unit test for function chunk
def test_chunk():
    import doctest
    doctest.testmod()
    print("All tests passed!")
# test_chunk()


# Generated at 2022-06-11 21:43:29.408010
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(range(10), empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[1, 2], [], [4, 5], [],
                                                                                              [7, 8], []]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'],
                                                                                 ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:43:40.804150
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    a = Range(2, 7)
    for i in range(5):
        assert(a[i] == 2+i)
    for i in range(4):
        assert(a[-(i+1)] == 6-i)
    assert(a[-5] == 2)

    b = Range(3, 10, 2)
    assert(b[1] == 5)
    assert(b[-2] == 7)
    assert(b[2:5] == [7, 9])
    assert(b[:2] == [3, 5])
    assert(b[::2] == [3, 7])
    assert(b[:-1] == [3, 5, 7])



# Generated at 2022-06-11 21:43:43.028403
# Unit test for function take
def test_take():
    x_take = take(5, range(10))
    assert list(x_take) == [0,1,2,3,4]
test_take()



# Generated at 2022-06-11 21:43:55.558736
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert lst[-1] == 10, "TypeError: __getitem__"
    assert lst[9] == 10, "TypeError: __getitem__"
    assert lst[0] == 1, "TypeError: __getitem__"
    assert lst[7] == 8, "TypeError: __getitem__"
    assert lst[-5] == 6, "TypeError: __getitem__"
    assert lst[4] == 5, "TypeError: __getitem__"
    assert lst[3] == 4, "TypeError: __getitem__"
    assert lst[2] == 3, "TypeError: __getitem__"

# Generated at 2022-06-11 21:43:58.665437
# Unit test for function take
def test_take():
    it = take(10, range(100))
    assert list(it) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:44:10.421698
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(5), criterion=lambda x: x == 2)) == [[0, 1], [3, 4]]
    assert list(split_by(range(5), criterion=lambda x: x == 2, empty_segments=True)) == [[], [0, 1], [3, 4]]
    assert list(split_by(range(5), criterion=lambda x: x == 5)) == [[0, 1, 2, 3, 4]]
    assert list(split_by(range(5), criterion=lambda x: x == 5, empty_segments=True)) == [[0, 1, 2, 3, 4], []]
    assert list(split_by(range(5), criterion=lambda x: x % 2 == 0)) == [[1], [3]]


# Generated at 2022-06-11 21:44:17.451623
# Unit test for function split_by
def test_split_by():
    class TestObject:
        def __init__(self, x: int):
            self.x = x

        def __eq__(self, other):
            return self.x == other.x

        def __hash__(self):
            return hash(self.x)

        def __repr__(self):
            return f"TestObject({self.x})"

    def test(split_fn, reference):
        for chunk in split_fn:
            assert isinstance(chunk, list)
            for item in chunk:
                assert isinstance(item, TestObject)

        assert list(split_fn) == reference

    test1 = list(map(TestObject, range(10)))
    test2 = list(map(TestObject, [0, 3, 3, 5, 0, 1, 2, 3, 0, 1]))

   

# Generated at 2022-06-11 21:45:45.524857
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():

    lst = LazyList([])
    assert lst[0] == 0
    assert lst[1] == 1
    assert lst[2] == 2
    assert lst[3] == 3
    assert lst[4] == 4
    assert lst[5] == 5
    assert lst[6] == 6
    assert lst[7] == 7
    assert lst[8] == 8
    assert lst[9] == 9

# Generated at 2022-06-11 21:45:50.176130
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r1 = Range(1, 11, 2)
    assert r1[0] == 1
    assert r1[-1] == 9
    assert r1[5] == 9
    assert r1[7] == IndexError
    assert r1[0:-1] == [1, 3, 5, 7, 9]


# Generated at 2022-06-11 21:45:51.754723
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert [0,2,4] == Range(0,10,2)[0:3]



# Generated at 2022-06-11 21:46:02.716197
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    def func(x: int) -> int: return x * x
    lst = [1, 2, 3, 4, 5]
    m = MapList(func, lst)
    assert(m[0]==func(lst[0]))
    assert(m[1]==func(lst[1]))
    assert(m[2]==func(lst[2]))
    assert(m[3]==func(lst[3]))
    assert(m[4]==func(lst[4]))
    assert([x for x in m] == [x*x for x in lst])
    assert(m[:] == [x*x for x in lst])
    assert(m[1:3] == [x*x for x in lst[1:3]])

test_MapList

# Generated at 2022-06-11 21:46:14.367126
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    import operator
    import functools
    import random

    i = range(1000000)  # an endless iterator
    lst = LazyList(i)

    assert isinstance(lst[50], int)
    assert isinstance(lst[50:100], list)

    # test that LazyList is a sequence
    assert lst[50] == 50
    assert lst[50:100] == list(range(50, 100))

    # test that LazyList is lazy.
    assert all(lst[i] == i for i in range(1000))
    if not functools.reduce(operator.eq, [random.randint(0, 99999) == lst[i] for _ in range(10000)], True):
        assert False



# Generated at 2022-06-11 21:46:20.137987
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
#    for i in range ( 0, max_length+1 ):
    for i in range ( 0, random_length+1 ):
        a = LazyList( [1,2,3] )
        t_len = len(a)
    pass

    print ( "Method __len__ of class LazyList is OK" )
# End of test method __len__ of class LazyList



# Generated at 2022-06-11 21:46:31.569609
# Unit test for method __getitem__ of class Range

# Generated at 2022-06-11 21:46:36.891189
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    # Test variable initialization
    pass


# Generated at 2022-06-11 21:46:42.721041
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    print('\nTesting function Range.__getitem__')
    r = Range(1, 11, 2)
    assert r[0] == 1, "Wrong result"
    assert r[2] == 5, "Wrong result"
    assert r[4] == 9, "Wrong result"


# Generated at 2022-06-11 21:46:44.491263
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    x = LazyList(range(10))
    assert list(x) == list(range(10))
