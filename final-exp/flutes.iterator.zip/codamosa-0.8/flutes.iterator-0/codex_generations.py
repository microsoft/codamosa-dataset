

# Generated at 2022-06-11 21:37:19.160237
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-11 21:37:26.440397
# Unit test for function take
def test_take():
    assert list(take(10, range(1000000))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(take(10, Range(1, 1000000))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(take(0, range(1000000))) == []
    assert list(take(-1, range(1000000))) == []



# Generated at 2022-06-11 21:37:30.479818
# Unit test for function drop_until
def test_drop_until():
    assert [4, 5, 6] == list(drop_until(lambda x: x > 3, [0, 1, 2, 3, 4, 5, 6]))
    assert [] == list(drop_until(lambda x: x > 10, []))



# Generated at 2022-06-11 21:37:35.241941
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(10))
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert lst[5:] == [5, 6, 7, 8, 9]
    assert lst[:] == list(range(10))
    it = iter(lst)
    assert next(it) == 0
    assert next(it) == 1
    assert lst[:5] == [0, 1, 2, 3, 4]
    assert next(it) == 2

# Generated at 2022-06-11 21:37:38.857413
# Unit test for function split_by
def test_split_by():
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]



# Generated at 2022-06-11 21:37:49.324122
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    ### Example 1
    print('Example 1')
    r = Range(5)
    print(r[1:5:2])
    ### Example 2
    print('Example 2')
    r = Range(10)
    print(r[:5:2])
    ### Example 3
    print('Example 3')
    r = Range(10)
    print(r[:])
    ### Example 4
    print('Example 4')
    r = Range(10)
    print(r[1:5:2])
    ### Example 5
    print('Example 5')
    r = Range(1, 10)
    print(r[:5:2])
    ### Example 6
    print('Example 6')
    r = Range(1, 10)
    print(r[:])
    ### Example 7
    print('Example 7')
   

# Generated at 2022-06-11 21:37:59.435825
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    mplst = MapList(lambda x: x * x, lst)
    assert lst[3] == 4
    assert mplst[3] == 16
    assert list(mplst) == [x * x for x in lst]
    assert mplst[:] == [x * x for x in lst]
    assert mplst[1:4] == [x * x for x in lst[1:4]]
    assert mplst[::2] == [x * x for x in lst[::2]]
    assert mplst[3:None:2] == [x * x for x in lst[3:None:2]]

# Generated at 2022-06-11 21:38:03.879789
# Unit test for function split_by
def test_split_by():
    assert list(split_by('Split by:', separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]
    assert list(split_by('Split by:', empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]



# Generated at 2022-06-11 21:38:16.099446
# Unit test for method __next__ of class Range
def test_Range___next__():
    assert next(iter(Range(0))) == 0
    assert next(iter(Range(0))) == 0
    r = Range(0)
    assert next(r) == 0
    assert next(r) == 0
    r = Range(3)
    assert next(r) == 0
    assert next(r) == 1
    assert next(r) == 2
    with pytest.raises(StopIteration):
        next(r)
    r = Range(2, 3)
    assert next(r) == 2
    with pytest.raises(StopIteration):
        next(r)
    r = Range(1, 10, 2)
    assert next(r) == 1
    assert next(r) == 3
    assert next(r) == 5
    assert next(r) == 7

# Generated at 2022-06-11 21:38:23.925646
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(7, [])) == []
    assert list(chunk(0, range(10))) == []
    try:
        list(chunk(-1, range(10)))
        assert False
    except ValueError:
        pass
    assert list(chunk(1, range(10))) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    assert list(chunk(10, range(10))) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]



# Generated at 2022-06-11 21:38:34.655491
# Unit test for function scanl
def test_scanl():
    assert [1,3,6,10] == list(scanl(operator.add, [1, 2, 3, 4], 0))
    assert ['a', 'ba', 'cba', 'dcba'] == list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd']))

# Generated at 2022-06-11 21:38:41.854750
# Unit test for method __next__ of class Range
def test_Range___next__():
    ok_(True)
    r = Range(10)
    for i in range(10):
        eq_(i, next(r))
    ok_(True)
    r = Range(1, 10 + 1)
    for i in range(10):
        eq_(i + 1, next(r))
    ok_(True)
    r = Range(1, 11, 2)
    for i in range(5):
        eq_(2 * i + 1, next(r))


# Generated at 2022-06-11 21:38:44.875058
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(3))
    res = []
    for x in lst:
        res.append(x)
    assert res == [0, 1, 2]



# Generated at 2022-06-11 21:38:49.387560
# Unit test for method __next__ of class Range
def test_Range___next__():
    class State0(object):
        def __init__(self):
            self.val = 1
            self.length = 5
            self.l = 0
            self.r = 6
            self.step = 1
    state0 = State0()
    r0 = Range(0, 6, 1)
    for _ in range(5):
        next(r0)
    pass

    # Asserts: AssertionError: 1 != 6


# Generated at 2022-06-11 21:39:01.553222
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(0,10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(3, range(0,8))) == [[0, 1, 2], [3, 4, 5], [6, 7]]
    assert list(chunk(2, range(0,8))) == [[0, 1], [2, 3], [4, 5], [6, 7]]


# def take(n: int, iterable: Iterable[T]) -> Iterator[T]:
#     r"""Take the first ``n`` elements from the ``iterable``.
# 


# Generated at 2022-06-11 21:39:09.379102
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    v = Range(0, 5, 2)
    if v[0] != 0:
        raise AssertionError()
    if v[1] != 2:
        raise AssertionError()
    if v[-1] != 4:
        raise AssertionError()
    if v[0:2] != [0, 2]:
        raise AssertionError()
    if v[1:4] != [2, 4]:
        raise AssertionError()



# Generated at 2022-06-11 21:39:13.967808
# Unit test for function drop
def test_drop():
    it = drop(10, range(100))
    for i in range(10, 100):
        assert next(it) == i
    try:
        next(it)
    except StopIteration:
        pass
    else:
        assert False

# Generated at 2022-06-11 21:39:22.134392
# Unit test for function drop_until
def test_drop_until():
    target = [6, 7, 8, 9]
    for i in range(0, 7):
        assert list(drop_until(lambda x: x > 5, range(i, i + 10))) == target
        assert list(drop_until(lambda x: x > 5, range(10, i, -1))) == target[10 - i:]
        assert list(drop_until(lambda x: x < 5, range(i, i + 10))) == target
        assert list(drop_until(lambda x: x < 5, range(10, i, -1))) == target[10 - i:]



# Generated at 2022-06-11 21:39:27.905296
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[-1] == 9

    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[-1] == 10

    r = Range(1, 11, 2)
    assert r[0] == 1
    assert r[2] == 5
    assert r[-1] == 9



# Generated at 2022-06-11 21:39:34.142823
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x % 2 == 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x == 100, range(10))) == []
    assert list(drop_until(lambda x: True, range(10))) == list(range(10))

# Generated at 2022-06-11 21:40:18.799003
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]


# Generated at 2022-06-11 21:40:26.922232
# Unit test for function split_by
def test_split_by():
    assert list(split_by([], criterion=lambda x: False)) == []
    assert list(split_by([1, 2, 3], criterion=lambda x: x % 3 == 0)) == [[1, 2]]
    assert list(split_by([1, 2, 3], empty_segments=True, criterion=lambda x: x % 3 == 0)) == [[1, 2], [3]]
    assert list(split_by([1, 2, 3], criterion=lambda x: x % 3 == 2)) == [[1], [3]]
    assert list(split_by([1, 2, 3], empty_segments=True, criterion=lambda x: x % 3 == 2)) == [[1], [], [2], [3]]

# Generated at 2022-06-11 21:40:30.780470
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x * x, [1, 2, 3, 4, 5])
    assert lst[1] == 4
    assert lst[::2] == [1, 9, 25]



# Generated at 2022-06-11 21:40:32.803161
# Unit test for function drop
def test_drop():
    assert next(drop(3, [1, 2, 3, 4, 5])) == 4
    
    

# Generated at 2022-06-11 21:40:34.727559
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # TODO: write test
    ...


# Generated at 2022-06-11 21:40:42.858419
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6,7,8,9]
    assert list(drop_until(lambda x: x > 5, [3,4,5,6,7,8,9])) == [6,7,8,9]
    assert list(drop_until(lambda x: x > 5, [5,6,7,8,9])) == [6,7,8,9]
    assert list(drop_until(lambda x: x > 5, [5,5])) == []

# test_drop_until()



# Generated at 2022-06-11 21:40:48.254221
# Unit test for function drop_until
def test_drop_until():
    assert [0] == list(drop_until(lambda x: x == 1, [0]))
    assert [1] == list(drop_until(lambda x: x == 1, [0, 1]))
    assert [1, 2] == list(drop_until(lambda x: x == 1, [0, 1, 2]))
    assert [1, 2, 3] == list(drop_until(lambda x: x == 1, [0, 1, 2, 3]))



# Generated at 2022-06-11 21:40:52.514276
# Unit test for function drop_until
def test_drop_until():
    it = list(drop_until(lambda x: x > 5, range(10)))
    assert it == [6, 7, 8, 9]
    it = list(drop_until(lambda x: x > 1000, range(10)))
    assert it == []


# Generated at 2022-06-11 21:41:03.835731
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    l = LazyList(range(1000000))
    assert l[-1] == 999999
    assert l[1000000] == 999999
    assert l[999999] == 999999
    assert l[-10] == 999999
    assert l[1000010] == 999999
    l = LazyList(range(10))
    assert l[1:5] == [1, 2, 3, 4]
    assert l[:5] == [0, 1, 2, 3, 4]
    assert l[1:] == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    l = LazyList(range(1000000))
    assert l[10000000] == 999999
    assert l[1:10000000] == list(range(1, 1000000))
    assert l[10:10000000]

# Generated at 2022-06-11 21:41:05.725770
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:41:52.325923
# Unit test for function drop_until
def test_drop_until():
    for iterable in [range(10), range(0), range(0, 5)]:
        assert list(drop_until(lambda x: x > 5, iterable)) == list(drop(6, iterable))



# Generated at 2022-06-11 21:42:02.133004
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    from random import choice
    from string import ascii_letters
    for _ in range(1000):
        s = ''.join(choice(ascii_letters) for _ in range(choice(range(1, 26))))
        lst = LazyList(s)
        assert lst[0] == s[0]
        assert lst[1] == s[1]
        assert lst[-1] == s[-1]
        assert lst[3:5] == list(s[3:5])
        assert lst[:5] == list(s[:5])
        assert lst[5:] == list(s[5:])
        assert lst[:] == list(s)
        assert lst == list(s)



# Generated at 2022-06-11 21:42:04.784150
# Unit test for function drop_until
def test_drop_until():
    iterable = range(10)
    predicate = lambda x: x > 5
    assert list(drop_until(predicate, iterable)) == list(filter(predicate, iterable))



# Generated at 2022-06-11 21:42:12.498097
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    def counter(n):
        for i in range(n):
            yield i
    x = LazyList(counter(100))
    assert len(x) == 100
    for i in range(100):
        assert x[i] == i
    assert list(x) == list(counter(100))
    assert list(x[-5:]) == list(counter(100))[-5:]
    assert list(x[:5]) == list(counter(100))[:5]
    assert list(x[5:15]) == list(counter(100))[5:15]
    assert list(x[::-1]) == list(counter(100))[::-1]
    assert list(x[-1:-50:-1]) == list(counter(100))[-1:-50:-1]
    assert list(x) == list

# Generated at 2022-06-11 21:42:17.916445
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    lst = LazyList(range(1000))
    for i in range(1000):
        next(iter(lst))
        assert i + 1 == len(lst.list)
    for i in range(1000):
        assert i == lst[i]

# Generated at 2022-06-11 21:42:19.654240
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    a_lazy_list = LazyList(range(10))
    assert len(a_lazy_list) == 10



# Generated at 2022-06-11 21:42:25.958442
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x >= 10, range(1000))) == list(range(10, 1000))
    assert list(drop_until(lambda x: x >= 1000, range(1000))) == []
    assert list(drop_until(lambda x: False, range(1000))) == list(range(1000))



# Generated at 2022-06-11 21:42:36.485270
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    class TestIterable:
        def __init__(self, seq: Iterable[int]):
            self.seq = seq
            self._seq_iter = None

        def __iter__(self):
            if self._seq_iter is None:
                self._seq_iter = iter(self.seq)
            return self._seq_iter

    seq = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    lst = LazyList(TestIterable(seq))
    assert tuple(lst) == tuple(seq)

    lst = LazyList(TestIterable(seq))
    it = iter(lst)
    assert tuple(it) == tuple(seq)

    lst = LazyList(TestIterable(seq))
    it = iter(lst)

# Generated at 2022-06-11 21:42:44.957642
# Unit test for function take
def test_take():
    assert list(take(0, [1, 2, 3])) == []
    assert list(take(1, [1, 2, 3])) == [1]
    assert list(take(2, [1, 2, 3])) == [1, 2]
    assert list(take(3, [1, 2, 3])) == [1, 2, 3]
    assert list(take(4, [1, 2, 3])) == [1, 2, 3]



# Generated at 2022-06-11 21:42:46.649065
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000)))==[0,1,2,3,4]
    assert list(take(5, iter(5)))==[5]


# Generated at 2022-06-11 21:43:41.341509
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    #
    # Lazy iteration
    #
    for t in [p[0] for p in product(range(1, 6), range(2, 3))]:
        f, a = lambda x: x + t, list(range(100))
        lst = MapList(f, a)
        for i in range(len(a)):
            assert lst[i] == f(a[i])
    #
    # Lazy slicing
    #
    for t in [p[0] for p in product(range(1, 6), range(2, 3))]:
        f, a = lambda x: x + t, list(range(100))
        lst = MapList(f, a)
        assert lst[:5] == [f(x) for x in a[:5]]

# Generated at 2022-06-11 21:43:48.165920
# Unit test for function split_by
def test_split_by():
    r"""
    >>> list(split_by(range(10), criterion=lambda x: x % 3 == 0))
    [[1, 2], [4, 5], [7, 8]]

    >>> list(split_by(" Split by: ", empty_segments=True, separator='.'))
    [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    """



# Generated at 2022-06-11 21:43:49.294233
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    assert list(LazyList(range(10))[:5]) == list(range(5))



# Generated at 2022-06-11 21:43:56.575971
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    obj = Range(1, 10 + 1)
    obj = Range(0, 10 + 1)
    obj = Range(1, 10 + 1, 2)
    obj[2]
    obj[2:2]
    obj[0:2]
    obj[:3]
    obj[5:]
    obj[:-1]
    obj[-1:]
    obj[-1:1]
    obj[-2:]
    obj[0:5:2]
    obj[1:5:2]
    obj[1:5:3]


# Generated at 2022-06-11 21:44:08.426455
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    with pytest.raises(TypeError):
        MapList(lambda x: x, [])[1:2]
    with pytest.raises(TypeError):
        MapList(lambda x: x, [])[1:2:3]
    MapList(lambda x: x, [])[:]
    MapList(lambda x: x, [1, 2, 3, 4])[0]
    MapList(lambda x: x, [1, 2, 3, 4])[-1]
    with pytest.raises(IndexError):
        MapList(lambda x: x, [1, 2, 3, 4])[5]
    MapList(lambda x: x, [1, 2, 3, 4])[:]
    MapList(lambda x: x, [1, 2, 3, 4])[1:3]
   

# Generated at 2022-06-11 21:44:11.448320
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    lst = LazyList(range(4))
    with pytest.raises(TypeError):
        assert len(lst) == 4
    assert lst[3] == 3
    assert len(lst) == 4


# Generated at 2022-06-11 21:44:20.221009
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Parameterize the tests
    lst_test_instances = [
        (Range(10),
         [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]),
        (Range(1, 10 + 1),
         [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]),
        (Range(1, 11, 2),
         [1, 3, 5, 7, 9]),
    ]
    # Use the instances above to test the class Range
    for test_instance, expected in lst_test_instances:
        yield assert_equals, test_instance[0], expected[0]
        yield assert_equals, test_instance[2], expected[2]
        yield assert_equals, test_instance[4], expected[4]



# Generated at 2022-06-11 21:44:27.483997
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert Range(1, 10 + 1)[0] == 1
    assert Range(1, 10 + 1)[9] == 10
    assert Range(1, 10 + 1, 2)[4] == 9
    assert Range(1, 10 + 1, 3)[1] == 4
    assert (Range(1, 10 + 1, 3)[:] == [1, 4, 7, 10])
    assert (Range(1, 10 + 1, 3)[1:4] == [4, 7, 10])
    assert (Range(1, 10 + 1, 3)[4:0] == [])



# Generated at 2022-06-11 21:44:28.336664
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    pass #FIXME

# Generated at 2022-06-11 21:44:35.120236
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()


# Generated at 2022-06-11 21:45:04.824309
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    lst = LazyList(range(10))
    assert lst[3] == 3
    assert lst[3:6] == [3, 4, 5]
    assert len(lst) == 10
    assert lst[9] == 9
    assert lst[7:10] == [7, 8, 9]
    assert lst[-1] == 9
    assert isinstance(lst[3:], list)
    assert lst[3:] == list(range(3, 10))
    # test that over-indexing raises IndexError
    with pytest.raises(IndexError):
        lst[10]
    # test getting indices before the iterable is consumed
    lst = LazyList(range(3))
    assert lst[0] == 0
    assert lst[1] == 1

# Generated at 2022-06-11 21:45:07.231041
# Unit test for function drop_until
def test_drop_until():
    fn = lambda x: x % 5 == 0
    for i in range(10):
        assert list(drop_until(fn, range(i))) == list(filter(fn, range(i)))

# Generated at 2022-06-11 21:45:14.407126
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    ll = LazyList(range(10))
    ll[0]
    assert len(ll.list) == 1
    ll[0:2]
    assert len(ll.list) == 2
    ll[3]
    assert len(ll.list) == 4
    ll[0:3]
    assert len(ll.list) == 4
    ll[0:5]
    assert len(ll.list) == 5


# Generated at 2022-06-11 21:45:21.200661
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    Range.__getitem__(Range.__init__(Range, 1, 10 + 1), 0)
    # for __getitem__ in range(0, 1, 1):
    #     Range.__getitem__(Range.__init__(Range, 1, 10 + 1), __getitem__)
    Range.__getitem__(Range.__init__(Range, 1, 10 + 1), slice(1, 10, 1))
    Range.__getitem__(Range.__init__(Range, 1, 10 + 1), 9)
    Range.__getitem__(Range.__init__(Range, 1, 10 + 1), slice(9, 1, 9))
    Range.__getitem__(Range.__init__(Range, 1, 10 + 1), slice(9, 1, -1))

# Generated at 2022-06-11 21:45:30.579077
# Unit test for function split_by
def test_split_by():
    # test criterion
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    # test separator
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    # test exception with criterion and separator as None
    try:
        list(split_by(" Split by: ", empty_segments=True, separator=None, criterion=None))
        raise AssertionError("No exception when criterion and separator are both None")
    except ValueError:
        pass
    # test exception with both criterion and separator specified

# Generated at 2022-06-11 21:45:32.582844
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    assert len(LazyList(range(100))) == 100
    assert len(LazyList(range(0))) == 0



# Generated at 2022-06-11 21:45:38.375320
# Unit test for function drop_until
def test_drop_until():
    # Drop nothing
    assert list(drop_until(lambda x: x >= 0, range(5))) == list(range(5))
    # Drop everything
    assert list(drop_until(lambda x: x >= 5, range(5))) == []
    # Drop a prefix
    assert list(drop_until(lambda x: x >= 2, range(5))) == list(range(2, 5))



# Generated at 2022-06-11 21:45:46.613610
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add, [1, 2, 3, 4], 0)) == [0, 1, 3, 6, 10]
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'])) == ['a', 'ba', 'cba', 'dcba']
    assert list(scanl(lambda s, x: x + s, ['a', 'b', 'c', 'd'], '')) == ['', 'a', 'ab', 'abc', 'abcd']



# Generated at 2022-06-11 21:45:50.514077
# Unit test for function drop_until
def test_drop_until():
    iter_ = list(range(10))
    for i in range(10):
        ret_iter = drop_until(lambda x: x > i, iter_)
        ret_list = [x for x in ret_iter]
        assert ret_list == list(range(i + 1, 10))



# Generated at 2022-06-11 21:46:01.841399
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    # Test if retrieve element by index and slice on LazyList
    arr = LazyList(range(10))
    # Before fetch
    assert len(arr) == 10
    assert sum(arr) == 45
    assert 5 in arr
    assert 11 not in arr
    # After fetch
    arr[0]
    assert len(arr) == 10
    assert sum(arr) == 45
    assert 5 in arr
    assert 11 not in arr
    # Test slicing
    assert arr[0:3] == [0, 1, 2]
    assert len(arr) == 10
    assert sum(arr) == 45
    assert 5 in arr
    assert 11 not in arr

    arr[0:3]
    assert len(arr) == 10
    assert sum(arr) == 45
    assert 5 in arr
    assert 11 not in arr

    arr

# Generated at 2022-06-11 21:46:45.961459
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__():
    assert list(LazyList(range(10))) == list(range(10))
    assert list(LazyList(range(10))[:10]) == list(range(10))
    assert list(LazyList(range(10))[:11]) == list(range(10))
    assert list(LazyList(range(10))[:11:-1]) == []
    assert list(LazyList(range(10))[::-1]) == list(range(10))[::-1]
    assert list(LazyList(range(10))[5:]) == list(range(5, 10))
    assert list(LazyList(range(10))[5:5]) == []
    assert list(LazyList(range(10))[5:6]) == [5]

# Generated at 2022-06-11 21:46:56.153727
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    for rng in Range(10), Range(1, 10 + 1), Range(1, 11, 2):
        # test get
        assert rng[0] == rng.l
        assert rng[-1] == (self.r - 1)
        assert rng[-2] == (self.r - 2 * self.step)
        assert rng[len(rng) - 1] == (self.r - 1)
        # test set
        start_value = rng.l
        with pytest.raises(TypeError):
            rng[0] = 0
        assert start_value == rng.l
        # test get without __len__ available
        del rng.__len__
        with pytest.raises(TypeError):
            rng[0]
        # test get item using slice