

# Generated at 2022-06-11 21:37:14.019655
# Unit test for function split_by
def test_split_by():
    cases = [
        (range(10), lambda x: x % 3 == 0, [[1, 2], [4, 5], [7, 8]]),
        (range(10), lambda x: x % 3 == 0, [[4, 5], [7, 8]]),
        (range(10), lambda x: x % 3 == 0, [[7, 8]]),
        (" Split by: ", '.', [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]),
        (" Split by: ", '.', [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]),
        (" Split by: ", '.', [['b', 'y', ':']]),
    ]

# Generated at 2022-06-11 21:37:18.674988
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    import random

    def test_map(lst, func):
        ml = MapList(func, lst)
        assert list(ml) == list(map(func, lst))
        for i in range(0, len(lst)):
            assert ml[i] == func(lst[i])
        idx = random.randint(0, len(lst) - 1)
        assert ml[idx:idx + 1] == [func(lst[idx])]
        assert ml[idx:idx + 2] == [func(lst[idx]), func(lst[idx + 1])]
        assert ml[idx:idx + random.randint(0, len(lst) - idx)] == [func(x) for x in lst[idx:]]
        assert ml

# Generated at 2022-06-11 21:37:21.283994
# Unit test for function drop
def test_drop():
    assert next(drop(1, [1, 2, 3])) == 2



# Generated at 2022-06-11 21:37:30.107548
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x % 3 == 0, [1, 2, 3, 4, 5])) == [3, 4, 5]
    assert list(drop_until(lambda x: x % 10 == 0, [1, 2, 3, 4, 5])) == []
    assert list(drop_until(lambda x: False, [1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
    assert list(drop_until(lambda x: True, [1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
# Test function drop_until
test_drop_until()


# Generated at 2022-06-11 21:37:31.804911
# Unit test for method __iter__ of class LazyList
def test_LazyList___iter__(): 
    lst = LazyList(range(1,9))
    assert lst.__iter__() == lst

# Generated at 2022-06-11 21:37:35.982808
# Unit test for function drop
def test_drop():
    from lazy.tests import assert_lazy_iter_equal
    assert_lazy_iter_equal(drop(3, [4, 2, 1, 2, 5, 0]), [1, 2, 5, 0])



# Generated at 2022-06-11 21:37:41.393994
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-11 21:37:47.216574
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x % 3 == 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x < 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-11 21:37:54.558789
# Unit test for function drop
def test_drop():
    """Tests for the drop function"""
    assert list(drop(0, [1,2,3,4])) == [1,2,3,4]
    assert list(drop(1, [1,2,3,4])) == [2,3,4]
    assert list(drop(2, [1,2,3,4])) == [3,4]
    assert list(drop(3, [1,2,3,4])) == [4]
    assert list(drop(4, [1,2,3,4])) == []



# Generated at 2022-06-11 21:38:02.239872
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x == 3, [1, 2, 3])) == []
    assert list(drop_until(lambda x: x == 4, [1, 2, 3])) == []
    assert list(drop_until(lambda x: x == 3, [1, 2, 3, 4, 5])) == [3, 4, 5]
    assert list(drop_until(lambda x: x == 4, [1, 2, 3, 4, 5])) == [4, 5]



# Generated at 2022-06-11 21:38:11.187695
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(10))) == list(range(3, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(0, range(10))) == list(range(10))



# Generated at 2022-06-11 21:38:13.201095
# Unit test for function drop
def test_drop():
    list(drop(5, range(1000000))) == list(range(499996))



# Generated at 2022-06-11 21:38:16.185330
# Unit test for method __len__ of class LazyList
def test_LazyList___len__():
    import pytest
    with pytest.raises(TypeError):
        len(LazyList([1, 2, 3]))


Range = LazyList[int]



# Generated at 2022-06-11 21:38:19.600920
# Unit test for function drop_until
def test_drop_until():
    iterable = [1, 2, 0, 3, 5, 7, 4]
    iterator = drop_until(lambda x: x > 0, iterable)
    assert list(iterator) == [2, 0, 3, 5, 7, 4]



# Generated at 2022-06-11 21:38:24.642638
# Unit test for function scanl
def test_scanl():
    assert list(scanl(operator.add,[1,2,3,4]))==[1,3,6,10]
    assert list(scanl(lambda s,x : x + s, ["a","b","c","d"]))==["a","ba","cba","dcba"]


# Generated at 2022-06-11 21:38:30.660552
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # 1. Set up any values you will need, here.
    r = Range(2)
    # 2. Run the code you want to test.
    result = r[:10:2]
    # 3. Verify that you got the result you expected.
    assert result == [0, 2, 4, 6, 8]

# Generated at 2022-06-11 21:38:36.537968
# Unit test for function take
def test_take():
    for n in range(4):
        seq = list(take(n, range(5)))
        assert len(seq) == min(n, 5)
        assert seq == list(range(min(n, 5)))
    for n in range(-4, 4):
        seq = list(take(n, range(5)))
        if n >= 0:
            assert len(seq) == min(n, 5)
            assert seq == list(range(min(n, 5)))
        else:
            assert len(seq) == 0



# Generated at 2022-06-11 21:38:43.550948
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [])) == []
# Test cases for the docstring example
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [])) == []



# Generated at 2022-06-11 21:38:49.336041
# Unit test for function drop
def test_drop():
    assert list(drop(1, ["a", "b", "c"])) == ["b", "c"]
    assert list(drop(10, ["a", "b", "c"])) == []
    assert list(drop(0, ["a", "b", "c"])) == ["a", "b", "c"]
    assert list(drop(3, range(10))) == [3, 4, 5, 6, 7, 8, 9]


# Generated at 2022-06-11 21:38:54.052736
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == [0, 1, 2, 3, 4]
    assert list(take(-5, range(1000000))) == ValueError



# Generated at 2022-06-11 21:39:15.493522
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, range(6))) == []
    assert list(drop_until(lambda _: False, range(1, 8))) == [1, 2, 3, 4, 5, 6, 7]
    assert list(drop_until(lambda x: x < 5, range(3, 6))) == [3, 4, 5]
    assert list(drop_until(lambda _: False, (1, 2))) == [1, 2]
    assert list(drop_until(lambda x: x > 5, range(10, 5, -1))) == []

# Generated at 2022-06-11 21:39:20.489583
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)         # (end)
    assert r[0] == 0
    assert r[1] == 1
    assert r[-1] == 9
    assert r[4:8] == [4, 5, 6, 7]
    assert r[8:4:-1] == [8, 7, 6, 5]
    r = Range(1, 10 + 1)  # (start, end)
    assert r[0] == 1
    assert r[1] == 2
    assert r[-1] == 10
    assert r[4:8] == [5, 6, 7, 8]
    assert r[8:4:-1] == [9, 8, 7, 6]
    r = Range(1, 11, 2)   # (start, end, step)
    assert r[0] == 1
   

# Generated at 2022-06-11 21:39:23.388392
# Unit test for function take
def test_take():
    for i in range(100):
        assert next(take(i, range(1000)), None) == i



# Generated at 2022-06-11 21:39:29.672749
# Unit test for function chunk
def test_chunk():
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(1, [1, 2, 3])) == [[1], [2], [3]]
    assert list(chunk(1, [])) == []
    assert list(chunk(0, [1, 2])) == [[1, 2]]
    assert list(chunk(3, range(2))) == [[0, 1]]
    assert list(chunk(3, range(10))) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
    assert list(chunk(2, range(3))) == [[0, 1], [2]]



# Generated at 2022-06-11 21:39:34.041955
# Unit test for function take
def test_take():
    it = (i for i in range(10))
    assert list(take(2, it)) == [0, 1]
    assert list(take(2, it)) == []
    assert list(take(0, it)) == []

# Generated at 2022-06-11 21:39:42.837140
# Unit test for function split_by
def test_split_by():
    def xor(iterable: Iterable[bool]) -> bool:
        return reduce(lambda x, y: x ^ y, iterable)

    assert list(split_by([False, False, False])) == [[], []]
    assert list(split_by([False, True, False, False])) == [[], [], []]
    assert list(split_by([0, 1, 2, 0, 1, 0, 2], criterion=lambda x: x % 2 == 1)) == [[0, 2, 0, 2]]
    assert list(split_by([0, 1, 2, 0, 1, 0, 2], criterion=lambda x: x % 2 == 1, empty_segments=True)) == [[], [0, 2], [], [2]]

# Generated at 2022-06-11 21:39:44.657524
# Unit test for function take
def test_take():
    assert list(take(5, range(1000000))) == list(range(5))



# Generated at 2022-06-11 21:39:50.269824
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [-10, 1, 2, 3])) == [-10, 1, 2, 3]



# Generated at 2022-06-11 21:39:57.119200
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[4] == 4
    assert r[9] == 9
    r = Range(1, 10 + 1)
    assert r[0] == 1
    assert r[2] == 3
    assert r[4] == 5
    assert r[9] == 10
    r = Range(1, 11, 2)
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9
    assert r[9] == 19


# Generated at 2022-06-11 21:40:05.299711
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by("Split by", separator=':')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y']]
    assert list(split_by(range(10), criterion=lambda x: x % 2 == 0)) == [[1, 3, 5, 7, 9]]
    assert list(split_by(range(10), separator=0)) == [[1, 2, 3, 4, 5, 6, 7, 8, 9]]



# Generated at 2022-06-11 21:40:25.579089
# Unit test for function drop
def test_drop():
    it = iter(range(100))
    print(list(drop(-1, it)))
    it = iter(range(100))
    print(list(drop(0, it)))
    it = iter(range(100))
    print(list(drop(10, it)))
    it = iter(range(100))
    print(list(drop(101, it)))
    it = iter(range(100))
    print(list(drop(100, it)))
    it = iter(range(100))
    print(list(drop(200, it)))
test_drop()


# Generated at 2022-06-11 21:40:35.100458
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
    with pytest.raises(ValueError):
        list(split_by(range(10), criterion=lambda x: x % 3 == 0, separator='.'))
    with pytest.raises(ValueError):
        list(split_by(range(10)))


# Generated at 2022-06-11 21:40:40.717582
# Unit test for function drop
def test_drop():
    assert next(drop(1, [1, 2, 3, 4, 5])) == 2
    assert list(drop(5, [1, 2, 3, 4, 5])) == []
    assert list(drop(0, [1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
    assert list(drop(5, [])) == []



# Generated at 2022-06-11 21:40:50.454478
# Unit test for function drop_until
def test_drop_until():
    # Test when the iterable is empty
    assert list(drop_until(lambda x: x == 0, [])) == []
    # Test when there are no elements in the iterable that satisfy the predicate
    assert list(drop_until(lambda x: x == 0, [1, 2, 3])) == []
    # Test when the first element satisfies the predicate
    assert list(drop_until(lambda x: x == 0, [0, 1, 2, 3])) == [0, 1, 2, 3]
    # Test when the first element does not satisfy the predicate
    assert list(drop_until(lambda x: x == 0, [1, 2, 0, 3, 4])) == [0, 3, 4]



# Generated at 2022-06-11 21:40:52.874537
# Unit test for function split_by
def test_split_by():
    assert list(split_by(' Split by: ', separator='.')) == [['S', 'p', 'l', 'i', 't'], ['b', 'y', ':']]



# Generated at 2022-06-11 21:40:55.602881
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]



# Generated at 2022-06-11 21:40:59.705180
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    for i, x in enumerate(MapList(lambda x: x + 1, [1, 2, 3])):
        assert i + 1 == x
    assert [1, 2, 3] == MapList(lambda x: x * 2, [0, 1, 2])[:3]



# Generated at 2022-06-11 21:41:05.120396
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    assert 4 == Range(4, 5)[0]
    assert 5 == Range(4, 6)[1]
    assert [4, 5] == Range(4, 7)[:2]
    assert [6, 7] == Range(4, 8)[-2:]
    assert [0, 1, 2] == Range(0, 3, 1)



# Generated at 2022-06-11 21:41:06.326377
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    pass


# Generated at 2022-06-11 21:41:16.858551
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(0, 11)
    assert r[0] == 0 and r[-1] == 10 and r[2::2] == [0, 4, 8]
    assert r[:2] == [0, 1]
    assert r[2:] == [2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert r[::2] == [0, 2, 4, 6, 8, 10]
    try:
        r[11]
        assert False
    except IndexError:
        pass
    try:
        r[-12]
        assert False
    except IndexError:
        pass
    try:
        r[::-1]
        assert False
    except ValueError:
        pass
    r = Range(-1)

# Generated at 2022-06-11 21:41:31.008924
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Test for case Range
    r = Range(1, 11, 2)
    print(r[0], r[2], r[4])
    assert r[0] == 1
    assert r[2] == 5
    assert r[4] == 9

if __name__ == '__main__':
    test_Range___getitem__()
    # Show documentation for all members that have documentation, in a form compatible with pydoc:
    doctest.testmod()

# Generated at 2022-06-11 21:41:39.926551
# Unit test for function drop_until
def test_drop_until():
    # check invalid inputs
    def invalid_inputs():
        drop_until(None, range(10))
        drop_until(lambda x: x > 5, None)
    with pytest.raises(TypeError):
        invalid_inputs()
    # check normal cases
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x % 2 == 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x % 2 == 1, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-11 21:41:48.630254
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = MapList(lambda x: x * x, [1, 2, 3, 4, 5])

    assert lst[0] == 1
    assert lst[1] == 4
    assert lst[2] == 9

    assert lst[0:3] == [1, 4, 9]
    assert lst[:3] == [1, 4, 9]
    assert lst[0:] == [1, 4, 9, 16, 25]
    assert lst[0::2] == [1, 9, 25]
    assert lst[:-1] == [1, 4, 9, 16]
    assert lst[::-1] == [25, 16, 9, 4, 1]



# Generated at 2022-06-11 21:41:59.347904
# Unit test for function take
def test_take():
    assert list(take(3, [1,2,3,4,5])) == [1,2,3]
    assert list(take(3, [1,2,3,4,5,6,7,8,9,10])) == [1,2,3]
    assert list(take(1, [1])) == [1]
    assert list(take(1, [1,2,3,4,5])) == [1]
    assert list(take(0, [1,2,3,4,5])) == []
    assert list(take(2, [1,2,3])) == [1,2]
    assert list(take(0, [1,2,3])) == []
    assert list(take(3, [1])) == [1]

# Generated at 2022-06-11 21:42:09.752373
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    # Get item
    r = Range(-10, 10)
    l = list(r)
    assert len(r) == 20 and l == r
    assert all(r[i] == r.l + i for i in range(r.length))
    assert all(r[-i - 1] == r.r - i - 1 for i in range(r.length))
    # Test slice
    assert r[2:8] == [r.l + 2, r.l + 3, r.l + 4, r.l + 5, r.l + 6, r.l + 7]
    assert r[2:8:2] == [r.l + 2, r.l + 4, r.l + 6]

# Generated at 2022-06-11 21:42:21.707103
# Unit test for function drop
def test_drop():
    assert list(drop(0, range(10))) == list(range(10))
    assert list(drop(1, range(10))) == list(range(1, 10))
    assert list(drop(2, range(10))) == list(range(2, 10))
    assert list(drop(3, range(10))) == list(range(3, 10))
    assert list(drop(4, range(10))) == list(range(4, 10))
    assert list(drop(5, range(10))) == list(range(5, 10))
    assert list(drop(6, range(10))) == list(range(6, 10))
    assert list(drop(7, range(10))) == list(range(7, 10))
    assert list(drop(8, range(10))) == list(range(8, 10))
    assert list

# Generated at 2022-06-11 21:42:30.776718
# Unit test for function split_by
def test_split_by():
    def test_criterion(ls, f, res):
        assert list(split_by(ls, criterion=f)) == res

    def test_separator(ls, sep, res):
        assert list(split_by(ls, separator=sep)) == res

    test_criterion([], lambda x: False, [])
    test_criterion([1, 2, 3], lambda x: False, [[1, 2, 3]])
    test_criterion([1, 2, 3], lambda x: x % 2 == 0, [[1], [3]])
    test_criterion([1, 2, 3], lambda x: x < 3, [[3]])
    test_criterion([1, 2, 3], lambda x: x > 0, [[1, 2, 3]])

# Generated at 2022-06-11 21:42:37.604444
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    for i in r:
        for j in range(5):
            print(r[i:5 + i])
    r = Range(1, 10 + 1)
    for i in r:
        for j in range(5):
            print(r[i:5 + i])
    r = Range(1, 11, 2)
    for i in r:
        for j in range(5):
            print(r[i:5 + i])
test_Range___getitem__()


# Generated at 2022-06-11 21:42:43.732315
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    assert MapList(lambda x: x, [1, 2, 3])[0:2] == [1, 2]
    assert MapList(lambda x: x, [1, 2, 3])[2:2] == []
    assert MapList(lambda x: x, [1, 2, 3])[2:0] == []


# Generated at 2022-06-11 21:42:49.445021
# Unit test for function drop
def test_drop():
    n = 5
    data = [0, 1, 2, 3]
    for i,x in enumerate(drop(n,data)):
        assert x == data[n+i]
    n= len(data)+1
    for i,x in enumerate(drop(n,data)):
        assert x == data[n+i]

    #test negative n
    n = -1
    try:
        next(drop(n,data))
    except ValueError:
        pass


# Generated at 2022-06-11 21:43:28.192693
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    # drop_until should return an empty iterator when the iterable is empty
    assert list(drop_until(lambda x: x > 5, [])) == []
    # drop_until should return an empty iterator when all elements in the iterable do not satisfy the predicate
    assert list(drop_until(lambda x: x > 5, (1, 2, 3))) == []
    # drop_until should return the entire iterator when the first item in the iterable satisfies the predicate
    assert list(drop_until(lambda x: x > 5, (6, 7, 8, 9))) == [6, 7, 8, 9]
    # drop_until should return an empty iterator when no elements in the iterable satisfies the predicate

# Generated at 2022-06-11 21:43:41.386564
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(3)
    assert r[0] == 0
    assert r[1] == 1
    assert r[2] == 2
    assert r[-1] == 2
    assert r[-2] == 1
    with raises(IndexError):
        r[3]
    with raises(IndexError):
        r[-3]
    assert r[0:1] == [0]
    assert r[0:2] == [0, 1]
    assert r[0:3] == [0, 1, 2]
    assert r[0:4] == [0, 1, 2]
    assert r[0:-1] == [0, 1]
    assert r[0:-2] == [0]
    assert r[0:-3] == []
    assert r[0:] == [0, 1, 2]

# Generated at 2022-06-11 21:43:49.562965
# Unit test for function drop_until
def test_drop_until():
  list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
  list(drop_until(lambda x: x < 3, range(4))) == [3]
  list(drop_until(lambda x: x < 3, range(3))) == []
  list(drop_until(lambda x: x < 0, range(3))) == []
  list(drop_until(lambda x: x < 3, [])) == []
test_drop_until()


# Generated at 2022-06-11 21:43:52.952521
# Unit test for function drop_until
def test_drop_until():
    seq = [1,2,3]
    def pred(x):
        return x > 2
    assert list(drop_until(pred, seq)) == [3]


# Generated at 2022-06-11 21:44:03.253231
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x % 2 == 0, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: x % 2 == 1, range(10))) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: False, range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(drop_until(lambda x: True, range(10))) == (list(range(10)))



# Generated at 2022-06-11 21:44:12.813549
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [5,6,7,8,9]
    assert list(drop_until(lambda x: x > 0, range(10))) == [0,1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: x > -1, range(10))) == [0,1,2,3,4,5,6,7,8,9]
    assert list(drop_until(lambda x: x > 9, range(10))) == []
    assert list(drop_until(lambda x: x > 5, [])) == []
    assert list(drop_until(lambda x: x > 5, [5,6,7,8,9])) == [5,6,7,8,9]


# Generated at 2022-06-11 21:44:22.772199
# Unit test for method __getitem__ of class LazyList
def test_LazyList___getitem__():
    a = LazyList(range(10))
    for i in (-10, -1, 0, 1, 2, 9):
        assert i == a[i]
    for i in range(10):
        assert i == a[i]
    assert a == list(a)
    assert tuple(a[0:5]) == tuple(range(5))
    assert tuple(a[5:10]) == tuple(range(5, 10))
    assert a[0::2] == [0, 2, 4, 6, 8]
    assert a[1::2] == [1, 3, 5, 7, 9]
    assert a[:5] == [0, 1, 2, 3, 4]
    assert a[5:] == [5, 6, 7, 8, 9]

# Generated at 2022-06-11 21:44:30.819883
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    TEST_DATA = [
        (Range(10), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]),
        (Range(1, 10), [1, 2, 3, 4, 5, 6, 7, 8, 9]),
        (Range(1, 11, 2), [1, 3, 5, 7, 9]),
        (Range(-10), [0, -1, -2, -3, -4, -5, -6, -7, -8, -9]),
        (Range(-1, -10), [-1, -2, -3, -4, -5, -6, -7, -8, -9]),
        (Range(-1, -11, -2), [-1, -3, -5, -7, -9]),
    ]

# Generated at 2022-06-11 21:44:37.532076
# Unit test for function split_by
def test_split_by():
    assert list(split_by(range(10), criterion=lambda x: x % 3 == 0)) == [[1, 2], [4, 5], [7, 8]]
    assert list(split_by(" Split by: ", empty_segments=True, separator='.')) == [[], ['S', 'p', 'l', 'i', 't'], ['b', 'y', ':'], []]
test_split_by()



# Generated at 2022-06-11 21:44:40.604711
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]
    assert list(drop(3, [])) == []
    with pytest.raises(ValueError):
        list(drop(-1, range(10)))
test_drop()



# Generated at 2022-06-11 21:45:18.230301
# Unit test for function drop
def test_drop():
    # Corner case 1: drop 0 elements
    assert list(drop(0,range(10))) == list(range(10))



# Generated at 2022-06-11 21:45:23.099290
# Unit test for function take
def test_take():
    assert list(take(0, range(1, 10))) == []
    assert list(take(3, range(1, 10))) == [0, 1, 2]
    assert list(take(10, range(1, 10))) == list(range(1, 10))



# Generated at 2022-06-11 21:45:28.143630
# Unit test for method __getitem__ of class MapList
def test_MapList___getitem__():
    lst = [1, 2, 3, 4, 5]
    m = MapList(lambda x: x * x, lst)
    assert m[0] == 1
    assert m[1] == 4
    assert m[0:2] == [1, 4]
    assert m[2:4] == [9, 16]
    # Unit test for method __iter__ of class MapList

# Generated at 2022-06-11 21:45:30.606622
# Unit test for function drop
def test_drop():
    assert list(drop(5, range(5))) == []
    assert list(drop(5, range(10))) == [5, 6, 7, 8, 9]


# Generated at 2022-06-11 21:45:40.158246
# Unit test for function drop
def test_drop():
    assert list(drop(3, range(10))) == list(range(3, 10))
    assert list(drop(10, range(10))) == []
    assert list(drop(11, range(10))) == []
    assert list(drop(10, [])) == []
    assert list(drop(10, ())) == []
    assert list(drop(10, "")) == []
    assert list(drop(0, "abc")) == list("abc")
    assert list(drop(2, "abc")) == list("c")
    assert list(drop(200, "abc")) == []
    assert list(drop(0, {'a': 1, 'b': 2})) == [1, 2]
    assert list(drop(2, {'a': 1, 'b': 2})) == []

# Generated at 2022-06-11 21:45:50.875051
# Unit test for method __getitem__ of class Range
def test_Range___getitem__():
    r = Range(10)
    assert r[0] == 0
    assert r[2] == 2
    assert r[3] == 3
    assert r[4] == 4
    assert r[5] == 5
    assert r[6] == 6
    assert r[7] == 7
    assert r[8] == 8
    assert r[9] == 9
    assert r[-1] == 9
    assert r[-2] == 8
    assert r[-3] == 7
    assert r[-4] == 6
    assert r[-5] == 5
    assert r[-6] == 4
    assert r[-7] == 3
    assert r[-8] == 2
    assert r[-9] == 1
    assert r[-10] == 0

# Generated at 2022-06-11 21:46:00.101875
# Unit test for function drop
def test_drop():
    assert list(drop(0, [1,2,3])) == [1,2,3]
    assert list(drop(1, [1,2,3])) == [2,3]
    assert list(drop(2, [1,2,3])) == [3]
    assert list(drop(3, [1,2,3])) == []
    assert list(drop(10, [1,2,3])) == []
    assert list(drop(0, [])) == []
    assert list(drop(1, [])) == []
    assert list(drop(2, [])) == []



# Generated at 2022-06-11 21:46:05.951131
# Unit test for function drop_until
def test_drop_until():
    assert list(drop_until(lambda x: x > 5, range(10))) == [6, 7, 8, 9]
    assert list(drop_until(lambda x: x > 5, [1, 2, 3])) == []
    assert list(drop_until(lambda x: x > 5, range(10, 5, -1))) == [10, 9, 8, 7, 6]



# Generated at 2022-06-11 21:46:16.209906
# Unit test for function take
def test_take():
    assert list(take(0, range(1))) == []
    assert list(take(1, range(1))) == [0]
    assert list(take(2, range(1))) == [0]
    assert list(take(0, range(3))) == []
    assert list(take(1, range(3))) == [0]
    assert list(take(2, range(3))) == [0, 1]
    assert list(take(3, range(3))) == [0, 1, 2]
    assert list(take(4, range(3))) == [0, 1, 2]



# Generated at 2022-06-11 21:46:18.535243
# Unit test for function drop
def test_drop():
    iterable = range(10)
    for n in range(10):
        i = 0
        for x in drop(n, iterable):
            assert x == i + n
            i += 1
        assert i == 10 - n

