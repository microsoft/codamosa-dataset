

# Generated at 2022-06-25 18:05:44.896209
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict()
    headers['User-Agent'] = 'HTTPie'
    header_dict = finalize_headers(headers)
    assert header_dict['User-Agent'] == 'HTTPie'

# Generated at 2022-06-25 18:05:50.672686
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = True
    args.form = True
    args.files = True
    args.json = True
    args.verify = True
    args.cert = True
    args.cert_key = True
    args.proxy = True
    args.headers = {'Content-Type' : 'application/json'}
    
    req1 = make_request_kwargs(args)
    req2 = make_request_kwargs(args)
    test_make_request_kwargs(req1, req2)



# Generated at 2022-06-25 18:06:02.727447
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.data = False
    args.form = False
    args.json = False
    args.files = []
    args.multipart = False
    args.method = 'GET'
    args.url = 'https://httpbin.org'
    args.headers = { 'User-Agent': 'curl/7.65.1' }
    args.params = { ('param-1', 'value-1'), ('param-2', 'value-2') }
    args.auth = ('user', 'pass')
    args.session = 'foo'
    args.session_read_only = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.timeout = 20.0
    args.verify = 'yes'
    args

# Generated at 2022-06-25 18:06:12.203128
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug')
    parser.add_argument('--form', action='store_true')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--data', default=None)
    parser.add_argument('--files', default=[])
    parser.add_argument('--multipart', action='store_true')
    parser.add_argument('--multipart-data', default=None)
    parser.add_argument('--boundary')
    parser.add_argument('--headers', default=[])
    parser.add_argument('--timeout', type=float, default=None)
    parser.add_argument('--auth', default=None)
    parser.add_argument('--params', default=[])
    parser

# Generated at 2022-06-25 18:06:13.461622
# Unit test for function max_headers
def test_max_headers():
    # print('Testing max_headers')
    assert True


# Generated at 2022-06-25 18:06:22.406883
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=None,
                              allow_redirects=False,
                              proxies=[],
                              stream=True,
                              verify='yes',
                              cert=None)
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {'timeout': None,
                              'allow_redirects': False,
                              'proxies': [],
                              'stream': True,
                              'verify': 'yes',
                              'cert': None}



# Generated at 2022-06-25 18:06:28.223399
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(data='{"key": "value"}', json=True)
    kwargs = make_send_kwargs_mergeable_from_env(args)

    if 'proxies' not in kwargs:
        raise AssertionError('proxies not in kwargs')

    if 'stream' not in kwargs:
        raise AssertionError('stream not in kwargs')

    if 'verify' not in kwargs:
        raise AssertionError('verify not in kwargs')

    if 'cert' not in kwargs:
        raise AssertionError('cert not in kwargs')


# Generated at 2022-06-25 18:06:32.152126
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(unittest.TestCase) == {}

# Generated at 2022-06-25 18:06:43.426651
# Unit test for function max_headers
def test_max_headers():
    # create a MaxSizeDict with max_size 5
    d = collections.OrderedDict()
    d['a'] = "A"
    d['b'] = "B"
    d['c'] = "C"
    d['d'] = "D"
    d['e'] = "E"

    # update value of 'a'
    d['a'] = "new"

    # Size of dict should be 5
    assert len(d) == 5

    # add value for 'f'
    d['f'] = "F"

    # 'b' should get popped as it was added before 'a'
    # Size of dict should be 5
    assert len(d) == 5


if __name__ == '__main__':
    test_max_headers()

# Generated at 2022-06-25 18:06:48.866749
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    output = collect_messages(
        args,
        config_dir,
        request_body_read_callback
    )
    assert type(output) == type(collect_messages(args, config_dir, request_body_read_callback))

# Generated at 2022-06-25 18:07:10.448667
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli.argtypes import KeyValueArgType

    args = argparse.Namespace()
    args.proxy = [KeyValueArgType(key='key', value='value')]

    result = make_send_kwargs_mergeable_from_env(args)

    assert result['proxies'] == {'key': 'value'}

# Generated at 2022-06-25 18:07:16.522963
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        http.client._MAXHEADERS = 2
    if http.client._MAXHEADERS == 2:
        print("Max headers unit test successful")

__test__ = {
    name: value
    for name, value in locals().items()
    if name.startswith('test_')
}


if __name__ == '__main__':
    test_case_0()
    test_max_headers()

# Generated at 2022-06-25 18:07:28.603403
# Unit test for function collect_messages
def test_collect_messages():
    args_0 = argparse.Namespace(auth=None, auth_plugin=None, cert=None, ciphers=None, chunked=False, compress=False, data=None, debug=False, form=False, headers=None, json=False, offline=False, params=None, path_as_is=False, proxy=None, session=None, session_read_only=None, ssl_version=None, timeout=None, url='http://httpbin.org/redirect/1', verify=False)
    config_dir_0 = Path('/')
    request_body_read_callback_0 = lambda chunk: chunk

# Generated at 2022-06-25 18:07:33.961004
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace()
    args_0.json = False
    args_0.form = False
    args_0.data = {}
    assert make_default_headers(args_0) == RequestHeadersDict({'User-Agent': 'HTTPie/1.1.1', 'Accept': 'application/json, */*;q=0.5'})


# Generated at 2022-06-25 18:07:46.057150
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:07:55.692990
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # the following are the arguments generated using --k-gen
    args = {}
    args['--auth'] = "username"
    args['--auth-type'] = "basic"
    args['--body'] = "filename.txt"
    args['--body-define'] = {}
    args['--body-file'] = "filename.txt"
    args['--body-fileb'] = "filename.txt"
    args['--body-json'] = "json.txt"
    args['--body-json-file'] = "filename.txt"
    args['--body-json-pp'] = False
    args['--body-json-s'] = "json.txt"
    args['--body-json-s-file'] = "filename.txt"
    args['--body-json-s-pp'] = False

# Generated at 2022-06-25 18:08:08.010245
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        chunked=False,
        cert=None,
        cert_key=None,
        ciphers=None,
        color=False,
        compress=None,
        data=None,
        files={},
        form=False,
        headers=None,
        max_headers=2000,
        json=False,
        offline=False,
        method='GET',
        params=argparse.Namespace(items=[]),
        path_as_is=False,
        proxy=[],
        session=None,
        session_read_only=None,
        ssl_version='',
        timeout=None,
        url='foo',
        verify=None,
        verbose=2,
    )
    config_dir

# Generated at 2022-06-25 18:08:17.195792
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    parser = argparse.ArgumentParser(description='HTTPie arg parser')
    parser.add_argument(
        '--form', dest='form', default=False, action='store_true',
        help='Parse JSON request body as application/x-www-form-urlencoded.'
    )
    parser.add_argument(
        '--json', dest='json', default=False, action='store_true',
        help='Parse JSON request body.'
    )
    parser.add_argument(
        '--data', dest='data', metavar='DATA', type=str,
        help='Data string to parse as JSON and pass in the request body.'
    )

# Generated at 2022-06-25 18:08:28.217607
# Unit test for function make_send_kwargs

# Generated at 2022-06-25 18:08:39.320097
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.compat import FileNotFoundError
    from httpie.cli import get_parser, main

    parser = get_parser()
    orig_stderr = sys.stderr
    sys.stderr = open('/dev/null', 'w')
    try:
        sys.argv = ['http', 'https://httpbin.org/get']
        args = parser.parse_args()
        list_0 = collect_messages(args, Path('/tmp/httpie'))
        for i in range(100):
            list_1 = list(list_0)


    except Exception as exception:
        print(exception)
    finally:
        sys.stderr = orig_stderr


# Generated at 2022-06-25 18:10:11.798603
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    arg1 = mock.MagicMock()
    arg2 = mock.MagicMock()

    # Calling make_send_kwargs(arg1, arg2)
    ret_val = make_send_kwargs(arg1, arg2)

    # Basic validation tests
    assert isinstance(ret_val, dict)


# Generated at 2022-06-25 18:10:20.979413
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # test: Check if the function returns the right type
    args_0 = argparse.Namespace()
    kwargs_0 = make_request_kwargs(args_0)
    assert type(kwargs_0) == dict
    # test: if you pass a arguments container with an empty url field
    #       the function should return an empty string
    args_1 = argparse.Namespace(url='')
    kwargs_1 = make_request_kwargs(args_1)
    assert kwargs_1['url'] == ''
    # test: if you pass a arguments container with a not empty url
    #       the function should return return the value of the url field
    #       of the arguments container
    args_2 = argparse.Namespace(url='www.google.com')
    kwargs_2 = make_

# Generated at 2022-06-25 18:10:25.283120
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    float_0 = float()
    str_0 = str()
    dict_0 = dict()
    return_value_0 = make_send_kwargs(str_0)
    return_value_1 = make_send_kwargs(dict_0)
    return_value_2 = make_send_kwargs(float_0)


# Generated at 2022-06-25 18:10:30.139663
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.proxy = ['http://foo:bar@host:8080']

    test_kwargs = make_send_kwargs_mergeable_from_env(args)

    assert args.verify == test_kwargs['verify']
    assert args.proxy[0].value == test_kwargs['proxies']['http']



# Generated at 2022-06-25 18:10:35.967605
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace()
    kwargs_0 = {'str':'str'}
    args_0.headers = kwargs_0
    args_0.json = True
    args_0.data = 3
    headers_0 = make_default_headers(args_0)
    # we can't make the exact string, but we can assert
    # that the headers contains the one we want
    assert('Content-Type' in headers_0) == True
    assert('Accept' in headers_0) == True


# Generated at 2022-06-25 18:10:39.515004
# Unit test for function make_default_headers
def test_make_default_headers():
    parser = argparse.ArgumentParser()
    make_default_headers(parser)


# Generated at 2022-06-25 18:10:52.039868
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:10:59.905149
# Unit test for function collect_messages
def test_collect_messages():
    args_0 = argparse.ArgumentParser(
        description='Command line HTTP client',
        add_help=False
    )
    args_0.add_argument('--auth', '-a', default=None,
                        help="""Supply an HTTP Basic Auth username and password via URL syntax, e.g. “example.com” or “foo:bar” or “ki:k:i:s:s”.\n""")
    args_1 = args_0
    config_dir_0 = None
    request_body_read_callback_0 = None
    result = collect_messages(
        args_1,
        config_dir_0,
        request_body_read_callback_0,
    )
    # Should be a generator

# Generated at 2022-06-25 18:11:03.596261
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 3
    args.allow_redirects = True
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 3


# Generated at 2022-06-25 18:11:08.642202
# Unit test for function build_requests_session
def test_build_requests_session():
    global counter, passed, total_cases, size
    counter += 1
    try:
        test_case_0()
        passed += 1
    except:
        print("Failed test case: test_build_requests_session()")


# Generated at 2022-06-25 18:12:26.913100
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    sentinel_1 = None
    sentinel_2 = None

    args = argparse.Namespace(
        auth=sentinel_2,
        cert=sentinel_1,
        chunked=sentinel_1,
        data=sentinel_1,
        files=sentinel_2,
        form=sentinel_2,
        headers={},
        json=sentinel_1,
        max_redirects=sentinel_1,
        method='sentinel_1',
        offline=sentinel_2,
        params=[],
        stream=sentinel_2,
        timeout=sentinel_1,
        url='sentinel_1',
        verify=sentinel_1,
    )


# Generated at 2022-06-25 18:12:28.275145
# Unit test for function max_headers
def test_max_headers():
    num_0 = float('Inf')
    assert max_headers(num_0)


# Generated at 2022-06-25 18:12:36.871871
# Unit test for function make_default_headers
def test_make_default_headers():
    test_make_default_headers_args_0 = argparse.Namespace()
    test_make_default_headers_args_0.json = False
    test_make_default_headers_args_0.session_read_only = None
    test_make_default_headers_args_0.data = None
    test_make_default_headers_args_0.verbose = False
    test_make_default_headers_args_0.form = False
    test_make_default_headers_args_0.json = False
    test_make_default_headers_args_0.headers = RequestHeadersDict()
    test_make_default_headers_args_0.headers['Content-Type'] = 'application/json'
    make_default_headers(test_make_default_headers_args_0)

# Unit test

# Generated at 2022-06-25 18:12:41.853517
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace()
    args_0.json = False
    args_0.form = False
    args_0.data = {}
    result_1 = make_default_headers(args_0)
    assert result_1 == RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'})


# Generated at 2022-06-25 18:12:45.429496
# Unit test for function max_headers
def test_max_headers():
    import http.client
    try:
        with max_headers(10):
            assert http.client._MAXHEADERS == 10
        assert http.client._MAXHEADERS != 10
    except Exception:
        print("test_max_headers failed")


# Generated at 2022-06-25 18:12:53.617325
# Unit test for function make_default_headers
def test_make_default_headers():
    bool_0 = True
    bool_1 = False
    args = argparse.Namespace()
    args.data = bool_0
    args.form = bool_0
    args.json = bool_0
    headers = make_default_headers(args)
    assert headers.get('Content-Type') == 'application/json; charset=utf-8'
    assert headers.get('Accept') == 'application/json, */*;q=0.5'
    args.json = bool_1
    headers = make_default_headers(args)
    assert headers.get('Content-Type') == 'application/x-www-form-urlencoded; charset=utf-8'
    args.form =bool_1
    headers = make_default_headers(args)
    assert headers.get('Content-Type') is None



# Generated at 2022-06-25 18:12:57.095531
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    try:
        result = make_default_headers(args)
        print(f"Success: make_default_headers")
    except:
        print(f"Failed: make_default_headers")
        raise


# Generated at 2022-06-25 18:13:00.787891
# Unit test for function max_headers
def test_max_headers():
    bool_0 = True
    int_0 = 222
    import http.client
    import httpie.utils
    str_0 = http.client._MAXHEADERS
    str_1 = httpie.utils.max_headers(int_0, bool_0)
    print(str_1)



# Generated at 2022-06-25 18:13:01.513366
# Unit test for function make_default_headers
def test_make_default_headers():
    pass



# Generated at 2022-06-25 18:13:09.418223
# Unit test for function collect_messages
def test_collect_messages():
    class Namespace:
        def __init__(self, some_property_0, some_property_1, some_property_2, some_property_3, some_property_4, some_property_5, some_property_6, some_property_7, some_property_8, some_property_9, some_property_10, some_property_11, some_property_12, some_property_13, some_property_14, some_property_15, some_property_16, some_property_17, some_property_18, some_property_19, some_property_20, some_property_21, some_property_22):
            self.data = some_property_0
            self.json = some_property_1
            self.form = some_property_2
            self.verbose = some_property_3
           