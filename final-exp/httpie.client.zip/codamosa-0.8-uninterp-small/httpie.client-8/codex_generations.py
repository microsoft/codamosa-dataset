

# Generated at 2022-06-25 18:05:24.810215
# Unit test for function finalize_headers
def test_finalize_headers():
    request_headers_dict_0 = RequestHeadersDict()
    request_headers_dict_1 = finalize_headers(request_headers_dict_0)

import httpie.cli as module_0


# Generated at 2022-06-25 18:05:32.184169
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    base_headers = RequestHeadersDict({"X-API-Token": "12345", "User-Agent": "Paw/3.1.8 (Macintosh; OS X/10.14.1) GCDHTTPRequest"})
    headers = make_default_headers(args)
    headers.update(base_headers)
    request_kwargs = make_request_kwargs(args, base_headers)
    # Assert
    assert request_kwargs["headers"] == headers


# Generated at 2022-06-25 18:05:36.746626
# Unit test for function collect_messages
def test_collect_messages():

    # Collect args.
    args_value_0 = dict()
    args_value_0['all'] = False
    args_value_0['auth'] = ()
    args_value_0['auth_plugin'] = None
    args_value_0['auth_type'] = 'basic'
    args_value_0['base_url'] = 'httpbin.org'
    args_value_0['body'] = '{}'
    args_value_0['body_columns'] = None
    args_value_0['body_reformat'] = False
    args_value_0['body_reformat_indent'] = 2
    args_value_0['boundary'] = '------------------------9fa5a5b5c5b5f254'
    args_value_0['ciphers'] = None
    args_value_

# Generated at 2022-06-25 18:05:42.318514
# Unit test for function collect_messages
def test_collect_messages():
    import httpie.cli.dicts as module_0
    import httpie.cli.dicts as module_1

    # Test with no arguments.
    kwargs_0 = {}
    request_headers_dict_0 = module_0.RequestHeadersDict()
    request_headers_dict_1 = finalize_headers(request_headers_dict_0)
    kwargs_0['headers'] = request_headers_dict_1
    kwargs_0['data'] = {}
    request_headers_dict_0 = module_0.RequestHeadersDict()
    request_headers_dict_1 = finalize_headers(request_headers_dict_0)
    kwargs_0['headers'] = request_headers_dict_1
    kwargs_0['form'] = True
    request_headers_dict_0

# Generated at 2022-06-25 18:05:44.395166
# Unit test for function max_headers
def test_max_headers():
    args_0 = argparse.Namespace()
    args_1 = args_0
    args_1.max_headers = 1
    assert True



# Generated at 2022-06-25 18:05:47.101700
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    result = collect_messages(args, config_dir, request_body_read_callback)


# Generated at 2022-06-25 18:05:48.869617
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(argparse.Namespace()) == {
        'allow_redirects': False,
        'timeout': None
    }

# Generated at 2022-06-25 18:05:50.951142
# Unit test for function collect_messages
def test_collect_messages():

    # Call collect_messages to test
    try:
        collect_messages()
    except:
        raise AssertionError("Should provide you with a specific error.")


# Generated at 2022-06-25 18:06:03.109528
# Unit test for function collect_messages

# Generated at 2022-06-25 18:06:05.551083
# Unit test for function finalize_headers
def test_finalize_headers():
    try:
        assert finalize_headers() == None
    except TypeError:
        pass

import httpie.cli.dicts as module_0


# Generated at 2022-06-25 18:06:29.728050
# Unit test for function make_default_headers
def test_make_default_headers():
	assert make_default_headers({'User-Agent': 'HTTPie/0.9.8'}) == ({'User-Agent': 'HTTPie/0.9.8'})
	assert make_default_headers({'User-Agent': 'HTTPie/0.9.8'}) == ({'User-Agent': 'HTTPie/0.9.8'})


# Generated at 2022-06-25 18:06:42.557415
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test input data
    args = argparse.NameSpace()
    args.verify = 'true'
    args.cert = 'path/to/cert'
    args.cert_key = 'path/to/key'
    args.proxy = ['127.0.0.1:1234', '127.0.0.1:5678']

    # Expected output

# Generated at 2022-06-25 18:06:51.258955
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    print("=========================== Test for function make_request_kwargs ===========================")
    # Test 1
    args = argparse.Namespace()
    args.data = dict()
    args.compress = None
    args.max_redirects = None
    args.json = None
    args.session = None
    args.traceback = None
    args.verbose = None
    args.debug = None
    args.output_file = None
    args.follow = None
    args.method = None
    args.check_status = None
    args.quiet = None
    args.all = None
    args.download = None
    args.timeout = None
    args.verify = None
    args.offline = None
    args.proxy = list()
    args.files = None
    args.form = None
    args

# Generated at 2022-06-25 18:06:57.089450
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from argparse import Namespace
    args = Namespace()
    args.proxy = []
    args.verify = 'true'
    args.cert = None
    result = make_send_kwargs_mergeable_from_env(args)
    assert result == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }
    args.proxy.append(Namespace(key='test_key', value='test_value'))
    args.verify = 'TruE'
    args.cert = 'test_cert'
    result = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-25 18:07:07.053087
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    var_0 = dict()
    parser = argparse.ArgumentParser()
    parser.add_argument('--proxy', dest='proxy', action='append', default=[])
    parser.add_argument('--verify', dest='verify', action='store_const', const=2, default=2)
    parser.add_argument('--cert', dest='cert', default=None)
    parser.add_argument('--cert-key', dest='cert_key', default=None)
    var_0['args'] = parser.parse_args()
    var_0['expected'] = dict()
    var_0['expected']['proxy'] = {p.key: p.value for p in var_0['args'].proxy}

# Generated at 2022-06-25 18:07:12.705218
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = int()
    args.allow_redirects = False

    kwargs = make_send_kwargs(args)
    print(kwargs)

    assert kwargs['timeout'] == int()
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-25 18:07:15.499848
# Unit test for function collect_messages
def test_collect_messages():
    collect_messages(
        args=var_0,
        config_dir=var_0,
        request_body_read_callback=var_0
    )



# Generated at 2022-06-25 18:07:18.659202
# Unit test for function make_default_headers
def test_make_default_headers():
    args = {'json': None, 'data': None, 'form': None, 'files': None}
    result = make_default_headers(args)

    expected = {'User-Agent': DEFAULT_UA}
    assert result == expected


# Generated at 2022-06-25 18:07:23.168744
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    var_0 = dict()
    var_1 = dict()
    response = make_request_kwargs(var_0, var_1)
    assert isinstance(response, dict)


# Generated at 2022-06-25 18:07:26.915044
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(test_case_0()) == {'proxies': {}, 'cert': None, 'verify': True, 'stream': True}


# Generated at 2022-06-25 18:08:06.097124
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Initialization
    args = argparse.Namespace()

    # Assigning values to instance attributes
    args._check_args = dict()
    args.max_headers = 5
    args.max_redirects = 10
    args.timeout = None
    args.auth = None
    args.auth_plugin = None
    args.headers = dict()
    args.multipart = False
    args.multipart_data = dict()
    args.data = None
    args.files = dict()
    args.form = False
    args.json = False
    args.output_file = sys.stdout
    args.method = 'GET'
    args.querystring = dict()
    args.url = 'http://httpbin.org/anything'
    args.params = dict()
    args.session = None

# Generated at 2022-06-25 18:08:15.664960
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = dict()
    var_9 = dict()
    var_10 = dict()
    var_11 = dict()
    var_12 = dict()
    var_13 = dict()
    var_14 = dict()
    var_15 = dict()
    var_16 = dict()
    var_17 = dict()
    var_18 = dict()
    var_19 = dict()
    var_20 = dict()
    var_21 = dict()
    var_22 = dict()
    var_23 = dict()
    var_24 = dict()

# Generated at 2022-06-25 18:08:26.427725
# Unit test for function collect_messages
def test_collect_messages():
    # arguments
    args = argparse.Namespace()
    args.verify = 'false'
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()
    args.data = dict()

# Generated at 2022-06-25 18:08:31.367683
# Unit test for function collect_messages
def test_collect_messages():
    var_0 = dict()
    var_1 = dict()
    try:
        assert None == collect_messages(var_0, var_1)
    except AssertionError as e:
        print(str(e))
        print("AssertionError: None == collect_messages(var_0, var_1)")


# Generated at 2022-06-25 18:08:43.469392
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = dict()
    args['verify'] = 'some /path/to/cert'
    args['cert'] = 'some /path/to/cert'
    args['cert_key'] = 'some /path/to/cert_key'
    args['proxy'] = dict()
    value_0 = make_send_kwargs_mergeable_from_env(args)
    assert(value_0 == dict({'verify': 'some /path/to/cert', 'cert': ('some /path/to/cert', 'some /path/to/cert_key'), 'proxies': dict(), 'stream': True}))
    assert(type(value_0) == dict)
    assert(type(make_send_kwargs_mergeable_from_env) == collections.abc.Callable)

# Generated at 2022-06-25 18:08:50.880254
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    data = {
        "test": "value"
    }
    files = []
    headers = RequestHeadersDict()
    headers['Content-Type'] = 'application/x-www-form-urlencoded'
    chunked = False
    offline = True
    content_length_header_value = "10"

    import argparse
    args = argparse.Namespace()
    args.method = "POST"
    args.url = "www.test.com"
    args.headers = headers
    args.json = True
    args.data = data
    args.form = False
    args.files = files
    args.chunked = chunked
    args.offline = offline
    args.content_length_header_value = content_length_header_value

    base_headers = RequestHeadersDict()
   

# Generated at 2022-06-25 18:08:57.121139
# Unit test for function max_headers
def test_max_headers():
    argv = [
        'http',
        '--headers',
        '',
        '--debug',
        'http://httpbin.org/get'
    ]
    parser = argparse.ArgumentParser()
    args = parser.parse_args(argv)
    context = max_headers(limit=10)
    assert(context is True)



# Generated at 2022-06-25 18:09:03.384498
# Unit test for function make_default_headers
def test_make_default_headers():
    args1 = argparse.Namespace()
    args1.json = True
    args1.form = True
    args1.data = {"bar": "baz"}
    headers1 = make_default_headers(args1)
    print(headers1)
    assert headers1['User-Agent'] == "HTTPie/1.0.2"
    assert headers1['Content-Type'] == "application/json"
    assert headers1['Accept'] == "application/json, */*;q=0.5"



# Generated at 2022-06-25 18:09:10.190897
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Setup
    class Args:
        def __init__(self):
            self.proxy = None
            self.verify = None
            self.cert = None
            self.cert_key = None

    args = Args()

    # Invocation
    kwargs = make_send_kwargs_mergeable_from_env(args)

    # Verification
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}


# Generated at 2022-06-25 18:09:13.810324
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'

    ret = make_send_kwargs_mergeable_from_env(args)

    assert ret['verify'] is True


# Generated at 2022-06-25 18:09:51.851715
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    pass


# Generated at 2022-06-25 18:10:00.451334
# Unit test for function max_headers
def test_max_headers():
    var_0 = dict()
    with max_headers(var_0) as v:
        var_1 = v
        var_2 = var_0
        var_3 = var_1
        var_4 = var_3
        var_4 = var_4
        var_4 = var_4
        var_4 = var_4
        var_4 = var_4
        var_4 = var_4
        var_4 = var_4
        var_4 = var_4
        var_5 = var_5
        var_5 = var_5
        var_5 = var_5
        var_5 = var_5
        var_5 = var_5
        var_5 = var_5
        var_5 = var_5
        var_5 = var_5
        var_5 = var_5

# Generated at 2022-06-25 18:10:05.130516
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Setup
    args = argparse.Namespace()
    args.data = None
    args.form = False
    args.json = None
    args.method = 'GET'
    args.url = 'https://www.google.com/'
    args.headers = dict()
    args.offline = False
    args.chunked = False
    args.multipart = False
    kwargs = make_request_kwargs(args)

    # Test cases
    assert kwargs['method'] == 'get'
    assert kwargs['url'] == args.url
    for key, value in make_default_headers(args).items():
        assert kwargs['headers'][key] == value
    assert kwargs['data'] is None

# Generated at 2022-06-25 18:10:10.124741
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    argv = sys.argv
    sys.argv = argv[:1] + ['--form', "{'username':'admin','password':'123456'}"] + argv[1:]
    args = argparse._ArgumentParser().parse_args()
    print(args)
    var_0 = make_request_kwargs(args)
    print(var_0)


# Generated at 2022-06-25 18:10:17.207313
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    cert = None
    if cert:
        cert = cert
        if cert_key:
            cert = cert, cert_key
    kwargs = {
        'proxies': {p.key: p.value for p in args.proxy},
        'stream': True,
        'verify': {
            'yes': True,
            'true': True,
            'no': False,
            'false': False,
        }.get(args.verify.lower(), args.verify),
        'cert': cert,
    }
    return kwargs

# Generated at 2022-06-25 18:10:26.405593
# Unit test for function collect_messages

# Generated at 2022-06-25 18:10:28.283379
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    dict_0 = dict()
    dict_0['timeout'] = None
    dict_0['allow_redirects'] = False
    return dict_0

# Generated at 2022-06-25 18:10:32.305561
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace
    args.json = None
    args.data = {}
    assert make_default_headers(args) is not None
    args.json = None
    args.data = []
    assert make_default_headers(args) is not None
    args.json = None
    args.data = ''
    assert make_default_headers(args) is not None


# Generated at 2022-06-25 18:10:38.205553
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Test class definition
    class class_0():
        def __init__(self):
            self.method = "POST"
            self.data = { "foo" : "bar" }
            self.json = True
            self.files = None
    
    class_1 = class_0()
    var_0 = make_request_kwargs(class_1)
    print("kwargs: %s" % var_0)

if __name__ == "__main__":
    #test_case_0()
    test_make_request_kwargs()

# Generated at 2022-06-25 18:10:50.864872
# Unit test for function collect_messages
def test_collect_messages():
    args_0 = test_case_0()
    config_dir_0 = Path()
    request_body_read_callback_0 = Callable[[bytes], None]
    print('Testing function collect_messages with:')
    print('    args = ' + argparse.Namespace.__str__(args_0))
    print('    config_dir = ' + Path.__str__(config_dir_0))
    print('    request_body_read_callback = ' + Callable[[bytes], None].__str__(request_body_read_callback_0))
    print('Expected:')
    print(Iterable[Union[requests.PreparedRequest, requests.Response]])
    print('Received:')

# Generated at 2022-06-25 18:11:24.518076
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    r = make_send_kwargs(args)
    assert r == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-25 18:11:27.042488
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_0 = {'timeout': 0, 'allow_redirects': False}
    dict_0 = make_send_kwargs(args_0)
    assert dict_0 == args_0


# Generated at 2022-06-25 18:11:32.317451
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = None
    base_headers_0 = dict({'User-Agent':'HTTPie/1.0.2'})
    func_0 = make_request_kwargs(args_0, base_headers_0)


# Generated at 2022-06-25 18:11:40.713263
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.cert = "./ckey.der"
    args.cert_key = "./ckey.key"
    args.proxy = '127.0.0.1'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    proxy = {'https': 'http://127.0.0.1'}
    assert kwargs.get('proxies')==proxy
    assert kwargs.get('stream')==True
    assert kwargs.get('verify') == True
    assert kwargs.get('cert') == ('./ckey.der','./ckey.key')



# Generated at 2022-06-25 18:11:44.048346
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    result = make_send_kwargs(1)
    if (result == "timeout" or result == "allow_redirects" or result == "allow_redirects"):
        print('True')
    else:
        print('False')

# Generated at 2022-06-25 18:11:54.052206
# Unit test for function make_default_headers
def test_make_default_headers():
    test_args0 = argparse.Namespace()
    test_args0.session_read_only = None
    test_args0.cert = None
    test_args0.json = None
    test_args0.session = None
    test_args0.data = None
    test_args0.auth = None
    test_args0.proxy = []
    test_args0.max_headers = None
    test_args0.offline = False
    test_args0.compress = None
    test_args0.debug = False
    test_args0.verify = None
    test_args0.cert_key = None
    test_args0.form = None
    test_args0.files = None
    test_args0.timeout = None
    test_args0.chunked = None
    test_

# Generated at 2022-06-25 18:11:54.626619
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    pass

# Generated at 2022-06-25 18:11:58.181052
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # >>> args = None
    # >>> make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}
    # True
    assert True


# Generated at 2022-06-25 18:12:01.560670
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = test_case_0()
    headers_0 = make_default_headers(args_0)
    # Expected Function: make_default_headers
    assert_equal(headers_0, {})


# Generated at 2022-06-25 18:12:12.940153
# Unit test for function collect_messages
def test_collect_messages():
    import pathlib
    import argparse

    print("Test 1: ")
    args_0 = argparse.Namespace()
    args_0.session = None
    args_0.session_read_only = None
    args_0.debug = None
    args_0.method = 'GET'
    args_0.url = 'http://httpbin.org/get'
    args_0.headers = [('Accept', 'application/json'), ('Accept', 'text/plain'), ('Accept', 'text/html')]
    args_0.params = []
    args_0.auth = None
    args_0.auth_type = 'basic'
    args_0.data = None
    args_0.json = None
    args_0.form = None
    args_0.pretty = None

# Generated at 2022-06-25 18:13:33.924026
# Unit test for function make_default_headers
def test_make_default_headers():
    dict_0 = dict()
    dict_0['Host'] = 'xkcd.com'
    dict_0['Accept-Encoding'] = 'gzip, deflate'
    dict_0['Accept'] = '*/*'
    dict_0['User-Agent'] = 'HTTPie/2.2.0'
    dict_0['Accept-Language'] = 'en-US,en;q=0.9,zh-HK;q=0.8,zh;q=0.7,zh-CN;q=0.6,zh-TW;q=0.5'
    dict_0['Connection'] = 'keep-alive'
    dict_0['Cache-Control'] = 'max-age=0'
    dict_0['Upgrade-Insecure-Requests'] = '1'

# Generated at 2022-06-25 18:13:39.468637
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # initialize args
    args = argparse.Namespace()
    args.timeout = None
    args.chrome_trace_file = None
    args.verbose = False
    args.debug = False
    args.offline = False
    args.session = False
    args.session_read_only = None
    args.allow_redirects = True
    args.max_redirects = None
    args.check_status = False
    args.headers = {'Content-Type': 'application/json'}
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.proxy = [{'key': 'http://localhost:3128', 'value': 'http://localhost:3128'}]
    args.files = None
    args.data = None

# Generated at 2022-06-25 18:13:40.862123
# Unit test for function collect_messages
def test_collect_messages():
    messages = collect_messages(args, config_dir, request_body_read_callback)


# Generated at 2022-06-25 18:13:47.444461
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-25 18:13:57.647050
# Unit test for function make_default_headers
def test_make_default_headers():
    print("testing make_default_headers()")
    # TestCase 0

# Generated at 2022-06-25 18:14:09.323818
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Data for which function will return dict of following form:
    #   {
    #        'proxies': {'key': 'value'},
    #        'stream': True,
    #        'verify': 'verify',
    #        'cert': 'cert',
    #   }
    test_data_0 = argparse.Namespace()
    # Assign values to test_data
    test_data_0.verify = 'verify'
    test_data_0.cert = 'cert'
    # Append to test_data objects
    test_data_0.proxy = [argparse.Namespace()]
    # Assign values to test_data.proxy[i]
    test_data_0.proxy[0].value = 'value'

# Generated at 2022-06-25 18:14:15.353603
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    setattr(args, 'verify', 'yes')
    setattr(args, 'files', None)
    setattr(args, 'url', 'https://httpbin.org/')
    setattr(args, 'data', '{"name":"test"}')
    setattr(args, 'json', True)
    setattr(args, 'form', False)
    setattr(args, 'chunked', False)
    setattr(args, 'headers', {'Content-Type': 'application/json'})
    setattr(args, 'method', 'POST')
    make_request_kwargs(args)


# Generated at 2022-06-25 18:14:24.815166
# Unit test for function make_default_headers
def test_make_default_headers():
    namespace = argparse.Namespace()
    namespace.json = True
    namespace.data = {}
    namespace.form = False
    namespace.files = None
    assert make_default_headers(namespace) == {
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    }
    namespace.json = False
    assert make_default_headers(namespace) == {
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT
    }
    namespace.json = False
    namespace.form = True

# Generated at 2022-06-25 18:14:33.223400
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    test_args = argparse.Namespace()
    base_headers = None
    callback_0 = lambda x: x
    result = make_request_kwargs(test_args, base_headers, callback_0)

# Generated at 2022-06-25 18:14:34.604279
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    assert type(make_send_kwargs(args)) == dict

