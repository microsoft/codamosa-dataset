

# Generated at 2022-06-25 18:05:26.533005
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    namespace_0 = None
    assert (make_send_kwargs_mergeable_from_env(namespace_0) == {'proxies': {}, 'stream': True, 'verify': None, 'cert': None})


# Generated at 2022-06-25 18:05:29.400195
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    namespace = argparse.Namespace()
    namespace.timeout = 1
    return make_send_kwargs(namespace)


# Generated at 2022-06-25 18:05:37.701670
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    namespace_0 = argparse.Namespace()
    namespace_1 = argparse.Namespace(verify='yes')
    namespace_2 = argparse.Namespace(verify='false')

    # case 0
    expected_dict_0 = {'proxies': {}, 'stream': True, 'verify': None, 'cert': None}
    assert make_send_kwargs_mergeable_from_env(namespace_0) == expected_dict_0

    # case 1
    expected_dict_1 = {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    assert make_send_kwargs_mergeable_from_env(namespace_1) == expected_dict_1

    # case 2

# Generated at 2022-06-25 18:05:39.386337
# Unit test for function max_headers
def test_max_headers():
    try:
        with max_headers(100.0):
            pass
    except Exception as e:
        assert False, f'Test failed with error: {e}'
    else:
        assert True


# Generated at 2022-06-25 18:05:40.069740
# Unit test for function collect_messages
def test_collect_messages():
    assert True == True



# Generated at 2022-06-25 18:05:42.613978
# Unit test for function collect_messages
def test_collect_messages():
    msg_list = collect_messages(args=None, config_dir=None)
    msg_response_count = 0
    for msg in msg_list:
        if isinstance(msg, requests.Response):
            msg_response_count += 1
    assert msg_response_count == 1

# Generated at 2022-06-25 18:05:45.905095
# Unit test for function build_requests_session
def test_build_requests_session():
    ssl_version = 'SSLv2'
    ciphers = 'ciphers'
    verify = True
    args_0 = build_requests_session(ssl_version, ciphers, verify)
    assert args_0 is not None, 'Expected a value but got None'


# Generated at 2022-06-25 18:05:54.076292
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test constructor without parameters
    args_0 = argparse.Namespace()
    args_0.verify = True
    args_0.cert = None
    args_0.cert_key = None
    args_0.proxy = None
    kwargs_0 = make_send_kwargs_mergeable_from_env(args_0)
    assert kwargs_0['verify'] == True
    assert kwargs_0['cert'] == None
    assert kwargs_0['proxies'] == None
    
    # Test constructor with parameters
    args_1 = argparse.Namespace()
    args_1.verify = 'false'
    args_1.cert = 'certificate.crt'
    args_1.cert_key = 'certificate.key'

# Generated at 2022-06-25 18:05:56.691127
# Unit test for function make_default_headers
def test_make_default_headers():
    namespace_0 = None
    request_headers_dict_0 = make_default_headers(namespace_0)
    assert request_headers_dict_0 == {'User-Agent': DEFAULT_UA}



# Generated at 2022-06-25 18:06:07.679592
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    base_headers = RequestHeadersDict({
        'User-Agent': 'test'
    })
    kwargs = make_request_kwargs(args, base_headers=base_headers)
    header_test = {}
    header_test['User-Agent'] = kwargs['headers']['User-Agent']
    header_test['User-Agent'] = 'test'
    assert header_test['User-Agent'] == 'test'
    method_test = 'GET'
    assert kwargs['method'] == method_test
    url_test = ''
    assert kwargs['url'] == url_test

# Generated at 2022-06-25 18:06:27.304467
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    timeout_0 = None
    allow_redirects_0 = False
    assert(make_send_kwargs(timeout_0) == {'timeout':None, 'allow_redirects':False})

# Generated at 2022-06-25 18:06:28.362131
# Unit test for function make_default_headers
def test_make_default_headers():
    assert 'User-Agent' in make_default_headers(None)


# Generated at 2022-06-25 18:06:41.181064
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    namespace = argparse.Namespace()
    namespace.verify = False
    namespace.proxy = [argparse.Namespace(key='https', value='192.168.86.38:8080')]
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(namespace)
    assert send_kwargs_mergeable_from_env['verify'] == False
    assert send_kwargs_mergeable_from_env['proxies'] == {'https': '192.168.86.38:8080'}
    assert send_kwargs_mergeable_from_env['stream'] == True
    assert send_kwargs_mergeable_from_env['cert'] == None


# Generated at 2022-06-25 18:06:50.757721
# Unit test for function collect_messages

# Generated at 2022-06-25 18:07:03.098880
# Unit test for function collect_messages
def test_collect_messages():

    namespace_0 = None
    config_dir_0 = None
    request_body_read_callback_0 = None
    function_result_0 = collect_messages(namespace_0, config_dir_0, request_body_read_callback_0)
    test_0 = function_result_0
    namespace_1 = None
    config_dir_1 = None
    request_body_read_callback_1 = None
    function_result_1 = collect_messages(namespace_1, config_dir_1, request_body_read_callback_1)
    test_1 = function_result_1
    namespace_2 = None
    config_dir_2 = None
    request_body_read_callback_2 = None

# Generated at 2022-06-25 18:07:06.769580
# Unit test for function max_headers
def test_max_headers():
    with pytest.raises(KeyError):
        with max_headers(None):
            raise KeyError


# Generated at 2022-06-25 18:07:12.098226
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    namespace_0 = argparse.Namespace()
    namespace_0.timeout = 3
    namespace_0.allow_redirects = False
    result_0 = make_send_kwargs(namespace_0)
    assert result_0 == {'timeout': 3, 'allow_redirects': False}

# Generated at 2022-06-25 18:07:18.962820
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    namespace_0 = argparse.Namespace(timeout=None, allow_redirects=False)
    assert make_send_kwargs(namespace_0) == {
        'timeout': None,
        'allow_redirects': False,
    }
    namespace_1 = argparse.Namespace(timeout='', allow_redirects='')
    assert make_send_kwargs(namespace_1) == {
        'timeout': '',
        'allow_redirects': '',
    }


# Generated at 2022-06-25 18:07:20.181171
# Unit test for function make_default_headers
def test_make_default_headers():
    x = make_default_headers(None)
    assert x.get('User-Agent') == 'HTTPie/0.9.9'


# Generated at 2022-06-25 18:07:26.210002
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:08:02.665624
# Unit test for function build_requests_session
def test_build_requests_session():
    # 2 basic tests

    # Test case 1
    test_case_0()



# Generated at 2022-06-25 18:08:08.779926
# Unit test for function make_default_headers

# Generated at 2022-06-25 18:08:17.790816
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    timeout_0 = None
    allow_redirects_0 = False
    kwargs_0 = {
        'timeout': timeout_0,
        'allow_redirects': allow_redirects_0,
    }
    bool_0 = True
    verify_0 = True
    cert_0 = None
    kwargs_1 = {
        'proxies': {
            'p.key': 'p.value'},
        'stream': bool_0,
        'verify': verify_0,
        'cert': cert_0
    }

# Generated at 2022-06-25 18:08:23.081075
# Unit test for function collect_messages
def test_collect_messages():
    args_0 = argparse.Namespace()
    args_0.url = ''
    config_dir_0 = Path()
    request_body_read_callback_0 = lambda chunk: chunk
    messages_0 = collect_messages(args_0, config_dir_0, request_body_read_callback_0)



# Generated at 2022-06-25 18:08:32.642073
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = argparse.Namespace(ciphers=None, cert=None, cert_key=None, chunked=False, compress=0, debug=False, data=None, form=False, headers=[], http_version='HTTP/1.1', json=False, method='GET', offline=False, params=[], path_as_is=False, proxy=[], session=None, session_read_only=None, upload_file=None, url=None, verify='yes', verbose=1)
    kwargs_0 = make_send_kwargs_mergeable_from_env(args_0)
    assert kwargs_0 == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

# Generated at 2022-06-25 18:08:44.837288
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from pathlib import Path
    main_0 = None
    for main_0 in plugin_manager.get_main_plugins():
        pass
    config_dir_0 = Path('./httpie/config')
    resources_path_0 = None
    for resources_path_0 in main_0._get_resources_paths():
        pass
    config_path_0 = None
    for config_path_0 in main_0._get_config_paths(config_dir_0):
        pass
    parser_0 = argparse.ArgumentParser(
        description='CLI HTTP client')

# Generated at 2022-06-25 18:08:47.775829
# Unit test for function make_default_headers
def test_make_default_headers():
    bool_0 = True
    dict_0 = {}
    dict_0 = make_default_headers(dict_0)
    assert dict_0["Accept"] == "application/json, */*;q=0.5"


# Generated at 2022-06-25 18:08:56.751273
# Unit test for function collect_messages
def test_collect_messages():
    class Namespace:
        def __init__(self, json, offline):
            self.json, self.offline = json, offline
        def __getattr__(self, name):
            return None
    args_0 = Namespace(False, False)
    config_dir_0 = '/'
    request_body_read_callback_0 = lambda body: body
    try:
        collect_messages(args_0, config_dir_0, request_body_read_callback_0)
    except Exception:
        print('An exception occured')


# Generated at 2022-06-25 18:09:05.529755
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.plugins import builtin
    from httpie import __version__
    from contextlib import contextmanager
    from typing import Callable, Iterable, Union, List, Tuple
    import json
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.ssl import AVAILABLE_SSL_VERSION_ARG_MAPPING, HTTPieHTTPSAdapter
    from httpie.uploads import (
        compress_request, prepare_request_body,
        get_multipart_data_and_content_type,
    )
    from httpie.utils import get_expired_cookies, repr_dict
    from httpie.cli.argtypes import AuthCredentials

# Generated at 2022-06-25 18:09:13.503729
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = argparse.Namespace()
    args_0.data = None
    args_0.form = False
    args_0.json = False
    args_0.session_read_only = False
    args_0.max_headers = None
    args_0.auth_plugin = None
    args_0.session = None
    args_0.path_as_is = False
    args_0.compress = False
    args_0.debug = False
    args_0.offline = False
    args_0.chunked = False
    args_0.verify = 'yes'
    args_0.cert = None
    args_0.cert_key = None
    args_0.ssl_version = None
    args_0.ciphers = None
    args_0.max_redirect

# Generated at 2022-06-25 18:10:23.203485
# Unit test for function max_headers
def test_max_headers():
    req = max_headers(1)
    assert isinstance(req,contextmanager)


# Generated at 2022-06-25 18:10:27.552351
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace()
    args_0.json = True
    args_0.form = True
    args_0.data = True
    headers_0 = make_default_headers(args_0)
    assert headers_0['Accept'] == JSON_ACCEPT
    assert headers_0['Content-Type'] == JSON_CONTENT_TYPE

# Generated at 2022-06-25 18:10:35.904052
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    bool_0 = False
    # bool_0 = True
    class object_1:
        pass
    class object_2:
        class object_3:
            def __init__(self, str_0, str_1):
                self.arg_0 = str_0
                self.arg_1 = str_1
            def __len__(self):
                return 0
    class object_4:
        class object_5:
            def __init__(self, str_0):
                self.arg_0 = str_0
            def items(self):
                return None
    class object_6:
        class object_7:
            pass
        class object_8:
            def __init__(self, str_0, str_1):
                self.arg_0 = str_0

# Generated at 2022-06-25 18:10:38.283352
# Unit test for function max_headers
def test_max_headers():
    parser = argparse.ArgumentParser()



# Generated at 2022-06-25 18:10:49.342805
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = 'header'
    args.form = False
    args.json = 'value'
    input_headers = [(args.data, args.form, args.json)]
    input_headers_str = 'header\nFalse\nvalue\n'

    output_headers = make_default_headers(args)
    output_headers_str = 'User-Agent: HTTPie/' + __version__ + '\nAccept: application/json, */*;q=0.5\nContent-Type: application/json' + '\n'

    assert input_headers_str == output_headers_str


# Generated at 2022-06-25 18:10:58.265424
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    kwargs = {
        'method': 'POST',
        'url': 'http://httpbin.org/post',
        'headers': {'User-Agent': DEFAULT_UA},
        'data': 'abc',
        'params': ('q3', 'r3'),
    }
    headers = {'Host': 'httpbin.org'}
    data = {'q3': 'r3'}

# Generated at 2022-06-25 18:11:08.157487
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class Namespace(object):
        def __init__(self, timeout):
            self.timeout = timeout
    args_0 = make_send_kwargs(Namespace(1))
# <class 'dict'> expected.
    assert type(args_0) == dict
    assert len(args_0) == 2
    test_dict = {'timeout': 1, 'allow_redirects': False}
    assert args_0 == test_dict
    args_1 = make_send_kwargs(Namespace(0))
# <class 'dict'> expected.
    assert type(args_1) == dict
    assert len(args_1) == 2
    test_dict = {'timeout': None, 'allow_redirects': False}
    assert args_1 == test_dict


# Generated at 2022-06-25 18:11:17.566274
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "POST"
    args.url = "https://httpie.org/"
    args.data = "data"
    args.json = True
    args.form = False
    args.files = True
    args.multipart = True

    # Test with default parameters
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == args.method.lower()
    assert kwargs['url'] == args.url
    assert kwargs['headers'] == make_default_headers(args)

    args.json = False
    args.form = True
    kwargs = make_request_kwargs(args)
    assert kwargs['headers'] == make_default_headers(args)

    args.json = True
    args.form

# Generated at 2022-06-25 18:11:26.781264
# Unit test for function build_requests_session
def test_build_requests_session():
    bool_0 = True
    ciphers_0 = 'foo'
    ssl_version_0 = 'foo'
    verify_0 = False
    session_0 = build_requests_session(verify_0, ssl_version_0, ciphers_0)
    str_0 = 'foo'
    str_1 = 'bar'
    dict_0 = {str_1: str_0}
    session_0.mount(str_0, dict_0)
    dict_1 = {str_1: dict_0}
    dict_2 = dict_1
    session_0 = build_requests_session(verify_0, ssl_version_0, ciphers_0)
    session_0.mount(str_0, dict_2)

# Generated at 2022-06-25 18:11:32.181406
# Unit test for function make_default_headers
def test_make_default_headers():
    argparse.Namespace.json = False
    argparse.Namespace.form = False
    argparse.Namespace.data = {}
    val_0 = make_default_headers(argparse.Namespace)

