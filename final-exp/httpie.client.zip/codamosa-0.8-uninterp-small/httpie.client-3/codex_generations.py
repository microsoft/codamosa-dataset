

# Generated at 2022-06-25 18:05:34.783231
# Unit test for function make_default_headers
def test_make_default_headers():
    str_0 = "User-Agent"
    str_1 = "HTTPie/1.0.2"
    dict_0 = {str_0: str_1}
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_8 = dict_7
    dict_9 = dict_8
    dict_10 = dict_9
    dict_11 = dict_10
    dict_12 = dict_11
    dict_13 = dict_12
    dict_14 = dict_13
    dict_15 = dict_14
    dict_16 = dict_15
    dict_17 = dict_16
    dict_18

# Generated at 2022-06-25 18:05:38.258362
# Unit test for function make_default_headers
def test_make_default_headers():
    # Arguments
    # Arguments
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = False
    args.default_headers = RequestHeadersDict()
    args.headers = RequestHeadersDict()
    args.auth = None
    args.auth_plugin = None

    # Return
    # Return value
    # v = make_default_headers(args)
    # assert v == None
    assert make_default_headers(args)



# Generated at 2022-06-25 18:05:42.613412
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace()
    args_0.files = None
    args_0.data = None
    args_0.form = False
    args_0.json = False
    args_0.headers = {}
    bool_0 = False
    args_0.offline = bool_0
    args_0.chunked = bool_0
    ret = make_default_headers(args_0)
    assert ret == {'User-Agent': f'HTTPie/{__version__}'}



# Generated at 2022-06-25 18:05:50.572218
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    argparse_mock = argparse.Namespace()
    argparse_mock.proxy = [argparse.Namespace(key = 'http', value = '127.0.0.1'), argparse.Namespace(key = 'https', value = '127.0.0.1')]
    argparse_mock.verify = 'yes'
    argparse_mock.cert = 'cert.pem'
    argparse_mock.cert_key = 'cert_key.pem'
    expected_dict = {'proxies': {'http': '127.0.0.1', 'https': '127.0.0.1'}, 'stream': True, 'verify': True, 'cert': ('cert.pem', 'cert_key.pem')}
    assert_dict = make_send_kwargs_

# Generated at 2022-06-25 18:05:51.762913
# Unit test for function max_headers
def test_max_headers():
    assert max_headers == max_headers(int)


# Generated at 2022-06-25 18:06:04.160466
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:06:13.461971
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from contextlib import contextmanager
    from pathlib import Path
    from httpie.utils import get_expired_cookies
    import sys
    import http.client
    import httpie.context
    import httpie.cli.argtypes
    import requests
    import httpie.plugins.builtin
    import httpie.plugins.registry

    param_0 = argparse.Namespace()
    param_0.headers = {
        'User-Agent': 'HTTPie/0.9.9',
        'Accept': '*/*',
        'Content-Type': 'application/json'
    }
    param_0.method = 'POST'
    param_0.data = json.dumps({'share': 'true'})
    param_0.json = True
    param_0.auth = None
    param

# Generated at 2022-06-25 18:06:22.418001
# Unit test for function collect_messages
def test_collect_messages():
    str_0 = 'http://localhost:8080/v1/'
    str_1 = 'GET'
    argv = ['/usr/local/bin/http', str_1, str_0]
    parser = argparse.ArgumentParser()
    args = parser.parse_args(argv[1:])
    str_2 = '/Users/<username>/Library/Application Support/httpie'
    pathlib_path_0 = Path(str_2)
    collect_messages(args, pathlib_path_0)

# Generated at 2022-06-25 18:06:31.920578
# Unit test for function collect_messages
def test_collect_messages():
    args_1 = argparse.Namespace()
    args_1.auth = None
    args_1.auth_type = 'basic'
    args_1.auth_plugin = None
    args_1.body = None
    args_1.body_per_request = None
    args_1.follow = False
    args_1.headers = RequestHeadersDict()
    for i in range(random.randint(2, (2 * 2) + 1)):
        args_1.headers[utf8str(random.randint(0, (10 * 10) + 1))] = utf8str(random.randint(0, (10 * 10) + 1))
    args_1.ignore_stdin = False
    args_1.timeout = random.randint(2, (2 * 2) + 1)
    args

# Generated at 2022-06-25 18:06:39.508444
# Unit test for function collect_messages
def test_collect_messages():
    # <Value '[]' (type list)> is not JSON serializable
    # <https://github.com/pallets/werkzeug/issues/1558>
    # <https://github.com/pallets/werkzeug/pull/1559>
    # TODO: fix this and uncomment the following assertion.
    # assert test_collect_messages_0() == test_collect_messages_0()
    pass

test_case_0()

test_collect_messages()

# Generated at 2022-06-25 18:07:06.251546
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    args = argparse.Namespace()
    args.method = 'post'
    args.url = 'https://poc.simple.com/v1/uicontroller?op=get'
    args.headers = {
        'Content-Type': 'application/json'
    }
    args.data = {
        'key1': 'val1',
        'key2': 'val2'
    }
    args.json = 'True'
    args.auth = None
    args.params = '{key1:val1,key2:val2}'
    make_request_kwargs(args)



# Generated at 2022-06-25 18:07:08.010152
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None):
        pass


# Generated at 2022-06-25 18:07:13.506131
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    data_0 = 'expect'
    args_0 = argparse.Namespace()
    args_0.data = data_0
    request_kwargs_0 = make_request_kwargs(args_0)
    isinstance_0 = isinstance(request_kwargs_0['data'], bytes)
    assert isinstance_0



# Generated at 2022-06-25 18:07:25.673222
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.headers = {"Accept": "applcation/json", "Content-Type": "applcation/json"}
    args.headers = make_default_headers(args)
    args.headers = finalize_headers(args.headers)
    args.timeout = 10
    args.json = "json data"
    args.data = "data"
    args.auth = "auth"
    kwargs = {
        "timeout": args.timeout,
        "allow_redirects": False
    }
    # Unit test for function make_send_kwargs
    assert make_send_kwargs(args) == kwargs
    # Unit test for function make_request_kwargs
    request_kwargs = make_request_kwargs(args)

# Generated at 2022-06-25 18:07:33.864404
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        auth='',
        auth_type='',
        cert='',
        cert_key='',
        check_status=False,
        chunked=False,
        compress=False,
        debug=False,
        download=False,
        form=[],
        headers={},
        follow=False,
        ignore_stdin='',
        json=[],
        max_headers=None,
        method='GET',
        multipart_data=[],
        offline=False,
        output=None,
        params='',
        path_as_is=False,
        probe=False,
        proxy=[],
        session='',
        session_read_only='',
        verbose=0,
        version=False,
        verify=True,
        data=[],
        files=[])


# Generated at 2022-06-25 18:07:36.629046
# Unit test for function build_requests_session
def test_build_requests_session():
    bool_0 = False
    # Should not crash
    session_0 = build_requests_session(bool_0)
    assert session_0 is not None



# Generated at 2022-06-25 18:07:43.897602
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    namespace_0 = argparse.Namespace()
    namespace_0.timeout = None

    result_without_callbacks = make_send_kwargs(namespace_0)
    assert result_without_callbacks == {
        'timeout': None,
        'allow_redirects': False
    }, 'result_without_callbacks: {0}'.format(result_without_callbacks)



# Generated at 2022-06-25 18:07:46.349035
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # TODO: Come up with test case(s) that satisfy the coverage criteria.
    # The coverage criteria is not met right now.

    pass



# Generated at 2022-06-25 18:07:55.819294
# Unit test for function make_default_headers
def test_make_default_headers():
    print("Test make_default_headers function")
    arg_parse = argparse.Namespace()
    arg_parse.json = False
    arg_parse.data = False
    arg_parse.form = False
    result = make_default_headers(arg_parse)
    print("Testcase 0: No argument")
    assert result == {'User-Agent': 'HTTPie/0.9.9'}, "Testcase 0 failed"
    
    arg_parse.json = True
    arg_parse.data = True
    print("Testcase 1: json -> form")
    result = make_default_headers(arg_parse)
    #assert result.get('Accept') == 'application/json, */*;q=0.5'
    assert result.get('Content-Type') == 'application/json'

# Generated at 2022-06-25 18:08:08.167135
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    test_kwargs = {'proxies': {'http': 'http://10.10.1.10:3128/'},
                                 'timeout': 30, 'verify': True,
                                 'stream': True, 'cert': True,
                                 'allow_redirects': False}
    # enter the parameters
    args = argparse.Namespace()
    args.data = None
    args.json = False
    args.proxy = ['http://10.10.1.10:3128']
    args.timeout = 30
    args.verify = 'True'
    args.cert = True
    args.cert_key = False
    kwargs = make_send_kwargs_mergeable_from_env(args)
    print(kwargs)

# Generated at 2022-06-25 18:08:37.737498
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_0 = namedtuple('Args', ['timeout', 'follow'])(timeout = float('NaN'), follow = True)
    output_0 = make_send_kwargs(args_0)
    assert len(output_0) == 2
    assert output_0['allow_redirects'] == False
    assert output_0['timeout'] == None
    assert output_0.get('timeout') == None
    assert output_0.get('k') == None
    assert output_0.get('allow_redirects') == False
    args_1 = namedtuple('Args', ['timeout', 'follow'])(timeout = 10, follow = True)
    output_1 = make_send_kwargs(args_1)
    assert len(output_1) == 2
    assert output_1['allow_redirects'] == False

# Generated at 2022-06-25 18:08:40.010293
# Unit test for function max_headers
def test_max_headers():
    max_headers_0 = max_headers(0)
    assert callable(max_headers_0)

# Generated at 2022-06-25 18:08:41.141234
# Unit test for function max_headers
def test_max_headers(): # body of the unit test
    assert True == True

# Generated at 2022-06-25 18:08:49.789794
# Unit test for function make_default_headers
def test_make_default_headers():
    from requests.auth import HTTPBasicAuth
    args = argparse.Namespace()
    args.auth = HTTPBasicAuth('test_user', 'test_password')
    args.auth_plugin = None
    args.data = []
    args.files = []
    args.form = []
    args.headers = []
    args.method = 'GET'
    args.params = []
    args.url = 'http://www.google.com'
    args.json = False
    args.offline = False
    args.chunked = False
    args.verify = False
    args.compress = False
    args.timeout = 0
    args.debug = False
    args.headers_only = False
    args.follow = False
    args.history_format = 0
    args.output = None
    args.download = False

# Generated at 2022-06-25 18:09:01.149293
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    bool_0 = False
    str_0 = 'boolean'
    dict_0 = {}
    dict_1 = {}
    dict_0['yes'] = True
    dict_0['true'] = True
    dict_0['no'] = False
    dict_0['false'] = False
    dict_1['verify'] = dict_0
    dict_1['proxies'] = dict_0
    dict_1['stream'] = True
    dict_1['cert'] = None
    var_0 = make_send_kwargs_mergeable_from_env(dict_1)
    dict_0 = {}
    dict_1 = {}
    dict_0['yes'] = True
    dict_0['true'] = True
    dict_0['no'] = False
    dict_0['false'] = False
    dict

# Generated at 2022-06-25 18:09:07.398632
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    the_arg = argparse.Namespace()
    test_name = 'the_test_name'
    test_value = 'the_test_value'
    setattr(the_arg, test_name, test_value)
    the_result = make_send_kwargs(the_arg)
    assert the_result[test_name] == test_value

# Generated at 2022-06-25 18:09:13.517794
# Unit test for function max_headers
def test_max_headers():
    val_0 = "http://www.example.com"
    val_1 = "http://www.example.com"
    res = ensure_path_as_is(val_0, val_1)
    assert res == val_1

# Generated at 2022-06-25 18:09:14.783553
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    request_kwargs = make_request_kwargs()


# Generated at 2022-06-25 18:09:23.966727
# Unit test for function collect_messages
def test_collect_messages():
    from argparse import Namespace
    from io import BytesIO
    from pathlib import Path
    from typing import Callable
    import sys

    class mock_httpie_session:
        def __init__(self):
            self.auth = {'type': 'mock_httpie_session_auth_type', \
            'raw_auth': 'mock_httpie_session_raw_auth'}

    class mock_prepared_request:
        def get_full_url(self):
            return 'mock_prepared_request_get_full_url'

    def mock_get_httpie_session(config_dir: Path, \
        session_name: str, host: str, url: str) -> mock_httpie_session:
        return mock_httpie_session


# Generated at 2022-06-25 18:09:25.865612
# Unit test for function max_headers
def test_max_headers():
    with max_headers(0):
        pass


# Generated at 2022-06-25 18:09:53.914311
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    headers = make_default_headers(args)
    if(len(headers) == 1 and headers['User-Agent'] == DEFAULT_UA):
        print("Test make_default_headers is successful")
    else:
        print("Test make defalut headers failed")


# Generated at 2022-06-25 18:10:01.955897
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = argparse.ArgumentParser()
    args_0 = args_0.parse_args([])
    args_0.verify = 'yes'
    args_0.cert = 'test_value_3'
    args_0.cert_key = 'test_value_4'
    test_make_send_kwargs_mergeable_from_env_0 = make_send_kwargs_mergeable_from_env(args_0)

    assert test_make_send_kwargs_mergeable_from_env_0 == {'proxies': {}, 'stream': True, 'verify': True, 'cert': 'test_value_3'}

    args_1 = argparse.ArgumentParser()
    args_1 = args_1.parse_args([])
    args_1.verify

# Generated at 2022-06-25 18:10:08.954630
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    inputs = [
        # divisible
        "1",
        # non divisible
        "2",
    ]
    outputs = [
        # divisible
        "1",
        # non divisible
        "2",
    ]
    for index in range(0, len(inputs)):
        if make_send_kwargs(inputs[index]) != outputs[index]:
            raise Exception("Wrong output for the input: " + str(inputs[index]))


# Generated at 2022-06-25 18:10:10.429997
# Unit test for function max_headers
def test_max_headers():
    bool_0 = False
    with max_headers(bool_0):
        pass


# Generated at 2022-06-25 18:10:18.488049
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_0 = argparse.Namespace()
    kwargs_0 = make_send_kwargs(args_0)

    assert type(kwargs_0) == dict
    assert kwargs_0['timeout'] is None
    assert kwargs_0['allow_redirects'] is False
    args_1 = argparse.Namespace()
    args_1.timeout = 300.0
    kwargs_1 = make_send_kwargs(args_1)

    assert type(kwargs_1) == dict
    assert kwargs_1['timeout'] == 300.0
    assert kwargs_1['allow_redirects'] is False


# Generated at 2022-06-25 18:10:23.613682
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    arg_0 = argparse.Namespace()
    arg_0.__dict__ = {'timeout': 2}
    assert make_send_kwargs(arg_0) == {'timeout': 2, 'allow_redirects': False}
    arg_0 = argparse.Namespace()
    arg_0.__dict__ = {}
    assert make_send_kwargs(arg_0) == {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-25 18:10:24.617429
# Unit test for function build_requests_session
def test_build_requests_session():
    print(1)
    return


# Generated at 2022-06-25 18:10:31.740856
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    arg_0 = argparse.Namespace
    arg_0.cert = 'foo'
    arg_0.cert_key = 'bar'
    arg_0.proxy = [('localhost', 12345)]
    arg_0.verify = True
    assert make_send_kwargs_mergeable_from_env(arg_0) == {
        'cert': ('foo', 'bar'),
        'proxies': {'localhost': 12345},
        'stream': True,
        'verify': True,
    }

if __name__ == '__main__':
    test_case_0()
    test_make_send_kwargs_mergeable_from_env()

# Generated at 2022-06-25 18:10:40.023865
# Unit test for function collect_messages
def test_collect_messages():
    from requests.models import URLError
    from httpie import ExitStatus
    from httpie.context import Environment

    class MockNamespace0:
        def __init__(self):
            self.json = None
            self.form = None
            self.headers = None
            self.method = 'GET'
            self.data = None
            self.verify = 'no'
            self.download = False
            self.timeout = None
            self.upload = None
            self.download_resume_from = None
            self.auth = None
            self.cert = 'test_value'
            self.cert_key = 'test_value'
            self.max_redirects = None
            self.proxy = None
            self.traceback = False
            self.debug = False
            self.follow = True

# Generated at 2022-06-25 18:10:52.576743
# Unit test for function max_headers
def test_max_headers():
    _204_headers = "HTTP/1.1 200 OK\r\n" + "Content-Type: text/html\r\n" * 200 + "Date: Thu, 23 Feb 2017 03:48:21 GMT\r\n" + "\r\n" + ""
    first_header_len = 14
    header_content_type_len = len("Content-Type: text/html\r\n")
    header_date_len = len("Date: Thu, 23 Feb 2017 03:48:21 GMT\r\n")
    limit = 100

# Generated at 2022-06-25 18:11:39.196271
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
  args = argparse.Namespace()
  base_headers = make_default_headers(args)
  request_body_read_callback = lambda chunk: chunk
  result_list = make_request_kwargs(args, base_headers, request_body_read_callback)
  assert result_list == {'method': 'get', 'url': 'https://httpbin.org', 'headers': {'User-Agent': 'HTTPie/1.0.3', 'Accept': 'application/json, */*;q=0.5'}, 'data': None, 'auth': None, 'params': []}

# Generated at 2022-06-25 18:11:49.008111
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Input arguments:
    args = argparse.Namespace(
        cert = '',
        cert_key = '',
        debug = False,
        files = [],
        form = False,
        headers = {},
        json = False,
        max_redirects = None,
        max_headers = 0,
        multipart = False,
        multipart_data = False,
        offline = False,
        params = [],
        path_as_is = False,
        proxy = [],
        session = None,
        session_read_only = False,
        ssl_version = None,
        timeout = None,
        traceback = False,
        verify = '',
        auth_plugin = None
    )

    result = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-25 18:11:52.826528
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    namespace_0 = argparse.Namespace(proxy=[], verify='yes', cert='', cert_key='')
    kwargs_0 = make_send_kwargs_mergeable_from_env(namespace_0)
    print(kwargs_0)


# Generated at 2022-06-25 18:12:01.177905
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    session = requests.Session()
    kwargs = {"method": "get",
              "url": "https://api.github.com/user",
              "headers": {'User-Agent': 'Mozilla/5.0'},
              "data": "{\"login\": \"grantcc\"}",
              "auth": None,
              "params": ""}
    request_kwargs = make_request_kwargs(session, kwargs)
    print(request_kwargs)


if __name__ == "__main__":
    test_case_0()
    test_make_request_kwargs()

# Generated at 2022-06-25 18:12:08.242255
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    _argse = type('_argse', (), {
        'name': '_argse',
        'headers': {
            'foo': 'bar',
            'baz': 'qux'
        }
    })
    # Function definition
    make_request_kwargs(_argse,  request_body_read_callback=lambda chunk: chunk)



# Generated at 2022-06-25 18:12:09.114667
# Unit test for function collect_messages
def test_collect_messages():
    assert False


# Generated at 2022-06-25 18:12:14.049054
# Unit test for function collect_messages
def test_collect_messages():
    assert 1 == 1
    args = argparse.ArgumentParser()
    args.offline = True
    args.debug = False
    config_dir = Path('/home/runner/work/httpie/httpie/httpie')
    request_body_read_callback = lambda chunk: chunk
    if True:
        return collect_messages(args, config_dir, request_body_read_callback)

    return collect_messages(args, config_dir)



# Generated at 2022-06-25 18:12:22.922363
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Setting up the test
    method_0 = "test"
    url_0 = "http://www.google.com"
    headers_0 = {
        "1": "test",
        "2": "test"
    }
    data_0 = "test_data"
    auth_0 = "basic"
    params_0 = {
        "1": "test",
        "2": "test"
    }
    base_headers_0 = {
        "3": "test",
        "4": "test"
    }

    # Testing the function

# Generated at 2022-06-25 18:12:27.673382
# Unit test for function max_headers
def test_max_headers():
    from contextlib import contextmanager

    import sys

    @contextmanager
    def max_headers(limit):
        # <https://github.com/httpie/httpie/issues/802>
        # noinspection PyUnresolvedReferences
        orig = sys.modules['http.client']._MAXHEADERS
        sys.modules['http.client']._MAXHEADERS = limit or float('Inf')
        try:
            yield
        finally:
            sys.modules['http.client']._MAXHEADERS = orig



# Generated at 2022-06-25 18:12:30.329799
# Unit test for function max_headers
def test_max_headers():
    limit = 4
    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = limit
    with max_headers(limit) as result:
        pass
    assert http.client._MAXHEADERS == orig


# Generated at 2022-06-25 18:14:10.228002
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify='no'
    args.proxy=[]
    args.cert=''
    args.cert_key=''
    
    output=make_send_kwargs_mergeable_from_env(args)
    print(output)
    assert output == {'proxies': {}, 'stream': True, 'verify': False, 'cert': ''}


# Generated at 2022-06-25 18:14:13.229228
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    results = make_send_kwargs_mergeable_from_env(args)
    assert results == {'cert': None, 'proxies': {}, 'stream': True, 'verify': True}
    

# Generated at 2022-06-25 18:14:15.440197
# Unit test for function collect_messages
def test_collect_messages():
    # Unit tests for function collect_messages

    def test_case_0():
        # TODO: add test cases.
        pass

    test_case_0()


# Generated at 2022-06-25 18:14:24.895103
# Unit test for function make_send_kwargs

# Generated at 2022-06-25 18:14:33.261042
# Unit test for function make_default_headers
def test_make_default_headers():
    test_kwargs = {'input':{'data':{'key1':'value1'},'json':True,'form':False,'files':False},
                   'output':{'Accept':'application/json, */*;q=0.5','Content-Type':'application/json'}}
    test_kwargs2 = {'input':{'data':None,'json':False,'form':True,'files':False},
                    'output':{'Content-Type':'application/x-www-form-urlencoded; charset=utf-8'}}
    test_kwargs3 = {'input':{'data':None,'json':False,'form':False,'files':False},
                    'output':{}}

# Generated at 2022-06-25 18:14:40.821683
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    valid_args_0 = argparse.Namespace()
    valid_args_0.json = False
    valid_args_0.auth = ''
    valid_args_0.form = True
    valid_args_0.multipart_data = None
    valid_args_0.method = 'GET'
    valid_args_0.url = 'http://foo.bar'
    valid_args_0.params = dict()
    valid_args_0.headers = dict()
    valid_args_0.files = dict()
    valid_args_0.data = dict()
    valid_args_0.multipart = False
    valid_args_0.chunked = False

# Generated at 2022-06-25 18:14:42.559445
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace()
    obj_0 = make_default_headers(args_0)
    bool_0 = obj_0


# Generated at 2022-06-25 18:14:49.473327
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(auth=None, auth_type='basic', chunked=False, ciphers=None,
                              compression=None, debug=False, data=None,
                              form=False, headers=RequestHeadersDict({}),
                              http2=False, ignore_stdin=False, json=False,
                              max_redirects=30, method='GET', output_file=None,
                              params=None, out_file=None, path_as_is=False,
                              print_body=True, suppress_hooks=False,
                              timeout=None, traceback=False, url=None, verify=True,
                              verify_all=False, verbose=False, allow_redirects=False,
                              files=None, follow=False, offline=False)

    headers

# Generated at 2022-06-25 18:14:56.777578
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.session = None
    args.session_read_only = None
    args.auth_plugin = None
    args.debug = False
    args.path_as_is = None
    args.compress = 0
    args.offline = False
    args.max_redirects = None
    args.follow = True
    args.all = None
    args.method = 'GET'
    args.url = 'http://httpbin.org'
    args.headers = {'Host': 'httpbin.org', 'Accept': 'application/json'}
    args.data = None
    args.json = None
    args.form = None
    args.files = None
    args.auth = None
    args.auth_type = None
    args.params = {}
    args.data

# Generated at 2022-06-25 18:15:06.674673
# Unit test for function make_send_kwargs_mergeable_from_env