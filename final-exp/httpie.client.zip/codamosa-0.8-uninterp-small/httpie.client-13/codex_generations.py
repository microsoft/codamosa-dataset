

# Generated at 2022-06-25 18:05:38.978042
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = None
    
    max_headers(100)
    http.client._MAXHEADERS = None


# Generated at 2022-06-25 18:05:41.954312
# Unit test for function make_default_headers
def test_make_default_headers():
    import httpie.cli.argtypes as module_argtypes
    import httpie.cli.dicts as module_dicts

    args_0=module_argtypes.Namespace()
    
    assert make_default_headers(args_0) == {'User-Agent': 'HTTPie/1.0.3'}


# Generated at 2022-06-25 18:05:49.795561
# Unit test for function collect_messages
def test_collect_messages():
    import httpie.cli.dicts as module_0
    request_headers_dict_0 = module_0.RequestHeadersDict()
    httpie_session_0 = make_httpie_session(request_headers_dict_0)
    headers_dict_0 = module_0.RequestHeadersDict()
    httpie_session_0.update_headers(headers_dict_0)
    headers_dict_1 = module_0.RequestHeadersDict()
    headers_dict_1['User-Agent'] = 'HTTPie/x'
    headers_dict_1['Accept'] = 'application/json, */*;q=0.5'
    headers_dict_1['Content-Type'] = 'application/json'
    headers_dict_2 = make_default_headers(headers_dict_1)
    final_headers

# Generated at 2022-06-25 18:05:53.650790
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    arguments = {'timeout': 20, 'allow_redirects': False}
    # Test.test_make_send_kwargs <<< kwargs
    kwargs = make_send_kwargs(arguments)
    # Test.test_make_send_kwargs <<< kwargs
    assert kwargs == arguments


# Generated at 2022-06-25 18:06:05.031758
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}
# Test case for make_send_kwargs
#   Make send kwargs with the given args
#   Input:
#       args - argparse.Namespace
#   Output:
#       kwargs - dict
#   Used by:
#       httpie.client.send_request(...)
#       httpie.client.collect_messages(...)
#   ATM, there is no way to set up the args for this function.

import httpie.cli.dicts as module_0


# Generated at 2022-06-25 18:06:10.280879
# Unit test for function make_default_headers
def test_make_default_headers():
    argparse_namespace_0 = argparse.Namespace()
    argparse_namespace_0.data = None
    argparse_namespace_0.form = 0
    argparse_namespace_0.json = 0
    test_default_headers = make_default_headers(argparse_namespace_0)
    assert test_default_headers == {'User-Agent': 'HTTPie/1.0.3'}


# Generated at 2022-06-25 18:06:12.796944
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    assert make_send_kwargs(args) == {'allow_redirects': False, 'timeout': None}


# Generated at 2022-06-25 18:06:24.810761
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-25 18:06:36.831375
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class Namespace:
        pass

    namespace = Namespace()
    namespace.url = 'http://www.google.com'
    namespace.json = '{ "some_key": "some_value" }'
    namespace.headers = {
        'Content-Type': 'application/json'
    }
    namespace.data = namespace.json
    namespace.method = 'PATCH'

    kwargs = make_request_kwargs(namespace)
    assert kwargs['url'] == 'http://www.google.com', \
        "Test that the url is set correctly - Failed"
    assert kwargs['method'] == 'patch', \
        "Test that the method is lower cased - Failed"

# Generated at 2022-06-25 18:06:39.096345
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    send_kwargs = make_send_kwargs(args)


# Generated at 2022-06-25 18:06:57.610096
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = None
    make_send_kwargs_mergeable_from_env(args)


# Generated at 2022-06-25 18:07:07.454645
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:07:11.952195
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:07:14.833184
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Test for exceptions:
    bad_args = argparse.Namespace(
        url='url',
        method='GET',
        headers={'Content-Type': 'application/json'}
    )
    try:
        make_request_kwargs(bad_args, None, None)
    except AssertionError:
        pass
    else:
        assert False, "Expected AssertionError"



# Generated at 2022-06-25 18:07:20.226428
# Unit test for function make_send_kwargs

# Generated at 2022-06-25 18:07:26.229237
# Unit test for function make_request_kwargs
def test_make_request_kwargs():

    class MockArgumentParser():
        def __init__(self):
            pass
        headers = RequestHeadersDict()

    # Test non-POST requests
    args = MockArgumentParser()
    args.method = 'GET'
    args.headers = RequestHeadersDict()
    args.headers['Content-Type'] = 'application/json'
    args.headers['Content-Length'] = '0'

    request_kwargs = make_request_kwargs(args)
    assert request_kwargs['method'] == args.method.lower()
    assert request_kwargs['headers'] == args.headers
    assert request_kwargs['data'] is None
    assert request_kwargs['params'] == []

    # Test POST requests with data:
    args = MockArgumentParser()
    args.method = 'POST'

# Generated at 2022-06-25 18:07:28.729558
# Unit test for function max_headers
def test_max_headers():
    args_0 = argparse.Namespace()
    args_0.max_headers = 1
    with max_headers(args_0.max_headers):
        pass


# Generated at 2022-06-25 18:07:32.310930
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Input parameters:
    args = {
    }
    base_headers = None
    request_body_read_callback = lambda chunk: chunk
    result = make_request_kwargs(
        args=args,
        base_headers=base_headers,
        request_body_read_callback=request_body_read_callback
    )


# Generated at 2022-06-25 18:07:44.326608
# Unit test for function make_default_headers
def test_make_default_headers():
    old_stderr = sys.stderr
    sys.stderr = open(os.devnull, "w")
    namespace_0 = argparse.Namespace()
    default_headers_0 = make_default_headers(namespace_0)
    assert default_headers_0 == {'User-Agent': 'HTTPie/1.0.3'}
    namespace_1 = argparse.Namespace()
    namespace_1.data = True
    namespace_1.form = False
    namespace_1.files = False
    namespace_1.json = False
    default_headers_1 = make_default_headers(namespace_1)

# Generated at 2022-06-25 18:07:54.290097
# Unit test for function collect_messages
def test_collect_messages():
    args_0 = argparse.Namespace()
    args_0.debug = False
    args_0.json = False
    args_0.form = False
    args_0.headers = RequestHeadersDict()
    args_0.data = None
    args_0.chunked = False
    args_0.multipart = False
    args_0.multipart_data = None
    args_0.offline = False
    args_0.timeout = None
    args_0.compress = 0
    args_0.max_redirects = None
    args_0.max_headers = None
    args_0.follow = False
    args_0.method = 'POST'
    args_0.url = 'https://www.example.com'
    args_0.params = {}
    args_

# Generated at 2022-06-25 18:08:19.848327
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    namespace_0 = module_0.Namespace()
    namespace_0.data = dict()
    namespace_0.form = False
    namespace_0.json = False
    namespace_0.auto_json = False
    namespace_0.method = str()
    namespace_0.url = str()
    namespace_0.headers = dict()
    namespace_0.offline = False
    namespace_0.chunked = False
    namespace_0.form = False
    namespace_0.files = dict()
    namespace_0.multipart = False
    namespace_0.multipart_data = dict()
    namespace_0.boundary = str()
    namespace_0.auth = None
    namespace_0.params = dict()
    namespace_0.ssl_version = str()
    namespace_0.ciphers = str

# Generated at 2022-06-25 18:08:24.066178
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # noinspection PyUnresolvedReferences
    args = argparse.Namespace()
    kwargs = make_request_kwargs(args)
    assert type(kwargs) == dict
    # Empty dict
    assert kwargs == {}

# Generated at 2022-06-25 18:08:26.207503
# Unit test for function max_headers
def test_max_headers():
    sys.stderr.write = lambda x: x
    namespace_0 = module_0.Namespace(max_headers=None)


# Generated at 2022-06-25 18:08:30.754988
# Unit test for function make_default_headers
def test_make_default_headers():
    namespace_0 = module_0.Namespace()
    namespace_0.data = None
    namespace_0.json = None
    namespace_0.form = None
    namespace_0.files = None
    namespace_0.headers = None

    assert make_default_headers(namespace_0)

# Generated at 2022-06-25 18:08:42.766064
# Unit test for function make_default_headers
def test_make_default_headers():
    namespace_0 = module_0.Namespace()
    namespace_0.json = False
    namespace_0.form = False
    namespace_0.data = {}
    assert make_default_headers(namespace_0) == {'User-Agent': 'HTTPie/2.2.0'}
    namespace_0.json = True
    assert make_default_headers(namespace_0) == {'User-Agent': 'HTTPie/2.2.0', 'Content-Type': 'application/json', 'Accept': 'application/json, */*;q=0.5'}
    namespace_0.json = False
    namespace_0.form = True

# Generated at 2022-06-25 18:08:43.529851
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    pass

# Generated at 2022-06-25 18:08:45.044751
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    namespace_0 = module_0.Namespace()


# Generated at 2022-06-25 18:08:58.881131
# Unit test for function collect_messages
def test_collect_messages():
    namespace_0 = module_0.Namespace()
    argparse.Namespace = lambda: namespace_0
    namespace_0.session_read_only = None
    namespace_0.debug = None
    namespace_0.json = None
    namespace_0.stream = False
    namespace_0.raw_response_headers = False
    namespace_0.auth = None
    namespace_0.http2 = False
    namespace_0.follow = False
    namespace_0.verify = 'yes'
    namespace_0.all = False
    namespace_0.form = False
    namespace_0.strict = False
    namespace_0.data = None
    namespace_0.output = None
    namespace_0.download = False
    namespace_0.timeout = None
    namespace_0.verbose = 0
    namespace_0.comp

# Generated at 2022-06-25 18:09:00.820937
# Unit test for function collect_messages
def test_collect_messages():
    with test_case_0() as value_0:
        assert value_0 is not None


# Generated at 2022-06-25 18:09:05.973252
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    assert callable(make_request_kwargs)

    # Check the following "if" statement
    if True:
        # Check the following "if" statement
        if True:
            # Check the following "if" statement
            if True:
                # Check the following "else" statement
                if True:
                    return None
                else:
                    # Check the following "if" statement
                    if True:
                        return None
                    else:
                        return None
            else:
                return None
        else:
            return None
    else:
        return None


# Generated at 2022-06-25 18:09:46.030364
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    bool_0 = True
    bool_1 = False
    namespace_0 = argparse.Namespace(
        cert='cert_arg_0',
        cert_key='cert_key_arg_0',
        proxy='proxy_arg_0',
        verify='true',
    )
    dict_0 = make_send_kwargs_mergeable_from_env(namespace_0)
    dict_1 = {'cert': 'cert_arg_0', 'cert_key': 'cert_key_arg_0'}
    bool_2 = dict_0 == dict_1
    dict_2 = {'verify': bool_0}
    bool_3 = dict_0 == dict_2
    namespace_1 = argparse.Namespace(cert='', cert_key='')
    dict_3 = make_send_kw

# Generated at 2022-06-25 18:09:55.630122
# Unit test for function make_default_headers
def test_make_default_headers():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_100 = bool()
    bool_101 = bool()
    bool_102 = bool()
    bool_103 = bool()
    bool_110 = bool()
    bool_111 = bool()
    bool_112 = bool()
    bool_113 = bool()
    bool_120 = bool()
    bool_121 = bool()
    bool_122 = bool()
    bool_123 = bool()
    bool_130 = bool()

# Generated at 2022-06-25 18:10:01.188859
# Unit test for function make_default_headers
def test_make_default_headers():
    class stub_args(object):
        def __init__(self):
            self.data = 'data'
            self.form = False
            self.json = False
            self.headers = [('key', 'value')]
    args = stub_args()
    result = make_default_headers(args)
    assert result == {
        'User-Agent': 'HTTPie/{0}'.format(__version__),
        'Accept': 'application/json, */*;q=0.5',
        'Content-Type': 'application/json'
    }



# Generated at 2022-06-25 18:10:02.688169
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        pass


# Generated at 2022-06-25 18:10:12.823875
# Unit test for function collect_messages

# Generated at 2022-06-25 18:10:16.598377
# Unit test for function make_default_headers
def test_make_default_headers():
    def test_case_1():
        args_1 = argparse.Namespace()
        args_1.json = False
        args_1.form = False
        headers_1 = make_default_headers(args_1)
        print(headers_1)

    test_case_1()


# Generated at 2022-06-25 18:10:25.870805
# Unit test for function make_default_headers
def test_make_default_headers():
    class args_0:
        def __init__(self):
            self.json = False
            self.form = False
            self.data = {}

    output_0 = __file__.replace('.pyc', '.py').replace('.py', '_output.json')
    with open(output_0, 'w', encoding='utf8') as outfile:
        json.dump(make_default_headers(args_0()), outfile)

    with open(output_0, 'r', encoding='utf8') as outfile:
        actual_data = json.load(outfile)

    output_1 = __file__.replace('.pyc', '.py').replace('.py', '_expected.json')
    with open(output_1, 'r', encoding='utf8') as outfile:
        expected_data = json

# Generated at 2022-06-25 18:10:27.180514
# Unit test for function build_requests_session
def test_build_requests_session():
    assert callable(build_requests_session)


# Generated at 2022-06-25 18:10:35.584972
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # checks the data conversion and assertions correctness
    import httpie.cli as cli
    import httpie.cli.argtypes as argtypes
    parser0 = cli.parser()
    parser0.add_argument("--verify", dest='verify', default=argtypes.str)
    parser0.add_argument("--ciphers", dest='ciphers', default=argtypes.str)
    parser0.add_argument("--cert", dest='cert', default=argtypes.str)
    parser0.add_argument("--cert-key", dest='cert_key', default=argtypes.str)
    parser0.add_argument("--ssl-version", dest='ssl_version', default=argtypes.str)
    parser0.add_argument("--proxy", dest='proxy', default=argtypes.str)
    args = parser

# Generated at 2022-06-25 18:10:36.707830
# Unit test for function max_headers
def test_max_headers():
    limit = 1000000000
    http.client._MAXHEADERS = limit


# Generated at 2022-06-25 18:11:22.640088
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    test = make_request_kwargs(args=argparse.Namespace(
        auth=None,
        cert=None,
        cert_key=None,
        chunked=False,
        data=True,
        files=None,
        form=False,
        headers=None,
        json=False,
        method='GET',
        offline=False,
        params=argparse.Namespace(items=None),
        path_as_is=False,
        proxy=None,
        session=None,
        session_read_only=False,
        ssl_version=None,
        timeout=None,
        url='http://localhost/',
        verify=True,
    ))

# Generated at 2022-06-25 18:11:24.253576
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs({})
    assert make_send_kwargs(None)


# Generated at 2022-06-25 18:11:32.004809
# Unit test for function collect_messages
def test_collect_messages():
    # Before function collect_messages is executed,
    # preload the following parameters for its test
    request_body_read_callback = lambda chunk: chunk
    args = []
    config_dir = []
    return_value = collect_messages(
        args,
        config_dir,
        request_body_read_callback
    )

    # The return value of collect_messages
    # is a generator containing 0 elements
    assert len(return_value) == 0



# Generated at 2022-06-25 18:11:41.431108
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:11:47.528809
# Unit test for function make_default_headers
def test_make_default_headers():
    import argparse
    global args
    args = argparse.Namespace()
    args.json = True
    args.data = dict()
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT,
                               'Content-Type': JSON_CONTENT_TYPE}


if __name__ == '__main__':
    test_case_0()
    test_make_default_headers()

# Generated at 2022-06-25 18:11:53.469109
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    mock_args_0 = argparse.Namespace()
    mock_args_0.timeout = None

    mock_args_0.allow_redirects = False

    mock_kwargs_0 = {
        'timeout': mock_args_0.timeout or None,
        'allow_redirects': False,
    }
    assert mock_kwargs_0 == make_send_kwargs(mock_args_0)



# Generated at 2022-06-25 18:12:03.607607
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    args_0 = Namespace(
        cert=None,
        cert_key=None,
        verify='yes'
    )
    m_kwargs_0 = make_send_kwargs_mergeable_from_env(args_0)
    assert m_kwargs_0['proxies'] == {}
    assert m_kwargs_0['stream']
    assert m_kwargs_0['verify'] is True
    assert m_kwargs_0['cert'] is None

    args_1 = Namespace(
        cert='/certs',
        cert_key='/keys',
        verify='false'
    )
    m_kwargs_1 = make_send_kwargs_

# Generated at 2022-06-25 18:12:11.325229
# Unit test for function collect_messages
def test_collect_messages():
    args_0 = argparse.Namespace()
    config_dir_0 = Path()
    request_body_read_callback_0 = lambda chunk: chunk
    try:
        collect_messages(args_0, config_dir_0, request_body_read_callback_0)
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 18:12:12.161134
# Unit test for function max_headers
def test_max_headers():
    assert True


# Generated at 2022-06-25 18:12:14.643196
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Assign args to its default value.
    args = None
    # Call the function.
    response = make_send_kwargs(args)
    # Assert the result of the function.
    assert response

# Generated at 2022-06-25 18:13:42.130421
# Unit test for function max_headers
def test_max_headers():
    assert True == True


# Generated at 2022-06-25 18:13:48.422869
# Unit test for function collect_messages

# Generated at 2022-06-25 18:13:55.819106
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()

    # Test with :
    # args =
    # config_dir =

    try:
        collect_messages(args, config_dir)
    except Exception as exception:
        print(exception)

if __name__ == "__main__":
    test_case_0()

    import unittest
    class UnitTest(unittest.TestCase):
        def test(self):
            test_collect_messages()

    unittest.main()

# Generated at 2022-06-25 18:13:59.784070
# Unit test for function max_headers
def test_max_headers():
    limit1 = 14
    with max_headers(limit1):
        assert http.client._MAXHEADERS == 14



# Generated at 2022-06-25 18:14:10.625041
# Unit test for function collect_messages

# Generated at 2022-06-25 18:14:18.908060
# Unit test for function collect_messages
def test_collect_messages():
    session_0 = requests.Session
    session_1 = requests.Session
    session_2 = requests.Session
    session_3 = requests.Session
    session_4 = requests.Session
    session_5 = requests.Session
    session_6 = requests.Session
    session_7 = requests.Session
    session_8 = requests.Session
    session_9 = requests.Session
    session_10 = requests.Session
    session_11 = requests.Session
    session_12 = requests.Session
    session_13 = requests.Session
    session_14 = requests.Session
    session_15 = requests.Session
    session_16 = requests.Session
    session_17 = requests.Session
    session_18 = requests.Session
    session_19 = requests.Session
    session_20 = requests.Session
    session_21 = requests.Session
   

# Generated at 2022-06-25 18:14:22.579611
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(True) is not None
    assert build_requests_session(True, "ssl_version_0", "ciphers_0") is not None


# Generated at 2022-06-25 18:14:31.006423
# Unit test for function make_send_kwargs

# Generated at 2022-06-25 18:14:33.984114
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout = '0.01')
    result = make_send_kwargs(args)
    assert result['timeout'] == 0.01
    assert result['allow_redirects'] == False


# Testing function ensure_path_as_is

# Generated at 2022-06-25 18:14:41.451008
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    env_vars = ['http_proxy', 'https_proxy', 'no_proxy', 'REQUESTS_CA_BUNDLE',
                'curl_ca_bundle', 'SSL_CERT_FILE', 'https_certificate']
    # Test case #1
    args_1 = argparse.Namespace(
        cert='',
        cert_key='',
        verify='',
        proxy=[])
    result_1 = make_send_kwargs_mergeable_from_env(args_1)
    assert result_1['verify'] == True
    for var in env_vars:
        assert var not in result_1
    # Test case #2
    args_2 = argparse.Namespace(
        cert='',
        cert_key='',
        verify='',
        proxy=[])
   