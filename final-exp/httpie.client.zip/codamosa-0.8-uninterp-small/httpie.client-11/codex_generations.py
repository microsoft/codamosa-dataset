

# Generated at 2022-06-25 18:05:41.700591
# Unit test for function max_headers
def test_max_headers():
    arg_0 = 65
    var_0 = max_headers(arg_0)
    try:
        with var_0:
            pass
        assert True
    except:
        assert False

test_case_0()

# Generated at 2022-06-25 18:05:49.525829
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    from tests.test_cli import test_arg_parser
    args = test_arg_parser()
    args.proxy = [
        argparse.Namespace(key='https', value='foo'),
        argparse.Namespace(key='http', value='foo'),
    ]
    args.verify = 'no'
    args.cert = 'foo'
    args.cert_key = 'foo'
    args.timeout = 'foo'
    args.method = 'foo'
    args.url = 'foo'
    args.headers = RequestHeadersDict({'foo': 'foo'})
    args.json = False

# Generated at 2022-06-25 18:05:50.366600
# Unit test for function collect_messages
def test_collect_messages():
    pass



# Generated at 2022-06-25 18:05:52.412624
# Unit test for function max_headers
def test_max_headers():
    # TESTCASE 0 starts
    bool_0 = False
    var_0 = max_headers(bool_0)
    # TESTCASE 0 ends



# Generated at 2022-06-25 18:06:04.941863
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = os.path.expanduser('~/workspace/httpie/certs/clientcert.pem')
    args.cert_key = os.path.expanduser('~/workspace/httpie/certs/clientkey.pem')
    args.ciphers = 'DEFAULT'
    args.verify = True
    # Set the attributes of a Namespace object
    args.data = {}
    args.files = None
    kwargs = make_send_kwargs(args)
    print(kwargs)

    args.verify = 'yes'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    print(kwargs)


if __name__ == '__main__':
    test_make_send

# Generated at 2022-06-25 18:06:15.147411
# Unit test for function make_default_headers

# Generated at 2022-06-25 18:06:26.061728
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    var_1 = argparse.Namespace()
    var_1.method = "Method_0"
    var_1.url = "Url_0"
    var_1.headers = {}
    var_1.data = "Data_0"
    var_1.json = False
    var_1.form = False
    var_1.files = False
    var_1.multipart = False
    var_1.offline = False
    var_1.chunked = False
    var_1.multipart_data = []
    var_1.auth = ()
    var_1.params = {}
    var_1.timeout = "Time_0"
    var_1.allow_redirects = False
    var_1.proxies = {}
    var_1.stream = True
    var_

# Generated at 2022-06-25 18:06:26.914401
# Unit test for function max_headers
def test_max_headers():
    assert callable(max_headers)


# Generated at 2022-06-25 18:06:33.023959
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    bool_0 = False
    str_0 = 'false'
    bool_1 = True
    str_1 = 'true'
    bool_2 = True
    str_2 = 'yes'
    str_3 = 'no'
    bool_3 = False
    str_4 = 'asdf'
    str_5 = 'asdf'
    bool_4 = True
    cert = './test_data/test_case_0/test_0.crt'
    cert_key = './test_data/test_case_0/test_0.key'

# Generated at 2022-06-25 18:06:34.514293
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    assert make_request_kwargs('variable_1') == 'value'


# Generated at 2022-06-25 18:07:01.258270
# Unit test for function collect_messages
def test_collect_messages():

    parser = argparse.ArgumentParser()
    parser.add_argument('-v','--verbose', action = 'store_true', help = 'Increase output verbosity')
    args = parser.parse_args()
    from contextlib import contextmanager
    import sys
    import os
    import tempfile

    @contextmanager
    def temp_config_dir():
        d = tempfile.mkdtemp()
        try:
            yield d
        finally:
            os.rmdir(d)

    config_dir = temp_config_dir()

    for r in collect_messages(args=args,config_dir=config_dir):
        print(r)

# Generated at 2022-06-25 18:07:08.054895
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # noinspection PyTypeChecker
    args = argparse.Namespace()
    args.proxy = ["http://foo.com", "http://bar.com"]
    args.verify = "yes"
    args.cert = "cert.pem"
    args.cert_key = "key.pem"
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {'http://foo.com': None, 'http://bar.com': None},
        'stream': True,
        'verify': True,
        'cert': ('cert.pem', 'key.pem'),
    }

# Generated at 2022-06-25 18:07:10.607768
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace
    args.json = False
    args.data = True
    args.form = False

    result = make_default_headers(args)
    assert result['User-Agent'] == DEFAULT_UA
    assert result['Accept'] == JSON_ACCEPT
    assert result['Content-Type'] == JSON_CONTENT_TYPE

# Generated at 2022-06-25 18:07:22.435778
# Unit test for function make_default_headers
def test_make_default_headers():
    print("in test_make_default_headers")
    args = argparse.Namespace()
    args.referer = False
    args.json = False
    args.compress = False
    args.form = False
    args.all = False
    args.offline = False
    args.files = False
    args.max_redirects = False
    args.chunked = False
    args.session_read_only = False
    args.compress_level = False
    args.style = False
    args.output_dir = False
    args.check_status = False
    args.timeout = False
    args.verify = False
    args.download = False
    args.pretty = False
    args.ugly = False
    args.print_body = False
    args.stream = False

# Generated at 2022-06-25 18:07:30.977022
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(auth=None, auth_type='basic',
                              code=None, compressed=False, cookies=None,
                              debug=False, data=None,
                              download=False,
                              form=False, headers=None, ignore_stdin=False,
                              json=False, output_dir=None, method='GET',
                              output_file=None, output_options=None,
                              params=None, stdin=None, upload=None, url='http://localhost')
    result = make_default_headers(args)
    assert(result['User-Agent'] == 'HTTPie/0.11.4')


# Generated at 2022-06-25 18:07:42.989884
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace()
    args_0.json = True
    args_0.data = 'b'
    args_0.form = True
    result = make_default_headers(args_0)
    assert result['Accept'] == 'application/json, */*;q=0.5'
    assert result['Content-Type'] == 'application/json'
    assert result['User-Agent'] == 'HTTPie/1.0.3'


args_0 = argparse.Namespace()
args_0.debug = True
args_0.data = 'b'
args_0.json = True
args_0.form = True
args_0.files = 'a'
args_0.multipart = True
args_0.multipart_data = {'c': 'd'}
args_

# Generated at 2022-06-25 18:07:53.207717
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    print('Testing make_send_kwargs_mergeable_from_env')
    class proxy():
        def __init__(self, key, value):
            self.key = key
            self.value = value
    proxy_list = [proxy('key0', 'value0'), proxy('key1', 'value1')]
    args_0 = argparse.Namespace(proxy=proxy_list, verify='True', cert=None, cert_key=None)
    kwargs_0 = make_send_kwargs_mergeable_from_env(args_0)
    expected = {
        'proxies': {'key0': 'value0', 'key1': 'value1'},
        'stream': True,
        'verify': True,
        'cert': None
    }

# Generated at 2022-06-25 18:07:56.729646
# Unit test for function collect_messages
def test_collect_messages():
    orig_url_0 = 'http://httpie.org'
    prepped_url_0 = 'https://httpie.org'
    ensure_path_as_is_ret_0 = ensure_path_as_is(orig_url_0, prepped_url_0)
    assert ensure_path_as_is_ret_0 == 'https://httpie.org'


# Generated at 2022-06-25 18:08:09.142814
# Unit test for function make_default_headers
def test_make_default_headers():
    test_args_0 = argparse.Namespace()
    test_args_1 = argparse.Namespace()
    test_args_2 = argparse.Namespace()
    test_args_3 = argparse.Namespace()
    test_args_4 = argparse.Namespace()
    test_args_5 = argparse.Namespace()
    test_args_6 = argparse.Namespace()
    test_args_7 = argparse.Namespace()
    test_args_8 = argparse.Namespace()
    test_args_9 = argparse.Namespace()
    test_args_10 = argparse.Namespace()
    test_args_11 = argparse.Namespace()
    test_args_12 = argparse.Namespace()
    test_args_13 = argparse.Namespace()
    test_

# Generated at 2022-06-25 18:08:17.990917
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from tests import httpbin
    from argparse import Namespace
    args = Namespace(cert=None, cert_key=None, chunked=False, data=None,
                     files=None, form=False, json=False, params=None,
                     path=False, path_as_is=False, proxy=None,
                     session_read_only=None, timeout=None, traceback=None,
                     verify='true')
    with httpbin.stub() as stub:
        stub.get('/get', 'get')
        kwargs = make_send_kwargs_mergeable_from_env(args)
        assert kwargs['proxies'] == {'http': None, 'https': None}
        assert kwargs['stream'] == True
        assert kwargs['verify'] == True
        assert kw

# Generated at 2022-06-25 18:09:00.850985
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
            data=[1, 2, 3],
            json=True,
            files=[],
            form=False
        )

    test_0 = make_default_headers(args)

# Generated at 2022-06-25 18:09:06.633550
# Unit test for function make_default_headers
def test_make_default_headers():
    # Initialize a tuple of args
    args_0 = argparse.Namespace()

    # Initialize a tuple of headers
    headers_0 = RequestHeadersDict()

    # Call the function
    result = make_default_headers(args_0)

    # Check the returned value is correct
    assert result == headers_0

# Generated at 2022-06-25 18:09:14.742781
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    prefix_0 = 'https://'
    prepped_url_0 = 'https://httpie.org'
    cert_0 = 'https://httpie.org'
    kwargs_0 = make_send_kwargs_mergeable_from_env(cert_0)
    assert kwargs_0 == {
        'proxies': {},
        'stream': True,
        'verify': 'https://httpie.org'
    }


# Generated at 2022-06-25 18:09:23.931947
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Build args.
    args = argparse.ArgumentParser()
    args.url = 'http://www.google.com'
    args.auth_plugin = auth_plugin
    args.auth = args.auth_plugin.get_auth()
    args.auth_plugin.validate_authorization_value(args.auth)
    args.method = 'GET'
    args.headers = RequestHeadersDict()
    args.data = {}
    args.form = True
    args.files = {}
    args.json = False
    args.compress = 1
    args.compress_level = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.max_redirects = 30
    args.follow = True
    args.path

# Generated at 2022-06-25 18:09:35.596054
# Unit test for function collect_messages
def test_collect_messages():
    namespace_0 = argparse.Namespace()
    namespace_0.verify = True
    namespace_0.chunked = None
    namespace_0.timeout = None
    namespace_0.form = None
    namespace_0.session_read_only = None
    namespace_0.compress = None
    namespace_0.json = None
    namespace_0.session = None
    namespace_0.insecure = None
    namespace_0.cert = None
    namespace_0.path_as_is = None
    namespace_0.auth = None
    namespace_0.proxy = None
    namespace_0.params = None
    namespace_0.data = None
    namespace_0.method = 'get'
    namespace_0.url = "http://google.com"
    namespace_0.files = None
    namespace_0

# Generated at 2022-06-25 18:09:46.115581
# Unit test for function make_send_kwargs

# Generated at 2022-06-25 18:09:49.710007
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Declare the parameters.
    args_0 = None

    # Call the function.
    try:
        make_send_kwargs_mergeable_from_env(args_0)
    except:
        print("unexpected failure")


# Generated at 2022-06-25 18:09:58.714164
# Unit test for function collect_messages
def test_collect_messages():
    default_args = argparse.Namespace(auth=None, auth_plugin=None, cert=None, ciphers=None, compression=None, debug=False, data=None, follow=None, form=None, header=None, headers=RequestHeadersDict({'User-Agent': 'HTTPie/1.0.3'}), ignore_stdin=False, json=None, max_headers=None, max_redirects=None, multipart=False, offline=False, output_file=None, output_options=None, params=(), path_as_is=False, plain=None, print_body=True, session=None, session_read_only=None, ssl_version='secure', style=None, timeout=30, url='https://httpbin.org/get', verify='yes', version=False)
    assert collect_mess

# Generated at 2022-06-25 18:09:59.664964
# Unit test for function max_headers
def test_max_headers():
    pass


# Generated at 2022-06-25 18:10:02.686727
# Unit test for function max_headers
def test_max_headers():
    try:
        with max_headers(1):
            assert http.client._MAXHEADERS == 1
    except:
        print('Error: Corrupt test_max_headers.')
        raise
    finally:
        http.client._MAXHEADERS = 10000


# Generated at 2022-06-25 18:11:17.829809
# Unit test for function collect_messages
def test_collect_messages():
    args_0 = argparse.Namespace()
    args_0.data = None
    args_0.session = None
    args_0.auth_plugin = None
    args_0.cert = None
    args_0.cert_key = None
    args_0.offline = False
    args_0.verify = None
    args_0.max_headers = None
    args_0.params = None
    args_0.max_redirects = None
    args_0.json = False
    args_0.follow = True
    args_0.compress = None
    args_0.form = False
    args_0.proxy = None
    args_0.auth = None
    args_0.headers = None
    args_0.timeout = None
    args_0.files = None
    args_

# Generated at 2022-06-25 18:11:20.361414
# Unit test for function make_default_headers
def test_make_default_headers():
    test_kwargs = {
    }
    test_args = argparse.Namespace(**test_kwargs)
    test_headers = make_default_headers(test_args)



# Generated at 2022-06-25 18:11:21.666798
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(2)


# Generated at 2022-06-25 18:11:28.729320
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    """
    ** Test for function make_send_kwargs_mergeable_from_env **
    """

    args = argparse.Namespace()
    args.verify = 'true'
    args.proxy = [('HTTP','http://username:password@proxy.com:80')]

    send_kwargs = make_send_kwargs_mergeable_from_env(args)

    assert send_kwargs['verify'] == True and send_kwargs['proxies'] == {'HTTP': 'http://username:password@proxy.com:80'}


# Generated at 2022-06-25 18:11:37.629225
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:11:38.476675
# Unit test for function max_headers
def test_max_headers():
    assert True


# Generated at 2022-06-25 18:11:48.304763
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session(False, 'TLSv1')
    assert type(session_0) == requests.sessions.Session
    # Test session_0.headers.get('User-Agent')
    assert session_0.headers.get('User-Agent') == b'HTTPie/1.0.0-dev0'
    # Test session_0._adapters['https://'].cert_verify
    assert session_0._adapters['https://'].cert_verify == False
    # Test session_0._adapters['https://'].cert_verify_capath
    assert session_0._adapters['https://'].cert_verify_capath == None
    # Test session_0._adapters['https://'].cert_verify_cadata

# Generated at 2022-06-25 18:11:53.468579
# Unit test for function collect_messages
def test_collect_messages():
    n = 1
    print(n)
    args_0 = None
    config_dir_0 = None
    request_body_read_callback_0 = None
    receive_0 = collect_messages(
        args_0,
        config_dir_0,
        request_body_read_callback_0
    )
    print(receive_0)


# Generated at 2022-06-25 18:11:54.868446
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    make_send_kwargs('' == 'string')


# Generated at 2022-06-25 18:12:01.941399
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class DummyArgs:
        def __init__(self):
            self.proxy = []
            self.verify = 'True'
            self.cert = 'True'
            self.cert_key = 'True'
    args = DummyArgs()
    test_result = make_send_kwargs_mergeable_from_env(args)
    expected_result = {}
    assert test_result == expected_result, "Unit test for make_send_kwargs_mergeable_from_env failed"
