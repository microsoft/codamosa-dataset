

# Generated at 2022-06-25 18:05:30.532060
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Testing Json data
    args = argparse.Namespace()
    args.headers = {'Content-Type': 'application/json', 'Accept': '*/*'}
    args.auth = ('username', 'password')
    args.offline = False
    args.chunked = False
    args.multipart = False
    args.method = "GET"
    args.url = "http://httpbin.org/get"
    args.verbose = False
    args.debug = False
    args.json = True
    args.form = False
    args.data = {'key1': 'value1'}
    args.file = ""
    args.files = []
    args.compress = False
    args.download = False
    args.output = ""
    args.session = None
    args.session_read

# Generated at 2022-06-25 18:05:33.224286
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    test_result_kwargs = make_send_kwargs(args)
    print(test_result_kwargs)



# Generated at 2022-06-25 18:05:40.227310
# Unit test for function make_default_headers

# Generated at 2022-06-25 18:05:47.753157
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-t', '--timeout',
        metavar='SECONDS',
        type=float,
        help='Set the socket timeout in seconds',
    )
    parser.add_argument(
        '--max-redirects',
        type=int,
        metavar='NUM',
        help='Number of maximum redirections allowed',
    )
    parser.add_argument(
        '--verify',
        choices=['yes', 'no'],
        default='yes',
        metavar='yes/no',
        help='Enable/disable SSL certificate verification.',
    )

# Generated at 2022-06-25 18:05:55.978510
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    args = argparse.Namespace()
    args.auth = 1
    args.baseurl = None
    args.body = 'file.txt'
    args.body_querystring = {}
    args.body_type = None
    args.boundary = '4XqluFzpPvtfyV7'
    args.check_status = 1
    args.chunked = 0
    args.color = 1
    args.compress = None
    args.config_dir = '/home/michael/.config/httpie-password-store/'
    args.config_file = 'config.json'
    args.continue_read = 0
    args.continue_write = 0
    args.debug = 0
    args.default_options = None
    args.default_scheme = 'https'
    args

# Generated at 2022-06-25 18:05:58.079738
# Unit test for function max_headers
def test_max_headers():
    with max_headers(args.max_headers):
        raise http.client.InvalidHeader


# Generated at 2022-06-25 18:06:10.364733
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
    import io
    from io import BytesIO

    class Namespace:
        def __init__(self, **kwargs):
            for k,v in kwargs.items():
                setattr(self,k,v)

        def __repr__(self):
            return ", ".join(k + "=" + str(getattr(self,k)) for k in vars(self))

    class FileObj:
        def __init__(self, file_name):
            self.name = file_name
            self.len = 0
            if file_name == "image.png":
                self.stream = BytesIO(open("image.png", "rb").read())
                self.len = os.path.getsize("image.png")

# Generated at 2022-06-25 18:06:22.406469
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test 1
    arg1 = argparse.Namespace(cert=None, cert_key=None, verify='', proxy=[], ssl_version=None, ciphers=None)
    assert make_send_kwargs_mergeable_from_env(arg1) == {'cert': None, 'proxies': {}, 'stream': True, 'verify': ''}
    # Test 2
    arg2 = argparse.Namespace(cert=None, cert_key=None, verify='', proxy=[], ssl_version='TLSv1.2', ciphers=None)
    assert make_send_kwargs_mergeable_from_env(arg2) == {'cert': None, 'proxies': {}, 'stream': True, 'verify': '', 'ssl_version': 2}
    # Test 3


# Generated at 2022-06-25 18:06:24.851019
# Unit test for function max_headers
def test_max_headers():
    with max_headers(20):
        if http.client._MAXHEADERS == 20:
            assert True
        else:
            assert False

#Unit test for function dump_request(

# Generated at 2022-06-25 18:06:32.822705
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    try:
        from unittest import mock
    except ImportError:
        import mock
    verify = 'yes'
    _proxy = mock.Mock()
    _proxies = {'key': _proxy.value}
    _kwargs = {'proxies' : _proxies, 'stream' : True,
               'verify' : True, 'cert' : args.cert}
    assert make_send_kwargs_mergeable_from_env(args) == _kwargs


# Generated at 2022-06-25 18:06:56.385023
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(False, None, None), requests.Session)


# Generated at 2022-06-25 18:07:06.615710
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = argparse.Namespace()
    args_0.method = 'GET'
    args_0.url = 'http://httpbin.org/get'
    args_0.headers = RequestHeadersDict()
    args_0.headers['User-Agent'] = 'HTTPie/0.9.8'
    args_0.headers['Accept-Encoding'] = 'gzip, deflate, compress'
    args_0.headers['Accept'] = 'application/json'
    args_0.headers['Connection'] = 'keep-alive'
    args_0.headers['Content-Type'] = 'application/json'
    args_0.auth = None
    args_0.params = {}
    args_0.data = {'foo': 'bar'}
    args_0.json = False
    args_0

# Generated at 2022-06-25 18:07:13.732371
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    proxy_list = module_proxy.ProxyList([])
    parser_proxy_list_0 = module_parser.ProxyList(proxy_list)
    argparser_namespace_0 = argparse.Namespace(cert=None, cert_key=None, verify=True)
    assert make_send_kwargs_mergeable_from_env(argparser_namespace_0) == {'cert': None, 'proxies': {}, 'stream': True, 'verify': True}

# Generated at 2022-06-25 18:07:17.889380
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Case 1 #
    arg_namespace_0 = argparse.Namespace(timeout=42, follow=False)
    call_0 = make_send_kwargs(arg_namespace_0)
    assert call_0 == {'timeout': 42, 'allow_redirects': False}


# Generated at 2022-06-25 18:07:29.865066
# Unit test for function make_default_headers

# Generated at 2022-06-25 18:07:35.321441
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = argparse.Namespace()
    args_0.verify = 'yes'
    args_0.proxy = []
    args_0.cert = ''
    args_0.cert_key = ''
    assert make_send_kwargs_mergeable_from_env(args_0) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }


# Generated at 2022-06-25 18:07:47.411598
# Unit test for function collect_messages
def test_collect_messages():
    # Check that all requirements are satisfied.
    assert callable(collect_messages)

    # The following line is modified by the test generator. Here, we
    # assign to config_dir the pathlib.Path instance representing the
    # parent directory of the httpie package, if execution is using
    # the test generator, otherwise we leave the value of config_dir
    # unchanged.
    config_dir = Path(__file__).parent.parent if __name__ == '__main__' else config_dir
    # The following line is modified by the test generator. Here, we
    # assign to args an argparse.Namespace instance representing a
    # default set of command line arguments for the http command,
    # if execution is using the test generator, otherwise we leave the
    # value of args unchanged.

# Generated at 2022-06-25 18:07:52.872871
# Unit test for function collect_messages
def test_collect_messages():
    class MockArgumentParser():
        def __init__(self):
            self.headers = {'get': 'get'}
            self.json = True
            self.method = 'GET'
            self.url = 'http://url'
            self.http3 = 0
            self.all = 0
            self.compress = 1
            self.max_redirects = 0
            self.max_headers = 0
            self.timeout = 30
            self.verify = True
            self.cert = 'cert'
            self.cert_key = 'cert_key'
            self.form = False
            self.debug = True
            self.path_as_is = True
            self.offline = True
            self.session = False
            self.session_read_only = 'MockSession'
            self.auth_plugin

# Generated at 2022-06-25 18:07:53.691671
# Unit test for function max_headers
def test_max_headers():
    assert False


# Generated at 2022-06-25 18:08:01.869454
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Setup
    args = None
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.verify = None

    # Expected result
    expected_result = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }

    # Run
    result = make_send_kwargs_mergeable_from_env(args)

    # Assert
    assert result == expected_result



# Generated at 2022-06-25 18:08:26.385688
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    str_0 = 'GET'
    str_1 = 'http://foo.com'
    dict_0 = {'User-Agent': 'HTTPie/1.0.2'}
    dict_1 = dict()
    dict_2 = dict()
    list_0 = []
    args_0 = argparse.Namespace(auth=None, chunked=False, offline=False, method=str_0, url=str_1, headers=dict_0, params=dict_1, json=False, form=False, data=dict_2, files=list_0)
    make_request_kwargs(args_0, None)


# Generated at 2022-06-25 18:08:29.209247
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = None
    result = make_send_kwargs(args)
    assert type(result) is dict
    assert result['timeout'] is None
    assert result['allow_redirects'] == False


# Generated at 2022-06-25 18:08:41.657626
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    test_args = argparse.Namespace()
    test_args.timeout = None
    test_kwargs = make_send_kwargs(test_args)
    assert test_kwargs['timeout'] == None
    test_args.timeout = 3.1
    test_kwargs = make_send_kwargs(test_args)
    assert test_kwargs['timeout'] == 3.1
    test_args.allow_redirects = True
    test_kwargs = make_send_kwargs(test_args)
    assert test_kwargs['allow_redirects'] == False
    test_args.allow_redirects = False
    test_kwargs = make_send_kwargs(test_args)
    assert test_kwargs['allow_redirects'] == False
    assert len(test_kwargs) == 2

# Generated at 2022-06-25 18:08:50.784977
# Unit test for function collect_messages
def test_collect_messages():
    # test case 1
    args_1 = None
    config_dir_1 = Path.cwd()
    request_body_read_callback_1 = None
    try:
        collect_messages(args_1, config_dir_1, request_body_read_callback_1)
    except TypeError as err:
        print(err.__str__())
        pass
    # test case 2
    args_2 = argparse.ArgumentParser()
    config_dir_2 = Path.cwd()
    request_body_read_callback_2 = None
    try:
        collect_messages(args_2, config_dir_2, request_body_read_callback_2)
    except TypeError as err:
        print(err.__str__())
        pass
    # test case 3

# Generated at 2022-06-25 18:08:54.980234
# Unit test for function collect_messages
def test_collect_messages():
    args_0 = argparse.Namespace()
    config_dir_0 = Path()
    result_0 = collect_messages(args_0, config_dir_0)
    print(result_0)

# Generated at 2022-06-25 18:09:04.451144
# Unit test for function collect_messages
def test_collect_messages():
    str_0 = "-"
    str_1 = "-"
    class_0 = get_httpie_session(str_0)
    str_2 = "-"
    str_3 = "-"
    dict_0 = dict()
    str_4 = "Index"
    dict_0['Index'] = str_4
    str_5 = "="
    dict_0['List'] = str_5
    str_6 = "="
    dict_0['Item1'] = str_6

# Generated at 2022-06-25 18:09:07.979916
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = argparse.Namespace()
    args_0.verify = 'no'
    test_make_send_kwargs_mergeable_from_env_0(args_0)

# noinspection PyUnusedLocal

# Generated at 2022-06-25 18:09:14.612787
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = ""
    args_0 = argparse.Namespace()
    args_0.cert = ""
    args_0.cert_key = ""
    args_0.proxy = ""
    args_0.verify = ""
    make_send_kwargs_mergeable_from_env(args_0)



# Generated at 2022-06-25 18:09:19.928328
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Setup
    args = argparse.Namespace()
    data_0 = dict()
    type(args).data = data_0
    base_headers_0 = dict()
    request_body_read_callback_0 = lambda chunk: chunk
    # Invocation
    kwargs_0 = make_request_kwargs(args, base_headers_0, request_body_read_callback_0)
    # Verification
    assert kwargs_0
    try:
        assert "dict" == type(kwargs_0).__name__
    except:
        raise AssertionError()
    try:
        assert kwargs_0["data"] == b"{}"
    except:
        raise AssertionError()



# Generated at 2022-06-25 18:09:26.919685
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    print('Testing make_send_kwargs')


# Generated at 2022-06-25 18:10:12.942917
# Unit test for function max_headers
def test_max_headers():
    args_0 = argparse.Namespace()
    args_0.max_headers = None
    args_1 = argparse.Namespace()
    args_1.max_headers = 0
    args_2 = argparse.Namespace()
    args_2.max_headers = 1
    args_3 = argparse.Namespace()
    args_3.max_headers = 2
    args_4 = argparse.Namespace()
    args_4.max_headers = 3
    args_5 = argparse.Namespace()
    args_5.max_headers = 4
    args_6 = argparse.Namespace()
    args_6.max_headers = 5
    args_7 = argparse.Namespace()
    args_7.max_headers = 6
    args_8 = argparse.Namespace()
    args_

# Generated at 2022-06-25 18:10:18.805556
# Unit test for function make_default_headers
def test_make_default_headers():
    parser = argparse.ArgumentParser()
    parser.add_argument('--json')
    parser.add_argument('--form')
    parser.add_argument('--files')
    parser.add_argument('--data')
    parser.add_argument('--headers')
    args = parser.parse_args(['--json', '--form', '--files', '--data', '--headers'])

    ret = make_default_headers(args)
    print(ret)


# Generated at 2022-06-25 18:10:28.088613
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    print("This test requires user input and may take a while. Unit test for function make_send_kwargs_mergeable_from_env")
    print("To exit the test at any time, please enter 'exit'")
    numTests = 0
    numPassed = 0
    print("Please enter a number of tests to run")
    x = input()
    if x == "exit":
        print("Exiting test...")
        return
    numTests = int(x)
    for i in range(numTests):
        print("Please enter a JSON object for the argparse arg (See https://docs.python.org/3/library/argparse.html#the-namespace-object for more information)")
        x = input()
        if x == "exit":
            print("Exiting test...")
            break

# Generated at 2022-06-25 18:10:28.970770
# Unit test for function max_headers
def test_max_headers():
    # TODO: add your test code here
    assert not max_headers('max_headers')


# Generated at 2022-06-25 18:10:31.861874
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = {'foo': 'bar'}
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == 'application/json, */*;q=0.5'
    assert default_headers['Content-Type'] == 'application/json'
    assert default_headers['User-Agent'] == 'HTTPie/0.9.9'

# Generated at 2022-06-25 18:10:40.286371
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.url = 'http://localhost:80/'
    args.data = None
    args.params = {'k1': 'v1'}
    args.form = False
    args.files = False
    args.json = None
    args.headers = {'k1': 'v1'}
    args.auth = None
    args.max_redirects = None
    args.method = 'GET'
    args.compress = False
    args.session = None
    args.debug = False
    args.chunked = False
    args.follow = False
    args.path_as_is = True
    args.proxies = {'k1': 'v1'}
    args.verify = False
    args.cert = None
    args.cert_key

# Generated at 2022-06-25 18:10:47.004282
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import pytest

    # args = argparse.Namespace()
    args = argparse.Namespace(no_verify_ssl=False, timeout=20, follow=False)

    kwargs = make_send_kwargs(args)
    # print(kwargs)
    assert kwargs == {'timeout': 20, 'allow_redirects': False}


# Generated at 2022-06-25 18:10:48.874677
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = make_default_headers(bool_0)


# Generated at 2022-06-25 18:10:53.302098
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 1
    args.allow_redirects = False
    res = make_send_kwargs(args)
    assert(res['timeout'] == 1)
    assert(res['allow_redirects'] == False)



# Generated at 2022-06-25 18:10:56.320267
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=[], verify='yes')
    result = make_send_kwargs_mergeable_from_env(args)
    assert result == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}


# Generated at 2022-06-25 18:12:01.968687
# Unit test for function collect_messages
def test_collect_messages():
    assert False


# Generated at 2022-06-25 18:12:09.496828
# Unit test for function make_default_headers
def test_make_default_headers():
    bool_0 = True
    bool_1 = True
    int_0 = 1
    dict_0 = {}
    dict_0["foo"] = "bar"
    dict1_0 = {}
    dict1_0["foo"] = "bar"
    dict2_0 = {}
    dict2_0["foo"] = "bar"
    dict3_0 = {}
    dict3_0["foo"] = "bar"
    dict4_0 = {}
    dict4_0["foo"] = "bar"
    dict5_0 = {}
    dict5_0["foo"] = "bar"
    dict6_0 = {}
    dict6_0["foo"] = "bar"
    dict7_0 = {}
    dict7_0["foo"] = "bar"
    dict8_0 = {}
    dict8_

# Generated at 2022-06-25 18:12:17.933484
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-25 18:12:26.301477
# Unit test for function make_default_headers
def test_make_default_headers():
    class DummyArgs(object):
        def __init__(self, data, form, json, files):
            self.data = data
            self.form = form
            self.json = json
            self.files = files


# Generated at 2022-06-25 18:12:27.291220
# Unit test for function build_requests_session
def test_build_requests_session():

    # Test case 0
    build_requests_session()

    test_case_0()

# Generated at 2022-06-25 18:12:31.990867
# Unit test for function build_requests_session
def test_build_requests_session():
    bool_0 = False
    ssl_version_0 = 'TLSv1.3'
    ciphers_0 = 'AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA256:AES256-SHA256'
    requests_session_0 = build_requests_session(bool_0, ssl_version_0, ciphers_0)
    assert session_0 == requests_session_0


# Generated at 2022-06-25 18:12:41.757714
# Unit test for function collect_messages
def test_collect_messages():
    config_dir = Path('\te')
    args = argparse.Namespace()
    args.session = 0
    args.session_read_only = 0
    args.url = 'http://httpie.org'
    args.headers = RequestHeadersDict()
    args.debug = True
    args.path_as_is = True
    args.compress = 2
    args.offline = True
    args.max_redirects = 0
    args.follow = False
    args.all = True
    request_body_read_callback = 0
    it = collect_messages(args, config_dir, request_body_read_callback)
    for i in it:
        print(i)

if __name__ == '__main__':
    test_case_0()
    test_collect_messages()

# Generated at 2022-06-25 18:12:46.300196
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    headers = make_default_headers()
    kwargs = {
        'method': 'get',
        'url': 'https://httpbin.org/ip',
        'headers': headers,
        'data': None,
        'auth': None,
        'params': [('foo', 'bar')]
    }
    assert make_request_kwargs(None) == kwargs

# Generated at 2022-06-25 18:12:51.829357
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import argparse
    class Namespace(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    args = Namespace(
            verify='False', 
            ciphers='',
            cert='',
            cert_key='',
            proxy=[],
            auth='asdf',
            ssl_version='', 
        )
    expected = {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': '',
        }
    kwargs = make_send_kwargs_mergeable_from_env(args)
    # TODO: Write unit test for this function
    assert kwargs == expected


# Generated at 2022-06-25 18:12:55.531510
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=None, follow=False, max_redirects=None, max_headers=None, allow_redirects=False, check_status=None)
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}
