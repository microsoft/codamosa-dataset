

# Generated at 2022-06-25 18:05:35.487776
# Unit test for function max_headers
def test_max_headers():
    namespace_0 = module_0.Namespace()
    test_case_0(namespace_0)

# Generated at 2022-06-25 18:05:40.192765
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import requests as module_1
    namespace_0 = module_0.Namespace()
    var_0 = make_request_kwargs(namespace_0)
    namespace_1 = module_0.Namespace()
    namespace_1.method = 'GET'
    namespace_1.url = var_0
    var_1 = make_request_kwargs(namespace_1)
    var_2 = module_1.Request(**var_1)
    var_3 = var_2.__dict__
    var_4 = var_3['method']
    var_5 = 'GET'
    var_6 = (var_4 == var_5)
    assert var_6



# Generated at 2022-06-25 18:05:47.714460
# Unit test for function make_send_kwargs

# Generated at 2022-06-25 18:05:55.901133
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify="no")) == {'verify': False, 'cert': None, 'proxies': {}}
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify="no", cert="cert.pem")) == {'verify': False, 'cert': 'cert.pem', 'proxies': {}}

# Generated at 2022-06-25 18:06:08.462654
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test with proxy
    args_0 = module_0.Namespace()
    args_0.proxy = [module_0.Namespace(key='my.proxy.com')]
    args_0.verify = 'yes'
    args_0.cert = 'cert'
    args_0.cert_key = 'cert_key'

    kwargs_0 = make_send_kwargs_mergeable_from_env(args_0)
    assert kwargs_0['proxies']['my.proxy.com'] == ''
    assert kwargs_0['verify'] is True
    assert kwargs_0['cert'] == 'cert'
    assert kwargs_0['cert_key'] == 'cert_key'


# Generated at 2022-06-25 18:06:20.053095
# Unit test for function collect_messages
def test_collect_messages():
    import random
    for _ in range(1000):
        namespace_0 = module_0.Namespace()
        namespace_0.session_read_only = random.choice((None,
                                                       random.randint(0, 1000)))
        namespace_0.debug = random.choice((None,
                                           random.randint(0, 1000)))
        namespace_0.follow = random.choice((None,
                                            random.randint(0, 1000)))
        namespace_0.session = random.choice((None,
                                             random.randint(0, 1000)))
        namespace_0.offline = random.choice((None,
                                             random.randint(0, 1000)))
        namespace_0.max_redirects = random.choice((None,
                                                   random.randint(1, 1000)))
        namespace

# Generated at 2022-06-25 18:06:22.786673
# Unit test for function collect_messages
def test_collect_messages():
    assert callable(collect_messages)
    collect_messages(namespace_0, path_1, request_body_read_callback=lambda chunk: chunk)


# Generated at 2022-06-25 18:06:23.943235
# Unit test for function collect_messages
def test_collect_messages():
    # Check that the expected keys are present in the returned dictionary
    # Check that the values are as expected
    assert True


# Generated at 2022-06-25 18:06:31.187404
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Bool type test
    arg_4 = argparse.Namespace(
        chunked = True,
        json = True,
        method = 'GET',
        offline = False,
        params = '<unprintable file object>',
        proxy = '<unprintable file object>',
        url = 'http://httpbin.org/get?id=0',
        verify = None,
        cert = '<unprintable file object>',
        cert_key = '<unprintable file object>',
        files = '<unprintable file object>',
        form = True,
        headers = '<unprintable file object>',
        data = '<unprintable file object>',
        max_redirects = None
        )
    var_1 = make_send_kwargs(arg_4)

# Generated at 2022-06-25 18:06:33.917339
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Assigning arguments
    args = module_0.Namespace()
    args.timeout = None
    args.allow_redirects = False

    # Call the function
    result = make_send_kwargs(args)

    # Verify the result
    assert result.get('timeout') is None
    assert result.get('allow_redirects') is False


# Generated at 2022-06-25 18:06:50.554549
# Unit test for function max_headers
def test_max_headers():
    pass

# Generated at 2022-06-25 18:06:51.989527
# Unit test for function max_headers
def test_max_headers():
    pass


# Generated at 2022-06-25 18:06:55.425660
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    namespace_0 = module_0.Namespace()
    dict_0 = make_send_kwargs(namespace_0)


import argparse as module_0

import requests as module_1


# Generated at 2022-06-25 18:06:58.915002
# Unit test for function collect_messages
def test_collect_messages():
    # Initialize the class with dummy args
    args_0 = argparse.Namespace()
    config_dir_0 = Path()
    request_body_read_callback_0 = None

    # Call collect_messages
    result_0 = collect_messages(args_0, config_dir_0, request_body_read_callback_0)

    return


# Generated at 2022-06-25 18:07:01.598752
# Unit test for function make_default_headers
def test_make_default_headers():
    namespace_0 = module_0.Namespace()
    dict_0 = make_default_headers(namespace_0)



# Generated at 2022-06-25 18:07:06.104461
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    namespace_1 = module_0.Namespace()
    dict_0 = make_send_kwargs(namespace_1)
    assert dict_0 == {'allow_redirects': False, 'timeout': None}
    assert namespace_1 == {'allow_redirects': False, 'timeout': None}

import sys as module_1


# Generated at 2022-06-25 18:07:07.962132
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    namespace_c = module_0.Namespace()
    assert make_send_kwargs(namespace_c) == dict_0

import argparse as module_1


# Generated at 2022-06-25 18:07:11.372307
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    assert "method undefined"
    assert "url undefined"
    assert "headers undefined"
    assert "data undefined"
    assert "auth undefined"
    assert "params undefined"



# Generated at 2022-06-25 18:07:13.331187
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        pass
    with max_headers(None):
        pass


# Generated at 2022-06-25 18:07:16.811325
# Unit test for function make_default_headers
def test_make_default_headers():
    arguments_0 = module_0.Namespace()
    arguments_0.json = False
    arguments_0.form = False
    arguments_0.data = {}
    assert {} == make_default_headers(arguments_0)


# Generated at 2022-06-25 18:07:51.200380
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # noinspection PyTypeChecker
    assert make_send_kwargs_mergeable_from_env(None) == {'proxies': {}, 'stream': True, 'verify': None}


from collections import OrderedDict
from httpie.sessions import Session
from requests.sessions import Session as Session_0


# Generated at 2022-06-25 18:07:53.575847
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    namespace_0 = module_0.Namespace()
    dict_0 = make_send_kwargs_mergeable_from_env(namespace_0)


# Generated at 2022-06-25 18:07:56.985268
# Unit test for function build_requests_session
def test_build_requests_session():
    if test_build_requests_session.__name__ == 'test_build_requests_session':
        build_requests_session(**{'ssl_version': None, 'ciphers': None, 'verify': True})


# Generated at 2022-06-25 18:07:59.290728
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env('namespace_1') == 'dict_1'


# Generated at 2022-06-25 18:08:01.313915
# Unit test for function collect_messages
def test_collect_messages():
    assert 0 == 1



# Generated at 2022-06-25 18:08:12.366311
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:08:15.851457
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    namespace_0 = argparse.Namespace()
    pathlib_0 = Path()
    callable_0 = lambda bytes: None
    iterable_0 = collect_messages(namespace_0, pathlib_0, callable_0)


# Generated at 2022-06-25 18:08:21.570590
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, "tlsv1_2", "EECDH+ECDSA+AESGCM:EECDH+aRSA+AESGCM:EECDH+ECDSA+SHA384:EECDH+ECDSA+SHA256:EECDH+aRSA+SHA384:EECDH+aRSA+SHA256:EECDH+aRSA+RC4:EECDH:EDH+aRSA:HIGH:!RC4:!aNULL:!eNULL:!LOW:!3DES:!MD5:!EXP:!PSK:!SRP:!DSS:!SSLv2")
    print(session)
    assert True


# Generated at 2022-06-25 18:08:24.279177
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    namespace_0 = module_0.Namespace()
    dict_0 = make_request_kwargs(namespace_0)


# Generated at 2022-06-25 18:08:26.736812
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    namespace_1 = module_0.Namespace()
    dict_1 = make_send_kwargs_mergeable_from_env(namespace_1)


# Generated at 2022-06-25 18:09:31.739132
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = b'{"key": "value"}'
    args.json = False
    args.form = False
    args.files = False
    headers = make_default_headers(args)

    assert headers['Content-Type'] == 'application/json'
    assert headers['Accept'] == 'application/json, */*;q=0.5'


# Generated at 2022-06-25 18:09:35.676223
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_0 = argparse.Namespace()
    args_0.timeout = None
    args_0.allow_redirects = False
    kwargs = make_send_kwargs(args_0)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }



# Generated at 2022-06-25 18:09:36.591608
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None):
        pass


# Generated at 2022-06-25 18:09:46.499542
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    config_dir = Path('./config')
    req = {
        'url': 'https://httpbin.org/get',
        'method': 'GET',
        'headers': {
            'User-Agent': 'HTTPie/2.2.0',
            'Accept-Encoding': 'gzip, deflate',
            'Accept': '*/*',
            'Connection': 'keep-alive',
            'Content-Length': '0',
        },
        'auth': None,
        'timeout': None,
        'allow_redirects': False,
        'stream': True,
        'verify': True,
        'cert': None,
        'files': {},
        'params': {},
    }
    test_reqs = []

# Generated at 2022-06-25 18:09:56.222822
# Unit test for function collect_messages
def test_collect_messages():
    bool_0 = False
    config_dir = Path('.')
    args = argparse.ArgumentParser()
    args.base_headers = None
    args.ciphers = None
    args.ssl_version = None
    args.verify = bool_0
    kwargs = make_send_kwargs_mergeable_from_env(args)
    requests_session = build_requests_session(bool_0)
    httpie_session = get_httpie_session(
        config_dir=Path('.'),
        host=args.headers.get('Host'),
        url=args.url,
        session_name="'default'"
    )
    request_kwargs = make_request_kwargs(args)
    request_kwargs['headers'] = {}

# Generated at 2022-06-25 18:10:01.292858
# Unit test for function max_headers
def test_max_headers():
    bool_0 = False
    with max_headers(bool_0):
        pass


# Generated at 2022-06-25 18:10:02.931086
# Unit test for function collect_messages
def test_collect_messages():
    assert callable(collect_messages)


# Generated at 2022-06-25 18:10:06.846063
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 7
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': 7, 'allow_redirects': False}


# Generated at 2022-06-25 18:10:08.219289
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    assert make_request_kwargs is not None


# Generated at 2022-06-25 18:10:12.656559
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    from httpie.cli import parser

    args = parser.parse_args(['--max-headers=42', 'https://httpbin.org/get'])
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] is not None
    assert kwargs['allow_redirects'] is False


# Generated at 2022-06-25 18:15:02.673518
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify', default='True')
    parser.add_argument('--proxy', default='127.0.0.1:8080', action='append')
    parser.add_argument('--cert', default='/abc.crt')
    parser.add_argument('--cert-key', default='/abc.key')

    args = parser.parse_args()
    for arg in vars(args):
        print("Argument {}: {}".format(arg, getattr(args, arg)))

    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True