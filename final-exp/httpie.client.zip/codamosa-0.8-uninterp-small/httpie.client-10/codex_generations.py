

# Generated at 2022-06-25 18:05:29.666760
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie import cli
    from httpie import __version__
    from httpie.cli import session
    from httpie.cli import dicts
    import httpie.cli
    import argparse
    import http.client
    import json
    import sys
    from contextlib import contextmanager
    from pathlib import Path
    from typing import Callable, Iterable, Union
    from urllib.parse import urlparse, urlunparse
    
    import requests
    # noinspection PyPackageRequirements
    import urllib3
    from httpie import __version__
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.ssl import AVAILABLE_SSL_VERSION_ARG_

# Generated at 2022-06-25 18:05:32.023137
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = None
    args.verify = True
    args.proxy = None
    result = make_send_kwargs_mergeable_from_env(args)
    assert result['cert'] is None
    assert result['proxies'] is None
    assert result['verify'] is True
    assert result['stream'] is True


# Generated at 2022-06-25 18:05:39.493853
# Unit test for function make_default_headers
def test_make_default_headers():
    namespace_0 = module_0.Namespace()
    result_0 = make_default_headers(namespace_0)
    assert result_0 == {
        'User-Agent': DEFAULT_UA
    }
    namespace_1 = module_0.Namespace()
    namespace_1.timeout = 5
    namespace_1.verify = "false"
    namespace_1.data = True
    result_1 = make_default_headers(namespace_1)
    assert result_1 == {
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT
    }
    namespace_2 = module_0.Namespace()
    namespace_2.timeout = 5
    namespace_2.verify = "false"

# Generated at 2022-06-25 18:05:41.462757
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = namespace_0
    expected_output = module_0
    actual_output = make_send_kwargs_mergeable_from_env(args)

    assert actual_output == expected_output

# Generated at 2022-06-25 18:05:45.206020
# Unit test for function finalize_headers
def test_finalize_headers():
    dict_0 = {
        'Transfer-Encoding': 'chunked',
        'Accept': 'application/json, */*;q=0.5',
        'Content-Type': 'application/json',
        'User-Agent': 'HTTPie/1.0.3',
    }
    request_headers_dict_1 = finalize_headers(dict_0)


# Generated at 2022-06-25 18:05:53.108532
# Unit test for function make_default_headers
def test_make_default_headers():
    def mock_make_default_headers(args):
        names = []
        for name, value in args.items():
            if value is not None:
                #
                value = value.strip()
            if isinstance(value, str):
                value = value.encode('utf8')
            names.append((name, value))
        return names

    def mock_make_default_headers_1(headers):
        names = []
        for name, value in headers.items():
            if value is not None:
                value = value.strip()
            if isinstance(value, str):
                value = value.encode('utf8')
            names.append((name, value))
        return names

    namespace_0 = module_0.Namespace()

# Generated at 2022-06-25 18:05:53.739793
# Unit test for function collect_messages
def test_collect_messages():
    assert True

# Generated at 2022-06-25 18:05:55.861102
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session_0 = build_requests_session(True, 'TLSv1', 'HIGH')
    assert requests_session_0.mounts


# Generated at 2022-06-25 18:05:57.926927
# Unit test for function make_default_headers
def test_make_default_headers():
    assert callable(make_default_headers), \
        'make_default_headers should be callable'


# Generated at 2022-06-25 18:06:04.125534
# Unit test for function make_default_headers
def test_make_default_headers():
    namespace_case_0 = module_0.Namespace()
    assert make_default_headers(namespace_case_0) == {'User-Agent': 'HTTPie/0.2.0'}


import argparse as module_1


# Generated at 2022-06-25 18:06:42.008042
# Unit test for function collect_messages
def test_collect_messages():
    # <https://github.com/httpie/httpie/issues/802>
    # noinspection PyUnresolvedReferences
    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = float('Inf')

# Generated at 2022-06-25 18:06:50.983480
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = argparse.Namespace()
    args_0.__dict__['method'] = 'GET'
    args_0.__dict__['url'] = 'http://foo.com/'
    args_0.__dict__['headers'] = {'key': 'value'}
    args_0.__dict__['data'] = 'data_0'
    args_0.__dict__['auth'] = 'auth_0'
    args_0.__dict__['params'] = [('key_0', 'value_0'), ('key_1', 'value_1')]
    kwargs_0 = make_request_kwargs(args_0)
    assert kwargs_0['method'] == 'get'
    assert kwargs_0['url'] == args_0.url
    assert kwargs_0

# Generated at 2022-06-25 18:06:53.646265
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_0 = None
    test_0 = make_send_kwargs(args_0)


# Generated at 2022-06-25 18:06:58.361286
# Unit test for function make_send_kwargs
def test_make_send_kwargs():

    # Check that all fields of the expected output are created
    timeout = 0;
    allow_redirects = True
    kwargs = make_send_kwargs(timeout, allow_redirects)
    assert kwargs == {'timeout': 0, 'allow_redirects': True}


# Generated at 2022-06-25 18:07:04.546498
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=None, allow_redirects=False, verify=False, cert="cert", cert_key=None, proxy=None, cert_type="cert_type")
    args.files = None
    args.json = False
    args.form = False
    args.data = "data"
    args.method = "POST"
    args.url = "http://127.0.0.1:5000/create"
    args.headers = None
    args.compress = False
    args.max_redirects = None
    args.max_headers = None
    args.offline = False
    args.session = None
    args.session_read_only = None
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.json_

# Generated at 2022-06-25 18:07:15.729004
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = argparse.Namespace(chunked=False, compress=False, debug=True, files=[], follow=True, form=False, headers={}, json=False, method='GET', offline=False, params=[], path_as_is=False, timeout=120, url='https://localhost:8443/')

    ret_0 = make_request_kwargs(args_0)

    assert ret_0 == {'method': 'get', 'url': 'https://localhost:8443/', 'headers': {'Accept': 'application/json, */*;q=0.5', 'User-Agent': 'HTTPie/1.0.2'}, 'data': None, 'auth': None, 'params': []}



# Generated at 2022-06-25 18:07:27.801538
# Unit test for function max_headers
def test_max_headers():
    bool_0 = True
    # noinspection PyTypeChecker
    str_0 = str_0
    config_dir = Path(str_0)
    req_0 = make_request_kwargs(config_dir)
    dict_0 = dict_0
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_8 = dict_7
    dict_9 = dict_8
    dict_10 = dict_9
    dict_11 = dict_10
    dict_12 = dict_11
    dict_13 = dict_12
    dict_14 = dict_13
    dict_15 = dict_14


# Generated at 2022-06-25 18:07:34.949987
# Unit test for function make_default_headers

# Generated at 2022-06-25 18:07:36.107674
# Unit test for function collect_messages
def test_collect_messages():
    collect_messages(None, None)

# Generated at 2022-06-25 18:07:41.250157
# Unit test for function collect_messages
def test_collect_messages():
    config_dir = Path('.')
    args = argparse.Namespace()
    for item in collect_messages(args, config_dir):
        assert item.body
        # assert isinstance(item, requests.PreparedRequest)
        assert item.body

# Generated at 2022-06-25 18:08:17.231709
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert ('timeout' in make_send_kwargs(argparse.Namespace(timeout='timeout_arg')) and 'timeout_arg' in make_send_kwargs(argparse.Namespace(timeout='timeout_arg'))['timeout'])
    assert ('allow_redirects' in make_send_kwargs(argparse.Namespace(always_allow_redirects=True)) and \
            make_send_kwargs(argparse.Namespace(always_allow_redirects=True))['allow_redirects'] == True)
    assert ('allow_redirects' in make_send_kwargs(argparse.Namespace(always_allow_redirects=False)) and \
            make_send_kwargs(argparse.Namespace(always_allow_redirects=False))['allow_redirects'] == False)

# Generated at 2022-06-25 18:08:28.215953
# Unit test for function make_default_headers

# Generated at 2022-06-25 18:08:34.131865
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace(data=None, json=None, form=None, files=None)
    actual_outcome_0 = make_default_headers(args_0)
    expected_outcome_0 = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    assert expected_outcome_0 == actual_outcome_0


# Generated at 2022-06-25 18:08:38.249920
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env.__doc__
    assert make_send_kwargs_mergeable_from_env.__annotations__


# Generated at 2022-06-25 18:08:41.910590
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = None
    default_headers_0 = make_default_headers(args_0)
    assert default_headers_0 == {'User-Agent': DEFAULT_UA}


# Generated at 2022-06-25 18:08:50.162595
# Unit test for function collect_messages
def test_collect_messages():
    class Arguments(object):
        def __init__(self, arg_url, arg_header, arg_data, arg_form, arg_json, arg_files,
                     arg_offline, arg_auth, arg_method, arg_params, arg_chunked, arg_verify):
            self.url = arg_url
            self.headers = arg_header
            self.data = arg_data
            self.form = arg_form
            self.json = arg_json
            self.files = arg_files
            self.offline = arg_offline
            self.auth = arg_auth
            self.method = arg_method
            self.params = arg_params
            self.chunked = arg_chunked
            self.verify = arg_verify
            self.path_as_is = False
           

# Generated at 2022-06-25 18:08:53.532711
# Unit test for function max_headers
def test_max_headers():
    with max_headers(0):
        print()

if __name__ == '__main__':
    print(test_max_headers())

# Generated at 2022-06-25 18:08:55.146102
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(True) is not None


# Generated at 2022-06-25 18:09:06.626038
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    t0 = {
        'method': 'GET',
        'url': 'http://127.0.0.1:5000/',
        'headers': {
            'User-Agent': 'HTTPie/0.9.6',
            'Accept': 'application/json, */*;q=0.5'
        },
        'data': '',
        'auth': None,
        'params': ()
    }
    res0 = make_request_kwargs(None)
    # diff = DictDiffer(res0, t0)
    print('Test case 0:')
    for k in t0.keys():
        assert res0[k] == t0[k]
    print('\nRES:', repr_dict(res0))
    print('\nT0:', repr_dict(t0))

    print

# Generated at 2022-06-25 18:09:12.543310
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace()
    args_0.headers = {"User-Agent":"HTTPie/0.9.9"}
    args_0.json =  False
    args_0.form = True
    args_0.files = False
    args_0.data = True
    test_result = make_default_headers(args_0)
    assert test_result == {'User-Agent': 'HTTPie/0.9.9', 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}

# Generated at 2022-06-25 18:10:47.061169
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = {}
    args.form = False
    args.json = False

    # test for the function
    ret_obj = make_default_headers(args)
    assert ret_obj['User-Agent'] == DEFAULT_UA

    ret_obj = make_default_headers(args)
    ret_obj['User-Agent'] = 'httpie/0.9.9'
    assert ret_obj['User-Agent'] == 'httpie/0.9.9'

# unit test for function build_requests_session

# Generated at 2022-06-25 18:10:55.327922
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    dummy_args = argparse.Namespace()
    dummy_args.proxy = [('x', 'y')]
    dummy_args.verify = True
    dummy_args.cert = 'certificate.pem'
    dummy_args.cert_key = 'certificate_key.pem'

    expected = {'proxies': {'x': 'y'}, 'stream': True, 'verify': True, 'cert': ('certificate.pem', 'certificate_key.pem')}
    actual = make_send_kwargs_mergeable_from_env(dummy_args)
    assert actual == expected


# Generated at 2022-06-25 18:11:01.586256
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test 1
    args = argparse.Namespace(verify='True')
    res = make_send_kwargs_mergeable_from_env(args)
    assert res == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }



# Generated at 2022-06-25 18:11:09.958158
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    test_args = argparse.Namespace()
    test_args.verify = 'yes'
    test_args.cert_key = 'foo'
    test_args.cert = 'bar'

    test_args.proxy = [
        argparse.Namespace(
            key='proxies-0-key',
            value='proxies-0-value'
        ),
        argparse.Namespace(
            key='proxies-1-key',
            value='proxies-1-value'
        ),
    ]

    test_send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(test_args)

    assert test_send_kwargs_mergeable_from_env['verify'] is True
    assert test_send_kwargs_mer

# Generated at 2022-06-25 18:11:18.926832
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():

    # Test 1: No proxy and verify True
    args_0 = argparse.Namespace()
    args_0.verify = 'true'
    # Call the function
    dict_0 = make_send_kwargs_mergeable_from_env(args_0)
    # Assert statements
    print(dict_0)
    assert dict_0['verify'] == True

    # Test 2: With proxy and verify False
    args_1 = argparse.Namespace()
    args_1.verify = 'false'
    args_1.proxy = ['http://proxy:8080']
    # Call the function
    dict_1 = make_send_kwargs_mergeable_from_env(args_1)
    # Assert statements

# Generated at 2022-06-25 18:11:24.787822
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = argparse.Namespace()
    args_0.proxy = {"proxy": "proxy"}
    args_0.verify = "verify"
    args_0.cert = "cert"
    assert (make_send_kwargs_mergeable_from_env(args_0) == {"proxies": {"proxy": "proxy"}, "stream": True, "verify": "verify", "cert": "cert"})


# Generated at 2022-06-25 18:11:34.795575
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = argparse.Namespace()
    args_0.method = 'get'
    args_0.url = 'https://httpbin.org/json'
    args_0.offline = None
    args_0.timeout = None
    args_0.auth = None
    args_0.headers = {'Host': 'httpbin.org', 'User-Agent': 'HTTPie/0.9.7'}
    args_0.json = True
    args_0.form = None
    args_0.files = None
    args_0.data = '{"hello": "world"}'
    args_0.params = {'p': 'hello'}
    args_0.compress = None
    args_0.compress_level = 6
    args_0.chunked = None
    args_0

# Generated at 2022-06-25 18:11:40.505831
# Unit test for function collect_messages
def test_collect_messages():
    # fixture
    from tempfile import TemporaryDirectory
    from httpie.cli import parser

    with TemporaryDirectory() as temp_dir_path:
        temp_dir = Path(temp_dir_path)
        args = parser.parse_args([
            'https://httpbin.org/anything',
        ])
        args.method = 'GET'

        args.session = 'my-session'
        args.auth = 'user:70'
        args.auth_plugin = []
        args.json = False
        args.debug = True
        config_dir = temp_dir

        try:
            # call
            for item in collect_messages(args, config_dir): pass
        except:
            print('Error: {}'.format(sys.exc_info()[1]))

# Generated at 2022-06-25 18:11:50.387293
# Unit test for function collect_messages
def test_collect_messages():
    import sys
    import unittest

    import pytest

    pytest.main([__file__])
    # env_arg_0 = EnvironmentAgnosticNamespace(
    #     arg_0='data', arg_1='headers', arg_2='url', arg_3=None, arg_4=True, arg_5=False,
    #     arg_6=None, arg_7=0, arg_8=[], arg_9=None)
    # class_0 = RequestHeadersDict()
    # str_0 = 'Content-Type'
    # str_1 = 'application/x-www-form-urlencoded; charset=utf-8'
    # class_0[str_0] = str_1
    # str_2 = 'Content-Type'
    # str_3 = 'application/json'

# Generated at 2022-06-25 18:12:01.026194
# Unit test for function collect_messages
def test_collect_messages():
    # Arrange
    import sys
    import tempfile
    import shutil
    import os
    import json

    def dummy_print(s, end=None, flush=None):
        if not hasattr(dummy_print, 'calls'):
            dummy_print.calls = []
        dummy_print.calls.append(s)

    old_print = print
    print = dummy_print

    temp_dir = tempfile.mkdtemp(prefix='httptest_')
    # temp_dir = 'c:\\tmp\\httptest_'
    os.makedirs(temp_dir, exist_ok=True)

    arg_parser = argparse.ArgumentParser()

# Generated at 2022-06-25 18:14:36.724573
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    parser = argparse.ArgumentParser()
    parser.add_argument("--proxy", dest="proxy", action="append", default=[])
    parser.add_argument("--verify", dest="verify", default=None)
    parser.add_argument("--cert", dest="cert", default=None)
    parser.add_argument("--cert-key", dest="cert_key", default=None)

    parser.add_argument("--debug")
    parser.add_argument("--session")
    parser.add_argument("--session-read-only")
    parser.add_argument("--auth")
    parser.add_argument("--auth-type")
    parser.add_argument("--auth-plugin")
    parser.add_argument("--ignore-stdin")
    parser.add_argument("--timeout")
    parser.add

# Generated at 2022-06-25 18:14:43.976725
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    sentinel = object()

    def generate_args(**kwargs):
        args = argparse.Namespace()
        for key, value in kwargs.items():
            setattr(args, key, value)
        return args

    # Test sending JSON data.
    data = {'foo': 'bar'}
    kwargs = make_request_kwargs(generate_args(json=True, data=data))
    assert kwargs['data'] == json.dumps(data)
    assert kwargs['headers']['Content-Type'] == JSON_CONTENT_TYPE
    assert kwargs['headers']['Accept'] == JSON_ACCEPT

    # Test sending form data.
    data = {'foo': 'bar'}

# Generated at 2022-06-25 18:14:50.686366
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    bool_0 = True
    str_0 = 'Use_a_keyboard_shortcut_'
    cert_0 = 'Use_a_keyboard_shortcut_'
    key_0 = 'Use_a_keyboard_shortcut_'
    cert_key_0 = cert_0, key_0
    argv_0 = argparse.Namespace(verify='Use_a_keyboard_shortcut_', cert=cert_key_0, cert_key=key_0, proxy=['--proxy'])
    kwargs_0 = make_send_kwargs_mergeable_from_env(argv_0)
    assert kwargs_0['cert'] == cert_key_0
    assert kwargs_0['proxies'] == {'--proxy': '--proxy'}
    assert kw

# Generated at 2022-06-25 18:14:54.370677
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Test args
    args_0 = argparse.Namespace()
    args_0.timeout = None
    args_0.allow_redirects = False

    # Call function
    res = make_send_kwargs(args_0)

    # Test result
    assert res == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-25 18:15:03.737218
# Unit test for function make_default_headers
def test_make_default_headers():
    class MockParser:
        def __init__(self, test_argv):
            self.test_argv = test_argv

    partial_args = {
        'json': False,
        'form': False,
        'files': False,
        'offline': False,
        'chunked': False,
        'headers': {},
    }
    args = argparse.Namespace(**partial_args)
    result = make_default_headers(args)
    assert result['User-Agent'] == DEFAULT_UA
    assert not result.get('Content-Type')
    assert DEFAULT_UA in result['User-Agent']

    args.json = True
    result = make_default_headers(args)
    assert result['User-Agent'] == DEFAULT_UA
    assert result['Accept'] == JSON_ACCEPT