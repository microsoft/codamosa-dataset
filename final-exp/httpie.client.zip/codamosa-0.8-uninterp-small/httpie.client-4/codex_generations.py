

# Generated at 2022-06-25 18:05:26.858170
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    dict_0 = make_send_kwargs_mergeable_from_env(module_0.Namespace())


# Generated at 2022-06-25 18:05:30.765574
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    mydict = make_send_kwargs(args)
    # Check if key exists
    assert 'timeout' in mydict
    assert 'allow_redirects' in mydict


# Generated at 2022-06-25 18:05:33.095550
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    namespace_0 = module_0.Namespace()
    dict_0 = make_send_kwargs_mergeable_from_env(namespace_0)


# Generated at 2022-06-25 18:05:39.068874
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    namespace_1 = module_0.Namespace()
    dict_1 = make_request_kwargs(namespace_1)

    dict_0 = dict_1
    assert (dict_0["data"] == None), "The value of dict_0['data'] is not equal to None."
    assert (dict_0["headers"] != None), "The value of dict_0['headers'] is equal to None."
    assert (dict_0["auth"] == None), "The value of dict_0['auth'] is not equal to None."


if __name__ == '__main__':
    test_case_0()
    test_make_request_kwargs()

# Generated at 2022-06-25 18:05:41.527958
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    namespace_0 = module_0.Namespace()
    namespace_0.verify = 'False'
    namespace_0.proxy = []
    assert make_send_kwargs_mergeable_from_env(namespace_0) is None


# Generated at 2022-06-25 18:05:49.347893
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    namespace_0 = argparse.Namespace()
    dict_0_expected = dict()
    dict_0_expected['method'] = 'get'
    dict_0_expected['url'] = ''
    dict_0_expected['headers'] = dict()
    dict_0_expected['headers']['User-Agent'] = 'HTTPie/0.9.9'
    dict_0_expected['data'] = None
    dict_0_expected['auth'] = None
    dict_0_expected['params'] = list()
    dict_0 = make_request_kwargs(namespace_0)

# Generated at 2022-06-25 18:05:54.747323
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import argparse as module_0
    namespace_0 = module_0.Namespace()
    namespace_0.verify = "yes"
    namespace_0.proxy = []
    namespace_0.cert = None
    namespace_0.cert_key = None
    dict_0 = make_send_kwargs_mergeable_from_env(namespace_0)
    assert dict_0 == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}


# Generated at 2022-06-25 18:06:02.180926
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {
        b'Content-Type': b'',
        b'x-test-header': None,
    }
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        assert finalize_headers(headers) == {
            b'content-type': b'',
        }


# Generated at 2022-06-25 18:06:11.472161
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    namespace_0 = argparse.Namespace()
    dict_0 = make_request_kwargs(namespace_0)
    assert dict_0['method'] == 'get'
    assert dict_0['url'] == ''
    assert dict_0['headers'] == {'User-Agent': 'HTTPie/'}
    # assert dict_0['data'] == ''
    # assert dict_0['auth'] == ''
    # assert dict_0['params'] == ''

    namespace_1 = argparse.Namespace()
    namespace_1.method = 'poSt'
    namespace_1.url = 'someurl'
    namespace_1.headers = {
        'a': 'aaa',
        'b': 'bbb',
        'c': 'ccc',
    }
    namespace_1.data = 'somedata'


# Generated at 2022-06-25 18:06:23.633417
# Unit test for function make_default_headers
def test_make_default_headers():
    namespace_0 = module_0.Namespace()
    namespace_0.proxy = []
    namespace_0.timeout = 30.0
    namespace_0.cert = 'certfile'
    namespace_0.cert_key = 'keyfile'
    namespace_0.form = False
    namespace_0.json = False
    namespace_0.data = {}
    namespace_0.files = {}
    namespace_0.verify = 'true'
    namespace_0.headers = {}
    namespace_0.chunked = False
    namespace_0.method = 'GET'
    namespace_0.url = 'http://localhost:8000/echo?a=1'
    namespace_0.auth = None
    namespace_0.params = {}
    namespace_0.offline = False
    namespace_0.max_redirects = None

# Generated at 2022-06-25 18:06:49.438865
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    kwargs_0 = {
        'headers': {
            'User-Agent': 'HTTPie/0.0.0',
            'Accept': 'application/json, */*;q=0.5',
            'Content-Type': 'application/json'
        },
        'method': 'GET',
        'auth': None,
        'url': 'http://httpbin.org/get',
        'data': '{"foo": "bar"}',
        'params': []
    }
    assert make_request_kwargs(
        args=module_0.Namespace(),
        base_headers=None,
        request_body_read_callback=lambda chunk: chunk
    ) == kwargs_0

# Generated at 2022-06-25 18:07:01.602164
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = module_0.Namespace()
    args_0.auth = None
    args_0.auth_plugin = None
    args_0.boundary = None
    args_0.ciphers = None
    args_0.client_certs = None
    args_0.colors = None
    args_0.config = None
    args_0.debug = None
    args_0.download = None
    args_0.follow = None
    args_0.headers = None
    args_0.ignore_stdin = None
    args_0.implicit_content_type = None
    args_0.json = None
    args_0.mime = None
    args_0.multipart = None
    args_0.multipart_data = None
    args_0.offline = None

# Generated at 2022-06-25 18:07:05.476843
# Unit test for function make_default_headers
def test_make_default_headers():
    from httpie import __version__
    args = module_0.Namespace()
    args.data = None
    args.form = None
    request_headers_dict_0 = module_0.Namespace()
    request_headers_dict_0.items = lambda : None
    request_headers_dict_0.update = lambda x : None
    result_0 = make_default_headers(args)
    assert result_0 is not None
    assert result_0 == request_headers_dict_0
    assert result_0['User-Agent'] == f'HTTPie/{__version__}'


# Generated at 2022-06-25 18:07:17.238867
# Unit test for function collect_messages
def test_collect_messages():
    import sys as module_0
    namespace_0 = module_0.Namespace()
    namespace_0.session = None
    namespace_0.session_read_only = None
    namespace_0.url = "http://httpbin.org/post"
    namespace_0.headers = {'Connection': 'close', 'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'User-Agent': 'HTTPie/1.0.2'}
    namespace_0.compress = False
    namespace_0.debug = False
    namespace_0.max_redirects = 0
    namespace_0.follow = True
    namespace_0.method = "POST"
    namespace_0.auth = None
    namespace_0.auth_type = None
    namespace_0.auth_plugin = None
    namespace_0

# Generated at 2022-06-25 18:07:20.708554
# Unit test for function max_headers
def test_max_headers():
    
    with max_headers(100):
    # TODO: verify that http.client._MAXHEADERS is set and reset.
        pass


# Generated at 2022-06-25 18:07:24.802347
# Unit test for function collect_messages
def test_collect_messages():
    ns_0 = module_0.Namespace()
    collect_messages(
        args=ns_0,
        config_dir=Path(),
        request_body_read_callback=lambda chunk: chunk
    )


# Generated at 2022-06-25 18:07:26.548364
# Unit test for function collect_messages
def test_collect_messages():
    namespace_0 = case_0()
    namespace_1 = case_1()


# Generated at 2022-06-25 18:07:27.929241
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    assert isinstance(make_request_kwargs(namespace_0), dict)

# Generated at 2022-06-25 18:07:35.034991
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = module_0.Namespace(auth='', auth_type=None, auth_plugin=None, cert=None, cert_key=None, chunked=False, ciphers='', compress=0, json=False, form=False, data=None, files=None, headers={}, method='GET', multipart=False, multipart_data=[], params=[], path_as_is=False, proxy={}, proxy_auth='', raw_response=False, session=None, session_read_only=False, ssl_version=None, stream=False, traceback=False, timeout=None, url='http://example.com', verify=True, version=False)
    base_headers = RequestHeadersDict({})
    request_body_read_callback = lambda chunk: chunk

# Generated at 2022-06-25 18:07:41.889083
# Unit test for function max_headers
def test_max_headers():
    # Testing for TypeError
    try:
        with max_headers(10):
            pass
        assert False, 'Expected exception not thrown'
    except TypeError:
        pass
    # Testing for TypeError
    try:
        with max_headers(10):
            pass
        assert False, 'Expected exception not thrown'
    except TypeError:
        pass


# Generated at 2022-06-25 18:08:06.917947
# Unit test for function collect_messages
def test_collect_messages():
    with open('./tests/data/request_method_post.json') as json_file:
        args = json.load(json_file)
    config_dir = Path('./tests/data/config_dir')
    request_body_read_callback = lambda chunk: chunk
    expected = '<PreparedRequest \
[POST]>\n<PreparedRequest [POST]>\n<PreparedRequest [POST]>\n'
    result = ''
    for message in collect_messages(args, config_dir, request_body_read_callback):
        result += str(message)
    if result == expected:
        print('Success')
    else:
        print('Failed')


# Generated at 2022-06-25 18:08:16.399474
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    #  case0: args.method = 'post', args.data = {'key': 'value'}, args.json = False, args.form = False, args.chunked = False 
    args.method = 'post'
    args.data = {'key': 'value'}
    args.json = False
    args.form = False
    args.chunked = False

# Generated at 2022-06-25 18:08:27.553139
# Unit test for function make_default_headers
def test_make_default_headers():
    AVAILABLE_SSL_VERSION_ARG_MAPPING = {
        'SSL2': 'SSLv2',
        'SSL3': 'SSLv3',
        'TLS1': 'TLSv1',
        'TLS1.0': 'TLSv1',
        'TLS1.1': 'TLSv1_1',
        'TLS1.2': 'TLSv1_2',
        'TLS1.3': 'TLSv1_3',
    }
    test_args = argparse.Namespace()
    test_args.data = None
    test_args.form = None
    test_args.json = None
    test_args.ssl_version = 'TLS1.2'
    test_args.ciphers = None
    test_args.verify = True

# Generated at 2022-06-25 18:08:39.321929
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        chunked=None,
        compress=None,
        data=None,
        debug=False,
        files=None,
        form=None,
        headers={'Content-Type': 'text/html', 'Accept': 'text/plain'},
        json=None,
        method='GET',
        multipart=False,
        multithreaded=False,
        offline=None,
        params=[],
        path_as_is=False,
        proxy=[],
        session=None,
        session_read_only=False,
        timeout=None,
        url='http://127.0.0.1:8000/',
        verify=0x0,
    )

# Generated at 2022-06-25 18:08:40.590738
# Unit test for function max_headers
def test_max_headers():
    assert True == True


# Generated at 2022-06-25 18:08:43.198171
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = None
    headers_0 = make_default_headers(args_0)
    assert headers_0 is not None



# Generated at 2022-06-25 18:08:50.738455
# Unit test for function collect_messages
def test_collect_messages():
    c_c = type('collect_messages', (object,), {
        '__init__': lambda self: None,
        '__next__': lambda self: None
    })
    class F1:
        '''
        For testing purpose
        '''
        def __init__(self):
            self.request_kwargs = None
            self.kwargs = None
        def set_request_kwargs(self, request_kwargs):
            self.request_kwargs = request_kwargs
        def set_kwargs(self, kwargs):
            self.kwargs = kwargs
        def prepare_request(self, request):
            return c_c()
        def merge_environment_settings(self, **kwargs):
            return kwargs

# Generated at 2022-06-25 18:09:01.952407
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    print("Test Case 1: Using False")
    args = argparse.Namespace()
    args.verify = 'FALSE'
    expected = {'verify': False}
    actual = make_send_kwargs_mergeable_from_env(args)
    print("expected:", expected)
    print("  actual:", actual, end="\n\n")

    print("Test Case 2: Using True")
    args = argparse.Namespace()
    args.verify = 'TRUE'
    expected = {'verify': True}
    actual = make_send_kwargs_mergeable_from_env(args)
    print("expected:", expected)
    print("  actual:", actual, end="\n\n")

    print("Test Case 3: Using yes")
    args = argparse.Namespace

# Generated at 2022-06-25 18:09:12.340902
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.data = None
    args.form = False
    bool_0 = None
    args.headers = {}
    args.auth = None
    args.params = None
    args.json = False
    args.method = "GET"
    args.url = "http://httpbin.org/get"
    args.files = None
    args.multipart = None
    args.multipart_data = None
    args.boundary = None
    args.chunked = None
    args.offline = False
    request_body_read_callback = None
    base_headers = None
    kwargs = make_request_kwargs(args, base_headers, request_body_read_callback)

# Generated at 2022-06-25 18:09:17.449516
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    orig_args = ['http', '--include', 'http://httpbin.org/headers']
    args = plugin_manager.hook.httpie_parse_args(orig_args)
    kwargs = make_request_kwargs(args)
    headers = kwargs['headers']
    assert headers['Accept'] == 'application/json, */*;q=0.5'


# Generated at 2022-06-25 18:10:21.791698
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class Object():
        def __init__(self, *args, **kwargs):
            pass

    class Fake_args():
        def __init__(self, *args, **kwargs):
            pass

        @property
        def verify(self):
            return 'yes'

        @property
        def cert(self):
            return ''

        @property
        def cert_key(self):
            return ''

        @property
        def proxy(self):
            return [Object()]

    args = Fake_args()
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'verify': True, 'cert': None, 'proxies': {}, 'stream': True}


# Generated at 2022-06-25 18:10:30.593703
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://go.com'
    args.headers = [{'key': 'value'}]
    args.data = '{}'
    args.json = True
    args.form = False

# Generated at 2022-06-25 18:10:38.338030
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():

    args = argparse.Namespace(verify = "abc")
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == "abc"

    args = argparse.Namespace(verify = "yes")
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True

    args = argparse.Namespace(verify = "no")
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == False

    args = argparse.Namespace(verify = "true")
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs

# Generated at 2022-06-25 18:10:47.339700
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace()
    args_0.data = {}
    args_0.form = False
    args_0.json = False
    args_0.files = {}
    headers_0 = make_default_headers(args_0)
    assert headers_0 == {'User-Agent': 'HTTPie/' + __version__}
    headers_1 = make_default_headers(args_0)
    assert headers_1 == {'User-Agent': 'HTTPie/' + __version__}


# Generated at 2022-06-25 18:10:56.690315
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    url = "http"
    dic = {"type" : "json"}
    dic2 = {"type" : "json"}

# Generated at 2022-06-25 18:11:07.053178
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    def run_test(test_name, args, expected_result):
        args = [
            '--allow-redirects',
            '--timeout',
            str(args[0]),
        ] + args[1]
        parser = argparse.ArgumentParser()
        plugin_manager.add_global_options(parser, color=False)
        plugin_manager.load_plugins()
        plugin_manager.add_commands_from_plugins(parser)
        args = parser.parse_args(args=args)
        assert make_send_kwargs_mergeable_from_env(args) == expected_result, test_name


# Generated at 2022-06-25 18:11:18.086851
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Test case data
    # Example 1
    args_1 = argparse.Namespace()
    args_1.timeout = None
    # Example 2
    args_2 = argparse.Namespace()
    args_2.timeout = 0
    # Example 3
    args_3 = argparse.Namespace()
    args_3.timeout = None
    # Example 4
    args_4 = argparse.Namespace()
    args_4.timeout = 9.8
    # Example 5
    args_5 = argparse.Namespace()
    args_5.timeout = None
    # Example 6
    args_6 = argparse.Namespace()
    args_6.timeout = '0'
    # Example 7
    args_7 = argparse.Namespace()
    args_7.timeout = None
    # Example 8
    args

# Generated at 2022-06-25 18:11:27.483522
# Unit test for function make_default_headers
def test_make_default_headers():
    class MockArgs:
        def __init__(self, headers=None, data=None, form=None, json=None, files=None):
            self.headers = RequestHeadersDict(headers)
            self.data = data
            self.form = form
            self.json = json
            self.files = files

    assert {
        'User-Agent': DEFAULT_UA
    } == make_default_headers(MockArgs()).dict

    assert {
        'User-Agent': DEFAULT_UA,
        'Content-Type': FORM_CONTENT_TYPE
    } == make_default_headers(MockArgs(form=True)).dict


# Generated at 2022-06-25 18:11:37.081597
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()

    args.method = 'GET'
    args.url = 'http://foo.com/bar'
    args.auth = None

    args.headers = RequestHeadersDict()
    args.headers['Content-Type'] = 'application/json'

    args.data = '{}'

    args.files = []

    args.json = False
    args.form = False
    args.chunked = False
    args.offline = False

    args.compress = False
    args.debug = False
    args.max_redirects = 30
    args.max_headers = None
    args.multipart = False
    args.multipart_data = []
    args.noproxy = []
    args.path_as_is = False
    args.proxy = []


# Generated at 2022-06-25 18:11:42.691212
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    make_send_kwargs_0 = make_send_kwargs(
        {
            "url": "https://httpie.org",
            "method": "GET",
            "headers": {},
            "auth": None,
            "auth_plugin": None,
            "follow_redirects": True,
            "max_redirects": 10,
            "timeout": 9.05,
        }
    )



# Generated at 2022-06-25 18:12:53.260674
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 30
    args.auth = 'user:pass'
    args.verify = 'no'
    args.method = 'post'
    args.headers = {'Accept': 'application/json'}
    args.data = {'name': 'httpie', 'version': 1.0}
    args.json = True
    args.url = "http://httpbin.org/post"
    args.files = False
    args.form = False
    args.compress = False
    args.max_redirects = 5
    args.all = False
    args.session = None
    args.proxy = []
    args.follow = False
    args.max_headers = None
    args.session = 'session'
    args.auth_plugin = "none"
    args

# Generated at 2022-06-25 18:13:01.850123
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    argv = ""

    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('url', nargs='?', type=str)
    parser.add_argument('--data', nargs='?', type=str)
    parser.add_argument('-H', '--header', nargs='*', type=str)
    parser.add_argument('-a', '--auth-type', nargs='?', type=str)
    parser.add_argument('--auth-type', nargs='?', type=str)
    parser.add_argument('--auth', nargs='?', type=str)
    parser.add_argument('-o', '--output', nargs='?', type=str)
    parser.add_argument('--download', nargs='?', type=str)
   

# Generated at 2022-06-25 18:13:05.429752
# Unit test for function build_requests_session
def test_build_requests_session():
    bool_1 = None
    str_2 = None
    str_3 = None
    expected = requests.Session()
    actual = build_requests_session(bool_1, str_2, str_3)
    assert actual == expected


# Generated at 2022-06-25 18:13:07.778552
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    kwargs = {'timeout': None, 'allow_redirects': False}
    assert make_send_kwargs(args) == kwargs


# Generated at 2022-06-25 18:13:17.343629
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    method_0 = 'Post'
    url_0 = 'https://www.google.com/'
    headers_0 = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
        'Accept-Language': 'en-US,en;q=0.5'
    }
    data_0 = {
        'id': '010',
        'name': 'kwak'
    }
    auth_0 = None
    params_0 = []
    # result = make_request_kwargs({'method': method_0, 'url': url_0, 'headers': headers_0, 'data': data_0, 'auth': auth_0, 'params': params_0})
    #

# Generated at 2022-06-25 18:13:19.362178
# Unit test for function make_default_headers
def test_make_default_headers():
    if True:
        raise ImportError
    else:
        pass
    if True:
        pass
    else:
        raise ImportError

# Generated at 2022-06-25 18:13:29.166263
# Unit test for function collect_messages
def test_collect_messages():
    # Test: args = arg<parser.Namespace> | config_dir = arg<Path> | request_body_read_callback = arg<Callable[[bytes], None]>
    # 
    # Failures:
    # test_collect_messages | args = arg<parser.Namespace> | config_dir = arg<Path> | request_body_read_callback = arg<Callable[[bytes], None]>
    # 
    # Errors:
    # collect_messages | args = arg<parser.Namespace> | config_dir = arg<Path> | request_body_read_callback = arg<Callable[[bytes], None]>
    # 
    # Returns:
    # Iterable[Union[requests.PreparedRequest, requests.Response]]
    # 
    pass


# Generated at 2022-06-25 18:13:35.535606
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class Dummy:
        pass
    temp_arg = Dummy()
    temp_arg.data = None
    temp_arg.method = 0
    temp_arg.url = 0
    temp_arg.auth = 0
    temp_arg.headers = 0
    temp_arg.params = 0
    temp_arg.files = 0
    temp_arg.form = 0
    temp_arg.json = 0
    temp_arg.timeout = 0
    temp_arg.compress = 0
    temp_arg.chunked = 0
    temp_arg.debug = 0
    temp_arg.session = 0
    temp_arg.session_read_only = 0
    temp_arg.verify = 0
    temp_arg.cert = 0
    temp_arg.cert_key = 0

# Generated at 2022-06-25 18:13:41.422430
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    
    args = argparse.Namespace(auth=None, cert=None, cert_key=None, chunked=False, client_cert=None, client_key=None, compile_test=False, cookies=None, data=None, debug=False, default=False, files=None, follow=False, form=False, ignore_stdin=False, json=None, max_headers=None, multipart=False, multipart_data=None, offline=False, params=None, path_as_is=False, proxy=None, session=None, session_read_only=None, ssl_version=None, timeout=None, traceback=False, url=None, verify=None, version=False, all=False, auth_plugin=None, boundary=None, ciphers=None, method='GET', max_redirects=None)
    

# Generated at 2022-06-25 18:13:47.887821
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    headers = RequestHeadersDict()
    args.method = 'get'
    args.url = 'http://foo'
    args.headers = headers
    args.data = '{"a", "b"}'
    args.json = '{"a", "b"}'
    args.form = [{"a", "b"}]
    args.multipart = True
    args.multipart_data = [{"a", "b"}]
    args.boundary = "--a"
    args.files = [{'a', 'b'}]
    args.auth = 'auth'
    args.params = {'a': 'a'}
    args.offline = True
    args.chunked = True
    kwargs = make_request_kwargs(args)
   

# Generated at 2022-06-25 18:15:05.208565
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace
    args_0.json = False
    args_0.form = False
    headers_0 = make_default_headers(args_0)
    header = 'User-Agent'
    assert header in headers_0
