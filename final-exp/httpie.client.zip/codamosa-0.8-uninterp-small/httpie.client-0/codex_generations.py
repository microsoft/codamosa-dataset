

# Generated at 2022-06-25 18:05:33.742875
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class args:
        def __init__(self):
            self.timeout = None
            self.allow_redirects = False

    res = make_send_kwargs(args())
    assert res == {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-25 18:05:38.705186
# Unit test for function collect_messages
def test_collect_messages():
    from tempfile import TemporaryDirectory
    from unittest.mock import Mock
    import argparse

    class MockClass0:
        headers = {}

        def __init__(self, cnt):
            self.read = Mock(side_effect=lambda cnt: b'X' * cnt)

    class MockClass1:
        name = "name"
        value = "value"

    class MockClass2:
        key = "key"
        value = "value"

    args = argparse.Namespace()
    args.session = None
    args.session_read_only = None
    args.url = "http://localhost"
    args.method = "get"
    args.headers = {}
    args.auth = None
    args.auth_plugin = None
    args.debug = False
    args.json = False


# Generated at 2022-06-25 18:05:45.791903
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    """
    Verify that the function make_send_kwargs returns the correct value for
    the give set of inputs
    """
    class TestArgs(argparse.Namespace):
        files=[]
        method=''
        data=''
        json=''
        form=''
        json=''
        json_or_form=(1 if 'json' else 'form')
        headers=''
        offline=''
        chunked=False
        verify=''
        cert=''
        cert_key=''
        proxy=''
    obj_0 = TestArgs()
    obj_0.files=['./test/test_packages/test_plugin/test_plugin.py']
    obj_0.method='PUT'
    obj_0.data='{"header": {"Content-Type": "application/json"}}'
    obj_0

# Generated at 2022-06-25 18:05:46.601512
# Unit test for function max_headers
def test_max_headers():

    assert callable(max_headers)


# Generated at 2022-06-25 18:05:54.786056
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    str_0 = 'e'
    data_0 = OrderedDict([('key_0', 'value_0'), ('key_1', 'value_1')])
    headers_0 = OrderedDict()
    params_0 = OrderedDict()
    args_0 = argparse.Namespace(
        auth=str_0,
        chunked=True,
        data=data_0,
        files=data_0,
        form=True,
        headers=headers_0,
        json=True,
        method=str_0,
        multipart=True,
        offline=True,
        params=params_0,
        url=str_0
    )
    kwargs = make_request_kwargs(args=args_0, base_headers=headers_0)

# Generated at 2022-06-25 18:06:07.596143
# Unit test for function build_requests_session
def test_build_requests_session():
    import copy
    import random
    import string

    args = copy.deepcopy(sys.argv)

# Generated at 2022-06-25 18:06:17.648171
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    arg_namespace = argparse.Namespace(
        proxies={'p1': 'p1', 'p2': 'p2'},
        verify='yes',
        cert='/root/cert.crt',
        cert_key='/root/cert.key'
    )
    proxies = {p.key: p.value for p in arg_namespace.proxy}
    verify = True
    cert = '/root/cert.crt'

    assert(make_send_kwargs_mergeable_from_env(arg_namespace) == {
        'proxies': proxies,
        'stream': True,
        'verify': verify,
        'cert': cert
    })


# Generated at 2022-06-25 18:06:27.268552
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    cert = '/xuMQknT^:3k\nr'

# Generated at 2022-06-25 18:06:34.122201
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args={'proxy':None,
    'verify': True,
    'cert': None,
    'cert_key': None}

# Generated at 2022-06-25 18:06:40.829043
# Unit test for function make_default_headers
def test_make_default_headers():
    print("")
    print("Unit test for function make_default_headers")
    args = argparse.Namespace
    args.json = True
    args.form = False
    args.data = '{  "test": 1 }'
    args.files = 'blah'
    args.headers = { "Content-Type": "application/json" }

    headers = make_default_headers(args)
    print("headers: ",headers)

# Generated at 2022-06-25 18:07:05.867668
# Unit test for function collect_messages
def test_collect_messages():
    # Test nested function make_request_kwargs
    def figleaf_ignore___make_request_kwargs():
        # Test nested function make_default_headers
        def figleaf_ignore___make_default_headers():
            # Test variable args
            args = argparse.Namespace()
            args.method = 'GET'
            args.url = 'http://www.example.com/'
            args.headers = RequestHeadersDict()
            args.auth = None
            args.params = dict()
            args.data = dict()
            args.files = dict()
            args.form = False
            args.json = False
            args.compress = False
            args.cert = None
            args.cert_key = None
            args.timeout = 30
            args.debug = False
            args.offline = False

# Generated at 2022-06-25 18:07:16.180125
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    arg_namespace = argparse.Namespace()
    arg_namespace.cert = '/xuMQknT^:3k'
    arg_namespace.cert_key = '/xuMQknT^:3k'
    arg_namespace.verify = 'yes'
    arg_namespace.proxy = []
    test_cases = [(arg_namespace, {'cert': '/xuMQknT^:3k',
                                   'verify': 'yes',
                                   'proxies': {},
                                   'stream': True})]
    for args, result in test_cases:
        assert make_send_kwargs_mergeable_from_env(args) == result

# Generated at 2022-06-25 18:07:17.350593
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(args) == kwargs


# Generated at 2022-06-25 18:07:29.462256
# Unit test for function make_default_headers

# Generated at 2022-06-25 18:07:36.292859
# Unit test for function make_default_headers
def test_make_default_headers():
    args = MockNamespace()
    args.data = None
    args.form = False
    args.json = False
    args.headers = {'Accept-Language': 'en-US,en;q=0.9'}
    result = make_default_headers(args)
    assert result == {'User-Agent': 'HTTPie/0.9.9', 'Accept-Language': 'en-US,en;q=0.9'}

    args = MockNamespace()
    args.data = 1234
    args.form = False
    args.json = False
    args.headers = {'Accept': 'application/json'}
    result = make_default_headers(args)
    assert result == {'User-Agent': 'HTTPie/0.9.9', 'Accept': 'application/json'}

    args = Mock

# Generated at 2022-06-25 18:07:48.514748
# Unit test for function make_request_kwargs

# Generated at 2022-06-25 18:07:51.989112
# Unit test for function max_headers
def test_max_headers():
    test_dict = {"a": "b", "c": "d"}
    assert len(test_dict) == 2


# Generated at 2022-06-25 18:08:02.521023
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import os
    import random
    import sys
    import tempfile
    import unittest
    from urllib.parse import urlparse
    import urllib.request
    import httpie
    import requests

    class TestCase(unittest.TestCase):
        def func(self, x):
            return x + 1

    test_cases = []
    test_case_0 = TestCase()
    test_case_0.test_input_0 = 'wOQW8<vF'
    test_case_0.test_input_1 = 'TmUo+MD\x0c3}'
    test_case_0.test_input_2 = 'FJvxNd'
    test_case_0.test_input_3 = 'M`\nK3U^'
    test_case

# Generated at 2022-06-25 18:08:13.561062
# Unit test for function make_send_kwargs

# Generated at 2022-06-25 18:08:17.130886
# Unit test for function make_default_headers
def test_make_default_headers():
    input_headers = ['user-agent', 'accept']
    expected_headers = {'User-Agent': 'HTTPie/1.0.3', 'Accept': '*/*'}
    assert make_default_headers(input_headers) == expected_headers
    print('Test 1 Passed')


# Generated at 2022-06-25 18:08:37.461812
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    kwargs = {}
    kwargs['timeout'] = 15
    kwargs['allow_redirects'] = False
    # Additional testing to check the result
    assert kwargs == make_send_kwargs(argparse.Namespace(timeout=15))


# Generated at 2022-06-25 18:08:47.999181
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    arguments_0 = argparse.Namespace()
    arguments_0.method = 'get'
    arguments_0.url = 'https://httpbin.org/get'
    arguments_0.headers = {'accept': 'application/json'}
    arguments_0.data = None
    arguments_0.json = False
    arguments_0.form = False
    arguments_0.files = {}
    arguments_0.params = {}
    arguments_0.auth = None
    arguments_0.max_redirects = 30
    arguments_0.follow = False
    arguments_0.timeout = 120
    arguments_0.check_status = None
    arguments_0.ignore_stdin = False
    arguments_0.style = 'solarized'
    arguments_0.style_variant = 'light'

# Generated at 2022-06-25 18:08:59.735733
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import tempfile
    import os
    import sys
    import mock
    import httpie.cli
    # suppress stdout
    mock_stdout = mock.Mock()
    sys.stdout = mock_stdout

    args_0 = httpie.cli.parser.parse_args(['GET', 'https://httpbin.org/get'])
    args_0.json = True
    args_0.data = {'value': 'foo'}
    request_body_read_callback_0 = None
    base_headers_0 = RequestHeadersDict()
    request_kwargs_0 = make_request_kwargs(args_0, base_headers_0, request_body_read_callback_0)
    request_kwargs_0['data'] = json.dumps(request_kwargs_0['data'])


# Generated at 2022-06-25 18:09:02.167636
# Unit test for function max_headers
def test_max_headers():
    args = argparse.Namespace(max_headers=None)
    result = max_headers(args.max_headers)
    assert not result


# Generated at 2022-06-25 18:09:08.843304
# Unit test for function make_default_headers
def test_make_default_headers():
    print('Test case 1')
    print('Test that httpie was properly installed')
    dict_0 = dict()
    dict_0['headers'] = dict_0
    args = argparse.Namespace(**dict_0)
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })

# Test case for function test_case_0

# Generated at 2022-06-25 18:09:20.428288
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()

    headers = {'foo': 'bar', 'baz': 'qux'}
    args.headers = headers

    args.files = {'test_files': 'test_files'}
    args.auth = ''
    args.data = ''

    args.method = 'get'
    args.path_as_is = ''
    args.compress = ''
    args.chunked = ''
    args.multipart_data = ''
    args.offline = ''
    args.boundary = ''

    args.url = 'url'

    request_kwargs = make_request_kwargs(args)
    assert(request_kwargs['headers'] == {'foo': 'bar', 'baz': 'qux'})

# Generated at 2022-06-25 18:09:23.063791
# Unit test for function collect_messages
def test_collect_messages():
    expected_result = 0
    args = argparse.Namespace()
    config_dir = Path('/home/carl/Programs/httpie/tests/data/httpie')
    result = collect_messages(args, config_dir)
    assert result == expected_result


# Generated at 2022-06-25 18:09:27.581022
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = argparse.Namespace()
    args_0.proxy = ['http://localhost:1234']
    args_0.verify = 'yes'
    args_0.cert = 'cert'
    args_0.cert_key = 'cert_key'

    expected = {'proxies': {'http': 'http://localhost:1234'}, 'stream': True, 'verify': True, 'cert': ('cert', 'cert_key')}
    assert make_send_kwargs_mergeable_from_env(args_0) == expected


# Generated at 2022-06-25 18:09:33.322774
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(chunked=None, files=[], offline=False)
    base_headers = None
    request_body_read_callback = None
    result = make_request_kwargs(args, base_headers, request_body_read_callback)
    assert(type(result) == dict)


# Generated at 2022-06-25 18:09:45.983888
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.data = None
    args.files = []
    args.form = False
    args.json = False
    args.multipart = False
    args.multipart_data = []
    args.boundary = '-=-=-='
    args.verify = False
    args.verify_args = None
    args.output = None
    args.all = True
    args.offline = False
    args.follow = False
    args.session = False
    args.session_read_only = False
    args.session_write_only = False
    args.output = None
    args.check_status = True
    args.headers = {}
    args.headers_as_dict = {}
    args.headers_as_env = {}
    args.auth = False
    args

# Generated at 2022-06-25 18:10:19.878713
# Unit test for function make_default_headers
def test_make_default_headers():
    pass


# Generated at 2022-06-25 18:10:23.243237
# Unit test for function build_requests_session
def test_build_requests_session():
    session_0 = build_requests_session(True, 'TLS', 'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384')
    assert isinstance(session_0, requests.Session)


# Generated at 2022-06-25 18:10:27.632883
# Unit test for function make_default_headers
def test_make_default_headers():
    # Test -> the values of all headers keys are not none
    args = argparse.Namespace(data='some data', form=False, json=False, files=False)
    assert make_default_headers(args)['User-Agent'] != None
    assert make_default_headers(args)['Accept'] != None


# Generated at 2022-06-25 18:10:30.861924
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    float_0 = float('Inf')
    float_1 = float('Inf')
    bool_0 = False
    int_0 = 0
    command = 'http'
    kwargs = make_send_kwargs({
        'timeout': float_0,
        'max_redirects': float_1,
        'follow': bool_0,
        'max_headers': int_0
    })
    assert(kwargs == {'timeout': float_0, 'allow_redirects': False})



# Generated at 2022-06-25 18:10:38.510643
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()

    args.timeout = None
    args.allow_redirects = False
    args.verify = True
    args.cert = None
    test_send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)

    assert test_send_kwargs_mergeable_from_env == {
        'proxies': None,
        'stream': True,
        'verify': True,
        'cert': None
    }

    args.timeout = '10'
    args.allow_redirecst = True
    args.verify = 'false'
    args.cert = 'test'
    args.proxy = {'https':'localhost:8080'}
    test_send_kwargs_mergeable_from

# Generated at 2022-06-25 18:10:42.237861
# Unit test for function max_headers
def test_max_headers():
    headers = "Accept-Encoding:gzip,deflate"
    print('Testing for function max_headers')
    try:
        with max_headers(headers):
            print ("Test passed")
    except:
        print ("Test failed")


# Generated at 2022-06-25 18:10:54.371082
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    data = {
        "hello": "world",
        "foo": "bar"
    }
    json_data = json.dumps(data)
    kwargs = make_request_kwargs(
        args=argparse.Namespace(
            auth=None,
            chunked=False,
            data=json_data,
            files=None,
            headers=None,
            json=True,
            method='POST',
            offline=False,
            params=None,
            form=False,
            url="127.0.0.1"
        ),
        request_body_read_callback = lambda chunk: chunk
    )

    assert(kwargs["method"] == "post")
    assert(kwargs["url"] == "127.0.0.1")

# Generated at 2022-06-25 18:11:03.663694
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Simple test
    method_0 = 'GET'
    url_0 = 'https://www.wikipedia.org/'
    headers_0 = {'Accept-Language': 'en-US,en;q=0.9'}
    data_0 = {'foo': 'bar'}
    res_0 = make_request_kwargs(args = None, method = method_0, url = url_0, headers = headers_0, data = data_0)
    assert res_0['method'] == method_0
    assert res_0['url'] == url_0
    # TODO: improve test


# Generated at 2022-06-25 18:11:08.242035
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_0 = argparse.Namespace()
    args_0.timeout = None
    # test for correct type
    assert type(make_send_kwargs(args_0)) == dict

# Generated at 2022-06-25 18:11:18.997816
# Unit test for function make_send_kwargs

# Generated at 2022-06-25 18:13:07.557997
# Unit test for function max_headers
def test_max_headers():
    limit = 9999
    with max_headers(limit) as ():
        assert http.client._MAXHEADERS == limit


# Generated at 2022-06-25 18:13:16.920495
# Unit test for function collect_messages
def test_collect_messages():
    parser_0 = argparse.ArgumentParser(description='A simple HTTP client')
    parser_0.add_argument('--auth', help='HTTP Basic Auth or Digest Auth credentials: \'username[:password]\'')
    parser_0.add_argument('--auth-type', help='Specify the authentication mechanism (Basic or Digest)')
    parser_0.add_argument('--body-format', help="Specify body content format: 'auto', 'json', 'form', 'text', or 'raw'")
    parser_0.add_argument('--body', help="Replace the request body with the given data.")
    parser_0.add_argument('--data', help="Assign JSON data.")
    parser_0.add_argument('--debug', help="Show debug info.", action='store_true')

# Generated at 2022-06-25 18:13:21.135801
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = argparse.Namespace()
    result_0 = make_send_kwargs_mergeable_from_env(args_0)

    assert result_0 == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }


# Generated at 2022-06-25 18:13:30.798074
# Unit test for function make_default_headers
def test_make_default_headers():
    from httpie.cli.argtypes import KeyValue

    class TestArgs:
        pass

    test_args = TestArgs()
    test_args.session, test_args.session_read_only = None, None
    test_args.auth_plugin = None
    test_args.headers = RequestHeadersDict([('X-Header-Test', 'Value-One')])
    test_args.cookies = {}
    test_args.data = '{"X-Header-Form": "Form-Value"}'
    test_args.json = True
    test_args.form = False

# Generated at 2022-06-25 18:13:33.024617
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    bool_0 = True
    send_kwargs_mergeable_from_env_0 = make_send_kwargs_mergeable_from_env(bool_0)
    assert send_kwargs_mergeable_from_env_0 == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }


# Generated at 2022-06-25 18:13:38.611785
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = argparse.Namespace()
    args_0.headers = dict()
    args_0.headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=utf-8'
    args_0.method = 'GET'
    args_0.url = 'https://www.example.com/'
    args_0.data = dict()
    args_0.data['foo'] = 'bar'
    args_0.params = dict()
    args_0.auth = 'username:password'
    args_0.auth_plugin = 'plugin'
    args_0.form = False
    args_0.json = False
    args_0.timeout = 10
    args_0.compress = 1
    args_0.debug = False
    args_0.offline = False

# Generated at 2022-06-25 18:13:39.643393
# Unit test for function max_headers
def test_max_headers():
    assert max_headers() is not None, 'Function max_headers not defined'


# Generated at 2022-06-25 18:13:46.597193
# Unit test for function make_default_headers
def test_make_default_headers():
    parser_0 = argparse.ArgumentParser(prog='http', description=None, usage=None, add_help=True)
    parser_0._optionals.title = 'positional arguments'
    parser_0.add_argument('url', nargs='?', help='URL', type=str)
    boolean_0 = False
    boolean_1 = True
    boolean_2 = False
    str_0 = 'httpie'
    str_1 = 'application/x-www-form-urlencoded; charset=utf-8'
    str_2 = 'json'
    str_3 = 'application/json'
    str_4 = 'no'
    str_5 = 'yes'
    str_6 = 'form'
    str_7 = 'params'
    str_8 = 'headers'
    str_9

# Generated at 2022-06-25 18:13:48.763123
# Unit test for function collect_messages
def test_collect_messages():
    assert collect_messages()


# Generated at 2022-06-25 18:13:58.026564
# Unit test for function build_requests_session
def test_build_requests_session():
    # Test Case 0 -
    bool_0 = False
    session_0 = build_requests_session(bool_0)
    assert type(session_0) == requests.sessions.Session
    # Test Case 1 -
    bool_1 = True
    session_1 = build_requests_session(bool_1)
    assert type(session_1) == requests.sessions.Session
    # Test Case 2 -
    bool_2 = False
    string_2 = '1'
    session_2 = build_requests_session(bool_2, ssl_version=string_2)
    assert type(session_2) == requests.sessions.Session
    # Test Case 3 -
    bool_3 = False
    string_3 = '1'
    list_3 = ['1']
    session_3 = build_requ