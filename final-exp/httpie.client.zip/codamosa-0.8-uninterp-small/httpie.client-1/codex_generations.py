

# Generated at 2022-06-25 18:05:24.548207
# Unit test for function max_headers
def test_max_headers():
    assert callable(max_headers)


# Generated at 2022-06-25 18:05:25.910315
# Unit test for function max_headers
def test_max_headers():
    var_0 = max_headers()


# Generated at 2022-06-25 18:05:27.167111
# Unit test for function build_requests_session
def test_build_requests_session():
    print(build_requests_session(True))


# Generated at 2022-06-25 18:05:31.482052
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert 'timeout' in make_send_kwargs({'timeout': 1})
    assert make_send_kwargs({'timeout': 1})['timeout'] == 1
    assert make_send_kwargs({'timeout': 1})['allow_redirects'] == False


# Generated at 2022-06-25 18:05:39.157335
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.ArgumentParser()
    args.verify = 'false'
    args.cert = 1
    args.cert_key = 2

    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    # Test Cases:
    # 1. verify is True
    # 2. verify is False
    # 3. verify is string
    # 4. verify is integer
    # 5. verify is None and cert is not None
    # 6. verify is None and cert is None
    # 7. verify is True and cert is not None
    # 8. verify is False and cert is not None
   

# Generated at 2022-06-25 18:05:40.868263
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(None)['timeout'] == None
    assert make_send_kwargs(None)['allow_redirects'] == False


# Generated at 2022-06-25 18:05:42.945271
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    kwargs = {
        'timeout': 1 or None,
        'allow_redirects': False
    }
    assert make_send_kwargs(1) == kwargs


# Generated at 2022-06-25 18:05:50.871206
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    base_headers = RequestHeadersDict
    request_body_read_callback = lambda chunk: chunk

    args = Namespace(
        method='get',
        url='http://www.baidu.com',
        headers=RequestHeadersDict(User_Agent=DEFAULT_UA),
        params=RequestHeadersDict(),
        auth=None,
        data=None
    )
    dict_0 = make_request_kwargs(args, base_headers, request_body_read_callback)

# Generated at 2022-06-25 18:06:02.949570
# Unit test for function collect_messages
def test_collect_messages():
    class Parameterized_function(object):
        def __init__(self, func):
            self.func = func
        # noinspection PyUnusedLocal
        def __call__(self, *args):
            return self.func()

    callbacks = []
    callbacks.append((
        Parameterized_function(
            test_case_0
        ),
        ('fnr_3', 'user_pass_1',),
        {'t4': 't4',},
        False,
    ))

    for callback, args, kwargs, result in callbacks:
        if isinstance(callback, Parameterized_function):
            func = callback.func
            args = callback.args
            kwargs = callback.kwargs
            result = callback.result
        else:
            func = callback

# Generated at 2022-06-25 18:06:07.076963
# Unit test for function make_default_headers
def test_make_default_headers():
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_1['User-Agent'] = 'HTTPie/0.9.9'
    dict_4['User-Agent'] = 'HTTPie/0.9.9'
    dict_2['Content-Type'] = 'application/json'
    dict_4['Content-Type'] = 'application/json'
    dict_3['Accept'] = 'application/json, */*;q=0.5'
    dict_4['Accept'] = 'application/json, */*;q=0.5'
    dict_5 = {}
    dict_5['json'] = 1
    dict_5['data'] = dict_1
    dict_5['form'] = 1

# Generated at 2022-06-25 18:06:27.452680
# Unit test for function make_default_headers
def test_make_default_headers():
    args = [
        {
            'url': 'http://httpbin.org/',
            'method': 'GET',
            'headers': {
                'Foo': 'bar'
            }
        },
        {
            'url': 'http://httpbin.org/',
            'method': 'GET',
            'headers': {
                'Foo': 'bar'
            }
        },
        {
            'url': 'http://httpbin.org/',
            'method': 'GET',
            'headers': {
                'Foo': 'bar'
            }
        },
        {
            'url': 'http://httpbin.org/',
            'method': 'GET',
            'headers': {
                'Foo': 'bar'
            }
        }
    ]

# Generated at 2022-06-25 18:06:40.330463
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    arg = argparse.Namespace()
    arg.method = "POST"
    arg.url = "https://httpbin.org/anything"
    arg.headers = RequestHeadersDict({'User-Agent': 'HTTPie/1.0.3'})
    arg.data = '{"content": "foo"}'
    arg.params = {'q': 'bar'}
    arg.auth = ("httpie", "password")
    arg.verify = "no"
    arg.cert = "/home/httpie/.httpie/cert.pem"
    arg.json = "yes"
    arg.form = "yes"
    arg.files = "yes"
    arg.multipart = "no"

    base_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
   

# Generated at 2022-06-25 18:06:50.236523
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = type('FakeArgs', (object,), {
        'verify': 'yes',
        'proxy': [
            type('FakeProxy', (object,), {
                'key': 'http',
                'value': '127.0.0.1'
            }),
            type('FakeProxy', (object,), {
                'key': 'https',
                'value': '127.0.0.1'
            }),
            type('FakeProxy', (object,), {
                'key': 'all',
                'value': '127.0.0.1'
            })
        ]
    })
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)


# Generated at 2022-06-25 18:06:55.092978
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # <https://github.com/httpie/httpie/issues/895>
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'


# Generated at 2022-06-25 18:07:05.685012
# Unit test for function make_default_headers

# Generated at 2022-06-25 18:07:17.425264
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.auth = None
    args.auth_type = 'basic'
    args.auth_plugin = None
    args.body = None
    args.body_columns = None
    args.body_preview_size = None
    args.chunked = None
    args.compress = None
    args.debug = False
    args.download = None
    args.download_resume = False
    args.download_wait = None
    args.explain = None
    args.follow = None
    args.form = None
    args.headers = []
    args.http2 = False
    args.ignore_stdin = False
    args.json = None
    args.max_redirects = None
    args.method = 'get'
    args.multipart = None


# Generated at 2022-06-25 18:07:29.586533
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    orig_func = make_request_kwargs
    def mock_make_request_kwargs(args: argparse.Namespace, base_headers: RequestHeadersDict = None, request_body_read_callback = lambda chunk: chunk):
        return orig_func(args, base_headers, request_body_read_callback)
    from httpie.cli.parser import get_parser
    parser = get_parser()
    args = parser.parse_args(['echo'])
    result = mock_make_request_kwargs(
        args=args,
        base_headers=None,
        request_body_read_callback=lambda chunk: chunk
    )

# Generated at 2022-06-25 18:07:40.053771
# Unit test for function collect_messages
def test_collect_messages():
    import os
    import requests


# Generated at 2022-06-25 18:07:51.027849
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Test with valid values.
    args = argparse.Namespace(
        auth=None,
        cert=None,
        cert_key=None,
        chunked=True,
        data=None,
        files=[],
        form=False,
        headers={},
        json=False,
        max_redirects=None,
        method='GET',
        multipart=False,
        offline=False,
        params=[],
        path_as_is=False,
        proxy=[],
        session=None,
        session_read_only=None,
        timeout=None,
        url='http://example.com/',
        verify=True,
        ssl_version=None,
        ciphers=None,
    )

# Generated at 2022-06-25 18:07:52.732790
# Unit test for function max_headers
def test_max_headers():
    assert callable(max_headers)
    assert isinstance(max_headers(), contextmanager)



# Generated at 2022-06-25 18:08:12.790946
# Unit test for function make_default_headers
def test_make_default_headers():

    # Function under test
    output = make_default_headers(None)

    assert(output is None)



# Generated at 2022-06-25 18:08:14.834399
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    make_request_kwargs_0 = make_request_kwargs(args, base_headers, request_body_read_callback)


# Generated at 2022-06-25 18:08:20.170927
# Unit test for function collect_messages
def test_collect_messages():
    args_0 = None
    config_dir_0 = Path('.')
    request_body_read_callback_0 = None
    output = collect_messages(args_0,
                              config_dir_0,
                              request_body_read_callback_0)
    print([
        (output_x.url, output_x.headers, output_x.body,
         output_x.next) for output_x in output
    ])



# Generated at 2022-06-25 18:08:27.471711
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    global args
    # Set arguments
    args.timeout = 10
    args.allow_redirects = False
    # Set expected results
    expected_send_kwargs = {
        'timeout': 10,
        'allow_redirects': False,
    }
    # Call function
    kwargs = make_send_kwargs(args)
    # Check results
    if kwargs != expected_send_kwargs:
        print('test_make_send_kwargs() failed')


# Generated at 2022-06-25 18:08:39.157545
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    argv_0 = ['-m', 'POST']
    argv_1 = ['-m', 'GET']
    argv_2 = ['--max-redirects', '3', '-m', 'GET']
    argv_3 = ['-m', 'PUT']
    argv_4 = ['-m', 'DELETE']
    argv_5 = ['-m', 'PATCH']
    argv_6 = ['-m', 'HEAD', '-r', 'GET']
    argv_7 = ['-m', 'OPTIONS']
    argv_8 = ['-m', 'CONNECT']
    argv_9 = ['-m', 'TRACE']
    argv_10 = ['-m', 'PURGE']
    
    args_0 = parse_args(argv_0)
   

# Generated at 2022-06-25 18:08:48.996015
# Unit test for function collect_messages
def test_collect_messages():
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
        def __getattr__(self, name):
            return self.__dict__[name]


# Generated at 2022-06-25 18:09:00.311493
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    test_args = argparse.Namespace(timeout=1, allow_redirects=False)
    args_false_1 = argparse.Namespace(timeout=1, allow_redirects=False)
    args_false_2 = argparse.Namespace(timeout=1, allow_redirects=False)
    args_false_3 = argparse.Namespace(timeout=1, allow_redirects=False)
    args_false_4 = argparse.Namespace(timeout=1, allow_redirects=False)
    args_false_5 = argparse.Namespace(timeout=1, allow_redirects=False)
    args_false_6 = argparse.Namespace(timeout=1, allow_redirects=False)

# Generated at 2022-06-25 18:09:02.863331
# Unit test for function collect_messages
def test_collect_messages():
    import argparse

    # Test for function collect_messages
    # This is a basic sample
    test_case_0()


if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-25 18:09:11.321555
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='key', value='value')]
    args.timeout = 'timeout'
    args.verify = 'verify'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    result_send_kwargs = make_send_kwargs_mergeable_from_env(args)
    assert result_send_kwargs == {
        'proxies': {'key': 'value'},
        'stream': True,
        'verify': 'verify',
        'cert': 'cert',
    }


# Generated at 2022-06-25 18:09:21.251669
# Unit test for function make_default_headers
def test_make_default_headers():
    args_0 = argparse.Namespace(
        chunked=False,
        compress=False,
        compress_level=None,
        debug=False,
        data=None,
        download=False,
        form=False,
        files=False,
        headers=None,
        json=False,
        method='GET',
        offline=False,
        params=argparse.Namespace(items=[]),
        path_as_is=False,
        print_body_only_if_redirect=False,
        print_body_only=False,
        session=None,
        session_read_only=False,
        timeout=None,
        url='',
        verbose=False,
        verify='yes'
    )
    assert callable(make_default_headers)

# Generated at 2022-06-25 18:09:58.249815
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = argparse.Namespace()
    args_0.data = 'foo'
    args_0.follow = False
    args_0.max_redirects = 5
    args_0.verify = 'foo'
    request_kwargs_0 = make_request_kwargs(args_0)
    assert request_kwargs_0 == {
        'method': 'GET',
        'url': '',
        'headers': {'User-Agent': 'HTTPie/', 'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'},
        'data': {'foo'},
        'auth': None,
        'params': [],
    }

# Generated at 2022-06-25 18:10:07.291096
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    print("Running test for function make_send_kwargs...")
    bool_0 = False
    int_0 = 14
    int_1 = 3
    int_2 = 0
    int_3 = 15
    int_4 = 2
    str_0 = '.'
    str_1 = ''
    str_2 = '1'
    str_3 = '5'
    str_4 = '*'
    str_5 = '/'
    str_6 = '@'
    str_7 = '`'
    str_8 = 'T'
    str_9 = 'o'
    str_10 = 'b'
    str_11 = '\\'
    str_12 = 'h'
    str_13 = 'e'
    str_14 = ' '
    str_15 = '^'
    str

# Generated at 2022-06-25 18:10:12.572187
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = argparse.Namespace()
    args_0.proxy = []
    args_0.verify = 'no'
    args_0.cert = None
    dict_0 = make_send_kwargs_mergeable_from_env(args_0)

    assert dict_0 == {'proxies': {}, 'stream': True, 'verify': False, 'cert': None}


# Generated at 2022-06-25 18:10:16.016854
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    kwargs = {
        'timeout': args.timeout or None,
        'allow_redirects': False,
    }
    assert make_send_kwargs(args) == kwargs


# Generated at 2022-06-25 18:10:18.011167
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Object args
    # Object base_headers
    # Func request_body_read_callback
    pass


# Generated at 2022-06-25 18:10:23.175364
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_0 = argparse.Namespace()
    args_0.verify = "yes"
    args_0.proxy = ("http_proxy", )
    cert_0 = ""
    args_0.cert = cert_0
    args_0.cert_key = cert_0
    result_0 = make_send_kwargs_mergeable_from_env(args_0)
    assert isinstance(result_0, dict)


# Generated at 2022-06-25 18:10:31.804896
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Simplified version of argparse.Namespace. This will be input to the tested function.
    args = {'verify': None, 'proxy': [], 'cert': None, 'cert_key': None}
    # Expected dict in normal situation
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {}, 'verify': True, 'cert': None, 'stream': True}
    # Input with a list of proxies and correct cert and key file
    args2 = {'verify': None, 'proxy': ['https', 'http'], 'cert': '/Users/example/cert.pem', 'cert_key': '/Users/example/key.pem'}
    # Expected dict with a list of proxies and correct cert and key file
    assert make_send_kwargs_mergeable

# Generated at 2022-06-25 18:10:33.597740
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    assert make_send_kwargs(args) == {
        'timeout': args.timeout or None,
        'allow_redirects': False,
    }


# Generated at 2022-06-25 18:10:37.672946
# Unit test for function make_default_headers
def test_make_default_headers():
    test_args = argparse.Namespace()
    test_args.json = True
    test_args.data = {}
    test_args.form = True
    test_args.files = False
    test_headers = make_default_headers(test_args)
    assert 'Content-Type' in test_headers
    assert 'Accept' in test_headers
    assert test_headers['Accept'] == 'application/json, */*;q=0.5'

# Generated at 2022-06-25 18:10:50.325609
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Initialise the test input
    namespace = argparse.Namespace()
    namespace.method = 'TestMethod'
    namespace.url = 'TestUrl'
    namespace.json = ''
    namespace.data = {}
    namespace.form = ''
    namespace.files = ''
    namespace.compress = ''
    namespace.chunked = ''
    namespace.offline = ''
    namespace.json = ''
    namespace.headers = RequestHeadersDict({"TestHeaderKey":"TestHeaderValue"})
    namespace.auth = "TestAuth"
    namespace.params = {"TestParamKey":"TestParamValue"}
    expected = {"method":"TestMethod", "url":"TestUrl", "headers": {"TestHeaderKey": "TestHeaderValue"}, "params":[("TestParamKey","TestParamValue")]}

# Generated at 2022-06-25 18:11:51.782068
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1) as c:
        pass


if __name__ == "__main__":
    test_max_headers()
    test_case_0()

# Generated at 2022-06-25 18:12:02.210320
# Unit test for function max_headers
def test_max_headers():
    args = argparse.Namespace()
    args.debug = False
    args.offline = False
    args.session = None
    args.session_read_only = None
    args.url = 'http://localhost:5000/'
    args.method = 'GET'
    args.auth = None
    args.headers = RequestHeadersDict()
    args.headers['Content-Type'] = 'application/json; charset=utf-8'
    args.headers['Accept'] = 'application/json, */*;q=0.5'
    args.headers['User-Agent'] = 'HTTPie/1.0.3'
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.json = False
    args.form = False


# Generated at 2022-06-25 18:12:04.790066
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    test_dict = {'timeout':2, 'allow_redirects': False}
    if(make_send_kwargs(test_dict) != test_dict):
        print('Test fail: make_send_kwargs')


# Generated at 2022-06-25 18:12:15.766798
# Unit test for function collect_messages
def test_collect_messages():
    test_0_args = argparse.Namespace()
    test_0_args.auth_plugin = None
    test_0_args.auth = None
    test_0_args.verify = None
    test_0_args.stream = False
    test_0_args.timeout = None
    test_0_args.cookies = []
    test_0_args.cert = None
    test_0_args.cert_key = None
    test_0_args.json = False
    test_0_args.form = False
    test_0_args.files = []
    test_0_args.data = None
    test_0_args.follow = False
    test_0_args.max_redirects = None
    test_0_args.all = True

# Generated at 2022-06-25 18:12:24.609077
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.auth = 'None'
    args.auth_plugin = 'None'
    args.max_headers = 100
    args.data = 'None'
    args.form = False
    args.headers =  {"Host": "httpbin.org", "Accept-Encoding": "gzip, deflate", "Accept": "*/*", "User-Agent": "python-requests/2.22.0", "Connection": "keep-alive"}
    args.json = False
    args.method = 'GET'
    args.verify = False
    args.debug = False
    args.proxy = []
    args.url = 'https://httpbin.org/get'
    #args.session = 'None'
    #args.session_read_only = 'None'
    args.off

# Generated at 2022-06-25 18:12:32.271051
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_0 = argparse.Namespace()
    args_0.chunked = False
    args_0.data = dict()
    args_0.auth = None
    args_0.json = False
    args_0.timeout = None
    args_0.params = dict()
    args_0.multipart = False
    args_0.cert = ''
    args_0.verify = ''
    args_0.proxy = list()
    args_0.headers = dict()
    args_0.boundary = ''
    args_0.compress = 0
    args_0.method = 'GET'
    args_0.url = 'http://example.com/'
    args_0.form = False
    args_0.files = list()
    args_0.max_redirects = None


# Generated at 2022-06-25 18:12:35.817850
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'true'
    args.proxy = []

    kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    print(kwargs_mergeable_from_env)


# Generated at 2022-06-25 18:12:45.915610
# Unit test for function make_default_headers
def test_make_default_headers():
    test_arg_0 = None
    str_0 = 'Content-Type'
    str_1 = 'Content-Type'
    str_2 = 'application/x-www-form-urlencoded; charset=utf-8'
    dict_0 = dict({(str_0, str_1): str_2})
    dict_1 = dict_0
    dict_2 = dict_1
    dict_1 = dict({(str_0, str_2): str_1})
    dict_1 = dict_2
    dict_0 = dict_1
    dict_0 = dict_1
    dict_1 = dict_2
    dict_0 = dict_1
    dict_0 = dict_1
    dict_1 = dict_2
    dict_2 = dict_1
    dict_0 = dict_1
   

# Generated at 2022-06-25 18:12:51.982524
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_0 = argparse.Namespace(method='POST', url='', headers=[], data=None, chunked=False, json=False, form=False, files=None, auth=None, params=[], timeout=None, verify='', cert=None, cert_key=None, max_redirects=None, max_headers=None, cookies=None, session=None, session_read_only=None, follow=True, all=False, offline=False, compress=False, output='', verbose=False, debug=False, https_tunnel=None, proxy=[], proxy_auth=None, auth_plugin=None, ssl_version=None, ciphers=None, multipart_data=[], boundary=None, path_as_is=False)

# Generated at 2022-06-25 18:12:59.118977
# Unit test for function collect_messages
def test_collect_messages():
    # create an args object to prevent errors
    args = argparse.Namespace()
    args.url = ''
    args.method = 'get'
    args.headers = {}
    args.data = {'foo': 'bar', 'baz': 'qux'}
    args.form = None
    args.json = True
    config_dir = Path('./')
    res = collect_messages(args, config_dir)
    val = next(res)
    assert val.body.decode('utf8') == '{"foo":"bar","baz":"qux"}'
    assert val.method == 'GET'
    assert val.url == ''
