

# Generated at 2022-06-17 20:02:58.988047
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {'foo': 'bar'}
    args.headers = {'Content-Type': 'application/json'}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    assert default_headers['Content-Type'] == args.headers['Content-Type']


# Generated at 2022-06-17 20:03:06.693871
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert'] == 'cert_key'

# Generated at 2022-06-17 20:03:18.110603
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = False
   

# Generated at 2022-06-17 20:03:20.893120
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    final_headers = finalize_headers(headers)
    assert final_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:03:29.323947
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}

    args.json = False
    args.form = True
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:03:40.713976
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='http://127.0.0.1:8080')]
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True
    assert kwargs['proxies'] == {'http': 'http://127.0.0.1:8080', 'https': 'http://127.0.0.1:8080'}
    assert kwargs['cert']

# Generated at 2022-06-17 20:03:48.509487
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:5000/api/v1/users'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'username': 'test', 'password': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = {}
    args.debug = False
    args.offline = False
    args.chunked

# Generated at 2022-06-17 20:03:53.918605
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:04:01.868100
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.proxies = {p.key: p.value for p in args.proxy}
    args.stream = True
    args.verify = {
        'yes': True,
        'true': True,
        'no': False,
        'false': False,
    }.get(args.verify.lower(), args.verify)
    args.cert = None

# Generated at 2022-06-17 20:04:09.132917
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'Accept': JSON_ACCEPT, 'User-Agent': DEFAULT_UA}

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'Content-Type': FORM_CONTENT_TYPE, 'User-Agent': DEFAULT_UA}

    args.json = False

# Generated at 2022-06-17 20:04:25.937670
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:34.558136
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}
    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}
    args.json = False
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}
    args.json = False
    args.form = False

# Generated at 2022-06-17 20:04:46.960626
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'https://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'}
    args.data = {'q': 'httpie'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = '--------------------------8d0f6a0e7c3a3a2a'
    args.auth = None
    args.params = {}

# Generated at 2022-06-17 20:04:56.421507
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080')]
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {'http': 'http://127.0.0.1:8080'}
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert.pem', 'cert_key.pem')

# Generated at 2022-06-17 20:05:03.002264
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'), argparse.Namespace(key='https', value='http://127.0.0.1:8081')]
    args.verify = 'no'
    args.cert = 'test.crt'
    args.cert_key

# Generated at 2022-06-17 20:05:10.770301
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=[], verify='yes', cert=None, cert_key=None)
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

    args = argparse.Namespace(proxy=[], verify='no', cert=None, cert_key=None)
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': False, 'cert': None}

    args = argparse.Namespace(proxy=[], verify='yes', cert='cert.pem', cert_key=None)
    kwargs = make_

# Generated at 2022-06-17 20:05:12.038171
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:05:17.304008
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'HTTPie/0.9.9',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive'
    }
    final_headers = finalize_headers(headers)
    assert final_headers == {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'HTTPie/0.9.9',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive'
    }

# Generated at 2022-06-17 20:05:26.686508
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='http://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'test.crt'
    args.cert

# Generated at 2022-06-17 20:05:31.489551
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:05:51.614393
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.all = False
    args.follow = False
    args.max

# Generated at 2022-06-17 20:05:55.738803
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=True, ssl_version='ssl3', ciphers='ECDHE-RSA-AES256-SHA')
    assert session.verify == True
    assert session.cert == None
    assert session.proxies == {}
    assert session.stream == True
    assert session.adapters['https://'].ssl_version == ssl.PROTOCOL_SSLv3
    assert session.adapters['https://'].ciphers == 'ECDHE-RSA-AES256-SHA'


# Generated at 2022-06-17 20:06:07.034337
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

    args.proxy = [argparse.Namespace(key='http', value='http://localhost:8080'),
                  argparse.Namespace(key='https', value='http://localhost:8081')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'


# Generated at 2022-06-17 20:06:11.821451
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False


# Generated at 2022-06-17 20:06:12.816052
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:21.905908
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'}
    args.data = {'q': 'httpie'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'q': 'httpie'}
    args.timeout = None
    args.verify = True
    args

# Generated at 2022-06-17 20:06:24.997714
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:29.588488
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:06:37.736654
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        ssl_version='TLSv1.2',
        ciphers='ECDHE-RSA-AES128-GCM-SHA256',
        verify=True
    )
    assert requests_session.mounts['https://'][0].ssl_version == ssl.PROTOCOL_TLS
    assert requests_session.mounts['https://'][0].ciphers == 'ECDHE-RSA-AES128-GCM-SHA256'
    assert requests_session.mounts['https://'][0].verify == True

# Generated at 2022-06-17 20:06:43.145672
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE,
        'Content-Type': FORM_CONTENT_TYPE,
    })
    final_headers = finalize_headers(headers)
    assert final_headers['User-Agent'] == DEFAULT_UA
    assert final_headers['Accept'] == JSON_ACCEPT
    assert final_headers['Content-Type'] == FORM_CONTENT_TYPE


# Generated at 2022-06-17 20:07:16.379482
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:07:21.089370
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = None
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:07:25.090168
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parse_args(['--json', '--method', 'GET', '--url', 'https://httpbin.org/get'])
    config_dir = Path('~/.httpie').expanduser()
    for message in collect_messages(args, config_dir):
        print(message)

# Generated at 2022-06-17 20:07:36.526558
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie
    import os
    import sys
    import tempfile
    import unittest

    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.sessions import Session
    from httpie.utils import get_config_dir

    class TestCollectMessages(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.config_dir = get_config_dir(self.tempdir)

# Generated at 2022-06-17 20:07:48.336204
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'test'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.ch

# Generated at 2022-06-17 20:07:59.228073
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers
    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers
    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:08:05.251891
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parser.parse_args(['--debug', 'https://httpbin.org/get'])
    config_dir = Path('.')
    for message in collect_messages(args, config_dir):
        print(message)

# Generated at 2022-06-17 20:08:13.728672
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.output.streams
    import httpie.cli.output.options
    import httpie.cli.output.formats
    import httpie.cli.auth
    import httpie.cli.sessions
    import httpie.cli.downloads
    import httpie.cli.plugins
    import httpie.cli.config
    import httpie.cli.downloads
    import httpie.cli.downloads.helpers
    import httpie.cli.downloads.streams
    import httpie.cli.downloads.threads
    import httpie.cli.downloads.verify
    import httpie.cli.downloads.progress

# Generated at 2022-06-17 20:08:19.208578
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'

# Generated at 2022-06-17 20:08:25.048706
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:10:25.670489
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:10:30.682995
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:10:41.772637
# Unit test for function make_default_headers

# Generated at 2022-06-17 20:10:48.757105
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'})
    args.data = '{"key": "value"}'
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False

# Generated at 2022-06-17 20:10:58.154564
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert.pem', 'cert_key.pem')

# Generated at 2022-06-17 20:11:07.093221
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = False
    args.data = {}
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == '*/*'
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE

    args.json = False
    args.data = {}
    args.form = False
    default

# Generated at 2022-06-17 20:11:13.258087
# Unit test for function collect_messages

# Generated at 2022-06-17 20:11:21.138290
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:11:29.291325
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'no'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == False
    assert kwargs['cert'] == None

# Generated at 2022-06-17 20:11:31.476939
# Unit test for function max_headers
def test_max_headers():
    import http.client
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100