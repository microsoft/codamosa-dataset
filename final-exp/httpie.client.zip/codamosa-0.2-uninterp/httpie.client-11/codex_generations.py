

# Generated at 2022-06-17 20:02:53.741262
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = False
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:03:04.620544
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'), argparse.Namespace(key='https', value='https://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key

# Generated at 2022-06-17 20:03:12.249848
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:03:22.928623
# Unit test for function collect_messages

# Generated at 2022-06-17 20:03:30.169080
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:03:35.100406
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:03:44.086409
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.output
    import httpie.cli.config
    import httpie.cli.auth
    import httpie.cli.sessions
    import httpie.cli.downloads
    import httpie.cli.stream
    import httpie.cli.form
    import httpie.cli.json
    import httpie.cli.headers
    import httpie.cli.pretty
    import httpie.cli.style
    import httpie.cli.colors
    import httpie.cli.context
    import httpie.cli.download
    import httpie.cli.help
    import httpie.cli.output_options
    import httpie.cli

# Generated at 2022-06-17 20:03:45.798023
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:03:51.639821
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.session = None
    args.session_read_only = None
    args.url = 'http://httpbin.org/get'
    args.method = 'GET'
    args.headers = {'Accept': 'application/json'}
    args.auth = None
    args.auth_plugin = None
    args.json = False
    args.form = False
    args.data = None
    args.params = {}
    args.files = []
    args.compress = False
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None


# Generated at 2022-06-17 20:04:00.438234
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:5000/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test', 'age': '20'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'test', 'age': '20'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.max_redirects = None
    args.follow = False

# Generated at 2022-06-17 20:04:20.656193
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'

# Generated at 2022-06-17 20:04:22.744037
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:32.805602
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'https://www.google.com'
    args.method = 'GET'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.data = None
    args.json = False
    args.form = False
    args.files = None
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.compress = False
    args.compress_level = None
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.ssl_version = None
    args.ciphers

# Generated at 2022-06-17 20:04:41.996404
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:04:52.929650
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:05:00.794119
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'), argparse.Namespace(key='https', value='https://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key

# Generated at 2022-06-17 20:05:09.432925
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:05:19.200248
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked = False
   

# Generated at 2022-06-17 20:05:21.048656
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:05:28.210468
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.data = None
    args.json = False
    args.form = False
    args.files = None
    args.params = {}
    args.auth = None
    args.auth_plugin = None
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.debug = False
    args.session = None
    args.session_read_only = None
    args.verify = True
   

# Generated at 2022-06-17 20:06:14.578575
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:23.198841
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:06:28.377069
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'

    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:06:36.049492
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:06:40.217287
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parse_args(['https://httpbin.org/get'])
    config_dir = Path('~/.httpie').expanduser()
    for message in collect_messages(args, config_dir):
        print(message)

# Generated at 2022-06-17 20:06:46.041947
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = False
    args.data = {}
    args.form = True
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == FORM_CONTENT_TYPE

# Generated at 2022-06-17 20:06:54.113941
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import sys
    from httpie.cli.parser import parser
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.utils import get_expired_cookies, repr_dict
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import JSON_CONTENT_TYPE
    from httpie.cli.constants import JSON_ACCEPT
    from httpie.cli.constants import FORM_CONTENT_TYPE
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import JSON_CONTENT_TYPE

# Generated at 2022-06-17 20:07:00.776783
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.auth = None
    args.auth_plugin = None
    args.json = False
    args.form = False
    args.files = []
    args.data = None
    args.params = {}
    args.max_redirects = 30
    args.follow = True
    args.max_headers = None
    args.timeout = None
    args.check_status = True
    args.check_headers = True
    args.check_body = True
    args.stream = False
    args.verbose = 1
    args.all = False
    args.debug = False
   

# Generated at 2022-06-17 20:07:11.006972
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = True
    args.form = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.data = False
    args.form = True
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.data = False
    args.form = True
    args.files = True
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_

# Generated at 2022-06-17 20:07:23.144963
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = None
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.session = None
    args.session_

# Generated at 2022-06-17 20:08:21.775969
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.url = 'http://localhost:8080/'
    args.method = 'GET'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.session = None
    args.session_read_only = None
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.compress = False

# Generated at 2022-06-17 20:08:32.972364
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.chunked = False
    args.offline = False
    args.compress = False

# Generated at 2022-06-17 20:08:40.333314
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version='TLSv1.2',
        ciphers='ECDHE-RSA-AES128-GCM-SHA256'
    )
    assert requests_session.verify == True
    assert requests_session.ssl_version == 'TLSv1.2'
    assert requests_session.ciphers == 'ECDHE-RSA-AES128-GCM-SHA256'

# Generated at 2022-06-17 20:08:46.765890
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')


# Generated at 2022-06-17 20:08:50.377017
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:08:59.186883
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:09:05.854087
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:09:08.556097
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:09:19.751696
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.proxy = []
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True
    assert kwargs['proxies'] == {}
    assert kwargs['cert'] == None
    args.verify = 'no'
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='http://127.0.0.1:8081')]
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'

# Generated at 2022-06-17 20:09:31.160442
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://httpbin.org/get'
    args.method = 'GET'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.compress = False
    args.compress_level = 6
    args.timeout = None
    args.max_redirects = None
    args.max_headers = None
    args.follow = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.verify = False
    args.cert = None
    args.cert_key = None
    args.proxy

# Generated at 2022-06-17 20:11:42.077089
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'key1': 'value1', 'key2': 'value2'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'param1': 'value1', 'param2': 'value2'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.max_redirects = None
   

# Generated at 2022-06-17 20:11:48.730268
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    headers = make_default_headers(args)
    assert headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    headers = make_default_headers(args)
    assert headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}

    args.json = False
    args.form = True
    args.data = None
    args.files = None
    headers = make_default_headers(args)
    assert headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}

   

# Generated at 2022-06-17 20:11:59.492574
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}
    args.data = {'name': 'test'}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'test'}
    args.timeout = None
    args

# Generated at 2022-06-17 20:12:09.575730
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:12:16.404672
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert'] == 'cert_key'