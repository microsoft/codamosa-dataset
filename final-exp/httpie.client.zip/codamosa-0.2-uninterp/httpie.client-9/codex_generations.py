

# Generated at 2022-06-17 20:02:47.445325
# Unit test for function collect_messages

# Generated at 2022-06-17 20:02:57.046806
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = None
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args

# Generated at 2022-06-17 20:03:07.537150
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.utils
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.plugins.registry
    import httpie.sessions
    import httpie.utils
    import httpie.compat
    import httpie.config
    import httpie.context
    import httpie.downloads
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.formatters.colors
    import httpie.output.formatters.utils
    import httpie.output.formatters.json
    import httpie.output.formatters.colors

# Generated at 2022-06-17 20:03:18.793707
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'}
    args.data = {'q': 'test'}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'q': 'test'}
    args.timeout = None
    args.verify = True


# Generated at 2022-06-17 20:03:25.861639
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'

# Generated at 2022-06-17 20:03:38.085881
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:03:46.495905
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
   

# Generated at 2022-06-17 20:03:52.484617
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE


# Generated at 2022-06-17 20:03:57.465833
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:04:08.913302
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = {}
    args.data = None
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.session = None
    args.session_read_only = None
    args.compress = False

# Generated at 2022-06-17 20:04:33.693497
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = False
   

# Generated at 2022-06-17 20:04:44.010518
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'

# Generated at 2022-06-17 20:04:49.227674
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = RequestHeadersDict()
    args.headers['Content-Type'] = 'application/json'
    args.headers['Accept'] = 'application/json'
    args.headers['User-Agent'] = 'HTTPie/0.9.9'
    args.headers['Host'] = 'www.google.com'
    args.headers['Connection'] = 'keep-alive'
    args.headers['Accept-Encoding'] = 'gzip, deflate'
    args.headers['Accept-Language'] = 'en-US,en;q=0.8'

# Generated at 2022-06-17 20:04:51.204869
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:59.661487
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:05:08.531918
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = False
    args.data = {}
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE

    args.json = False
    args.data = {}
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] is None

# Generated at 2022-06-17 20:05:12.393036
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    final_headers = finalize_headers(headers)
    assert final_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:05:20.600689
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='https://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert

# Generated at 2022-06-17 20:05:22.359810
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:05:25.472003
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }

# Generated at 2022-06-17 20:06:18.818305
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {'foo': 'bar'}
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}
    args.json = False
    args.form = True
    args.data = {'foo': 'bar'}
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}
    args.json = False
    args.form = False
    args.data = {'foo': 'bar'}
    default_headers = make_default_

# Generated at 2022-06-17 20:06:21.978510
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:25.108984
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:30.380650
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parser.parse_args(['-v', 'http://httpbin.org/get'])
    config_dir = Path(__file__).parent
    for msg in collect_messages(args, config_dir):
        print(msg)

# Generated at 2022-06-17 20:06:36.385294
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

# Generated at 2022-06-17 20:06:43.737575
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.proxies = {p.key: p.value for p in args.proxy}
    args.stream = True
    args.verify = {
            'yes': True,
            'true': True,
            'no': False,
            'false': False,
        }.get(args.verify.lower(), args.verify)
    args.cert = None
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:06:47.482339
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:06:50.492114
# Unit test for function max_headers
def test_max_headers():
    # noinspection PyUnresolvedReferences
    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = 10
    assert http.client._MAXHEADERS == 10
    http.client._MAXHEADERS = orig

# Generated at 2022-06-17 20:06:53.764555
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:57.521372
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    for i in collect_messages(args, config_dir, request_body_read_callback):
        print(i)

# Generated at 2022-06-17 20:07:37.174508
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.proxies = {p.key: p.value for p in args.proxy}
    args.stream = True
    args.verify = {
        'yes': True,
        'true': True,
        'no': False,
        'false': False,
    }.get(args.verify.lower(), args.verify)
    args.cert = cert
    kwargs = make_send_kwargs(args)

# Generated at 2022-06-17 20:07:49.082335
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/api/v1/test'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.chunked = False
    args.offline = False
    args.compress = False
   

# Generated at 2022-06-17 20:07:52.389873
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:07:57.424769
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:08:04.723461
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:08:13.334601
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:08:20.709409
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(verify=True, ssl_version='TLSv1.3', ciphers='ECDHE-ECDSA-AES256-GCM-SHA384')
    assert build_requests_session(verify=False, ssl_version='TLSv1.3', ciphers='ECDHE-ECDSA-AES256-GCM-SHA384')
    assert build_requests_session(verify=True, ssl_version='TLSv1.3', ciphers=None)
    assert build_requests_session(verify=False, ssl_version='TLSv1.3', ciphers=None)
    assert build_requests_session(verify=True, ssl_version=None, ciphers=None)

# Generated at 2022-06-17 20:08:28.641861
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parse_args(['--json', 'http://httpbin.org/get'])
    config_dir = Path('/home/user/.config/httpie')
    request_body_read_callback = lambda chunk: chunk
    messages = collect_messages(args, config_dir, request_body_read_callback)
    for message in messages:
        print(message)

# Generated at 2022-06-17 20:08:36.554536
# Unit test for function collect_messages

# Generated at 2022-06-17 20:08:46.705331
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'), argparse.Namespace(key='https', value='http://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key

# Generated at 2022-06-17 20:10:00.533411
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36'}
    args.data = {'q': 'httpie'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = '--------------------------935116712495736897222761'
    args.auth = None
    args.params = {}
    args.timeout = None

# Generated at 2022-06-17 20:10:04.424408
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = None
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:10:15.557488
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked = False
    args.comp

# Generated at 2022-06-17 20:10:18.733745
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}



# Generated at 2022-06-17 20:10:20.767465
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 100


# Generated at 2022-06-17 20:10:26.800049
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie
    import os
    import sys
    import tempfile
    import unittest
    from httpie.cli.parser import parser
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.utils import get_expired_cookies
    from httpie.utils import get_response_text
    from httpie.utils import get_response_json
    from httpie.utils import get_response_headers
    from httpie.utils import get_response_status
    from httpie.utils import get_response_cookies
    from httpie.utils import get_response_history
    from httpie.utils import get_response_redirect_url

# Generated at 2022-06-17 20:10:32.728177
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {'foo': 'bar'}
    args.form = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:10:43.246366
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import http.client
    import json
    import sys
    from contextlib import contextmanager
    from pathlib import Path
    from typing import Callable, Iterable, Union
    from urllib.parse import urlparse, urlunparse
    import requests
    # noinspection PyPackageRequirements
    import urllib3
    from httpie import __version__
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.ssl import AVAILABLE_SSL_VERSION_ARG_MAPPING, HTTPieHTTPSAdapter

# Generated at 2022-06-17 20:10:47.135150
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}


# Generated at 2022-06-17 20:10:59.168612
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.proxies = {p.key: p.value for p in args.proxy}
    args.stream = True
    args.verify = {
        'yes': True,
        'true': True,
        'no': False,
        'false': False,
    }.get(args.verify.lower(), args.verify)
    args.cert = None