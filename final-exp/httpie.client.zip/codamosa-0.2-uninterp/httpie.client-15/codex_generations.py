

# Generated at 2022-06-17 20:02:47.471669
# Unit test for function collect_messages

# Generated at 2022-06-17 20:02:50.411204
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    for i in collect_messages(args, config_dir, request_body_read_callback):
        print(i)


# Generated at 2022-06-17 20:02:53.064934
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-17 20:03:03.739150
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://httpbin.org/get'
    args.method = 'GET'
    args.headers = {}
    args.params = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.compress = False
    args.debug = False
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.auth = None
    args.auth_plugin = None
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.timeout = None
    args.check_status = False
    args.check_headers = False
    args.check_body = False
    args.check_comp

# Generated at 2022-06-17 20:03:11.764684
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'name': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'value'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.ch

# Generated at 2022-06-17 20:03:13.793093
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:03:24.428785
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}

    args.json = False
    args.form = True
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:03:29.917868
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:03:34.857381
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 1
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 1
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:03:44.456207
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.utils
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.plugins.registry
    import httpie.plugins.transport
    import httpie.plugins.auth
    import httpie.plugins.auth.basic_auth
    import httpie.plugins.auth.digest_auth
    import httpie.plugins.auth.plugin
    import httpie.plugins.auth.aws
    import httpie.plugins.auth.aws.aws_sigv4
    import httpie.plugins.auth.aws.aws_sigv4_auth

# Generated at 2022-06-17 20:04:08.876611
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.sessions
    import httpie.utils
    import httpie.uploads
    import httpie.ssl
    import httpie.plugins.registry
    import httpie.plugins.transport.http
    import httpie.plugins.transport.https
    import httpie.plugins.transport.http2
    import httpie.plugins.transport.http2_alt
    import httpie.plugins.transport.httpbin
    import httpie.plugins.transport.httpbin_any
    import httpie.plugins.transport.httpbin_org
    import httpie.plugins.transport.httpbin_org_https
    import httpie.plugins.transport.httpbin_org_ip

# Generated at 2022-06-17 20:04:15.211211
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'), argparse.Namespace(key='https', value='http://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key

# Generated at 2022-06-17 20:04:21.114579
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version='TLSv1.2',
        ciphers='ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:ECDHE-RSA-AES128-SHA:ECDHE-RSA-AES256-SHA:ECDHE-RSA-DES-CBC3-SHA:AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA256:AES256-SHA256:AES128-SHA:AES256-SHA:DES-CBC3-SHA:!DSS'
    )
    assert requests_session

# Generated at 2022-06-17 20:04:31.311344
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.url = 'https://httpbin.org/get'
    args.method = 'GET'
    args.headers = {'User-Agent': 'HTTPie/1.0.3'}
    args.auth = None
    args.auth_plugin = None
    args.json = False
    args.form = False
    args.files = []
    args.data = None
    args.params = {}
    args.compress = False
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.timeout = None
    args.chunked = False
    args.session = None
    args.session_read_only = None
    args.verify = True
    args

# Generated at 2022-06-17 20:04:43.942970
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}

    args.json = False

# Generated at 2022-06-17 20:04:47.837943
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:04:52.617542
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:04:56.178923
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:05:02.844790
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'})
    args.data = {'q': 'httpie'}
    args.json = True
    args.form = False
    args.files = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.max_redirects = None
    args.follow = False
    args.all = False

# Generated at 2022-06-17 20:05:10.664675
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "http://www.google.com"
    args.headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36'}
    args.data = {'q': 'httpie'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None

# Generated at 2022-06-17 20:05:36.287620
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:05:42.943216
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'

# Generated at 2022-06-17 20:05:50.177132
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080')]
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True
    assert kwargs['proxies'] == {'http': 'http://127.0.0.1:8080'}
    assert kwargs['cert'] == 'cert.pem'
    assert kwargs['cert_key'] == 'cert_key.pem'

# Generated at 2022-06-17 20:05:55.876392
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = "http://httpbin.org/get"
    args.method = "GET"
    args.headers = {"Content-Type": "application/json"}
    args.data = {"foo": "bar"}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
   

# Generated at 2022-06-17 20:06:07.484481
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:06:09.502096
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:20.273187
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.data = None
    args.json = False
    args.form = False
    args.files = None
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.compress = False
    args.debug = False
    args.session = None
    args.session_read_only = None
    args.timeout = None
    args.check_status = False
    args.check_headers = False
    args.check_body

# Generated at 2022-06-17 20:06:23.330483
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:35.267314
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False


# Generated at 2022-06-17 20:06:38.860350
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parser.parse_args(['--json', '--form', '--data', '{"a":1}', 'http://httpbin.org/post'])
    config_dir = Path('.')
    for i in collect_messages(args, config_dir):
        print(i)

# Generated at 2022-06-17 20:07:36.525197
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {'key': 'value'}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = {'key': 'value'}
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = {'key': 'value'}
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] is None


# Generated at 2022-06-17 20:07:48.335618
# Unit test for function collect_messages

# Generated at 2022-06-17 20:07:55.736631
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://127.0.0.1:5000/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'test'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.chunked = False
    args.offline = False

# Generated at 2022-06-17 20:08:04.054780
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/api/v1/users/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test', 'email': 'test@test.com'}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = None
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.offline = False

# Generated at 2022-06-17 20:08:07.352976
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = None
    for i in collect_messages(args, config_dir, request_body_read_callback):
        print(i)


# Generated at 2022-06-17 20:08:10.506321
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-17 20:08:18.054193
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'}
    args.data = None
    args.json = False
    args.form = False
    args.files = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.max_redirects = None
    args.follow = False
    args.max_headers = None


# Generated at 2022-06-17 20:08:24.072096
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable

# Generated at 2022-06-17 20:08:27.950337
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'

# Generated at 2022-06-17 20:08:30.951269
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:10:53.022619
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:10:56.187872
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:10:58.680908
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:11:07.718955
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=False,
        ssl_version='TLSv1.2',
        ciphers='AES128-GCM-SHA256:RC4:HIGH:!MD5:!aNULL:!EDH',
    )
    assert requests_session.verify == False
    assert requests_session.cert == None
    assert requests_session.proxies == {}
    assert requests_session.stream == True
    assert requests_session.timeout == None
    assert requests_session.allow_redirects == False
    assert requests_session.adapters['https://'].ssl_version == ssl.PROTOCOL_TLSv1_2

# Generated at 2022-06-17 20:11:13.442092
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:11:15.415768
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:11:26.188434
# Unit test for function collect_messages

# Generated at 2022-06-17 20:11:36.950504
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:11:45.057346
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'https://www.google.com'
    args.method = 'GET'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.compress = False
    args.debug = False
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.path_as_is = False
    args.session = None
    args.session_read_only = None
    args.auth = None
    args.auth_plugin

# Generated at 2022-06-17 20:11:48.532366
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100