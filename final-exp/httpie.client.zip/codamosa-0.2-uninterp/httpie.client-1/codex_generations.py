

# Generated at 2022-06-17 20:02:47.294747
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/test'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'test': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.chunked = False
    args.offline = False
    args.compress = False

# Generated at 2022-06-17 20:02:50.485896
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:02:55.079572
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parse_args(['--json', 'GET', 'http://httpbin.org/get'])
    config_dir = Path('/home/user/.config/httpie')
    for message in collect_messages(args, config_dir):
        print(message)

# Generated at 2022-06-17 20:03:06.214127
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        form=False,
        json=False,
        files=None,
        headers=RequestHeadersDict(),
    )
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args = argparse.Namespace(
        data=None,
        form=False,
        json=True,
        files=None,
        headers=RequestHeadersDict(),
    )
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type'

# Generated at 2022-06-17 20:03:08.974948
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:03:13.386696
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    })
    final_headers = finalize_headers(headers)
    assert final_headers == headers

# Generated at 2022-06-17 20:03:24.039400
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:03:29.161099
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=10,
        allow_redirects=False,
    )
    assert make_send_kwargs(args) == {
        'timeout': 10,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:03:40.603433
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'key': 'value'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked

# Generated at 2022-06-17 20:03:48.423675
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {'a': 'b'}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    assert default_headers['User-Agent'] == DEFAULT_UA

    args.json = False
    args.form = True
    args.data = {'a': 'b'}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    assert default_headers['User-Agent'] == DEFAULT_UA

    args.json = False
    args

# Generated at 2022-06-17 20:04:07.703747
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:11.731626
# Unit test for function collect_messages

# Generated at 2022-06-17 20:04:17.336939
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    assert finalize_headers(headers) == headers
    headers['User-Agent'] = 'HTTPie/1.0.3'
    assert finalize_headers(headers) == headers
    headers['User-Agent'] = 'HTTPie/1.0.3 '
    assert finalize_headers(headers) == headers
    headers['User-Agent'] = ' HTTPie/1.0.3'
    assert finalize_headers(headers) == headers
    headers['User-Agent'] = ' HTTPie/1.0.3 '
    assert finalize_headers(headers) == headers
    headers['User-Agent'] = ' HTTPie/1.0.3 '
    assert finalize_headers(headers) == headers

# Generated at 2022-06-17 20:04:20.786109
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    headers['Accept'] = JSON_ACCEPT
    headers['Content-Type'] = JSON_CONTENT_TYPE
    final_headers = finalize_headers(headers)
    assert final_headers['Accept'] == JSON_ACCEPT
    assert final_headers['Content-Type'] == JSON_CONTENT_TYPE
    assert final_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:04:31.008600
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:04:37.286644
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        chunked=False,
        cert=None,
        cert_key=None,
        data=None,
        debug=False,
        files=None,
        form=False,
        headers=RequestHeadersDict(),
        json=False,
        max_headers=None,
        method='GET',
        multipart=False,
        multipart_data=None,
        offline=False,
        params=RequestHeadersDict(),
        path_as_is=False,
        proxy=None,
        session=None,
        session_read_only=None,
        timeout=None,
        url='http://localhost:8080/',
        verify='yes',
    )
    base_headers = RequestHeadersD

# Generated at 2022-06-17 20:04:49.173445
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.max

# Generated at 2022-06-17 20:04:58.549444
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False


# Generated at 2022-06-17 20:05:00.666295
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:05:09.369121
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.plugins.builtin
    import httpie.plugins.registry
    import httpie.plugins.manager
    import httpie.plugins.transport.http
    import httpie.plugins.transport.httpie
    import httpie.plugins.transport.raw
    import httpie.plugins.transport.wget
    import httpie.plugins.transport.curl
    import httpie.plugins.transport.urllib3
    import httpie.plugins.transport.http2
    import httpie.plugins.transport.httpx
    import httpie.plugins.transport.httpcore
    import httpie.plugins.transport

# Generated at 2022-06-17 20:06:13.333064
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:06:15.915743
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:23.765827
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {}
    args.chunked = False
    args.offline = False
    args.compress = False
    args.compress_level = None
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.session = None
    args.session_read_only = None
    args.verify

# Generated at 2022-06-17 20:06:35.608833
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked

# Generated at 2022-06-17 20:06:44.143859
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:5000/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False
   

# Generated at 2022-06-17 20:06:47.440050
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:06:59.366279
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:07:05.579230
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': ('cert', 'cert_key')}

# Generated at 2022-06-17 20:07:14.375333
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version='TLSv1.2',
        ciphers='ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384'
    )
    assert requests_session.verify == True

# Generated at 2022-06-17 20:07:19.499276
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:08:10.890721
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0'}
    args.data = {'foo': 'bar'}
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.offline = False
    args.chunked = False
    args.comp

# Generated at 2022-06-17 20:08:14.431827
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:08:18.705556
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': ('cert', 'cert_key')}

# Generated at 2022-06-17 20:08:25.781982
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8000/api/v1/'
    args.headers = RequestHeadersDict({'Content-Type': 'application/json'})
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False


# Generated at 2022-06-17 20:08:34.962192
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    assert finalize_headers(headers) == {'User-Agent': DEFAULT_UA}
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Content-Type': 'application/json'
    })
    assert finalize_headers(headers) == {'User-Agent': DEFAULT_UA, 'Content-Type': 'application/json'}
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    })

# Generated at 2022-06-17 20:08:45.740451
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key = 'cert.key'
    kwargs = make_send_kwargs_mergeable_from_

# Generated at 2022-06-17 20:08:52.126796
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:09:01.132962
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=False,
        ssl_version=None,
        ciphers=None,
    )
    assert requests_session.verify == False
    assert requests_session.cert == None
    assert requests_session.proxies == {}
    assert requests_session.stream == True
    assert requests_session.timeout == None
    assert requests_session.allow_redirects == False
    assert requests_session.adapters == {
        'https://': HTTPieHTTPSAdapter(
            ciphers=None,
            verify=False,
            ssl_version=None,
        )
    }


# Generated at 2022-06-17 20:09:03.714362
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:09:12.050214
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://httpbin.org/get'
    args.method = 'GET'
    args.headers = RequestHeadersDict()
    args.headers['User-Agent'] = 'HTTPie/0.9.9'
    args.headers['Accept'] = '*/*'
    args.headers['Accept-Encoding'] = 'gzip, deflate'
    args.headers['Connection'] = 'keep-alive'
    args.headers['Host'] = 'httpbin.org'
    args.headers['Content-Length'] = '0'
    args.headers['Content-Type'] = 'application/json'
    args.headers['Cookie'] = 'foo=bar'
    args.headers['X-Foo'] = 'Bar'
    args.headers['X-Bar']

# Generated at 2022-06-17 20:10:23.397489
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import os
    import sys
    import tempfile
    import unittest
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.cli.parser import get_parser
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.utils import get_expired_cookies
    from httpie.utils import get_response_info
    from httpie.utils import get_response_text
    from httpie.utils import is_json
    from httpie.utils import is_pretty

# Generated at 2022-06-17 20:10:34.102193
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

    args.proxy = [argparse.Namespace(key='http', value='http://localhost:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'

# Generated at 2022-06-17 20:10:44.122985
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.session = None
    args.session_read_only = None

# Generated at 2022-06-17 20:10:51.570439
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:5000/api/v1/users'
    args.headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    args.headers.update({
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    })
    args.headers = finalize_headers(args.headers)
    args.data = {
        'username': 'test',
        'password': 'test'
    }
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None

# Generated at 2022-06-17 20:10:58.087730
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'test'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.compress = False
    args.chunked = False
    args.offline = False
    args.session = None
    args.session_read_only = None
    args.max_redirects = None

# Generated at 2022-06-17 20:11:07.090563
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = RequestHeadersDict()
    args.headers['Content-Type'] = 'application/json'
    args.headers['Accept'] = 'application/json'
    args.headers['User-Agent'] = 'HTTPie/1.0.3'
    args.headers['Connection'] = 'keep-alive'
    args.headers['Host'] = 'www.google.com'
    args.headers['Accept-Encoding'] = 'gzip, deflate'
    args.headers['Accept-Language'] = 'en-US,en;q=0.9'

# Generated at 2022-06-17 20:11:15.223252
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Accept': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.session = None
    args.session_read_only = None
    args.debug = False
    args.all = False
    args.follow = False
    args.max_redirects = None
    args.max_

# Generated at 2022-06-17 20:11:24.858888
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version='TLSv1.2',
        ciphers='ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256'
    )
    assert requests_session.verify == True
    assert requests_session.adapters['https://'].ssl_version == ssl.PROTOCOL_TLS
    assert requests_session.adapters['https://'].ciphers == 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256'

# Generated at 2022-06-17 20:11:35.387724
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/api/v1/users'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'John Doe'}
    args.json = True
    args.form = False
    args.files = None
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked = False
   

# Generated at 2022-06-17 20:11:39.617147
# Unit test for function max_headers
def test_max_headers():
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 1000
    with max_headers(10):
        # noinspection PyUnresolvedReferences
        assert http.client._MAXHEADERS == 10
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 1000