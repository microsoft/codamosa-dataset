

# Generated at 2022-06-17 20:03:03.739635
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in headers
    assert 'Content-Type' not in headers

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in headers

    args.json = False
    args.form = True
    args.data = None
    args.files = None

# Generated at 2022-06-17 20:03:07.804667
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "http://www.google.com"
    args.headers = RequestHeadersDict()
    args.headers['Content-Type'] = "application/json"
    args.headers['Accept'] = "application/json"
    args.headers['User-Agent'] = "HTTPie/1.0.3"
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = []
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
   

# Generated at 2022-06-17 20:03:12.435661
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': 10, 'allow_redirects': False}


# Generated at 2022-06-17 20:03:23.106255
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import os
    import sys
    import tempfile
    import shutil
    import json
    import requests
    import httpie
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.sessions import get_httpie_session
    from httpie.utils import get_expired_cookies, repr_dict
    from httpie.plugins.registry import plugin_manager
    from httpie.uploads import (
        compress_request, prepare_request_body,
        get_multipart_data_and_content_type,
    )
    from httpie.ssl import AVAILABLE_SSL_VERSION_ARG_MAPPING, HTTPieHTTPSAdapter
    from httpie.utils import get_expired_cookies, repr_dict

    # Create a temporary directory
    temp_dir

# Generated at 2022-06-17 20:03:25.050119
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:03:33.812853
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:03:35.880654
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:03:41.565946
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parser.parse_args(['--json', '--auth', 'foo:bar', 'http://httpbin.org/get'])
    config_dir = Path('/Users/tianyizhu/.httpie')
    request_body_read_callback = lambda chunk: chunk
    for i in collect_messages(args, config_dir, request_body_read_callback):
        print(i)

# Generated at 2022-06-17 20:03:47.580246
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}
    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}
    args.json = False
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}
    args.data = {}

# Generated at 2022-06-17 20:03:58.217150
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        cert=None,
        cert_key=None,
        chunked=False,
        data=None,
        files=None,
        form=False,
        headers=RequestHeadersDict(),
        json=False,
        method='GET',
        multipart=False,
        multipart_data=None,
        offline=False,
        params=None,
        path_as_is=False,
        proxy=None,
        session=None,
        session_read_only=None,
        timeout=None,
        url='http://www.example.com',
        verify=True,
    )
    base_headers = RequestHeadersDict()
    request_body_read_callback = lambda chunk: chunk
   

# Generated at 2022-06-17 20:04:22.246554
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'key': 'value'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked

# Generated at 2022-06-17 20:04:32.364860
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}

    args.json = False

# Generated at 2022-06-17 20:04:45.092134
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = True
    default_headers = make_default_headers(args)
    assert 'Content-Type' not in default_headers
    args.json = False
    args.form = False
    args.data = False


# Generated at 2022-06-17 20:04:55.756724
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = {}
    args.params = {}
    args.data = {}
    args.files = {}
    args.json = False
    args.form = False
    args.auth = None
    args.auth_plugin = None
    args.session = None
    args.session_read_only = None
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.debug = False
    args.verify = False
    args.cert = None
    args.cert_key = None
   

# Generated at 2022-06-17 20:05:00.854063
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://foo.com'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.max_redirects = None
    args.follow = False
    args

# Generated at 2022-06-17 20:05:09.505960
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'a': 'b'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'a': 'b'}
    args.timeout = None
    args.chunked = False
    args.offline = False
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args

# Generated at 2022-06-17 20:05:12.660763
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:05:18.246521
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:05:22.730699
# Unit test for function max_headers
def test_max_headers():
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 100
    with max_headers(None):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == float('Inf')
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 100
    with max_headers(42):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == 42
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:05:29.427728
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        chunked=False,
        cert=None,
        cert_key=None,
        data=None,
        debug=False,
        files=None,
        form=False,
        headers=RequestHeadersDict(),
        json=False,
        max_headers=None,
        method='GET',
        multipart=False,
        multipart_data=None,
        offline=False,
        params=RequestHeadersDict(),
        path_as_is=False,
        proxy=[],
        session=None,
        session_read_only=None,
        timeout=None,
        url='http://www.google.com',
        verify=True,
    )
    base_headers = RequestHeadersDict

# Generated at 2022-06-17 20:06:09.460542
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:06:20.272771
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] is None
    args.json = False
    args.form = False

# Generated at 2022-06-17 20:06:25.230902
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == None

# Generated at 2022-06-17 20:06:36.599205
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'), argparse.Namespace(key='https', value='http://127.0.0.1:8081')]
    args.verify = 'no'
    args.cert = 'cert'

# Generated at 2022-06-17 20:06:45.691963
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:06:47.563979
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:55.405415
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.data = None
    args.json = False
    args.form = False
    args.files = []
    args.params = []
    args.auth = None
    args.auth_plugin = None
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.session = None
    args.session_read_only = None
    args.offline = False
    args.compress = False
    args.chunked = False
    args.json_pp = False
    args.style = None


# Generated at 2022-06-17 20:07:01.754612
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'https://httpbin.org/get'
    args.method = 'GET'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.json = False
    args.form = False
    args.pretty = False
    args.style = None
    args.print_headers = False
    args.print_bodies = True
    args.download = False
    args.follow = False
    args.max_redirects = None
    args.session = None
    args.session_read_only = None
    args.timeout = None
    args.check_status = False
    args.check_ssl = False
   

# Generated at 2022-06-17 20:07:11.855710
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.data = {'foo': 'bar'}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:07:16.739188
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.stream = True
    args.proxies = None
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False, 'stream': True}


# Generated at 2022-06-17 20:08:20.860900
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    args.proxy = []
    args.stream = True
    args.verify = True
    args.cert = None
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False
    assert kwargs['proxy'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:08:26.676621
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:08:35.473878
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'wd': 'test'}
    args.timeout = None
    args.verify = True

# Generated at 2022-06-17 20:08:40.333704
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:08:48.436945
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = True
    args.form = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.data = False
    args.form = True
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.data = False
    args.form = False
    args.files = True
    default_headers = make_default_headers(args)
    assert 'Content-Type' not in default_headers


# Generated at 2022-06-17 20:09:00.768801
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:09:04.943521
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE

# Generated at 2022-06-17 20:09:12.696974
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = None
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False


# Generated at 2022-06-17 20:09:15.957582
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:09:22.108451
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:11:49.662343
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:11:59.754098
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = RequestHeadersDict()
    args.headers['Content-Type'] = 'application/json'
    args.headers['Accept'] = 'application/json'
    args.headers['User-Agent'] = 'HTTPie/1.0.3'
    args.headers['Host'] = 'www.google.com'
    args.headers['Connection'] = 'keep-alive'
    args.headers['Accept-Encoding'] = 'gzip, deflate'
    args.headers['Accept-Language'] = 'en-US,en;q=0.8'

# Generated at 2022-06-17 20:12:09.832513
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.proxies = {p.key: p.value for p in args.proxy}
    args.stream = True
    args.verify = {
        'yes': True,
        'true': True,
        'no': False,
        'false': False,
    }.get(args.verify.lower(), args.verify)
    args.cert = cert

# Generated at 2022-06-17 20:12:19.737030
# Unit test for function collect_messages

# Generated at 2022-06-17 20:12:22.666828
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

