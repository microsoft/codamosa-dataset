

# Generated at 2022-06-17 20:03:05.339827
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:03:18.021635
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.timeout = None
    args.auth = None
    args.params = {}
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False


# Generated at 2022-06-17 20:03:27.297154
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == '*/*'
    assert default_headers['Content-Type'] == None

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == None

    args.json = False
    args.form = True
    args.data = None

# Generated at 2022-06-17 20:03:33.405001
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version=None,
        ciphers=None,
    )
    assert requests_session.verify == True
    assert requests_session.cert == None
    assert requests_session.ciphers == None
    assert requests_session.ssl_version == None


# Generated at 2022-06-17 20:03:34.696912
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:03:43.830976
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'https://httpbin.org/get'
    args.method = 'GET'
    args.headers = {'Accept': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.max_redirects = None
    args.follow = False
    args.max

# Generated at 2022-06-17 20:03:49.169245
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='https://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs

# Generated at 2022-06-17 20:03:52.779281
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:03:56.473271
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert'] == 'cert_key'

# Generated at 2022-06-17 20:04:01.135064
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:22.762764
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:04:32.806445
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0'}
    args.data = None
    args.json = None
    args.form = None
    args.files = None
    args.auth = None
    args.params = None
    args.timeout = None
    args.allow_redirects = None
    args.proxies = None
    args.stream = None
    args.verify = None
    args.cert = None
    args.json = None
    args.form = None
    args.files = None

# Generated at 2022-06-17 20:04:41.233607
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'true'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': ('cert', 'cert_key')}

# Generated at 2022-06-17 20:04:43.543538
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}


# Generated at 2022-06-17 20:04:47.546562
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:04:57.877907
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/'
    args.headers = RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'})
    args.data = {'foo': 'bar'}
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.max_redirects = None
    args.follow = False
    args.session = None
    args.session_read_only = None
    args.all = False
    args.offline = False

# Generated at 2022-06-17 20:05:02.102674
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:05:10.236818
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'q': 'httpie'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False

# Generated at 2022-06-17 20:05:14.762218
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'

# Generated at 2022-06-17 20:05:20.659777
# Unit test for function collect_messages

# Generated at 2022-06-17 20:06:21.572659
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:27.845611
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = True
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

# Generated at 2022-06-17 20:06:34.592426
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {'foo': 'bar'}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:06:39.836751
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'

# Generated at 2022-06-17 20:06:44.801441
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.chunked

# Generated at 2022-06-17 20:06:48.386968
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:06:59.448458
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'https://httpbin.org/get'
    args.method = 'GET'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.auth = None
    args.auth_plugin = None
    args.json = False
    args.form = False
    args.files = []
    args.data = None
    args.params = {}
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.compress = False
    args.verify = True
    args.ssl_version = None
    args.ciphers = None
    args.proxy = []
    args.cert = None
    args.cert_key = None
    args.timeout = None

# Generated at 2022-06-17 20:07:09.664994
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:07:12.498834
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = True
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

# Generated at 2022-06-17 20:07:14.297408
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:08:31.948846
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080')]
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True
    assert kwargs['proxies'] == {'http': 'http://127.0.0.1:8080'}
    assert kwargs['cert'] == ('cert.pem', 'cert_key.pem')

# Generated at 2022-06-17 20:08:34.732122
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:08:45.629484
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:08:59.812702
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {}
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = False
    args.form = True
    args.data = {}
    headers = make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE

    args.json = False
    args.form = False
    args.data = {}
    headers = make_default_headers(args)
    assert 'Content-Type' not in headers

    args.json = False
    args.form = False
    args.data = {'foo': 'bar'}
    headers = make_default_

# Generated at 2022-06-17 20:09:06.290819
# Unit test for function collect_messages

# Generated at 2022-06-17 20:09:09.170843
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS != 10

# Generated at 2022-06-17 20:09:15.116688
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import os
    import sys
    import tempfile
    import unittest
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.parser import parser
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import Session
    from httpie.utils import get_response_dict
    from httpie.utils import get_response_json
    from httpie.utils import get_response_text
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import get

# Generated at 2022-06-17 20:09:23.772696
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        cert=None,
        cert_key=None,
        chunked=False,
        data=None,
        files=None,
        form=False,
        headers=RequestHeadersDict(),
        json=False,
        method='GET',
        multipart=False,
        multipart_data=None,
        offline=False,
        params=RequestHeadersDict(),
        path_as_is=False,
        proxy=None,
        session=None,
        session_read_only=None,
        url='http://httpbin.org/get',
        verify=True,
    )
    base_headers = RequestHeadersDict()
    request_body_read_callback = lambda chunk: chunk
    k

# Generated at 2022-06-17 20:09:35.383440
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/api/v1/test'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'test': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = None
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked = False
    args

# Generated at 2022-06-17 20:09:45.191440
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'name': 'John Doe'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.chunked = False
    args.offline = False
   