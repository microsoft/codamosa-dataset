

# Generated at 2022-06-17 20:02:44.257635
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:02:51.448993
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = True
    args.data = {}
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = {}
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = {}
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False

# Generated at 2022-06-17 20:03:02.558950
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}

    args.json = False

# Generated at 2022-06-17 20:03:11.077669
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:03:21.485819
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'https://httpbin.org/get'
    args.headers = {'Accept': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.debug = False
    args.session = None
    args.session_read_only = None
    args.offline = False
   

# Generated at 2022-06-17 20:03:28.022482
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'


# Generated at 2022-06-17 20:03:35.094296
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = "yes"
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

# Generated at 2022-06-17 20:03:44.534517
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'test'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.chunked = False
    args.offline = False
    args.max_headers

# Generated at 2022-06-17 20:03:55.377401
# Unit test for function collect_messages

# Generated at 2022-06-17 20:04:08.238802
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.sessions
    import httpie.utils
    import httpie.uploads
    import httpie.ssl
    import httpie.plugins.registry
    import httpie.plugins.builtin
    import httpie.plugins.transport.http
    import httpie.plugins.transport.https
    import httpie.plugins.transport.http2
    import httpie.plugins.transport.http2.adapters
    import httpie.plugins.transport.http2.adapters.hyper
    import httpie.plugins.transport.http2.adapters.hyper.h2
    import httpie.plugins.transport.http2.adapters.hyper.h2.connection
    import httpie.plugins.transport.http

# Generated at 2022-06-17 20:04:48.294486
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.form = False
    args.data = False
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] is None


# Generated at 2022-06-17 20:04:58.371207
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:5000/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False
   

# Generated at 2022-06-17 20:05:04.590923
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:05:09.032425
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = None
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:05:18.844467
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/api/v1/users'
    args.headers = {'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c'}
    args.data = {'username': 'admin', 'password': 'admin'}

# Generated at 2022-06-17 20:05:24.849486
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://127.0.0.1:8080/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'key1': 'value1', 'key2': 'value2'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'key1': 'value1', 'key2': 'value2'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None

# Generated at 2022-06-17 20:05:26.778808
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:05:36.528870
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    args.verify = 'no'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': False, 'cert': None}
    args.verify = 'true'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs

# Generated at 2022-06-17 20:05:45.633928
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'), argparse.Namespace(key='https', value='https://127.0.0.1:8080')]
    args.verify = 'yes'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {'http': 'http://127.0.0.1:8080', 'https': 'https://127.0.0.1:8080'}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True

# Generated at 2022-06-17 20:05:49.363753
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parser.parse_args(['--json', 'http://localhost:8080/api/v1/users'])
    config_dir = Path('/home/julien/.config/httpie')
    for message in collect_messages(args, config_dir):
        print(message)

# Generated at 2022-06-17 20:06:35.609260
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:06:44.174503
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = '{"key": "value"}'
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.offline = False
    args.chunked = False
    args.compress = False
    args.debug = False


# Generated at 2022-06-17 20:06:49.658640
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:06:54.654395
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = None
    for i in collect_messages(args, config_dir, request_body_read_callback):
        print(i)

# Generated at 2022-06-17 20:07:01.169574
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'test.crt'
    args.cert_key = 'test.key'
    kwargs = make_send_kwargs_mergeable_from_

# Generated at 2022-06-17 20:07:08.212848
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:07:12.959790
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='https://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key = 'cert.key'
    kwargs = make_

# Generated at 2022-06-17 20:07:23.804168
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = RequestHeadersDict()
    args.headers['Content-Type'] = 'application/json'
    args.headers['Accept'] = 'application/json'
    args.headers['Accept-Encoding'] = 'gzip, deflate'
    args.headers['Accept-Language'] = 'zh-CN,zh;q=0.9'
    args.headers['Connection'] = 'keep-alive'
    args.headers['Host'] = 'www.baidu.com'
    args.headers['Referer'] = 'http://www.baidu.com/'

# Generated at 2022-06-17 20:07:31.067171
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': ('cert', 'cert_key')}

# Generated at 2022-06-17 20:07:34.421513
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = None
    assert collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:09:04.299062
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:09:11.146561
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.proxies = {p.key: p.value for p in args.proxy}
    args.stream = True
    args.verify = {
            'yes': True,
            'true': True,
            'no': False,
            'false': False,
        }.get(args.verify.lower(), args.verify)
    args.cert = None
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:09:22.239704
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/api/v1/users'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = 'boundary'
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.max_redirect

# Generated at 2022-06-17 20:09:34.541574
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    })
    args.json = False
    args.form = True
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:09:40.688015
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'foo': 'bar'}
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.session = None
    args.session_read_only = None
    args.debug = False
    args.compress = False
    args.chunked = False
    args.offline = False

# Generated at 2022-06-17 20:09:48.937503
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'test'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.max_redirects = None
    args.follow = False
    args.all = False

# Generated at 2022-06-17 20:09:55.762064
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.compress = False
    args.debug = False
    args.verify = True
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.session = None
    args.session_read_only = None
    args.auth = None
    args.auth_plugin = None
    args.proxy = []
    args.cert = None
    args.cert_key = None
    args.ssl_version = None
    args.ciphers = None


# Generated at 2022-06-17 20:09:59.045419
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:10:08.812772
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.plugins.builtin
    import httpie.plugins.registry
    import httpie.plugins.manager
    import httpie.plugins.transport.http
    import httpie.plugins.transport.https
    import httpie.plugins.transport.http2
    import httpie.plugins.transport.http2.adapter
    import httpie.plugins.transport.http2.adapter.backend.hyper
    import httpie.plugins.transport.http2.adapter.backend.hyper.h2
    import httpie.plugins.transport.http2.adapter.backend.hyper.h2.connection

# Generated at 2022-06-17 20:10:19.135962
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   