

# Generated at 2022-06-17 20:02:59.619565
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}

    args.json = False
    args.form = True
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:03:03.788016
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:03:11.791001
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://httpbin.org/get'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.data = None
    args.json = False
    args.form = False
    args.files = []
    args.params = {}
    args.auth = None
    args.auth_plugin = None
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.compress = False
    args.compress_level = None
    args.timeout = None
    args.check_status = False
    args.check_headers = False
    args.check_body = False
    args.stream = False
    args.session

# Generated at 2022-06-17 20:03:21.958881
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://httpbin.org/get'
    args.headers = {'Accept': 'application/json'}
    args.data = {'key1': 'value1', 'key2': 'value2'}
    args.json = True
    args.form = False
    args.files = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.max_redirects = None
    args.follow = False
   

# Generated at 2022-06-17 20:03:32.949887
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import os
    import sys
    import tempfile
    import unittest
    from httpie.cli import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.utils import get_expired_cookies, repr_dict
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 20:03:34.248400
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:03:43.562282
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = RequestHeadersDict()
    args.headers['User-Agent'] = 'HTTPie/0.9.9'
    args.headers['Accept-Encoding'] = 'gzip, deflate'
    args.headers['Accept'] = '*/*'
    args.headers['Connection'] = 'keep-alive'
    args.headers['Host'] = 'www.google.com'
    args.headers['Content-Length'] = '0'
    args.headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=utf-8'
    args.headers['Accept-Encoding'] = 'gzip, deflate'

# Generated at 2022-06-17 20:03:49.388490
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.stream = True
    args.proxies = None
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
        'verify': True,
        'cert': None,
        'stream': True,
        'proxies': None
    }

# Generated at 2022-06-17 20:03:55.465885
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}


# Generated at 2022-06-17 20:04:08.392823
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/test'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'test': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress

# Generated at 2022-06-17 20:04:31.825048
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}



# Generated at 2022-06-17 20:04:36.564855
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:04:47.598725
# Unit test for function max_headers
def test_max_headers():
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000
    with max_headers(None):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == float('Inf')
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000
    with max_headers(100):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == 100
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000
    with max_headers(0):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == 0
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-17 20:04:51.609050
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:04:59.943154
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = "http://www.google.com"
    args.method = "GET"
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.compress = False
    args.debug = False
    args.offline = False
    args.chunked = False
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.session = None
    args.session_read_only = None
    args.auth = None
    args.auth_plugin = None
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
   

# Generated at 2022-06-17 20:05:08.936307
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = 'boundary'
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.offline = False
    args.chunked = False
    args.compress = False
    args.debug = False
    args.session = None
    args.session_read_only

# Generated at 2022-06-17 20:05:18.769284
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}

    args.json = False
    args.form = True
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:05:19.563326
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(10) == 10

# Generated at 2022-06-17 20:05:21.987574
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:05:26.977418
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'HTTPie/1.0.2'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {'key': 'value'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.session = None
    args.session_read_only = None
    args.debug = False
    args.follow = False
    args.max_redirects = None
    args.max_

# Generated at 2022-06-17 20:06:11.807088
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {}
    args.headers = {}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    assert default_headers['User-Agent'] == DEFAULT_UA

    args = argparse.Namespace()
    args.json = False
    args.form = True
    args.data = {}
    args.headers = {}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == '*/*'
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:06:12.922986
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:21.996308
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080')]
    args.verify = 'yes'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {'http': 'http://127.0.0.1:8080'}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert.pem'
    assert kwargs['cert_key'] == 'cert_key.pem'

# Generated at 2022-06-17 20:06:34.721682
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False

# Generated at 2022-06-17 20:06:37.909862
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = None
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:06:40.340532
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:06:45.190927
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        chunked=False,
        cert=None,
        cert_key=None,
        data=None,
        debug=False,
        files=None,
        form=False,
        headers=RequestHeadersDict(),
        json=False,
        max_redirects=None,
        method='GET',
        multipart=False,
        multipart_data=None,
        offline=False,
        params=RequestHeadersDict(),
        path_as_is=False,
        proxy=None,
        session=None,
        session_read_only=None,
        timeout=None,
        url='http://www.google.com',
        verify=True,
    )
    base_headers = RequestHead

# Generated at 2022-06-17 20:06:53.411997
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://localhost:8080/'
    args.method = 'GET'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'test': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.max_redirects = None
    args.follow = True
    args.all = False
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.ssl_

# Generated at 2022-06-17 20:06:57.381506
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)


# Generated at 2022-06-17 20:07:08.159572
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = None
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = None
    headers = make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = None
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in headers
    assert 'Content-Type' not in headers
    args.json = False

# Generated at 2022-06-17 20:08:25.194221
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        chunked=False,
        cert=None,
        cert_key=None,
        data=None,
        files=None,
        form=False,
        headers=RequestHeadersDict(),
        json=False,
        max_headers=None,
        method='GET',
        multipart=False,
        multipart_data=None,
        offline=False,
        params=RequestHeadersDict(),
        path_as_is=False,
        proxy=[],
        session=None,
        session_read_only=None,
        timeout=None,
        url='http://example.com',
        verify=True,
    )
    base_headers = RequestHeadersDict()
    request_body_read

# Generated at 2022-06-17 20:08:34.610503
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    args.files = False
    args.headers = {}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    assert default_headers['User-Agent'] == DEFAULT_UA
    args.json = False
    args.data = {}
    args.form = True
    args.files = False
    args.headers = {}
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    assert default_headers['User-Agent'] == DEFAULT_UA
    args.json = False
    args

# Generated at 2022-06-17 20:08:37.025880
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:08:46.946600
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = {'User-Agent': DEFAULT_UA}
    args.data = None
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.compress = False
    args.compress_level = None
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.ssl_version = None
    args.ciphers = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
   

# Generated at 2022-06-17 20:08:53.189592
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    for i in collect_messages(args, config_dir, request_body_read_callback):
        print(i)


# Generated at 2022-06-17 20:08:58.092005
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)


# Generated at 2022-06-17 20:09:08.909547
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
   

# Generated at 2022-06-17 20:09:20.099736
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = False
    args.form = True
    args.data = None
    args.files

# Generated at 2022-06-17 20:09:31.560359
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://127.0.0.1:8080/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.offline = False
    args.chunked = False
    args.compress = False
   

# Generated at 2022-06-17 20:09:39.456500
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.sessions
    import httpie.utils
    import httpie.ssl
    import httpie.uploads
    import httpie.plugins.registry
    import httpie.plugins.builtin
    import httpie.plugins.transport.http
    import httpie.plugins.transport.https
    import httpie.plugins.transport.http2
    import httpie.plugins.transport.http2_alt
    import httpie.plugins.transport.httpbin
    import httpie.plugins.transport.httpbin_any
    import httpie.plugins.transport.httpbin_https
    import httpie.plugins.transport.httpbin_org
    import httpie.plugins.transport.httpie
    import http