

# Generated at 2022-06-17 20:03:00.668130
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:03:10.061010
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.utils
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.plugins.registry
    import httpie.plugins.transport
    import httpie.plugins.transport.http
    import httpie.plugins.transport.http.http
    import httpie.plugins.transport.http.https
    import httpie.plugins.transport.http.http2
    import httpie.plugins.transport.http.http2.http2
    import httpie.plugins.transport.http.http2.http2_adapter
    import httpie.plugins.transport.http.http

# Generated at 2022-06-17 20:03:14.590794
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }

# Generated at 2022-06-17 20:03:25.169426
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    headers.update({'Content-Type': 'application/json'})
    headers.update({'Content-Type': 'application/json'})
    headers.update({'Content-Type': 'application/json'})
    headers.update({'Content-Type': 'application/json'})
    headers.update({'Content-Type': 'application/json'})
    headers.update({'Content-Type': 'application/json'})
    headers.update({'Content-Type': 'application/json'})
    headers.update({'Content-Type': 'application/json'})
    headers.update({'Content-Type': 'application/json'})
    headers.update({'Content-Type': 'application/json'})

# Generated at 2022-06-17 20:03:30.294235
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': 10, 'allow_redirects': False}


# Generated at 2022-06-17 20:03:38.662764
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'


# Generated at 2022-06-17 20:03:42.366938
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:03:49.536054
# Unit test for function collect_messages

# Generated at 2022-06-17 20:04:00.030753
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "http://www.google.com"
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.offline = False
    args.chunked = False
    args.compress = False
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.session = None
    args.session_read_only = None
    args.debug = False

# Generated at 2022-06-17 20:04:06.447611
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version='TLSv1.2',
        ciphers='AES128-GCM-SHA256'
    )
    assert requests_session.verify == True
    assert requests_session.ssl_version == 'TLSv1.2'
    assert requests_session.ciphers == 'AES128-GCM-SHA256'

# Generated at 2022-06-17 20:04:27.227744
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {}
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    headers = make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE

# Generated at 2022-06-17 20:04:30.788428
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-17 20:04:35.234304
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT

# Generated at 2022-06-17 20:04:43.157944
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.proxy = None
    args.stream = True
    args.verify = False
    args.cert = None
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False, 'stream': True, 'verify': False, 'cert': None}


# Generated at 2022-06-17 20:04:46.882666
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:04:57.293371
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'https://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'q': 'httpie'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.offline = False
    args.chunked = False
    args.compress = False
    args.debug = False
    args.max_redirects = None
    args.follow = False

# Generated at 2022-06-17 20:05:02.951611
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'Accept': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.offline = False
    args.chunked = False
    args.compress = False
    args

# Generated at 2022-06-17 20:05:05.022233
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-17 20:05:16.597655
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:05:26.623282
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:05:54.233198
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS != 10

# Generated at 2022-06-17 20:06:06.158423
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import os
    import sys
    import tempfile
    from pathlib import Path
    from httpie.cli.parser import parser
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import Session
    from httpie.utils import get_response_dict

    # noinspection PyProtectedMember
    plugin_manager._instances = {}
    plugin_manager._plugin_classes = {}
    plugin_manager._plugin_kwargs = {}
    plugin_manager._plugin_kwargs_types = {}
    plugin_manager._plugin_lookup = {}
    plugin_manager._plugin_lookup_classes = {}

# Generated at 2022-06-17 20:06:14.802269
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = None
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'a': 1, 'b': 2}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunk

# Generated at 2022-06-17 20:06:17.014911
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-17 20:06:28.248368
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.data = {}
    args.form = True
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE

# Generated at 2022-06-17 20:06:38.445224
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = None
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'test'}
    args.timeout = None
    args.verify = True

# Generated at 2022-06-17 20:06:43.805226
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:06:51.768060
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.method = 'GET'
    args.headers = {'User-Agent': 'HTTPie/0.9.9'}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.compress = False
    args.debug = False
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.path_as_is = False
    args.session = None
    args.session_read_only = None
    args.auth = None
    args.auth_plugin = None
    args.timeout = None
    args.verify

# Generated at 2022-06-17 20:06:58.778055
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:07:08.926490
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.files = False
    args.data = None
    args.headers = {}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == '*/*'
    assert default_headers['Content-Type'] == 'application/json'
    args.json = True
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True

# Generated at 2022-06-17 20:07:47.530581
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}

    args.json = False

# Generated at 2022-06-17 20:07:52.570416
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'timeout': 10, 'allow_redirects': False}



# Generated at 2022-06-17 20:08:00.607131
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}

    args.json = False
    args.form = True
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:08:10.169132
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080'
    args.headers = RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'})
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {'key': 'value'}
    args.timeout = None
    args.verify = False
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.follow = False
    args.max_

# Generated at 2022-06-17 20:08:15.220286
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parse_args(['--json', 'http://localhost:5000/api/v1/users'])
    config_dir = Path('/home/travis/.config/httpie')
    request_body_read_callback = lambda chunk: chunk
    messages = collect_messages(args, config_dir, request_body_read_callback)
    for message in messages:
        print(message)

# Generated at 2022-06-17 20:08:18.066849
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:08:19.964240
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'timeout': 10, 'allow_redirects': False}



# Generated at 2022-06-17 20:08:24.277918
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:08:32.642412
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version='TLSv1.2',
        ciphers=None,
    )
    assert requests_session
    assert requests_session.mounts
    assert requests_session.mounts['https://']
    assert requests_session.mounts['https://'][0].verify
    assert requests_session.mounts['https://'][0].ssl_version
    assert requests_session.mounts['https://'][0].ciphers
    assert requests_session.mounts['https://'][0].__class__.__name__ == 'HTTPieHTTPSAdapter'


# Generated at 2022-06-17 20:08:44.583039
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:09:43.855137
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:09:45.731933
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:09:58.782803
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.data = {}
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.data = {}
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type'

# Generated at 2022-06-17 20:10:08.666501
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == '*/*'
    assert default_headers['Content-Type'] == None
    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:10:19.136254
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {'foo': 'bar'}
    args.form = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    assert default_headers['User-Agent'] == DEFAULT_UA
    args.json = False
    args.data = {'foo': 'bar'}
    args.form = True
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE

# Generated at 2022-06-17 20:10:25.945534
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:10:30.902505
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:10:37.845360
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }

# Generated at 2022-06-17 20:10:46.269170
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='http://127.0.0.1:8081')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs

# Generated at 2022-06-17 20:10:55.318176
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}