

# Generated at 2022-06-17 20:02:43.497105
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:02:46.403492
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    headers.update({'Content-Type': 'application/json'})
    headers = finalize_headers(headers)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Content-Type'] == 'application/json'

# Generated at 2022-06-17 20:02:47.836349
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:02:57.666954
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        form=False,
        json=False,
        files=None,
    )
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args = argparse.Namespace(
        data=None,
        form=False,
        json=True,
        files=None,
    )
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers


# Generated at 2022-06-17 20:03:02.458792
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:03:08.594574
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:03:19.812335
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'}
    args.data = {'wd': 'httpie'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'ie': 'utf-8'}
    args.timeout = None
    args.ver

# Generated at 2022-06-17 20:03:28.621860
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import os
    import sys
    from httpie.cli.parser import parser
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import Session
    from httpie.utils import get_expired_cookies, repr_dict
    from httpie.compat import is_windows
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.cli.utils import get_response_stream
    from httpie.output.streams import get_output

# Generated at 2022-06-17 20:03:35.451970
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'no'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == False
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:03:44.614459
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == '*/*'
    assert default_headers['Content-Type'] == None

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = False
    args.form = True


# Generated at 2022-06-17 20:04:09.143871
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:04:11.200139
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:04:17.178196
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/'
    args.headers = RequestHeadersDict()
    args.headers['Content-Type'] = 'application/json'
    args.headers['Accept'] = 'application/json'
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
   

# Generated at 2022-06-17 20:04:24.085508
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:04:31.612298
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.proxy = None
    args.stream = True
    args.verify = True
    args.cert = None
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False
    assert kwargs['proxy'] == None
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:04:37.044749
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080')]
    args.verify = 'yes'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {
        'proxies': {'http': 'http://127.0.0.1:8080'},
        'stream': True,
        'verify': True,
        'cert': ('cert.pem', 'cert_key.pem')
    }

# Generated at 2022-06-17 20:04:42.603363
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['timeout'] == 10
    assert send_kwargs['allow_redirects'] == False

# Generated at 2022-06-17 20:04:52.749428
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:04:57.195455
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:05:02.787259
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.proxy = [
        argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
        argparse.Namespace(key='https', value='https://127.0.0.1:8080')
    ]
    args.cert = './cert.pem'
    args.cert_key = './cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True
    assert kwargs['proxies'] == {'http': 'http://127.0.0.1:8080', 'https': 'https://127.0.0.1:8080'}

# Generated at 2022-06-17 20:05:41.362955
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}

    args.json = False
    args.form = True
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:05:49.495517
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}

    args.json = False
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}

    args.json = False
    args.form = False

# Generated at 2022-06-17 20:05:55.286110
# Unit test for function collect_messages

# Generated at 2022-06-17 20:06:06.341978
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [
        argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
        argparse.Namespace(key='https', value='https://127.0.0.1:8080')
    ]
    args.verify = 'yes'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {'http': 'http://127.0.0.1:8080', 'https': 'https://127.0.0.1:8080'}
    assert kwargs['stream'] == True
    assert kwargs

# Generated at 2022-06-17 20:06:08.786213
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:11.298585
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    final_headers = finalize_headers(headers)
    assert final_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:06:21.409331
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == '*/*'
    assert default_headers['Content-Type'] == None

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == None

    args.json = False
    args.form = True
    args.data = None

# Generated at 2022-06-17 20:06:34.192700
# Unit test for function build_requests_session

# Generated at 2022-06-17 20:06:37.571154
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:06:40.984705
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-17 20:08:10.890689
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 1
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'timeout': 1, 'allow_redirects': False}


# Generated at 2022-06-17 20:08:18.270531
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:08:22.123172
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

# Generated at 2022-06-17 20:08:26.627007
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:08:32.599821
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'no'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == False
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:08:44.583277
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = True
    args.form = False
    args.files = False
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.data = False
    args.form = True
    args.files = False
    headers = make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.data = False
    args.form = True
    args.files = True
    headers = make_default_headers(args)
    assert 'Content-Type' not in headers
    args.json = False
    args.data = True


# Generated at 2022-06-17 20:08:58.969825
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = True
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.data = False
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.data = True
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

# Generated at 2022-06-17 20:09:03.532568
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }

# Generated at 2022-06-17 20:09:08.319529
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parser.parse_args(['--session', 'test', '--json', 'http://httpbin.org/get'])
    config_dir = Path.home() / '.httpie'
    for message in collect_messages(args, config_dir):
        print(message)

# Generated at 2022-06-17 20:09:19.671146
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = False
    args.form = True
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE

    args.json = False
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT

# Generated at 2022-06-17 20:11:48.190368
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunked = False
    args.compress = False


# Generated at 2022-06-17 20:11:54.215058
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}



# Generated at 2022-06-17 20:12:04.632955
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
   

# Generated at 2022-06-17 20:12:12.671942
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/api/v1/users'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'username': 'test', 'password': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.offline = False
    args.chunk

# Generated at 2022-06-17 20:12:14.033672
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:12:17.468865
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }

# Generated at 2022-06-17 20:12:26.145707
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   