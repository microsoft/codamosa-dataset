

# Generated at 2022-06-17 20:02:48.915931
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.chunked = False
    args.offline = False
    args.compress = False

# Generated at 2022-06-17 20:02:50.628300
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=None):
        assert http.client._MAXHEADERS == float('Inf')
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:02:55.381732
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:02:58.200580
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-17 20:03:00.412396
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:03:09.900259
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://localhost:8080/'
    args.method = 'GET'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.compress = 0
    args.comp

# Generated at 2022-06-17 20:03:13.431528
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:03:24.084063
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.url = 'http://httpbin.org/get'
    args.method = 'GET'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.compress = False
    args.debug = False
    args.offline = False
    args.chunked = False
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.path_as_is = False
    args.timeout = None
    args.auth = None
    args.auth_plugin = None
    args.session = None
    args.session_read_only = None
    args.verify = True
    args.cert = None


# Generated at 2022-06-17 20:03:29.520812
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }

# Generated at 2022-06-17 20:03:40.885843
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-17 20:04:09.918407
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'), argparse.Namespace(key='https', value='http://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'test.crt'
    args.cert_key

# Generated at 2022-06-17 20:04:12.400369
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:04:13.790013
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:19.782157
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}
    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}
    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}
    args.json = False

# Generated at 2022-06-17 20:04:22.661063
# Unit test for function max_headers
def test_max_headers():
    with max_headers(3):
        assert http.client._MAXHEADERS == 3
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:32.766191
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = True
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = True
    headers = make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.form = False
    args.data = True
    headers = make_default_headers(args)
    assert 'Content-Type' not in headers
    args.json = False
    args.form = False
    args.data = False
    headers = make_default_headers(args)

# Generated at 2022-06-17 20:04:36.185289
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:47.673007
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = "https://httpbin.org/get"
    args.method = "GET"
    args.headers = {}
    args.data = None
    args.json = None
    args.form = None
    args.files = None
    args.params = {}
    args.auth = None
    args.auth_plugin = None
    args.session = None
    args.session_read_only = None
    args.timeout = None
    args.verify = None
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = None
    args.compress = None
    args.max_redirects = None
    args.follow = None
    args.max_headers = None
    args.ssl_version = None

# Generated at 2022-06-17 20:04:51.698809
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:04:53.853057
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:05:14.756411
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:05:17.316620
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:05:20.940695
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

# Generated at 2022-06-17 20:05:28.157251
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:05:32.995766
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = ''
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None


# Generated at 2022-06-17 20:05:37.847107
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:05:42.585762
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

# Generated at 2022-06-17 20:05:46.175227
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:05:49.327394
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:05:51.645912
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:06:14.315661
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}
    args.json = False
    args.form = True
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}
    args.json = False
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:06:18.688918
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:06:26.918567
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

# Generated at 2022-06-17 20:06:37.706254
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'}
    args.data = {'wd': 'httpie'}
    args.json = True
    args.form = False
    args.files = None
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'ie': 'utf-8'}
    args.timeout = None
    args.ver

# Generated at 2022-06-17 20:06:46.073177
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:06:55.409912
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

# Generated at 2022-06-17 20:06:56.992531
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:07:08.063304
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        cert=None,
        cert_key=None,
        chunked=False,
        data=None,
        debug=False,
        files=None,
        form=False,
        headers=RequestHeadersDict(),
        json=False,
        max_headers=None,
        method='GET',
        multipart=False,
        multipart_data=None,
        offline=False,
        params=RequestHeadersDict(),
        path_as_is=False,
        proxy=[],
        session=None,
        session_read_only=None,
        timeout=None,
        url='http://127.0.0.1:5000/',
        verify=True,
    )

# Generated at 2022-06-17 20:07:16.287271
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'test'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.chunked = False
    args.offline = False

# Generated at 2022-06-17 20:07:26.542859
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'}
    args.data = {'q': 'httpie'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None

# Generated at 2022-06-17 20:08:34.095918
# Unit test for function make_default_headers

# Generated at 2022-06-17 20:08:45.105386
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {'key': 'value'}
    args.compress = False
    args.max_redirects = None
    args.max_headers = None
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.offline = False
    args.chunked = False
    args.session

# Generated at 2022-06-17 20:08:59.749827
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        form=False,
        json=False,
        files=None,
        headers=RequestHeadersDict(),
    )
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })

    args = argparse.Namespace(
        data=None,
        form=False,
        json=True,
        files=None,
        headers=RequestHeadersDict(),
    )
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
    })


# Generated at 2022-06-17 20:09:02.152206
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:09:08.517259
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:09:10.172744
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:09:15.312879
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}



# Generated at 2022-06-17 20:09:23.887036
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import os
    import sys
    import tempfile
    from httpie.cli.parser import parser
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import Session
    from httpie.utils import get_expired_cookies
    from httpie.utils import get_response_text
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import get_response_type_raw_from_headers
    from httpie.utils import get_response_type_raw_from_url
    from httpie.utils import get

# Generated at 2022-06-17 20:09:35.460107
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.constants
    import httpie.cli.utils
    import httpie.cli.auth
    import httpie.cli.output
    import httpie.cli.formatter
    import httpie.cli.formatters
    import httpie.cli.formatters.colors
    import httpie.cli.formatters.json
    import httpie.cli.formatters.json_lines
    import httpie.cli.formatters.json_lines_pretty
    import httpie.cli.formatters.json_pretty
    import httpie.cli.formatters.table
    import httpie.cli.formatters.table_pretty
    import http

# Generated at 2022-06-17 20:09:38.820803
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:11:26.615995
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == '*/*'
    assert default_headers['Content-Type'] == None

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == None

    args.json = False
    args.form = True
    args.data = None

# Generated at 2022-06-17 20:11:37.423977
# Unit test for function collect_messages

# Generated at 2022-06-17 20:11:39.576464
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:11:44.088571
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:11:52.740330
# Unit test for function make_default_headers

# Generated at 2022-06-17 20:12:04.421371
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'key': 'value'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {'key': 'value'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.session = None
    args.session_read_only = None
    args.debug = False
    args.compress = False
    args.max_redirects = None

# Generated at 2022-06-17 20:12:13.939808
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='http://127.0.0.1:8080')]
    args.verify = 'yes'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {'http': 'http://127.0.0.1:8080', 'https': 'http://127.0.0.1:8080'}
    assert kwargs['stream'] == True
    assert kwargs['verify']

# Generated at 2022-06-17 20:12:23.012024
# Unit test for function collect_messages