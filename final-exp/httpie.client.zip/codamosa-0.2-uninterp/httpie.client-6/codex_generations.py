

# Generated at 2022-06-17 20:02:47.327213
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    args.data = None
    default_headers = make_default_headers(args)
   

# Generated at 2022-06-17 20:02:56.880930
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'get'
    args.url = 'http://www.baidu.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = None
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'name': 'test'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.offline = False
    args.chunked = False
    args.debug = False

# Generated at 2022-06-17 20:03:03.586343
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=False,
        ssl_version='TLSv1.2',
        ciphers='ECDHE-ECDSA-AES256-GCM-SHA384'
    )
    assert requests_session.verify == False
    assert requests_session.ssl_version == 'TLSv1.2'
    assert requests_session.ciphers == 'ECDHE-ECDSA-AES256-GCM-SHA384'

# Generated at 2022-06-17 20:03:11.677699
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}

    args.json = False
    args.form = True
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:03:21.868481
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers
    args.json = True
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = {}
    default_headers = make_default_headers(args)
    assert default

# Generated at 2022-06-17 20:03:32.743508
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'get'
    args.url = 'http://www.baidu.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'test'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW'
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False

# Generated at 2022-06-17 20:03:36.303524
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-17 20:03:42.368360
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli.parser import parser
    args = parser.parse_args(['--json', 'http://httpbin.org/post'])
    config_dir = Path('/Users/yunfei/.httpie')
    request_body_read_callback = lambda chunk: chunk
    for i in collect_messages(args, config_dir, request_body_read_callback):
        print(i)

if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-17 20:03:44.732137
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:03:46.974011
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:10.089705
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    args.proxy = [argparse.Namespace(key='http', value='http://localhost:8080')]
    args.verify = 'no'
    args.cert = 'cert.pem'
    args.cert_key = 'cert_key.pem'

# Generated at 2022-06-17 20:04:14.437943
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    ssl_version = 'TLSv1.2'
    ciphers = 'ECDHE-RSA-AES256-GCM-SHA384'
    requests_session = build_requests_session(
        verify=verify,
        ssl_version=ssl_version,
        ciphers=ciphers
    )
    assert requests_session.verify == verify
    assert requests_session.ssl_version == ssl_version
    assert requests_session.ciphers == ciphers


# Generated at 2022-06-17 20:04:22.822544
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        chunked=False,
        data=None,
        debug=False,
        files=None,
        form=False,
        headers=RequestHeadersDict(),
        json=False,
        max_headers=None,
        max_redirects=None,
        multipart=False,
        multipart_data=None,
        offline=False,
        params=RequestHeadersDict(),
        path_as_is=False,
        session=None,
        session_read_only=None,
        timeout=None,
        url='http://httpbin.org/get',
        verify=True,
    )
    config_dir = Path('/home/user/.config/httpie')
    request_body_read

# Generated at 2022-06-17 20:04:32.857602
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'}
    args.data = {'q': 'httpie'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = []
    args.boundary = '--------------------------8a8f8b8c8d8e8f8g'
    args.auth = None

# Generated at 2022-06-17 20:04:45.782409
# Unit test for function make_request_kwargs

# Generated at 2022-06-17 20:04:46.943781
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:04:57.366149
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'}
    args.data = None
    args.form = False
    args.json = False
    args.files = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False

# Generated at 2022-06-17 20:05:03.091617
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.url = 'http://localhost:5000/'
    args.method = 'GET'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.params = {}
    args.auth = None
    args.auth_plugin = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.compress = False
    args.debug = False
    args.timeout = None
    args.check_status = False
    args.check_ssl = False
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.ssl_version = None
    args.cip

# Generated at 2022-06-17 20:05:05.849241
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:05:10.267533
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:05:38.812541
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:05:41.189857
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(verify=True, ssl_version='tls1.2', ciphers='ECDHE-RSA-AES256-GCM-SHA384')

# Generated at 2022-06-17 20:05:49.328367
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.debug = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.max_redirects = None
    args.follow = False
    args.session = None
    args.session_read_only = None

# Generated at 2022-06-17 20:05:53.400917
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.utils
    import httpie.cli.auth
    import httpie.cli.output
    import httpie.cli.formatter
    import httpie.cli.formatters
    import httpie.cli.sessions
    import httpie.cli.downloads
    import httpie.cli.download
    import httpie.cli.stream
    import httpie.cli.streams
    import httpie.cli.environment
    import httpie.cli.config
    import httpie.cli.config_dir
    import httpie.cli.config_types
    import httpie.cli.config_helpers
    import httpie.cli.config

# Generated at 2022-06-17 20:05:58.465707
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.auth = None
    args.params = {'foo': 'bar'}
    args.compress = False
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.session = None
    args.session_read_only = None

# Generated at 2022-06-17 20:06:09.459964
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.utils
    import httpie.plugins.registry
    import httpie.sessions
    import httpie.utils
    import httpie.cli.auth
    import httpie.cli.auth
    import httpie.cli.downloads
    import httpie.cli.form
    import httpie.cli.headers
    import httpie.cli.json
    import httpie.cli.output
    import httpie.cli.pretty
    import httpie.cli.stream
    import httpie.cli.style
    import httpie.cli.verbose
    import httpie.cli.config
    import httpie.cli.downloads
   

# Generated at 2022-06-17 20:06:14.629768
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli.parser
    args = httpie.cli.parser.parse_args(['--json', '--auth', 'user:pass', 'http://httpbin.org/get'])
    config_dir = Path('/tmp')
    collect_messages(args, config_dir)

# Generated at 2022-06-17 20:06:23.224912
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://httpbin.org/get'
    args.method = 'GET'
    args.headers = RequestHeadersDict()
    args.headers['User-Agent'] = 'HTTPie/1.0.3'
    args.headers['Accept'] = '*/*'
    args.headers['Connection'] = 'keep-alive'
    args.headers['Host'] = 'httpbin.org'
    args.headers['Accept-Encoding'] = 'gzip, deflate'
    args.headers['Cache-Control'] = 'no-cache'
    args.headers['Postman-Token'] = 'f7e9c6a1-8b3f-4e1b-b9b5-a8a9c9f0a7a2'

# Generated at 2022-06-17 20:06:24.538497
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:06:29.133772
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 1
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 1
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:07:26.212007
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = None
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-17 20:07:31.774420
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:07:34.421693
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:07:40.259397
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.headers = {'User-Agent': 'Mozilla/5.0'}
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {'foo': 'bar'}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.offline = False
    args.chunked

# Generated at 2022-06-17 20:07:44.702565
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-17 20:07:48.300292
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-17 20:07:57.202402
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('cert', 'cert_key')

# Generated at 2022-06-17 20:08:04.753504
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:08:13.368197
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'name': 'John Doe'}
    args.json = True
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.offline = False
    args.chunked = False
    args.compress = False
    args.debug = False

# Generated at 2022-06-17 20:08:19.611366
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = True
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='http://127.0.0.1:8080')]
    args.verify = False
    args.cert = 'cert.pem'

# Generated at 2022-06-17 20:10:14.474243
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-17 20:10:23.094273
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'https://www.google.com'
    args.method = 'GET'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.timeout = None
    args.auth = None
    args.params = {}
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.chunked = False
    args.compress = False
    args.debug = False
    args.session = None
    args.session_read_only = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = []

# Generated at 2022-06-17 20:10:34.046244
# Unit test for function collect_messages

# Generated at 2022-06-17 20:10:44.088094
# Unit test for function collect_messages

# Generated at 2022-06-17 20:10:46.816898
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-17 20:10:56.807503
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = None
    args.cert_key = None
    args.proxy = []
    args.verify = 'yes'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None


# Generated at 2022-06-17 20:11:06.357144
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'http://httpbin.org/get'
    args.method = 'GET'
    args.headers = {'Accept': 'application/json'}
    args.json = True
    args.data = {'foo': 'bar'}
    args.form = False
    args.files = []
    args.auth = None
    args.auth_plugin = None
    args.params = {}
    args.session = None
    args.session_read_only = None
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.compress = False
    args.chunked = False
    args.json = True
    args.form = False
   

# Generated at 2022-06-17 20:11:14.819116
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json = False
    args.data = {}
    args.form = True
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    args.json = False
    args.data = {}
    args.form = False
    args.files = True
    default_headers = make_default_headers(args)

# Generated at 2022-06-17 20:11:25.715305
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:8080'), argparse.Namespace(key='https', value='http://127.0.0.1:8080')]
    args.verify = 'no'
    args.cert = 'test.crt'
    args.cert_key = 'test.key'
    kwargs = make_send_

# Generated at 2022-06-17 20:11:36.330070
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        form=False,
        json=False,
        files=None,
    )
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args = argparse.Namespace(
        data=None,
        form=True,
        json=False,
        files=None,
    )
    default_headers = make_default_headers(args)
    assert default_headers == {
        'User-Agent': DEFAULT_UA,
        'Content-Type': FORM_CONTENT_TYPE,
    }

    args = argparse.Namespace(
        data=None,
        form=False,
        json=True,
        files=None,
    )