

# Generated at 2022-06-21 13:29:50.722341
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_dict = {
            '--form': True,
            '<url>': 'http://jsonplaceholder.typicode.com/posts',
            'data': {
                'body': 'this is body',
                'title': 'this is title',
                'userId': 1
            },
            'files': None,
            'json': True,
            'method': 'POST',
            'headers': {
                'Content-Type': 'application/json',
                'User-Agent': 'HTTPie/1.0.2'
            },
            'auth': None,
            'params': [],
            'verify': True
    }
    args = argparse.Namespace(**args_dict)
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'post'

# Generated at 2022-06-21 13:29:59.421151
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'url': 'http://127.0.0.1:8000/match/',
        'headers': {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
            "Content-Length": "36",
            "Content-Type": "application/json",
            "Host": "httpbin.org",
            "User-Agent": "python-requests/2.12.3"

        },
        'data': "{\"id\":[\"1\",\"2\",\"3\"],\"name\":\"yang\"}",
        'auth': ('user', 'pass'),
        'method': "POST",
        'timeout': None,
        'allow_redirects': False,
    }

# Generated at 2022-06-21 13:30:05.039290
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session(verify=False, ssl_version='SSLv2')
    build_requests_session(verify=False, ciphers='RC4')
    build_requests_session(verify=False)
    build_requests_session(verify=False, ssl_version='SSLv2', ciphers='RC4')

# Generated at 2022-06-21 13:30:14.724580
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://httpbin.org/get'
    args.headers = {'Accept':'application/json'}
    args.json = True
    args.data = {'key':'value'}
    args.verify = True
    args.debug = True
    args.compress = False
    args.timeout = None
    args.allow_redirects = True
    args.max_redirects = 5

    kwargs = make_request_kwargs(
        args = args
    )
    dump_request(kwargs)



# Generated at 2022-06-21 13:30:18.075694
# Unit test for function make_default_headers
def test_make_default_headers():
    headers = make_default_headers(argparse.Namespace(json=True))
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    assert headers['Accept'] == JSON_ACCEPT

# Generated at 2022-06-21 13:30:26.208341
# Unit test for function make_send_kwargs

# Generated at 2022-06-21 13:30:38.237396
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    def request_body_read_callback(chunk):
        chunk.decode()
        return chunk
    #@todo: test file, see https://github.com/psf/requests/blob/master/tests/test_requests.py#L643

# Generated at 2022-06-21 13:30:48.903156
# Unit test for function collect_messages
def test_collect_messages():
    from io import BytesIO
    from unittest import mock

    def _test(args, json_dumps_exp=None, data_exp=None,
              files_exp=None, data_callback_exp=None, stream=True,
              verify=''):
        with mock.patch('httpie.client.make_send_kwargs_mergeable_from_env') \
                as m, \
                mock.patch('httpie.client.make_send_kwargs') as m2, \
                mock.patch('httpie.client.build_requests_session') \
                as m3, \
                mock.patch('httpie.client.get_httpie_session') as m4, \
                mock.patch('httpie.client.dump_request') as m5:
            m4.return_value.headers

# Generated at 2022-06-21 13:30:54.414104
# Unit test for function make_default_headers
def test_make_default_headers():
    args = ['--form', '',
            '--data', '{"name":"John"}',
            '--json']
    args = argparse.Namespace(*args)
    default_headers = make_default_headers(args)
    default_headers_expected = RequestHeadersDict({
                                                       'User-Agent': DEFAULT_UA,
                                                       'Content-Type': FORM_CONTENT_TYPE,
                                                       'Accept': JSON_ACCEPT,
                                                       'Content-Type': JSON_CONTENT_TYPE
                                                   })

    #default_headers = finalize_headers(default_headers)

# Generated at 2022-06-21 13:31:07.633485
# Unit test for function make_default_headers

# Generated at 2022-06-21 13:31:24.365161
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.proxy = {}
    args.verify = "yes"
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    if(kwargs):
        print(kwargs)

# Generated at 2022-06-21 13:31:32.897924
# Unit test for function dump_request
def test_dump_request():
    # Test for the line containing 'requests.request'
    kwargs = {'method': 'get', 'url': 'http://example.com/'}
    dump_request(kwargs)
    test_line = """>>> requests.request(**{'method': 'get', 'url': 'http://example.com/'})"""
    sys.stderr.seek(0)
    assert sys.stderr.readline() == test_line + '\n'
    sys.stderr.close()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-21 13:31:38.193718
# Unit test for function collect_messages
def test_collect_messages():
    sys.argv = [sys.argv[0], 'http://www.wikipedia.org/']
    args = cli.parser.parse_args()
    config_dir = Path(__file__).parent.parent / 'httpie' / 'config'
    collect_messages(args, config_dir)

# Generated at 2022-06-21 13:31:50.474100
# Unit test for function finalize_headers
def test_finalize_headers():
    # Tests for leading and trailing whitespaces
    # in headers and keys
    assert finalize_headers(RequestHeadersDict({'Content-Type': 'text/html'})) == RequestHeadersDict({'Content-Type': b'text/html'})
    assert finalize_headers(RequestHeadersDict({' Content-Type': 'text/html'})) == RequestHeadersDict({' Content-Type': b'text/html'})
    assert finalize_headers(RequestHeadersDict({'Content-Type ': 'text/html'})) == RequestHeadersDict({'Content-Type ': b'text/html'})

# Generated at 2022-06-21 13:31:59.556937
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    """
    Testcase for function make_request_kwargs.
    """
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "http://www.google.com"
    args.headers = None
    args.data = "hello world"
    args.default = None
    args.json = False
    args.form = False
    args.files = False
    args.verify = False
    args.cert = None
    args.cert_key = None
    args.auth = "username:password"
    args.proxy = False
    args.timeout = None
    args.allow_redirects = False

    result = make_request_kwargs(args)
    assert result['method'] == 'get'
    assert result['url'] == 'http://www.google.com'


# Generated at 2022-06-21 13:32:03.813366
# Unit test for function make_default_headers
def test_make_default_headers():
    args = {'json': False, 'form': False, 'data': False}
    expected = {'User-Agent': 'HTTPie/0.9.9'}
    assert make_default_headers(args) == expected



# Generated at 2022-06-21 13:32:13.950152
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = None
    args.headers = None
    args.data = None
    args.json = None
    args.form = None
    args.files = None
    args.files = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None
    args.verify = None

# Generated at 2022-06-21 13:32:26.338200
# Unit test for function make_send_kwargs

# Generated at 2022-06-21 13:32:31.555060
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.json import JSON_PASSTHROUGH_CLI_ARGS
    from httpie.cli.parser import parse_args
    args = parse_args(args=['https://google.com', '--json'])
    config_dir = Path('.')
    msgs = [m for m in collect_messages(args, config_dir)]
    assert len(msgs) == 2 and isinstance(msgs[-1], requests.Response)

# Generated at 2022-06-21 13:32:36.901446
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict([('User-Agent', 'httpie/1.0.0-dev1'), ('Host', 'example.com')])
    assert finalize_headers(headers) == {b'User-Agent': b'httpie/1.0.0-dev1', b'Host': b'example.com'}



# Generated at 2022-06-21 13:33:06.429299
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'https://www.google.com'
    args.follow = False
    args.path_as_is = True
    args.json = False
    args.form = False
    args.files = None
    args.data = None
    args.headers = dict()
    args.auth = None
    args.params = dict()
    args.max_redirects = 5
    args.max_headers = None
    args.compress = 0
    args.timeout = 5
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.ssl_version = 'TLSv1.2'
    args.proxy = None
    args.debug = False

# Generated at 2022-06-21 13:33:11.313705
# Unit test for function max_headers
def test_max_headers():
    import re
    import http.client
    import http.server
    import threading
    import urllib.request

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)

            self.send_header('foo', 'bar')
            self.send_header('foo', 'baz')
            self.send_header('foo', 'qux')

            self.end_headers()

            self.wfile.write(b'ok')

    srv = http.server.HTTPServer(('localhost', 0), Handler)
    thread = threading.Thread(target=srv.serve_forever)
    thread.start()


# Generated at 2022-06-21 13:33:17.188440
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    """
    Ensure that the ensured path is still encoded.

    >>> test_ensure_path_as_is()
    'http://foo/%2E%2E/?foo=bar'
    """
    orig_url = 'http://foo/../'
    prepped_url = 'http://foo/?foo=bar'
    ensured_url = ensure_path_as_is(orig_url, prepped_url)
    print(ensured_url)

# Generated at 2022-06-21 13:33:23.972073
# Unit test for function finalize_headers
def test_finalize_headers():
    header3 = b'Accept: application/json, */*;q=0.5'
    header_dict = {}
    header_dict['User-Agent'] = DEFAULT_UA
    header_dict['Accept'] = JSON_ACCEPT
    header_dict['Content-Type'] = JSON_CONTENT_TYPE
    assert make_default_headers() == header_dict
    assert make_default_headers([header3]) == header_dict

# Generated at 2022-06-21 13:33:31.626134
# Unit test for function max_headers
def test_max_headers():
    from httpie.cli.parser import parse_args
    from httpie.cli import environment
    from requests import Response
    from requests import PreparedRequest
    from io import BytesIO

    args = parse_args(['https://en.wikipedia.org/wiki/Main_Page'], env=environment.Environment())
    args.max_headers = 100
    print('\n')
    for message in collect_messages(
        args=args,
        config_dir=Path('.'),
        request_body_read_callback=lambda chunk: chunk,
    ):
        if isinstance(message, PreparedRequest):
            request = message
            print(request)
        if isinstance(message, Response):
            response = message
            print(response)
    print('\n')


# Generated at 2022-06-21 13:33:33.484439
# Unit test for function dump_request
def test_dump_request():
    a = argparse.Namespace()
    a.headers = {"Content-Type": "application/json"}
    a.method = "GET"
    dump_request(vars(a))

test_dump_request()

# Generated at 2022-06-21 13:33:41.054324
# Unit test for function collect_messages
def test_collect_messages():
    class Args:
        headers = {}
        form = True
        files = False
        json = True
        multipart = False
        raw_data = False
        method = 'get'
        url = 'https://swift.i-novus.ru'
        timeout = 60
        data = {'UserName': 'nfntgrbq'}
        params = {}
        files = {}
        auth = None
        max_redirects=30
        session=None
        follow=False
        output_file=None
        output_dir=None
        stream=False
        all=False
        history_aware=False
        session_read_only=False
        pretty=False
        colors=False
        ssl_version=None
        verify=True
        cert=None
        cert_key=None
        insecure=True

# Generated at 2022-06-21 13:33:44.259909
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=True, data=None, form=False)
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent']=='HTTPie/1.0.3'
    assert default_headers['Accept']=='application/json, */*;q=0.5'


# Generated at 2022-06-21 13:33:46.398952
# Unit test for function max_headers
def test_max_headers():
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000
    with max_headers(None) as value:
        assert http.client._MAXHEADERS == float('Inf')
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-21 13:33:51.969651
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'POST'
    args.url = 'http://localhost:8888/'
    args.headers = RequestHeadersDict()
    args.data = {'foo': 'bar'}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.offline = False
    args.chunked = False
    args.auth = None
    args.params = {}

# Generated at 2022-06-21 13:35:01.749971
# Unit test for function dump_request

# Generated at 2022-06-21 13:35:12.593441
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Positive Test Cases
    # 1. Verify all Arguments are added as per requirement from requests module
    args = argparse.Namespace(timeout=20, allow_redirects=False,
                              verify=True, cert=None,
                              proxy=None, stream=True)
    kwargs = make_send_kwargs(args)
    assert kwargs.get('timeout') == 20
    assert kwargs.get('allow_redirects') == False
    assert kwargs.get('verify') == True
    assert kwargs.get('cert') == None
    assert kwargs.get('proxy') == None
    assert kwargs.get('stream') == True
    # 2. Verify the values are set to None if the arguments are not passed
    args = argparse.Namespace()
    kwargs = make

# Generated at 2022-06-21 13:35:17.931446
# Unit test for function collect_messages
def test_collect_messages():
    sys.argv = ['http', 'https://httpie.org']
    parser, args = parse_args()
    config_dir = plugin_manager.global_config_dir
    messages = list(collect_messages(args, config_dir))
    request, response = messages
    assert request.method == 'GET'
    assert 'Content-Type' not in request.headers
    assert response.status_code == 200
    assert response.reason == 'OK'

# Generated at 2022-06-21 13:35:23.443472
# Unit test for function max_headers
def test_max_headers():
    # test http.client._MAXHEADERS after context
    with max_headers(None):
        assert http.client._MAXHEADERS is float('Inf')    
    # test http.client._MAXHEADERS before context
    assert http.client._MAXHEADERS == 100
    # test http.client._MAXHEADERS after context with limit
    with max_headers(3):
        assert http.client._MAXHEADERS == 3
    # test http.client._MAXHEADERS after context (no limit)
    with max_headers(None):
        assert http.client._MAXHEADERS is float('Inf')
    # test http.client._MAXHEADERS before context 
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-21 13:35:30.330383
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Arrange
    args = argparse.Namespace()
    args.cert = True
    args.cert_key = True
    args.proxy = [(1, 2)]
    args.stream = True
    args.verify = "no"
    expectedResult = {
        'proxies': {
            1:2
        },
        'stream': True,
        'verify': False,
        'cert': True
    }

    # Act
    result = make_send_kwargs_mergeable_from_env(args)

    # Assert
    assert result == expectedResult


# Generated at 2022-06-21 13:35:39.948856
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/bar', 'http://foo/?foo=bar') == 'http://foo/bar?foo=bar'
    assert ensure_path_as_is('http://foo/bar?foo', 'http://foo/?foo=bar') == 'http://foo/bar?foo'
    assert ensure_path_as_is('http://foo/foo%20bar', 'http://foo/?foo=bar') == 'http://foo/foo%20bar?foo=bar'
    assert ensure_path_as_is('http://foo/', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'

# Generated at 2022-06-21 13:35:45.563845
# Unit test for function max_headers
def test_max_headers():
    # 1. Test normal situation
    code = 1
    with max_headers(code):
        # 1.1 normal situation
        assert http.client._MAXHEADERS == code
    # 2. Test other situations
    code = 2
    try:
        with max_headers(code):
            # 2.1 no exception raised
            assert http.client._MAXHEADERS == code
        assert False
    except Exception as e:
        # 2.2 exception raised
        assert isinstance(e, Exception)


# Generated at 2022-06-21 13:35:54.715045
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "http://httpbin.org/get"
    args.headers = {'Accept-Encoding':None, 'Accept':'*/*'}
    args.data = {'foo': 'bar baz'}
    args.json = False
    args.form = False
    args.files = None
    args.multipart = False
    args.multipart_data = []
    args.boundary = None
    args.auth = None
    args.timeout = None
    args.session = None
    args.session_read_only = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.json = False
    args.form = False
    args.debug = False

# Generated at 2022-06-21 13:35:58.608867
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': 'POST',
        'url': 'http://localhost',
        'headers': {'Content-Type': 'application/json', 'Accept': 'application/json, */*;q=0.5'},
        'data': '{"key":"value"}',
        'auth': None,
        'params': [],
    }
    try:
        dump_request(kwargs)
    except:
        pass
    assert True


# Generated at 2022-06-21 13:36:05.122281
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class Args:
        def __init__(self):
            self.proxy = []
            self.verify = True
            self.cert = 'cert'
            self.cert_key = 'cert_key'

    args = Args()
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {}, 'stream': True, 'verify': True, 'cert': ('cert', 'cert_key')}


# Generated at 2022-06-21 13:37:13.814094
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    # Without any argument
    default_headers = make_default_headers(args)
    assert default_headers.__eq__({"User-Agent": DEFAULT_UA})
    assert type(default_headers) == RequestHeadersDict

    args.json = True
    args.data = True
    default_headers = make_default_headers(args)
    assert default_headers.__eq__(
        {
            "User-Agent": DEFAULT_UA,
            "Accept": JSON_ACCEPT,
            "Content-Type": JSON_CONTENT_TYPE
        })

    args.data = False
    default_headers = make_default_headers(args)

# Generated at 2022-06-21 13:37:22.348205
# Unit test for function dump_request

# Generated at 2022-06-21 13:37:33.253445
# Unit test for function make_default_headers
def test_make_default_headers():
    """Testing function make_default_headers."""
    args = argparse.Namespace
    args.headers = {'Accept': 'text/html'}
    args.json = True
    args.form = False
    args.data = {'id': 1}
    default_headers = make_default_headers(args)
    assert default_headers == {'Accept': 'application/json', 'Content-Type': 'application/json','User-Agent': 'HTTPie/1.0.2'}
    assert args.headers == {'Accept': 'text/html'}
    args.json = False
    args.form = True
    default_headers = make_default_headers(args)

# Generated at 2022-06-21 13:37:43.937175
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    r = requests.Request(**make_request_kwargs(argparse.Namespace(
        method='GET',
        url='http://localhost/',
        headers='content-type:application/json'
    )))
    assert r.headers['Content-Type'] == 'application/json'
    assert r.method == 'get'
    assert r.url == 'http://localhost/'
    assert r.headers['User-Agent'] == DEFAULT_UA
    assert r.headers['Accept'] == JSON_ACCEPT
    assert r.headers['Content-Type'] == JSON_CONTENT_TYPE

    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:37:46.103269
# Unit test for function max_headers
def test_max_headers():
    try:
        with max_headers(100):
            pass
    except:
        return False
    else:
        return True



# Generated at 2022-06-21 13:37:47.434873
# Unit test for function dump_request
def test_dump_request():
    dump_request({'headers': {}})

# Generated at 2022-06-21 13:37:57.342832
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    # Test some random URL with a query string
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    # Test some random URL with a path
    assert ensure_path_as_is('http://foo/asdf', 'http://foo/12345') == 'http://foo/asdf'
    # Test some random URL with a path and query string
    assert ensure_path_as_is('http://foo/asdf', 'http://foo/12345?foo=bar') == 'http://foo/asdf?foo=bar'

# Generated at 2022-06-21 13:38:02.748687
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    arg_test = argparse.Namespace()
    arg_test.timeout = None
    arg_test.allow_redirects = False
    arg_test.debug = False
    arg_test.offline = False

    kwargs = make_send_kwargs(arg_test)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False



# Generated at 2022-06-21 13:38:05.454908
# Unit test for function dump_request
def test_dump_request():
    print("Testing dump_request()")
    kwargs = {"headers": {'key1': 'val1'}, "name": "test"}
    dump_request(kwargs)



# Generated at 2022-06-21 13:38:13.090077
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    """Test function ensure_path_as_is."""
    import pytest