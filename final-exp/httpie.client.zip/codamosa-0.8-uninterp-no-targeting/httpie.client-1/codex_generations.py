

# Generated at 2022-06-21 13:29:59.526083
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'POST'
    args.url = 'https://localhost:8000/'
    args.headers = {'Accept':'abc', 'Content-Type':'efg'}
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'POST'
    assert kwargs['url'] == 'https://localhost:8000/'
    assert len(kwargs['headers']) == 2
    assert kwargs['headers']['Accept'] is 'abc'
    assert kwargs['headers']['Content-Type'] is 'efg'

# Generated at 2022-06-21 13:30:10.978768
# Unit test for function dump_request

# Generated at 2022-06-21 13:30:22.019741
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli.parser import get_parser
    from httpie.context import Environment
    config_dir = Path('/User/li/.config/httpie')
    args = get_parser().parse_args([])
    silent = True
    env = Environment
    env.config_dir = config_dir
    env.config = None
    env.default_options = args
    env.colors = None
    env.stdout_isatty = not silent
    env.stdin_isatty = not silent
    env.is_windows = sys.platform.startswith('win')
    env.is_a_tty = env.stdout_isatty or env.stdin_isatty
    env.output_encoding = 'utf8'
    env.key_file = None
    env.cert_file = None

# Generated at 2022-06-21 13:30:29.722955
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        requests_session = requests.Session()
        https_adapter = HTTPieHTTPSAdapter(
            ciphers=None,
            verify=True,
            ssl_version=None,
        )
        requests_session.mount('https://', https_adapter)
        requests_session.verify = True
        requests_session.ciphers = None
        requests_session.ssl_version = None
    except Exception as e:
        print(e)
    assert requests_session.verify, "build_requests_session test 1 fail"
    assert requests_session.ciphers, "build_requests_session test 2 fail"
    assert requests_session.ssl_version, "build_requests_session test 3 fail"


# Generated at 2022-06-21 13:30:34.043510
# Unit test for function collect_messages
def test_collect_messages():
    args= argparse.Namespace()
    config_dir=Path()
    result=collect_messages(args, config_dir)
    #print(result)
    assert type(result) == Iterable[Union[requests.PreparedRequest, requests.Response]]



# Generated at 2022-06-21 13:30:38.828142
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = True
    args.proxy = []
    assert {'proxies': {}, 'stream': True, 'verify': True, 'cert': None} == make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-21 13:30:49.358133
# Unit test for function collect_messages
def test_collect_messages():
    import argparse

# Generated at 2022-06-21 13:30:51.049853
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Accept-Encoding': ' gzip, deflate '}
    final_headers = finalize_headers(headers)
    assert(final_headers.get('Accept-Encoding') == 'gzip,deflate')


# Generated at 2022-06-21 13:30:52.087225
# Unit test for function dump_request
def test_dump_request():
	kwargs = make_request_kwargs(args)
	dump_request(kwargs)

# Generated at 2022-06-21 13:30:54.773654
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(argparse.Namespace(timeout=2.4)) == dict(timeout=2.4, allow_redirects=False)
    assert make_send_kwargs(argparse.Namespace()) == dict(timeout=None, allow_redirects=False)


# Generated at 2022-06-21 13:31:23.063293
# Unit test for function collect_messages
def test_collect_messages():
    request_args = argparse.Namespace()

    request_args.method = "GET"
    request_args.url = "http://127.0.0.1:8888"
    request_args.headers = {"Content-Type": "application/json"}
    request_args.params = {}
    request_args.auth = None
    request_args.body = None
    request_args.max_headers = None
    request_args.form = False

    config_dir = Path('/')
    for x in collect_messages(request_args, config_dir):
        print(x)



# Generated at 2022-06-21 13:31:29.144387
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import json
    class Args:
        def __init__(self):
            self.timeout = None
            self.allow_redirects = False
    args = Args()
    kwargs = make_send_kwargs(args)
    assert json.dumps(kwargs) == '{"timeout": null, "allow_redirects": false}'

# Generated at 2022-06-21 13:31:33.742454
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers('json') == {
                'User-Agent': DEFAULT_UA,
                'Accept': JSON_ACCEPT,
                'Content-Type': JSON_CONTENT_TYPE,
            }
    assert make_default_headers('form') == {
                'User-Agent': DEFAULT_UA,
                'Content-Type': FORM_CONTENT_TYPE,
            }

# Generated at 2022-06-21 13:31:46.387429
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Create args object
    args = argparse.Namespace()
    args.method = 'POST'
    args.url = 'http://some_url'
    args.auth = ('user', 'pass')
    args.params = {}
    args.headers = {'h1': 'v1',
                    'h2': 'v2'}
    args.files = None
    args.json = False
    args.data = {}
    args.form = False
    args.multipart = False
    args.multipart_data = None
    args.insecure = False
    args.session = None
    args.session_read_only = None
    args.auth_plugin = None
    args.max_time = None
    args.timeout = None
    args.max_redirects = None
    args.max_headers

# Generated at 2022-06-21 13:31:57.027860
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.files = False
    args.data = None

    result = make_default_headers(args)
    assert result == {'User-Agent': DEFAULT_UA}

    args.json = True
    result = make_default_headers(args)
    assert result == {
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    }

    args.json = False
    args.form = True
    result = make_default_headers(args)
    assert result == {
        'User-Agent': DEFAULT_UA,
        'Content-Type': FORM_CONTENT_TYPE
    }

    args.data = dict()
    args

# Generated at 2022-06-21 13:32:01.568812
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()

    # base_headers
    args.headers = dict()
    base_headers = RequestHeadersDict({
        'User-Agent': 'this is base head'
    })
    request_kwargs = make_request_kwargs(args, base_headers)
    assert 'User-Agent' in request_kwargs['headers']
    assert 'this is base head' == request_kwargs['headers']['User-Agent']

    # parse "key : value"
    args.headers = dict()
    args.headers['key' + '  ' + ' : ' + '  ' + 'value'] = ''
    request_kwargs = make_request_kwargs(args, base_headers=None)
    assert 'key' in request_kwargs['headers']
    assert 'value' == request_kw

# Generated at 2022-06-21 13:32:04.163163
# Unit test for function max_headers
def test_max_headers():
    with max_headers(3):
        assert http.client._MAXHEADERS == 3

    assert http.client._MAXHEADERS == 100

    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')

    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-21 13:32:07.962368
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import argparse
    args = argparse.Namespace(proxy=[], verify=True, cert=None, cert_key=None)
    assert make_send_kwargs_mergeable_from_env(args)["verify"]

# Generated at 2022-06-21 13:32:16.703820
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    p = argparse.ArgumentParser()
    p.add_argument('verify', action='store')
    args = p.parse_args(['yes'])
    result = make_send_kwargs_mergeable_from_env(args)
    assert result['verify'] == True
    args = p.parse_args(['true'])
    result = make_send_kwargs_mergeable_from_env(args)
    assert result['verify'] == True
    args = p.parse_args(['false'])
    result = make_send_kwargs_mergeable_from_env(args)
    assert result['verify'] == False
    args = p.parse_args(['no'])
    result = make_send_kwargs_mergeable_from_env(args)
    assert result

# Generated at 2022-06-21 13:32:20.272100
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(ssl_version=None, ciphers=None, verify=True)
    assert isinstance(requests_session, requests.Session)


# Generated at 2022-06-21 13:33:26.038484
# Unit test for function finalize_headers
def test_finalize_headers():

    headers = {
        'User-Agent': 'HTTPie/1.0.2',
        'Accept': 'application/json, */*;q=0.5',
        'Content-Type': 'application/json',
        'Test-header': '  test123  '
    }
    final_headers = finalize_headers(header)
    assert final_headers == headers

# Generated at 2022-06-21 13:33:28.721946
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:33:32.491651
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    ssl_version = None
    ciphers = 'TLS13-AES-128-GCM-SHA256:TLS13-CHACHA20-POLY1305-SHA256'
    test_session = build_requests_session(verify=verify, ssl_version=ssl_version, ciphers=ciphers)
    return test_session


# Generated at 2022-06-21 13:33:40.365673
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    """
    >>> ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')
    'http://foo/../?foo=bar'
    >>> ensure_path_as_is('http://foo/bar', 'http://foo/?foo=bar')
    'http://foo/bar?foo=bar'
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 13:33:45.485618
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'cert': ('/path/client.cert', '/path/client.key'),
              'data': '',
              'files': None,
              'headers': {'Content-Length': '0'},
              'method': 'GET',
              'proxies': {},
              'stream': True,
              'url': 'http://example.com',
              'verify': False}

    assert dump_request(kwargs)

# Generated at 2022-06-21 13:33:52.398140
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "get"
    args.url = "www.baidu.com"
    args.headers = {"content-type": "application/json"}
    args.data = {"name": "fang"}
    args.auth = None
    args.params = {"name": "fang"}
    args.json = True
    args.form = False
    args.files = None
    args.max_redirects = 2
    args.max_headers = None
    args.timeout = None
    args.compress = True
    args.follow = True
    args.session = 'session'
    args.debug = True
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.ssl_version = None
    args.ch

# Generated at 2022-06-21 13:33:53.408486
# Unit test for function dump_request
def test_dump_request():
    dump_request({'key': 'value'})

# Generated at 2022-06-21 13:34:04.761954
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        form=False,
        json=True,
        files=False,
    )
    headers = make_default_headers(args)
    assert headers['Content-Type']==JSON_CONTENT_TYPE
    args = argparse.Namespace(
        data={"a":"b"},
        form=False,
        json=False,
        files=False,
    )
    headers = make_default_headers(args)
    assert headers['Content-Type']==JSON_CONTENT_TYPE
    args = argparse.Namespace(
        data={"a":"b"},
        form=True,
        json=False,
        files=False,
    )
    headers = make_default_headers(args)
    assert headers['Content-Type']==FORM_CONTENT_

# Generated at 2022-06-21 13:34:09.210802
# Unit test for function finalize_headers
def test_finalize_headers():
    input = RequestHeadersDict({"Content-Type": "application/json"})
    expected_output = RequestHeadersDict({'Content-Type': 'application/json'})

    output = finalize_headers(input)

    assert output == expected_output



# Generated at 2022-06-21 13:34:12.940645
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'User-Agent': '{{user-agent}}', 'Accept': '{{accept}}'}
    result = finalize_headers(headers)
    assert result['User-Agent'] == '{{user-agent}}'
    assert result['Accept'] == '{{accept}}'

# Generated at 2022-06-21 13:35:13.435116
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "get"
    args.url = "http://www.baidu.com"
    args.auth = ""
    args.params = ""
    args.headers = {}
    args.chunked = False
    args.data = []
    print(make_request_kwargs(args))


# Generated at 2022-06-21 13:35:16.197362
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({'User-Agent': ' httpie/1.0.2 '}) == {
        'User-Agent': b' httpie/1.0.2 '
    }

# Generated at 2022-06-21 13:35:19.995392
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    kwargs = make_send_kwargs(args)
    if not (kwargs['timeout'] is None):
        exit(1)
    if not (kwargs['allow_redirects'] is False):
        exit(1)
    if (len(kwargs) != 2):
        exit(1)


# Generated at 2022-06-21 13:35:21.536413
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        pass

# Generated at 2022-06-21 13:35:26.778264
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    parsed_orig_url = urlparse('http://foo/../')
    parsed_prepped_url = urlparse('http://foo/?foo=bar')
    expected_url = 'http://foo/../?foo=bar'

    resulted_url = ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')

    assert resulted_url == expected_url

# Generated at 2022-06-21 13:35:29.493388
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(verify=True,ssl_version=None,ciphers=None)
    assert isinstance(requests_session,requests.Session)

# Generated at 2022-06-21 13:35:33.628348
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(data=None,
                              form=None,
                              json=None,
                              files=None,
                              headers=RequestHeadersDict())
    default_headers = make_default_headers(args)
    assert default_headers == RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })

# Generated at 2022-06-21 13:35:42.590109
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class Args:
        def __init__(self, proxy_str, verify_str, cert, cert_key):
            self.proxy = proxy_str
            self.verify = verify_str
            self.cert = cert
            self.cert_key = cert_key
    
    args = Args(['http://localhost:8080'], 'true', '../.pem', '../.pem')
    expected_kwargs = {
        'proxies': {'http': 'http://localhost:8080'},
        'stream': True,
        'verify': True,
        'cert': ('../.pem', '../.pem')
    }

    assert expected_kwargs == make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-21 13:35:44.661654
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=False, ssl_version = None, ciphers = None)
    print(session)

# Generated at 2022-06-21 13:35:47.315263
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    test_args = argparse.Namespace()

    result_kwargs = make_send_kwargs(test_args)

    assert result_kwargs == {
        "allow_redirects": False,
        "timeout": None
    }

# Generated at 2022-06-21 13:37:25.348865
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # TODO: Please write unit test for function make_send_kwargs_mergeable_from_env

    assert False



# Generated at 2022-06-21 13:37:30.372147
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = 'yes'
    args.form = 'yes'
    args.data = 'yes'
    assert make_default_headers(args) == RequestHeadersDict({'User-Agent': 'HTTPie/{}'.format(__version__),
                                                             'Accept': 'application/json, */*;q=0.5',
                                                             'Content-Type': 'application/json'})

    args = argparse.Namespace()
    args.form = 'yes'
    args.data = 'yes'

# Generated at 2022-06-21 13:37:35.125550
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout='12', allow_redirects=False)
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': '12', 'allow_redirects': False}

# Generated at 2022-06-21 13:37:45.264852
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = True
    args.proxy = [
        argparse.Namespace(key='http', value='myproxy.com'),
        argparse.Namespace(key='https', value='myproxy.com:8080')
    ]
    args.cert = 'client.pem'
    args.cert_key = 'client.key'

    merged_kwargs = make_send_kwargs_mergeable_from_env(args)
    assert ('verify' in merged_kwargs) is True
    assert ('proxies' in merged_kwargs) is True
    assert ('stream' in merged_kwargs) is True
    assert ('cert' in merged_kwargs) is True

# Generated at 2022-06-21 13:37:51.096995
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(argparse.Namespace(timeout=None, follow=False)) == {'timeout': None, 'allow_redirects': False}
    assert make_send_kwargs(argparse.Namespace(timeout=12, follow=False)) == {'timeout': 12, 'allow_redirects': False}


# Generated at 2022-06-21 13:37:54.457145
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Content-Type': 'json'}
    final_headers = finalize_headers(headers)
    if final_headers['Content-Type'] == 'json':
        return True
    else:
        return False

# Generated at 2022-06-21 13:37:59.268552
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Formating the data
    args = argparse.Namespace()
    args.verify = 'false'
    args.proxy = [
        argparse.Namespace(
            key="https",
            value="10.10.10.121:443"
        ),
        argparse.Namespace(
            key="http",
            value="10.10.10.121:80"
        )
    ]
    args.cert = 'client.pem'
    args.cert_key = 'client.key'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    # Verifying the data
    if kwargs['proxies']['https'] != "10.10.10.121:443" :
        raise AssertionError()

# Generated at 2022-06-21 13:38:02.322495
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

test_ensure_path_as_is()

# Generated at 2022-06-21 13:38:07.939279
# Unit test for function dump_request
def test_dump_request():
    args = {'headers': {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0'},
            'method': 'GET',
            'url': 'https://httpie.org',
            'auth': 'admin:admin',
            'timeout': None,
            'allow_redirects': False}
    dump_request(kwargs=args)

# Generated at 2022-06-21 13:38:09.823352
# Unit test for function max_headers
def test_max_headers():
    limit = 20
    with max_headers(limit):
        assert http.client._MAXHEADERS == limit
    assert http.client._MAXHEADERS == dict