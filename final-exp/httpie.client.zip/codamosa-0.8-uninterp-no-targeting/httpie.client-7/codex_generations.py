

# Generated at 2022-06-21 13:30:30.137209
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': '  HTTPie/0.9.9',
        'Host': 'httpbin.org',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': '*/*',
        'Connection': 'keep-alive',
        'Content-Length': '9',
    })
    headers_expected = RequestHeadersDict({
        'User-Agent': 'HTTPie/0.9.9',
        'Host': 'httpbin.org',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': b'*/*',
        'Connection': 'keep-alive',
        'Content-Length': '9',
    })
    headers = finalize_headers(headers)
    assert headers == headers_expected

# Generated at 2022-06-21 13:30:42.381085
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:30:48.904574
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    result = make_request_kwargs()
    assert repr(result) == repr({})
    result = make_request_kwargs(args=None)
    assert repr(result) == repr({})
    result = make_request_kwargs(args=None, base_headers=None)
    assert repr(result) == repr({})
    result = make_request_kwargs(args=None, base_headers=None, request_body_read_callback=None)
    assert repr(result) == repr({})


# Generated at 2022-06-21 13:30:53.357054
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class Args:
        data = None
        form = True
        json = False
        files = False
        headers = None
        verify = 'yes'
        cert = None
        cert_key = None
        proxy = None
        proxy_auth = None
        chunked = False
        offline = False
        timeout = None
        multipart = False
        multipart_data = None
        boundary = None
        auth = None
        auth_plugin = None
        session_read_only = None
        session = None
        path_as_is = None
        debug = True
        follow = None
        all = None
        max_redirects = None
        max_headers = None
        method = 'GET'
        url = 'http://www.baidu.com'

    args = Args()

    kwargs = make_

# Generated at 2022-06-21 13:31:06.129255
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:31:10.656187
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'User-Agent': 'HTTPie', 'Accept': 'application/json'}
    final_headers = RequestHeadersDict({
        'User-Agent': 'HTTPie',
        'Accept': 'application/json'
    })
    assert finalize_headers(headers) == final_headers

# Generated at 2022-06-21 13:31:13.502997
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    orig = 'http://foo/bar/../'
    prep = 'http://foo/?foo=bar'
    assert ensure_path_as_is(orig, prep) == 'http://foo/bar/../?foo=bar'



# Generated at 2022-06-21 13:31:16.761526
# Unit test for function max_headers
def test_max_headers():
    client._MAXHEADERS = 100
    with max_headers(limit = 500):
        assert http.client._MAXHEADERS == 500
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-21 13:31:17.647634
# Unit test for function collect_messages
def test_collect_messages():
    pass

# Generated at 2022-06-21 13:31:21.047132
# Unit test for function max_headers
def test_max_headers():
    import builtins
    import http.client
    with max_headers(8):
        assert http.client._MAXHEADERS == 8
    assert http.client._MAXHEADERS == builtins.MAX_HEADERS

# Generated at 2022-06-21 13:31:48.962347
# Unit test for function collect_messages
def test_collect_messages():
    args = make_request_kwargs({
        'method': 'post',
        'url': 'http://localhost:4100/login',
        'headers': {},
        'data': {
          "name": "morpheus",
          "job": "leader"
        },
        'auth': None,
        'params': {},
    })
    config_dir = Path('C:/Users/kimta/.httpie')
    res = collect_messages(args, config_dir)
    print(res)
    next(res)


if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-21 13:31:57.152071
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    # test for case with no query params
    result = ensure_path_as_is('http://foo/../', 'http://foo/')
    assert result == 'http://foo/..'

    # test for case with query params
    result = ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')
    assert result == 'http://foo/../?foo=bar'

    # test for case with multiple query params
    result = ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar&name=nik')
    assert result == 'http://foo/../?foo=bar&name=nik'

# Generated at 2022-06-21 13:31:58.110470
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100) as mh:
        assert mh == 100



# Generated at 2022-06-21 13:32:05.631152
# Unit test for function dump_request
def test_dump_request():
    import pytest
    from httpie.cli import parser

    dump_args = ('GET --headers "Accept: application/json" '
                 'https://httpbin.org/get').split()
    dump_args = parser.parse_args(dump_args)
    dump_request(make_request_kwargs(dump_args))
    with pytest.raises(SystemExit):
        dump_request(Exception('Error'))

# Generated at 2022-06-21 13:32:11.694528
# Unit test for function make_default_headers
def test_make_default_headers():
    headers = {'accept': 'application/json', 'content-type': 'application/json'}
    assert(make_default_headers(headers)['Accept'] == 'application/json, */*;q=0.5')
    assert(make_default_headers(headers)['Content-Type'] == 'application/json')
    headers = {'accept': 'application/xml', 'content-type': 'application/xml'}
    assert(make_default_headers(headers)['Accept'] == 'application/json, */*;q=0.5')
    assert(make_default_headers(headers)['Content-Type'] == 'application/x-www-form-urlencoded; charset=utf-8')

# Generated at 2022-06-21 13:32:18.534213
# Unit test for function dump_request
def test_dump_request():
    url = 'http://google.com'
    headers = [('User-Agent', 'Mozilla/5.0'), ('Accept', 'application/json')]
    data = b'{"name": "John"}'
    kwargs = {'method': 'POST', 'url': url, 'headers': {}, 'data': data}
    kwargs['headers'].update(headers)
    dump_request(kwargs)

# Generated at 2022-06-21 13:32:20.738163
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({'foo': ' bar '}) == {'foo': 'bar'}

# Generated at 2022-06-21 13:32:31.624682
# Unit test for function max_headers
def test_max_headers():
    from httpie import input
    from httpie.compat import is_py26
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.context import Environment
    from httpie.plugins.manager import PluginManager
    from httpie.output.streams import get_default_output_stream

    # Creates an Environment instance
    env = Environment()
    # Initializes the plugin manager
    plugin_manager_instance = PluginManager()

    global args

# Generated at 2022-06-21 13:32:42.566666
# Unit test for function max_headers
def test_max_headers():
    limit = 1
    headers = {'a': 'a', 'b': 'b', 'c': 'c'}
    old_max_headers = http.client._MAXHEADERS
    assert http.client._MAXHEADERS >= limit
    with max_headers(limit):
        assert http.client._MAXHEADERS == limit
        req = requests.Request('GET', url='http://foo.com/', headers=headers)
        preq = requests.Request('GET', url='http://foo.com/', headers=headers).prepare()
        with pytest.raises(requests.exceptions.InvalidHeader) as excinfo:
            requests.Session().send(preq)
        assert 'Exceeded the maximum number' in str(excinfo.value)
        assert excinfo.value.response is None
    assert http.client._MAXHEADERS

# Generated at 2022-06-21 13:32:49.813981
# Unit test for function max_headers
def test_max_headers():
    """
    Test the function max_headers if it is working properly
    """
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000
    with max_headers(1):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == 1
    with max_headers(2000):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == 2000
    try:
        with max_headers(-1):
            pass
    except:
        with max_headers(0):
            # noinspection PyProtectedMember
            assert http.client._MAXHEADERS == float('Inf')
    finally:
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-21 13:33:30.822365
# Unit test for function finalize_headers
def test_finalize_headers():
    header_dict = RequestHeadersDict()
    header_dict['Host'] = 'www.example.com'
    header_dict['Accept'] = 'text/html'
    final_header_dict = finalize_headers(header_dict)
    assert len(header_dict) == 2
    assert final_header_dict['Host'] == 'www.example.com'
    assert final_header_dict['Accept'] == 'text/html'

# Generated at 2022-06-21 13:33:39.243173
# Unit test for function collect_messages
def test_collect_messages():
    request_kwargs = {'method': 'GET', 'url': 'https://httpie.org', 'headers': {'User-Agent': 'HTTPie/1.0.3', 'Accept': 'application/json, */*;q=0.5'}, 'data': b'', 'auth': None, 'params': [('a', 'b')]}
    send_kwargs = {'timeout': None, 'allow_redirects': False}
    send_kwargs_mergeable_from_env = {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    requests_session = build_requests_session(True, None, None)
    httpie_session = get_httpie_session(None, None, None, None)

# Generated at 2022-06-21 13:33:41.339155
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args={'timeout': 1, 'allow_redirects': False}
    assert make_send_kwargs(args)==args

# Generated at 2022-06-21 13:33:44.035008
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    default_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    default_headers['Accept'] = JSON_ACCEPT
    assert make_default_headers(args) == default_headers

# Generated at 2022-06-21 13:33:47.286048
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli import parser
    args = parser.parse_args([])
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }

# Generated at 2022-06-21 13:33:52.131982
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = True

    request_kwargs = make_send_kwargs_mergeable_from_env(args)
    assert isinstance(request_kwargs,dict),'Function must return dictionary'
    assert set(request_kwargs.keys()).issubset(set(['proxies', 'stream', 'verify', 'cert'])),'Request kwargs keys must be a subset of the following set: {}'.format(set(['proxies', 'stream', 'verify', 'cert']))


# Generated at 2022-06-21 13:33:58.536395
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.headers = {'User-Agent': DEFAULT_UA}
    args.url = 'http://foo/../'
    config_dir = Path()
    result = collect_messages(args=args, config_dir=config_dir)
    assert result == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:33:59.568861
# Unit test for function max_headers
def test_max_headers():
    assert max_headers


# Generated at 2022-06-21 13:34:04.784718
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # import inspect
    # print(inspect.getclosurevars(make_send_kwargs))

    # argfile = 
    # args = parse_args(['--verify=false', '--argfile='])
    # test_args = argparse.Namespace(verify = 'no')

    print('test_make_send_kwargs')
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(verify='false')
    assert send_kwargs_mergeable_from_env['verify'] == False, "Error : verify value is wrong"



# Generated at 2022-06-21 13:34:14.829986
# Unit test for function collect_messages
def test_collect_messages():
    import argparse

# Generated at 2022-06-21 13:35:43.453251
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json=True
    args.form=True
    args.data=True
    headers = make_default_headers(args)
    assert 'Accept' in headers
    assert 'Content-Type' in headers
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == FORM_CONTENT_TYPE


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 13:35:51.010834
# Unit test for function dump_request
def test_dump_request():
    test_dict = {
        'method': 'GET',
        'url': 'http://foo.bar/',
        'data': '',
        'headers': {'Test': 'value'},
        'cookies': '',
        'auth': '',
        'params': '',
        'files': '',
        'verify': '',
        'cert': '',
        'timeout': '',
        'redirect': '',
        'allow_redirects': '',
        'proxies': '',
        'hooks': '',
        'stream': '',
        'verify': '',
        'cert': '',
        'json': '',
    }

    dump_request(test_dict)



# Generated at 2022-06-21 13:35:53.605482
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie.cli import parser

    args = parser.parse_args(['GET', 'http://localhost'])
    print(args)
    kwargs = make_request_kwargs(args)
    print(kwargs)

# Generated at 2022-06-21 13:35:56.341625
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False
    }


# Generated at 2022-06-21 13:35:57.311549
# Unit test for function dump_request
def test_dump_request():
    d={"hello":1, "world":9}
    dump_request(d)

# Generated at 2022-06-21 13:36:07.798133
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli import parser
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.input import AuthCredentials
    from httpie.compat import str

    parser_args = parser.parse_args(['GET', 'http://localhost:8000/'])
    auth_plugin = HTTPBasicAuth()
    auth_plugin.raw_auth = AuthCredentials('foo', 'bar')
    parser_args.auth_plugin = auth_plugin
    parser_args.offline = True
    parser_args.chunked = False
    parser_args.compress = 0
    parser_args.form = False
    parser_args.json = False
    parser_args.multipart = False
    parser_args.pretty = False
    parser_args.session = None
    parser_args.session_read_

# Generated at 2022-06-21 13:36:15.481023
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    def set_args(value, key = 'verify'):
        if key == 'timeout':
            value = int(value)
        if key == 'cert':
            if ':' in value:
                value = tuple(value.split(':'))
        setattr(args, key, value)


# Generated at 2022-06-21 13:36:23.793446
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    url_1 = 'http://foo/bar'
    url_2 = 'http://foo/../bar'
    url_3 = 'http://foo/%2E%2E/bar'

    assert(ensure_path_as_is(url_1, 'http://foo/?foo=bar') == 'http://foo/bar?foo=bar')
    assert(ensure_path_as_is(url_2, 'http://foo/?foo=bar') == 'http://foo/../bar?foo=bar')
    assert(ensure_path_as_is(url_3, 'http://foo/?foo=bar') == 'http://foo/%2E%2E/bar?foo=bar')

# Generated at 2022-06-21 13:36:33.737619
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.json = True
    args.data = {"hello":"world"}
    args.headers = RequestHeadersDict({"Content-Type":"application/json"})
    res = make_request_kwargs(args)
    assert res == {
        'method': 'get',
        'url': None,
        'headers': RequestHeadersDict({
            'Content-Type': 'application/json', 
            'Accept': 'application/json, */*;q=0.5', 
            'User-Agent': 'HTTPie/1.1.3'}),
        'data': '{\n    "hello": "world"\n}',
        'auth': None,
        'params': []}
    args = argparse.Namespace()
    args.json = False
    args

# Generated at 2022-06-21 13:36:36.861075
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace(auth=None, auth_plugin=None, chunked=False,
                              headers={}, json=None, method='GET')
    config_dir = Path('.')
    collect_messages(args, config_dir)

