

# Generated at 2022-06-21 13:29:52.248709
# Unit test for function collect_messages
def test_collect_messages():
    import requests
    args = argparse.Namespace()
    args.url = 'https://www.google.com'
    args.method = 'GET'

    config_dir = ''

    request_body_read_callback = None
    result = collect_messages(args, config_dir, request_body_read_callback)
    assert isinstance(result, Iterable)

# Generated at 2022-06-21 13:29:57.015736
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 1000
    assert(http.client._MAXHEADERS == 1000)
    with max_headers(None):
        assert(http.client._MAXHEADERS == float('Inf'))
    assert(http.client._MAXHEADERS == 1000)
    with max_headers(500):
        assert(http.client._MAXHEADERS == 500)
    assert(http.client._MAXHEADERS == 1000)

# Generated at 2022-06-21 13:30:07.942274
# Unit test for function finalize_headers
def test_finalize_headers():
    assert (finalize_headers(RequestHeadersDict([('ACCEPT', 'json')])) ==
            RequestHeadersDict(Accept='json'))
    assert (finalize_headers(RequestHeadersDict([('accept', 'json')])) ==
            RequestHeadersDict(Accept='json'))
    assert (finalize_headers(RequestHeadersDict([('accept', 'JSON')])) ==
            RequestHeadersDict(Accept='JSON'))
    assert (finalize_headers(RequestHeadersDict([('accept', '*/*')])) ==
            RequestHeadersDict(Accept='*/*'))

# Generated at 2022-06-21 13:30:19.805190
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import urllib3
    urllib3.disable_warnings()
    from httpie.core import main
    from httpie import ExitStatus
    from tests.httpie.test_core import http, httpbin
    args = main.parser.parse_args([
        '--timeout=5', '--verify=false',
        '--proxy', 'http://10.10.1.10:3128',
        '--proxy', 'https://10.10.1.10:1080',
        '--cert', 'client.crt',
        '--cert-key', 'client.key',
        'GET',
        httpbin() + '/get'
    ])
    args.headers = {}
    args.ignore_stdin = True
    args.auth_plugin = None
    args.session = None
    args.session_read

# Generated at 2022-06-21 13:30:23.571062
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=True)
    assert type(session) == requests.Session
    session = build_requests_session(ssl_version='TLSv1.3')
    assert type(session) == requests.Session
    session = build_requests_session(ciphers='AES256-SHA')
    assert type(session) == requests.Session

# Generated at 2022-06-21 13:30:27.476714
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env('yes') == True
    assert make_send_kwargs_mergeable_from_env('true') == True
    assert make_send_kwargs_mergeable_from_env('no') == False
    assert make_send_kwargs_mergeable_from_env('false') == False
    assert make_send_kwargs_mergeable_from_env('random') == 'random'

# Generated at 2022-06-21 13:30:39.429536
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import argparse
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('--timeout', help='timeout value')
    arg_parser.add_argument('--allow-redirects', help='allow redirects')
    args_values = [
        ['--timeout', '60'],
        ['--allow-redirects', 'True'],
        ['--allow-redirects', 'False'],
        ['--allow-redirects', '1'],
        ['--allow-redirects', '0']
    ]
    for args_value in args_values:
        args = arg_parser.parse_args(args_value)
        kwargs = make_send_kwargs(args)

# Generated at 2022-06-21 13:30:49.129891
# Unit test for function finalize_headers
def test_finalize_headers():
    h = RequestHeadersDict({
        'Content-Type': ' application/json ',
        'Accept': ' text/html;q=0.5,*/*;q=0.1 ',
        'Leading-Space': ' is okay',
        'Defined': '',
        'Multi' : ['TEST VALUE', 'TEST VALUE']
    })
    expected = {
        'Content-Type': 'application/json',
        'Accept': 'text/html;q=0.5,*/*;q=0.1',
        'Leading-Space': 'is okay',
        'Defined': '',
        'Multi' : ['TEST VALUE', 'TEST VALUE']
    }
    assert finalize_headers(h) == expected

# Generated at 2022-06-21 13:30:56.000155
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:31:08.855244
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:31:32.778111
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    setattr(sys.modules[__name__], 'AVAILABLE_SSL_VERSION_ARG_MAPPING', {'TLS1': 'TLS1'})
    setattr(sys.modules[__name__], 'HTTPieHTTPSAdapter', lambda *args, **kwargs: None)
    setattr(sys.modules[__name__], 'plugin_manager', lambda: [])
    requests_session = build_requests_session(verify=verify)
    assert requests_session._adapters['https://']
    assert requests_session._adapters['https://'].kwargs['ssl_version'] == 'TLS1'
    assert requests_session._adapters['https://'].kwargs['verify']

    requests_session = build_requests_session(verify=False)
    assert requests

# Generated at 2022-06-21 13:31:36.582492
# Unit test for function max_headers
def test_max_headers():
    with max_headers(2):
        assert getattr(http.client, "_MAXHEADERS") == 2

# Below functions are unit tests except the function make_request_kwargs
# because function max_headers is the part of function make_request_kwargs

# Generated at 2022-06-21 13:31:39.878277
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'Accept': 'application/json'
    })

    assert finalize_headers(headers) == {'Accept': 'application/json'}

# Generated at 2022-06-21 13:31:45.796724
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    verify_value = 'true'
    cert_file = 'cert.pem'
    args = argparse.Namespace()
    args.verify = verify_value
    args.cert = cert_file
    send_kwargs = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs['verify'] == True

# Generated at 2022-06-21 13:31:47.982036
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(ssl_version='TLSv1')
    print(requests_session)

# Generated at 2022-06-21 13:31:48.666557
# Unit test for function build_requests_session
def test_build_requests_session():
    pass

# Generated at 2022-06-21 13:31:58.538572
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli.parser import get_parser
    from httpie.plugins.registry import plugin_manager

    parser = get_parser()
    args = parser.parse_args(['https://httpbin.org/headers'])
    httpie_plugins = plugin_manager.get_transport_plugins()
    args.auth_plugin = httpie_plugins[0]
    args.auth = tuple()
    args.headers = tuple()
    args.params = tuple()
    args.proxy = tuple()
    args.url = 'https://httpbin.org/headers'
    headers = {'Content-Type': 'application/json'}
    args.headers = headers
    args.cert = 'cert'

    req_kwargs = make_request_kwargs(args=args)

# Generated at 2022-06-21 13:32:06.225024
# Unit test for function dump_request
def test_dump_request():
    class argparse_namespace():
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    args = argparse_namespace(**{'method': 'GET', 'url': 'http://httpie.org/', 'headers': {'User-Agent': DEFAULT_UA}, 'data': '{"foo": "bar"}'})
    dump_request(make_request_kwargs(args))

# Generated at 2022-06-21 13:32:11.005725
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    import unittest
    class TestEnsurePathAsIs(unittest.TestCase):
        def test_path_as_is(self):
            self.assertEqual(ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar'), 'http://foo/../?foo=bar')

    unittest.main()

# Generated at 2022-06-21 13:32:14.613765
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(
        'http://foo/../',
        'http://foo/?foo=bar'
    ) == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:32:53.054042
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data = None,
        form = False,
        json = False
    )
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })

    args = argparse.Namespace(
        data = None,
        form = False,
        json = True
    )
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    })

    args = argparse.Namespace(
        data = {'name': 'anhtu'},
        form = False,
        json = False
    )

# Generated at 2022-06-21 13:33:01.688948
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    test_prepped_url = ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')
    assert test_prepped_url == 'http://foo/../?foo=bar', "Path should be /../"
    test_prepped_url = ensure_path_as_is('http://foo/../', 'http://foo/bar.html?foo=bar')
    assert test_prepped_url == 'http://foo/bar.html?foo=bar', "Path should be /bar.html"

# Generated at 2022-06-21 13:33:07.258582
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # With no arguments
    assert make_send_kwargs_mergeable_from_env({}) == {
        'proxies': {},
        'stream': True,
        'verify': 'yes',
        'cert': None,
    }

    # With arguments
    assert make_send_kwargs_mergeable_from_env({
        'proxy': [('http', 'foo.com:80')],
        'verify': 'no',
        'cert': 'cert',
        'cert_key': 'cert-key',
    }) == {
        'proxies': {'http': 'foo.com:80'},
        'stream': True,
        'verify': False,
        'cert': 'cert',
        'cert_key': 'cert-key',
    }

# Unit tests for function

# Generated at 2022-06-21 13:33:13.800180
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # example from https://httpie.org/doc#proxy
    args_proxy = argparse.Namespace(proxy=[argparse.Namespace(key='http', value="http://10.10.1.10:3128"),
                                           argparse.Namespace(key='https', value="http://10.10.1.10:1080")])
    assert make_send_kwargs_mergeable_from_env(args_proxy)['proxies'] == {'http': "http://10.10.1.10:3128",
                                                                          'https': "http://10.10.1.10:1080"}


# Generated at 2022-06-21 13:33:24.961635
# Unit test for function collect_messages
def test_collect_messages():
    # TODO: Test it with real and large file data
    args = argparse.Namespace()
    args.session = 1
    args.session_read_only = 2
    args.headers = {'Host': 'foo.com'}
    args.url = 'http://foo.com?foo=bar'
    args.debug = 1
    args.path_as_is = True
    args.compress = True
    args.offline = False
    args.max_redirects = 10
    args.follow = True
    args.all = True
    config_dir = Path(__file__).parent.parent.absolute()
    collect_messages(args, config_dir)

if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-21 13:33:32.283481
# Unit test for function dump_request
def test_dump_request():
    # set up object
    class args:
        def __init__(self):
            self.url = 'http://127.0.0.1:80'
            self.method = 'GET'
            self.headers = {}
            self.auth = None
            self.params = {}
            self.method = 'GET'
            self.data = 0
            self.debug = False
            self.json = False
            self.form = False
            self.files = False
            self.multipart = False
            self.multipart_data = None
            self.boundary = None
            self.chunked = False
            self.offline = False
            self.session = None
            self.session_read_only = None
            self.auth_plugin = None
            self.cert = None

# Generated at 2022-06-21 13:33:40.215076
# Unit test for function build_requests_session
def test_build_requests_session():
    from httpie.plugins.builtin import HTTPBasicAuth
    from requests.adapters import HTTPAdapter

    requests_session = build_requests_session(
        ssl_version=False,
        ciphers=False,
        verify=False
    )

    plugin_cls = plugin_manager.get_adapter_plugin(HTTPAdapter)
    plugin = plugin_cls()
    try:
        assert requests_session._adapters[plugin.prefix.lower()] == plugin.get_adapter()
    except KeyError:
        assert False, "Request adapter plugin not installed"

    plugin_cls = plugin_manager.get_auth_plugin(HTTPBasicAuth)
    plugin = plugin_cls()
    assert plugin.auth_type == "basic"
    assert plugin.raw_auth == ":password"

# Generated at 2022-06-21 13:33:49.087223
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:33:54.543674
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-21 13:33:59.619170
# Unit test for function finalize_headers
def test_finalize_headers():
    header_dict = {'Accept':'*/*', 'Content-Type':'application/json'}
    final_header_dict = finalize_headers(header_dict)
    assert final_header_dict['Accept'] == b'*/*'
    assert final_header_dict['Content-Type'] == b'application/json'

# Generated at 2022-06-21 13:34:53.837718
# Unit test for function max_headers
def test_max_headers():
    args_test = argparse.Namespace
    args_test = argparse.Namespace(max_headers = 10)
    args = argparse.Namespace(max_headers = None)
    max_headers(10)
    assert args_test.max_headers == args.max_headers

# Generated at 2022-06-21 13:35:00.047017
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.timeout = 30
    args.follow = True
    expected_kwargs = {
        'allow_redirects': False,
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
        'timeout': 30,
    }
    assert(make_send_kwargs_mergeable_from_env(args) == expected_kwargs)

# Generated at 2022-06-21 13:35:02.117670
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert 'http://foo/../?foo=bar' == ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')

# Generated at 2022-06-21 13:35:12.925696
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:35:21.214636
# Unit test for function finalize_headers
def test_finalize_headers():
    my_headers = {'Host':'localhost', 'User-Agent':"httpie/0.9.9", "Accept":"application/json, */*;q=0.5"}
    assert finalize_headers(my_headers) == {'Host':b'localhost', 'User-Agent':b'httpie/0.9.9', 'Accept':b'application/json, */*;q=0.5'}
    my_headers = {'Host':'localhost', 'User-Agent':"\t httpie/0.9.9 "}
    assert finalize_headers(my_headers) == {'Host':b'localhost', 'User-Agent':b'httpie/0.9.9'}

# Generated at 2022-06-21 13:35:30.420687
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:35:40.027385
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.auth = None
    args.boundary = None
    args.ciphers = None
    args.chunked = False
    args.compress = False
    args.cert = None
    args.cert_key = None
    args.data = None
    args.debug = False
    args.files = []
    args.form = False
    args.headers = {}
    args.json = None
    args.method = 'GET'
    args.multipart = False
    args.http2 = False
    args.multipart_data = None
    args.max_headers = float('inf')
    args.max_redirects = float('inf')
    args.offline = False
    args.params = {}
    args.path_as_is = False
   

# Generated at 2022-06-21 13:35:43.685680
# Unit test for function finalize_headers
def test_finalize_headers():
    headers_dict = {'Accept': 'text/html', 'Accept-Language': 'en-US,en;q=0.5'}
    final_headers_dict = finalize_headers(headers_dict)
    assert final_headers_dict['Accept'] == 'text/html'
    assert final_headers_dict['Accept-Language'] == 'en-US,en;q=0.5'

# Generated at 2022-06-21 13:35:51.689954
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    # Use default argument values
    args.chunked = False
    args.debug = False
    args.json = False
    args.method = 'GET'
    args.multipart = False
    args.offline = False
    args.path_as_is = False
    args.params = {}
    args.headers = {}
    args.session = None
    args.session_read_only = None
    args.ssl_version = 'best'
    args.timeout = None
    # Set this here
    args.url = 'http://www.google.com'

    # TODO: make the code independent of config_dir
    # This should be enough
    config_dir = Path('.')

    request_body

# Generated at 2022-06-21 13:35:53.403102
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {' Foo ': ' Bar '}
    expected = {'Foo': 'Bar'}
    assert finalize_headers(headers) == expected

# Generated at 2022-06-21 13:37:56.820178
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace
    args.timeout = 10
    args.allow_redirects = False
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['timeout'] == 10
    assert send_kwargs['allow_redirects'] == False

    cert = '/path/to/your/cert.pem'
    args.cert = cert
    args.cert_key = 'key/path.pem'
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['cert'] == (cert, 'key/path.pem')

# Generated at 2022-06-21 13:38:00.572733
# Unit test for function build_requests_session
def test_build_requests_session():
    request_session = build_requests_session(
        verify = True,
        ciphers = 'TLSv1.3',
        ssl_version = 'TLSv1.3'
    )
    assert request_session is not None



# Generated at 2022-06-21 13:38:09.823757
# Unit test for function make_default_headers
def test_make_default_headers():
    args1 = argparse.Namespace()
    args1.json = True
    args1.form = False
    args1.data = None
    args2 = argparse.Namespace()
    args2.json = False
    args2.data = True
    args2.files = argparse.Namespace()
    args2.files.items = []
    args2.files.filefields = []

    args3 = argparse.Namespace()
    args3.json = False
    args3.form = False
    args3.data = None
    args3.files = argparse.Namespace()
    args3.files.items = []
    args3.files.filefields = []

    assert make_default_headers(args1)['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in make_default_headers

# Generated at 2022-06-21 13:38:14.711054
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {
        'User-agent': ' httpie test/0.0.1',
        'Date ': ' 123456789',
        'Content-type ': ' test/1'
    }
    headers = finalize_headers(headers)
    assert headers['User-agent'] == b'httpie test/0.0.1'
    assert headers['Date'] == '123456789'
    assert headers['Content-type'] == 'test/1'

# Generated at 2022-06-21 13:38:22.765403
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "https://httpbin.org/get"
    args.json = "This is a json"
    args.data = json.dumps(args.json)
    args.form = "This is a form"
    args.files = "This is a file"
    args.multipart = "This is a multipart"
    args.method = "GET"
    args.headers = {"content_type":"text/plain"}
    args.offline = "false"
    args.chunked = "100"
    args.auth = "Basic"
    args.params = {"key": "val"}

    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == args.method
    assert kw

# Generated at 2022-06-21 13:38:26.445783
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=None, allow_redirects=False)
    test_kwargs = {'timeout': None, 'allow_redirects': False}
    assert make_send_kwargs(args) == test_kwargs



# Generated at 2022-06-21 13:38:29.849732
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    final_headers = make_default_headers(args)
    final_headers = final_headers["User-Agent"]
    assert final_headers == "HTTPie/0.9.9"

# Generated at 2022-06-21 13:38:37.898666
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'method': 'POST',
              'url': 'http://localhost:5000/api/v1/swagger.json',
              'headers': {'Header-A': 'Value A', 'Header-B': 'Value B'},
              'data': '{"key":"value"}'}
    assert dump_request(kwargs) \
        == '\n>>> requests.request(**{\'method\': \'POST\', ' \
           '\'url\': \'http://localhost:5000/api/v1/swagger.json\', ' \
           '\'headers\': {\'Header-A\': \'Value A\', \'Header-B\': \'Value B\'}, ' \
           '\'data\': \'{"key":"value"}\'})\n\n'

# Generated at 2022-06-21 13:38:40.042109
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:38:51.006987
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Do not try to use this function: it is just used for unit testing
    import argparse

    from httpie import __version__, _cli_builders

    parser = _cli_builders.create_parser(prog='')
    args = parser.parse_args(
        '--proxy=https://http:3128 https://httpbin.org/'.split())

    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['proxies'] == {'https': 'https://http:3128'}

    parser = _cli_builders.create_parser(prog='')
    args = parser.parse_args(
        '--verify=yes https://httpbin.org/'.split())

