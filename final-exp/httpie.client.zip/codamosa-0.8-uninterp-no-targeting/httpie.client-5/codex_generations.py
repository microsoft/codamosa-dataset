

# Generated at 2022-06-21 13:30:01.561141
# Unit test for function max_headers
def test_max_headers():
    import http.client
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-21 13:30:08.883127
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    default_headers = make_default_headers(args)
    assert isinstance(default_headers, dict)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert not default_headers.get('Accept')
    assert not default_headers.get('Content-Type')
    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers.get('Accept') == JSON_ACCEPT
    assert default_headers.get('Content-Type') == JSON_CONTENT_TYPE

# Generated at 2022-06-21 13:30:10.290181
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    import doctest; doctest.testmod()

# Generated at 2022-06-21 13:30:17.054917
# Unit test for function max_headers
def test_max_headers():
    # Test that the maximum number of headers is configurable
    # See: https://github.com/pawamoy/httpie/issues/849
    def max_headers_test(max_header_value):
        with max_headers(max_header_value):
            assert http.client._MAXHEADERS is max_header_value

    max_headers_test(None)
    max_headers_test(100)

# Generated at 2022-06-21 13:30:21.464941
# Unit test for function make_default_headers
def test_make_default_headers():
    output = make_default_headers({
        'data': 'test_data',
        'json': True,
        'form': False,
    })
    expected_output = {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}
    assert output == expected_output

# Generated at 2022-06-21 13:30:22.214820
# Unit test for function max_headers
def test_max_headers():
    assert 'test_max_headers'



# Generated at 2022-06-21 13:30:25.768455
# Unit test for function max_headers
def test_max_headers():
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000

    with max_headers(None):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == float('Inf')

    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-21 13:30:32.022708
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json

    import pytest

    from tests.httpbin import HTTPBIN_URL

    # noinspection PyUnresolvedReferences
    from httpie.compat import str
    from httpie.config import TestEnvironment
    from httpie.cli.parser import parser
    from httpie.input import SequenceDataReader

    class AuthPlugin:
        auth_type = 'foo'
        raw_auth = 'bar'

    env = TestEnvironment(colors=256)
    args = ['-v', '--debug', '--auth-plugin', AuthPlugin, '--pretty', 'all']

    def get_cli_kwargs(data):
        args.extend(data)
        cli_kwargs = vars(parser.parse_args(args))
        cli_kwargs['stream'] = None
        return cli_kwargs



# Generated at 2022-06-21 13:30:41.768021
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = 'testcert.pem'
    args.proxy = ['http://proxy.com:8080']
    args.verify = 'test'

    expected_dict = {
        'proxies': {'http': 'http://proxy.com:8080'},
        'stream': True,
        'verify': 'test',
        'cert': 'testcert.pem'
    }
    actual_dict = make_send_kwargs_mergeable_from_env(args)
    assert expected_dict == actual_dict



# Generated at 2022-06-21 13:30:51.444382
# Unit test for function make_default_headers
def test_make_default_headers():
    args = []
    args.json = False
    args.form = False
    args.files = False
    args.data = {}
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.data = []
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.data = None
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.data = {}
    args.form = True
    headers = make_default_headers(args)
    assert headers['Accept']

# Generated at 2022-06-21 13:31:14.369567
# Unit test for function collect_messages
def test_collect_messages():
    parser = argparse.ArgumentParser()
    url_or_file_or_item_or_args = parser.add_argument(
        'url_or_file_or_item_or_args',
        nargs='*',
        type=str,
    )
    url_or_file_or_item_or_args.completer = None


    args = parser.parse_args(['http://example.com'])
    from pathlib import Path
    config_dir = Path("~/.httpie").expanduser()
    msgs = collect_messages(args, config_dir)
    for msg in msgs:
        print(msg)

# Generated at 2022-06-21 13:31:26.752214
# Unit test for function make_default_headers
def test_make_default_headers():
    import argparse
    class Namespace:
        data = {}
        form = False
    args = Namespace()
    args.data = {}
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA}

    args.data = None
    args.json = True
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}

    args.data = {}
    args.json = False
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA}

    args.data = {}
    args.form = True

# Generated at 2022-06-21 13:31:34.684354
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie import core
    from httpie.input import ParseError
    from httpie.cli.parser import parser
    arg_parser = parser()
    arg = arg_parser.parse_args(['-X', 'POST', 'example.com', '-b', 'hello'])
    #arg.__dict__
    try:
        args = core.parse_args(arg.args, arg)
        make_request_kwargs(args)
    except ParseError as e:
        print(e)

if __name__ == '__main__':
    test_make_request_kwargs()

# Generated at 2022-06-21 13:31:39.063085
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'


if __name__ == '__main__':
    test_ensure_path_as_is()

# Generated at 2022-06-21 13:31:40.364413
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 13:31:48.475318
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = {p.key: p.value for p in args.proxy}
    args.stream = True
    args.verify = {
            'yes': True,
            'true': True,
            'no': False,
            'false': False,
        }.get(args.verify.lower(), args.verify)
    args.cert = None
    assert args == make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-21 13:31:58.390869
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli.parser import parse_items
    from httpie.client import get_response
    from httpie.sessions import get_httpie_session
    import os
    import shutil
    import tempfile
    import time

    # Test args
    args = argparse.Namespace()
    args.verbose = 1
    args.url = 'https://httpbin.org/html'
    args.timeout = None
    args.allow_redirects = False
    args.auth = None
    args.headers = RequestHeadersDict([])
    args.data = None
    args.method = 'GET'
    args.form = None
    args.json = None
    args.body = None
    args.files = {}

# Generated at 2022-06-21 13:32:07.055816
# Unit test for function build_requests_session
def test_build_requests_session():
    config_proxies = {
        'http': 'http://10.10.1.10:3128',
        'https': 'http://10.10.1.10:1080',
        'ftp': 'ftp://10.10.1.10:3128'
    }
    requests_session = build_requests_session(verify=False)
    assert not requests_session.verify
    assert requests_session.proxies == config_proxies
    assert requests_session.stream

# Generated at 2022-06-21 13:32:16.185189
# Unit test for function collect_messages
def test_collect_messages():
    args = type("", (), {})()
    config_dir = Path('/tmp')
    max_redirects = 0
    certificate = False

    args.session = None
    args.session_read_only = None
    args.debug = False
    args.max_headers = None
    args.max_redirects = max_redirects
    args.follow = False
    args.all = False
    args.method = 'GET'
    args.url = 'http://localhost:8081'
    args.headers = {'User-Agent': 'HTTPie/1.0.3'}
    args.timeout = None
    args.verify = 'yes'
    args.auth = None
    args.auth_plugin = None
    args.multipart = False
    args.multipart_data = None
   

# Generated at 2022-06-21 13:32:18.115882
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs({}) == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-21 13:33:01.689219
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.cert = '../../.ssl/cert.pem'
    args.cert_key = '../../.ssl/cert.key'
    args.chunked = False
    args.files = None
    args.form = False
    args.json = False
    args.max_redirects = None
    args.method = 'GET'
    args.data = None
    args.multipart = False
    args.offline = False
    args.path_as_is = True
    args.compress = False
    args.proxy = ['99.117.155.226:80']
    args.url = 'http://f.com'
    args.headers = {}
    args.params = {}
    args.verify = 'no'
    args.auth = None


# Generated at 2022-06-21 13:33:03.435062
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(args=None) == RequestHeadersDict({'User-Agent': DEFAULT_UA})

# Generated at 2022-06-21 13:33:05.355259
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS != 100

# Generated at 2022-06-21 13:33:06.916967
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True)
    assert type(session) is requests.Session


# Generated at 2022-06-21 13:33:15.074834
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # TODO: add proper tests!
    class args:
        method = 'GET'
        url = 'http://example.com/'
        headers = {'header': 'value'}
        data = None
        auth = None
        params = {'param': ['value']}
        files = []
        json = False
        form = False
        cert = None
        cert_key = None
        ciphers = None
        http2 = False
        http2_prior_knowledge = False
        ignore_stdin = False
        max_redirects = -1
        multipart = False
        multipart_data = {}
        params = None
        path_as_is = False
        proxy = []
        session = None
        session_read_only = None
        ssl_version = None
        timeout = None
        trace

# Generated at 2022-06-21 13:33:20.914293
# Unit test for function collect_messages
def test_collect_messages():
    print("Test collecting messages...")
    parser = argparse.ArgumentParser()
    args = parser.parse_args([
        '--headers', '--verbose', 'http://httpbin.org/ip']
    )
    print("collect_messages output:")
    for k in collect_messages(args, Path("")):
        print(k)

# Generated at 2022-06-21 13:33:29.122471
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    kwargs = make_request_kwargs(args)

    assert kwargs['method'] == 'get'
    assert kwargs['url'] is None
    assert kwargs['headers'] == make_default_headers(args)
    assert kwargs['data'] is None
    assert kwargs['auth'] is None
    assert kwargs['params'] == []

    args = argparse.Namespace()
    args.method = 'POST'
    args.url = 'http://example.org/path'
    args.headers = {'k1': 'v1', 'k2': 'v2'}
    args.data = {'arg1': 'val1', 'arg2': 'val2'}
    args.auth = ('user', 'passw0rd')
    args

# Generated at 2022-06-21 13:33:34.966065
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        method='GET',
        url='',
        data='',
        headers={},
        files=[],
        json=False,
        form=False,
        chunked=False,
        offline=False,
        timeout=None,
        auth_plugin=None,
        auth=None,
        params=[]
    )
    headers = make_default_headers(args)
    assert(headers['User-Agent'] == DEFAULT_UA)

# Generated at 2022-06-21 13:33:46.133963
# Unit test for function dump_request
def test_dump_request():
    test_args_1 = argparse.Namespace(
        '__request_method__',
        '__request_url__',
        '__request_headers__',
        '__request_data__',
        '__request_params__',
    )

# Generated at 2022-06-21 13:33:53.081519
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(True, None)
    assert requests_session is not None
    assert type(requests_session) == requests.Session
    # https://2.python-requests.org/en/master/user/advanced/#session-objects
    # Session objects are not thread-safe
    assert requests_session._thread_local_data == None
    # confirm that adapter is added
    # https://2.python-requests.org/en/master/user/advanced/#session-objects
    # Note that the mount point will be prefixed with the scheme of the
    # request. (For example, it will be treated as ‘https://’ if the scheme
    # of the request was ‘https’.)
    assert https_adapter == requests_session.adapters['https://']
    assert https_

# Generated at 2022-06-21 13:35:06.072329
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    base_headers = None
    request_body_read_callback = lambda chunk: chunk
    kwargs = make_request_kwargs(args, base_headers, request_body_read_callback)
    dump_request(kwargs)

# Generated at 2022-06-21 13:35:16.792516
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:35:22.824577
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 20
    args.allow_redirects = False
    args.proxy = None
    args.stream = True
    args.verify = False
    args.cert = "httpie"
    res = make_send_kwargs(args)
    assert res == {'timeout': 20, 'allow_redirects': False, 'stream': True, 'verify': False, 'cert': 'httpie'}


# Generated at 2022-06-21 13:35:25.657221
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-21 13:35:29.110095
# Unit test for function max_headers
def test_max_headers():
    limit = 10
    try:
        with max_headers(limit):
            assert http.client._MAXHEADERS == limit
    finally:
        assert http.client._MAXHEADERS != limit

if __name__ == '__main__':
    test_max_headers()

# Generated at 2022-06-21 13:35:31.201128
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-21 13:35:33.231980
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        pass
    except requests.TooManyRedirects:
        pass
    except Exception as e:
        print(e)


# Generated at 2022-06-21 13:35:35.330914
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-21 13:35:39.159602
# Unit test for function dump_request
def test_dump_request():
    from httpie.cli.parser import get_parser
    args = get_parser().parse_args(['--debug', '--body', '"a"', 'https://httpbin.org/post'])
    dump_request(make_request_kwargs(args))
    return 0

# Generated at 2022-06-21 13:35:45.078164
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    from httpie.cli.base import httpie
    args = httpie.parser.parse_args(['--json', '--timeout=10', '--verify=False', 'GET', 'http://httpbin.org/'])
    send_kwargs = {
        'verify': {
            'yes': True,
            'true': True,
            'no': False,
            'false': False,
        }.get(args.verify.lower(), args.verify),
        'timeout': 10 or None,
        'allow_redirects': False,
    }
    assert make_send_kwargs(args) == send_kwargs

# Generated at 2022-06-21 13:38:15.282206
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False, "TLSv1_3", None)
    print("Verify: " + str(session.verify))
    print("Adapter: " + str(session.adapters))

# Generated at 2022-06-21 13:38:19.610578
# Unit test for function finalize_headers
def test_finalize_headers():
    class RequestHeadersDict(dict):
        def __getitem__(self, name):
            # Lowercase name and then check the dict.
            return super(RequestHeadersDict, self).__getitem__(name.lower())

    headers = RequestHeadersDict({
        'Host': 'Foo',
    })
    print(headers)
    print(headers['Host'])

# test_finalize_headers()

# Generated at 2022-06-21 13:38:29.633310
# Unit test for function collect_messages
def test_collect_messages():
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    send_kwargs = make_send_kwargs(args)
    requests_session = build_requests_session(
        ssl_version=args.ssl_version,
        ciphers=args.ciphers,
        verify=bool(send_kwargs_mergeable_from_env['verify'])
    )
    request_kwargs = make_request_kwargs(
        args=args,
        base_headers=httpie_session_headers,
        request_body_read_callback=request_body_read_callback
    )


# Generated at 2022-06-21 13:38:36.625706
# Unit test for function finalize_headers
def test_finalize_headers():
    """
    Tests function finalize_headers()
    :return:
    """
    test_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': FORM_CONTENT_TYPE
    })
    assert finalize_headers({'User-Agent': DEFAULT_UA,
                             'Accept': 'a p p l i c a t i o n / j s o n , */*;q=0.5',
                             'Content-Type': ' application/x-www-form-urlencoded; charset=utf-8',
                             'key': 'another_val'}) == test_headers

# Generated at 2022-06-21 13:38:39.270878
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    assert collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-21 13:38:46.125452
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = True
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.stream = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False
    assert kwargs['stream'] == True


# Generated at 2022-06-21 13:38:50.514613
# Unit test for function finalize_headers
def test_finalize_headers():
    print(finalize_headers(RequestHeadersDict({
        ' User-Agent': DEFAULT_UA,
        ' Accept ': JSON_ACCEPT,
        ' Content-Type ': JSON_CONTENT_TYPE,
        ' Content-Length ': '1024',
    })))

# Generated at 2022-06-21 13:38:58.358382
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    assert {'proxies':{}, 'stream':True, 'verify':True, 'cert':None} == make_send_kwargs_mergeable_from_env(args)
    args.proxy = ['http:127.0.0.1:8888']
    args.verify = "true"
    args.cert = '~/.cert/foo.pem'
    args.cert_key = '~/.cert/foo.key'
    assert {'proxies':{'http':'127.0.0.1:8888'}, 'stream':True, 'verify':True, 'cert':'~/.cert/foo.pem'}

# Generated at 2022-06-21 13:39:09.563086
# Unit test for function finalize_headers
def test_finalize_headers():
    original_headers = RequestHeadersDict({
        'Content-Type': ' application/x-www-form-urlencoded; charset=utf-8 ',
        'Accept': 'application/json; q=1, text/plain; q=0.5, application/xml; q=0.2',
        'User-Agent': ' HTTPie/0.9.2',
        'Cache-Control': ' no-cache',
        'Foo': 'bar'
    })
    final_headers = finalize_headers(original_headers)

# Generated at 2022-06-21 13:39:12.782776
# Unit test for function finalize_headers
def test_finalize_headers():
    header_dict = RequestHeadersDict({'  Accepts': 'json'})
    assert header_dict == finalize_headers(header_dict)
    header_dict = RequestHeadersDict({'Accepts': ' json'})
    assert header_dict == finalize_headers(header_dict)
