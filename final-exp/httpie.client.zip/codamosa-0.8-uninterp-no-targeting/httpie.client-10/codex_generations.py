

# Generated at 2022-06-21 13:30:17.832552
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.headers = [('Content-Type', 'application/json')]
    args.json = False
    args.data = {'key', 'value'}
    args.form = False
    default_headers = make_default_headers(args)

    assert default_headers == {'User-Agent': 'HTTPie/1.0.0', 'Content-Type': 'application/json'}



# Generated at 2022-06-21 13:30:25.953686
# Unit test for function dump_request
def test_dump_request():
    # noinspection PyUnusedLocal
    def request_body_read_callback(chunk):
        pass

# Generated at 2022-06-21 13:30:26.405117
# Unit test for function collect_messages
def test_collect_messages():
    pass

# Generated at 2022-06-21 13:30:26.861998
# Unit test for function build_requests_session
def test_build_requests_session():
    pass

# Generated at 2022-06-21 13:30:30.899759
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    default_headers = {'User-Agent': 'HTTPie/{}'.format(__version__), 'Accept': 'application/json, */*;q=0.5'}
    assert default_headers == make_default_headers(args)

# Generated at 2022-06-21 13:30:36.142737
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': args.timeout or None, 'allow_redirects': False}


# Generated at 2022-06-21 13:30:38.940448
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1000):
        assert http.client._MAXHEADERS == 1000
    assert http.client._MAXHEADERS != 1000


# Generated at 2022-06-21 13:30:49.443313
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    test_args = argparse.Namespace(proxy=[])
    assert make_send_kwargs_mergeable_from_env(test_args) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }

    test_args_with_ssl_certificate = argparse.Namespace(
        proxy=[],
        cert='certificate.pem',
        cert_key='key.pem'
    )
    assert make_send_kwargs_mergeable_from_env(
        test_args_with_ssl_certificate) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': ('certificate.pem', 'key.pem'),
    }



# Generated at 2022-06-21 13:30:51.142671
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        ssl_version='TLSv1.1',
        ciphers='ECDH+AESGCM',
        verify=False
    )
    assert requests_session is not None

# Generated at 2022-06-21 13:30:54.487064
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.argparse.ArgumentParser()
    args.cert = '../../../cert.pem'
    args.cert_key = '../../../key.pem'
    args.verify = 'False'

    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['cert'] == '../../../cert.pem', kwargs
    assert kwargs['verify'] == False, kwargs



# Generated at 2022-06-21 13:31:19.397018
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    d = make_send_kwargs_mergeable_from_env(None)
    assert d['verify'] == True
    assert len(d.keys()) == 2
    assert d['proxies'] == {}

# Generated at 2022-06-21 13:31:24.391332
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    # args.debug = False
    # args.data = None
    # args.files = None
    # args.form = False
    # args.json = False
    # args.compress = None
    # args.max_redirects = None
    # args.max_headers = None
    # args.method = 'GET'
    args.offline = False
    args.chunked = False
    # args.multipart = False
    # args.multipart_data = None
    # args.boundary = None
    # args.path_as_is = False
    args.proxy = []
    args.verify = 'yes'
    # args.session = None
    # args.session_read_only = None
    # args.auth = None
    # args

# Generated at 2022-06-21 13:31:26.058986
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 1000  # Post patch make sure it's 4
    with max_headers(4):
        assert http.client._MAXHEADERS == 4
    assert http.client._MAXHEADERS == 1000  # Post patch make sure it's 4

# Generated at 2022-06-21 13:31:35.929854
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from non_httpie import NonHTTPie
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.compat import urlencode
    from httpie.plugins import builtin
    from httpie.output.streams import StdoutBytesIO
    from httpie.cli import parser
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.context import Environment

# Generated at 2022-06-21 13:31:40.808332
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Construct a fake argparse.Namespace object
    args = argparse.Namespace()
    args.timeout = 100
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    print(kwargs)



# Generated at 2022-06-21 13:31:48.031119
# Unit test for function dump_request
def test_dump_request():
    # Here we create an object used to call functions in httpie.py
    import sys
    sys.argv = ['httpie.py', 'get', 'www.google.com']
    from httpie.cli import main
    arguments = main()
    # Here we run the function to dump request
    assert dump_request(arguments) is not '\n>>> requests.request(**{repr_dict(kwargs)})\n\n'

# Generated at 2022-06-21 13:31:49.208468
# Unit test for function collect_messages
def test_collect_messages():
    # TODO: test
    pass



# Generated at 2022-06-21 13:31:56.941550
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'no'
    args.proxy = 'https://10.33.2.31'
    args.cert = 'foo.crt'
    args.cert_key = 'foo.key'
    expected = {
        'proxies': {'https:': 'https://10.33.2.31'},
        'stream': True,
        'verify': False,
        'cert': ('foo.crt', 'foo.key'),
    }
    assert make_send_kwargs_mergeable_from_env(args) == expected

# Generated at 2022-06-21 13:31:59.177234
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        form=False,
        json=False,
        files=None,
        headers=(),
    )
    expected_default_headers = {
        'User-Agent': DEFAULT_UA
    }
    assert make_default_headers(args) == expected_default_headers



# Generated at 2022-06-21 13:32:11.006300
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=None, verify=None, cert=None, cert_key=None)
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == dict(proxies=None, stream=True, verify=None, cert=None)
    args = argparse.Namespace(
        proxy=[argparse.Namespace(key='https', value='1.1.1.1:8080')],
        verify='no',
        cert='/home/me/client.pem',
        cert_key='/home/me/client.pem',
    )
    kwargs = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-21 13:32:50.369695
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env({
        'proxy': {'key':'value'},
        'stream': True,
        'verify': True,
        'cert': 'cert'
    }) == {
        'proxy': {'key': 'value'},
        'stream': True,
        'verify': True,
        'cert': 'cert'
    }

# Generated at 2022-06-21 13:32:53.389055
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == \
        'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:33:04.896977
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    '''
    This function test the function make_request_kwargs

    '''
    from httpie.cli.argtypes import KeyValueArgType

    # For testing we set up the command line arguments like following:

    args = argparse.Namespace()

    # The method
    args.method = "post"

    # The headers
    args.headers = KeyValueArgType("headers").convert("k1=v1", "k2=v2")

    # The url
    args.url = "http://foo"

    # Set the chunked flag to true
    args.chunked = True

    # Set the offline flag to true
    args.offline = True

    # The data
    args.data = "data1"
    
    # Check the arguments are passed correctly to make_request_kwargs

# Generated at 2022-06-21 13:33:06.795190
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:33:09.512610
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    url = 'http://foo/../'
    correct_url = 'http://foo/?foo=bar'
    new_url = ensure_path_as_is(url, correct_url)
    assert new_url == correct_url, "FAILED TEST"

# Generated at 2022-06-21 13:33:12.678801
# Unit test for function max_headers
def test_max_headers():
    """Test function max_headers"""
    try:
        with max_headers(10):
            assert http.client._MAXHEADERS == 10
    finally:
        http.client._MAXHEADERS = http.client._MAXLINE

# Generated at 2022-06-21 13:33:13.962360
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1

# Generated at 2022-06-21 13:33:17.877707
# Unit test for function make_default_headers
def test_make_default_headers():
    # Arrange
    args = argparse.Namespace()
    # Act
    default_headers = make_default_headers(args)
    # Assert
    assert default_headers['User-Agent'] == 'HTTPie/0.9.9'


# Generated at 2022-06-21 13:33:26.629354
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    mock_args = argparse.Namespace()
    mock_args.proxy = [argparse.Namespace(key='foo', value='bar')]
    mock_args.verify = 'foo'
    mock_args.cert = 'bar'
    mock_args.cert_key = 'foobar'
    result = make_send_kwargs_mergeable_from_env(mock_args)
    assert result['proxies'] == {'foo': 'bar'}
    assert result['stream'] is True
    assert result['verify'] == 'foo'
    assert result['cert'] == ('bar', 'foobar')

# Generated at 2022-06-21 13:33:36.310381
# Unit test for function build_requests_session

# Generated at 2022-06-21 13:34:59.942633
# Unit test for function max_headers
def test_max_headers():

    # create dictionary to hold headers
    headers = collections.OrderedDict()

    # create key and value in dictionary
    headers['a'] = 'b'

    # create key and value in dictionary
    headers['a'] = 'b'

    # create another key and value in dictionary
    headers['c'] = 'd'

    # create function that takes one parameter
    def test_func(headers):
        # create a try-except statement
        try:
            pass
        # if an exception occurs, print a message
        except:
            print('Something went wrong')

    # assert that the function returns a dictionary with the following keys and values
    assert test_func(headers) == {'a': 'b', 'c': 'd'}

    # create function that takes one parameter

# Generated at 2022-06-21 13:35:05.371465
# Unit test for function build_requests_session
def test_build_requests_session():
    import pytest
    from .test_utils import MockPlugin


# Generated at 2022-06-21 13:35:07.506776
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:35:15.386417
# Unit test for function max_headers
def test_max_headers():
    MAX_HEADERS = 20
    original_header = http.client._MAXHEADERS
    with max_headers(MAX_HEADERS):
        test_headers = {}
        for i in range(MAX_HEADERS):
            test_headers["test"+str(i)] = "header"+str(i)
        http.client._MAXHEADERS = len(test_headers)
        http.client._MAXHEADERS = len(test_headers)+1
        assert http.client._MAXHEADERS == MAX_HEADERS
    http.client._MAXHEADERS = original_header

# Generated at 2022-06-21 13:35:15.979588
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    pass

# Generated at 2022-06-21 13:35:25.792166
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()

    args.json = False
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert 'User-Agent' in default_headers
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = True
    args.form = False
    default_headers = make_default_headers(args)
    assert 'User-Agent' in default_headers
    assert 'Accept' in default_headers
    assert 'Content-Type' not in default_headers

    args.json = False
    args.form = True
    default_headers = make_default_headers(args)
    assert 'User-Agent' in default_headers
    assert 'Accept' not in default_headers

# Generated at 2022-06-21 13:35:32.801669
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    test_args = argparse.Namespace()

    # Test with no proxy, no cert, cert_key
    result = make_send_kwargs_mergeable_from_env(test_args)
    expected = {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    assert result == expected

    # Test with proxy, cert, cert_key
    test_args.proxy = [argparse.Namespace(key='https', value='proxy.example.com')]
    test_args.cert = "cert.pem"
    test_args.cert_key = "cert-key.pem"
    result = make_send_kwargs_mergeable_from_env(test_args)

# Generated at 2022-06-21 13:35:42.167136
# Unit test for function finalize_headers
def test_finalize_headers():
    input_headers = {
        'content-Type':'type1',
        'content-length': '1',
        'content-md5' : 'md5',
        'x-amz-Date': 'date'
    }
    output_headers = finalize_headers(input_headers)

    expected_final_headers = {
        'Content-Type':'type1',
        'Content-Length': '1',
        'Content-MD5' : 'md5',
        'X-Amz-Date': 'date'
    }
    # print(output_headers)
    # {'Content-Type': 'type1', 'Content-Length': '1', 'Content-MD5': 'md5', 'X-Amz-Date': 'date'}
    assert expected_final_headers == output_headers

# Generated at 2022-06-21 13:35:50.063846
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from tempfile import TemporaryDirectory
    from requests.structures import CaseInsensitiveDict
    from httpie.context import Environment

    with TemporaryDirectory() as td:
        env = Environment(td, proxy_list=[], auth=None, verify=True, cert=None,
                          debug=False, options=None)
        kwargs = make_send_kwargs_mergeable_from_env(args=env)
        assert (kwargs['proxies'] == {p.key: p.value for p in env.proxy})
        assert (kwargs['stream'] is env.stream)
        assert (kwargs['verify'] is env.verify)
        assert (kwargs['cert'] is env.cert)
        env.verify = 'No'
        env.cert = 'abc'

# Generated at 2022-06-21 13:35:52.359226
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=1)
    assert make_send_kwargs(args) == {'timeout': 1, 'allow_redirects': False}
