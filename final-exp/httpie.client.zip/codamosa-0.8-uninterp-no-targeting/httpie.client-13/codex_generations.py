

# Generated at 2022-06-21 13:30:14.439493
# Unit test for function make_send_kwargs

# Generated at 2022-06-21 13:30:23.189845
# Unit test for function make_default_headers
def test_make_default_headers():
    # Test with json
    args = argparse.Namespace(json=1,headers={},data={},files={},form=0)
    result = make_default_headers(args)
    assert result['User-Agent'] == DEFAULT_UA
    assert result['Accept'] == JSON_ACCEPT
    assert result['Content-Type'] == JSON_CONTENT_TYPE

    # Test without json
    args = argparse.Namespace(json=0,headers={},data={},files={},form=0)
    result = make_default_headers(args)
    assert result['User-Agent'] == DEFAULT_UA
    assert result.get('Accept') is None
    assert result.get('Content-Type') is None


# Generated at 2022-06-21 13:30:26.323407
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': None,
        'Accept': 'application/json'
    })
    assert finalize_headers(headers) == {
        'Accept': 'application/json'
    }

# Generated at 2022-06-21 13:30:29.312418
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace(
        method='get',
        url='www.google.com',
    )
    config_dir = Path('config')
    request_body_read_callback = lambda chunk: None
    collect_messages(args, config_dir, request_body_read_callback)

# Generated at 2022-06-21 13:30:41.356803
# Unit test for function dump_request

# Generated at 2022-06-21 13:30:51.143117
# Unit test for function max_headers
def test_max_headers():

    with max_headers(3):
        test_headers = [('Accept', 'application/json'), ('User-Agent', 'HTTPie/1.0.3'), ('Authorization', 'Basic 123456')]
        print(len(test_headers))
        assert len(test_headers)

    with max_headers(0):
        test_headers = [('Accept', 'application/json'), ('User-Agent', 'HTTPie/1.0.3'), ('Authorization', 'Basic 123456')]
        print(len(test_headers))
        assert not len(test_headers)

    with max_headers(5):
        test_headers = [('Accept', 'application/json'), ('User-Agent', 'HTTPie/1.0.3'), ('Authorization', 'Basic 123456')]
        print(len(test_headers))
        assert len

# Generated at 2022-06-21 13:30:53.554615
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.headers = {}
    args.json = False
    args.form = False
    args.data = {'abc': '123'}
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert 'Content-Type' not in headers

# Generated at 2022-06-21 13:30:56.192682
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:31:08.987785
# Unit test for function dump_request

# Generated at 2022-06-21 13:31:16.597806
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_test = argparse.Namespace(
        method='GET', url='http://httpbin.org/get', headers={},
        auth=('', ''), timeout=None, files=[], params=[],
        data=[], form=False, json=False, chunked=False,
        offline=False, max_redirects=30, follow=False,
        verify='yes', cert=None, cert_key=None, proxy=[],
        all=False, debug=False, download=False,
        session='', session_read_only='',
        stream=False,
        ssl_version='',
        ciphers='',
        boundary='',
        multipart_data=[],
        multipart=False,
        path_as_is=False,
        compress=0,
    )
    request_kwargs = make_

# Generated at 2022-06-21 13:31:49.016593
# Unit test for function build_requests_session
def test_build_requests_session():
    print(build_requests_session())

# Generated at 2022-06-21 13:31:53.861753
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import requests
    import pytest

# Generated at 2022-06-21 13:31:55.870904
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:32:01.042475
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': 'GET',
        'url': 'http://foo/bar',
        'headers': {'HOST': 'foo', 'ACCEPT': 'application/json; q=0.5'},
        'data': None
    }
    output = ">>> requests.request(**{'method': 'GET', 'url': 'http://foo/bar', 'headers': {'HOST': 'foo', 'ACCEPT': 'application/json; q=0.5'}, 'data': None})\n\n"
    assert dump_request(kwargs) == output

# Generated at 2022-06-21 13:32:12.070459
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        cert = 'cert',
        cert_key = 'cert_key',
        verify = 'verify',
        proxy = ['proxy1', 'proxy2']
    )

    kwargs = make_send_kwargs_mergeable_from_env(args)
    print(kwargs)
    assert kwargs['cert'] == 'cert'
    assert kwargs['cert_key'] == 'cert_key'
    assert kwargs['verify'] == 'verify'
    assert kwargs['proxies']['proxy1'] == 'proxy1'
    assert kwargs['proxies']['proxy2'] == 'proxy2'

if __name__ == '__main__':
    test_make_send_kwargs_mergeable_from_env()

# Generated at 2022-06-21 13:32:25.033117
# Unit test for function collect_messages
def test_collect_messages():
    assert make_request_kwargs() == {
        'auth': None,
        'data': b'',
        'headers': {'Accept': 'application/json, */*;q=0.5',
                    'Content-Type': 'application/json; charset=utf-8',
                    'User-Agent': 'HTTPie/0.9.9'},
        'method': 'get',
        'params': [],
        'url': 'httpbin.org'
    }

    assert make_send_kwargs() == {
        'allow_redirects': False,
        'timeout': None,
    }


# Generated at 2022-06-21 13:32:33.268324
# Unit test for function collect_messages
def test_collect_messages():
    class Args:
        pass
    args = Args()
    args.session = None
    args.session_read_only = False
    args.url = 'http://api.example.com/test'
    args.debug = False
    args.path_as_is = False
    args.compress = False
    args.offline = False
    args.max_redirects = False
    args.follow = True
    args.all = False
    args.method = 'GET'
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = {
        'form_key': 'form_value'
    }
    args.timeout = 5
    args.verify = False
    args.cert = '/path/to/cert'

# Generated at 2022-06-21 13:32:37.896696
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=100,
        allow_redirects=False,
    )
    result = make_send_kwargs(args)
    assert result == {
        'timeout': 100,
        'allow_redirects': False,
    }

# Generated at 2022-06-21 13:32:47.080663
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie import docopt_parse
    from httpie.constants import AUTH_NAME_ENV

# Generated at 2022-06-21 13:32:49.720788
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path('.')
    request_body_read_callback = lambda chunk: chunk
    for m in collect_messages(args, config_dir, request_body_read_callback):
        print(m)

# Generated at 2022-06-21 13:33:36.142732
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://localhost:8080/api/v1/test'
    args.headers = [
                    ('Accept', 'application/json'),
                    ('Content-Type', 'application/json'),
                    ('Authorization', 'Bearer 36d2b24e-f818-4f0b-a7be-44d9b8f2f2fb')
                   ]
    args.follow = False
    args.timeout = None
    args.cert = None
    args.cert_key = None
    args.ssl_version = None
    args.ciphers = None
    args.proxy = []

    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'get'
    assert kw

# Generated at 2022-06-21 13:33:42.810771
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Accept': ' application/json  '}
    final_headers = finalize_headers(headers)
    assert final_headers['Accept'] == b'application/json'

    headers = {'Accept': ' application/json  ', 'Content-Type' : None}
    final_headers = finalize_headers(headers)
    assert final_headers['Accept'] == b'application/json'
    assert final_headers['Content-Type'] == b''

    headers = {'Accept': ' application/json  ', 'Content-Type' : 'text/html'}
    final_headers = finalize_headers(headers)
    assert final_headers['Accept'] == b'application/json'
    assert final_headers['Content-Type'] == b'text/html'


# Generated at 2022-06-21 13:33:49.979990
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.status_codes import Status
    from httpie.cli import parser
    args = parser.parse_args(['--json', 'http://www.google.com'])
    stream = collect_messages(args, Path('~').expanduser())
    request = next(stream)
    assert request.url == 'http://www.google.com/'
    assert request.headers['Accept'] == 'application/json, */*;q=0.5'
    assert request.headers['Content-Type'] == 'application/json'
    response = next(stream)
    assert response.status == Status.ok
    assert response.url == 'http://www.google.com/'
    assert not hasattr(response, 'next')

    print(response.headers)

# Generated at 2022-06-21 13:33:53.022754
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'content-length': '0',
        'content-type': 'application/json',
        'accept': 'application/json'
    })
    expected = RequestHeadersDict({
        'content-length': '0',
        'content-type': 'application/json',
        'accept': 'application/json'
    })
    assert finalize_headers(headers) == expected

# Generated at 2022-06-21 13:34:04.498250
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class TestArgumentParser(argparse.ArgumentParser):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.i = kwargs.get('i', 0)
    
    def main():
        parser = TestArgumentParser()
        arguments = []
        parser.add_argument('--method', '-m')
        arguments.append(('method', 'PUT'))
        parser.add_argument('--url', '-u')
        arguments.append(('url', 'https://github.com/httpie/httpie'))
        parser.add_argument('--headers', '-h', action='append')
        arguments.append(('headers', 'Authorization: token'))
        parser.add_argument('--auth', '-a')
       

# Generated at 2022-06-21 13:34:10.265083
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace
    args.data = {}
    args.form = ''
    # args.json = ''
    # args.args = ''
    # args.headers = ''
    # args.files = ''
    # args.session = ''
    # args.verbose = ''
    # args.offline = ''
    # args.chunked = ''
    # args.compress = ''
    # args.max_redirects = ''
    # args.max_headers = ''
    # args.json_pp = ''
    # args.pretty = ''
    # args.style = ''
    # args.download = ''
    # args.download_all = ''
    # args.upload = ''
    # args.stream = ''
    # args.session_read_only = ''
    # args.print

# Generated at 2022-06-21 13:34:14.140348
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {
        'Content-Type': 'application/json',
        'Content-Length': '0',
    }
    headers = finalize_headers(headers)
    assert headers['Content-Type'] == 'application/json'
    assert headers['Content-Length'] == '0'



# Generated at 2022-06-21 13:34:23.860510
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    # Test three types of paths (1 = "normal", 2 = "with spaces", 3 = "with unicode")
    print("")
    print("Testing function ensure_path_as_is...")
    url_original = "https://www.google.com/abc/def.php"
    url_new = "https://www.google.com/new/path/"
    url_new_spaces = "https://www.google.com/new path/"
    url_new_unicode = "https://www.google.com/new%20path/"
    url_new_unicode_with_spaces = "https://www.google.com/new%20path%20with%20spaces/"


# Generated at 2022-06-21 13:34:25.313631
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        pass
    assert(http.client._MAXHEADERS == orig)

# Generated at 2022-06-21 13:34:34.001990
# Unit test for function finalize_headers
def test_finalize_headers():
    test_dict = {
        'User-Agent': 'HTTPie/1.0.2',
        'Content-Type': 'application/json',
        'Accept': 'application/json, */*;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Host': 'httpbin.org',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache',
        'Postman-Token': '04e77a2a-3c7b-4a09-8c00-ce0c9f9b86d6'
    }
    assert test_dict == finalize_headers(test_dict)

# Generated at 2022-06-21 13:35:59.945563
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args=argparse.Namespace
    args.headers={}
    args.json={}
    args.data={}
    args.form={}
    args.files={}
    args.auth={}
    args.params={}
    args.method='GET'
    args.url='https://httpbin.org/'
    args.timeout=None
    args.verify='yes'
    args.cert=None
    args.cert_key=None
    args.proxy=[]
    args.session=False
    args.session_read_only=False
    args.max_redirects=False
    args.offline=False
    args.chunked=False
    args.compress=False
    args.follow=False
    args.all=False
    args.ssl_version=None

# Generated at 2022-06-21 13:36:03.746213
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie import cli
    parser = cli.get_argparser()
    args = parser.parse_args(['GET'])
    print(make_request_kwargs(args))

test_make_request_kwargs()

# Generated at 2022-06-21 13:36:12.706918
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        chunked=False,
        data={"id":123},
        files=[],
        form=False,
        headers=[],
        json=True,
        method='GET',
        chunked=False,
        offline=False,
        url='http://127.0.0.1:5000/getsituation'
    )
    output = make_request_kwargs(args=args, base_headers=None, request_body_read_callback=None)

# Generated at 2022-06-21 13:36:14.099254
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    send_kwargs = make_send_kwargs(2)
    assert send_kwargs['args'] == 2

# Generated at 2022-06-21 13:36:16.398337
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env({'verify': False}) == {'verify': False}

# Generated at 2022-06-21 13:36:20.805074
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(False, None, None)
    assert session.trust_env is False
    session = build_requests_session(False, ssl.PROTOCOL_TLS, 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256')
    assert session.trust_env is False

# Generated at 2022-06-21 13:36:24.115798
# Unit test for function max_headers
def test_max_headers():
    import http.client
    with max_headers(1):
        # noinspection PyUnresolvedReferences
        assert http.client._MAXHEADERS == 1
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 100



# Generated at 2022-06-21 13:36:26.384589
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'


# Generated at 2022-06-21 13:36:36.134193
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('https://httpbin.org', 'https://httpbin.org/') == 'https://httpbin.org/'
    assert ensure_path_as_is('https://httpbin.org/get', 'https://httpbin.org/get/') == 'https://httpbin.org/get/'
    assert ensure_path_as_is('https://httpbin.org/headers', 'https://httpbin.org/Headers/') == 'https://httpbin.org/Headers/'
    assert ensure_path_as_is('https://httpbin.org/', 'https://httpbin.org/get') == 'https://httpbin.org/get'

# Generated at 2022-06-21 13:36:38.093819
# Unit test for function dump_request
def test_dump_request():
    kwargs = {"url": "http://example.com", "method": "GET"}
    dump_request(kwargs)

