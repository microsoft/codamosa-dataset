

# Generated at 2022-06-21 13:30:04.810067
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    args.url = 'https://httpbin.org/get'
    kwargs = {'method':'GET'}
    dump_request(kwargs)


# Generated at 2022-06-21 13:30:16.783550
# Unit test for function dump_request
def test_dump_request():
    class Args:
        def __init__(self):
            self.auth = ('Doe', 'Pass')
            self.auth_plugin = None
            self.compress = False
            self.data = {}
            self.form = False
            self.headers = {'Accept': 'text/html'}
            self.json = True
            self.method = 'get'
            self.multipart = False
            self.multipart_data = {}
            self.offline = False
            self.params = {}
            self.session = None
            self.session_read_only = None
            self.url = 'http://www.google.com'
            self.verify = 'true'
            self.files = False
            self.max_redirects = None
            self.max_headers = None

# Generated at 2022-06-21 13:30:23.513778
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    ssl_version = None
    ciphers = 'TLSv1.2'
    session = build_requests_session(verify, ssl_version, ciphers)
    assert session.adapters == {
        'http://': requests.adapters.HTTPAdapter(
            max_retries=3,
        ),
        'https://': HTTPieHTTPSAdapter(
            ciphers=ciphers,
            verify=verify,
            ssl_version=None,
            max_retries=3,
        )
    }

# Generated at 2022-06-21 13:30:24.947220
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie.cli import parser
    args = parser.parse_args([
    ])

# Generated at 2022-06-21 13:30:29.115970
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class MockNamespace:
        def __init__(self):
            self.auth = None
            self.auth_plugin = None

    args = MockNamespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': 'cert',
    }

# Generated at 2022-06-21 13:30:30.040327
# Unit test for function make_default_headers
def test_make_default_headers():
    return make_default_headers()

# Generated at 2022-06-21 13:30:42.273157
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    assert headers['User-Agent'] == DEFAULT_UA
    args.data = '["test"]'
    args.json = False
    headers = make_default_headers(args)
    assert headers['Accept'] == '*/*'
    assert headers['Content-Type'] is None
    args.data = {}
    args.form = True
    headers = make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE
    args.form = False
    args.files = '/tmp/file'
    headers = make_default_headers(args)
    assert headers

# Generated at 2022-06-21 13:30:45.430158
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(
        orig_url='http://foo/../',
        prepped_url='http://foo/?foo=bar',
    ) == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:30:46.582377
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ("http://foo/../?foo=bar" == ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar'))

# Generated at 2022-06-21 13:30:50.859576
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.auth = None
    args.auth_plugin = None
    args.verify = 'true'
    args.ciphers = None
    args.debug = False
    args.max_redirects = None
    args.max_headers = None
    args.form = False
    args.json = False
    args.offline = False
    args.session = None
    args.session_read_only = None
    args.url = 'http://httpbin.org/anything'
    args.method = 'GET'
    args.headers = RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'})
    args.data = None
    args.files = None
    args.params = None
    args.timeout = None
   

# Generated at 2022-06-21 13:31:14.897686
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert (ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')== 'http://foo/../?foo=bar')
    assert (ensure_path_as_is('http://foo/', 'http://foo/?foo=bar') == 'http://foo/?foo=bar')
    assert (ensure_path_as_is('http://foo/bar/', 'http://foo/?foo=bar') == 'http://foo/bar/?foo=bar')
    assert (ensure_path_as_is('https://foo/bar/', 'http://foo/?foo=bar') == 'http://foo/bar/?foo=bar')

# Generated at 2022-06-21 13:31:18.423554
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 100
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-21 13:31:30.745803
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=False, form=False, data=False, files=False)
    default_headers = make_default_headers(args)
    assert 'User-Agent' in default_headers
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers
    # args = argparse.Namespace(json=True, form=False, data=False, files=False)
    # default_headers = make_default_headers(args)
    # assert 'User-Agent' in default_headers
    # assert 'Accept' in default_headers
    # assert default_headers['Accept'] == JSON_ACCEPT
    # assert 'Content-Type' in default_headers
    # assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    # args = argparse.Namespace(

# Generated at 2022-06-21 13:31:43.997672
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.chunked = None
    args.offline = None
    args.method = None
    args.url = None
    args.headers = None
    args.data = None
    args.json = None
    args.form = None
    args.multipart = None
    args.boundary = None
    args.files = None
    args.auth = None
    args.params = None

    data = {
    	'key1': 'value1',
    	'key2': 'value2'
    }
    args.data = data
    args.json = False
    args.form = True
    args.files = None
    args.multipart = False

    result = make_request_kwargs(args=args)

# Generated at 2022-06-21 13:31:55.436639
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict()
    headers['User-Agent'] = f'HTTPie/{__version__}'
    headers['Accept'] = JSON_ACCEPT
    headers['Content-Type'] = JSON_CONTENT_TYPE

    final_headers = finalize_headers(headers)
    assert final_headers['User-Agent'] == DEFAULT_UA
    assert final_headers['Accept'] == JSON_ACCEPT
    assert final_headers['Content-Type'] == JSON_CONTENT_TYPE

    headers = RequestHeadersDict()
    headers['User-Agent'] = f' HTTPie/{__version__} '
    headers['Accept'] = JSON_ACCEPT
    headers['Content-Type'] = JSON_CONTENT_TYPE

    final_headers = finalize_headers(headers)
    assert final_headers['User-Agent'] == DEFAULT

# Generated at 2022-06-21 13:31:59.920213
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 1
    args.allow_redirects = True
    args.max_redirects = 10
    args.verify = 1
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    args.proxy = []
    args.proxy_auth = []
    args.stream = True
    args.offline = True
    args.session = None
    args.session_read_only = None
    send_kwargs = make_send_kwargs(args)

    assert(send_kwargs['timeout'] == 1)
    assert(send_kwargs['allow_redirects'] == True)
    assert(send_kwargs['max_redirects'] == 10)
    assert(send_kwargs['verify'] == 1)


# Generated at 2022-06-21 13:32:11.322718
# Unit test for function collect_messages
def test_collect_messages():
    # 1. Test with all default arguments
    args = get_default_args()
    config_dir = Path(".")
    request_body_read_callback = lambda chunk: chunk
    collect_messages(
            args=args,
            config_dir=config_dir,
            request_body_read_callback=request_body_read_callback)
    
    # 2. Test with --verify = false
    args = get_default_args()
    args.verify = False
    collect_messages(
            args=args,
            config_dir=config_dir,
            request_body_read_callback=request_body_read_callback)
    
    # 3. Test with --json
    args = get_default_args()
    args.json = True

# Generated at 2022-06-21 13:32:23.759210
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    # test1
    print("test1")
    orig_url = 'http://foo/../'
    prepped_url = 'http://foo/?foo=bar'
    final_url = ensure_path_as_is(orig_url, prepped_url)
    assert final_url == 'http://foo/../?foo=bar'
    # test2
    print("test2")
    orig_url = 'http://foo/../'
    prepped_url = 'http://foo:123/?foo=bar'
    final_url = ensure_path_as_is(orig_url, prepped_url)
    assert final_url == 'http://foo:123/../?foo=bar'
    # test3
    print("test3")
    orig_url = 'http://foo/../'

# Generated at 2022-06-21 13:32:32.914477
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    plugin_manager.set_output_stream(None)

    # Test empty headers
    args.headers = {}
    expected = {'User-Agent': 'HTTPie/0.9.9'}
    result = make_default_headers(args)
    assert result == expected

    # Test empty headers with Accept
    args.headers['Accept'] = 'text/plain'
    expected = {'User-Agent': 'HTTPie/0.9.9', 'Accept': 'text/plain'}
    result = make_default_headers(args)
    assert result == expected

    # Test empty headers with Content-Type
    args.headers = {}
    args.headers['Content-Type'] = 'application/json'

# Generated at 2022-06-21 13:32:34.843040
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=False)
    assert session


# Generated at 2022-06-21 13:33:16.422383
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import json
    import os
    import time

    from httpie.cli import parser

    def helper(self, *args, **kwargs):
        request_body_read_callback = kwargs.pop('request_body_read_callback', None)
        args = parser.parse_args(args=args, env=self.env)
        config_dir = Path(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
        ms = list(collect_messages(args=args, config_dir=config_dir, \
            request_body_read_callback=request_body_read_callback))
        return ms

    # FIXME: def test_collect_messages_timeout
    # FIXME: def test_collect_messages_timeout_after_request_

# Generated at 2022-06-21 13:33:27.304193
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    args.url = "http://localhost"
    args.headers = {'userid':"1"}
    args.json = False
    args.compress = False
    args.auth = None
    args.data = {"test":"test"}
    args.files = None
    args.form = False
    args.method = "GET"
    args.session = None
    args.session_read_only = False
    args.offline = False
    args.timeout = 30
    args.max_redirects = 5
    args.max_headers = 100
    args.timeout = 30
    args.timeout = 30
    args.debug = False


# Generated at 2022-06-21 13:33:31.760864
# Unit test for function dump_request
def test_dump_request():
    import json
    d = {
        'url': 'http://www.taobao.com/',
        'headers': {'Content-Type': 'application/json'},
        'data': json.dumps({'name': 'dura'}),
        'method': 'post'
    }
    dump_request(d)

# Generated at 2022-06-21 13:33:43.311513
# Unit test for function dump_request
def test_dump_request():
    data = [{'name': 'X', 'age': '20'}, {'name': 'Y', 'age': '30'}]

# Generated at 2022-06-21 13:33:49.525284
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace(
        json = True
        , data = {'test': 'key'}
        , method = 'get'
        , verify = 'yes'
        , max_redirects = 1
        , url = 'https://endpoint.com/v1/test'
        , timeout = 300
        , debug = True
        , headers = {'Content-Type': 'application/json'}
        , auth = 'none'
    )
    request_kwargs = make_request_kwargs(
        args,
        None
        , lambda chunk: chunk
    )

    dump_request(request_kwargs)

# Generated at 2022-06-21 13:34:00.668484
# Unit test for function collect_messages
def test_collect_messages():
    config_dir = Path('/Users/vivek/.httpie')

# Generated at 2022-06-21 13:34:03.147088
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    result = make_send_kwargs_mergeable_from_env()
    assert result.get('proxies') == {}
    assert result.get('stream') == True
    assert result.get('verify') == True
    assert result.get('cert') == None


# Generated at 2022-06-21 13:34:07.378193
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # TODO: implement better tests
    args = argparse.Namespace()
    args.verify = 'yes'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] is True

    args.verify = 'false'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] is False

    args.verify = 'random'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] == 'random'



# Generated at 2022-06-21 13:34:13.217905
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # pylint: disable=import-outside-toplevel
    from httpie.cli.parser import parser
    args = parser.parse_args('-p')
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {
        'http': 'http://http:http@proxy:3128',
        'https': 'https://https:https@proxy:3130',
    }


# Generated at 2022-06-21 13:34:18.620767
# Unit test for function finalize_headers
def test_finalize_headers():
    assert (finalize_headers(
        RequestHeadersDict({'Content-Type': 'application/json'})) ==
            RequestHeadersDict({'Content-Type': 'application/json'}))
    assert (finalize_headers(
        RequestHeadersDict({'Content-Type': 'application/json;'})) ==
            RequestHeadersDict({'Content-Type': 'application/json'}))
    assert (finalize_headers(
        RequestHeadersDict({'Content-Type': 'application/json \t'})) ==
            RequestHeadersDict({'Content-Type': 'application/json'}))

# Generated at 2022-06-21 13:36:50.735723
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, "TLSv1_0", "AES128-SHA")
    assert session, requests.Session

# Generated at 2022-06-21 13:36:53.131037
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    ssl = AVAILABLE_SSL_VERSION_ARG_MAPPING['TLSv1.3']
    assert ssl == ssl.__unique__()


# Generated at 2022-06-21 13:37:00.845409
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    url = "http://www.baidu.com"
    method = "GET"
    headers = {
        'User-Agent':DEFAULT_UA
    }
    params = []
    data = {}
    auth = None
    args = argparse.Namespace(method=method, url=url, headers=headers, data=data, params=params, auth=auth)
    result = make_request_kwargs(args)
    assert result["url"] == "http://www.baidu.com"
    assert result["method"] == "get"
    assert result["headers"] == headers
    assert result["params"] == []
    assert result["auth"] == None
    assert result["data"] == data

# Generated at 2022-06-21 13:37:06.560367
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = "yes"
    args.cert = "file.cert"
    args.cert_key = "file.cert.key"
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {}, 'stream': True, 'verify': True, 'cert': ('file.cert', 'file.cert.key')}
    # Test with different values
    args1 = argparse.Namespace()
    args1.proxy = []
    args1.verify = "no"
    args1.cert = "file.cert"
    args1.cert_key = "file.cert.key"

# Generated at 2022-06-21 13:37:09.624231
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 1000
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-21 13:37:15.061705
# Unit test for function max_headers
def test_max_headers():
    """
    https://docs.pytest.org/en/latest/example/simple.html#control-skipping-of-tests-according-to-command-line-option
    """
    import argparse
    args = argparse.Namespace(max_headers=1)
    with max_headers(args.max_headers):
        assert (http.client._MAXHEADERS == 1)

# Generated at 2022-06-21 13:37:22.861458
# Unit test for function make_default_headers
def test_make_default_headers():
    # First, test with json
    json_test_header = make_default_headers(argparse.Namespace(json=True))
    assert json_test_header['User-Agent'] == DEFAULT_UA
    assert json_test_header['Accept'] == JSON_ACCEPT
    assert json_test_header.get('Content-Type', None) == JSON_CONTENT_TYPE
    # Then, test with data and form
    data_form_test_header = make_default_headers(argparse.Namespace(data=[], form=True))
    assert data_form_test_header['User-Agent'] == DEFAULT_UA
    assert data_form_test_header['Accept'] == '*/*'
    assert data_form_test_header.get('Content-Type', None) == None # should be None
    # Then, test with data

# Generated at 2022-06-21 13:37:34.833716
# Unit test for function dump_request
def test_dump_request():
    with path(__file__).joinpath('dump_request.out').open('rb') as f:
        expected = f.read()
    output = io.BytesIO()
    with redirect_stdout(output):
        dump_request({
            'method': 'GET',
            'url': 'http://httpbin.org/',
            'headers': {
                'Accept-Encoding': 'gzip, deflate',
                'Accept': '*/*',
                'User-Agent': 'python-requests/2.20.0',
            },
            'auth': ('user', 'pass'),
            'params': [('foo', 'bar')],
            'files': {},
            'data': None,
            'json': None,
            'hooks': {},
        })
    assert output.getvalue() == expected




# Generated at 2022-06-21 13:37:36.683346
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(verify=False), requests.Session)


# Generated at 2022-06-21 13:37:39.996471
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert (
        ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') ==
        'http://foo/../?foo=bar'
    )

# Generated at 2022-06-21 13:39:26.839335
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
