

# Generated at 2022-06-21 13:29:55.382923
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:30:00.063216
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {"User-Agent": "HTTPie/0.9.9", "Accept-Encoding": "gzip, deflate",
               "Accept": "*/*", "Connection": "keep-alive"}
    final_headers = finalize_headers(headers)
    assert final_headers == {"User-Agent": "HTTPie/0.9.9", "Accept-Encoding": "gzip, deflate",
                             "Accept": "*/*", "Connection": "keep-alive"}

# Generated at 2022-06-21 13:30:06.105375
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=False,
        ssl_version='sslv2',
        ciphers='rc2-cbc-md5'
    )
    assert type(requests_session) == requests.Session
    import types
    assert isinstance(requests_session.mount, types.MethodType)
    assert isinstance(requests_session.send, types.MethodType)

# Generated at 2022-06-21 13:30:18.075581
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:30:20.589158
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(args=None) == {
        'allow_redirects': False,
        'timeout': None,
    }


# Generated at 2022-06-21 13:30:21.600447
# Unit test for function dump_request
def test_dump_request():
    print(dump_request({'url': 'www.google.com'}))

# Generated at 2022-06-21 13:30:23.853051
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'headers': {
            'Accept-Encoding': 'gzip, deflate'
        }
    }
    dump_request(kwargs)

# Generated at 2022-06-21 13:30:26.817257
# Unit test for function finalize_headers
def test_finalize_headers():
    h = RequestHeadersDict()
    h['X-DATA'] = '{"name":"João"}'
    final_h = finalize_headers(h)
    assert final_h['X-DATA'] == '{"name":"João"}'

# Generated at 2022-06-21 13:30:38.411837
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    args.url = "www.google.com"
    args.method = "GET"
    args.headers = {
        'User-Agent' : DEFAULT_UA,
    }
    args.auth = "admin:admin"
    args.json = False
    args.form = True
    args.timeout = 25
    args.data = None
    args.verify = False
    args.cert = "cert.pem"
    args.cert_key = "certkey.pem"
    args.proxy = {
        'http': "http://127.0.0.1:8080",
        'https': "https://127.0.0.1:8080",
    }
    kwargs = make_request_kwargs(args)

# Generated at 2022-06-21 13:30:42.327115
# Unit test for function finalize_headers
def test_finalize_headers():
    headers_dict = {'a':'aaaa\t', ' b ':'bbbb\t'}
    result = finalize_headers(headers_dict)
    assert result == {'a':b'aaaa', 'b':b'bbbb'}

# Generated at 2022-06-21 13:31:04.636639
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs({'timeout': 10}) == {'timeout': 10, 'allow_redirects': False}


# Generated at 2022-06-21 13:31:08.342636
# Unit test for function build_requests_session
def test_build_requests_session():
    from urllib3.connectionpool import HTTPConnectionPool

    assert isinstance(build_requests_session().adapters.get('https://'),
                      HTTPConnectionPool)



# Generated at 2022-06-21 13:31:15.986772
# Unit test for function make_default_headers
def test_make_default_headers():
    headers = make_default_headers(
        argparse.Namespace(
            json=True, data=True, form=True, files=True,
            verify='true', cert='/foo/cert.pem', cert_key='/foo/cert.key',
            auth=('user', 'password'),
            proxy=[argparse.Namespace(key='http', value='http://foo/')],
            timeout=30,
            headers=RequestHeadersDict(
                {'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
                 'User-Agent': 'HTTPie/0.9.9'})))
    if headers['Accept'] == JSON_ACCEPT:
        print(headers)
    else:
        print('Fail')

# Generated at 2022-06-21 13:31:18.213401
# Unit test for function dump_request
def test_dump_request():
    try:
        assert False
        dump_request({'a':'b'})
    except:
        assert True

# Generated at 2022-06-21 13:31:24.908552
# Unit test for function finalize_headers
def test_finalize_headers():
    try:
        from .test_sessions import main as test_sessions
        for args in test_sessions.ARGS:
            try:
                finalize_headers(make_default_headers(args))
            except:
                sys.stderr.write(f'\n>>> finalize_headers(make_default_headers(args))\n\n')
                raise
    except SystemExit as e:
        sys.exit(e)

# Generated at 2022-06-21 13:31:34.715559
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    eq_('http://foo/bar?foo=bar', ensure_path_as_is('http://foo/bar', 'http://foo/bar'))
    eq_('http://foo/bar?foo=bar', ensure_path_as_is('http://foo/bar', 'http://foo/bar?foo=bar'))
    eq_('http://foo/bar?foo=bar', ensure_path_as_is('http://foo/bar', 'http://foo/bar?foo=bar&bar=foo'))
    eq_('http://foo/bar?foo=bar&bar=foo', ensure_path_as_is('http://foo/bar', 'http://foo/bar?foo=bar&bar=foo&bar=bar'))

# Generated at 2022-06-21 13:31:39.501502
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    orig = "http://foo/../../bar/baz"
    prepped = "http://foo/?boom=bang"

    # Check
    assert(ensure_path_as_is(orig, prepped) == "http://foo/../../bar/baz?boom=bang")

# Generated at 2022-06-21 13:31:52.051341
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(headers={}, params={})
    args.auth = 'user:pass'
    args.base_url = None
    args.cert = '/path/to/cert'
    args.cert_key = None
    args.chunked = False
    args.debug = False
    args.download_rate = None
    args.files = None
    args.follow = False
    args.max_redirects = 30
    args.method = 'GET'
    args.multipart_data = None
    args.multipart = False
    args.offline = False
    args.timeout = 10
    args.url = 'https://httpbin.org/get'
    args.json = {}
    args.form = False
    args.data = None
    args.auth_plugin = None
   

# Generated at 2022-06-21 13:32:00.277825
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        auth='test_auth',
        cert='test_cert',
        cert_key='test_cert_key',
        chunked=True,
        data={'test_data':'test_data'},
        files={'test_files':'test_files'},
        form=True,
        headers={'test_header':'test_header'},
        json=True,
        method='test_method',
        multipart=True,
        params={'test_param':'test_param'},
        proxy={'test_proxy':'test_proxy'},
        timeout=10,
        url='test_url',
        verify='test_verify',
    )
    send_kwargs = make_send_kwargs(args)

# Generated at 2022-06-21 13:32:07.963800
# Unit test for function finalize_headers
def test_finalize_headers():
    test_dict1 = {'Content-Type': None}
    test_dict2 = {'Content-Type': ''}
    test_dict3 = {'Content-Type': 'application/json'}
    
    assert finalize_headers(test_dict1) == {'Content-Type': None}
    assert finalize_headers(test_dict2) == {'Content-Type': ''}
    assert finalize_headers(test_dict3) == {'Content-Type': 'application/json'}

# Generated at 2022-06-21 13:32:33.216625
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert get_max_headers() == 5
    assert get_max_headers() == 100


# Generated at 2022-06-21 13:32:39.039566
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'url': 'https://google.com',
        'method': 'GET',
        'headers': {
            'Accept': '*/*',
            'User-Agent': 'HTTPie/1.0.3'
        },
        'body': 'Hello World'
    }
    dump_request(kwargs)


# Generated at 2022-06-21 13:32:40.584476
# Unit test for function dump_request
def test_dump_request():
    from typing import Any
    from collections.abc import Mapping
    kwargs: Any = make_request_kwargs()

# Generated at 2022-06-21 13:32:44.371549
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {'a': 'b'}

    headers = make_default_headers(args)
    assert headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}

# Generated at 2022-06-21 13:32:53.205380
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    generic_url = 'https://httpie.org/foo/../bar?hello#bye'
    assert ensure_path_as_is(generic_url, generic_url) == generic_url
    assert ensure_path_as_is(generic_url+'%', generic_url) == generic_url
    assert ensure_path_as_is(generic_url+' ', generic_url) == generic_url
    assert ensure_path_as_is(generic_url+'+', generic_url) == generic_url
    assert ensure_path_as_is(generic_url+' ', generic_url) == generic_url
    assert ensure_path_as_is(generic_url+'+', generic_url) == generic_url
    assert ensure_path_as_is(generic_url+'.', generic_url) == generic_url

# Generated at 2022-06-21 13:32:57.920317
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    result = make_send_kwargs_mergeable_from_env(argparse.Namespace())
    print(result)
    # Unit test result
    # {'verify': True, 'proxies': {}}



# Generated at 2022-06-21 13:33:03.563399
# Unit test for function finalize_headers
def test_finalize_headers():
    header = RequestHeadersDict({'User-Agent': 'HTTPie/1.0.1',
                                 'Content-Type': 'application/json',
                                 'Date': ''})
    assert finalize_headers(header) == RequestHeadersDict({
        'User-Agent': 'HTTPie/1.0.1',
        'Content-Type': 'application/json',
        'Date': '',
    })

# Generated at 2022-06-21 13:33:08.801861
# Unit test for function dump_request
def test_dump_request():
    kwargs = {}
    kwargs["method"] = "GET"
    kwargs["url"] = "http://localhost"
    kwargs["headers"] = {"Hello":"World"}
    kwargs["data"] = 'data'
    kwargs["auth"] = ("admin", "pass")
    kwargs["params"] = [("page", "1")]
    assert dump_request(kwargs) == '\n>>> requests.request(**{\'method\': \'GET\', \'url\': \'http://localhost\', \'headers\': {\'Hello\': \'World\'}, \'data\': \'data\', \'auth\': (\'admin\', \'pass\'), \'params\': [(\'page\', \'1\')]})\n\n'

# Generated at 2022-06-21 13:33:12.816975
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = "yes"
    args.proxy = []
    args.cert = None
    args.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] is True

# Generated at 2022-06-21 13:33:14.818408
# Unit test for function dump_request
def test_dump_request():
    args = {'method': 'get',
            'url': 'myurl'
            }
    dump_request(args)


# Generated at 2022-06-21 13:33:44.659085
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA}
    args.json = True
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}
    args.data = True
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}
    args.json = False
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT}
    args.form = True

# Generated at 2022-06-21 13:33:48.540804
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path(".")
    messages = collect_messages(args,config_dir)
    print("The collected messages are ")
    for message in messages:
        print(message)

if __name__ == "__main__":
    test_collect_messages()

# Generated at 2022-06-21 13:33:50.704312
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert (
        ensure_path_as_is(
            orig_url='http://foo/../',
            prepped_url='http://foo/?foo=bar'
        ) == 'http://foo/../?foo=bar'
    )

# Generated at 2022-06-21 13:33:59.972374
# Unit test for function max_headers
def test_max_headers():
    import requests
    import http
    expected_headers = {
        'a': 'b',
        'c': 'd',
        'e': 'f'
    }
    expected_head_num = len(expected_headers)
    request_headers = [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h')]
    with max_headers(expected_head_num):
        r = requests.Request('GET', 'http://google.com/', headers=request_headers)
        assert r.headers == expected_headers
    assert http.client._MAXHEADERS == 100000



# Generated at 2022-06-21 13:34:05.630682
# Unit test for function make_default_headers
def test_make_default_headers():
    import argparse
    a = argparse.Namespace()
    a.json=False
    a.form=True
    a.data=None
    h = make_default_headers(a)
    assert h['Content-Type'] == 'application/x-www-form-urlencoded; charset=utf-8'
    a.form=False
    h = make_default_headers(a)
    assert h['Accept'] == 'application/json, */*;q=0.5'

    a.json=True
    a.data=dict()
    h = make_default_headers(a)
    assert h['Accept'] == 'application/json, */*;q=0.5'

# Generated at 2022-06-21 13:34:11.457358
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = False
    ssl_version = None
    ciphers = None
    requests_session = build_requests_session(
        verify=verify,
        ssl_version=ssl_version,
        ciphers=ciphers
    )
    # It should be a requests.Session object
    assert type(requests_session) == requests.Session



# Generated at 2022-06-21 13:34:18.241555
# Unit test for function finalize_headers
def test_finalize_headers():
    # test for items in headers
    assert finalize_headers({'key': '123'}) == {'key': '123'}
    # test for items not in headers
    assert finalize_headers({'key': '123', 'key_2': None}) == {'key': '123'}
    # test that the value is stripped
    assert finalize_headers({'key': ' 123'}) == {'key': '123'}
    assert finalize_headers({'key': '123 '}) == {'key': '123'}
    # test that the value is encoded to utf-8
    assert finalize_headers({'key': '123'})['key'] == b'123'

# Generated at 2022-06-21 13:34:20.919554
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert (ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar')

# Generated at 2022-06-21 13:34:28.647307
# Unit test for function finalize_headers
def test_finalize_headers():
    header = {
        'foo': ' bar ',
        'baz': '',
        'qux': None,
        'to': 'to@example.com',
        'cc': 'cc@example.com',
        'bcc': 'bcc@example.com',
    }
    expected = {
        b'foo': b'bar',
        b'baz': b'',
        b'to': b'to@example.com',
        b'cc': b'cc@example.com',
        b'bcc': b'bcc@example.com',
    }
    assert finalize_headers(header) == expected

# Generated at 2022-06-21 13:34:36.529618
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
    import shutil
    import tempfile
    from io import BytesIO
    from httpie.cli.parser import get_parser
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import Session
    from httpie.models import AUTH_REQUIRED
    from httpie.plugins.builtin import HEADERS

    def outputSendKW(*args, **kw):
        return kw["timeout"]

    def output(*args, **kw):
        return make_request_kwargs(*args, **kw)

    # Test case 1: no args added
    parser = get_parser()
    environment = Environment(stdin=BytesIO(), stdout=BytesIO(),
                              stderr=BytesIO())

# Generated at 2022-06-21 13:36:06.019865
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    with max_headers(0):
        assert http.client._MAXHEADERS == float('Inf')

# Generated at 2022-06-21 13:36:14.443438
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/bar', 'http://foo/baz?foo=bar') == 'http://foo/bar?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('https://foo/bar', 'https://foo/baz?foo=bar') == 'https://foo/bar?foo=bar'
    assert ensure_path_as_is('http://foo/bar', 'http://foo/bar') == 'http://foo/bar'
    assert ensure_path_as_is('http://foo/BAR', 'http://foo/bar') == 'http://foo/BAR'

# Generated at 2022-06-21 13:36:17.671832
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'method': 'get',
              'url': 'https://www.github.com',
              'headers': {},
              'data': 'data'}
    dump_request(kwargs)

# Generated at 2022-06-21 13:36:23.612533
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {"a":"b"}
    expected = {"a": "b"}
    assert finalize_headers(headers) == expected

    headers = {"a":None}
    expected = {}
    assert finalize_headers(headers) == expected

    headers = {"a":""}
    expected = {"a": ""}
    assert finalize_headers(headers) == expected

    headers = {"a":"  "}
    expected = {"a": ""}
    assert finalize_headers(headers) == expected

# Generated at 2022-06-21 13:36:33.523797
# Unit test for function collect_messages
def test_collect_messages():
    from requests import Request
    from httpie.utils import unicode
    from httpie.cli.dicts import RequestHeadersDict


# Generated at 2022-06-21 13:36:41.928046
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth, HTTPDigestAuth
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.transport.utils import load_module_from_file
    from httpie.cli import parser
    from httpie.config import Config
    from httpie.context import Environment
    config = Config(config_dir=None)
    env = Environment(config=config)

# Generated at 2022-06-21 13:36:50.808398
# Unit test for function collect_messages
def test_collect_messages():
    """
    Test function collect_messages
    """
    config_dir = Path("/Users/xinyi/Documents/GitHub/HTTPie")

# Generated at 2022-06-21 13:36:52.570920
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:37:01.456499
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:37:06.912509
# Unit test for function make_default_headers
def test_make_default_headers():
    args_json = argparse.Namespace(
        method = 'GET',
        json = True,
        data = {"first_name": "John", "last_name": "Doe"},
        form = False,
        files = None
    )
    default_headers = make_default_headers(args_json)
    assert default_headers == {
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    }
    args_form = argparse.Namespace(
        method = 'GET',
        json = False,
        data = None,
        form = True,
        files = None
    )
    default_headers = make_default_headers(args_form)

# Generated at 2022-06-21 13:38:04.190953
# Unit test for function collect_messages
def test_collect_messages():
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--method", help="The HTTP method to use.")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable the verbose output mode.")
    parser.add_argument("-h", "--headers", nargs='*', action="append", help="Extra headers to include in the request: 'Header: Value'",)
    parser.add_argument('-a', '--auth', help="The HTTP Basic Auth credentials.")

    args = parser.parse_args(["-m", "GET", "--verbose", "-h", "Header1: Value1", "-h", "Header2: Value2", "-a", "test:test"])


# Generated at 2022-06-21 13:38:12.297176
# Unit test for function make_send_kwargs

# Generated at 2022-06-21 13:38:20.463537
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class Args:
        def __init__(self):
            self.verbose = True
            self.debug = False
            self.traceback = False
            self.check_status = False
            self.headers = []
            self.auth = None
            self.auth_type = None
            self.auth_plugin = None
            self.follow = False
            self.max_redirects = 1
            self.method = 'GET'
            self.url = 'http://httpbin.org/get'
            self.params = []
            self.data = ''
            self.files = []
            self.form = False
            self.json = False
            self.compress = False
            self.compress_level = None
            self.timeout = 0.0
            self.verify = False
            self.cert = None


# Generated at 2022-06-21 13:38:24.255368
# Unit test for function max_headers
def test_max_headers():
    max_headers_value = 20
    sys.stderr.write(
        f'\n>>> requests.request(**{max_headers_value})\n\n')
    # print(
    #     f'\n>>> requests.request(**{max_headers_value})\n\n')

# Generated at 2022-06-21 13:38:33.780434
# Unit test for function collect_messages
def test_collect_messages():
    #test the source code from httpie/downloads.py to test the functions
    import io
    import os
    import requests
    import httpie.downloads as download
    # set the values for args

# Generated at 2022-06-21 13:38:37.291553
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    kwargs = {
        'method': 'post',
        'url': 'http://baidu.com',
        'headers': {'User-Agent': 'Python/3.6', 'Content-Type': 'application/json'},
        'data': {"a": "b"},
        'auth': ('user', 'passwd'),
        'params': {'name': 'jason', 'age':18},
    }
    dump_request(kwargs)


if __name__ == '__main__':
    test_dump_request()

# Generated at 2022-06-21 13:38:37.862503
# Unit test for function collect_messages
def test_collect_messages():
    assert 1 == 1

# Generated at 2022-06-21 13:38:42.741644
# Unit test for function dump_request
def test_dump_request():
    test_dict = {
        'method':'POST',
        'url': 'http://api.httpbin.org',
        'headers': {'User-Agent':'HTTPie/0.9.9', 'Accept':'application/json-home'},
        'data': 'somedata'
    }
    dump_request(test_dict)


# Generated at 2022-06-21 13:38:49.196129
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import requests
    import json
    # TODO: find a way to load kwargs from CLI
    kwargs = make_request_kwargs(
        # args,
        base_headers=RequestHeadersDict({
            'User-Agent': DEFAULT_UA
        }),
        # request_body_read_callback=lambda chunk: chunk
    )
    # print(kwargs)
    # print(requests.request(**kwargs))

# Generated at 2022-06-21 13:38:50.785614
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session(False, None, None)) == requests.Session