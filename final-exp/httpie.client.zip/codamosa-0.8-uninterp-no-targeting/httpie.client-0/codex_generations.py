

# Generated at 2022-06-21 13:29:59.875517
# Unit test for function dump_request
def test_dump_request():
    args = None
    try:
        import pytest
        pytest.skip("Tests the dump_request function")
    except ModuleNotFoundError:
        pass
    kwargs = {"url":"http://127.0.0.1", "method":"get",
              "data":"hello world", "headers":{}}
    dump_request(kwargs)

# Generated at 2022-06-21 13:30:05.086513
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = None
    args.json = False
    args.form = False
    args.files = False
    default_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    headers = make_default_headers(args)
    assert headers == default_headers

# Generated at 2022-06-21 13:30:14.339120
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        proxy = [Proxy('http', 'http://127.0.0.1:8080', 'http://127.0.0.1:8080'), Proxy('https', 'http://127.0.0.1:8080', 'http://127.0.0.1:8080')],
        cert = "test_cert",
        cert_key = "test_cert_key",
        verify = "test_verify"
    )
    res = make_send_kwargs_mergeable_from_env(args)
    print(res)


# Generated at 2022-06-21 13:30:18.841646
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout = 10,
        allow_redirects = True,
        )
    result = make_send_kwargs(args)
    assert result == {
        'timeout': 10,
        'allow_redirects': True,
        }


# Generated at 2022-06-21 13:30:20.501426
# Unit test for function dump_request
def test_dump_request():
    assert dump_request(kwargs={"arg1": "1", "arg2": "2"}) == None

# Generated at 2022-06-21 13:30:24.469896
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(verify=True)
    assert isinstance(requests_session, requests.Session)
    assert isinstance(requests_session.adapters['http://'], requests.adapters.HTTPAdapter)
    assert isinstance(requests_session.adapters['https://'], HTTPieHTTPSAdapter)


# Generated at 2022-06-21 13:30:29.375041
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    args.proxy = [Proxy(key='http', value='http://127.0.0.1:3128'), Proxy(key='https', value='http://127.0.0.1:3128')]
    args.stream = True
    args.verify = True
    args.cert = None
    kwargs = make_send_kwargs(args)
    print(kwargs)


# Generated at 2022-06-21 13:30:41.495802
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:30:51.218529
# Unit test for function collect_messages
def test_collect_messages():
    __builtins__.__dict__['ARGS'] = None
    __builtins__.__dict__['CONFIG_DIR'] = None
    __builtins__.__dict__['KWARGS'] = None


    class test_args:
        class ciphers:
            def __init__(self):
                self.value = 'test_ciphers'
        class method:
            def __init__(self):
                self.value = 'test_method'
        class url:
            def __init__(self):
                self.value = 'test_url'
        class auth:
            def __init__(self):
                self.value = 'test_auth'
        class headers:
            def __init__(self):
                self.value = 'test_headers'

# Generated at 2022-06-21 13:30:54.890952
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'

    kwargs = make_send_kwargs_mergeable_from_env(args)

    expected_kwargs = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': 'cert',
        'cert_key': 'cert_key'
    }
    assert expected_kwargs == kwargs

# Generated at 2022-06-21 13:31:26.642233
# Unit test for function finalize_headers
def test_finalize_headers():
    test_headers = {'content-type': 'application/json', 'key': 'value'}
    result = finalize_headers(test_headers)
    if result['content-type'] == 'application/json' and result['key'] == 'value':
        print("Unit test passed")
    else:
        print("Unit test failed")



# Generated at 2022-06-21 13:31:36.182738
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    # 1.1) Test simple URL, without path
    assert ensure_path_as_is('http://foo', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    # 1.2) Test URL with path
    assert ensure_path_as_is('http://foo/bar/', 'http://foo/?foo=bar') == 'http://foo/bar/?foo=bar'
    # 2) Test URL with path. path is no modified
    assert ensure_path_as_is('http://foo/bar', 'http://foo/?foo=bar') == 'http://foo/bar?foo=bar'
    # 3) Test URL with path. path is modified
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:31:39.985978
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(args = argparse.Namespace(json = False, form = False, data = False, headers = False, files = False)) == {'User-Agent': DEFAULT_UA}


# Generated at 2022-06-21 13:31:43.157964
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert 'http://foo/../?foo=bar' == ensure_path_as_is('http://foo/../',
                                                         'http://foo/?foo=bar')

# Generated at 2022-06-21 13:31:43.960807
# Unit test for function dump_request
def test_dump_request():
    pass

# Generated at 2022-06-21 13:31:48.714865
# Unit test for function max_headers
def test_max_headers():
    """
    Tests the max_headers function.
    """
    limit = 10
    with max_headers(limit) as header_limit:
        header_count = http.client._MAXHEADERS

    assert header_count == limit, "header count should be equal to limit"



# Generated at 2022-06-21 13:31:58.575553
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie.cli.parser import parse_args
    args = parse_args(["--json", "--method", "POST", "--auth-type", "basic", "--auth", "foo:bar", "https://www.example.com"])
    args.data = {"hello": "world"}
    kwargs = make_request_kwargs(args)
    assert kwargs == {'method': 'post', 'url': 'https://www.example.com', 'headers': RequestHeadersDict({'Content-Type': 'application/json', 'Accept': 'application/json, */*;q=0.5', 'User-Agent': 'HTTPie/1.0.0'}), 'data': b'{"hello": "world"}', 'auth': ('basic', 'foo', 'bar'), 'params': []}

# Generated at 2022-06-21 13:32:10.807514
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.headers = []
    args.json = False
    args.form = {}
    args.files = {}
    args.data = {}
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': 'HTTPie/0.9.8.dev0'}
    args.json = True
    args.data = {'name': 'foo'}
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': 'HTTPie/0.9.8.dev0', 'Content-Type': 'application/json', 'Accept': 'application/json, */*;q=0.5'}
    args.data = {}
    args.json = False

# Generated at 2022-06-21 13:32:16.112886
# Unit test for function make_default_headers
def test_make_default_headers():
    from httpie.cli import parser
    
    args = parser.parse_args(['-f'])
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    assert default_headers['Accept'] == JSON_ACCEPT

# Generated at 2022-06-21 13:32:20.466147
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({'User-Agent': 'HTTPie/0.9.6'})
    final_headers = finalize_headers(headers)
    assert final_headers['User-Agent'] == 'HTTPie/0.9.6'

# Generated at 2022-06-21 13:33:03.185218
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests

    def transport_plugin_simple():
        from httpie.plugins import TransportPlugin
        class TransportPluginSimple(TransportPlugin):
            prefix = 'simple'
            def get_adapter(self):
                return TestHTTPAdapter()

        return TransportPluginSimple()

    class TestHTTPAdapter(requests.adapters.HTTPAdapter):
        pass

    plugin_manager.register_plugin(transport_plugin_simple())

    ssl_version = None
    ciphers = 'AES128-SHA'
    verify = False
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=verify
    )
    assert isinstance(requests_session.adapters['https://'], HTTPieHTTPSAdapter)

# Generated at 2022-06-21 13:33:07.115724
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    args.url = 'https://www.google.com'
    args.headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    kwargs = make_request_kwargs(args)
    dump_request(kwargs)

# Generated at 2022-06-21 13:33:12.279612
# Unit test for function max_headers
def test_max_headers():
    from unittest import mock
    import http
    # override the sys.stderr for testing
    with mock.patch.object(sys, 'stderr', open('test_max_headers.txt', 'w')) as mocked_stderr:
        mocked_stderr.write('Test the max_headers\n')
        with max_headers(100):
            assert http._MAXHEADERS == 100
        with max_headers(0):
            assert http._MAXHEADERS == float('Inf')
        with max_headers(5):
            assert http._MAXHEADERS == float('Inf')

# Generated at 2022-06-21 13:33:19.775043
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Content-Type': '  text/html; charset=utf-8  '}
    finalize_headers(headers)
    assert headers == {'Content-Type': 'text/html; charset=utf-8'}
    headers = {'Content-Type': '  text/html; charset=utf-8  ', 'Foo': None}
    finalize_headers(headers)
    assert headers == {'Content-Type': 'text/html; charset=utf-8'}



# Generated at 2022-06-21 13:33:28.694590
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    assert {'User-Agent': DEFAULT_UA} == make_default_headers(args)
    args = argparse.Namespace(json=True)
    assert {'Accept': JSON_ACCEPT,
            'Content-Type': JSON_CONTENT_TYPE,
            'User-Agent': DEFAULT_UA
            } == make_default_headers(args)
    args = argparse.Namespace(data='{}')
    assert {'Accept': JSON_ACCEPT,
            'Content-Type': JSON_CONTENT_TYPE,
            'User-Agent': DEFAULT_UA
            } == make_default_headers(args)
    args = argparse.Namespace(data='{}', json=False)

# Generated at 2022-06-21 13:33:37.924892
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data="foo=42",
        form=False,
        json=False,
        files={}
    )

    expected_headers = {
        'User-Agent': DEFAULT_UA,
        'Content-Type': FORM_CONTENT_TYPE
    }

    headers = make_default_headers(args)
    assert headers == expected_headers

    args = argparse.Namespace(
        data="",
        form=False,
        json=True,
        files={}
    )

    expected_headers = {
        'User-Agent': DEFAULT_UA,
        'Content-Type': JSON_CONTENT_TYPE,
        'Accept': JSON_ACCEPT
    }

    headers = make_default_headers(args)
    assert headers == expected_headers

# Generated at 2022-06-21 13:33:47.376051
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse

    obj = argparse.Namespace()
    obj.url = "https://httpbin.org/post"
    obj.method = "POST"
    obj.data = "{\"foo\": \"bar\"}"
    obj.form = False
    obj.json = False
    obj.files = []
    obj.headers = {"Accept": "application/json"}
    obj.auth = None
    obj.params = []
    obj.verify = "yes"
    obj.timeout = None
    obj.cert = None
    obj.cert_key = None
    obj.proxy = []
    obj.cookie = []
    obj.session = None
    obj.session_read_only = None
    obj.max_redirects = 30
    obj.follow = False
    obj.max_headers = None
    obj.comp

# Generated at 2022-06-21 13:33:51.886631
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../?foo=bar', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../?foo=bar', 'http://foo/../?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:34:01.070922
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify', default='yes')
    parser.add_argument('--cert', default=None)
    parser.add_argument('--cert-key', default=None)
    parser.add_argument('--proxy', default=[])    
    args = parser.parse_args()

    result = make_send_kwargs_mergeable_from_env(args)
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    test_make_send_kwargs_mergeable_from_env()

# Generated at 2022-06-21 13:34:04.089762
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = None
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept']=="application/json, */*;q=0.5"
    assert default_headers['Content-Type']==None

# Generated at 2022-06-21 13:35:27.666318
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    from pprint import pprint
    from httpie.cli.argtypes import KeyValueArg
    args = argparse.Namespace()
    args.method = "get"
    args.url = "http://www.example.com"
    args.headers = KeyValueArg(items=[("foo", "bar")])
    args.data = KeyValueArg(items=[("foo", "bar")])

    kwargs = make_request_kwargs(
        args=args,
        base_headers=RequestHeadersDict(),
        request_body_read_callback=lambda chunk: chunk
    )
    pprint(kwargs)


if __name__ == "__main__":
    test_make_request_kwargs()

# Generated at 2022-06-21 13:35:33.451259
# Unit test for function max_headers
def test_max_headers():
    import http.client
    from httpie.utils import max_headers
    print(http.client._MAXHEADERS)
    with max_headers(None):
        print(http.client._MAXHEADERS)
    with max_headers(1):
        print(http.client._MAXHEADERS)
    with max_headers(2):
        print(http.client._MAXHEADERS)
    print(http.client._MAXHEADERS)

# Generated at 2022-06-21 13:35:42.753255
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.cert = []
    args.verify = 'yes'
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

    args = argparse.Namespace()
    args.proxy = ['https://test.test']
    args.cert = []
    args.verify = False
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {'https': 'https://test.test'}, 'stream': True, 'verify': False, 'cert': None}

    args = argparse.Namespace()
    args.proxy = []
    args.cert = ['yes']
   

# Generated at 2022-06-21 13:35:45.211529
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 100
    with max_headers(500):
        assert http.client._MAXHEADERS == 500
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-21 13:35:46.839548
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(argparse.Namespace()) == {
        'timeout': None,
        'allow_redirects': False
    }


# Generated at 2022-06-21 13:35:50.733005
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=3, allow_redirects=False)
    args.proxy = lambda: url
    expected = {
        'timeout': 3,
        'allow_redirects': False,
    }
    assert make_send_kwargs(args) == expected

# Generated at 2022-06-21 13:35:57.433858
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Host': 'www.baidu.com',
               '                                           Accept': '                                                    text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'}
    headers = finalize_headers(headers)
    assert(headers['Host'] == 'www.baidu.com')
    assert(headers['Accept'] == 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')

# Generated at 2022-06-21 13:36:00.245168
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(
        'http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:36:01.326871
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(5)

# Generated at 2022-06-21 13:36:05.505245
# Unit test for function make_default_headers
def test_make_default_headers():
    from mock import Mock

    from httpie.core import main
    args_test = Mock()
    args_test.json = False
    args_test.form = False
    args_test.data = False
    args_test.files = False
    args_test.headers = Mock()
    default_headers = make_default_headers(args_test)
    assert default_headers['Content-Type'] == 'application/json'
    assert default_headers['Accept'] == 'application/json, */*;q=0.5'
    assert default_headers['User-Agent'] == 'HTTPie/0.9.8'

# Generated at 2022-06-21 13:38:51.274680
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=[], cert=None, cert_key=None, verify=None)

    kwargs = make_send_kwargs_mergeable_from_env(args)

    assert kwargs['proxies'] == {}
    assert kwargs['verify'] is None
    assert kwargs['cert'] is None


# Generated at 2022-06-21 13:38:54.104504
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    kwargs = make_send_kwargs(args = argparse.Namespace(timeout = None))
    assert kwargs["timeout"] == None
    assert kwargs["allow_redirects"] == False


# Generated at 2022-06-21 13:38:56.876290
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'method': 'POST', 'url': 'https://www.interviewbuddy.com', 'headers': {'Host': 'www.google.com', 'Content-Type': 'application/json'}}
    dump_request(kwargs)

# Generated at 2022-06-21 13:39:01.192623
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = make_default_headers(argparse.Namespace())
    headers['Accept'] = 'application/json,'
    final_headers = finalize_headers(headers)
    assert final_headers['Accept'] == 'application/json'

# Generated at 2022-06-21 13:39:07.033502
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # a new argument verify is added to make_default_headers in version 1.0.2
    args = argparse.Namespace()
    args.verify = 'yes'
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }

# Generated at 2022-06-21 13:39:12.406886
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "POST"
    args.form = False
    args.url = "http://0.0.0.0:8001/api/v1/users"
    args.headers = {}
    args.data = {
        "email": "test4@gmail.com",
        "username": "test4",
        "password": "test4"
    }
    request_kwargs = make_request_kwargs(args)
    print(request_kwargs)

# Generated at 2022-06-21 13:39:14.414280
# Unit test for function max_headers
def test_max_headers():
    class A():
        a = None
    a = A()
    assert a.a == None
    with max_headers(limit=10):
        assert a.a == 10
        a.a = None
    assert a.a == None
    a.a = None


# Generated at 2022-06-21 13:39:18.426593
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from mock import Mock

# Generated at 2022-06-21 13:39:28.027564
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []

    args.verify = True
    assert make_send_kwargs_mergeable_from_env(args)['verify'] is True
    args.verify = False
    assert make_send_kwargs_mergeable_from_env(args)['verify'] is False

    args.verify = 'yes'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] is True
    args.verify = 'no'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] is False

    args.verify = 'true'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] is True