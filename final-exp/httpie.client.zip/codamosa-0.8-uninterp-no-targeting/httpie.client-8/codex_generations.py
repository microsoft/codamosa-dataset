

# Generated at 2022-06-21 13:30:07.331693
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = None
    args.verify = 'C:/Users/user/Desktop/code/httpie/httpie/cacert.pem'
    args.cert = 'C:/Users/user/Desktop/code/httpie/httpie/cacert.pem'
    args.cert_key = None
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['verify'] == 'C:/Users/user/Desktop/code/httpie/httpie/cacert.pem'
    assert send_kwargs_mergeable_from_env['proxies'] == {}
    assert send_kwargs_mergeable_from_env

# Generated at 2022-06-21 13:30:19.217249
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:30:23.303123
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert 'http://foo/../?foo=bar' == ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')
    assert 'http://foo/../%22?foo=bar' == ensure_path_as_is('http://foo/../%22', 'http://foo/?foo=bar')

# Generated at 2022-06-21 13:30:26.435404
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=0.5, allow_redirects=False)
    kwargs = make_send_kwargs(args)
    assert(kwargs['timeout'] == 0.5)


# Generated at 2022-06-21 13:30:33.363359
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace(method='GET', url='http://localhost:3000/')
    config_dir = Path(__file__).parent
    kwargs = make_request_kwargs(args)
    requests_session = build_requests_session(verify=False)
    request = requests.Request(**kwargs)
    prepared_request = requests_session.prepare_request(request)
    assert prepared_request.url == 'http://localhost:3000/'

# Generated at 2022-06-21 13:30:40.023407
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        "method": "POST",
        "url": "http://host.com:6613",
        "headers": {
            "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
        },
        "data": "a=1&b=2"
    }
    dump_request(kwargs)


# Generated at 2022-06-21 13:30:50.237126
# Unit test for function make_default_headers
def test_make_default_headers():
    a = argparse.Namespace()
    a.json = False
    a.form = False
    a.data = dict({'key1':'value1'})
    kwargs = make_default_headers(a)
    assert kwargs['User-Agent'] == DEFAULT_UA
    assert str(kwargs) == "{'User-Agent': b'HTTPie/0.9.9'}"
    a.json = True
    kwargs = make_default_headers(a)
    assert kwargs['User-Agent'] == DEFAULT_UA
    assert str(kwargs) == "{'User-Agent': b'HTTPie/0.9.9', 'Accept': b'application/json, */*;q=0.5', 'Content-Type': b'application/json'}"
    a.form = True
   

# Generated at 2022-06-21 13:30:53.795868
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({'key': 'value'}) == {b'key': b'value'}
    assert finalize_headers({'key': ' '}) == {b'key': b''}
    assert finalize_headers({'key': '  '}) == {b'key': b''}
    assert finalize_headers({'key': ' \t '}) == {b'key': b''}
    assert finalize_headers({'key': '\tvalue\t'}) == {b'key': b'value'}

# Generated at 2022-06-21 13:30:56.904836
# Unit test for function dump_request
def test_dump_request():
    kwargs = {}
    kwargs['url'] = 'some_url'
    kwargs['method'] = 'get'
    dump_request(kwargs)

# Generated at 2022-06-21 13:31:09.535202
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(url="https://www.google.com/", method="GET", headers={"key1": "value1", "key2": "value2"}, data="TEST_DATA", json=True, form=False, files=False)
    args.auth = None
    args.auth_plugin = None
    args.auth_str = ""
    args.auth_type = ""
    args.body = ""
    args.compress = 0
    args.debug = False
    args.download = False
    args.files_require_filenames = True
    args.follow = False
    args.max_headers = None
    args.max_redirects = 30
    args.multipart_data = []
    args.multipart = False
    args.offline = False
    args.params = []

# Generated at 2022-06-21 13:31:31.246821
# Unit test for function dump_request
def test_dump_request():
    assert dump_request({'method': 'GET', 'url': 'https://httpie.org/'}) == \
           '\n>>> requests.request(**{\'method\': \'GET\', \'url\': \'https://httpie.org/\'})\n\n'

# Generated at 2022-06-21 13:31:39.301854
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy = [{"key":"http://192.168.1.1","value":"192.168.1.1"},
    {"key":"https://192.168.1.1","value":"192.168.1.1"}],verify=True, cert=None, cert_key=None)
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert(kwargs["verify"] == True)



# Generated at 2022-06-21 13:31:43.631453
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'method': 'GET', 'url': 'https://example.com', 'headers': {'User-Agent': 'HTTPie/0.9.9'}}
    dump_request(kwargs)
    assert True


# Generated at 2022-06-21 13:31:47.958466
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = "test"
    assert make_default_headers(args) == RequestHeadersDict({'User-Agent': DEFAULT_UA})

    args.json = False
    args.form = True
    args.data = "test"
    assert make_default_headers(args)== RequestHeadersDict({'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE})

    args.json = True
    args.form = True
    args.data = "test"
    assert make_default_headers(args) == RequestHeadersDict({'User-Agent': DEFAULT_UA, 'Content-Type': JSON_CONTENT_TYPE, 'Accept': JSON_ACCEPT})

    args.json

# Generated at 2022-06-21 13:31:50.982899
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': '  HTTPie/0.9.9\n   '
    })
    final_headers = finalize_headers(headers)
    print(final_headers)

    # Test if header is modified or not
    if final_headers['User-Agent'] != 'HTTPie/0.9.9':
        sys.exit(1)


if __name__ == '__main__':
    test_finalize_headers()
    exit(0)

# Generated at 2022-06-21 13:31:58.718915
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': '  HTTPie/0.9.2 ',
        'Accept': '  application/json , */* ;q = 0.5 '
    })
    headers = finalize_headers(headers)
    assert headers == RequestHeadersDict({
        'User-Agent': 'HTTPie/0.9.2',
        'Accept': 'application/json, */*;q=0.5'
    })
    assert headers['User-Agent'] == b'HTTPie/0.9.2'
    assert headers['Accept'] == b'application/json, */*;q=0.5'



# Generated at 2022-06-21 13:32:04.381082
# Unit test for function max_headers
def test_max_headers():
    limit = 8
    with max_headers(limit):
        assert http.client._MAXHEADERS == 8
    assert http.client._MAXHEADERS == 8
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')
    assert http.client._MAXHEADERS == 8

# Generated at 2022-06-21 13:32:14.410171
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = ""
    args.url = "https://www.google.com"
    args.headers = {}
    args.json = False
    args.data = {}
    args.form = False
    args.files = {}
    args.auth = None
    args.params = {}
    args.verify = False
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.offline = False
    args.ssl_version = ""
    args.compress = False
    args.chunked = False
    args.path_as_is = False
    args.max_headers = False
    args.ciphers = ""
    args.session = ""
    args.session_read_only

# Generated at 2022-06-21 13:32:16.794089
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:32:18.689380
# Unit test for function dump_request
def test_dump_request():
    kwargs = dict(method='GET', url='http://example.com')
    dump_request(kwargs)

# Generated at 2022-06-21 13:32:44.783768
# Unit test for function build_requests_session

# Generated at 2022-06-21 13:32:51.443844
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(argparse.Namespace(data={}, form=False, json=True)) == {
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    }

    assert make_default_headers(argparse.Namespace(data={}, form=False)) == {
        'User-Agent': DEFAULT_UA,
    }

    assert make_default_headers(argparse.Namespace(data={}, form=True)) == {
        'User-Agent': DEFAULT_UA,
        'Content-Type': FORM_CONTENT_TYPE,
    }

# Generated at 2022-06-21 13:32:58.994622
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import unittest
    class Test_make_send_kwargs(unittest.TestCase):
        def test_make_send_kwargs(self):
            self.assertEqual(
                make_send_kwargs(
                    (argparse.Namespace(timeout=None))
                ),
                {
                    'timeout': None,
                    'allow_redirects': False,
                }
            )

    unittest.main()

# Generated at 2022-06-21 13:33:08.272806
# Unit test for function collect_messages

# Generated at 2022-06-21 13:33:09.346547
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(verify=False)

# Generated at 2022-06-21 13:33:15.946684
# Unit test for function make_default_headers
def test_make_default_headers():
    import json
    from httpie.cli.parser import parser
    args = parser.parse_args(['-j', 'GET', '--json', 'http://httpbin.org/get'])
    actual_output = make_default_headers(args)
    expected_output = {
        'User-Agent': 'HTTPie/1.0.3',
        'Accept': 'application/json, */*;q=0.5',
        'Content-Type': 'application/json'
    }
    assert actual_output == expected_output

# Generated at 2022-06-21 13:33:20.095288
# Unit test for function make_default_headers
def test_make_default_headers():
    try:
        assert make_default_headers(args=None) == {'User-Agent': DEFAULT_UA}
    except AssertionError:
        return False
    else:
        return True


# Generated at 2022-06-21 13:33:28.184616
# Unit test for function collect_messages
def test_collect_messages():
    data = {
        'method': 'GET',
        'url': 'http://httpbin.org/',
        'data': {'key': 'value'},
        'headers': ['foo:bar'],
        'timeout': 100,
        'json': True,
        'verify': 'true',
        'cert': 'path/to/file'
    }

    args = argparse.Namespace(**data)
    config_dir = Path(__file__).parent.parent / 'httpie'
    response = collect_messages(args, config_dir)

    assert next(response)
    assert next(response).json()['origin'] == '127.0.0.1'


# Generated at 2022-06-21 13:33:32.344905
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert(http.client._MAXHEADERS==5)
        with max_headers(3):
            assert(http.client._MAXHEADERS==3)
        assert(http.client._MAXHEADERS==5)
    assert(http.client._MAXHEADERS==1000)

# Generated at 2022-06-21 13:33:39.450040
# Unit test for function collect_messages
def test_collect_messages():
    args = [1,2,3]
    config_dir = [1,2,3]
    request_body_read_callback = [1,2,3]
    result = collect_messages(args,config_dir,request_body_read_callback)
#     assert result == []
    
    
    
    
    
    
    



# Generated at 2022-06-21 13:34:00.836110
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli import parser

    args = parser.parse_args(['--offline', '-v', 'http://example.org'])
    messages = list(collect_messages(args))
    assert len(messages) == 2
    assert isinstance(messages[0], requests.PreparedRequest)
    assert isinstance(messages[1], requests.Response)

# Generated at 2022-06-21 13:34:01.690321
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(2)

# Generated at 2022-06-21 13:34:03.918254
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:34:12.780574
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    # test that the path is replaced by the final path
    assert ensure_path_as_is("http://foo/../", "http://foo/?foo=bar") == "http://foo/../?foo=bar"
    # test that the host is the same, even though it may have been manipulated
    assert ensure_path_as_is("http://foo/../", "http://foo/./?foo=bar") == "http://foo/./?foo=bar"
    # test that query strings and fragments remain unchanged
    assert ensure_path_as_is("http://foo/../", "http://foo/./?foo=bar#frag") == "http://foo/./?foo=bar#frag"

# Generated at 2022-06-21 13:34:15.784344
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = True
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] is True


# Generated at 2022-06-21 13:34:20.764181
# Unit test for function dump_request
def test_dump_request():
    kwargs = {}
    kwargs['method'] = 'GET'
    kwargs['url'] = 'http://www.baidu.com'
    kwargs['data'] = 'test'
    kwargs['headers'] = {'User-Agent': 'python-httpie'}
    dump_request(kwargs)



# Generated at 2022-06-21 13:34:24.520780
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Content-Type': '   application/json;charset:utf-8'}
    assert finalize_headers(headers) == {'Content-Type': 'application/json'}

if __name__ == "__main__":
    # Unit test for function finalize_headers
    test_finalize_headers()

# Generated at 2022-06-21 13:34:32.024360
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    #testing on time out
    args = argparse.Namespace(timeout=10)
    assert make_send_kwargs(args) == {'timeout': 10, 'allow_redirects': False}, "time out testing for make_send_kwargs"

    #testing on allow redirects
    args = argparse.Namespace(allow_redirects = True)
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': True}, "allow redirects testing for make_send_kwargs"


# Generated at 2022-06-21 13:34:33.780730
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:34:38.100173
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'name ': 'a', 'name  ': 'a', 'f': 'g'}
    final_headers = finalize_headers(headers)
    assert (final_headers['name'] == b'a')
    assert (final_headers['f'] == b'g')

# Generated at 2022-06-21 13:35:13.088006
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace
    args.url = 'https://www.google.com'
    args.data, args.form, args.json = [], [], [{}]
    args.method = 'GET'
    args.headers = {}
    args.auth = {'foo': 'shmoo'}
    args.params = {}
    kwargs = make_request_kwargs(args=args)
    assert(kwargs['params'] == ())
    assert(kwargs['auth'] == {'foo': 'shmoo'})
    assert(kwargs['data'] == '{}')
    assert(kwargs['method'] == 'get')
    assert(kwargs['url'] == 'https://www.google.com')

# Generated at 2022-06-21 13:35:17.139295
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()

    args.data = None
    args.json = False
    args.form = False
    args.headers = []

    result = make_default_headers(args)['User-Agent']
    assert result == f'HTTPie/{__version__}'



# Generated at 2022-06-21 13:35:27.546953
# Unit test for function make_request_kwargs
def test_make_request_kwargs():

    # Test case for request with json data
    args = argparse.Namespace()
    args.method = 'get'
    args.headers = {}
    args.auth = None
    args.url = 'http://google.com'
    args.data = {'hello': 'world'}
    args.json = True
    args.form = False
    args.chunked = False
    args.offline = False
    args.compress = False
    args.compress_level = None
    args.all = False
    args.follow = False
    args.max_redirects = 10
    args.max_headers = None
    args.session = None
    args.session_read_only = None
    args.verify = False
    args.proxy = None
    args.files = None
    args.params = {}

# Generated at 2022-06-21 13:35:31.590894
# Unit test for function make_default_headers
def test_make_default_headers():
    expected_result = {'User-Agent': DEFAULT_UA}
    args = argparse.Namespace(data='{"data": "value"}', form=False, json=False, files=False)
    assert(make_default_headers(args)==expected_result)


# Generated at 2022-06-21 13:35:37.009673
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    args = argparse.Namespace()
    args.form = True
    args.files = "/data/charmander.jpg"

    request_kwargs = make_request_kwargs(args)
    print(request_kwargs)
    #print(request_kwargs['method'])



if __name__ == '__main__':
    test_make_request_kwargs()

# Generated at 2022-06-21 13:35:45.683073
# Unit test for function make_default_headers
def test_make_default_headers():
    def test(args, expected_headers):
        assert make_default_headers(args) == RequestHeadersDict(expected_headers)

    test({'json': True, 'data': True}, {'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json', 'User-Agent': 'HTTPie/' + __version__})
    test({'json': True, 'data': {}}, {'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json', 'User-Agent': 'HTTPie/' + __version__})
    test({'json': False, 'data': {}}, {'User-Agent': 'HTTPie/' + __version__})

# Generated at 2022-06-21 13:35:53.442885
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    proxy = [
        argparse.Namespace(
            key=key,
            value=value,
        ) for key, value in [
            ('http', 'http://user:pass@proxy.example.com:8080/'),
            ('https', 'https://user:pass@proxy.example.com:8080/'),
        ]
    ]
    cert = "./test_cert.crt"
    cert_key = "./test_cert_key.key"
    args = argparse.Namespace(
        proxy=proxy,
        verify='no',
        cert=cert,
        cert_key=cert_key,
    )


# Generated at 2022-06-21 13:35:56.693854
# Unit test for function dump_request
def test_dump_request():
    class DummyArgs(object):
        def __init__(self, url):
            self.url = url
    dummy_args = DummyArgs('https://www.google.com')
    kwargs = {'method': 'get',
              'url':dummy_args.url,
              'headers':{},
              'data':''}
    dump_request(kwargs)

# Generated at 2022-06-21 13:36:07.248559
# Unit test for function make_default_headers
def test_make_default_headers():
    # simulate args with json option
    class Args:
        json = True
    args = Args()
    # make_default_headers should return a dict with 'Accept' and 'Content-Type'
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    # simulate args with form option
    class Args:
        json = False
        form = True
    args = Args()
    headers = make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE
    # simulate args with files option
    class Args:
        json = False
        form = True
        files = True
    args = Args()
    headers = make_default_headers(args)

# Generated at 2022-06-21 13:36:15.126217
# Unit test for function max_headers
def test_max_headers():
    from httpie.client import httpie_session
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.output.streams import CACHED_STDERR, CACHED_STDOUT
    from httpie.plugins.registry import plugin_manager
    from tests.utils import override_config_dir
    import httpie.cli
    from httpie.compat import is_windows
    from httpie.plugins import builtin
    from httpie.plugins import humanize
    from httpie.plugins import HTTPBasicAuth
    from httpie.plugins import HTTPiePlugin
    from httpie.plugins import HTTPGzip
    from httpie.plugins import HTTPMultipartFormData
    from httpie.plugins import HTTPMultipartPostData
    from httpie.plugins import HTT

# Generated at 2022-06-21 13:37:16.080845
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'text/html, application/xml+foo; q=0.9, */*; q=0.8',
        'Accept-Language': 'en-US,en;q=0.8',
        'Connection': 'keep-alive',
        'Accept-Encoding': 'gzip, deflate, sdch',
    }

# Generated at 2022-06-21 13:37:23.007627
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs({'timeout': None, 'allow_redirects': None}) == {'timeout': None, 'allow_redirects': False}
    assert make_send_kwargs({'timeout': 5, 'allow_redirects': None}) == {'timeout': 5, 'allow_redirects': False}
    assert make_send_kwargs({'timeout': 5, 'allow_redirects': False}) == {'timeout': 5, 'allow_redirects': False}
    assert make_send_kwargs({'timeout': 5, 'allow_redirects': True}) == {'timeout': 5, 'allow_redirects': True}


# Generated at 2022-06-21 13:37:25.783958
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = True
    args.headers = {'Accept': 'application/json'}
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA, 'Accept': 'application/json'}



# Generated at 2022-06-21 13:37:37.810583
# Unit test for function build_requests_session
def test_build_requests_session():
    from httpie.sessions import HTTPieSession
    from ssl import CERT_NONE
    requests_session = build_requests_session(True, 'tlsv1.2', 'ECDHE-ECDSA-AES256-GCM-SHA384')
    assert isinstance(requests_session, requests.Session)
    assert isinstance(requests_session.adapters['https://'], HTTPieHTTPSAdapter)
    assert requests_session.adapters['https://'].ciphers == 'ECDHE-ECDSA-AES256-GCM-SHA384'
    assert requests_session.adapters['https://'].ssl_context.options == 0x0
    assert requests_session.adapters['https://'].ssl_context.verify_mode == CERT_NONE

# Generated at 2022-06-21 13:37:46.562556
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    argv = ['--json', 'GET', 'http://httpbin.org/get']

# Generated at 2022-06-21 13:37:55.761544
# Unit test for function max_headers
def test_max_headers():
    sys.stderr.write('Test max header\n')

    # Test with max header limit
    with max_headers(5):
        assert http.client._MAXHEADERS == 5

    # Test with max header limit 0 and infinite
    with max_headers(0):
        assert http.client._MAXHEADERS == float('Inf')
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')

    sys.stderr.write('Test max header passed!\n')
    sys.stderr.flush()


# Generated at 2022-06-21 13:38:06.411074
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = None
    args.verify = 'yes'
    args.key = None
    args.cert = 'yes'
    args.cert_key = 'yes'
    args.proxy = None
    args.stream = None
    args.ssl_version = None
    args.ciphers = None
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {}, 'stream': True, 'verify': 'yes', 'cert': ('yes', 'yes')}

if __name__ == '__main__':
    test_make_send_kwargs()

# Generated at 2022-06-21 13:38:09.270493
# Unit test for function dump_request
def test_dump_request():
    foo = {
            'verify': True,
            'url': 'http://127.0.0.1:5000/echo',
            'headers': {'Accept': 'application/json, */*;q=0.5', 'User-Agent': 'HTTPie/1.0.3'},
            'method': 'GET'
    }
    dump_request(foo)

# Generated at 2022-06-21 13:38:17.379420
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(argparse.Namespace(data={},
                                json=True,
                                files=None,
                                form=False,))['Accept'] == JSON_ACCEPT

    assert make_default_headers(argparse.Namespace(data={},
                                json=True,
                                files=None,
                                form=False,))['Content-Type'] == JSON_CONTENT_TYPE

    assert make_default_headers(argparse.Namespace(data={},
                                json=True,
                                files=None,
                                form=False,))['User-Agent'] == DEFAULT_UA

    assert make_default_headers(argparse.Namespace(data={},
                                json=False,
                                files=None,
                                form=True,))['Content-Type'] == FORM_CONTENT

# Generated at 2022-06-21 13:38:26.065897
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # 1. Method: GET with query and header
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "https://httpbin.org/anything?a=b"
    args.headers = {"Content-Type": "application/json"}
    args.data = None
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.multipart_data = None
    args.multipart = False
    args.verify = True
    args.cert = None
    args.chunked = False
    args.timeout = None
    args.max_redirects = None
    args.follow = True
    args.all = False
    args.history = True
    args.session = None
    args.session_read_

# Generated at 2022-06-21 13:39:31.216412
# Unit test for function make_send_kwargs