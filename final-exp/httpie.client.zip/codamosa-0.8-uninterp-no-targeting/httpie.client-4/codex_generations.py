

# Generated at 2022-06-21 13:30:19.624187
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'true'
    args.cert = "/path/to/cert"
    args.cert_key = "/path/to/cert_key"
    kwargs = make_send_kwargs_mergeable_from_env(args)

    assert kwargs['proxies'] == {}
    assert kwargs['verify'] == True
    assert kwargs['cert'] == (args.cert, args.cert_key)

# Generated at 2022-06-21 13:30:24.902677
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }
    args.timeout = 30
    args.allow_redirects = True
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': 30,
        'allow_redirects': True,
    }


# Generated at 2022-06-21 13:30:27.875889
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    dummy_args = argparse.Namespace()
    dummy_args.timeout=None
    kwargs = make_send_kwargs(dummy_args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-21 13:30:29.608010
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    n = make_send_kwargs(True)
    assert n['allow_redirects'] == False
    assert n['timeout'] == None
    

# Generated at 2022-06-21 13:30:33.036757
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['timeout'] == args.timeout
    assert send_kwargs['allow_redirects'] == False


# Generated at 2022-06-21 13:30:33.731452
# Unit test for function collect_messages
def test_collect_messages():
    pass

# Generated at 2022-06-21 13:30:45.527331
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = False
    args.files = False
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9'}

    args.json = True
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9', 'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'}

    args.json = False
    args.form = True
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9', 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}

   

# Generated at 2022-06-21 13:30:47.436530
# Unit test for function max_headers
def test_max_headers():
    # <https://github.com/httpie/httpie/issues/802>
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
        raise Exception
    assert http.client._MAXHEADERS == http.client._MAXHEADERS



# Generated at 2022-06-21 13:30:52.492599
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = '''{'no_env': True, 'verify': 'yes', 'cert': '/Users/dbouley/www/certs/https-jsonapi.com/fullchain1.pem', 'cert_key': '/Users/dbouley/www/certs/https-jsonapi.com/privkey1.pem'}'''
    assert make_send_kwargs_mergeable_from_env(eval(args))['proxies'] == {}


# Generated at 2022-06-21 13:31:03.017377
# Unit test for function make_default_headers
def test_make_default_headers():
    result = make_default_headers(args=argparse.Namespace(data=True, form=False, json=False, files=None))
    assert 'Content-Type' in result and result['Content-Type'] == JSON_CONTENT_TYPE
    assert 'Accept' in result and result['Accept'] == JSON_ACCEPT

    result = make_default_headers(args=argparse.Namespace(data=None, form=True, json=False, files=None))
    assert 'Content-Type' in result and result['Content-Type'] == FORM_CONTENT_TYPE
    assert 'Accept' not in result

# Generated at 2022-06-21 13:31:32.085213
# Unit test for function finalize_headers
def test_finalize_headers():
    input_headers = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
        'Host': 'www.example.com',
        'User-Agent': 'HTTPie/0.9.6',
    }
    expected_headers = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
        'Host': 'www.example.com',
        'User-Agent': 'HTTPie/0.9.6',
    }
    assert finalize_headers(input_headers) == expected_headers


# Generated at 2022-06-21 13:31:41.320931
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = False
    args.proxy = []
    args.cert = None
    args.cert_key = None

    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env["proxies"] == {}
    assert send_kwargs_mergeable_from_env["verify"] == False
    assert send_kwargs_mergeable_from_env["cert"] == None

# Generated at 2022-06-21 13:31:42.077262
# Unit test for function max_headers
def test_max_headers():
    pass

# Generated at 2022-06-21 13:31:45.421294
# Unit test for function dump_request
def test_dump_request():
    assert dump_request({"method": "GET"}) is not None
    assert dump_request({"method": "GET", "body": "test body"}) is not None

# Generated at 2022-06-21 13:31:48.081593
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:31:54.367690
# Unit test for function dump_request
def test_dump_request():
    from httpie import main
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    parsed = main.parser.parse_args([
        '--cookies', 'key=value',
        'httpbin.org', 'key2=value2'])

# Generated at 2022-06-21 13:32:01.528934
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import os
    import tempfile
    import requests
    from dotenv import load_dotenv
    from pathlib import Path
    from httpie.cli import parser

    env_path = Path('test') / '.test_env'
    load_dotenv(dotenv_path=env_path)
    args = parser.parse_args(['--verify=1', 'http://localhost'])
    expected_send_kwargs_mergeable_from_env = {
        'proxies': {
            'http': 'http://proxy-us.intel.com:911',
            'https': 'http://proxy-us.intel.com:912',
        },
        'verify': '/etc/ssl/certs/ca-certificates.crt',
        'cert': None
    }
    send_kwargs = make

# Generated at 2022-06-21 13:32:12.448968
# Unit test for function finalize_headers
def test_finalize_headers():
    dict1 = dict(a=1)
    dict2 = dict(b=2)
    dict3 = dict()
    dict4 = dict(c='c')
    dict5 = dict(c=3)
    dict6 = dict(test='test')
    dict7 = dict(test='test')
    dict8 = dict(test='test')

    args_test1 = argparse.Namespace(headers=dict1, files=None, data=None, form=True, json=False)
    args_test2 = argparse.Namespace(headers=dict2, files=None, data=None, form=True, json=False)
    args_test3 = argparse.Namespace(headers=dict3, files=None, data=None, form=True, json=False)

# Generated at 2022-06-21 13:32:25.376618
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:32:33.456063
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        url='http://localhost/',
        proxy=[],
        auth={},
        data={},
        json={},
        params={},
        form={},
        files={},
        headers={},
        method='GET',
        timeout={},
        chunked={},
        compress={},
        verify={},
        cert={},
        cert_key={},
        json={},
        form={},
        offline={},
        ssl_version=None,
        ciphers=None,
        debug={}
    )

    kwargs = make_request_kwargs(
        args=args,
        base_headers=None,
        request_body_read_callback=None
    )
    assert kwargs['method'] == 'get'

# Generated at 2022-06-21 13:33:19.663191
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    parser = argparse.ArgumentParser()
    parser.add_argument("-H", action='append', default=['User-Agent: HTTPie/' + __version__])
    parser.add_argument("-a", type=str, dest='auth', nargs='?', const='', help='username:password')
    parser.add_argument("-b", dest="cookie", help="Set cookie")
    parser.add_argument("-c", dest="cert", help="Load client certificate from file")
    parser.add_argument("-d", dest="data", nargs=1, help="HTTP request body data")
    parser.add_argument("-f", dest="form", action='store_true', help="Load data from stdin")
    parser.add_argument("--follow", action='store_true', help='Follow redirects')
    parser

# Generated at 2022-06-21 13:33:26.256511
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../bar', 'http://foo/?foo=bar') == 'http://foo/../bar?foo=bar'
    assert ensure_path_as_is('http://foo/../bar?foo=bar', 'http://foo/?foo=bar') == 'http://foo/../bar?foo=bar'


# Generated at 2022-06-21 13:33:30.852686
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(data={}, form=True, files=False, json=False)
    default_headers = make_default_headers(args)
    assert default_headers == RequestHeadersDict({'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE})


# Generated at 2022-06-21 13:33:36.735975
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Test the actual values of the returned dict
    request_args = argparse.Namespace(timeout='60', allow_redirects=False, verify='n')
    test_send_kwargs = make_send_kwargs(request_args)
    assert test_send_kwargs['timeout'] == '60'
    assert test_send_kwargs['allow_redirects'] == False
    # Test the length of the returned dict
    assert len(test_send_kwargs) == 2



# Generated at 2022-06-21 13:33:41.163521
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    kwargs = {'hello':'world','method': 'POST', 'url': 'http://localhost:4000/node/API/' }
    result = dump_request(kwargs)
    assert result == None



# Generated at 2022-06-21 13:33:46.068711
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = mock.MagicMock()
    args.verify = "yes"
    args.cert = True
    args.cert_key = True
    args.proxy = mock.MagicMock()
    args.proxy.key = "username"
    args.proxy.value = "password"
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs["proxies"] == {'username': 'password'}
    assert kwargs["verify"] == True
    assert kwargs["cert"] == (True, True)

# Generated at 2022-06-21 13:33:53.030517
# Unit test for function collect_messages
def test_collect_messages():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--verbose', action='store_true')
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--headers', action='append')
    parser.add_argument('--compress', action='count')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--form', action='store_true')
    parser.add_argument('--method', default='GET', type=str)
    parser.add_argument('--body', default=None, type=str)
    parser.add_argument('--auth', default=None, type=str)
    parser.add_argument('--auth-type', default='basic', type=str)
    parser.add_argument

# Generated at 2022-06-21 13:33:58.289208
# Unit test for function max_headers
def test_max_headers():
    import argparse
    args = argparse.Namespace(max_headers = 10)
    with max_headers(args.max_headers):
        assert http.client._MAXHEADERS == 10
    # assert http.client._MAXHEADERS == 5000000

# Generated at 2022-06-21 13:34:08.518550
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    """
    Test the behavior of make_send_kwargs function, especially the fix
    of #820.
    """
    import argparse
    args = argparse.Namespace()
    args.timeout = None
    args.verify = ''
    args.cert = ''
    args.cert_key = ''
    args.proxy = []
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] is None
    assert kwargs['verify'] == ''
    assert kwargs['cert'] == ''
    assert kwargs['proxies'] == {}

    args.verify = "cacert.pem"
    kwargs = make_send_kwargs(args)
    assert kwargs['verify'] == "cacert.pem"


# Generated at 2022-06-21 13:34:13.856691
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(
        'http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is(
        'https://example.com/api', 'https://example.com:443/?foo=bar') == 'https://example.com:443/api?foo=bar'
    assert ensure_path_as_is(
        'https://example.com/api', 'https://user:pass@example.com:443/?') == 'https://user:pass@example.com:443/api?'
    # Make sure we don't change anything if host is different, but path is the same
    assert ensure_path_as_is(
        'https://example.com/api', 'https://example.org:443/?foo=bar')

# Generated at 2022-06-21 13:35:38.507903
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert(ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar')
    assert(ensure_path_as_is('http://foo/../', 'http://bar/?foo=bar') == 'http://bar/../')

# Generated at 2022-06-21 13:35:41.431395
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = make_send_kwargs(
        argparse.Namespace(
            timeout=1,
            allow_redirects=True,
        )
    )
    assert args == {'timeout': 1, 'allow_redirects': False}



# Generated at 2022-06-21 13:35:44.110906
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace(method='GET', url='httpbin.org')
    kwargs = make_request_kwargs(args)
    dump_request(kwargs)



# Generated at 2022-06-21 13:35:53.185798
# Unit test for function finalize_headers
def test_finalize_headers():
    # noinspection PyPep8Naming
    def assert_header_equal(r1, r2):
        assert r1 == r2
        assert type(r1) == type(r2)

    def assert_dict(r1, r2):
        assert isinstance(r1, dict)
        assert isinstance(r2, dict)

    assert_header_equal(
        finalize_headers({
            'a': 'b',
            'c': '      d   ',
        }),
        {
            'a': 'b',
            'c': 'd',
        },
    )


# Generated at 2022-06-21 13:36:03.403084
# Unit test for function make_default_headers
def test_make_default_headers():
    test_args1 = argparse.Namespace()
    test_args2 = argparse.Namespace()
    test_args3 = argparse.Namespace()
    test_args4 = argparse.Namespace()
    test_args5 = argparse.Namespace()
    test_args6 = argparse.Namespace()
    test_args7 = argparse.Namespace()
    test_args8 = argparse.Namespace()
    test_args9 = argparse.Namespace()
    test_args10 = argparse.Namespace()

    test_args1.json = False
    test_args1.form = False
    test_args1.data = None
    test_args1.headers = {}

    test_args2.json = False
    test_args2.form = False
    test_args2.data = {}

# Generated at 2022-06-21 13:36:12.445505
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:36:18.274952
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    base_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    args.url = "http://example.com"
    args.method = "GET"
    args.headers = "Content-Type: application/json"
    args.data = ""
    args.params = {"key": "value"}
    args.json = False
    args.form = False
    args.auth = False
    args.verify = "True"
    args.cert = False
    args.cert_key = False
    args.path_as_is = False
    args.compress = False
    args.timeout = False
    args.debug = False
    args.all = False
    args.offline = False
    args.chunked = False

# Generated at 2022-06-21 13:36:20.615060
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(
        verify=True,
        ssl_version=None
    )
    assert session


# Generated at 2022-06-21 13:36:27.606544
# Unit test for function finalize_headers
def test_finalize_headers():
    test_headers = RequestHeadersDict({
        'User-Agent': '  HTTPie/1.0.0  ',
        'Accept': '  application/json  ',
        'Content-Type': '  application/x-www-form-urlencoded; charset=utf-8  ',
    })
    final_headers = finalize_headers(test_headers)
    assert final_headers['User-Agent'] == 'HTTPie/1.0.0'
    assert final_headers['Accept'] == 'application/json'
    assert final_headers['Content-Type'] == 'application/x-www-form-urlencoded; charset=utf-8'

# Generated at 2022-06-21 13:36:37.653777
# Unit test for function build_requests_session
def test_build_requests_session():
    verify_ssl = False
    ssl_version = "TLS2"
    ciphers = "RSA1"
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=verify_ssl,
    )
    assert(requests_session.verify is False)
    assert(requests_session.cert is None)
    assert(requests_session.proxies == {})

    verify_ssl = True
    ssl_version = "TLS1"
    ciphers = "RSA5"
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=verify_ssl,
    )