

# Generated at 2022-06-21 13:29:57.882262
# Unit test for function make_default_headers
def test_make_default_headers():
    # argparse.parse_args already creates a Namespace
    args = argparse.Namespace()
    args.json = False
    args.data = None
    args.form = False

    default_headers_dict = make_default_headers(args)
    assert b'User-Agent' in default_headers_dict
    assert b'Accept' not in default_headers_dict
    assert b'Content-Type' not in default_headers_dict

    args.data = True
    args.json = True
    default_headers_dict = make_default_headers(args)

    assert b'User-Agent' in default_headers_dict
    assert b'Accept' in default_headers_dict
    assert b'Content-Type' in default_headers_dict


# Generated at 2022-06-21 13:30:06.517083
# Unit test for function max_headers
def test_max_headers():
    from httpie.core import main as cli
    args = cli.parser.parse_args(args=['-v'])
    args.max_headers = 10
    args.method = b'GET'
    args.url = b'https://www.google.com'

    sys.stdout = io.StringIO()
    request_gen = collect_messages(args=args, config_dir=Path('./'))
    request = next(request_gen)
    # Test headers have been overwritten
    assert request.headers['user-agent'] == 'HTTPie/0.9.9'

# Generated at 2022-06-21 13:30:15.456151
# Unit test for function dump_request
def test_dump_request():
    import json
    import sys
    sys.stderr = open('_debug.txt', 'w')
    kwargs = {
        "method": "post",
        "url": "http://localhost:8000/api/v1/event/",
        "headers": "Authorization: Token f8f83b7de96f441c8f8dbe1f0c9fa35bAccept: application/json; ver=1.0",
        "data": json.dumps({"event": "dupa"})
        }
    dump_request(kwargs)

# Generated at 2022-06-21 13:30:24.628998
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = [
        ("Content-type", "text/html; charset=utf-8"),
        ("Date", "Sat, 26 Jan 2019 05:06:03 GMT"),
        ("Content-Length", "133"),
        ("Server", "Werkzeug/0.14.1 Python/3.5.2"),
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
        ("X-XSS-Protection", "1; mode=block"),
        ("Content-Security-Policy", "default-src 'self'"),
        ("X-Content-Security-Policy", "default-src 'self'"),
        ("ETag", "W/'85-IAGA0tKc+aHdZtXH2tFx8DGyok'")
    ] 



# Generated at 2022-06-21 13:30:31.382179
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    sys.argv = ['httpbin.org/get']
    parser = create_parser()
    args = parser.parse_args()
    args.cert = "path/to/cert"
    args.cert_key = "path/to/key"
    args.verify = "nope"

    proxies = args.proxy
    args.proxy = [("http", "http://proxy1.org"), ("https", "http://proxy2.org")]
    
    send_kwargs_merged = make_send_kwargs_mergeable_from_env(args)

    if send_kwargs_merged is None:
        raise AssertionError("Expected send_kwargs_merged to be not None")


# Generated at 2022-06-21 13:30:43.784560
# Unit test for function max_headers
def test_max_headers():
    # Test scenario:
    # 1. create test class to mock sys.stderr.write()
    # 2. setup the mock class to be used in the test
    # 3. initiate the test context manager
    # 4. test that sys.stderr.write() is not called
    # 5. test that sys.stderr.write() is called
    # 6. exit the context manager
    # 7. verify that the calls were made correctly
    # 8. reset mock

    # 1
    class MockSysStderr:
        def __init__(self):
            self._called = False
            self._written = 0
            self._called_with = ''

        def write(self, text):
            self._called = True
            self._written += 1
            self._called_with = text

    mock_sys_stderr = Mock

# Generated at 2022-06-21 13:30:48.437804
# Unit test for function dump_request
def test_dump_request():
    import unittest
    import io
    import sys

    class TestDumpRequest(unittest.TestCase):
        def setUp(self):
            self.held, sys.stderr = sys.stderr, io.StringIO()

        def tearDown(self):
            sys.stderr = self.held

        def test_dump_request(self):
            dump_request({"method": "GET", "url": "http://test-url.com", "headers": {"content-type": "application/json"}})
            sys.stderr.seek(0)

# Generated at 2022-06-21 13:30:55.605995
# Unit test for function collect_messages
def test_collect_messages():
    URL = 'http://httpbin.org/post'
    DATA = {}
    DATA['foo'] = 'bar'
    DATA['baz'] = 'qux'
    DATA['qux'] = 'quux'


# Generated at 2022-06-21 13:31:08.530433
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()

    args.json = True
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA,
                                          'Accept': JSON_ACCEPT,
                                          'Content-Type': JSON_CONTENT_TYPE}
    args.json = False
    args.data = True
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA,
                                          'Accept': JSON_ACCEPT,
                                          'Content-Type': JSON_CONTENT_TYPE}
    args.form = True
    args.files = False
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA,
                                          'Accept': JSON_ACCEPT,
                                          'Content-Type': FORM_CONTENT_TYPE}




# Generated at 2022-06-21 13:31:18.370257
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = '{"test": 1}'
    args.files = None
    default_headers = make_default_headers(args)
    assert default_headers["Accept"] == JSON_ACCEPT
    assert default_headers["Content-Type"] == JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = None
    args.files = True
    default_headers = make_default_headers(args)
    assert default_headers["Accept"] != JSON_ACCEPT
    assert default_headers["Content-Type"] != JSON_CONTENT_TYPE
    args.json = False
    args.form = True
    args.data = {}
    args.files = None
    default_headers = make_default_headers(args)


# Generated at 2022-06-21 13:31:54.455084
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert(ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') ==
           'http://foo/../?foo=bar')


# Generated at 2022-06-21 13:31:58.683903
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo/../%2e%2e/?%2e%2e=foo') == 'http://foo/../?..=foo'

# Generated at 2022-06-21 13:32:10.864086
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(args=argparse.Namespace(json=False, data=None, form=False)) == {'User-Agent': 'HTTPie/' + __version__}
    assert make_default_headers(args=argparse.Namespace(json=True, data=None, form=False)) == {'User-Agent': 'HTTPie/' + __version__, 'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'}
    assert make_default_headers(args=argparse.Namespace(json=False, data=None, form=True)) == {'User-Agent': 'HTTPie/' + __version__, 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}


# Generated at 2022-06-21 13:32:12.066891
# Unit test for function collect_messages
def test_collect_messages():
    pass


# Generated at 2022-06-21 13:32:19.647602
# Unit test for function max_headers
def test_max_headers():
    from httpie.cli import parser
    from httpie import ExitStatus
    args = parser.parse_args([
        '--max-headers', '10',
        '--print', 'B',
        '--verbose',
        'https://httpbin.org/anything'
    ])
    try:
        collect_messages(args, args.config_dir)
        assert False, 'should raise exception'
    except SystemExit as e:
        assert e.code == ExitStatus.OK

# Generated at 2022-06-21 13:32:25.630995
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    original_url = 'http://foo/../'
    parsed_prepped_url = 'http://foo/?foo=bar'
    parsed_final_url = 'http://foo/../?foo=bar'
    assert ensure_path_as_is(original_url, parsed_prepped_url) == parsed_final_url
    print("Unit test passed.")

# Generated at 2022-06-21 13:32:30.986798
# Unit test for function finalize_headers
def test_finalize_headers():
    'Test the function finalize_headers'

    assert finalize_headers(RequestHeadersDict({'Accept':'application/json'})) == RequestHeadersDict({'Accept':b'application/json'})
    assert finalize_headers(RequestHeadersDict({'Content-Type':'application/json'})) == RequestHeadersDict({'Content-Type': b'application/json'})

    return True


# Generated at 2022-06-21 13:32:35.125399
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    print('\ntest_ensure_path_as_is')
    print(ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar'))

if __name__ == "__main__":
    test_ensure_path_as_is()

# Generated at 2022-06-21 13:32:37.941505
# Unit test for function max_headers
def test_max_headers():
    with max_headers(3):
        assert http.client._MAXHEADERS == 3
    assert http.client._MAXHEADERS != 3

# Generated at 2022-06-21 13:32:47.119316
# Unit test for function make_default_headers
def test_make_default_headers():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        '--json',
        action="store_true",
        help='Encode data as JSON.',
    )
    group.add_argument(
        '--form',
        action="store_true",
        help='Encode data as form data.',
    )
    parser.add_argument(
        '--data',
        metavar='<object>',
    )

    args = parser.parse_args(['--json'])
    assert make_default_headers(args) == RequestHeadersDict(
        {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT,
         'Content-Type': JSON_CONTENT_TYPE})


# Generated at 2022-06-21 13:33:23.670498
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {}
    final_headers = finalize_headers(headers)
    assert len(final_headers.keys()) == 1

    headers = {
        'Accept': 'text/html'
    }
    final_headers = finalize_headers(headers)
    assert len(final_headers.keys()) == 2


# Generated at 2022-06-21 13:33:30.072483
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = "yes"
    args.proxy = []
    args.cert = None
    args.cert_key = None

    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['verify'] == True
    assert send_kwargs_mergeable_from_env['proxies'] == {}
    assert send_kwargs_mergeable_from_env['stream'] == True
    assert send_kwargs_mergeable_from_env['cert'] == None

# Generated at 2022-06-21 13:33:38.895235
# Unit test for function finalize_headers
def test_finalize_headers():
    import json
    import requests
    import http.client
    headers = RequestHeadersDict({
        'User-Agent': 'HTTPie/1.0.2',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': '*/*',
        'Connection': 'keep-alive'
        # 'Content-Length': '2',
        # 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'
    })
    headers = finalize_headers(headers)
    kwargs = {
        'method': 'POST',
        'url': 'http://localhost:5000/',
        'headers': headers,
        'data': '{}',
        'timeout': 10.0,
        'auth': ('', ''),
        'params': None
    }

# Generated at 2022-06-21 13:33:43.395424
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    # Set verify to 'foo' so that we can confirm the value ends up in the dict
    args.verify = 'foo'

    # Build the dict
    kwargs = make_send_kwargs_mergeable_from_env(args)

    # verify that verify has been mapped to the correct boolean
    assert kwargs['verify'] is True

# Generated at 2022-06-21 13:33:48.865565
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = type('Namespace', (), {
        'method': 'POST',
        'url': 'http://www.baidu.com',
        'headers': RequestHeadersDict(),
        'auth': [],
        'params': RequestHeadersDict(),
        'json': True,
        'data': {
            'foo': 'bar',
            'name': 'Admin',
            'age': '20'
        }
    })()
    kwargs = make_request_kwargs(args)
    print(kwargs['data'])

# Generated at 2022-06-21 13:33:50.349129
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:33:56.147281
# Unit test for function max_headers
def test_max_headers():
    # noinspection PyProtectedMember
    http.client._MAXHEADERS = float('Inf')
    with max_headers(limit=10):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == 10
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == float('Inf')



# Generated at 2022-06-21 13:34:05.950516
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(verify='truE', proxy=[], cert='test_cert',
                              cert_key='test_cert_key')
    expected_dict = {'proxies': {}, 'stream': True, 'verify': True, 'cert': 'test_cert, test_cert_key'}
    assert expected_dict == make_send_kwargs_mergeable_from_env(args)
    args = argparse.Namespace(verify='unknown', proxy=[], cert='test_cert',
                              cert_key='test_cert_key')
    expected_dict = {'proxies': {}, 'stream': True, 'verify': 'unknown', 'cert': 'test_cert, test_cert_key'}
    assert expected_dict == make_send_kwargs_mergeable_from

# Generated at 2022-06-21 13:34:15.589296
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:34:25.088222
# Unit test for function make_send_kwargs

# Generated at 2022-06-21 13:35:29.353345
# Unit test for function collect_messages
def test_collect_messages():

    args_1 = argparse.Namespace(method='GET', url='http://localhost:8080/login')
    args_2 = argparse.Namespace(
        method='POST', url='http://localhost:8080/test',
        json=True, data = {
            'param': {'test': ['test']
            }
    })
    config_dir = Path.cwd()

    cnt = 0
    for i in collect_messages(args_1, config_dir):
        cnt += 1
        print(i)
    assert cnt == 2

    cnt = 0
    for i in collect_messages(args_2, config_dir):
        cnt += 1
        print(i)
    assert cnt == 2

# Generated at 2022-06-21 13:35:39.063087
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=False, data=False, form=False, files=False)
    headers = make_default_headers(args)
    assert headers['Accept'] == 'application/json, */*;q=0.5'
    assert headers['Content-Type'] == 'application/json'
    assert headers['User-Agent'] == DEFAULT_UA
    args.json = True
    args.data = True
    headers = make_default_headers(args)
    assert headers['Accept'] == 'application/json, */*;q=0.5'
    assert headers['Content-Type'] == 'application/json'
    assert headers['User-Agent'] == DEFAULT_UA
    args.json = False
    args.form = True
    args.data = True
    headers = make_default_headers(args)


# Generated at 2022-06-21 13:35:47.429754
# Unit test for function ensure_path_as_is

# Generated at 2022-06-21 13:35:49.774727
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify = False,
        ssl_version = None,
        ciphers = None
    )
    assert isinstance(requests_session, requests.Session)

# Generated at 2022-06-21 13:35:57.221383
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # case_0: default value
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

    # case_1: args.timeout is not None
    args1 = argparse.Namespace()
    args1.timeout = 1
    args1.allow_redirects = False
    kwargs1 = make_send_kwargs(args1)
    assert kwargs1 == {'timeout': 1, 'allow_redirects': False}

    # case_2: args.allow_redirects is not False
    args2 = argparse.Namespace()
    args2.timeout = None
    args2.allow

# Generated at 2022-06-21 13:35:59.485106
# Unit test for function dump_request
def test_dump_request():
    test_request_kwargs = {'url': 'https://httpbin.org/get?q=dump_request', 'method': 'GET'}
    dump_request(test_request_kwargs)
    assert True # if there is no exception, then test_dump_request pass.

# Generated at 2022-06-21 13:36:04.092579
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    #TODO: add test on verify = verify = {
            # 'yes': True,
            # 'true': True,
            # 'no': False,
            # 'false': False,
            # }.get(args.verify.lower(), args.verify),
    return



# Generated at 2022-06-21 13:36:07.501309
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({'Host': 'https://www.google.com/'})
    final_headers = finalize_headers(headers)
    assert final_headers['Host'] == 'https://www.google.com/'


# Generated at 2022-06-21 13:36:15.264748
# Unit test for function finalize_headers
def test_finalize_headers():
    # Case 1: input is bytes
    input1 = {b'Content-Type': b'application/json', b'num': b'123', b'Name': b'xiao'}
    output1 = finalize_headers(input1)
    assert output1['Content-Type'] == 'application/json'
    assert output1['num'] == '123'
    assert output1['Name'] == 'xiao'

    # Case 2: input is str
    input2 = {'Content-Type': 'application/json', 'num': '123', 'Name': 'xiao'}
    output2 = finalize_headers(input2)
    assert output2['Content-Type'] == 'application/json'
    assert output2['num'] == '123'
    assert output2['Name'] == 'xiao'




# Generated at 2022-06-21 13:36:19.189431
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(verify=True)
    print(requests_session)
    # requests_session = build_requests_session(verify=True, ssl_version='TLSv1.2')
    # print(requests_session)


# Generated at 2022-06-21 13:38:11.258396
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    base_headers = {'Content-Type': 'application/json'}
    result = make_request_kwargs(args=args,
                                 base_headers=base_headers)
    result == {'method': 'get',
               'url': 'http://localhost:8080/test1',
               'headers': {'Content-Type': 'application/json',
                           'User-Agent': 'HTTPie/1.0.2'},
               'data': None,
               'auth': None,
               'params': None}

# Generated at 2022-06-21 13:38:18.118114
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/bar', 'http://foo/baz/') == 'http://foo/bar/'
    assert ensure_path_as_is('http://foo/bar/../.', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/bar/../baz', 'http://foo/?foo=bar') == 'http://foo/../baz?foo=bar'
    assert ensure_path_as_is('http://foo/bar/..', 'http://foo/?foo=bar') == 'http://foo/../baz?foo=bar'

# Generated at 2022-06-21 13:38:22.533577
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class mock_args():
        proxies = []
        stream = True
        verify = 'yes'
        cert = None

    args = mock_args()
    expected = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    assert make_send_kwargs_mergeable_from_env(args) == expected

# Generated at 2022-06-21 13:38:29.151287
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=True, ssl_version='tlsv1', ciphers='ECDH+AESGCM:DH+AESGCM:ECDH+AES256:DH+AES256:ECDH+AES128:DH+AES:ECDH+3DES:DH+3DES:RSA+AESGCM:RSA+AES:RSA+3DES:!aNULL:!MD5:!DSS')
    assert session != None

# Generated at 2022-06-21 13:38:37.491792
# Unit test for function collect_messages
def test_collect_messages():
    print('test_collect_messages')
    print('test_collect_messages')
    parser = argparse.ArgumentParser()
    #parser.add_argument('--url', dest='url', nargs='?', const='', )
    parser.add_argument('--url', dest='url', nargs='?', const='', default='http://127.0.0.1/index.html')
    #parser.add_argument('--url', dest='url', nargs='?', const='', default='http://127.0.0.1')
    parser.add_argument('--method', dest='method', nargs='?', const='', default='GET')
    parser.add_argument('--headers', dest='headers', nargs='?', const='')

# Generated at 2022-06-21 13:38:39.601393
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    kwargs = {}
    dump_request(kwargs)
    assert kwargs == {}

# Generated at 2022-06-21 13:38:50.516831
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = "data"
    args.form = True
    headers = make_default_headers(args)
    assert 'Content-Type' in headers.keys()
    assert 'Accept' in headers.keys()
    assert 'User-Agent' in headers.keys()
    args2 = argparse.Namespace()
    args2.json = True
    args2.data = "data"
    args2.form = True
    headers2 = make_default_headers(args2)
    assert 'Content-Type' in headers2.keys()
    assert 'Accept' in headers2.keys()
    assert 'User-Agent' in headers2.keys()
    args3 = argparse.Namespace()
    args3.data = "data"
    args3.form = True

# Generated at 2022-06-21 13:38:58.386421
# Unit test for function max_headers
def test_max_headers():
    # Check limit increase
    new_limit = 200
    old_limit = http.client._MAXHEADERS
    with max_headers(new_limit):
        assert new_limit == http.client._MAXHEADERS
    assert old_limit == http.client._MAXHEADERS
    # Check limit decrease
    new_limit = 10
    with max_headers(new_limit):
        assert new_limit == http.client._MAXHEADERS
    assert old_limit == http.client._MAXHEADERS
    # Check Max value
    with max_headers(1000000000):
        assert 1000000000 == http.client._MAXHEADERS
    assert old_limit == http.client._MAXHEADERS
    # Check No Limit value
    with max_headers(None):
        assert float('Inf') == http.client._MAXHEADERS
    assert old_limit == http

# Generated at 2022-06-21 13:39:01.473965
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:39:06.286984
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=True, ssl_version='TLS', ciphers=None)
    assert session.mounts['https://'][1].verify
    assert session.mounts['https://'][1].ssl_context.protocol == ssl.PROTOCOL_TLS