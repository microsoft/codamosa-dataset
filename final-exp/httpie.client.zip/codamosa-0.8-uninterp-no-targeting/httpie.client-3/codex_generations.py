

# Generated at 2022-06-21 13:29:52.846742
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True)
    print(session)
    session = build_requests_session(False)
    print(session)
    session = build_requests_session(True, 'TLSv1')
    print(session)
    session = build_requests_session(False, 'TLSv1')
    print(session)


# Generated at 2022-06-21 13:29:55.250385
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    # TODO: more tests

# Generated at 2022-06-21 13:30:06.365287
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args1 = argparse.Namespace()
    args1.proxy = []
    args1.verify = 'True'
    args1.cert = 'cert.pem'
    args1.cert_key = 'cert_key.pem'
    kwargs1 = {}
    kwargs1['proxies'] = {}
    kwargs1['stream'] = True
    kwargs1['verify'] = 'True'
    kwargs1['cert'] = 'cert.pem'
    assert make_send_kwargs_mergeable_from_env(args1) == kwargs1
    args2 = argparse.Namespace()
    args2.proxy = []
    args2.verify = 'False'
    args2.cert = 'cert.pem'

# Generated at 2022-06-21 13:30:18.317530
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth='test',
        body='test',
        chunked=False,
        data='{}',
        files='test',
        form=True,
        headers='test',
        json=True,
        maxredirs=5,
        method='GET',
        params='test',
        offline=True,
        proxy={'key': 'value'},
        timeout=5,
        ua='test',
        url='http://localhost:5000',
        verify='test'
    )

    dic = {}
    dic.update(make_request_kwargs(args))
    dic.update(make_send_kwargs(args))
    dic.update(make_send_kwargs_mergeable_from_env(args))

# Generated at 2022-06-21 13:30:19.236397
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5

# Generated at 2022-06-21 13:30:27.696200
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(argparse.Namespace(data=False, json=False, form=False)) == {'User-Agent': 'HTTPie/2.2.0'}
    assert make_default_headers(argparse.Namespace(data=True, json=False, form=False)) == {'User-Agent': 'HTTPie/2.2.0'}
    assert make_default_headers(argparse.Namespace(data=True, json=True, form=False)) == {'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json', 'User-Agent': 'HTTPie/2.2.0'}

# Generated at 2022-06-21 13:30:30.136579
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    kwargs = make_send_kwargs_mergeable_from_env()
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None

# Generated at 2022-06-21 13:30:33.233002
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') \
           == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:30:35.909864
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:30:47.264419
# Unit test for function finalize_headers
def test_finalize_headers():
    headerList = ['Accept-Encoding', 'Content-Type', 'User-Agent']
    headerList1 = ['Accept-Encoding', 'Content-Type', 'User-Agent', 'Host']
    input_dict = {'Accept-Encoding': 'gzip, deflate', 'Content-Type': 'application/json', 'User-Agent': 'test/1.0'}
    output_dict = finalize_headers(input_dict)
    assert set(headerList) == set(output_dict.keys())

    output_dict = finalize_headers(headers=input_dict, base_headers=input_dict)
    assert set(headerList) == set(output_dict.keys())

    output_dict = finalize_headers(headers=input_dict, base_headers=None)

# Generated at 2022-06-21 13:31:13.021540
# Unit test for function finalize_headers
def test_finalize_headers():
    args = argparse.Namespace(
        method='GET',
        url='http://localhost:8080',
        headers=[],
        data=None,
        params={},
        auth=None,
        auth_plugin=None,
        json=False,
        form=False,
    )
    default_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': FORM_CONTENT_TYPE,
    })
    final_headers = finalize_headers(default_headers)
    assert final_headers == default_headers

# Generated at 2022-06-21 13:31:14.850999
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10


# Generated at 2022-06-21 13:31:18.866922
# Unit test for function max_headers
def test_max_headers():
    import http.client

    max_headers = 100
    with max_headers(max_headers):
        assert http.client._MAXHEADERS == max_headers
    assert http.client._MAXHEADERS == float('Inf')

# Generated at 2022-06-21 13:31:23.274294
# Unit test for function build_requests_session
def test_build_requests_session():
    print("Testing `build_requests_session`")
    assert(build_requests_session(verify=True, ssl_version='1.2', ciphers='ECDH')).__class__.__name__ == 'Session'
    print("Test passed")


# Generated at 2022-06-21 13:31:25.854069
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10000):
       print(http.client._MAXHEADERS)
    print(http.client._MAXHEADERS)

# Generated at 2022-06-21 13:31:35.806069
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie.utils import Path_to_folder
    args = Path_to_folder.make_argparse(
        "GET", 
        "https://www.example.com",
        {}, ["/home/kien/ThisFolderDoesNotExists/test.txt"], []
    )
    my_request_kwargs = make_request_kwargs(args, base_headers=None, request_body_read_callback=None)
    assert my_request_kwargs["method"] == "get"
    assert my_request_kwargs["url"] == "https://www.example.com"
    assert my_request_kwargs["headers"] == {}
    assert my_request_kwargs["data"] is None
    assert my_request_kwargs["auth"] is None

# Generated at 2022-06-21 13:31:41.673689
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.stream = True
    args.verify = True
    args.cert = None
    assert make_send_kwargs(args) == {
        'timeout': None,
        'allow_redirects': False
    }

# Generated at 2022-06-21 13:31:48.760887
# Unit test for function max_headers
def test_max_headers():
    import requests
    import http.client
    import httpie.cli.argtypes as argtypes
    args = argparse.Namespace()
    args.max_headers = 12
    header_max = http.client._MAXHEADERS
    try:
        with max_headers(args.max_headers):
            assert http.client._MAXHEADERS == args.max_headers
    finally:
        http.client._MAXHEADERS = header_max



# Generated at 2022-06-21 13:31:51.463563
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:31:59.975527
# Unit test for function make_request_kwargs

# Generated at 2022-06-21 13:32:44.024548
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class ar():
        def __init__(self):
            self.method = 'GET'
            self.url = 'http://127.0.0.1/'
            self.timeout = '200'
            self.headers = []
            self.data = '{}'
            self.auth = None
            self.json = None
            self.compress = None
            self.max_redirects = None
            self.follow = None
            self.max_headers = None
            self.offline = None
            self.allow_redirects = None
            self.verify = None
            self.debug = None
            self.auth_plugin = None
            self.cert = None
            self.cert_key = None
            self.proxy = None
            self.multipart = None
            self.files = None

   

# Generated at 2022-06-21 13:32:47.486127
# Unit test for function collect_messages
def test_collect_messages():
  parser_args = None
  config_dir = None
  request_body_read_callback = None
  messages = collect_messages(parser_args, config_dir, request_body_read_callback)
  assert messages is not None
  # TODO: write more unit tests


# Generated at 2022-06-21 13:32:49.369062
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({'Foo': ' Bar '})
    new_data = finalize_headers(headers)
    assert new_data['Foo'] == b'Bar'


# Generated at 2022-06-21 13:32:50.352291
# Unit test for function collect_messages
def test_collect_messages():
    return None


# Generated at 2022-06-21 13:33:02.554664
# Unit test for function make_default_headers
def test_make_default_headers():
    import unittest

    class TestMakeDefaultHeaders(unittest.TestCase):
        def test_make_default_headers(self):
            import argparse
            args = argparse.Namespace()
            self.assertEqual(make_default_headers(args)['User-Agent'], DEFAULT_UA)
            self.assertEqual(make_default_headers(args).get('Accept',' '), ' ')

        def test_json_headers(self):
            args = argparse.Namespace()
            args.json = True
            self.assertEqual(make_default_headers(args)['Accept'], JSON_ACCEPT)
            self.assertEqual(make_default_headers(args).get('Content-Type',' '), JSON_CONTENT_TYPE)


# Generated at 2022-06-21 13:33:03.562816
# Unit test for function collect_messages
def test_collect_messages():
    assert callable(collect_messages)

# Generated at 2022-06-21 13:33:08.703032
# Unit test for function finalize_headers
def test_finalize_headers():
    header_dict = {}
    header_dict['foo'] = ' bar '
    header_dict['baz'] = [1, 2, 3]
    final_header_dict = finalize_headers(header_dict)
    assert 'foo' in final_header_dict
    assert 'bar' == final_header_dict.get('foo')
    assert 'baz' not in final_header_dict
    return True

## Unit test for function make_default_headers

# Generated at 2022-06-21 13:33:14.882886
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    proxy = Proxy('http://127.0.0.1:8888', 'username', 'password')

# Generated at 2022-06-21 13:33:17.189150
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'url': 'http://test.com',
    }
    dump_request(kwargs)



# Generated at 2022-06-21 13:33:27.786678
# Unit test for function dump_request
def test_dump_request():
    sys.stderr.write('Testing dump_request\n')

    args = argparse.Namespace()
    config_dir = Path("/tmp")


# Generated at 2022-06-21 13:34:05.714672
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import argparse
    args = argparse.Namespace(timeout=1, follow=1)
    send_kwargs = make_send_kwargs(args)

    assert send_kwargs['timeout'] == args.timeout
    assert send_kwargs['allow_redirects'] == args.follow


# Generated at 2022-06-21 13:34:15.504188
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(ssl_version='SSLv3'), requests.Session)
    assert isinstance(build_requests_session(ssl_version='TLSv1_0'), requests.Session)
    assert isinstance(build_requests_session(ssl_version='TLSv1_1'), requests.Session)
    assert isinstance(build_requests_session(ssl_version='TLSv1_2'), requests.Session)
    assert isinstance(build_requests_session(ssl_version='TLSv1'), requests.Session)
    assert isinstance(build_requests_session(ssl_version='TLS'), requests.Session)

# Generated at 2022-06-21 13:34:16.379339
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace
    assert 1==1

# Generated at 2022-06-21 13:34:23.752973
# Unit test for function dump_request
def test_dump_request():
    return (
        '\n>>> requests.request(**{\n    "data": "",\n    "headers": {\n        '
        '"User-Agent": "HTTPie/0.9.9",\n        "Content-Length": "0",\n     '
        '   "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"\n '
        '   },\n    "method": "post",\n    "url": "http://httpbin.org/post"\n})\n\n'
    )

# Generated at 2022-06-21 13:34:32.774256
# Unit test for function build_requests_session
def test_build_requests_session():
    from httpie import plugins

    class CustomTransportPlugin(plugins.TransportPlugin):
        prefix = 'custom://'
        default = True

        def __init__(self):
            super().__init__()
            self.is_adapter_installed = False

        def get_adapter(self):
            self.is_adapter_installed = True
            return super().get_adapter()

    custom_transport_plugin = CustomTransportPlugin()

    build_requests_session(
        verify=True,
        ssl_version='sslv3',
        ciphers='ECDHE-RSA-AES256-SHA',
    )

    assert custom_transport_plugin.is_adapter_installed is True

# Generated at 2022-06-21 13:34:40.588558
# Unit test for function finalize_headers
def test_finalize_headers():
    a=finalize_headers({"a":"b "})
    assert len(a)==1
    b=finalize_headers({"a":" b"})
    assert len(b)==1
    c=finalize_headers({"a":" b "})
    assert len(c)==1
    d=finalize_headers({"a":" b "})
    assert len(d)==1
    e=finalize_headers({"a":[ "b "]})
    assert len(e)==1
    f=finalize_headers({"a":{"b":"c"}})
    assert len(f) == 1

# Generated at 2022-06-21 13:34:44.521673
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.form = False
    args.json = False
    args.data = False
    args.files = False

    default_headers = make_default_headers(args)

    assert 'User-Agent' in default_headers.keys() and 'HTTPie' in default_headers['User-Agent']



# Generated at 2022-06-21 13:34:54.668797
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from io import StringIO
    from httpie.sessions import Session
    from httpie.ssl import AVAILABLE_SSL_VERSION_ARG_MAPPING
    from sockets import MockSocket2 as MockSocket
    from tempfile import TemporaryDirectory

    plugin_manager.get_transport_plugins = lambda: [
        MockTransportPlugin('mock', MockSocket),
    ]

    with TemporaryDirectory() as config_dir:
        session = Session(
            name='my_session',
            host='example.com',
            config_dir=config_dir,
            config_dir_mode='override',
        )
        session.auth = {'type': 'basic', 'raw_auth': 'admin:admin'}
        session.save()


# Generated at 2022-06-21 13:35:02.198186
# Unit test for function ensure_path_as_is

# Generated at 2022-06-21 13:35:06.029777
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=None, allow_redirects=False)
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-21 13:37:34.633342
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'timeout': 10, 'allow_redirects': False}

# Generated at 2022-06-21 13:37:40.977872
# Unit test for function max_headers
def test_max_headers():
    """Test if max_headers works properly"""
    # noinspection PyProtectedMember
    num_headers = http.client._MAXHEADERS
    limit = 10
    with max_headers(limit):
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == limit
    assert http.client._MAXHEADERS == num_headers

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 13:37:45.362093
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = '2'
    args.allow_redirects = '0'
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {
        'timeout': 2,
        'allow_redirects': False,
    }

test_make_send_kwargs()

# Generated at 2022-06-21 13:37:47.936488
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:37:51.044655
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:37:53.611185
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
    data='{"test": 1}',
    )
    make_default_headers(args)

# Generated at 2022-06-21 13:37:56.999258
# Unit test for function max_headers
def test_max_headers():
    args=argparse.Namespace(max_headers="2")
    with max_headers(args.max_headers):
        assert http.client._MAXHEADERS == 2


# Generated at 2022-06-21 13:37:59.936717
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = "10"
    assert make_send_kwargs(args) == {'timeout': 10, 'allow_redirects': False}


# Generated at 2022-06-21 13:38:09.436942
# Unit test for function collect_messages

# Generated at 2022-06-21 13:38:13.859716
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(
        ssl_version='tlsv1.2',
        ciphers="TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256",
        verify=False)
    assert isinstance(session, requests.Session)