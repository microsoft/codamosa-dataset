

# Generated at 2022-06-21 13:29:51.488299
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({' foo ': '  bar '}) == {'foo': 'bar'}

# Generated at 2022-06-21 13:29:59.907691
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(
        argparse.Namespace(verify="true")) == {
               'proxies': {},
               'stream': True,
               'verify': True,
               'cert': None,
           }
    assert make_send_kwargs_mergeable_from_env(
        argparse.Namespace(verify="false")) == {
               'proxies': {},
               'stream': True,
               'verify': False,
               'cert': None,
           }

# Generated at 2022-06-21 13:30:04.024744
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'method': 'GET', 'url': 'www.example.com', 'headers': {}, 'data': None, 'auth': '', 'params': []}
    dump_request(kwargs)


# Generated at 2022-06-21 13:30:12.498759
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    str_yes = 'yes'
    str_no = 'no'
    str_true = 'true'
    str_false = 'false'
    args = argparse.Namespace()
    args.verify = 'no'
    send_kwargs = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs['verify'] == {
        str_yes: True,
        str_true: True,
        str_no: False,
        str_false: False,
    }.get(args.verify.lower(), args.verify)

# Generated at 2022-06-21 13:30:22.879246
# Unit test for function dump_request
def test_dump_request():
    # Python 3.7
    from unittest import mock
    from io import StringIO
    import sys
    from httpie.core import dump_request

    test1_str = "test1.com"
    test2_str = "test2.com"

    # test1 code
    with mock.patch.object(sys, 'stderr', new=StringIO()) as fake_stderr:
        dump_request({"url":test1_str})
        out = fake_stderr.getvalue().strip()
        assert out == f'\n>>> requests.request(**{test1_str})\n\n'

    # test2 code
    with mock.patch.object(sys, 'stderr', new=StringIO()) as fake_stderr:
        dump_request({"url":test2_str})

# Generated at 2022-06-21 13:30:26.322510
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }


# Generated at 2022-06-21 13:30:27.983468
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=2):
        assert http.client._MAXHEADERS == 2
    assert http.client._MAXHEADERS == 1000 # the original value

# Generated at 2022-06-21 13:30:33.303419
# Unit test for function build_requests_session
def test_build_requests_session():

    def get_requests_session(args):
        verify = bool(send_kwargs_mergeable_from_env['verify'])
        requests_session = build_requests_session(
            ssl_version=args.ssl_version,
            ciphers=args.ciphers,
            verify=verify
        )
        return requests_session

    class Args:
        def __init__(self, ssl_version=None, ciphers=None):
            self.ssl_version = ssl_version
            self.ciphers = ciphers

    class Send_kwargs_mergeable_from_env:
        def __init__(self, verify):
            self.verify = verify


# Generated at 2022-06-21 13:30:38.526790
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = "True"
    args.cert = "cert.pem"
    args.cert_key = "cert_key.pem"
    make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-21 13:30:49.130028
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'POST'
    args.url = 'http://example.com'
    
    headers = {
        'Host': 'example.com',
        'Accept': '*/*',
        'User-Agent': 'HTTPie/1.0.0'
    }
    args.headers = RequestHeadersDict(headers)
    args.auth = None
    args.data = {'abc': 'def'}
    
    args.json = False
    args.form = False
    
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'POST'
    assert kwargs['url'] == 'http://example.com'
    assert kwargs['headers'] == headers

# Generated at 2022-06-21 13:31:13.466112
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=None,
    )
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['timeout'] == args.timeout
    assert send_kwargs['allow_redirects'] == False



# Generated at 2022-06-21 13:31:15.079366
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:31:23.714211
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(proxies = [])) == {'proxies': {}}
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify = "true")) == {'verify': True, 'proxies': {}}
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(cert = "cert")) == {'cert': "cert", 'proxies': {}}


# Generated at 2022-06-21 13:31:31.008582
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        cert_key=None,
        cert=None,
        proxy=None,
        timeout=None,
        verify='yes',
    )
    send_kwargs = make_send_kwargs(args)
    should_be = {
        'timeout': args.timeout,
        'allow_redirects': False,
    }
    assert send_kwargs == should_be



# Generated at 2022-06-21 13:31:35.006869
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers(RequestHeadersDict({
        'User-Agent': ' HTTPie/2.0.0-dev ',
        'Cache-Control': None,
        'X-String': 'foobar'})) == {
            'User-Agent': b'HTTPie/2.0.0-dev',
            'X-String': 'foobar'}


# Generated at 2022-06-21 13:31:47.932238
# Unit test for function max_headers
def test_max_headers():
    # Initialize the arguments namespace
    args = argparse.Namespace()
    args.headers = {'Host': 'http://localhost:5000/'}
    args.json = True
    args.data_file_path = 'data.json'
    args.data = None
    args.params = {}
    args.verify = False
    args.verify_ssl = False
    args.prepared_request = None
    args.compress = 0
    args.compress_level = 9
    args.form = False
    args.files = []
    args.chunked = False
    args.json_flat = False
    args.offline = False
    args.max_redirects = None
    args.max_headers = None
    args.timeout = None
    args.auth = ''
    args.auth_type

# Generated at 2022-06-21 13:31:53.108808
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    url1 = 'http://10.210.55.55:8080/../'
    url2 = 'http://10.210.55.55:8080/?foo=bar'
    assert ensure_path_as_is(url1, url2) == 'http://10.210.55.55:8080/../?foo=bar'

# Generated at 2022-06-21 13:32:00.895629
# Unit test for function collect_messages
def test_collect_messages():
    # Create a Namespace object to be passed to the collect_messages()
    # function.
    args = argparse.Namespace()
    args.abstract = False
    args.all = False
    args.auth = None
    args.auth_type = None
    args.body = None
    args.body_columns = None
    args.body_format = None
    args.body_vim = False
    args.break_ = False
    args.chunked = True
    args.cli_style = 'auto'
    args.color = False
    args.config_dir = '~/.httpie'
    args.default_options = None
    args.download = False
    args.download_all = False
    args.download_dir = None
    args.download_file = None

# Generated at 2022-06-21 13:32:11.984002
# Unit test for function collect_messages
def test_collect_messages():

    # Request rate quiya:
    # 100 request per 100 second
    # 10 request per 10 second
    # 1 request per 1 second
    # 0.1 request per 100 second
    # 0.01 request per 1000 second
    # 0.001 request per 10000 second

    # Prepare args
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.base import parser
    from httpie import __version__ as httpie_version
    from requests.structures import CaseInsensitiveDict
    from httpie.input import InputFilePath, InputFileStream
    from httpie.cli.parser import get_parser
    from httpie.cli.constants import MAX_CONTENT_LENGTH
    from httpie.cli.constants import DEFAULT_CONTENT_TYPE
    import tempfile



# Generated at 2022-06-21 13:32:25.034209
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    """
    json data, auto_json data, files, auto_json data and files
    args.json and args.form
    args.json and args.files
    args.form and args.files
    args.form and args.files and args.multipart
    args.chunked and 'Transfer-Encoding' not in headers
    """

# Generated at 2022-06-21 13:33:04.053689
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:33:06.593558
# Unit test for function dump_request
def test_dump_request():
    args = {
        "method": "GET",
        "url": "http://www.baidu.com"
    }
    dump_request(kwargs=args)



# Generated at 2022-06-21 13:33:09.250758
# Unit test for function max_headers
def test_max_headers():
    # Unit test for issue #802
    with max_headers(2):
        sys.stderr.write(f'\n>>> {http.client._MAXHEADERS}\n\n')
    # Restore original value
    sys.stderr.write(f'\n>>> {http.client._MAXHEADERS}\n\n')

# Generated at 2022-06-21 13:33:20.147119
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [
        argparse.Namespace(key="http", value="http://proxy1.example.com"),
        argparse.Namespace(key="https", value="https://proxy2.example.com"),
    ]
    args.verify = "false"
    args.cert = "cert.pem"
    args.cert_key = "cert_key.pem"

# Generated at 2022-06-21 13:33:28.918841
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import unittest
    import httpie.cli.parser
    parser = httpie.cli.parser.Parser()
    args_parse = parser.parse_args(
        ['--json', 'http://localhost:5000/api/v1/exercises', ],
    )
    data = {"user_id": 1, "workout_id": 1, "exercise_id": 1, "sets": 6,
            "reps": 10, "weight": 70}

# Generated at 2022-06-21 13:33:29.862146
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session(False, None, None)

# Generated at 2022-06-21 13:33:33.593681
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # test1
    args = argparse.Namespace()
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['stream'] == True
    assert send_kwargs['timeout'] == None

# Generated at 2022-06-21 13:33:35.581286
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(False, 'TLSv1')
    assert requests_session


# Generated at 2022-06-21 13:33:40.554206
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    print("Entering test_make_send_kwargs##############################")
    from httpie.core import main as httpie
    sys.argv = ["httpie", "www.google.com", "-v"]
    args = httpie.parser().parse_args()
    send_kwargs = make_send_kwargs(args)
    print("send_kwargs = {}".format(send_kwargs))
    #assert send_kwargs["timeout"] is None
    #assert send_kwargs["allow_redirects"] is False


# Generated at 2022-06-21 13:33:49.309343
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.verify_yes = False
    args.proxy = None
    args.timeout = 20
    args.verify = 'False'
    args.cert = 'ca'
    args.cert_key = 'ca_key'

    kwargs = make_send_kwargs(args)
    kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)

    assert kwargs_mergeable_from_env['proxies'] is None
    assert kwargs_mergeable_from_env['verify'] is False
    assert kwargs_mergeable_from_env['stream'] is True
    assert kwargs_mergeable_from_env['cert'] == 'ca'

# Generated at 2022-06-21 13:35:19.929642
# Unit test for function collect_messages
def test_collect_messages():
    import os
    import sys
    import json
    
    class Namespace:
        pass
    args = Namespace()
    config_dir = Namespace()
    config_dir.__str__ = lambda x: '.'
    
    args.session = None
    
    args.url = "http://httpbin.org/get"
    args.auth_plugin = None
    args.method = "GET"
    args.headers = {}   # Dict
    args.json = False
    args.data = ""
    args.form = False
    args.files = []
    args.compress = False
    args.debug = False
    args.offline = False
    args.verbose = False
    args.stream = False
    args.chunked = False
    args.output = None
    args.download = None


# Generated at 2022-06-21 13:35:20.924565
# Unit test for function collect_messages
def test_collect_messages():
    print("Testing function collect_messages")
    assert(1)



# Generated at 2022-06-21 13:35:30.238908
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.auth = None
    args.auth_plugin = None
    args.cert = None
    args.cert_key = None
    args.check_status = None
    args.chunked = None
    args.compress = None
    args.data = None
    args.debug = None
    args.files = None
    args.form = None
    args.follow = None
    args.headers = []
    args.http2 = None
    args.ignore_stdin = None
    args.include = None
    args.json = None
    args.method = None
    args.offline = None
    args.output = None
    args.output_file = None
    args.output_options = None
    args.output_style = None
    args.output_style_ex

# Generated at 2022-06-21 13:35:35.968685
# Unit test for function make_default_headers
def test_make_default_headers():

    class args:
        def __init__(self):
            self.headers = RequestHeadersDict()
            self.data = None
            self.files = None
            self.form = False
            self.json = False
        
        def __getattr__(self, attr):
            return None

    _args = args()
    default_headers = make_default_headers(_args)

    print(f"headers = {default_headers}")


# Generated at 2022-06-21 13:35:39.299725
# Unit test for function max_headers
def test_max_headers():
    import http.client
    import httpie.http
    http.client.MAXHEADERS = 1000
    with max_headers(300):
        assert http.client.MAXHEADERS == 300
    assert httpie.http.MAXHEADERS == 1000

# Generated at 2022-06-21 13:35:42.957245
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = None
    test_dict = dict()
    test_dict['timeout'] = args.timeout or None
    test_dict['allow_redirects'] = False

    assert(test_dict == make_send_kwargs(args))


# Generated at 2022-06-21 13:35:51.138652
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # The args should include headers, method and url
    args = argparse.Namespace(headers = {'Header1':'123'}, method = 'GET', url = 'http://httpbin.org/get')
    request_kwargs = make_request_kwargs(args)
    assert request_kwargs['headers'] == {'Header1':'123'}
    assert request_kwargs['method'] == 'get'
    assert request_kwargs['url'] == 'http://httpbin.org/get'
    assert request_kwargs['auth'] is None
    assert request_kwargs['data'] is None
    assert request_kwargs['params'] == []
    # Test when the data is given

# Generated at 2022-06-21 13:35:53.745657
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = type('Namespace', (), {'timeout': 1, 'allow_redirects': False})
    assert make_send_kwargs(args) == {'timeout': 1, 'allow_redirects': False}

# Generated at 2022-06-21 13:36:01.787214
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(argparse.Namespace(json=True)) == {
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    }
    assert make_default_headers(argparse.Namespace(form=True, files=False)) == {
        'User-Agent': DEFAULT_UA,
        'Content-Type': FORM_CONTENT_TYPE
    }
    assert make_default_headers(argparse.Namespace(files=True)) == {
        'User-Agent': DEFAULT_UA,
    }



# Generated at 2022-06-21 13:36:05.244408
# Unit test for function build_requests_session
def test_build_requests_session():
    verify_true = True
    ssl_version = 'TLSv1.0'
    session = build_requests_session(verify_true, ssl_version)
    print ("test_build_requests_session:" + str(session))

# Generated at 2022-06-21 13:37:52.543433
# Unit test for function make_default_headers
def test_make_default_headers():
    from argparse import Namespace

# Generated at 2022-06-21 13:37:58.640071
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(True, 'TLSv1.2', None)
    assert isinstance(requests_session, requests.Session)
    assert requests_session.verify == True
    assert requests_session.cert == None
    assert requests_session.proxies == {}
    assert requests_session.stream == True
    assert requests_session.timeout == None


# Generated at 2022-06-21 13:38:08.278197
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    # >>> ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')
    # 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    # >>> ensure_path_as_is('https://test.test/test/test/test/test', 'https://test.test:444/?foo=bar')
    # 'https://test.test:444/test/test/test/test?foo=bar'

# Generated at 2022-06-21 13:38:14.634741
# Unit test for function make_default_headers
def test_make_default_headers():
    print('-' * 10, 'test make_default_headers', '-' * 10)
    class Namespace:
        def __init__(self, json=False, form=False, data={}, timeout=None, headers={}, files={}, verify='', cert='', cert_key='', max_redirects=0,
                     chunked=False, offline=False, method='GET', url='', auth='', params='', data_items=[], headers_items=[], files_items=[],
                     params_items=[], auth_plugin='', session='', session_read_only='', max_headers=32):
            self.json = json
            self.form = form
            self.data = data
            self.timeout = timeout
            self.headers = RequestHeadersDict(headers)
            self.files = files
            self.verify = verify

# Generated at 2022-06-21 13:38:20.188200
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    args.headers = ["Accept:application/json"]
    args.json = True
    args.data = {"name":"zqwa"}
    args.debug = True
    args.url = "http://127.0.0.1:5000"
    args.method = "POST"
    kwargs = make_request_kwargs(
        args=args,
        base_headers=None,
        request_body_read_callback=lambda chunk: chunk
    )
    dump_request(kwargs)



# Generated at 2022-06-21 13:38:30.318577
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'Host'       : 'www.baidu.com',
        'User-Agent' : '  HTTPie/1.0.3',
        'Accept'     : 'application/json',
        'Referer'    : '   <https://www.baidu.com/>',
        'Cookie'     : 'hello=world; hello2=world2'
    })

# Generated at 2022-06-21 13:38:38.695542
# Unit test for function make_default_headers
def test_make_default_headers():
    args = []
    args.json = False
    args.data = False
    args.form = False
    args.files = False
    headers = RequestHeadersDict()
    headers["User-Agent"] = DEFAULT_UA
    headers["Accept"] = "application/json, */*;q=0.5"
    assert headers == make_default_headers(args)
    args.json = True
    args.data = None
    args.form = False
    args.files = False
    headers = RequestHeadersDict()
    headers["User-Agent"] = DEFAULT_UA
    headers["Accept"] = "application/json, */*;q=0.5"
    headers["Content-Type"] = JSON_CONTENT_TYPE
    assert headers == make_default_headers(args)
    args.json = False
    args

# Generated at 2022-06-21 13:38:47.227047
# Unit test for function finalize_headers
def test_finalize_headers():
    import re

    if re.search(r'^[0-9.-]+$', __version__) is None:
        # Only run in releases, not in development versions.
        return

    assert finalize_headers(headers=RequestHeadersDict({
        ' Content-Type ': 'application/json',
        'User-Agent ': 'HTTPie/0.9.9',
        'X-Custom ': ' foo ',
    })) == RequestHeadersDict({
        'Content-Type': b'application/json',
        'User-Agent': b'HTTPie/0.9.9',
        'X-Custom': b'foo',
    })

# Generated at 2022-06-21 13:38:51.723574
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env() == {
        'proxies': {},
        'stream': True,
        'verify': {'yes': True, 'true': True, 'no': False, 'false': False}.get('yes'),
        'cert': None
    }

# Generated at 2022-06-21 13:38:53.602722
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 1000