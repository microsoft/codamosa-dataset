

# Generated at 2022-06-21 13:29:56.137492
# Unit test for function dump_request

# Generated at 2022-06-21 13:30:03.589633
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = "yes"
    args.proxy = []
    args.cert = "cert.pem"
    args.cert_key = "cert_key.pem"

    output = make_send_kwargs_mergeable_from_env(args)
    assert output == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': "cert.pem",
    }

# Generated at 2022-06-21 13:30:15.226978
# Unit test for function build_requests_session
def test_build_requests_session():
    from httpie.plugins.builtin import HTTPieHTTPSAdapter

    requests_session = build_requests_session(
        ssl_version='TLS', verify=True, ciphers='DEFAULT')
    # The session is created
    assert isinstance(requests_session, requests.Session)
    # The HTTPIE HTTPS Adapter is installed
    assert isinstance(
        requests_session.adapters['https://'], HTTPieHTTPSAdapter)
    # The correct SSL version 'PROTOCOL_TLS' is used
    assert requests_session.adapters['https://'].ssl_version == 'PROTOCOL_TLS'
    # The correct ciphers 'DEFAULT' is used
    assert requests_session.adapters['https://'].ciphers == 'DEFAULT'
    # Cert verification is set to False

# Generated at 2022-06-21 13:30:20.359216
# Unit test for function dump_request
def test_dump_request():
    r_dict = {}
    r_dict['method'] = 'POST'
    r_dict['url'] = 'http://127.0.0.1:8080/login'
    r_dict['headers'] = {'Content-Type':'application/json'}
    r_dict['data'] = 'hello world'
    dump_request(r_dict)

# Generated at 2022-06-21 13:30:22.994085
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')
    assert http.client._MAXHEADERS == 100

# Test for function ensure_path_as_is

# Generated at 2022-06-21 13:30:23.973254
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session(True, None, None)

# Generated at 2022-06-21 13:30:31.113319
# Unit test for function finalize_headers
def test_finalize_headers():
    """
    Tests the function finalize_headers

    :return: None
    """
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })

    final_headers = RequestHeadersDict()
    for name, value in headers.items():
        if value is not None:
            # “leading or trailing LWS MAY be removed without
            # changing the semantics of the field value”
            # <https://www.w3.org/Protocols/rfc2616/rfc2616-sec4.html>
            # Also, requests raises `InvalidHeader` for leading spaces.
            value = value.strip()
            if isinstance(value, str):
                # See <https://github.com/httpie/httpie/issues/212>
                value = value.encode('utf8')

# Generated at 2022-06-21 13:30:43.471918
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.argv = {'fake'}
    args.session = None
    args.session_read_only = None
    args.stream = False
    args.verbose = False
    args.headers = []
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.download = False
    args.force_colors = False
    args.timeout = 30
    args.max_redirects = None
    args.check_status = False
    args.json = False
    args.form = False
    args.style = 'default'
    args.style_sheet = None
    args.print_headers = False
    args.download_dir = None
    args.all = False
    args.output_file = None
    args

# Generated at 2022-06-21 13:30:50.475182
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import argparse
    from httpie.auth import AuthCredentials

    class Args(argparse.Namespace):
        pass

    args = Args()
    args.verify = 'True'
    args.proxy = [('http', 'http://httpbin.org')]
    args.cert = '/home/roka/cert.pem'
    args.cert_key = '/home/roka/cert_key.pem'
    args.auth = AuthCredentials('foo:bar')

    make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-21 13:30:51.823768
# Unit test for function build_requests_session
def test_build_requests_session():
    def test_build_requests_session_assert(assertion):
        assert assertion

    test_build_requests_session_assert(build_requests_session)

# Generated at 2022-06-21 13:31:29.196756
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        data=None,
        files=None,
        form=False,
        json=None,
        headers=[],
        auth=None,
        params={},
        method='GET',
        timeout=(10.5, 200),
        chunked=False,
        offline=False,
        verify='yes',
        cert=None,
        cert_key=None,
        proxy=[],
        follow=True,
        max_redirects=10,
        max_headers=0,
        compress=0,
        debug=False,
        session=None,
        session_read_only=None,
        ssl_version='secure',
        ciphers=None,
        auth_plugin=None,
        url='www.test.com',
    )
    request_kwargs

# Generated at 2022-06-21 13:31:37.192922
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(files=None, data=None, form=None, json=False)
    assert make_default_headers(args).get('Content-Type') is None

    args = argparse.Namespace(files=None, data=None, form=True, json=False)
    assert make_default_headers(args).get('Content-Type') == FORM_CONTENT_TYPE

    args = argparse.Namespace(files=None, data=None, form=False, json=True)
    assert make_default_headers(args).get('Content-Type') == JSON_CONTENT_TYPE
    assert make_default_headers(args).get('Accept') == JSON_ACCEPT

    args = argparse.Namespace(files=None, data={}, form=False, json=True)

# Generated at 2022-06-21 13:31:42.237256
# Unit test for function build_requests_session
def test_build_requests_session():
    args = argparse.Namespace()
    args.ssl_version = None
    args.ciphers = None
    args.verify = True
    session = build_requests_session(args.verify, args.ssl_version, args.ciphers)
    assert session is not None

# Generated at 2022-06-21 13:31:46.493639
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = '/'
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args,config_dir,request_body_read_callback)



# Generated at 2022-06-21 13:31:51.996441
# Unit test for function max_headers
def test_max_headers():
    """
    The function without any input should do nothing.
    """
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000


# Generated at 2022-06-21 13:31:57.930751
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/bar', 'http://foo/bar?foo=bar') == 'http://foo/bar?foo=bar'
    assert ensure_path_as_is('http://foo/bar', 'http://foo/?foo=bar') == 'http://foo/bar?foo=bar'



# Generated at 2022-06-21 13:32:03.762488
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({'Accept': ' application/json  , */*;q=0.5'})
    expected = RequestHeadersDict({'Accept': 'application/json, */*;q=0.5'})
    assert finalize_headers(headers) == expected

# Generated at 2022-06-21 13:32:06.280104
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:32:08.172820
# Unit test for function build_requests_session
def test_build_requests_session():
    req_ses=build_requests_session(False)
    req_ses=build_requests_session(True)

# Generated at 2022-06-21 13:32:14.614762
# Unit test for function dump_request
def test_dump_request():
    dump_request({
        'method': 'GET',
        'url': 'http://httpbin.org/get',
        'headers': {'User-Agent': 'HTTPie/0.9.2'},
        'auth': ('user', 'pass'),
        'params': (('q', ''), ('foo', 'bar')),
        'cookies': {'a': 'b'}
    })

# Generated at 2022-06-21 13:32:53.718576
# Unit test for function build_requests_session
def test_build_requests_session():
    # TODO: Improve unit test by checking that the adapter has been added to the session
    # TODO: Improve unit test by checking that the plugin adapter has been added to the session
    session = build_requests_session(verify=True, ssl_version='TLSv1', ciphers='SSL_RSA_WITH_RC4_128_MD5')
    # TODO: Add asserts to test fail condition



# Generated at 2022-06-21 13:32:58.990427
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout = 10,
        allow_redirects = False,
    )
    assert make_send_kwargs(args) == {
        'timeout': 10,
        'allow_redirects': False,
    }

# Generated at 2022-06-21 13:32:59.990942
# Unit test for function dump_request
def test_dump_request():
    assert(dump_request(kwargs={'test':1}) == 'test')

test_dump_request()

# Generated at 2022-06-21 13:33:03.797131
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout=None
    args.allow_redirects = False
    kwargs = {'timeout': None, 'allow_redirects': False}
    assert kwargs == make_send_kwargs(args)



# Generated at 2022-06-21 13:33:06.020974
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-21 13:33:08.191997
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, "TLSv1_2", None)
    assert isinstance(session, requests.Session)


# Generated at 2022-06-21 13:33:14.545190
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import copy
    import json
    import requests
    from httpie import auth
    from . import utils
    from .utils import MockServerTestCase
    from .utils import MockServer

    class TestMakeRequestKwargs(MockServerTestCase):

        def test_headers(self):
            args = mock_args('-a', 'test:password', self.mock_url, '--headers',
                             'X-Foo: bar', 'X-Biz:baz')
            kwargs = make_request_kwargs(args)
            self.assertEqual(kwargs['headers'], {
                'User-Agent': DEFAULT_UA,
                'X-Foo': 'bar',
                'X-Biz': 'baz',
            })

        def test_auth(self):
            args = mock_args

# Generated at 2022-06-21 13:33:26.002232
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    arg = argparse.Namespace()
    arg.auth = None
    arg.auth_type = None
    arg.cert = None
    arg.cert_key = None
    arg.ciphers = None
    arg.data = ''
    arg.debug = False
    arg.files = ''
    arg.form = False
    arg.headers = None
    arg.http2 = False
    arg.ignore_stdin = False
    arg.method = 'GET'
    arg.multipart = False
    arg.proxy = None
    arg.redirect = True
    arg.timeout = None
    arg.traceback = False
    arg.url = 'https://api.github.com/'
    arg.verify = 'yes'
    arg.verify_tunnel = False
    kwargs = make_send_kw

# Generated at 2022-06-21 13:33:36.184791
# Unit test for function make_default_headers
def test_make_default_headers():
    test_json = "test.json"
    test_form = "test.form"
    args_json = argparse.Namespace(
        data = test_json,
        form = False,
        json = True,
        files = False,
        headers = [],
        method = "",
        timeout = None,
        url = "",
        auth = [],
        params = [],
        proxy = [],
        cert = None,
        cert_key = None,
        json_pp = [],
        chunked = False,
        offline = False,
    )

# Generated at 2022-06-21 13:33:37.695204
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=3.14,
        allow_redirects=False,
    )
    make_send_kwargs(args)
    return True

# Generated at 2022-06-21 13:37:06.390566
# Unit test for function dump_request

# Generated at 2022-06-21 13:37:12.831467
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    argparse.Namespace.__dict__['timeout']=5
    argparse.Namespace.__dict__['allow_redirects']=True

    args = argparse.Namespace()
    kwargs = {
        'timeout': args.timeout or None,
        'allow_redirects': False,
    }

    make_send_kwargs(args)
    assert make_send_kwargs(args) == kwargs



# Generated at 2022-06-21 13:37:14.680811
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    url_expected = 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == url_expected

# Generated at 2022-06-21 13:37:17.567123
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    ssl_version = None
    ciphers = None
    session = build_requests_session(verify, ssl_version, ciphers)
    assert session is not None
    session.close()

# Generated at 2022-06-21 13:37:20.472796
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = None
    print( http.client._MAXHEADERS)
    with max_headers(5):
        print( http.client._MAXHEADERS)
    print( http.client._MAXHEADERS)



# Generated at 2022-06-21 13:37:24.849318
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/?foo=bar', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo/path/?foo=bar', 'http://foo/?foo=bar') == 'http://foo/path/?foo=bar'

# Generated at 2022-06-21 13:37:36.452797
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert(
        ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') ==
        'http://foo/../?foo=bar'
    )
    assert(
        ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') ==
        'http://foo/../?foo=bar'
    )
    assert(
        ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') ==
        'http://foo/../?foo=bar'
    )

    assert(
        ensure_path_as_is('http://foo/../?foo=bar', 'http://foo/?foo=bar') ==
        'http://foo/?foo=bar'
    )

# Generated at 2022-06-21 13:37:40.744095
# Unit test for function build_requests_session
def test_build_requests_session():

    tests = [
        {
            'description': '', 'ssl_version': None, 'ciphers': None,
            'verify': True, 'expected': '<requests.sessions.Session object at 0x7f6a9c597f60>',
        },
    ]

    for test in tests:
        result = build_requests_session(
            ssl_version=test['ssl_version'],
            ciphers=test['ciphers'],
            verify=test['verify'],
        )
        assert str(result) == test['expected']


# Generated at 2022-06-21 13:37:43.404678
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}



# Generated at 2022-06-21 13:37:52.966344
# Unit test for function collect_messages
def test_collect_messages():
    args={'base_headers': {'foo': 'bar'}, 'method': 'GET', 'url': 'http://foo/bar', 'headers': {'Content-Type': 'application/json'}, 'data': {'foo': 'bar'},
        'files': [], 'auth': None, 'timeout': None, 'allow_redirects': False, 'proxies': {}, 'stream': True, 'verify': True,
         'cert': None, 'ssl_version': 'TLS', 'ciphers': None}
    config_dir=Path('/home/xkania/Desktop')
    collect_messages(args, config_dir)