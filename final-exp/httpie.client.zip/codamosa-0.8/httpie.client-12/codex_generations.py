

# Generated at 2022-06-11 23:12:29.342500
# Unit test for function max_headers
def test_max_headers():
    # create a header dictionary
    header_dict = {'headers': 'foo'}

    with max_headers(limit=1):
        # set max header to 1
        http.client._MAXHEADERS = 1
        # try to add a second header to the dictionary
        header_dict['headers2'] = 'bar'
    # ensure that the second header was not added to the dictionary
    assert 'headers2' not in header_dict


# Generated at 2022-06-11 23:12:39.566559
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Make a test namespace
    class TestNamespace(argparse.Namespace):
        def __init__(self):
            self.proxy = ["http://127.0.0.1:8080"]
            self.verify = "test"
            self.cert = "test"
            self.cert_key = "test"

    namespace = TestNamespace()
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(namespace)
    # Make a list of all the arguments that should be in the arguments and check whether they are in the dictionary
    expected_arguments = ['proxies', 'stream', 'verify', 'cert']

# Generated at 2022-06-11 23:12:42.793841
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 1000
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-11 23:12:52.665013
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data='{"foo": "bar"}',
        files=None,
        form=False,
        offline=False,
        raw_response=False,
        json=False,
        headers=RequestHeadersDict(),
        chunked=False,
    )
    dhs = make_default_headers(args)
    assert dhs['Content-Type'] == JSON_CONTENT_TYPE
    assert dhs['Accept'] == JSON_ACCEPT
    args = argparse.Namespace(
        data='foo=bar&bar=baz',
        files=None,
        form=True,
        offline=False,
        raw_response=False,
        json=False,
        headers=RequestHeadersDict(),
        chunked=False,
    )
    dhs = make_default_

# Generated at 2022-06-11 23:13:01.200540
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli import parser
    import requests
    from httpie.utils import get_unicode_writer
    args = parser.parse_args(['GET', 'http://httpbin.org/'])
    file = open('message.txt', 'w')
    # writer = get_unicode_writer(file, 'utf8', 'strict')
    for i in collect_messages(args, Path('./')):
        writer.write(str(i))
        # if isinstance(i, requests.PreparedRequest):
        #     writer.write(str(i))
        # else:
        #     print(i.headers)

# Generated at 2022-06-11 23:13:10.808687
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [urlparse('https://127.0.0.1:8080')]
    args.verify = True
    args.cert = 'cert.pem'
    args.cert_key = 'cert-key-pem'

    results = make_send_kwargs_mergeable_from_env(args)
    assert  results['proxies'] == {'https': 'https://127.0.0.1:8080'}
    assert  results['stream'] == True
    assert  results['verify'] == True
    assert  results['cert'] == ('cert.pem', 'cert-key-pem')



# Generated at 2022-06-11 23:13:18.568999
# Unit test for function max_headers
def test_max_headers():
    limit = 2
    http.client._MAXHEADERS = limit
    kwargs = {'headers': {
        'Content-Length': '333',
        'X-Header1': 'value1',
        'X-Header2': 'value2',
        'X-Header3': 'value3'
    }}
    with max_headers(limit):
        requests.request(**kwargs)
    assert kwargs['headers'].keys == {'X-Header2', 'X-Header3'}

# Generated at 2022-06-11 23:13:24.757898
# Unit test for function max_headers
def test_max_headers():
    args = argparse.Namespace(max_headers=4)

# Generated at 2022-06-11 23:13:36.178046
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from argparse import Namespace
    params = ['--auth-type=basic', '--auth=user:password', '--form', '-H', 'Authorization:Basic', '--data', '{"a":1, "b": [1, 2, 3], "c": "abc"}', 'http://127.0.0.1:8001/']
    args = Namespace(auth_type='basic', auth=('user', 'password'), form=True, headers={'Authorization': 'Basic'}, data={'a': 1, 'b': [1, 2, 3], 'c': 'abc'}, url='http://127.0.0.1:8001/')
    kw = make_request_kwargs(args)

# Generated at 2022-06-11 23:13:41.661625
# Unit test for function finalize_headers
def test_finalize_headers():
    headers={"Content-Type":" application/json; \r\n\t charset=utf-8 "}
    headers=finalize_headers(headers)
    if headers['Content-Type']!='application/json; charset=utf-8':
        raise AssertionError()

# Generated at 2022-06-11 23:14:15.818320
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    assert http.client._MAXHEADERS != 5

# Generated at 2022-06-11 23:14:23.802702
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert {'proxies': {}, 'stream': True, 'verify': True, 'cert': None} == make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='true', proxy=[], cert=None, cert_key=None))
    assert {'proxies': {}, 'stream': True, 'verify': False, 'cert': None} == make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='false', proxy=[], cert=None, cert_key=None))

# Generated at 2022-06-11 23:14:33.775574
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Test
    args = argparse.Namespace(method='get',
                              url='http://example.com/hello-world',
                              headers=[],
                              data=[],
                              json=False,
                              form=False,
                              files=[],
                              auth='',
                              params=[],
                              verify=True,
                              cert='',
                              cert_key='',
                              timeout=None,
                              proxy=[],
                              chunked=False,
                              offline=True,
                              compress=False,
                              stream=None,
                              max_redirects=None,
                              max_headers=None)

# Generated at 2022-06-11 23:14:43.894538
# Unit test for function max_headers
def test_max_headers():
    import contextlib
    import io
    import sys
    import time

    http.client._MAXLINE = 0  # To enable testing

    class StderrBuffer(io.StringIO):
        def __init__(self):
            super().__init__()
            self.truncated = 0

        def write(self, s):
            if self.tell() > 0:
                if (self.getvalue()[-2:] + s).endswith('\r\n'):
                    self.truncated += 1
                    super().seek(0)
            super().write(s)


# Generated at 2022-06-11 23:14:44.871248
# Unit test for function max_headers
def test_max_headers():
    max_headers(5)

# Generated at 2022-06-11 23:14:57.939236
# Unit test for function collect_messages

# Generated at 2022-06-11 23:15:06.314742
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    timeout = 10
    args.timeout = timeout
    assert make_send_kwargs(args).get('timeout') == timeout
    args.timeout = None
    assert make_send_kwargs(args).get('timeout') == None
    args.allow_redirects = True
    assert make_send_kwargs(args).get('allow_redirects') == False
    args.allow_redirects = False
    assert make_send_kwargs(args).get('allow_redirects') == False


# Generated at 2022-06-11 23:15:14.701444
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
    import sys
    from httpie.cli import main

    url = 'https://httpbin.org/post'
    method = 'post'
    headers = {"X-Header-1": "asd", "X-Header-2": "aasd"}
    data = {"title": "foo", "body": "bar", "userId": 1}

    argv = [
        '--json',
        '--ignore-stdin',
        '--verbose',
        '-H',
        'X-Header-1:asd',
        '-H',
        'X-Header-2:aasd',
        method,
        url,
        'title=foo',
        'body=bar',
        'userId=1',
    ]


# Generated at 2022-06-11 23:15:24.570532
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    def test1():
        args = argparse.Namespace()
        args.json = True
        args.data = {}
        # print(json.dumps(make_request_kwargs(args)))

    def test2():
        args = argparse.Namespace()
        args.json = False
        args.data = {"a":"b", "c":"d"}
        # print(json.dumps(make_request_kwargs(args)))

    def test3():
        args = argparse.Namespace()
        args.json = False
        args.data = {"a":"b", "c":"d"}
        args.form = True
        # print(json.dumps(make_request_kwargs(args)))

    def test4():
        args = argparse.Namespace()
        args.json = False
        args.data

# Generated at 2022-06-11 23:15:36.187122
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.url = "https://www.baidu.com"
    args.method = "GET"
    args.headers = {}
    args.data = {}
    args.json = False
    args.form = False
    args.files = False
    args.auth = None
    args.params = {}
    args.timeout = None
    args.compress = False
    args.debug = True
    args.traceback = False
    args.output_file = ""
    args.output_dir = ""
    args.output_options = {}
    args.style = ""
    args.style_sheet = ""
    args.style_sheet_path = ""
    args.style_sheet_data = ""
    args.style_sheet_data_url = ""
    args.style_sheet

# Generated at 2022-06-11 23:16:11.357479
# Unit test for function max_headers
def test_max_headers():
    class MockRaw:
        def __init__(self):
            self._headers = {'test': '123'}

    class MockRes:
        def __init__(self):
            self.msg = MockRaw()

    class MockReq:
        def __init__(self):
            self._original_response = MockRes()

    with max_headers(100):
        assert http.client._MAXHEADERS == 100
        MockReq()
        assert http.client._MAXHEADERS == 100

# Generated at 2022-06-11 23:16:21.357935
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'post'
    args.url = 'http://www.google.com'
    args.headers = {}
    args.data = '{"name": "yo"}'
    args.json = None
    args.form = None
    args.files = None
    args.multipart = None
    args.multipart_data = None
    args.boundary = None
    args.json_pp = None
    args.style = None
    args.offline = None
    args.chunked = None
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.auth_pass = None
    args.proxy = None
    args.timeout = None
    args.verify = None
    args.stream = None

# Generated at 2022-06-11 23:16:29.989925
# Unit test for function max_headers
def test_max_headers():
    # test for function max_headers with float('inf')
    with max_headers(float('inf')):
        import http.client
        # http.client._MAXHEADERS = float('inf')
        assert http.client._MAXHEADERS == float('inf')
    # test for function max_headers with 100
    with max_headers(100):
        import http.client
        # http.client._MAXHEADERS = 100
        assert http.client._MAXHEADERS == 100
    # test for function max_headers with 200
    with max_headers(200):
        import http.client
        # http.client._MAXHEADERS = 200
        assert http.client._MAXHEADERS == 200

# Generated at 2022-06-11 23:16:31.249308
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None):
        print(http.client._MAXHEADERS)

# Generated at 2022-06-11 23:16:42.198084
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    from httpie.plugins import plugin_manager
    from httpie.downloads import StreamingMultipartEncoderMonitor
    from httpie.compat import urlunparse
    plugin_manager.load_installed_plugins()

# Generated at 2022-06-11 23:16:45.386136
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = None
    args.verify = 'no'
    args.cert = ''
    args.cert_key = ''

    assert make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-11 23:16:55.385007
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    req_dict = dict()
    req_dict['method'] = 'post'
    req_dict['url'] = 'http://localhost:8000/api/restful/'
    req_dict['headers'] = {'Authorization': 'Basic ajdkjfklsdajf'}
    req_dict['data'] = {'username': 'test', 'password': 'test'}

    obj = collections.namedtuple('Namespace', 'method url headers data')
    args = obj(req_dict['method'], req_dict['url'], req_dict['headers'], req_dict['data'])

    result = make_request_kwargs(args)
    assert(req_dict == result)

# Generated at 2022-06-11 23:17:02.480944
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_ = argparse.Namespace(timeout=None, allow_redirects=False)
    kwargs_ = make_send_kwargs(args=args_)
    assert "timeout" in kwargs_
    assert "allow_redirects" in kwargs_
    assert kwargs_.get("timeout") is None
    assert kwargs_.get("allow_redirects") is False
    assert kwargs_.get("anything") is None
    assert kwargs_.get("something") is None



# Generated at 2022-06-11 23:17:12.427289
# Unit test for function max_headers
def test_max_headers():
    try:
        import http.client as http_client
        http_client.HTTPConnection._http_vsn_str = 'HTTP/1.1'
    except ImportError:
        # Python 2
        import httplib
        httplib.HTTPConnection._http_vsn_str = 'HTTP/1.1'
    # <https://github.com/requests/requests/blob/master/tests/test_utils.py>
    # noinspection PyAbstractClass,PyPep8Naming
    class TestHTTPConnection(httplib.HTTPConnection):
        def __init__(self):
            httplib.HTTPConnection.__init__(self, host='example.com')
            self.headers = None

        def send(self, str):
            self.headers = httplib.parse_headers(str)

   

# Generated at 2022-06-11 23:17:14.815995
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(True, 'TLSv1.3', 'TLS13-AES-256-GCM-SHA384')

# Generated at 2022-06-11 23:18:09.020307
# Unit test for function max_headers

# Generated at 2022-06-11 23:18:17.263103
# Unit test for function collect_messages
def test_collect_messages():
    print("testing collect_messages")

# Generated at 2022-06-11 23:18:21.102710
# Unit test for function max_headers
def test_max_headers():
    import http.client

    def run_context_manager():
        with contextmanager(limit) as x:
            print(http.client._MAXHEADERS)
            return x

    limit = 10
    assert run_context_manager() == 10

    limit = 100
    assert run_context_manager() == 100

# Generated at 2022-06-11 23:18:28.313558
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = {}
    args.json = False
    args.form = False
    args.files = []
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] == 'application/json, */*;q=0.5'
    assert headers['Content-Type'] == 'application/json'
    args.data = {}
    args.json = True
    args.form = False
    args.files = []
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] == 'application/json, */*;q=0.5'
    assert headers['Content-Type'] == 'application/json'

# Generated at 2022-06-11 23:18:31.734675
# Unit test for function make_default_headers
def test_make_default_headers():
    arg_namespace = argparse.Namespace()
    h = make_default_headers(arg_namespace)
    h = str(h)
    assert 'User-Agent: '+DEFAULT_UA in h


# Generated at 2022-06-11 23:18:33.843211
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    requests_session = build_requests_session(verify=verify)
    assert requests_session != None

# Generated at 2022-06-11 23:18:44.343581
# Unit test for function make_request_kwargs
def test_make_request_kwargs():

    class Namespace(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-11 23:18:54.821704
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import sys

    sys.path.append('../')


# Generated at 2022-06-11 23:19:03.375739
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        url='http://a.b/',
        method='GET',
        auth=None,
        headers=RequestHeadersDict({
            'User-Agent': 'abc',
            'Host': 'a.b',
        }),
        data=None,
        max_redirects=1,
        files={},
        json=False,
        form=False,
        params={},
    )
    print(make_request_kwargs(args=args))


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 23:19:05.053085
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=10):
        assert http.client._MAXHEADERS == 10



# Generated at 2022-06-11 23:20:32.669210
# Unit test for function max_headers
def test_max_headers():
    class TestArgs:
        max_headers = 2
    
    args = TestArgs()
    with max_headers(args.max_headers) as x:
        assert http.client._MAXHEADERS == args.max_headers



# Generated at 2022-06-11 23:20:35.153467
# Unit test for function collect_messages
def test_collect_messages():
    # prepare the argument needed to initialize an argparse.Namespace
    pass

# Generated at 2022-06-11 23:20:45.846272
# Unit test for function make_default_headers
def test_make_default_headers():
    from collections import UserDict
    from httpie.input import KeyValue, KeyValueArgType
    from httpie.cli import parser

    args = parser.parse_args(argv=['GET', 'https://127.0.0.1', '--json'])
    input = KeyValueArgType()
    headers = RequestHeadersDict()
    headers['Content-Type'] = 'application/json'
    headers['Accept'] = 'application/json, */*;q=0.5'
    headers['User-Agent'] = 'HTTPie/{}'.format(__version__)
    expected = headers
    assert make_default_headers(args=args) == expected

    args = parser.parse_args(argv=['GET', 'https://127.0.0.1', '--form'])
    input = KeyValueArgType

# Generated at 2022-06-11 23:20:56.319944
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.session = False
    args.session_read_only = False
    args.debug = False
    args.path_as_is = False
    args.compress = False
    args.offline = False
    args.max_headers = None
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.timeout = None
    args.verify = None
    args.chunked = False
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.json = False
    args.form = False
    args.data = False
    config_dir = Path(".")
    request_body_read_callback = None

# Generated at 2022-06-11 23:21:05.674417
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.data = {"id":1,"name":"john"}
    args.form = False
    args.json = True
    args.headers = {"Content-Type":JSON_CONTENT_TYPE}
    args.method = "post"
    args.url = "http://jsonplaceholder.typicode.com/todos"
    args.auth = None
    kwargs = make_request_kwargs(args,base_headers=None)
    print(kwargs)
    assert(kwargs["data"] == json.dumps(args.data))
    assert(kwargs["headers"]["Content-Type"] == JSON_CONTENT_TYPE)
    assert(kwargs["method"] == "post")

# Generated at 2022-06-11 23:21:10.475588
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli import parser

    args = parser.parse_args(args=['--verify', 'no'])
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {}, 'stream': True, 'verify': False, 'cert': None}

# Generated at 2022-06-11 23:21:16.690336
# Unit test for function collect_messages
def test_collect_messages():
    import httpie.cli
    args = httpie.cli.parser.parse_args(args=['GET','https://www.baidu.com/'])

    config_dir = Path('/Users/biantiao/.config/httpie')
    msgs = collect_messages(
        args=args,
        config_dir=config_dir,
    )
    for msg in msgs:
        print(msg)


if __name__ == "__main__":
    test_collect_messages()

# Generated at 2022-06-11 23:21:19.995405
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.files = False
    args.data = {}
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/1.0.3'}

# Generated at 2022-06-11 23:21:29.045619
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    # set default value
    args.json = False
    args.form = False
    args.data = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': f'HTTPie/{__version__}'}

    # data == True,json == False, form == False
    args.data = True
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': f'HTTPie/{__version__}', 'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'}

    # data == True, json == True, form == False
    args.json = True
   

# Generated at 2022-06-11 23:21:34.879782
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = ['1', '2']
    args.verify = 'yes'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    result = make_send_kwargs_mergeable_from_env(args)
    assert result['proxies'] == {'1': '2'}
    assert result['verify'] == True
    assert result['cert'] == 'cert'
    assert result['cert_key'] == 'cert_key'