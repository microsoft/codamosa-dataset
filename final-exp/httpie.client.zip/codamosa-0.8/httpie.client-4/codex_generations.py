

# Generated at 2022-06-11 23:12:30.150637
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'post'
    args.timeout = 1
    args.allow_redirects = True
    args.json = True
    args.form = True
    args.data = {}
    args.chunked = False
    args.offline = False
    headers = RequestHeadersDict()
    headers['test'] = 'test'
    args.headers = headers
    args.auth = None
    args.params = {}
    args.auth_plugin = None
    args.files = {}
    args.follow = False

    c = make_request_kwargs(args)
    assert c['method'] == 'post'
    assert c['method'] == 'post'
    assert c['url'] == 'localhost'

# Generated at 2022-06-11 23:12:40.140360
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    send_kwargs = make_send_kwargs(args=dict(timeout=2))
    if not(send_kwargs['timeout'] == 2 and not send_kwargs['allow_redirects']):
        sys.exit(1)
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(
        args=dict(proxy=[dict(key="https", value="127.0.0.1"),
                          dict(key="http", value="127.0.0.2")],
                  verify=True,
                  cert="cert.pem",
                  cert_key="key.pem",
                  )
    )

# Generated at 2022-06-11 23:12:46.310577
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {}
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

# Generated at 2022-06-11 23:12:51.257486
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        files=[],
        form=False,
        headers={},
        json=None,
        max_headers=100,
        offline=True
    )
    headers = make_default_headers(args)

    assert(headers['Content-Type'] == 'application/json')
    assert(headers['User-Agent'] == DEFAULT_UA)

# Generated at 2022-06-11 23:13:01.862820
# Unit test for function collect_messages
def test_collect_messages():
    import httpie.utils
    import tempfile


# Generated at 2022-06-11 23:13:04.573868
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 1
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': 1, 'allow_redirects': False}



# Generated at 2022-06-11 23:13:11.243727
# Unit test for function build_requests_session
def test_build_requests_session():
    is_adapter_installed = False

    # noinspection PyUnusedLocal
    def mock_plugin_cls():
        nonlocal is_adapter_installed
        is_adapter_installed = True

    plugin_manager.get_transport_plugins = lambda: [mock_plugin_cls
                                                    ]
    build_requests_session(verify=True)
    assert is_adapter_installed



# Generated at 2022-06-11 23:13:22.781613
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.proxy = []
    args.verify = []
    args.cert = None
    args.cert_key = None

    kwargs = make_send_kwargs(args=args)

    test_result = {
        'timeout': args.timeout or None,
        'allow_redirects': False,
        'proxies': {p.key:p.value for p in args.proxy},
        'stream': True,
        'verify': {
            'yes': True,
            'true': True,
            'no': False,
            'false': False,
        }.get(args.verify.lower(), args.verify),
        'cert': args.cert,
    }

    assert kwargs == test_result

# Generated at 2022-06-11 23:13:34.106911
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        '\n': '\n',
        ' ': ' ',
        '   ': '   ',
        '\n\n\n\n': '\n\n\n\n',
        '\n \n': '\n \n',
        'host': 'host\nhost',
        'host ': 'host\nhost',
        '\nhost': 'host\nhost',
        '\nhost\n': 'host\nhost',
        'content-type': 'application/x-www-form-urlencoded; charset=utf-8',
        'Content-Type': 'application/json'
    })
    final_headers = finalize_headers(headers)

# Generated at 2022-06-11 23:13:46.977188
# Unit test for function collect_messages

# Generated at 2022-06-11 23:14:09.694011
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = None
    args.verify = False
    args.cert = None
    args.cert_key = None
    print (make_send_kwargs_mergeable_from_env(args))



# Generated at 2022-06-11 23:14:20.657936
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:14:31.944130
# Unit test for function make_send_kwargs

# Generated at 2022-06-11 23:14:35.193026
# Unit test for function max_headers
def test_max_headers():
    """
    Test function max_headers
    """
    with max_headers(100) as n:
        n = n + 100
    assert n == 100


if __name__ == '__main__':
    test_max_headers()

# Generated at 2022-06-11 23:14:40.743371
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    req=make_request_kwargs({})
    assert req=={'allow_redirects': False, 'data': {}, 'headers': {'User-Agent': 'HTTPie/1.0.2'}, 'method': 'get', 'url': 'http://localhost:8181'}

# Generated at 2022-06-11 23:14:51.694661
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=[], verify=True)
    result = make_send_kwargs_mergeable_from_env(args)
    assert result == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    args = argparse.Namespace(proxy=[], verify=False)
    result = make_send_kwargs_mergeable_from_env(args)
    assert result == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': None,
    }
    args = argparse.Namespace(
        proxy=[], verify=True, cert='foo', cert_key='bar'
    )
    result = make_send_kwargs_mer

# Generated at 2022-06-11 23:15:00.753368
# Unit test for function max_headers
def test_max_headers():
    """
    Unit-test to check if max_headers function works properly
    """

    # https://github.com/httpie/httpie/issues/802
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 1000

    # Using max_headers as a context manager
    with max_headers(10):
        # noinspection PyUnresolvedReferences
        assert http.client._MAXHEADERS == 10

    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-11 23:15:11.901362
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = None
    args.form = None
    args.json = None

    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == '*/*'
    assert default_headers['Content-Type'] == 'application/x-www-form-urlencoded; charset=utf-8'

    args.json = True
    args.data = {'a': 2}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == 'application/json, */*;q=0.5'
    assert default_headers['Content-Type'] == 'application/json'

#

# Generated at 2022-06-11 23:15:22.776934
# Unit test for function collect_messages
def test_collect_messages():
    # Import neccessary library
    from httpie.cli.parser import parser
    from httpie.cli import version_value
    from httpie.config import Config
    from httpie.sessions import Items
    from httpie.sessions import get_httpie_session

    # Initialize args and config values ...
    args = parser.parse_args(['-b', 'http://www.host.name/path/to/file'])
    config = Config()
    config.output_options.pretty = True
    config.output_options.colors = False

    # ... as well pick a httpie session file
    items = config.load_sessions()
    items.items['test_session'] = Items.Item('http://www.host.name/path/to/file')

# Generated at 2022-06-11 23:15:27.548236
# Unit test for function build_requests_session
def test_build_requests_session():
    """
    Test case: Tests the functionality of build_requests_session with only https adapter
    Expected Output: httpie.ssl.HTTPieHTTPSAdapter object
    :return: True
    """
    requests_session = build_requests_session(True, None, None)
    assert isinstance(requests_session.adapters.get("https://"), HTTPieHTTPSAdapter)



# Generated at 2022-06-11 23:15:59.160116
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)


# Generated at 2022-06-11 23:16:02.186464
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-11 23:16:14.172992
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = '127.0.0.1:1080'
    args.verify = False
    args.cert = 'cacert.pem'
    args.cert_key = 'privatekey.pem'

    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {'http': '127.0.0.1:1080', 'https': '127.0.0.1:1080'}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == False
    assert kwargs['cert'] == ('cacert.pem', 'privatekey.pem')
    assert kwargs['allow_redirects'] == True

# Generated at 2022-06-11 23:16:19.268110
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 20
    args.cert = "cacert.pem"
    args.cert_key = "key.pem"
    args.proxy = {"http": "127.0.0.1", "https": "127.0.0.1"}
    args.verify = "yes"
    kwargs = make_send_kwargs(args)

    assert kwargs["timeout"] == 20
    assert kwargs["allow_redirects"] == False
    assert kwargs["proxies"] == {"http": "127.0.0.1", "https": "127.0.0.1"}
    assert kwargs["stream"] == True
    assert kwargs["verify"] == True

# Generated at 2022-06-11 23:16:30.187303
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-11 23:16:41.064406
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class FakeNamespace(object):
        def __init__(self):
            self.http_method = 'GET'
            self.url = 'http://foo.com/'
            self.headers = {}
            self.auth = None
            self.data = None
            self.json = False
            self.form = False
            self.compress = False
            self.timeout = None
            self.verify = True
            self.offline = False
            self.chunked = False
            self.auth_plugin = None
            self.cert = None
            self.cert_key = None
            self.proxy = None
            self.debug = False
            self.path_as_is = False
            self.max_headers = None
            self.follow = False
            self.max_redirects = None
            self.files

# Generated at 2022-06-11 23:16:51.488059
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie.core import main

    argv = ['http', 'example.com', '--auth', 'user:pass', '--json', '--form',
            'name=httpie&version=', '--chunked', '--compress']
    args = main.parse_args(argv)

# Generated at 2022-06-11 23:16:54.064064
# Unit test for function collect_messages
def test_collect_messages():
    try:
        collect_messages(None,None)
    except Exception as e:
        assert(e.args[0]=="test_collect_messages")

# Generated at 2022-06-11 23:17:03.964649
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    parser = argparse.ArgumentParser(description='HTTPie arguments')
    parser.add_argument('--timeout', type=int)
    parser.add_argument('--allow_redirects', action='store_true')
    args = parser.parse_args([])
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}

    args = parser.parse_args(['--timeout', '5'])
    assert make_send_kwargs(args) == {'timeout': 5, 'allow_redirects': False}

    args = parser.parse_args(['--allow_redirects'])
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': True}


# Generated at 2022-06-11 23:17:14.210423
# Unit test for function collect_messages
def test_collect_messages():
    try:
        from unittest import mock
    except ImportError:
        import mock
    from httpie.input import ParseError
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parser
    from httpie.context import Environment
    from httpie.output.streams import STDERR
    m = mock.Mock()
    m.parse_args.return_value = argparse.Namespace(url='http://example.com/')

# Generated at 2022-06-11 23:18:20.612240
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class A():
        def __init__(self,value):
            self.value = value
    a1 = A('http://127.0.0.1:1234')
    a2 = A('http://127.0.0.1:2345')
    a3 = A('http://127.0.0.1:3456')
    args = argparse.Namespace()
    args.proxy = [a1,a2,a3]
    args.verify = 'yes'
    args.cert = '127.0.0.1'
    args.cert_key = '234'
    result = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-11 23:18:25.952772
# Unit test for function max_headers
def test_max_headers():
    limit = 5
    headers = []
    for x in range(limit+1):
        d = {}
        d['name'] = 'a'*x
        d['value'] = 'a'*x
        headers.append(d)
     # httplib should raise error for request headers greater than limit:
    with pytest.raises(http.client.HTTPException):
        with max_headers(limit):
            conn = http.client.HTTPSConnection('localhost')
            conn.request('GET', '/', headers=headers)

# Generated at 2022-06-11 23:18:36.133139
# Unit test for function make_default_headers
def test_make_default_headers():
    from httpie.input import ParseArg
    from requests.models import CaseInsensitiveDict
    import pytest

    ua = 'HTTPie/0.9.4'

    # Test with json argument
    args = ParseArg(['-j', 'hi'])
    default_headers = CaseInsensitiveDict()
    default_headers['User-Agent'] = ua
    default_headers['Accept'] = JSON_ACCEPT
    default_headers['Content-Type'] = JSON_CONTENT_TYPE
    default_headers = default_headers.copy()

    assert default_headers == make_default_headers(args)

    # Test with form argument
    args = ParseArg(['-f', 'hi'])
    default_headers = CaseInsensitiveDict()
    default_headers['User-Agent'] = ua
    default_

# Generated at 2022-06-11 23:18:46.556904
# Unit test for function collect_messages

# Generated at 2022-06-11 23:18:49.176191
# Unit test for function max_headers
def test_max_headers():
    # <https://github.com/httpie/httpie/issues/802>
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-11 23:18:59.217113
# Unit test for function max_headers

# Generated at 2022-06-11 23:19:04.210388
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 1000  # Default value
    with max_headers(None):
        assert http.client._MAXHEADERS == 1000
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    with max_headers(10000):
        assert http.client._MAXHEADERS == 10000
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-11 23:19:10.848604
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = "yes"
    args.proxy = [Proxy('127.0.0.1:8080', 'http')]
    args.cert = "test.cert"
    args.cert_key = "test.key"
    assert len(make_send_kwargs_mergeable_from_env(args)) == 4
    assert len(make_send_kwargs_mergeable_from_env(args)['proxies']) == 1
    assert make_send_kwargs_mergeable_from_env(args)['verify']
    assert make_send_kwargs_mergeable_from_env(args)['cert'] == (args.cert, args.cert_key)

# Generated at 2022-06-11 23:19:21.782663
# Unit test for function collect_messages
def test_collect_messages():
    sys.argv = ['http', '--download', 'http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js&ip=118.28.8.8']
    args = parser.parse_args()
    #print(args)
    plugin_manager.load_builtin_plugins()
    plugin_manager.load_plugins(args.plugins)

    messages = collect_messages(args, config_dir=config_dir)

    for message in messages:
        print(message)
    #print(messages)

if __name__ == '__main__':
    config_dir = Path(os.path.expanduser('~/.config/httpie'))
    parser = get_parser(config_dir=config_dir)

    #print(parser)
    #print

# Generated at 2022-06-11 23:19:31.663237
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    from httpie.argtypes import KeyValueArg
    from httpie.sessions import session_name_from_url
    from httpie.config import Config
    from httpie.utils import expand_path


# Generated at 2022-06-11 23:21:37.239268
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import pytest
    args = pytest.importorskip("argparse").Namespace()
    args.timeout = None
    args.allow_redirects = False

    kwargs = make_send_kwargs(args)
    assert not kwargs

    args.timeout = 10
    args.allow_redirects = True

    kwargs = make_send_kwargs(args)
    assert kwargs.get('timeout') == 10
    assert kwargs.get('allow_redirects') == False

# Generated at 2022-06-11 23:21:45.320303
# Unit test for function max_headers
def test_max_headers():
    # Test for the normal case
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
        assert http.client._MAXHEADERS == 10
    # Test for the non-positive case
    with max_headers(0):
        assert http.client._MAXHEADERS == float('Inf')
        assert http.client._MAXHEADERS is float('Inf')
    # Test for the None case
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')
        assert http.client._MAXHEADERS is float('Inf')

# Generated at 2022-06-11 23:21:52.192134
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = json.dumps({'foo': 'bar'})
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = True
    args.form = False
    args.data = '{foo:bar}"'
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = False

# Generated at 2022-06-11 23:21:56.848445
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()

    args.timeout = 30
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)

    assert(kwargs['timeout'] == 30)
    assert(kwargs['allow_redirects'] == False)


# Generated at 2022-06-11 23:21:58.280640
# Unit test for function make_default_headers
def test_make_default_headers():
    assert 'User-Agent' in make_default_headers(object())

# Generated at 2022-06-11 23:22:05.556041
# Unit test for function make_default_headers
def test_make_default_headers():
    args=argparse.Namespace()
    headers=make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in headers
    args.json=True
    headers=make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    args.json=False
    headers=make_default_headers(args)
    assert 'Accept' not in headers
    assert 'Content-Type' not in headers
    args.form=True
    headers=make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE
    assert 'Accept' not in headers