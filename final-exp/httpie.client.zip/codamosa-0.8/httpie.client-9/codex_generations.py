

# Generated at 2022-06-11 23:12:21.797817
# Unit test for function max_headers
def test_max_headers():
    with max_headers(0):
        assert http.client._MAXHEADERS == 0
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-11 23:12:29.686712
# Unit test for function finalize_headers
def test_finalize_headers():
    print(finalize_headers({'a': 'b'}))
    print(finalize_headers({'a': '  b'}))
    print(finalize_headers({'a': 'b   '}))
    print(finalize_headers({'a': '  b   '}))
    print(finalize_headers({'a': '  b   c'}))
    print(finalize_headers({'a': '  b   c   '}))


if __name__ == '__main__':
    test_finalize_headers()

# Generated at 2022-06-11 23:12:36.554568
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    with patch('httpie.client.make_send_kwargs_mergeable_from_env', return_value={}):
        kwargs = make_send_kwargs(
            argparse.Namespace(
                verify=True,
                timeout=30,
                proxy=[],
                cert=None,
                cert_key=None,
            )
        )
        assert kwargs == {
            'timeout': 30,
            'allow_redirects': False,
        }

# Generated at 2022-06-11 23:12:40.369254
# Unit test for function make_default_headers
def test_make_default_headers():
    user_agent = ""
    args = {
        'json': '',
        'data': [],
        'form': ''
    }
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == user_agent

# Generated at 2022-06-11 23:12:46.571469
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = ''
    args.form = False
    args.json = False
    args.files = False
    actual = make_default_headers(args)
    expected = {'User-Agent': 'HTTPie/1.0.2'}
    assert actual == expected


# Generated at 2022-06-11 23:12:49.527299
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Content-Type': '  application/json  '}
    final_headers = finalize_headers(headers)
    assert '  application/json  ' not in final_headers.values()

# Generated at 2022-06-11 23:13:00.620943
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {
                     'Content-Type': 'application/json',
                     'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:58.0) Gecko/20100101 Firefox/58.0',
                     'Accept': '*/*',
                     'Accept-Language': 'en-US,en;q=0.5',
                     'Accept-Encoding': 'gzip, deflate',
                     'Referer': 'http://localhost:9000/',
                     'Content-Length': '24',
                     'Connection': 'close',
                     'Cookie': 'foo_session=...',
                     'Pragma': 'no-cache',
                     'Cache-Control': 'no-cache'
                  }
    final_headers = finalize_headers(headers)

# Generated at 2022-06-11 23:13:01.730996
# Unit test for function build_requests_session
def test_build_requests_session():
    b = build_requests_session()
    assert b != None

# Generated at 2022-06-11 23:13:05.611568
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    kwargs = make_send_kwargs_mergeable_from_env(None)
    assert kwargs['proxies'] == {}
    assert kwargs['verify'] == True
    assert kwargs['stream'] == True
    assert kwargs['cert'] == None

# Generated at 2022-06-11 23:13:10.136124
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = True
    args.form = False
    args.json = True
    args.session = 'testsession'
    
    headers = make_default_headers(args)
    print("headers: ", headers)

# Generated at 2022-06-11 23:13:57.455117
# Unit test for function collect_messages
def test_collect_messages():
    a = argparse.Namespace()
    a.headers = dict()
    a.headers['Content-Type'] = 'application/json'
    a.headers['Accept'] = 'application/json'
    a.url = 'https://httpie.org'
    a.method = 'get'
    a.json = True
    # a.data = json.dumps(r.json())
    a.data = r.json()
    a.session = None
    a.session_read_only = None
    a.auth_plugin = None
    a.debug = False
    a.path_as_is = False
    a.compress = 0
    a.offline = False
    a.chunked = 0
    a.timeout = None
    a.max_redirects = None
    a.follow = True


# Generated at 2022-06-11 23:14:07.794176
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:14:13.192658
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.headers = {'Host': 'httpbin.org'}
    args.method = 'GET'
    args.url = 'https://httpbin.org'

    kwargs = make_request_kwargs(args)
    assert 'User-Agent' in kwargs['headers']
    assert kwargs['url'] == 'https://httpbin.org'
    assert kwargs['method'] == 'get'
    assert kwargs['auth'] == None
    assert kwargs['params'] == []

# Generated at 2022-06-11 23:14:17.326565
# Unit test for function make_default_headers
def test_make_default_headers():
    from httpie.cli.parser import get_parser
    parser = get_parser()
    args = parser.parse_args(['GET', 'https://www.google.com'])
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-11 23:14:20.251234
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    kwarg = make_request_kwargs(args)
    print(kwarg)
    print(kwarg['headers'])
    print(kwarg['data'])

# Generated at 2022-06-11 23:14:27.750522
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    parser = argparse.ArgumentParser()
    parser.add_argument('--timeout')
    parser.add_argument('--allow-redirects', action='store_true')
    args, _ = parser.parse_known_args(['--timeout', '42', '--allow-redirects'])
    expected_kwargs = {
        'timeout': 42,
        'allow_redirects': True,
    }
    assert make_send_kwargs(args) == expected_kwargs

# Generated at 2022-06-11 23:14:31.538232
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        json = False,
        form = False,
        data = None,
        files = ()
    )
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-11 23:14:38.819629
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = None
    args.cert_key = None
    args.proxy = [
        argparse.Namespace(key='http', value='100.100.100.100:8080'),
        argparse.Namespace(key='https', value='100.100.100.100:8081')
    ]
    args.verify = 'no'
    result = make_send_kwargs_mergeable_from_env(args)

    assert result['cert'] == None
    assert result['proxies'] == {'http': '100.100.100.100:8080', 'https': '100.100.100.100:8081'}
    assert result['verify'] == False
    assert result['stream'] == True



# Generated at 2022-06-11 23:14:46.622538
# Unit test for function make_default_headers
def test_make_default_headers():
    res = make_default_headers
    args1 = argparse.Namespace()
    args1.data = []
    args1.form = True
    args1.json = False
    assert res(args1) == {'User-Agent': 'HTTPie/1.0.0', 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}
    args2 = argparse.Namespace()
    args2.data = []
    args2.form = False
    args2.json = False
    assert res(args2) == {'User-Agent': 'HTTPie/1.0.0'}



# Generated at 2022-06-11 23:14:48.439613
# Unit test for function collect_messages
def test_collect_messages():
    msg = collect_messages(args, config_dir)
    assert msg != None

# Generated at 2022-06-11 23:15:39.671300
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(argparse.Namespace(
        data=None,
        form=None,
        files=None,
        json=False,
        method="GET"
    )) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })

    assert make_default_headers(argparse.Namespace(
        data=None,
        form=None,
        files=None,
        json=True,
        method="GET"
    )) == RequestHeadersDict({
        'Accept': JSON_ACCEPT,
        'User-Agent': DEFAULT_UA
    })

    assert make_default_headers(argparse.Namespace(
        data=None,
        form=True,
        files=None,
        json=False,
        method="GET"
    )) == RequestHeaders

# Generated at 2022-06-11 23:15:42.370629
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout='10',
                              allow_redirects='False')
    send_kwargs = make_send_kwargs(args)
    print(send_kwargs)



# Generated at 2022-06-11 23:15:47.425251
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(verify="yes")
    req_kwargs = make_request_kwargs(args)
    assert req_kwargs['verify'] == True

    args = argparse.Namespace(verify="some_random_value")
    req_kwargs = make_request_kwargs(args)
    assert req_kwargs['verify'] == "some_random_value"

# Generated at 2022-06-11 23:15:57.978002
# Unit test for function collect_messages

# Generated at 2022-06-11 23:16:01.330064
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        ssl_version='tlsv1.2',
        ciphers=None,
        verify=True,
    )
    assert isinstance(requests_session, requests.Session)

# Generated at 2022-06-11 23:16:07.637261
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    expected = {
        'proxies': None,
        'stream': True,
        'verify': True,
        'cert': None,
    }
    actual = make_send_kwargs_mergeable_from_env(args)
    assert(expected == actual)

# Generated at 2022-06-11 23:16:10.686312
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    # test if the default user agent is set
    assert DEFAULT_UA == make_default_headers(args)['User-Agent']

# Generated at 2022-06-11 23:16:21.026601
# Unit test for function make_default_headers

# Generated at 2022-06-11 23:16:25.561859
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()

    args.timeout = None
    args.allow_redirects = False

    kwargs = make_send_kwargs(args)

    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-11 23:16:32.042810
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = '10'
    args.proxy = []
    args.verify = True
    args.cert = "certificate.crt"
    args.cert_key = "certificate.key"
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ("certificate.crt", "certificate.key")


# Generated at 2022-06-11 23:18:02.864904
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class Namespace:
        def __init__(self, verify):
            self.verify = verify

    args = Namespace("True")
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['verify'] is True
    args = Namespace("False")
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['verify'] is False



# Generated at 2022-06-11 23:18:14.443077
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://jupiter:8080/search'
    args.headers = RequestHeadersDict({'Host': 'jupiter:8080'})
    args.data = {}
    args.auth = None
    args.params = {}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.chunked = False
    args.offline = False
    args.multipart_data = []
    args.boundary = None
    args.compress = False
    args.max_headers = None
    args.debug = False
    args.session = None
    args.session_read_only = None
    args.quiet = False
    args.download

# Generated at 2022-06-11 23:18:16.573616
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    out = make_default_headers(args)
    assert out['User-Agent'] == DEFAULT_UA


# Generated at 2022-06-11 23:18:25.410276
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.registry import plugin_manager
    import sys

    # Make plugin_manager ready
    sys.modules['pytest'] = None
    plugin_manager.get_plugins()
    import pprint

    class TestAuth(AuthPlugin):
        auth_type = 'testauth'
        description = 'test auth plugin'

        @classmethod
        def add_parser_arguments(cls, parser):
            parser.add_argument(
                '--test-auth',
                dest='testauth',
                action='store',
                help='test auth'
            )

    plugin_manager.register(TestAuth)
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.auth_plugin = TestAuth()
   

# Generated at 2022-06-11 23:18:30.858342
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=True,
                            data=None,
                            form=False,
                            files=False)
    result = make_default_headers(args)
    expected_result = RequestHeadersDict(
        {'Accept': JSON_ACCEPT, 'User-Agent': DEFAULT_UA})
    assert result == expected_result


# Generated at 2022-06-11 23:18:41.256139
# Unit test for function make_default_headers

# Generated at 2022-06-11 23:18:51.424644
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:19:00.589586
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    args.method = "POST"
    args.url = "https://httpbin.org/post"

    args.data = {'say': "do"}
    args.json = True

    args.headers = {'Connection':"Keep-Alive"}
    args.form = True
    args.files = False

    args.auth = "user:pass"
    args.params = {"test":"test"}
    args.offline = False

    request_kwargs = make_request_kwargs(args)
    print(request_kwargs)


# Generated at 2022-06-11 23:19:03.547819
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    from httpie.cli.argument_parser import parser
    args = parser.parse_args(['--help'])
    print(args)
    ret = make_send_kwargs(args)
    print(ret)

# Generated at 2022-06-11 23:19:10.899248
# Unit test for function build_requests_session
def test_build_requests_session():
    # test ssl_version
    requests_session_ssl_verion = build_requests_session(
        verify=True,
        ssl_version='tlsv1.0',
        ciphers='TLS_AES_256_GCM_SHA384',
    )
    if requests_session_ssl_verion.adapters['https://'].__class__.__name__ == 'HTTPieHTTPSAdapter':
        if requests_session_ssl_verion.adapters['https://']._kw['ssl_version'] == ssl.PROTOCOL_TLS:
            print('test_build_requests_session succeed')
    # test ciphers

# Generated at 2022-06-11 23:22:02.646674
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    a = argparse.Namespace()
    a.proxy = None
    a.verify = True
    a.cert = None
    a.cert_key = None
    make_send_kwargs_mergeable_from_env(a)