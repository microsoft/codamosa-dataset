

# Generated at 2022-06-11 23:12:53.444789
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://example.com'
    args.headers = {'Test': 'test'}
    args.data = 'test'
    args.auth = ('username', 'password')
    args.params = {'param': 'param'}
    args.json = False
    args.form = False
    args.files = False
    args.multipart = False
    args.offline = False
    args.compress = False
    args.chunked = False
    args.debug = False
    args.verify = 'True'
    args.timeout = 10
    args.max_redirects = 30
    args.max_headers = None
    args.history_aware = False
    args.follow = False

# Generated at 2022-06-11 23:13:03.454425
# Unit test for function make_default_headers

# Generated at 2022-06-11 23:13:06.205841
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(argparse.Namespace()) == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-11 23:13:10.293717
# Unit test for function max_headers
def test_max_headers():
    try:
        with max_headers(3):
            assert http.client._MAXHEADERS == 3
    except Exception as e:
        print(e)
        assert False
    assert http.client._MAXHEADERS == 1000



# Generated at 2022-06-11 23:13:14.853670
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    follow = True
    print(json.dumps(make_request_kwargs({'url': 'http://www.baidu.com', 'follow':follow}), indent=2))

if __name__ == '__main__':
    test_make_request_kwargs()

# Generated at 2022-06-11 23:13:19.370454
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path('/tmp')
    request_body_read_callback = None
    messages = collect_messages(args, config_dir, request_body_read_callback)
    # TODO: test this function
    # TODO: test every function with this function

# Generated at 2022-06-11 23:13:25.214364
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import http.client
    http.client._MAXHEADERS = None
    
    sys.argv.append('--offline')
    sys.argv.append('--verbose')
    sys.argv.append('GET')
    sys.argv.append('https://www.google.com')

    args = setup_args_parser().parse_args()
    for message in collect_messages(args=args, config_dir=''):
        print(message)
    
    

# Generated at 2022-06-11 23:13:32.727435
# Unit test for function max_headers
def test_max_headers():
    sys.stderr.write('\n>>> http.client._MAXHEADERS\n\n')
    sys.stderr.write(str(http.client._MAXHEADERS))
    sys.stderr.write('\n>>> max_headers\n\n')
    with max_headers(10):
        sys.stderr.write(str(http.client._MAXHEADERS))
        assert(http.client._MAXHEADERS == 10)
    sys.stderr.write(str(http.client._MAXHEADERS))
    assert(http.client._MAXHEADERS != 10)

# Generated at 2022-06-11 23:13:42.945214
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    import requests

    args = argparse.Namespace()
    args.proxy = []
    args.verify = False

    with requests.Session(), warnings.catch_warnings():
        warnings.simplefilter("ignore", InsecureRequestWarning)
        request_kwargs = make_send_kwargs_mergeable_from_env(args)
        assert request_kwargs == {
            'proxies': {},
            'stream': True,
            'verify': False,
            'cert': None
        }


# Generated at 2022-06-11 23:13:53.633452
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('--proxy', action='append', type=str, default='')
    arg_parser.add_argument('--cert', action='store', type=str, default='')
    arg_parser.add_argument('--cert-key', action='store', type=str, default='')
    arg_parser.add_argument('--verify', action='store', type=str, default='')
    args = arg_parser.parse_args(['--proxy', 'a:b', '--proxy', 'c:d', '--verify', 'no'])

# Generated at 2022-06-11 23:14:20.945155
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    iterable = collect_messages(args, config_dir, request_body_read_callback)
    try:
        while True:
            item = next(iterable)
            print(item)
    except StopIteration:
        return

# if __name__ == '__main__':
#     test_collect_messages()

# Generated at 2022-06-11 23:14:29.495175
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Mocking args object
    args = argparse.Namespace()
    args.proxy = []
    args.verify = True
    args.cert = "cert.pem"
    args.cert_key = "key.pem"
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': "cert.pem",
        'cert_key': "key.pem",
    }

# Generated at 2022-06-11 23:14:31.865523
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    print(make_send_kwargs(args))


# Generated at 2022-06-11 23:14:37.174439
# Unit test for function collect_messages
def test_collect_messages():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("--test-comment")
    argument_parsed = arg_parser.parse_args(["--test-comment", "the answer is 42"])
    req = list(collect_messages(
        args=argument_parsed,
        config_dir=Path('')
    ))
    assert isinstance(req[0], requests.PreparedRequest)
    assert req[0].headers['test-comment'] == "the answer is 42"

# Generated at 2022-06-11 23:14:42.045286
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    config = build_requests_session(verify=True, ssl_version=None, ciphers=None)
    kwargs = make_send_kwargs_mergeable_from_env(config)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

# Generated at 2022-06-11 23:14:53.451937
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    """
    Test that make_request_kwargs() can construct a kwargs dict
    with a request body callback function.
    """

# Generated at 2022-06-11 23:14:58.616852
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(data='data')
    expected_output = {'timeout': None, 'allow_redirects': False}
    assert(make_send_kwargs(args) == expected_output)


# Generated at 2022-06-11 23:15:00.090672
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert type(make_send_kwargs(None)) == type(dict())

# Generated at 2022-06-11 23:15:11.425129
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    arg = argparse.Namespace(
        auth = None,
        auth_plugin = None,
        cert = 'cert',
        cert_key = 'cert_key',
        chunked = False,
        data = {},
        files = None,
        form = True,
        headers = RequestHeadersDict(
            {'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}),
        json = False,
        method = 'GET',
        offline = False,
        params = {},
        path_as_is = False,
        proxy = {},
        session = '',
        session_read_only = '',
        timeout = '',
        url = 'http://127.0.0.1:8000',
        verify = True
    )
    base_headers

# Generated at 2022-06-11 23:15:22.266375
# Unit test for function make_default_headers

# Generated at 2022-06-11 23:15:48.719815
# Unit test for function make_default_headers
def test_make_default_headers():
    from httpie.cli.argtypes import KeyValueArgType
    args = argparse.Namespace()
    args.data = {}
    args.form = False
    args.json = True
    args.headers = KeyValueArgType(KeyValueArgType.SEP_HEADERS)('header:value')
    result = make_default_headers(args)
    assert result.get('User-Agent') == DEFAULT_UA
    assert result.get('Accept') == JSON_ACCEPT
    assert result.get('Content-Type') == JSON_CONTENT_TYPE
    assert result.get('header') == 'value'

# Generated at 2022-06-11 23:15:59.120633
# Unit test for function max_headers
def test_max_headers():
    from httpie import ExitStatus
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.context import Environment
    from requests import Request

    args = argparse.Namespace()
    args.max_headers = 5
    args.headers = KeyValueArgType()([
        'User-Agent:Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36',
        'Accept-Encoding:gzip, deflate, sdch', 'Accept-Language:zh-CN,zh;q=0.8',
        'Cache-Control:max-age=0', 'Connection:keep-alive'
    ])
    args.method = 'GET'
    args.offline = False

# Generated at 2022-06-11 23:16:06.071911
# Unit test for function make_default_headers
def test_make_default_headers():
    from httpie.utils import ConfigDict
    from httpie.cli import parser
    args = parser.parse_args(['--json', 'https://httpbin.org/get'])
    args.config = ConfigDict(headers=dict(Host='httpbin.org'))
    args.ignore_stdin = True
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA, 'Accept': 'application/json, */*;q=0.5'}
    # TODO: test head

# Generated at 2022-06-11 23:16:14.468536
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import sys
    sys.path.append('../')
    from cli import parser
    args = parser.parse_args(['--verify=no', '--cert=localhost',
                              '--proxy=http://localhost:8080'])
    kwargs = make_send_kwargs_mergeable_from_env(args)
    expected = {'proxies': {'http': 'http://localhost:8080'},
                'stream': True, 'verify': False, 'cert': 'localhost'}
    assert kwargs == expected

# Generated at 2022-06-11 23:16:21.376884
# Unit test for function max_headers
def test_max_headers():
    assert 'http' in sys.modules
    assert sys.modules['http']
    assert 'client' in sys.modules['http']
    assert '_MAXHEADERS' in sys.modules['http'].client.__dict__
    # noinspection PyProtectedMember
    orig = sys.modules['http'].client._MAXHEADERS
    # noinspection PyProtectedMember
    sys.modules['http'].client._MAXHEADERS = orig
    assert sys.modules['http'].client._MAXHEADERS == orig
    #noinspection PyProtectedMember
    assert sys.modules['http'].client._MAXHEADERS == orig

# Generated at 2022-06-11 23:16:24.038231
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path('some path')

    list(collect_messages(args, config_dir))

    assert True

# Generated at 2022-06-11 23:16:32.911594
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.timeout = 2
    args.allow_redirects = False
    args.proxies = {p.key: p.value for p in args.proxy}
    args.stream = True
    args.verify = {
        'yes': True,
        'true': True,
        'no': False,
        'false': False,
    }.get(args.verify.lower(), args.verify)
    args.cert = True
    args.cert_key = True
    args.method = 'post'
    args.url = 'jd.com'
    args.headers = {'jd': 'jd'}
    args.data = ''
    args.auth = ''
    args.params = ''

# Generated at 2022-06-11 23:16:39.775625
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    kwargs = {
        'method': 'get'.lower(),
        'url': 'https://www.google.com',
        'headers': {},
        'data': None,
        'auth': None,
        'params': None
    }
    _kwargs = make_request_kwargs(args='', base_headers=None, request_body_read_callback=None)
    assert kwargs == _kwargs


# Generated at 2022-06-11 23:16:41.620763
# Unit test for function collect_messages
def test_collect_messages():
    kwargs = {'args': None, 'config_dir': None}
    requests.Request(**kwargs)

# Generated at 2022-06-11 23:16:52.151485
# Unit test for function max_headers
def test_max_headers():
    import http.client
    import sys

    max_headers = 6

    # Create a headers list that is longer than max_headers
    headers_list = []
    for i in range(1,max_headers):
        headers_list.append(('H1', i))

    # Add one more key to headers_list, which is equal to the max_headers
    headers_list.append(('H2', 'value'))
    headers_list.append(('H3', 'value'))

    headers_dict = {}
    headers_dict.update(headers_list)

    # hardwire the http.client._MAXHEADERS to -1
    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = -1

    # test function
    assert len(headers_dict) == max_headers

# Generated at 2022-06-11 23:17:32.505775
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--timeout', type=float)
    parser.add_argument('--allow-redirects', action='store_true')
    args = parser.parse_args()
    result = make_send_kwargs(args)
    assert result == {'timeout': None, 'allow_redirects': False}

test_make_send_kwargs()

# Generated at 2022-06-11 23:17:36.739318
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Args is an instance of `argparse.Namespace`.
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = True
    args.verify = True
    send_kwargs = make_send_kwargs(args)
    res = {
        'timeout': args.timeout, 
        'allow_redirects': True
    }
    assert send_kwargs == res

# Generated at 2022-06-11 23:17:44.574800
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        verify='no',
        cert='foo.pem',
        cert_key='foo.key',
        proxy=[urllib3.ProxyManager.Proxy(key='bar', value='baz')]
    )
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == False
    assert kwargs['cert'] == ('foo.pem', 'foo.key')
    assert kwargs['proxies'] == {'bar': 'baz'}
    assert kwargs['stream'] == True

# Generated at 2022-06-11 23:17:54.327300
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(
        argparse.Namespace(
            cert=None,
            cert_key=None,
            proxy=[
            ],
        )
    ) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    assert make_send_kwargs_mergeable_from_env(
        argparse.Namespace(
            cert='cert',
            cert_key=None,
            proxy=[
                argparse.Namespace(
                    key='http',
                    value='http://proxy:8080/',
                ),
                argparse.Namespace(
                    key='https',
                    value='https://proxy:8080/',
                ),
            ],
        )
    )

# Generated at 2022-06-11 23:18:02.678746
# Unit test for function make_default_headers
def test_make_default_headers():
    '''
    Function test for make_default_headers()
    '''
    args = argparse.Namespace()
    args.data = '{"course_id": "neuE6f-cz6Ujz8wYGMJGvA", "course_name": "AWS"}'
    args.json = "True"
    args.headers = RequestHeadersDict({'Content-Type': JSON_CONTENT_TYPE})
    tester = make_default_headers(args)
    assert tester['User-Agent'] == DEFAULT_UA
    assert tester['Accept'] == JSON_ACCEPT
    assert tester['Content-Type'] == JSON_CONTENT_TYPE
    return True


# Generated at 2022-06-11 23:18:05.126747
# Unit test for function make_send_kwargs
def test_make_send_kwargs():

    # Test with no args
    assert make_send_kwargs(args=None) ==  {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-11 23:18:16.344697
# Unit test for function collect_messages
def test_collect_messages():
    import io
    import os
    import pytest
    def test_callback(chunk):
        if chunk == 'b\r\n':
            return 'ab\r\n'
        return chunk
    class args:
        @property
        def url(self):
            return 'https://quotes.instaforex.com/api/quotesTick?m=json&q=EURUSD'
        @property
        def method(self):
            return 'get'
        @property
        def headers(self):
            return {}
        @property
        def timeout(self):
            return 20
        @property
        def verify(self):
            return True
        @property
        def compress(self):
            return False
        @property
        def form(self):
            return False

# Generated at 2022-06-11 23:18:25.232225
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class argparse:
        class Namespace:
            def __init__(self):
                self.cert = None
                self.cert_key = None
                self.proxy = []
                self.verify = "no"

    args = argparse.Namespace()

    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': None
    }

    args.proxy.append(argparse.Namespace())
    args.proxy[0].key = "http"
    args.proxy[0].value = "http://localhost"

    assert make_send_kwargs_mergeable_from_env(args)['proxies'] == {'http': 'http://localhost'}

    args

# Generated at 2022-06-11 23:18:35.707508
# Unit test for function max_headers
def test_max_headers():
    from httpie.core import main
    from httpie.utils import get_response_headers_and_body
    import requests
    import sys
    request_kwargs = make_request_kwargs(
        args=main.main(
            args=['-v', '--max-headers=1', 'get', 'http://www.google.com'],
            env=['HOME=/dev/null', 'HTTPIE_CONFIG_DIR=/dev/null']
        )
    )
    requests_session = build_requests_session(
        ssl_version='1.2',
        ciphers='',
        verify=True
    )
    request = requests.Request(**request_kwargs)
    prepared_request = requests_session.prepare_request(request)

# Generated at 2022-06-11 23:18:41.124237
# Unit test for function collect_messages
def test_collect_messages():
    import tempfile
    sys.argv = ['http', 'localhost:8080']
    parser, args = make_parser()
    # args = parser.parse_args()
    config_dir = Path(tempfile.gettempdir())
    messages = collect_messages(args, config_dir)
    response = next(messages)

    assert isinstance(response.headers, dict)

# Generated at 2022-06-11 23:19:59.532815
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.form = True
    args.files = []
    args.multipart = False
    args.multipart_data = []
    args.boundary = None
    args.headers = []
    args.offline = True
    args.chunked = True
    args.method = "method"
    args.url = "url"
    args.auth = "auth"
    args.params = []
    args.json = False
    args.data = []

    actual = make_request_kwargs(args)

# Generated at 2022-06-11 23:20:02.654741
# Unit test for function max_headers
def test_max_headers():
    max_headers_val = 20
    http.client._MAXHEADERS = max_headers_val

    with max_headers(12):
        assert http.client._MAXHEADERS == 12

    assert http.client._MAXHEADERS == max_headers_val

# Generated at 2022-06-11 23:20:13.610488
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
    from httpie.cli import parser

    args = parser.parse_args([
        'http://httpbin.org/post',
        '--json',
    ])
    request_kwargs = make_request_kwargs(args)
    assert json.loads(request_kwargs['data']) == {}

    args = parser.parse_args([
        'http://httpbin.org/post',
        '--json',
        '{}',
    ])
    request_kwargs = make_request_kwargs(args)
    assert json.loads(request_kwargs['data']) == {}

    args = parser.parse_args([
        'http://httpbin.org/post',
        '--json',
        '{"id": "test"}',
    ])
    request_kwargs = make_request_kw

# Generated at 2022-06-11 23:20:19.518408
# Unit test for function collect_messages
def test_collect_messages():
    # test 1
    from argparse import Namespace
    from pathlib import Path
    args1 = Namespace(ciphers='', cert=None, cert_key=None, chunked=True,
                      data='', debug=False, files='', form=False,
                      headers='', json=False, method='get', offline=False,
                      params='', path_as_is=False, pretty='all', proxy='',
                      session=None, session_read_only=None, stream=False,
                      timeout=None, traceback=False, upload_file='',
                      verify='yes', version=False, auth=None)
    config_dir = Path('./test/test1_config')
    request_body_read_callback = lambda chunk: chunk

# Generated at 2022-06-11 23:20:25.808811
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import collections
    import json
    import httpie
    args = argparse.Namespace()
    args.url = "http://httpbin.org/get"
    args.method = "GET"
    args.headers = {}
    args.offline = False
    args.auth = None
    args.auth_plugin = None
    args.auth_type = None
    args.auth_password = None
    args.auth_username = None
    args.proxy = []
    args.params = collections.OrderedDict()
    args.data = None
    args.json = False
    args.form = False
    args.files = []
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.session = None
    args

# Generated at 2022-06-11 23:20:34.967320
# Unit test for function max_headers
def test_max_headers():
    class MockHeaders():
        def __init__(self, headers):
            self._headers = headers

    class MockResponse:
        def __init__(self, mock_headers):
            self._original_response = mock_headers

        def msg(self):
            return self._original_response


# Generated at 2022-06-11 23:20:45.716747
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    base_headers = RequestHeadersDict()
    send_kwargs = {
        'timeout': 1.5,
        'allow_redirects': False,
        'stream': True
    }
    send_kwargs_mergeable_from_env = {
        'proxies': {
            'http': 'http://127.0.0.1:8888',
            'https': 'https://127.0.0.1:9999'
        },
        'verify': True,
        'cert': None
    }
    request_kwargs = make_request_kwargs(
        args, base_headers, send_kwargs, send_kwargs_mergeable_from_env
    )
    assert isinstance(request_kwargs, dict)

# Generated at 2022-06-11 23:20:52.162278
# Unit test for function build_requests_session
def test_build_requests_session():
    ssl_version = '1.1'
    ciphers = 'CIPHERS'
    verify = True
    session = build_requests_session(ssl_version, ciphers, verify)
    assert session.verify is True
    assert session.cert == None
    assert session.proxies == {}
    assert session.stream is True
    assert session._pool_connections is 1
    assert session._pool_maxsize is 10



# Generated at 2022-06-11 23:20:57.725521
# Unit test for function max_headers
def test_max_headers():
    """
    >>> with max_headers(123):
    ...     import http.client
    ...     http.client._MAXHEADERS
    123
    >>> import http.client
    >>> http.client._MAXHEADERS
    1000
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod(
        verbose=False,
        optionflags=doctest.ELLIPSIS,
    )

# Generated at 2022-06-11 23:21:03.661672
# Unit test for function max_headers