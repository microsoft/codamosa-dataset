

# Generated at 2022-06-11 23:12:35.932534
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:12:38.525380
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.core import main
    import pytest
    args = main.parser.parse_args(['--verify'])
    make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-11 23:12:44.652351
# Unit test for function max_headers
def test_max_headers():
    class TestClientConnection(object):
        _MAXHEADERS = 0
        class TestMessage(object):
            _MAXHEADERS = 0
            _headers = []
        
        def __init__(self, *args, **kwargs):
            self._original_response = TestClientConnection.TestMessage()
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass

    class TestResponse(object):
        class TestMessage(object):
            _headers = []

        def __init__(self, *args, **kwargs):
            self.raw = TestResponse.TestMessage()
            self.raw.msg = TestResponse.TestMessage()

    class TestSession(object):
        def __init__(self, *args, **kwargs):
            pass

# Generated at 2022-06-11 23:12:53.273665
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_true = create_args('https://httpbin.org', verify=True)
    args_false = create_args('https://httpbin.org', verify=False)
    args_yes = create_args('https://httpbin.org', verify='yes')
    args_no = create_args('https://httpbin.org', verify='no')
    args_string_path = create_args(
        'https://httpbin.org', verify='/usr/local/etc/httpie/cacert.pem'
    )
    args_os_path = create_args(
        'https://httpbin.org', verify=os.path.abspath('/')
    )


# Generated at 2022-06-11 23:13:02.130089
# Unit test for function max_headers
def test_max_headers():
    max = 100
    test_headers = max + 1
    with max_headers(max) as headers:
        assert http.client._MAXHEADERS == max
    assert http.client._MAXHEADERS == 1000
    try:
        with max_headers(max):
            # noinspection PyUnresolvedReferences
            http_client._MAXHEADERS = test_headers
    except ValueError:
        pass
    else:
        raise AssertionError(
            f'Attempt to set http.client._MAXHEADERS to {test_headers} should have'
            f'raised a ValueError.')

if __name__ == '__main__':
    test_max_headers()

# Generated at 2022-06-11 23:13:13.837121
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from pathlib import Path
    from httpie.cli.dicts import RequestHeadersDict

    args = argparse.Namespace()
    config_dir = Path()
    httpie_session_headers = RequestHeadersDict()
    request_body_read_callback = lambda chunk: chunk
    request_kwargs = make_request_kwargs(args=args, base_headers=httpie_session_headers, request_body_read_callback=request_body_read_callback)
    send_kwargs = make_send_kwargs(args=args)
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args=args)

# Generated at 2022-06-11 23:13:24.903760
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class Arguments:
        def __init__(
            self,
            data=None,
            json=False,
            form=False,
            multipart=False,
            headers=None,
            method='GET',
            url=None,
            params=None,
            auth=None,
            chunked=False,
            offline=False,
            ):
            self.data = data
            self.json = json
            self.form = form
            self.multipart = multipart
            self.headers = headers
            self.method = method
            self.url = url
            self.params = params
            self.auth = auth
            self.chunked = chunked
            self.offline = offline


# Generated at 2022-06-11 23:13:33.442483
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from httpie.cli import parser

    args = parser.parse_args(['-v', 'GET', 'https://httpbin.org/'])
    args.output_options = parser.parser_output_options.parse_args([])
    args.auth_plugin = None
    args.auth = ()
    args.headers = RequestHeadersDict()

    list(collect_messages(args, args.config_dir))

    args.output_options.json = True
    args.headers['Content-Type'] = 'application/json'

    list(collect_messages(args, args.config_dir))

# Generated at 2022-06-11 23:13:42.380088
# Unit test for function max_headers
def test_max_headers():
    import requests
    import http.client
    with max_headers(3):
        assert http.client._MAXHEADERS  == 3
        r = requests.Request()
        assert len(r.headers) == 0
        r.headers['foo'] = 'bar'
        r.headers['baz'] = 'qux'
        r.headers['quux'] = 'corge'
        with pytest.raises(http.client.InvalidHeader):
            r.headers['grault'] = 'garply'
        assert len(r.headers) == 3

# Generated at 2022-06-11 23:13:53.184084
# Unit test for function collect_messages

# Generated at 2022-06-11 23:14:28.621298
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:14:36.512870
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.ArgumentParser()
    args.url = 'http://127.0.0.1:5000/'
    args.method = 'GET'
    args.json = False
    args.data = False
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = False
    args.compress = False
    args.headers = {}
    args.parameters = {}
    args.params = []
    args.auth = None
    args.auth_plugin = None
    args.session = None
    args.session_read_only = None
    args.timeout = None
    args.verify = True
    args.ssl_version = None
    args.ciphers = None
    args.proxy = None
    args.debug = True


# Generated at 2022-06-11 23:14:44.900779
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [
        argparse.Namespace(key='http', value='http://localhost:8888'),
        argparse.Namespace(key='https', value='http://localhost:8999'),
    ]
    args.verify = argparse.Namespace()
    args.verify.lower = lambda: 'true'
    args.cert = 'foo'
    args.cert_key = 'bar'
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {"http": "http://localhost:8888",
                    "https": "http://localhost:8999"},
        'stream': True,
        'verify': True,
        'cert': ('foo', 'bar'),
    }

# Generated at 2022-06-11 23:14:47.193847
# Unit test for function max_headers
def test_max_headers():
    with max_headers(3):
        assert http.client._MAXHEADERS == 3
    assert http.client._MAXHEADERS != 3

# Generated at 2022-06-11 23:15:00.374279
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import os
    import requests
    import responses
    import sys
    import httpie
    parser = argparse.ArgumentParser()
    parser.add_argument("--auth", type=str)
    parser.add_argument("--chunked", action='store_true')
    parser.add_argument("--json", action='store_true')
    parser.add_argument("--method", type=str)
    parser.add_argument("--offline", action='store_true')
    parser.add_argument("--url", type=str)
    parser.add_argument("--verify", type=str)
    parser.add_argument("--session", type=str)
    parser.add_argument("--session_read_only", type=str)

# Generated at 2022-06-11 23:15:11.627461
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:15:22.505783
# Unit test for function collect_messages
def test_collect_messages():
    a = argparse.Namespace()
    a.url = 'https://localhost'
    a.verify = True
    a.method = 'GET'
    a.headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
    a.data = {'hello': 'world'}
    a.json = True
    a.form = False
    a.params = {}
    a.data = {'hello': 'world'}
    a.compress = True
    a.body = False
    a.compress = True
    a.output = './test.out'
    a.offline = False
    a.session = None
    a.session_read_only = None
    a.auth = None
    a.auth_type = 'basic'

# Generated at 2022-06-11 23:15:25.681138
# Unit test for function make_default_headers
def test_make_default_headers():
    headers = make_default_headers(None)
    assert 'Accept' in headers
    assert headers['Accept'] == 'application/json, */*;q=0.5'
    assert 'User-Agent' in headers
    assert headers['User-Agent'] == 'HTTPie/' + __version__

# Generated at 2022-06-11 23:15:37.299947
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace
    args.method = 'get'
    args.cert = "/home"
    args.cert_key = "home.key"
    args.headers = dict
    args.headers.items = dict.items
    args.headers.get = dict.get
    args.chunked = 'chunked'
    args.offline = False
    request_body_read_callback = lambda chunk: chunk
    # args.data = dict(username='foobar')
    args.data = dict
    args.json = True
    args.form = False
    kwargs = make_request_kwargs(
        args=args,
        base_headers=None,
        request_body_read_callback=request_body_read_callback
    )
    # print(kwargs)
    assert kwargs

# Generated at 2022-06-11 23:15:48.199810
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from argparse import Namespace
    from httpie.input import KeyValue, KeyValueArgType
    from httpie.core import main
    from collections import OrderedDict
    from httpie.cli.dicts import RequestHeadersDict
    import json
    import httpie.compat
    for i in ['json']:
        for j in ['yes', 'no']:
            for k in ['yes', 'no']:
                for l in ['yes', 'no']:
                    for m in ['yes', 'no']:
                        cmd = f"http {i} {j} {k} {l} {m} :8000"
                        args = main.get_parser().parse_args(cmd.split())
                        args.headers = RequestHeadersDict({'Content-Type': 'application/json'})
                        args.files = None


# Generated at 2022-06-11 23:16:07.837033
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie import cli
    parser = cli.parser.get_parser()
    args = parser.parse_args(['--verify=false', 'http://foo.bar'])
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == False
    assert kwargs['proxies'] == {}

# Generated at 2022-06-11 23:16:16.181653
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import argparse
    args = argparse.Namespace()
    args.proxy = [
        argparse.Namespace(key='key', value='value')
    ]
    args.verify = 'true'
    args.cert = 'cert'
    args.cert_key = 'cert key'
    result = make_send_kwargs_mergeable_from_env(args=args)
    assert result['verify'] is True
    assert result['proxies'] == {'key': 'value'}
    assert result['cert'] == args.cert

# Generated at 2022-06-11 23:16:23.633294
# Unit test for function make_send_kwargs

# Generated at 2022-06-11 23:16:24.063816
# Unit test for function collect_messages
def test_collect_messages():
    collect_messages()

# Generated at 2022-06-11 23:16:26.527581
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'false'
    args.cert = None
    args.cert_key = None

    rv = make_send_kwargs_mergeable_from_env(args)
    assert rv

# Generated at 2022-06-11 23:16:34.044166
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:16:35.920534
# Unit test for function max_headers
def test_max_headers():
    max_headers(10)
    assert http.client._MAXHEADERS == 10


# Generated at 2022-06-11 23:16:38.599028
# Unit test for function max_headers
def test_max_headers():
    with max_headers(50) as m:
        print(http.client._MAXHEADERS)


test_max_headers()

# Generated at 2022-06-11 23:16:39.775067
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS



# Generated at 2022-06-11 23:16:46.842479
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(method = 'GET', url='http://www.gogole.com/search')
    base_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    request_body_read_callback= None
    kwargs = make_request_kwargs(args=args, base_headers=base_headers, request_body_read_callback=request_body_read_callback)
    assert kwargs['auth'] == None
    assert kwargs['params'] == []
    assert kwargs['headers'] == {
        'User-Agent':'HTTPie/0.9.9',
        'Accept': 'application/json, */*;q=0.5'
    }
    assert kwargs['data'] == None

# Generated at 2022-06-11 23:17:17.607471
# Unit test for function collect_messages
def test_collect_messages():
    # TODO: the function needs some refactoring to make it testable.
    pass

# Generated at 2022-06-11 23:17:26.888900
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
    import requests
    import httpie
    import argparse

    args = argparse.Namespace()
    from httpie.cli import parser
    args.json = False
    args.form = False
    args.files = False

    args.data = {
  "title": "hello",
  "body": "world",
  "userId": 1
}
    req_args = make_request_kwargs(args)
    print(req_args['data'])
    print(req_args['headers'])
    requests_session = build_requests_session(
        ssl_version=args.ssl_version,
        ciphers=args.ciphers,
        verify=bool(send_kwargs_mergeable_from_env['verify'])
    )
    send_kwargs = make_

# Generated at 2022-06-11 23:17:33.191735
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'True'
    args.proxy = []
    args.cert = 'some_cert'
    args.cert_key = 'some_cert_key'
    send_kwargs = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs == {
        'cert': ('some_cert', 'some_cert_key'),
        'proxies': {},
        'stream': True,
        'verify': True
    }

# Generated at 2022-06-11 23:17:39.598607
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-11 23:17:45.295522
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = dict(
        verify="yes",
        cert="cert",
        cert_key="cert_key",
        proxy=["www.google.com"],
    )

    # Compares values in both dicts
    assert make_send_kwargs_mergeable_from_env(**args) == dict(
        proxies=dict(proxy=["www.google.com"]),
        stream=True,
        verify=True,
        cert=("cert", "cert_key"),
    )

# Generated at 2022-06-11 23:17:55.039064
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    test_args = argparse.Namespace()
    test_args.json = False
    test_args.method = 'GET'
    test_args.all = False
    test_args.data = None
    test_args.form = True
    test_args.json = False
    test_args.headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    test_args.auth = None
    test_args.verify = True
    test_args.timeout = None
    test_args.debug = False
    test_args.compress = False
    test_args.offline = False
    test_args.chunked = False
    test_args.proxy = None
    test_args.download_filename = ''
    test_args.download_output_directory = ''
    test

# Generated at 2022-06-11 23:17:59.439168
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = type('Args', (object,), {
        'timeout': 5.5,
        'verify': 'true',
        'allow_redirects': False,
    })
    kwargs = make_send_kwargs(args=args)
    assert kwargs == {
        'timeout': 5.5,
        'allow_redirects': False,
    }

# Generated at 2022-06-11 23:18:11.159834
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://contoso.com'
    args.headers = {}
    args.data = {}
    args.json = True
    args.form = False
    args.files = False
    args.multipart_data = [{'name': 'foo', 'filename': 'bar.txt', 'data': 'bar'}]
    args.multipart = True
    args.boundary = 'QaZjhvf'
    args.auth = None
    args.params = {}
    args.verify = 'True'
    args.cert = None
    args.timeout = 5
    args.max_redirects = 3
    args.follow = True
    args.max_headers = 3
    args.offline = False

# Generated at 2022-06-11 23:18:21.020929
# Unit test for function collect_messages
def test_collect_messages():
    from typing import List

    from py._path.local import LocalPath
    from httpie.cli.args import parser
    from httpie.cli.keyboard import Keybinding
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.compat import is_py26
    from httpie.utils import get_response_output_stream

    # noinspection PyBroadException
    try:
        import httpie
        httpie.__version__
    except Exception:
        httpie = None

    class MockResponse:
        status_code = 200
        reason = 'OK'
        headers = {}
        raw = None  # type: MockRawResponse


# Generated at 2022-06-11 23:18:28.266421
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.ArgumentParser()
    args.url = ["https://www.google.com"]
    args.data = ""
    args.json = None
    args.form = False
    args.files = None
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.headers = {}
    args.method = "GET"
    args.params = {}
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.timeout = None
    args.max_redirects = None
    args.follow = False
    args.max_headers = None
    args.session = None
    args.session_read_only = None
    args.path_as_is = False

# Generated at 2022-06-11 23:18:59.738194
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
        assert {
        'timeout': None,
        'allow_redirects': False,
    } == make_send_kwargs(args=argparse.Namespace())


# Generated at 2022-06-11 23:19:08.641370
# Unit test for function collect_messages
def test_collect_messages():
    print("Testing function collect_messages")

# Generated at 2022-06-11 23:19:13.635875
# Unit test for function max_headers
def test_max_headers():
    def test_func():
        # noinspection PyUnresolvedReferences
        http.client._MAXHEADERS = 42
        # noinspection PyUnresolvedReferences
        assert http.client._MAXHEADERS == 42
    with max_headers(42):
        test_func()
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS != 42

# Generated at 2022-06-11 23:19:24.427279
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=None,
        chunked=False,
        data=None,
        files=[],
        form=False,
        headers=RequestHeadersDict(
            {'Content-Type':'image/gif', 'Accept':'image/jpeg'}),
        json=False,
        max_headers=float('Inf'),
        method='GET',
        multiform=False,
        multipart_data=None,
        params=None,
        path_as_is=False,
        session=None,
        session_read_only=None,
        timeout=None,
        url='http://example.com',
        verify=True,
    )
    base_headers = RequestHeadersDict({})

# Generated at 2022-06-11 23:19:31.278314
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='test', value='test')]
    args.verify = 'no'
    args.cert = 'test'
    args.cert_key = 'test'
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {'test': 'test'},
        'stream': True,
        'verify': False,
        'cert': 'test',
        'cert_key': 'test',
    }

# Generated at 2022-06-11 23:19:40.859599
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = None
    args.url = None
    args.headers = None
    args.data = None
    args.form = None
    args.json = None
    args.files = None
    args.multipart = None
    args.multipart_data = None
    args.boundary = None
    args.chunked = None
    args.offline = None
    args.auth = None
    args.params = None

    headers = make_default_headers(args)
    headers = finalize_headers(headers)


# Generated at 2022-06-11 23:19:47.645644
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args=argparse.Namespace()
    args.verify = True
    args.proxy = [argparse.Namespace(key='proxy', value='value')]
    args.cert_key = 'cert key'
    args.cert = 'cert'
    res = make_send_kwargs_mergeable_from_env(args)

    assert res['proxies'] == {'proxy': 'value'}
    assert res['stream']
    assert res['verify'] == True
    assert res['cert'] == 'cert'

# Generated at 2022-06-11 23:19:51.709440
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-11 23:20:01.570384
# Unit test for function collect_messages
def test_collect_messages():
    command_line = ('http', '-f POST http://httpbin.org/post',
                    'name=httpie')
    args = httpie.cli.parser.parse_args(command_line)

    config_dir = Path.cwd()
    assert(config_dir.exists())
    assert(config_dir.is_dir())

    messages = list(collect_messages(args, config_dir))
    assert(len(messages) == 2)

    request = messages[0]
    assert(isinstance(request, requests.PreparedRequest))
    assert(request.method == 'POST')
    assert(request.url == 'http://httpbin.org/post')
    assert(request.body == 'name=httpie')

    response = messages[1]
    assert(isinstance(response, requests.Response))

# Generated at 2022-06-11 23:20:12.516005
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:21:19.842310
# Unit test for function make_default_headers
def test_make_default_headers():
    test_args = argparse.Namespace()
    test_args.files = False
    test_args.json = False
    test_args.form = False
    test_args.data = False
    assert make_default_headers(test_args) == {'User-Agent': 'HTTPie/0.9.9'}
    test_args.json = True
    assert make_default_headers(test_args) == {'User-Agent': 'HTTPie/0.9.9', 'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'}
    test_args.files = False
    test_args.data = True
    test_args.json = False
    test_args.form = True

# Generated at 2022-06-11 23:21:29.045800
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    args=argparse.Namespace()
    args.hostname=None
    args.headers={}
    args.compress=None
    args.max_headers=None
    args.compress=None
    args.chunked=False
    args.compress=False
    args.compress_level=None
    args.offline=False
    args.method='get'
    args.auth=None
    args.timeout=30
    args.verify=True
    args.cert=None
    args.cert_key=None
    args.proxy=[argparse.Namespace()]
    args.follow=False
    args.max_redirects=None
    args.session=None
    args.session_read_only=None
    args.json=False
    args.form=False


# Generated at 2022-06-11 23:21:38.211997
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_test = argparse.Namespace()
    args_test.verify = 'no'
    args_test.proxy = []
    args_test.cert = None
    args_test.cert_key = None
    kwargs_test = make_send_kwargs_mergeable_from_env(args_test)

    assert kwargs_test == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': None,
    }

    args_test = argparse.Namespace()
    args_test.verify = 'no'
    args_test.proxy = [RequestHeadersDict({'key':'value'})]
    args_test.cert = 'cert_test'
    args_test.cert_key = None
    kwargs

# Generated at 2022-06-11 23:21:43.889786
# Unit test for function collect_messages
def test_collect_messages():
    args = make_argument_parser().parse_args(
        ['--output', 'out', 'http://httpbin.org/ip'])
    args.session = 'test'
    args.max_headers = 200
    config_dir = Path(__file__).parent
    for message in collect_messages(args, config_dir):
        print(message)



# Generated at 2022-06-11 23:21:46.443225
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # this turn off the ssl verification
    args = argparse.Namespace(verify="false")
    print(make_send_kwargs_mergeable_from_env(args))

# Generated at 2022-06-11 23:21:56.128731
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.headers = {'Accept': 'application/json, */*;q=0.5'}
    expected = {'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json', 'User-Agent': 'HTTPie/1.0.3'}
    assert(make_default_headers(args) == expected)
    expected = {'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8', 'User-Agent': 'HTTPie/1.0.3'}
    args.form = True
    args.json = False
    assert(make_default_headers(args) == expected)

# Generated at 2022-06-11 23:22:00.041727
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.url = 'http://localhost'
    args.method = 'GET'
    args.data = {'key': 'value'}
    args.timeout = 60
    print(collect_messages(args, '.'))

# Generated at 2022-06-11 23:22:06.761414
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        json=0,
        form=0,
        data="",
    )
    assert DEFAULT_UA in make_default_headers(args).values()
    args = argparse.Namespace(
        json=0,
        form=0,
        data="{}",
    )
    assert JSON_ACCEPT in make_default_headers(args).values()
    assert JSON_CONTENT_TYPE in make_default_headers(args).values()
    args = argparse.Namespace(
        json=1,
        form=0,
        data="",
    )
    assert JSON_ACCEPT in make_default_headers(args).values()
    assert JSON_CONTENT_TYPE not in make_default_headers(args).values()