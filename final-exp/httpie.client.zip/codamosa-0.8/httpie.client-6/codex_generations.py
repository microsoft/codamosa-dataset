

# Generated at 2022-06-11 23:12:24.025302
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=False, form=False, data="test data")
    print(make_default_headers(args))



# Generated at 2022-06-11 23:12:35.253701
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(cert=None, cert_key=None, proxy=[], verify='', timeout=None)
    expected_kwargs = {
        'proxies': {},
        'stream': True,
        'verify': '',
        'cert': None,
    }
    assert make_send_kwargs_mergeable_from_env(args) == expected_kwargs

    args = argparse.Namespace(cert='/tmp/cert.pem', cert_key=None, proxy=[], verify='', timeout=None)
    expected_kwargs = {
        'proxies': {},
        'stream': True,
        'verify': '',
        'cert': '/tmp/cert.pem',
    }

# Generated at 2022-06-11 23:12:37.631567
# Unit test for function max_headers
def test_max_headers():
    print('test max_headers')
    with max_headers(10):
        print(http.client._MAXHEADERS)
    print(http.client._MAXHEADERS)

# Generated at 2022-06-11 23:12:49.273012
# Unit test for function make_default_headers
def test_make_default_headers():
    """should return default headers"""

# Generated at 2022-06-11 23:12:52.244642
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS != 10

# Generated at 2022-06-11 23:13:02.545086
# Unit test for function build_requests_session
def test_build_requests_session():
    s = build_requests_session(verify=False, ssl_version='TLSv1_3')
    assert s is not None

    s = build_requests_session(verify=False, ssl_version='TLSv1')
    assert s is not None

    s = build_requests_session(verify=False, ssl_version='TLSv1_1')
    assert s is not None

    s = build_requests_session(verify=False, ssl_version='TLSv1_2')
    assert s is not None

    s = build_requests_session(verify=False, ssl_version=None)
    assert s is not None

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 23:13:14.344274
# Unit test for function max_headers
def test_max_headers():
    import unittest
    import unittest.mock

    class MaxHeadersTest(unittest.TestCase):
        def test_headers_limit(self):
            with unittest.mock.patch('http.client._MAXHEADERS') as mock_max_headers:
                # noinspection PyProtectedMember
                mock_max_headers.value = 1
                with max_headers(3):
                    self.assertEqual(3, http.client._MAXHEADERS)
                self.assertEqual(1, http.client._MAXHEADERS)

        def test_headers_no_limit(self):
            with unittest.mock.patch('http.client._MAXHEADERS') as mock_max_headers:
                # noinspection PyProtectedMember
                mock_max_headers.value = 1

# Generated at 2022-06-11 23:13:18.978773
# Unit test for function max_headers
def test_max_headers():
    temp_limit = 30
    try:
        with max_headers(limit=temp_limit):
            assert http.client.MAXHEADERS == temp_limit
    except:
        print("test_max_headers FAILED")
        sys.exit(1)
    print("test_max_headers PASS")


# Generated at 2022-06-11 23:13:20.992844
# Unit test for function collect_messages
def test_collect_messages():
    print(collect_messages({"original_url":"google.com"},Path("/Users/qiyue/Desktop/httpie2")))

# Generated at 2022-06-11 23:13:23.884465
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(ssl_version=None, ciphers=None, verify=True)
    assert isinstance(session, requests.Session)

# Generated at 2022-06-11 23:13:39.259071
# Unit test for function max_headers
def test_max_headers():
    try:
        with max_headers(limit=10):
            headers = ['A: B'] * 20
            http.client._MAXHEADERS = 5 # Set the limit explicitly to the hardcoded value to see if the context manager changes it
            http.client.parse_headers(StringIO("\r\n".join(headers)))
    except http.client.LineTooLong as e:
        print("test passed")
    else:
        print("test failed")

test_max_headers()

# Generated at 2022-06-11 23:13:51.116032
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify', type=str, default='yes')
    parser.add_argument('--proxy', action='append', dest='proxy',
                        default=[], help='Add a proxy to use.')
    parser.add_argument('--stream', action='store_true', dest='stream',
                        default=False, help='Stream the request data.')
    parser.add_argument('--cert', type=str, default=None,
                        help='Path to a client certificate')
    parser.add_argument('--cert-key', type=str, default=None,
                        help='Path to a client certificate key')

# Generated at 2022-06-11 23:13:54.167044
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    request_kwargs = make_request_kwargs(args)
    assert request_kwargs.get('url') is None
    assert request_kwargs.get('method') is None
    assert request_kwargs.get('headers')

# Generated at 2022-06-11 23:14:03.850533
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import requests

    args = argparse.Namespace(timeout=1,follow=True)
    ssl_version='TLSv1.2'
    verify=False
    ciphers='all'
    proxies={}
    stream=True
    cert=None

    requests_session = build_requests_session(
        verify=verify,
        ssl_version=ssl_version,
        ciphers=ciphers
    )
    send_kwargs = make_send_kwargs(args)
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-11 23:14:04.421460
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    pass

# Generated at 2022-06-11 23:14:13.127582
# Unit test for function max_headers
def test_max_headers():
    import unittest
    import http.client
    from contextlib import contextmanager

    class TestMaxHeaders(unittest.TestCase):
        def setUp(self):
            self.orig_max_headers = http.client._MAXHEADERS

        def tearDown(self):
            http.client._MAXHEADERS = self.orig_max_headers

        def test_set_max_headers_context(self):
            http.client._MAXHEADERS = 10
            with max_headers(0) as _:
                self.assertEqual(http.client._MAXHEADERS, 0)
            self.assertEqual(http.client._MAXHEADERS, 10)


# Generated at 2022-06-11 23:14:22.560762
# Unit test for function max_headers
def test_max_headers():
    from io import BytesIO

    # This is the max header size that will trigger the Error
    # "HTTPHeaderParser: Got more than 131072 bytes when reading headers"
    max_header_size = 131072

    if hasattr(BytesIO, 'write_through'):
        # workaround for https://bugs.python.org/issue29474
        BytesIO.write_through = BytesIO.write

    # At least one header required.
    # Header length max 131072 bytes
    # Key is 0 - 255 characters
    # Value is 0 - 16383 characters

    # Create header with length 131072
    header_key = 'x' * 256
    header_value = 'x' * 16383


# Generated at 2022-06-11 23:14:25.318986
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    kwargs = make_send_kwargs(args)
    assert kwargs.get('timeout') == None

# Generated at 2022-06-11 23:14:25.896913
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(True) is not None

# Generated at 2022-06-11 23:14:27.154057
# Unit test for function collect_messages
def test_collect_messages():
    print(list(collect_messages))

# Generated at 2022-06-11 23:14:59.722856
# Unit test for function finalize_headers
def test_finalize_headers():
    test_headers = {
        'Content-Type': 'application/x-www-form-urlencoded\t; charset=utf-8',
        'Other-Header': 'test\t\n',
        'Other-Header2': 'test2'
    }
    final_headers = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
        'Other-Header': 'test\n',
        'Other-Header2': 'test2'
    }
    assert finalize_headers(test_headers) == final_headers

# Generated at 2022-06-11 23:15:11.100523
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    ssl_version = None
    ciphers = None
    requests_session = build_requests_session(
        verify=verify,
        ssl_version=ssl_version,
        ciphers=ciphers,
    )
    assert isinstance(requests_session, requests.Session)
    assert requests_session.verify == verify
    assert requests_session.auth is None
    assert requests_session.cert is None
    assert requests_session.cookies == requests.cookies.RequestsCookieJar()
    assert requests_session.headers == {'User-Agent': DEFAULT_UA}
    assert requests_session.hooks['response'][0] == requests.adapters.DEFAULT_RETRIES.increment
    assert requests_session.max_redirects == requests.adapters.DE

# Generated at 2022-06-11 23:15:12.835718
# Unit test for function make_default_headers
def test_make_default_headers():
    make_default_headers(args = argparse.Namespace(
        data = {"1":"1"},
        form = False
    ))


# Generated at 2022-06-11 23:15:23.597918
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli.constants import DEFAULT_UA
    from httpie.request import make_request_headers_tuples
    args = argparse.Namespace()
    args.headers = {'Host':'foo.com', 'User-Agent': 'haha'}
    args.url = 'http://foo.com/'
    args.data = {}
    config_dir = Path('.')
    request_body_read_callback = lambda x : x
    httpie_session = get_httpie_session(
            config_dir=config_dir,
            session_name=args.session or args.session_read_only,
            host=args.headers.get('Host'),
            url=args.url,
        )
    httpie_session_headers = httpie_session.headers
    request_kwargs = make_

# Generated at 2022-06-11 23:15:27.404007
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=[120],
        allow_redirects=False,
    )
    kwargs = {
        'timeout': [120],
        'allow_redirects': False,
    }
    assert make_send_kwargs(args) == kwargs

# Generated at 2022-06-11 23:15:34.597956
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli import parser

    # GIVEN
    args = parser.parse_args([])
    args.proxy = []

    # WHEN
    kwargs = make_send_kwargs_mergeable_from_env(args)

    # THEN
    assert kwargs['stream'] is True
    assert kwargs['verify'] is True
    assert kwargs['proxies'] == {}
    assert kwargs['cert'] is None


# Generated at 2022-06-11 23:15:35.895815
# Unit test for function collect_messages
def test_collect_messages():
    collect_messages()

# Generated at 2022-06-11 23:15:39.118625
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version='TLSv1.3',
        ciphers='AECDH-AES256-SHA384',
    )
    print(requests_session)


# Generated at 2022-06-11 23:15:48.678160
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # x = requests.get('https://httpie.org/',verify=False)
    test_args = argparse.Namespace(
            data=[],
            files=[],
            form=False,
            json=False,
            chunked=False,
            headers=RequestHeadersDict(
                {'User-Agent': 'HTTPie/1.0.3'}),
            method='GET',
            offline=False,
            params=[],
            auth=None,
            url='https://httpie.org/',
            verify='False',
        )
    test_args.headers.update(
        {'User-Agent': 'HTTPie/1.0.3', 'Content-Type': 'application/json'})
    kwargs = make_request_kwargs(test_args)

# Generated at 2022-06-11 23:15:59.083023
# Unit test for function collect_messages
def test_collect_messages():
    from argparse import Namespace

    args = Namespace()
    args.url = 'http://localhost:8080'
    args.method = 'GET'
    args.headers = {}
    args.session = None
    args.session_read_only = None
    args.auth = None
    args.auth_plugin = None
    args.debug = True
    args.data = None
    args.form = False
    args.json = False
    args.compress = 0
    args.offline = False
    args.chunked = False
    args.path_as_is = False
    args.max_redirects = None
    args.follow = True
    args.all = False
    args.ssl_version = None
    args.ciphers = None
    args.verify = 'yes'

# Generated at 2022-06-11 23:16:31.747426
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class args:
        args = argparse.Namespace()
        args.data = None
        args.form = False
        args.json = True

        args.json, args.form = True, False
        assert make_request_kwargs(args).get('headers')['Accept'] == JSON_ACCEPT
        assert make_request_kwargs(args).get('headers')['Content-Type'] == JSON_CONTENT_TYPE

        args.json, args.form = False, True
        assert make_request_kwargs(args).get('headers')['Content-Type'] == FORM_CONTENT_TYPE

    print("Unit test success")


# Generated at 2022-06-11 23:16:42.672503
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(verify=False, cert='/path/to/cert', cert_key='/path/to/cert_key',
                              proxy=[argparse.Namespace(key='http', value='https://proxy.example.com'),
                                     argparse.Namespace(key='https', value='https://proxy.example.com')],
                              timeout=10.0
                              )
    send_kwargs_mergeable_from_env = {'verify': False,
                                      'proxies': {'http': 'https://proxy.example.com',
                                                  'https': 'https://proxy.example.com'},
                                      'cert': ('/path/to/cert', '/path/to/cert_key')
                                      }
    send_kwargs = {'timeout': args.timeout}

# Generated at 2022-06-11 23:16:53.508519
# Unit test for function finalize_headers
def test_finalize_headers():
    args = argparse.Namespace()
    req_hd = {"a": "b"}
    fin_hd = finalize_headers(req_hd)
    assert fin_hd == {"a": "b"}
    def test_finalize_headers():
        args = argparse.Namespace()
        req_hd = {"a": "b", "c": "  d"}
        fin_hd = finalize_headers(req_hd)
        assert fin_hd == {"a": "b", "c": "d"}
    def test_finalize_headers():
        args = argparse.Namespace()
        req_hd = {"a": "  b   ", "c": "  d"}
        fin_hd = finalize_headers(req_hd)
        assert fin_hd == {"a": "b", "c": "d"}

# Generated at 2022-06-11 23:16:55.517013
# Unit test for function max_headers
def test_max_headers():
    from httpie.core import main

    cmd = ['-v']
    assert not main(cmd)

# Generated at 2022-06-11 23:17:05.435122
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    headers = make_default_headers(args)
    assert headers['Content-Type'] == ''
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] == ''
    args = argparse.Namespace()
    args.headers = dict()
    headers = make_default_headers(args)
    assert headers['Content-Type'] == ''
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] == ''
    args = argparse.Namespace()
    args.json = False
    args.data = dict()
    args.headers = dict()
    headers = make_default_headers(args)
    assert headers['Content-Type'] == ''
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] == ''


# Generated at 2022-06-11 23:17:08.973659
# Unit test for function collect_messages
def test_collect_messages():
    args = ['http', 'localhost:5000/test_collect_messages_path', '-f', 'call_number=1']
    args = argparse.Namespace(method='GET', path_as_is=False, host='')
    collect_messages(args)
    assert True

# Generated at 2022-06-11 23:17:19.893777
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    def test_helper(args_input, final_output):
        args = argparse.Namespace()
        args.chunked = args_input['chunked']
        args.offline = args_input['offline']
        args.headers = args_input['headers']

        request_body_read_callback = lambda chunk: chunk

        result = make_request_kwargs(args, request_body_read_callback)

        assert final_output == result

    test_helper({'chunked': False, 'offline': False, 'headers': {'test_header': 'test_value'}},
                {'chunked': False, 'offline': False, 'headers': {'test_header': 'test_value'}})

# Generated at 2022-06-11 23:17:29.394259
# Unit test for function max_headers
def test_max_headers():
    # Expected behavior:
    # When client set header limit to 3, only 3 header would be send to server.
    # When client set header limit to negative, all header would be send.
    # When client set header limit to 0, no header would be send to server.
    # When client set header limit to 1, only 1 header would be send to server.

    # initialize variables
    lim = 3
    headers = ["A:B", "A:B", "A:B", "C:D"]
    k = 0
    # set header limit to 3
    with max_headers(lim):
        # create request
        request = requests.Request(method="GET", url="http://httpbin.org/get", headers=headers)
        prepped_request = requests.Session().prepare_request(request)
        # send headers to server

# Generated at 2022-06-11 23:17:33.310939
# Unit test for function max_headers
def test_max_headers():
    import http.client as http_client
    print("max headers: ", http_client._MAXHEADERS )
    with max_headers(100):
        print("max headers: ", http_client._MAXHEADERS)
    print("max headers: ", http_client._MAXHEADERS)


if __name__ == '__main__':
    test_max_headers()

# Generated at 2022-06-11 23:17:43.652354
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    ssl_version = None
    ciphers = None
    verify = False
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=verify
    )

    # args = None
    assert_raises(TypeError, make_request_kwargs, None)

    # Test case 1
    args.method = 'POST'
    args.url = 'https://httpbin.org/post'
    args.compress = False

    args.json = False
    args.data = {
        'hello': 'world'
    }
    args.json = True
    args.form = False

    args.timeout = 30

# Generated at 2022-06-11 23:18:42.730541
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=[],
        form=False,
        json=False,
        files=[])
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args = argparse.Namespace(
        data=False,
        form=False,
        json=False,
        files=[])
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

    args = argparse.Namespace(
        data={},
        form=False,
        json=True,
        files=[])
    default_headers = make_default_headers(args)

# Generated at 2022-06-11 23:18:50.583240
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    proxy = 'http://127.0.0.1:8118'
    kwargs = make_send_kwargs_mergeable_from_env(args=argparse.Namespace(proxy=proxy))
    assert kwargs['proxies']['http'] == proxy
    assert kwargs['proxies']['https'] == proxy
    kwargs = make_send_kwargs_mergeable_from_env(args=argparse.Namespace(no_proxy=['google.com']))
    assert kwargs['proxies']['no'] == ['google.com']

# Generated at 2022-06-11 23:19:01.904132
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # data passed, no form
    args = argparse.Namespace()
    args.data = 'test'
    args.form = False
    args.method = 'GET'
    args.url = 'http://www.example.com'
    args.headers = {'User-Agent': 'HTTPie'}
    args.json = False
    args.auth = 'user:pass'
    args.params = {'arg1': 'val1', 'arg2': 'val2'}
    args.files = None
    request_body_read_callback = lambda chunk: chunk
    kwargs = make_request_kwargs(args, request_body_read_callback)
    assert kwargs['method'] == 'get'
    assert kwargs['url'] == 'http://www.example.com'

# Generated at 2022-06-11 23:19:08.176389
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    
    args = argparse.Namespace()
    args.proxy = [URLArgument("http://127.0.0.1")]
    args.cert = ''
    args.cert_key = ''
    args.verify = "yes"

    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {'http': 'http://127.0.0.1/'},
        'stream': True,
        'verify': "yes",
        'cert': None,
    }



# Generated at 2022-06-11 23:19:18.929083
# Unit test for function collect_messages
def test_collect_messages():
    import tempfile
    import shutil
    from httpie.config import Config
    from httpie.plugins.registry import plugin_manager
    cdir = tempfile.mkdtemp()
    cdir = Path(cdir)
    config = Config(
            config_dir=cdir,
            config_file=cdir / 'config.json',
            env=None,
        )
    httpie_session = None
    httpie_session_headers = None
    request_kwargs = None
    send_kwargs = {
        'timeout': None,
        'allow_redirects': False
    }

# Generated at 2022-06-11 23:19:25.053200
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    headers = make_default_headers(args)
    assert headers.get("Accept") == JSON_ACCEPT
    args.json = False
    headers = make_default_headers(args)
    assert headers.get("Accept") is None
    args.form = True
    headers = make_default_headers(args)
    assert headers.get("Content-Type") == FORM_CONTENT_TYPE

# Generated at 2022-06-11 23:19:26.162131
# Unit test for function make_default_headers
def test_make_default_headers():
    pass


# Generated at 2022-06-11 23:19:36.905961
# Unit test for function collect_messages
def test_collect_messages():
    import contextlib
    import unittest.mock

    with contextlib.ExitStack() as stack:
        request_body_read_callback = stack.enter_context(
            unittest.mock.patch.object(
                sys.stdout,
                'buffer',
                unittest.mock.MagicMock(spec=sys.stdout.buffer),
            )
        ).write
        config_dir = stack.enter_context(
            unittest.mock.patch(
                'httpie.cli.requests_impl.get_config_dir',
                return_value=unittest.mock.sentinel.config_dir,
            )
        )

# Generated at 2022-06-11 23:19:43.059789
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    sys.argv = [
        "http",
        "--verify",
        "yes",
        "--proxy",
        "host:80",
        "--cert",
        "cert.pem",
        "--cert-key",
        "key.pem",
        "https://www.integralist.co.uk/posts/http-testing-in-python",
    ]
    args = parse_args()
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['proxies'] == {'http': 'host:80'}
    assert send_kwargs_mergeable_from_env['verify']
    assert send_kwargs_mergeable_from_

# Generated at 2022-06-11 23:19:52.872572
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Unit test for function make_send_kwargs_mergeable_from_env
    # with insecure password
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'false'
    args.cert = ''
    args.cert_key = ''
    test_verify = make_send_kwargs_mergeable_from_env(args)['verify']
    assert test_verify is False

    # with secure password
    args.verify = 'true'
    test_verify_1 = make_send_kwargs_mergeable_from_env(args)['verify']
    assert test_verify_1 is True

    # test proxy
    args.proxy = [argparse.Namespace(key='http', value='http://http-proxy.org')]
    test

# Generated at 2022-06-11 23:21:42.732082
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=False,
        ssl_version=None,
        ciphers=None,
    )

    assert not requests_session.verify, "The verify property should be False"
    assert requests_session.stream, "The stream property should be True"

# Generated at 2022-06-11 23:21:51.028439
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.context import Environment
    from httpie.input import KeyValue, KeyValueArgType, KeyValueType
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    a = ['-i', '-v', '--print=B', 'GET', 'http://httpbin.org/get']
    args = argparse.Namespace()
    args.max_redirects = 5
    args.max_headers = 32
    args.offline = False
    args.chunked = False
    args.compress = None
    args.debug = False
    args.follow = True
    args.headers = []
    args.output_options = ['B']
    args.output_file = None
    args.timeout = None
    args.session = None
    args.session_

# Generated at 2022-06-11 23:21:53.936741
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None), max_headers(123), max_headers(float('Inf')):
        assert http.client._MAXHEADERS is float('Inf')
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-11 23:22:04.090019
# Unit test for function make_request_kwargs