

# Generated at 2022-06-11 23:12:50.765213
# Unit test for function collect_messages
def test_collect_messages():
    class Args():
        def __init__(self):
            self.auth_plugin = 'NoAuth'
            self.debug = False
            self.files = []
            self.form = False
            self.headers = {}
            self.method = 'GET'
            self.multipart = False
            self.multipart_data = []
            self.offline = False
            self.params = []
            self.path_as_is = False
            self.proxy = []
            self.session = None
            self.session_read_only = None
            self.ssl_version = None
            self.timeout = 180
            self.url = "http://httpbin.org"
            self.verify = True
            self.session = None
            self.session_read_only = None
            self.json = None
           

# Generated at 2022-06-11 23:13:01.477934
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from httpie import __version__
    from httpie.cli.dicts import RequestHeadersDict
    args = argparse.Namespace()
    headers = RequestHeadersDict({
        'User-Agent': f'HTTPie/{__version__}'
    })
    headers.update({'TestAuthorization': ['Basic']})
    headers.update({'Test-Token': ['123T']})
    headers.update({'Test-Content': ['application/json']})
    headers.update({'Test-Accept': ['application/json']})
    headers = finalize_headers(headers)
    args.url = 'https://httpbin.org/get'
    args.method = 'get'
    args.headers = headers

# Generated at 2022-06-11 23:13:12.824394
# Unit test for function make_default_headers

# Generated at 2022-06-11 23:13:22.501231
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    arg_namespace = argparse.Namespace()
    kwargs = make_send_kwargs(arg_namespace)
    assert kwargs['timeout'] is None
    assert not kwargs['allow_redirects']
    arg_namespace.timeout = 10
    kwargs = make_send_kwargs(arg_namespace)
    assert kwargs['timeout'] == 10
    assert not kwargs['allow_redirects']
    arg_namespace.allow_redirects = True
    kwargs = make_send_kwargs(arg_namespace)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects']

# Generated at 2022-06-11 23:13:23.198365
# Unit test for function collect_messages
def test_collect_messages():
    assert None

# Generated at 2022-06-11 23:13:34.478622
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.plugins import AuthPlugin
    from httpie.cli.parser import parse
    from httpie.cli.context import Environment
    env = Environment()
    args = parse(args=[], env=env)
    args.proxy = [urllib3.util.url.ProxyInfo(None, 'http://localhost:8080', True)]
    args.verify = 'yes'
    args.auth_plugin = AuthPlugin()
    args.auth_plugin.raw_auth = 'foo'
    args.cert = 'bar'
    args.cert_key = 'baz'

# Generated at 2022-06-11 23:13:35.538662
# Unit test for function make_default_headers
def test_make_default_headers():
    make_default_headers(argparse.Namespace())

# Generated at 2022-06-11 23:13:48.365423
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class args:
        pass

    args.method = 'GET'
    args.url = 'https://httpbin.org/ip'
    args.headers = {}
    args.data = {}
    args.json = True
    args.form = False
    args.files = {}
    args.multipart = False
    args.multipart_data = []
    args.boundary = '-BOUNDARY-'
    args.auth = None
    args.timeout = None
    args.verify = False
    args.cert = None
    args.cert_key = None
    args.proxy = {}
    args.allow_redirects = False
    args.debug = False
    args.chunked = False
    args.offline = False

    request_kwargs = make_request_kwargs(args)

# Generated at 2022-06-11 23:13:55.995594
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    test_namespace = argparse.Namespace()
    test_namespace.proxy = [argparse.Namespace(key='http', value='http://foo:80'), argparse.Namespace(key='https', value='http://foo:443')]
    test_namespace.verify = 'true'
    test_namespace.cert = None
    test_namespace.cert_key = None
    ret = make_send_kwargs_mergeable_from_env(test_namespace)
    print(ret)
    ret_expected = {'proxies': {'http': 'http://foo:80', 'https': 'http://foo:443'}, 'stream': True, 'verify': True, 'cert': None}
    assert ret == ret_expected

# Generated at 2022-06-11 23:14:03.503882
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['verify'] == False
    assert send_kwargs_mergeable_from_env['proxies'] == {'http': 'http://10.10.1.10:3128', 'https': 'http://10.10.1.10:1080'}
    assert send_kwargs_mergeable_from_env['cert'] == '/path/client.cert'


# Generated at 2022-06-11 23:14:21.967170
# Unit test for function collect_messages
def test_collect_messages():
    args = None
    config_dir = None
    request_body_read_callback = None
    try:
        collect_messages(args, config_dir, request_body_read_callback)
    except:
        pass

# Generated at 2022-06-11 23:14:29.547246
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(verify='False', cert_key='abc', cert='abc.pem', proxy=['http://1.1.1.1', 'https://google.com'])
    result = make_send_kwargs_mergeable_from_env(args)
    assert not result['verify']
    assert result['cert'] == ('abc.pem', 'abc')
    assert result['proxies'] == {'http://1.1.1.1': None, 'https://google.com': None}

# Generated at 2022-06-11 23:14:37.781452
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import argparse
    class Args:
        def __init__(self):
            self.verify = 'true'
            self.cert = 'cert_path'
            self.cert_key = 'cert_key_path'
            self.proxy = [
                argparse.Namespace(key="https", value="https://proxy"),
                argparse.Namespace(key="http", value="http://proxy"),
            ]
    kwargs = make_send_kwargs_mergeable_from_env(Args())
    assert kwargs['verify'] == True
    assert kwargs['cert'] == "cert_path"
    assert kwargs['proxies']['https'] == "https://proxy"
    assert kwargs['proxies']['http'] == "http://proxy"

# Generated at 2022-06-11 23:14:40.861095
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 100
    with max_headers(limit=4):
        assert http.client._MAXHEADERS == 4
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-11 23:14:51.910808
# Unit test for function collect_messages
def test_collect_messages():
    import pytest
    from httpie import doc_opts
    result = ''
    def collect_messages_wrapper(args, config_dir, request_body_read_callback):
        nonlocal result
        # First prepare the message
        request_kwargs = make_request_kwargs(
            args=args,
            base_headers=None,
            request_body_read_callback=None
        )

        send_kwargs = make_send_kwargs(args)
        send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-11 23:15:05.242929
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class _args:
        headers={'Content-Type': 'text/plain'}

    # tests with chunked
    args_chunked = _args()
    args_chunked.method = 'GET'
    args_chunked.url = 'http://www.google.com'
    args_chunked.files = None
    args_chunked.chunked = True
    args_chunked.offline = True
    test_kwargs = make_request_kwargs(args_chunked, request_body_read_callback=None)

# Generated at 2022-06-11 23:15:10.971462
# Unit test for function make_default_headers
def test_make_default_headers():
    accept = JSON_ACCEPT
    content_type = JSON_CONTENT_TYPE
    args = argparse.Namespace()
    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == accept
    assert default_headers['Content-Type'] == content_type


# Generated at 2022-06-11 23:15:21.745611
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli import parser
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import plugin_manager


# Generated at 2022-06-11 23:15:25.182991
# Unit test for function collect_messages
def test_collect_messages():
    # args, config_dir, request_body_read_callback
    x = collect_messages(
        args="",
        config_dir="",
        request_body_read_callback="",
    )
    assert not x


# Generated at 2022-06-11 23:15:28.660589
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    test_arg = argparse.Namespace(timeout=10)
    test_kwargs = make_send_kwargs(test_arg)
    assert test_kwargs == {'timeout': 10, 'allow_redirects': False}



# Generated at 2022-06-11 23:16:07.132862
# Unit test for function max_headers
def test_max_headers():
    # import tempfile
    # import os
    # sys.stderr = open(os.path.join(tempfile.gettempdir(), 'tmp.log'), 'w')
    global http
    with max_headers(1):
        http.client._MAXHEADERS = 1
    with max_headers(2):
        http.client._MAXHEADERS = 2
    with max_headers(3):
        http.client._MAXHEADERS = 3
    with max_headers(4):
        http.client._MAXHEADERS = 4
    with max_headers(5):
        http.client._MAXHEADERS = 5
    with max_headers(6):
        http.client._MAXHEADERS = 6
    with max_headers(7):
        http.client._MAXHEADERS = 7

# Generated at 2022-06-11 23:16:17.561643
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = make_send_kwargs_mergeable_from_env({"proxy": [{"key": "http", "value": "http://127.0.0.1:8888"},
                                                          {"key": "https", "value": "https://127.0.0.1:8888"}],
                                                "verify": "true",
                                                "cert": "True",
                                                "cert_key": "True"})
    assert args == {"proxies": {"http": "http://127.0.0.1:8888", "https": "https://127.0.0.1:8888"},
                    "stream": True, "verify": "true", "cert": "True"}

# Generated at 2022-06-11 23:16:29.538294
# Unit test for function collect_messages
def test_collect_messages():
    import argparse

# Generated at 2022-06-11 23:16:40.349659
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        method='get',
        url='http://www.httpbin.org/get',
        headers={'Content-Type': 'application/json'},
        data=b'{"hello": "world"}',
        form=False,
        json=False,
        files=False,
        multipart=False,
        chunked=False,
        offline=False,
        auth=None,
        params=[], 
        verify='true', 
        cert=None, 
        cert_key=None
    )
    kwargs = make_request_kwargs(args)
    assert kwargs['url'] == 'http://www.httpbin.org/get'
    assert kwargs['method'] == 'get'

# Generated at 2022-06-11 23:16:50.621468
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    base_headers = RequestHeadersDict()
    final_dict = {
        'method': None,
        'url': None,
        'headers': None,
        'data': None,
        'auth': None,
        'params': None,
        'files': None,
        'json': None,
        'form': None,
        'chunked': None,
    }
    assert make_request_kwargs(args, base_headers) == final_dict
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.json = 'true'
    data = {'hello':'world'}
    args.data = data

# Generated at 2022-06-11 23:16:56.429660
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    headers_dict = make_default_headers(args)
    assert(headers_dict['User-Agent'] == DEFAULT_UA)

# Generated at 2022-06-11 23:17:06.298540
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = [
        'https://httpbin.org/post',
        '--auth',
        'testuser:123456',
        '--json',
        '--headers',
        'X_Test: abc',
        '--headers',
        'X-Test2: def',
        '--form',
        'foo=bar',
        '--data',
        '{"x": "y"}',
        '--verify',
        'no',
        '--timeout',
        '300',
        '--cert',
        '/home/testuser/test.crt',
        '--cert-key',
        '/home/testuser/test.key'
    ]

    from argparse import Namespace
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        args = argparse.Namespace

# Generated at 2022-06-11 23:17:17.242590
# Unit test for function collect_messages

# Generated at 2022-06-11 23:17:26.490895
# Unit test for function collect_messages
def test_collect_messages():
    from click.testing import CliRunner
    from httpie.cli import main
    from .test_utils import run_httpie

# Generated at 2022-06-11 23:17:30.550327
# Unit test for function max_headers
def test_max_headers():
    limit = 5
    try:
        with max_headers(limit):
            pass
    except:
        assert False, 'context manager max_headers failed in try block'

    # check we restored default value after leaving with block
    assert http.client._MAXHEADERS == 1000, 'did not reset to default'

# Generated at 2022-06-11 23:18:58.430818
# Unit test for function collect_messages
def test_collect_messages():
    class Args:
        def __init__(self, url, method, headers, data, files, params, form,
                     json, auth, auth_plugin, debug, max_headers, offline,
                     chunked, multipart, multipart_data, boundary, cert, cert_key,
                     compress, proxy, timeout, max_redirects, follow, all, session,
                     session_read_only, path_as_is, verify, ssl_version, ciphers):
            self.url = url
            self.method = method
            self.headers = headers
            self.data = data
            self.files = files
            self.params = params
            self.form = form
            self.json = json
            self.auth = auth
            self.auth_plugin = auth_plugin
            self.debug = debug
            self.max_

# Generated at 2022-06-11 23:19:01.538338
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 0
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 0


# Generated at 2022-06-11 23:19:09.727112
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace(
        auth_plugin=None,
        cert=None,
        cert_key=None,
        chunked=None,
        data=None,
        debug=None,
        files=False,
        headers=RequestHeadersDict(),
        json=False,
        max_redirects=None,
        method='GET',
        offline=False,
        params=argparse.Namespace(),
        path_as_is=None,
        session=None,
        session_read_only=None,
        ssl_version=None,
        timeout=None,
        url='http://foo'
    )
    config_dir = Path('.')
    request_body_read_callback = lambda chunk: chunk

    # Test type

# Generated at 2022-06-11 23:19:20.556454
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "http://localhost:8080"
    args.headers = {'Content-Type': 'application/json'}
    args.data = {}
    args.json = False
    args.form = False
    args.auth = None
    args.params = {}
    args.files = None
    args.chunked = False
    args.offline = False
    args.compress = False
    args.follow = False
    args.all = False
    args.download = False
    args.output = None
    args.session = None
    args.auth_plugin = None
    args.timeout = 5
    args.verify = False
    args.cert = None
    args.cert_key = None
    args.max_red

# Generated at 2022-06-11 23:19:26.021802
# Unit test for function max_headers
def test_max_headers():
    import http.client as http
    import http.cookies as cookies
    import _http_clientserver
    _http_clientserver.MAX_HEADERS = 123
    assert _http_clientserver.MAX_HEADERS == 123
    http.MAX_HEADERS = 321
    assert http.MAX_HEADERS == 321
    assert http._MAXHEADERS == 321
    assert cookies.Cookie.MAX_HEADERS == 123

# Generated at 2022-06-11 23:19:26.703330
# Unit test for function max_headers
def test_max_headers():
    pass

# Generated at 2022-06-11 23:19:37.390343
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import http.client
    import json
    import sys
    from contextlib import contextmanager
    from pathlib import Path
    from typing import Callable, Iterable, Union
    from urllib.parse import urlparse, urlunparse
    import requests
    from httpie import __version__
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.ssl import AVAILABLE_SSL_VERSION_ARG_MAPPING, HTTPieHTTPSAdapter
    from httpie.uploads import (
        compress_request, prepare_request_body,
        get_multipart_data_and_content_type,
    )
    from httpie.utils import get_expired

# Generated at 2022-06-11 23:19:46.309262
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()

    args.method = "get"
    args.url = "www.google.com"
    args.timeout = 2
    args.headers = {'User-Agent':'mohit'}
    args.data = "Hello"
    args.json = {}
    args.form = False
    args.multipart = False
    args.multipart_data = {"name":"mohit","value":"gupta"}
    args.boundary = "abc"
    args.auth = "abc"
    args.params = {"key":"value"}
    args.debug = False
    args.offline = True
    response = make_request_kwargs(args)

    assert response["method"] == "get"
    assert response["url"] == "www.google.com"

# Generated at 2022-06-11 23:19:56.348984
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    """Unit test case for function make_send_kwargs
    by injecting different arguments to it and testing it is as expected
    :return:
    """
    class MockNamespace:
        def __init__(self, timeout:'int'=30, verify:'str'='true'):
            self.timeout = timeout
            self.verify = verify

    class MockArgument:
        def __init__(self, key:'str', value:'str'):
            self.key = key
            self.value = value

    def _test_make_send_kwargs(args:'argparse.Namespace', expected_kwargs:dict):
        kwargs = make_send_kwargs(args)
        assert kwargs == expected_kwargs


# Generated at 2022-06-11 23:19:58.425218
# Unit test for function max_headers
def test_max_headers():
    with max_headers(3):
        assert http.client._MAXHEADERS == 3
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-11 23:21:00.353836
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli.parser import get_argparser
    from .timer import Timer
    from httpie import exit_status
    class Options(object):
        def __init__(self, args):
            self.__dict__ = args.__dict__
    args = get_argparser().parse_args()
    args.debug = True
    args.form = True
    args.url = 'https://www.baidu.com'
    args.method = 'GET'
    args.max_redirects = 2
    args.max_headers = None
    args.json = False
    args.data = None
    args.files = None
    args.compress = False
    args.offline = False
    args.headers = RequestHeadersDict()
    args.auth = None
    args.verify = True


# Generated at 2022-06-11 23:21:05.098181
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=False, form=False, files=[], data=None, auth=None)
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] is None
    assert headers['Content-Type'] is None


# Generated at 2022-06-11 23:21:11.105371
# Unit test for function max_headers
def test_max_headers():
    with open('max_headers.txt', 'w') as f:
        with f as sys.stderr:
            with max_headers(10):
                f.write('hello')
                f.flush()
                f.seek(0)
                assert f.read() == 'hello'
    with open('max_headers.txt', 'r') as f:
        assert f.read() == ''


# Generated at 2022-06-11 23:21:15.204457
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout':10, 'allow_redirects':False}

# Tests for function finalize_headers

# Generated at 2022-06-11 23:21:19.180363
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    default_send_kwargs = {
        'timeout': 10,
        'allow_redirects': False,
    }
    assert default_send_kwargs == make_send_kwargs(args)



# Generated at 2022-06-11 23:21:25.748350
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        cert = None,
        cert_key = None,
        proxy = [],
        verify = False,
        proxy_auth = None,
    )
    kwargs = make_send_kwargs_mergeable_from_env(args)

    assert kwargs['proxies'] == {}, 'Proxies should be empty'
    assert kwargs['verify'] == False, 'Verify should be False'
    assert kwargs['cert'] == None, 'Cert should be None'

# Generated at 2022-06-11 23:21:30.561998
# Unit test for function max_headers
def test_max_headers():
    """
    Test if max_headers() works as expected, given a certain limit.

    """
    # This statement raises a NoneType error due to the return value
    # being None, instead of a (modified) response with a limit set
    # to 10. This issue is solved by adding a yield statement.
    #
    # assert max_headers(10) == None

    # Testing max_headers() with a limit set to 10.
    assert next(max_headers(10)) == 10


# Generated at 2022-06-11 23:21:32.925074
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version='TLSv1.2'
    )
    assert requests_session is not None

# Generated at 2022-06-11 23:21:43.656742
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    """
    The unit test to check the functionality of make_request_kwargs
    """
    class Args:
        method = "GET"
        headers = {}
        json = "json"
        form = "form"
        offline = "offline"
        chunked = "chunked"
        auth= "auth"
        cert = "cert"
        cert_key = "cert_key"
        data = "data"
        params = "params"

    class Proxy:
        key = "key"
        value = "value"

    args = Args()
    args.url = "https://example.com"
    args.headers = {"key": "value"}
    args.auth_plugin = "auth_plugin"
    args.session = "session"

# Generated at 2022-06-11 23:21:51.437625
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import argparse
    from httpie.cli.argtypes import KeyValueArg
    from sys import version_info
    if version_info < (3, 6):
        from collections import OrderedDict
    else:
        OrderedDict = dict
    args = argparse.Namespace()
    args.verify = "some-string"
    args.proxy = OrderedDict()
    args.proxy['key'] = KeyValueArg('key')
    args.proxy['key'].value = "value"
    args.cert = "/path/to/cert"
    args.cert_key = "/path/to/cert"
    ret = make_send_kwargs_mergeable_from_env(args)
    assert ret["verify"] == "some-string"