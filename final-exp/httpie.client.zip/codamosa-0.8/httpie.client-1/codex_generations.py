

# Generated at 2022-06-11 23:12:38.092882
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # This is an automatic test for the function make_request_kwargs
    args = argparse.Namespace()
    args.method = 'post'
    args.url = 'http://localhost:5000'
    args.headers = {'Content-Type':'json'}
    args.data = {}
    args.form = False
    args.json = True
    args.files = None
    args.auth = None
    args.params = {'height':'0.72', 'width':'3.3'}
    args.verify = True
    args.chunked = False
    args.offline = False
    args.debug = False
    args.path_as_is = False
    args.session = None
    args.session_read_only = None
    args.compress = True
    args.compress_

# Generated at 2022-06-11 23:12:43.353739
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.__dict__ = {'timeout': None, 'allow_redirects': False, 'body': '{"name": "sharath"}'}
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}
    return


# Generated at 2022-06-11 23:12:51.472311
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        cert = None,
        cert_key = None,
        verify = 'yes',
        proxy = [
            argparse.Namespace(key = 'http', value = 'http://example.com'),
            argparse.Namespace(key = 'https', value = 'https://example.com')
        ]
    )
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {'http': 'http://example.com', 'https': 'https://example.com'}, 'stream': True, 'verify': True, 'cert': None}

# Generated at 2022-06-11 23:12:55.618211
# Unit test for function make_default_headers
def test_make_default_headers():
    import httpie.cli.argtypes

    args = argparse.Namespace()
    args.json = False
    args.data = None
    args.form = False

    assert make_default_headers(args) == RequestHeadersDict({'User-Agent': 'HTTPie/2.2.0'})

# Generated at 2022-06-11 23:12:58.729682
# Unit test for function max_headers
def test_max_headers():
    import os
    os.environ['http_parser.max_header_size'] = '123'
    with max_headers(None):
        assert http.client._MAXHEADERS == 123

# Generated at 2022-06-11 23:12:59.356330
# Unit test for function collect_messages
def test_collect_messages():
    pass

# Generated at 2022-06-11 23:13:00.895125
# Unit test for function max_headers
def test_max_headers():
    headers = {'test': 'test'}
    with max_headers(limit=1):
        if len(headers) <= 1:
            return True
    return False

# Generated at 2022-06-11 23:13:04.499387
# Unit test for function build_requests_session
def test_build_requests_session():
    ssl_version='TLSv1_3'
    ciphers='foo'
    verify=True
    requests_session = build_requests_session(ssl_version, ciphers, verify)
    assert isinstance(requests_session, requests.Session)

# Generated at 2022-06-11 23:13:13.552859
# Unit test for function max_headers
def test_max_headers():

    import requests.models
    class response():
        class _original_response():
            msg = requests.models.Response()
            msg._headers = list()
            msg._headers.append([b'Content-Length', b'9999364'])
        def __init__(self):
            self.raw = response._original_response()

    # Initiate the class
    test = response()
    
    # Test for get_expired_cookies
    expired = get_expired_cookies(
                headers=test.raw._original_response.msg._headers
            )
    assert len(expired) == 0

# Generated at 2022-06-11 23:13:24.666703
# Unit test for function collect_messages

# Generated at 2022-06-11 23:13:51.481678
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        proxy=['http://foo', 'http://bar'],
        verify='false',
        cert='key.crt',
        cert_key='/home/foo',
    )
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    print(send_kwargs_mergeable_from_env)
    # the output is : {'verify': False, 'proxies': {'http': 'http://bar', 'https': 'http://bar'}, 'cert': ('key.crt', '/home/foo'), 'stream': True}

    args = argparse.Namespace(
        proxy=[],
        verify='true',
        cert=None,
        cert_key=None,
    )
    send

# Generated at 2022-06-11 23:13:54.723487
# Unit test for function max_headers
def test_max_headers():
    import http.client
    import random

    max_header_len = random.randrange(1000)
    with max_headers(max_header_len):
        assert http.client._MAXHEADERS == max_header_len
        print(http.client._MAXHEADERS)

test_max_headers()

# Generated at 2022-06-11 23:13:57.260922
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_kwargs = make_send_kwargs(argparse.Namespace())
    assert args_kwargs['timeout'] == None
    assert args_kwargs['allow_redirects'] == False


# Generated at 2022-06-11 23:14:07.597300
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    headers = make_default_headers(args)
    assert headers.get('User-Agent') == DEFAULT_UA
    assert headers.get('Accept') is None
    assert headers.get('Content-Type') is None

    args.json = True
    headers = make_default_headers(args)
    assert headers.get('User-Agent') == DEFAULT_UA
    assert headers.get('Accept') == JSON_ACCEPT
    assert headers.get('Content-Type') == JSON_CONTENT_TYPE

    args.form = True
    headers = make_default_headers(args)
    assert headers.get('User-Agent') == DEFAULT_UA
    assert headers.get('Accept') is None
    assert headers.get('Content-Type')

# Generated at 2022-06-11 23:14:10.709940
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    headers = make_default_headers(args)
    assert headers == {'User-Agent': 'HTTPie/X.Y.Z'}

# Generated at 2022-06-11 23:14:18.632442
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = None
    args.headers = {
        'Accept': None,
    }
    default_headers = make_default_headers(args)
    assert 'Accept' in default_headers
    assert default_headers['Accept'] == 'application/json, */*;q=0.5'
    assert 'User-Agent' in default_headers
    assert default_headers['User-Agent'] == DEFAULT_UA



# Generated at 2022-06-11 23:14:30.156008
# Unit test for function max_headers
def test_max_headers():
    limit = 10
    headers = []
    for i in range(limit+1):
        headers.append(('Header-{}'.format(i), 'Value{}'.format(i)))
    with max_headers(limit):
        resp = requests.Request('GET', 'http://www.httpbin.org/headers', headers=headers)
    # Ensure the response has been sent, since the context manager runs on a separate thread
    requests.Session().send(resp, allow_redirects=True)
    assert resp.status_code == 200
    # Check that all the headers are in the response from server
    for i in range(limit):
        assert headers[i][0] in resp.json()['headers']
    # Check that the header limit was enforced
    assert headers[limit][0] not in resp.json()['headers']

# Generated at 2022-06-11 23:14:38.010247
# Unit test for function collect_messages
def test_collect_messages():
    import os
    import sys
    import unittest


# Generated at 2022-06-11 23:14:41.832013
# Unit test for function make_default_headers
def test_make_default_headers():
    import pytest
    with pytest.raises(TypeError):
        make_default_headers(["hello"])
    assert make_default_headers(argparse.Namespace()) == RequestHeadersDict({'User-Agent': 'HTTPie/2.0.0-dev17'})

# Generated at 2022-06-11 23:14:53.206461
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    kwargs = make_request_kwargs(argparse.Namespace(
        method='GET',
        url='https://www.jd.com/',
        headers = RequestHeadersDict({'name': 'tom', 'password': 'jerry'}),
        data = '',
        auth = '',
        params = '',
        json = False,
        form = False,
        files = False,
        chunked = False,
        offline = True,
        base_headers = None,
        request_body_read_callback = None
    ))

# Generated at 2022-06-11 23:15:23.187463
# Unit test for function make_default_headers
def test_make_default_headers():
    make_default_headers(args.__dict__)

# Generated at 2022-06-11 23:15:33.819594
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.google.com'
    args.form = True
    args.data = [{'name': 'Liu'}]
    args.json = True
    args.auth = ('username','password')
    args.params = {'key1':'value1','key2':'value2'}
    args.headers = {'User-Agent':'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Mobile Safari/537.36'}
    args.path_as_is = False
    args.compress = False
    args.debug = False
    args.timeout

# Generated at 2022-06-11 23:15:38.276175
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(
    args=args,
    config_dir=config_dir,
    request_body_read_callback=request_body_read_callback
)



# Generated at 2022-06-11 23:15:48.334476
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    
    from argparse import Namespace

    args = Namespace()

    args.cert = 'test.crt'
    args.cert_key = 'test.pem'
    args.timeout = 10
    args.verify = 'yes'
    args.proxy = [urllib3.ProxyManager('https://proxy.com')]

    assert(make_send_kwargs(args)) == {
        'timeout': 10,
        'allow_redirects': False
    }

# Generated at 2022-06-11 23:15:50.135174
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session('https://app.api.tago.io/', "HTTPie")

# Generated at 2022-06-11 23:16:00.160597
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class Args:
        def __init__(self, method=None, url=None, cert=None, cert_key=None,
                     headers=None, json=False, data=None, form=None, timeout=None,
                     proxy=None, verify=None, chunked=None, offline=None,
                     path_as_is=False, multipart=False, compress=False,
                     chunk_size=None, session=None, max_redirects=None,
                     max_headers=None, auth_plugin=None):
            self.method = method
            self.url = url
            self.cert = cert
            self.cert_key = cert_key
            self.headers = headers
            self.json = json
            self.data = data
            self.form = form
            self.timeout = timeout

# Generated at 2022-06-11 23:16:11.516953
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cert",
        help="""Path to the client certificate, a single file containing
             the private key and the certificate in PEM format.
             """
    )
    parser.add_argument(
        "--cert-key",
        help="""Path to the client certificate key.
             """
    )
    parser.add_argument(
        "--proxy",
        action="append",
        default=[],
        help="""Proxy URL scheme, user and password, hostname and port.
            """
    )
    parser.add_argument(
        "--verify",
        help="""Set to "yes" to enable SSL certificate verification.
             """
    )

# Generated at 2022-06-11 23:16:16.881534
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = 'cert'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert 'proxies' in kwargs
    assert 'stream' in kwargs
    assert 'verify' in kwargs
    assert 'cert' in kwargs

# Generated at 2022-06-11 23:16:23.944715
# Unit test for function collect_messages
def test_collect_messages():
    # check if each message is instance of prepared request and response

    import argparse

    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = None
    args.headers = {}
    args.method = 'GET'
    args.url = 'https://httpbin.org/get'
    args.auth = None
    args.auth_plugin = None
    args.compress = False
    args.chunked = False
    args.follow = False
    args.timeout = None
    args.max_redirects = 30
    args.max_headers = 200
    args.verify = True
    args.debug = False
    args.all = False
    args.outfile = '-'
    args.params = {}

# Generated at 2022-06-11 23:16:27.394853
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=42,
        allow_redirects=False,
        proxy=[],
        verify='yes',
        cert='',
        cert_key='',
    )
    result = make_send_kwargs(args)
    expected = {
        'timeout': 42,
        'allow_redirects': False,
    }
    assert result == expected


# Generated at 2022-06-11 23:18:12.750603
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:18:22.277540
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Completely wrong arguments
    try:
        make_send_kwargs_mergeable_from_env(1)
    except TypeError:
        pass

    args = argparse.Namespace()

    # Default arguments
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }

    # Proxies
    args.proxy = [
        argparse.Namespace(key='http', value='localhost:3128'),
        argparse.Namespace(key='https', value='localhost:3128'),
        argparse.Namespace(key='socks', value='localhost:9050'),
    ]
    kwargs = make

# Generated at 2022-06-11 23:18:26.427271
# Unit test for function max_headers
def test_max_headers():
    from requests.structures import CaseInsensitiveDict
    with max_headers(255):
        assert http.client._MAXHEADERS == 255
        test_dict = CaseInsensitiveDict()
        test_dict.update({"a" * 1024: "b" * 1024})
        http.client.parse_headers(test_dict.items())
    assert http.client._MAXHEADERS == 100


# Generated at 2022-06-11 23:18:36.536736
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli_args
    import httpie.cli.argtypes
    # args = argparse.Namespace(
    #     auth=None,
    #     auth_plugin=None,
    #     auth_type=None,
    #     chunked=False,
    #     compress=False,
    #     data={'@': 't1.txt'},
    #     files=[],
    #     form=False,
    #     headers={},
    #     json=True,
    #     method='POST',
    #     multibyte_encoding=None,
    #     params=[]
    # )
    # args.headers['Content-Type'] = 'application/json'

    # args._env = None
    # args.output_options = None
    # args.output

# Generated at 2022-06-11 23:18:41.850967
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = ['test']
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == 'application/json, */*;q=0.5' and default_headers['Content-Type'] == 'application/json'


# Generated at 2022-06-11 23:18:45.727294
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    result_dict = make_default_headers(args)
    assert type(result_dict) == RequestHeadersDict
    assert result_dict.items() == [('User-Agent', DEFAULT_UA)]



# Generated at 2022-06-11 23:18:50.742352
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    parser = argparse.ArgumentParser()
    add_parser_options(parser)
    args = parser.parse_args(
        ['-d', '{"a": "b"}', 'https://example.org/upload'],
    )
    request_kwargs = make_request_kwargs(args)
    print(request_kwargs)


# Generated at 2022-06-11 23:18:53.949748
# Unit test for function max_headers
def test_max_headers():
    import http.client
    max_headers = 100
    # Check that http.client._MAXHEADERS = 100
    with max_headers(100):
        assert http.client._MAXHEADERS == 100

# Generated at 2022-06-11 23:19:04.750396
# Unit test for function collect_messages
def test_collect_messages():
    class Args:
        def __init__(self):
            self.auth = None
            self.auth_plugin = None
            self.chunked = None
            self.compress = None
            self.data = None
            self.debug = None
            self.form = None
            self.headers = None
            self.json = None
            self.max_headers = None
            self.max_redirects = None
            self.method = None
            self.offline = None
            self.params = None
            self.path_as_is = None
            self.proxy = None
            self.session = None
            self.timeout = None
            self.url = None
            self.verify = None

    import tempfile
    config_dir = tempfile.TemporaryDirectory()
    args = Args()
    args

# Generated at 2022-06-11 23:19:13.684211
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli.parser import parser
    args = parser.parse_args(
        ['--method', 'GET', 'https://httpbin.org/get']
    )
    httpie_session = get_httpie_session(
        config_dir=Path(__file__).parent / 'httpie',
        session_name='session',
        host='httpbin.org',
        url="https://httpbin.org/get"
    )
    assert httpie_session.session_name == 'session'

    request_kwargs = make_request_kwargs(
        args=args
    )
    assert request_kwargs['method'] == 'get'
    assert request_kwargs['url'] == 'https://httpbin.org/get'

# Generated at 2022-06-11 23:21:34.639848
# Unit test for function collect_messages
def test_collect_messages():
    if os.path.exists('https://www.baidu.com/'):
        os.remove('https://www.baidu.com/')
    print(collect_messages(args=None,config_dir=Path('https://www.baidu.com/')))

if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-11 23:21:44.867403
# Unit test for function build_requests_session
def test_build_requests_session():
    class FakePlugin:
        def __init__(self):
            self.prefix = 'prefix'

        def get_adapter(self):
            pass

    original_transport_plugins = plugin_manager._TRANSPORT_PLUGINS
    plugin_manager._TRANSPORT_PLUGINS = [FakePlugin]
    session = build_requests_session(verify=False, ssl_version='ssl_version', ciphers='ciphers')

    for prefix, adapter in session.adapters.items():
        assert prefix == 'prefix'
        assert type(adapter) == HTTPieHTTPSAdapter
    # Restore the original state
    plugin_manager._TRANSPORT_PLUGINS = original_transport_plugins



# Generated at 2022-06-11 23:21:48.188724
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.__dict__.update({"json": False, "form": False, "data": None})

    headers = make_default_headers(args)

    assert headers == {"User-Agent": "HTTPie/1.0.0"}

# Generated at 2022-06-11 23:21:51.484082
# Unit test for function max_headers
def test_max_headers():
    mh = \
    '''        print(f'\n>>> requests.request(**{repr_dict(kwargs)})\n\n')
    '''
    assert max_headers(50) == 50


# Generated at 2022-06-11 23:21:56.397951
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        form=False,
        files=None,
        headers=[],
        json=False,
    )
    expected_result = {'User-Agent': 'HTTPie/1.0.3'}
    headers = make_default_headers(args)
    assert(headers == expected_result)

# Generated at 2022-06-11 23:22:05.286435
# Unit test for function make_request_kwargs