

# Generated at 2022-06-11 23:12:31.958017
# Unit test for function collect_messages
def test_collect_messages():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()

    config_dir = Path()

    print(list(collect_messages(args, config_dir)))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    args = parser.parse_args()

    config_dir = Path()

    if args.test:
        test_collect_messages()

    list(collect_messages(args, config_dir))

# Generated at 2022-06-11 23:12:35.932099
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-11 23:12:48.262958
# Unit test for function collect_messages
def test_collect_messages():
    import os
    from os import path
    from pathlib import Path
    from httpie.compat import str
    from urllib.parse import urlparse, parse_qs
    from json import JSONDecodeError

    def decode_json(s):
        if not s:
            return None
        else:
            try:
                return json.loads(s)
            except JSONDecodeError:
                return None

    config_dir = Path(os.path.expanduser('~/.httpie'))

# Generated at 2022-06-11 23:12:59.591815
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 30
    args.allow_redirects = False
    args.proxies = {'http': 'http://proxy:8888', 'https': 'https://proxy:8888'}
    args.proxy = {'http': 'http://proxy:8888', 'https': 'https://proxy:8888'}
    args.stream = True
    args.verify = True
    args.cert = '/opt/app/app.crt'
    args.cert_key = '/opt/app/app.key'

    send_kwargs = make_send_kwargs(args)

# Generated at 2022-06-11 23:13:09.511781
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    # If sending files, `requests` will set
    # the `Content-Type` for us.
    args = argparse.Namespace()
    args.files = {'file': open('file.txt','rb')}
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] is None

    # If args.form and not files:
    args = argparse.Namespace()
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers['Content-Type'] == FORM_

# Generated at 2022-06-11 23:13:12.624714
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 10
    assert http.client._MAXHEADERS==10, "http_client._MAXHEADERS value is not updating correctly"


# Generated at 2022-06-11 23:13:23.931556
# Unit test for function collect_messages
def test_collect_messages():
    try:
        from httpie.cli import parser as parser
        from httpie.plugins.registry import plugin_manager
        plugin_manager.discover()
        args = parser.parse_args(['-v'])
        args.headers = finalize_headers(args.headers)
        messages = collect_messages(args=args,config_dir=Path())

        import sys
        import json
        print(json.dumps({'version': '1.0.0', 'type': 'send', 'payload': {'message': repr(messages)}}))
        sys.stdout.flush()
    except Exception as e:
        import traceback, sys
        # Print the stack trace
        traceback.print_exc()
        # Print the exception type
        print('Exception:', e)
        # Print the exception arguments
        print

# Generated at 2022-06-11 23:13:32.941852
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()

    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA}

    args.json = True
    assert make_default_headers(args) == {'Accept': JSON_ACCEPT, 'User-Agent': DEFAULT_UA}

    args.json = False
    args.form = True
    assert make_default_headers(args) == {'Content-Type': FORM_CONTENT_TYPE, 'User-Agent': DEFAULT_UA}

    args.json = True
    args.form = True
    assert make_default_headers(args) == {'Accept': JSON_ACCEPT, 'User-Agent': DEFAULT_UA}

# Generated at 2022-06-11 23:13:45.699618
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    parser = argparse.ArgumentParser()
    parser.add_argument("--follow-redirects", action="store_true", dest="follow")
    parser.add_argument("--max-redirects", type=int, default=5)
    parser.add_argument("--timeout", type=int)
    parser.add_argument("--verify", action="store_true", default="yes",
                        dest="verify")
    parser.add_argument("--cert", default=None)
    parser.add_argument("--cert-key", default=None)
    parser.add_argument('--proxy', action='append',
                        type=lambda x: ProxyArg(*x.split('://', 1)),
                        dest='proxy')
    args = parser.parse_args()
    data = make_send_kwargs_mergeable_from

# Generated at 2022-06-11 23:13:55.374512
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()

    # args.data = dict()
    # args.json = True
    # data = json.dumps(args.data)
    # kwargs = {
    #     'method': args.method,
    #     'url': args.url,
    #     'headers': headers,
    #     'data': prepare_request_body(
    #         body=data,
    #         body_read_callback=request_body_read_callback,
    #         chunked=args.chunked,
    #         offline=args.offline,
    #         content_length_header_value=headers.get('Content-Length'),
    #     ),
    #     'auth': args.auth,
    #     'params': args.params.items(),
    # }
    assert make

# Generated at 2022-06-11 23:14:16.747836
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_ = argparse.Namespace()
    args_.timeout = None
    assert make_send_kwargs(args_) == {
        'timeout': None,
        'allow_redirects': False,
    }
    args_.timeout = 2
    assert make_send_kwargs(args_) == {
        'timeout': 2,
        'allow_redirects': False,
    }

# Generated at 2022-06-11 23:14:17.829936
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(10)

# Generated at 2022-06-11 23:14:29.137283
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.offline = False
    args.session = None
    args.session_read_only = None
    args.config_dir = None
    args.method = "GET"
    args.url = "https://httpie.org"
    args.data = None
    args.files = []
    args.form = False
    args.params = []
    args.chunked = False
    args.json = False
    args.body = None
    args.headers = {}
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.output = None
    args.style = None
    args.stream = False
    args.compress = False
    args.max_redirects = 30
    args.max_headers = None

# Generated at 2022-06-11 23:14:31.576250
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(True, None, None)
    assert 'https' in requests_session.adapters
    assert 's3' not in requests_session.adapters

# Generated at 2022-06-11 23:14:36.997908
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # GIVEN
    class args:
        cert = False
        cert_key = False
        verify = 'true'
        proxy = (TestArgsWrapper(key='proxies', value='foo'),)

    # WHEN
    res = make_send_kwargs_mergeable_from_env(args)

    # THEN
    assert res == {'proxies': {'proxies': 'foo'}, 'stream': True, 'verify': True, 'cert': None}


# Generated at 2022-06-11 23:14:40.078941
# Unit test for function max_headers
def test_max_headers():
    with max_headers(50):
        assert http.client._MAXHEADERS == 50
    assert http.client._MAXHEADERS != 50

# Generated at 2022-06-11 23:14:50.712885
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test 1
    args = argparse.Namespace()
    args.proxy = argparse.Namespace()
    args.verify = False
    args.cert = None
    args.cert_key = None

    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env == {'proxies': {}, 'stream': True, 'verify': False, 'cert': None}, \
        "Testing make_send_kwargs_mergeable_from_env #1 failed"
    print("Testing make_send_kwargs_mergeable_from_env #1 passed")

    # Test 2
    args.proxies = argparse.Namespace()

# Generated at 2022-06-11 23:15:01.453539
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    sys.argv = [
        "http",
        "www.baidu.com",
        "-H",
        "Accept:application/json",
        "-v"
    ]
    args = argparse.Namespace()
    args.method = "get"
    args.url = "www.baidu.com"
    args.headers = {
        "Accept": "application/json"
    }
    args.auth = None
    args.data = None
    args.files = None
    args.form = False
    args.json = False
    kwargs = make_request_kwargs(args)
    dump_request(kwargs)

# Generated at 2022-06-11 23:15:12.375243
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'https://www.google.com'
    args.timeout = 30
    args.allow_redirects = False
    args.proxies = None
    args.stream = True
    args.verify = {
        'yes': True,
        'true': True,
        'no': False,
        'false': False,
    }
    args.cert = None
    args.auth = None
    args.params = None

    args.headers = finalize_headers(make_default_headers(args))
    args.headers.update('Accept-Encoding: gzip, deflate, br')
    args.headers.update('Accept-Language: en-US,en;q=0.9,es;q=0.8')

# Generated at 2022-06-11 23:15:14.751754
# Unit test for function max_headers
def test_max_headers():
    with max_headers(3):
        print(http.client._MAXHEADERS)
    print(http.client._MAXHEADERS)

# Generated at 2022-06-11 23:15:31.501505
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS==1000
    with max_headers(10):
        assert http.client._MAXHEADERS==10
    assert http.client._MAXHEADERS==1000
    with max_headers(None):
        assert http.client._MAXHEADERS==float('Inf')
    assert http.client._MAXHEADERS==1000

# Generated at 2022-06-11 23:15:40.768266
# Unit test for function collect_messages
def test_collect_messages():
    import unittest.mock
    import httpie.plugins.builtin

    args = unittest.mock.Mock()
    args.debug = False

    args.session = None
    args.session_read_only = None

    args.auth_plugin = None

    #args.headers = RequestHeadersDict()
    #args.headers['Host'] = '127.0.0.1'
    #args.headers['Accept'] = '*/*'
    args.headers = {'Host': '127.0.0.1', 'Accept': '*/*'}

    args.url = 'http://127.0.0.1/status'

    args.ssl_version = None
    args.ciphers = None
    args.proxy = {}

    args.timeout = None

    args.method = 'GET'

# Generated at 2022-06-11 23:15:50.412347
# Unit test for function max_headers
def test_max_headers():
    from test import http
    from collections import OrderedDict
    args = http.parse_args(['GET', '--debug', 'http://localhost:8080/x'])
    with max_headers(limit=None):
        requests.request(**args.__dict__)
    with max_headers(limit=100):
        requests.request(**args.__dict__)
    with max_headers(limit=100):
        headers = OrderedDict()
        for _ in range(100):
            headers[f'key{_}'] = str(_)

        args.__dict__['headers'] = headers
        requests.request(**args.__dict__)
    with max_headers(limit=100):
        headers = OrderedDict()
        for _ in range(101):
            headers[f'key{_}']

# Generated at 2022-06-11 23:16:00.369410
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class Args:
        cert = "c.crt"
        cert_key = "c.key"
        chunked = False
        data = [1, 2]
        files = []
        form = False
        json = False
        method = "GET"
        url = "http://localhost"
        headers = []
        params = {}
        auth = None
        verify = True
        offline = False
        multipart = False
        multipart_data = None
        boundary = ""

    test_args = Args()

    test_kwargs = make_request_kwargs(test_args, request_body_read_callback=None)
    assert test_kwargs['method'] == "get"
    assert test_kwargs['url'] == "http://localhost"
    assert test_kwargs['headers']['User-Agent']

# Generated at 2022-06-11 23:16:11.678810
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    """
    Test to make sure send_kwargs is properly modified
    """
    # Test 1
    args = argparse.Namespace()
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {'timeout': None, 'allow_redirects': False}

    # Test 2
    args = argparse.Namespace()
    args.timeout = 5
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {'timeout': 5, 'allow_redirects': False}

    # Test 3
    args = argparse.Namespace()
    args.timeout = None
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {'timeout': None, 'allow_redirects': False}


# Unit test

# Generated at 2022-06-11 23:16:21.527774
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    """
    Unit test for function make_send_kwargs_mergeable_from_env
    :return:
    """

    # Check basic properties
    args = argparse.Namespace(verify="yes", proxy=[], cert=None, cert_key=None)
    res = make_send_kwargs_mergeable_from_env(args)
    assert res['proxies'] == {} and res['verify']

    # Check proxy
    args = argparse.Namespace(verify="yes", proxy=[('http', 'http://foo:2342'), ('http', 'http://bar:2342')], cert=None, cert_key=None)
    res = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-11 23:16:31.299292
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    """
    Unit test for function make_request_kwargs
    """
    # pylint: disable=protected-access

# Generated at 2022-06-11 23:16:42.240571
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import unittest
    import httpie.cli.parser


# Generated at 2022-06-11 23:16:45.435594
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli.parser import parser

    args = parser.parse_args(['--verify', 'no'])
    verify = make_send_kwargs_mergeable_from_env(args)['verify']
    assert verify == False

# Generated at 2022-06-11 23:16:51.235955
# Unit test for function max_headers
def test_max_headers():
    import http.client
    max_headers = 100
    assert http.client._MAXHEADERS == max_headers
    with max_headers(50):
        assert http.client._MAXHEADERS == 50
        with max_headers(30):
            assert http.client._MAXHEADERS == 30
        assert http.client._MAXHEADERS == 50
    assert http.client._MAXHEADERS == max_headers

# Generated at 2022-06-11 23:17:25.502572
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace(
        data=[],
        files=[],
        form=False,
        headers=[],
        json=None,
        method='GET',
        multipart_data=[],
        params=[],
        timeout=None,
        url='http://localhost:5002/pdf2htmlEX/get_info',
    )
    config_dir = Path(r"C:\Users\pengs\.httpie")
    collect_messages(args, config_dir)



# Generated at 2022-06-11 23:17:26.488081
# Unit test for function collect_messages
def test_collect_messages():
    pass


# Generated at 2022-06-11 23:17:29.478980
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=True, ssl_version='TLSv1.0')
    assert isinstance(session, requests.Session)

# Unit tests for function make_default_headers

# Generated at 2022-06-11 23:17:34.926058
# Unit test for function make_default_headers
def test_make_default_headers():
    """
    Test for function make_default_headers
    """
    print("----------[test_make_default_headers]----------")
    args = argparse.Namespace()
    args.json = False
    args.data = False
    args.form = False
    args.files = False
    headers = make_default_headers(args)
    print("headers:", end=" ")
    print(headers)
    print("-------------------END----------------------")
    print("\r")



# Generated at 2022-06-11 23:17:43.817181
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}
    args = argparse.Namespace()
    args.timeout = 20
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'timeout': 20, 'allow_redirects': False}
    args = argparse.Namespace()
    args.timeout = 20
    args.allow_redirects = True
    assert make_send_kwargs(args) == {'timeout': 20, 'allow_redirects': True}


# Generated at 2022-06-11 23:17:53.458678
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=[], verify='yes', cert=None, cert_key=None)
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    args = argparse.Namespace(proxy=[], verify='no', cert=None, cert_key=None)
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {}, 'stream': True, 'verify': False, 'cert': None}
    args = argparse.Namespace(proxy=[], verify='false', cert=None, cert_key=None)

# Generated at 2022-06-11 23:17:54.830160
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    send_kwargs = make_send_kwargs(args)
    assert isinstance(send_kwargs, dict)

# Generated at 2022-06-11 23:17:58.775364
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = [{'timeout': '10','allow_redirects': False,'proxies':{}, 'stream': True, 'verify': True, 'cert': 'null'}]
    assert(make_send_kwargs(args) == {
        'timeout': '10',
        'allow_redirects': False,
    })

# Generated at 2022-06-11 23:18:10.415264
# Unit test for function make_default_headers

# Generated at 2022-06-11 23:18:20.403303
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class Args:
        def __init__(self, proxy, verify, cert, cert_key, timeout, chunked):
            self.proxy = proxy
            self.verify = verify
            self.cert = cert
            self.cert_key = cert_key
            self.timeout = timeout
            self.chunked = chunked


    proxy = [0, 1]
    verify = [True, False]
    cert = [True, False]
    cert_key = [True, False]
    timeout = [10, 15]
    chunked = [True, False]

# Generated at 2022-06-11 23:20:16.541679
# Unit test for function collect_messages

# Generated at 2022-06-11 23:20:23.782073
# Unit test for function make_default_headers
def test_make_default_headers():
    # Set arguments to be passed to make_default_headers
    args= argparse.Namespace()
    args.data = "sample_data"
    args.json = True
    args.form = True
    args.files = None
    default_headers = make_default_headers(args)

    assert len(default_headers) == 2
    if len(default_headers) == 2:
        assert "User-Agent" in default_headers
        assert "Accept" in default_headers
        assert default_headers['User-Agent'] == "HTTPie/1.0.3"
        assert default_headers['Accept'] == "application/json, */*;q=0.5"

# Generated at 2022-06-11 23:20:26.154522
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path(__file__).parent.parent
    for _ in collect_messages(args=args, config_dir=config_dir):
        pass



# Generated at 2022-06-11 23:20:29.937072
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie.cli.parser import parse_args

    args = parse_args(['httpie', '--version'])
    request_kwargs = make_request_kwargs(args)
    print(request_kwargs)

# Generated at 2022-06-11 23:20:36.616834
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import argparse
    args = argparse.Namespace()
    args.url = "http://www.baidu.com"
    args.method = "get"
    args.verify = "yes"
    args.cert = "1"
    args.cert_key = "2"
    args.proxy = []
    args.path_as_is = None
    args.headers = {}
    args.auth = None
    args.json = None
    args.form = None
    args.data = ""
    args.files = []
    args.params = []
    args.compress = None
    args.timeout = 10
    args.max_redirects = 10
    args.allow_redirects = None
    args.follow = None
    args.session = None
    args.session_read_only = None

# Generated at 2022-06-11 23:20:46.823946
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import random
    import datetime
    import io
    import itertools


# Generated at 2022-06-11 23:20:51.540223
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = build_args()
    kwargs = make_send_kwargs(args)
    assert set(kwargs.keys()) == {'timeout', 'allow_redirects'}
    assert kwargs['timeout'] is None
    assert not kwargs['allow_redirects']



# Generated at 2022-06-11 23:20:55.441690
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    original_result = {
        'timeout': 0.0,
        'allow_redirects': False}
    test_args = argparse.Namespace(timeout=0.0)
    assert(original_result == make_send_kwargs(test_args))



# Generated at 2022-06-11 23:21:04.118984
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from httpie.cli.argtypes import KeyValueArgType

    args = argparse.Namespace()
    args.url = 'http://www.google.com'
    args.auth = ('user','pass')
    args.data = None
    args.form = False
    args.compress = False
    args.path_as_is = False
    args.json = False
    args.method = 'GET'
    args.headers = KeyValueArgType([])
    args.params = KeyValueArgType([])
    args.proxy = KeyValueArgType([])
    args.debug = False
    args.timeout = None
    args.max_headers = None
    args.max_redirects = 30
    args.follow = False
    args.offline = False
    args.all = False
    args

# Generated at 2022-06-11 23:21:11.378838
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = {'proxy': [{'key': 'http', 'value': 'http://localhost:8123'}], 'verify': 'no', 'cert': 'client.crt'}
    result = make_send_kwargs_mergeable_from_env(args)
    assert result['proxies'] == {'http': 'http://localhost:8123'}
    assert result['verify'] == False
    assert result['cert'] == 'client.crt'
