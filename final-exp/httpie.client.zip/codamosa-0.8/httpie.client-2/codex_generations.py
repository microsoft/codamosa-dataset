

# Generated at 2022-06-11 23:12:38.092990
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_test_verify_yes = argparse.Namespace()
    args_test_verify_yes.verify = 'yes'
    args_test_verify_no = argparse.Namespace()
    args_test_verify_no.verify = 'no'
    print(make_send_kwargs_mergeable_from_env(args_test_verify_yes))
    print(make_send_kwargs_mergeable_from_env(args_test_verify_no))
    assert make_send_kwargs_mergeable_from_env(args_test_verify_yes)['verify'] is True
    assert make_send_kwargs_mergeable_from_env(args_test_verify_no)['verify'] is False

# Generated at 2022-06-11 23:12:43.352283
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [('http', 'foo.com')]
    args.verify = True
    assert make_send_kwargs_mergeable_from_env(args) == {
        'cert': None,
        'proxies': {'http': 'foo.com'},
        'verify': True,
    }

# Generated at 2022-06-11 23:12:48.861421
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = dict()
    result = make_default_headers(args)

    expected_result = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    assert result == expected_result


# Generated at 2022-06-11 23:12:59.035192
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Test when files and form args are present
    class Args(object):
        def __init__(self):
            self.files = 'test'
            self.form = True

    args = Args()
    assert(make_request_kwargs(args)['data'] == 'test')

    # Test when files and form args are absent
    class Args(object):
        def __init__(self):
            self.files = None
            self.form = None

    args = Args()
    assert(make_request_kwargs(args)['data'] == None)

if __name__ == '__main__':
    test_make_request_kwargs()

# Generated at 2022-06-11 23:13:06.447512
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        header=[],
        cert=None,
        cert_key=None,
        json=False,
        form=False,
        data=[],
        params=[],
        proxy=[],
        stream=True,
        timeout=30,
        verify=True
    )

    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 30
    assert kwargs['allow_redirects'] == False
    kwargs_mergeable = make_send_kwargs_mergeable_from_env(args)
    assert kwargs_mergeable['proxies'] == {}
    assert kwargs_mergeable['cert'] == None
    assert kwargs_mergeable['stream'] == True
    assert kwargs_merge

# Generated at 2022-06-11 23:13:18.416492
# Unit test for function collect_messages
def test_collect_messages(): 
    from subprocess import call
    import json
    import requests
    import logging
    from time import time, sleep
    try:
        pid = call(['ps','aux','|','grep','python','|','grep','-v','grep','|','awk','{print $2}'])
    except:
        pass
    pid = str(pid).strip('0')
    #print(pid)
    #print(pid is None)
    class dateTimeEncoder(json.JSONEncoder):
        def default(self, o):
            if isinstance(o, datetime):
                return o.isoformat()
            return json.JSONEncoder.default(self, o)

    class Logger(object):
        def __init__(self):
            self.terminal = sys.stdout

# Generated at 2022-06-11 23:13:24.938090
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args=argparse.Namespace()
    args.method='GET'
    args.url='https://httpbin.org/get'
    args.headers=RequestHeadersDict()
    args.headers['Content-Type']='application/json'
    req_kwargs=make_request_kwargs(args,None)
    print(req_kwargs)
    

if __name__=='__main__':
    test_make_request_kwargs()

# Generated at 2022-06-11 23:13:36.278712
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    # Since body isn't provided, it's assumed to be an auto-json request.
    args.data = {'foo': 'bar'}
    args.json = False
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE
    args.data = {'foo': 'bar'}
    args.json = True
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT

# Generated at 2022-06-11 23:13:49.044332
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.request_timeout = '5'
    args.method = 'GET'
    args.headers = {}
    args.auth = ''
    args.data = ''
    args.form = ''
    args.json = ''
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert 'Accept' not in default_headers
    assert 'Content-Type' not in default_headers

    args.json = 'a: b'
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert 'Content-Type' not in default_headers

    args.json = ''

# Generated at 2022-06-11 23:13:50.841454
# Unit test for function collect_messages
def test_collect_messages():
    # No Error
    return True

if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-11 23:14:13.389936
# Unit test for function collect_messages
def test_collect_messages():
    import requests
    for msg in collect_messages(args=None):
        if isinstance(msg, requests.PreparedRequest):
            print(msg.method)
            print(msg.headers)
            print(msg.url)
            print(msg.body)
        else:
            print(msg.headers)
            print(msg.url)
            print(msg.request.method)
            print(msg.request.headers)
            print(msg.request.body)
            print(msg.request.url)
            print(msg.text)
            pass
    pass



# Generated at 2022-06-11 23:14:17.656026
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli.parser import parser
    args = parser.parse_args(['--verify=yes'])
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True

# Generated at 2022-06-11 23:14:28.467968
# Unit test for function make_default_headers
def test_make_default_headers():
    import argparse
    args = argparse.Namespace()
    args.headers = {'foo': 'bar'}
    args.json = True
    
    #test adding default header with json
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE, 'foo': 'bar'}
    
    #test adding default header with form
    args.json = False
    args.form = True
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE, 'foo': 'bar'}


# Generated at 2022-06-11 23:14:36.468904
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:14:39.472971
# Unit test for function collect_messages
def test_collect_messages():
    collect_messages('args', '/config/dir', 'request_body_read_callback')


# Generated at 2022-06-11 23:14:49.754442
# Unit test for function make_send_kwargs

# Generated at 2022-06-11 23:14:57.886973
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=True,
        form=False,
        json=False,
        cert='',
        cert_key='',
        files=[],
        verify='',
        proxy=[],
        timeout=0,
        chunked=False,
        offline=False,
        max_redirects=0,
        max_headers=0,
        auth='',
        auth_plugin='',
    )

# Generated at 2022-06-11 23:15:02.008757
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-11 23:15:12.740057
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.accept = None
    args.auth = None
    args.auth_type = None
    args.auth_endpoint = None
    args.auth_plugin = None
    args.body = None
    args.body_regex = None
    args.body_regex_ignore_case = False
    args.chunked = False
    args.cli_style = 'fancy'
    args.colors = 'auto'
    args.compress = False
    args.compress_level = None
    args.config_dir = 'C:/Users/Yicheng/Documents/GitHub/httpie/httpie'
    args.download_dir = None
    args.download_output = None
    args.download_progress = False
    args.download_timeout = None
    args

# Generated at 2022-06-11 23:15:23.528498
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.files = False
    args.method = 'GET'
    args.url = 'https://httpie.org/'
    args.headers = {'Accept':'application/json'}
    args.data = None
    args.auth = None
    args.params = None
    args.timeout = 30
    args.allow_redirects = False
    args.proxies = None
    args.verify = True
    args.cert = None
    request_kwargs = make_request_kwargs(args)
    assert request_kwargs['method'] == 'GET'
    assert request_kwargs['url'] == 'https://httpie.org/'

# Generated at 2022-06-11 23:15:49.082934
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:15:53.416416
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout = 5,
    )
    kwargs = make_send_kwargs(args)
    assert(kwargs == {'timeout': 5, 'allow_redirects': False,})
    sys.stderr.write(str(kwargs))


# Generated at 2022-06-11 23:15:54.522469
# Unit test for function collect_messages
def test_collect_messages():
    return collect_messages()

# Generated at 2022-06-11 23:16:01.310874
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = {}

    args['method'] = 'GET'
    args['url'] = 'https://example.com'
    args['headers'] = {'Accept':'application/json','Content-Type':'application/json'}
    args['data'] = 'This is a query string'
    args['auth'] = ('admin','admin')
    args['params'] = [('param1','value1'),('param2','value2')]
    args['files'] = 'path/to/file.txt'

    res = make_request_kwargs(args)

    print(res)


# Generated at 2022-06-11 23:16:12.840890
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:16:15.331123
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.headers = []
    args.timeout = 10
    args.method = 'GET'
    args.url = 'http://localhost:8080/'

    list(collect_messages(args=args, config_dir=None))

# Generated at 2022-06-11 23:16:23.182015
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    test_args = argparse.Namespace(
        auth=('user', 'pass'),
        chunked=False,
        data='{"message": "hello"}',
        files=[],
        form=False,
        headers=RequestHeadersDict({'host': 'httpbin.org'}),
        json=False,
        method='POST',
        multipart_data=[],
        url='https://httpbin.org/post',
        verify='True',
        cert='/tmp/test.cert',
        cert_key='/tmp/test.key',
        offline=False,
    )


# Generated at 2022-06-11 23:16:29.485468
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    h1 = {'Content-Type': 'application/json'}
    h2 = {'Accept': 'application/json'}

    class Args:
        def __init__(self, method, headers, data, json, form, files,
                     auth, params, chunked, offline, **kwargs):
            self.method = method
            self.headers = headers
            self.data = data
            self.json = json
            self.form = form
            self.files = files
            self.auth = auth
            self.params = params
            self.chunked = chunked
            self.offline = offline
            self.kwargs = kwargs

        def __getitem__(self, item):
            if hasattr(self, item):
                return getattr(self, item)
            return self.kwargs[item]

# Generated at 2022-06-11 23:16:30.743250
# Unit test for function collect_messages
def test_collect_messages():
    import pytest
    assert '' == 'er'
    assert True

# Generated at 2022-06-11 23:16:41.667554
# Unit test for function collect_messages
def test_collect_messages():
    class _args:
        pass
    args_ = _args()
    args_.headers = {}
    args_.json = False
    args_.form = False
    args_.files = []
    args_.data = ""
    args_.auth_plugin = None
    args_.path_as_is = False
    args_.compress = 0
    args_.debug = False
    args_.offline = False
    args_.max_headers = None
    args_.max_redirects = None
    args_.follow = False
    args_.session = None
    args_.session_read_only = None
    args_.all = False
    args_.version = "None"
    args_.timeout = None
    args_.method = "None"
    args_.multi_thread = False
    args_.url = "None"
    args_.params = dict()
   

# Generated at 2022-06-11 23:17:07.170702
# Unit test for function make_default_headers
def test_make_default_headers():
    import argparse

    # --------------------------json------------------------
    test_args_json = argparse.Namespace()
    test_args_json.headers = {}

    # json True
    test_args_json.json = True
    test_args_json.data = {}
    test_args_json.form = False
    default_headers_json_1 = make_default_headers(test_args_json)
    default_headers_json_1_expect = {}
    default_headers_json_1 = {k.lower(): v.lower() for k, v in default_headers_json_1.items()}
    default_headers_json_1_expect = {k.lower(): v.lower() for k, v in default_headers_json_1_expect.items()}
    assert default_headers_json_1 == default

# Generated at 2022-06-11 23:17:18.069750
# Unit test for function collect_messages
def test_collect_messages():
    import json, requests
    args = argparse.Namespace()
    args.url = 'https://www.apple.com'
    args.method = 'GET'
    args.no = True 
    args.headers = {}
    args.json = False
    args.auth_plugin = False
    args.data = {}
    args.offline = False
    args.session = False
    args.session_read_only = False
    args.multipart = False
    args.form = False
    args.files = []
    args.data = {}
    args.timeout = None
    args.max_redirects = 5
    args.verify = True
    args.debug = False
    args.chunked = False
    args.compress = False
    args.proxy = []
    args.all = False
   

# Generated at 2022-06-11 23:17:27.355550
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data = None,
        form = None,
        json = True,
        files = None,
    )
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9', 'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'}
    args.json = False
    args.form = True
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9', 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}
    args.files = True
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9'}
    args

# Generated at 2022-06-11 23:17:35.935556
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:17:37.236048
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = make_request_kwargs()
    print(args)

# Generated at 2022-06-11 23:17:46.424379
# Unit test for function collect_messages
def test_collect_messages():
    import subprocess
    import sys
    # run httpie program
    response = subprocess.run(['http', 'www.baidu.com'], encoding='utf8', stdout=subprocess.PIPE)
    print(response.stdout)
    # set args
    args = subprocess.run(['http', '--debug', 'www.baidu.com'], encoding='utf8', stdout=subprocess.PIPE)
    parsed = httpie.cli.parser.parse_args(args=args)

# Generated at 2022-06-11 23:17:56.052529
# Unit test for function collect_messages
def test_collect_messages():
    class Namespace(object): pass
    args = Namespace()
    args.compress = 0
    args.auth = None
    args.auth_plugin = None
    args.chunked = False
    args.data = {}
    args.env = {}
    args.files = []
    args.form = False
    args.headers = {}
    args.json = None
    args.max_headers = 0
    args.multipart = False
    args.multipart_data = None
    args.params = {}
    args.session = None
    args.session_read_only = None
    args.timeout = 0
    args.url = ''
    args.verify = 'no'
    args.method = 'get'
    args.ssl_version = 'SSLv3'

# Generated at 2022-06-11 23:17:58.610149
# Unit test for function max_headers
def test_max_headers():
    from http.client import _MAXHEADERS

    with max_headers(10):
        assert _MAXHEADERS == 10
    assert _MAXHEADERS == 1000



# Generated at 2022-06-11 23:18:10.215411
# Unit test for function collect_messages

# Generated at 2022-06-11 23:18:14.593266
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.files = False
    args.data = None
    headers = make_default_headers(args)
    assert 'User-Agent' in headers
    assert headers['User-Agent'] == 'HTTPie/'+__version__

# Generated at 2022-06-11 23:18:58.861538
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    data = {'a':'b', 'b':'c'}

    args = argparse.Namespace()
    args.url = "http://www.google.com"
    args.cert = "csr.cert"
    args.cert_key = "csr.key"
    args.compress = 0
    args.data = data
    args.download = False
    args.form = False
    args.headers = {'a': 'b', 'b': 'c'}
    args.json = True
    args.max_redirects = 1
    args.method = 'GET'
    args.params = {'a': 'b', 'b': 'c'}
    args.verify = True
    args.timeout = 4
    args.auth = ('user', 'pass')

# Generated at 2022-06-11 23:19:08.070563
# Unit test for function collect_messages
def test_collect_messages():
    import unittest
    from httpie.cli.parser import parse_args
    import subprocess
    import os
    # testcase_1
    args = parse_args(['--json', 'GET', 'http://localhost:19999/api/user'])
    assert args.json == True
    assert args.method == 'GET'
    assert args.url == 'http://localhost:19999/api/user'
    # testcase_2
    args = parse_args(['--auth-type=basic', '--auth=test:123', 'GET', 'http://localhost:19999/api/user'])
    assert args.auth_type == 'basic'
    assert args.auth == 'test:123'
    assert args.method == 'GET'
    assert args.url == 'http://localhost:19999/api/user'

# Generated at 2022-06-11 23:19:18.732589
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Following is a unit test for the method make_request_kwargs in http.py
    import tempfile
    out_file = tempfile.NamedTemporaryFile(delete=False)
    out_file.close()

# Generated at 2022-06-11 23:19:28.859819
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from pathlib import Path
    from typing import Callable
    from httpie.cli.dicts import RequestHeadersDict

    args_ = argparse.Namespace
    config_dir_ = Path
    request_body_read_callback_ = Callable[[bytes], None]


# Generated at 2022-06-11 23:19:32.283031
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.files = None
    args.data = None
    headers = make_default_headers(args)
    assert headers['Content-Type'] == JSON_CONTENT_TYPE
    

# Generated at 2022-06-11 23:19:41.487364
# Unit test for function build_requests_session

# Generated at 2022-06-11 23:19:44.481922
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 1000
    with max_headers(50):
        assert http.client._MAXHEADERS == 50
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-11 23:19:54.528426
# Unit test for function collect_messages
def test_collect_messages():
    import pytest
    args = pytest.config.getoption("--args")
    config_dir = Path("/root/.config/httpie")
    request_body_read_callback = None
    messages = collect_messages(args, config_dir, request_body_read_callback)
    for message in messages:
        print(message.url + "\n")

    # def _get_args():
    #     return ['http', '--json', '--pretty', 'all', 'get', 'https://httpbin.org/status/418']
    #
    #
    # # Unit test for function collect_messages
    # def test_collect_messages():
    #     args = _get_args()
    #     config_dir = Path("/root/.config/httpie")
    #     request_body_read_callback

# Generated at 2022-06-11 23:19:59.490823
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    parser = argparse.ArgumentParser()
    # pass in test parameters
    args = parser.parse_args(['--verify', 'yes', '--cert', 'cert.pem'])
    kwargs = make_send_kwargs_mergeable_from_env(args)
    
    assert kwargs['verify'] == True
    assert kwargs['cert'] == 'cert.pem'

# Generated at 2022-06-11 23:20:10.052285
# Unit test for function max_headers
def test_max_headers():
    print("Testing max_headers case 0")
    assert http.client._MAXHEADERS == 1000
    with max_headers(500):
        assert http.client._MAXHEADERS == 500
    assert http.client._MAXHEADERS == 1000
    print("Successfully passed test max_headers case 0\n")

    print("Testing max_headers case 1")
    assert http.client._MAXHEADERS == 1000
    try:
        with max_headers(500):
            assert http.client._MAXHEADERS == 500
            raise AssertionError()
    except AssertionError:
        assert http.client._MAXHEADERS == 500
    assert http.client._MAXHEADERS == 1000
    print("Successfully passed test max_headers case 1\n")

    print("Testing max_headers case 2")
    assert http.client._MAXHEADERS == 1000


# Generated at 2022-06-11 23:21:27.688265
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        assert build_requests_session(verify=True, ssl_version=None, ciphers=None) is not None
        assert build_requests_session(verify=False, ssl_version=None, ciphers=None) is not None
        assert build_requests_session(verify=True, ssl_version=None, ciphers=False) is not None
        assert build_requests_session(verify=True, ssl_version=None, ciphers=None) is not None
        assert build_requests_session(verify=False, ssl_version=None, ciphers=False) is not None
    except AssertionError:
        print("Cant pass test_build_requests_session")

# Generated at 2022-06-11 23:21:33.758725
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import os
    import sys
    import pytest
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../tests/')))
    from http import client
    import requests.utils
    import requests
    import httpie.configuration
    import httpie.cli.parser
    import httpie.plugins
    import uuid

    parser = httpie.cli.parser.HTTPieArgumentParser()
    args = parser.parse_args([])
    args.url = 'http://' + str(uuid.uuid4())
    config = httpie.configuration.Configuration()
    args.config = config

    args.session = None
    args.session_read_only = None
    args.session_write_only = None

    args.auth_plugin

# Generated at 2022-06-11 23:21:37.946425
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None) as headers:
        assert http.client._MAXHEADERS == float('Inf')
    assert http.client._MAXHEADERS == 20
    with max_headers(123) as headers:
        assert http.client._MAXHEADERS == 123
    assert http.client._MAXHEADERS == 20

# Generated at 2022-06-11 23:21:43.155151
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=True, form=False)
    actual = make_default_headers(args)

    assert 'User-Agent' in actual
    assert actual['User-Agent'] == DEFAULT_UA
    assert actual['Accept'] == JSON_ACCEPT
    assert actual['Content-Type'] == JSON_CONTENT_TYPE

# Generated at 2022-06-11 23:21:51.229151
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import httpie.cli
    import sys
    import os
    from httpie.context import Environment
    from httpie.cli.parser import parse_items
    from httpie.downloads import Downloader
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import (
        STDOUT_ENCODING, get_response_stream, get_stream,
    )
    from httpie.plugins import plugin_manager
    from httpie.output.streams import get_response_stream
    from httpie.output.writers.streams import FileWriteAdapter
    from httpie.output.writers import (
        RawStreamWriter,
    )
    from httpie.compat import is_windows
    from httpie.core import main
    from httpie import ExitStatus

# Generated at 2022-06-11 23:22:01.853440
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--verify', action='store_true')
    parser.add_argument('--cert', action='store_true')
    parser.add_argument('--cert-key', action='store_true')
    parser.add_argument('--proxy', action='append')
    args = parser.parse_args(['--verify', 'yes', '--cert', '/tmp/cert.pem', '--cert-key', '/tmp/cert.key', '--proxy', 'http://127.0.0.1:80'])
    result = make_send_kwargs_mergeable_from_env(args)
    assert result['verify'] == True
    assert result['cert'] == ('/tmp/cert.pem', '/tmp/cert.key')