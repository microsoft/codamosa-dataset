

# Generated at 2022-06-11 23:12:30.556250
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 1
    args.allow_redirect = False

    r = make_send_kwargs(args)
    assert r == {'timeout': 1, 'allow_redirects': False}

# Generated at 2022-06-11 23:12:39.826282
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.files = [1,2]
    args.method = "GET"
    args.url = "http://www.baidu.com"
    args.headers = {"Test":"Test"}
    args.data = "test_data"
    args.json = True
    args.form = True
    args.multipart = [1,2]
    args.multipart_data = [1,2]
    args.boundary = "test"
    args.auth = "test"
    args.params = [1,2]
    args.chunked = True
    args.offline = True
    kwargs = make_request_kwargs(args)
    print(kwargs)

# Generated at 2022-06-11 23:12:51.111855
# Unit test for function collect_messages
def test_collect_messages():

    class Request(argparse.Namespace):
        def __init__(self):
            self.auth = None
            self.auth_plugin = None
            self.data = None
            self.form = True
            self.headers = None
            self.host = None
            self.method = 'POST'
            self.url = 'http://httpbin.org/post'

    req = Request()
    req.headers = ['-H' , 'X-Token: test']
    # print(req.data)
    args = req
    config_dir = 'C:\\Users\\Wallie\\PycharmProjects\\HTTPie-Master\\httpie\\tests\\data'
    messages = collect_messages(args,config_dir)
    for message in messages:
        print(message)

test_collect_messages()

# Generated at 2022-06-11 23:13:01.821057
# Unit test for function collect_messages
def test_collect_messages():
    class Test_argparse_Namespace:
        def __init__(self):
            self.headers = {}
            self.url = 'http://www.test.com'
            self.session = None
            self.session_read_only = None
            self.auth_plugin = None
            self.data = ''
            self.form = False
            self.files = None
            self.json = False
            self.debug = False
            self.path_as_is = False
            self.compress = False
            self.offline = False
            self.chunked = False
            self.ssl_version = None
            self.ciphers = None
            self.max_headers = None
            self.max_redirects = None
            self.follow = False
            self.all = False
            self.timeout = None


# Generated at 2022-06-11 23:13:07.786043
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers({'json':True}) == {'Content-Type': 'application/json', 'Accept': 'application/json, */*;q=0.5', 'User-Agent': 'HTTPie/1.0.3'}
    assert make_default_headers({'json':False}) == {'Accept': '*/*', 'User-Agent': 'HTTPie/1.0.3'}

# Generated at 2022-06-11 23:13:19.285940
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()

    # Check default headers
    args.json = False
    args.form = False
    args.data = {}
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9'}

    # Check json header
    args.json = True
    args.form = False
    args.data = {}
    assert make_default_headers(args) == {
        'User-Agent': 'HTTPie/0.9.9',
        'Content-Type': 'application/json; charset=utf-8',
        'Accept': 'application/json, */*;q=0.5',
    }
    args.data = {'a': 1, 'b': 2}

# Generated at 2022-06-11 23:13:27.058495
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    url_data_cert = ["localhost:8443", "data", "cert.pem"]
    namespace = argparse.Namespace


# Generated at 2022-06-11 23:13:39.078624
# Unit test for function collect_messages
def test_collect_messages():
    class args:
        url = 'http://example.com'
        method = 'POST'
        data = 'test'
        auth_plugin = None
        session = None
        debug = False
        follow = False
        offline = False
        chunked = False
        max_headers = None
        redirect = 'auto'
        max_redirects = None
        compress = True
        multipart = False
        multipart_data = None
        boundary = None
        files = None
        form = False
        json = False
        params = None
        headers = {'Content-Type': 'text/html'}
        path_as_is = False
        verify = True
        cert = None
        cert_key = None
        proxy = None
        timeout = None
        ssl_version = None
        ciphers = None
        all

# Generated at 2022-06-11 23:13:45.435964
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli.parser import parse_args
    args = parse_args(['/'])

    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env == {'cert': None, 'proxies': {}, 'stream': True, 'verify': True}

# Generated at 2022-06-11 23:13:55.182091
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    pars = argparse.Namespace()
    pars.method = 'opt'
    pars.url = 'http://xx.com'
    pars.auth = ('user', 'pass')
    pars.headers = None
    pars.data = {}
    pars.json = False
    pars.form = False
    pars.verbose = 1
    pars.verify = 'no'
    pars.proxy = []
    pars.timeout = 5
    pars.cert = 'www.baidu.com'
    pars.cert_key = 'abc'
    pars.output_file = 'dd'
    pars.compress = None
    pars.debug = True
    pars.max_redirects = 2
    pars.follow = True
    pars.all = True
    pars.stream = True

# Generated at 2022-06-11 23:14:34.853895
# Unit test for function collect_messages
def test_collect_messages():
    from argparse import Namespace
    from httpie.cli.streams import EchoStream
    from httpie.cli import output
    from httpie.context import Environment

    args = Namespace()

    args.method = 'GET'
    args.url = 'http://example.com'
    args.data = None
    args.form = False
    args.json = False
    args.headers = RequestHeadersDict()
    args.compress = 0
    args.path_as_is = False
    args.follow = False
    args.max_redirects = None
    args.max_headers = None
    args.timeout = None
    args.debug = False
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.session = None
    args.session_read

# Generated at 2022-06-11 23:14:38.895442
# Unit test for function collect_messages
def test_collect_messages():    # pragma: no cover
    sys.stderr.write("\ntest_collect_messages: TODO\n")

# Generated at 2022-06-11 23:14:43.101838
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        form=False,
        files=None,
        json=False,
        auth=None,
        auth_plugin=None,
        headers=RequestHeadersDict({}),
    )
    default_headers = make_default_headers(args)
    assert 'User-Agent' in default_headers


# Generated at 2022-06-11 23:14:55.339163
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import http.client
    import json
    import sys
    from contextlib import contextmanager
    from pathlib import Path
    from typing import Callable, Iterable, Union
    from urllib.parse import urlparse, urlunparse
    import requests
    # noinspection PyPackageRequirements
    import urllib3
    from httpie import __version__
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.ssl import AVAILABLE_SSL_VERSION_ARG_MAPPING, HTTPieHTTPSAdapter

# Generated at 2022-06-11 23:14:58.682040
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # default
    assert make_send_kwargs(argparse.Namespace(timeout=None,
                                               allow_redirects=False)) == {'timeout': None, 'allow_redirects': False}

    # no timeout
    assert make_send_kwargs(argparse.Namespace(timeout=0,
                                               allow_redirects=True)) == {'timeout': 0, 'allow_redirects': True}

# Generated at 2022-06-11 23:15:05.047410
# Unit test for function collect_messages
def test_collect_messages():
    parser = argparse.ArgumentParser()
    args = parser.parse_args(["-b", "key:value", "-H", "User-Agent: HTTPie/0.9.9"])
    print(args)
    config_dir = Path("/Users/yisheng/.config/httpie")
    for message in collect_messages(args, config_dir):
        print(message)

# Generated at 2022-06-11 23:15:07.776327
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 65536


# Generated at 2022-06-11 23:15:15.367497
# Unit test for function collect_messages
def test_collect_messages():
    class args:
        def __init__(self):
            class headers:
                def __init__(self):
                    self.header = {"Accept": "application/json"}
            self.headers = headers()
            self.url = "https://httpbin.org/get"
            self.method = "GET"
            self.session= None
            self.session_read_only= None
            self.path_as_is=False
            self.compress=False
            self.debug=False
            self.offline=False
            self.data= False
            self.form=False
            self.json= False
            self.params= False
            self.auth=False
            self.auth_plugin=None
            self.files=False
            self.multipart=None
            self.multipart_data=None
           

# Generated at 2022-06-11 23:15:18.826900
# Unit test for function max_headers
def test_max_headers():
    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = 10
    try:
        assert http.client._MAXHEADERS == 10
    finally:
        http.client._MAXHEADERS = orig


# Generated at 2022-06-11 23:15:26.222257
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.data = ''
    args.form = False
    args.json = False
    args.session_read_only = None
    args.cert = None
    args.cert_key = None
    args.proxy = ''
    args.max_redirects = 30
    args.verify = ''
    args.traceback = False
    args.headers = {'Content-type': 'text/html; charset=utf-8'}
    args.auth = requests.auth.HTTPBasicAuth('username', 'password')
    args.url = 'http://httpbin.org/ip'
    args.params = {}
    args.method = 'GET'
    args.timeout = 30
    args.max_headers = None
    args.follow = False
    args.session = None
   

# Generated at 2022-06-11 23:15:52.363022
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(2)

# Generated at 2022-06-11 23:16:01.520897
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.headers = {}
    args.timeout = 1000
    args.method = "GET"
    args.params = []
    args.url = "https://httpie.org"
    args.files = None
    args.verify = False
    args.json = None
    args.auth = None
    args.offline = False
    args.chunked = False
    args.multipart = False
    args.data = None
    args.form = None
    args.follow = False
    args.output = None
    args.all = False
    args.debug = False
    args.session = None
    args.session_read_only = None
    args.stream = False
    args.max_redirects = None
    args.max_headers = None

# Generated at 2022-06-11 23:16:13.290025
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = [
            '--verify', 'no',
            '--verify', 'false',
            '--verify', 'true',
            '--verify', 'yes',
            '--verify', 'whatever',
            '--verify', 'True',
            '--proxy', 'http=localhost',
            '--proxy', 'https=localhost',
            '--proxy', 'http=localhost:8000',
            '--proxy', 'https=localhost:8000',
            '--proxy', 'http=localhost',
            '--proxy', 'https=localhost',
            '--cert', './mycert.pem',
            '--cert', './mycert.pem',
            '--cert-key', './mycert.key'
            ]
    args = parser.parse_args(args=args)
    send_kw

# Generated at 2022-06-11 23:16:14.779975
# Unit test for function build_requests_session
def test_build_requests_session():
    # TODO: Fix this test
    session = build_requests_session(False)

    assert isinstance(session, requests.Session)

# Generated at 2022-06-11 23:16:20.471020
# Unit test for function make_default_headers
def test_make_default_headers():
	parser = argparse.ArgumentParser()
	args = parser.parse_args(["https://httpbin.org/get"])
	default_headers = make_default_headers(args)
	assert default_headers['Accept'] == 'application/json, */*;q=0.5'
	assert default_headers['Content-Type'] == 'application/json'
	assert default_headers['User-Agent'] == 'HTTPie/1.0.2'


# Generated at 2022-06-11 23:16:28.489360
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = 'test_cert'
    args.cert_key = 'test_cert_key'
    args.dummy = 'dummy'

    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('test_cert', 'test_cert_key')
    assert not kwargs['dummy']
    assert not kwargs['proxy']

# Generated at 2022-06-11 23:16:35.078832
# Unit test for function collect_messages
def test_collect_messages():
    import mock
    import httpie.cli.argtypes
    import httpie.plugins

    class DummyPlugin(httpie.plugins.AuthPlugin):
        auth_type = 'dummy'
        scheme = None
        auth_require = True

        def get_auth(self, username=None, password=None):
            auth_info = 'dummy'
            return auth_info, None

    httpie.cli.argtypes.AuthCredentials = DummyPlugin  # (class)
    httpie.plugins.auth_plugin_registry.add(DummyPlugin)

    args = mock.MagicMock()
    args.auth = ('test1', 'test2')
    args.auth_plugin = DummyPlugin()

    kwargs = make_request_kwargs(args)
    assert 'auth' in kwargs.keys()

# Generated at 2022-06-11 23:16:36.184899
# Unit test for function collect_messages
def test_collect_messages():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 23:16:40.247567
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] is None
    assert kwargs['allow_redirects'] is False


# Generated at 2022-06-11 23:16:47.071621
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    """
    Test integration of make_request_kwargs


    """

    # Normal case
    args = argparse.Namespace(
        auth=None,
        cert=None,
        cert_key=None,
        chunked=False,
        debug=False,
        files={},
        follow=False,
        form=False,
        headers={},
        json={},
        method="GET",
        multipart=False,
        multpart_data={},
        offline=False,
        params=[],
        path_as_is=False,
        proxy=[],
        request_body_read_callback=lambda chunk: chunk,
        session=None,
        session_read_only=None,
        timeout=None,
        url="http://www.google.com",
        verify=False,
    )

   

# Generated at 2022-06-11 23:17:44.433208
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    # Test for do not have --json
    args.json = False
    args.data = []
    args.form = False
    parsed_headers = make_default_headers(args)
    assert parsed_headers.items() == [('User-Agent', 'HTTPie/0.9.9')]
    # Test for do not have --form
    args.json = False
    args.data = []
    args.form = True
    parsed_headers = make_default_headers(args)
    assert parsed_headers.items() == [('User-Agent', 'HTTPie/0.9.9')]
    # Test for have --json and --form
    args.json = True
    args.data = True
    args.form = True
    parsed_headers = make_default_headers(args)

# Generated at 2022-06-11 23:17:51.642054
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    setattr(args, 'proxy', [])
    setattr(args, 'verify', 'True')
    setattr(args, 'cert', 'test_cert')
    setattr(args, 'cert_key', 'test_cert_key')
    kwargs = make_send_kwargs_mergeable_from_env(args)
    kwargs_expected = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': 'test_cert',
    }
    assert kwargs == kwargs_expected

# Generated at 2022-06-11 23:17:58.892915
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(), argparse.Namespace()]
    args.proxy[0].key = 'https'
    args.proxy[0].value = 'https'
    args.proxy[1].key = 'no'
    args.proxy[1].value = 'https'
    args.verify = 'no'
    args.cert = 'https'
    args.cert_key = 'https'

    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    proxies = send_kwargs_mergeable_from_env['proxies']
    verify = send_kwargs_mergeable_from_env['verify']
    cert = send_kwargs_mergeable_from_

# Generated at 2022-06-11 23:18:07.682489
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        method='get',
        url='http://baidu.com',
        headers=OrderedDict(),
        data='test data',
        json=False,
        form=False,
        files=False,
        auth=None,
        params=OrderedDict()
    )
    base_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    request_body_read_callback=lambda chunk: chunk
    make_request_kwargs(args, base_headers, request_body_read_callback)

# Generated at 2022-06-11 23:18:12.519719
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class args(object):
        def __init__(self):
            args.timeout = '10'
            args.allow_redirects = 'False'

    args = args()
    result = make_send_kwargs(args)

    assert result == {'timeout': 10, 'allow_redirects': False}


# Generated at 2022-06-11 23:18:16.298380
# Unit test for function max_headers
def test_max_headers():
    import http.client
    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = 99
    with max_headers(None):
        # Expect no exception
        assert http.client._MAXHEADERS == float('Inf')
    http.client._MAXHEADERS = orig

# Generated at 2022-06-11 23:18:19.528836
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 10
    assert http.client._MAXHEADERS == 10
    with max_headers(50):
        assert http.client._MAXHEADERS == 50
    assert http.client._MAXHEADERS == 10


# Generated at 2022-06-11 23:18:23.541955
# Unit test for function max_headers
def test_max_headers():
    args = argparse.Namespace()
    args.url = 'example.com'
    args.method = 'get'
    args.max_headers = 3
    with max_headers(args.max_headers):
        print(http.client._MAXHEADERS)
    print(http.client._MAXHEADERS)


# Generated at 2022-06-11 23:18:27.525515
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        ssl_version="TLS1.1", ciphers="ECDH+AESGCM", verify="yes"
    )

# Generated at 2022-06-11 23:18:37.571921
# Unit test for function make_default_headers
def test_make_default_headers():
    #test for form data (Content-Type is set to default)
    args = argparse.Namespace(files=None, form=True)
    default_headers = make_default_headers(args)
    assert default_headers.get('Content-Type') == FORM_CONTENT_TYPE

    #test for files
    args = argparse.Namespace(files="a file path", form=True)
    default_headers = make_default_headers(args)
    assert 'Content-Type' not in default_headers

    #test for json data
    data = dict(name="John", age=42)
    args = argparse.Namespace(json=True, data=data)
    default_headers = make_default_headers(args)
    assert default_headers.get('Content-Type') == JSON_CONTENT_TYPE
    assert default_headers

# Generated at 2022-06-11 23:19:45.587201
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = None
    args.form = None
    args.data = None
    args.output = None
    args.method = "get"
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] is None
    assert headers['Content-Type'] is None


# Generated at 2022-06-11 23:19:55.772798
# Unit test for function collect_messages

# Generated at 2022-06-11 23:20:05.369061
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    import http.client
    import json
    import sys
    from contextlib import contextmanager
    from pathlib import Path
    from typing import Callable, Iterable, Union
    from urllib.parse import urlparse, urlunparse

    import requests
    # noinspection PyPackageRequirements
    import urllib3
    from httpie import __version__
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import get_httpie_session
    from httpie.ssl import AVAILABLE_SSL_VERSION_ARG_MAPPING, HTTPieHTTPSAdapter

# Generated at 2022-06-11 23:20:16.100404
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(verify='yes', proxy=[], cert=None, cert_key=None)
    kwargs = {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    assert make_send_kwargs_mergeable_from_env(args) == kwargs

    args = argparse.Namespace(verify='true', proxy=[], cert=None, cert_key=None)
    kwargs = {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    assert make_send_kwargs_mergeable_from_env(args) == kwargs

    args = argparse.Namespace(verify='no', proxy=[], cert=None, cert_key=None)

# Generated at 2022-06-11 23:20:19.204110
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 0
    assert http.client._MAXHEADERS == 0
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    assert http.client._MAXHEADERS == 0

# Generated at 2022-06-11 23:20:21.635596
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(verify='TRUE', proxy='')
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs.get('verify')

# Generated at 2022-06-11 23:20:25.186162
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    default_headers = {}
    result = make_default_headers(args)
    assert type(result) == RequestHeadersDict
    for key in default_headers.keys():
        assert key in result.keys()
    for key in result.keys():
        assert key in default_headers.keys()


# Generated at 2022-06-11 23:20:29.497637
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path("../test/test_config")
    collect_messages(args=args, config_dir=config_dir)
    # print(dir(collect_messages))
    # assert(collect_messages.__defaults__)

# Generated at 2022-06-11 23:20:36.422996
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie import cli
    from httpie.compat import is_windows

    args = cli.parser.parse_args([
        '--verify=true',
        '--proxy=https://127.0.0.1:123',
    ])
    assert args.verify
    if not is_windows:
        assert args.proxy[0].value == 'socks5://127.0.0.1:123'
    else:
        assert args.proxy[0].value == 'https://127.0.0.1:123'

    kwargs = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-11 23:20:46.312494
# Unit test for function make_default_headers
def test_make_default_headers():
    argep = argparse.Namespace()
    argep.data = "foo"
    argep.json = False
    argep.form = False
    headers = make_default_headers(argep)
    assert headers["Accept"] == 'application/json, */*;q=0.5'
    assert headers["Content-Type"] == "application/json"
    argep = argparse.Namespace()
    argep.data = "foo"
    argep.json = False
    argep.form = True
    headers = make_default_headers(argep)
    assert "Accept" not in headers
    assert headers["Content-Type"] == "application/x-www-form-urlencoded; charset=utf-8"
