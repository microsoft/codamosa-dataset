

# Generated at 2022-06-11 23:12:37.845006
# Unit test for function make_request_kwargs

# Generated at 2022-06-11 23:12:46.050375
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({
        'Content-Length': '    ',
        'Content-Type': None,
        'Accept-Language': 'fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5',
    }) == {
        'Content-Length': '',
        'Accept-Language': 'fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5',
    }

# Generated at 2022-06-11 23:12:53.810781
# Unit test for function collect_messages
def test_collect_messages():
    class Namespace():
        def __init__(self, **kwargs):
            self.__dict__.update(**kwargs)
    class Opts():
        def __init__(self, **kwargs):
            self.__dict__.update(**kwargs)
    opts = Opts(auth_plugin=None, auth=None)

# Generated at 2022-06-11 23:13:03.680825
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'www.google.com'
    args.session = None
    args.session_read_only = None
    args.auth_plugin = None
    args.debug = False
    args.path_as_is = False
    args.compress = False
    args.offline = False
    args.chunked = False
    args.max_redirects = 30
    args.follow = True
    args.all = False
    args.data = None
    args.form = False
    args.json = False
    args.files = []
    args.multipart = False
    args.multipart_data = False
    args.timeout = None
    args.cert = None
    args.cert_

# Generated at 2022-06-11 23:13:04.512713
# Unit test for function collect_messages
def test_collect_messages():
    pass

# Generated at 2022-06-11 23:13:16.497589
# Unit test for function collect_messages
def test_collect_messages():
    class MethodAction(argparse.Action):
        def __call__(self, parser, args, values, option_string=None):
            if values is not None:
                if not values:
                    values = 'GET'
                setattr(args, self.dest, values.upper())
            else:
                setattr(args, self.dest, None)
    argparser = argparse.ArgumentParser()
    argparser.add_argument('--method', action=MethodAction, metavar='METHOD')
    argparser.add_argument('-L', '--location', action='store_true')
    argparser.add_argument('-o', '--output', metavar='FILE', dest='output_file')
    argparser.add_argument('-p', '--print', action='store_true')
    args = argparser.parse

# Generated at 2022-06-11 23:13:27.362526
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Test if the function return correct request arguments
    global args
    global send_kwargs

# Generated at 2022-06-11 23:13:38.054275
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout = None,
        proxy = None,
        verify = None,
        cert = None,
        cert_key = None,
    )
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env == {
        'proxies': {},
        'stream': True,
        'verify': None,
        'cert': None,
    }

# Generated at 2022-06-11 23:13:50.094028
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli import parser
    args = parser.parse_args(
        ['-h'],
        env={
             'no_proxy': 'example.com',
             'REQUESTS_CA_BUNDLE': '/etc/requests/cert.pem',
             'REQUESTS_PROXY': 'http://user:password@127.0.0.1:3128/',
             'REQUESTS_PROXIES': 'http://user:password@127.0.0.1:3128/',
             'REQUESTS_CERT': '/etc/requests/cert.pem',
             'REQUESTS_SSL_VERIFY': 'no',
        }
    )
    send_kwargs = make_send_kwargs_mergeable_from_env(args)
   

# Generated at 2022-06-11 23:13:51.523392
# Unit test for function collect_messages
def test_collect_messages():
    c = collect_messages([], {})
    assert isinstance(c, Iterable)

# Generated at 2022-06-11 23:14:19.299330
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 1000

if __name__ == '__main__':
    test_max_headers()

# Generated at 2022-06-11 23:14:24.403541
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli import parser
    from httpie.client import collect_messages
    args = parser.parse_args(['--json', '/'])
    for x in collect_messages(args, config_dir=None, request_body_read_callback=None):
        print(x)


# Generated at 2022-06-11 23:14:34.198089
# Unit test for function collect_messages
def test_collect_messages():
    print("test_collect_messages")

# Generated at 2022-06-11 23:14:42.288974
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    h = make_default_headers(args)
    assert h['User-Agent'] == 'HTTPie/'+__version__
    args.json = True
    h = make_default_headers(args)
    assert h['Accept'] == JSON_ACCEPT
    assert h['Content-Type'] == JSON_CONTENT_TYPE
    args.form = True
    args.json = False
    h = make_default_headers(args)
    assert h['Content-Type'] == FORM_CONTENT_TYPE

# Generated at 2022-06-11 23:14:44.820670
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-11 23:14:52.368468
# Unit test for function max_headers
def test_max_headers():

    with patch.dict.multiple(sys.modules,
                      {'http.client': MagicMock(),
                       'urllib3': MagicMock(),
                       'urllib3.disable_warnings': MagicMock()}
                      ):

        assert sys.modules['http.client']._MAXHEADERS == 200

        with max_headers(10):
            assert sys.modules['http.client']._MAXHEADERS == 10

        assert sys.modules['http.client']._MAXHEADERS == 200

# Generated at 2022-06-11 23:15:05.569743
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.headers = RequestHeadersDict({'User-Agent': 'HTTPie/0.9.8'})
    args.data = dict()
    args.data['foo'] = 'bar'
    args.method = 'post'
    args.url = 'https://httpbin.org/post'

# Generated at 2022-06-11 23:15:08.943177
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')
    orig = 200
    http.client._MAXHEADERS = orig
    assert http.client._MAXHEADERS == orig

# Generated at 2022-06-11 23:15:09.547107
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    pass

# Generated at 2022-06-11 23:15:16.277184
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Given
    data = [dict(a=1), dict(b=2)]
    dataDict = dict()
    dataDict['a'] = [1, dict(c=3)]
    dataDict['b'] = 2
    dataDict['c'] = 3

    # When

# Generated at 2022-06-11 23:15:55.323987
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = "https://www.github.com/orgs/httpie"
    config_dir = Path('httpie')
    result_object = collect_messages(
        args=args,
        config_dir=config_dir
    )
    assert(
        result_object.__next__().url == "https://www.github.com/orgs/httpie"
    )

# Generated at 2022-06-11 23:15:58.767806
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=False, form=False, data=False, files=False)
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA



# Generated at 2022-06-11 23:16:03.376158
# Unit test for function build_requests_session
def test_build_requests_session():
    print('\n'+f'build_requests_session test:')
    verify=False
    ssl_version=None
    ciphers=None
    requests_session=build_requests_session(verify,ssl_version,ciphers)
    print(f'requests_session: {requests_session}')


# Generated at 2022-06-11 23:16:15.472392
# Unit test for function collect_messages
def test_collect_messages():
    parser = argparse.ArgumentParser()
    parser.add_argument("--auth", help="HTTP Basic Auth Credentials")
    parser.add_argument("--body", help="Request body data to STDIN.")
    parser.add_argument("--body-on-error", help="Send request body on error.")
    parser.add_argument("--browse", help="Open a browser frame for this request.")
    parser.add_argument("--chunked", help="Transfer the body using chunked encoding.")
    parser.add_argument("--download", help="Stream response body to a file.")
    parser.add_argument("--follow", help="Follow redirects.")
    parser.add_argument("--form", help="Send the data as a form instead of JSON.")
    parser.add_argument("--headers", help="Headers to use in the request.")

# Generated at 2022-06-11 23:16:17.683781
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5, "Passed test parameter was not passed by function"

# Generated at 2022-06-11 23:16:24.895582
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.data = "data"
    args.form = False
    args.files=False
    headers = make_default_headers(args)
    headers_1={'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}
    assert headers == headers_1
    


# Generated at 2022-06-11 23:16:29.242691
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data = "",
        form = True,
        json = False,
        files = False,
    )
    assert make_default_headers(args) == {
        'User-Agent': DEFAULT_UA,
        'Content-Type': FORM_CONTENT_TYPE,
    }

# Generated at 2022-06-11 23:16:33.987710
# Unit test for function make_default_headers
def test_make_default_headers():
    tmpargs = argparse.Namespace(
        data = None, 
        files = None, 
        form = None, 
        json = None, 
        headers = None, )
    headers = make_default_headers(tmpargs)

    assert headers == {'User-Agent': DEFAULT_UA, 'Accept': 'application/json, */*;q=0.5'}



# Generated at 2022-06-11 23:16:44.349004
# Unit test for function collect_messages
def test_collect_messages():
    class Request:
        def __init__(self):
            self.request_dict = {
                'method': 'GET',
                'url': '/',
                'headers': {},
                'data': None,
            }

    orig_requests = {
        'method': 'GET',
        'url': '/',
        'headers': {
            'Chat-With-Ryan': 'Yes',
            'User-Agent': 'httpie/2.2.0',
            'Accept': 'application/json, */*;q=0.5'
        },
        'data': None
    }
    msgs = collect_messages(args=Request(), config_dir=None, request_body_read_callback=lambda chunk: chunk)
    msg = next(msgs)
    new_requests = msg.request_dict
   

# Generated at 2022-06-11 23:16:55.517309
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Load test data
    json_data = json.loads((Path(__file__).parent / 'data.json').read_text())
    # Load json data
    for test in json_data['test']:
        # print('Test: ', test['description'])
        # Parse test json data
        args = json.loads(json.dumps(test['args']))
        base_headers = args['headers']
        headers = make_default_headers(args)
        for key in base_headers:
            headers[key] = base_headers[key]
        #
        request_kwargs = make_request_kwargs(
            args=args,
            base_headers=headers,
            request_body_read_callback=None
        )
        expected_data = test['expected_params']
        # Verify result
        assert request

# Generated at 2022-06-11 23:18:09.616671
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None) as none:
        pass
    assert none is None
    with max_headers(2) as two:
        pass
    assert two is None
    with max_headers(3) as three:
        pass
    assert three is None
    with max_headers(4) as four:
        pass
    assert four is None
    with max_headers(5) as five:
        pass
    assert five is None
    with max_headers(6) as six:
        pass
    assert six is None

# Generated at 2022-06-11 23:18:19.750024
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    args.method = 'GET'
    args.url = 'https://httpbin.org/get'
    args.data = {'foo': 'bar'}
    args.json = True
    args.headers = {'X': 'x'}
    args.auth = ('user', 'pass')
    args.params = {'bar': 'baz'}
    args.timeout = 10
    args.verify = 'yes'
    request_kwargs = make_request_kwargs(args)
    assert request_kwargs['method'].lower() == 'get'
    assert request_kwargs['url'] == 'https://httpbin.org/get'

# Generated at 2022-06-11 23:18:27.458101
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.files = None

    args.method = 'GET'
    args.data = None
    assert make_default_headers(args) == {
        'User-Agent': DEFAULT_UA
    }

    args.data = 'foo'
    assert make_default_headers(args) == {
        'User-Agent': DEFAULT_UA
    }

    args.json = True
    assert make_default_headers(args) == {
        'User-Agent': DEFAULT_UA,
        'Content-Type': JSON_CONTENT_TYPE,
        'Accept': JSON_ACCEPT
    }

    args.json = False
    args.form = True

# Generated at 2022-06-11 23:18:37.523195
# Unit test for function make_default_headers
def test_make_default_headers():
    ns = argparse.Namespace()
    ns.json = None
    ns.form = None
    ns.data = None

    # Case 1 : Inputs are args.json = None, args.form = None, args.data = None.
    # Expected Output : {"User-Agent": "HTTPie/0.9.9"}
    assert make_default_headers(ns) == {"User-Agent": "HTTPie/0.9.9"}

    # Case 2 : Inputs are args.json = True, args.form = None, args.data = None.
    # Expected Output : {"Accept": "application/json, */*;q=0.5", "User-Agent": "HTTPie/0.9.9"}
    ns.json = True

# Generated at 2022-06-11 23:18:48.120129
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        verify="Yes",
        cert="/home/johndoe/my.pem",
        cert_key="/home/johndoe/my.key",
        proxy=["https://localhost:9000", "http://localhost:8000"]
    )
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {'https': 'https://localhost:9000', 'http': 'http://localhost:8000'}, 'cert': ['/home/johndoe/my.pem', '/home/johndoe/my.key'], 'verify': 'Yes', 'stream': True}
    args.verify = False

# Generated at 2022-06-11 23:18:59.216557
# Unit test for function collect_messages

# Generated at 2022-06-11 23:19:01.994067
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = None
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == None



# Generated at 2022-06-11 23:19:10.006475
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.method = 'GET'
    args.json = True
    headers = make_default_headers(args)
    assert headers['Content-Type'] == 'application/json; charset=utf-8'
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['User-Agent'] == DEFAULT_UA
    args.json = False
    args.data = {'foo': 'bar'}
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Content-Type'] == 'application/json; charset=utf-8'
    args.json = False
    args.data = {'foo': 'bar'}
    args.form = True
    headers = make

# Generated at 2022-06-11 23:19:20.857668
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = {"key": "value"}
    actual = make_default_headers(args)
    expected = {"Accept": "application/json, */*;q=0.5", "Content-Type": "application/json", "User-Agent":"HTTPie/1.0.3"}
    assert actual == expected
    args = argparse.Namespace()
    args.json = False
    args.form = True

# Generated at 2022-06-11 23:19:30.935568
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    a = argparse.Namespace()

# Generated at 2022-06-11 23:21:53.437473
# Unit test for function max_headers
def test_max_headers():
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        with max_headers(10):
            pass
        # Verify some things
        assert len(w) == 1
        assert issubclass(w[-1].category, UserWarning)
        assert "Replace max_headers" in str(w[-1].message)

# Generated at 2022-06-11 23:22:03.711672
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class args:
        def __init__(self, proxy = [], verify = '', cert = '', cert_key = ''):
            self.proxy = proxy
            self.verify = verify
            self.cert = cert
            self.cert_key = cert_key
    
    test_arg1 = args(proxy = [], verify = 'True', cert = '', cert_key = '')
    assert make_send_kwargs_mergeable_from_env(test_arg1) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }

    test_arg2 = args(proxy = [('key', 'value'), ('key2', 'value2')], verify = 'False', cert = '', cert_key = '')
    assert make_