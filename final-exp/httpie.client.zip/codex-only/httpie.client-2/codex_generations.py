

# Generated at 2022-06-23 18:47:57.033704
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict()
    headers['name'] = ' value '
    headers[' name2'] = 'value 2 '
    headers[b' name3'] = b'value 3 '
    headers[' name '] = b' value 4'

    final_headers = finalize_headers(headers)
    assert final_headers['name'] == 'value'
    assert final_headers['name2'] == 'value 2'
    assert final_headers['name3'] == 'value 3'
    assert final_headers['name'] == 'value 4'

# Generated at 2022-06-23 18:48:07.310774
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE,
    })
    args.json = False
    args.form = True
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Content-Type': FORM_CONTENT_TYPE,
    })



# Generated at 2022-06-23 18:48:08.365487
# Unit test for function dump_request
def test_dump_request():
   assert(1 == 1)

# Generated at 2022-06-23 18:48:17.465581
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    from argparse import Namespace
    # Test make_send_kwargs wihtout arguments
    args = Namespace(timeout=None, allow_redirects=False)
    test_make_send_kwargs = make_send_kwargs(args)
    assert test_make_send_kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }

    # Test make_send_kwargs with arguments
    args = Namespace(timeout='10', allow_redirects=True)
    test_make_send_kwargs = make_send_kwargs(args)
    assert test_make_send_kwargs == {
        'timeout': '10',
        'allow_redirects': True,
    }



# Generated at 2022-06-23 18:48:21.703792
# Unit test for function build_requests_session
def test_build_requests_session():
    k = build_requests_session(
        verify=False,
        ssl_version=None,
        ciphers=None,
    )
    print(k)



# Generated at 2022-06-23 18:48:27.663250
# Unit test for function dump_request
def test_dump_request():
    assert dump_request({'method': 'GET', 'url': 'http://www.google.com/', 'headers': {'User-Agent': 'HTTPie/0.9.7'}}) == '>>> requests.request(**{\'method\': \'GET\', \'url\': \'http://www.google.com/\', \'headers\': {\'User-Agent\': \'HTTPie/0.9.7\'}})\n\n'

# Generated at 2022-06-23 18:48:30.056380
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:48:39.418838
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.client import parse_items

    args = parser.parse_args()
    args.offline = False
    args.chunked = False
    args.method = 'GET'
    args.json = False
    args.form = False
    args.data = {}
    args.multipart = False
    args.compress = False
    args.debug = False
    args.json = False
    args.json = False
    args.follow = True
    args.output = ''
    args.all = False
    args.ssl_version = None
    args.ciphers = None
    args.compress = False
    args.verify = True
    args.headers = {}
    args.timeout = None
    args

# Generated at 2022-06-23 18:48:48.549541
# Unit test for function collect_messages
def test_collect_messages():
    import sys
    import argparse
    import json

    url = "http://localhost:5000"
    args = argparse.Namespace()
    args.data = json.dumps({'first' : 1})
    args.url = url
    args.method = "POST"
    args.json = False
    args.data = json.dumps({'first' : 1})
    args.form = False
    args.headers = []
    args.files = []
    args.auth = None
    args.auth_plugin = None
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.json = False
    args.pretty = 'all'
    args.style = 'monochrome'
    args.print_body_only_if_

# Generated at 2022-06-23 18:48:57.432017
# Unit test for function max_headers
def test_max_headers():
    import http
    """
    >>> test_max_headers()
    """

    class Connection:
        def __init__(self, headers):
            self.headers = headers
            self.header_received = False
            self.header = ""

        def send(self, header):
            if self.header_received:
                raise http.client.ResponseNotReady()
            else:
                self.header_received = True
                self.header = header

    class Response:
        def __init__(self, headers):
            self.msg = Message(headers)

    class Message:
        def __init__(self, headers):
            self._headers = headers

    class HTTPConnection:
        def __init__(self, headers):
            self.headers = headers
            self.header_received = []


# Generated at 2022-06-23 18:49:03.147837
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo/') == 'http://foo/'
    assert ensure_path_as_is('http://foo/../', 'http://foo') == 'http://foo'
    assert ensure_path_as_is('http://foo/../', 'http://foo:/') == 'http://foo:/'

# Generated at 2022-06-23 18:49:12.665707
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.plugins.builtin import HTTPBasicAuth

    parser = argparse.ArgumentParser()
    parser.add_argument("url", nargs='?', default='https://www.google.com')
    parser.add_argument("--verify", default="false")
    parser.add_argument("--proxy", action='append')
    parser.add_argument("--auth-type", default='basic')
    parser.add_argument("--auth", default='user:pass')
    parser.add_argument("-cert")
    parser.add_argument("-cert-key")
    args = parser.parse_args()

    auth_plugin = HTTPBasicAuth()
    args = auth_plugin.add_auth_options(parser).parse_args(args=args)

# Generated at 2022-06-23 18:49:16.482107
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

# Generated at 2022-06-23 18:49:28.260634
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.headers = {}
    args.method = 'GET'
    args.url = 'http://foo.com'
    args.data = None
    args.json = None
    args.form = None
    args.auth = None
    args.params = []
    args.timeout = None
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.proxy = ""

    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'get'
    assert kwargs['url'] == 'http://foo.com'
    assert not kwargs['data']
    assert kwargs['auth'] is None
    assert kwargs['params'] == []
    assert kwargs['timeout']

# Generated at 2022-06-23 18:49:37.732447
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    print("---> test_make_request_kwargs")
    args = argparse.Namespace()

    # Making default args
    args.method = 'GET'
    args.url = 'https://httpbin.org/get'
    args.json = False
    args.form = False
    args.data = None
    args.compress = False
    args.compress_level = 6
    args.chunked = False
    args.timeout = None
    args.max_redirects = 30
    args.follow = True
    args.auth = None
    args.auth_type = None
    args.auth_plugin = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.ssl_version = None
    args.ciphers = None

# Generated at 2022-06-23 18:49:39.378117
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(ssl_version='TLSv1.2', verify=False)
    session.get(url='www.baidu.com')

# Generated at 2022-06-23 18:49:44.385036
# Unit test for function make_default_headers
def test_make_default_headers():
    import httpie.cli.args
    parser = httpie.cli.args.create_parser()
    args = parser.parse_args(["GET", "-f", "http://google.com"])
    headers = make_default_headers(args)
    assert headers['User-Agent'] == 'HTTPie/1.0.3'

# Generated at 2022-06-23 18:49:51.302881
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = None
    args.cert = None
    args.cert_key = None
    args = make_send_kwargs_mergeable_from_env(args)
    assert(args == {'proxies': {}, 'stream': True, 'verify': None, 'cert': None})

# Generated at 2022-06-23 18:49:58.241391
# Unit test for function build_requests_session
def test_build_requests_session():
    from httpie.context import Environment
    from httpie.plugins import transport_plugins
    from httpie.ssl import AVAILABLE_SSL_VERSION_ARG_MAPPING
    from tests.mock_transport_plugin import MockTransportPlugin

    env = Environment()
    for plugin_cls in transport_plugins:
        plugin = plugin_cls()
        env.transport.update({plugin.prefix: plugin})

    transport = env.transport
    transport['mock_transport_plugin_prefix'] = MockTransportPlugin()

    session = build_requests_session(
        ssl_version=list(AVAILABLE_SSL_VERSION_ARG_MAPPING.keys())[0],
        verify=False,
        ciphers=None,
    )


# Generated at 2022-06-23 18:50:08.891028
# Unit test for function collect_messages
def test_collect_messages():
    '''
    This is a sample test case to test the collect_messages function
    This test case checks whether the function is returning a list
    '''
    class Namespace:
        pass
    args = Namespace()
    args.headers = {}
    args.url = 'https://docs.python.org/3/library/'
    args.method = 'GET'
    args.session = ''
    args.session_read_only = ''
    args.path_as_is = False
    args.compress = False
    args.json = False
    args.form = False
    args.files = []
    args.data = None
    args.auth = None
    args.params = {}
    args.timeout = 30
    args.session_read_only = ''
    args.max_headers = 20
    args.cert

# Generated at 2022-06-23 18:50:10.742021
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=None):
        pass
    # TODO: Verify the `limit` parameter is being used.
    pass

# Generated at 2022-06-23 18:50:14.071583
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    
    assert(ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')== 'http://foo/../?foo=bar')

    assert(ensure_path_as_is('http://foo/../', 'http://foo/../?foo=bar')== 'http://foo/../?foo=bar')

    print('function  test_ensure_path_as_is is  successful')

# Generated at 2022-06-23 18:50:24.791278
# Unit test for function collect_messages
def test_collect_messages():
    import os
    import shutil
    import tempfile

    import requests

    old_cwd = os.getcwd()
    config_dir = Path(old_cwd)

    requests_session = requests.Session()
    test = requests.Request(
        method='GET',
        url=f'test-dir',
        headers=RequestHeadersDict(),
        data=b'',
        auth=None,
        params=[('a', 'b')],
    )
    prepared_request = requests_session.prepare_request(test)
    test_response = requests.Response()
    test_body = 'test response'
    test_response._content = test_body.encode('utf-8')
    test_response.status_code = 200


# Generated at 2022-06-23 18:50:35.815125
# Unit test for function finalize_headers

# Generated at 2022-06-23 18:50:41.492044
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    from httpie.cli import parser

    args = parser.parse_args([
        '--auth-type', 'basic',
        '--auth', 'user:password',
        'GET', 'http://httpbin.org/get'
    ])

    send_kwargs = make_send_kwargs(args)
    print(send_kwargs)
    # assert send_kwargs['verify'] is True



# Generated at 2022-06-23 18:50:53.659579
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args1 = make_request_kwargs(args= argparse.Namespace(method= 'GET', url='https://google.com', timeout=None, allow_redirects=False, json=False, form=False, files=False, data=True, headers='Host: localhost:5000', offline=False, chunked=False, verify='yes', cert=False, ciphers=None, max_redirects=None, multipart=False, boundary=None, follow=False, max_headers=None, max_history=None, style='all', print_body=False, implied_end_headers=False))

# Generated at 2022-06-23 18:51:01.126799
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(
        'http://foo/../',
        'http://foo/?foo=bar'
    ) == 'http://foo/../?foo=bar'

    assert ensure_path_as_is(
        'http://foo/../bar',
        'http://foo/%2E%2E/bar?foo=bar'
    ) == 'http://foo/../bar?foo=bar'

    assert ensure_path_as_is(
        'http://foo/../bar',
        'http://foo/%2E%2E/bar/?foo=bar'
    ) == 'http://foo/../bar/?foo=bar'

# Generated at 2022-06-23 18:51:09.462628
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import logging
    import json
    import os
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(message)s')
    logging.debug('Start of program')

    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli import parser
    from httpie.config import DEFAULT_CONFIG_DIR
    from pathlib import Path
    from httpie import __version__
    SOURCE_DIR = Path(os.path.dirname(__file__)).resolve()
    config_dir = SOURCE_DIR / DEFAULT_CONFIG_DIR
    plugin_manager.load_installed_plugins(config_dir)


# Generated at 2022-06-23 18:51:10.230680
# Unit test for function build_requests_session
def test_build_requests_session():
    print(build_requests_session(True))

# Generated at 2022-06-23 18:51:13.231699
# Unit test for function finalize_headers
def test_finalize_headers():
    k = finalize_headers({'a': ' v', 'b': None, 'c': '   '})
    assert k == {'a': 'v', 'c': '   '}

# Generated at 2022-06-23 18:51:14.731418
# Unit test for function max_headers
def test_max_headers():
    max_headers(100)



# Generated at 2022-06-23 18:51:16.558257
# Unit test for function make_default_headers
def test_make_default_headers():
    default_headers = {
        'User-Agent': DEFAULT_UA
    }


# Generated at 2022-06-23 18:51:19.561513
# Unit test for function max_headers
def test_max_headers():
    with max_headers(4):
        assert http.client._MAXHEADERS == 4
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:51:31.628784
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=10,
        auth=('user', 'password'),
        cert=('/path/server.crt', '/path/key'),
        data=b'data',
        form=True,
        json=True,
        files=[('field', 'filename.txt')],
        proxy=[argparse.Namespace(key='key', value='value')],
        verify='/path/to/cacert.pem',
        chunked=True,
        offline=True,
        method='GET',
        url='https://httpbin.org/get',
        headers={'User-Agent': 'HTTPie'},
        params={'key': 'value'}
    )

# Generated at 2022-06-23 18:51:35.722271
# Unit test for function dump_request
def test_dump_request():
    class args:
        method = 'GET'
        url = 'https://www.google.com'
        headers = RequestHeadersDict()
        headers['User-Agent'] = 'HTTPie/0.9.9'
        auth = ('username','password')
        params = dict(foo='bar')

    kwargs = {
        'method': args.method.lower(),
        'url': args.url,
        'headers': args.headers,
        'data': "hello world",
        'auth': args.auth,
        'params': args.params.items(),
    }

    dump_request(kwargs)

# Generated at 2022-06-23 18:51:45.471132
# Unit test for function collect_messages
def test_collect_messages():
    # create dummy object for args
    class Dummy:
        def __init__(self):
            self.url = ''
            self.session_read_only = False
            self.session = ''
            self.headers = {}
            self.offline = False
            self.session = ''
            self.auth_plugin = ''
            self.debug = False
            self.path_as_is = False
            self.compress = False
            self.method = None
            self.json = False
            self.form = False
            self.files = None
            self.data = None
            self.multipart_data = None
            self.boundary = None
            self.timeout = None
            self.allow_redirects = False
            self.verify = None
            self.proxy = None

# Generated at 2022-06-23 18:51:52.889873
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': 'GET',
        'url': 'http://httpbin.org/',
        'headers': {
        'User-Agent': 'HTTPie/0.9.9'
        },
        'data': b'',
        'auth': None,
        'params': [('foo', 'bar')]
    }

    dump_request(kwargs)


# Generated at 2022-06-23 18:51:59.427212
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({}) == {}
    assert finalize_headers({'k': 'v'}) == {b'k': b'v'}
    assert finalize_headers({'k': ' v '}) == {b'k': b'v'}
    assert finalize_headers({'k': 123}) == {b'k': b'123'}
    
test_finalize_headers()

# Generated at 2022-06-23 18:52:03.192507
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({"Content-Type": "  application/json;charset=utf-8; q=0.8"})
    headers = finalize_headers(headers)
    assert headers == {"Content-Type": "application/json;charset=utf-8; q=0.8"}

# Generated at 2022-06-23 18:52:06.504952
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        json=False,
        form=False,
        data={},
        files=None
    )
    make_default_headers(args)



# Generated at 2022-06-23 18:52:09.043493
# Unit test for function build_requests_session
def test_build_requests_session():
    r = [i for i in build_requests_session(verify=True, ssl_version='TLS',ciphers='ALL')]
    return r

# Generated at 2022-06-23 18:52:18.078069
# Unit test for function make_default_headers

# Generated at 2022-06-23 18:52:19.635566
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert(make_send_kwargs_mergeable_from_env(args) == kwargs)

# Generated at 2022-06-23 18:52:21.411153
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import pytest
    pytest.main(["-vv", "--capture=sys", "httpie/utils.py"])

# Generated at 2022-06-23 18:52:28.045984
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')
    try:
        with max_headers(5):
            http.client._MAXHEADERS = 10
            assert http.client._MAXHEADERS == 10
    finally:
        http.client._MAXHEADERS = 100
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:52:31.401612
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session(True, 'TLSv1_2', 'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384')

# Generated at 2022-06-23 18:52:42.042697
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import unittest
    class TestMethods(unittest.TestCase):
        def test_make_send_kwargs_mergeable_from_env(self):
            args = argparse.Namespace()

            args.proxies = {
                "x": "y"
            }
            args.stream = True
            args.verify = False
            args.cert = "C:/Users/Certs/Certificate.pem"

            expected_kwargs = {
                'proxies': {'x': 'y'},
                'stream': True,
                'verify': False,
                'cert': 'C:/Users/Certs/Certificate.pem',
            }

            self.assertEqual(make_send_kwargs_mergeable_from_env(args), expected_kwargs)
    unitt

# Generated at 2022-06-23 18:52:46.057309
# Unit test for function dump_request
def test_dump_request():
    print(dump_request({
        'method': 'get',
        'url': 'http://httpbin.org',
        'data': 'sample data',
        'auth': ('username', 'password'),
        'params': {'key1': 'value1', 'key2': 'value2'},
    }))

# Generated at 2022-06-23 18:52:50.019382
# Unit test for function finalize_headers
def test_finalize_headers():
    test_dict = {
        'Content-Type': 'application/json'
    }
    test_obj = finalize_headers(test_dict)
    assert test_obj.get('Content-Type') == test_dict.get('Content-Type')

# Generated at 2022-06-23 18:52:53.569776
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False

# Generated at 2022-06-23 18:52:56.254181
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 60
    assert make_send_kwargs(args) == {'timeout':  60, 'allow_redirects': False}

# Generated at 2022-06-23 18:53:00.848500
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'method': 'GET', 'url': 'http://www.example.com/', 'headers': {'User-Agent': DEFAULT_UA}, 'data': '{"test":"test"}', 'auth': None, 'params': [('foo', 'bar')]}
    dump_request(kwargs)

test_dump_request()

# Generated at 2022-06-23 18:53:11.685764
# Unit test for function dump_request
def test_dump_request():
    print('\n>>> test_dump_request function')
    #Dump & logs
    print('>>> test_dump_request_logs')
    kwargs = {
        'method': "POST",
        'url': 'http://localhost:8080/bpt/api/login',
        'headers': {
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        'data': json.dumps({'username': 'admin', 'password': 'admin'}),
        'auth': None,
        'params': {'bpt-session-id': '9aec0f72-d935-4e7f-b308-a850a6c28a93'}.items()
    }
    dump_request(kwargs)
    print('\n')
    #

# Generated at 2022-06-23 18:53:15.879080
# Unit test for function dump_request
def test_dump_request():
	kwargs = {
		'method': 'get',
		'url': 'http://www.douyu.com',
		'headers': {
			'User-Agent': 'hahahha'
		}
	}
	assert ('\n>>> requests.request(**' in dump_request(kwargs))

# Generated at 2022-06-23 18:53:22.076706
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        cert=None,
        cert_key=None,
        verify='True',
        proxy=[],
        timeout=0,
        chunked=False,
        offline=True,
    )
    expected = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    assert make_send_kwargs_mergeable_from_env(args) == expected

# Generated at 2022-06-23 18:53:25.977254
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        ssl_version='TLSv1_2',
        ciphers='ECDHE-RSA-AES128-GCM-SHA256',
        verify='false'
    )
    assert requests_session is not None

# Generated at 2022-06-23 18:53:29.772813
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=True, form=False, data={'foo': 'bar'})
    expected_headers = {'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE, 'User-Agent': DEFAULT_UA}
    assert make_default_headers(args) == expected_headers

# Generated at 2022-06-23 18:53:30.383109
# Unit test for function collect_messages
def test_collect_messages():
    pass

# Generated at 2022-06-23 18:53:36.248967
# Unit test for function finalize_headers
def test_finalize_headers():
    myHeader = RequestHeadersDict()
    myHeader['BC'] = 'ID'
    myHeader['Authorization'] = 'abc123'
    myHeader['Date'] = 'Today'
    with pytest.raises(requests.exceptions.InvalidHeader):
        make_default_headers({})
        finalize_headers(myHeader)
    print(myHeader)

# Generated at 2022-06-23 18:53:44.716643
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    """
    Test function make_send_kwargs_mergeable_from_env
    :return:
    """
    p = argparse.ArgumentParser()
    p.add_argument('--verify', type=str, default='true')
    p.add_argument('--proxy', type=str, action='append', default=[])
    p.add_argument('--cert', type=str, default=None)
    p.add_argument('--cert-key', type=str, default=None)
    args = p.parse_args()
    assert(make_send_kwargs_mergeable_from_env(args) == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None})

    p = argparse.ArgumentParser()

# Generated at 2022-06-23 18:53:48.716349
# Unit test for function dump_request
def test_dump_request():
    sys.stderr.write(
        f'\n>>> requests.request(**{repr_dict({"url":"http://foo","method":"get"})})\n\n')

# Generated at 2022-06-23 18:53:55.364489
# Unit test for function dump_request
def test_dump_request():
    import pytest
    kwargs = dict(url='http://docs.python-requests.org', method='GET', auth=('user', 'pass'),
                  headers={'User-Agent': 'fake1.3.4'},
                  cookies={'foo': 'bar'}, params={'key': 'value'}, data='foo=bar')
    dump_request(kwargs)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:54:07.415709
# Unit test for function dump_request
def test_dump_request():
    sys.stderr.write("\n\n********** Testing dump_request **********\n\n")
    # Define arguments

# Generated at 2022-06-23 18:54:17.955873
# Unit test for function make_default_headers
def test_make_default_headers():
    import os
#    Base URL to be append to
    my_base_url="https://www.baidu.com"
#    Arg Parser
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("method", default="get", help="Request Method: GET/POST/PUT/DELETE/PATCH")
    parser.add_argument("url", default=my_base_url, help="URL to be send")
    parser.add_argument("--headers", help="HTTP Headers")
    parser.add_argument("--data", help="Data to be send")
    parser.add_argument("--json", help="json data to be send")
    parser.add_argument("--verify", help="SSL verify", default="true")

# Generated at 2022-06-23 18:54:25.553239
# Unit test for function make_default_headers
def test_make_default_headers():
    import pytest

    args = pytest.Namespace()
    args.json = False
    args.data = '{"some":"data"}'
    args.form = True
    args.files = True
    args.max_headers = 10

    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.3', 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}


# Generated at 2022-06-23 18:54:28.991359
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
  args = ['a', 'b', 'c', 'd', 'e', 'f']
  kwargs = make_send_kwargs(args)

  assert(kwargs['timeout'] == 'b')
  assert(kwargs['allow_redirects'] == False)


# Generated at 2022-06-23 18:54:37.406507
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    from httpie.input import KeyValueArgType
    from httpie.utils import CaseInsensitiveDict

    args = argparse.Namespace()
    args.files = None
    args.json = False
    args.form = True
    args.data = {"key": "value"}
    args.headers = CaseInsensitiveDict()
    args.headers["key1"] = "value1"
    args.headers["key2"] = "value2"
    args.method = "GET"
    args.url = "127.0.0.1"
    args.auth = None
    args.params = KeyValueArgType().__call__("key=value")
    kwargs = make_request_kwargs(args)
    print(kwargs)

# Generated at 2022-06-23 18:54:48.436647
# Unit test for function collect_messages
def test_collect_messages():
    import tempfile
    import shutil
    import os
    import json

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    temp_dir_path = Path(temp_dir)
    requests_session = build_requests_session(True, "TLSv1")

# Generated at 2022-06-23 18:55:00.614625
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True)
    session = build_requests_session(True, "TLSv1")
    session = build_requests_session(True, "TLSv1", "ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA256")

# Generated at 2022-06-23 18:55:06.599933
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli.parser import get_parser
    parser = get_parser()
    args = parser.parse_args(["--verify", "yes", "http://example.com/"])
    assert make_send_kwargs_mergeable_from_env(args)['verify']

    # non-string value false
    args = parser.parse_args(["--verify", "false", "http://example.com/"])
    assert not make_send_kwargs_mergeable_from_env(args)['verify']

    # string value false
    args = parser.parse_args(["--verify", "False", "http://example.com/"])
    assert not make_send_kwargs_mergeable_from_env(args)['verify']

# Generated at 2022-06-23 18:55:18.571480
# Unit test for function collect_messages

# Generated at 2022-06-23 18:55:21.500132
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
                            ssl_version='tlsv1.3',
                            ciphers=None,
                            verify=True
                        )

# Generated at 2022-06-23 18:55:32.532002
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='yes', proxy=[])) == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='asdf', proxy=[])) == {'proxies': {}, 'stream': True, 'verify': 'asdf', 'cert': None}
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='no', proxy=[])) == {'proxies': {}, 'stream': True, 'verify': False, 'cert': None}

# Generated at 2022-06-23 18:55:42.840952
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=True, ssl_version='TLSv1', ciphers="AES")
    assert isinstance(session, requests.Session)
    assert isinstance(session.adapters['https://']._ssl_context, ssl.SSLContext)
    assert session.adapters['https://']._ssl_context.verify_mode == ssl.CERT_REQUIRED
    assert session.adapters['https://']._ssl_context.protocol == ssl._TLS_VERSION_TO_PROTOCOL_NAME[ssl.PROTOCOL_TLSv1]
    assert session.adapters['https://']._ssl_context.options & ssl.OP_NO_SSLv2
    assert session.adapters['https://']._ssl_context.options & s

# Generated at 2022-06-23 18:55:47.001304
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'timeout': 10, 'allow_redirects': False}



# Generated at 2022-06-23 18:55:49.031483
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10) as m:
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:55:57.750154
# Unit test for function make_send_kwargs

# Generated at 2022-06-23 18:56:09.821753
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.ArgumentParser()
    args = type("Namespace", (), {
        "url": "http://localhost",
        "method": "GET",
        "auth": "test_auth",
        "timeout": "test_timeout",
        "allow_redirects": False,
    })()
    config_dir = Path("/test/dir")
    request_body_read_callback = print
    result = list(collect_messages(args, config_dir, request_body_read_callback))
    assert len(result) == 3
    assert result[0].method == "GET"
    assert result[0].url == "http://localhost"
    assert result[0].auth == "test_auth"
    assert result[0].timeout == "test_timeout"
    assert len(result) == 3

# Unit

# Generated at 2022-06-23 18:56:11.055445
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5

# Generated at 2022-06-23 18:56:18.300059
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://127.0.0.1'
    args.verbose = True
    request_kwargs = make_request_kwargs(args)
    dump_request(request_kwargs)
    assert request_kwargs == {'method': 'get', 'url': 'http://127.0.0.1', 'headers': RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'}), 'data': None, 'auth': None, 'params': []}


# Generated at 2022-06-23 18:56:23.047676
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 100
    with max_headers(1000):
        assert http.client._MAXHEADERS == 1000
    assert http.client._MAXHEADERS == 100
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')

# Generated at 2022-06-23 18:56:27.651174
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
    'method': 'GET',
    'url': 'http://127.0.0.1:5000/',
    'headers': {'User-Agent': 'HTTPie/1.0.3'}
    }
    dump_request(kwargs)

# Generated at 2022-06-23 18:56:28.855392
# Unit test for function dump_request
def test_dump_request():
    print(repr_dict({"test": "it is fine"}))

# Generated at 2022-06-23 18:56:41.070318
# Unit test for function dump_request

# Generated at 2022-06-23 18:56:51.987100
# Unit test for function max_headers
def test_max_headers():
    import string
    import http.client

    orig_max_headers = http.client._MAXHEADERS
    http.client._MAXHEADERS = 20

    # Test headers length less than MAXHEADERS
    try:
        http.client.HTTPMessage(string.ascii_letters)
    except:
        assert False, 'test_max_headers(): test 1 failed'

    http.client._MAXHEADERS = 0

    # Test headers length equal to MAXHEADERS
    try:
        http.client.HTTPMessage(string.ascii_letters[:20])
    except:
        assert False, 'test_max_headers(): test 2 failed'

    http.client._MAXHEADERS = 10

    # Test headers length larger than MAXHEADERS

# Generated at 2022-06-23 18:56:55.816871
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'User-Agent': 'HTTPie/1.0.2'}
    assert(finalize_headers(headers) == headers)


# Generated at 2022-06-23 18:57:05.345131
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Verify this function can merge verify option
    args = argparse.Namespace(verify='yes')
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == True
    args = argparse.Namespace(verify='no')
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify'] == False
    # Verify this function can merge proxy option
    args = argparse.Namespace(proxy=[argparse.Namespace(key='http', value='http://test:test@1.1.1.1:8080')])
    kwargs = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-23 18:57:08.865922
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = None
    args.form = False
    args.json = False
    default_headers = make_default_headers(args)
    print(default_headers)
    assert default_headers == {'User-Agent': 'HTTPie/0.10.1'}


if __name__ == '__main__':
    test_make_default_headers()

# Generated at 2022-06-23 18:57:10.346223
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10) as t:
        assert(t == None)


# Generated at 2022-06-23 18:57:19.521081
# Unit test for function collect_messages

# Generated at 2022-06-23 18:57:21.045041
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = finalize_headers({"aaa": " bbb ", "ccc": None})
    assert headers == {"aaa": "bbb"}


# Generated at 2022-06-23 18:57:25.477820
# Unit test for function collect_messages
def test_collect_messages():
  #Test for create_request_kwargs
  args = argparse.Namespace()
  # Test for when data is present and form is present
  args.data = {'foo':'bar'}
  args.form = True
  create_request_kwargs(args)
  assert headers == {'User-Agent': 'HTTPie/0.9.9', 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}
  assert data == {'foo':'bar'}

# Generated at 2022-06-23 18:57:28.624157
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(argparse.Namespace(timeout=5, follow=1, max_redirects=1)) == {'timeout': 5, 'allow_redirects': False}

# Generated at 2022-06-23 18:57:32.970532
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert (
        ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') ==
        'http://foo/../?foo=bar'
    )



# Generated at 2022-06-23 18:57:42.372901
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
    import argparse

    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://www.baidu.com'
    args.headers = ['Host: www.baidu.com', 'Accept: */*']
    args.auth = None
    args.params = None

    # test json type data
    args.json = True
    args.data = {'name': 'abc', 'age': 20}
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'GET'
    assert kwargs['url'] == 'http://www.baidu.com'

# Generated at 2022-06-23 18:57:49.473664
# Unit test for function build_requests_session
def test_build_requests_session():
    args = argparse.Namespace()
    args.ciphers = 'DHE-RSA-AES256-SHA'
    args.ssl_version = 'TLSv1'
    args.verify = 'true'
    s = build_requests_session(verify=bool(args.verify),
                               ssl_version=args.ssl_version,
                               ciphers=args.ciphers)
    print(s)

# Generated at 2022-06-23 18:57:58.839354
# Unit test for function collect_messages
def test_collect_messages():
    # TODO: refactor unit test to use main function
    from httpie import main as httpie_main
    from httpie.input import ParseError
    from httpie.plugins import plugin_manager
    from httpie.output import get_output_opts_and_class
    from httpie.cli.argtypes import KeyValueArg
    from pygments import highlight
    from pygments.formatters import TerminalFormatter
    from pygments.styles import get_style_by_name
    from pygments.lexers import get_lexer_for_mimetype
    from json import loads as json_loads
    from httpie import __version__
    from httpie.client import parse_auth
    # noinspection PyProtectedMember
