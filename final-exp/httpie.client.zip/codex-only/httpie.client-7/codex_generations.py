

# Generated at 2022-06-23 18:47:50.147209
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert 'http://foo/../' == ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')

# Generated at 2022-06-23 18:47:51.680331
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(limit=None).__enter__() == True
    print("max_headers func test passed")

# Generated at 2022-06-23 18:47:53.176107
# Unit test for function collect_messages
def test_collect_messages():
    return print("test_collect_messages")


# Generated at 2022-06-23 18:47:59.433276
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'auth': ('admin', '123'), 'cookies': {'sessionID': 'myid'}, 'data': 'username=admin&password=1234567', 'headers': {'Content-Type': 'application/x-www-form-urlencoded'}, 'method': 'post', 'params': {}, 'url': 'http://ec2-52-15-186-28.us-east-2.compute.amazonaws.com:8080/csrf'}
    dump_request(kwargs)

# Generated at 2022-06-23 18:48:05.280023
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo/') == 'http://foo/..'

# Generated at 2022-06-23 18:48:16.067531
# Unit test for function collect_messages
def test_collect_messages():
    import argparse


# Generated at 2022-06-23 18:48:28.102911
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    httpie_args = argparse.Namespace(cert=None,
                                     cert_key=None,
                                     proxy=[],
                                     verify='True')
    assert make_send_kwargs_mergeable_from_env(httpie_args) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    httpie_args = argparse.Namespace(cert='certificate',
                                     cert_key='certificate_key',
                                     proxy=[],
                                     verify='False')

# Generated at 2022-06-23 18:48:30.892177
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)


# Generated at 2022-06-23 18:48:40.155521
# Unit test for function dump_request
def test_dump_request():
    import unittest.mock as mock
    from unittest import TestCase

    class T(TestCase):
        def test_dump_request(self):
            with mock.patch('sys.stderr.write') as write:
                dump_request(dict(
                    method='foo',
                    url='bar',
                    headers='baz',
                    data='qux',
                    auth='quux',
                    params='corge',
                    json=None,
                    timeout=None,
                    verify='true',
                    cert=None,
                    allow_redirects=False,
                    proxies='grault',
                    stream=True,
                    files='garply',
                    param_sep='waldo',
                    body='fred'
                ))


# Generated at 2022-06-23 18:48:43.960882
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.data = {'foo': 'bar'}
    data = make_request_kwargs(args)
    assert data['data'] == '{"foo": "bar"}'

# Generated at 2022-06-23 18:48:54.482016
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [
        argparse.Namespace(key='http:', value='http://proxy'),
        argparse.Namespace(key='https:', value='http://proxy'),
    ]
    args.verify = True
    args.cert = '~/.cert.pem'
    args.cert_key = '~/.cert.key.pem'
    kwargs = make_send_kwargs_mergeable_from_env(args)

    assert kwargs == {
        'proxies': {
            'http:': 'http://proxy',
            'https:': 'http://proxy',
        },
        'stream': True,
        'verify': True,
        'cert': '~/.cert.pem',
    }
    assert make_send_

# Generated at 2022-06-23 18:48:58.456936
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    assert make_default_headers(args) == RequestHeadersDict({'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE})

# Generated at 2022-06-23 18:49:08.048324
# Unit test for function make_default_headers
def test_make_default_headers():
    default_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })

    args_1 = argparse.Namespace()

    def assign(attr, val):
        setattr(args_1, attr, val)

    assign('json', True)

    default_headers_1 = make_default_headers(args_1)
    assert default_headers_1 == default_headers.update({'Accept': JSON_ACCEPT})

    args_2 = argparse.Namespace()
    assign('json', False)
    assign('form', True)
    assign('files', True)

    default_headers_2 = make_default_headers(args_2)
    assert default_headers_2 == default_headers

# Generated at 2022-06-23 18:49:10.470203
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict()
    headers['content-type'] = 'text/plain'
    headers['content-type'] = None
    assert headers.get('content-type') == 'text/plain'

# Generated at 2022-06-23 18:49:22.680324
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=False, ssl_version='SSLv3', ciphers=None)
    assert requests_session is not None

if __name__ == '__main__':
    # setup the command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--ciphers', type=str)
    parser.add_argument('-v', '--verify', action='store_true')
    parser.add_argument('-P', '--ssl-version', type=str)
    args = parser.parse_args()

    requests_session = build_requests_session(
        verify=args.verify, ssl_version=args.ssl_version, ciphers=args.ciphers)
    assert requests_session is not None

# Generated at 2022-06-23 18:49:26.351218
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({"content-type": "text/html"})
    assert finalize_headers(headers) == RequestHeadersDict({"content-type": "text/html"})

# Generated at 2022-06-23 18:49:33.195907
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({"Content-Type": "    ","User-Agent":"    abc  "})
    final_headers = finalize_headers(headers)
    header_expectation = {'User-Agent':b'abc'}
    assert header_expectation==final_headers
    print('[test_finalize_headers] passed!')

if __name__ == '__main__':
    test_finalize_headers()

# Generated at 2022-06-23 18:49:45.293878
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.debug = False
    args.method = "post"
    args.headers = {"Authorization": "test"}
    args.url = "https://login.salesforce.com/services/oauth2/token"
    args.auth = ""
    args.auth_plugin = None
    args.timeout = 15
    args.follow = False
    args.session = False
    args.session_read_only = True
    args.max_redirects = 5
    args.max_headers = None
    args.compress = False
    args.compress_level = 9
    args.json = False
    args.data = "test_data"
    args.form = False
    args.files = False
    args.params = "test_params"

# Generated at 2022-06-23 18:49:58.012821
# Unit test for function dump_request
def test_dump_request():
    class args:
        def __init__(self):
            self.debug = True
            self.url = "http://127.0.0.1:5000/admin/1"
            self.headers = ["Content-Type: application/json","Cache-control: no-cache"]
            self.method = "GET"
            self.auth = "foo:bar"
            self.json = True
            self.follow = True
            self.timeout = "5.5"
            self.offline = True
            self.max_redirects = 3
            self.params = ["id=1"]
            self.verify = True
            self.proxies = []
            self.cert = None
            self.compress = True
            self.max_headers = 20
            self.compress_level = 6



# Generated at 2022-06-23 18:50:02.546864
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = False
    ssl_version = None
    ciphers = None

    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=verify
    )

    # TODO: Assert this...



# Generated at 2022-06-23 18:50:11.751214
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.verbose = False
    args.json = False
    args.form = False
    args.body = 'body'
    args.auth= ('user', 'pass')
    args.timeout = 5.0
    args.max_redirects = 2
    args.max_headers = 3
    args.chunked = False
    args.offline = False
    args.headers = {'Header1': 'value_1', 'Header2': 'value_2'}
    args.verify = True
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    # args.proxy = {'proxy1': 'value_1'}
    args.follow = False
    args.all = False
    args.debug = False
    args.path_

# Generated at 2022-06-23 18:50:15.256485
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': 'GET',
        'url': 'https://www.baidu.com',
        'headers': RequestHeadersDict({
            'User-Agent': DEFAULT_UA
        }),
        'data': 'abc',
        'auth': None,
        'params': [],
    }
    dump_request(kwargs)

# Generated at 2022-06-23 18:50:25.996312
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    f = lambda a: a

# Generated at 2022-06-23 18:50:30.690308
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Test parsing args without JSON, multipart or form
    args = make_request_kwargs({
        'method': 'POST',
        'url': 'http://example.com',
        'headers': {'User-Agent': 'CA'},
        'data': {'a': 1},
        'auth': 'foo',
        'params': {'b': '2'},
    })
    assert args == {
        'method': 'post',
        'url': 'http://example.com',
        'headers': {
            'User-Agent': 'CA',
        },
        'data': '{"a": 1}',
        'auth': 'foo',
        'params': [
            ('b', '2')
        ],
    }

    # Test parsing args with multipart data and content_type
    args = make_request

# Generated at 2022-06-23 18:50:36.958033
# Unit test for function max_headers
def test_max_headers():
    class MyVerboseHTTPConnection(http.client.HTTPConnection):
        def __init__(self, host, port=None, strict=None, timeout=0.0, limit=0):
            headers = {k: v for k, v in limit.items() if k != 'max_headers'}
            http.client.HTTPConnection.__init__(self, host, port, strict, timeout)
            self.set_max_headers(limit['max_headers'])
            for header, value in headers.items():
                self.putheader(header, value)

    def test_max_headers(headers, max_headers, expected_error):
        with pytest.raises(expected_error):
            conn = MyVerboseHTTPConnection('localhost', limit={'max_headers': max_headers, **headers})

# Generated at 2022-06-23 18:50:41.112577
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = "yes"
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert(kwargs['verify'] == True)
    assert(kwargs['proxies'] == {})

# Generated at 2022-06-23 18:50:43.814938
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    make_send_kwargs_mergeable_from_env(["", "", ["1", "2"]])

# Generated at 2022-06-23 18:50:55.750131
# Unit test for function finalize_headers
def test_finalize_headers():
    # print(finalize_headers(RequestHeadersDict({'accept-encoding': 'gzip'})))
    assert(finalize_headers(RequestHeadersDict({'accept-encoding': 'gzip'})) == RequestHeadersDict({'accept-encoding': b'gzip'}))
    assert(finalize_headers(RequestHeadersDict({'Accept-Encoding': 'gzip'})) == RequestHeadersDict({'accept-encoding': b'gzip'}))
    assert(finalize_headers(RequestHeadersDict({'Accept': 'gzip'})) == RequestHeadersDict({'accept': b'gzip'}))
    # print(finalize_headers(RequestHeadersDict({'accept-encoding': 'gzip', 'accept': 'gzip'})))
   

# Generated at 2022-06-23 18:51:04.736233
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    test_url = "http://foo/../index.html?x=y"
    prepped_url = ensure_path_as_is(test_url, "http://foo/index.html")
    assert prepped_url == test_url
    # Make sure that the prepped url is not modified when path-as-is is not passed
    test_url = "http://foo/index2.html?x=y"
    prepped_url = ensure_path_as_is(test_url, "http://foo/index.html")
    assert prepped_url == test_url

# Generated at 2022-06-23 18:51:10.051326
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=True)
    headers = make_default_headers(args)
    assert headers.get('Accept') == 'application/json, */*;q=0.5'
    assert headers.get('Content-Type') == 'application/json'


# Generated at 2022-06-23 18:51:22.443885
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    expected = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }
    assert make_send_kwargs_mergeable_from_env(args) == expected
    args.proxy = [argparse.Namespace(key='http://key.com', value='http://key.com')]
    args.verify = 'no'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    expected['proxies'] = {'http://key.com': 'http://key.com'}
    expected['verify'] = False


# Generated at 2022-06-23 18:51:27.388218
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 30
    args.allow_redirects = True
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 30
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-23 18:51:30.572424
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is("http://foo/../", "http://foo/?foo=bar") == "http://foo/../?foo=bar"

# Generated at 2022-06-23 18:51:31.630161
# Unit test for function dump_request
def test_dump_request():
    assert dump_request({'abc':12}) == None

# Generated at 2022-06-23 18:51:33.238192
# Unit test for function max_headers
def test_max_headers():
    with max_headers(2):
        assert http.client._MAXHEADERS == 2

# Generated at 2022-06-23 18:51:41.303810
# Unit test for function make_send_kwargs

# Generated at 2022-06-23 18:51:42.528377
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    assert make_request_kwargs(args) is not None

# Generated at 2022-06-23 18:51:53.193368
# Unit test for function collect_messages
def test_collect_messages():

    def test_collect_messages_unit(args, config_dir,request_body_read_callback):
        httpie_session = None
        httpie_session_headers = None
        if args.session or args.session_read_only:
            httpie_session = get_httpie_session(
                config_dir=config_dir,
                session_name=args.session or args.session_read_only,
                host=args.headers.get('Host'),
                url=args.url,
            )
            httpie_session_headers = httpie_session.headers

        request_kwargs = make_request_kwargs(
            args=args,
            base_headers=httpie_session_headers,
            request_body_read_callback=request_body_read_callback
        )
        send_kwargs = make

# Generated at 2022-06-23 18:52:01.042386
# Unit test for function finalize_headers
def test_finalize_headers():
    args = argparse.Namespace()
    args.headers = {'content-type': 'application/json'}

    default_headers = RequestHeadersDict({'User-Agent': DEFAULT_UA})
    final_headers = make_default_headers(args)
    final_headers.update(args.headers)
    final_headers = finalize_headers(final_headers)
    assert 'Content-Type' in final_headers
    assert 'Content-Type' == 'application/json; charset=utf-8'


# Generated at 2022-06-23 18:52:03.412555
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        print(http.client._MAXHEADERS)


# Generated at 2022-06-23 18:52:05.011051
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(True) is not None


# Generated at 2022-06-23 18:52:14.350880
# Unit test for function collect_messages
def test_collect_messages():
    class MyNamespace:
        def __init__(self, url, headers, method, auth, data, params, json, form, files, cert, cert_key,
                     proxy, verify, timeout, chunked, offline, session,
                     session_read_only, debug, compress, chunk_size, follow, all, max_redirects,
                     max_headers, boundary, multipart_data, ssl_version, ciphers):
            self.url = url
            self.headers = headers
            self.method = method
            self.auth = auth
            self.data = data
            self.params = params
            self.json = json
            self.form = form
            self.files = files
            self.cert = cert
            self.cert_key = cert_key
            self.proxy = proxy
            self.verify = verify


# Generated at 2022-06-23 18:52:19.142573
# Unit test for function make_send_kwargs
def test_make_send_kwargs():

    args = argparse.Namespace(timeout=1000)

    final_kwargs = {
        'timeout': args.timeout or None,
        'allow_redirects': False
    }
    assert make_send_kwargs(args) == final_kwargs



# Generated at 2022-06-23 18:52:20.934712
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(True, None, None)
    assert type(requests_session) is requests.Session

# Generated at 2022-06-23 18:52:25.523731
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {"Accept-Encoding": None, "Host": "google.com",
               "User-Agent": "curl/7.53.0"}
    temp = []
    for k, v in headers.items():
        temp.append((k, v.strip()))
    headers = temp
    return headers

# Generated at 2022-06-23 18:52:37.159456
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://127.0.0.1:5000/get'
    args.headers = []
    args.data = None
    args.json = None
    args.form = False
    args.files = {}
    args.multipart = False
    args.multipart_data = None
    args.boundary = None
    args.auth = None
    args.params = {}
    args.timeout = 30
    args.allow_redirects = True
    args.verify = False
    args.cert = None
    args.cert_key = None


# Generated at 2022-06-23 18:52:39.255783
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
        # noinspection PyProtectedMember
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:52:44.619139
# Unit test for function make_default_headers
def test_make_default_headers():
    """
    :return: True if make_default_headers return DEFAULT_UA as User-Agent header by default.
    """
    def fixture(self):
        args = argparse.Namespace()
        default_headers = make_default_headers(args=args)
        assert default_headers['User-Agent'] == DEFAULT_UA

    fixture(None)
    return True

# Generated at 2022-06-23 18:52:55.541749
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    argparse_namespace = argparse.Namespace()
    argparse_namespace.verify = True
    argparse_namespace.cert = './cert.pem'
    argparse_namespace.cert_key = './key.pem'
    argparse_namespace.proxy = [argparse.Namespace(key='http', value='http://foo.com'), argparse.Namespace(key='http', value='foo.com')]

    result = make_send_kwargs_mergeable_from_env(argparse_namespace)

# Generated at 2022-06-23 18:53:02.177714
# Unit test for function collect_messages
def test_collect_messages():
    import pytest
    import utils
    # set valid url
    args1 = utils.create_args(url="https://www.google.com")
    # set invalid url
    args2 = utils.create_args(url="3001")
    assert collect_messages(args1, Path())
    
    # invalid requests
    with pytest.raises(Exception):
        collect_messages(args2, Path())

# Generated at 2022-06-23 18:53:11.430504
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    proxy_input={
        'http':'http://127.0.0.1',
        'https':'https://127.0.0.1',
        'ftp':'ftp://127.0.0.1',
        'socks4':'socks4://127.0.0.1',
        'socks4a':'socks4a://127.0.0.1',
        'socks5':'socks5://127.0.0.1',
        'socks5h':'socks5h://127.0.0.1',
    }
    cert='cert'
    cert_key='cert_key'
    verify='true'
    args=argparse.Namespace(proxy=proxy_input, cert=cert, cert_key=cert_key, verify=verify)
   

# Generated at 2022-06-23 18:53:13.512056
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(argparse.Namespace()) == {'User-Agent': DEFAULT_UA}


# Generated at 2022-06-23 18:53:21.065389
# Unit test for function collect_messages
def test_collect_messages():
    class Args:
        def __init__(self):
            self.url = None
            self.headers = {}
            self.method = 'get'
            self.timeout = 100
            self.auth = None
            self.verify = None
            self.params = {}
            self.data = None
            self.form = False
            self.json = False
            self.files = None
            self.compress = False
            self.compress_level = None
            self.chunked = False
            self.follow = False
            self.max_redirects = None
            self.max_headers = None
            self.offline = False
            self.multipart = False
            self.debug = False
            self.ssl_version = None
            self.ciphers = None
            self.boundary = None


# Generated at 2022-06-23 18:53:30.744976
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests

    # Test with HTTPs adapter
    assert build_requests_session(True, None).adapters['https://'] == HTTPieHTTPSAdapter
    assert build_requests_session(False, None).adapters['https://'] == HTTPieHTTPSAdapter
    assert build_requests_session(True, None).adapters['https://'].verify
    assert not build_requests_session(False, None).adapters['https://'].verify
    
    # Test with HTTPs adapter from plugins
    from httpie.plugins import TransportPlugin
    from httpie.plugins.builtin import HTTP
    from httpie.upload import UploadFile

# Generated at 2022-06-23 18:53:33.611512
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(True,None,None)
    assert isinstance(requests_session,requests.Session)

# Generated at 2022-06-23 18:53:43.131787
# Unit test for function make_default_headers
def test_make_default_headers():
    new_default_headers = make_default_headers({
        "headers": {},
        "json": False,
        "form": False,
        "data": None,
    })
    assert new_default_headers.get('User-Agent') == DEFAULT_UA
    assert 'Accept' not in new_default_headers
    assert 'Content-Type' not in new_default_headers
    new_default_headers = make_default_headers({
        "headers": {},
        "json": False,
        "form": True,
        "data": None,
    })
    assert new_default_headers.get('User-Agent') == DEFAULT_UA
    assert 'Accept' not in new_default_headers
    assert new_default_headers.get('Content-Type') == \
        FORM_CONTENT_TYPE
    new_

# Generated at 2022-06-23 18:53:46.907933
# Unit test for function max_headers
def test_max_headers():
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:53:51.065436
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
  import sys
  import os
  import json
  import requests
  class DummyClass():
    def __init__(self, url, **kwargs):
        self.url = url
        self.kwargs = kwargs

  class Args():
    def __init__(self, **kwargs):
      self.__dict__.update(kwargs)


# Generated at 2022-06-23 18:53:56.956456
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=[], cert=None, cert_key=None, verify=False)
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == False
    assert kwargs['cert'] == None

# Generated at 2022-06-23 18:54:05.517361
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert 'http://foo/../?foo=bar'==ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')
    assert 'http://foo/../?foo=bar'==ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')
    assert 'https://foo/../?foo=bar'==ensure_path_as_is('https://foo/../', 'https://foo/?foo=bar')
    assert 'http://foo/../?foo=bar'==ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')

# Generated at 2022-06-23 18:54:16.964189
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import os
    import requests
    import httpie.cli.argtypes as argtypes
    args = argparse.Namespace(
        cert='mycert.pem',
        cert_key="mycert.key",
        verify="false",
        proxy=[
            argtypes.KeyValueArgType('http://myproxy'),
        ],
    )

    expected_kwargs = {
        'proxies':{
            'http': 'http://myproxy',
        },
        'verify':False,
        'cert':(
            os.path.join(os.getcwd(), 'mycert.pem'),
            os.path.join(os.getcwd(), 'mycert.key')
        )
    }
    kwargs = make_send_kwargs_mergeable_from_env(args)
    session

# Generated at 2022-06-23 18:54:27.678397
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    def _test(orig_url, prepped_url, expected_url):
        actual_url = ensure_path_as_is(orig_url, prepped_url)
        assert actual_url == expected_url

    with_auth = 'https://user:pass@httpbin.org'
    _test(
        orig_url=with_auth + '/up/down',
        prepped_url=with_auth + '/foo/bar?foo=bar',
        expected_url=with_auth + '/up/down?foo=bar',
    )

# Generated at 2022-06-23 18:54:31.333361
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        cert = '',
        cert_key = '',
        proxy = [],
        verify = 'true'
    )
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert(kwargs['verify'] == True)

# Generated at 2022-06-23 18:54:37.220143
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Create args and set default attributes
    args = argparse.Namespace()
    args.timeout = 0.5
    args.allow_redirects = True

    # Get the correct dictionary
    correct_dict = {
        'timeout': args.timeout,
        'allow_redirects': args.allow_redirects
    }
    # Get the dictionary created by the function
    function_dict = make_send_kwargs(args)

    # Assert both dictionaries are equal
    assert function_dict == correct_dict

# Generated at 2022-06-23 18:54:48.324096
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    assert make_default_headers(args) == RequestHeadersDict({'User-Agent': DEFAULT_UA})

    args.files = True
    assert make_default_headers(args) == RequestHeadersDict({'User-Agent': DEFAULT_UA})

    args.files = False
    args.json = True
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
    })

    args.json = False
    args.data = {'a': 'b'}

# Generated at 2022-06-23 18:54:54.596619
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({
        'Foo': 'bar',
        'baz': ' baz ',
        'Content-Length': None,
        'content-type': 'text/plain',
    }) == {
        'Foo': b'bar',
        'baz': b'baz',
        'content-type': b'text/plain',
    }

# Generated at 2022-06-23 18:55:06.763076
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:55:18.667888
# Unit test for function finalize_headers
def test_finalize_headers():
    # Testcase 1
    headers = {
        ' content-length  ': '100000',
        'User-Agent': f'HTTPie/{__version__}',
    }
    final_headers = finalize_headers(headers)
    assert final_headers == headers

    # Testcase 2
    headers = {
        ' content-length  ': '100000',
        'User-Agent': f'HTTPie/{__version__}',
        'content-type': 'application/json',
    }
    final_headers = finalize_headers(headers)
    assert final_headers == {
        'content-length': b'100000',
        'User-Agent': f'HTTPie/{__version__}',
        'content-type': 'application/json',
    }

    # Testcase 3

# Generated at 2022-06-23 18:55:29.474625
# Unit test for function make_default_headers
def test_make_default_headers():
    expected1 = {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}
    expected2 = {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}
    expected3 = {'User-Agent': DEFAULT_UA}

    args1 = argparse.Namespace()
    args1.json = True
    args2 = argparse.Namespace()
    args2.form = True
    args3 = argparse.Namespace()

    test1 = make_default_headers(args1)
    test2 = make_default_headers(args2)
    test3 = make_default_headers(args3)

    assert test1 == expected1
    assert test2 == expected2
    assert test3 == expected3

# Generated at 2022-06-23 18:55:35.970497
# Unit test for function max_headers
def test_max_headers():
    # <https://github.com/httpie/httpie/issues/802>
    # noinspection PyUnresolvedReferences
    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = None

    try:
        assert http.client._MAXHEADERS is None
    finally:
        http.client._MAXHEADERS = orig


# Generated at 2022-06-23 18:55:41.774893
# Unit test for function build_requests_session
def test_build_requests_session():
    ssl_version = 'tls1'
    assert isinstance(build_requests_session(ssl_version=ssl_version, ciphers='abc'), requests.Session)
    assert isinstance(build_requests_session(ssl_version=ssl_version, ciphers='abc', verify=True), requests.Session)
    assert isinstance(build_requests_session(ssl_version=ssl_version, ciphers='abc', verify=False), requests.Session)



# Generated at 2022-06-23 18:55:45.187985
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = type('Namespace', (), {'timeout': 10, 'allow_redirects': False})
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-23 18:55:49.256379
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 5
    args.allow_redirects = False

    expected = {
        'timeout': args.timeout or None,
        'allow_redirects': False,
    }

    assert(make_send_kwargs(args) == expected)

# Generated at 2022-06-23 18:55:56.306425
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'true'
    args.cert = '123'
    args.cert_key = '456'
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['verify'] == True
    assert send_kwargs_mergeable_from_env['cert'] == '123'

# Generated at 2022-06-23 18:56:01.343135
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        session_obj = build_requests_session(False)
    except Exception as e:
        assert(0)

    if session_obj is not None:
        assert(1)
    else:
        assert(0)



# Generated at 2022-06-23 18:56:04.334054
# Unit test for function build_requests_session
def test_build_requests_session():
    assert isinstance(build_requests_session(True, 'TLSv1_3', 'TLS_AES_128_GCM_SHA256'), requests.Session)

# Generated at 2022-06-23 18:56:11.174678
# Unit test for function max_headers
def test_max_headers():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    if sys.platform == 'win32':
        test_dir = dir_path+"\\unit_test_data\\headers\\"
        test_file = dir_path+"\\unit_test_data\\headers\\test.txt"
    else:
        test_dir = dir_path+"/unit_test_data/headers/"
        test_file = dir_path+"/unit_test_data/headers/test.txt"
    dump_lines = []
    with open(test_file, 'rb') as fh:
        with max_headers(200):
            dump_lines = fh.readlines()
    lines = []

# Generated at 2022-06-23 18:56:14.516477
# Unit test for function collect_messages
def test_collect_messages():
    class args:
        data = "test"
        session = True
        max_headers = False

    config_dir = "D:\Workspace\GitHub\httpie\httpie\config"
    collect_messages(args, config_dir)

# Generated at 2022-06-23 18:56:22.548821
# Unit test for function collect_messages
def test_collect_messages():
    import logging
    import os
    logging.basicConfig(level=logging.DEBUG)

# Generated at 2022-06-23 18:56:30.278659
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    url = 'http://foo/../'
    scheme, netloc, path, params, query, fragment = urlparse(url)
    assert scheme == 'http'
    assert netloc == 'foo'
    assert path == '/..'
    assert params == ''
    assert query == ''
    assert fragment == ''

    url = 'http://foo/../bar'
    scheme, netloc, path, params, query, fragment = urlparse(url)
    assert scheme == 'http'
    assert netloc == 'foo'
    assert path == '/../bar'
    assert params == ''
    assert query == ''
    assert fragment == ''

    url = 'http://foo/../bar'
    url_encoded = 'http://foo/%2E%2E/bar'

# Generated at 2022-06-23 18:56:41.920437
# Unit test for function max_headers
def test_max_headers():
    limit = 5
    headers = {'a':'b', 'c':'d', 'e':'f', 'g':'h', 'i':'j', 'k':'l', 'm':'n',
               'o':'p', 'q':'r', 's':'t', 'u':'v', 'w':'x', 'y':'z'}
    # The following line is to make the httpie client works on python 3.0
    # instead of http.client, also see:
    # https://github.com/jakubroztocil/httpie/issues/1161
    # https://github.com/jakubroztocil/httpie/issues/28
    # http.client._MAXHEADERS = 5

# Generated at 2022-06-23 18:56:45.644972
# Unit test for function make_default_headers
def test_make_default_headers():
    test_args = argparse.Namespace()
    default_headers = make_default_headers(test_args)
    assert default_headers.__class__.__name__ == 'RequestHeadersDict'

# Generated at 2022-06-23 18:56:54.045360
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:57:01.475103
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    ssl_version = None
    ciphers = None
    requests_session = build_requests_session(
        verify=verify,
        ssl_version=ssl_version,
        ciphers=ciphers,
    )
    assert requests_session.adapters != {}
    assert 'https://' in requests_session.adapters.keys()
    assert isinstance(requests_session.adapters['https://'], HTTPieHTTPSAdapter)



# Generated at 2022-06-23 18:57:05.737740
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 7.0
    args.allow_redirects = False
    data = make_send_kwargs(args)
    print(data['timeout'])
    print(data['allow_redirects'])
    print(data)
    assert data['timeout'] == 7.0
    assert data['allow_redirects'] == False


# Generated at 2022-06-23 18:57:11.027199
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo:8080/?foo=bar') == 'http://foo:8080/../?foo=bar'

# Generated at 2022-06-23 18:57:19.958104
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    base_kwargs = {
        'verify': {
            'yes': True,
            'true': True,
            'no': False,
            'false': False,
        }.get('yes'),
        'cert': None,
        'proxies': {'https': 'https://proxy.example.com:8080'},
    }
    assert make_send_kwargs_mergeable_from_env({}) == base_kwargs
    assert make_send_kwargs_mergeable_from_env({'--verify': 'yes'}) == base_kwargs
    assert make_send_kwargs_mergeable_from_env({'--verify': 'true'}) == base_kwargs
    assert make_send_kwargs_mergeable_from_env({'--verify': 'no'})

# Generated at 2022-06-23 18:57:24.565589
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 1
    args.allow_redirects = False
    result = make_send_kwargs(args)
    expected = {
        'timeout': args.timeout or None,
        'allow_redirects': False,
    }
    assert result == expected


# Generated at 2022-06-23 18:57:33.133049
# Unit test for function dump_request
def test_dump_request():
    # test dump_request
    kwargs_test = [
        {'method':'GET', 'url':'https://myurl1', 'headers':{'User-Agent':'test/0.5.0'}, 'data':None, 'params':[]},
        {'method':'POST', 'url':'https://myurl2', 'headers':{'User-Agent':'test/0.5.0'}, 'data':'This is a test', 'params':[]},
        {'method':'PUT', 'url':'https://myurl3', 'headers':{'User-Agent':'test/0.5.0'}, 'data':b'This is a test', 'params':[]}
    ]
    for kwargs_current in kwargs_test:
        out = dump_request(kwargs_current)

# Generated at 2022-06-23 18:57:37.553621
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    a = make_send_kwargs_mergeable_from_env({})
    assert a == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }
    b = make_send_kwargs_mergeable_from_env({'proxy': '1'})
    assert b == {
        'proxies': {'https': '1', 'http': '1'},
        'stream': True,
        'verify': True,
        'cert': None
    }



# Generated at 2022-06-23 18:57:38.416305
# Unit test for function collect_messages
def test_collect_messages():
    assert True

# Generated at 2022-06-23 18:57:42.804263
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = {}
    args['timeout'] = 15
    args['allow_redirects'] = False
    
    kwargs = make_send_kwargs(args)
    returned_timeout = kwargs['timeout']
    returned_redirects = kwargs['allow_redirects']
    
    assert returned_timeout == 15
    assert returned_redirects == False

# Generated at 2022-06-23 18:57:47.669257
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace(method='GET', url='https://github.com/')
    kwargs = make_request_kwargs(args=args, base_headers=None)
    dump_request(kwargs)


# Generated at 2022-06-23 18:57:54.184909
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': 'GET',
        'url': 'http://www.google.com',
        'headers': {'Content-Type': 'json'},
        'data': 'test',
    }
    assert dump_request(kwargs) == '\n>>> requests.request(**{\'method\': \'GET\', \'url\': \'http://www.google.com\', \'headers\': {\'Content-Type\': \'json\'}, \'data\': \'test\'})\n\n'