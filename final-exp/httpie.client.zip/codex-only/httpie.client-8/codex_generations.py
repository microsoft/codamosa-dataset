

# Generated at 2022-06-23 18:47:57.569028
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:48:10.906153
# Unit test for function collect_messages
def test_collect_messages():
    import unittest
    class TestCollect_message(unittest.TestCase):
        def test_collect_messages(self):
            import argparse
            import json
            import sys
            class MockArgs(argparse.Namespace):
                method = 'GET'
                url = None
                headers = {'User-Agent': DEFAULT_UA}
                data = None
                files = None
                params = {}
                json = None
                form = False
                verbose = False
                debug = False
            args = MockArgs()
            data = json.loads(json.dumps('{}'))
            args.data = data
            args.json = True
            request_body_read_callback = None
            from pathlib import Path
            config_dir = Path('.')

# Generated at 2022-06-23 18:48:13.412399
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert 'http://foo/../?foo=bar' == ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')

# Generated at 2022-06-23 18:48:25.696492
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = ''
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': DEFAULT_UA}

args = argparse.Namespace()
args.json = False
args.form = False
args.data = True
default_headers = make_default_headers(args)
assert default_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': JSON_CONTENT_TYPE}

args = argparse.Namespace()
args.json = True
args.form = False
args.data = '{"name": "S"}'
default_headers = make_default_headers(args)

# Generated at 2022-06-23 18:48:28.420048
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:48:40.001740
# Unit test for function finalize_headers
def test_finalize_headers():
    test1headers = RequestHeadersDict({
        'User-Agent': 'HTTPIE/0.9.8'
    })
    test1final_headers = finalize_headers(test1headers)
    if test1final_headers['User-Agent'] != 'HTTPIE/0.9.8':
        raise RuntimeError(
            'test1final_headers error! Should be HTTPIE/0.9.8 but get '
            '{}'.format(test1final_headers['User-Agent']))
    if len(test1final_headers.keys()) != 1:
        raise RuntimeError(
            'test1final_headers error! Should only have 1 key but get {}'
            ' keys'.format(len(test1final_headers.keys())))


# Generated at 2022-06-23 18:48:43.056655
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 0
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    assert http.client._MAXHEADERS == 0

# Generated at 2022-06-23 18:48:46.743601
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = True
    args.cert = 'foo'
    args.cert_key = 'bar'
    result = make_send_kwargs_mergeable_from_env(args)
    assert result.get('proxies') == {}
    assert result.get('stream') == True
    assert result.get('verify') == True
    assert result.get('cert') == ('foo', 'bar')

# Generated at 2022-06-23 18:48:53.825553
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept-Language': None,
        'Content-Type': ''
    })
    final_headers = finalize_headers(headers)
    assert final_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': ''}

    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept-Language': '   ',
        'Content-Type': ''
    })
    final_headers = finalize_headers(headers)
    assert final_headers == {'User-Agent': DEFAULT_UA, 'Content-Type': ''}

# Generated at 2022-06-23 18:48:56.889693
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    test_url = ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')
    assert test_url == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:49:03.610643
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(argparse.Namespace(json=True)) == RequestHeadersDict(
            {'User-Agent': DEFAULT_UA, 'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE}
        )
    assert make_default_headers(argparse.Namespace(form=True)) == RequestHeadersDict(
        {'User-Agent': DEFAULT_UA, 'Content-Type': FORM_CONTENT_TYPE}
    )
    assert make_default_headers(argparse.Namespace(data=dict(foo=1))) == RequestHeadersDict(
        {'User-Agent': DEFAULT_UA, 'Content-Type': JSON_CONTENT_TYPE, 'Accept': JSON_ACCEPT}
    )

# Generated at 2022-06-23 18:49:11.893849
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()

    args.json = False
    args.form = False
    args.files = False
    args.data = False

    headers = make_default_headers(args)
    assert headers['User-Agent'] == 'HTTPie/' + __version__
    assert not list(headers.keys()) == ['User-Agent']

    args.json = True
    headers = make_default_headers(args)
    assert headers['User-Agent'] == 'HTTPie/' + __version__
    assert headers['Accept'] == 'application/json, */*;q=0.5'
    assert headers['Content-Type'] == 'application/json'
    assert not list(headers.keys()) == ['User-Agent', 'Accept', 'Content-Type']

    args.json = False
    args.form = True
   

# Generated at 2022-06-23 18:49:24.681104
# Unit test for function collect_messages
def test_collect_messages():
    import os
    import sys

    pkg_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    sys.path.insert(0, pkg_dir)


# Generated at 2022-06-23 18:49:33.813421
# Unit test for function make_default_headers
def test_make_default_headers():
    # Test default user-agent header
    args = argparse.Namespace(json=False, headers={}, data=None,
                              form=False, files=None)
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA}
    # Test other headers
    expected_headers = {'User-Agent': DEFAULT_UA, 'Content-Type':
                        FORM_CONTENT_TYPE, 'Accept': JSON_ACCEPT}
    args = argparse.Namespace(json=True, headers={'Accept': 'text/html'},
                              data={}, form=True, files=None)
    # "Accept" should be overridden with "application/json"
    assert make_default_headers(args) == expected_headers

# Generated at 2022-06-23 18:49:38.810116
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.url = 'http://example.com'
    args.method = 'GET'
    args.headers = RequestHeadersDict({'Content-Type': 'text/plain'})
    args.json = True
    args.auth = ('user', 'password')
    args.params = {'foo': '1', 'bar': '2'}
    args.data = 'test'
    args.form = None
    args.files = None
    args.multipart = None
    args.multipart_data = None
    args.boundary = None
    args.max_redirects = 5
    args.follow = True
    args.max_redirects = 5
    args.timeout = 1.0
    args.verify = True

# Generated at 2022-06-23 18:49:44.239004
# Unit test for function dump_request
def test_dump_request():
    kwargs = dict(
        method='GET',
        url='http://httpbin.org/get',
        headers={'User-Agent': 'HTTPie/0.8.0'},
        data=None,
        auth=('user', 'pass'),
        params={'a': 'b'}
    )
    dump_request(kwargs)
    assert True


# Generated at 2022-06-23 18:49:53.343382
# Unit test for function max_headers
def test_max_headers():
    limit = 3
    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = limit

    # Create headers
    headers = ['Client-Date: date', 'Client-Peer: peer', 'Client-Response-Num: num', 'Client-Transfer-Encoding: encoding']
    request = urllib3.HTTPResponse()
    assert len(headers) == limit + 1

    # Setup request
    for header in headers:
        header_elements = header.split(':')
        request.addheader(header_elements[0], header_elements[1])

    # Ensure that the header length is equal to the limit
    request._original_response.msg._headers = headers
    assert len(request._original_response.msg._headers) == limit
    http.client._MAXHEADERS = orig

# Unit

# Generated at 2022-06-23 18:49:57.494947
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS=100
    assert http.client._MAXHEADERS==100
    with max_headers(150):
        assert http.client._MAXHEADERS==150
    assert http.client._MAXHEADERS==100


# Generated at 2022-06-23 18:50:01.449220
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = None
    for i in collect_messages(args, config_dir, request_body_read_callback):
        print(i)

# Generated at 2022-06-23 18:50:11.734718
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'https://foo/?foo=bar') == 'https://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://127.0.0.1/?foo=bar') == 'http://127.0.0.1/../?foo=bar'
    assert ensure_path_as_is('localhost:8080', 'http://localhost:8080/') == 'http://localhost:8080/'
    assert ensure_path_as_is('localhost', 'http://localhost:8080/') == 'http://localhost:8080/'



# Generated at 2022-06-23 18:50:14.799679
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = "./"
    for message in collect_messages(args, config_dir):
        print(message)

# Generated at 2022-06-23 18:50:18.807987
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({"Content-type": " text/html;charset = UTF-8", "accept": "application/json "})
    headers_finalized = RequestHeadersDict({"Content-type": "text/html;charset=UTF-8", "accept": "application/json"})
    assert finalize_headers(headers) == headers_finalized

# Generated at 2022-06-23 18:50:25.989956
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = ['key']
    args.verify = True
    args.cert = ['cert']
    args.cert_key = ['cert_key']
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {'key': 'key'}
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ['cert', 'cert_key']



# Generated at 2022-06-23 18:50:30.530491
# Unit test for function max_headers
def test_max_headers():
#test for default value
    max_headers = 10
    max_headers_ = http.client._MAXHEADERS
    assert max_headers_ == max_headers, "http.client._MAXHEADERS should be equal to 10 default value"
#test for value set by context manager
    with max_headers(12):
        max_headers_ = http.client._MAXHEADERS
        assert max_headers_ == 12, "http.client._MAXHEADERS should be equal to 12 value set by context manager"
#test for value set by argparse
    _MAXHEADERS = 15
    max_headers_ = http.client._MAXHEADERS
    assert max_headers_ == _MAXHEADERS, "http.client._MAXHEADERS should be equal to 15 value set by variable _MAXHEADERS"
print(test_max_headers())

# Generated at 2022-06-23 18:50:36.021408
# Unit test for function collect_messages
def test_collect_messages():
    kwargs = {}

# Generated at 2022-06-23 18:50:42.321586
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    args = Namespace(
        timeout = 10,
        allow_redirects = False,
    )

    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {
        'timeout': args.timeout or None,
        'allow_redirects': args.allow_redirects,
    }


# Generated at 2022-06-23 18:50:53.941851
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    def fun_request_body_read_callback(data):
        return data
    class args:
        method = "GET"
        url = "http://127.0.0.1:5643/query/select"
        headers = {}
        data = {"keys": "1"}
        files = ""
        form = False
        json = True
        args = ""
        chunked = False
        offline = False
        all = False
        follow = True
        max_headers = None
        max_redirects = None
        path_as_is = False
        cert = ""
        cert_key = ""
        proxy = ""
        verify = ""
        timeout = ""
        auth = ""
        params = ""
        debug = False


# Generated at 2022-06-23 18:51:05.645614
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test set 1: no proxy
    args = argparse.Namespace()
    args.proxy = []
    args.verify = "yes"
    args.cert = None
    args.cert_key = None
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    # Test set 2: with proxy
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='http', value='http://proxy.com')]
    args.verify = "true"
    args.cert = "cert.crt"
    args.cert_key = "cert.key"
    assert make_send_kwargs_merge

# Generated at 2022-06-23 18:51:10.544477
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [urlparse('http://1.1.1.1'), urlparse('http://[::1]')]
    args.verify = 'true'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['verify'] == True
    assert send_kwargs_mergeable_from_env['cert'] == 'cert'
    assert send_kwargs_mergeable_from_env['cert_key'] == 'cert_key'

# Generated at 2022-06-23 18:51:12.760217
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:51:18.216155
# Unit test for function collect_messages
def test_collect_messages():
    url = 'http://httpbin.org/get'

# Generated at 2022-06-23 18:51:30.572069
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(data='', form='', files='',json='', ua='', auth='', auth_type='', headers='', output='',
         chunked=False, traceback=False, check_status=False,
         timeout='', max_redirects='',max_headers='', stream=False,
         verbose=False, traceback=False, debug=False,
         follow=False, all=False, history_aware=False,
         stream_session=False, session=False,
         session_read_only=False,auth_plugin=False,
         output_options={})

    #check that the user agent is correct
    headers = make_default_headers(args)
    user_agent = headers['User-Agent']
    if user_agent != 'HTTPie/0.9.9':
        print

# Generated at 2022-06-23 18:51:39.753134
# Unit test for function make_default_headers
def test_make_default_headers():
    # test without --json
    args = argparse.Namespace()
    args.json = False
    args.data = False
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers.get('Content-Type') is None
    assert default_headers.get('Accept') is None
    # test --json
    args = argparse.Namespace()
    args.json = True
    args.data = False
    args.form = False
    default_headers = make_default_headers(args)
    assert default_headers.get('Content-Type') == JSON_CONTENT_TYPE
    assert default_headers.get('Accept') == JSON_ACCEPT
    # test --form
    args = argparse.Namespace()
    args.json = False
    args.data = False
    args

# Generated at 2022-06-23 18:51:43.283620
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=5, allow_redirects=False)
    expected_send_kwargs = {'timeout': 5, 'allow_redirects': False}
    assert make_send_kwargs(args) == expected_send_kwargs

# Generated at 2022-06-23 18:51:50.102491
# Unit test for function collect_messages
def test_collect_messages():
    requests_session = build_requests_session(verify=False, ssl_version=None, ciphers=None)
    kwargs = {
        'method': 'GET',
        'url': 'http://foo.bar',
        'headers': {"h1":"h1"},
        'data': "data",
        'auth': None,
        'params': "",
    }
    request = requests.Request(**kwargs)
    prepared_request = requests_session.prepare_request(request)
    # prepared_request = requests.PreparedRequest()
    # prepared_request.body = "body"
    # prepared_request.url = "foo.bar"
    # prepared_request.headers = {"headers":"headers"}
    # prepared_request.method = "get"
    # prepared_request.params = {'

# Generated at 2022-06-23 18:51:55.549642
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        ssl_version='TLSv1',
        ciphers=None,
        verify=True
    )
    assert 'HTTPieHTTPSAdapter' in str(requests_session.adapters.get('https://'))


# Generated at 2022-06-23 18:51:59.870239
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie.cli.parser import parse_args
    args = parse_args(['-d', '{"a": "b"}', 'http://localhost'])
    kwargs = make_request_kwargs(args)
    assert json.loads(kwargs['data']) == {"a": "b"}

# Generated at 2022-06-23 18:52:04.630805
# Unit test for function make_default_headers
def test_make_default_headers():
    x=make_default_headers({})
    print("User-Agent :",x["User-Agent"])
    print("Accept :",x["Accept"])
    print("Content-Type :",x["Content-Type"])

if __name__ == '__main__':
    test_make_default_headers()

# Generated at 2022-06-23 18:52:10.461070
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
	import argparse
	args = argparse.Namespace(
            timeout=0,
            forece_colors=False,
			trim=False,
			verify=True
	)
	send_kwargs = make_send_kwargs(args)
	assert send_kwargs == {
        'timeout': None,
        'allow_redirects': False
	}, 'make_send_kwargs failed'

# Generated at 2022-06-23 18:52:19.045181
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [('http://foo.com', 'http://bar.com'), ('http://test.com', 'http://test.com')]
    args.verify = 'yes'
    args.cert = '../../README.md'
    args.cert_key = '../../README.md'

    # Testing function make_send_kwargs_mergeable_from_env in module messages

# Generated at 2022-06-23 18:52:26.747542
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.form = False
    args.data = {'name': 'ABC', 'age': '30'}
    args.files = False
    args.json = True
    args.method = 'GET'
    args.headers = {}
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    args.json = False
    args.form = True
    headers = make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE


# Generated at 2022-06-23 18:52:37.773568
# Unit test for function collect_messages
def test_collect_messages():
    class A:
        def __init__(self):
            self.url = "https://www.google.com/"
            self.headers = RequestHeadersDict({'User-Agent': 'haha'})
            self.method = "GET"
            self.auth = ""
            self.session = None
            self.session_read_only = None
            self.data = None
            self.json = None
            self.form = None
            self.files = None
            self.params = {}
            self.debug = False
            self.offline = False
            self.chunked = False
            self.compress = 0
            self.max_headers = None
            self.max_redirects = 30
            self.timeout = None
            self.follow = False
            self.all = False
            self.auth_plugin

# Generated at 2022-06-23 18:52:39.666766
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from . import validate_output

    validate_output(make_request_kwargs, "test_make_request_kwargs.json")

# Generated at 2022-06-23 18:52:44.340636
# Unit test for function max_headers
def test_max_headers():
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 1000
    with max_headers(1):
        # noinspection PyUnresolvedReferences
        assert http.client._MAXHEADERS == 1
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:52:48.928587
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    send_kwargs = make_send_kwargs(args)
    assert([
        ('timeout', None), ('allow_redirects', False)
        ] == sorted(send_kwargs.items()))


# Generated at 2022-06-23 18:53:00.659578
# Unit test for function make_send_kwargs

# Generated at 2022-06-23 18:53:03.588892
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({'Content-Type': ' application/json'}) == {'Content-Type': 'application/json'}


# Generated at 2022-06-23 18:53:13.687403
# Unit test for function finalize_headers
def test_finalize_headers():
    from httpie.cli.parser import parser
    from httpie.cli.dicts import KeyValue
    from urllib.parse import urlparse
    args = parser.parse_args([
        '--headers', 'user-agent:',
        '--headers', 'Host:api.github.com',
        '--headers', 'accept:application/json',
        '--headers', 'foo: baz',
        'GET', 'https://api.github.com/users/jkbrzt'
        ])

    request_body_read_callback = lambda chunk: chunk
    default_headers = make_default_headers(args)
    headers = RequestHeadersDict(args.headers)
    headers.update(default_headers)
    final_headers = finalize_headers(headers)

    headers = RequestHeadersDict()
    headers

# Generated at 2022-06-23 18:53:24.878665
# Unit test for function finalize_headers
def test_finalize_headers():

    # Simple case
    args = argparse.Namespace()
    args.headers = {'key1': 'val1'}
    args.json = False
    args.form = False
    headers = make_default_headers(args)

    final_headers = finalize_headers(headers)
    assert final_headers == {'key1': 'val1', 'User-Agent': DEFAULT_UA}

    # Mixed case
    args = argparse.Namespace()
    args.headers = {'key1': 'val1', 'kEy2': 'vAl2'}
    args.json = False
    args.form = False
    headers = make_default_headers(args)

    final_headers = finalize_headers(headers)

# Generated at 2022-06-23 18:53:32.999544
# Unit test for function collect_messages
def test_collect_messages():
    class args:
        session = None
        session_read_only = None
        headers = {'Host': '127.0.0.1:5000'}
        url = 'http://127.0.0.1:5000/?foo=bar'
        path_as_is = False
        compress = False
        debug = False
        offline = False
        max_redirects = None
        follow = False
        all = False
        ssl_version = '1.1'
        ciphers = None
        cert = None
        cert_key = None
        method = 'GET'
        form = False
        json = False
        data = ''
        params = {}
        auth = None
        auth_plugin = None
        max_headers = None
        chunked = False
        request_body_read_callback = None
        files

# Generated at 2022-06-23 18:53:36.987496
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    kwargs = {
    'timeout': None,
    'allow_redirects': False
    }
    args = argparse.Namespace(timeout=None, follow=False)
    result = make_send_kwargs(args)
    assert result == kwargs


# Generated at 2022-06-23 18:53:45.134524
# Unit test for function build_requests_session
def test_build_requests_session():
    verify_proxy = False
    verify = True
    ssl_version = 'TLSv1.2'
    ciphers = 'ECDH+AESGCM:DH+AESGCM:ECDH+AES256:DH+AES256:ECDH+AES128:DH+AES:ECDH+3DES:DH+3DES:RSA+AESGCM:RSA+AES:RSA+3DES:!aNULL:!MD5:!DSS'
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=(False or verify_proxy or verify)
    )
    #test plugin
    requests_session.mount('test', HTTPieHTTPSAdapter())
    print(requests_session.adapters)


# Generated at 2022-06-23 18:53:50.651094
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    kwargs = {'method': 'GET', 'url': 'https://httpie.org', 'proxies': {'https':'194.230.85.46:8080'}}
    dump_request(kwargs)
    assert(1 == 1)


# Generated at 2022-06-23 18:53:59.204342
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    """Test 'path-as-is' function ensure_path_as_is."""

    url = 'http://foo/../'
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

    url = 'http://foo/./'
    assert ensure_path_as_is('http://foo/./', 'http://foo/?foo=bar') == 'http://foo/./?foo=bar'

    url = 'http://foo/.'
    assert ensure_path_as_is('http://foo/.', 'http://foo/?foo=bar') == 'http://foo/./?foo=bar'

    url = 'http://foo/..'

# Generated at 2022-06-23 18:54:00.478734
# Unit test for function build_requests_session
def test_build_requests_session():
    # TODO add test
    return None

# Generated at 2022-06-23 18:54:12.380996
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(method='GET', url='https://www.google.com', headers={'User-Agent': 'HTTPie'}, data=['Hello', 'World'], json=False, form=True, files=[], auth=None, params=[], auth_plugin=None, session=None, session_read_only=False, timeout=180, verify=False, cert=None, cert_key=None, max_redirects=10, max_headers=0, chunked=False, compress=False, path_as_is=False, debug=False, proxy=[], ssl_version=None, ciphers=None, offline=False, json_pp=False)
    request_kwargs = make_request_kwargs(args=args)
    assert request_kwargs['url'] == 'https://www.google.com'
   

# Generated at 2022-06-23 18:54:13.862958
# Unit test for function finalize_headers
def test_finalize_headers():
    dictionary = {"Content-Type": "application/json"}
    final_headers = finalize_headers(dictionary)
    assert final_headers['Content-Type'] == b"application/json"

# Generated at 2022-06-23 18:54:17.912288
# Unit test for function max_headers
def test_max_headers():
    global http
    try:
        if http:
            pass
    except NameError:
        http = type('', (object,), {'client': type('', (object,), {})})
        http.client._MAXHEADERS = 999999999
    with max_headers(100):
        assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:54:29.589760
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from httpie.context import Environment
    from httpie.utils import get_config_dir
    from httpie.cli.utils import UnsetType
    from pathlib import Path
    env = Environment(stdin_isatty=True, stdout_isatty=True,
                      stdin_bytes=False, stdout_bytes=False,
                      stdin=None, stdout=None,
                      simple_output=False, verify=False,
                      config_dir=get_config_dir(),
                      colors=UnsetType)


# Generated at 2022-06-23 18:54:32.851198
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None):
        assert http.client._MAXHEADERS == float('Inf')
    with max_headers(2):
        assert http.client._MAXHEADERS == 2
    assert http.client._MAXHEADERS == float('Inf')

# Generated at 2022-06-23 18:54:38.100518
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(
                                                verify=False,
                                                ssl_version=None,
                                                ciphers=None,
                                            )
    assert isinstance(session, requests.Session)
    assert isinstance(session.mount('https://', HTTPieHTTPSAdapter(
        ciphers=None,
        verify=False,
        ssl_version=None,
    )), requests.adapters.HTTPAdapter)


# Generated at 2022-06-23 18:54:41.376915
# Unit test for function collect_messages
def test_collect_messages():
    returned_values = collect_messages(args=None, config_dir=None)
    print(returned_values)

test_collect_messages()

# Generated at 2022-06-23 18:54:48.888319
# Unit test for function finalize_headers
def test_finalize_headers():
    def test_single(name, value, expected):
        assert finalize_headers(RequestHeadersDict({name: value})) == RequestHeadersDict({expected[0]: expected[1]})

    # test_single('Accept-Language', '\nzh-cn', ('Accept-Language', 'zh-cn'))
    test_single('Accept-Language', 'zh-cn', ('Accept-Language', 'zh-cn'))
    test_single('Accept-Language', '', ('Accept-Language', ''))
    test_single('Accept-Language', None, ('Accept-Language', None))



# Generated at 2022-06-23 18:55:01.083795
# Unit test for function max_headers
def test_max_headers():
    max_headers_dict = {
        'User-Agent': 'HTTPie/0.9.2',
        'Accept': 'application/json, */*;q=0.5',
        'Connection': 'keep-alive',
        'Content-Length': '0',
        'Accept-Encoding': 'gzip, deflate',
    }
    max_headers_normal = ['Accept','Connection','Content-Length','Accept-Encoding','User-Agent']
    max_headers_limited = ['Accept','Connection','Content-Length','User-Agent']
    with max_headers(4):
        headers_normal = list(max_headers_dict.keys())
        headers_limited = list(max_headers(4).__enter__().keys())
    assert headers_normal == max_headers_normal
    assert headers_limited == max_headers_limited

# Generated at 2022-06-23 18:55:01.858640
# Unit test for function collect_messages
def test_collect_messages():
    assert(1 ==2)

# Generated at 2022-06-23 18:55:02.933693
# Unit test for function collect_messages
def test_collect_messages():
    print(collect_messages)

# Generated at 2022-06-23 18:55:04.803818
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs_mergeable_from_env()
    assert make_send_kwargs()

# Generated at 2022-06-23 18:55:09.575537
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
         ' User-Agent': 'HTTPie/1.0.3'
    })
    headers = finalize_headers(headers)
    assert 'User-Agent' in headers
    assert headers['User-Agent'].strip() == DEFAULT_UA

# Generated at 2022-06-23 18:55:21.053580
# Unit test for function make_default_headers
def test_make_default_headers():
    arg = argparse.Namespace(
        json = False,
        form = False,
        data = None,
        files = None,
    )
    assert make_default_headers(arg) == {
        'User-Agent': 'HTTPie/1.0.2-dev0'
    }
    arg.json = True
    assert make_default_headers(arg) == {
        'Accept': 'application/json, */*;q=0.5',
        'User-Agent': 'HTTPie/1.0.2-dev0'
    }
    arg.json = False
    arg.data = {'foo': 'bar'}

# Generated at 2022-06-23 18:55:32.099482
# Unit test for function make_default_headers
def test_make_default_headers():
    class Namespace(argparse.Namespace):
        def __init__(self, data=None, form=None, json=None,files=None, **kwargs):
            super().__init__(data=data, form=form, json=json,files=files, **kwargs)
    args = Namespace(data=[{"a":2}], form=[], json=None,files=[])
    headers=make_default_headers(args)
    assert headers['Content-Type'] == 'application/json'
    args = Namespace(data={}, form=[], json=None,files=[])
    headers=make_default_headers(args)
    assert headers['Content-Type'] == 'application/json'
    args = Namespace(data=[], form=[], json=None,files=[])
    headers=make_default_headers(args)

# Generated at 2022-06-23 18:55:42.724885
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:55:49.868784
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()

    args.files = None
    args.data = None
    args.json = False
    args.form = False
    args.headers = None

    args.method = 'POST'
    args.url = 'http://localhost:8080/api/v1/addresses/'
    args.headers = {
        'Content-Type': 'application/json; charset=utf-8'
    }
    args.timeout = 30

    kwargs = make_request_kwargs(args)

    # print(f'test_make_request_kwargs {kwargs}')
    # assert(kwargs['data'] is None)
    # assert(kwargs['headers'] is None)



# Generated at 2022-06-23 18:55:50.780328
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session

# Generated at 2022-06-23 18:55:53.536506
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    import doctest
    doctest.run_docstring_examples(ensure_path_as_is, globals())

# Generated at 2022-06-23 18:55:59.941960
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session_with_default_cert_verify = build_requests_session(
        verify=True,
        ssl_version=None,
        ciphers=None)

    requests_session_with_false_cert_verify = build_requests_session(
        verify=False,
        ssl_version=None,
        ciphers=None)

    assert requests_session_with_default_cert_verify.verify is not False
    assert requests_session_with_false_cert_verify.verify is False

# Generated at 2022-06-23 18:56:11.049837
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    headers = make_default_headers(args)
    assert headers.get('Accept') == JSON_ACCEPT
    assert headers.get('Content-Type') == JSON_CONTENT_TYPE
    args = argparse.Namespace()
    args.json = False
    args.form = True
    headers = make_default_headers(args)
    assert headers.get('Content-Type') == FORM_CONTENT_TYPE
    assert headers.get('Accept') is None
    args = argparse.Namespace()
    args.json = False
    args.form = False
    headers = make_default_headers(args)
    assert headers.get('Content-Type') is None
    assert headers.get('Accept') is None

# Generated at 2022-06-23 18:56:20.117060
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-23 18:56:26.051200
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    r = requests.Response()
    r.url = 'https://2.2.2.2:2222'
    http_proxy = 'http://1.1.1.1:1111'
    https_proxy = 'https://3.3.3.3:3333'
    args = argparse.Namespace(verify='yes', cert=None)
    args.proxy = [
        argparse.Namespace(key='http', value=http_proxy),
        argparse.Namespace(key='https', value=https_proxy),
        ]
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    requests_session = requests.Session()

# Generated at 2022-06-23 18:56:30.078339
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.headers = RequestHeadersDict()
    ua = make_default_headers(args)
    assert ua['User-Agent'] == DEFAULT_UA, "Default User-Agent Must Be '{}'".format(DEFAULT_UA)



# Generated at 2022-06-23 18:56:40.875002
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Test for function make_request_kwargs when data is a dict and arg.json is False
    # the result should be success
    args = argparse.Namespace()
    args.json = False
    args.data = {'hello':'world'}
    assert make_request_kwargs(args)['data'] == '{"hello": "world"}'
    # Test for function make_request_kwargs when data is a dict and arg.json is True
    # the result should be success
    args = argparse.Namespace()
    args.json = True
    args.data = {'hello':'world'}
    assert make_request_kwargs(args)['data'] == '{"hello": "world"}'

# Generated at 2022-06-23 18:56:51.869710
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    #Test for method: GET
    msg = make_request_kwargs(
        argparse.Namespace(
            method='GET',
            url='http://test/test',
            headers=RequestHeadersDict({'Content-Type': 'application/json', 'Content-Length': '10'}),
            data='{"key":"value"}',
            json=False,
            form=False,
            files=False,
            params=RequestHeadersDict({'key':'value'}),
            auth=None,
            chunked=False,
            offline=False
        )
    )

# Generated at 2022-06-23 18:57:03.436568
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'https://foo/?foo=bar') == 'https://foo/../?foo=bar'
    assert ensure_path_as_is('http://user:pass@foo/../', 'http://foo/?foo=bar') == 'http://user:pass@foo/../?foo=bar'
    assert ensure_path_as_is('http://foo:port/../', 'http://foo/?foo=bar') == 'http://foo:port/../?foo=bar'

# Generated at 2022-06-23 18:57:08.232117
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../?a=1&b=2', 'http://foo?foo=bar') == 'http://foo//../?a=1&b=2'

# Generated at 2022-06-23 18:57:18.038847
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class Args(object):
        pass
    args = Args()
    args.data = {'foo': 'bar'}
    args.json = True
    args.url = 'http://www.baidu.com:8080'
    args.method = 'POST'
    args.headers = {}
    args.offline = True
    args.chunked = False
    args.form = False
    args.files = None
    args.multipart = False
    args.multipart_data = {}
    args.boundary = ''
    args.auth = None
    args.params = {}
    args.max_headers = None
    args.session = None
    args.session_read_only = None
    args.auth_plugin = None
    args.debug = False
    args.follow = False
   

# Generated at 2022-06-23 18:57:24.609788
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.data = {}
    args.form = True
    args.files = False
    x = make_default_headers(args)
    assert x == {'User-Agent': 'HTTPie/1.0.3', 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}

# Generated at 2022-06-23 18:57:27.417244
# Unit test for function finalize_headers
def test_finalize_headers():
    data = RequestHeadersDict({'Content-Type': '   text/plain; charset=utf8    ', None: {'asd': 'asd'}})
    res = finalize_headers(data)
    assert res['Content-Type'] == 'text/plain; charset=utf8'

# Generated at 2022-06-23 18:57:34.938298
# Unit test for function dump_request
def test_dump_request():
    from httpie.cli.parser import get_parser
    parser = get_parser()
    args = parser.parse_args(['--json', 'https://httpbin.org/post', 'name=jack'])
    expected_output = '\n>>> requests.request(**{!r})\n\n'
    kwargs = make_request_kwargs(args)
    assert expected_output.format(kwargs) == dump_request(kwargs)


# Generated at 2022-06-23 18:57:37.240929
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    url_src = 'http://foo/../'
    url_dst = 'http://foo/?foo=bar'
    ret = ensure_path_as_is(url_src, url_dst)
    assert ret == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:57:45.739320
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args_kwargs = make_request_kwargs(request_kwargs = {
        'method': 'get',
        'url': 'http://localhost:5000/api/v1/registrations',
        'headers': 'User-Agent: httpie/1.0.3',
        'auth': ('username', 'password'),
        'params': {'name': 'postman'},
        'data': ''
    }) 
    assert args_kwargs['method'] == 'get'
    assert args_kwargs['url'] == 'http://localhost:5000/api/v1/registrations'
    assert args_kwargs['auth'] == ('username', 'password')
    assert args_kwargs['params'] == {'name': 'postman'}
    assert args_kwargs['data'] == ''

# Generated at 2022-06-23 18:57:47.690894
# Unit test for function max_headers
def test_max_headers():
    headers = {'a'}

    assert len(headers) == 1
    with max_headers(1):
        assert len(headers) == 1
    with max_headers(0):
        assert len(headers) == 0

# Generated at 2022-06-23 18:57:48.157404
# Unit test for function collect_messages
def test_collect_messages():
    assert True

# Generated at 2022-06-23 18:57:52.505813
# Unit test for function finalize_headers
def test_finalize_headers():
    # Test if leading and trailing spaces are removed from the request header Value
    args = argparse.Namespace()
    args.headers = RequestHeadersDict({'Test': '   Value   '})
    assert finalize_headers(args.headers) == {'Test': 'Value'}


# Unit tests for function make_default_headers