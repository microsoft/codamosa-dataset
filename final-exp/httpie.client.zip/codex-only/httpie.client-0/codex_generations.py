

# Generated at 2022-06-23 18:47:55.752200
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        ssl_version=None,
        ciphers=None,
        verify=True
    )
    https_adapter = requests_session.get_adapter('https://')
    assert https_adapter.ssl_version is None

# Generated at 2022-06-23 18:48:04.031755
# Unit test for function dump_request
def test_dump_request():
    sys.argv = ["http", "--auth=user:pass", "--method", "POST", "--form", "--json", "hello:world"]
    args = parser.parse_args(sys.argv[1:])
    config_dir = Path(__file__).parent.parent / '.config' / 'httpie'
    dump_request(make_request_kwargs(args, request_body_read_callback))
    pass


if __name__ == '__main__':
    test_dump_request()

# Generated at 2022-06-23 18:48:15.638281
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    kwargs = make_send_kwargs_mergeable_from_env(args={"proxy": [{'key': 'http', 'value': 'http://127.0.0.1:8080'}, {'key': 'https', 'value': 'https://127.0.0.1:8080'}], 'verify': 'no', 'cert': 'certs/todo.pem', 'cert_key': 'certs/todo.key'})
    assert {
        'proxies': {'http': 'http://127.0.0.1:8080', 'https': 'https://127.0.0.1:8080'},
        'verify': False,
        'cert': 'certs/todo.pem',
        'stream': True
    } == kwargs

# Generated at 2022-06-23 18:48:20.709940
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    '''
    >>> make_send_kwargs(argparse.Namespace(timeout=10, allow_redirects=False))
    {'timeout': 10, 'allow_redirects': False}
    '''



# Generated at 2022-06-23 18:48:24.964785
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    ssl_version = None
    ciphers = "111"
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=verify
    )

# Generated at 2022-06-23 18:48:30.421087
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    input_url = 'http://foo/../'
    prepped_url = 'http://foo/?foo=bar'
    expected_output = 'http://foo/../?foo=bar'
    result = ensure_path_as_is(input_url, prepped_url)
    if result == expected_output:
        print('test_ensure_path_as_is: PASS')
        return 0
    else:
        print('test_ensure_path_as_is: FAIL')
        return 1


# Generated at 2022-06-23 18:48:39.524804
# Unit test for function dump_request
def test_dump_request():
    import json
    import sys
    import tempfile
    import shutil
    from contextlib import contextmanager
    # noinspection PyUnresolvedReferences
    from httpie.core import main
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import plugin_manager

    class FakePlugin:
        name = 'fake'
        auth_type = 'fake'

        def _get_auth(self):
            return HTTPBasicAuth(username='george', password='monkey')

        def _get_auth_from_url(self, url):
            return url, None

    plugin_manager.register(FakePlugin)
    args = main.parser.parse_args(['https://httpbin.org/get'])
    # noinspection PyProtectedMember
    args.auth_plugin = plugin_manager.get

# Generated at 2022-06-23 18:48:48.150627
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': 'LORD',
        'url': 'http://127.0.0.1:1234',
        'headers': {'Host': '127.0.0.1'},
        'data': 'data'
    }
    dump_request(kwargs)
    kwargs['params'] = 'param'
    dump_request(kwargs)
    kwargs['params'] = {'param': 'param'}
    dump_request(kwargs)
    kwargs['auth'] = 'test'
    dump_request(kwargs)

# Generated at 2022-06-23 18:48:51.963243
# Unit test for function dump_request
def test_dump_request():
    kwargs = {"method": "GET", "url": "www.example.com", "data": b"test_data", "headers": {"User-Agent" : "bla"}}
    print(dump_request(kwargs))

# Generated at 2022-06-23 18:49:00.167514
# Unit test for function collect_messages

# Generated at 2022-06-23 18:49:06.356973
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import argparse
    args = argparse.Namespace()
    args.timeout = "100"
    args.allow_redirects = False
    kwargs = make_send_kwargs(args = args)
    assert kwargs == {
        'timeout': '100',
        'allow_redirects': False,
    }

if __name__ == "__main__":
    test_make_send_kwargs()

# Generated at 2022-06-23 18:49:14.128415
# Unit test for function collect_messages
def test_collect_messages():
    # Unit test for function collect_message
    args = argparse.ArgumentParser()
    args.session = "session1"
    args.session_read_only = None
    args.url = "https://github.com/httpie/httpie"
    args.headers = {'Host': 'github.com'}
    args.auth_plugin = "auth.BasicAuth"
    args.debug = False
    args.path_as_is = False
    args.compress = False
    args.offline = False
    args.max_redirects = None
    args.follow = False
    args.all = False
    args.timeout = None
    args.auth = None
    args.method = "GET"
    args.data = ""
    args.json = False
    args.form = False

# Generated at 2022-06-23 18:49:18.009502
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = ""
    request_body_read_callback = ""
    collect_messages(args, config_dir, request_body_read_callback)


# Generated at 2022-06-23 18:49:23.697764
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    path = os.path.dirname(os.path.abspath(__file__))
    config_dir = os.path.join(path, '../../httpie/config')
    gen = collect_messages(args, config_dir)
    while True:
        try:
            next(gen)
        except StopIteration:
            break

# Generated at 2022-06-23 18:49:34.540492
# Unit test for function build_requests_session
def test_build_requests_session():
    # test for function build_requests_session()
    cert = "cert"
    verify = "verify"
    ssl_version = "ssl_version"
    ciphers = "ciphers"

    requests_session = build_requests_session(verify=verify, ssl_version=ssl_version, ciphers=ciphers)
    assert isinstance(requests_session, requests.Session)

    # test for https adapter
    https_adapter = HTTPieHTTPSAdapter(ciphers=ciphers, verify=verify, ssl_version=ssl_version)
    assert isinstance(https_adapter, HTTPieHTTPSAdapter)

    https_adapter.cert_verify(cert, verify)

    # test for https connection 

# Generated at 2022-06-23 18:49:36.532105
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({'Agent': ' '})
    final_headers = finalize_headers(headers)
    assert final_headers == RequestHeadersDict()

# Generated at 2022-06-23 18:49:41.193979
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # TODO: Unit test fails, plugin should be mocked
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='http', value='127.0.0.1:8000')]
    args.cert = '~/cert.pem'
    args.cert_key = '~/key.pem'
    args.verify = 'yes'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['verify']
    assert kwargs['proxies']

# Generated at 2022-06-23 18:49:52.491670
# Unit test for function build_requests_session
def test_build_requests_session():
    """
    Test function build_requests_session
    :return: test result
    """
    import unittest
    import requests

    class TestBuildRequestSession(unittest.TestCase):
        """
        Class unit test build_requests_session
        """

        def test_build_requests_session(self):
            """
            Test function build_requests_session
            :return: test result
            """
            verify = True
            ssl_version = 'TLSv2'
            ciphers = None
            requests_session = build_requests_session(verify, ssl_version, ciphers)
            self.assertIsInstance(requests_session, requests.Session)

# Generated at 2022-06-23 18:50:03.315542
# Unit test for function make_default_headers
def test_make_default_headers():
    # Test headers if argument is : --json
    args = argparse.Namespace(json=True, data=None, form=False)
    headers = make_default_headers(args)
    assert 'Accept' in headers
    assert 'Content-Type' not in headers
    # Test headers if argument is : --json --data
    args = argparse.Namespace(json=True, data={}, form=False)
    headers = make_default_headers(args)
    assert 'Accept' in headers
    assert 'Content-Type' in headers
    # Test headers if argument is : --json --form
    args = argparse.Namespace(json=True, data={}, form=True)
    headers = make_default_headers(args)
    assert 'Accept' in headers
    assert 'Content-Type' not in headers
    # Test headers if argument

# Generated at 2022-06-23 18:50:05.587390
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=True,
        ssl_version=None,
        ciphers=None,
    )

# Generated at 2022-06-23 18:50:14.733872
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.json = True
    args.data = {'name': 'foo', 'age': 3, 'tel': '1234567'}
    args.method = 'POST'
    args.url = 'http://127.0.0.1:8000/accounts/'
    args.headers = {'X-AD-Key': '123456'}
    args.auth = 'username=admin,password=admin'
    args.params = {'p1': '000', 'p2': '123'}
    args.files = ''
    args.form = False
    args.verify = 'no'
    args.max_redirects = 1
    args.timeout = 2
    args.chunked = False
    args.offline = False
    args.compress = 1


# Generated at 2022-06-23 18:50:25.501199
# Unit test for function collect_messages

# Generated at 2022-06-23 18:50:33.576059
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # simple test for make_send_kwargs_mergeable_from_env
    # create a mock args
    args = argparse.Namespace()
    args.verify = True
    args.proxy = []
    args.cert = '1.crt'
    args.cert_key = '2.crt'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': '1.crt', 'key': '2.crt'}

# Generated at 2022-06-23 18:50:38.691820
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "http://www.baidu.com"
    args.headers = RequestHeadersDict()
    args.headers["User-Agent"] = "Mozilla/5.0"
    args.headers["Host"] = "www.baidu.com"

    args.compress = False
    args.form = False
    args.offline = False
    args.ciphers = False
    args.verify = "YES"
    args.files = None
    args.data = None
    args.session = None

    args.json = False
    args.auth = None

    print(make_request_kwargs(args))
    print(make_send_kwargs(args))

# Generated at 2022-06-23 18:50:41.380633
# Unit test for function finalize_headers
def test_finalize_headers():
    h = RequestHeadersDict({"Content-Type" : " application/json    "})
    assert finalize_headers(h) == RequestHeadersDict({"Content-Type" : "application/json"})

# Generated at 2022-06-23 18:50:53.658971
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    test_arg_namespace = argparse.Namespace()
    test_arg_namespace.headers = {}
    test_arg_namespace.files = ''
    test_arg_namespace.data = {}
    test_arg_namespace.json = ''
    test_arg_namespace.form = ''
    test_arg_namespace.path_as_is = ''
    test_arg_namespace.timeout = ''


    # Test (1)
    test_arg_namespace.method = 'GET'
    test_arg_namespace.url = 'http://example.com/api'

    kwargs = make_request_kwargs(args=test_arg_namespace)

    assert kwargs['method'] == 'get'
    assert kwargs['url'] == 'http://example.com/api'


# Generated at 2022-06-23 18:50:56.804072
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(argparse.Namespace()) == {'timeout': None, 'allow_redirects': False}

test_make_send_kwargs()

# Generated at 2022-06-23 18:51:07.568692
# Unit test for function collect_messages
def test_collect_messages():
    """
    This function is used to test function collect_messages,
    which is used to generate request and response message.

    Args:
        args: any arguments
        config_dir: the directory for config
        request_body_read_callback: the callback for request body reading
    """

# Generated at 2022-06-23 18:51:12.620251
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(0) == 0
    assert max_headers(1) == 1
    assert max_headers(2) == 2
    assert max_headers() is None
    assert max_headers(0,2) == 0
    assert max_headers(1,2) == 1
    assert max_headers(2,1) == 1


# Generated at 2022-06-23 18:51:16.154782
# Unit test for function dump_request
def test_dump_request():
    result = dump_request({'timeout': '30'})
    assert result == '\n>>> requests.request(**{\'timeout\': \'30\'})\n\n'

# Generated at 2022-06-23 18:51:28.509298
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.headers = {}
    args.chunked = False
    args.offline = False
    args.method = 'post'
    args.json = False
    args.url = 'https://desolate-journey-77427.herokuapp.com/'
    args.auth = None
    args.data = {'count': 1}
    args.files = None
    args.params = {}
    args.multipart = False
    args.form = False 
    args.multipart_data = []
    args.boundary = None
    request_kwargs = make_request_kwargs(args=args)
    assert request_kwargs['method'] == 'post'
    assert request_kwargs['url'] == args.url

# Generated at 2022-06-23 18:51:38.678199
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict()
    headers.add('User-Agent', 'HTTPie/')
    headers = finalize_headers(headers)
    assert headers['User-Agent'] == 'HTTPie/', headers['User-Agent']

    headers = RequestHeadersDict()
    headers.add('User-Agent', ' HTTPie/')
    headers = finalize_headers(headers)
    assert headers['User-Agent'] == 'HTTPie/', headers['User-Agent']

    headers = RequestHeadersDict()
    headers.add('User-Agent', 'HTTPie/ ')
    headers = finalize_headers(headers)
    assert headers['User-Agent'] == 'HTTPie/', headers['User-Agent']

    headers = RequestHeadersDict()
    headers.add('User-Agent', ' HTTPie/ ')
   

# Generated at 2022-06-23 18:51:45.391834
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class MockArgs(object):
        def __init__(self):
            self.proxy = []
            self.verify = True
            self.cert = 'file_path'
            self.cert_key = 'file_path'

    args = MockArgs()
    expected = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': ('file_path', 'file_path')
    }
    return make_send_kwargs_mergeable_from_env(args) == expected


# Generated at 2022-06-23 18:51:56.972141
# Unit test for function build_requests_session
def test_build_requests_session():
    """
    >>> requests_session = build_requests_session(
    ...     verify=True, ssl_version='sslv23', ciphers=''
    ... )
    >>> requests_session.adapters
    {'https://': <httpie.ssl.HTTPieHTTPSAdapter object at 0x000001D7B536F278>}
    >>> requests_session.mounts
    {'https://': [('httpie.ssl.HTTPieHTTPSAdapter', '')]}
    >>> requests_session.verify
    True
    >>> requests_session.cert
    None
    >>> requests_session.auth
    None
    >>> requests_session.proxies
    {}
    >>> requests_session.stream
    True
    """
    pass



# Generated at 2022-06-23 18:51:59.541031
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    import doctest
    (fails, total_tests) = doctest.testmod()
    print(f"{fails}/{total_tests} tests failed")

# Generated at 2022-06-23 18:52:05.108856
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({"Content-Type": "   application/json"}) == {"Content-Type": "application/json"}
    assert finalize_headers({"Content-Type": "application/json    "}) == {"Content-Type": "application/json"}
    assert finalize_headers({"Content-Type": " application/json "}) == {"Content-Type": "application/json"}

# Generated at 2022-06-23 18:52:13.533853
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.verify = 'yes'
    args.cert = None
    args.cert_key = None
    args.proxy = [
        argparse.Namespace(key="http_proxy", value="http://192.168.1.1:3128"),
        argparse.Namespace(key="https_proxy", value="http://192.168.1.1:3128")
    ]
    args.stream = True
    args.cert = None
    args.verify = 'yes'
    args.data = '{}'

    make_request_kwargs(args)

# Generated at 2022-06-23 18:52:21.182649
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import argparse

    args = argparse.Namespace(
        data=None,
        files=None,
        json=False,
        form=[],
        multipart_data=[],
        boundary=None,
        chunked=False,
        offline=False,
        headers=[],
        max_headers=float('inf')
    )

    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] is None
    assert not kwargs['allow_redirects']

    # Add some values to the args
    args.timeout = 15
    args.allow_redirects = True
    args.proxy = [
        argparse.Namespace(key="http", value="localhost:8000"),
        argparse.Namespace(key="https", value="localhost:8001")
    ]
    args

# Generated at 2022-06-23 18:52:25.769324
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 1
    args = argparse.Namespace(max_headers=10)
    with max_headers(args.max_headers):
        assert http.client._MAXHEADERS == args.max_headers
    assert http.client._MAXHEADERS == 1


# Generated at 2022-06-23 18:52:31.947414
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = None
    args.verify = "yes"
    args.cert = None

    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }

# Generated at 2022-06-23 18:52:42.351182
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Setup
    args = ['-v']

# Generated at 2022-06-23 18:52:51.837368
# Unit test for function build_requests_session
def test_build_requests_session():
    import os
    import requests
    skip_env_vars = ['REQUESTS_CA_BUNDLE', 'CURL_CA_BUNDLE']
    for k in skip_env_vars:
        if k in os.environ:
            del os.environ[k]
    from httpie.client import build_requests_session
    verify = True
    ssl_version = 'SSLv2'
    ciphers = 'NULL'
    r = build_requests_session(verify, ssl_version, ciphers)
    r2 = requests.Session()
    url = 'https://httpbin.org/get'
    assert r.get(url)
    assert r2.get(url).status_code == 200



# Generated at 2022-06-23 18:52:56.526038
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {
        'User-Agent': 'HTTPie/1.0.2',
        'Content-Type': 'application/json',
    }
    final_headers = finalize_headers(headers)
    assert final_headers['User-Agent'] == 'HTTPie/1.0.2'
    assert final_headers['Content-Type'] == 'application/json'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:53:05.355175
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = None
    args.verify = True
    args.offline = False
    args.cert = "~/.config/httpie/cert.pem"
    args.cert_key = "~/.config/httpie/key.pem"
    result = make_send_kwargs_mergeable_from_env(args)
    assert result["proxies"] == {}
    assert result["verify"] ==True
    assert result["cert"] ==  "~/.config/httpie/cert.pem"
    assert result["key"] == "~/.config/httpie/key.pem"



# Generated at 2022-06-23 18:53:15.375853
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:53:23.086959
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():

    assert ensure_path_as_is(
        'http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

    assert ensure_path_as_is(
        'http://foo?a=/..', 'http://foo/?foo=bar') == 'http://foo/?a=/..&foo=bar'

    assert ensure_path_as_is(
        'http://foo/?a=/..', 'http://foo/bar/') == 'http://foo/?a=/..&bar'

# Generated at 2022-06-23 18:53:32.302689
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-23 18:53:36.358608
# Unit test for function build_requests_session
def test_build_requests_session():
    ssl_version = "SSLV3"
    ciphers = "AES:SHA"
    verify = True
    requests_session = build_requests_session(verify, ssl_version, ciphers)
    assert requests_session.mounts.__len__() == 2

# Generated at 2022-06-23 18:53:39.673292
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # args = argparse.Namespace(timeout=10, allow_redirects=False)
    # ret = make_send_kwargs(args)
    # assert ret == {'timeout': 10, 'allow_redirects': False}
    pass

# Generated at 2022-06-23 18:53:47.228095
# Unit test for function finalize_headers
def test_finalize_headers():
    final_headers = finalize_headers({})
    assert final_headers == {}
    final_headers = finalize_headers({"key": None})
    assert final_headers == {}
    final_headers = finalize_headers({"key": "value"})
    assert final_headers == {"key": "value"}
    final_headers = finalize_headers({"key": " value "})
    assert final_headers == {"key": "value"}
    final_headers = finalize_headers({"key": "value1", "key": "value2"})
    assert final_headers == {"key": "value2"}
    final_headers = finalize_headers({" key ": " value "})
    assert final_headers == {b" key ": b" value "}

# Generated at 2022-06-23 18:53:57.425244
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    class Namespace(object):
        def __init__(self):
            self.url = 'URL'
            self.session = None
            self.session_read_only = None
            self.headers = {}
            self.debug = False
            self.path_as_is = False
            self.compress = False
            self.offline = False
            self.max_headers = 0
            self.max_redirects = 0
            self.follow = False
            self.all = False
            self.auth_plugin = None
            self.cert = None
            self.cert_key = None
            self.ciphers = None
            self.verify = None
            self.proxy = []
            self.ssl_version = None
            self.timeout = None

# Generated at 2022-06-23 18:54:07.967432
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(verify=True, ssl_version="tlsv1_2")
    assert requests_session.verify is not False
    requests_session = build_requests_session(verify=False, ssl_version="tlsv1_2")
    assert requests_session.verify is False
    if 'tlsv1_2' in AVAILABLE_SSL_VERSION_ARG_MAPPING:
        request_adapter = requests_session.get_adapter("https://")
        assert request_adapter.ssl_version == AVAILABLE_SSL_VERSION_ARG_MAPPING["tlsv1_2"]
        assert request_adapter.ciphers is None

# Generated at 2022-06-23 18:54:14.590262
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Setup
    test_args = argparse.Namespace()
    test_args.timeout = 200
    test_args.allow_redirects = False

    # Exercise
    test_result = make_send_kwargs(test_args)

    # Verify
    assert test_result == {'timeout': test_args.timeout or None, 'allow_redirects': False}

    # Cleanup - none necessary
    pass


# Generated at 2022-06-23 18:54:20.969781
# Unit test for function build_requests_session
def test_build_requests_session():
    http_adapter = HTTPieHTTPSAdapter(
        ciphers = "ECDHE-RSA-AES128-GCM-SHA256",
        verify  = True,
        ssl_version = "TLSv1.2"
    )

    requests_session = build_requests_session(True, "TLSv1.2", "ECDHE-RSA-AES128-GCM-SHA256")

    assert requests_session.mounts == {"https://": http_adapter}
    assert requests_session.mount('https://', http_adapter)


# Generated at 2022-06-23 18:54:23.950061
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = finalize_headers({'letf':'   left','right':'right','empty':''})
    assert headers['letf'] == 'left'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:54:26.583431
# Unit test for function max_headers
def test_max_headers():
    try:
        with max_headers(5):
            assert http.client._MAXHEADERS == 5
    except:
        assert False, 'max_headers context manager failed'

# Generated at 2022-06-23 18:54:36.353182
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class Args:
        def __init__(self):
            self.proxy = []
            self.verify = 1
            self.cert = ''
            self.cert_key = ''
    args = Args()
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {},
                                                          'stream': True,
                                                          'verify': 1,
                                                          'cert': None}
    class Args:
        def __init__(self):
            self.proxy = []
            self.verify = 'true'
            self.cert = 'mycert'
            self.cert_key = 'mycert_key'
    args = Args()

# Generated at 2022-06-23 18:54:41.932926
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(ssl_version='TLSv1.2', verify=True)
    assert 'https' in dict(requests_session.adapters)
    https_adapter = requests_session.adapters['https://']
    assert isinstance(https_adapter, HTTPieHTTPSAdapter)

# Generated at 2022-06-23 18:54:50.889149
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
    import argparse

    # create args
    args = argparse.Namespace()
    args.chunked = False
    args.json = False
    args.p = False
    args.ciphers = None
    args.verify = argparse.Namespace()
    args.verify.lower = lambda: "false"
    args.files = False
    args.data = {'message': 'hello world!'}
    args.multipart = False
    args.form = False
    args.method = 'PUT'
    args.proxy = [argparse.Namespace(key='http', value='127.0.0.1:8080'),
                  argparse.Namespace(key='https', value='127.0.0.1:8080')]

# Generated at 2022-06-23 18:55:03.090854
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class NamespaceMock(object):
        def __init__(self, cert=None, cert_key=None, proxy=None, verify=True,
                     timeout=100, allow_redirects=False):
            self.cert = cert
            self.cert_key = cert_key
            self.proxy = proxy
            self.verify = verify
            self.timeout = timeout
            self.allow_redirects = allow_redirects

    assert (make_send_kwargs(NamespaceMock()) ==
            {'timeout': 100, 'allow_redirects': False})
    assert (make_send_kwargs(NamespaceMock(cert='test_cert')) ==
            {'timeout': 100, 'allow_redirects': False, 'cert': 'test_cert'})

# Generated at 2022-06-23 18:55:04.546844
# Unit test for function build_requests_session
def test_build_requests_session():
    x = build_requests_session(verify=False)
    assert x

# Generated at 2022-06-23 18:55:15.087715
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = bool('yes')
    session = build_requests_session(verify, ssl_version='sslv3', ciphers=None)
    assert (session.verify == True)
    assert (session.adapters['https://'].ssl_version == 0)
    assert (session.adapters['https://'].ciphers == None)
    session = build_requests_session(verify, ssl_version=None, ciphers=None)
    assert (session.verify == True)
    assert (session.adapters['https://'].ssl_version == None)
    assert (session.adapters['https://'].ciphers == None)


# Generated at 2022-06-23 18:55:18.135675
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(argparse.Namespace(timeout=10,follow=True)) == {'timeout': 10, 'allow_redirects': False}

# Generated at 2022-06-23 18:55:23.185215
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers(RequestHeadersDict({
        'Host': 'foo.com',
        'User-Agent': f'HTTPie/{__version__}',
        'Content-Type': 'application/json'
    })) == {b'Host': b'foo.com', b'User-agent': b'HTTPie/1.0.0', b'Content-type': b'application/json'}

# Generated at 2022-06-23 18:55:33.155818
# Unit test for function collect_messages
def test_collect_messages():
    class FakeSession:
        def __init__(self):
            self.cookies = ''
            self.headers = {}
            self.auth = {}
    
    class FakeArgparse:
        class Namespace:
            print('hi')
            pass
    requests_session = requests.Session()
    args = FakeArgparse.Namespace()
    args.method = 'POST'
    args.url = 'http://www.example.com'
    args.headers = {'Header1': 'Value1', 'Header2': 'Value2'}
    args.data = [1,2,3,4]
    args.json = True
    args.form = True
    args.files = True
    args.multipart = True
    args.multipart_data = {'Name': 'Tom', 'Age': '20'}


# Generated at 2022-06-23 18:55:37.239033
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('https://httpie.org/../../', 'https://httpie.org/?foo=bar') == 'https://httpie.org/../../?foo=bar'

# Generated at 2022-06-23 18:55:39.051609
# Unit test for function dump_request
def test_dump_request():
    print(dump_request({'method': 'GET', 'url': 'http://example.com'}))



# Generated at 2022-06-23 18:55:48.037714
# Unit test for function make_default_headers
def test_make_default_headers():
    import json
    import requests

    request_content = {
        'user': {
            'name': 'toto',
            'age': '10'
        }
    }
    
    req_header = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }

    resp_header = {
        'Content-Length': '57',
        'Content-Type': 'application/json; charset=utf-8'
    }
    
    args = argparse.Namespace(
        data=request_content,
        files=None,
        params=dict(),
        url="http://localhost:8080",
        method="POST",
        json=True,
        form=False
    )

    def test_make_request_kwargs():
        request_kwargs = make

# Generated at 2022-06-23 18:55:58.541527
# Unit test for function collect_messages
def test_collect_messages():
    #test for function collect_messages
    import argparse
    import httpie
    import requests
    import tempfile
    import os
    import types
    import json
    import utils
    config_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:56:05.032557
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'method': 'GET', 'url': 'http://foo.com', 'headers': {'Accept': 'text', 'Content-Type': 'text'},
              'data': '', 'auth': 'na', 'params': {'a': 1, 'b': 2}, 'stream': True, 'verify': False, 'cert': 'na'}
    dump_request(kwargs)

# Generated at 2022-06-23 18:56:11.357473
# Unit test for function dump_request
def test_dump_request():
    print(make_request_kwargs(get_args(['GET','http://www.google.com','--debug'])))
    print(make_send_kwargs(get_args(['GET','http://www.google.com','--debug'])))
    print(make_send_kwargs_mergeable_from_env(get_args(['GET','http://www.google.com','--debug'])))


# Generated at 2022-06-23 18:56:17.928188
# Unit test for function finalize_headers
def test_finalize_headers():
    # Filter None value
    headers = RequestHeadersDict({ 'X-Auth': None })
    assert 0 == len(finalize_headers(headers))

    # Test isinstance
    headers = RequestHeadersDict({ 'X-Auth': 'xxx' })
    assert 'xxx' == finalize_headers(headers)['X-Auth']

    # Test value.strip()
    headers = RequestHeadersDict({ 'X-Auth': '   xxx' })
    assert 'xxx' == finalize_headers(headers)['X-Auth']

# Generated at 2022-06-23 18:56:28.326397
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = ""
    args.timeout = None
    args.form = False
    args.session = None
    args.json = None
    args.auth_plugin = None
    args.auth = None
    args.debug = False
    args.max_redirects = 0
    args.follow = False
    args.max_headers = 0
    args.header = []
    args.headers = RequestHeadersDict()
    headers = make_default_headers(args)
    assert headers == RequestHeadersDict({'User-Agent': DEFAULT_UA})
    args.json = True
    args.data = {'a': 1}
    headers = make_default_headers(args)

# Generated at 2022-06-23 18:56:40.534502
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Setup
    args = argparse.Namespace()
    args.proxy = []
    args.proxy.append(argparse.Namespace())
    args.proxy[0].key = 'key'
    args.proxy[0].value = 'value'
    args.proxy.append(argparse.Namespace())
    args.proxy[1].key = 'key2'
    args.proxy[1].value = 'value2'
    args.cert = 'certificate.pem'
    args.cert_key = 'key.pem'
    args.verify = "true"

    # Execute
    kwargs = make_send_kwargs_mergeable_from_env(args)

    # Verify
    assert kwargs['proxies'] == {'key': 'value', 'key2': 'value2'}

# Generated at 2022-06-23 18:56:46.710658
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=[], verify=True, cert=None, cert_key=None)
    actual = make_send_kwargs_mergeable_from_env(args)
    expected = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    assert actual == expected

# Generated at 2022-06-23 18:56:52.050884
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from . import parser

    args = parser.parse_args(['--verify=true'])
    res = make_send_kwargs_mergeable_from_env(args)
    assert res['verify'] is True

    args = parser.parse_args(['--verify=false'])
    res = make_send_kwargs_mergeable_from_env(args)
    assert res['verify'] is False

    args = parser.parse_args(['--verify=bogus', '--ignore-stdin'])
    res = make_send_kwargs_mergeable_from_env(args)
    assert res['verify'] == 'bogus'

# Generated at 2022-06-23 18:57:00.930999
# Unit test for function max_headers
def test_max_headers():
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 100
    with max_headers(50):
        # noinspection PyUnresolvedReferences
        assert http.client._MAXHEADERS == 50
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 100
    with max_headers(None):
        # noinspection PyUnresolvedReferences
        assert http.client._MAXHEADERS == float('Inf')
    # noinspection PyUnresolvedReferences
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:57:06.078646
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 1
    args.cert = 'abc'
    args.cert_key = 'abc'

    expected_kwargs = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': ('abc', 'abc')
    }

    assert make_send_kwargs_mergeable_from_env(args) == expected_kwargs


# Generated at 2022-06-23 18:57:09.501909
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace(url = "http://httpbin.org/get?test=test")
    config_dir = "C:/Users/anand88/Documents/PythonProjects/httpie/httpie"
    for msg in collect_messages(args, config_dir):
        pass

if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-23 18:57:13.493467
# Unit test for function max_headers
def test_max_headers():
    args = argparse.Namespace()
    args.headers = ['456','123']
    config_dir = Path()
    (request_kwargs, send_kwargs) = collect_messages(args, config_dir)
    assert request_kwargs['headers'] == ['123', '456']

# Generated at 2022-06-23 18:57:21.356604
# Unit test for function dump_request
def test_dump_request():
    sys.argv = ['http', 'http://localhost:8080/getUser']
    args = parser.parse_args()
    config_dir = Path(__file__).parent / 'config'
    messages = collect_messages(args, config_dir)
    for message in messages:
        if isinstance(message, requests.PreparedRequest):
            dump_request()
        elif isinstance(message, requests.Response):
            print(message.request)
        else:
            print(message)

# Generated at 2022-06-23 18:57:23.130295
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session(verify=False, ciphers=None, ssl_version=None)

# Generated at 2022-06-23 18:57:31.347268
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import datetime
    args = argparse.Namespace()
    args.timeout = datetime.datetime.now()
    args.allow_redirects = False
    assert len(make_send_kwargs(args)) == 2
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == args.timeout
    assert kwargs['allow_redirects'] == args.allow_redirects


# Generated at 2022-06-23 18:57:40.052827
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.follow = True
    args.max_redirects = True
    args.timeout = True
    args.verify = True
    args.cert = True
    args.cert_key = True
    args.proxy = [True]
    args.stream = True 
    assert make_send_kwargs(args) == {
        'allow_redirects': False,
        'timeout': True,
    }
    assert make_send_kwargs_mergeable_from_env(args) == {
        'cert': True,
        'proxies': {True: True},
        'stream': True,
        'verify': True,
    }

# Generated at 2022-06-23 18:57:45.608147
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = "cert.pem"
    args.cert_key = "key.pem"
    args.proxy = (("https", "https://httpbin.org"),)
    args.verify = "no"
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert 'cert' in kwargs
    assert kwargs['cert'] == ("cert.pem", "key.pem")
    assert 'proxies' in kwargs
    assert 'https' in kwargs['proxies']
    assert 'https://httpbin.org' == kwargs['proxies']['https']
    assert 'verify' in kwargs
    assert kwargs['verify'] is False

# Generated at 2022-06-23 18:57:48.887235
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../',
                             'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../',
                             'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../',
                             'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:57:58.458923
# Unit test for function dump_request