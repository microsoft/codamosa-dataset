

# Generated at 2022-06-23 18:48:00.123840
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    json_data = b'{"name":"ramazan"}'
    plain_data = b"hello"
    args = argparse.Namespace(
        args=[],
        auth=None,
        chunked=False,
        follow=True,
        form=False,
        json=True,
        max_headers=0,
        method="POST",
        offline=False,
        path_as_is=False,
        proxy=None,
        chunked=False,
        verify=True,
        headers={'Content-Type': 'application/json'},
        data={},
        url="http://localhost:8080",
        files={},
        timeout=60,
        max_redirects=5,
    )

# Generated at 2022-06-23 18:48:07.685985
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'key1': "   value1", 'key2': "   value2"}
    result = finalize_headers(headers)
    assert result['key1'] == 'value1'
    assert result['key2'] == 'value2'
    assert result['key1'] == "value1"
    assert result['key2'] == "value2"

# Unit tests for function make_default_headers

# Generated at 2022-06-23 18:48:15.063458
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        proxy=['1.1.1.1:3128'],
        verify='no',
        cert=None,
        cert_key=None
    )

    assert make_send_kwargs_mergeable_from_env(
        args=args) == {
            'proxies': {'http': '1.1.1.1:3128', 'https': '1.1.1.1:3128'},
            'stream': True, 'verify': False, 'cert': None
        }

# Generated at 2022-06-23 18:48:27.300361
# Unit test for function dump_request
def test_dump_request():
    from httpie.compat import is_windows

    def exploit_request(args, config_dir, request_body_read_callback):
        for request in collect_messages(args, config_dir, request_body_read_callback):
            pass

    class args:
        url = "http://httpbin.org/get"
        headers = {}
        method = "GET"
        data = ""
        json = False
        form = ""
        files = ""
        auth = ""
        auth_plugin = ""
        params = ""
        verify = ""
        cert = ""
        cert_key = ""
        timeout = ""
        chunked = False
        debug = True
        offline = False
        stream = False
        follow = False
        max_redirects = ""
        all = False
        config_dir = ""
        session

# Generated at 2022-06-23 18:48:33.530142
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=5.5,
        allow_redirects=False
    )
    kwargs_expected = {
        'timeout': 5.5,
        'allow_redirects': False,
    }
    kwargs_actual = make_send_kwargs(args)
    assert kwargs_expected == kwargs_actual



# Generated at 2022-06-23 18:48:38.474650
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    request_kwargs = make_request_kwargs(args)
    assert request_kwargs['method'] == 'get'
    assert request_kwargs['url'] == None
    assert request_kwargs['headers'] == {'User-Agent': 'HTTPie/1.0.3'}
    assert request_kwargs['data'] == None
    assert request_kwargs['auth'] == None
    assert request_kwargs['params'] == ()

# Generated at 2022-06-23 18:48:50.112677
# Unit test for function dump_request
def test_dump_request():
    """
    Unit test for function dump_request
    :return:
    """
    args = argparse.Namespace()
    args.verify = True
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })

# Generated at 2022-06-23 18:48:51.728804
# Unit test for function max_headers
def test_max_headers():
    res = max_headers(5)
    assert res == 5

# Generated at 2022-06-23 18:49:00.007362
# Unit test for function build_requests_session
def test_build_requests_session():
    """
    Test the build_requests_session function with different inputs
    """
    assert build_requests_session(False, 'TLSv1', 'DEFAULT') is not None, 'Function failed'
    assert build_requests_session(True, 'SSLv3', 'RC4-SHA') is not None, 'Function failed'
    assert build_requests_session(False, 'SSLv2') is not None, 'Function failed'
    assert build_requests_session(False, 'TLSv1.2') is not None, 'Function failed'
    assert build_requests_session(False, 'TLSv1.1') is not None, 'Function failed'
    assert build_requests_session(False, 'TLSv1') is not None, 'Function failed'



# Generated at 2022-06-23 18:49:10.353944
# Unit test for function make_default_headers
def test_make_default_headers():
    '''
    Test function make_default_headers

    :return:
    '''
    args = argparse.Namespace()
    args.json = True
    args.data = True
    args.form = True
    args.files = True

    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    args.json = False
    args.data = [1, 2, 3]
    args.form = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE

# Generated at 2022-06-23 18:49:22.299756
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.chunked = 1
    args.method = 'GET'
    args.url = 'www.google.com'
    args.headers = RequestHeadersDict()
    args.data = ''
    args.form = False
    args.offline = False
    args.json = False
    args.multipart = False
    args.params = ''
    args.debug = True
    args.auth = ''
    args.verify = False
    args.files = ''
    args.cert = ''
    args.cert_key = ''
    args.max_redirects = ''
    args.proxy = ''
    args.timeout = ''
    args.follow = False
    args.all = False
    args.session = ''
    args.session_read_only = ''

# Generated at 2022-06-23 18:49:32.400087
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:49:39.807017
# Unit test for function build_requests_session
def test_build_requests_session():
    test_cases = [
        # verify: bool, ssl_version: str, ciphers: str, expected_ciphers
        (True, None, None, None),
        (False, None, None, None),
        (True, 'TLSv1_2', None, None),
        (False, 'TLSv1_2', None, None),
        (True, None, 'AES128-SHA', 'AES128-SHA'),
        (False, None, 'AES128-SHA', 'AES128-SHA'),
        (True, 'TLSv1_2', 'AES128-SHA', 'AES128-SHA'),
        (False, 'TLSv1_2', 'AES128-SHA', 'AES128-SHA')
    ]

# Generated at 2022-06-23 18:49:51.950986
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.data = True
    args.form = True
    args.files = True
    args.multipart = True
    args.multipart_data = True
    args.boundary = True
    args.headers = RequestHeadersDict({
        "User-Agent": "HTTPie/0.9.8",
        "Accept": "application/json, */*;q=0.5"
    })
    assert make_default_headers(args) == RequestHeadersDict({
        "User-Agent": "HTTPie/0.9.8",
        "Accept": "application/json, */*;q=0.5",
        "Content-Type": "application/json"
    })


# Generated at 2022-06-23 18:49:59.522221
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import argparse
    arg = argparse.Namespace()
    arg.proxy = [argparse.Namespace(key='http://localhost/', value='foo')]
    arg.verify = 'no'
    arg.cert = 'foo'
    arg.cert_key = 'foo'
    res = make_send_kwargs_mergeable_from_env(arg)
    assert res['proxies'] == {'http://localhost/': 'foo'}
    assert res['verify'] == False
    assert res['cert'] == 'foo'

# Generated at 2022-06-23 18:50:09.318936
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args_local = argparse.Namespace()
    args_local.proxy = None
    args_local.verify = 'True'
    args_local.cert = None
    kwargs_local = make_send_kwargs_mergeable_from_env(args_local)
    assert kwargs_local['proxies'] is None
    assert kwargs_local['verify'] is True
    assert kwargs_local['cert'] is None

    args_local.proxy = 'http=localhost:8080'
    args_local.proxy_any = None
    args_local.verify = 'False'
    args_local.cert = 'localhost.pem'
    args_local.cert_key = 'localhost.key'
    kwargs_local = make_send_kwargs_mergeable_from_

# Generated at 2022-06-23 18:50:11.063230
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    kwargs=make_send_kwargs(argparse.Namespace(timeout=10))
    assert kwargs['timeout']==10


# Generated at 2022-06-23 18:50:13.863329
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:50:20.288826
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'cacert.pem'
    args.cert = False
    args.cert_key = False
    kwargs = make_send_kwargs_mergeable_from_env(args)

    assert kwargs == {
        'proxies': {},
        'stream': True,
        'verify': 'cacert.pem',
        'cert': False
    }


# Generated at 2022-06-23 18:50:30.893052
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Case verify as True
    args1 = argparse.Namespace()
    args1.verify = 'yes'
    args1.proxy = [argparse.Namespace(key='http', value='127.0.0.1:3128')]
    args1.cert = '/tests/data/cert.pem'
    args1.cert_key = '/tests/data/key.pem'
    kwargs1 = make_send_kwargs_mergeable_from_env(args=args1)

    assert kwargs1['verify'] is True
    assert kwargs1['proxies'] == {'http': '127.0.0.1:3128'}
    assert kwargs1['cert'] == '/tests/data/cert.pem'
    assert kwargs1['cert_key']

# Generated at 2022-06-23 18:50:40.710874
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        json = False,
        form = False,
        data = False
    )
    default_headers = make_default_headers(args)
    assert type(default_headers) == RequestHeadersDict
    assert 'Accept' not in default_headers

    args = argparse.Namespace(
        json = True,
        form = False,
        data = False
    )
    default_headers = make_default_headers(args)
    assert type(default_headers) == RequestHeadersDict
    assert default_headers['Accept'] == 'application/json, */*;q=0.5'


# Generated at 2022-06-23 18:50:52.862052
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {"Content-Type": "application/json", "Host": "httpbin.org"}
    final_headers = finalize_headers(headers)
    assert "Content-Type" in final_headers
    assert "Host" in final_headers
    assert "application/json" in final_headers["Content-Type"]
    assert "httpbin.org" in final_headers["Host"]

    headers = {"Content-Type": " application/json ", "Host": " httpbin.org "}
    final_headers = finalize_headers(headers)
    assert "Content-Type" in final_headers
    assert "Host" in final_headers
    assert "application/json" in final_headers["Content-Type"]
    assert "httpbin.org" in final_headers["Host"]

# Generated at 2022-06-23 18:51:05.391446
# Unit test for function collect_messages
def test_collect_messages():
    import requests
    import os

    config_dir = os.getcwd()+'/httpie/test_data'
    
    # 1. test --session
    test_args = ['-s','test_session']
    args = parse_args(test_args)
    for msg in collect_messages(args, config_dir, request_body_read_callback=None):
        assert type(msg) is requests.PreparedRequest
    test_args = ['-s','test_session','-o','--offline']
    args = parse_args(test_args)
    for msg in collect_messages(args, config_dir, request_body_read_callback=None):
        assert type(msg) is requests.PreparedRequest
        assert type(msg.url) is str

    # 2. test --session-read-only


# Generated at 2022-06-23 18:51:17.575077
# Unit test for function make_send_kwargs

# Generated at 2022-06-23 18:51:22.845991
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    orig_url = 'http://foo.bar.com/../'
    prepped_url = 'http://foo.bar.com/?foo=bar'
    result = ensure_path_as_is(orig_url, prepped_url)
    assert result == 'http://foo.bar.com/../?foo=bar'

# Generated at 2022-06-23 18:51:29.677627
# Unit test for function finalize_headers
def test_finalize_headers():
    # Test valid input
    result = finalize_headers({
        'Content-Type': 'application/json'
    })
    assert result == {'Content-Type': 'application/json'}

    # Test empty input
    result = finalize_headers({})
    assert result == {}

    # Test invalid input
    result = finalize_headers({
        'Content-Type': ''
    })
    assert result == {}

    # Test null input
    result = finalize_headers({
        'Content-Type': None
    })
    assert result == {}

# Generated at 2022-06-23 18:51:32.283453
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    if ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar':
        print('True')

#test_ensure_path_as_is()

# Generated at 2022-06-23 18:51:32.942305
# Unit test for function collect_messages
def test_collect_messages():
    assert False

# Generated at 2022-06-23 18:51:44.542596
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:51:47.822468
# Unit test for function collect_messages
def test_collect_messages():
    out = collect_messages(None, None)
    assert next(out) == "Executing..."
    assert next(out) == "Executing..."

# Generated at 2022-06-23 18:51:48.464215
# Unit test for function collect_messages
def test_collect_messages():
    pass

# Generated at 2022-06-23 18:51:51.463723
# Unit test for function build_requests_session
def test_build_requests_session():
    sess = build_requests_session(True)
    assert (isinstance(sess,requests.Session))


# Generated at 2022-06-23 18:51:54.498492
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert 'http://foo/../?foo=bar' == ensure_path_as_is(
        'http://foo/../', 'http://foo/?foo=bar')

# Generated at 2022-06-23 18:51:58.116485
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs(argparse.Namespace(timeout=3.3)) == {'timeout': 3.3,
                                                                 'allow_redirects': False}



# Generated at 2022-06-23 18:52:09.043862
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.utils import get_response_texts


# Generated at 2022-06-23 18:52:10.272741
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:52:15.137629
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 3
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    expected_kwargs = {
        'timeout': 3,
        'allow_redirects': False
    }
    if kwargs != expected_kwargs:
        raise Exception('Test failed: make_send_kwargs')



# Generated at 2022-06-23 18:52:24.854782
# Unit test for function dump_request

# Generated at 2022-06-23 18:52:33.770354
# Unit test for function dump_request
def test_dump_request():
    class FakeResponse:
        def __init__(self, headers):
            self.headers = headers
        def get(self, key, _):
            return self.headers[key]
    class FakeRequest:
        def __init__(self, headers):
            self.headers = FakeResponse(headers)
        def has_header(self, h):
            return h in self.headers.keys()
    req = FakeRequest({'Content-Type': 'application/json',
                       "Content-Length":2,
                       "Accept-Encoding": "gzip, deflate",
                       "Accept": "*/*",
                       "User-Agent":"python-requests/2.3.0 CPython/3.3.0",
                       "Connection":"keep-alive"})
    dump_request(req)

# Generated at 2022-06-23 18:52:40.683631
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(ssl_version='TLSv1.1', ciphers='RSA', verify=False)
    assert requests_session.mounts["https://"] == \
           [HTTPieHTTPSAdapter(ciphers='RSA', verify=False, ssl_version=ssl.PROTOCOL_TLSv1_1)]
    assert len(requests_session.mounts["https://"]) == 1

# Generated at 2022-06-23 18:52:50.588724
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = 1
    args.data = 1
    args.form = 1
    args.headers = ''
    headers = make_default_headers(args)
    assert(headers['User-Agent'] == DEFAULT_UA)
    assert(headers['Accept'] == JSON_ACCEPT)
    assert(headers['Content-Type'] == JSON_CONTENT_TYPE)
    args.json = ''
    args.data = ''
    args.form = ''
    headers = make_default_headers(args)
    assert(headers['User-Agent'] == DEFAULT_UA)
    assert(not headers['Accept'])
    assert(not headers['Content-Type'])
    args.form = 1
    headers = make_default_headers(args)

# Generated at 2022-06-23 18:52:55.298833
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    test_args = argparse.Namespace(verify='no', proxy=[])
    actual = make_send_kwargs_mergeable_from_env(test_args)
    expected = {'proxies': {}, 'stream': True, 'verify': False, 'cert': None}
    assert actual == expected

# Generated at 2022-06-23 18:52:58.138216
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    kwargs = make_send_kwargs(args)
    print(kwargs)


# Generated at 2022-06-23 18:53:04.546935
# Unit test for function max_headers
def test_max_headers():
    # TODO: This unit test fails; fix it
    # <https://github.com/httpie/httpie/issues/1110>
    import http.client
    def test_limiting():
        # A bunch of headers
        headers_str = '\r\n'.join(
            f'{k}: {k}' for k in range(http.client._MAXHEADERS + 10)
        )
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS < len(headers_str.splitlines())
        res = http.client.parse_headers(headers_str)
        # noinspection PyProtectedMember
        assert len(res._headers) == http.client._MAXHEADERS

    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = 42

# Generated at 2022-06-23 18:53:06.067117
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    collect_messages(args)

# Generated at 2022-06-23 18:53:11.430167
# Unit test for function make_default_headers
def test_make_default_headers():
    mock_args = argparse.Namespace()
    mock_args.data = {}
    mock_args.form = False
    mock_args.json = True
    expected_dict = {'Content-Type': 'application/json', 'Accept': 'application/json, */*;q=0.5', 'User-Agent': 'HTTPie/1.0.3'}
    assert make_default_headers(mock_args) == expected_dict


# Generated at 2022-06-23 18:53:17.056645
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    sys.argv = ['http', '--verify', 'yes', 'www.google.com']
    args = parser.parse_args()
    result = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    assert make_send_kwargs_mergeable_from_env(args) == result

# Generated at 2022-06-23 18:53:23.596029
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli.parser import get_parser
    parser = get_parser()
    args = parser.parse_args(['--method=GET', 'https://postman-echo.com/get'])
    for request, response in collect_messages(
        args, config_dir=None, request_body_read_callback=None
    ):
        assert (
            request.url == 'https://postman-echo.com/get'
            and response.status_code == 200
        )

# Generated at 2022-06-23 18:53:31.341112
# Unit test for function max_headers
def test_max_headers():
    assert(http.client._MAXHEADERS == 100)
    assert(isinstance(max_headers(100), contextmanager))
    with max_headers(100):
        assert(http.client._MAXHEADERS == 100)
    assert(http.client._MAXHEADERS == 100)
    assert(isinstance(max_headers(200), contextmanager))
    with max_headers(200):
        assert(http.client._MAXHEADERS == 200)
    assert(http.client._MAXHEADERS == 100)
    with max_headers(None):
        assert(http.client._MAXHEADERS == float('Inf'))
    assert(http.client._MAXHEADERS == 100)

# Generated at 2022-06-23 18:53:41.719471
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
    import random
    import re
    import string
    import urllib.parse

    def make_text(length):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))
    

# Generated at 2022-06-23 18:53:43.835448
# Unit test for function max_headers
def test_max_headers():
    with max_headers(2):
        assert http.client._MAXHEADERS == 2
    assert http.client._MAXHEADERS == 100


# Generated at 2022-06-23 18:53:56.092458
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    args = argparse.Namespace()
    args.headers = {}
    args.json = False
    args.offline = False
    args.url = 'http://localhost:8888/api/mock'
    args.chunked = False
    args.auth = False
    args.params = {}
    args.method = 'GET'
    args.data = 'hello httpie!'
    args.form = False
    args.files = False
    args.cert = False
    args.cert_key = False
    args.verify = True
    args.proxy = False
    args.multipart = False
    args.multipart_data = {}
    args.debug = False
    args.path_as_is = False
    args.compress = False
    args.json_pp = False


# Generated at 2022-06-23 18:54:02.167349
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie.cli.parser import get_parser
    args = get_parser().parse_args(
        ['request_kwargs', '--json', '--auth=foo:bar']
    )
    assert make_request_kwargs(args)['url'] == 'request_kwargs'
    assert make_request_kwargs(args)['headers']['Accept'] == JSON_ACCEPT
    assert make_request_kwargs(args)['auth'] == ('foo', 'bar')



# Generated at 2022-06-23 18:54:15.051720
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    import httpie

    dir_cwd = Path.cwd()
    config_dir = dir_cwd.joinpath('config')
    config_dir.mkdir(parents=True, exist_ok=True)

    ssl_version = 'SSLv23'

# Generated at 2022-06-23 18:54:24.024538
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'https://localhost'
    args.files = None
    args.json = False
    args.data = None
    args.form = False
    args.multipart = False
    args.headers = {}
    args.auth = None
    args.params = {}
    args.timeout = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.chunked = None
    args.compress = None
    args.compress_level = 6
    args.output = None
    args.stream = None
    args.all = False
    args.debug = False
    args.body_debug = False
    args.offline = False
   

# Generated at 2022-06-23 18:54:34.422036
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    verify_result = {'yes': True, 'true': True, 'no': False, 'false': False}.get('yes'.lower(), 'yes')
    cert_result = './server.crt'
    proxy_result = {'http': 'http://127.0.0.1:8888', 'https': 'https://127.0.0.1:8888'}
    args = argparse.Namespace(verify='yes', cert=cert_result, cert_key='', proxy='http://127.0.0.1:8888')
    kwargs = make_send_kwargs_mergeable_from_env(args=args)
    assert kwargs['verify'] is verify_result
    assert kwargs['cert'] == cert_result
    assert kwargs['proxies'] == proxy_result


# Generated at 2022-06-23 18:54:35.758992
# Unit test for function finalize_headers
def test_finalize_headers():
  pass

# Generated at 2022-06-23 18:54:46.649812
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    kwargs = make_request_kwargs({
        'data': "",
        'json': False,
        'form': False,
        'method': "GET",
        'url': "",
        'headers': {},
        'auth': [],
        'params': {},
        'files': False
    })
    assert kwargs == {
        'method': 'get',
        'url': '',
        'headers': {'User-Agent': 'HTTPie/0.1', 'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'},
        'data': b'',
        'auth': [],
        'params': []
    }



# Generated at 2022-06-23 18:54:54.145189
# Unit test for function collect_messages
def test_collect_messages():
    import httpie.cli.argtypes
    parser = argparse.ArgumentParser()
    group = parser.add_argument_group('group')
    httpie.cli.argtypes.KeyValueArgType().add_to_parser(group, '--header')
    httpie.cli.argtypes.KeyValueArgType(
        unquote_before=True).add_to_parser(group, '--data')
    args = parser.parse_args([
        '--data', 'a=hi', '--header', 'content-type:application/json', 'http://abc'
    ])
    config_dir = Path('./test_data')
    request_body_read_callback = lambda chunk: chunk

# Generated at 2022-06-23 18:54:55.556808
# Unit test for function max_headers
def test_max_headers():
    with max_headers(15):
        assert http.client._MAXHEADERS == 15

    assert http.client._MAXHEADERS != 15

# Generated at 2022-06-23 18:54:58.816340
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(
        orig_url='http://foo/../',
        prepped_url='http://foo/?foo=bar'
    ) == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:55:04.279199
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('https://foo/../', 'https://foo/?foo=bar') == 'https://foo/../?foo=bar'
    assert ensure_path_as_is('https://foo/../bar', 'https://foo/?foo=bar') == 'https://foo/../bar?foo=bar'
    assert ensure_path_as_is('http://foo/../bar', 'http://foo/?foo=bar') == 'http://foo/../bar?foo=bar'

# Generated at 2022-06-23 18:55:09.508488
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        ssl_version=None,
        ciphers=None,
        verify=True)
    try:
        requests_session.get("https://www.google.com")
    except:
        assert(False)
    assert(True)

# Generated at 2022-06-23 18:55:17.177460
# Unit test for function build_requests_session
def test_build_requests_session():
    config = lambda: None
    config.verify = 'test_data/test-ca-chain.pem'
    config.ciphers = 'test_data/test-ciphers.txt'
    config.ssl_version = 'TLSv1_0'
    config.proxy = []
    session = build_requests_session(
        verify=config.verify,
        ssl_version=config.ssl_version,
        ciphers=config.ciphers,
    )
    assert session is not None
    assert isinstance(session, requests.Session)
    assert len(session.adapters) == 1
    https_adapter = session.get_adapter('https://')
    assert isinstance(https_adapter, HTTPieHTTPSAdapter)
    assert https_adapter.verify == config.verify

# Generated at 2022-06-23 18:55:26.100452
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import io
    import sys
    orig_stdout = sys.stdout
    sys.stdout = io.StringIO()
    try:
        import httpie.cli.parser
    except ImportError:
        return

    parser = httpie.cli.parser.get_parser()
    args = parser.parse_args(['https://postman-echo.com/get'])
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'GET'
    assert kwargs['url'] == 'https://postman-echo.com/get'
    assert 'User-Agent' in kwargs['headers']
    assert kwargs['auth'] is None
    assert kwargs['params'] == []

    sys.stdout = orig_stdout

test_make_request_kwargs()

# Generated at 2022-06-23 18:55:27.384434
# Unit test for function dump_request
def test_dump_request():
    dump_request('kwargs')

# Generated at 2022-06-23 18:55:40.248836
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/bar?a=b', 'http://foo/?foo=bar') == 'http://foo/bar?foo=bar'
    assert ensure_path_as_is('http://foo/bar/', 'http://foo/?foo=bar') == 'http://foo/bar/?foo=bar'
    assert ensure_path_as_is('http://foo/bar/../baz', 'http://foo/?foo=bar') == 'http://foo/baz?foo=bar'
    assert ensure_path_as_is('http://foo/../bar/', 'http://foo/?foo=bar') == 'http://foo/../bar/?foo=bar'
    assert ensure_path_as_is('http://foo/bar', 'http://foo') == 'http://foo/bar'
    assert ensure_

# Generated at 2022-06-23 18:55:45.348531
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'key1': 'value1', 'key2': 'value2', 'key3': None, 'key4': ' v4'}
    res = finalize_headers(headers)
    assert res == {'key1': 'value1', 'key2': 'value2', 'key4': 'v4'}


if __name__ == '__main__':
    test_finalize_headers()

# Generated at 2022-06-23 18:55:47.959186
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 1000
    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:55:58.542598
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
    })
    assert (finalize_headers(headers) == {})

    headers = RequestHeadersDict({
        'Accept': 'json',
        'Host': 'www.example.com',
        'Content-Type': 'application/json',
        'Host': 'www.example.com'
    })
    assert (finalize_headers(headers) == {b'Accept': b'json', b'Content-Type': b'application/json', b'Host': b'www.example.com'})

    headers = RequestHeadersDict({
        'Host': '  www.example.com '
    })
    assert (finalize_headers(headers) == {b'Host': b'www.example.com'})


# Generated at 2022-06-23 18:55:59.547707
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    pass

# Generated at 2022-06-23 18:56:01.763594
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace(debug=False)
    kwargs = {}
    dump_request(kwargs)

# Generated at 2022-06-23 18:56:06.248782
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    #  assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    #  print(ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar'))

# Generated at 2022-06-23 18:56:09.060592
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:56:14.389450
# Unit test for function dump_request
def test_dump_request():
    dict = {
        'method':'GET',
        'url':'www.google.com',
        'headers': {
            'user-agent':'HTTPie/1.0',
            'Accept':'application/json, */*;q=0.5'
        }
    }
    dump_request(dict)
    assert True


# Generated at 2022-06-23 18:56:18.176639
# Unit test for function collect_messages
def test_collect_messages():
    from httpie import cli

    args = cli.parser.parse_args(['--verbose', 'https://httpbin.org/get'])
    config_dir = Path('./')
    for item in collect_messages(args=args, config_dir=config_dir):
        print(item)

# Generated at 2022-06-23 18:56:23.048323
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.data = {}
    default_headers = make_default_headers(args)
    assert 'Accept' in default_headers
    assert 'Content-Type' in default_headers

# Generated at 2022-06-23 18:56:33.363887
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie import arguments

# Generated at 2022-06-23 18:56:43.254948
# Unit test for function collect_messages
def test_collect_messages():
    config_dir = Path.cwd().joinpath('.httpie')

# Generated at 2022-06-23 18:56:46.137485
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 1000
    with max_headers(100) as context:
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:56:48.028176
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    args.post = 'data'
    dump_request(kwargs=args)

# Generated at 2022-06-23 18:56:51.346143
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    r = make_send_kwargs(argparse.Namespace(timeout=None, allow_redirects=False))
    assert r['timeout'] == None
    assert r['allow_redirects'] == False


# Generated at 2022-06-23 18:56:57.988801
# Unit test for function finalize_headers
def test_finalize_headers():
    class Dummy: pass
    args = Dummy()
    args.headers = {'User-Agent': 'HTTPie/0.9.8',
                    'Accept': 'application/json, */*;q=0.5',
                    'Content-Type': 'application/json'}
    print(make_default_headers(args))
    print(finalize_headers(args.headers))

# Generated at 2022-06-23 18:57:03.821752
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    args.stream = True
    args.verify = 'False'
    args.cert = None
    args.proxies = {'https': 'http://127.0.0.1:9001'}
    assert make_send_kwargs(args) == {'timeout': args.timeout, 'allow_redirects': False}
    assert make_send_kwargs_mergeable_from_env(args) == {'proxies': {'https': 'http://127.0.0.1:9001'}, 'stream': True, 'verify': 'False', 'cert': None}


# Generated at 2022-06-23 18:57:09.346836
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=5,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout':5, 'allow_redirects':False}

# Generated at 2022-06-23 18:57:10.920451
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    make_send_kwargs_mergeable_from_env()

# Generated at 2022-06-23 18:57:13.637576
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://localhost/api/token', 'http://localhost:80/?param=value') == 'http://localhost/api/token?param=value'

# Generated at 2022-06-23 18:57:15.345484
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    assert repr_dict({'url': 'http://foo'}) == "{'url': 'http://foo'}"

# Generated at 2022-06-23 18:57:20.728694
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    setattr(args, 'timeout', None)
    setattr(args, 'allow_redirects', False)
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}

    setattr(args, 'timeout', 12345)
    setattr(args, 'allow_redirects', True)
    assert make_send_kwargs(args) == {'timeout': 12345, 'allow_redirects': True}


# Generated at 2022-06-23 18:57:28.357747
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='http', value='127.0.0.1')]
    args.verify = True
    args.cert = 'cert.cert'
    args.cert_key = 'cert.key'
    kwargs = make_send_kwargs_mergeable_from_env(args)

    assert(kwargs['proxies'] == {'http': '127.0.0.1'})
    assert(kwargs['stream'] == True)
    assert(kwargs['verify'] == True)
    assert(kwargs['cert'] == 'cert.cert')

# Generated at 2022-06-23 18:57:33.078027
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace
    args.timeout = 1  # default is None
    args.allow_redirects = False
    result = make_send_kwargs(args)
    print(result)


# Generated at 2022-06-23 18:57:36.950910
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-23 18:57:40.050281
# Unit test for function dump_request
def test_dump_request():
    args = []
    config_dir = []
    request_body_read_callback = []
    messages = collect_messages(args, config_dir, request_body_read_callback)
    dump_request(messages)

# Generated at 2022-06-23 18:57:47.503470
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    config = Path("config")

# Generated at 2022-06-23 18:57:57.484559
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    test_url_1 = 'http://foo/../'
    test_parsed_url_1 = urlparse(test_url_1)
    test_prepped_url_1 = 'http://foo/?foo=bar'
    test_parsed_prepped_url_1 = urlparse(test_prepped_url_1)
    test_d_urlt_1 = {
        # noinspection PyProtectedMember
        **test_parsed_prepped_url_1._asdict(),
        'path': test_parsed_url_1.path,
    }
    test_final_url_1 = urlunparse(tuple(test_d_urlt_1.values()))