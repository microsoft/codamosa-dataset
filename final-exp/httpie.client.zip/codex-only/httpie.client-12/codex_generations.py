

# Generated at 2022-06-23 18:48:01.112289
# Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-23 18:48:02.652546
# Unit test for function dump_request
def test_dump_request():
    assert 0

# Generated at 2022-06-23 18:48:08.991764
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

    args.timeout=5
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': 5, 'allow_redirects': False}



# Generated at 2022-06-23 18:48:12.780816
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=False,
        ssl_version='SSLv2',
        ciphers='AES')
    return requests_session.__class__.__name__


# Generated at 2022-06-23 18:48:19.924534
# Unit test for function make_default_headers
def test_make_default_headers():
    from httpie.input import ParseResult

# Generated at 2022-06-23 18:48:29.841462
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    args = Namespace(
        cert='/path/to/cert',
        cert_key='/path/to/cert_key',
        proxy=['foo bar}}'],
        verify='/path/to/cert',
        )
    expected_result = {
        'proxies': {'foo': 'bar}}'},
        'stream': True,
        'verify': '/path/to/cert',
        'cert': (
            '/path/to/cert',
            '/path/to/cert_key'
            )
        }
    result = make_send_kwargs_mergeable_from_env(args)
    assert result == expected_result, 'result :'+re

# Generated at 2022-06-23 18:48:38.982276
# Unit test for function max_headers
def test_max_headers():
    import http.client
    import socket
    import doctest;
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
    ##https://gist.github.com/satomacoto/2a73582a1f2e7fb22c258afc7af80d61
    from http.client import HTTPConnection
    from io import BytesIO
    from http.client import RemoteDisconnected
    from http.server import HTTPResponse, HTTPServer, BaseHTTPRequestHandler
    import threading

    class Responder(BaseHTTPRequestHandler):
        def do_GET(self):
            code = 200 if self.path.endswith("test") else 500
            resp = HTTPResponse(self.rfile, self.wfile, method=self.command)
            resp

# Generated at 2022-06-23 18:48:47.305501
# Unit test for function dump_request
def test_dump_request():
    headers = {'HOST': 'www.baidu.com', 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0'}
    request_kwargs = {
        'method': 'GET',
        'url': 'www.baidu.com',
        'headers': headers,
        'data': b'123456',
    }

    dump_request(request_kwargs)


# Entry function for unit test

# Generated at 2022-06-23 18:48:56.120798
# Unit test for function build_requests_session
def test_build_requests_session():
    verify_true = build_requests_session(verify=True)
    verify_false = build_requests_session(verify=False)
    ssl_none = build_requests_session(ssl_version=None)
    ssl_TLSv1 = build_requests_session(ssl_version='TLSv1')
    ciphers_default = build_requests_session(ciphers=None)
    ciphers_all = build_requests_session(ciphers='ALL')
    assert verify_true != verify_false
    assert ssl_none != ssl_TLSv1
    assert ciphers_default != ciphers_all


# Generated at 2022-06-23 18:49:05.240844
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = [argparse.Namespace(key='b', value='c')]
    args.verify = False
    args.cert = 'ca.crt'
    args.cert_key = 'ca.key'
    returned_dict = make_send_kwargs_mergeable_from_env(args)
    assert type(returned_dict) == dict
    assert returned_dict['proxies'] == {'b': 'c'}
    assert returned_dict['stream'] == True
    assert returned_dict['verify'] == False
    assert returned_dict['cert'] == 'ca.crt'


# Generated at 2022-06-23 18:49:07.340402
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    print(__file__)
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:49:14.640015
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.method = 'GET'
    args.url = 'http://foo.com/'
    args.headers = {'Accept-Encoding': '*'}
    args.data = {"foo": 'bar'}
    args.files = None
    args.json = False
    args.form = False
    args.compress = False
    args.max_redirects = None
    args.offline = False
    args.chunked = False
    args.timeout = None
    args.auth = None
    args.session = None
    args.session_read_only = None
    args.follow = False
    args.all = False
    args.params = {}
    args.upload = False
    args.verify = True
    args.proxy = []
    args.ssl

# Generated at 2022-06-23 18:49:17.549747
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {'timeout': None, 'allow_redirects': False}

# Generated at 2022-06-23 18:49:28.851119
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=False, form=False,
                       data=None, files=False, method='get')
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    args = argparse.Namespace(json=True, form=True,
                       data=None, files=False, method='get')
    headers = make_default_headers(args)
    assert headers['Accept'] == JSON_ACCEPT
    args = argparse.Namespace(json=False, form=True,
                       data=None, files=False, method='get')
    headers = make_default_headers(args)
    assert headers['Content-Type'] == FORM_CONTENT_TYPE

# Generated at 2022-06-23 18:49:34.130640
# Unit test for function build_requests_session
def test_build_requests_session():
    ssl_version = 'tlsv1'
    ciphers = 'ecdhe-rsa-aes128-gcm-sha256:ECDHE-RSA-AES256-SHA384:AES128-GCM-SHA256'
    verify = '1'
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=verify
    )

    return requests_session


# Generated at 2022-06-23 18:49:39.320581
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from configparser import ConfigParser
    from httpie.settings import ConfigProxy

    config_parser = ConfigParser()
    config_parser.add_section('default')
    config_parser.set('default', 'verify', 'yes')
    global__config = ConfigProxy(config_parser)

    args = argparse.Namespace(
        verify=global__config.verify,
    )

    send_kwargs = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs.get('verify') == 'yes'

# Generated at 2022-06-23 18:49:51.900656
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert {'proxies': {}, 'stream': True, 'verify': 'no', 'cert': None} == make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='no'))
    assert {'proxies': {}, 'stream': True, 'verify': 'yes', 'cert': None} == make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='yes'))
    assert {'proxies': {}, 'stream': True, 'verify': 'true', 'cert': None} == make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='true'))
    assert {'proxies': {}, 'stream': True, 'verify': 'false', 'cert': None} == make_send

# Generated at 2022-06-23 18:49:59.476450
# Unit test for function dump_request
def test_dump_request():
    """Unit test for function dump_request"""
    kwargs = {'method': 'post', 'url': 'http://example.com', 'headers': '{}', 'data': '{}', 'auth': '{}'}
    result = '\n>>> requests.request(**{\'method\': \'post\', \'url\': \'http://example.com\', \'headers\': \'{}\', \'data\': \'{}\', \'auth\': \'{}\'})\n\n'

    assert dump_request(kwargs) == result

# Generated at 2022-06-23 18:50:02.552378
# Unit test for function max_headers
def test_max_headers():
    import http.client
    import urllib3
    urllib3.disable_warnings()
    with max_headers(5):
        assert http.client._MAXHEADERS == 5

    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:50:11.225572
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    arg = argparse.Namespace()
    arg.cert = 'fakename'
    arg.cert_key = 'whatelse'
    proxy_name = "proxy_name"
    proxy_value = "http://example.com"
    arg.proxy = SimpleNamespace(key=proxy_name, value=proxy_value)
    arg.verify = "yes"

    to_check = make_send_kwargs_mergeable_from_env(arg)
    assert to_check['proxies'][proxy_name] == proxy_value
    assert to_check['cert'] == [arg.cert, arg.cert_key]
    assert to_check['verify'] == True
    assert to_check['stream'] == True


# Generated at 2022-06-23 18:50:11.849417
# Unit test for function collect_messages
def test_collect_messages():

    pass

# Generated at 2022-06-23 18:50:16.716067
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    headers = {
        'User-Agent': 'HTTPie/0.0.0'
    }
    response = make_request_kwargs(
        args=argparse.Namespace(
            method='GET',
            url='http://google.com',
            headers = headers,
            verify = True,
        )
    )
    assert response['url'] == 'http://google.com'
    assert response['method'] == 'get'

# Generated at 2022-06-23 18:50:20.055564
# Unit test for function collect_messages
def test_collect_messages():
    args = ['GET', '--headers="Content-Type: application/json"',
            'http://localhost:8200/v1/secret/dev', '-v']
    args = parser.parse_args(args)
    for request in collect_messages(args, './'):
        print(request)

# Generated at 2022-06-23 18:50:22.719933
# Unit test for function max_headers
def test_max_headers():
    """
    >>> import http.client
    >>> with max_headers(2):
    ...     assert http.client._MAXHEADERS == 2
    ...
    >>> assert http.client._MAXHEADERS != 2
    """

# Generated at 2022-06-23 18:50:33.578678
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': 'a',
        'Content-Length': '1   ',
        '  a': 'a',
        '  b': '   b ',
        'c': None,
        'd': '  ',
        'Host': u'\u2603.net',
        'e': 1,
        'f': 'f',
    })
    final_headers = finalize_headers(headers)
    assert final_headers['User-Agent'] == 'a'
    assert final_headers['Content-Length'] == '1'
    assert final_headers['a'] == 'a'
    assert final_headers['b'] == 'b'
    assert not final_headers.get('c')
    assert not final_headers.get('d')

# Generated at 2022-06-23 18:50:39.296262
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers(RequestHeadersDict({'Accept': 'text/plain'})) == RequestHeadersDict({'Accept': 'text/plain'})
    assert finalize_headers(RequestHeadersDict({'Accept': ' text/plain'})) == RequestHeadersDict({'Accept': 'text/plain'})


# Generated at 2022-06-23 18:50:49.599968
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'data': '', 'url': 'http://httpbin.org/get', 'headers': {'Content-Type': 'application/json'}, 'auth': None, 'method': 'GET', 'params': []}
    dump_request(kwargs)

if __name__ == '__main__':
    kwargs = {'data': '', 'url': 'http://httpbin.org/get', 'headers': {'Content-Type': 'application/json'}, 'auth': None, 'method': 'GET', 'params': []}
    dump_request(kwargs)

    # Run unit tests
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:50:58.740693
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:51:05.606962
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = '/home/user/cert.pem'
    args.cert_key = '/home/user/cert_key.pem'
    args.verify = 'yes'
    args.proxy = [argparse.Namespace(key='https', value='http://192.168.1.3:3128')]
    kwargs = make_send_kwargs_mergeable_from_env(args)
    print(kwargs)

# Generated at 2022-06-23 18:51:12.576130
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/bar', 'http://foo:81/bar') == 'http://foo:81/bar'
    assert ensure_path_as_is('http://foo/bar', 'http://foo/?foo=bar') == 'http://foo/bar?foo=bar'

# Generated at 2022-06-23 18:51:20.424662
# Unit test for function finalize_headers
def test_finalize_headers():
    args_headers_1 = RequestHeadersDict([('Accept', 'application/json'),
                                         ('User-Agent', 'httpie/1.0.3')])
    final_headers_1 = finalize_headers(args_headers_1)
    assert final_headers_1 is not None
    assert final_headers_1.as_list() == [('Accept', 'application/json'),
                                         ('User-Agent', 'httpie/1.0.3')]

# Generated at 2022-06-23 18:51:32.673828
# Unit test for function finalize_headers
def test_finalize_headers():
    """
    Test finalize headers
    """
    # remove leading and trailing white space
    headers = RequestHeadersDict()
    headers["User-Agent"] = ' HTTPie/1.0.0'
    headers["User-Agent"] = 'HTTPie/1.0.0 '

    final_headers = finalize_headers(headers)
    assert final_headers["User-Agent"] == b"HTTPie/1.0.0"

    # convert leading white space to utf-8 
    headers["User-Agent"] = 'HTTPie/1.0.0 '
    final_headers = finalize_headers(headers)
    assert final_headers["User-Agent"] == b"HTTPie/1.0.0 "

    # Do not convert non-leading white space

# Generated at 2022-06-23 18:51:36.813113
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'content-type': 'application/json'}
    return finalize_headers(headers)

print(test_finalize_headers())

# Generated at 2022-06-23 18:51:46.315157
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    """
    Unit test
    """
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/?foo=bar', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo?foo=bar', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo#foo=bar', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo/?foo=bar', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'

# Generated at 2022-06-23 18:51:49.799539
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == float('Inf')
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == float('Inf')

# Generated at 2022-06-23 18:52:01.369303
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Create mock objects
    arg_parser = argparse.ArgumentParser()

# Generated at 2022-06-23 18:52:04.584141
# Unit test for function make_default_headers
def test_make_default_headers():
    request_headers_dict = RequestHeadersDict()
    default_headers = make_default_headers(namespace)
    assert default_headers == request_headers_dict


# Generated at 2022-06-23 18:52:07.408339
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(verify='false')
    assert make_send_kwargs_mergeable_from_env(args)['verify'] == False

# Generated at 2022-06-23 18:52:16.979014
# Unit test for function make_default_headers
def test_make_default_headers():
    from httpie import ExitStatus
    from httpie.cli.parser import get_parser
    from httpie.core import main
    from httpie.plugins.builtin import JSONPlugin
    from httpie.plugins.registry import PluginRegistry
    from httpie.plugins.unicode import UnicodePlugin
    from httpie.utils import get_response_text
    import json
    import sys

    p = get_parser()
    data = {'a': True}
    args = p.parse_args([
        '--json',
        f'{data}'])
    args.data = data
    args.output_options = ['unicode']
    args.headers = {'Content-Type': 'application/json'}
    args.file_or_stdin = []
    args.output_options = []

# Generated at 2022-06-23 18:52:27.234880
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    assert make_default_headers(args) == {'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE, 'User-Agent': DEFAULT_UA}
    args.form = True
    assert make_default_headers(args) == {'Content-Type': FORM_CONTENT_TYPE, 'User-Agent': DEFAULT_UA}
    args.json = True
    assert make_default_headers(args) == {'Content-Type': JSON_CONTENT_TYPE, 'User-Agent': DEFAULT_UA}
    args.json = False
    assert make_default_headers(args) == {'Content-Type': FORM_CONTENT_TYPE, 'User-Agent': DEFAULT_UA}



# Generated at 2022-06-23 18:52:28.581622
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers(None) is None


# Generated at 2022-06-23 18:52:37.114320
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.__setattr__("url","www.baidu.com")
    args.__setattr__("method", "GET")
    args.__setattr__("json", True)
    args.__setattr__("data", {"a":1})
    headers = RequestHeadersDict()
    headers.__setitem__("Content-Type","application/json")
    args.__setattr__("headers", headers)
    request_kwargs = make_request_kwargs(args)
    print(request_kwargs)


# Generated at 2022-06-23 18:52:44.616066
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    def test_base_headers():
        args = argparse.Namespace()
        data = {'foo': 'bar'}
        base_headers = {'bar': 'foo'}
        res = make_request_kwargs(args, base_headers, None)
        assert 'data' not in res
        assert res['headers'] == base_headers

    def test_auth():
        args = argparse.Namespace(auth='foo')
        res = make_request_kwargs(args, None, None)
        assert res['auth'] == 'foo'

    def test_method():
        args = argparse.Namespace(method='GET')
        res = make_request_kwargs(args, None, None)
        assert res['method'] == 'get'


# Generated at 2022-06-23 18:52:46.682266
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:52:54.849555
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert 'http://foo/../' == urlparse(ensure_path_as_is('http://foo/../',
                                                          'http://foo/?foo=bar')).path
    assert 'http://foo/../' == urlparse(ensure_path_as_is('http://foo/../',
                                                          'http://foo/../')).path
    assert 'http://foo/?foo=bar' == urlparse(ensure_path_as_is('http://foo/?foo=bar',
                                                               'http://foo/../')).path

# Generated at 2022-06-23 18:52:58.065752
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:53:08.085818
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:53:11.447905
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    headers = make_default_headers(args)
    assert type(headers) is RequestHeadersDict
    assert len(headers) == 1
    assert headers['User-Agent'] == DEFAULT_UA


# Generated at 2022-06-23 18:53:12.451465
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(5) == None

# Generated at 2022-06-23 18:53:23.315932
# Unit test for function collect_messages
def test_collect_messages():
    from httpie.cli.parser import parser
    args = parser.parse_args(['-s', 'https://httpbin.org/anything'])
    config_dir = Path(__file__).parent.parent
    request_headers = {}
    request_body_read_callback = lambda chunk: chunk
    kwargs = make_request_kwargs(
        args=args,
        base_headers=request_headers,
        request_body_read_callback=request_body_read_callback
    )
    # pprint.pprint(args)
    data = dict(a=1, b='foo')
    kwargs['data'] = json.dumps(data)
    # print(kwargs)
    # print(json.dumps(data))

# Generated at 2022-06-23 18:53:27.993716
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        proxies=["proxy=http://foo.bar"],
        verify=True,
    )
    # Prints the dictionary
    print(make_send_kwargs_mergeable_from_env(args))

# Generated at 2022-06-23 18:53:35.714363
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = ['http://foo']
    args.verify = 'bar'
    args.cert = 'baz'
    args.cert_key = 'buz'
    args.proxy = [argparse.Namespace()]
    args.proxy[0].key = 'http'
    args.proxy[0].value = 'foobar'
    args.proxy.append(argparse.Namespace())
    args.proxy[1].key = 'https'
    args.proxy[1].value = 'foobaz'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies']['http'] == 'foobar'
    assert kwargs['proxies']['https'] == 'foobaz'

# Generated at 2022-06-23 18:53:40.590701
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(
        'http://foo/../', 'http://foo/?foo=bar'
    ) == 'http://foo/../?foo=bar'
    assert ensure_path_as_is(
        'http://foo/..', 'http://foo/?foo=bar'
    ) == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:53:52.313927
# Unit test for function finalize_headers
def test_finalize_headers():
    # Ignore the warning that this makes
    # noinspection PyUnresolvedReferences
    from httpie.cli.context import Environment
    env = Environment()
    env.headers = ['User-Agent: some']
    env.headers.append('X-Header:     asdf')
    env.headers.append('X-Header:asdfasdf')
    env.headers.append('X-Header:  asdfasdf  ')
    env.headers.append('X-Header:  asdfasdf')
    args = argparse.Namespace(headers = env.headers)
    # Ignore the warning that this makes
    # noinspection PyUnresolvedReferences
    from httpie.sessions import RequestHeadersDict
    final_headers = finalize_headers(args.headers)

# Generated at 2022-06-23 18:53:55.996174
# Unit test for function dump_request
def test_dump_request():
    print('Function: dump_request')
    d = {'url': 'http://www.google.com', 'headers': {'User-Agent': 'curl/7.54.0'}}
    dump_request(d)


# Generated at 2022-06-23 18:54:01.058257
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    args.form = False
    args.files = False
    args.data = True
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9', 'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'}


# Generated at 2022-06-23 18:54:08.312607
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from contextlib import contextmanager
    import os
    import sys
    import tempfile
    import unittest

    from httpie import exit_status
    from httpie.core import main
    from httpie.input import SEP_CREDENTIALS
    from httpie.plugins.builtin import HTTPBasicAuth
    from os import path
    from tempfile import gettempdir
    from unittest import TestCase
    from unittest.mock import patch
    from urllib.parse import parse_qsl
    from urllib3.exceptions import HTTPError

    # noinspection PyUnresolvedReferences
    from httpie.client import collect_messages
    # noinspection PyUnresolvedReferences
    from httpie.compat import is_windows
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-23 18:54:18.591432
# Unit test for function dump_request

# Generated at 2022-06-23 18:54:30.205516
# Unit test for function max_headers
def test_max_headers():
    """
    Try to write the following code snippet:
    >>> http.client._MAXHEADERS = 20
    >>> http.client._MAXHEADERS
    20
    >>> http.client._MAXHEADERS = 30
    >>> http.client._MAXHEADERS
    20
    >>> http.client._MAXHEADERS = float('Inf')
    >>> http.client._MAXHEADERS
    30
    >>> http.client._MAXHEADERS = float('Inf')
    >>> http.client._MAXHEADERS
    float('Inf')
    >>> http.client._MAXHEADERS = 50
    >>> http.client._MAXHEADERS
    float('Inf')
    >>> http.client._MAXHEADERS = 50
    >>> http.client._MAXHEADERS
    50
    """
    # To mock the calls to the global variable http.client._MAXHEADERS,
    #

# Generated at 2022-06-23 18:54:33.163299
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify = False,
        ssl_version = 'TLSv1_3',
        ciphers = 'auth'
    )

# Generated at 2022-06-23 18:54:40.673541
# Unit test for function collect_messages

# Generated at 2022-06-23 18:54:50.200024
# Unit test for function finalize_headers
def test_finalize_headers():
    headers_dict = {
        'Content-Type': 'application/json',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Cookie': 'foo=bar',
        'Host': 'www.google.com',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:31.0) Gecko/20100101 Firefox/31.0',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    final

# Generated at 2022-06-23 18:54:52.201214
# Unit test for function max_headers
def test_max_headers():
    with max_headers(10):
        assert http.client._MAXHEADERS == 10

# Generated at 2022-06-23 18:54:55.144685
# Unit test for function max_headers
def test_max_headers():
    def myfunc():
        pass

    with max_headers(1):
        assert http.client._MAXHEADERS == 1
    assert http.client._MAXHEADERS == 1000



# Generated at 2022-06-23 18:54:59.835506
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=1,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 1
    assert kwargs['allow_redirects'] == False

# Generated at 2022-06-23 18:55:06.054754
# Unit test for function dump_request
def test_dump_request():
    from logging import basicConfig, DEBUG
    basicConfig(level=DEBUG)
    # noinspection PyProtectedMember
    assert hasattr(http.client, '_MAXHEADERS')
    _orig_maxheaders = http.client._MAXHEADERS
    try:
        dump_request({'url': 'http://example.com'})
    finally:
        http.client._MAXHEADERS = _orig_maxheaders

# Generated at 2022-06-23 18:55:18.295819
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse

# Generated at 2022-06-23 18:55:22.636353
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    ssl_version = None
    ciphers = None
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=bool(verify),
    )
    assert(isinstance(requests_session, requests.Session))

# Generated at 2022-06-23 18:55:28.915549
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = {'method': 'GET', 'url': 'http://www.baidu.com'}
    request_kwargs = make_request_kwargs(args)
    assert request_kwargs['method'] == 'GET'
    assert request_kwargs['url'] == 'http://www.baidu.com'
    assert 'user-agent' in request_kwargs['headers'].keys()


# Generated at 2022-06-23 18:55:30.485221
# Unit test for function collect_messages
def test_collect_messages():
    collect_messages(None, None)


# Generated at 2022-06-23 18:55:33.607792
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    parser = argparse.ArgumentParser()
    parser.add_argument('-x')
    args = parser.parse_args(['-x', 'foo'])
    assert make_send_kwargs(args) == {
        'timeout': None,
        'allow_redirects': False,
    }

# Generated at 2022-06-23 18:55:37.436362
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=[],
        files=[],
        form=False,
        json=False,
        headers={'header': 'value'},
        json=True
    )
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['Accept'] == JSON_ACCEPT

# Generated at 2022-06-23 18:55:47.006355
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    import pytest
    from hypothesis import given, example, strategies as st
    from urllib.parse import urlparse
    from urllib.parse import urlunparse

    # just path
    assert ensure_path_as_is('../', '?foo=bar') == '../foo=bar'
    # both netloc and path
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    # with some query param
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar&bar=1') == 'http://foo/../?foo=bar&bar=1'
    # everything

# Generated at 2022-06-23 18:55:58.509327
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:56:01.391981
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5) as headers:
        assert http.client._MAXHEADERS == 5
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:56:03.553915
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    print(ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar'))

# Generated at 2022-06-23 18:56:08.450413
# Unit test for function build_requests_session
def test_build_requests_session():

    # (4) Verify update
    verify = "test_verify"
    ssl_version = "test_ssl_version"
    ciphers = "test_ciphers"
    requests_session = build_requests_session(verify, ssl_version, ciphers)

    https_adapter = requests_session.adapters['https://']
    assert https_adapter.verify == verify
    assert https_adapter.ssl_version == int(ssl_version)
    assert https_adapter.ciphers == ciphers

# Generated at 2022-06-23 18:56:16.467462
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Authorization': 'Basic c3Rvcnk6bXlwYXNzd29yZA==', 'Content-Type': 'application/x-www-form-urlencoded'}
    result = finalize_headers(headers)
    assert result == {'Authorization': 'Basic c3Rvcnk6bXlwYXNzd29yZA==', 'Content-Type': 'application/x-www-form-urlencoded'}

    headers = {'Authorization': 'Basic c3Rvcnk6bXlwYXNzd29yZA==', 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}
    result = finalize_headers(headers)

# Generated at 2022-06-23 18:56:27.167757
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        cert="/path/to/cert",
        cert_key="/path/to/cert_key",
        verify="true",
        proxy=[argparse.Namespace(
            key="http",
            value="http://host:port"
        ),
            argparse.Namespace(
            key="https",
            value="https://host:port"
        )
        ]
    )
    expected = {
        "proxies": {"http": "http://host:port", "https": "https://host:port"},
        "stream": True,
        "verify": True,
        "cert": args.cert,
    }
    actual = make_send_kwargs_mergeable_from_env(args)
    assert expected == actual



# Generated at 2022-06-23 18:56:39.210889
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=[])
    args.verify = 'false'

    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'verify': False, 'proxies': {}}

    args.verify = 'true'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'verify': True, 'proxies': {}}

    args.verify = '/path/to/certs'
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs == {'verify': '/path/to/certs', 'proxies': {}}



# Generated at 2022-06-23 18:56:44.573969
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    from httpie.utils import assert_equals
    assert_equals(
        ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar'),
        'http://foo/../?foo=bar'
    )

# Generated at 2022-06-23 18:56:48.019599
# Unit test for function dump_request
def test_dump_request():
    kwargs = {}
    kwargs['url'] = 'www.google.com'
    kwargs['method'] = 'GET'
    kwargs['headers'] = {'User-Agent': 'HTTPie/1.0.2'}
    dump_request(kwargs)


# Generated at 2022-06-23 18:56:58.905550
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    help_dict = {'x': 1}
    help_url = 'http://httpbin.org/get'
    args = argparse.Namespace(help_dict, help_url)
    kwargs = make_request_kwargs(args)
    assert kwargs['url'] == help_url
    assert kwargs['headers'] == {'User-Agent': DEFAULT_UA, 'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'}
    assert kwargs['data'] == '{"x": 1}'
    assert kwargs['auth'] == None
    assert kwargs['params'] == [('x', 1)]

# Generated at 2022-06-23 18:57:04.309630
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=1, allow_redirects=False)
    assert make_send_kwargs(args) == {'timeout': 1, 'allow_redirects': False}
    args = argparse.Namespace(timeout=None, allow_redirects=True)
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-23 18:57:07.931713
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=False,
    )
    assert isinstance(requests_session, requests.Session)

# Generated at 2022-06-23 18:57:17.202918
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../abc.txt', 'http://foo/?foo=bar') == 'http://foo/../abc.txt?foo=bar'
    assert ensure_path_as_is('http://foo/', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'

if __name__ == '__main__':
    test_ensure_path_as_is()

# Generated at 2022-06-23 18:57:25.969143
# Unit test for function finalize_headers
def test_finalize_headers():
     headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': 'application/xml',
        'Content-Type': 'application/xml'
     })
     final_headers = finalize_headers(headers)
     assert list(final_headers.keys()) == ['User-Agent', 'Accept', 'Content-Type']
     assert final_headers['User-Agent'] == DEFAULT_UA
     assert final_headers['Accept'] == 'application/xml'
     assert final_headers['Content-Type'] == 'application/xml'



# Generated at 2022-06-23 18:57:37.202258
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from click import Context

    from httpie.cli import main
    from httpie.cli.argtypes import KeyValueArgType

    args = main(args=['apitest'], invocations={'apitest': Context(obj={'foo': 'bar'})})

    def test_default():
        # test that an empty dictionary is returned as default
        with pytest.raises(KeyError):
            make_send_kwargs_mergeable_from_env(args)['test']

    def test_proxy():
        # test that proxies get passed correctly
        args.proxy = KeyValueArgType()('local:8080')
        assert make_send_kwargs_mergeable_from_env(args)['proxies'] == {'http': 'http://local:8080', 'https': 'http://local:8080'}

# Generated at 2022-06-23 18:57:40.650361
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    print(kwargs)


# Generated at 2022-06-23 18:57:50.318004
# Unit test for function dump_request
def test_dump_request():
    file_name = "dummy.txt"
    with open(file_name, 'w') as f:
        f.write("Dummy text goes here")

    sys.stdout.close()
    sys.stdout = open(os.devnull, 'w')
    parser = argparse.ArgumentParser()
    parser.add_argument('--json', help='json data to send with the request')
    parser.add_argument('--form', help='form data to send with the request')
    parser.add_argument('--files', help='file data to send with the request')
    parser.add_argument('--data', help='data to send with the request')
    parser.add_argument('--cert', help='ssl certificate')
    parser.add_argument('--cert-key', help='ssl certificate key')
    parser.add_

# Generated at 2022-06-23 18:57:56.236591
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    default_headers = make_default_headers(args)
    print(default_headers)
    # assert default_headers['Accept'] == JSON_ACCEPT
    # assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

if __name__ == '__main__':
    test_make_default_headers()