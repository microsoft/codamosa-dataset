

# Generated at 2022-06-23 18:48:02.872461
# Unit test for function max_headers
def test_max_headers():
    import unittest
    import unittest.mock

    old_MAXHEADERS = http.client._MAXHEADERS
    test_limit = 100

    def test_change():
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == test_limit

    def test_reset():
        # noinspection PyProtectedMember
        assert http.client._MAXHEADERS == old_MAXHEADERS

    with unittest.mock.patch(
            'http.client._MAXHEADERS',
            old_MAXHEADERS,
            create=True,
    ):
        with max_headers(test_limit):
            test_change()
        test_reset()


# Generated at 2022-06-23 18:48:14.744224
# Unit test for function dump_request
def test_dump_request():
    a = [{'headers': {}, 'data': {'test': 'test'}, 'method': 'GET', 'url': 'http://test.com'}]

# Generated at 2022-06-23 18:48:19.050717
# Unit test for function dump_request
def test_dump_request():
    test_kwargs = {
                'url': 'http://127.0.0.1',
                'headers': {'User-Agent': 'test-httpie'}}
    dump_request(test_kwargs)

# Generated at 2022-06-23 18:48:29.362731
# Unit test for function collect_messages
def test_collect_messages():
    import requests
    import requests.adapters
    args = argparse.Namespace()
    args.url = 'https://m.baidu.com'
    config_dir = Path('./')
    response_count = 0
    expired_cookies = []
    send_kwargs_merged = {}
    httpie_session = get_httpie_session(config_dir, 'test', None, 'https://m.baidu.com')
    httpie_session.update_headers({'User-Agent': DEFAULT_UA})
    requests_session = requests.Session()
    requests_session.mount('https://', requests.adapters.HTTPAdapter())

# Generated at 2022-06-23 18:48:31.597644
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:48:34.524756
# Unit test for function dump_request
def test_dump_request():
    result = dump_request({'test1':'test', 'test2':'test'})
    assert result == None
    assert True

# Generated at 2022-06-23 18:48:46.491578
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class Namespace(object):
        def __init__(self, kwargs):
            self.__dict__ = kwargs
            if not hasattr(self, 'data'):
                self.data = None
            if not hasattr(self, 'form'):
                self.form = False
            if not hasattr(self, 'multipart'):
                self.multipart = False
            if not hasattr(self, 'multipart_data'):
                self.multipart_data = None
            if not hasattr(self, 'auth'):
                self.auth = None
            if not hasattr(self, 'params'):
                self.params = None
            if not hasattr(self, 'headers'):
                self.headers = {}
            if not hasattr(self, 'files'):
                self

# Generated at 2022-06-23 18:48:54.845193
# Unit test for function finalize_headers

# Generated at 2022-06-23 18:48:55.538305
# Unit test for function dump_request
def test_dump_request():
    pass

# Generated at 2022-06-23 18:49:00.310722
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=3,
        allow_redirects=False,
    )
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {
        'timeout': args.timeout or None,
        'allow_redirects': False,
    }



# Generated at 2022-06-23 18:49:05.067235
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    parser = argparse.ArgumentParser()
    parser.add_argument('--timeout', default=30)
    args = parser.parse_args()
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': 30, 'allow_redirects': False}



# Generated at 2022-06-23 18:49:12.850856
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:49:25.733253
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.url = 'http://example.com'
    args.method = 'GET'
    args.headers = RequestHeadersDict()
    args.params = {}
    args.data = ''
    args.form = False
    args.json = False
    args.offline = False
    args.chunked = False
    args.files = True
    args.path_as_is = True
    args.compress = False
    args.timeout = None
    args.verify = True
    args.auth = None
    args.all = False
    args.proxy = []
    args.download = False
    args.follow = False
    args.max_redirects = 10
    args.max_headers = None
    args.session_read_only = 'foo'
   

# Generated at 2022-06-23 18:49:30.577958
# Unit test for function build_requests_session
def test_build_requests_session():
    try:
        from pytest import raises
    except ImportError:
        from py.test import raises
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.core import main

    args = parser.parse_args(args=[], env=os.environ)
    with raises(SystemExit):
        main(args=args, config_dir=None)

# Generated at 2022-06-23 18:49:34.848819
# Unit test for function dump_request
def test_dump_request():
    request_kwargs = {'url': 'url', 'headers': {'header': 'header'}}
    dump_request(request_kwargs)
    assert (sys.stderr.getvalue() == '\n>>> requests.request(**{ \'url\': \'url\', \'headers\': {\'header\': \'header\'}})\n\n')

# Generated at 2022-06-23 18:49:47.338714
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import os
    import tempfile

    cert_path = tempfile.NamedTemporaryFile(mode='w+b')
    cert_path.write(b'foobarbaz')
    cert_path.flush()
    cert_key_path = tempfile.NamedTemporaryFile(mode='w+b')
    cert_key_path.write(b'foobarbaz')
    cert_key_path.flush()
    verify_path = tempfile.NamedTemporaryFile(mode='w+b')
    verify_path.write(b'foobarbaz')
    verify_path.flush()

    proxy_path = tempfile.NamedTemporaryFile(mode='w+b')
    proxy_path.write(b'foobarbaz')
    proxy_path.flush()


# Generated at 2022-06-23 18:49:48.546334
# Unit test for function collect_messages
def test_collect_messages():
    # TODO:
    pass

# Generated at 2022-06-23 18:50:00.143860
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace
    args.url = 'https://google.com'
    args.method = 'GET'
    args.headers = {'Content-Type':'application/json'}
    args.data = {'name':'ABC'}
    args.json = True
    args.form = True
    args.files = ['/home/abc.txt']
    args.multipart = True
    args.multipart_data = {'name':'abc'}
    args.boundary = '----boundary'
    args.auth = 'abc'
    args.base_headers = {'Base-Content':'application/json'}
    args.params = {'name':'abc','age':'20'}
    args.timeout = 10

# Generated at 2022-06-23 18:50:04.348431
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers(RequestHeadersDict({"Accept": "application/json, text/javascript;q=0.01"})) == \
           finalize_headers(RequestHeadersDict({"Accept": "application/json, text/javascript; q=0.01"}))


# Generated at 2022-06-23 18:50:07.200751
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(True, "TLS1_2", "HIGH")
    assert isinstance(session, requests.Session)
    assert isinstance(session.adapters, requests.adapters.HTTPAdapter)

# Generated at 2022-06-23 18:50:16.175214
# Unit test for function dump_request
def test_dump_request():
    def my_callback_function(chunk):
        pass

    path = 'http://localhost:8080'

# Generated at 2022-06-23 18:50:26.612879
# Unit test for function dump_request
def test_dump_request():
  argv = [
    'http',
    '--form',
    '--data',
    'foo=bar',
    'https://httpbin.org/post'
  ]
  # noinspection PyTypeChecker
  parser = argparse.ArgumentParser()
  httpie.cli.parser.add_parser_options(parser)
  args = parser.parse_args(argv)
  #parameters = {
  #  'headers':{},
  #  'data': 'foo=bar',
  #  'url': 'https://httpbin.org/post',
  #  'method': 'POST'
  #}
  #print(type(args.headers))
  #dump_request(parameters)
  final_headers = finalize_headers(make_default_headers(args))

# Generated at 2022-06-23 18:50:29.190208
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()


if __name__ == '__main__':
    test_make_request_kwargs()

# Generated at 2022-06-23 18:50:37.126427
# Unit test for function collect_messages
def test_collect_messages():
    config_dir = 'E:/project/py/httpie/httpie/'
    args = argparse.Namespace()

    args.session = 'zhangjun'
    args.headers = RequestHeadersDict({})
    args.url = 'http://www.baidu.com'
    print(args.url)
    #print(args.headers)

    messages = collect_messages(args=args, config_dir=config_dir)
    print(messages)
    request = next(messages)
    print(request.url)

if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-23 18:50:45.322618
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(json=False, data="", form=True)
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Content-Type': FORM_CONTENT_TYPE,
    })

    args = argparse.Namespace(json=False, data=dict(), form=False)
    assert make_default_headers(args) == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE,
    })

    args = argparse.Namespace(json=True, data=dict(), form=False)

# Generated at 2022-06-23 18:50:56.480933
# Unit test for function make_default_headers
def test_make_default_headers():
    assert make_default_headers(args=argparse.Namespace(
        data=None,
        files=None,
        form=False,
        json=False,
        max_redirects=None,
        headers={},
        multipart=False,
        chunked=False,
        offline=False,
        session=None,
    )) == {'User-Agent': 'HTTPie/0.1.2'}

# Generated at 2022-06-23 18:51:07.363190
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = False
    args.form = True
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9', 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}

    args.json = True
    assert make_default_headers(args) == {'User-Agent': 'HTTPie/0.9.9', 'Accept': 'application/json, */*;q=0.5'}

    args.json = False
    args.data = {'foo': 'bar'}

# Generated at 2022-06-23 18:51:16.507206
# Unit test for function dump_request
def test_dump_request():
    import sys
    import io
    out = io.StringIO()
    sys.stderr = out
    dump_request({"method": "POST", "url": "http://localhost:5000/",
                  "headers": {"Content-Type": "application/json"},
                  "data": "{\r\n  \"cfg\": \"hello\",\r\n  \"number\": 100\r\n}"})
    output = out.getvalue().strip()
    assert output.find(
        'requests.request(**{\'method\': \'POST\', \'url\': \'http://localhost:5000/\', \'h') == 0

# Generated at 2022-06-23 18:51:29.172580
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class Foo:
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return str(self.value)

    def test_dict(kwargs, expected_value):
        for name, value in expected_value.items():
            assert isinstance(value, type(kwargs[name]))
            assert kwargs[name] == value

    # Test timeout
    args = argparse.Namespace(timeout=Foo(5))
    kwargs = make_send_kwargs(args)
    test_dict(kwargs, {'timeout': 5})

    # Test allow_redirects
    args = argparse.Namespace(allow_redirects=False)
    kwargs = make_send_kwargs(args)

# Generated at 2022-06-23 18:51:33.350272
# Unit test for function finalize_headers
def test_finalize_headers():
    h = RequestHeadersDict({
        'User-Agent': 'HTTPie/1.0.3'
    })
    assert 'User-Agent' in h
    h = finalize_headers(h)
    assert h['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-23 18:51:44.584035
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.encoding = None
    args.auth_plugin = None
    args.headers = None
    args.verify = 'true'
    args.json = None
    args.form = None
    args.compress = 0
    args.cert = None
    args.cert_key = None
    args.method = 'GET'
    args.timeout = 0
    args.url = 'https://httpbin.org/?key1=value1&key2=value2'
    args.params = None
    args.data = {'key': 'value', 'key2': 'value2'}

    # expected result

# Generated at 2022-06-23 18:51:47.869523
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = {}
    args['timeout'] = None
    args['allow_redirects'] = False

    assert make_send_kwargs(args) == args

# Generated at 2022-06-23 18:51:56.719542
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.proxy = {'yes','no'}
    args.cert = 'yes'
    args.cert_key = 'yes'

    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['proxies'] == {'yes','no'}
    assert kwargs['stream'] == True
    assert kwargs['verify'] == True 
    assert kwargs['cert'] == 'yes'


# Generated at 2022-06-23 18:52:01.094371
# Unit test for function finalize_headers
def test_finalize_headers():
    input_headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    output_headers = finalize_headers(input_headers)
    assert output_headers != None
    assert isinstance(output_headers, dict)
    assert output_headers['User-Agent'] == DEFAULT_UA



# Generated at 2022-06-23 18:52:01.885742
# Unit test for function build_requests_session
def test_build_requests_session():
    build_requests_session(True, None)

# Generated at 2022-06-23 18:52:12.290780
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    #pylint: disable=missing-function-docstring
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        cert=None,
        cert_key=None,
        chunked=None,
        chunk_size=10,
        data={},
        files={},
        form=False,
        headers={},
        json=False,
        method='POST',
        params={},
        timeout=None,
        url='http://foo',
        verify=False,
        traceback=True
    )
    data = {'key': 'value'}
    args.data = data
    request_kwargs = make_request_kwargs(args)
    assert request_kwargs['method'] == 'POST'
    assert request_kwargs['url'] == 'http://foo'

# Generated at 2022-06-23 18:52:20.382842
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json
    import requests
    class args:
        url='https://www.google.com/'
        method='GET'
        headers=dict()
        data=dict()
        files=list()
        form=False
        json=True
        auth=None
        params=dict()
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'get'
    assert kwargs['url'] == 'https://www.google.com/'
    assert kwargs['headers']['Accept'] == 'application/json, */*;q=0.5'
    assert kwargs['headers']['Content-Type'] == 'application/json'
    assert kwargs['data'] is None
    assert kwargs['auth'] is None

# Generated at 2022-06-23 18:52:30.218465
# Unit test for function build_requests_session
def test_build_requests_session():
    import requests
    import httpie.plugins.builtin.transport.httpie_adapter
    # Install our adapter.
    https_adapter = httpie.plugins.builtin.transport.httpie_adapter.HTTPieHTTPSAdapter(
        ciphers='DEFAULT',
        verify=True,
        ssl_version='TLSv1_2',
    )
    requests_session = requests.Session()
    requests_session.mount('https://', https_adapter)

    # Install adapters from plugins.
    for plugin_cls in plugin_manager.get_transport_plugins():
        transport_plugin = plugin_cls()
        requests_session.mount(
            prefix=transport_plugin.prefix,
            adapter=transport_plugin.get_adapter(),
        )


# Generated at 2022-06-23 18:52:33.688722
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    sys.argv = [sys.argv[0], '-j', 'get', 'http://127.0.0.1:8000/api/v1/testcases/1/']
    main()

# Generated at 2022-06-23 18:52:41.518560
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = attrdict.AttrDict({"key":"value"})
    args.verify = "yes"
    args.cert = "value"
    args.cert_key = "value"

    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs["proxies"] == args.proxy
    assert kwargs["stream"] == True
    assert kwargs["verify"] == True
    assert kwargs["cert"] == args.cert

# Generated at 2022-06-23 18:52:54.442105
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test if make_send_kwargs_mergeable_from_env() returns the correct results
    # when the arguments are correct
    # Test if the output is correct when the input is correct
    args1 = argparse.Namespace(
        verify=None,
        cert=None,
        cert_key=None,
        proxy=None
    )
    ans1 = {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None
    }
    assert make_send_kwargs_mergeable_from_env(args1) == ans1

    # Test if the output is correct when the input has arguments the
    # function does not support

# Generated at 2022-06-23 18:53:03.106450
# Unit test for function collect_messages
def test_collect_messages():
    #import argparse
    # Collect events from 4 seconds of data
    #progress_start = time.time()
    #while True:
    #    event = frida.get_usb_device(timeout=1).enumerate_events()
    #    events.append(event)
    #    if event.type == 'output':
    #        sys.stdout.write(event.payload)
        # If it's time, then leave the event loop
    #    if time.time() - progress_start >= 2:
    #        break

    class DummyArgs:
        auth = None
        auth_plugin = None
        cert = None
        cert_key = None
        ciphers = None
        chunked = None
        compression = None
        data = None
        debug = None
        files = None
        follow = None


# Generated at 2022-06-23 18:53:08.568421
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Arrange
    args = argparse.Namespace(verify='yes', cert=None, cert_key=None, proxy=[])
    expected_result = {}
    expected_result['verify'] = True
    expected_result['proxies'] = {}

    # Act
    result = make_send_kwargs_mergeable_from_env(args)

    # Assert
    assert result == expected_result

# Generated at 2022-06-23 18:53:17.748565
# Unit test for function make_default_headers
def test_make_default_headers():
    class args:
        json = False
        form = False
        files = False
        data = None
    
    def test(json, form, files, data, expected):
        args.json = json
        args.form = form
        args.files = files
        args.data = data
        assert make_default_headers(args) == expected
        
    # JSON
    test(True, False, False, None, {"Accept":"application/json, */*;q=0.5","Content-Type":"application/json","User-Agent":DEFAULT_UA})
    test(True, False, False, 1, {"Accept":"application/json, */*;q=0.5","Content-Type":"application/json","User-Agent":DEFAULT_UA})

# Generated at 2022-06-23 18:53:19.601467
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session(verify=True)).__name__ == 'Session'

# Generated at 2022-06-23 18:53:23.841906
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli import parser
    args = parser.parse_args(['--verify', 'no', '--proxy', 'http://proxy.com'])
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['verify'] is False
    assert send_kwargs_mergeable_from_env['proxies'] == {'http': 'http://proxy.com'}

# Generated at 2022-06-23 18:53:27.587929
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    assert http.client._MAXHEADERS != 5

# Generated at 2022-06-23 18:53:29.616179
# Unit test for function build_requests_session
def test_build_requests_session():
    assert len(build_requests_session(verify=True, ssl_version='SSLv23', ciphers='RSA').adapters) == 2


# Generated at 2022-06-23 18:53:34.859858
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    setattr(args, 'timeout', 15)
    setattr(args, 'allow_redirects', False)
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['timeout'] == 15
    assert send_kwargs['allow_redirects'] == False


# Generated at 2022-06-23 18:53:36.358632
# Unit test for function build_requests_session
def test_build_requests_session():
    assert type(build_requests_session(verify=False)) == requests.Session()

# Generated at 2022-06-23 18:53:37.788348
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=False)
    print(session)
    assert session is not None



# Generated at 2022-06-23 18:53:41.678850
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(method='get', url='http://www.test.com', data=[])
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-23 18:53:53.570221
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    headers = make_default_headers(args)
    assert headers == {'Accept': 'application/json, */*;q=0.5', 'User-Agent': 'HTTPie/1.0.0'}
    args.data = {}
    headers = make_default_headers(args)
    assert headers == {'Accept': 'application/json, */*;q=0.5', 'User-Agent': 'HTTPie/1.0.0', 'Content-Type': 'application/json'}
    args.json = False
    args.form = True
    args.files = False
    headers = make_default_headers(args)

# Generated at 2022-06-23 18:54:00.853051
# Unit test for function collect_messages
def test_collect_messages():
    import unittest
    class TestCollectMessages(unittest.TestCase):
        def test_collect_messages(self):
            class Args:
                def __init__(self):
                    self.auth=None
                    self.auth_plugin=None
                    self.boundary=None
                    self.chunked=False
                    self.compress=0
                    self.cert=None
                    self.cert_key=None
                    self.ciphers=None
                    self.debug=False
                    self.form=False
                    self.data=None
                    self.headers=None
                    self.method="get"
                    self.multipart=False
                    self.multipart_data=None
                    self.offline=False
                    self.path_as_is=False
                    self.params=None

# Generated at 2022-06-23 18:54:08.390651
# Unit test for function finalize_headers
def test_finalize_headers():
    x = {'Content-Type':'application/x-www-form-urlencoded; charset=utf-8'}
    y = {'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'}
    if finalize_headers(x) != {'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'}:
        raise AssertionError
    if finalize_headers(y) != {'Accept': 'application/json, */*;q=0.5', 'Content-Type': 'application/json'}:
        raise AssertionError



# Generated at 2022-06-23 18:54:15.353005
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('https://foo/../', 'https://foo/?foo=bar') == 'https://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'https://foo/?foo=bar') == 'https://foo/../?foo=bar'

# Generated at 2022-06-23 18:54:21.767291
# Unit test for function finalize_headers
def test_finalize_headers():
    # Test for removing leading and trailing spaces of the value
    assert finalize_headers(RequestHeadersDict({
        'User-Agent': '   HTTPie/0.9.9'
    }))['User-Agent'] == b'HTTPie/0.9.9'
    assert finalize_headers(RequestHeadersDict({
        'User-Agent': 'HTTPie/0.9.9   '
    }))['User-Agent'] == b'HTTPie/0.9.9'
    assert finalize_headers(RequestHeadersDict({
        'User-Agent': '   HTTPie/0.9.9   '
    }))['User-Agent'] == b'HTTPie/0.9.9'

    # Test for non-ascii headers

# Generated at 2022-06-23 18:54:31.112823
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    # Test for method
    args = argparse.Namespace(method='get') 
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'get'
    args = argparse.Namespace(method='Get') 
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'get'
    args = argparse.Namespace(method='GET') 
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'get'
    args = argparse.Namespace(method='post') 
    kwargs = make_request_kwargs(args)
    assert kwargs['method'] == 'post'
    # Test for url

# Generated at 2022-06-23 18:54:36.274541
# Unit test for function finalize_headers
def test_finalize_headers():
    test_dict = {}
    test_dict['test_1'] = 'test_1'
    test_dict['test_2'] = ' test_2 '
    test_dict['test_3'] = 'test_3 '
    assert(finalize_headers(test_dict) == {'test_1':b'test_1', 'test_2':b'test_2', 'test_3':b'test_3'})


# Generated at 2022-06-23 18:54:40.497621
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/bar?baz=qux', 'http://foo:8080/?foo=bar') == 'http://foo/bar?baz=qux'

# Generated at 2022-06-23 18:54:50.072153
# Unit test for function collect_messages

# Generated at 2022-06-23 18:54:54.147029
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    print(ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar'))

if __name__ == '__main__':
    test_ensure_path_as_is()

# Generated at 2022-06-23 18:54:57.404181
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(True, "TLSv1.1", "DEFAULT:!aNULL:!eNULL:!LOW:!EXPORT:!SSLv2:!MD5")


# Generated at 2022-06-23 18:55:02.682823
# Unit test for function finalize_headers
def test_finalize_headers():
    actual = finalize_headers(RequestHeadersDict({
        'User-Agent': '    HTTPie/0.9.9   '
    }))
    expected = RequestHeadersDict({
        'User-Agent': b'HTTPie/0.9.9'
    })
    assert actual == expected

# Generated at 2022-06-23 18:55:08.674250
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = None
    args.verify = 'no'
    args.proxy = None

    result = make_send_kwargs_mergeable_from_env(args)
    assert result == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': None,
    }

# Generated at 2022-06-23 18:55:15.343521
# Unit test for function collect_messages
def test_collect_messages():
    from httpie import docopt_args
    from httpie.compat import is_windows
    from httpie.context import Environment

    args = docopt_args(['httpie'])
    assert args.url is None
    env = Environment(args=args)
    args = env.args
    if is_windows:
        args.config_dir = 'C:\\Users\\IEUser\\AppData\\Roaming\\httpie'
    else:
        args.config_dir = '/home/IEUser/.config/httpie'
    args.session = ''
    collect_messages(args, args.config_dir)

# Generated at 2022-06-23 18:55:24.965080
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo?foo=bar') == 'http://foo/..?foo=bar'
    assert ensure_path_as_is('http://foo/../?foo=bar', 'http://foo') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../?foo=bar', 'http://foo/') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('https://foo/', 'https://foo/?foo=bar') == 'https://foo/?foo=bar'

# Generated at 2022-06-23 18:55:34.129678
# Unit test for function collect_messages

# Generated at 2022-06-23 18:55:42.661846
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA}
    args.json = True
    assert make_default_headers(args) == {'Accept': JSON_ACCEPT, 'User-Agent': DEFAULT_UA, 'Content-Type': JSON_CONTENT_TYPE}
    args.json = False
    args.form = True
    assert make_default_headers(args) == {'Content-Type': FORM_CONTENT_TYPE, 'User-Agent': DEFAULT_UA}
    args.form = False
    args.files = True
    assert make_default_headers(args) == {'User-Agent': DEFAULT_UA}

# Generated at 2022-06-23 18:55:47.790208
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA})
    headers = finalize_headers(headers)
    assert headers == {'User-Agent': b'HTTPie/1.0.0'}

    headers = RequestHeadersDict({
        'User-Agent': DEFAULT_UA})
    headers = finalize_headers(headers)
    assert headers == {'User-Agent': b'HTTPie/1.0.0'}

# Generated at 2022-06-23 18:55:58.544384
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test case 1: args.verify = 'yes'
    args = argparse.Namespace(verify='yes')
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    # Test case 2: args.verify = 'no'
    args = argparse.Namespace(verify='no')
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': None,
    }
    # Test case 3: args.verify = '1.1.1.1'

# Generated at 2022-06-23 18:56:06.116365
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = False
    args.cert = None
    args.cert_key = None
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': None
    }
    args.proxy.append(argparse.Namespace(key='http', value='127.0.0.1'))
    args.verify = True
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {'http': '127.0.0.1'},
        'stream': True,
        'verify': True,
        'cert': None
    }

# Generated at 2022-06-23 18:56:08.555701
# Unit test for function dump_request
def test_dump_request():
    request_kwargs = {}
    dump_request(request_kwargs)


# Generated at 2022-06-23 18:56:16.905589
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:56:21.938456
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout=None,
        allow_redirects=False
    )
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': None,
        'allow_redirects': False,
    }


# Generated at 2022-06-23 18:56:29.935515
# Unit test for function build_requests_session

# Generated at 2022-06-23 18:56:35.381258
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['timeout'] == 10
    assert send_kwargs['allow_redirects'] == False


# Generated at 2022-06-23 18:56:44.410284
# Unit test for function max_headers
def test_max_headers():

    limit = 1
    dict_headers = {
        "Content-Type": "application/json",
        "Accept-Charset": "utf-8",
        "Accept": "application/json, text/javascript, */*",
        "User-Agent": "wget",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive"
    }

    headers = []

# Generated at 2022-06-23 18:56:51.393243
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path('')
    b = collect_messages(args, config_dir)

    # noinspection PyUnresolvedReferences
    import requests
    import json

    url = "http://ip.nfd.com.tw"
    payload = json.dumps({
        "query": "114.34.235.62",
        "data": "ip",
        "data_id": "ip_id"
    })
    headers = {
        'content-type': "application/json",
        'cache-control': "no-cache",
        'postman-token': "e2e0f410-0eaa-1327-6cbc-6e1a6f091f82"
    }


# Generated at 2022-06-23 18:56:57.990655
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {'timeout': None, 'allow_redirects': False}

    args.timeout = 10
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {'timeout': 10, 'allow_redirects': False}

# Generated at 2022-06-23 18:57:02.292485
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False

    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False


# Generated at 2022-06-23 18:57:14.878533
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = True
    ssl_version = 'TLSv1.2'
    kwargs = {
        'ciphers': None,
        'verify': verify,
        'ssl_version': AVAILABLE_SSL_VERSION_ARG_MAPPING[ssl_version]
    }
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=None,
        verify=bool(verify)
    )
    https_adapter = requests_session.adapters['https://']
    assert https_adapter.init_kwargs.get('ssl_version') == kwargs['ssl_version']
    assert https_adapter.init_kwargs.get('verify') == kwargs['verify']
    assert https_adapter.init_kw

# Generated at 2022-06-23 18:57:15.902530
# Unit test for function collect_messages
def test_collect_messages():
    collector = collect_messages()
    assert collector is not None

# Generated at 2022-06-23 18:57:23.265942
# Unit test for function make_default_headers

# Generated at 2022-06-23 18:57:35.780566
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = True
    expected_kwargs = {
        'verify': True,
        'proxies': {},
        'stream': True,
        'cert': None,
    }
    assert expected_kwargs == make_send_kwargs_mergeable_from_env(args)
    args.verify = False
    expected_kwargs = {
        'verify': False,
        'proxies': {},
        'stream': True,
        'cert': None,
    }
    assert expected_kwargs == make_send_kwargs_mergeable_from_env(args)
    args.verify = 'yes'

# Generated at 2022-06-23 18:57:39.921207
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    args.files = []
    args.headers = {}
    headers = make_default_headers(args)
    assert headers == {'User-Agent': DEFAULT_UA}


# Generated at 2022-06-23 18:57:45.055559
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "https://www.google.com/"
    args.headers = {'User-Agent': "Myself"}
    args.data = ""
    args.json = ""
    args.form = ""
    args.auth = "0"
    args.params = ""
    args.dump_config = ""
    kwargs = make_request_kwargs(args)
    dump_request(kwargs)

# Generated at 2022-06-23 18:57:54.953044
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify=False,
        ssl_version='TLSv1_2',
        ciphers='EECDH+AESGCM:EDH+AESGCM:AES256+EECDH:AES256+EDH'
    )
    assert requests_session._adapters['https://'].ssl_version == ssl.PROTOCOL_TLS
    assert requests_session._adapters['https://'].ciphers == 'EECDH+AESGCM:EDH+AESGCM:AES256+EECDH:AES256+EDH'
    assert requests_session._adapters['https://'].verify == False