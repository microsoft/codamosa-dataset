

# Generated at 2022-06-23 18:47:51.969517
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(verify = "true", cert = "test", cert_key = "test")
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs["verify"] == True
    assert kwargs["cert"] == ("test", "test")

# Generated at 2022-06-23 18:48:01.380384
# Unit test for function collect_messages

# Generated at 2022-06-23 18:48:13.566822
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.auth = None
    args.headers = []
    args.data = ''
    args.files = ''
    args.method = ''
    args.url = ''
    args.json = ''
    args.form = ''
    args.params = {}
    args.timeout = ''
    args.allow_redirects = ''
    args.verify = ''
    args.cert = ''
    args.cert_key = ''
    args.data = ''
    args.chunked = ''
    args.json = ''
    args.boundary = ''
    args.multipart_data = ''
    args.multipart = False
    args.path_as_is = False
    args.compress = False
    args.debug = False
    args.offline = False

# Generated at 2022-06-23 18:48:25.871098
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('https://foo/../', 'https://foo/?foo=bar') == 'https://foo/../?foo=bar'
    assert ensure_path_as_is('https://foo/../hello/world.txt', 'https://foo/?foo=bar') == 'https://foo/../hello/world.txt?foo=bar'    
    assert ensure_path_as_is('http://foo/../.', 'http://foo/bar.html') == 'http://foo/bar.html'

# Generated at 2022-06-23 18:48:30.022425
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(data=False, form=False, json=False, files=False)
    result = make_default_headers(args)
    assert result == RequestHeadersDict({'User-Agent': DEFAULT_UA})

    args = argparse.Namespace(data=True, form=False, json=True, files=False)
    result = make_default_headers(args)
    assert result == RequestHeadersDict({'Accept': JSON_ACCEPT, 'Content-Type': JSON_CONTENT_TYPE, 'User-Agent': DEFAULT_UA})

# Generated at 2022-06-23 18:48:34.111891
# Unit test for function make_default_headers
def test_make_default_headers():
    real_kwargs = {"headers": None, "json": False, "form": False, "data": None}
    result = make_default_headers(real_kwargs)
    assert result == {'User-Agent': DEFAULT_UA}



# Generated at 2022-06-23 18:48:37.422999
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    result = make_send_kwargs(args)
    assert result["timeout"] == None
    assert result["allow_redirects"] == False


# Generated at 2022-06-23 18:48:49.060849
# Unit test for function collect_messages

# Generated at 2022-06-23 18:48:53.870253
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(proxy=None, verify='yes', cert=None, cert_key=None)
    expected = {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    assert make_send_kwargs_mergeable_from_env(args) == expected


# Generated at 2022-06-23 18:48:58.748283
# Unit test for function finalize_headers
def test_finalize_headers():
  from httpie.cli.headers import HeadersParser
  args = argparse.Namespace()
  headers = HeadersParser().parse_headers_from_string('')
  headers = finalize_headers(headers)
  assert headers['User-Agent'] == DEFAULT_UA
  assert 'Accept' not in headers

# Generated at 2022-06-23 18:49:09.459910
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    argparse_namespace = argparse.Namespace()

# Generated at 2022-06-23 18:49:19.662016
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    class args:
        proxy = [urlparse('http://127.0.0.1:8080')]
        timeout = 10
        allow_redirects = False
        cert = None
        cert_key = None
        verify = False
    assert {
        'proxies': {'http': 'http://127.0.0.1:8080'},
        'stream': True,
        'verify': False,
        'cert': None
    } == make_send_kwargs_mergeable_from_env(args)
    assert {
        'timeout': 10,
        'allow_redirects': False
    } == make_send_kwargs(args)

# Generated at 2022-06-23 18:49:30.414166
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "GET"
    args.url = "https://www.google.com"
    args.json = True
    args.data = {}
    args.auth = ""
    args.headers = {}
    args.files = {}
    args.params = {}
    args.form = False
    args.multipart = False
    args.multipart_data = {}
    args.boundary = None

    req = make_request_kwargs(args)
    assert req["method"] == "GET"
    assert req["url"] == "https://www.google.com"
    assert req["params"] == args.params.items()
    assert req["headers"]["Content-Type"] == JSON_CONTENT_TYPE

# Generated at 2022-06-23 18:49:38.676221
# Unit test for function dump_request
def test_dump_request():
    import pytest

# Generated at 2022-06-23 18:49:45.401138
# Unit test for function build_requests_session
def test_build_requests_session():
    config_dir = Path("/home/user/.config/httpie")
    ssl_version = None
    args = argparse.Namespace()
    args.verify = False
    args.ciphers = None
    session = build_requests_session(verify=True, ssl_version=ssl_version, ciphers=args.ciphers)
    print(session)
    print(session.verify)
    print(session.proxies)


# Generated at 2022-06-23 18:49:53.639418
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='yes')) == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify='no')) == {'proxies': {}, 'stream': True, 'verify': False, 'cert': None}


# Generated at 2022-06-23 18:50:04.264622
# Unit test for function collect_messages
def test_collect_messages():
    import io
    import json
    import pkgutil
    import csv
    import urllib3
    import httpie.cli.json
    import httpie.compat
    import httpie.core
    import httpie.output.formatters
    import httpie.output.streams

    import json
    import sys
    import httpie.plugins
    import httpie.utils
    import httpie.__main__
    import httpie
    import httpie.plugins.manager
    import httpie.plugins.builtin
    import httpie.plugins
    import httpie.output.streams
    import httpie.plugins.builtin
    import httpie.plugins
    import httpie.compat
    import httpie.plugins.builtin
    import httpie.carriers
    import httpie.plugins
    import httpie.utils


# Generated at 2022-06-23 18:50:07.106437
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

test_ensure_path_as_is()

# Generated at 2022-06-23 18:50:14.001899
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli.argtypes import KeyValueArg
    args = argparse.Namespace(proxy=[], verify=None)
    # verify default value
    assert make_send_kwargs_mergeable_from_env(args)['verify'] is None

    # test proxy
    args = argparse.Namespace(proxy=[KeyValueArg('http:', 'http://localhost'),
                                      KeyValueArg('https:', 'https://localhost')],
                              verify=None)
    assert make_send_kwargs_mergeable_from_env(args)['proxies'] == {'https': 'https://localhost', 'http': 'http://localhost'}

    # test verify
    args = argparse.Namespace(proxy=[], verify="0")

# Generated at 2022-06-23 18:50:17.384314
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

if __name__ == '__main__':
    test_ensure_path_as_is()

# Generated at 2022-06-23 18:50:27.506156
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.url = 'https://www.google.com/'
    args.method = 'GET'
    args.auth = None
    args.headers = {'Host': 'www.google.com', 'User-Agent': 'HTTPie/0.3.1'}
    args.params = {'q': 'httpie'}
    args.data = None
    args.form = False
    args.json = False
    args.multipart_data = None
    args.multipart = None
    args.boundary = None
    args.files = None
    args.verify = True
    args.cert = None
    args.cert_key = None
    args.proxy = None
    args.debug = False
    args.session = None
    args.max_redirects

# Generated at 2022-06-23 18:50:33.577552
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie import parser
    parser.parser._inited = 2  # HACK
    args = parser.parser.parse_args(
        [
            "--verify",
            "no",
            "--proxy",
            "https://httpbin.org",
            "--proxy",
            "https://httpbin.local",
        ]
    )
    make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-23 18:50:37.155487
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': 'GET',
        'url': 'http://localhost:8080',
        'headers': {
            'User-Agent': DEFAULT_UA,
            'Accept': JSON_ACCEPT,
            'Content-Type': JSON_CONTENT_TYPE
        },
        'data': '',
        'auth': (None, None)
    }
    dump_request(kwargs)

# Generated at 2022-06-23 18:50:45.326330
# Unit test for function make_default_headers
def test_make_default_headers():
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # case json
    arg1 = Namespace(json=True, data=None, form=True)
    arg2 = Namespace(json=False, data='{"a":1}', form=False)
    arg3 = Namespace(json=False, data="", form=False)
    arg4 = Namespace(json=False, data=None, form=False)
    arg5 = Namespace(json=False, data=None, form=True)

    default_headers1 = make_default_headers(arg1)
    default_headers2 = make_default_headers(arg2)
    default_headers3 = make_default_headers(arg3)
    default_headers4 = make_default_headers

# Generated at 2022-06-23 18:50:56.482283
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth=('user', 'pass'),
        cert=('/path/client.crt', '/path/client.key'),
        chunked=False,
        data={'data': 'test'},
        files=None,
        form=False,
        headers={'Content-Type': 'application/json'},
        json=False,
        max_headers=False,
        method='POST',
        multipart_data=[],
        multipart=False,
        offline=False,
        params={'key': 'value'},
        path_as_is=False,
        session=False,
        session_read_only=False,
        timeout=False,
        url='http://www.example.com',
        verify='/path/to/cacert.pem',
    )

# Generated at 2022-06-23 18:51:07.179468
# Unit test for function max_headers
def test_max_headers():
    from tests.test_client import HTTPBIN_HOSTNAME
    from httpie.cli.argtypes import KeyValueArgType
    # noinspection PyPackageRequirements
    import unittest

    # noinspection PyUnresolvedReferences

# Generated at 2022-06-23 18:51:11.141062
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(False, None, None)
    assert requests_session.proxies == {}
    assert requests_session.cert is None
    assert requests_session.verify == False


# Generated at 2022-06-23 18:51:23.657569
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify="True")) == {
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(verify="False")) == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': None,
    }

# Generated at 2022-06-23 18:51:25.906755
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=None, ssl_version=None, ciphers=None)
    assert session is not None

# Generated at 2022-06-23 18:51:28.609860
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:51:32.252785
# Unit test for function collect_messages
def test_collect_messages():
	import argparse

	parser = argparse.ArgumentParser(description='What is description?')
	args = parser.parse_args()
	config_dir = Path()
	request_body_read_callback = None
	list(collect_messages(args, config_dir, request_body_read_callback))


# Generated at 2022-06-23 18:51:33.551596
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'params': 'username=peanut&password=butter'}
    dump_request(kwargs)



# Generated at 2022-06-23 18:51:41.814740
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    from httpie.cli.base import default_options
    from httpie.cli.parser import parser
    from io import StringIO
    args = argparse.Namespace(**default_options)
    parser.parse_args(["--debug", "http://httpbin.org/get"], args)
    buf = StringIO()
    for request_or_response in collect_messages(args, None, lambda chunk: buf.write(chunk.decode("utf-8"))):
        print(request_or_response)


# Generated at 2022-06-23 18:51:46.583685
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': 'get',
        'url': 'http://www.google.com',
        'headers': {
            'User-Agent': 'HTTPie/0.9.6'
        },
        'data': '{"key":"value"}',
        'auth': 'admin:hello',
        'params': {'foo': 'bar'}
    }
    stdout = sys.stdout
    stdout_tmp = sys.stdout = StringIO()
    dump_request(kwargs)
    sys.stdout = stdout
    print(stdout_tmp.getvalue())

# Generated at 2022-06-23 18:51:58.072809
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Accept': '\ntext/html, application/xhtml+xml, application/xml\n',
               'Accept-Charset': ' utf-8, utf-16  ',
               'Accept-Language': '  de-AT, de;q=0.9 ',
               'Cache-Control': None}
    test_headers = finalize_headers(headers)
    assert test_headers['Accept'] == 'text/html, application/xhtml+xml, application/xml'
    assert test_headers['Accept-Charset'] == 'utf-8, utf-16'
    assert test_headers['Accept-Language'] == 'de-AT, de;q=0.9'
    assert test_headers['Cache-Control'] is None



# Generated at 2022-06-23 18:52:00.369908
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    assert http.client._MAXHEADERS != 5

# Generated at 2022-06-23 18:52:08.859707
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict()
    headers['Accept'] = 'application/json'
    headers['Content-Type'] = 'application/json'
    headers['  x-foo'] = '  bar '
    headers['x-bar'] = None
    headers['x-baz '] = 5
    headers['x-qux'] = ' '
    assert finalize_headers(headers) == {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'x-foo': 'bar',
        'x-baz': 5,
        'x-qux': ' ',
    }

# Generated at 2022-06-23 18:52:16.676123
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = ['http:127.0.0.1:90', 'https://127.0.0.1:80']
    args.verify = None
    args.cert = None
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {
            'http': '127.0.0.1:90',
            'https': '127.0.0.1:80'
        },
        'stream': True,
        'verify': True,
        'cert': None
    }
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'yes'
    args.cert = '/foo/bar'
    assert make_send_kwargs_mergeable_from_

# Generated at 2022-06-23 18:52:25.769969
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    args = argparse.Namespace(method='get',
                              url='http://localhost:8080/foo',
                              headers=None,
                              json=False,
                              chunked=False,
                              offline=False,
                              data=None,
                              form=False,
                              files=None,
                              auth=None,
                              params=None,
                              multipart=False,
                              multipart_data=None
                              )
    assert make_request_kwargs(args)['headers'] == {'User-Agent': 'HTTPie/',
                                                    'Accept':
                                                    'application/json, */*;q=0.5'}

# Generated at 2022-06-23 18:52:31.419715
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = make_default_headers(argparse.Namespace(
        data=None,
        form=None,
        json=None,
        files=None,
    ))
    headers.update(RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    }))
    headers.update(RequestHeadersDict({
        'Accept': '*'
    }))
    headers.update(RequestHeadersDict({
        'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'
    }))
    final_headers = finalize_headers(headers)
    assert 'User-Agent' in final_headers
    assert 'Accept' in final_headers
    assert 'Content-Type' in final_headers

# Generated at 2022-06-23 18:52:37.975806
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestsHeadersDict({
        "User-Agent": "HTTPie/0.9.9",
        "Accept": "application/json, */*;q=0.5",
        "Content-Type": "application/json",
        "X-Client-ID": None
    })

    final_headers = RequestHeadersDict({
        'User-Agent': 'HTTPie/0.9.9',
        'Accept': 'application/json, */*;q=0.5',
        'Content-Type': 'application/json'
    })

    if(finalize_headers(headers) != final_headers):
        print("Unit test for function finalize_headers: FAILED")
    else:
        print("Unit test for function finalize_headers: PASSED")



# Generated at 2022-06-23 18:52:48.312904
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = ['https://httpbin.org/anything', '--form', '--json', '{}', '--headers','{"Content-Type":"multipart/form-data; boundary=--------------------------845251939347230211941838"}']
    parser = argparse.ArgumentParser()
    parser.add_argument("url", help="The url of the website or API you want to make a request to. To send data use the --data flag.")
    parser.add_argument("--json", help="Sends JSON data in the body of your request. If you have a JSON file you can send the contents using --json=@filename.json.", action="store_true")

# Generated at 2022-06-23 18:52:49.417155
# Unit test for function collect_messages
def test_collect_messages():
    pass


# Generated at 2022-06-23 18:52:53.403978
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    orig = 'http://foo/../'
    prepped = 'http://foo/?foo=bar'
    final = 'http://foo/../?foo=bar'

    assert(ensure_path_as_is(orig, prepped) == final)

# Generated at 2022-06-23 18:53:02.005881
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    """ Test function make_send_kwargs_mergeable_from_env """
    args = argparse.Namespace()
    args.verify = "/path/to/cert/file"
    args.cert = "cert"
    args.cert_key = "cert_key"
    args.proxy = []
    if make_send_kwargs_mergeable_from_env(args) == {'proxies': {}, 'stream': True, 'verify': '/path/to/cert/file', 'cert': ('cert', 'cert_key')}:
        print("Passed Unit Test")
    else:
        print("Failed Unit Test")
test_make_send_kwargs_mergeable_from_env()

# Generated at 2022-06-23 18:53:11.276268
# Unit test for function collect_messages

# Generated at 2022-06-23 18:53:16.799896
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert 'foo.com/?bar=baz&b=2' == ensure_path_as_is(
        'http://foo.com/',
        'http://foo.com/?bar=baz&b=2'
    )
    assert 'http://foo.com/%2' == ensure_path_as_is(
        'http://foo.com/%2',
        'http://foo.com/%2?bar=baz&b=2'
    )

# Generated at 2022-06-23 18:53:27.184565
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:53:30.615027
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        files=None,
        form=True,
        json=False,
        json_pp=False,
    )
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA



# Generated at 2022-06-23 18:53:41.245736
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'POST'
    args.url = 'www.google.com'
    args.headers = {'Content-Type': 'application/json'}
    args.data = {'key1': 'value1', 'key2': 'value2'}
    args.json = 'POST'
    args.form = False
    args.files = False
    args.multipart = False
    args.multipart_data = {'key1': 'value1', 'key2': 'value2'}
    args.boundary = '--------------------------509898181022733790888229'
    args.auth = ('admin', 'password')
    args.params = {'key1': 'value1', 'key2': 'value2'}
    args.verify = False

# Generated at 2022-06-23 18:53:43.878423
# Unit test for function finalize_headers
def test_finalize_headers():
    test_headers = RequestHeadersDict({'a': '1', 'b': '2'})
    assert finalize_headers(test_headers) == {'a': '1', 'b': '2'}

# Generated at 2022-06-23 18:53:49.948542
# Unit test for function finalize_headers
def test_finalize_headers():
    # Test whether function finalize_headers ignores leading or trailing whitespace.
    assert finalize_headers(RequestHeadersDict({'User-Agent': '\n HTTPie/1.0.0\t'})) == RequestHeadersDict({'User-Agent': b'HTTPie/1.0.0'})

# Generated at 2022-06-23 18:53:55.325344
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
        timeout='0.1',
        allow_redirects=False,
    )
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == float(0.1)
    assert kwargs['allow_redirects'] == False

# Generated at 2022-06-23 18:54:05.312989
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = "get"
    args.url = "http://test.com"
    args.headers = {}
    args.data = "test"
    make_request_kwargs(args=args)
    # Test exception
    args = argparse.Namespace()
    args.method = "get"
    args.url = ""
    args.headers = {}
    args.data = "test"
    try:
        make_request_kwargs(args=args)
    except Exception as e:
        assert e.args[0] == "Can not send request to the server that has no url"

# Generated at 2022-06-23 18:54:10.638039
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: None
    msg_list = [msg for msg in collect_messages(args, config_dir, request_body_read_callback)]
    assert msg_list == []

# Generated at 2022-06-23 18:54:12.113182
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(False)
    assert(requests_session.mount('https://', HTTPieHTTPSAdapter()) is not None)

# Generated at 2022-06-23 18:54:20.546295
# Unit test for function build_requests_session
def test_build_requests_session():
    from json import dumps, loads
    session = build_requests_session(verify=True, ssl_version='TLSv1.1')
    response = session.get("https://httpbin.org/get")
    assert loads(response.text) == {"args": {}, "headers": {"Accept": "*/*", "Accept-Encoding": "gzip, deflate", "Connection": "close", "Host": "httpbin.org", "User-Agent": "python-requests/2.19.1"}, "url": "https://httpbin.org/get"}
    session = build_requests_session(verify=False, ssl_version='TLSv1.2')
    response = session.post("https://httpbin.org/post", data=dumps({"foo": "bar"}))

# Generated at 2022-06-23 18:54:30.650546
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    # Test for default httpie
    args.data = None
    args.form = False
    args.json = False
    args.files = False
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA

    # Test for json content
    args.json = True
    args.data = {'foo': 'bar'}
    default_headers = make_default_headers(args)
    assert default_headers['User-Agent'] == DEFAULT_UA
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    # Test for json auto content
    args.json = False
    default_headers = make_default_headers(args)
    assert default_

# Generated at 2022-06-23 18:54:39.060456
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = False
    args.files = {}
    default_headers = make_default_headers(args)
    default_headers_want = RequestHeadersDict({
        'User-Agent': DEFAULT_UA
    })
    assert default_headers == default_headers_want
    args.json = True
    default_headers = make_default_headers(args)
    default_headers_want = RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE
    })
    assert default_headers == default_headers_want
    args.json = False
    args.form = True
    args.files = {}
   

# Generated at 2022-06-23 18:54:42.387067
# Unit test for function max_headers
def test_max_headers():
    assert(max_headers.__code__.co_varnames[0] == 'limit')
    assert(max_headers.__code__.co_varnames[1] == 'orig')
    assert(max_headers.__code__.co_varnames[2] == '__tracebackhide__')

# Generated at 2022-06-23 18:54:45.758126
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    arg_parser = argparse.ArgumentParser()
    args = arg_parser.parse_args([])
    print(make_send_kwargs(args))

if __name__ == "__main__":
    test_make_send_kwargs()

# Generated at 2022-06-23 18:54:53.372161
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        cert='<some path>',
        cert_key='<some path>',
        proxy=[
            argparse.Namespace(
                key='foo',
                value='bar'
                )
            ],
        verify='yes',
    )
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert kwargs['cert'] == ('<some path>', '<some path>')
    assert kwargs['proxies'] == {'foo': 'bar'}
    assert kwargs['verify']
    assert kwargs['stream']
    assert kwargs['allow_redirects'] == False

# Generated at 2022-06-23 18:54:56.253945
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 1000
    with max_headers(2000):
        assert http.client._MAXHEADERS == 2000
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:55:05.298441
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = "True"
    args.cert = ""
    args.timeout = 10
    args.chunked = False
    args.offline = False
    args.max_headers = 40
    result = dict({
        'proxies': {},
        'stream': True,
        'verify': True,
        'cert': "",
        'timeout': 10,
        'allow_redirects': False,
    })
    assert make_send_kwargs(args) == result


# Generated at 2022-06-23 18:55:17.761065
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    # 1. Test for the successful case
    # Test for the case when the base URL has a query parameter (curl
    # appends a ? if the base URL does not have a query)

    result = ensure_path_as_is(
        'http://foo/../',
        'http://foo/?foo=bar'
    )
    try:
        assert result == 'http://foo/../?foo=bar'
        print('1. OK!')
    except AssertionError:
        print('1. ERROR!')


    # 2. Test for the case when the base URL doesn't have a query parameter
    # (curl appends a ? if the base URL does not have a query)
    result = ensure_path_as_is(
        'http://foo/../',
        'http://foo'
    )

# Generated at 2022-06-23 18:55:26.168706
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/..', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo/', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'
    assert ensure_path_as_is('http://foo:8080/../', 'http://foo:8080/?foo=bar') == 'http://foo:8080/../?foo=bar'

# Generated at 2022-06-23 18:55:32.557059
# Unit test for function build_requests_session
def test_build_requests_session():
    class Test_plugin_cls(object):
        def __init__(self):
            self.prefix = 'http://httpbin.org'

        def get_adapter(self):
            return 'Test_plugin_adapter'


    def test_plugin_manager_get_transport_plugins():
        return {Test_plugin_cls}


    plugin_manager.get_transport_plugins = test_plugin_manager_get_transport_plugins
    args = argparse.Namespace()
    args.ssl_version = None
    args.ciphers = None
    args.verify = True
    verify = bool(args.verify)

# Generated at 2022-06-23 18:55:41.488871
# Unit test for function finalize_headers
def test_finalize_headers():
    test_headers = []
    assert test_headers == finalize_headers({})
    assert test_headers == finalize_headers(None)
    assert test_headers == finalize_headers(['foo: bar'])
    assert test_headers == finalize_headers(['foo'])
    assert test_headers == finalize_headers([['foo']])
    assert test_headers == finalize_headers(['foo=bar'])
    assert test_headers == finalize_headers([['foo=bar']])
    assert test_headers == finalize_headers([{'foo': 'bar'}])
    assert test_headers == finalize_headers([{'foo': 'bar'}])
    assert test_headers == finalize_headers([{'foo': 1}])
    assert test_headers == finalize_headers([1])

# Generated at 2022-06-23 18:55:43.832327
# Unit test for function make_default_headers
def test_make_default_headers():
    import doctest
    (failed, total) = doctest.testmod()
    assert failed == 0, f'Failed {failed} out of {total} doctests.'


# Generated at 2022-06-23 18:55:53.248913
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'yes'
    args.proxy = '127.0.0.1:8080'
    args.cert = 'client.crt'
    args.cert_key = 'client_key.key'

    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env['verify'] == True
    assert send_kwargs_mergeable_from_env['proxies']['http'] == '127.0.0.1:8080'
    assert send_kwargs_mergeable_from_env['cert'] == ('client.crt', 'client_key.key')



# Generated at 2022-06-23 18:56:01.952877
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    class Args:
        def __init__(self):
            self.proxy = []
            self.verify = "yes"
            self.cert = None
            self.cert_key = None

    args = Args()
    proxy1 = Args()
    proxy1.key = "http"
    proxy1.value = "10.0.0.1:8080"
    proxy2 = Args()
    proxy2.key = "https"
    proxy2.value = "10.0.0.1:8080"
    args.proxy.append(proxy1)
    args.proxy.append(proxy2)
    args.cert = "cert"
    args.cert_key = "cert_key"
    kwargs = make_send_kwargs_mergeable_from_env(args)
    assert k

# Generated at 2022-06-23 18:56:09.247829
# Unit test for function finalize_headers
def test_finalize_headers():
    # Test that leading and trailing white spaces are removed from header values
    # assert finalize_headers({"Accept": "*/*"}) == {"Accept": "*/*"}
    assert finalize_headers({"Accept": " application/json"}) == {"Accept": "application/json"}
    assert finalize_headers({"Accept": "application/json "}) == {"Accept": "application/json"}
    assert finalize_headers({"Accept": " application/json "}) == {"Accept": "application/json"}
    # Test that Accept is set to JSON if it is not set by the user
    assert make_default_headers(argparse.Namespace(json=False, form=False, files=False, data=None)) == {"Accept": "application/json, */*;q=0.5", "User-Agent": "HTTPie/0.9.8"}

# Generated at 2022-06-23 18:56:14.744859
# Unit test for function make_send_kwargs
def test_make_send_kwargs():

    def set_up_namespace(arg_dict):
        args = argparse.Namespace()
        for arg, val in arg_dict.items():
            setattr(args, arg, val)
        return args

    arg_dict = {'timeout': 900,
                'allow_redirects': False}
    args = set_up_namespace(arg_dict)
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': 900, 'allow_redirects': False}

# Generated at 2022-06-23 18:56:20.872120
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    base_headers = RequestHeadersDict({})
    args.method = 'post'
    args.url = 'http://127.0.0.1:5000/'
    args.headers = RequestHeadersDict({'Content-type': 'application/json'})
    args.data = {'test': 'success'}
    args.auth = ('admin', '123456')
    args.params = {'is_admin': True}

    assert make_request_kwargs(args, base_headers=base_headers)

# Generated at 2022-06-23 18:56:29.359912
# Unit test for function finalize_headers
def test_finalize_headers():
    # Test1: a dict
    s = finalize_headers(headers={'content-type': 'application/x-www-form-urlencoded; charset=utf-8'})
    assert s == {"content-type": b"application/x-www-form-urlencoded; charset=utf-8"}
    # Test2: a RequestHeadersDict
    s = finalize_headers(headers=RequestHeadersDict({'content-type': 'application/x-www-form-urlencoded; charset=utf-8'}))
    assert s == {"content-type": b"application/x-www-form-urlencoded; charset=utf-8"}
    # Test3: a list

# Generated at 2022-06-23 18:56:33.618896
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    kwargs = make_send_kwargs(None)
    assert kwargs.get('timeout') == None
    assert kwargs.get('allow_redirects') == False


# Generated at 2022-06-23 18:56:42.105227
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    kwargs = {
        'method': 'GET',
        'url': 'www.test.test',
        'headers': {
            'User-Agent': DEFAULT_UA,
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        'data': json.dumps('{}'),
        'auth': None,
        'params': [{}],
        'timeout': 60,
        'proxies': '',
        'allow_redirects': True,
    }
    dump_request(kwargs)


# Generated at 2022-06-23 18:56:52.386175
# Unit test for function finalize_headers
def test_finalize_headers():
    # blank space test
    headers = RequestHeadersDict({
        'Accept': '*/*',
        'Host': 'a',
    })
    final_headers = finalize_headers(headers)
    assert('*/*' == final_headers['Accept'])

    # utf-8 test
    headers = RequestHeadersDict({
        'Accept': '中文',
    })
    final_headers = finalize_headers(headers)
    assert('中文' == final_headers['Accept'].decode('utf8'))

    # blank space and utf-8 test
    headers = RequestHeadersDict({
        'Accept': '  中文',
        'Host': 'a',
    })
    final_headers = finalize_headers(headers)

# Generated at 2022-06-23 18:56:55.068330
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Test': 'Test'}
    headers['Test'] = None
    assert ('Test' not in headers)

# Generated at 2022-06-23 18:57:05.043560
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        auth='bob@example.com:password',
        chunked=False,
        data=None,
        files=None,
        form=False,
        headers=[],
        json=False,
        method='GET',
        multipart=False,
        params=[],
        url='https://bob@example.com:password@localhost',
        verify=True,
        ssl_version='SSLv3',
        ciphers=''
    )

    result = make_request_kwargs(args, lambda x: x)

# Generated at 2022-06-23 18:57:07.054571
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(ssl_version = 'tlsv1.2')

# Generated at 2022-06-23 18:57:09.981675
# Unit test for function max_headers
def test_max_headers():
    try:
        with max_headers(4):
            assert http.client._MAXHEADERS == 4
    finally:
        assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:57:13.996103
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo/../') == 'http://foo/../'

# Generated at 2022-06-23 18:57:21.851076
# Unit test for function build_requests_session
def test_build_requests_session():
    """
    Test build_requests_session

    """
    # Test the default setting
    verify = True
    built_session = build_requests_session(ssl_version=None, ciphers=None, verify=verify)
    assert isinstance(built_session, requests.Session)
    assert built_session.cert == None
    assert built_session.verify == True

    # Test the setting with proxy
    verify = True
    built_session = build_requests_session(ssl_version='TLSv1.2', ciphers='MD5', verify=verify)
    assert isinstance(built_session, requests.Session)
    assert built_session.cert == None
    assert built_session.verify == True
    assert built_session.cert_store.get_current_x509_store().get_default_

# Generated at 2022-06-23 18:57:23.865418
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 1000
    with max_headers(100) as context:
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:57:30.216263
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'true'
    args.proxy = [
    {'scheme': 'http', 'hostname': '127.0.0.1', 'port': '8080', 'username': 'user', 'password': 'pass'},
    {'scheme': 'socks4', 'hostname': '127.0.0.1', 'port': '9050'}
    ]
    args.cert = 'test/test'
    args.cert_key = 'test/test_key'
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-23 18:57:32.459055
# Unit test for function collect_messages
def test_collect_messages():
    import httpie
    import sys
    # noinspection PyProtectedMember
    args = httpie.cli.parse_args([])
    collect_messages(args,sys.modules[__name__].__file__)

# Generated at 2022-06-23 18:57:33.914020
# Unit test for function dump_request
def test_dump_request():
    kwargs = {}
    dump_request(kwargs)

# Generated at 2022-06-23 18:57:34.385453
# Unit test for function collect_messages
def test_collect_messages():
    return True

# Generated at 2022-06-23 18:57:43.478742
# Unit test for function make_send_kwargs

# Generated at 2022-06-23 18:57:48.677554
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    expected_result = "\n>>> requests.request(**{'url': None, 'method': 'GET'})\n\n"
    actual_result=dump_request({'url': None, 'method': 'GET'})
    assert(actual_result == expected_result)

# Generated at 2022-06-23 18:57:57.877500
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    test_args = argparse.Namespace()
    test_args.verify = True
    test_args.cert = "cert"

    kwargs = make_send_kwargs_mergeable_from_env(test_args)
    assert kwargs == {'proxies': {}, 'stream': True, 'verify': True, 'cert': "cert"}


    # test for proxies
    test_args.proxy = ["a","b"]
    kwargs = make_send_kwargs_mergeable_from_env(test_args)
    assert kwargs == {'proxies': {'a': None, 'b': None}, 'stream': True, 'verify': True, 'cert': "cert"}