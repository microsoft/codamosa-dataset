

# Generated at 2022-06-23 18:47:53.507281
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    def test_case(args, expected):
        actual = make_send_kwargs({'timeout':args})
        print('case',args,'\n',actual,'\n',expected)
        assert actual==expected
    test_case(args=None, expected={})
    test_case(args=1, expected={'timeout':1})
    test_case(args=float('inf'), expected={'timeout':float('inf')})
    # Unit test for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-23 18:47:58.736912
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': 'get',
        'url': 'http://www.google.com',
        'headers': {
            'User-Agent': 'HTTPie/0.9.8'
        },
        'data': {}
    }
    print(kwargs)
    dump_request(kwargs)

if __name__ == '__main__':
    test_dump_request()

# Generated at 2022-06-23 18:48:11.648744
# Unit test for function make_default_headers
def test_make_default_headers():
    def test(args, expected):
        assert make_default_headers(args) == expected

    test(argparse.Namespace(
        json=True,
        data='foo',
        form=False,
        files=False,
    ), {
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE,
        'User-Agent': DEFAULT_UA
    })

    test(argparse.Namespace(
        json=False,
        data='foo',
        form=True,
        files=False,
    ), {
        'Accept': '*/*',
        'Content-Type': FORM_CONTENT_TYPE,
        'User-Agent': DEFAULT_UA
    })


# Generated at 2022-06-23 18:48:15.597571
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    kwargs = make_send_kwargs_mergeable_from_env(args=None)
    if not isinstance(kwargs, dict):
        raise Exception(
            'make_send_kwargs_mergeable_from_env must return a dict')

# Generated at 2022-06-23 18:48:27.420768
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Test without proxy
    args = argparse.Namespace()
    args.timeout = ''
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {'timeout': None, 'allow_redirects': False}

    # Test with proxy
    args = argparse.Namespace()
    args.proxy = ''
    args.stream = True
    args.verify = ''
    args.cert = ''
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env == {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

# Generated at 2022-06-23 18:48:32.106230
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path('.')
    request_body_read_callback = None
    messages = collect_messages(args, config_dir, request_body_read_callback)
    print(messages)
    # print(requests.Response.next)

# Generated at 2022-06-23 18:48:35.444393
# Unit test for function finalize_headers
def test_finalize_headers():
    headers_dict = {'    Authorization': 'Bearer 123456'}
    final_headers = finalize_headers(headers_dict)
    assert final_headers == {'Authorization': 'Bearer 123456'}

# Generated at 2022-06-23 18:48:36.999047
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:48:48.613114
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    a = argparse.Namespace()
    a.timeout = 120
    a.allow_redirects = False
    a.proxies = 'http://www.baidu.com'
    a.stream = True
    a.verify = True
    a.cert = './cert'
    a.cert_key = './key'
    assert make_send_kwargs(a)['timeout'] == 120
    assert make_send_kwargs(a)['allow_redirects'] == False
    assert make_send_kwargs_mergeable_from_env(a)['proxies'] == 'http://www.baidu.com'
    assert make_send_kwargs_mergeable_from_env(a)['stream'] == True
    assert make_send_kwargs_mergeable_from_

# Generated at 2022-06-23 18:48:53.510094
# Unit test for function max_headers
def test_max_headers():
    with max_headers(None):
        assert http.client._MAXHEADERS is float('Inf')
    assert http.client._MAXHEADERS == 1000  # default value
    with max_headers(500):
        assert http.client._MAXHEADERS == 500
    assert http.client._MAXHEADERS == 1000  # default value


# Generated at 2022-06-23 18:48:54.432402
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:48:57.192921
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    assert http.client._MAXHEADERS != 5


# Generated at 2022-06-23 18:49:07.534787
# Unit test for function build_requests_session
def test_build_requests_session():
    """
    Unit test for function build_requests_session
    """
    # pylint: disable=protected-access
    assert isinstance(build_requests_session(verify=True), requests.Session)
    assert not isinstance(build_requests_session(verify=False), requests.Session)
    assert isinstance(build_requests_session(ssl_version='tls1.3', verify=True),
                      requests.Session)
    assert not isinstance(build_requests_session(ssl_version='tls1.3', verify=False),
                         requests.Session)
    assert isinstance(build_requests_session(ciphers='TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384'), requests.Session)

# Generated at 2022-06-23 18:49:14.722950
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args = argparse.Namespace()
    args.method = 'get'
    args.url = 'https://www.baidu.com'
    args.headers = {}
    args.browse = False
    args.check_status = False
    args.headers = RequestHeadersDict()
    args.http_status_only = False
    args.ignore_stdin = False
    args.max_redirects = 30
    args.output_file = None
    args.pretty = 'all'
    args.print_body = True
    args.style = 'solarized'
    args.style_error = 'solarized'
    args.style_headers = 'solarized'
    args.style_http_error = 'solarized'

# Generated at 2022-06-23 18:49:26.784590
# Unit test for function dump_request
def test_dump_request():
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.plugins import AuthPlugin
    from httpie.config import Config, JSONStream
    from httpie.status import ExitStatus
    from httpie.cli.parser import parse_args

    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test'

    class TestConfig(Config):
        env = Environment()
        directory = None

        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)


    base_url = 'http://echo.josefsson.org/put'
    filename = 'test_dump_request.txt'
    data = '{}'
    verify = 'yes'

# Generated at 2022-06-23 18:49:30.028010
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-23 18:49:32.816775
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    Boolean = True
    timeout = False
    kwargs = {
        'timeout': timeout or None,
        'allow_redirects': Boolean,
    }
    assert make_send_kwargs(Boolean) == kwargs


# Generated at 2022-06-23 18:49:34.885982
# Unit test for function dump_request
def test_dump_request():
    with open('tests/test_dump_request.txt','r') as f:
        assert dump_request(kwargs={'url': 'https://github.com', 'data': 'No'})==f.read()

# Generated at 2022-06-23 18:49:40.255514
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.headers = RequestHeadersDict()
    args.json = False
    args.data = {'a': 'b'}
    args.form = False
    # If test case pass, it means that the make_default_headers function is working normally.
    make_default_headers(args)

# Generated at 2022-06-23 18:49:52.820255
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace(
        auth=None,
        auth_plugin=None,
        chunked=False,
        cert=None,
        cert_key=None,
        client_cert=None,
        debug=False,
        data='',
        default=False,
        download=False,
        form=False,
        headers={},
        ignore_stdin=False,
        json=False,
        max_headers=False,
        method='GET',
        offline=False,
        params=None,
        pretty=False,
        proxies=None,
        session=None,
        session_read_only=None,
        style=False,
        traceback=False,
        url=None,
        upload=False,
        verify=False,
        verbose=False,
    )
    config

# Generated at 2022-06-23 18:50:03.599149
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {
        'Host': '',
        'User-Agent': 'HTTPie/0.9.2',
        'Accept': 'application/json, */*;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'X-Test': 'test\t'
    }
    expected = {
        'Host': '',
        'User-Agent': b'HTTPie/0.9.2',
        'Accept': b'application/json, */*;q=0.5',
        'Accept-Encoding': b'gzip, deflate',
        'Connection': b'keep-alive',
        'X-Test': b'test'
    }
    correct_output = finalize_headers(RequestHeadersDict(headers))

# Generated at 2022-06-23 18:50:08.997793
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method'   : 'get',
        'url'      : 'http://www.xxx.net',
        'headers'  : {'hh':'hh'},
        'data'     : 'data',
        'auth'     : ('name', 'pass'),
        'params'   : {'a':'a', 'b':'b'}
    }
    dump_request(kwargs)


# Generated at 2022-06-23 18:50:10.280306
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
        with max_headers(200):
            assert http.client._MAXHEADERS == 200
        assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:50:16.451618
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace(
        cert='',
        cert_key='',
        verify='no',
        proxy=[]
    )
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': None
    }

# Generated at 2022-06-23 18:50:26.826650
# Unit test for function make_default_headers

# Generated at 2022-06-23 18:50:34.561286
# Unit test for function max_headers
def test_max_headers():

    # test with a limit

    with max_headers(5):
        pass

    # test without a limit

    with max_headers(None):
        pass

    # test with a non-integer limit raises TypeError

    try:
        with max_headers("test"):
            pass
    except TypeError as e:
        # expected since the limit is non-integer
        pass

    # test with a non-integer limit raises TypeError

    try:
        with max_headers(5.5):
            pass
    except TypeError as e:
        # expected since the limit is non-integer
        pass

# Generated at 2022-06-23 18:50:44.118788
# Unit test for function dump_request

# Generated at 2022-06-23 18:50:55.897009
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:51:03.497415
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # TODO before submiting pull, delete this function and the import from test_unittest.py
    import sys;

    sys.stderr.write("make_send_kwargs is being tested")
    assert str(make_send_kwargs(args=None, kwargs="hello")) == "hello"
    assert str(make_send_kwargs(args=None, kwargs="hello")) == "hello"

    assert (False)

# Generated at 2022-06-23 18:51:11.042676
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'False'
    args.cert = 'cert'
    args.cert_key = 'cert_key'
    assert make_send_kwargs_mergeable_from_env(args) == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': 'cert',
    }

# Generated at 2022-06-23 18:51:12.760277
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'method': "GET"
    }
    dump_request(kwargs)

# Generated at 2022-06-23 18:51:16.202941
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(verify=True, ssl_version="TLS1.1", ciphers=None)
    assert requests_session != None



# Generated at 2022-06-23 18:51:23.610646
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'true'
    expected = {
        'proxies': {p.key: p.value for p in args.proxy},
        'stream': True,
        'verify': True,
        'cert': None,
    }
    assert make_send_kwargs_mergeable_from_env(args) == expected


# Generated at 2022-06-23 18:51:31.675789
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    urls = [
        'http://foo/bar',
        'http://foo/?foo=bar',
        'http://foo/%3Ffoo=bar',
        'http://foo/../bar',
        'http://foo/bar/..',
        'http://foo/',
        'http://foo',
        'http://foo/bar/../baz',
        'http://foo/bar/..;param?foo=bar',
    ]
    for url in urls:
        assert ensure_path_as_is(url, url) == url

# Generated at 2022-06-23 18:51:38.127017
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=1, allow_redirects=False)
    expected_kwargs = {'timeout': 1, 'allow_redirects': False}
    assert expected_kwargs == make_send_kwargs(args)



# Generated at 2022-06-23 18:51:47.062439
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    from requests.structures import CaseInsensitiveDict
    from utils import Config
    import os
    import sys

    config_directory = os.path.join(os.path.expanduser("~"), ".config/httpie")
    if not os.path.exists(config_directory):
        os.makedirs(config_directory)

    config_file_path = os.path.join(config_directory, "config.json")
    sys.stdout.write("config_file_path:{}\n".format(config_file_path))
    sys.stdout.write("config_directory:{}\n".format(config_directory))

    args = argparse.Namespace()
    args.__setattr__("url", "--url=http://www.stackoverflow.com")
    args.__set

# Generated at 2022-06-23 18:51:59.432615
# Unit test for function collect_messages
def test_collect_messages():
    import sys
    import json
    import os
    import tempfile
    from httpie import __main__ as httpie
    #import httpie
    import os
    import shlex
    import signal
    import sys
    import tempfile
    import contextlib
    import os
    import signal
    import subprocess
    import sys
    import types
    import unittest
    from httpie.compat import is_windows, isatty
    from httpie.output.streams import STREAM_BINARY_SUPPRESSED_NOTICE
    from httpie.cli import main as httpie_main
    from httpie.context import Environment
    from httpie.plugins import plugin_manager, TransportPlugin


    class CustomPlugin(TransportPlugin):
        name = 'custom'
        description = 'Custom plugin'


# Generated at 2022-06-23 18:52:04.044713
# Unit test for function max_headers
def test_max_headers():
    try:
        http.client._MAXHEADERS = 300
        with max_headers(200):
            assert http.client._MAXHEADERS == 200
        assert http.client._MAXHEADERS == 300
    except Exception as e:
        print(e)
    finally:
        http.client._MAXHEADERS = 100

# Generated at 2022-06-23 18:52:12.529225
# Unit test for function collect_messages
def test_collect_messages():
    # $ pytest tests/test_collect_messages.py
    import os
    import sys
    prog_dir = os.path.dirname(__file__)
    httpie_dir = os.path.dirname(prog_dir)
    root_dir = os.path.dirname(httpie_dir)
    sys.path.append(root_dir)
    from httpie.cli.utils import get_args
    args = get_args(["http://127.0.0.1/search?q=name:foo"])
    config_dir = Path("~/")
    messages = [item for item in collect_messages(args, config_dir)]

# Generated at 2022-06-23 18:52:19.782944
# Unit test for function finalize_headers
def test_finalize_headers():
    # Basic tests
    assert finalize_headers({"test": "test"}) == {"test": "test"}
    assert finalize_headers({"test": "test", "test2": "test2"}) == {
        "test": "test",
        "test2": "test2"
    }
    assert finalize_headers({"test": "test", "test2": None}) == {"test": "test"}
    assert finalize_headers({"test": "test", "test2": None, "test3": "test3"}) == {
        "test": "test",
        "test3": "test3"
    }
    assert finalize_headers(None) == RequestHeadersDict()

# Generated at 2022-06-23 18:52:25.499695
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'url': 'http://httpbin.org/get', 'method': 'GET', 'headers': {'User-Agent': 'HTTPie/0.9.8', 'Accept-Encoding': 'gzip, deflate', 'Accept': 'application/json', 'Connection': 'keep-alive'}, 'params': [('foo', 'bar'), ('baz', 'xoxo')], 'auth': None}
    dump_request(kwargs)

# Generated at 2022-06-23 18:52:30.916288
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = "False"
    args.cert = "certificate"
    args.cert_key = "certificate_key"
    result = make_send_kwargs_mergeable_from_env(args)
    assert result["proxies"] == {}
    assert result["verify"] == False
    assert result["cert"] == "certificate"

# Generated at 2022-06-23 18:52:35.007603
# Unit test for function max_headers
def test_max_headers():
    assert http.client._MAXHEADERS == 1000
    with max_headers(None):
        assert http.client._MAXHEADERS == float("Inf")
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS == 1000


# Generated at 2022-06-23 18:52:37.240896
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = CommandLineArgumentParser().parse_args()

    print(make_send_kwargs(args))

# Generated at 2022-06-23 18:52:39.381183
# Unit test for function make_default_headers
def test_make_default_headers():
    test_args = argparse.Namespace()
    header = make_default_headers(test_args)
    assert header['User-Agent'] == DEFAULT_UA


# Generated at 2022-06-23 18:52:42.061009
# Unit test for function collect_messages
def test_collect_messages():
    collect_messages('http://mockbin.com/request', config_dir=None, request_body_read_callback=None)

# Generated at 2022-06-23 18:52:46.811753
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = False
    ssl_version = 'SSLv2'
    ciphers = 'ECDHE-ECDSA-CHACHA20-POLY1305'
    requests_session = build_requests_session(verify, ssl_version, ciphers)
    sys.stderr.write(requests_session.headers)




# Generated at 2022-06-23 18:52:50.951697
# Unit test for function collect_messages
def test_collect_messages():
    # test code
    args = argparse.Namespace()
    config_dir = Path()
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)



# Generated at 2022-06-23 18:52:55.144214
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'method': 'POST', 'url': 'https://some.com/some/path',
              'headers': {'X-Custom-Header': 'Custom value'}, 'data': 'foo'}
    dump_request(kwargs)



# Generated at 2022-06-23 18:53:00.202203
# Unit test for function dump_request
def test_dump_request():
    args = argparse.Namespace()
    kwargs = {
        'method': 'GET',
        'url': 'http://foo.com/bar',
        'headers': {"foo": "bar"},
        'data': '{"name": "baz"}',
        'auth': None,
        'params': [],
    }
    dump_request(kwargs)
    assert True

# Generated at 2022-06-23 18:53:04.506592
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    assert 'Accept' not in make_default_headers(args)
    setattr(args, 'json', True)
    assert make_default_headers(args)['Accept'] == JSON_ACCEPT

# Generated at 2022-06-23 18:53:08.979991
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 3
    args.allow_redirects = False
    kwargs = make_send_kwargs(args)
    assert kwargs == {
        'timeout': 3,
        'allow_redirects': False,
    }



# Generated at 2022-06-23 18:53:14.764285
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(False, None, None)
    assert isinstance(requests_session, requests.Session)
    assert isinstance(list(requests_session.adapters.values())[0], requests.adapters.HTTPAdapter)
    requests_session = build_requests_session(True, 'tls1_0', None)
    assert isinstance(list(requests_session.adapters.values())[0].ssl_context, ssl.SSLContext)

# Generated at 2022-06-23 18:53:16.865557
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({'foo': ' bar '}) == {'foo': b'bar'}

# Generated at 2022-06-23 18:53:20.336303
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = None
    args.allow_redirects = False
    assert make_send_kwargs(args) == {'allow_redirects': False, 'timeout': None}


# Generated at 2022-06-23 18:53:28.865259
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({"ACCEPT": "text/plain"}) == {"accept": "text/plain"}
    assert finalize_headers({"accept": "text/plain"}) == {"accept": "text/plain"}
    assert finalize_headers({"Accept": "text/plain"}) == {"accept": "text/plain"}
    assert finalize_headers({}) == {}
    assert finalize_headers({"X": "Y"}) == {"x": "Y"}
    assert finalize_headers({"x": " Y "}) == {"x": "Y"}
    assert finalize_headers({b"x": b" Y "}) == {"x": "Y"}


# Generated at 2022-06-23 18:53:39.582114
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        method='GET',
        auth='httpie',
        cert='httpie_cert',
        chunked=False,
        data='httpie_data',
        form=False,
        files='httpie_files',
        headers={'httpie': 'httpie_header'},
        json=False,
        offline=False,
        params={'httpie': 'httpie_param'},
        path_as_is=True,
        proxy='httpie_proxy',
        session='httpie_session',
        session_read_only='httpie_session_read_only',
        url='httpie_url',
        verify='true',
        version=True,
    )
    base_headers = {'httpie': 'httpie_base_header'}
    request_body_

# Generated at 2022-06-23 18:53:41.591535
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:53:43.024861
# Unit test for function build_requests_session
def test_build_requests_session():
    kwargs = {}
    requests_session = build_requests_session(**kwargs)
    assert requests_session

# Generated at 2022-06-23 18:53:50.439054
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():


    # noinspection SpellCheckingInspection
    kwargs = make_send_kwargs_mergeable_from_env(
        argparse.Namespace(
            proxy=[],
            verify='yes',
            cert='/tmp/certy.cert',
            cert_key='/tmp/certy_key.cert'
        )
    )

    assert kwargs['verify'] == 'yes'

# Generated at 2022-06-23 18:54:01.138501
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():

    send_kwargs_mergeable_from_env_true = {'proxies': {'username': 'user', 'password': 'pass'}, 'stream': True, 'verify': {'yes': True, 'true': True, 'no': False, 'false': False}.get('true', True), 'cert': True}
    args = argparse.Namespace(verify='true')
    assert make_send_kwargs_mergeable_from_env(args) == send_kwargs_mergeable_from_env_true
    args = argparse.Namespace(verify='yes')
    assert make_send_kwargs_mergeable_from_env(args) == send_kwargs_mergeable_from_env_true
    args = argparse.Namespace(verify=True)
    assert make_send_

# Generated at 2022-06-23 18:54:06.100834
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {
        '   Content-Type    ': '  application/json   ',
        'User-Agent': 'HTTPie/1.0.3',
        'Accept': None,
    }
    final_headers = finalize_headers(headers);
    assert final_headers['   Content-Type    '] == b'application/json'
    assert final_headers['User-Agent'] == b'HTTPie/1.0.3'
    assert final_headers['Accept'] == None



# Generated at 2022-06-23 18:54:07.762597
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(False)
    assert requests_session != None

# Generated at 2022-06-23 18:54:14.457776
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    arguments = argparse.Namespace()
    arguments.proxy = []
    arguments.verify = 'yes'
    arguments.cert = None
    arguments.cert_key = None
    kwargs = make_send_kwargs_mergeable_from_env(arguments)
    assert kwargs['proxies'] == {}
    assert kwargs['verify'] == True
    assert kwargs['cert'] == None
    assert arguments.cert == None

# Generated at 2022-06-23 18:54:15.440860
# Unit test for function collect_messages
def test_collect_messages():
    pass



# Generated at 2022-06-23 18:54:24.244502
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import json

# Generated at 2022-06-23 18:54:34.628884
# Unit test for function collect_messages
def test_collect_messages():
    class args:
        def __init__(self):
            self.url='www.example.com'
            self.method='GET'
            self.headers=RequestHeadersDict()
            self.auth=None
            self.session=None
            self.session_read_only=None
            self.data=None
            self.json=None
            self.form=None
            self.files=None
            self.params=None
            self.auth_plugin=None
            self.compress=None
            self.timeout=None
            self.max_redirects=None
            self.follow=None
            self.verify=None
            self.cert=None
            self.cert_key=None
            self.ssl_version=None
            self.proxy=None
            self.ciphers=None
            self

# Generated at 2022-06-23 18:54:41.713425
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = "http://localhost:5000/"
    args.method = "GET"
    args.headers = RequestHeadersDict()
    config_dir = Path()

    for i in collect_messages(args, config_dir):
        print(i)


if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-23 18:54:48.289682
# Unit test for function collect_messages

# Generated at 2022-06-23 18:55:00.527161
# Unit test for function dump_request
def test_dump_request():
    global args
    args = argparse.Namespace()
    global config_dir
    config_dir = Path()
    global request_body_read_callback
    request_body_read_callback = None
    global httpie_session
    httpie_session = None
    global httpie_session_headers
    httpie_session_headers = None
    global request_kwargs
    request_kwargs = make_request_kwargs(args, base_headers=httpie_session_headers, request_body_read_callback=request_body_read_callback)
    global send_kwargs
    send_kwargs = make_send_kwargs(args)
    global send_kwargs_mergeable_from_env
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env

# Generated at 2022-06-23 18:55:07.150141
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 10
    args.allow_redirects = False

    send_kwargs = make_send_kwargs(args)
    assert len(send_kwargs.items()) == 2

    assert send_kwargs['timeout'] == args.timeout
    assert send_kwargs['allow_redirects'] == args.allow_redirects



# Generated at 2022-06-23 18:55:11.393266
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = 1
    args.verify = False

    expected_results = {
        'timeout': 1,
        'allow_redirects': False,
    }
    assert make_send_kwargs(args) == expected_results

# Generated at 2022-06-23 18:55:22.595534
# Unit test for function collect_messages
def test_collect_messages():
    class MockArgs:
        class MockArgsHeadersDict(dict):
            def __setitem__(self,key,value):
                if key == 'Host':
                    raise Exception
                else:
                    super(MockArgs.MockArgsHeadersDict, self).__setitem__(key, value)

        def __init__(self):
            self.auth = None
            self.auth_plugin = None
            self.all = False
            self.body = False
            self.boundary = '--------------------------98917294pfi492'
            self.cert = None
            self.cert_key = None
            self.ciphers = None
            self.chunked = False
            self.compress = False
            self.data = {"foo": "bar"}
            self.debug = False
            self.files = None


# Generated at 2022-06-23 18:55:26.764509
# Unit test for function max_headers
def test_max_headers():
    with max_headers(limit=10):
        assert http.client._MAXHEADERS == 10
        with max_headers(limit=20):
            assert http.client._MAXHEADERS == 20

    assert http.client._MAXHEADERS == 10



# Generated at 2022-06-23 18:55:30.034915
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli import parser
    args = parser.parse_args(['--verify=false', 'https://example.com'])
    assert make_send_kwargs_mergeable_from_env(args)['verify'] == False

# Generated at 2022-06-23 18:55:33.590892
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 10
    with max_headers(100):
        if http.client._MAXHEADERS == 100:
            print('True')
    print(http.client._MAXHEADERS)

# Generated at 2022-06-23 18:55:43.290808
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()

    # case1: --form --json
    args.form = True
    args.json = True
    hd = make_default_headers(args)
    assert hd == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE,
    })

    # case2: --json
    args.form = False
    args.data = ['{"foo":"bar", "baz":"qux"}']
    hd = make_default_headers(args)
    assert hd == RequestHeadersDict({
        'User-Agent': DEFAULT_UA,
        'Accept': JSON_ACCEPT,
        'Content-Type': JSON_CONTENT_TYPE,
    })

    #

# Generated at 2022-06-23 18:55:53.054937
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    from httpie.cli.parser import parser
    from httpie.cli.exceptions import ParseError
    import io

    def simulate_stdin(stdin_str):
        sys.stdin = io.StringIO(stdin_str)

    def simulate_args(arg_list, init=True):
        if init:
            args = parser.parse_args(arg_list)
        else:
            args = arg_list
        return args

    # Test 1: check if args.timeout is set.
    simulate_stdin("")
    args = simulate_args(["--timeout=1"])
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['timeout'] == 1

    # Test 2: check if args.timeout is not set.
    simulate_stdin("")

# Generated at 2022-06-23 18:55:55.412545
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:56:00.501633
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    values = ["yes", "true", "no", "false", "random"]
    for value in values:
        result = make_send_kwargs_mergeable_from_env(argparse.Namespace(verify=value))
        assert result['verify'] is not None

# Generated at 2022-06-23 18:56:12.209381
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    fake_headers = {
        'name1': 'value1',
        'name2': 'value2',
    }
    fake_data = {
        'key1':'value1',
        'key2': 'value2'
    }
    fake_args = argparse.Namespace(
        method = 'get',
        url = 'http://www.baidu.com',
        headers = fake_headers,
        data = fake_data,
        params ={
            'name':'value'
        },
        auth = {
            'username':'name',
            'password':'password'
        },
        json = True,
        form = False,
        compress = 0
    )
    # make a fake request_body_read_callback, just return the data

# Generated at 2022-06-23 18:56:14.919967
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    kwargs = make_send_kwargs(argparse.Namespace(timeout=10.0, follow=False))
    assert kwargs == { 'timeout': 10.0, 'allow_redirects': False }

# Generated at 2022-06-23 18:56:17.675362
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
        print('test max_headers')


if __name__ == "__main__":
    test_max_headers()

# Generated at 2022-06-23 18:56:21.019077
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        'headers': None,
        'body': '{}'
    }
    dump_request(kwargs);
    assert True

# Generated at 2022-06-23 18:56:28.760138
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    from httpie.cli.parser import parser

    args = parser.parse_args(
        ['--verbose',
         '--json', '{}',
         'https://httpbin.org/post'])

    res = make_request_kwargs(args)
    assert res == {'method': 'post',
                   'url': 'https://httpbin.org/post',
                   'headers': {
                       'Accept': 'application/json, */*;q=0.5',
                       'Content-Type': 'application/json',
                       'User-Agent': 'HTTPie/2.2.0'
                   },
                   'data': b'{}',
                   'auth': None,
                   'params': []}

# Generated at 2022-06-23 18:56:35.540614
# Unit test for function collect_messages
def test_collect_messages():
    import sys
    import unittest
    from .context import Arguments

    class TestHttpie(unittest.TestCase):
        def test_collect_messages(self):
            args = Arguments(url='http://localhost:5000')
            collect_messages(
                args=args,
                config_dir=None)
    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-23 18:56:44.485121
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = 'no'
    args.proxy = [argparse.Namespace() for i in range(2)]
    args.proxy[0].key = 'https'
    args.proxy[0].value = 'http://foo'
    args.proxy[1].key = 'http'
    args.proxy[1].value = 'http://bar'
    args.cert = 'cert.pem'
    args.cert_key = 'public.key'
    kwargs = make_send_kwargs_mergeable_from_env(args)

# Generated at 2022-06-23 18:56:52.803383
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(files=None, data=None, json=None, form=None)
    make_request_kwargs(args)

    args.files = ['a', 'b']
    make_request_kwargs(args)

    args.files = None
    args.data = '{"a": "b", "c": "d"}'
    make_request_kwargs(args)

    args.data = None
    args.form = True
    make_request_kwargs(args)

    args.form = None
    args.json = True
    make_request_kwargs(args)

    args.json = None
    args.multipart = True
    make_request_kwargs(args)

# Generated at 2022-06-23 18:57:04.049537
# Unit test for function dump_request
def test_dump_request():
    # Argument
    args = argparse.Namespace() 
    kwargs = {
        'method': 'GET',
        'url': 'http://localhost',
        'headers': {'Content-Type': 'application/json', 'User-Agent': 'HTTPie/1.0.1'},
        'data': 'test',
    }
    
    # Call function
    dump_request(kwargs)
    
    # Assertion
    assert dump_request(kwargs) == \
        '\n>>> requests.request(**{\'method\': \'GET\', \'url\': \'http://localhost\', \'headers\': {\'Content-Type\': \'application/json\', \'User-Agent\': \'HTTPie/1.0.1\'}, \'data\': \'test\'})\n\n'

# Unit

# Generated at 2022-06-23 18:57:15.825638
# Unit test for function dump_request
def test_dump_request():
    from httpie.cli import parser
    args = parser.parse_args(["--timeout=5", "--form", "http://127.0.0.1:8080", "-d", '{"id": [123,345]}'])
    kwargs = {
        'headers': {
            'User-Agent': 'HTTPie/1.0.3', 
            'Accept': 'application/json, */*;q=0.5', 
            'Content-Type': 'application/json'
        }, 
        'data': b'{"id": [123,345]}', 
        'auth': None, 
        'params': [], 
        'method': 'post', 
        'url': 'http://127.0.0.1:8080', 
        'timeout': 5
    }
    assert kw

# Generated at 2022-06-23 18:57:20.873742
# Unit test for function dump_request
def test_dump_request():
    kwargs = make_request_kwargs(args=None, base_headers=None, request_body_read_callback=None)
    dump_request(kwargs)
    test_dump_request()

# Generated at 2022-06-23 18:57:30.386209
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(data=None, form=False, json=False)
    headers = make_default_headers(args)
    assert 'User-Agent' in headers
    assert 'Accept' in headers
    assert 'Content-Type' not in headers
    args = argparse.Namespace(data={}, form=False, json=True)
    headers = make_default_headers(args)
    assert 'User-Agent' in headers
    assert 'Accept' in headers
    assert 'Content-Type' in headers
    assert headers['Content-Type'] == 'application/json'
    args = argparse.Namespace(data={}, form=True, json=False)
    headers = make_default_headers(args)
    assert 'User-Agent' in headers
    assert 'Accept' not in headers

# Generated at 2022-06-23 18:57:40.394987
# Unit test for function dump_request
def test_dump_request():
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-23 18:57:47.756024
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:57:49.281219
# Unit test for function max_headers
def test_max_headers():
    import http.client
    with max_headers(1):
        assert http.client._MAXHEADERS == 1