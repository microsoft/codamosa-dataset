

# Generated at 2022-06-23 18:48:01.112441
# Unit test for function make_default_headers

# Generated at 2022-06-23 18:48:09.924858
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = ['--url', 'www.google.com', '--verify', 'True', '--verify-host', 'False']
    args = parser.parse_args(args)
    send_kwargs = make_send_kwargs(args=args)
    if args.timeout or None == send_kwargs['timeout'] and not args.offline == send_kwargs['allow_redirects']:
        print("make_send_kwargs test: pass")
    else:
        print("make_send_kwargs test: fail")



# Generated at 2022-06-23 18:48:18.531947
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import argparse

# Generated at 2022-06-23 18:48:20.397230
# Unit test for function finalize_headers
def test_finalize_headers():
    # TODO: Write unit test for function finalize_headers
    assert True

# Generated at 2022-06-23 18:48:30.042674
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(form='', files='', json=False, data='{}', verify=True, headers={},
                              method='get', url='url', params={}, auth=None, proxy=[], cert=None, cert_key=None,
                              ssl_version='default', ciphers=None,
                              chunked=True, offline=False, multipart=False, boundary=None,
                              multipart_data='',
                              all=False, follow=False, max_redirects=30,
                              prompt_password=False, session=None, session_read_only=None,
                              verbose=False, debug=False, download=False, force_colors=False, timeout=None,
                              max_headers=None, path_as_is=False, compress=False)
    final

# Generated at 2022-06-23 18:48:37.790848
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(verify = True, ssl_version = None, ciphers = None).cookies == None
    assert build_requests_session(verify = False, ssl_version = "0.0.0", ciphers = " ").cookies == None
    assert build_requests_session(verify = True, ssl_version = "0.0.0", ciphers = " ").cookies == None
    assert build_requests_session(verify = False, ssl_version = "1.0.2", ciphers = " ").cookies == None


# Generated at 2022-06-23 18:48:47.014312
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.data = None
    args.form = False
    args.files = None
    args.verify = 'True'
    args.proxy = [argparse.Namespace(key='http', value='http://127.0.0.1:9090')]
    args.timeout = 5
    args.headers = {'foo': 'bar'}
    headers = make_default_headers(args)
    assert headers['User-Agent'] == DEFAULT_UA
    assert headers['foo'] == 'bar'


# Generated at 2022-06-23 18:48:56.824307
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    from httpie.cli.parser import get_parser
    from pytest import raises

    parser = get_parser()
    args = parser.parse_args(['http', 'httpbin.org'])

    send_kwargs = make_send_kwargs_mergeable_from_env(args)

    assert send_kwargs['proxies'] == {}
    assert send_kwargs['stream'] is True
    assert send_kwargs['verify'] is True
    assert send_kwargs['cert'] is None

    args = parser.parse_args(['http', '--verify=no', 'httpbin.org'])
    send_kwargs = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs['verify'] is False


# Generated at 2022-06-23 18:48:59.893471
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path.cwd()
    request_body_read_callback = None
    collect_messages(args, config_dir)

# Generated at 2022-06-23 18:49:02.979504
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    assert make_send_kwargs({
        'timeout': 5,
        'allow_redirects': False,
    }) == {'timeout': 5, 'allow_redirects': False}


# Generated at 2022-06-23 18:49:11.859770
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    base_headers = RequestHeadersDict()
    request_kwargs = make_request_kwargs(args, base_headers)
    assert request_kwargs == {
        'method': args.method.lower(),
        'url': args.url,
        'headers': {
            'User-Agent': DEFAULT_UA
        },
        'data': prepare_request_body(
            body=None,
            body_read_callback=lambda chunk: chunk,
            chunked=False,
            offline=False,
            content_length_header_value=None,
        ),
        'auth': args.auth,
        'params': args.params.items()
    }

# Generated at 2022-06-23 18:49:15.506662
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(verify=True, ssl_version=None, ciphers=None)
    assert(isinstance(requests_session, requests.Session))

# Generated at 2022-06-23 18:49:21.529958
# Unit test for function dump_request
def test_dump_request():
    rkwargs = {'method': 'GET',
               'url': 'https://httpbin.org/get',
               'headers': {'content-type': 'application/json;charset=UTF-8'},
               'data': {},
               'auth': None,
               'params': {}}
    dump_request(rkwargs)



# Generated at 2022-06-23 18:49:25.140177
# Unit test for function make_default_headers
def test_make_default_headers():
    headers_dict = make_default_headers(object)
    assert 'User-Agent' in headers_dict
    assert 'Accept' not in headers_dict
    assert 'Content-Type' not in headers_dict

# Generated at 2022-06-23 18:49:35.599906
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.url = "https://localhost:8000/test"
    args.method = 'GET'
    args.headers = {'Accept-Encoding': 'gzip,deflate,br'}
    args.auth = ('user', 'pass')
    args.json = False
    args.form = False
    args.files = None
    args.data = {'key': 'value'}
    args.multipart = False
    args.auth_plugin = None
    args.verify = True
    args.chunked = True
    args.timeout = 1
    request_kwargs = make_request_kwargs(args)
    assert request_kwargs['method'] == 'GET'
    assert request_kwargs['url'] == "https://localhost:8000/test"
    assert request

# Generated at 2022-06-23 18:49:37.077873
# Unit test for function collect_messages
def test_collect_messages():
    assert(True)



# Generated at 2022-06-23 18:49:47.720810
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args_obj = argparse.Namespace(
        cert_key=None,
        cert='./examples/ca-cert-chain.pem',
        timeout='10.0',
        verify='./examples/ca-cert-chain.pem',
        proxy=[],
    )
    kwargs = make_send_kwargs_mergeable_from_env(args_obj)
    assert('proxies' in kwargs)
    assert('stream' in kwargs)
    assert('verify' in kwargs)
    assert('cert' in kwargs)
    assert(len(kwargs) == 4)
    print(kwargs)


# Generated at 2022-06-23 18:49:57.213655
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'User-Agent': 'HTTPie/0.9.6',
        'Accept': 'application/json',
        'Accept': 'text/plain',
        'X-Custom-Header': 'foo bar baz'
    })

    expected_headers = RequestHeadersDict({
        'User-Agent': b'HTTPie/0.9.6',
        'Accept': b'text/plain',
        'X-Custom-Header': b'foo bar baz'
    })

    assert(finalize_headers(headers) == expected_headers)


# Generated at 2022-06-23 18:50:08.018952
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.auth = None
    args.boundary = None
    args.cert = None
    args.cert_key = None
    args.chunked = False
    args.form = False
    args.headers = {}
    args.json = False
    args.method = 'GET'
    args.params = {}
    args.proxy = []
    args.timeout = None
    args.url = 'http://localhost:8080/'
    args.verify = False
    args.files = None
    args.data = None
    kwargs = make_request_kwargs(args)
    if kwargs['method'] != 'get':
        raise ValueError('Incorrect value for method')
    if kwargs['url'] != 'http://localhost:8080/':
        raise

# Generated at 2022-06-23 18:50:12.538347
# Unit test for function dump_request
def test_dump_request():
    from httpie import cli

    parser = cli.parser
    args = parser.parse_args(args=[
        '--json', '--headers', 'Content-Type: application/json',
        'https://httpie.org/', 'key=value',
        'key2=value2', 'foo=bar'
    ])
    dump_request(make_request_kwargs(args, request_body_read_callback=None))


# Generated at 2022-06-23 18:50:19.261973
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    file = open('test.txt', 'w')
    file.write('Test')
    file.close()

# Generated at 2022-06-23 18:50:29.080928
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict()
    headers['User-Agent'] = 'httpie '
    headers['content-type'] = 'application/json'
    headers['Content-length'] = None
    headers['accept'] = 'application/json'
    headers['Accept'] = 'application/xml '
    headers['Connection'] = 'keep-alive'
    headers['Foo'] = 'bar'
    final_headers = finalize_headers(headers)
    assert final_headers['User-agent'] == 'httpie'
    assert final_headers['content-type'] is headers['content-type']
    assert final_headers['Content-length'] is None
    assert final_headers['accept'] == 'application/json, application/xml'
    assert final_headers['Connection'] == 'keep-alive'
    assert final_headers['Foo']

# Generated at 2022-06-23 18:50:38.223904
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.verify = "false"
    args.proxy = [argparse.Namespace(key='https', value='https://localhost')]
    send_kwargs_mergeable_from_env = make_send_kwargs_mergeable_from_env(args)
    assert send_kwargs_mergeable_from_env == {'proxies': {'https': 'https://localhost'}, 'stream': True, 'verify': False, 'cert': None}

# Generated at 2022-06-23 18:50:45.594289
# Unit test for function collect_messages
def test_collect_messages():
    try:
        from io import BytesIO
    except ImportError:
        from io import StringIO as BytesIO
    from httpie.cli import get_parser
    parser = get_parser()
    # HTTP verb; GET
    args = parser.parse_args(['--verbose', 'GET', 'http://localhost:8000/test'])
    config_dir = Path('./config_dir')
    iterable = collect_messages(args, config_dir)
    print(iterable)
    x = iterable.__next__()
    print(x.headers)
    x = iterable.__next__()
    print(x.headers)
    # HTTP verb; POST
    args = parser.parse_args(['--verbose', 'POST', 'http://localhost:8000/test'])
    iterable = collect_

# Generated at 2022-06-23 18:50:53.002464
# Unit test for function build_requests_session
def test_build_requests_session():
    # default ssl_version should be None
    requests_session = build_requests_session(
        verify=True,
        ssl_version=None,
        ciphers=None
    )
    assert requests_session.trust_env is True

    # If ssl_version is specified, 
    requests_session = build_requests_session(
        verify=True,
        ssl_version='SSLv3',
        ciphers=None
    )
    assert requests_session.trust_env is False

# Generated at 2022-06-23 18:51:05.391757
# Unit test for function build_requests_session
def test_build_requests_session():
    config_dir = Path('.')
    httpie_session = get_httpie_session(
        config_dir=config_dir,
        session_name='test',
        host='localhost',
        url='http://localhost/',
    )
    httpie_session.auth = {
        'type': 'bearer',
        'raw_auth': 'foo',
    }

# Generated at 2022-06-23 18:51:17.575633
# Unit test for function collect_messages
def test_collect_messages():
    # Set up the argparse namespace by specifying the arguments that the function will call.
    args = Namespace
    args.session = 'data'
    args.session_read_only = False
    args.url = 'https://api.github.com/user'
    args.auth = ('user', 'pass')
    args.auth_plugin = None
    args.cert = None
    args.cert_key = None
    args.data = None
    args.form = False
    args.json = False
    args.method = 'GET'
    args.multipart = False
    args.multipart_data = []
    args.headers = [('Accept', 'application/json')]
    args.params = []
    args.files = None
    args.timeout = None
    args.compress = 0

# Generated at 2022-06-23 18:51:29.958796
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    """
    Test the function make_request_kwargs

    """
    args = argparse.Namespace()
    args.json = None
    args.form = None
    args.data = None


    # Post request with json data
    args.data = {'name': 'Mike'}
    args.json = True
    body = b'{"name": "Mike"}'
    kwargs = make_request_kwargs(args)
    assert kwargs['data'] == body

    # Post request with json and headers
    args.headers = RequestHeadersDict({'Custom-Header': 'foo'})
    kwargs = make_request_kwargs(args)

# Generated at 2022-06-23 18:51:39.392778
# Unit test for function dump_request
def test_dump_request():
    kwargs = {
        "stream": True,
        "data": "{\n  \"foo\": \"bar\"\n}",
        "method": "post",
        "headers": {
            "user-agent": "HTTPie/1.0.2",
            "accept": "*/*",
            "content-length": "15",
            "content-type": "application/json"
        },
        "url": "https://httpie.org/post"
    }

# Generated at 2022-06-23 18:51:41.361067
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(orig_url='/path/to/dir/../', prepped_url='/path/to/?foo=bar') == '/path/to/dir/../?foo=bar'

# Generated at 2022-06-23 18:51:46.828412
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(
        'http://foo/../',
        'http://foo/?foo=bar'
    ) == 'http://foo/../?foo=bar', 'est assert 1'
    assert ensure_path_as_is(
        'http://foo/../?foo=bar',
        'http://foo/?foo=baz'
    ) == 'http://foo/../?foo=baz', 'est assert 2'
    assert ensure_path_as_is(
        'http://foo?foo=bar#x=1',
        'http://foo/?foo=baz'
    ) == 'http://foo/?foo=baz#x=1', 'est assert 3'

# Generated at 2022-06-23 18:51:49.953559
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 0
    http.client._MAXHEADERS
    with max_headers(10):
        http.client._MAXHEADERS
    http.client._MAXHEADERS

# Generated at 2022-06-23 18:52:01.476637
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = []
    args.verify = 'True'
    args.cert = None
    args.headers=[]

    assert make_send_kwargs_mergeable_from_env(args) == \
        {'proxies': {}, 'stream': True, 'verify': True, 'cert': None}

    args.proxy = ['http=127.0.0.1:80', 'https=127.0.0.2:443']
    args.verify = '/path/to/cafile'
    args.cert = '/path/to/crt'
    args.headers={'header-key': 'header-value'}


# Generated at 2022-06-23 18:52:06.775899
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(
            verify='asdfasdf',
            timeout=10,
            cert_key=None,
            cert=None,
            chucked=False,
            max_headers=None,
            max_redirects=None,
            proxies=[],
            proxy=False,
        )
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == 10
    assert kwargs['allow_redirects'] == False

# Generated at 2022-06-23 18:52:13.852438
# Unit test for function finalize_headers
def test_finalize_headers():
    import collections
    import json

    data = "hello world"
    test_dict = {
        "accept": None,
        "User-Agent": "HTTPie/1.0.2",
        "content-length": len(data),
        "Content-type": "application/json"
    }
    
    final_dict = finalize_headers(test_dict)
    assert final_dict == collections.OrderedDict([('User-Agent', "HTTPie/1.0.2"), ('Content-type', 'application/json'), ('content-length', 11)])



# Generated at 2022-06-23 18:52:21.167196
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    expected = {
        'method': 'GET',
        'url': 'http://example.com',
        'headers': {'User-Agent': DEFAULT_UA, 'Host': 'example.com'}, 'data': '',
        'auth': ('auth Username:password', 'password')
    }
    args = make_request_kwargs({'method': 'get', 'url': 'http://example.com', 'headers': {'Host': 'example.com'},
                                'auth': ('auth', 'Username:password')})
    assert args == expected

# Generated at 2022-06-23 18:52:31.652377
# Unit test for function finalize_headers
def test_finalize_headers():
    print('Testing for function finalize_headers...', end='')
    headers = RequestHeadersDict({
        'user-agent': '   HTTPie/',
        'Accept': 'application/json, */*;q=0.5   ',
        'Host': ' host.local',
        'Content-Length': None
    })
    final_headers = finalize_headers(headers)
    assert final_headers['user-agent'] == 'HTTPie/'
    assert final_headers['Accept'] == 'application/json, */*;q=0.5'
    assert final_headers['Host'] == 'host.local'
    assert 'Content-Length' not in final_headers
    print('Done.')


# Generated at 2022-06-23 18:52:32.091058
# Unit test for function max_headers
def test_max_headers():
    pass

# Generated at 2022-06-23 18:52:36.704777
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    args.timeout = '5'
    args.allow_redirects = False
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {
        'timeout': 5,
        'allow_redirects': False,
    }

# Generated at 2022-06-23 18:52:46.857114
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    # Test the path is the only different part
    assert ensure_path_as_is('http://foo/bar', 'http://foo/..') == 'http://foo/..'
    assert ensure_path_as_is('http://foo/bar', 'http://foo/bar') == 'http://foo/bar'
    assert ensure_path_as_is('http://foo/bar', 'http://foo/../bar') == 'http://foo/../bar'

    # Test the query is not changed
    assert ensure_path_as_is('http://foo/?baz=bar', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'

    # Test the port is not changed

# Generated at 2022-06-23 18:52:49.963900
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:52:55.969318
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import sys
    import argparse
    from httpie.cli.parser import parser
    data = {'a': '1'}
    args = parser.parse_args(['http://www.google.com', '-v', '-j', json.dumps(data)])
    kwargs = make_request_kwargs(args, None)
    print(kwargs)
    sys.stdout.flush()
    print(kwargs['data'])
    sys.stdout.flush()
    assert kwargs['data'] == json.dumps(data)

# Generated at 2022-06-23 18:53:00.604800
# Unit test for function max_headers
def test_max_headers():
    args = argparse.Namespace()
    config_dir = Path('/home/csaybar/.httpie')
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)


# Generated at 2022-06-23 18:53:11.587782
# Unit test for function max_headers
def test_max_headers():
    def test1():
        # https://curl.haxx.se/libcurl/c/CURLOPT_MAX_RECV_HEADER_SIZE.html
        limit = 100
        with max_headers(limit):
            # noinspection PyProtectedMember
            assert http.client._MAXHEADERS == limit
            assert http.client.MAXHEADERS == limit
    test1()

    def test2():
        limit = sys.maxsize
        with max_headers(limit):
            # noinspection PyProtectedMember
            assert http.client._MAXHEADERS == limit
            assert http.client.MAXHEADERS == limit
    test2()

    def test3():
        limit = None

# Generated at 2022-06-23 18:53:19.982074
# Unit test for function finalize_headers
def test_finalize_headers():
    assert finalize_headers({'Foo': 'bar'}) == {'foo': b'bar'}
    assert finalize_headers({'foo': 'bar', 'Foo': 'baz'}) == {'foo': b'baz'}
    assert finalize_headers({'foo': ' bar '}) == {'foo': b'bar'}
    assert finalize_headers({'foo': u'bar'}) == {'foo': b'bar'}
    assert finalize_headers({'foo': b'bar'}) == {'foo': b'bar'}
    assert finalize_headers({'foo': None}) == {}



# Generated at 2022-06-23 18:53:24.011120
# Unit test for function finalize_headers
def test_finalize_headers():
    # This is the test for function finalize_headers.
    # function finalize_headers is to remove the leading and trailing LWS.

    input_headers = {
        'a': None,
        'b': '   ',
        'c': '  c ',
    }
    output_headers = finalize_headers(input_headers)
    assert output_headers == {
        'a': None,
        'b': '',
        'c': 'c',
    }

# Generated at 2022-06-23 18:53:29.210620
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {"Header_First_Line":"Line 1","Header_Second_Line":"Line2"}
    assert finalize_headers(headers) == {'Header-First-Line': 'Line 1', 'Header-Second-Line': 'Line2'}


if __name__ == '__main__':
    test_finalize_headers()

# Generated at 2022-06-23 18:53:39.859206
# Unit test for function max_headers
def test_max_headers():
    import requests
    import time
    import http.client
    orig = http.client._MAXHEADERS
    http.client._MAXHEADERS = float('inf')

# Generated at 2022-06-23 18:53:51.706227
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class args:
        url = 'http://httpbin.org/post'
        auth='AUTH'
        headers = {
            'h1':'v1',
            'h2':'v2',
        }
        params = {
            'p1':'v1',
            'p2':'v2',
        }
        data = {
            'd1':1,
            'd2':'22',
        }
        files = {'f1':1,'f2':2}
        method = 'POST'
        json = True
        form = False
        multipart = False
        offline = False
        chunked = False
        verify = True
        cert = None
        cert_key = None
        proxy = None
        timeout = None
        max_redirects = None
        follow = True
   

# Generated at 2022-06-23 18:53:58.981551
# Unit test for function dump_request
def test_dump_request():
    """
    The function dump_request should print out an inputted dictionary
    :return: None
    """
    sys.stderr = open('./test.txt', 'a')
    kwargs = {
        'headers':{'Content-Type': 'application/json', 'upload':'download'},
        'data': 'json'
    }
    dump_request(kwargs)
    sys.stderr.close()
    f = open('./test.txt', 'r')
    assert '>>> requests.request(**{' in f.read()

# Generated at 2022-06-23 18:54:08.454072
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()

    # When verify is "yes" or "true"
    args.verify = 'yes'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] == True

    args.verify = 'true'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] == True

    # When verify is "no" or "false"
    args.verify = 'no'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] == False

    args.verify = 'false'
    assert make_send_kwargs_mergeable_from_env(args)['verify'] == False

    args.verify = 'invalid_value'

# Generated at 2022-06-23 18:54:18.664458
# Unit test for function make_request_kwargs
def test_make_request_kwargs():

    # parse the main arguments given by the command line
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--verbose", help="increase output verbosity", \
                        action="count", default=0)
    parser.add_argument("--offline", help="Do not make HTTP requests",\
                        action="store_true")
    parser.add_argument("--verbose", "-v", help="Verbose mode (-vvv for more, -vvvv to enable request/response tracing)",\
                        action="count", default=0)
    parser.add_argument("--headers", "-h", action=HTTPieHeaders, default={},\
                        dest="headers", metavar="HEADER",\
                        help="header values")

# Generated at 2022-06-23 18:54:26.025707
# Unit test for function dump_request
def test_dump_request():
    # If a regular dict is passed as expected it dumps the dict
    try:
        assert dump_request({'foo': 'bar'}) == '\n>>> requests.request(**{\'foo\': \'bar\'})\n\n'
    except AssertionError:
        pass

    # If a dict with a unicode value is passed the value is encoded to utf8
    try:
        assert dump_request({'foo': 'bär'}) == '\n>>> requests.request(**{\'foo\': \'b\\xc3\\xa4r\'})\n\n'
    except AssertionError:
        pass

# Generated at 2022-06-23 18:54:32.034529
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.data = None
    args.form = None
    args.json = None
    args.files = None
    
    default_headers = make_default_headers(args)

    assert default_headers['User-Agent'] == 'HTTPie/2.0.0'
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE
    

# Generated at 2022-06-23 18:54:39.795398
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:54:49.732437
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        chunked=False,
        data={},
        form=False,
        files=None,
        json=False,
        method="GET",
        url="http://foo.bar",
        headers={},
        verify="yes",
        cert=None,
        cert_key=None,
        proxy=[],
        timeout=None,
        auth=None,
        params=[]
    )
    result = make_request_kwargs(args)

# Generated at 2022-06-23 18:55:02.245134
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:55:11.687261
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    """
    Test for request_kwargs
    """
    # get test data
    file_name = "test_make_request_kwargs_data.json"
    path = "tests/utils/data/"
    file_path = path + file_name

    # get args
    args = get_data(file_path)

    # call function make_request_kwargs
    kwargs = make_request_kwargs(args)

    # get expected data
    expected_data = get_expected_data(file_path)

    # Compare expected data and actual data
    assert(kwargs == expected_data)


# Generated at 2022-06-23 18:55:18.309376
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace()
    args.method = 'get'
    args.url = 'https://httpbin.org/get'
    args.json = True
    args.data = {'key': 'value'}
    args.headers = {'X-Foo': 'bar'}
    args.timeout = 20
    args.verify = True
    args.chunked = True
    args.offline = False

    request_kwargs = make_request_kwargs(
        args=args,
        base_headers=None,
        request_body_read_callback=lambda chunk: chunk
    )
    assert request_kwargs['method'] == 'get'
    assert request_kwargs['url'] == 'https://httpbin.org/get'

# Generated at 2022-06-23 18:55:24.890682
# Unit test for function dump_request

# Generated at 2022-06-23 18:55:27.460823
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace(timeout=100, allow_redirects=True)
    expect = {'timeout':100,'allow_redirects':True}
    assert make_send_kwargs(args) == expect


# Generated at 2022-06-23 18:55:40.288367
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    args.url = 'url_ex'
    args.method = 'method_ex'
    args.headers = {'Accept': 'application/json'}
    args.ssl_version = None
    args.ciphers = 'ciphers_ex'
    args.timeout = None
    args.allow_redirects = False
    args.verify = 'verify_ex'
    args.cert = None
    args.cert_key = None
    args.auth = None
    args.json = None
    args.form = None
    args.data = None
    args.files = None
    args.params = dict()
    args.compress = None
    args.debug = True
    args.session = None
    args.session_read_only = None
    args.path

# Generated at 2022-06-23 18:55:41.853778
# Unit test for function max_headers
def test_max_headers():
    with max_headers(200):
        assert http.client._MAXHEADERS == 200

# Generated at 2022-06-23 18:55:46.626052
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = False
    args.form = False
    args.data = None
    test_headers = make_default_headers(args)
    assert test_headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-23 18:55:52.638954
# Unit test for function build_requests_session
def test_build_requests_session():
    """
    This function test build_requests_session with given parameters
    """


# Generated at 2022-06-23 18:56:01.099575
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.proxy = requests.compat.OrderedDict({'http': 'http://127.0.0.1:3128'})
    args.verify = True
    args.cert = './cert.pem'
    args.cert_key = './key.pem'
    rtn_dict = {
        'proxies': {'http': 'http://127.0.0.1:3128'},
        'stream': True,
        'verify': True,
        'cert': ('./cert.pem', './key.pem'),
    }
    assert make_send_kwargs_mergeable_from_env(args) == rtn_dict



# Generated at 2022-06-23 18:56:04.984936
# Unit test for function dump_request
def test_dump_request():
    method = "GET"
    url = "https://httpbin.org/html"
    headers = {'my-header': 'my-value'}
    data = None
    response = requests.get(url, headers=headers)
    assert response.ok

# Generated at 2022-06-23 18:56:09.329059
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    orig_url = "http://foo/../dir1/dir2/"
    prepped_url = "http://foo/?foo=bar"
    assert ensure_path_as_is(orig_url, prepped_url) == "http://foo/../dir1/dir2/?foo=bar"

# Generated at 2022-06-23 18:56:18.836045
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    headers = make_default_headers(args)
    # print(headers)
    assert('Accept' not in headers)
    assert('User-Agent' in headers)

    args.json = True
    args.data = True
    headers = make_default_headers(args)
    assert('Accept' in headers)
    assert('Content-Type' in headers)

    args.headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }
    args.json = False
    args.data = False
    headers = make_default_headers(args)
    assert('Accept' in headers)
    assert('Content-Type' in headers)
    # print(headers)


# Generated at 2022-06-23 18:56:28.577573
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(method='GET', url='https://localhost', headers=RequestHeadersDict({"Header1":"value1", "Header2":"value2"}), params=None, auth='', json=False, form=True, data=True, files=None, chunked=False, offline=False, verify='', cert=None, cert_key=None, proxy=[], debug=False, session=None, session_read_only=None, auth_plugin=None, multipart_data=None, boundary='httpie-boundary', max_headers=None, path_as_is=False, all=False, follow=False, max_redirects=None, timeout=None)
    base_headers = RequestHeadersDict({"Header1":"value1", "Header2":"value2"})

# Generated at 2022-06-23 18:56:40.834428
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    import pytest

    # test whether make_send_kwargs_mergeable_from_env returns correct proxies when proxy parameters is passwd in
    args = argparse.Namespace(proxy=['http://1.1.1.1:8080'])
    result = make_send_kwargs_mergeable_from_env(args)

    assert 'proxies' in result, 'proxies are not present in result'
    assert result['proxies'] == {'http': 'http://1.1.1.1:8080'}, 'proxy result is not correct'

    # test whether make_send_kwargs_mergeable_from_env returns correct stream value
    args = argparse.Namespace(proxy=['http://1.1.1.1:8080'])
    result = make_send_kwargs_

# Generated at 2022-06-23 18:56:43.476828
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    return ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar')

# Generated at 2022-06-23 18:56:50.766323
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(verify=True, ssl_version='1.2', ciphers=None)
    assert requests_session.verify == True, "Failed to set the verify flag"

    for prefix, adapter in list(requests_session.adapters.items()):
        if prefix == 'https://':
            assert isinstance(adapter, HTTPieHTTPSAdapter), "The adapter is not an HTTPieHTTPSAdapter"


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:57:02.772930
# Unit test for function ensure_path_as_is

# Generated at 2022-06-23 18:57:15.240185
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    args_parse = argparse.ArgumentParser()
    #args_parse.add_argument('--url', type=str)
    args = args_parse.parse_args()
    args.url = 'http://httpbin.org/post'

    args.auth = None
    args.auth_plugin = None
    args.method = 'post'
    args.data = None
    args.json = None
    args.form = None
    args.files = []
    args.params = []
    args.headers = []
    args.compress = False
    args.debug = None
    args.session = None
    args.session_read_only = None
    args.offline = False
    args.download_output = None
    args.download_verify_ssl = None
    args.max_red

# Generated at 2022-06-23 18:57:19.386281
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    import argparse
    args = argparse.Namespace()

    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['allow_redirects'] == False
    args.timeout = '100'
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs['timeout'] == 100



# Generated at 2022-06-23 18:57:24.038002
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args = argparse.Namespace()
    args.cert = ''
    args.cert_key = ''
    args.proxy = [
        argparse.Namespace(
            key = 'http',
            value = '127.0.0.1'
        )
    ]
    args.verify = 'true'
    w = make_send_kwargs_mergeable_from_env(args)
    assert w['proxies'] == {'http': '127.0.0.1'}
    assert w['verify'] == True

# Generated at 2022-06-23 18:57:29.924764
# Unit test for function collect_messages
def test_collect_messages():
    import argparse
    class ArgsMock:
        def __init__(self):
            pass
    args = ArgsMock()
    args.url = 'https://httpbin.org/get'
    args.method = 'GET'
    config_dir = Path('config_dir')
    request_body_read_callback = lambda chunk: chunk

    for message in collect_messages(
        args=args,
        config_dir=Path('config_dir'),
        request_body_read_callback=request_body_read_callback
    ):
        assert isinstance(message, requests.PreparedRequest)
        assert isinstance(message, requests.Response)

if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-23 18:57:37.035936
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    argv = "httpie httpbin.org/get".split(" ")

    parser = argparse.ArgumentParser()
    args = parser.parse_args(argv)
    assert make_request_kwargs(args) == {'method': 'get', 'url': 'httpbin.org/get', 'headers': {'User-Agent': 'HTTPie/1.0.0'}, 'data': None, 'params': [], 'auth': None}

if __name__ == "__main__":
    test_make_request_kwargs()

# Generated at 2022-06-23 18:57:39.787872
# Unit test for function make_default_headers
def test_make_default_headers():
    make_default_headers(argparse.Namespace(
        json=False,
        data='{}',
        form=True,
        files=False,
    ))

# Generated at 2022-06-23 18:57:41.989829
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert 'proxies' in make_send_kwargs_mergeable_from_env(['proxy', '-p', 'http:127.0.0.1:8080'])

# Generated at 2022-06-23 18:57:48.968173
# Unit test for function build_requests_session
def test_build_requests_session():
    from httpie.downloads import Downloader
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuthWithKeyring
    from httpie.plugins.builtin import HTTPGSSAPI
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPDigestAuthWithKeyring
    from httpie.plugins.builtin import HTTPDump
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPMultipartEncoder
    from httpie.plugins.builtin import HTTPMultipartPost
    from httpie.plugins.builtin import HTTPProxyAuth

# Generated at 2022-06-23 18:57:58.759469
# Unit test for function make_default_headers