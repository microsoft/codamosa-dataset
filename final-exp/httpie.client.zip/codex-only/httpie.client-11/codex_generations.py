

# Generated at 2022-06-23 18:47:56.757641
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(
        method=None,
        url=None,
        data=None,
        json=False,
        form=False,
        headers={},
        files={},
        params={},
        auth=None,
        chunked=False,
        offline=False,
        verify=False,
        cert=None,
    )
    data = {"foo":"bar"}
    args.data = data
    print(make_request_kwargs(args))
    args.json = True
    print(make_request_kwargs(args))
    args.form = True
    print(make_request_kwargs(args))
    args.files = [{'name':'foo', 'type':'text/plain', 'data':'bar'}]

# Generated at 2022-06-23 18:48:00.031839
# Unit test for function max_headers
def test_max_headers():
    with max_headers(0):
        if sys.version_info < (3, 6):
            assert http.client._MAXHEADERS == 1
        else:
            assert http.client._MAXHEADERS == 0
    assert http.client._MAXHEADERS == 100


# Generated at 2022-06-23 18:48:03.711794
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is(
        'http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:48:13.570442
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/bar/', 'http://foo/?foo=bar') == 'http://foo/bar/?foo=bar'
    assert ensure_path_as_is('http://foo/../', 'http://foo/bar/?foo=bar') == 'http://foo/../bar/?foo=bar'
    assert ensure_path_as_is('http://foo/bar/', 'http://foo/bar/?foo=bar') == 'http://foo/bar/?foo=bar'

# Generated at 2022-06-23 18:48:17.290131
# Unit test for function dump_request
def test_dump_request():
    request_kwargs = {'url':'http://www.google.com', 'data':
    {'name':'user1', 'password':'pass1'}}
    dump_request(request_kwargs)


# Generated at 2022-06-23 18:48:19.184124
# Unit test for function max_headers
def test_max_headers():
    assert max_headers(1)

# Generated at 2022-06-23 18:48:29.428729
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    # Test with verify = yes
    test_args = argparse.Namespace(
        proxy=[],
        verify='yes'
    )
    assert make_send_kwargs_mergeable_from_env(test_args) == {
        # Make sure that verify is True
        'proxies': {},
        'stream': True,
        'verify': True,
        # Make sure that cert is None
        'cert': None
    }
    # Test with verify = no
    test_args = argparse.Namespace(
        proxy=[],
        verify='no'
    )

# Generated at 2022-06-23 18:48:38.593106
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = 0
    args.form = 0
    args.data = 0
    args.files = 0
    result = make_default_headers(args)
    assert 'User-Agent' in result
    assert 'Accept' not in result
    assert 'Content-Type' not in result
    args.json = 1
    result = make_default_headers(args)
    assert result['Accept'] == JSON_ACCEPT
    assert result['Content-Type'] == JSON_CONTENT_TYPE
    args.form = 1
    args.json = 0
    result = make_default_headers(args)
    assert 'Accept' not in result
    assert result['Content-Type'] == 'application/x-www-form-urlencoded; charset=utf-8'
    args.json = 1


# Generated at 2022-06-23 18:48:43.848060
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    default_headers = make_default_headers(args)
    assert default_headers == {'User-Agent': 'HTTPie/1.0.2', 'Accept': 'application/json, */*;q=0.5'}



# Generated at 2022-06-23 18:48:49.108367
# Unit test for function collect_messages
def test_collect_messages():
    args = {'url': 'http://httpbin.org/get', 'headers': {'Host': 'httpbin.org'}}
    config_dir = 'tests/test_config'
    for item in collect_messages(args=args, config_dir=config_dir):
        print(item)

if __name__ == '__main__':
    test_collect_messages()

# Generated at 2022-06-23 18:48:58.519230
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(method='GET', url='http://foo.com/')
    args.data = 'bar'
    args.form = False
    args.json = False
    args.files = ['bar']
    args.multipart = False
    args.multipart_data = {'foo': 'bar'}
    args.boundary = None
    args.headers = {'foo': 'bar'}
    args.offline = None
    args.chunked = False
    args.auth = None
    args.params = {'foo': 'bar'}
    request_body_read_callback = lambda chunk: chunk
    kwargs = make_request_kwargs(args,
                                 base_headers=None,
                                 request_body_read_callback=request_body_read_callback)


# Generated at 2022-06-23 18:49:08.951754
# Unit test for function dump_request
def test_dump_request():
    test_kwargs = {
        'method':'GET',
        'url': 'https://httpbin.org/get',
        'headers': {
            'Accept': 'application/json',
            'Accept-Charset': 'UTF-8',
            'Host': 'httpbin.org',
            'User-Agent': DEFAULT_UA
        },
        'params': [
            ('key1', 'value1'),
            ('key2', 'value2')
        ]
    }
    stdout = sys.stdout
    out = io.StringIO()
    sys.stdout = out
    dump_request(test_kwargs)
    sys.stdout = stdout
    output = out.getvalue().strip()

# Generated at 2022-06-23 18:49:11.406864
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace()
    config_dir = Path()
    r = collect_messages(args,config_dir)
    next(r)



# Generated at 2022-06-23 18:49:23.877478
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    assert make_send_kwargs_mergeable_from_env(argparse.Namespace(
        proxies=[],
        verify='false',
        cert=None,
        cert_key=None,
    )) == {
        'proxies': {},
        'stream': True,
        'verify': False,
        'cert': None,
    }

# Generated at 2022-06-23 18:49:32.854248
# Unit test for function max_headers
def test_max_headers():
    def mock_stderr_write(message):
        pass

    sys.stderr.write = mock_stderr_write
    args1 = argparse.Namespace(debug = True)
    dump_request(make_request_kwargs(args1))
    dump_request(make_send_kwargs_mergeable_from_env(args1))
    dump_request(make_send_kwargs(args1))
    dump_request(make_default_headers(args1))
    dump_request(finalize_headers(RequestHeadersDict()))
    requests_session1 = build_requests_session(
        verify=True,
        ssl_version='TSL',
        ciphers='ECDH'
    )

# Generated at 2022-06-23 18:49:34.621202
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    print (ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar'))

# Generated at 2022-06-23 18:49:36.543518
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    request_kwargs = make_send_kwargs({})
    assert request_kwargs['timeout'] == None
    assert request_kwargs['allow_redirects'] == False
    assert request_kwargs == {'timeout': None, 'allow_redirects': False}


# Generated at 2022-06-23 18:49:38.146987
# Unit test for function max_headers
def test_max_headers():
    def test1(headers):
        print("headers", headers)
        print(max_headers(headers))

    test1(1000)



# Generated at 2022-06-23 18:49:41.279819
# Unit test for function build_requests_session
def test_build_requests_session():
    _ssl_version = 'TLSv1.3'
    _verify = True
    print (build_requests_session(_verify, ssl_version=_ssl_version))


# Generated at 2022-06-23 18:49:48.879206
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar', 'Should return path http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/?foo=bar', 'http://foo/?foo=bar') == 'http://foo/?foo=bar', 'Should return path http://foo/?foo=bar'

test_ensure_path_as_is()

# Generated at 2022-06-23 18:49:49.664619
# Unit test for function collect_messages
def test_collect_messages():
    assert callable(collect_messages)

# Generated at 2022-06-23 18:49:53.580134
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = {'Content-Type': 'application/json', 'User-Agent': "HTTPie/1.0.3"}
    final_headers = finalize_headers(headers)
    assert final_headers['Content-Type'] == "application/json"
    assert final_headers['User-Agent'] == "HTTPie/1.0.3"


# Generated at 2022-06-23 18:49:59.066544
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data=None,
        files=None,
        form=False,
        json=False,
    )
    headers = make_default_headers(args)
    assert(headers['User-Agent'] == DEFAULT_UA)
    assert('Accept' not in headers)
    assert('Content-Type' not in headers)



# Generated at 2022-06-23 18:50:01.495376
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:50:08.541526
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == None
    assert kwargs['allow_redirects'] == False
    args.timeout = "30"
    kwargs = make_send_kwargs(args)
    assert kwargs['timeout'] == "30"
    args.allow_redirects = "yes"
    kwargs = make_send_kwargs(args)
    assert kwargs['allow_redirects'] == "yes"

# Generated at 2022-06-23 18:50:12.220916
# Unit test for function build_requests_session
def test_build_requests_session():
    print("test_build_requests_session")
    verify = True
    ssl_version = None
    ciphers = None
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=verify
    )
    return requests_session


# Generated at 2022-06-23 18:50:18.994110
# Unit test for function dump_request
def test_dump_request():
    request_kwargs = dict(
        {
            'method': 'POST',
            'url': 'http://localhost:9000',
            'headers': {'User-Agent': 'HTTPie/1.0.0'},
            'data': "{\n  \"user_name\": \"test_user\"\n}",
            'auth': None,
            'params': [('test_param', 'test_value')],
        }
    )
    dump_request(request_kwargs)

# Generated at 2022-06-23 18:50:28.845661
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    import argparse
    args = argparse.Namespace()
    args.method = 'get'
    args.url = 'http://www.test.com/test2/'
    args.headers = None
    args.data = None
    args.json = None
    args.form = None
    args.files = []
    args.auth = None
    args.params = {}
    args.chunked = False
    args.compress = False
    args.debug = False
    args.output= None
    args.insecure = False
    args.session = None
    args.session_read_only = None
    args.timeout= 3
    args.check_status = False
    args.follow= False
    args.max_redirects= 30
    args.max_headers= None
    args.style= None


# Generated at 2022-06-23 18:50:31.093644
# Unit test for function max_headers
def test_max_headers():
    args={'max_headers':None}
    with max_headers(args['max_headers']):
        pass


# Generated at 2022-06-23 18:50:36.542326
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(method='GET',url='https://www.google.com',headers=['Content-Type'] )
    assert make_request_kwargs(args)['headers'] == {'Content-Type':[''], 'User-Agent': ['HTTPie/0.9.9']}


# Generated at 2022-06-23 18:50:43.191605
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    req_kwargs = make_request_kwargs(argparse.Namespace(
        method='get',
        url='http://a',
        files='a',
        data='a',
        chunked=False,
        offline=False
    ))
    assert req_kwargs['url'] == 'http://a'
    assert req_kwargs['method'] == 'get'
    assert req_kwargs['files'] == 'a'
    assert req_kwargs['data'] == 'a'
    assert req_kwargs['chunked'] == False

# Generated at 2022-06-23 18:50:53.269939
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    # Testing with make_send_kwargs
    args = argparse.Namespace(
        auth=('user', 'password'),
        auth_type='basic',
        chunked=False,
        data={
            'status': 'ok'
        },
        form=False,
        headers={},
        json=True,
        method='POST',
        timeout=None,
        url='example.com/',
        verify=None,
    )
    expected_result = {
        'allow_redirects': False,
        'cert': None,
        'timeout': None,
    }
    assert make_send_kwargs(args) == expected_result



# Generated at 2022-06-23 18:50:56.090930
# Unit test for function build_requests_session
def test_build_requests_session():
    session = build_requests_session(verify=True, ssl_version=None)
    assert session
    # TODO: verify further with the result

# Generated at 2022-06-23 18:51:01.274446
# Unit test for function finalize_headers
def test_finalize_headers():
    # Test for headers when record separator is "\r\n"
    source = '{}'
    assert finalize_headers(source) == '{}{}'.format('{}\r\n', '\r\n')



# Generated at 2022-06-23 18:51:04.828065
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    from argparse import Namespace

    args = Namespace(
        timeout=1,
        allow_redirects=False,
    )
    assert make_send_kwargs(args) == {'timeout': 1, 'allow_redirects': False}



# Generated at 2022-06-23 18:51:17.304389
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    sys.argv = [
        'httpie',
        '--method=DELETE',
        '--data',
        'name=bla',
        'POST',
        '--json',
        '--body={"name":"bla"}',
        '--headers',
        'Content-Language:en-US',
        '--headers',
        'Host: example.com',
        # '--auth-type=basic',
        # '--auth=janedoe:sup3rs3cr3t',
        'https://example.com/api/users/42'
    ]
    args = plugin_manager.resolve_command_line()
    request_kwargs = make_request_kwargs(args)

# Generated at 2022-06-23 18:51:29.657528
# Unit test for function dump_request
def test_dump_request():
    request_kwargs = dict()
    request_kwargs['headers'] = dict()
    request_kwargs['headers']['Host'] = 'www.google.com'
    request_kwargs['headers']['Content-Length'] = 199
    request_kwargs['headers']['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0'
    request_kwargs['headers']['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
    request_kwargs['headers']['Accept-Language'] = 'en-US,en;q=0.5'
    request_kwargs

# Generated at 2022-06-23 18:51:36.284636
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace()
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {'allow_redirects': False}

    args = argparse.Namespace(timeout=3)
    send_kwargs = make_send_kwargs(args)
    assert send_kwargs == {'timeout': 3, 'allow_redirects': False}


# Unit tests for function make_send_kwargs_mergeable_from_env

# Generated at 2022-06-23 18:51:45.937857
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/../bar', 'http://foo/?foo=bar') == 'http://foo/../bar?foo=bar'
    assert ensure_path_as_is('http://foo/../bar', 'http://foo/bar/baz?foo=bar') == 'http://foo/../bar?foo=bar'
    assert ensure_path_as_is('http://foo/../../bar', 'http://foo/bar/baz?foo=bar') == 'http://foo/../../bar?foo=bar'

# Generated at 2022-06-23 18:51:56.894078
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    cli_args = argparse.Namespace()
    cli_args.verify = 'yes'
    cli_args.cert = '/path/to/my/cert.pem'
    cli_args.cert_key = '/path/to/my/private.key'
    cli_args.proxy = ('localhost', '8080')
    kwargs = make_send_kwargs_mergeable_from_env(cli_args)
    assert kwargs['verify'] == True
    assert kwargs['cert'] == ('/path/to/my/cert.pem', '/path/to/my/private.key')
    assert kwargs['proxies'] == {'http': 'localhost', 'https': '8080'}

# Generated at 2022-06-23 18:52:06.916362
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict(
        [
            ('Accept', 'application/json'),
            ('Content-Type', 'text/plain')
        ]
    )
    assert finalize_headers(headers) == {
        'Accept' : 'application/json',
        'User-Agent' : 'HTTPie/0.9.9',
        'Content-Type' : 'text/plain'
    }
    assert finalize_headers(RequestHeadersDict()) == {
        'User-Agent' : 'HTTPie/0.9.9'
    }
    assert finalize_headers(RequestHeadersDict([])) == {
        'User-Agent' : 'HTTPie/0.9.9'
    }


# Generated at 2022-06-23 18:52:14.348160
# Unit test for function build_requests_session
def test_build_requests_session():
    assert build_requests_session(True)
    assert build_requests_session(False)
    assert build_requests_session(True, None)
    assert build_requests_session(True, 'TLSv1_3')
    
    for plugin_cls in plugin_manager.get_transport_plugins():
        transport_plugin = plugin_cls()
        requests_session = build_requests_session(True)
        assert requests_session.mount(
            prefix=transport_plugin.prefix,
            adapter=transport_plugin.get_adapter(),
        )


# Generated at 2022-06-23 18:52:23.997670
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    test_ssl_version = AVAILABLE_SSL_VERSION_ARG_MAPPING['sslv3']

# Generated at 2022-06-23 18:52:33.299108
# Unit test for function finalize_headers

# Generated at 2022-06-23 18:52:38.621423
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.url = "http://example.com/"
    args.json = "false"
    args.form = "false"
    args.data = "false"

    result = make_default_headers(args)
    assert type(result) == RequestHeadersDict
    assert result.get('User-Agent') == "HTTPie/2.2.0"


# Generated at 2022-06-23 18:52:42.071524
# Unit test for function max_headers
def test_max_headers():
    with http.client._MAXHEADERS == 100:
        assert http.client._MAXHEADERS == 100
    with http.client._MAXHEADERS == 1000:
        assert http.client._MAXHEADERS == 1000

# Generated at 2022-06-23 18:52:43.097862
# Unit test for function collect_messages
def test_collect_messages():
    args = argparse.Namespace
    assert 1 == 1

# Generated at 2022-06-23 18:52:48.311817
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = make_default_headers(args=None)
    final_headers = finalize_headers(headers)
    req = requests.Request(
        url="http://httpbin.org/get", method="GET", headers=final_headers,
    )
    assert req.headers['User-Agent'] == DEFAULT_UA

# Generated at 2022-06-23 18:52:56.689486
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:53:07.098898
# Unit test for function build_requests_session
def test_build_requests_session():
    from .sessions import HTTPieSession
    from .utils import get_expired_cookies
    ssl_version = 'default'
    ciphers=None
    verify=False
    config_dir = Path('/') #TODO change
    host = 'localhost'
    url = 'http://localhost:5000/'
    httpie_session = get_httpie_session(
        config_dir=config_dir,
        session_name='',
        host=host,
        url=url
    )
    cookies=httpie_session.cookies
    requests_session = build_requests_session(
        ssl_version=ssl_version,
        ciphers=ciphers,
        verify=verify
    )
    requests_session.cookies = cookies

# Generated at 2022-06-23 18:53:12.403343
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({'Accept': '  text/plain  ,*/*;q=0.5', 'User-Agent': '  HTTPie/1.0.3  '})
    headers = finalize_headers(headers)
    assert headers['Accept'] == b'text/plain,*/*;q=0.5'
    assert headers['User-Agent'] == b'HTTPie/1.0.3'

# Generated at 2022-06-23 18:53:15.501260
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 1000
    try:
        with max_headers(100):
            assert http.client._MAXHEADERS == 100
            raise Exception()
    except:
        assert http.client._MAXHEADERS == 1000



# Generated at 2022-06-23 18:53:22.401262
# Unit test for function make_send_kwargs

# Generated at 2022-06-23 18:53:31.708919
# Unit test for function collect_messages
def test_collect_messages():
    import requests
    import argparse
    #import pytest
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    config_dir = Path(args.config_dir)
    request_body_read_callback = lambda chunk: chunk
    import os
    import sys
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(sys.path[0] + "/../")
    from test_plugin.plugin import TestPlugin
    from test_plugin.plugin import TestPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import AuthPlugin, AuthCredentials
    from httpie.cli.auth import get_auth_

# Generated at 2022-06-23 18:53:39.116990
# Unit test for function max_headers
def test_max_headers():
    import http.client
    from httpie.utils import max_headers
    from contextlib import redirect_stdout

    http.client._MAXHEADERS = 30
    with max_headers(20):
        assert http.client._MAXHEADERS == 20

    with max_headers(None):
        assert http.client._MAXHEADERS == float('inf')

    with redirect_stdout(sys.stderr):
        http.client._MAXHEADERS = -1
        max_headers(20)
        assert http.client._MAXHEADERS == 20

# Generated at 2022-06-23 18:53:42.163383
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
  url = 'http://foo/../'
  prepped_url = 'http://foo/?foo=bar'
  assert ensure_path_as_is(url, prepped_url) == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:53:54.844893
# Unit test for function collect_messages

# Generated at 2022-06-23 18:54:01.185063
# Unit test for function collect_messages
def test_collect_messages():
    kwargs = {'method': 'GET',
              'url': 'http://httpbin.org/get',
              'headers': {'User-Agent': 'HTTPie/1.0.2'},
              'data': '',
              'auth': None,
              'params': {}}

    kwargs_send = {'timeout':None, 'allow_redirects':False}
    kwargs_send_merge = {
        'proxies':{},
        'stream':True,
        'verify':True,
        'cert':None,
    }

# Generated at 2022-06-23 18:54:08.363863
# Unit test for function dump_request
def test_dump_request():
    dummy_request = {
        'headers': {
            'Accept': '* / *',
            'Accept-Encoding': 'gzip, deflate',
            'Host': 'httpbin.org',
            'User-Agent': 'python-requests/2.22.0',
            'X-Amzn-Trace-Id': 'Root=1-5e6f7f47-ba71c0d85f8585de6f06b6a2'
        },
        'method': 'POST',
        'url': 'http://httpbin.org/post'
    }

    dump_request(dummy_request)

# Generated at 2022-06-23 18:54:18.627579
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    args1 = argparse.Namespace()
    args2 = argparse.Namespace()
    args3 = argparse.Namespace()
    args4 = argparse.Namespace()
    p1 = argparse.Namespace()
    p1.key = 'http'
    p1.value = 'http'
    p2 = argparse.Namespace()
    p2.key = 'http'
    p2.value = 'https'
    p3 = argparse.Namespace()
    p3.key = 'https'
    p3.value = 'https'
    args1.proxy = [p1]
    args2.proxy = [p2, p3]
    args2.verify = 'yes'
    args2.cert = True
    args4.verify = 'no'
    args4.cert = False

# Generated at 2022-06-23 18:54:21.638072
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    args = argparse.Namespace
    kwargs = make_send_kwargs(args)
    assert(kwargs['timeout'] is None)
    assert(kwargs['allow_redirects'] == False)

# Generated at 2022-06-23 18:54:27.601053
# Unit test for function dump_request
def test_dump_request():
    kwargs = {'data': None, 'method': 'GET', 'url': 'http://httpbin.org/get', 'headers': {'User-Agent': 'HTTPie/0.9.9', 'Accept': 'application/json, */*;q=0.5', 'Accept-Encoding': 'gzip, deflate', 'Connection': 'keep-alive'}, 'params': ()}
    dump_request(kwargs)

test_dump_request()

# Generated at 2022-06-23 18:54:29.111853
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(False, None, None)
    assert requests_session.mounts != []

# Generated at 2022-06-23 18:54:33.242266
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace()
    args.json = True
    assert make_default_headers(args)['Accept'] == JSON_ACCEPT
    args.json = False
    args.form = True
    assert make_default_headers(args)['Content-Type'] == FORM_CONTENT_TYPE


# Generated at 2022-06-23 18:54:35.630163
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:54:42.253630
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    arg_namespace = argparse.Namespace()
    arg_namespace.timeout = 10
    arg_namespace.allow_redirects = False
    send_kwargs = make_send_kwargs(arg_namespace)
    assert type(send_kwargs) == dict
    assert send_kwargs == {'timeout': 10, 'allow_redirects': False}

# Generated at 2022-06-23 18:54:43.339146
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:54:48.054513
# Unit test for function finalize_headers
def test_finalize_headers():
    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = '  json  '
    result = finalize_headers(request_headers)
    print(result)
    assert (result['Content-Type'] == b'json'), \
        'finalize_headers did not work'

if __name__ == '__main__':
    test_finalize_headers()

# Generated at 2022-06-23 18:55:00.438955
# Unit test for function dump_request
def test_dump_request():
    # test with empty kwargs
    test_dump_request_case_1 = {}
    assert dump_request(test_dump_request_case_1) == \
           f'\n>>> requests.request(**{repr_dict({})})\n\n'

# Generated at 2022-06-23 18:55:12.345260
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify", default="True", help="")
    parser.add_argument("--insecure", action="store_true", help="")
    parser.add_argument("--cert", default="", help="")
    parser.add_argument("--cert-key", help="")
    parser.add_argument("--proxy", default=[], action="append", help="")
    parser.add_argument("--timeout", default="", help="")
    parser.add_argument("--max-redirects", default="", help="")
    parser.add_argument("--allow-redirects", action="store_true", help="")
    parser.add_argument("--offline", action="store_true", help="")


# Generated at 2022-06-23 18:55:16.354617
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = argparse.Namespace(url="https://localhost:8080",method="GET",headers="",data=None)
    print(make_request_kwargs(args))


# Generated at 2022-06-23 18:55:24.964845
# Unit test for function build_requests_session
def test_build_requests_session():

    args_ssl_version = "SSLv3"
    args_verify = "False"
    args_ciphers = "ciphers"
    req_session = build_requests_session(verify=args_verify,
                                          ssl_version=args_ssl_version,
                                          ciphers=args_ciphers)
    assert req_session.mounts['https://'][0].ssl_version ==\
           AVAILABLE_SSL_VERSION_ARG_MAPPING[args_ssl_version]
    assert req_session.mounts['https://'][0].ciphers == args_ciphers
    assert req_session.mounts['https://'][0].verify == False

# Generated at 2022-06-23 18:55:27.044993
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = False
    ssl_version = None
    ciphers = None
    build_requests_session(verify, ssl_version, ciphers)

# Generated at 2022-06-23 18:55:35.211059
# Unit test for function dump_request

# Generated at 2022-06-23 18:55:36.967960
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'

# Generated at 2022-06-23 18:55:44.806737
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    args = type('Namespace', (object,), {
            'auth': None,
            'body': None,
            'form': False,
            'headers': {
                'Content-Type': 'text/plain',
                'Accept': 'text/plain'
            },
            'json': False,
            'method': 'GET',
            'params': {},
            'timeout': None,
            'url': 'http://localhost'
        })
    assert make_request_kwargs(args)[
        'headers'] == {'Content-Type': 'text/plain', 'Accept': 'text/plain'}

# Generated at 2022-06-23 18:55:47.046055
# Unit test for function max_headers
def test_max_headers():
    with max_headers(100):
        assert http.client._MAXHEADERS == 100
    assert http.client._MAXHEADERS != 100

# Generated at 2022-06-23 18:55:53.194187
# Unit test for function make_request_kwargs
def test_make_request_kwargs():
    class args:
        method = 'post'
        url = 'http://www.google.co.kr'
        headers = {}
        data = 45
        json = False
        form = True
    kwargs = make_request_kwargs(args=args)
    print(kwargs)


# Generated at 2022-06-23 18:56:01.925076
# Unit test for function make_send_kwargs_mergeable_from_env
def test_make_send_kwargs_mergeable_from_env():
    testargs = [
        '-p', 'proxy1=http://localhost:8080',
        '-p', 'proxy2=socks://localhost:8080',
        '--verify', 'yes',
        '--verify', 'false',
        '--cert', 'customcert.pem',
        '--cert-key', 'customcert.pem'
    ]
    args = argparse.Namespace()
    args.proxy = [
        argparse.Namespace(key='proxy1', value='http://localhost:8080'),
        argparse.Namespace(key='proxy2', value='socks://localhost:8080')
    ]
    args.verify = 'yes'
    args.cert = 'customcert.pem'
    args.cert_key = 'customcert.pem'
    assert make_

# Generated at 2022-06-23 18:56:09.111752
# Unit test for function build_requests_session
def test_build_requests_session():
    from httpie.plugins.builtin import HTTPBasicAuth
    https_adapter = HTTPieHTTPSAdapter(ciphers='aes256-gcm-sha384',
                                       verify=False,
                                       ssl_version='TLS')
    requests_session = requests.Session()
    requests_session.mount('https://', https_adapter)
    requests_session.auth = HTTPBasicAuth('root','toor')
    requests_session.trust_env = False
    return requests_session

# Generated at 2022-06-23 18:56:18.950498
# Unit test for function collect_messages
def test_collect_messages():
    import argparse


# Generated at 2022-06-23 18:56:27.017828
# Unit test for function finalize_headers
def test_finalize_headers():
    headers = RequestHeadersDict({
        'Content-Type': 'a; charset=b',
        'User-Agent': 'HTTPie/0.9.9',
        'Accept-Encoding': 'c',
        'Accept': 'd',
        'Host': 'e'
    })
    final_headers = finalize_headers(headers)
    assert final_headers["Accept"] == "d"
    assert final_headers["Content-Type"] == "a; charset=b"
    assert final_headers["Accept-Encoding"] == "c"
    assert final_headers["Host"] == "e"

# Generated at 2022-06-23 18:56:31.674174
# Unit test for function build_requests_session
def test_build_requests_session():
    requests_session = build_requests_session(
        verify="no",
        ssl_version=None,
        ciphers=None,
    )
    assert(isinstance(requests_session, requests.Session))
    #assert(isinstance(requests_session.adapters,HTTPieHTTPSAdapter))
    assert(requests_session.headers['User-Agent'] == DEFAULT_UA)


# Generated at 2022-06-23 18:56:39.073705
# Unit test for function collect_messages
def test_collect_messages():
    import httpie.cli
    args = httpie.cli.parser.parse_args(['http://www.google.com/'])
    config_dir = Path('/tmp/httpie.d/')
    request_body_read_callback = lambda chunk: chunk
    collect_messages(args, config_dir, request_body_read_callback)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:56:42.486926
# Unit test for function collect_messages
def test_collect_messages():
    # TODO: Add a unit test for function collect_messages
    pass


# Generated at 2022-06-23 18:56:47.683477
# Unit test for function max_headers
def test_max_headers():
    http.client._MAXHEADERS = 10
    with max_headers(None):
        assert http.client._MAXHEADERS == float('inf')
    assert http.client._MAXHEADERS == 10

    with max_headers(20):
        assert http.client._MAXHEADERS == 20

    assert http.client._MAXHEADERS == 10

# Generated at 2022-06-23 18:56:50.018175
# Unit test for function finalize_headers
def test_finalize_headers():
    h = {'Accept': 'application/json'} 
    assert finalize_headers(h) == h
    

# Generated at 2022-06-23 18:56:53.046401
# Unit test for function max_headers
def test_max_headers():
    with max_headers(5):
        assert http.client._MAXHEADERS == 5
    assert http.client._MAXHEADERS == 100

# Generated at 2022-06-23 18:56:59.009705
# Unit test for function make_send_kwargs
def test_make_send_kwargs():
    test_args = argparse.Namespace()
    setattr(test_args, 'timeout', 100)
    setattr(test_args, 'allow_redirects', False)
    kwargs = make_send_kwargs(test_args)
    assert kwargs['timeout'] == 100
    assert kwargs['allow_redirects'] == False

# Generated at 2022-06-23 18:57:05.092347
# Unit test for function make_request_kwargs

# Generated at 2022-06-23 18:57:16.132271
# Unit test for function make_default_headers
def test_make_default_headers():
    arg = argparse.Namespace()
    arg.json = None
    arg.form = False
    default_headers = make_default_headers(arg)
    assert default_headers['User-Agent'] == DEFAULT_UA

    arg.json = False
    arg.form = True
    default_headers = make_default_headers(arg)
    assert default_headers['Content-Type'] == FORM_CONTENT_TYPE

    arg.json = True
    arg.form = False
    default_headers = make_default_headers(arg)
    assert default_headers['Accept'] == JSON_ACCEPT
    assert default_headers['Content-Type'] == JSON_CONTENT_TYPE

    arg.json = True
    arg.form = True
    default_headers = make_default_headers(arg)
    assert default_headers['Accept'] == JSON_

# Generated at 2022-06-23 18:57:22.424912
# Unit test for function ensure_path_as_is
def test_ensure_path_as_is():
    assert ensure_path_as_is('http://foo/../', 'http://foo/?foo=bar') == 'http://foo/../?foo=bar'
    assert ensure_path_as_is('http://foo/', 'http://foo/?foo=bar') == 'http://foo/?foo=bar'

# Generated at 2022-06-23 18:57:25.969466
# Unit test for function build_requests_session
def test_build_requests_session():
    verify = False
    ssl_version = None
    ciphers = None
    return build_requests_session(
        verify=verify,
        ssl_version=ssl_version,
        ciphers=ciphers
    )


# Generated at 2022-06-23 18:57:30.585227
# Unit test for function make_default_headers
def test_make_default_headers():
    args=argparse.Namespace(headers={},
                 data={},
                 json=True,
                 form=False,
                 files={})
    default_headers=make_default_headers(args)
    assert default_headers == {'Accept': 'application/json, */*;q=0.5', 'User-Agent': 'HTTPie/'+ __version__}



# Generated at 2022-06-23 18:57:40.563067
# Unit test for function finalize_headers
def test_finalize_headers():
    test_headers = RequestHeadersDict({
        'Test': None,
        'Test2': 'Test2',
        'Test3': '   Test3   ',
        'Test4': 'Test4',
        'Test4': None
    })
    expected_headers = RequestHeadersDict({
        'Test2': b'Test2',
        'Test3': b'Test3',
        'Test4': b'Test4',
        'User-Agent': DEFAULT_UA
    })
    actual_headers = finalize_headers(test_headers)
    if actual_headers != expected_headers:
        print('Unit test failed!')
        print(f'Expected: {expected_headers}')
        print(f'Actual: {actual_headers}')
        sys.exit(1)
    else:
        print

# Generated at 2022-06-23 18:57:42.925993
# Unit test for function collect_messages
def test_collect_messages():
    """
    Test the function collect_messages
    :return:
    """
    args = None
    config_dir = None
    request_body_read_callback = None
    assert collect_messages(args, config_dir, request_body_read_callback)



# Generated at 2022-06-23 18:57:48.479577
# Unit test for function make_default_headers
def test_make_default_headers():
    args = argparse.Namespace(
        data={},
        files=[],
        form=False,
        json=False
    )
    expected = {'User-Agent': 'HTTPie/0.9.8'}
    result = make_default_headers(args)
    assert result == expected, result

