

# Generated at 2022-06-21 18:08:02.334959
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-21 18:08:03.711327
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from .base import BaseTransformerTest


# Generated at 2022-06-21 18:08:15.162226
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    n = ast.Module([ast.Expr(ast.Call(ast.Name('foo', ast.Load()), [ast.Call(ast.Name('bar', ast.Load()), [ast.Name('str', ast.Load())], [], None, None)]))])

    transformer = StringTypesTransformer.from_version(version=(2, 7))
    transformed_tree = transformer.transform(tree=n)

    assert isinstance(transformed_tree.new_tree, ast.AST)
    assert isinstance(transformed_tree.new_tree, ast.Module)
    assert len(transformed_tree.new_tree.body) == 1
    assert isinstance(transformed_tree.new_tree.body[0], ast.Expr)

# Generated at 2022-06-21 18:08:17.333239
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:08:18.532874
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:08:24.250221
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    input_str = """str\na = str()\nb = str("string")"""
    expected_str = """unicode\na = unicode()\nb = unicode("string")"""

    tree = ast.parse(input_str)
    tree = StringTypesTransformer.transform(tree).tree

    assert astor.to_source(tree) == expected_str

# Generated at 2022-06-21 18:08:24.850314
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:08:30.691586
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('s = "Hello World."')
    StringTypesTransformer().transform(tree)

    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="s", ctx=Store())], value=Str(s="Hello World."))])'


# Generated at 2022-06-21 18:08:35.240675
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import parse, encode

    test_tree = parse("print(str)")
    res_tree = StringTypesTransformer.transform(test_tree)
    assert encode(res_tree.tree) == "print unicode "

# Generated at 2022-06-21 18:08:46.879580
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_base import BaseTransformerTest
    from ..types import TransformationResult


# Generated at 2022-06-21 18:08:51.775485
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('''x = str(1)
    ''')) ==  TransformationResult(ast.parse('''x = unicode(1)
    '''), True, [])

# Generated at 2022-06-21 18:08:57.837467
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('''
a = str(42)
''')).tree_changed == True
    assert StringTypesTransformer.transform(ast.parse('''
a = 42
''')).tree_changed == False
    assert StringTypesTransformer.transform(ast.parse('''
a = str(unicode(42))
''')).tree_changed == False

# Generated at 2022-06-21 18:09:01.543269
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_tree = ast.parse('x = str()')
    StringTypesTransformer.transform(test_tree)
    assert(test_tree == ast.parse('x = unicode()'))

# Generated at 2022-06-21 18:09:09.117965
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast

    tree_a = source_to_tree('''\
        def f():
            a = str(1)
            return "a"
    ''')
    tree_b = source_to_tree('''\
        def f():
            a = unicode(1)
            return "a"
    ''')

    tree = StringTypesTransformer.transform(tree_a)
    assert compare_ast(tree, tree_b)



# Generated at 2022-06-21 18:09:15.368989
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def transform(self, tree):
        return 'str' 
    """
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(new_tree.tree).strip() == astor.to_source(ast.parse("""
    def transform(self, tree):
        return 'unicode' 
    """).body[0]).strip()
    assert new_tree.tree_changed

# Generated at 2022-06-21 18:09:19.419431
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast_string = 'a = str(3)'
    tree = ast.parse(ast_string)
    tree_copy = copy.deepcopy(tree)

    result = StringTypesTransformer.transform(tree)
    tree = result.tree

    assert result.tree_changed
    assert ast.dump(tree) != ast.dump(tree_copy)
    assert ast.dump(tree) == ast.dump(ast.parse('a = unicode(3)'))

# Generated at 2022-06-21 18:09:30.114098
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    msg = '''
    def func(a: str, b: str, c=str):
        print(str('foo'))
        print(type('baz'))
        return str()
    '''

    tree = ast.parse(msg)
    ref_node = find(tree,  ast.Name)
    t = StringTypesTransformer()
    t.transform(tree)

    assert t.version == (2, 7)
    assert ref_node[0].id == 'unicode'
    assert ref_node[1].id == 'unicode'
    assert ref_node[2].id == 'unicode'
    assert ref_node[3].id == 'unicode'
    assert ref_node[4].id == 'unicode'

# Generated at 2022-06-21 18:09:36.183281
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert_equals = Equals(
            StringTypesTransformer.transform(
                    ast.parse('a = str()', '<test>', 'exec')))
    assert_equals.string = "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"
    assert_equals.warnings = []
    assert_equals.changed = True


# Generated at 2022-06-21 18:09:37.118240
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:09:49.362367
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..ast_tools import dump
    from textwrap import dedent
    from .base import create
    source = dedent(u'''
    class Test(object):
        def __init__(self, name: str) -> None:
            self.name = name 
        def foo(self, x: int) -> str:
            return "foo" + self.name + str(x)''')
    tree = create(source)
    result = StringTypesTransformer.transform(tree)
    assert dump(result.tree) == dedent(u'''
    class Test(object):

        def __init__(self, name: unicode) -> None:
            self.name = name

        def foo(self, x: int) -> unicode:
            return 'foo' + self.name + unicode(x)
    ''')

# Generated at 2022-06-21 18:10:02.060950
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # sample code for StringTypesTransformer class
    code='''
    a=str(5)
    '''
    # parse the code string to AST
    module_node = ast.parse(code)
    # initialize the class
    trans = StringTypesTransformer()
    # transform the code from 2.7 to 2.6
    module_node = trans.visit(module_node)
    # compile the AST to code object
    codeobj = compile(module_node, filename="<ast>", mode="exec")
    # if you want to get the code back as a string, use the below function
    code2 = to_source(module_node)
    # execute the code object
    exec(codeobj)
    assert a == 5

# Generated at 2022-06-21 18:10:04.810786
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
""")
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed

# Generated at 2022-06-21 18:10:09.934129
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # tree = ast.parse('str = "a"')
    # t = StringTypesTransformer()
    # assert_equal(unicode(ast.dump(t.visit(tree))), unicode('Module(body=[Assign(targets=[Name(id=\'unicode\', ctx=Store())], value=Str(s=\'a\'))])'))
    pass

# Generated at 2022-06-21 18:10:20.258601
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """str(foo)"""
    tree = ast.parse(code)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed is True
    assert type(tree) == type(new_tree)

    code = """str"""
    tree = ast.parse(code)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed is True
    assert type(tree) == type(new_tree)

    code = """foo"""
    tree = ast.parse(code)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed is False
    assert type(tree) == type(new_tree)

# Generated at 2022-06-21 18:10:30.530602
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(
        ast.parse('x = str(); str', mode='eval')) == \
        TransformationResult(
        ast.parse('x = unicode(); unicode', mode='eval'),
        True, [])
    assert StringTypesTransformer.transform(
        ast.parse('x = str(); str', mode='eval')) != \
        TransformationResult(
        ast.parse('x = str(); unicode', mode='eval'),
        False, [])
    assert StringTypesTransformer.transform(
        ast.parse('x = unicode(); str', mode='eval')) == \
        TransformationResult(
        ast.parse('x = unicode(); unicode', mode='eval'),
        False, [])

# Generated at 2022-06-21 18:10:33.505526
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = "str('foo')" 
    expected = "unicode('foo')" 
    actual = StringTypesTransformer.transform(ast.parse(s))
    assert expected == actual

# Generated at 2022-06-21 18:10:39.709058
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo():
            return str
    """)
    assert tree.body[0].body[0].value.id == 'str'
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].body[0].value.id == 'unicode'

# Generated at 2022-06-21 18:10:49.980242
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Testing transformations
    cases = [
        ('var = str(1)', 'var = unicode(1)'),
        ('var = str(1.0)', 'var = unicode(1.0)'),
        ('var = str()', 'var = unicode()'),
        ('var = str(1, 2)', 'var = unicode(1, 2)'),
        ('import str', 'import unicode'),
        ('import str as test', 'import unicode as test'),
        ('from str import test', 'from unicode import test'),
        ('from str import *', 'from unicode import *'),
        ('from str import test as test2', 'from unicode import test as test2')
    ]

    for test, result in cases:
        tree = ast.parse(test)
        StringTypesTransformer.transform(tree)

# Generated at 2022-06-21 18:10:53.450417
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name(id='str', ctx=ast.Load())
    assert StringTypesTransformer.transform(node) == TransformationResult(
        node,
        True,
        []
    )

# Generated at 2022-06-21 18:11:03.271751
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer
    t_expr_x = ast.parse('a.decode()', mode='eval')
    t_expr_y = ast.parse('a.decode(x)', mode='eval')
    (t_expr_x,) = transformer.transform(t_expr_x).get_modified()
    (t_expr_y,) = transformer.transform(t_expr_y).get_modified()
    assert ast.dump(t_expr_x) == ast.dump(ast.parse('a.decode()', mode='eval'))
    assert ast.dump(t_expr_y) == ast.dump(ast.parse('a.decode(x)', mode='eval'))

# Generated at 2022-06-21 18:11:11.410823
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test `StringTypesTransformer` transformer.

    """

# Generated at 2022-06-21 18:11:13.120725
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:11:20.572694
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = inspect.getsource(StringTypesTransformer)
    tree = ast.parse(code)
    expected = TransformationResult(
        ast.parse(code[:27] + 'unicode' + code[31:]), True, [])
    assert expected.tree_changed == True

# Generated at 2022-06-21 18:11:23.702840
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
            x = str('foo')
            """
    result = StringTypesTransformer(code).transform()

    assert 'x = str(\'foo\')' not in result 
    assert 'x = unicode(\'foo\')' in result

# Generated at 2022-06-21 18:11:25.022828
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert hasattr(StringTypesTransformer, 'transform')
    assert callable(StringTypesTransformer.transform)

# Generated at 2022-06-21 18:11:26.951710
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("def f():\n return str(100)")
    StringTypesTransformer(tree).transform()
    # TODO: check that the tree has been transformed as expected.
    return True

# Generated at 2022-06-21 18:11:29.001507
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = "it's a nice day, isn't it?"
    assert isinstance(x, str)
    assert not isinstance(x, unicode)

# Generated at 2022-06-21 18:11:40.305441
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    string_types_transformer = transformer.transform

    # Test for class StringTypesTransformer
    assert isinstance(string_types_transformer, type(lambda: None))

    # Test for method StringTypesTransformer.transform
    # Empty code string
    tree = ast.parse("")
    assert string_types_transformer(tree) == TransformationResult(tree, False, [])

    # Code string without modifications
    tree = ast.parse("str is str")
    assert string_types_transformer(tree) == TransformationResult(tree, False, [])

    # Code string with modifications
    tree = ast.parse("str()")
    result_obj = string_types_transformer(tree)
    assert result_obj == TransformationResult(tree, True, [])
    assert result_obj.tree is not tree

# Generated at 2022-06-21 18:11:49.224214
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # given
    target = (2, 7)
    code = dedent('''
    def foo(a: str):
        return a
    ''')
    tree = ast.parse(code)

    # when
    result = StringTypesTransformer.transform(tree)

    # then
    assert result.tree_changed
    assert isinstance(result.tree.body[0].args.args[0].annotation, ast.Name)
    assert result.tree.body[0].args.args[0].annotation.id == 'unicode'


# Generated at 2022-06-21 18:11:57.933206
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Test 1: This should produce the same file
    test = """
    a = u'Hello World'
    """
    expected = [ast.parse(test)]
    transformer = StringTypesTransformer(expected)
    assert transformer.transform() == expected

    # Test 2: This should produce the same file
    test = """
    a = u'Hello World'
    b = 'How are you?'
    c = b
    """
    expected = [ast.parse(test)]
    
    transformer = StringTypesTransformer(expected)
    assert transformer.transform() == expected

    # Test 3: This should produce the same file
    test = """
    a = 'Hello World'
    b = 'How are you?'
    c = b + a
    """
    expected = [ast.parse(test)]
    
    transformer = StringTypesTrans

# Generated at 2022-06-21 18:12:13.450987
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

    t = ast.parse('''
        if x == str():
            pass
    ''')

    t = StringTypesTransformer.transform(t).tree

    assert astunparse.unparse(t) == '''
        if x == unicode():
            pass
    '''

# Generated at 2022-06-21 18:12:18.391668
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
a = str('abc')
b = str(b)
'''
    expected = '''
a = unicode('abc')
b = unicode(b)
'''

    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    result = compile(new_tree, '', 'exec')
    test_env = {}
    exec(result, test_env)

    assert test_env == {}
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected))
    assert transformer.transformation_count == 2

# Generated at 2022-06-21 18:12:26.936879
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    class X:
        def __init__(self, a:str, b:str="hello")->str:
            self.result=a+b
    tree=ast.parse(inspect.getsource(X))
    res=StringTypesTransformer.transform(tree)
    for node in res.changed_nodes:
        assert type(node.id)==str
        assert node.id!="str"
        assert node.id=="unicode"
    assert res.tree!=tree

# Tests the transformation: str->unicode


# Generated at 2022-06-21 18:12:29.347134
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.target == (2, 7)
    assert isinstance(t, BaseTransformer)

# Generated at 2022-06-21 18:12:30.653130
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import make_tree


# Generated at 2022-06-21 18:12:35.278176
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast

    tree = build_ast("""
    x = str(1) + str(2)
    y = unicode(1) + unicode(2)
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.num_errors == 0
    assert result.report == []


# Generated at 2022-06-21 18:12:43.290911
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils import parse, compare_source
    
    s = "print(str)"

    t1 = parse(s)
    t2 = StringTypesTransformer.transform(t1)
    assert compare_source(astor.to_source(t1), astor.to_source(t2.tree)) == True
    assert t2.tree_changed == True
    assert t2.messages == []



# Generated at 2022-06-21 18:12:54.112477
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    
    """
    # tree = ast.parse('''
    #     from __future__ import absolute_import
    #     from typing import Literal

    #     def foo(bar: Literal[str]):
    #         ...
    #     '''
    # )

    # tree = ast.parse('''
    #     def foo(bar: str):
    #         ...
    #     '''
    # )

    tree = ast.parse('''
        baz = bool(foo(bar))
        '''
    )

    # tree = ast.parse('''
    #     baz = str
    #     '''
    # )

    tree_changed, report = StringTypesTransformer.transform(tree)

    assert tree_changed == True

# Generated at 2022-06-21 18:12:56.304077
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    t.tree_changed
    t.log
import astor

# make AST of a small expression


# Generated at 2022-06-21 18:13:02.184519
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit tests for StringTypesTransformer"""
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import transform_tree

    tree_before = source_to_tree('''
    x = str
    def bar(arg=str):
        return str
    ''')

    tree_after = source_to_tree('''
    x = unicode
    def bar(arg=unicode):
        return unicode
    ''')

    assert compare_trees(
        transform_tree(tree_before, [StringTypesTransformer]),
        tree_after,
        'Strings are converted to unicode properly.'
    )

# Generated at 2022-06-21 18:13:30.205704
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = """
    def test():
        return str()
    """
    tree = ast.parse(code)
    # When
    result = StringTypesTransformer.transform(tree)
    # Then
    assert result.tree != tree
    assert result.tree != None

# Generated at 2022-06-21 18:13:36.353091
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.Name("str",ast.Load())
    name1 = StringTypesTransformer.transform(x)
    assert name1.tree.id == "unicode"
    assert name1.tree_changed== True
    x = ast.Name("int",ast.Load())
    name1 = StringTypesTransformer.transform(x)
    assert name1.tree_changed == False

# Generated at 2022-06-21 18:13:38.231269
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("a = str(b)")).tree_changed
    assert StringTypesTransformer.transform(ast.parse("a = str(b)")).tree == ast.parse("a = unicode(b)")

# Generated at 2022-06-21 18:13:43.836958
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # See https://github.com/serge-sans-paille/python-modernize/issues/46
    code = 'if isinstance(s, bytes): u = s.decode()\nelse: u = s'
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert StringTypesTransformer.tree_changed
    assert ast.unparse(tree.tree) == 'if isinstance(s, bytes): u = s.decode()\nelse: u = unicode(s)'

# Generated at 2022-06-21 18:13:46.143331
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Constructor test. 

    """
    x = StringTypesTransformer()
    assert x is not None


# Generated at 2022-06-21 18:13:47.531402
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.required_version == (2, 7)

# Generated at 2022-06-21 18:13:53.882850
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(
        ast.parse("""\
foo = str()
bar = str(baz)
qux = str(quux, quuz)
""")) == \
        TransformationResult(ast.parse("""\
foo = unicode()
bar = unicode(baz)
qux = unicode(quux, quuz)
"""), True, [])

# Generated at 2022-06-21 18:13:59.232632
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str()')
    result = str(StringTypesTransformer.transform(tree))
    expected = """
Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])
""".strip()  # noqa: E501
    assert result == expected

# Generated at 2022-06-21 18:14:09.735159
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test StringTypesTransformer

    """
    # Test "str"
    input_code = """
    def hello(something):
        return str(something)
    """
    tree = ast.parse(input_code)
    tree_changed, new_code = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert new_code == """
    def hello(something):
        return unicode(something)
    """

    # Test "str"
    input_code = """
    def hello(something):
        return str(something)
    """
    tree = ast.parse(input_code)
    tree_changed, new_code = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert new_code == """
    def hello(something):
        return unicode(something)
    """

# Generated at 2022-06-21 18:14:10.247939
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:15:20.692174
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from typed_ast import ast3

    # Create AST
    node = ast3.Call(
        func=ast3.Name(id='int', ctx=ast3.Load()),
        args=[ast3.Call(
            func=ast3.Name(id='str', ctx=ast3.Load()),
            args=[],
            keywords=[])],
        starargs=None,
        kwargs=None)

    # Test
    tree_changed, error = StringTypesTransformer.transform(node)
    node = astor.to_source(node).rstrip()
    assert(node == "int(unicode())")
    assert(tree_changed)

# Generated at 2022-06-21 18:15:26.397362
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TEST 1
    sample_code: str = "str = 10\n"
    sample_ast = ast.parse(sample_code)
    StringTypesTransformer.transform(sample_ast)
    assert(ast.dump(sample_ast) == "Module(body=[Assign(targets=[Name(id='unicode', ctx=Store())], "
                                    "value=Num(n=10))])")



# Generated at 2022-06-21 18:15:27.913732
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:15:28.926283
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:15:39.667293
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    import os
    sys.path.append(os.getcwd())
    from transform.string_types import StringTypesTransformer
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import fix_missing_locations
    from typed_ast.ast3 import AST

    file_contents = """
    def my_test():
        s = str("test")
    """

    test_tree = parse(file_contents)
    test_tree = fix_missing_locations(test_tree)
    fix_missing_locations(test_tree)
    assert(isinstance(test_tree, AST))

    transformed_tree, changed, messages = StringTypesTransformer.transform(test_tree)
    assert(changed)

# Generated at 2022-06-21 18:15:46.183084
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'str(x)'
    expected_output = 'unicode(x)'
    tree = ast.parse(code, mode='exec')
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    output = ast.unparse(new_tree)
    assert output == expected_output


# Generated at 2022-06-21 18:15:47.069447
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TODO:
    pass

# Generated at 2022-06-21 18:15:48.560575
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.name == 'StringTypesTransformer'


# Generated at 2022-06-21 18:15:51.715912
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # arrange
    code = """def test():
        a = str()
    """
    expected = """def test():
        a = unicode()
    """
    tree = ast.parse(code)

    # act
    result = StringTypesTransformer.transform(tree)

    # assert
    result.tree_should_match(expected)

# Generated at 2022-06-21 18:15:57.762406
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert (
        StringTypesTransformer.transform(
            ast.parse(
                textwrap.dedent("""
                    def f():
                        return str()
                """)
            )
        )
        ==
        TransformationResult(
            tree=ast.parse(
                textwrap.dedent("""
                    def f():
                        return unicode()
                """)
            ),
            tree_changed=True,
            messages=[]
        )
    )