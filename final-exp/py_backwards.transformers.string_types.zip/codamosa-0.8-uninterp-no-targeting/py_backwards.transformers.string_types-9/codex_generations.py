

# Generated at 2022-06-21 18:08:01.493012
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.tree import find

    tree = ast.parse('if True: x = str(5)')
    StringTypesTransformer.transform(tree)

    # Type of x must be unicode
    x = find(tree, ast.Name, name='x')[0]
    print(dir(x))

    print(astor.to_source(tree))

# Generated at 2022-06-21 18:08:06.145708
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
        tree = ast.parse('a = str()')
        expected_tree = ast.parse('a = unicode()')

        assert ast.dump(StringTypesTransformer.construct().visit(tree), annotate_fields=False) == \
            ast.dump(expected_tree, annotate_fields=False)

# Generated at 2022-06-21 18:08:17.123704
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Set up AST we will be working on
    test_module = ast.parse('def foo(x): return str(x)')

    # We are testing a class which inherits from BaseTransformer, which in turn 
    # inherits from ast.NodeTransformer, so we will just use the constructor 
    # of the BaseTransformer class
    str_trans = StringTypesTransformer()

    # Run the transformations and get the resulting tree and tree_changed variables
    output_module, output_tree_changed = str_trans.transform(test_module)

    # What the code was after transformations (note the unicode)
    expected_code = 'def foo(x): return unicode(x)'

    # Was the tree changed after transformations?
    expected_tree_changed = True

    # Ensure that the AST is equal to what we expected
    assert expected_

# Generated at 2022-06-21 18:08:22.984124
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typedpy import String, Structure

    class A(Structure):
        b = String

    code = 'import typedpy\n\nclass A(typedpy.Structure):\n    b = str'
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True

# Generated at 2022-06-21 18:08:28.928845
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
        s = str()
        ''', '<test>', 'exec')
    new_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse('''
        s = unicode()
        ''', '<test>', 'exec'))


# Generated at 2022-06-21 18:08:32.767928
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'def foo(bar): return str(bar)'
    tree = ast.parse(code)
    tree1 = StringTypesTransformer.transform(tree)
    assert tree1.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-21 18:08:37.423695
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    tree = ast.parse("""
a = 2
print(a)
    """)
    # When
    result = StringTypesTransformer.transform(tree)
    # Then
    assert result.is_changed() == False

# Generated at 2022-06-21 18:08:41.078048
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name(id='str', ctx=ast.Load())
    tree = ast.parse('str')
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].value.id == 'unicode'

# Generated at 2022-06-21 18:08:45.143736
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .util import generate_equivalent_ast, assert_transformation_result
    import astunparse

    tree = ast.parse("""
x = str(1)
y = str()
z = str
""")

    transformed, _, _ = StringTypesTransformer.transform(tree)

    assert_transformation_result(transformed, tree, astunparse.unparse(transformed), """
x = unicode(1)
y = unicode()
z = unicode
""")

    assert generate_equivalent_ast(transformed)

# Generated at 2022-06-21 18:08:47.279886
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:08:58.047223
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
    def func(x):
        return str(x)
    '''

    try:
        result = StringTypesTransformer.transform(ast.parse(source))
    except Exception as e:
        assert(False)
        print(str(e))

    source = '''
    def func(x):
        return unicode(x)
    '''

    try:
        result = StringTypesTransformer.transform(ast.parse(source))
        assert(result.tree_changed == False)
    except Exception as e:
        assert(False)
        print(str(e))

    print("Test passed!")
test_StringTypesTransformer()

# Generated at 2022-06-21 18:09:04.181523
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
        from __future__ import unicode_literals
        def f(a):
            return str(a)
    '''
    tree = ast.parse(code)
    res, _ = StringTypesTransformer.transform(tree)
    assert res.body[1].body[0].value.func.id == 'unicode'



# Generated at 2022-06-21 18:09:05.469850
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..base import BaseNodeTransformer
    assert issubclass(StringTypesTransformer, BaseNodeTransformer)


# Generated at 2022-06-21 18:09:12.478739
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Setup
    tree = ast.parse("""
a = str("Hello World")
""")
    # Exercise
    StringTypesTransformer.transform(tree)
    
    # Verify
    assert ast.dump(tree) == """Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='Hello World')], keywords=[], starargs=None, kwargs=None))])
"""

# Generated at 2022-06-21 18:09:14.674647
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..tests.py2 import sample, expected
    from .. import transform

    assert str(transform(sample, [StringTypesTransformer])) == str(expected)

# Generated at 2022-06-21 18:09:16.013140
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Creating ast structure
    stringtypes = StringTypesTransformer()
    assert stringtypes is not None


# Generated at 2022-06-21 18:09:22.405621
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    node = ast.Name('str', ast.Load())
    # When
    result = StringTypesTransformer.transform(node)
    # Then
    assert isinstance(result, TransformationResult)
    assert isinstance(result.result[0], ast.Name)
    assert result.result[0].id == 'unicode'
    assert result.tree_changed == True



# Generated at 2022-06-21 18:09:31.991097
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    
    """
    test_cases = (
        # test_input, expected_result
        (ast.parse("print('hello world')"), True),
        (ast.parse("print('hello world'.encode('utf-8'))"), True),
        (ast.parse("print(u'hello world')"), False),
        (ast.parse("print(b'hello world')"), False),
        (ast.parse("print(1)"), False),
        (ast.parse("str(1)"), True),
        (ast.parse("type(1) is str"), True),
        (ast.parse("type(1) is unicode"), False),
        (ast.parse("type(1) is bytes"), False),
    )


# Generated at 2022-06-21 18:09:36.419685
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""def hello():
    a = str(1)
    b = "Hello"
    c = '''World'''
    return str(b + c)""")
    foo = tree.body[0].body
    print(foo[0])
    print(foo[1])
    print(foo[2])
    print(foo[3].value)

# Generated at 2022-06-21 18:09:44.611631
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils import parse

    module = parse("""
    x = str('abc')
    y = str(123)
    z = str(None)
    """)
    result = StringTypesTransformer.transform(module)
    src = to_src(result.tree)
    assert src == """
    x = unicode('abc')
    y = unicode(123)
    z = unicode(None)
    """, src

# Generated at 2022-06-21 18:09:57.033012
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
        unicode_var = unicode(5)
        str_var = str(5)
    """

    tree = ast.parse(src)
    StringTypesTransformer.transform(tree)
    new_src = astunparse.unparse(tree)
    assert new_src == """
        unicode_var = unicode(5)
        str_var = unicode(5)
    """

# Generated at 2022-06-21 18:10:03.906681
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    code = '''
    def x(s: str):
        return s
    '''
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.transformed

    for node in find(tree.node, ast.Name):
        if node.id == 'str':
            assert False
    assert True

    code = '''
    def x(s: str):
        return s
    '''
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.transformed

    for node in find(tree.node, ast.Name):
        if node.id == 'str':
            assert False
    assert True

# Generated at 2022-06-21 18:10:04.517105
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:10:09.133245
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code: str = 'def foo(some_str: str): pass\n'
    tree: ast.AST = ast.parse(code)
    # When
    transformed_code, tree_changed = StringTypesTransformer.transform(tree)
    # Then
    assert 'def foo(some_str: unicode): pass\n' == transformed_code

# Generated at 2022-06-21 18:10:16.620965
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
name = str(1)
"""
    expected = """
name = unicode(1)
"""

    tree = ast.parse(code)
    name = find(tree, ast.Name)
    
    actual = StringTypesTransformer.transform(tree)
    assert name == find(actual.tree, ast.Name)
    assert name[0].id == 'unicode'
    assert actual.changed
    
test_StringTypesTransformer()

# Generated at 2022-06-21 18:10:26.519287
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .builtins import BuiltinsTransformer
    from .fstrings import FStringsTransformer
    from .annotations import AnnotationsTransformer
    from .constants import ConstantsTransformer
    from .module import ModuleTransformer

    with open('testdata/transformer/StringTypesTransformer.py') as f:
        tree = ast.parse(f.read(), mode='exec')

    tree = ConstantsTransformer().transform(tree)
    tree = AnnotationsTransformer().transform(tree)
    tree = FStringsTransformer().transform(tree)
    tree = BuiltinsTransformer().transform(tree)
    tree = StringTypesTransformer().transform(tree)
    assert ModuleTransformer().transform(tree)

# Generated at 2022-06-21 18:10:33.428005
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import textwrap
    from ..utils.tree import find

    tree = ast.parse(textwrap.dedent('''
        def my_func(x):
            my_var = str(x)
            return my_var'''))

    assert len(find(tree, ast.Name)) == 5
    assert 'str' in (node.id for node in find(tree, ast.Name))

    res = StringTypesTransformer.transform(tree)

    assert 'str' not in (node.id for node in find(tree, ast.Name))
    assert 'unicode' in (node.id for node in find(tree, ast.Name))
    assert len(find(tree, ast.Name)) == 5


# Generated at 2022-06-21 18:10:36.756678
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""a = str('hello')""")
    t = StringTypesTransformer()
    t.transform(tree)
    print(ast.dump(tree))

# Generated at 2022-06-21 18:10:41.120175
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = 123 + str('a')")
    new_tree = StringTypesTransformer.transform(tree)
    assert new_tree.tree.body[0].value.right.args[0].id == 'unicode'
    assert new_tree.tree_changed == True

# Generated at 2022-06-21 18:10:48.117004
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .autotransformer import AutoTransformer
    from .imports import RemoveUnusedImportsTransformer
    from ..parser.parser import parse
    tree = parse('''
        from __future__ import unicode_literals

        x = str(x)
        y = 'y'
    ''')
    assert isinstance(RemoveUnusedImportsTransformer.transform(tree).tree, ast.Module)
    assert isinstance(StringTypesTransformer.transform(tree).tree, ast.Module)
    output = AutoTransformer.transform(tree, target=(2,7))
    assert isinstance(output, TransformationResult) and output.tree is not None and output.tree_changed
    assert output.problems == []
    assert get_source(output.tree) == "y = 'y'\nx = unicode(x)\n"

# Generated at 2022-06-21 18:11:03.436964
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    trans = StringTypesTransformer()
    assert(trans.target == (2, 7))

    tree = ast.parse("str(a)")
    new_tree, tree_changed, warnings = trans.transform(tree)

    assert(tree_changed)
    assert(len(new_tree.body) == 1)
    assert(isinstance(new_tree.body[0], ast.Expr))
    assert(isinstance(new_tree.body[0].value, ast.Call))
    assert(isinstance(new_tree.body[0].value.func, ast.Name))
    assert(new_tree.body[0].value.func.id == 'unicode')

# Generated at 2022-06-21 18:11:10.051126
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typing import Dict, List
    from typed_ast import ast3 as ast
    ast1 = ast.parse("def fun(x: str, y): pass")
    tree_changed, tree2, messages = StringTypesTransformer.transform(ast1)
    print(tree2)
    assert tree_changed
    assert len(messages) == 0
    assert ast.dump(ast1) == ast.dump(ast.parse("def fun(x: unicode, y): pass"))

# Generated at 2022-06-21 18:11:20.236936
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    from ..utils import dump_ast, run_transformer

    code = textwrap.dedent("""
    a = str("Hello")
    """)

    tree = ast.parse(code)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert (
        dump_ast(new_tree) ==
        "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], "
        "value=Call(func=Name(id='unicode', ctx=Load()), "
        "args=[Str(s='Hello')], keywords=[], starargs=None, kwargs=None))]"
        ")"
    )

# Generated at 2022-06-21 18:11:25.107627
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    import logging
    logging.basicConfig(level=logging.INFO)
    test_input = """
""".strip()
    expected_result = """
""".strip()
    test_input_ast = astor.code_to_ast.parse_string(test_input)
    transformer = StringTypesTransformer()
    actual_result = transformer.transform(test_input_ast)
    assert astor.to_source(actual_result) == expected_result

# Generated at 2022-06-21 18:11:33.499447
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """\
    def foo(x: str):
        x = str('Hello')
        x = 'Hello'
        x = 1
    """
    expected = """\
    def foo(x: unicode):
        x = unicode('Hello')
        x = 'Hello'
        x = 1
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.removed
    assert len(result.removed) == 0
    assert astor.to_source(result.tree) == expected


# Generated at 2022-06-21 18:11:36.736768
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_obj = StringTypesTransformer()
    assert class_obj.target == (2, 7)
    assert class_obj.python_version == (2, 7)



# Generated at 2022-06-21 18:11:39.216832
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = "a"')
    expected = ast.parse('x = u"a"')
    transformer = StringTypesTransformer.for_tree(tree)
    assert transformer.transform() == (expected, True, [])



# Generated at 2022-06-21 18:11:44.396054
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(
        """
        x = str('hello')
        """
    )
    assert StringTypesTransformer.transform(tree) == TransformationResult(
        ast.parse(
            """
        x = unicode('hello')
        """
        ),
        True,
        [],
    )

# Generated at 2022-06-21 18:11:49.267587
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str'))[0] == ast.parse('unicode')
    assert StringTypesTransformer.transform(ast.parse('str.__class__'))[0] == ast.parse('unicode.__class__')



# Generated at 2022-06-21 18:11:57.961935
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_tree1 = ast.parse("print 'hello world'")
    test_tree2 = ast.parse("while(True): print(str(3))")
    result1 = StringTypesTransformer.transform(test_tree1)
    result2 = StringTypesTransformer.transform(test_tree2)
    assert(result1.tree_changed == True)
    assert(result2.tree_changed == True)
    assert(str(result1.tree) == "Module(body=[Print(dest=None, values=[Str(s='hello world')], nl=True)])")

# Generated at 2022-06-21 18:12:12.157184
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    import sys
    from ..utils.testing import assert_source_equal


# Generated at 2022-06-21 18:12:21.395322
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert hasattr(StringTypesTransformer, 'transform')
    assert callable(StringTypesTransformer.transform)

    # test code:
    # x = str('hello') + ' ' + str('world')

# Generated at 2022-06-21 18:12:27.295637
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    x = ast.Name(id='str', ctx=ast.Load()) 
    tree = ast.Module(body=[x]) 
    transformed = ast.dump(StringTypesTransformer.transform(tree).tree)
    expected = ast.dump(ast.Module(body=[ast.Name(id='unicode', ctx=ast.Load())]))
    assert transformed == expected

# Generated at 2022-06-21 18:12:28.104767
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:12:36.232530
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import transform_code
    from ..utils.testing import compare_with_expected

    code = """
        from typing import Literal
        from datetime import datetime
    """
    # tree = ast.parse(code)
    # result = StringTypesTransformer.transform(tree)
    #
    # assert result.tree_changed == True
    # assert compare_with_expected( result.new_code, 'tests/expected/StringTypesTransformer/tree_changed.txt')
    #
    # code = """
    #     import abc
    # """
    # tree = ast.parse(code)
    # result = StringTypesTransformer.transform(tree)
    #
    # assert result.tree_changed == False
    # assert compare_with_expected( result.new_code, 'tests/expected/StringTypes

# Generated at 2022-06-21 18:12:38.443313
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert(string_types_transformer.transform(ast.parse('a = str')).new_tree.body == [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], 
                                                                                                value=ast.Name(id='unicode', ctx=ast.Load()))])

# Generated at 2022-06-21 18:12:39.774120
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer() is not None

# Generated at 2022-06-21 18:12:47.423570
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    (tree, resources) = StringTypesTransformer.transform(parse('''\
if (isinstance(x, str)):
    assert(type(x) is str)
'''))

    assert(str(tree) == '''\
if (isinstance(x, unicode)) {
    assert(((type(x) === unicode)));
}
'''.lstrip())
    # The function isinstance is not present in Python 2, so it is replaced by the function
    # type. Hence, this function is added as resource.
    assert(resources == ['type'])

# Generated at 2022-06-21 18:12:53.916713
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import test_utils
    in_file = test_utils.file_from_template("StringTypesTransformer.py")
    expected_out_file = test_utils.file_from_template("StringTypesTransformer_output.py")
    tree = test_utils.parse_file(in_file)
    transformed = StringTypesTransformer.transform(tree)
    assert expected_out_file == test_utils.dump_tree(transformed.tree)

# Generated at 2022-06-21 18:12:55.436057
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer is not None

# Generated at 2022-06-21 18:13:20.011403
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:13:29.860843
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from transform.string_types import StringTypesTransformer

    tree = ast.parse('a = str(b)')
    trans = StringTypesTransformer()
    res = trans.transform(tree)
    assert isinstance(res.tree, ast.Module)
    assert len(res.warnings) == 0
    assert res.tree_changed
    assert ast.dump(res.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='b', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-21 18:13:30.425403
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:13:36.166673
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    module = ast.parse('def x(y: str): pass')
    tree = StringTypesTransformer.transform(module)
    assert tree.tree_changed == True
    #assert ast.dump(tree.tree, include_attributes=False) == ast.dump(ast.parse('def x(y: unicode): pass'), include_attributes=False)

# Generated at 2022-06-21 18:13:41.033289
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    type = str
    """

    tree = ast.parse(code)
    changed, _ = StringTypesTransformer.transform(tree)

    # Make sure it was actually changed
    assert(changed)

    # Make sure the tree is equal to what we'd expect
    assert(ast.dump(tree) == ast.dump(ast.parse("""
    type = unicode
    """)))



# Generated at 2022-06-21 18:13:42.249894
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from . import MockFileLoader
    import typed_ast.ast3 as ast


# Generated at 2022-06-21 18:13:48.264866
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_string = '''
    a = str()
    b = str(1)
    c = str.__new__(str)
    def test(self):
        d = str
        return str(1)
    '''
    test_tree = ast.parse(test_string)
    expected_output = '''
    a = unicode()
    b = unicode(1)
    c = unicode.__new__(unicode)
    def test(self):
        d = unicode
        return unicode(1)
    '''
    expected_tree = ast.parse(expected_output)
    result_tree, tree_changed, _ = StringTypesTransformer.transform(test_tree)
    assert ast.dump(result_tree) == ast.dump(expected_tree)
    assert tree_changed == True

# Generated at 2022-06-21 18:13:53.740260
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""\
a = str(x)
""")
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse("""\
a = unicode(x)
"""))

# Generated at 2022-06-21 18:13:55.154092
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert isinstance(StringTypesTransformer(), StringTypesTransformer)

# Generated at 2022-06-21 18:13:57.817192
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('type(x) is str')
    assert type(StringTypesTransformer.transform(tree)) is TransformationResult
    assert pretty(tree) == 'type(x) is unicode'

# Generated at 2022-06-21 18:15:06.776271
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTransformerTest

    class TestStringTypesTransformer(BaseTransformerTest):

        transform = StringTypesTransformer
        target_version = (2, 7)

        def test_str_1(self):
            code = "print(str('Hello'))"
            expected_code = "print(unicode('Hello'))"

            self.assertTransformedAST(code, expected_code)

        def test_str_2(self):
            code = "print(type(str(1)))"
            expected_code = "print(type(unicode(1)))"

            self.assertTransformedAST(code, expected_code)


# Generated at 2022-06-21 18:15:09.194708
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:15:22.379281
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Source code
    src = (
        'import six\n'
        'def f(s: str):\n'
        '    print(s)\n'
        'f("abc")'
    )

    # Expected results
    expected_out = (
        'import six\n'
        'def f(s: unicode):\n'
        '    print(s)\n'
        'f("abc")'
    )

    # Perform test
    tree = ast.parse(src)
    out, tree_changed, metadata = StringTypesTransformer.transform(tree)
    actual_out = compile(out, '<string>', 'exec')

    assert expected_out == actual_out
    assert tree_changed == True
    assert metadata == []

# Generated at 2022-06-21 18:15:33.184596
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    import astunparse
    import textwrap

    source = textwrap.dedent('''\
    class Foo(object):
        def __init__(self, value):
            self.value = value
            self.unicode = str

        def __repr__(self):
            return "Foo(%r)" % self.value

    ''')
    expect = textwrap.dedent('''\
    class Foo(object):
        def __init__(self, value):
            self.value = value
            self.unicode = unicode

        def __repr__(self):
            return "Foo(%r)" % self.value

    ''')

    tree = ast.parse(source)
    tree = StringTypesTransformer.run_pipeline(tree)

# Generated at 2022-06-21 18:15:40.988692
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # This is an example in which StringTypesTransformer will be applied
    tree = ast.parse('''x = "abcd"''')
    expected_tree = ast.parse('''x = unicode("abcd")''')
    assert StringTypesTransformer.transform(tree) == (expected_tree, True)


    # This is an example in which StringTypesTransformer will not be applied
    tree = ast.parse('''x = 42''')
    expected_tree = ast.parse('''x = 42''')
    assert StringTypesTransformer.transform(tree) == (expected_tree, False)

# Generated at 2022-06-21 18:15:50.845292
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Case: class declaration
    code = """class TestClass(object):
    def __init__(self):
        self.value = str(10)
"""
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    print(code)
    print(astor.to_source(result.tree))
    exec(compile(result.tree, filename="<ast>", mode="exec"))
    assert TestClass().value == u'10'

    # Case: if statement
    code = """if type(value) == str:
    print(value)
"""
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    print(code)
    print(astor.to_source(result.tree))

# Generated at 2022-06-21 18:16:00.292204
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print('Testing StringTypesTransformer class...')
    tree = ast.parse('"abc" + str(123)')
    print(ast.dump(tree))
    StringTypesTransformer.transform(tree)
    print(ast.dump(tree))
    tree = ast.parse('unicode("abc")')
    print(ast.dump(tree))
    StringTypesTransformer.transform(tree)
    print(ast.dump(tree))
    tree = ast.parse('str("abc")')
    print(ast.dump(tree))
    StringTypesTransformer.transform(tree)
    print(ast.dump(tree))
    print('Done!')

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:16:01.175018
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(None) is not None

# Generated at 2022-06-21 18:16:04.553868
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    t1 = ast.parse("x = str('hello')")
    assert StringTypesTransformer.transform(t1).tree_changed == True

    # Test 2
    t2 = ast.parse("x = []")
    assert StringTypesTransformer.transform(t2).tree_changed == False

# Generated at 2022-06-21 18:16:05.533084
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("a = str()"))