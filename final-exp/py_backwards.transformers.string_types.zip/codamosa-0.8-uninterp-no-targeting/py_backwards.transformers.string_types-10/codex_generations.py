

# Generated at 2022-06-21 18:08:05.913782
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program_code = """
result = str(variable)"""
    expected_code = """
result = unicode(variable)"""
    expected_warnings = []
    tree = ast.parse(program_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_transformed == expected_code
    assert result.warnings == expected_warnings

# Generated at 2022-06-21 18:08:06.589395
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert(True)

# Generated at 2022-06-21 18:08:13.398634
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pyast = ast.parse("""
        def foo():
            if isinstance('foo', str):
                pass
    """)
    expected_ast = ast.parse("""
        def foo():
            if isinstance('foo', unicode):
                pass
    """)
    pyast_expected = StringTypesTransformer.transform(pyast)
    assert pyast_expected.tree == expected_ast
    assert pyast_expected.tree_changed is True

# Test generator for StringTypesTransformer

# Generated at 2022-06-21 18:08:17.333625
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    expression = """a = str(b)"""
    expected = """a = unicode(b)"""

    tree = ast.parse(expression)
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-21 18:08:23.141094
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert_equal(
        StringTypesTransformer.transform(
            ast.parse('import os\nos.path.join("a", "b")')
        )
        ,
        TransformationResult(
            ast.parse('import os\nos.path.join(u"a", u"b")'),
            True,
            []
        )
    )

# Generated at 2022-06-21 18:08:35.431069
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import run_transformer, compare_asts

    expected = """
a = unicode(b)
c = unicode()
d = unicode(1, 2, 3, e)
f = unicode(1, 2, 3, **e)
g = unicode(1, 2, 3, *e)
h = unicode(1, 2, 3, *e, **e)
    """

    tree = """
a = str(b)
c = str()
d = str(1, 2, 3, e)
f = str(1, 2, 3, **e)
g = str(1, 2, 3, *e)
h = str(1, 2, 3, *e, **e)
    """


# Generated at 2022-06-21 18:08:47.081041
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ...testing import assert_transform


# Generated at 2022-06-21 18:08:48.728971
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(None) == TransformationResult(None, False, None)

# Generated at 2022-06-21 18:08:59.086338
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from typed_ast import ast3 as ast

    # Testing AST node that uses str as a variable name
    tree = ast.Module([ast.Import([ast.alias('str', None)]), ast.Expr(ast.Name('str', ast.Load()))])
    assert astor.to_source(tree) == "import str\nstr\n"

    # Test that the AST node is transformed
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert astor.to_source(result.new_tree) == "import unicode\nunicode\n"

    # Test that the AST node is not transformed if the variable name is unicode

# Generated at 2022-06-21 18:09:10.255315
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:09:18.992302
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    assert_transformed(StringTypesTransformer, 'unicode', 'str')
    assert_transformed(StringTypesTransformer, '"abc"', "'abc'")
    assert_transformed(StringTypesTransformer, '"""a\nbc"""', "'''a\nbc'''")
    assert_transformed(StringTypesTransformer, "'\\\\'", '"\\\\"')
    assert_transformed(StringTypesTransformer, '"""a"""', "'''a'''")

# Generated at 2022-06-21 18:09:26.020941
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t1 = ast.Str('Test')
    t1.__class__ = ast.Name  # HACK
    t1.id = 'str'
    
    t2 = ast.Name('unicode', ast.Load())
    
    t = ast.BoolOp(ast.And(), [t1, t2])
    tree = ast.Module(body=[t])
    
    result = StringTypesTransformer.transform(tree)
    
    assert result.tree == ast.Module(body=[t2])

# Generated at 2022-06-21 18:09:36.386518
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  import ast
  import sys
  import typed_ast.ast3 as typed_ast
  from typed_ast import ast3 as ast
  from pprint import pprint

  print(StringTypesTransformer.transform(typed_ast.parse("str('')", mode='exec')))

  print(StringTypesTransformer.transform(typed_ast.parse("def test(string: str): pass", mode='exec')))

  print(StringTypesTransformer.transform(typed_ast.parse("s = 'abc'", mode='exec')))
  
  print(StringTypesTransformer.transform(typed_ast.parse("a = b + 'abc'", mode='exec')))
  
  print(StringTypesTransformer.transform(typed_ast.parse("if isinstance(a, str): pass", mode='exec')))
  
 

# Generated at 2022-06-21 18:09:48.348663
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import json
    from ..main import transform_tree
    from ..utils.tree import convert_to_str

    test_str = """
        class Test:
            def __init__(self):
                self.a = str()
                self.b = str(self.a)
                self.c = str(u'a')
                self.d = str('a')
                self.e = str(1)
            def test_str_call(self):
                self.a = str()
                self.b = str(self.a)
                self.c = str(u'a')
                self.d = str('a')
                self.e = str(1)
    """

# Generated at 2022-06-21 18:09:54.502119
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast_tree = ast.parse("def test_func(a): return str('abc') + 'abc'")
    # str replaced by unicode
    expected_tree = ast.parse("def test_func(a): return unicode('abc') + 'abc'")

    actual_tree, tree_changed, messages = StringTypesTransformer.transform(
        ast_tree)

    actual_code = ast.fix_missing_locations(actual_tree)
    expected_code = ast.fix_missing_locations(expected_tree)

    assert ast.dump(actual_code) == ast.dump(expected_code)

# Generated at 2022-06-21 18:09:57.227002
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("Testing StringTypesTransformer...")
    assert StringTypesTransformer().__class__.__name__ == "StringTypesTransformer"
    print("PASSED")


# Generated at 2022-06-21 18:10:03.370388
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import parse_code
    from ..utils.tree import ast2str
    tree = parse_code('a = str(123)')
    transformator = StringTypesTransformer()
    new_tree = transformator.transform(tree)
    assert ast2str(new_tree.tree) == 'a = unicode(123)'

# Generated at 2022-06-21 18:10:09.837126
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input = """
from builtins import str

x = 'foo'

if str(x) == 'bar':
    print('foo')
"""
    tree = ast.parse(input, 'file.py')
    result = StringTypesTransformer.transform(tree)

    expected = """
from builtins import unicode

x = 'foo'

if unicode(x) == 'bar':
    print('foo')
"""
    assert ast.dump(result.tree) == expected

# Generated at 2022-06-21 18:10:11.946006
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def check(source: str, expected: str):
        tree = ast.parse(source)
        assert str(tree) == expected

    source = 'print(str(3))'
    expected = 'print(unicode(3))'
    check(source, expected)

test_StringTypesTransformer()

# Generated at 2022-06-21 18:10:17.538199
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    # Test tree
    test_tree = ast.Str('String')

    # Expected tree
    expected_tree = ast.Str('String')
    expected_tree.id = 'unicode'

    result = StringTypesTransformer.transform(test_tree)

    assert result.tree == expected_tree

# Generated at 2022-06-21 18:10:30.216350
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    code = 'str(123)'
    tree = ast.parse(code)
    new_tree, tree_changed, errors = string_types_transformer.transform(tree)
    assert False is tree_changed
    assert new_tree is tree
    assert [] == errors

    code = 'str'
    tree = ast.parse(code)
    new_tree, tree_changed, errors = string_types_transformer.transform(tree)
    assert True is tree_changed
    assert new_tree is not tree
    assert [] == errors
    assert ast.dump(new_tree) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"

# Generated at 2022-06-21 18:10:42.143154
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import sys
    from typed_ast import ast3
    from typed_ast import codetransformer
    # Build AST from source code
    ast_tree = ast.parse('param = str()')
    # Run typed AST transformers
    tree = codetransformer.CodeTransformer().visit(ast_tree)
    # Run custom transformers
    result = StringTypesTransformer.transform(tree)
    # Check nodes
    call = ast.Call(func = ast.Name(id='unicode', ctx=ast.Load()), args=[], keywords=[], starargs=None, kwargs=None)
    assert(bool(result.tree.body[0].value == call))
    # Check number of statements
    assert(result.number_of_statements == 0)
    # Check changes

# Generated at 2022-06-21 18:10:49.091240
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        x = str(name)
        y = y + str(name)
        y = str(name) + y
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    #print(ast.dump(tree))

    assert 'unicode' in ast.dump(tree)
    assert 'str' not in ast.dump(tree)
    
    
if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:11:00.617570
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # n.b.
    #    Tester module version:
    #    - astor==0.7.1
    #    - typed-ast==1.4
    #    - asttokens==2.0.3
    t = StringTypesTransformer()

    # Test a simple case, 
    # 
    # <Input>
    # test = True
    # if test:
    #     print('hello')
    #
    # <Expected Output>
    # test = True
    # if test:
    #     print('hello')
    test_case = """test = True\nif test:\n    print('hello')"""
    tree = ast.parse(test_case)
    transformed_tree, tree_changed, code_lines_removed = t.transform(tree)
    assert tree_changed == False

# Generated at 2022-06-21 18:11:09.531769
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils import load_example_code
    from .base import BaseTestCase

    code = load_example_code('str_types.py')
    init_tree = astor.code_to_ast.parse_string(code)

    class TestStringTypesTransformer(BaseTestCase):
        target = (2, 7)
        transformer = StringTypesTransformer
        target_code = 'unicode'

        def test_transformation(self):
            self.assertTransformSucceeded(self.transformer)
            self.assertTreeChanged(self.transformer)

    TestStringTypesTransformer.run_test()

# Generated at 2022-06-21 18:11:11.316230
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast


# Generated at 2022-06-21 18:11:19.897317
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = """
    def some_func(x: str):
        print("To be or not to be")
    """
    t = ast.parse(s)
    transformer = StringTypesTransformer()
    t_new = transformer.visit(t)
    assert t_new is not t
    assert transformer.tree_changed
    assert transformer.has_errors() is False
    assert t_new.body[0].args[0].annotation.id == 'unicode'
    assert t_new.body[0].body[0].value.s == 'To be or not to be'

# Generated at 2022-06-21 18:11:23.776920
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''def test_string_types():
        return str("test")'''
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    exec(compile(tree, "<ast>", "exec"))
    assert test_string_types() == "test"

# Generated at 2022-06-21 18:11:25.222437
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:11:35.938515
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # All the tests here are for the source code of transform and
    # for the target_ast.
    # No tests are needed for the rest of the class.

    # Test target_ast
    target_ast = ast.parse(
        """str_object = "This is a string."
            
           str_object
        """
    )
    expected_target_ast = ast.parse(
        """unicode_object = "This is a string."
            
           unicode_object
        """
    )
    tree_changed, target_ast = (
        StringTypesTransformer.transform(target_ast).target_ast
    )
    assert tree_changed
    assert ast.dump(target_ast) == ast.dump(expected_target_ast)

# Generated at 2022-06-21 18:11:51.673439
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import sys

    code = r'''
    from __future__ import print_function
    x = str(1)
    print(x)
    '''

    # Parse code into an AST
    module_ast = ast.parse(code)

    # Output the code represented by the AST
    #print(ast.dump(module_ast))

    # Visit the AST and rewrite the code
    StringTypesTransformer.transform(module_ast)
    compiled_code = compile(module_ast, "<string>", "exec")
    exec(compiled_code)
    #print(ast.dump(module_ast))



# Generated at 2022-06-21 18:11:55.792879
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_tree = ast.parse("""a = str('a')""")
    expected_tree = ast.parse("""a = unicode('a')""")

    transformed_tree, tree_changed = StringTypesTransformer.transform(code_tree)

    assert tree_changed
    assert ast.dump(transformed_tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 18:12:04.910542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    #Valid input
    input_str = '''
        string = str()
        another_string = str(string)
    '''

    #Expected output
    output_str = '''
        string = unicode()
        another_string = unicode(string)
    '''

    #Run the test!
    transformer = StringTypesTransformer(None)
    transformer.old_tree = ast.parse(input_str)
    transformer.new_tree = ast.parse(input_str)
    transformer.transform()

    assert ast.dump(transformer.new_tree) == ast.dump(ast.parse(output_str))

# Generated at 2022-06-21 18:12:07.723953
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:12:08.866309
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:12:12.314670
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = str(b)")
    tt = StringTypesTransformer()
    new_tree = tt.visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse("a = unicode(b)"))
    assert tt.tree_changed == True

# Generated at 2022-06-21 18:12:14.849512
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    """
    tree = ast.parse('str')
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].value.s == 'unicode'

# Generated at 2022-06-21 18:12:25.810046
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    item = ast.Name(id="str", ctx=None)
    assert isinstance(item, ast.Name)
    assert item.id == "str"
    # we cannot access item.ctx from here, it is a feature of typed_ast

    # create a module, an alias and a function node
    mod = ast.Module()
    alias = ast.alias(name="unicode", asname=None)
    alias2 = ast.alias(name="str", asname=None)
    funcdef = ast.FunctionDef(
        name="foo",
        args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]),
        body=[ast.Return(value=item)],
        decorator_list=[],
        returns=None
    )
    # add the function node to the module node


# Generated at 2022-06-21 18:12:35.039090
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test if the string types are correctly transformed.
    """
    code = """
    def a_function(argument1):
        text = 'Hello, ' + str(argument1)
        return text
    """
    transformed = StringTypesTransformer.transform(ast.parse(code))
    module = transformed.tree
    assert type(module) == ast.Module
    assert transformed.tree_changed
    
    a_function = module.body[0]
    assert type(a_function) == ast.FunctionDef
    assert a_function.name == 'a_function'

    text = a_function.body[0]
    assert type(text) == ast.Assign
    assert type(text.targets[0]) == ast.Name

    plus_str = text.value
    assert type(plus_str) == ast.Bin

# Generated at 2022-06-21 18:12:41.962770
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.get_name() == "StringTypesTransformer"
    sample = StringTypesTransformer.transform('a = str("a")').tree
    assert sample.body[0].value.args[0].s == u'a'
    assert type(sample.body[0].value.args[0].s) is unicode


# Generated at 2022-06-21 18:12:59.121986
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
str_thing = 'I am a str'
str_thing.decode()
"""

    transpiled_code = """
str_thing = u'I am a str'
str_thing.decode()
"""

    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed == True
    assert result.errors == []

# Generated at 2022-06-21 18:13:03.643783
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
a = str('a')
"""
    tree = ast.parse(source)
    new_tree, has_changed, _ = StringTypesTransformer.transform(tree)
    assert has_changed
    codeobj = compile(new_tree, '<test>', 'exec')
    assert codeobj
    ns = {}
    exec(codeobj, ns)

    assert ns['a'] == u'a'

# Generated at 2022-06-21 18:13:09.718322
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    import sys

    code = ast3.parse("""
# Python 3.4's implementation of print is actually "print", so it doesn't need to be changed.
print(type(str('hi')))
    """)

    test = StringTypesTransformer(sys.version_info)
    test.transform(code)
    print(ast3.dump(code))


# Generated at 2022-06-21 18:13:16.299582
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import refactor
    from ..models import SourceFileContent
    from ..refactor import RefactoringError

    # For example, the code
    # "hello" == str()
    # is changed to
    # "hello" == unicode()
    tree = ast.parse("hello == str()")
    t = StringTypesTransformer()
    t.transform(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=Compare(left=Str(s='hello'), ops=[Eq()], comparators=[Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None)]))])"

    # For example, the code
    # True = bool is str
    # is changed to
    # True = bool is unicode
    tree

# Generated at 2022-06-21 18:13:28.225502
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test1
    tree1 = ast.parse('"ABC"')
    result1 = StringTypesTransformer.transform(tree1)
    assert(not result1.tree_changed)
    assert(result1.warnings == [])
    assert(result1.tree == tree1)

    # test2
    tree2 = ast.parse('abc')
    result2 = StringTypesTransformer.transform(tree2)
    assert(not result2.tree_changed)
    assert(result2.warnings == [])
    assert(result2.tree == tree2)

    # test3
    tree3 = ast.parse('str(123)')
    result3 = StringTypesTransformer.transform(tree3)
    assert(result3.tree_changed)
    assert(result3.warnings == [])

# Generated at 2022-06-21 18:13:35.344652
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3

    t = StringTypesTransformer()

    tree = typed_ast.ast3.parse("print(str('hello'))")
    t.transform(tree)

    expected_tree = typed_ast.ast3.parse("print(unicode('hello'))")

    assert typed_ast.ast3.dump(tree) == typed_ast.ast3.dump(expected_tree)

# Generated at 2022-06-21 18:13:36.305914
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TODO: implement the test here
    pass

# Generated at 2022-06-21 18:13:40.455452
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = StringTypesTransformer()
    assert tt.target == (2, 7)
    assert isinstance(tt, BaseTransformer) == True
    assert tt.__class__.__name__ == 'StringTypesTransformer'
    assert tt.__class__.transform.__name__ == 'transform'



# Generated at 2022-06-21 18:13:44.407428
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.snippet import to_module

# Generated at 2022-06-21 18:13:56.060680
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:28.943674
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open('tests/sample/string.py') as f:
        sample = f.read()

    tree = ast.parse(sample)
    res = StringTypesTransformer.transform(tree)
    assert res.tree_changed

# Generated at 2022-06-21 18:14:30.174299
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    StringTypesTransformer.transform(ast.parse('"text"', mode='exec'))

# Generated at 2022-06-21 18:14:36.460242
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast as pyast
    # TODO: fix test
    tree = pyast.parse('str(1)')
    transformer = StringTypesTransformer()
    tree, changed = transformer.visit(tree)
    assert changed
    assert(isinstance(tree, pyast.AST))
    assert(isinstance(tree.body[0].value, pyast.Call))
    assert(tree.body[0].value.args[0].n == 1)
    assert(isinstance(tree.body[0].value.func, pyast.Name))
    assert(tree.body[0].value.func.id == 'unicode')

# Generated at 2022-06-21 18:14:39.216750
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse("str(1)")
    t = StringTypesTransformer.transform(t).tree
    assert t == ast.parse("unicode(1)")



# Generated at 2022-06-21 18:14:41.654965
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test the constructor of class StringTypesTransformer.
    """
    obj = StringTypesTransformer(None)
    assert obj.target == (2, 7)


# Generated at 2022-06-21 18:14:44.697700
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    test_ast, tree_changed = StringTypesTransformer.transform(ast.parse('test = str(test)'))
    assert tree_changed == True
    assert astor.to_source(test_ast).strip() == "test = unicode(test)"

# Generated at 2022-06-21 18:14:46.813603
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """str"""
    expected = """unicode"""
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.run(tree)
    assert astor.to_source(new_tree).rstrip() == expected

# Generated at 2022-06-21 18:14:48.375364
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:56.274023
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
x = str()
y = str(1)
z = str.join(', ', ['hardcoded', 'strings'])
""")
    stt = StringTypesTransformer()
    transformed_tree = stt.transform(tree)
    assert transformed_tree._changed == True
    assert ast.dump(transformed_tree._tree) == ast.dump(ast.parse("""
x = unicode()
y = unicode(1)
z = unicode.join(', ', ['hardcoded', 'strings'])
"""))

# Generated at 2022-06-21 18:15:04.887529
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = str(y)')
    assert StringTypesTransformer.transform(tree).tree_changed is True
    print(ast.dump(tree))
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='y', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:16:02.841680
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    # Constructor test
    t = StringTypesTransformer()
    assert isi

# Generated at 2022-06-21 18:16:09.269994
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from comtype.utils.tree import node_to_str, str_to_node
    from comtype.utils.tree_equal import assert_tree_equal

    tree = str_to_node('''
    (Module (FunctionDef (Name (id foo)) (arguments (arg (arg a))) 
    (body (str (str (str (str (str (str (str (str (str (str (str (str (str (str (str (str (str (str (str a))))))))))))))))))))
    ''')


# Generated at 2022-06-21 18:16:20.127639
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import os.path
    import astunparse
    example = os.path.abspath(__file__)
    example = os.path.dirname(example)
    example = os.path.join(example, '..', 'examples', 'for.py')
    with open(example, 'rt') as f:
        example = f.read()

    tree = ast.parse(example)
    trans = StringTypesTransformer.transform(tree)
    transformed = astunparse.unparse(trans.tree)

    expected = """def f():
    for i in xrange(0, 10):
        if i % 2:
          print i
        elif i > 5:
            print i
        else:
            print "hi"
            # print "bye"
    print "done"
"""

    assert transformed == expected

# Generated at 2022-06-21 18:16:24.013898
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..transformers.transformers import StringTypesTransformer

    tree = ast.parse(
        "def foo(x):\n\treturn str(x)"
    )

    StringTypesTransformer.match(tree)
    StringTypesTransformer.transform(tree)

    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])"

#

# Generated at 2022-06-21 18:16:27.516030
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    b = StringTypesTransformer
    tree = ast.parse("a = str('b')")
    b.transform(tree)
    expected = ast.parse("a = unicode('b')")
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:16:31.952726
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str')).tree_str == 'unicode'
    assert StringTypesTransformer.transform(ast.parse('str().split()')).tree_str == 'unicode().split()'
    assert StringTypesTransformer.transform(ast.parse('name = str; name = name;')).tree_str == 'name = unicode; name = name;'

# Generated at 2022-06-21 18:16:33.464240
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """

# Generated at 2022-06-21 18:16:40.971543
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """\
r = str(10)
"""
    tree = ast.parse(source)
    result = list(StringTypesTransformer.transform(tree))
    assert len(result) == 1
    assert result[0].tree != tree
    expected_source = """\
r = unicode(10)
"""
    assert ast.dump(result[0].tree) == ast.dump(ast.parse(expected_source))


if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:16:49.012818
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Note:
        This test will not pass because node.id = 'unicode' is 
        not supported by typed_ast
    """
    string_types_transformer = StringTypesTransformer()

    code = """str = 'hello world'"""
    tree = ast.parse(code)
    tree_changed, new_tree = string_types_transformer.transform(tree)
    assert tree_changed == True
    assert ast.dump(new_tree) == "Module(body=[Assign(targets=[Name(id='unicode', ctx=Store())], value=Str(s='hello world'))])"

# Generated at 2022-06-21 18:16:52.423944
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('s = "hello"')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
