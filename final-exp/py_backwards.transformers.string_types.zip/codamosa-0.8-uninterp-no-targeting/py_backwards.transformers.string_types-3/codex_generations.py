

# Generated at 2022-06-21 18:08:03.570349
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform_file('./tests/samples/str_types.py')[1] == True

# Generated at 2022-06-21 18:08:14.799789
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    import astor
    from pprint import pprint
    from ..utils.tree import node_name

    class A(object): 
        def f1(self):
            return str("")
    
    class B(object): 
        def f2(self):
            return str("", "", sep="")

    class C(object): 
        def f3(self):
            return str("", "", "", sep="")

    class D(object): 
        def f4(self):
            return str("", "", "", "", sep="")

    a = A()
    b = B()
    c = C()
    d = D()

    ast_a = ast.parse(inspect.getsource(a.f1))

# Generated at 2022-06-21 18:08:20.939678
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """"""
    expected = """"""
    tree = ast.parse(code)
    result, modif = StringTypesTransformer.transform(tree)
    print(astunparse.unparse(result))
    assert astunparse.unparse(result) == expected

# Generated at 2022-06-21 18:08:25.456120
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .transformers.base import test_transformer
    transformer = StringTypesTransformer()
    test_transformer(transformer,
        '''
        a = str("abc")
        ''',
        '''
        a = unicode("abc")
        ''',
    )

# Generated at 2022-06-21 18:08:38.139144
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('print(str(3))')
    transformer = StringTypesTransformer()
    output = transformer.transform(tree)
    assert output.tree_changed
    assert isinstance(output.tree, ast.Module)
    assert isinstance(output.tree.body[0], ast.Expr)
    assert isinstance(output.tree.body[0].value, ast.Call)
    assert isinstance(output.tree.body[0].value.func, ast.Name)
    assert output.tree.body[0].value.func.id == 'print'
    assert isinstance(output.tree.body[0].value.args[0], ast.Call)
    assert isinstance(output.tree.body[0].value.args[0].func, ast.Name)

# Generated at 2022-06-21 18:08:41.162212
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import parse

    tree = parse("""foo = str(bar)""")
    tree = StringTypesTransformer.transform(tree)
    assert tree.changed is True
    assert tree.code == """foo = unicode(bar)"""

# Generated at 2022-06-21 18:08:50.331239
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import compile_ast, transform_source

    source = """
    s = str(42)
    print(s)
    y = unicode("asdf")
    print(y)
    """

    tree = compile_ast(source)
    ntree, changed, messages = transform_source(source, [StringTypesTransformer], target=(2, 7))

    assert changed
    assert messages == []

    expected_source = """
    s = unicode(42)
    print(s)
    y = unicode("asdf")
    print(y)
    """

    assert str(ntree) == expected_source

# Generated at 2022-06-21 18:08:56.633976
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import Source
    from ..utils import load_ipython_extension
    from ..utils.target import Target
    from ..transformer.string_types import StringTypesTransformer
    # Fixture to test loading of extension
    target = Target(('2', '7'))
    source = Source('def test() -> str: return "string"')
    tree = source.tree
    load_ipython_extension(target)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed == True

# Generated at 2022-06-21 18:09:02.892062
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    from __future__ import unicode_literals
    s = str(10)
    s = unicode(10)
    """
    expected_code = """
    from __future__ import unicode_literals
    s = unicode(10)
    s = unicode(10)
    """
    tt = transformer_class.transform_string(code)
    assert tt == expected_code

# Generated at 2022-06-21 18:09:05.188402
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  """Unit test for constructor of class StringTypesTransformer.

  """
  # Define code to transform

# Generated at 2022-06-21 18:09:11.106718
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import _ast3 as ast3
    tree = ast3.parse('assert len(str(x)) == 0')
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].test.left.args[0].id == 'unicode'
    assert result.tree_changed == True

# Generated at 2022-06-21 18:09:19.525420
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class A:
        def __init__():
            pass
    class B:
        def __init__(self):
            pass
    class C(object):
        def __init__(self):
            pass
    class D(object):
        def __init__(self, a):
            self.a = a
    class E:
        def __init__(self, a, b):
            self.a = a
            self.b = b
    class F(object):
        def __init__(self, a, b=5):
            self.a = a
            self.b = b
    class G(object):
        def __init__(self, a, b, c=5):
            self.a = a
            self.b = b
            self.c = c

# Generated at 2022-06-21 18:09:25.560468
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    target_code = """
        x = 2
        y = str('Hello')
        """
    expected_code = """
        x = 2
        y = unicode('Hello')
        """
    print(expected_code)
    print('---------------')
    transformed_code = StringTypesTransformer.transform_code(target_code)
    print(transformed_code)
    assert expected_code in transformed_code



# Generated at 2022-06-21 18:09:30.740760
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def test(a: str):
        print("str")
    """

    result = StringTypesTransformer().transform_source(code)
    assert result.code == """
    def test(a: unicode):
        print("str")
    """
    assert result.tree_changed is True

# Generated at 2022-06-21 18:09:37.318990
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    a = ast.parse('a = myClass(str, 12)')
    node = StringTypesTransformer.transform(a)
    assert(ast.dump(a) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Call(func=Name(id="myClass", ctx=Load()), args=[Call(func=Name(id="unicode", ctx=Load()), args=[Str(s=str)], keywords=[], starargs=None, kwargs=None), Num(n=12)], keywords=[], starargs=None, kwargs=None))])')

# Generated at 2022-06-21 18:09:39.706734
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:09:46.141676
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""x = str(1)""")
    t = StringTypesTransformer()
    t.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[]))])"

# Generated at 2022-06-21 18:09:53.068071
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def _test_string_transformer(string, expected):
        test_node = ast.parse(string)
        tree_changed, tree = StringTypesTransformer.transform(test_node)
        assert (str(tree) == expected)

    _test_string_transformer("str", "unicode")
    _test_string_transformer("str(i)", "unicode(i)")
    _test_string_transformer("print(str)", "print(unicode)")
    _test_string_transformer("abc = str(i)", "abc = unicode(i)")

# Generated at 2022-06-21 18:10:00.832986
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    import typing as tp
    source = textwrap.dedent(r'''
    class A:
        def __init__(self, a: str):
            self.a = a
    ''')

    expected = textwrap.dedent(r'''
    class A:
        def __init__(self, a: unicode):
            self.a = a
    ''')

    module, _ = StringTypesTransformer.transform(ast.parse(source))
    assert ast.dump(module) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 18:10:05.175842
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for StringTypesTransformer 

    """
    from .base import run_transformer_on_single_file

    run_transformer_on_single_file(StringTypesTransformer, 'stringtypes_test.py')

# Generated at 2022-06-21 18:10:15.336657
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer"""
    source2 = """str(a)"""
    expected2 = """unicode(a)"""

    tree = ast.parse(source2)
    new_tree = tree.body[0].body[0]
    tree = StringTypesTransformer().visit(tree)
    new_tree2 = tree.body[0].body[0]
    assert ast.dump(new_tree) == ast.dump(new_tree2)
    assert ast.dump(tree) == ast.dump(ast.parse(expected2))

# Generated at 2022-06-21 18:10:26.565610
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(
        ast.Str('abc')).tree == ast.Unicode('abc')
    assert StringTypesTransformer.transform(
        ast.Str('abc')).changed == True
    assert StringTypesTransformer.transform(
        ast.Str('abc')).warnings == []
    assert StringTypesTransformer.transform(
        ast.Bytes('abc')).tree == ast.Bytes('abc')
    assert StringTypesTransformer.transform(
        ast.Bytes('abc')).changed == False
    assert StringTypesTransformer.transform(
        ast.Bytes('abc')).warnings == []

    # test bytes
    assert StringTypesTransformer.transform(
        ast.Bytes('abc')) == (ast.Bytes('abc'), False, [])

# Generated at 2022-06-21 18:10:33.782670
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.python_snippet import PythonSnippet
    from ..utils.source_code_info import SourceCodeInfo, SourceCodeInfoFetcher
    from check_python_version import PythonVersion
    from ..utils.source_code_info import SourceCodeInfo, SourceCodeInfoFetcher
    from ..utils.my_ast import print_ast, dump_tree

    tree = PythonSnippet.build_ast(
        'x = "a string"',
        target_python_version=PythonVersion(2, 7),
        fetch_source_code_info=SourceCodeInfoFetcher.fetch_single_line,
    )


# Generated at 2022-06-21 18:10:42.037631
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast # type: ignore
    from ..transpile import Transpiler
    from .unpacking import UnpackingAssignmentTransformer # type: ignore
    from .decorators import DecoratorTransformer # type: ignore

    transpiler = Transpiler([UnpackingAssignmentTransformer, DecoratorTransformer, StringTypesTransformer])

    tree = ast.parse('a = str()')
    tree = transpiler.transpile(tree)
    assert tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-21 18:10:46.737408
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():  
    raw_source = """
a = str("hello")
b = "hello"
"""
    expected_source = """
a = unicode("hello")
b = "hello"
"""
    source_ast = ast.parse(raw_source)
    transformed_ast, tree_changed = StringTypesTransformer.transform(source_ast)
    py_ast = ast.parse(expected_source)

    assert compare_ast(transformed_ast, py_ast) == True

# Generated at 2022-06-21 18:10:49.230404
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    cls = StringTypesTransformer
    assert cls.transform.__name__ == 'transform'
    assert cls.transform.__doc__ == ''

# Generated at 2022-06-21 18:11:00.770765
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test import check_tree
    from ..utils.test import generate_test_cases
    from ..parser import parse_string
    from ..transformer import transform_ast

    test_cases = generate_test_cases(
        'StringTypesTransformer', (
            ('from builtins import str\nx = str\n', 'from builtins import unicode\nx = unicode\n'),
            ('from __builtin__ import str\nx = str\n', 'from __builtin__ import unicode\nx = unicode\n'),
            
        )
    )

    for test_input, expected in test_cases:
        tree = parse_string(test_input)
        tree = transform_ast(StringTypesTransformer, tree)
        check_tree(tree, expected)

    exit_code = 0

    return

# Generated at 2022-06-21 18:11:11.167375
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import random
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Name, Store

    for i in range(500):
        n = random.randrange(1,10)

        for j in range(n):
            # Generate a random string.
            string = ''.join(chr(random.randrange(ord('a'), ord('z') + 1)) for i in range(n))

            # Create a random AST.
            node = Name(id=string, ctx=Store())
            tree = ast.parse(string)

            # Run the transformation and assert that the result is correct.
            result = StringTypesTransformer.transform(node)
            assert result.tree.id == "unicode"
            assert result.tree_changed == string == "str"
            assert result.log == []

            result

# Generated at 2022-06-21 18:11:16.892729
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_string = "str(\"lol\").upper()"
    tree_changed = False

    tree = ast.parse(input_string)
    result = StringTypesTransformer().transform(tree)
    assert(result.tree_changed == tree_changed)
    assert(result.tree_transformed == tree)
    assert(result.warnings == [])


# Generated at 2022-06-21 18:11:22.980631
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # New tree
    tree = ast.parse("s = str(\"1\");\nprint s")
    # Should return (True, tree)
    transformer = StringTypesTransformer()
    x = transformer.transform(tree)
    assert x[0] == True
    # Should return (False, tree)
    transformer = StringTypesTransformer()
    x = transformer.transform(x[1])
    assert x[0] == False

# Generated at 2022-06-21 18:11:33.277771
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import get_ast

    source = '''
        def foo(l):
            s = str()
            return len(s)
    '''
    expected = '''
        def foo(l):
            s = unicode()
            return len(s)
    '''
    tree = get_ast(source)
    t = StringTypesTransformer.transform(tree)
    assert t.tree_changed
    assert get_ast(expected) == t.tree

# Generated at 2022-06-21 18:11:42.515506
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from ..utils.source import source

    tree = ast.parse(source('''
        a = str('a')
        b = str(2)
        c = str(1+2)
        d = str(True)
    '''))

    replace = ast.parse(source('''
        a = unicode('a')
        b = unicode(2)
        c = unicode(1+2)
        d = unicode(True)
    '''))

    assert ast.dump(replace) == ast.dump(transform(tree, [StringTypesTransformer]))


# Generated at 2022-06-21 18:11:54.062885
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    # Test for class StringTypesTransformer
    # StringTypesTransformer(self)
    def test_StringTypesTransformer_class_constructor():
        StringTypesTransformer()
        # No return type, no return value, no exceptions raised

    # Test for method transform
    # Signature: def transform(self, tree: ast.AST) -> TransformationResult
    def test_StringTypesTransformer_transform():
        StringTypesTransformer().transform(tree2)
        # Type Error #

    # Test for method _transform
    # Signature: def _transform(self, tree: ast.AST, context: Context) -> ast.AST
    @patch('py2to3.transformers.stringtypes.StringTypesTransformer._transform', Mock())
    def test_StringTypesTransformer__transform(monkeypatch):
        monkeypatch

# Generated at 2022-06-21 18:11:57.206728
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

    def parse(string: str) -> ast.AST:
        return ast.parse(string)

    def test_1():
        string = "a = str(b)"

# Generated at 2022-06-21 18:12:08.914519
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Testing StringTypesTransformer.
    """
    # Make sure we are using the correct version of python
    required_version = (2, 7)
    if sys.version_info[:2] != required_version:
        raise SystemError("Test requires python {}. Found python {}".format(
            ".".join(map(str, required_version)),
            ".".join(map(str, sys.version_info[:2]))))

    # Code to be transformed
    code = "a = str('test')"
    input_tree = ast.parse(code)

    # Construct TreeTransformer object and apply transformation
    transformer = StringTypesTransformer()
    result = transformer.transform(input_tree)

    # Make sure the expected tree is created
    expected_result = """
a = unicode('test')
"""
    assert ast

# Generated at 2022-06-21 18:12:13.211720
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open('tests/resources/ast_2_7/str_type.py') as file:
        tree = ast.parse(file.read())

    transformer = StringTypesTransformer()
    transformed_tree = transformer.visit(tree)

    assert find(transformed_tree, ast.Name, id='unicode') != []
    assert find(transformed_tree, ast.Name, id='str') == []

# Generated at 2022-06-21 18:12:17.583356
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest

    class StringTypesTransformerTest(unittest.TestCase):
        def test_change_str(self):
            from typed_ast import ast3 as ast

            source = """a = str()"""
            expected = """a = unicode()"""

            tree = ast.parse(source)
            new_tree = StringTypesTransformer.transform(tree)
            self.assertEqual(ast.dump(new_tree.tree), ast.dump(ast.parse(expected)))
    
    unittest.main()

# Generated at 2022-06-21 18:12:18.532644
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # type: () -> None
    pass

# Generated at 2022-06-21 18:12:27.582168
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Creates a sample tree.
    tree = ast.parse("""
print(str(1))
""")

    # Constructs and runs the transformer.
    t = StringTypesTransformer()
    t.run(tree)

    # Tests the transformer.
    assert ast.dump(tree) == textwrap.dedent("""\
    (Module
      (Expr
        (Call
          (Name
            (id unicode
            )
          )
          (
          )
          (
            (Num
              (n 1
              )
            )
          )
        )
      )
    )""")

# Generated at 2022-06-21 18:12:28.265454
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:12:44.070802
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    in_str = '''
    a = str()
    b = str('abc')
    '''
    exp_out_str = '''
    a = unicode()
    b = unicode('abc')
    '''
    out_tree = StringTypesTransformer.transform(ast.parse(in_str))
    out_str = astor.to_source(out_tree.tree)

    print(out_str)
    print(exp_out_str)
    assert out_str == exp_out_str

# Generated at 2022-06-21 18:12:47.223437
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    tree = ast3.parse('str(10)')
    result = StringTypesTransformer.transform(tree)
    assert isinstance(result.tree, ast3.Module)
    assert result.tree_changed

    # Print the result
    import astunparse
    print(astunparse.unparse(result.tree))

# Generated at 2022-06-21 18:12:56.988878
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('s = str("ABC")', '', 'single')
    res = StringTypesTransformer.transform(tree)
    assert res.tree_changed
    assert isinstance(res.tree, ast.AST)

    the_str = ast.Str('ABC')
    unicode_call = ast.Call(func=ast.Name(id='unicode', ctx=ast.Load()), 
                            args=[the_str], keywords=[], starargs=None, 
                            kwargs=None)
    expected = ast.Module(body=[
        ast.Assign(targets=[ast.Name(id='s', ctx=ast.Store())], value=unicode_call)
    ])

    assert dump(res.tree) == dump(expected)

# Generated at 2022-06-21 18:12:59.681499
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """To test the constructor.
    """
    string_types = StringTypesTransformer()
    assert string_types.target == (2, 7)


# Generated at 2022-06-21 18:13:00.253236
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:13:05.607104
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import apply_transformation
    from typed_ast import ast3, parse

    trans_class = StringTypesTransformer
    trans_name = 'StringTypesTransformer'

    ###########################################################################
    # Tests for general functionality.
    ###########################################################################

    # Test basic case.
    code = 'str(123)'
    tree = parse(code)
    new_tree, is_changed, messages = apply_transformation(
        tree, trans_name, check_compat=False)

    assert messages == []
    assert is_changed == True
    assert ast.dump(new_tree) == ast.dump(parse('unicode(123)'))

    # Test base case.
    code = 'str(123)'
    tree = parse(code)

# Generated at 2022-06-21 18:13:09.473371
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert eval(StringTypesTransformer.transform(ast.parse(
        """
if is_python2:
    str('a')
        """
    )).code) == 0

# Test for method transform of class StringTypesTransformer

# Generated at 2022-06-21 18:13:16.188534
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..runners import run_transformer
    from ..types import Transformation
    from ..grammar import ast as pdt_ast
    from ..loader_utils import Source

    source = Source('/path/to/file', '', open(__file__).read())

    example1 = 'from typing import Union\ntyped_tuple: Union[int, str]'

    res1 = run_transformer(
        source,
        Transformation([StringTypesTransformer]),
    )

    print(res1.source.code)

    assert res1.source.code == 'from typing import Union\ntyped_tuple: Union[int, unicode]'

    example2 = 'x: str; y: str'

    res2 = run_transformer(
        source,
        Transformation([StringTypesTransformer]),
    )


# Generated at 2022-06-21 18:13:21.452683
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .utils import roundtrip
    from .test_BaseTransformer import Source
    from .test_BaseTransformer import FakeOptions


# Generated at 2022-06-21 18:13:27.988050
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
a = str(1)
b = str.strip("hello")
c = str
d = str
    """

    expected_src = """
a = unicode(1)
b = unicode.strip("hello")
c = unicode
d = unicode
    """

    tree = ast.parse(src)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert expected_src == astor.to_source(result.tree)

# Generated at 2022-06-21 18:13:44.170993
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = str()')
    tree_changed, new_tree, messages = StringTypesTransformer.transform(tree)
    assert tree_changed
    source = ast.dump(new_tree)
    assert 'x = unicode()' in source
    assert messages == []


# Generated at 2022-06-21 18:13:55.440241
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(1)')
    t = StringTypesTransformer()
    res = t.transform(tree)
    assert(res.tree_changed)
    assert(res.transformations_applied == [])
    assert(ast.dump(res.tree) == ast.dump(ast.parse('unicode(1)')))
    assert(res.tree == ast.parse('unicode(1)'))
    assert(res.tree.body[0].value.func.id == 'unicode')
    assert(res.tree.body[0].value.args[0].n == 1)
    assert(res.tree.body[0].value.args[0].s == None)
    assert(res.tree.body[0].value.args[0].id == None)

# Generated at 2022-06-21 18:13:56.751903
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    

# Generated at 2022-06-21 18:13:59.087808
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from tests.utils import assert_transformation

    assert_transformation(
        StringTypesTransformer,
        "str('foo')",
        "unicode('foo')"
    )

# Generated at 2022-06-21 18:14:04.332741
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    
    cur_ast = ast.parse("a = str('foo')")
    trans = StringTypesTransformer.transform
    expected_ast = ast.parse("a = unicode('foo')")

    new_ast, changed, messages = trans(cur_ast)
    assert not changed
    assert new_ast == expected_ast

# Generated at 2022-06-21 18:14:09.126175
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(
        'def example():'
        '    a = "I am a ' + 'str")'
    )
    tree = StringTypesTransformer.transform(tree)
    exec(compile(tree.new_tree, filename="", mode="exec"))
    assert example() == 'I am a unicode'

# Generated at 2022-06-21 18:14:10.652419
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:11.440305
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform('') == 0

# Generated at 2022-06-21 18:14:15.918532
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_tree1 = ast.parse('a = str(1) + "a"')
    transformed_trees = StringTypesTransformer.transform(test_tree1)
    assert transformed_trees[0].body[0].value.right.id == 'unicode'

    test_tree2 = ast.parse('a = unicode(1) + "a"')
    transformed_trees = StringTypesTransformer.transform(test_tree2)
    assert transformed_trees[0].body[0].value.right.id == 'unicode'

# Generated at 2022-06-21 18:14:16.678707
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:55.926889
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    import astor
    x = textwrap.dedent('''\
    x = str(2)
    y = str()
    ''')
    tree = ast.parse(x)
    tree = StringTypesTransformer.transform(tree)
    code = astor.to_source(tree)
    print(code)
    #assert code == textwrap.dedent('''\
    #''')

# Generated at 2022-06-21 18:15:01.784777
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.fixtures import get_test_file_ast, compare_asts
    target_ast, _ = get_test_file_ast('2.7/string_types')
    tree_changed, _, new_tree = StringTypesTransformer.transform(target_ast)
    assert tree_changed
    assert compare_asts(new_tree, target_ast)

# Generated at 2022-06-21 18:15:10.611583
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .common import _test_transformer
    from ..types import PythonFileContents
    _test_transformer(StringTypesTransformer, PythonFileContents(
        path="dummy.py",
        contents="""
        def a_function():
            a_string = str('hello')
            b_string = str(a_string)

            return a_string
        """,
    ))
    _test_transformer(StringTypesTransformer, PythonFileContents(
        path="dummy.py",
        contents="""
        def a_function():
            a_string = unicode('hello')
            b_string = str(a_string)

            return a_string
        """,
    ))

# Generated at 2022-06-21 18:15:19.657567
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
    def f(x: str) -> str:
        pass
    """
    expected_src = """
    def f(x: unicode) -> unicode:
        pass
    """

    tree = ast.parse(src)
    result = StringTypesTransformer.transform(tree)
    result.tree._fields == ('body',)
    actual_src = astor.to_source(result.tree)
    assert actual_src == expected_src

# Generated at 2022-06-21 18:15:22.973477
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import Transformation

    from ..utils.tree import dump_ast
    import ast

    transformer = StringTypesTransformer()

    result = transformer.transform(
        Transformation(
            ast.parse('str(x)'),
            target=(2, 7),
            source=(3, 6)
        )
    )

    assert dump_ast(result.tree) == dump_ast(ast.parse('unicode(x)'))

# Generated at 2022-06-21 18:15:34.137876
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str.lower()')) == TransformationResult(ast.parse('unicode.lower()'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str.lower().upper()')) == TransformationResult(ast.parse('unicode.lower().upper()'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str')) == TransformationResult(ast.parse('unicode'), True, [])
    assert StringTypesTransformer.transform(ast.parse('"Some string"')) == TransformationResult(ast.parse('"Some string"'), False, [])
    assert StringTypesTransformer.transform(ast.parse('""')) == TransformationResult(ast.parse('""'), False, [])
    assert StringTypesTransformer.transform(ast.parse('"str"')) == TransformationResult

# Generated at 2022-06-21 18:15:37.405095
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert hasattr(StringTypesTransformer, 'transform')
    assert type(StringTypesTransformer.transform) == types.MethodType
    assert issubclass(StringTypesTransformer, BaseTransformer)


# Generated at 2022-06-21 18:15:43.142149
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.Name(id='str', ctx=ast.Load())
    assert isinstance(x, ast.AST)
    assert x.id == 'str'
    with pytest.raises(TypeError):
        x.id = 1

    # Test no transform - no str
    y = ast.Name(id='foo', ctx=ast.Load())
    result = StringTypesTransformer.transform(y)
    assert not result.tree_changed
    assert result.tree == y

    # Test transform
    result = StringTypesTransformer.transform(x)
    assert result.tree_changed
    assert result.tree.id == 'unicode'



# Generated at 2022-06-21 18:15:48.561606
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from astpretty import pprint
    from ..transformers.string_types import StringTypesTransformer
    x = ast.parse('''a = str(b)''')
    new_x = StringTypesTransformer.transform(x)
    pprint(new_x.tree)
    assert astor.to_source(new_x.tree) == "a = unicode(b)"

# Generated at 2022-06-21 18:15:49.419738
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:17:01.209832
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    p1 = ast.parse('str(1)')
    p2 = ast.parse('unicode(1)')
    assert StringTypesTransformer.transform(p1).tree == p2

# Generated at 2022-06-21 18:17:06.982493
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open(path_join(path_join(path_dirname(__file__), 'test'), 'StringTypesTransformer.py')) as FileObj:
        tree = ast.parse(FileObj.read())

    assert StringTypesTransformer.transform(tree).changed

    with open(path_join(path_join(path_dirname(__file__), 'test'), 'StringTypesTransformerExpected.py')) as FileObj:
        expected_tree = ast.parse(FileObj.read())

    assert ast.dump(tree, include_attributes=True) == ast.dump(expected_tree, include_attributes=True)

# Generated at 2022-06-21 18:17:11.293618
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo():
        mystr = str()
    """
    tree = ast.parse(code)
    newtree = StringTypesTransformer.transform(tree)
    assert newtree.tree.body[0].body[0].value.id == 'unicode'

# Generated at 2022-06-21 18:17:12.328610
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str()'))

# Generated at 2022-06-21 18:17:23.784556
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_node = ast.ClassDef(name='Foo', bases=[], keywords=[], body=[
        ast.Expr(ast.Call(func=ast.Name(id='str', ctx=ast.Load()), args=[], keywords=[])),
        ast.Expr(ast.Call(func=ast.Name(id='unicode', ctx=ast.Load()), args=[], keywords=[]))
    ], decorator_list=[])

    tree = ast.fix_missing_locations(ast.Module(body=[class_node]))
    tree = StringTypesTransformer.transform(tree).tree

# Generated at 2022-06-21 18:17:27.284895
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    for code in [
        'x = str(y)',
        'x = str',
    ]:
        tree = ast.parse(code)
        changed_tree = StringTypesTransformer.transform(tree)
        changed_code = astor.to_source(changed_tree)

        assert changed_code == code.replace('str', 'unicode')

# Generated at 2022-06-21 18:17:28.630144
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert issubclass(StringTypesTransformer, BaseTransformer)



# Generated at 2022-06-21 18:17:31.967545
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "str"
    compare = "unicode"
    tree = ast.parse(code, '<string>', 'exec')
    result = StringTypesTransformer.transform(tree)
    assert compare == ast.dump(result.tree)

# Generated at 2022-06-21 18:17:40.712351
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    example_string = '''
    def func(a):
        a = str(a)
        return a 
    '''
    example_string_expected = '''
    def func(a):
        a = unicode(a)
        return a 
    '''

    tree = astor.parse_string(example_string)
    tree_expected = astor.parse_string(example_string_expected)
    transformer = StringTypesTransformer()

    new_tree = transformer.transform(tree).tree

    assert astor.to_source(tree_expected) == astor.to_source(new_tree)

# Generated at 2022-06-21 18:17:43.196243
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    assert StringTypesTransformer.transform(
        source_to_ast("a = str('abc')")).code == "a = unicode('abc')"