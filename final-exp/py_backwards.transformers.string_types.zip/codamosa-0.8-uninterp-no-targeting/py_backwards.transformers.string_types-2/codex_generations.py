

# Generated at 2022-06-21 18:07:58.345913
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer

    Arguments:
        unittest {[type]} -- [description]
    """
    # assert StringTypesTransformer.transform()

# Generated at 2022-06-21 18:08:03.658653
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test case 1, when transformer is supposed to make all changes.
    code = """
            if some_var.startswith(""):
                other_var = str(some_var)
            elif some_var.endswith(""):
                other_var = str(some_var)
            else:
                other_var = str("")
            """
    tree = ast.parse(code)
    result, changed = StringTypesTransformer.transform(tree)
    assert changed
    compile(result, filename='<string>', mode='exec')


# Generated at 2022-06-21 18:08:12.103010
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform

    source = """\
import sys

if isinstance('foo', str):
    try:
        print('foo')
    except StandardError as e:
        print(str(e))
else:
    print('bar')
"""
    expected = """\
import sys

if isinstance('foo', unicode):
    try:
        print('foo')
    except StandardError as e:
        print(unicode(e))
else:
    print('bar')
"""
    tr = transform(source)
    assert expected == tr.code

# Generated at 2022-06-21 18:08:16.111383
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """ Test case for constructor of class StringTypesTransformer.
    """
    try:
        StringTypesTransformer(None)
    except TypeError:
        assert True
    except Exception:
        assert False
    else:
        assert False


# Generated at 2022-06-21 18:08:17.755071
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:08:20.894457
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast27
    from ..utils.mock import make_fake_module_from_source


# Generated at 2022-06-21 18:08:24.993016
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Initialize the transformer and call it with an argument
    transformer = StringTypesTransformer()
    result = transformer.transform(ast.parse('str.join(a)'))
    assert isinstance(result, TransformationResult)
    assert result.tree
    assert result.tree_changed

# Generated at 2022-06-21 18:08:35.193446
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    >>> from typed_ast import ast3 as ast
    >>> import astor
    >>> import python_modernize
    >>> node = ast.parse("str('str')")
    >>> node = StringTypesTransformer.transform(node)
    >>> print(astor.to_source(node))
    unicode('str')
    >>> node = ast.parse("name = 'str'")
    >>> node = StringTypesTransformer.transform(node)
    >>> print(astor.to_source(node))
    name = 'str'
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 18:08:40.574809
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform

    s = """
    def test():
        return 'test'
    """
    expected = """
    def test():
        return u'test'
    """

    tree = ast.parse(s)
    tree = transform(tree, 2, 7, [StringTypesTransformer])
    assert ast.dump(tree) == expected

# Generated at 2022-06-21 18:08:47.028573
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.syntaxtree import syntax_tree

    ast_tree = syntax_tree('''
    a = str(b)
    c = str(d)
    ''')

    new_ast = StringTypesTransformer.transform(ast_tree)
    assert(len(find(new_ast, 'FunctionDef')) == 0)
    assert(len(find(new_ast, 'unicode'))) == 2

# Generated at 2022-06-21 18:08:55.666873
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import inspect
    import ast
    import textwrap

    source = textwrap.dedent(inspect.getsource(test_StringTypesTransformer))
    tree = ast.parse(source)

    result = StringTypesTransformer.transform(tree)
    print(ast.dump(result.tree))
    assert result.tree_changed

    result = StringTypesTransformer.transform(tree)
    print(ast.dump(result.tree))
    assert not result.tree_changed

# Generated at 2022-06-21 18:09:02.123369
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """test StringTypesTransformer"""
    test_string = """
    s = str("Hello")

    d = str(b"Hello")

    t = str("Yes", "utf-8")
    """
    tree = ast.parse(test_string)
    StringTypesTransformer.transform(tree)
    # print("\n", astunparse.unparse(tree))
    nodes = list(find(tree, ast.Name))
    assert nodes[0].id == "unicode"
    assert nodes[1].id == "unicode"
    assert nodes[2].id == "unicode"
    

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:09:06.548840
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "print(str(0))"
    tree = ast.parse(code)
    new_tree = st.StringTypesTransformer.transform(tree)

    str_func = find(new_tree.tree, ast.Name)
    assert str_func[0].id == "unicode"

# Generated at 2022-06-21 18:09:07.127743
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert False

# Generated at 2022-06-21 18:09:16.912926
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer

    """

    # Test 1
    tree_in = ast.parse('"nice"')
    res = StringTypesTransformer.transform(tree_in)
    tree_out = ast.parse('u"nice"')

    assert res.tree_out == tree_out

    # Test 2
    tree_in = ast.parse('str')
    res = StringTypesTransformer.transform(tree_in)
    tree_out = ast.parse('unicode')

    assert res.tree_out == tree_out

    # Test 3
    tree_in = ast.parse('x = "nice"')
    res = StringTypesTransformer.transform(tree_in)
    tree_out = ast.parse('x = u"nice"')

    assert res.tree_out == tree_out



# Generated at 2022-06-21 18:09:17.949977
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:09:25.068549
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..tests.utils import generate_equivalent_ast

    code_in = """
        a = str('hello')
    """
    code_out = """
        a = unicode('hello')
    """
    tree_in = generate_equivalent_ast(code_in)
    tree_out = generate_equivalent_ast(code_out)

    t = StringTypesTransformer()
    assert t.transform(tree_in) == TransformationResult(tree_out, True, [])

# Generated at 2022-06-21 18:09:35.875229
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """ Test class StringTypesTransformer"""
    # init 
    StringTypesTransformer.target = (2, 7)
    StringTypesTransformer.constraints = []
    StringTypesTransformer.level = 0
    assert StringTypesTransformer.target == (2, 7)
    assert StringTypesTransformer.constraints == []
    assert StringTypesTransformer.level == 0
    # transform
    class_1 = ast.ClassDef(name="class_1", body=[], decorator_list=[], lineno=2, col_offset=4)
    node = ast.Name(id="str", ctx=ast.Load(), lineno=2, col_offset=4)

# Generated at 2022-06-21 18:09:40.237270
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("Testing StringTypesTransformer")
    class_name = "StringTypesTransformer"
    class_obj = globals()[class_name]

# Generated at 2022-06-21 18:09:45.024120
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "a = str()"
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    code2 = compile(tree, '', 'exec')
    res = exec(code2)
    assert(res == {})
    assert(isinstance(a, unicode))

# Generated at 2022-06-21 18:09:49.032774
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-21 18:09:51.022849
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import test_string_types_transformer
    test_string_types_transformer(StringTypesTransformer)

# Generated at 2022-06-21 18:09:58.194151
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    '''Tests StringTypesTransformer.transform method'''
    tree = ast.parse("str(1)")
    StringTypesTransformer.transform(tree)
    object_rep = ast.dump(tree)
    expected = "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))"
    assert object_rep == expected
    return True


# Generated at 2022-06-21 18:10:05.145166
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # class for testing
    class A(ast.NodeTransformer):
        foo = ast.Str('new ')
        bar = ast.Subscript(ast.Name('x', ast.Load()), ast.Index(ast.Str('key')), ast.Load())

    # testing constructor
    tree = A()
    assert isinstance(tree.foo, ast.Str)
    assert isinstance(tree.bar, ast.Subscript)
    assert isinstance(tree.bar.value, ast.Name)
    assert isinstance(tree.bar.slice, ast.Index)
    assert isinstance(tree.bar.slice.value, ast.Str)
    assert tree.foo.s == 'new '
    assert tree.bar.value.id == 'x'
    assert tree.bar.slice.value.s == 'key'

# Unit test

# Generated at 2022-06-21 18:10:08.589595
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_base import Code

    code = Code(
        'def f():\n'
        '    return str()'
    )
    assert code.transformed(StringTypesTransformer) == 'def f():\n    return unicode()'

# Generated at 2022-06-21 18:10:20.510336
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_def = ast.ClassDef(name='Test', bases=[], body=[
        ast.FunctionDef(
            name='func',
            args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]),
            body=[ast.Expr(value=ast.Call(func=ast.Name(id='str', ctx=ast.Load(), lineno=3, col_offset=8), args=[], keywords=[], starargs=None, kwargs=None, lineno=3, col_offset=8))],
            decorator_list=[],
            lineno=3,
            col_offset=4
        )
    ])


# Generated at 2022-06-21 18:10:29.144272
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import compile_tree
    from .unicode_literals_transformer import UnicodeLiteralsTransformer
    # Test a python module with implicit unicode literals already defined
    code = '''def b(): return str(a)'''
    tree = ast.parse(code)
    tree = UnicodeLiteralsTransformer.transform(tree).tree
    transformed_tree = StringTypesTransformer.transform(tree).tree
    assert astor.to_source(transformed_tree) == "from __future__ import unicode_literals\n\ndef b(): return unicode(a)"


# Generated at 2022-06-21 18:10:30.051002
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:10:34.874768
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class `StringTypesTransformer`.
    
    """

    example_tree = ast.parse('print(str)')
    StringTypesTransformer.transform(example_tree)
    assert example_tree == ast.parse('print(unicode)')

# Generated at 2022-06-21 18:10:35.959621
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:10:46.114116
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .transformer import Transformer

    code = """
a = 123
s = str(a)
    """
    tree = ast.parse(code)

    new_transformer = Transformer()
    new_transformer.register(StringTypesTransformer)

    new_tree = new_transformer.transform(tree)

    # 

# Generated at 2022-06-21 18:10:49.879225
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse('x = str()')
    t = StringTypesTransformer.transform(t)
    assert t.tree.body[0].value.func.id == 'unicode'
    assert t.tree_changed
    assert not t.messages

# Generated at 2022-06-21 18:10:51.045153
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:10:54.116543
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor 
    tree = astor.parse_file('examples/string_types.py')
    tree = StringTypesTransformer.transform(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-21 18:11:05.638432
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..testing_utils import make_test_tree

    # Given...
    tree = make_test_tree(
        """
        a = str()
        b = str.upper()
        c = str.join(str(1) + str(2))
        """
    )

    # When...
    t, changed, errors = StringTypesTransformer.transform(tree)

    # Then...
    assert changed
    assert errors == []

    assert t.body[0].value.func.id == 'unicode'
    assert t.body[1].value.func.value.id == 'unicode'
    assert t.body[1].value.func.attr == 'upper'
    assert t.body[2].value.func.value.id == 'unicode'

# Generated at 2022-06-21 18:11:11.729706
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as astt
    t = ast.parse("""
a = str('a')
b = 'b'
    """)
    t2 = astt.parse("""
a = unicode('a')
b = 'b'
    """)
    t3 = StringTypesTransformer.transform(t)
    assert(ast.dump(t2, include_attributes=True) == ast.dump(t3.tree, include_attributes=True))


# Generated at 2022-06-21 18:11:13.720820
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for StringTypesTransformer.
    
    """

# Generated at 2022-06-21 18:11:17.721873
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('print str("some string")')
    expected = ast.parse('print unicode("some string")')
    tree = StringTypesTransformer.transform(tree).tree
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:11:23.146102
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    ast_source = "str('abc')"
    ast_tree = ast.parse(ast_source)
    tree_changed, errors = StringTypesTransformer.transform(ast_tree)
    new_code = compile(ast_tree, '', 'exec')
    exec(new_code)
if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:11:27.655877
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    from typed_ast import ast3 as ast
    import io
    from ..utils.ast_builder import build_ast

    statement = "def foo():\n    s = 'str'\n    return str(s)"

    tree = build_ast(io.StringIO(statement))
    new_tree = StringTypesTransformer.transform(tree)
    new_code = ast.unparse(new_tree.tree)

    assert new_code == "def foo():\n    s = 'str'\n    return unicode(s)"


# Generated at 2022-06-21 18:11:44.003489
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert(issubclass(StringTypesTransformer, BaseTransformer))
    assert(StringTypesTransformer.__name__ == 'StringTypesTransformer')
    assert(StringTypesTransformer.target == (2, 7))

# Unit tests for class StringTypesTransformer

# Generated at 2022-06-21 18:11:55.288682
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:11:56.509831
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    from typed_ast import ast3 as ast


# Generated at 2022-06-21 18:12:02.801981
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.trees import parse_ast
    from ..utils import text
    source: str = '''\
    if type(x) == str:
        y = str(x)
    else:
        y = unicode(x)
    '''
    tree = parse_ast(source)
    r = StringTypesTransformer.transform(tree)
    assert text(r.tree) == text(tree)

# Generated at 2022-06-21 18:12:07.776634
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    node = ast.Name(id='str', ctx=ast.Load())
    t = StringTypesTransformer()
    result = t.visit(node)
    assert astor.to_source(result).strip() == "unicode"


if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:12:11.357351
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    code = 'x = str(123)'
    expected_code = 'x = unicode(123)'

    # Act
    transformed, _ = StringTypesTransformer.transform_code(code)

    # Assert
    assert transformed == expected_code

# Generated at 2022-06-21 18:12:13.694538
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    initial_tree = ast.parse('_ = str(a)')
    transformer = StringTypesTransformer()
    res = transformer.transform(initial_tree)
    assert isinstance(res.tree, ast.Module)

# Generated at 2022-06-21 18:12:16.685641
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Constructor test
    try:
        obj = StringTypesTransformer()
        print("StringTypesTransformer instantiated succesfully")
    except Exception as e:
        print("Failed to construct StringTypesTransformer")
        exit(e)

# Generated at 2022-06-21 18:12:27.134505
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    expected_tree = ast.Module(body=[ast.Expr(value=ast.Compare(left=ast.Name(id='a', ctx=ast.Load()), ops=[ast.Gt()], comparators=[ast.Call(func=ast.Name(id='unicode', ctx=ast.Load()), args=[ast.Num(n=2)], keywords=[], starargs=None, kwargs=None)]))], type_ignores=[])
    actual_tree = ast.parse("""a > unicode(2)""")
    tree_changed, error_messages = StringTypesTransformer(actual_tree).transform()
    assert ast.dump(expected_tree) == ast.dump(actual_tree)
    assert tree_changed == True



# Generated at 2022-06-21 18:12:30.896324
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast import parse
    from ..types import TransformationResult
    from ..utils.tree import compare_trees
    from ..utils.source import generate_code
    from ..utils.tools import save_temp_file

    transformer = StringTypesTransformer()


# Generated at 2022-06-21 18:13:01.718878
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import parse
    from .base import BaseTransformer

    tree = parse('str')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed is True
    assert isinstance(result.tree_transformer, BaseTransformer)

    tree = parse('unicode')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed is False
    assert isinstance(result.tree_transformer, BaseTransformer)

# Generated at 2022-06-21 18:13:04.056337
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    from typed_ast import ast3 as ast
    tree = ast.parse("x = str(y)")

    # Act
    result = StringTypesTransformer.transform(tree)

    # Assert
    assert result.tree.body[0].value.func.id == 'unicode'
    assert result.tree_changed is True

# Generated at 2022-06-21 18:13:14.066071
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    test_tree = ast.parse("s = str(s)")

    # Test simple replace
    replaced_tree = StringTypesTransformer.transform(test_tree)
    new_str = ast.dump(replaced_tree.tree)
    assert new_str == "Module(body=[Assign(targets=[Name(id='s', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='s', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

    # Test no replace
    old_tree = ast.parse("s = 123")
    replaced_tree = StringTypesTransformer.transform(old_tree)

# Generated at 2022-06-21 18:13:25.878119
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Node(ast.AST):
        def __init__(self, value):
            self.value = value

# Generated at 2022-06-21 18:13:33.408326
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    # Correct AST
    tree  = ast.parse('''foo = str''')
    tt = StringTypesTransformer.transform(tree)
    assert tt.tree == tree
    assert tt.tree_changed 
    assert tt.messages == []

    # Correct AST
    tree  = ast.parse('''foo = str(x)''')
    tt = StringTypesTransformer.transform(tree)
    assert tt.tree == tree
    assert tt.tree_changed 
    assert tt.messages == []

    # Correct AST
    tree  = ast.parse('''foo = astr''')
    tt = StringTypesTransformer.transform(tree)
    assert tt.tree == tree
    assert not tt.tree_changed 
    assert tt.messages == []



# Generated at 2022-06-21 18:13:37.890244
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open(os.path.join(os.path.dirname(__file__), 'StringTypesTransformer.py')) as f:
        file_content = f.read()

    tree = ast.parse(file_content)
    res = StringTypesTransformer.transform(tree)
    print(res)
    assert res.tree_changed == True

# Generated at 2022-06-21 18:13:39.725716
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import assert_equal_ast
    from typed_ast import ast3 as ast
    from . import py_to_pyconverter, PYTHON_VERSION


# Generated at 2022-06-21 18:13:40.122270
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:13:40.797805
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:13:46.728128
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    code = 'def f(x: str) -> str: return x'
    tree = ast.parse(code)
    result = StringTypesTransformer().transform(tree)
    assert result.tree_changed
    result_code = compile(result.tree, '<test>', 'exec')
    g = {'__builtins__': __builtins__}
    exec(result_code, g)
    assert g['f']('test') == 'test'
    # Check that 'str' is not in the code
    assert not result_code.co_consts.__contains__('str')
    assert result_code.co_consts.__contains__('unicode')

# Generated at 2022-06-21 18:14:43.800861
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Text:
        pass


# Generated at 2022-06-21 18:14:49.470472
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    # Example 1: StringTypesTransformer.transform
    root1 = ast.parse('''
    a = str()
    ''')
    result1, tree_changed1 = StringTypesTransformer.transform(root1)
    assert tree_changed1
    
    root2 = ast.parse('''
    a = unicode()
    ''')
    result2, tree_changed2 = StringTypesTransformer.transform(root2)
    assert not tree_changed2
    
    root3 = ast.parse('''
    a = str()
    b = unicode()
    ''')
    result3, tree_changed3 = StringTypesTransformer.transform(root3)
    assert tree_changed3
    
    # Example 2: unittest.main()

# Generated at 2022-06-21 18:14:51.719506
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-21 18:14:56.846283
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''def func():
        x = str(1)'
'''
    tree = ast.parse(code)
    res = StringTypesTransformer.transform(tree)
    ast.fix_missing_locations(res.tree)

    assert res.tree_changed
    assert res.messages == []
    assert ast.dump(res.tree) == ast.dump(tree)

# Generated at 2022-06-21 18:14:57.664329
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:15:01.588369
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert 'unicode' == StringTypesTransformer.transform(ast.parse('class foo: x: unicode = 0')).tree.body[0].body[0].target.id

# Generated at 2022-06-21 18:15:08.364270
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    tree = ast.parse("s = str(s + s)")
    expected_tree = ast.parse("s = unicode(s + s)")
    tree, tree_changed = StringTypesTransformer.transform(tree)
    assert(tree_changed == True)
    assert(ast.dump(tree) == ast.dump(expected_tree))

# Generated at 2022-06-21 18:15:10.085289
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from ..types import ASTNode

# Generated at 2022-06-21 18:15:18.673839
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    source = """p = str("hello")"""
    source = dedent(source)
    tree = ast.parse(source)
    result = transformer.transform(tree)
    expected = """p = unicode("hello")"""
    expected = dedent(expected)
    assert result.tree_changed is True 
    assert ast.dump(result.tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 18:15:19.651096
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..ast_parser import parse


# Generated at 2022-06-21 18:17:26.227087
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Basic unit test for StringTypesTransformer.

    """
    tree = ast.parse('if a: str(a)')
    transformer = StringTypesTransformer()

    new_tree, changed, _ = transformer.transform(tree)

    assert changed
    assert new_tree != tree
    assert str(new_tree) == 'if a: unicode(a)'


# Generated at 2022-06-21 18:17:28.603579
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open('tests/scripts/string_types.py') as f:
        source_code = f.read()
    tree = ast.parse(source_code)
    tree_changed, new_code = StringTypesTransformer.transform(tree)
    assert tree_changed

# Generated at 2022-06-21 18:17:33.729576
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("def foo(s: str): print(s)")
    result = StringTypesTransformer.transform(tree)
    assert result.changed
    assert ast.dump(result.tree) == ast.dump(ast.parse("def foo(s: unicode): print(s)"))
    assert result.errors == []

# Generated at 2022-06-21 18:17:38.053799
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert (fix_code.fix_code(StringTypesTransformer.__name__, """
a = str(a)
b = str(b)
c = str(c)
""") == """
a = unicode(a)
b = unicode(b)
c = unicode(c)
""")

# Generated at 2022-06-21 18:17:43.924906
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ..utils import dump
    import textwrap
    source = textwrap.dedent('''\
        def f():
            g(str)
        ''')
    tree = ast3.parse(source)
    new_tree = StringTypesTransformer.transform(tree)
    print(dump(new_tree))
    assert dump(new_tree) == textwrap.dedent('''\
        def f():
            g(unicode)
        ''')

# Generated at 2022-06-21 18:17:45.609070
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()

# Generated at 2022-06-21 18:17:52.370264
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_string = '''
    a = str("some string")
    '''

    tree = ast.parse(code_string)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == '''Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='some string')], keywords=[], starargs=None, kwargs=None))])'''

# Generated at 2022-06-21 18:17:57.072085
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'a = str("hello")'

    tree = ast.parse(code, mode='eval')
    tree_changed, _ = StringTypesTransformer.transform(tree)

    expected_code = 'a = unicode("hello")'

    assert ast.dump(tree) == ast.dump(ast.parse(expected_code, mode='eval'))
