

# Generated at 2022-06-21 18:08:07.462227
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('assert isinstance(foo, str)')
    tree_changed = StringTypesTransformer.transform(tree)
    print(ast_unparse(tree).strip())
    assert ast_unparse(tree).strip() == 'assert isinstance(foo, unicode)'
    assert tree_changed.tree_changed == True

# Generated at 2022-06-21 18:08:09.167921
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import ast_parser

# Generated at 2022-06-21 18:08:13.795326
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTestTransformer
    from ..utils import parse_to_functiondef
    from ..utils.nodes import ast_print
    
    class TestStringTypesTransformer(BaseTestTransformer):
        target = (2,7)
        Transformer = StringTypesTransformer


# Generated at 2022-06-21 18:08:21.889808
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Necessary to add tests for every class.

    """
    code = """
from sys import version_info

if version_info < (3,0):
    string = str
else:
    string = str

print(string)
    """

    tree = ast.parse(code)
    trf = StringTypesTransformer()
    trf.run(tree)

    expected_code = """
from sys import version_info

if version_info < (3,0):
    string = unicode
else:
    string = str

print(string)
    """


# Generated at 2022-06-21 18:08:23.779229
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer.target == (2, 7)

# Generated at 2022-06-21 18:08:27.425149
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    r = len(StringTypesTransformer.get_transformed_packages(['astunparse', 'typed_ast']))
    assert r == 1


# Unit test if the transformation works.
# It should transform "str" to "unicode"

# Generated at 2022-06-21 18:08:31.134144
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Setup
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from .base import transformers
    import astor
    # Tests

# Generated at 2022-06-21 18:08:31.856727
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    m = ast.parse('str')
    StringTypesTransformer.transform(m)

# Generated at 2022-06-21 18:08:44.169553
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    import typed_astunparse
    from ..utils.source import Source
    from ..logger import Logger
    from ..utils.tree import node_to_string


# Generated at 2022-06-21 18:08:51.206009
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from .base import BaseTransformer
    from .string_types import StringTypesTransformer
    from .utils import compare_ast
    source = """
    a = 'hello'
    """
    expect = """
    a = 'hello'
    """
    tree = ast3.parse(source)
    StringTypesTransformer.transform(tree)
    assert compare_ast(ast3.parse(expect), tree)
    pass



# Generated at 2022-06-21 18:08:59.498481
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import py2to3.tests.test_main
    
    test_files_dir = py2to3.tests.test_main.__path__[0]
    with open(f'{test_files_dir}/test_string_types.py') as f:
        code = f.read()
    tree = ast.parse(code)

    transformer = StringTypesTransformer()
    tree = transformer.transform(tree)

    assert tree.body[0].value.values[0].s == 'New string'

# Generated at 2022-06-21 18:09:06.244808
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with io.open(os.path.join(os.path.dirname(__file__), '../../../examples/string_types.py'), 'r', encoding='utf8') as f:
        code = f.read()
    tree = ast.parse(code)
    trans = StringTypesTransformer()
    new_tree, changed = trans.transform(tree)
    type(new_tree) is ast.Module
    assert(changed == True)

# Generated at 2022-06-21 18:09:11.035882
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''x = "abc"'''
    tree = ast.parse(code)
    tr = StringTypesTransformer()
    tr.transform(tree)
    assert dump_tree(tree) == 'Module(body=[Assign(targets=[Name(id="x", ctx=Store())], value=Str(s="abc"))])'


# Generated at 2022-06-21 18:09:16.696435
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer

    """
    tree = ast.parse('s = str()')
    tree = StringTypesTransformer.transform(tree).tree
    assert ast.dump(tree) == "Assign(targets=[Name(id='s', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-21 18:09:19.248701
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..unit import run_transformer_test

    run_transformer_test(StringTypesTransformer, '2to3')

# Generated at 2022-06-21 18:09:24.557001
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    tree = ast.parse('a = str(1)\n')
    expected = ast.parse('a = unicode(1)\n')
    transformer = StringTypesTransformer()
    
    # When
    actual = transformer.transform(tree).tree

    # Then
    assert ast.dump(expected) == ast.dump(actual)



# Generated at 2022-06-21 18:09:30.980336
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import jupyter_client
    from ..utils import transform_ast
    from ..utils.tree import find
    tree = ast.parse("a = 'a'")
    StringTypesTransformer.transform(tree)

    print(ast.dump(tree))
    return
    b = find(tree, ast.Assign)
    assert a.target.id == 'a'
    assert a.value.id == 'b'

# Generated at 2022-06-21 18:09:37.021310
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(b)')
    tree = StringTypesTransformer.transform(tree)
    assert isinstance(tree, TransformationResult)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='b', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-21 18:09:46.028223
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import textwrap
    from ..utils.tree import tostring

    tree_before = ast.parse(textwrap.dedent("""\
        def has_str_type():
            pass"""))

    tree_after = ast.parse(textwrap.dedent("""\
        def has_str_type():
            pass"""))

    tree = StringTypesTransformer.transform(tree_before)

    assert tostring(tree.tree) == tostring(tree_after)
    assert tree.tree_changed is False
    assert tree.errors == []

# Generated at 2022-06-21 18:09:50.566740
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import compare_ast, test_transformer

    ast_before = """
f = str('abc')
"""
    ast_after = """
f = unicode('abc')
"""
    compare_ast(ast_before, ast_after, test_transformer(StringTypesTransformer))

# Generated at 2022-06-21 18:09:58.240702
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    input_ = "def foo():\n    pass"
    expected_output = "def foo():\n    pass"

    # When
    actual_output = Thalia(StringTypesTransformer).transform(input_)

    # Then
    assert actual_output == expected_output


# Generated at 2022-06-21 18:09:59.541493
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass # TODO: add unit tests for class StringTypesTransformer

# Generated at 2022-06-21 18:10:10.824597
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import typed_ast.ast3 as typed_ast

    tree = ast.parse('''
        x = str()
    ''', mode='eval')

    new_tree = StringTypesTransformer.transform(tree)
    
    assert isinstance(new_tree.root, typed_ast.Expression)
    assert isinstance(new_tree.root.body, typed_ast.Assign)
    assert isinstance(new_tree.root.body.value, typed_ast.Call)
    assert isinstance(new_tree.root.body.value.func, typed_ast.Name)
    assert new_tree.root.body.value.func.id == 'unicode'

# Generated at 2022-06-21 18:10:17.231299
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # No op test
    tree = ast.parse('x = "abc"')
    res = StringTypesTransformer.transform(tree)
    assert res.tree_changed is False
    assert res.errors == []

    # Replace test
    tree = ast.parse('x = str("abc")')
    res = StringTypesTransformer.transform(tree)
    assert res.tree_changed is True
    assert res.errors == []

# Generated at 2022-06-21 18:10:18.222933
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:10:21.432343
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """x = 'hello'"""
    tree = ast.parse(code)
    t = StringTypesTransformer()
    t.transform(tree)
    assert tree.body[0].value.s == 'hello'

# Generated at 2022-06-21 18:10:25.137218
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = "foo"')

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    x = find(result.tree, ast.Name)

    assert x.id == 'unicode'


# Generated at 2022-06-21 18:10:33.163269
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tester import assert_examples

    transformer = StringTypesTransformer.from_version(2, 7)

    # `str` => `unicode`
    assert_examples(transformer, 'str', 'unicode')
    assert_examples(transformer, 'str(2)', 'unicode(2)')
    assert_examples(transformer, 'def f(a: str): pass', 'def f(a: unicode): pass')
    assert_examples(transformer, 'def f(a: str="a"): pass', 'def f(a: unicode="a"): pass')

    # `str` is not replaced when it is an object.
    assert_examples(transformer, 'class A: str = 1', 'class A: str = 1')

# Generated at 2022-06-21 18:10:42.248966
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test basic functionality of the class StringTypesTransformer.

    """
    tree = ast.parse(textwrap.dedent("""\
        result = str('this is great')
        result = 2 * str('this is great')
        result = str('this is great') + str('that is good')
        """))
    result = StringTypesTransformer.transform(tree)
    code = compile(result.tree, '<string>', 'exec')
    ns = {}
    eval(code, {}, ns)
    assert ns['result'] == 'this is great' * 2 + 'this is greatthat is good'

# Generated at 2022-06-21 18:10:52.261232
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    module = ast.parse("")
    module.body.append(ast.FunctionDef(name="a", args=ast.arguments(args=[ast.Name(id=str, ctx=ast.Param())])))
    module.body.append(ast.FunctionDef(name="b", args=ast.arguments(args=[ast.Name(id=str, ctx=ast.Param())])))
    module.body.append(ast.FunctionDef(name="c", args=ast.arguments(args=[ast.Name(id=str, ctx=ast.Param())])))
    StringTypesTransformer.transform(module)
    assert module.body[0].args.args[0].id == "unicode"


# Generated at 2022-06-21 18:11:03.485334
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
import json
unicode(json.dumps({"a": "b"}))
''' 

    res = StringTypesTransformer.transform(astor.parse_file(io.StringIO(code)))

    print(res.tree)

    assert res.tree_changed is True
    assert 'unicode' in astor.to_source(res.tree)

# Generated at 2022-06-21 18:11:05.070717
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:11:06.555253
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:11:07.976920
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string = StringTypesTransformer()
    assert string.target == (2, 7)

# Generated at 2022-06-21 18:11:11.867048
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from py2to3.utils.tree import to_source

    tree = ast.parse("""
    def func(arg):
        return str(arg)
    """)

    return_code = StringTypesTransformer.transform(tree)
    assert to_source(tree) == """
    def func(arg):
        return unicode(arg)
    """, to_source(tree)

# Generated at 2022-06-21 18:11:18.623227
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = '''def foo(s: str) -> str:
        return s'''
    expected_code = '''def foo(s: unicode) -> unicode:
        return s'''

    # When
    result = StringTypesTransformer.transform(astor.parse_file(StringIO(code)))

    # Then
    assert_code_equal(astor.to_source(result.tree), expected_code)

# Generated at 2022-06-21 18:11:21.235971
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_program

    # Example 1
    code = """
x = str()
"""
    expected = """
x = unicode()
"""
    assert_program(code, expected, StringTypesTransformer.transform)

    # Example 2

# Generated at 2022-06-21 18:11:29.002652
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Setup
    import typed_ast.ast3 as ast
    from ..utils.synthesize import synthesize
    from typed_ast import ast3 as ast

    example_code = """
    a = str()
    b = str('hello, world')
    c = str(123)
    """

    expected_code = """
    a = unicode()
    b = unicode('hello, world')
    c = unicode(123)
    """

    tree = synthesize(example_code, target=2.7)
    # Exercise
    tree = StringTypesTransformer.run_pipeline(tree)
    # Verify
    assert expected_code == ast.unparse(tree)

# Generated at 2022-06-21 18:11:34.304189
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..parser.parser import parse
    from textwrap import dedent

    tree = parse(dedent('''
    def foo(bar):
        baz = str(bar)
    '''))
    t = StringTypesTransformer.transform(tree)
    assert t.tree_changed
    assert 'unicode' in t.to_import

# Generated at 2022-06-21 18:11:40.194496
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    code = """
        a = str('b')
    """
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    tree = transformer.visit(tree)

    eval(compile(tree, '', 'exec'))

    assert 'a' in locals() and isinstance(a, unicode)
    assert a == 'b'

# Generated at 2022-06-21 18:11:55.965725
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    from typed_ast import ast3 as ast

    code = """
    x = str(a)
    """
    tree = ast.parse(code)

    # When
    tree = StringTypesTransformer().transform(tree)

    # Then
    assert(code == astor.to_source(tree))


# Generated at 2022-06-21 18:12:07.341484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..parser import Parser

    # Use the StringTypesTransformer on a python file of Python version '2'
    test_code = """str = 7
str = 'ten'
h = str(1)
str(8)"""
    parsed_result = Parser.parse(test_code, version=2)
    assert(not parsed_result.error)
    transformed_result = StringTypesTransformer.transform(parsed_result.tree)
    assert(transformed_result.tree_changed)

    # Test if the output after transformation is correct
    from .util import SourceWrapper

    # The expected output
    expected_result = """unicode = 7
unicode = 'ten'
h = unicode(1)
unicode(8)
"""
    output = SourceWrapper.get_source(transformed_result.tree)


# Generated at 2022-06-21 18:12:15.510159
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import run_transformer
    from typed_ast import ast3
    from ..types import TransformationResult
    transformer = StringTypesTransformer()
    # Test 1: simplest test case
    code = "a = str('a')"
    tree = ast3.parse(code)
    transformed = transformer.transform(tree)
    assert(transformed.tree_changed)
    assert(transformed.tree == ast3.parse("a = unicode('a')"))
    # Test 2: check that no errors reported
    tree = ast3.parse(code)
    transformed = transformer.transform(tree)
    assert(transformed.tree_changed)
    assert(transformed.tree == ast3.parse("a = unicode('a')"))
    assert(transformed.errors == [])
    # Test 3: transform input code

# Generated at 2022-06-21 18:12:18.669281
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_ast = ast.parse(r"""
a = str('hello')
b = str.__name__
""")

    result = StringTypesTransformer.transform(input_ast)

    assert result.tree_changed
    assert result.num_steps == 2

# Generated at 2022-06-21 18:12:30.114783
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def new_node(node):
        s = ast.Str(node, lineno=1, col_offset=1)
        u = ast.Unicode(node, lineno=1, col_offset=1)
        tree = ast.AST(ast.Module([ast.Expr(s), ast.Expr(u)]))
        return ast.copy_location(tree, node)

    # test module level string
    node = ast.Str("test", lineno=1, col_offset=1)
    tree = StringTypesTransformer.transform(node)
    assert tree.code == new_node(node).code

    # test class level string
    node = ast.Str("test", lineno=1, col_offset=1)

# Generated at 2022-06-21 18:12:34.811980
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
        a = str(1)
        b = "test"
    """
    expected_src = """
        a = unicode(1)
        b = "test"
    """

    tree = ast.parse(src)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert ast.dump(result.tree) == ast.dump(ast.parse(expected_src))

# Generated at 2022-06-21 18:12:38.349359
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse("""
x = str(1)
""")
    node = tree.body[0].value
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    assert (typed_ast.ast3.dump(new_tree) == typed_ast.ast3.dump(typed_ast.ast3.parse("""
x = unicode(1)
""")))

# Generated at 2022-06-21 18:12:41.834692
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'print str(42)'
    expected_code = 'print unicode(42)'
    t = StringTypesTransformer()
    assert t.transform(ast.parse(code), None) == expected_code

# Generated at 2022-06-21 18:12:46.855275
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    string=['''str("hello")''']
    instance=StringTypesTransformer()
    expected='''unicode("hello")'''
    tree=ast.parse(string[0])
    tree_changed, change_details=instance.transform(tree)
    output=astor.to_source(tree_changed)
    print(change_details)
    assert  output==expected

# Generated at 2022-06-21 18:12:52.453284
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
             'Test String'
    """
    expected_output = """
             'Test String'
    """
    to_check = StringTypesTransformer.transform(ast.parse(code))[0]
    exec(compile(ast.fix_missing_locations(to_check), filename="<ast>", mode="exec"))

# Generated at 2022-06-21 18:13:19.140619
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-21 18:13:29.827212
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast2json import ast2json
    from ..utils.json2ast import json2ast
    import json
    import random

    ast_list = [
        ast.Str,
        ast.Name,
        ast.Str,
        ast.Name
    ]

    json_list = [
        '{"_attributes": {}, "s": "hi"}',
        '{"_attributes": {}, "ctx": {"_attributes": {}, "ctx_type": "Load"}, "id": "str"}',
        '{"_attributes": {}, "s": "hi"}',
        '{"_attributes": {}, "ctx": {"_attributes": {}, "ctx_type": "Load"}, "id": "str"}'
    ]


# Generated at 2022-06-21 18:13:31.540547
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Constructor of class StringTypesTransformer should do nothing
    StringTypesTransformer()
    assert True

# Generated at 2022-06-21 18:13:38.053597
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast import parse
    from ..utils.tree import print_tree
    tree = parse("""def func(a): pass""")
    tree = StringTypesTransformer.transform(tree)
    print(print_tree(tree))
    tree = parse("""def func(a: str) -> str: pass""")
    tree = StringTypesTransformer.transform(tree)
    print(print_tree(tree))

# Generated at 2022-06-21 18:13:40.734798
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str = 'hello'")
    from ..transforms import StringTypesTransformer
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='unicode', ctx=Store())], value=Str(s='hello'))])"

# Generated at 2022-06-21 18:13:43.655408
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.parse('""', 'fake', 'exec')
    expected_node = ast.parse('""', 'fake', 'exec')  # no changes

    transformer = StringTypesTransformer()
    actual_node = transformer.transform(node)

    assert ast.dump(actual_node) == ast.dump(expected_node)

# Generated at 2022-06-21 18:13:46.005787
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    #To test the constructor of class StringTypesTransformer
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 18:13:56.671294
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    import StringIO

    tree = ast.parse('''a = str(b)''')
    StringTypesTransformer.transform(tree)
    codeobj = StringIO.StringIO()
    astor.codegen.to_source(tree, codeobj)
    assert codeobj.getvalue() == 'a = unicode(b)\n'
    codeobj.close()

    tree = ast.parse('''a = b.encode(c)''')
    StringTypesTransformer.transform(tree)
    codeobj = StringIO.StringIO()
    astor.codegen.to_source(tree, codeobj)
    assert codeobj.getvalue() == 'a = b.encode(c)\n'
    codeobj.close()

# Generated at 2022-06-21 18:13:57.868561
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.__name__ == "StringTypesTransformer"

# Generated at 2022-06-21 18:14:08.484988
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from textwrap import dedent
    from ..utils import dump
    from .fixtures import string_types_module

    t = StringTypesTransformer(string_types_module)

    assert dump(t.transformed[0]) == dedent("""
    def f():
        # type: () -> unicode
        return 'a'
    
    
    def g():
        # type: () -> unicode
        return unicode('a')
    
    
    def h():
        # type: () -> unicode
        def f():
            # type: () -> unicode
            return 'a'
    
    
    def i():
        # type: () -> unicode
        f = 'a'
    
    
    def j():
        # type: () -> unicode
        f = unicode('a')
    """).l

# Generated at 2022-06-21 18:15:09.710849
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types = StringTypesTransformer()
    assert string_types
    assert str(string_types) == '<StringTypesTransformer>'

# Generated at 2022-06-21 18:15:11.554485
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    f = StringTypesTransformer(None, None)
    assert f is not None

# Generated at 2022-06-21 18:15:14.704956
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test constructor of StringTypesTransformer
    StringTypesTransformer.__init__()


# Generated at 2022-06-21 18:15:25.751024
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..utils.fake_context import FakeContext
    from ..utils.tree import to_src

    from .string import StringTypesTransformer

    # Test case 1
    src = "def foo():\n    return str()"
    expected_src = "def foo():\n    return unicode()"
    tree = ast.parse(src)
    tree = StringTypesTransformer.transform(tree)
    actual_src = to_src(tree)
    assert actual_src == expected_src

    # Test case 2
    src = "def foo():\n    x = str()\n    return x"
    expected_src = "def foo():\n    x = unicode()\n    return x"
    tree = ast.parse(src)

# Generated at 2022-06-21 18:15:26.940409
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:15:33.280298
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .example import example_py2_7_str
    from .example import python_tree

    from .example import example_py2_7_unicode

    test_instance = StringTypesTransformer()
    test_instance.tree = python_tree
    result = test_instance.transform()
    print(result.tree)

    assert(str(result.tree) == example_py2_7_unicode)


# Generated at 2022-06-21 18:15:41.058601
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer(2, 7)
    assert t.transform((ast.parse("print(str(1))")), is_expression=False) == TransformationResult(ast.Module(body=[ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Call(func=ast.Name(id='unicode', ctx=ast.Load()), args=[ast.Num(n=1)], keywords=[], starargs=None, kwargs=None)], keywords=[], starargs=None, kwargs=None))]), True, [])

# Generated at 2022-06-21 18:15:47.228170
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import tree_transform, parse
    from ..utils.source import source

    x = '''
    s = str()
    s = str
    '''
    expected = '''
    s = unicode()
    s = unicode
    '''

    t = tree_transform(StringTypesTransformer, parse(source(x)))
    assert source(t) == expected

# Generated at 2022-06-21 18:15:48.710204
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    a = StringTypesTransformer()
    assert a.tree == ''

# Generated at 2022-06-21 18:15:52.202462
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test StringTypesTransformer by verifying that unicode
    is used in place of str.
    """
    test_str = "x = str()"
    tree = ast.parse(test_str)
    result = StringTypesTransformer.transform(tree)
    new_tree = result.tree
    new_code = astunparse.unparse(new_tree)
    assert new_code == "x = unicode()"