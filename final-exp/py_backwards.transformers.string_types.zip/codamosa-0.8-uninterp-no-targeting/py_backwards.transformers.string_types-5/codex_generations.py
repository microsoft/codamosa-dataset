

# Generated at 2022-06-21 18:08:11.506026
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast27
    from copy import deepcopy
    from ..helpers import assert_equal_ignore_whitespace, parse_ast
    from ..transformations.common import CommonTransformer
    from ..transformations.typed_ast import TypedAstTransformer


# Generated at 2022-06-21 18:08:12.666664
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from . import assert_transformation_result


# Generated at 2022-06-21 18:08:14.572999
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer(2,7)
    assert t.target == (2,7)

# Generated at 2022-06-21 18:08:20.820068
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  import astor
  from textwrap import dedent
  from ..utils.source import source_to_ast

  class_def = '''
    class A(object):
      def __init__(self):
        self.str_ = str()
  '''

  module = ast.parse(dedent(class_def))

  t = StringTypesTransformer()
  t.visit(module)

  assert astor.to_source(module).strip() == "class A(object):\n  def __init__(self):\n    self.str_ = unicode()"

# Generated at 2022-06-21 18:08:29.338322
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Test 1:
    tree = ast.parse("""
x = "Hello" if True else "World"
y = str('Hello')
z = str(x)
""")
    expected = ast.parse("""
x = u"Hello" if True else u"World"
y = unicode('Hello')
z = unicode(x)
""")

    new_tree = StringTypesTransformer().visit(tree)
    assert ast.dump(new_tree) == ast.dump(expected)

    # Test 2:

# Generated at 2022-06-21 18:08:38.403906
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_node = ast.parse('class A(str):\n    def __init__(self):\n        pass').body[0]
    assert isinstance(class_node, ast.ClassDef)
    new_class_node, tree_changed = StringTypesTransformer.transform(class_node)
    assert tree_changed
    assert isinstance(new_class_node, ast.ClassDef)
    assert isinstance(new_class_node.bases[0], ast.Name)
    assert new_class_node.bases[0].id == 'unicode'

# Generated at 2022-06-21 18:08:39.162992
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-21 18:08:45.402542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program_code = '''
        example_str1 = str('abc')
        example_str2 = 'abc'
        example_list_str = ['abc', str('ab'), 'c']
        example_list_str2 = ['abc', 'abc', 'abc']
        if example_str2 == 'abc':
            example_str3 = 'abc'
        else:
            example_str3 = 'def'
    '''

# Generated at 2022-06-21 18:08:56.756393
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .fixtures.strings import str_0
    from .fixtures.strings import str_1
    from .fixtures.strings import str_2
    from .fixtures.strings import str_3
    from .fixtures.strings import str_4
    from .fixtures.strings import str_5
    from .fixtures.strings import str_6
    from .fixtures.strings import str_7
    from .fixtures.strings import str_8
    from .fixtures.strings import str_9
    from .fixtures.strings import str_10

    transformer = StringTypesTransformer()

    # Test case 1
    result = transformer.transform(str_0)
    assert result.tree != str_0
    assert result.tree == str_1

    # Test case 2
    result = transformer.transform(str_2)

# Generated at 2022-06-21 18:09:03.379078
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test one
    input_str = """str"""
    expect_str = """unicode"""

    tree = ast.parse(input_str)
    new_tree = StringTypesTransformer.transform(tree)
    output_str = astor.to_source(new_tree)

    assert output_str == expect_str, \
        "Expect: \n{}\nActual: \n{}".format(expect_str, output_str)

# Generated at 2022-06-21 18:09:15.332524
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('"f"' if sys.version_info < (3, 0) else 'b"f"')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed is True
    assert result.warnings == []
    assert result.messages == []
    assert ast.dump(result.tree) == "Module(body=[Expr(value=Bytes(s=b'f'))])"

    tree = ast.parse('str(1)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed is True
    assert result.warnings == []
    assert result.messages == []

# Generated at 2022-06-21 18:09:21.310250
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    code = '''class Example(object):
    def __init__(self, name: str, age: int) -> None:
        self.name = name
        self.age = age
    def __repr__(self) -> str:
        return str(self.__dict__)
    '''

    expected_code = '''class Example(object):
    def __init__(self, name: unicode, age: int) -> None:
        self.name = name
        self.age = age
    def __repr__(self) -> unicode:
        return unicode(self.__dict__)
    '''

    # Act
    result = StringTypesTransformer.transform(code)

    # Assert
    assert result.tree == expected_code

# Generated at 2022-06-21 18:09:29.144823
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    from .. import transform
    from textwrap import dedent
    # Act
    tree = transform(dedent('''
    from test import str
    from typing import List

    def foo() -> str:
        return str('')
    '''))

    # Assert
    import astor
    assert astor.to_source(tree) == dedent('''
    from __future__ import unicode_literals
    from test import unicode
    from typing import List


    def foo() -> unicode:
        return unicode('')
    ''')

# Generated at 2022-06-21 18:09:35.060750
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    from ..utils import get_test_src, get_test_result
    source = get_test_src('stringtypetransformer.src.py')
    expected = get_test_result('stringtypetransformer.result.py')

    # Act
    transformer = StringTypesTransformer()
    result, changed = transformer.transform(source)

    # Assert
    assert changed
    assert expected == result

# Generated at 2022-06-21 18:09:36.084103
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:09:48.013425
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    """
    Unit test for constructor of class StringTypesTransformer.
    """
    
    # use the same test method name as in the original code
    def test():
        import ast
        import textwrap
        import unittest
        from typed_ast import ast3
        from typed_ast import py23
        import sys
    
        class StringTypesTransformerTest(unittest.TestCase):
    
            def _Check(self, source, expected, expecting_failure):
                tree = ast.parse(textwrap.dedent(source))
                transformer = StringTypesTransformer()
                new_tree = transformer.transform(tree)
                if expecting_failure:
                    self.assertTrue(transformer.failed, 'Expected failure')
                else:
                    self.assertFalse(transformer.failed, 'Expected success')


# Generated at 2022-06-21 18:09:55.450696
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testutils import assert_transform, assert_transform_result
    import os
    import sys

    from_path = os.path.join(os.path.dirname(__file__),
                             "../../tests/resources/string-types/string_a.py")
    to_path = os.path.join(os.path.dirname(__file__),
                           "../../tests/resources/string-types/string_b.py")

    # loads test file, compares the result of the transformation
    # with the expected result
    assert_transform(from_path, to_path, StringTypesTransformer)

    # loads test file, compares the result of the transformation
    # with the expected result
    assert_transform_result(
        from_path, StringTypesTransformer, True)

# Generated at 2022-06-21 18:09:58.866959
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    tree = ast.parse("a = str('abc')")
    t = StringTypesTransformer()
    res = t.transform(tree)[0]
    assert astor.to_source(res) == "a = unicode('abc')"

# Generated at 2022-06-21 18:10:05.519252
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_tokens

    # We can't use doctest because we want to test the class method
    # transform.
    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    tree = result.tree

    tokens = source_to_tokens(source)
    expected_tokens = source_to_tokens(
        """
        def foo(bar):
            return unicode(bar)
        """
    )

    assert tokens != expected_tokens
    assert tree is not None

# Generated at 2022-06-21 18:10:17.495387
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    for ver in ['2.7', '3.4', '3.5']:
        T = StringTypesTransformer

        code = "a = str()"
        tree = ast.parse(code)
        T.transform(tree)
        assert T.tree_to_code(tree) == "a = unicode()"

        code = "a = str"
        tree = ast.parse(code)
        T.transform(tree)
        assert T.tree_to_code(tree) == "a = unicode"

        code = "def f(a: str): return"
        tree = ast.parse(code)
        T.transform(tree)
        assert T.tree_to_code(tree) == "def f(a: unicode): return"


# Generated at 2022-06-21 18:10:30.808094
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Test case 1: Change all str(xx) to unicode(xx)
    code = """
    def hello(x):
        if x == str():
           print(str(x))
    """
    correct_code = """
    def hello(x):
        if x == unicode():
           print(unicode(x))
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(correct_code))

    # Test case 2: Change all str(xx) to unicode(xx)
    code = """
    def hello(x):
        if x == str():
           print(str(x))
        else:
            print(x)
    """

# Generated at 2022-06-21 18:10:36.546782
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.Name(id='str', ctx=ast.Load())
    tree = ast.parse('w = x + y', mode='eval')
    tree.body.value.left = x
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body.value.left.id == 'unicode'

# Generated at 2022-06-21 18:10:46.262400
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Declaring strings using str
    tree1 = ast.parse("""\
x = "hi"
y = str("hello")""")
    tree1_changed = ast.parse("""\
x = "hi"
y = unicode("hello")""")
    # Declaring unicode
    tree2 = ast.parse("""\
x = u'ABC'
y = unicode("hello")""")

    # Calling constructor
    result = StringTypesTransformer.transform(tree1)

    # Checking transformation tree
    assert compare_ast(result.transformed_tree, tree1_changed)
    assert result.tree_changed is True
    assert result.new_imports == []

    # Calling constructor
    result = StringTypesTransformer.transform(tree2)

    # Checking transformation tree

# Generated at 2022-06-21 18:10:53.888150
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(a):
        x = str(a)
    """)
    tree_changed, messages = StringTypesTransformer.transform(tree)
    new_tree = ast.dump(tree_changed)
    expected = ast.dump("""
    def foo(a):
        x = unicode(a)
    """)
    assert new_tree == expected
    assert len(messages) == 0

# check parent pointer is set correctly in StringTypesTransformer

# Generated at 2022-06-21 18:11:02.498369
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    simple_program = """
x = str()
y = str(x)
"""
    tree = ast.parse(simple_program)
    transformed_tree, tree_changed, messages = StringTypesTransformer.transform(tree)
    assert tree_changed is True
    assert len(messages) == 0
    assert transformed_tree is not None

    simple_program_expected = """
x = unicode()
y = unicode(x)
"""
    tree_expected = ast.parse(simple_program_expected)
    assert ast.dump(transformed_tree) == ast.dump(tree_expected)
    return


# Generated at 2022-06-21 18:11:06.555097
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from . import tree_builder

    # The following is a template of the source code to be transformed.

# Generated at 2022-06-21 18:11:07.606417
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:11:14.088256
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import sys
    import textwrap

    code = textwrap.dedent('''\
    """StringTypesTransformer is a docstring."""
    import types
    def test_func(a, b):
        """Test function."""
        temp = a + b
        if isinstance(temp, str):
            return True
        else:
            return False

        return isinstance(None, str)
    ''')

    tree = ast.parse(code)
    transformed_tree, tree_changed = StringTypesTransformer.transform(tree)

    if tree_changed:
        # Execute transformed tree
        exec(compile(transformed_tree, filename="<ast>", mode="exec"))
        assert test_func(1, 1) is False
    else:
        assert False, "Source code did not change"



# Generated at 2022-06-21 18:11:22.319199
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class LocalTest(StringTypesTransformer):
        # Unit test function for method transform of class StringTypesTransformer
        def test_transform(self):
            # Test 1
            self.source = 'def x():\n    return str()'
            self.expected = 'def x():\n    return unicode()'
            self.test()
            # Test 2
            self.source = 'def x():\n    a = str'
            self.expected = 'def x():\n    a = unicode'
            self.test()


    LocalTest().test_transform()


# Generated at 2022-06-21 18:11:32.186839
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTransformer
    from ..utils.tree import find
    from ..utils.context import Context
    from ..types import TransformationResult

    tree_changed = False
    tree = ast.parse('''
    def f():
        x = str(y)
        return str(y)
    ''')
    old_tree = ast.parse('''
    def f():
        x = str(y)
        return str(y)
    ''')
    ctx = Context()

    t = StringTypesTransformer()
    result = t.transform(tree)
    assert result.tree_changed == True
    assert result.errors == []
    assert tree != old_tree



# Generated at 2022-06-21 18:11:42.908884
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
print  #@
str  #@
"""
    original_tree = ast.parse(code)
    tree = copy.deepcopy(original_tree)

    transformer = StringTypesTransformer()
    assert transformer.transform(tree) == TransformationResult(ast.parse("""
print  #@
unicode  #@
"""), True, [])

    transformer.undo(tree)
    assert astor.to_source(tree) == astor.to_source(original_tree)

# Generated at 2022-06-21 18:11:50.739927
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # construct an AST
    root = ast.parse("""
        s = str(x)
    """)
    # construct a transformer
    transformer = StringTypesTransformer()
    # call the transformer
    transformer.transform(root)
    # test the results
    assert transformer.tree_changed == True
    assert astor.to_source(transformer.tree).strip().split('\n') == ["s = unicode(x)"]
    assert transformer.errors == []

test_StringTypesTransformer()

# Generated at 2022-06-21 18:11:53.832213
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
import sys
x = str(sys)
""")
    # This should not throw an error
    transformer = StringTypesTransformer(tree, target=(2, 7))

# Generated at 2022-06-21 18:11:54.775345
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer() != None

# Generated at 2022-06-21 18:12:05.864762
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Dummy:
        def __init__(self):
            self.cls = StringTypesTransformer
            self.node = ast.Name(id='str')
    # intialize
    dummy = Dummy()
    # read the source code of the target class
    source_code = inspect.getsource(dummy.cls)
    # check that the target class has doc string
    assert dummy.cls.__doc__ is not None
    # check that the target class has the unit test
    assert 'test_' + dummy.cls.__name__ in sys.modules[__name__].__dict__
    # check that the target class has the version 
    assert dummy.cls.target is not None
    # check that the target class has the version 
    assert dummy.cls.transform_node is not None
    # check

# Generated at 2022-06-21 18:12:07.045049
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:12:12.805985
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:12:16.421900
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    transformer = StringTypesTransformer()
    input_code = "def a_function(value: str):\n    print(value)"
    tree = ast3.parse(input_code)
    print(ast3.dump(tree))
    changed, declaration, code = transformer.transform(tree)
    assert(changed)
    print(ast3.dump(tree))



# Generated at 2022-06-21 18:12:17.420281
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass



# Generated at 2022-06-21 18:12:28.930564
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:12:49.496337
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
x = 'y'
z = str
""")

    transformed_tree, tree_changed = StringTypesTransformer().transform(tree)

    assert tree_changed
    assert ast.dump(transformed_tree) == """
Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Str(s='y')), Assign(targets=[Name(id='z', ctx=Store())], value=Name(id='unicode', ctx=Load()))])
    """

# Generated at 2022-06-21 18:12:55.351708
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    import typed_ast.ast3 as ast

    class TestTransformerPass(unittest.TestCase):
        def test(self):
            code = '''
            def test(x: str) -> str:
                return x
            '''
            tree = ast.parse(code)
            self.assertIsNotNone(StringTypesTransformer.transform(tree))
    unittest.main()

# Generated at 2022-06-21 18:13:00.676804
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree = ast.Module()
    tree.body = [ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Store())],
        value=ast.BinOp(
            left=ast.Constant(value='hello', kind=None),
            op=ast.Mod(),
            right=ast.Name(id='str', ctx=ast.Load())
        )
    )]

    print(ast.dump(tree))

    StringTypesTransformer.transform(tree)
    print(ast.dump(tree))

# Generated at 2022-06-21 18:13:01.419502
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:13:02.018211
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  pass

# Generated at 2022-06-21 18:13:08.753782
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from . import sample_code
    from . import round_trip
    from . import dump_tree
    from . import get_tree


    tree_before = get_tree(sample_code.string_types)
    dump_tree(tree_before)
    tree_after = StringTypesTransformer.run_full_program(sample_code.string_types)
    dump_tree(tree_after)
    assert round_trip(StringTypesTransformer, sample_code.string_types)

# Generated at 2022-06-21 18:13:09.769521
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer."""

# Generated at 2022-06-21 18:13:14.131675
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    source = "foo = 'bar' + str(45) + str(67)"
    tree = ast.parse(source)

    result = transformer.transform(tree)

    assert result.tree_transformed
    expected_source = "foo = 'bar' + unicode(45) + unicode(67)"
    assert astor.to_source(result.tree).strip() == expected_source

# Generated at 2022-06-21 18:13:19.020803
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input = """
import sys

print(str)
"""
    desired_output = """
import sys

print(unicode)
"""
    # Constructor
    au_test = AutoUpgrader()
    # Unit tests
    au_test.test(StringTypesTransformer, input, desired_output)

# Generated at 2022-06-21 18:13:20.121542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert list(StringTypesTransformer.transform(ast.parse("str")))[0].body[0].value.id == "unicode"

# Generated at 2022-06-21 18:13:56.320000
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
        class Test:
            def __init__(self):
                if isinstance(x, str):
                    pass
                self.my_str = 'test'
    """
    dst = """
        class Test:
            def __init__(self):
                if isinstance(x, unicode):
                    pass
                self.my_str = 'test'
    """
    src_node = ast.parse(src).body[0]
    expected_node = ast.parse(dst).body[0]
    transformer = StringTypesTransformer(src_node)
    result = transformer.visit_ClassDef(src_node)
    assert str(result) == str(expected_node)
    assert len(transformer.warnings) == 0

# Generated at 2022-06-21 18:14:03.518687
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import assert_equal_with_printing
    from typed_ast import ast3

    tree_before = ast3.Name('str', ast3.Load())
    tree_after = StringTypesTransformer.transform(tree_before).new_tree
    assert_equal_with_printing(tree_after, ast3.Name('unicode', ast3.Load()))
    assert_equal_with_printing(
        astor.dump_tree(tree_after),
        "Name('unicode', Load())",
        "Transformation did not work properly"
    )

# Generated at 2022-06-21 18:14:11.912240
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("x = str()", mode="eval")) == TransformationResult(ast.parse("x = unicode()", mode="eval"), True, [])
    assert StringTypesTransformer.transform(ast.parse("x = str(y)", mode="eval")) == TransformationResult(ast.parse("x = unicode(y)", mode="eval"), True, [])
    assert StringTypesTransformer.transform(ast.parse("str", mode="eval")) == TransformationResult(ast.parse("unicode", mode="eval"), True, [])
    assert StringTypesTransformer.transform(ast.parse("y = str", mode="eval")) == TransformationResult(ast.parse("y = unicode", mode="eval"), True, [])

# Generated at 2022-06-21 18:14:13.548778
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:16.365512
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import generate_testcase_from_func
    from .test_utils import run_test_cases


# Generated at 2022-06-21 18:14:20.096069
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .transformations.common import print_tree

    code = 'abc = str("abc")'
    print(code)
    parsed = ast.parse(code)
    print_tree(StringTypesTransformer.transform(parsed))

# Generated at 2022-06-21 18:14:24.063409
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str(str)")
    tree = StringTypesTransformer.transform(tree)
    tree = ast.fix_missing_locations(tree)
    code = compile(tree, "<string>", mode="exec")
    eval(code)

# Generated at 2022-06-21 18:14:28.122074
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
        """ constructed StringTypesTransformer should have the following properties:
            - a function called transform that takes the tree to be transformed as input and
              returns a tuple (changed_tree, tree_changed, import_replacements)
        """
        assert hasattr(StringTypesTransformer, 'transform')

# Generated at 2022-06-21 18:14:29.387866
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:31.836839
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()

# Generated at 2022-06-21 18:15:41.622144
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from cStringIO import StringIO
    import sys
    sys.stderr = StringIO()
    class DummyError:
        def __init__(self, *args, **kwargs):
            pass
        def __call__(self, *args, **kwargs):
            pass
        def __enter__(self, *args, **kwargs):
            pass
        def __exit__(self, *args, **kwargs):
            pass
    sys.exit = DummyError
    # Replace sys.stderr with a string buffer
    import unittest
    import textwrap
    import typed_ast.ast3 as ast3

    class StringTypesTransformerTest(unittest.TestCase):
        """Test StringTypesTransformer."""
        def setUp(self):
            self.transformer = StringTypesTransformer()

       

# Generated at 2022-06-21 18:15:44.716459
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = str()')
    StringTypesTransformer.transform(tree)
    assert show(tree) == 'x = unicode()'

# Generated at 2022-06-21 18:15:46.720608
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:15:50.337597
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Create a new node
    node = ast.parse('str')

    # Transform the node
    tree_changed, messages = StringTypesTransformer.transform(node)
    assert tree_changed
    assert len(messages) == 1

    # Check that the first node is a 'unicode'
    assert node.body[0].value.id == 'unicode'

# Generated at 2022-06-21 18:15:55.470913
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..typed_ast import ast27
    code = """assert isinstance('thing', str)"""
    tree = ast27.parse(code)

    transformed_code, tree_changed, _ = StringTypesTransformer.transform(tree)

    assert tree_changed
    eval(compile(transformed_code, '', 'exec'))

# Generated at 2022-06-21 18:15:58.631363
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("a = str('test')")).tree_changed
    assert StringTypesTransformer.transform(ast.parse("a = unicode('test')")).tree_changed == False

# Generated at 2022-06-21 18:16:03.252765
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Setup
    from ..utils.testing import setup_test_file

    # Exercise
    root = setup_test_file(__file__)
    tree = StringTypesTransformer.transform(root)[0]

    # Verify
    assert str(ast.dump(tree)) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Str(s="hello"))])'

# Generated at 2022-06-21 18:16:05.245455
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.transform(ast.parse('a = str("a")')).tree == ast.parse('a = unicode("a")')


# Generated at 2022-06-21 18:16:07.024666
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.find(ast.Name).id == 'unicode'

# Generated at 2022-06-21 18:16:08.691979
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..tests.test_transformers import assert_transformer_output
