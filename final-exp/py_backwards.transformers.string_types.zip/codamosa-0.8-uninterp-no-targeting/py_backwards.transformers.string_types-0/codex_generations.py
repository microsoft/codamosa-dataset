

# Generated at 2022-06-21 18:08:00.234900
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .util import roundtrip

    test_code = '''
        def func(x: str):
            return x

        s: str = "abc"
    '''

    expected_code = '''
        def func(x: unicode):
            return x

        s: unicode = "abc"
    '''

    tree = roundtrip(test_code)
    tree = StringTypesTransformer.transform(tree)
    output = roundtrip(tree)
    assert expected_code == output

# Generated at 2022-06-21 18:08:01.159125
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:08:03.801976
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """str"""
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].value.id == 'unicode'

# Generated at 2022-06-21 18:08:12.185067
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from astor import to_source
    import astor
    from .base import BaseTransformer

    x = astor.parse_file('./backports/tests/test_StringTypesTransformer.py')
    y = astor.parse_file('./backports/tests/test_StringTypesTransformer_result.py')
    x = StringTypesTransformer.transform(x).tree
    assert(compare_ast(ast.Module(body=x.body), ast.Module(body=y.body), ignore_changes=['lineno', 'col_offset']) == True)

# Generated at 2022-06-21 18:08:14.229490
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    input = """
        str('')
    """
    tree = ast.parse(input)
    tr = t.transform(tree)
    result = astor.to_source(tr.tree)
    expected = """
        unicode('')
    """
    assert result == expected


# Generated at 2022-06-21 18:08:17.928795
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tr = StringTypesTransformer()
    result = tr.transform(ast.parse("a = str(b)"))
    assert ast.dump(result.tree) == ast.dump(ast.parse("a = unicode(b)"))

# Generated at 2022-06-21 18:08:30.136374
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    test1 = """
a = str()
b = str(1)
c = str
d = str(a, b, c)
"""
    test1_expected = """
a = unicode()
b = unicode(1)
c = unicode
d = unicode(a, b, c)
"""    
    
    # Test the StringTypesTransformer class
    tree1 = ast.parse(test1)
    tree1_transformed = StringTypesTransformer.transform(tree1)
    tree1_expected = ast.parse(test1_expected)
    assert(tree1_transformed.changed == True)
    assert(compare_ast(tree1_expected, tree1_transformed.tree) == True)

    
if __name__ == "__main__":
    # Run the unit tests
    test_String

# Generated at 2022-06-21 18:08:32.014361
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.__class__.__name__ == 'StringTypesTransformer'

# Generated at 2022-06-21 18:08:39.510021
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_parsed_to, assert_transformed_to, get_ast
    assert_parsed_to(StringTypesTransformer, 'str', """
    unicode
    """)
    assert_transformed_to(StringTypesTransformer, get_ast("""
    if var in set(str) 
        var = []
    """), get_ast("""
    if var in set(unicode) 
        var = []
    """))

# Generated at 2022-06-21 18:08:51.118796
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # code snippet
    code_str = "def test(text):\n  return len(str(text))"
    # create the AST from string
    tree = ast3.parse(code_str)
    # apply the transformation
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    # convert back to string
    code_out = ast3.unparse(new_tree)
    # get it back as python code 
    code_obj = compile(new_tree, filename="<ast>", mode="exec")
    print(code_obj)
    # change the value of text to have the right output
    text = "test"
    # execute the code object
    exec(code_obj)
    # make the unit test
    assert test(text) == len(str(text))

# Generated at 2022-06-21 18:08:55.960886
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    assert hasattr(StringTypesTransformer, 'transform')
    assert callable(getattr(StringTypesTransformer, 'transform'))


# Generated at 2022-06-21 18:09:01.005118
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import tree_from_str
    from ..utils.transform import transform_from_str
    from astpretty import pprint

    code = '''
        expr = str()
    '''
    tree = tree_from_str(code, 'exec')
    result = transform_from_str(code, 'StringTypesTransformer')
    # pprint(result.tree)
    assert result.tree_changed
    # TODO: Why this is not working?
    # assert result.errors == []


# Generated at 2022-06-21 18:09:01.975466
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import parse, ast3


# Generated at 2022-06-21 18:09:07.946871
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Setup
    code = 'from typing import TYPE_CHECKING\nif TYPE_CHECKING:\n    from typing import AnyStr'
    tree = ast.parse(code)
    
    # Exercise
    res = StringTypesTransformer.transform(tree)

    # Verify
    assert res.was_changed
    assert not res.errors
    assert res.code == 'from typing import TYPE_CHECKING\nif TYPE_CHECKING:\n    from typing import unicode'

# Generated at 2022-06-21 18:09:16.659747
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.codegen import to_source
    from ..utils.parsing import parse

    # Use module-level 'ast' node here,
    # so that we can use find() on the node.
    tree = parse("""
a = str("a")
b = unicode("b")
c = str("c", "d")
d = unicode("d", "e")
    """)
    print(StringTypesTransformer.transform(tree))
    expected = """
a = unicode("a")
b = unicode("b")
c = unicode("c", "d")
d = unicode("d", "e")
    """
    assert to_source(tree) == expected


# Generated at 2022-06-21 18:09:19.588458
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    """
    instance = StringTypesTransformer()
    assert(instance)



# Generated at 2022-06-21 18:09:22.506823
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('x = str()')) == TransformationResult(
        ast.parse('x = unicode()'), True, [])

# Generated at 2022-06-21 18:09:28.897101
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    """
    tree = ast.parse('str')
    node = tree.body[0].value
    tree_new = StringTypesTransformer.transform(tree)
    node_new = tree_new.tree.body[0].value
    assert isinstance(node, ast.Name)
    assert node.id == 'str'
    assert isinstance(node_new, ast.Name)
    assert node_new.id == 'unicode'

# Generated at 2022-06-21 18:09:37.937658
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # no-op test
    test_tree = ast.parse('print("Hello world")')
    t = StringTypesTransformer()
    new_tree = t.visit(test_tree)
    assert ast.dump(test_tree) == ast.dump(new_tree)

    # test for valid case
    t = StringTypesTransformer()
    test_tree = ast.parse('''print(str("Hello world"))''')
    new_tree = t.visit(test_tree)
    assert ast.dump(test_tree) != ast.dump(new_tree)

    test_tree = ast.parse('''print(str.decode())''')
    new_tree = t.visit(test_tree)
    assert ast.dump(test_tree) != ast.dump(new_tree)

# Generated at 2022-06-21 18:09:41.037508
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import make_test, roundtrip_unparse
    make_test(roundtrip_unparse, StringTypesTransformer)

# Generated at 2022-06-21 18:09:47.300682
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = "a = str('test'); print(a)"
    tree = ast.parse(code)

    transformed_tree, tree_changed, messages = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert len(messages) == 0
    assert astor.to_source(transformed_tree).strip() == "a = unicode('test'); print(a)"


# Generated at 2022-06-21 18:09:47.881933
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:09:49.172711
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:09:53.477195
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "type('') == str"

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)

    assert isinstance(tree, TransformationResult)
    assert tree.tree_changed 

    if not tree.tree_changed:
        return

    code2 = compile(tree.new_tree, '<string>', mode='exec')
    exec(code2)

# Generated at 2022-06-21 18:09:59.381076
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    # The node we're interested in:
    node = ast.Name(id='str', ctx=ast.Load())

    # Transform it!
    xformed = StringTypesTransformer.transform(node)

    # It should have been transformed:
    assert xformed.tree.id == 'unicode'
    # But the tree didn't change:
    assert not xformed.tree_changed

# Generated at 2022-06-21 18:10:04.900274
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo():
            return str()
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert astunparse(tree) == code.replace('str()', 'unicode()')

# Generated at 2022-06-21 18:10:09.180683
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse("""
x = str
""")
    t_changed = ast.parse("""
x = unicode
""")

    t_result, _, _ = StringTypesTransformer.transform(t)
    assert ast.dump(t_result) == ast.dump(t_changed)

# Generated at 2022-06-21 18:10:18.268646
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ast_helpers import parse_ast, compare_ast, find

    tree_before = ast.parse(
        """
        def f(a):
            return str(a)
        """
    )

    expected_ast = ast.parse(
        """
        def f(a):
            return unicode(a)
        """
    )

    tree_after = StringTypesTransformer.transform(tree_before)

    assert compare_ast(expected_ast, tree_after[0])
    assert tree_after[1]

# Generated at 2022-06-21 18:10:20.113091
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer(ast.parse(''))


# Unit tests for method transform of class StringTypesTransformer

# Generated at 2022-06-21 18:10:25.979201
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from astor import to_source
    from .test_pre_parser import pre_parse

    code = """
a = str(5)
"""

    parsed = pre_parse(code, 2, 7)
    parsed_transformed = StringTypesTransformer.transform(parsed)

    expected = """
a = unicode(5)
"""

    assert to_source(parsed_transformed.root) == expected

# Generated at 2022-06-21 18:10:44.184448
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests for constructor of class `StringTypesTransformer`.

    """
    # Test with full code
    code = "print(str(2))"
    result = StringTypesTransformer.transform(ast.parse(code))
    assert result.tree_changed
    assert result.messages == []

# Generated at 2022-06-21 18:10:56.236693
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse('''
    str_1 = 'some_value'
    str_2 = str_1 + 'other_value'
    str_3 = str_1 + str_2
    ''')

    expected_tree = typed_ast.ast3.parse('''
    str_1 = u'some_value'
    str_2 = str_1 + u'other_value'
    str_3 = str_1 + str_2
    ''')

    transformer = StringTypesTransformer(tree)
    transformer.transform()

    assert typed_ast.ast3.dump(tree) == typed_ast.ast3.dump(expected_tree)

# Generated at 2022-06-21 18:10:59.488876
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    from typed_ast import ast3 as ast 
    from .context import Context 
    from .transformer_factory import transformer_factory 
    from .test_utils import should_not_change 


# Generated at 2022-06-21 18:11:03.036009
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse("""
        def a() -> str:
            return 'sasa'
    """)
    result = StringTypesTransformer.transform(t)
    assert isinstance(result, TransformationResult)



# Generated at 2022-06-21 18:11:04.010919
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass


# Generated at 2022-06-21 18:11:05.587509
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:11:13.325111
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    from .sample_asts import sample_ast_StringTypesTransformer_1


# Generated at 2022-06-21 18:11:17.318445
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..transpile import transpile

    transpile('''
    ast = ast.parse("str(\"123\")")
    print ast
    ''')
    # Prints: ast.parse("unicode(\"123\")")

# Generated at 2022-06-21 18:11:18.562378
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:11:26.867072
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_text = '''
    import typing
    import datetime
    from typing import Any, Union, List, Callable, IO, Tuple

    def some_func():
        x: str
        x = '123'
        x: str = '321'
        return str('123'), str(True)
    '''
    output_text = '''
    import typing
    import datetime
    from typing import Any, Union, List, Callable, IO, Tuple

    def some_func():
        x: unicode
        x = '123'
        x: unicode = '321'
        return unicode('123'), unicode(True)
    '''
    module = ast.parse(input_text)
    result = StringTypesTransformer.transform(module)
    assert result.tree_changed is True

# Generated at 2022-06-21 18:11:43.579300
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    tree = ast.parse("s = str(42)")
    tree = StringTypesTransformer.transform(tree).tree
    assert astor.to_source(tree) == "s = unicode(42)\n"

# Generated at 2022-06-21 18:11:54.288625
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    import ast
    import textwrap
    module = ast.parse(textwrap.dedent('''\
        class Test:
            def __init__(self, name: str) -> None:
                self.name = name
        '''))

    # Act
    transformation = StringTypesTransformer.transform(module)

    # Assert
    assert transformation.tree_changed
    assert not transformation.errors
    assert len(transformation.errors) == 0
    assert '\n'.join(ast.dump(transformation.tree).splitlines()[4:7]) == textwrap.dedent('''\
        class Test():
          def __init__(self, name: unicode) -> None:
            self.name = name''')

# Generated at 2022-06-21 18:12:05.436058
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:12:06.062289
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:12:12.505459
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    s = """
        x = str(1)
        a = str(x)
        b = b"foo"
        c = u"bar"
    """

    t = ast.parse(s)
    t = StringTypesTransformer.transform(t).tree

    expected = """
        x = unicode(1)
        a = unicode(x)
        b = b"foo"
        c = u"bar"
    """

    e = ast.parse(expected)

    assert ast.dump(t) == ast.dump(e)

# Generated at 2022-06-21 18:12:13.315511
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:12:19.325926
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_python.compiler.type_wrappers.wrapper import Wrapper
    from typed_ast import ast3
    from typed_python import Function
    import astunparse

    tree = ast.parse("""a = str('a')\nb = str.format('b')\nc = str('c')\nd = str.format('d')\n""")

    f = Function(ast.Module(body=tree.body), Wrapper(), None)
    f.type_env = {
        'str': f.type_env.type_from_builtin('str'),
        'format': f.type_env.type_from_builtin('str').get_attribute('format')
    }

    res = StringTypesTransformer.transform(tree)

# Generated at 2022-06-21 18:12:25.226970
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("def foo(a: str, b) -> str: pass")
    tree_changed, _ = StringTypesTransformer.transform(tree)
    assert tree_changed
    expected = ast.parse("def foo(a: unicode, b) -> unicode: pass")
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:12:30.405311
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = 'def foo(a: str) -> str:\n    return a'
    expected = 'def foo(a: unicode) -> unicode:\n    return a'
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    assert ast.unparse(new_tree) == expected

# Generated at 2022-06-21 18:12:35.474526
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name(id='str', ctx=ast.Load(), annotation=None)
    new_node = StringTypesTransformer.transform(node)[0]
    assert isinstance(new_node, ast.Name)
    assert new_node.id == 'unicode'
    assert new_node.ctx == ast.Load()
    assert new_node.annotation is None

    # unchanged
    node_a = ast.Name(id='abc', ctx=ast.Load(), annotation=None)
    node_b = ast.Name(id='', annotation=None)
    node_c = ast.Name(ctx=ast.Load())
    new_node_a = StringTypesTransformer.transform(node_a)[0]
    new_node_b = StringTypesTransformer.transform(node_b)[0]
    new_node

# Generated at 2022-06-21 18:13:05.749577
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_string = ast.ClassDef('test', [], [], [], [], [])
    constructor_test = ast.FunctionDef('__init__', ast.arguments([], None, [], [], None, []), [], [], None)
    constructor_test.args = ast.arguments([], None, [], [], None, [])
    constructor_test.args.args = [ast.Name('test', ast.Param())]
    constructor_test.args.vararg = ast.Name('test', ast.Param())
    constructor_test.args.kwarg = ast.Name('test', ast.Param())
    class_string.body.append(constructor_test)

    subtree = [class_string]
    root_node = ast.Module(subtree)
    tree_changed, result_code = StringTypesTransformer

# Generated at 2022-06-21 18:13:09.145854
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer."""
    source = """
        def foo():
            return str(1)
    """

    assert_expectations(StringTypesTransformer, source)

# Generated at 2022-06-21 18:13:15.458637
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..bin.j2py import transform
    from typed_ast import ast3 as ast

    TEST_STRINGS = [
        'str',
        'def foo() -> str: pass',
    ]

    for code in TEST_STRINGS:
        tree = ast.parse(code)
        tr = transform(tree, [StringTypesTransformer])
        assert not tr.tree_changed

    code = 'foo = str'
    tree = ast.parse(code)
    tr = transform(tree, [StringTypesTransformer])
    assert tr.tree_changed
    assert len(tr.messages) == 1
    assert tr.messages[0].message == 'str -> unicode'

# Generated at 2022-06-21 18:13:16.083146
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-21 18:13:28.036345
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    -> a = str(b)
    <= a = unicode(b)
    """
    expected_tree = ast.Module([ast.Assign([ast.Name('a', ast.Store())], ast.Call(
        ast.Name('unicode', ast.Load()), [ast.Name('b', ast.Load())], []))])
    tree = ast.Module([ast.Assign([ast.Name('a', ast.Store())], ast.Call(
        ast.Name('str', ast.Load()), [ast.Name('b', ast.Load())], []))])
    expected_tree = expected_tree.body[0]
    tree = tree.body[0]
    expected_tree = ast.fix_missing_locations(expected_tree)
    tree = ast.fix_missing_locations(tree)
   

# Generated at 2022-06-21 18:13:38.321365
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # set-up
    tree = ast.parse("a = 'foo' + str('bar')")
    
    # test
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    # assert
    assert result.tree_changed == True
    assert ast.dump(result.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=BinOp(left=Str(s='foo'), op=Add(), right=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='bar')], keywords=[], starargs=None, kwargs=None)))])"

# Generated at 2022-06-21 18:13:45.817426
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typing import Union
    from ..utils.source import source_to_unicode
    from ..utils.tree import check_equal
    from ..providers.typeshed import load_symlink_path, load_typeshed
    from ..transformers.base import get_transformer_classes

    source = source_to_unicode("""
    def func(a):
        return str(a)
    """)
    source_tree = ast.parse(source)
    typeshed_tree = load_typeshed()
    classes = get_transformer_classes(load_symlink_path(StringTypesTransformer))
    for clazz in classes:
        clazz.transform(source_tree)
    source_after = source_to_unicode(astunparse.unparse(source_tree))
    source_expected = source_to_unic

# Generated at 2022-06-21 18:13:52.792423
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str()")
    new_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) != ast.dump(new_tree.tree)
    assert ast.dump(new_tree.tree) == "Module(body=[Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"
    print(ast.dump(new_tree.tree))

# Generated at 2022-06-21 18:13:56.634378
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform(ast.parse('foo = str(bar)', '<test>', 'exec')) == \
        TransformationResult(ast.parse('foo = unicode(bar)', '<test>', 'exec'), True, [])

# Generated at 2022-06-21 18:14:01.641189
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program_strs = [
    """
    b = str
    c = unicode
    """,
    """
    def f(a):
        return a + 1
    """
    ]
    program_asts = [ast.parse(program_str) for program_str in program_strs]
    for program_ast in program_asts:
        StringTypesTransformer.transform(program_ast)

# Generated at 2022-06-21 18:15:08.887192
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import transform_and_compare_ast

    code = "a = str('a')"
    # Note: The f-string gets converted to a normal string in Python 2,
    #       so we're testing that.
    expected_transformed_code = "a = unicode('a')"
    transform_and_compare_ast(StringTypesTransformer, code, expected_transformed_code)

# Generated at 2022-06-21 18:15:17.971331
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """string-types-transformer unit test.
    """
    import ast
    from ..tools.parser import parse
    from ..tools.renderer import render

    code = '''
from __future__ import unicode_literals

'''

    tree = parse(code)

    result = StringTypesTransformer.transform(tree)


# Generated at 2022-06-21 18:15:21.210277
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(
        ast.parse('x = str')).tree_changed

    assert not StringTypesTransformer.transform(
        ast.parse('x = int')).tree_changed

# Generated at 2022-06-21 18:15:24.948969
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import inspect
    import typed_ast.ast3 as ast

    source = inspect.getsource(StringTypesTransformer)
    module = ast.parse(source)
    tree_changed = StringTypesTransformer.transform(module)

    assert tree_changed.changed == True

# Generated at 2022-06-21 18:15:30.038642
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..builder import build_ast, dump_ast
    
    code = open("examples/string_types.py").read()
    tree = build_ast(code)
    StringTypesTransformer.apply(tree)
    assert dump_ast(tree) == code.replace("str", "unicode")

# Generated at 2022-06-21 18:15:32.367288
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test for constructor of class StringTypesTransformer.
    """
    assert isinstance(StringTypesTransformer(), BaseTransformer) == True

# Generated at 2022-06-21 18:15:36.838839
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(
        ast.parse('''x = str(3)''')
    ).tree == ast.parse('''x = unicode(3)''')


# Generated at 2022-06-21 18:15:41.420894
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
a = str()
b = type(a)
c = str(b)
    """
    tree = ast.parse(code)
    transformed, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(transformed) == ast.dump(ast.parse("""
a = unicode()
b = type(a)
c = unicode(b)
    """))

# Generated at 2022-06-21 18:15:50.378810
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            if isinstance(bar, str):
                bar = bar.decode('utf-8')
        """)
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    expected_source = source_to_unicode("""
        def foo(bar):
            if isinstance(bar, unicode):
                bar = bar.decode('utf-8')
        """)
    assert tree_to_str(new_tree) == expected_source

# Generated at 2022-06-21 18:15:56.171107
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
        def hello():
            name = str(7)
    '''
    tree = ast.parse(source)
    t = StringTypesTransformer.transform(tree)
    t = StringTypesTransformer.transform(t.tree)
    assert astor.to_source(t.tree).strip() == "def hello():\n    name = unicode(7)"
