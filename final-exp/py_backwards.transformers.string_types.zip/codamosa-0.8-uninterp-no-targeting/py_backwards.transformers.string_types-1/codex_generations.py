

# Generated at 2022-06-21 18:08:13.338091
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import assert_transformation_result
    from ..utils.source import source_to_unicode

    source = source_to_unicode("""
    def test():
        x = str(1)
    """)
    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)
    assert_transformation_result(
        result,
        expected_tree = source_to_unicode("""
        def test():
            x = unicode(1)
        """),
        expected_code = source_to_unicode("""
        def test():
            x = unicode(1)
        """)
    )

# Generated at 2022-06-21 18:08:16.553534
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    '''Test case for constructor from class StringTypesTransformer'''
    # Not an example of bad code
    x = 'str'
    assert(x == 'str')

# Generated at 2022-06-21 18:08:25.260703
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import parse
    # Works fine
    assert StringTypesTransformer.transform(parse("str('str')")).tree_changed
    # Test that it doesn't transform other calls
    assert not StringTypesTransformer.transform(parse("len('str')")).tree_changed
    # Test that it doesn't transform any attrib
    assert not StringTypesTransformer.transform(parse("__name__")).tree_changed
    # Test that it doesn't transform other variables
    assert not StringTypesTransformer.transform(parse("a = 1\na")).tree_changed

# Generated at 2022-06-21 18:08:30.691683
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
a = 'This is a text'
"""
    expected_source = """
a = unicode('This is a text')
"""

    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)
    result_source = dump_code(result.tree)

    assert result_source == expected_source

# Generated at 2022-06-21 18:08:33.757702
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "print str(x)"
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == "print unicode(x)"

# Generated at 2022-06-21 18:08:35.430277
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:08:46.654318
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from .test_fixtures.classes_to_test_transformer import (
        StringTypesTransformerInheritance,
        StringTypesTransformerComposition,
        StringTypesTransformerDecorator,
        StringTypesTransformerMethod,
        StringTypesTransformerFunction,
    )

    test_classes = [
        StringTypesTransformerInheritance,
        StringTypesTransformerComposition,
        StringTypesTransformerDecorator,
        StringTypesTransformerMethod,
        StringTypesTransformerFunction,
    ]

    for test_class in test_classes:
        instance = test_class()

        tree = ast.parse(instance.before)
        instance.transformer.transform(tree)

        assert astunparse.unparse(tree) == instance.after

# Generated at 2022-06-21 18:08:50.795071
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_helpers import assert_source
    from ..node_transformer import NodeTransformer

    tree = NodeTransformer.run(StringTypesTransformer, ast.parse('assert type(s) is str'))

    assert_source(tree, 'assert type(s) is unicode')

# Generated at 2022-06-21 18:08:53.038257
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert(StringTypesTransformer.transform(ast.parse('a = str(1)')).code == 'a = unicode(1)')

# Generated at 2022-06-21 18:08:55.909191
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_tree = ast.parse('a = str(3)')
    StringTypesTransformer.transform(code_tree)
    exec(compile(code_tree, filename="", mode="exec"))
    assert a == 3

# Generated at 2022-06-21 18:09:00.388268
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True
# vim: sw=4:et:ai

# Generated at 2022-06-21 18:09:06.653694
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

    # Structure of the test cases:
    #
    # [ <test_name>, <code before>, <code after> ]

# Generated at 2022-06-21 18:09:09.855403
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = ast.parse("def foo(x): return str(x)")
    t = StringTypesTransformer.transform(s)
    assert t.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-21 18:09:12.988975
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import get_test_case_names, run_transformer

    for name in get_test_case_names(__file__):
        yield run_transformer, StringTypesTransformer, name

# Generated at 2022-06-21 18:09:16.230678
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that StringTypesTransformer is constructed appropriately 

    """
    assert StringTypesTransformer.target == (2, 7)
    s = StringTypesTransformer()
    assert s.target == (2, 7)


# Generated at 2022-06-21 18:09:23.840298
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert pretty_source(StringTypesTransformer.transform(parse_ast("""
        x = str()
    """)).tree) == pretty_source("""
        x = unicode()
    """)

    tree = parse_ast("""
        x = 'a'
        f(str)
    """)
    assert pretty_source(StringTypesTransformer.transform(tree).tree) == pretty_source("""
        x = 'a'
        f(unicode)
    """)

# Generated at 2022-06-21 18:09:31.866746
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast

    tree = ast.parse('def foo(x: str): pass')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed is True
    assert result.errors == []
    assert ast.dump(result.tree) == \
            "Module(body=[FunctionDef(name='foo', " \
            "args=arguments(args=[arg(arg='x', annotation=Name(id='unicode', ctx=Load()))], vararg=None, varargannotation=None, kwonlyargs=[], kwarg=None, kwargannotation=None, defaults=[], kw_defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"
    assert result.tree is not tree

# Generated at 2022-06-21 18:09:38.686446
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    result = StringTypesTransformer.transform(ast.parse("""\
if True:
    print str(3)"""))

    assert result.tree_changed, "Tree must be changed"
    assert len(result.log) == 0, "There must be no info messages"

    assert result.tree.body[0].test.value.value == True and \
           result.tree.body[0].body[0].values[0].s == 'unicode(3)'

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:09:41.819193
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('my_string = str(x)')
    new_tree = StringTypesTransformer().transform(tree)
    assert ast.dump(new_tree) == \
        "Module(body=[Assign(targets=[Name(id='my_string', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-21 18:09:48.405429
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("f = str('abc')", '<test>', 'exec')
    tree_original = copy.deepcopy(tree)
    tree_modified = ast.parse("f = unicode('abc')", '<test>', 'exec')
    tree = StringTypesTransformer.transform(tree).new_tree
    assert ast.dump(tree) == ast.dump(tree_modified)
    assert ast.dump(tree) != ast.dump(tree_original)

# Generated at 2022-06-21 18:09:59.165933
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo():
            return str('hello')
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == \
"""Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='hello')], keywords=[]))], decorator_list=[])])"""

# Generated at 2022-06-21 18:10:05.226035
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "processor = str.lower"
    tree = ast.parse(code)
    expected_code = "processor = unicode.lower"
    StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == expected_code



# Generated at 2022-06-21 18:10:11.411242
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """a = 3 + 4 * 5; print(str(a))"""
    tree = ast.parse(code)

    new_tree, changed, msg = StringTypesTransformer.transform(tree)

    assert changed
    assert msg == []
    assert ast.dump(new_tree) == ast.dump(ast.parse("""a = 3 + 4 * 5; print(unicode(a))"""))

# Generated at 2022-06-21 18:10:19.027877
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str = type('str', (object, ), {'__str__': None})")

    expected_tree = ast.parse("unicode = type('str', (object, ), {'__str__': None})")

    res, added, removed = StringTypesTransformer.transform(tree)

    assert ast.dump(res) == ast.dump(expected_tree)
    assert not added
    assert not removed


if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:10:23.217417
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """x = str(y)"""
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    expectedCode = """x = unicode(y)"""
    assert ast.unparse(result.tree) == expectedCode

# Generated at 2022-06-21 18:10:25.882221
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'a = str()'
    tree = ast.parse(code)

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed == True

# Generated at 2022-06-21 18:10:26.850160
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:10:31.224916
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print('Testing StringTypesTransformer class')
    test = """str"""
    tree = ast.parse(test)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"


if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-21 18:10:39.513661
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
s = str(0)
"""

    expected = """
s = unicode(0)
"""

    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert astunparse.unparse(result.new_tree) == expected

    # Test that the transformer does not change the tree if it does
    # not have to
    result = StringTypesTransformer.transform(tree)
    assert not result.tree_changed

# Generated at 2022-06-21 18:10:45.600088
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast

    code = "str(1)"

    # Construct AST from code.
    tree = ast.parse(code)

    # Apply transformation to AST.
    transformer = StringTypesTransformer()
    transformed = transformer.visit(tree)

    # Convert transformed AST back to code.
    code = compile(transformed, "<test>", "exec")

    # Execute code.
    result = eval(code)
    assert result == u'1'


# Generated at 2022-06-21 18:11:02.388720
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import inspect
    import os
    import astor
    import ast

    # read test files
    path_to_test_files = os.path.join(
        os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))),
        'test_files',
        'StringTypesTransformer',
    )
    test_file_names = [
        'test_str',
    ]
    test_file_paths = [os.path.join(path_to_test_files, name) for name in test_file_names]
    test_files = [open(path).read() for path in test_file_paths]

    # parse test files
    trees = [astor.parse_file(path) for path in test_file_paths]

    # read original

# Generated at 2022-06-21 18:11:08.414556
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    tree = ast.parse('str(1)')
    transformed_tree, code_changed, _ = transformer.transform(tree)
    assert code_changed
    assert astor.to_source(transformed_tree) == 'unicode(1)\n'
    assert len(astor.code_to_ast.parse_tree(astor.to_source(transformed_tree))) == 1

# Generated at 2022-06-21 18:11:14.393131
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_processing.transformation.utils import replace_fields
    from typed_ast import ast3 as ast
    from ast_processing.py27_to_py2.stringtypes import StringTypesTransformer
    from ast_processing.utils.tree import find
    import sys    
    
    source = """
        import os
        import sys

        def func(a: str, b: bytes = ""):
            c = str(a)
            return c
    """
    orig_ast = ast.parse(source)
    updated_ast = StringTypesTransformer.transform(orig_ast)
    assert updated_ast.tree_changed == True
    # will change the `str` to `unicode`
    assert len(find(updated_ast.tree, ast.Name)) == 6

# Generated at 2022-06-21 18:11:15.711057
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:11:25.321995
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    tree = ast.parse("""
x = str('x')
y = str()
""")
    assert str(tree) == """
Module(body=[
  Assign(targets=[
    Name(id='x', ctx=Store())],
    value=Call(func=Name(id='str', ctx=Load()),
               args=[Str(s='x')],
               keywords=[])),
  Assign(targets=[
    Name(id='y', ctx=Store())],
    value=Call(func=Name(id='str', ctx=Load()),
               args=[],
               keywords=[]))])
"""
    transformed, _ = StringTypesTransformer(tree).transform()

# Generated at 2022-06-21 18:11:31.642055
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    # Testing if replacing s = str(int(n)) with s = unicode(int(n))
    tree = astor.parse_file('tests/examples/str.py')
    result, changed = StringTypesTransformer.transform(tree)
    assert(changed == True)

# Generated at 2022-06-21 18:11:40.002957
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''a = str; b = str;
    def foo(str): pass
    class bar(str): pass
    class baz(object):
        def __init__(self, str): pass
        ''')

    t = StringTypesTransformer()
    assert t.transform(tree) == TransformationResult(
        ast.parse('''a = unicode; b = unicode;
    def foo(unicode): pass
    class bar(unicode): pass
    class baz(object):
        def __init__(self, unicode): pass
        '''),
        True, [])

# Generated at 2022-06-21 18:11:51.911273
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_node = ast.ClassDef(name = 'TestClass', bases = [], keywords = [], body = [], decorator_list = [])
    arg_node = ast.Name(id = 'str', ctx = ast.Load())
    func_node = ast.FunctionDef(name = 'test_func', args = ast.arguments(args = [arg_node], vararg = None, kwarg = None, defaults = []), body = [], decorator_list = [])
    module_node = ast.Module(body = [class_node, func_node])
    
    new_module_node = StringTypesTransformer().transform(module_node).node

    # Check that there are no ClassDef nodes in the new module AST
    num_class_defs = len(find(new_module_node, ast.ClassDef))


# Generated at 2022-06-21 18:11:57.543999
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    environ = {}
    test_code = """
        a = str('hello')
        """
    expected_code = """
        a = unicode('hello')
        """
    test_module = ast.parse(test_code)
    expected_module = ast.parse(expected_code)

    transformer = StringTypesTransformer()
    transformed_module, tree_changed = transformer.transform(test_module)

    assert tree_changed
    assert ast.dump(transformed_module) == ast.dump(expected_module)

# Generated at 2022-06-21 18:12:04.958775
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import code_to_ast
    from .string_literal_transformer import StringLiteralTransformer

    code = '''class A: def method(self): print str'''
    tree = code_to_ast.parse(code)

    t = StringLiteralTransformer()
    t.transform(tree)

    t = StringTypesTransformer()
    tree, changed, messages = t.transform(tree)

    assert not changed


# Generated at 2022-06-21 18:12:17.118969
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:12:21.032811
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(
        dedent("""\
        s = 'yolo'
        s2 = str(42)
        """)) == dedent("""\
        s = u'yolo'
        s2 = unicode(42)
        """)

# Generated at 2022-06-21 18:12:24.444521
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # assert type(StringTypesTransformer()) == StringTypesTransformer

    assert type(StringTypesTransformer.transform) == staticmethod
    assert callable(StringTypesTransformer.transform)

# Generated at 2022-06-21 18:12:25.863448
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..abstract_syntax_tree import parse

# Generated at 2022-06-21 18:12:35.063095
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    import astor
    from ..utils.tree import find
    from ..utils.context import Context
    from ..utils.code_writer import CodeWriter
    from ..base import Transformer

    test_input = """
        def test(x: str, y, z: list) -> str:
            return y
    """

    test_input_tree = ast.parse(test_input)

    result = StringTypesTransformer.transform(test_input_tree)
    assert result.tree is not test_input_tree
    assert result.tree_changed

    result_str = astor.to_source(result.tree)
    result_str_expected = """
        def test(x: unicode, y, z: list) -> unicode:
            return y
    """
    assert result_str.strip() == result_str_expected.strip()

# Generated at 2022-06-21 18:12:46.752106
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    
    # Test 1: Basic
    source = """
y = 'abc'
"""
    
    expected_result = """
y = 'abc'
"""
    
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.transform(tree)

    assert ast.dump(new_tree.tree) == expected_result

    # Test 2: Replacing str with unicode
    source = """
y = str
"""
    
    expected_result = """
y = unicode
"""
    
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.transform(tree)

    assert ast.dump(new_tree.tree) == expected_result

# Generated at 2022-06-21 18:12:47.459544
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  assert True == True

# Generated at 2022-06-21 18:12:49.244532
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 18:12:56.459737
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_object = StringTypesTransformer()
    assert class_object.target[0] == 2
    assert class_object.target[1] == 7
    assert isinstance(class_object.tree, ast.Module)
    assert class_object.tree_changed == False
    assert class_object.import_injector.imports == {}
    assert class_object.deprecated_remover.collected_nodes == []
    assert class_object.undefined_names_checker.collected_nodes == []



# Generated at 2022-06-21 18:13:04.355820
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    node = ast.parse('x = 1 + str(y)')
    tree = StringTypesTransformer.transform(node)
    assert str(tree.node) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=BinOp(left=Constant(value=1, kind=None), op=Add(), right=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='y', ctx=Load())], keywords=[], starargs=None, kwargs=None)))])"

# Generated at 2022-06-21 18:13:30.189103
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    sut = StringTypesTransformer()
    assert sut.target == (2, 7)



# Generated at 2022-06-21 18:13:31.172326
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:13:40.533001
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for class StringTypesTransformer"""

    # StringTypesTransformer.transform()
    tree = ast.parse("def f(a: str) -> None: pass")
    new_tree = StringTypesTransformer.transform(tree)

    assert type(new_tree) == TransformationResult
    assert type(new_tree.tree) == ast.AST
    assert new_tree.tree_changed == True
    assert new_tree.messages == []

    u_tree = ast.parse("def f(a: unicode) -> None: pass")
    assert ast.dump(new_tree.tree) == ast.dump(u_tree)

test_StringTypesTransformer()

# Generated at 2022-06-21 18:13:42.022240
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that Constructor works as expected.

    """
    t = StringTypesTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-21 18:13:47.351171
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    code = 'def foo(int x): str'
    tree = ast.parse(code)

    StringTypesTransformer.transform(tree)

    # Modification in place.
    assert code == 'def foo(int x): str'
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=foo, args=arguments(args=[arg(arg=x, annotation=Name(id=int, ctx=Load()))], vararg=None, kwarg=None, defaults=[]), body=[Expr(value=Name(id=unicode, ctx=Load()))], decorator_list=[])])'

# Generated at 2022-06-21 18:13:53.687970
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str')
    
    assert isinstance(tree, ast.AST)

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed

    root = result.tree
    assert root is not None
    assert isinstance(root, ast.AST)

    for node in find(root, ast.Name):
        assert node.id == 'unicode'

# Generated at 2022-06-21 18:14:03.648816
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:10.876799
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    from textwrap import dedent

    tree = typed_ast.ast3.parse(dedent('''
    if True:
        s = str()
    '''))

    expected_tree = typed_ast.ast3.parse(dedent('''
    if True:
        s = unicode()
    '''))

    actual_tree = StringTypesTransformer.transform(tree).tree
    assert typed_ast.ast3.dump(expected_tree) == typed_ast.ast3.dump(actual_tree)


# Generated at 2022-06-21 18:14:11.911277
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..transpile import transpile


# Generated at 2022-06-21 18:14:22.260844
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.transform(ast.parse('''type(x)''')) == TransformationResult(ast.parse('''type(x)'''), False, [])
    assert transformer.transform(ast.parse('''type(x) is str''')) == TransformationResult(ast.parse('''type(x) is unicode'''), True, [])
    assert transformer.transform(ast.parse('''type(x) is int''')) == TransformationResult(ast.parse('''type(x) is int'''), False, [])
    assert transformer.transform(ast.parse('''type(x) is str and type(y) is str''')) == TransformationResult(ast.parse('''type(x) is unicode and type(y) is unicode'''), True, [])
   

# Generated at 2022-06-21 18:15:21.109782
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    result = transformer.transform(ast.parse("str('str')"))
    assert result.tree_changed

    result = transformer.transform(ast.parse("str('str')"))
    assert not result.tree_changed

    result = transformer.transform(ast.parse("unicode('str')"))
    assert not result.tree_changed

# Generated at 2022-06-21 18:15:26.830788
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
    s = str(u'hello')
    """
    module = ast.parse(source)
    result = StringTypesTransformer.transform(module)

    print(result.tree)
    print(result.tree_changed)

# Test if the transformer can do the following transformation in the real file

# Generated at 2022-06-21 18:15:38.280609
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Transforms "str" to "unicode", added to the module tree
    module = ast.Module([], [ast.Expr(ast.Str('test'))])
    result = StringTypesTransformer.transform(module)
    assert result.tree[0].value.s == 'unicode'

    # Transforms "str" to "unicode", added to the module tree
    module = ast.Module([], [ast.Expr(ast.Name('str', ast.Load()))])
    result = StringTypesTransformer.transform(module)
    assert result.tree[0].value.id == 'unicode'

    # No changes made
    module = ast.Module([], [ast.Expr(ast.Str('unicode'))])
    result = StringTypesTransformer.transform(module)

# Generated at 2022-06-21 18:15:46.720224
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import utils
    from ..conftest import ast_from_source

    source = "foo = 'string'\n"
    source += "bar = str(foo)"
    tree = ast_from_source(source, utils.AST_NODE_CLASS['2.7'])
    tree = StringTypesTransformer.transform(tree)

    assert source != utils.dump_python_source(tree)
    exec(utils.dump_python_source(tree))
    assert bar == u'string'

# Generated at 2022-06-21 18:15:50.846788
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import parse_code
    import astunparse
    tree = parse_code("x = str(u'Привет')")
    t = StringTypesTransformer()
    result = t.transform(tree)
    assert result.tree_changed
    assert astunparse.unparse(result.tree) == "x = unicode(u'Привет')"

# Generated at 2022-06-21 18:15:51.966629
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    return StringTypesTransformer


# Generated at 2022-06-21 18:16:01.857308
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s= '''def f():
    return str(b"#\xc3\xa9")'''
    t= ast.parse(s)
    s2= '''def f():
    return unicode(b"#\xc3\xa9")'''
    t2= ast.parse(s2)
    r= StringTypesTransformer.transform(t)
    assert r.modified== True, 'Failed to detect string change.'
    assert ast.dump(r.tree)== ast.dump(t2), 'Failed to make desired changes.'

"""
Note: When you have created all of your own transformers, you can call the function
`apply_all_transformers` to get the tree for a Python 3 version of the code.
"""

apply_all_transformers(Python2to3TreeTransformer(t))

# Generated at 2022-06-21 18:16:06.409240
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    code = """
        str = 'foo'
        unicode = 'bar'
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree).tree
    assert compile(tree, "<test>", 'exec').co_names == ('unicode',)
    exec(compile(tree, "<test>", 'exec'))
    assert unicode == 'bar'

# Generated at 2022-06-21 18:16:11.035986
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test variable declarations
    assert StringTypesTransformer.transform(ast.parse("""str""")) == (ast.parse("""unicode"""), True, [])
    assert StringTypesTransformer.transform(ast.parse("""str a = 5""")) == (ast.parse("""unicode a = 5"""), True, [])
    assert StringTypesTransformer.transform(ast.parse("""str a, b""")) == (ast.parse("""unicode a, b"""), True, [])
    assert StringTypesTransformer.transform(ast.parse("""str a = 5, b = 6""")) == (ast.parse("""unicode a = 5, b = 6"""), True, [])

# Generated at 2022-06-21 18:16:17.253060
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
str_var = 'str'
""".strip()

    expected_source = """
str_var = u'str'
""".strip()

    tree = ast.parse(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)

    result_source = SourceGenerator.to_source(new_tree)

    assert result_source == expected_source