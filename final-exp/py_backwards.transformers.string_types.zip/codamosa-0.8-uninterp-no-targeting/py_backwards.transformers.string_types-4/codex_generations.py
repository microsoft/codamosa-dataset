

# Generated at 2022-06-21 18:08:11.461747
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from import_from_future.fixes import StringTypesTransformer
    from ..utils.source_code import SourceCode
    from ..utils.tree import to_src


# Generated at 2022-06-21 18:08:15.408055
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = 'Hello, world!'")
    stt = StringTypesTransformer()
    tree = stt.visit(tree)
    # assert that the tree is modified by the transformer
    assert tree.body[0].value.s == b'Hello, world!'

# Generated at 2022-06-21 18:08:21.717419
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
foo = str()
    """
    expected_dst = """
foo = unicode()
    """
    dst = StringTypesTransformer.transform(ast.parse(src))
    assert expected_dst == astor.to_source(dst.tree).strip()


# Generated at 2022-06-21 18:08:29.706488
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast_str = """
a = 'abc'
b = int('abc')
c = str('abc')
    """
    tree = ast.parse(ast_str)
    tree_changed, issues, tree = StringTypesTransformer.transform_single_file(tree=tree)
    assert tree_changed
    assert len(issues) == 0
    assert astor.to_source(tree).strip() == """
a = u'abc'
b = int(u'abc')
c = unicode(u'abc')
    """.strip()

# Generated at 2022-06-21 18:08:36.651908
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
        def foo():
            return 'foo'
    """
    expected_src = """
        def foo():
            return u'foo'
    """
    tree = ast.parse(src)
    expected = ast.parse(expected_src)
    transformer = StringTypesTransformer()
    transformed, changed = transformer.transform(tree)
    assert changed == True
    assert ast.dump(transformed) == ast.dump(expected)

# Generated at 2022-06-21 18:08:45.017538
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # each name(token) must be replaced
    code = 'a = str(1)'
    new_code = StringTypesTransformer.transform(code)
    assert new_code == 'a = unicode(1)'

    # each name(token) must be replaced
    code = 'str(a)'
    new_code = StringTypesTransformer.transform(code)
    assert new_code == 'unicode(a)'

    # each name(token) must be replaced
    code = 'a = str()'
    new_code = StringTypesTransformer.transform(code)
    assert new_code == 'a = unicode()'

    # each name(token) must be replaced
    code = 'import str'
    new_code = StringTypesTransformer.transform(code)
    assert new_code == 'import unicode'

    # each

# Generated at 2022-06-21 18:08:53.431254
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''

if __name__ == '__main__':
    print(str(1))
    print('str' + 'str')
    print(str)
    print(str())
    '''

    expected = """
if __name__ == '__main__':
    print(unicode(1))
    print('str' + 'str')
    print(unicode)
    print(unicode())
    """

    tree = ast.parse(code)

    result = StringTypesTransformer.transform(tree)
    assert expected == to_source(result.tree)

# Generated at 2022-06-21 18:08:55.261197
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-21 18:09:02.778839
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Test for StringTypeTransformer.
    """
    source = ast.parse("""
        s = "Hello"
        u = u"World"
        b = b"!"
        """)
    res = StringTypesTransformer.transform(source)
    source_new = ast.parse("""
        s = "Hello"
        u = unicode("World")
        b = b"!"
        """)
    assert isinstance(res, TransformationResult)
    assert ast.dump(res.tree) == ast.dump(source_new)

# Generated at 2022-06-21 18:09:08.331078
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    operand_tree = ast.parse("""
if True:
    str('')
else:
    str('2')
""").body
    expected_result = ast.parse("""
if True:
    unicode('')
else:
    unicode('2')
""").body
    result = StringTypesTransformer.transform(operand_tree)
    assert result.tree == expected_result

# Generated at 2022-06-21 18:09:13.781528
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse("x = str(1)")
    transformed = StringTypesTransformer.transform(t)
    assert(transformed.tree.body[0].value.func.id == 'unicode')
    assert(transformed.changed == True)

# Generated at 2022-06-21 18:09:15.123752
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:09:21.374855
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    '''This method is used to test if the StringTypesTransformer class
    transforms a Python code in the right way.
    '''
    # The code to be transformed
    api_code = '''
                for i in range(10):
                    x = str(i)
                '''

    # The expected output, transformed code
    expected_output = '''
                       for i in range(10):
                           x = unicode(i)
                       '''

    # The expected output, error-list
    expected_output_errorlist = []

    # The expected output, transformed AST (just for debug)
    expected_output_ast = ast.parse(expected_output)

    # Create the Transformer object
    transformer = StringTypesTransformer()

    # Transform the code
    result = transformer.transform(api_code)

    # Check if the

# Generated at 2022-06-21 18:09:32.925947
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    code = 'def fn(a: str) -> str: return a'
    parsed_code = ast.parse(code)
    tree_transformed = StringTypesTransformer.transform(parsed_code)
    fn_node = tree_transformed.tree.body[0]
    assert fn_node.name == 'fn'
    assert isinstance(fn_node.args.args[0], ast.arg)
    assert fn_node.args.args[0].arg == 'a'
    assert fn_node.args.args[0].annotation.id == 'unicode'
    assert fn_node.returns.id == 'unicode'
    assert isinstance(fn_node.body[0], ast.Return)

# Generated at 2022-06-21 18:09:36.645912
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """ Test to verify the constructor of class StringTypesTransformer
    """

    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.messages == []
    assert transformer.tree_changed == False
    assert transformer.tree is None


# Generated at 2022-06-21 18:09:48.661973
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    
    # Allocate nodes
    module = ast.Module()

# Generated at 2022-06-21 18:09:49.418281
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:09:53.638473
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    nodes = ast.parse("str", "<test>", "exec")
    tree = nodes.body[0]
    tr = StringTypesTransformer.transform(tree)

    assert type(tr.tree) == ast.Expr
    assert type(tr.tree.value) == ast.Name

    assert tr.tree_changed == True
    assert tr.failures == None
    assert tr.tree.value.id == "unicode"

# Generated at 2022-06-21 18:09:57.867838
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_input = """def foo():
    pass"""
    expected_output = """def foo():
    pass"""
    expected_output = ast.parse(expected_output)
    result = StringTypesTransformer.transform(ast.parse(test_input))
    assert result.tree == expected_output

# Generated at 2022-06-21 18:10:04.981712
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    # Without line number
    tree = ast.parse(
    '''
    a = str(1)
    b = str()
    ''')
    output = StringTypesTransformer.transform(tree)
    assert output.get_tree() == ast.parse(
    '''
    a = unicode(1)
    b = unicode()
    ''')
    assert output.get_tree_changed() == True
    assert output.get_linenos() == []
    
    # With line number
    tree = ast.parse(
    '''
    a = str(1)
    b = str()
    ''',
    mode='exec')
    output = StringTypesTransformer.transform(tree)

# Generated at 2022-06-21 18:10:19.923455
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    # Input
    my_string = ast.Str(s="hello")
    my_int = ast.Num(n=3)
    print_func = ast.Call(func=ast.Name(id='print'), args=[my_string], keywords=[])
    print_func2 = ast.Call(func=ast.Name(id='print'), args=[my_int], keywords=[])
    funcdef = ast.FunctionDef(name='test_me', args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]),
                              body=[print_func, print_func2], decorator_list=[], returns=None)
    module = ast.Module(body=[funcdef])

    # Expected output
    my_string_expected = ast.Str(s="hello")
    my_

# Generated at 2022-06-21 18:10:24.192067
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    sample_code = """
        x = str()
        x = str(2)
        x = str('a', 'b')
        x = str(1, 2, 3)
    """
    expected_code = """
        x = unicode()
        x = unicode(2)
        x = unicode('a', 'b')
        x = unicode(1, 2, 3)
    """
    tree = ast.parse(sample_code)
    new_tree, tree_changed, _ = StringTypesTransformer.transform(tree)
    new_code = astor.to_source(new_tree)
    assert expected_code == new_code

# Generated at 2022-06-21 18:10:25.239241
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:10:28.934224
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor
    test_StringTypesTransformer.transformer = StringTypesTransformer()
    assert isinstance(test_StringTypesTransformer.transformer, BaseTransformer)
    assert test_StringTypesTransformer.transformer.target == (2,7)


# Generated at 2022-06-21 18:10:34.078826
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
    def f():
        x = str()
    ''')

    etree = ast.parse('''
    def f():
        x = unicode()
    ''')

    transformer = StringTypesTransformer()
    transformed_tree, tree_changed = transformer.transform(tree)

    transformed_etree, etree_changed = transformer.transform(etree)

    assert tree_changed == True and etree_changed == False
    assert ast.dump(transformed_tree) == ast.dump(etree)
    assert ast.dump(transformed_etree) == ast.dump(etree)

# Generated at 2022-06-21 18:10:45.144297
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    import unittest 
    from darglint.types import TransformationResult
    from .base import BaseTransformer
    from ..utils.tree import find
    import textwrap

    class TestStringTypesTransformer(unittest.TestCase):
        def test_transform(self):
            # Test with  str
            tree = ast.parse(textwrap.dedent("""
                x = str
                """))
            tree = StringTypesTransformer().visit(tree)
            node = find(tree, ast.Name).next()
            self.assertEqual(node.id, 'unicode')

            # Test with  non-str
            tree = ast.parse(textwrap.dedent("""
                x = 1
                """))
            tree = StringTypesTransformer().visit(tree)

# Generated at 2022-06-21 18:10:48.047819
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse('def f() -> str: pass')
    tree = StringTypesTransformer.transform(t)
    assert tree.changed


# Generated at 2022-06-21 18:10:57.691851
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    # Test first transformation with an random Python code.
    tree = ast.parse('str(1)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.messages == []
    assert result.tree != tree

    # Test second transformation with a Python code that has been already transformed.
    tree = ast.parse('unicode(1)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == False
    assert result.messages == []
    assert result.tree == tree


# Generated at 2022-06-21 18:11:04.011725
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .constructor import create_transformer

    transformer = create_transformer(StringTypesTransformer)

    tree = ast.parse('x = str("test")')
    expected_tree = ast.parse('x = unicode("test")')

    tree, outputs = transformer(tree)

    assert outputs['typch_strict_mode'] == False
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 18:11:11.093633
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    import astor
    from . import _unittest_helper

    class TestStringTypesTransformer(unittest.TestCase):
        def test_stringTypesTransformer(self):
            code = """a=str("test")"""
            result, changed = _unittest_helper.transformed(StringTypesTransformer, code)
            self.assertTrue(changed)
            expected_result = "a = unicode(\"test\")"
            self.assertEqual(result, expected_result)

    unittest.main()

# Generated at 2022-06-21 18:11:23.106300
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    source = """
        class Foo: 
            def __init__(self, text: str) -> None: 
                pass
    """

    result = StringTypesTransformer.transform(ast.parse(source))
    assert result.tree_changed
    assert result.source == """
        class Foo: 
            def __init__(self, text: unicode) -> None: 
                pass
    """
    assert result.log == []

# Generated at 2022-06-21 18:11:24.785718
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str(a)')) == TransformationResult(ast.parse('unicode(a)'), True, [])

# Generated at 2022-06-21 18:11:30.936600
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Create a string transformer
    transformer = StringTypesTransformer()

    # Create an AST for a string as a class def
    class_node = ast.ClassDef(name = 'Test', bases = [], body = [], 
                              decorator_list = [], keywargs = None)

    # Transfrom the node
    result = transformer.transform(class_node)

    # Assert that the node has not changed
    assert result.tree == class_node

# Generated at 2022-06-21 18:11:39.128340
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .transformation_factory import get_name

    code = '''\
        def f(x):
            return isinstance(x, str)\
    '''
    tree = ast.parse(code)
    
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert 'isinstance(x, unicode)' in get_name(result.tree)

    result = StringTypesTransformer.transform(result.tree)
    assert not result.tree_changed
    assert 'isinstance(x, unicode)' in get_name(result.tree)

# Generated at 2022-06-21 18:11:49.915919
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = '''
with open('fake.txt', 'r') as fil:
    mystr = str(fil)
    '''
    expected_code = '''
with open('fake.txt', 'r') as fil:
    mystr = unicode(fil)
    '''
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert astor.to_source(result.tree) == astor.to_source(expected_tree)
    assert result.tree_changed == True
    assert result.futures_used == []

# Generated at 2022-06-21 18:11:58.284668
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import codecs
    from .base import CodeTransformer
    path = 'code/string_types_transformer_test.py'
    with codecs.open(path, 'r', 'utf-8') as file_obj:
        source_code = file_obj.read()
    tree = ast.parse(source_code)
    node = tree.body[0].body[1].body[0].value.left
    assert isinstance(node.func, ast.Attribute)
    assert node.func.attr == 'decode'
    StringTypesTransformer.transform(tree)
    CodeTransformer.dump(tree)
    node = tree.body[0].body[1].body[0].value.left
    assert isinstance(node.func, ast.Attribute)
    assert node.func.attr == 'decode'

# Unit

# Generated at 2022-06-21 18:12:10.037599
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import pprint
    from ..utils.source import generate_module_source
    from ..utils import transform_with_print

    source = generate_module_source(
        nodes=[
            ast.Assign(
                targets=[
                    ast.Name(id='var', ctx=ast.Store())
                ],
                value=ast.Name(id='str', ctx=ast.Load())
            )
        ]
    )

    _, printable = transform_with_print(source)


# Generated at 2022-06-21 18:12:18.532752
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class MockNode(ast.AST):
        _fields = ('name',)
        def __init__(self, name):
            self.name = name
    
    parser = ast.parse("""class A:\n
        def __init__(self, name: str):
            self.name = name""")
    class_node = parser.body[0]
    method_node = class_node.body[0]
    parameter_node = method_node.args.args[0]
    annotation_node = parameter_node.annotation
    assert isinstance(annotation_node, ast.Name)
    assert annotation_node.id == 'str'
    StringTypesTransformer.transform(parser)
    assert annotation_node.id == 'unicode'

# Generated at 2022-06-21 18:12:23.168770
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_code = '''
a = str(1)
'''
    tree, changed = StringTypesTransformer.transform_ast(ast.parse(test_code))
    print(changed)
    print(ast.dump(tree))

# Generated at 2022-06-21 18:12:24.699938
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # If the test throws an exception, it'll fail
    StringTypesTransformer()

# Generated at 2022-06-21 18:12:48.213655
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_ = StringTypesTransformer
    print('Testing class {}'.format(class_))
    print('Testing method transform of {}'.format(class_))

    # Test 1
    node = ast.Name(id='str', ctx=ast.Load())
    expected_result = {'tree': ast.Name(id='unicode', ctx=ast.Load()), 
                       'tree_changed': True, 
                       'log': []}
    result = class_.transform(node)
    print('Test 1: \n      input: {} \n    output: {} \n expected: {}'.format(
        node, result, expected_result))
    assert result == expected_result
    # Test 2
    node = ast.Name(id='STRING', ctx=ast.Load())

# Generated at 2022-06-21 18:12:55.228766
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that the StringTypesTransformer performs 
    the expected substitutions.
    """
    program_ast_1 = ast.parse('isinstance(x, str)')
    transformed_program_1 = StringTypesTransformer.transform(program_ast_1)
    expected_ast_1 = ast.parse('isinstance(x, unicode)')
    assert transformed_program_1.tree.body[0].value.args[1].id == expected_ast_1.body[0].value.args[1].id

# Generated at 2022-06-21 18:12:59.085197
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(42)')
    _, changed, _ = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(tree) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=42)], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-21 18:13:02.959410
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.parse('a = str("b")')
    t = StringTypesTransformer.transform(node)

    assert ast.dump(t.tree) == ast.dump(ast.parse('a = unicode("b")'))
    assert t.tree_changed == True

# Generated at 2022-06-21 18:13:11.434246
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    from ..utils.tree import visit
    from ..transformations.string_types import StringTypesTransformer

    tree = ast.parse(""" 
        x = 'hello'
        y = str(x)
    """)

    tree, tree_changed = StringTypesTransformer.transform(tree)

    def test(node):
        if isinstance(node, ast.Name):
            assert node.id != 'str', "str should be removed"
        else:
            assert False, "Only names should be found"

    visit(tree, test)

    # Assert the transformations was successful
    assert tree_changed, "tree should be changed"

# Generated at 2022-06-21 18:13:12.500736
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:13:17.152129
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .examples import TYPE_ANNOTATION_EXAMPLE_1
    from textwrap import dedent
    file_path, tree, output = TYPE_ANNOTATION_EXAMPLE_1
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == dedent(output).strip()

# Generated at 2022-06-21 18:13:23.587739
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Replaces `str` with `unicode`. 

    """
    src1 = '''
    class A(str):
        pass
    '''
    expected_dst1 = '''
    class A(unicode):
        pass
    '''

    # Apply
    dst1 = StringTypesTransformer.run_test(src1)
    assert(dst1 == expected_dst1)

# Generated at 2022-06-21 18:13:31.866544
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'import json\nfrom datetime import datetime\n\nfrom typing import Optional, List\n\n\nclass Example:\n\n    def __init__(self,\n                 parameter_1: str,\n                 parameter_2: str,\n                 parameter_3: List[dict],\n                 parameter_4: str,\n                 parameter_5: Optional[str]) -> None:\n        pass\n\n'
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    result_code = compile(result.new_tree, '<string>', 'exec')
    result_code = strip_backslash(str(result_code))

# Generated at 2022-06-21 18:13:38.720818
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """
    a = str([1, 2])
    b = str()
    """
    expected_code = """
    a = unicode([1, 2])
    b = unicode()
    """
    tree = astor.parse_file(code)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert astor.to_source(new_tree) == expected_code

# Generated at 2022-06-21 18:14:07.647776
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:08.863481
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_str = "str('hello')"

    tree_orig = ast.parse(test_str)
    tree_result, changed, messag

# Generated at 2022-06-21 18:14:15.479585
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from textwrap import dedent
    from typed_ast import ast3

    s = '''
    def func():
        return str()
    '''
    tree = ast3.parse(dedent(s))
    transformer = StringTypesTransformer()
    changed_tree = transformer.transform(tree)
    assert changed_tree.tree != tree
    assert 'str()' not in ast3.dump(changed_tree.tree)
    assert 'unicode()' in ast3.dump(changed_tree.tree)
    assert changed_tree.warnings == []
    assert changed_tree.errors == []

# Generated at 2022-06-21 18:14:19.171302
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("x = str(1)")
    expected = ast.parse("x = unicode(1)")
    actual, tree_changed, fixers = StringTypesTransformer.transform(tree)
    assert actual == expected
    assert tree_changed

# Generated at 2022-06-21 18:14:20.011624
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:25.363231
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
    str()
    x = str()
    ''')


    tree_changed, tree, diagnostics = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert find(tree, ast.Name)
    assert find(tree, ast.Name).id == 'unicode'

# Generated at 2022-06-21 18:14:28.307965
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(42)')

    expected = ast.parse('unicode(42)')

    res = StringTypesTransformer.transform(tree)

    assert res.tree == expected


# Generated at 2022-06-21 18:14:35.093083
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test input
    input_line = "i=str(5)"
    print("INPUT:", input_line)

    # Expected output
    output_line = "i=unicode(5)"
    print("OUTPUT:", output_line)

    # Test
    tree = ast.parse(input_line)
    tree = StringTypesTransformer.transform(tree).tree
    ast.fix_missing_locations(tree)
    output_line_actual = compile(tree, filename='<string>', mode='exec')
    assert output_line == output_line_actual

# Generated at 2022-06-21 18:14:36.394007
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-21 18:14:39.612323
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert (StringTypesTransformer.transform(ast.parse("def f(s: str) -> str: pass")).tree == 
        ast.parse("def f(s: unicode) -> str: pass"))

# Generated at 2022-06-21 18:15:42.720122
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from src.utils.tree import build

    # Transformer without transformation
    tree = build([
        (2, 7),
        "name = 'unicode'",
        [],
        []
    ])
    res = StringTypesTransformer.transform(tree)
    assert res.transformed is False

    # Transformer with transformation
    tree = build([
        (2, 7),
        "name = 'unicode'",
        [],
        []
    ])
    res = StringTypesTransformer.transform(tree)
    assert res.transformed is False

    tree = build([
        (2, 7),
        "name = str()",
        [],
        []
    ])
    res = StringTypesTransformer.transform(tree)
    assert res.transformed is True

# Generated at 2022-06-21 18:15:51.544081
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    from .test_base import create_test_case_class

    tests = [
        ('str', 'unicode'),
        ('str(1)', 'unicode(1)'),
        ('str(a)', 'unicode(a)'),
        ('str.x', 'unicode.x'),
        ('str.y()', 'unicode.y()'),
        ('str.z(1)', 'unicode.z(1)'),
        ('str.z(a)', 'unicode.z(a)'),
    ]

    TestStringTypesTransformer = create_test_case_class(StringTypesTransformer, tests)

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestStringTypesTransformer))
    return suite


# Generated at 2022-06-21 18:16:01.447579
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    root = ast.parse("def f(s: str) -> str: return s")
    result = StringTypesTransformer.transform(root)
    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed
    assert isinstance(result.diagnostics, list)
    assert not result.diagnostics
    assert isinstance(result.tree.body[0], ast.FunctionDef)
    assert isinstance(result.tree.body[0].args.args[0], ast.arg)
    assert isinstance(result.tree.body[0].args.args[0].annotation, ast.Name)
    assert result.tree.body[0].args.args[0].annotation.id == 'unicode'
    assert isinstance(result.tree.body[0].returns, ast.Name)
    assert result.tree

# Generated at 2022-06-21 18:16:05.366403
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ast_unparse import Unparser

    tt = StringTypesTransformer()
    tree = ast3.parse("foo = str(a)")
    new_tree = tt.visit(tree)
    Unparser(new_tree)

    assert Unparser(new_tree).unparse() == "foo = unicode(a)\n"

# Generated at 2022-06-21 18:16:06.817146
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests the ``StringTypesTransformer`` class constructor.

    """
    transformer = StringTypesTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:16:09.153250
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('x = str(1)\n')).changed
    assert not StringTypesTransformer.transform(ast.parse('x = unicode(1)\n')).changed
    assert not StringTypesTransformer.transform(ast.parse('x = 1\n')).changed

# Generated at 2022-06-21 18:16:17.154416
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = str(1)')
    transformer = StringTypesTransformer(2, 7)
    result = transformer.transform(tree)
    assert isinstance(result.tree, ast.Module)
    assert isinstance(result.tree.body[0], ast.Assign)
    assert isinstance(result.tree.body[0].value, ast.Call)
    assert isinstance(result.tree.body[0].value.func, ast.Name)
    assert result.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-21 18:16:21.321015
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    module = ast.parse("a = str(b)")

    assert module.body[0].value.func.id == "str"

    new_module = StringTypesTransformer.transform(module)
    module = new_module.tree

    assert module.body[0].value.func.id == "unicode"



# Generated at 2022-06-21 18:16:31.855099
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import ast_to_str
    from . import to_python2
    from . import to_python3

    # Test for string and unicode
    # test for unicode literal
    unicode_string_literal = to_python2(
        to_python3(
            ast.parse("s = u'a'"),
            version=(3, 6)
        )
    )

    # test for unicode function
    unicode_string_function = to_python2(
        to_python3(
            ast.parse("s = unicode('a')"),
            version=(3, 6)
        )
    )

    # Test for string and unicode
    # test for unicode literal

# Generated at 2022-06-21 18:16:36.702384
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    expected_ast = ast.parse("a = (unicode) (1)") 
    src = "a = (str) (1)"
    tree = ast.parse(src)
    actual_result = StringTypesTransformer.transform(tree)    
    assert actual_result.tree == expected_ast
    assert actual_result.tree_changed == True
    assert actual_result.warnings == []