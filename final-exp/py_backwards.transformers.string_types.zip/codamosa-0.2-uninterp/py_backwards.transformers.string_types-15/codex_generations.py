

# Generated at 2022-06-18 00:30:30.489470
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
        def foo(x):
            return unicode(x)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:30:36.956526
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(bar: str):
        pass
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(bar: unicode):
        pass
    """)

# Generated at 2022-06-18 00:30:43.813393
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    expected = """
    def foo(bar):
        return unicode(bar)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:30:44.700480
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:30:49.213709
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo():
            return str(1)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
        def foo():
            return unicode(1)
    """))

# Generated at 2022-06-18 00:30:55.715454
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
    def foo(a: unicode):
        return a
    """

# Generated at 2022-06-18 00:31:03.967198
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo():
            return str(1)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo():
            return unicode(1)
    """)))

# Generated at 2022-06-18 00:31:13.303208
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str()
        b = str(1)
        c = str(1, 2)
        d = str(a)
        e = str(a, b)
        f = str(a, b, c)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)


# Generated at 2022-06-18 00:31:15.026150
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Test that the class constructor works
    assert StringTypesTransformer(2, 7) is not None


# Generated at 2022-06-18 00:31:21.010167
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo():
            return str()
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)

    expected_source = """
        def foo():
            return unicode()
    """
    expected_tree = source_to_tree(expected_source)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:31:28.971945
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet
    from ..utils.testing import load_transformed_snippet

    snippet = load_example_snippet('string_types.py')
    expected = load_transformed_snippet('string_types.py')

    transformer = StringTypesTransformer()
    result = transformer.transform(snippet)

    assert_transformation_result(result, expected)

# Generated at 2022-06-18 00:31:29.662723
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:38.180801
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert source_to_ast(source) != tree
    assert source_to_ast(source).body[0].body.value.func.id == 'str'
    assert tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:31:45.056910
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.dump import dump_tree

    source = """
    a = str(1)
    """
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.transform(tree)

    assert compare_trees(new_tree.tree, source_to_tree("""
    a = unicode(1)
    """))

    assert new_tree.tree_changed
    assert new_tree.warnings == []

# Generated at 2022-06-18 00:31:51.086510
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(a: str):
        pass
    """
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert new_tree.tree_changed
    assert new_tree.messages == []
    assert ast.dump(new_tree.tree) == ast.dump(ast.parse("""
    def foo(a: unicode):
        pass
    """))

# Generated at 2022-06-18 00:31:55.602738
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar: str):
        pass
    """
    expected = """
    def foo(bar: unicode):
        pass
    """
    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:32:02.871508
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:32:06.251230
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert new_tree.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:32:13.201478
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert len(tree.errors) == 0
    assert len(find(tree.tree, ast.Name)) == 1
    assert astor.to_source(tree.tree).strip() == 'unicode'

# Generated at 2022-06-18 00:32:18.284711
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)

    transformer = StringTypesTransformer()
    new_tree = run_transformer(transformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:32:27.203401
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    expected = """
    def foo(x):
        return unicode(x)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:32:32.205439
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    source = '''
    def foo(x):
        return str(x)
    '''
    tree = source_to_tree(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:32:37.969755
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x: str):
            return x
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x: unicode):
            return x
    """)))

# Generated at 2022-06-18 00:32:45.446702
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert tree_to_str(new_tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)))

# Generated at 2022-06-18 00:32:55.014367
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:33:01.122301
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = run_transformer(tree, StringTypesTransformer)

    assert compare_trees(tree, source_to_tree('''
        def foo(x):
            return unicode(x)
    '''))

# Generated at 2022-06-18 00:33:07.238907
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:33:17.891037
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
    def foo(a):
        return str(a)
    """
    expected_ast = """
    Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """

    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.run_it(tree)
   

# Generated at 2022-06-18 00:33:24.068786
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
        def foo(a):
            return str(a)
    """
    expected = """
        def foo(a):
            return unicode(a)
    """
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:33:34.860932
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')
    assert_transformation(StringTypesTransformer, 'str(1)', 'unicode(1)')
    assert_transformation(StringTypesTransformer, 'str(1, 2)', 'unicode(1, 2)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3)', 'unicode(1, 2, 3)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4)', 'unicode(1, 2, 3, 4)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4, 5)', 'unicode(1, 2, 3, 4, 5)')
    assert_

# Generated at 2022-06-18 00:33:37.563610
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:33:42.451263
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(bar):
        return str(bar)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(bar):
        return unicode(bar)
    """))

# Generated at 2022-06-18 00:33:48.792386
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:33:56.225626
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_visitor

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)
    tree = ast.parse(source)
    print_visitor(tree)
    tree = StringTypesTransformer.transform(tree)
    print_visitor(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:34:04.550354
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:34:09.914386
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(bar):
        return str(bar)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(bar):
        return unicode(bar)
    """))

# Generated at 2022-06-18 00:34:15.021089
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_module_transformations
    from ..utils.transform import run_function_transformations
    from ..utils.transform import run_class_transformations
    from ..utils.transform import run_method_transformations


# Generated at 2022-06-18 00:34:20.263043
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(s: str):
            return s
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(s: unicode):
            return s
    """)

# Generated at 2022-06-18 00:34:26.275595
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    StringTypesTransformer.transform(tree)
    source = astor.to_source(tree)
    assert 'unicode' in source

# Generated at 2022-06-18 00:34:31.205780
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast("""
    def foo(x):
        return str(x)
    """)

    tree = StringTypesTransformer.transform(tree).tree
    assert astor.to_source(tree) == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:34:42.819344
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
        def foo(x):
            return str(x)
    '''
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, source_to_tree('''
        def foo(x):
            return unicode(x)
    '''))

# Generated at 2022-06-18 00:34:49.122249
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:34:55.703101
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    expected = """
    def foo(x):
        return unicode(x)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:35:03.101078
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """
    expected = """
        def foo(bar):
            return unicode(bar)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(new_tree, expected)

# Generated at 2022-06-18 00:35:09.558891
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """
    expected = """
        def foo(x):
            return unicode(x)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:35:11.335970
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:35:15.595936
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Test if the class is correctly initialized
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.name == 'StringTypesTransformer'
    assert transformer.description == 'Replaces `str` with `unicode`.'


# Generated at 2022-06-18 00:35:20.245523
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    tree = ast.parse("""
        def foo(bar: str):
            pass
    """)

    expected_tree = ast.parse("""
        def foo(bar: unicode):
            pass
    """)

    assert_transformation_result(
        StringTypesTransformer,
        tree,
        expected_tree
    )

# Generated at 2022-06-18 00:35:25.854272
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        pass
    """

    tree = source_to_ast(source)
    tree, _, _ = StringTypesTransformer.transform(tree)

    assert source_to_ast(source) != tree

# Generated at 2022-06-18 00:35:29.465586
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(
        StringTypesTransformer,
        '''
        def foo():
            return str(1)
        ''',
        '''
        def foo():
            return unicode(1)
        '''
    )

# Generated at 2022-06-18 00:35:45.769448
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:35:53.067382
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.tree import find
    from ..types import TransformationResult
    from .base import BaseTransformer

    class StringTypesTransformer(BaseTransformer):
        """Replaces `str` with `unicode`. 

        """
        target = (2, 7)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.Name):
                if node.id == 'str':
                    node.id = 'unicode'
                    tree_changed = True

            return TransformationResult(tree, tree_changed, [])

    # Unit test for constructor of class StringTypesTransformer
    def test_StringTypesTransformer():
        import astor
        from typed_ast import ast

# Generated at 2022-06-18 00:35:58.395974
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import parse

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = parse(source)
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:36:02.101291
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('a = str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'a = unicode(1)\n'

# Generated at 2022-06-18 00:36:08.529371
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    tree = ast.parse("""
        def foo():
            return str(x)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
        def foo():
            return unicode(x)
    """))

# Generated at 2022-06-18 00:36:13.570776
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(x):
        return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:36:18.141402
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert ast.dump(tree) == ast.dump(source_to_ast("""
    def foo(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:36:22.680848
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast
    from ..utils.dump import dump_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert compare_ast(tree, '''
        def foo(x):
            return unicode(x)
    ''')

# Generated at 2022-06-18 00:36:33.514047
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees


# Generated at 2022-06-18 00:36:42.205008
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)

    expected_source = source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

    assert tree_to_str(tree) == expected_source

# Generated at 2022-06-18 00:37:02.261818
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a, b):
            return str(a) + str(b)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a, b):
            return unicode(a) + unicode(b)
    """)

# Generated at 2022-06-18 00:37:07.618564
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    tree = ast.parse('str')
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"

# Generated at 2022-06-18 00:37:13.428790
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    from ..utils.ast_builder import build_ast
    from ..utils.tree import find
    from ..utils.source import generate_source

    source = '''
    def foo(x):
        return str(x)
    '''

    tree = build_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert generate_source(tree) == '''
    def foo(x):
        return unicode(x)
    '''

# Generated at 2022-06-18 00:37:17.663192
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Test the constructor of class StringTypesTransformer
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)


# Generated at 2022-06-18 00:37:20.945181
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:37:27.236759
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)
    assert tree_to_str(result.tree) == tree_to_str(ast.parse(source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)))

# Generated at 2022-06-18 00:37:35.148112
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ..utils.source import generate_source
    from ..utils.source import generate_source

    tree = ast3.parse(
        generate_source(
            """
            def foo():
                return str()
            """
        )
    )

    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)

    assert generate_source(new_tree) == generate_source(
        """
        def foo():
            return unicode()
        """
    )

# Generated at 2022-06-18 00:37:38.741305
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(a: str):
            return a
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:37:41.842084
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """
    a = str()
    """
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(new_tree.tree).strip() == "a = unicode()"

# Generated at 2022-06-18 00:37:49.498312
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source1 = """
    def foo(a):
        return str(a)
    """
    source2 = """
    def foo(a):
        return unicode(a)
    """
    tree1 = source_to_tree(source1)
    tree2 = source_to_tree(source2)
    tree3 = run_transformer(StringTypesTransformer, tree1)
    assert compare_trees(tree2, tree3)

# Generated at 2022-06-18 00:38:20.297719
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast, ast_to_source
    from ..utils.tree import find

    source = """
        def foo(x):
            return str(x)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    source = ast_to_source(tree)

    assert source == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:38:22.602914
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:38:28.012915
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeCounter

    source = source_to_unicode("""
    def foo(x: str):
        return x
    """)

    tree = ast.parse(source)
    assert NodeCounter(ast.Name).visit(tree) == 2

    tree = StringTypesTransformer.transform(tree)
    assert NodeCounter(ast.Name).visit(tree) == 2

    assert tree_to_str(tree) == """
    def foo(x: unicode):
        return x
    """

# Generated at 2022-06-18 00:38:29.914710
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str(1)', 'unicode(1)')

# Generated at 2022-06-18 00:38:35.359667
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:38:39.864511
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    a = str()
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    a = unicode()
    """

# Generated at 2022-06-18 00:38:46.375860
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    assert StringTypesTransformer.transform(ast.parse('str')) == TransformationResult(ast.parse('unicode'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str')) != TransformationResult(ast.parse('str'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str')) != TransformationResult(ast.parse('unicode'), False, [])
    assert StringTypesTransformer.transform(ast.parse('str')) != TransformationResult(ast.parse('str'), False, [])

# Generated at 2022-06-18 00:38:52.781321
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..types import TransformationResult

    code = """
    def foo(bar):
        return str(bar)
    """

    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:38:56.481718
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src

    tree = ast.parse('str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert to_src(tree) == 'unicode(1)'

# Generated at 2022-06-18 00:39:01.362456
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(a):
            return str(a)
    ''')

    new_tree = StringTypesTransformer.transform(tree)

    assert compare_trees(new_tree, '''
        def foo(a):
            return unicode(a)
    ''')

# Generated at 2022-06-18 00:40:13.532598
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:40:17.885232
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:40:25.025444
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        StringTypesTransformer,
        'str',
        'unicode'
    )

    assert_transformation(
        StringTypesTransformer,
        'a = str',
        'a = unicode'
    )

    assert_transformation(
        StringTypesTransformer,
        'def foo(a: str): pass',
        'def foo(a: unicode): pass'
    )

    assert_transformation(
        StringTypesTransformer,
        'def foo(a: str = "bar"): pass',
        'def foo(a: unicode = "bar"): pass'
    )
