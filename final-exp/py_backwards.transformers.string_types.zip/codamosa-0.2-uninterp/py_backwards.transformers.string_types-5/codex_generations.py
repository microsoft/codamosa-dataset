

# Generated at 2022-06-18 00:30:33.377194
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-18 00:30:42.846780
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
    def foo(x):
        return str(x)
    '''

    expected_tree = source_to_tree('''
    def foo(x):
        return unicode(x)
    ''')

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:30:45.125815
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees


# Generated at 2022-06-18 00:30:49.893831
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.run_pipeline(tree)

    assert tree == source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

# Generated at 2022-06-18 00:30:56.747093
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert new_tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:31:02.998965
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:31:06.568653
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:31:10.136160
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(x):
            return str(x)
    """

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:31:15.928680
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    expected_tree = source_to_ast(source.replace('str', 'unicode'))
    tree = source_to_ast(source)

    new_tree, _ = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:31:17.515447
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:30.722527
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    expected_ast = """
    Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """

    tree = source_to_ast(source)
    new_tree = run

# Generated at 2022-06-18 00:31:40.107991
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_node
    from ..utils.visitor import visit_and_replace_node

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    print(tree_to_str(tree))
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:31:46.268376
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a: str):
        pass
    """
    expected = """
    def foo(a: unicode):
        pass
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:31:51.595230
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_unicode
    from ..utils.visitor import TreeCopyVisitor

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    tree_copy = TreeCopyVisitor().visit(tree)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed
    assert node_to_unicode(tree) == node_to_unicode(tree_copy)

# Generated at 2022-06-18 00:31:55.255088
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(bar):
            return str(bar)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(bar):
            return unicode(bar)
    """

# Generated at 2022-06-18 00:32:02.550209
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name, ast_str

    tree = ast_call(
        func=ast_name(id='print'),
        args=[
            ast_str(s='Hello, world!')
        ]
    )

    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'print(u\'Hello, world!\')'

# Generated at 2022-06-18 00:32:08.186210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(s: str):
        pass
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.tree_changed
    assert tree.messages == []
    assert ast.dump(tree.new_tree) == ast.dump(source_to_ast("""
    def foo(s: unicode):
        pass
    """))

# Generated at 2022-06-18 00:32:16.131320
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree_before = source_to_tree('''
        def foo(a: str):
            return a
    ''')

    tree_after = source_to_tree('''
        def foo(a: unicode):
            return a
    ''')

    transformer = StringTypesTransformer()
    result = transformer.transform(tree_before)
    assert compare_trees(result.tree, tree_after)

# Generated at 2022-06-18 00:32:24.813734
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.ast_factory import ast_factory

    tree = ast_factory('''
    def foo(a: str):
        pass
    ''', mode='exec')

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert to_src(result.tree) == '''
    def foo(a: unicode):
        pass
    '''
    assert result.tree_changed is True
    assert result.messages == []

# Generated at 2022-06-18 00:32:30.314286
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.source import source_to_ast

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert astor.to_source(new_tree) == """
    def foo(a):
        return unicode(a)
    """

# Generated at 2022-06-18 00:32:40.530777
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:32:48.388231
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x: str):
            return x
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x: unicode):
            return x
    """)

# Generated at 2022-06-18 00:32:48.978339
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:53.741245
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = '''
    def foo(x):
        return str(x)
    '''
    tree = ast.parse(source_to_unicode(source))
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == '''
    def foo(x):
        return unicode(x)
    '''

# Generated at 2022-06-18 00:32:59.489609
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        if isinstance(bar, str):
            return bar
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body[0].test.args[1].id == 'unicode'

# Generated at 2022-06-18 00:33:05.687145
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:33:12.194933
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(a: str):
            return a
    """
    expected = """
        def foo(a: unicode):
            return a
    """

    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(new_tree.tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:33:17.708632
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    a = str(1)
    """

    expected_source = """
    a = unicode(1)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected_source))

# Generated at 2022-06-18 00:33:19.696885
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test that the constructor works
    StringTypesTransformer()


# Generated at 2022-06-18 00:33:24.562476
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    a = str(b)
    """
    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert ast.dump(new_tree) == ast.dump(source_to_ast("""
    a = unicode(b)
    """))

# Generated at 2022-06-18 00:33:36.295282
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def func(a: str):
            pass
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def func(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:33:40.610168
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(x):
        return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:33:43.109781
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for class constructor
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)


# Generated at 2022-06-18 00:33:49.526465
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)

    assert compare_trees(tree, """
    def foo(a):
        return unicode(a)
    """)

# Generated at 2022-06-18 00:33:53.866158
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(bar):
        return str(bar)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:34:00.366047
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    expected_tree = source_to_tree('''
        def foo(bar):
            return unicode(bar)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:34:05.709757
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    code = """
    def foo(x):
        return str(x)
    """

    expected_code = """
    def foo(x):
        return unicode(x)
    """

    assert_transformation_result(StringTypesTransformer, code, expected_code)

# Generated at 2022-06-18 00:34:11.923919
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast

    code = '''
        def foo(a):
            return str(a)
    '''

    expected_code = '''
        def foo(a):
            return unicode(a)
    '''

    tree = parse_ast(code)
    result = StringTypesTransformer.transform(tree)
    assert_transformation_result(result, expected_code)

# Generated at 2022-06-18 00:34:15.072333
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        StringTypesTransformer,
        'str',
        'unicode'
    )

# Generated at 2022-06-18 00:34:20.027393
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet

    snippet = load_example_snippet('string_types.py')
    expected_tree = load_example_snippet('string_types_expected.py')

    transformer = StringTypesTransformer()
    result = transformer.transform(snippet)

    assert_transformation_result(result, expected_tree, [])

# Generated at 2022-06-18 00:34:38.619210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(tree, new_tree)

# Generated at 2022-06-18 00:34:46.730999
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)))

# Generated at 2022-06-18 00:34:52.708726
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    tree = ast.parse("""
        def foo(bar: str) -> str:
            return bar
    """)

    expected_tree = ast.parse("""
        def foo(bar: unicode) -> unicode:
            return bar
    """)

    assert_transformation_result(StringTypesTransformer, tree, expected_tree)

# Generated at 2022-06-18 00:35:03.354990
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(s: str):
            return s
    """

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert isinstance(tree.body[0].args.args[0], ast.Name)
    assert tree.body[0].args.args[0].id == 's'
    assert isinstance(tree.body[0].args.args[0].annotation, ast.Name)
    assert tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:35:08.051586
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    code = '''
        def foo(x):
            return str(x)
    '''

    expected_code = '''
        def foo(x):
            return unicode(x)
    '''

    assert_transformation_result(StringTypesTransformer, code, expected_code)

# Generated at 2022-06-18 00:35:14.892394
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """

    expected = """
    def foo(a):
        return unicode(a)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:35:19.169610
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(a: unicode):
        pass
    """

# Generated at 2022-06-18 00:35:26.665461
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert astor.to_source(result.tree) == source.replace('str', 'unicode')

# Generated at 2022-06-18 00:35:30.308673
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    source = """
        def foo(x):
            return str(x)
    """
    expected_tree = """
        def foo(x):
            return unicode(x)
    """
    assert_transformation_result(StringTypesTransformer, source, expected_tree)

# Generated at 2022-06-18 00:35:37.797778
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    expected_tree = source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

    tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:36:10.176555
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_visitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    print_visitor(tree)

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert tree_to_str(result.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))

# Generated at 2022-06-18 00:36:16.758170
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str('bar')
    """

    expected_tree = source_to_ast(source)
    expected_tree.body[0].body[0].value.func.id = 'unicode'

    tree = source_to_ast(source)
    new_tree, changed = run_transformer(StringTypesTransformer, tree)

    assert changed
    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:36:22.111159
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree(
        """
        def foo(bar):
            return str(bar)
        """
    )

    tree = StringTypesTransformer.run_pipeline(tree)

    assert tree_to_str(tree) == """
        def foo(bar):
            return unicode(bar)
        """

# Generated at 2022-06-18 00:36:29.776923
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:36:32.641521
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_tree = source_to_tree("""
    def foo(x):
        return unicode(x)
    """)
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:36:39.611912
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def f(x):
        return str(x)
    """

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    from ..utils.source import ast_to_source

    source_transformed = ast_to_source(tree)

    assert source_transformed == """
    def f(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:36:45.862184
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str()
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
    def foo():
        return unicode()
    """)

# Generated at 2022-06-18 00:36:48.131011
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        StringTypesTransformer,
        '''
        def foo():
            return str(1)
        ''',
        '''
        def foo():
            return unicode(1)
        '''
    )

# Generated at 2022-06-18 00:36:57.054153
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a):
        return str(a)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
    def foo(a):
        return unicode(a)
    """)))

# Generated at 2022-06-18 00:37:04.798484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo(a: str):
            return a
    ''')

    expected_tree = source_to_tree('''
        def foo(a: unicode):
            return a
    ''')

    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(expected_tree, new_tree)

    assert tree_to_source(new_tree) == tree_to_source(expected_tree)

# Generated at 2022-06-18 00:37:58.816464
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:38:08.534210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    expected_ast = """
    Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='bar', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='bar', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """
    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.run_it(tree)
   

# Generated at 2022-06-18 00:38:13.931963
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)

    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert tree_to_str(new_tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a: unicode):
            pass
    """)))

# Generated at 2022-06-18 00:38:19.695517
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, """
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:38:25.269578
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = '''
        def foo(bar):
            return str(bar)
    '''

    expected_tree = source_to_ast('''
        def foo(bar):
            return unicode(bar)
    ''')

    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:38:30.513983
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(bar):
            return str(bar)
    """)

    tree = StringTypesTransformer.run_pipeline(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:38:35.389260
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:38:42.553116
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(bar):
        return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(bar):
        return unicode(bar)
    """)

# Generated at 2022-06-18 00:38:47.593161
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:38:52.145661
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(a: str):
        return a
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(a: unicode):
        return a
    """