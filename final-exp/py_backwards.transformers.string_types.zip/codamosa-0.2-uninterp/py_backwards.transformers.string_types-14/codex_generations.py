

# Generated at 2022-06-18 00:30:20.260333
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    expected = """
    def foo(x):
        return unicode(x)
    """
    tree = source_to_ast(source)
    new_tree, _, _ = StringTypesTransformer.transform(tree)
    assert astor.to_source(new_tree) == expected

# Generated at 2022-06-18 00:30:26.683931
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(bar):
            return str(bar)
    """

    expected = """
        def foo(bar):
            return unicode(bar)
    """

    tree = source_to_ast(source)
    new_tree, _ = StringTypesTransformer.transform(tree)
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:30:34.962349
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    tree_before = source_to_tree('''
        def foo(a):
            return str(a)
    ''')
    tree_after = source_to_tree('''
        def foo(a):
            return unicode(a)
    ''')
    transformer = StringTypesTransformer()
    tree_transformed = transformer.transform(tree_before)
    assert compare_trees(tree_after, tree_transformed)

# Generated at 2022-06-18 00:30:44.001745
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
    def foo(x: str):
        return x
    """)

    tree = ast.parse(source)
    tree = NodeTransformerVisitor(StringTypesTransformer).visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x: unicode):
        return x
    """)

# Generated at 2022-06-18 00:30:49.003873
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(a: str):
            pass
    ''')

    expected_tree = source_to_tree('''
        def foo(a: unicode):
            pass
    ''')

    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:30:59.442491
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast

    source = """
        def foo(a: str):
            return a
    """
    expected_tree = """
        Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=Name(id='unicode', ctx=Load()))], vararg=None, kwarg=None, defaults=[]), body=[Return(value=Name(id='a', ctx=Load()))], decorator_list=[])])
    """

    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)
    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-18 00:31:04.447246
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    x = str()
    """

    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert new_tree != tree
    assert new_tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:31:12.088360
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_tree = source_to_tree("""
    def foo(a):
        return unicode(a)
    """)

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:31:18.692474
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar: str):
        pass
    """

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    for node in find(tree, ast.Name):
        if node.id == 'str':
            assert False

    for node in find(tree, ast.Name):
        if node.id == 'unicode':
            assert True

# Generated at 2022-06-18 00:31:21.693828
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:29.887236
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    NodeTransformerVisitor(StringTypesTransformer).visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:31:41.245188
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """

    expected_ast = """
    Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='bar', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='bar', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """

    tree = source_to_ast(source)
    new_tree = run

# Generated at 2022-06-18 00:31:46.878159
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a: str):
        pass
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a: unicode):
        pass
    """)

# Generated at 2022-06-18 00:31:51.557424
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.source import source_to_ast

    source = """
        def foo(a: str):
            return a
    """
    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert astor.to_source(new_tree) == """
        def foo(a: unicode):
            return a
    """

# Generated at 2022-06-18 00:31:52.725611
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:58.392977
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(a: str):
            pass
    ''')

    transformer = StringTypesTransformer()
    new_tree, _ = transformer.transform(tree)

    assert new_tree == source_to_tree('''
        def foo(a: unicode):
            pass
    ''')

# Generated at 2022-06-18 00:32:02.683264
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src

    tree = ast.parse('str("hello")')
    tree = StringTypesTransformer.transform(tree)
    assert to_src(tree) == 'unicode("hello")'

# Generated at 2022-06-18 00:32:06.984495
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert tree_to_str(new_tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:32:08.279131
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:32:10.266381
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:16.710746
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree

    source = source_to_unicode("""
    x = str()
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:32:24.719031
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
        def foo(x):
            return str(x)
    '''
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, '''
        def foo(x):
            return unicode(x)
    ''')

# Generated at 2022-06-18 00:32:30.222518
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source('StringTypesTransformer.py')
    tree = get_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == get_source('StringTypesTransformer_result.py')

# Generated at 2022-06-18 00:32:34.470221
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo(bar):
            return str(bar)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(ast.parse("""
        def foo(bar):
            return unicode(bar)
    """))

# Generated at 2022-06-18 00:32:42.789244
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)

    expected_source = """
        def foo(x):
            return unicode(x)
    """
    expected_tree = source_to_tree(expected_source)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:32:49.920168
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:32:56.742406
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str()
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, """
    def foo():
        return unicode()
    """)

# Generated at 2022-06-18 00:33:01.498465
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:33:07.283296
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    a = str(1)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    a = unicode(1)
    """)

# Generated at 2022-06-18 00:33:12.920056
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
        """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(x):
            return unicode(x)
        """

# Generated at 2022-06-18 00:33:22.776600
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_tree = source_to_tree("""
    def foo(bar):
        return unicode(bar)
    """)

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:33:27.839156
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = '''
        def foo(bar):
            return str(bar)
    '''

    tree = ast.parse(source_to_unicode(source))
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed is True
    assert tree_to_str(new_tree) == tree_to_str(ast.parse('''
        def foo(bar):
            return unicode(bar)
    '''))

# Generated at 2022-06-18 00:33:30.002981
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:33:34.949382
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(bar):
        return str(bar)
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse("""
    def foo(bar):
        return unicode(bar)
    """))

# Generated at 2022-06-18 00:33:40.349310
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    import textwrap
    source = textwrap.dedent('''
        def foo(x):
            return str(x)
    ''')
    tree = astor.parse_file(source)
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == textwrap.dedent('''
        def foo(x):
            return unicode(x)
    ''')

# Generated at 2022-06-18 00:33:47.658928
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
    def foo(bar):
        return str(bar)
    '''

    expected_tree = source_to_tree('''
    def foo(bar):
        return unicode(bar)
    ''')

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:33:54.743428
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_tree = source_to_tree("""
        def foo(bar):
            return unicode(bar)
    """)

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:34:02.523107
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a: str):
            return a
    """

    expected = """
        def foo(a: unicode):
            return a
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:34:07.236508
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(x):
        return str(x)
    """)

    t = StringTypesTransformer()
    new_tree = t.visit(tree)

    assert new_tree != tree
    assert new_tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:34:09.309552
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:34:18.255954
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo():
            return str('foo')
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []

# Generated at 2022-06-18 00:34:24.610483
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    a = str(1)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree.tree) == source_to_unicode("""
    a = unicode(1)
    """)

# Generated at 2022-06-18 00:34:30.591181
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    new_tree, tree_changed, messages = StringTypesTransformer.transform(tree)
    new_source = astor.to_source(new_tree)

    assert tree_changed
    assert new_source == source.replace('str', 'unicode')

# Generated at 2022-06-18 00:34:39.157170
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    # Given
    code = """
        def foo(x):
            return str(x)
    """
    expected_code = """
        def foo(x):
            return unicode(x)
    """
    tree = ast.parse(code)

    # When
    result = StringTypesTransformer.transform(tree)

    # Then
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-18 00:34:40.101211
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:34:45.196502
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo(a):
            return str(a)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
        def foo(a):
            return unicode(a)
    """))

# Generated at 2022-06-18 00:34:53.591028
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:34:59.449020
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, source_to_tree("""
    def foo(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:35:04.542258
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(x):
            return str(x)
    """

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:35:09.471854
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse
    from ..utils.source import source

    tree = parse(source('''
        def foo(bar):
            return str(bar)
    '''))

    tree = StringTypesTransformer.run(tree)

    assert source(tree) == source('''
        def foo(bar):
            return unicode(bar)
    ''')

# Generated at 2022-06-18 00:35:22.360506
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:35:28.021187
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:35:35.478822
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert new_tree != tree
    assert new_tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:35:38.991286
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:35:48.908094
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    tree = ast.parse('str')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"

    # Test 2
    tree = ast.parse('str(1)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == "Module(body=[Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[]))])"

    # Test 3

# Generated at 2022-06-18 00:35:54.767335
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:36:00.969396
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    new_tree, tree_changed, messages = StringTypesTransformer.transform(tree)

    assert tree_changed
    assert len(messages) == 0
    assert astor.to_source(new_tree) == source.replace('str', 'unicode')

# Generated at 2022-06-18 00:36:01.435833
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:36:08.080471
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo():
            return str('foo')
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo():
            return unicode('foo')
    """)

# Generated at 2022-06-18 00:36:14.814332
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(x):
            return str(x)
    """

    expected = """
        def foo(x):
            return unicode(x)
    """

    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:36:45.335915
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source('StringTypesTransformer.py')
    tree = get_ast(source)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed == True
    assert astor.to_source(result.tree) == source.replace('str', 'unicode')

# Generated at 2022-06-18 00:36:51.128526
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..types import TransformationResult
    from .base import BaseTransformer

    class StringTypesTransformer(BaseTransformer):
        """Replaces `str` with `unicode`. 

        """
        target = (2, 7)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            tree_changed = False

            for node in find(tree, ast.Name):
                if node.id == 'str':
                    node.id = 'unicode'
                    tree_changed = True

            return TransformationResult(tree, tree_changed, [])

    code = '''
    def foo(a: str):
        return a
    '''

    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)


# Generated at 2022-06-18 00:36:56.109491
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:37:01.292415
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo():
            return str()
    ''')

    tree = StringTypesTransformer.run_pipeline(tree)

    assert tree_to_str(tree) == '''
        def foo():
            return unicode()
    '''

# Generated at 2022-06-18 00:37:07.900813
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(a: str):
            pass
    ''')

    new_tree = StringTypesTransformer.transform(tree)

    assert compare_trees(new_tree.tree, source_to_tree('''
        def foo(a: unicode):
            pass
    '''))

# Generated at 2022-06-18 00:37:13.698107
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert ast.dump(tree) == ast.dump(source_to_ast("""
    def foo(bar):
        return unicode(bar)
    """))

# Generated at 2022-06-18 00:37:20.734763
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:37:25.156063
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:37:35.270713
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_builder import build_ast
    tree = build_ast("""
    a = str()
    b = str(1)
    c = str(1, 2)
    d = str(1, 2, 3)
    """)
    expected_tree = build_ast("""
    a = unicode()
    b = unicode(1)
    c = unicode(1, 2)
    d = unicode(1, 2, 3)
    """)
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == astor.to_source(expected_tree)
    assert result.tree_changed == True
    assert result.warnings == []

# Generated at 2022-06-18 00:37:40.725700
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_source = """
    def foo(a):
        return unicode(a)
    """
    expected_tree = source_to_tree(expected_source)
    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:38:36.579978
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:38:46.375870
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
        def foo(bar):
            return unicode(bar)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:38:49.567099
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:38:55.247975
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:38:56.627433
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    # Given

# Generated at 2022-06-18 00:39:01.231084
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)
    assert compare_ast(tree, """
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:39:11.093793
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str')) == TransformationResult(ast.parse('unicode'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str(1)')) == TransformationResult(ast.parse('unicode(1)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str(1, 2)')) == TransformationResult(ast.parse('unicode(1, 2)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str(1, 2, 3)')) == TransformationResult(ast.parse('unicode(1, 2, 3)'), True, [])

# Generated at 2022-06-18 00:39:15.653793
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, """
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:39:23.992484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.ast_factory import ast_factory
    from .base import BaseTransformer
    from .string_types import StringTypesTransformer
    from ..types import TransformationResult

    # Test 1:
    # Input:
    #   print(str(1))
    # Output:
    #   print(unicode(1))
    tree = ast.parse("print(str(1))")
    tree_changed, messages = StringTypesTransformer.transform(tree)
    assert to_src(tree) == "print(unicode(1))"
    assert tree_changed == True
    assert messages == []

    # Test 2:
    # Input:
    #   print(str(1) + str(2))
    # Output:


# Generated at 2022-06-18 00:39:30.464474
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(1)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        a = unicode(1)
    """)