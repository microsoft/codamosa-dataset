

# Generated at 2022-06-18 00:30:34.902413
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def f(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, source_to_tree("""
    def f(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:30:42.626580
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    a = str(1)
    """
    expected = """
    a = unicode(1)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(tree, StringTypesTransformer)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:30:48.235750
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert new_tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:30:57.586578
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)

    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)))

# Generated at 2022-06-18 00:31:07.393602
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def func(a: str):
        pass
    """

    expected_ast = """
    Module(body=[FunctionDef(name='func', args=arguments(args=[arg(arg='a', annotation=Name(id='unicode', ctx=Load()))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])
    """

    ast = source_to_ast(source)
    new_ast = run_transformer(StringTypesTransformer, ast)
    assert compare_ast(expected_ast, new_ast)

# Generated at 2022-06-18 00:31:11.491523
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(a: unicode):
        return a
    """

# Generated at 2022-06-18 00:31:12.915696
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:31:14.508001
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:31:20.304534
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:31:26.062463
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(a):
        return str(a)
    """)

    transformed, _ = StringTypesTransformer.transform(tree)

    assert transformed.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:31:31.444618
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    x = str(1)
    """
    expected = """
    x = unicode(1)
    """
    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:31:40.290959
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import TreeCopyVisitor

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)

    tree = ast.parse(source)
    visitor = TreeCopyVisitor()
    visitor.visit(tree)
    tree_copy = visitor.get_tree_copy()

    assert StringTypesTransformer.transform(tree) == TransformationResult(tree, True, [])
    assert tree_to_str(tree) == tree_to_str(tree_copy)

# Generated at 2022-06-18 00:31:45.785640
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    a = str(1)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_ast(new_tree, """
    a = unicode(1)
    """)

# Generated at 2022-06-18 00:31:49.871741
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:31:55.601081
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
    def foo(x: str):
        return x
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x: unicode):
        return x
    """)

# Generated at 2022-06-18 00:32:02.144898
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, """
    def foo(bar):
        return unicode(bar)
    """)

# Generated at 2022-06-18 00:32:06.627744
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast

    code = """
    def foo(x):
        return str(x)
    """
    tree = get_ast(code)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed

# Generated at 2022-06-18 00:32:13.951201
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:32:17.865127
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse
    from ..utils.source import source

    tree = parse(source('''
        def foo(bar):
            return str(bar)
    '''))

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert source(result.tree) == source('''
        def foo(bar):
            return unicode(bar)
    ''')

# Generated at 2022-06-18 00:32:19.185976
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:32:26.799343
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(x):
            return str(x)
    """

    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert result.messages == []

    assert result.tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:32:32.161595
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.source import source_to_tree

    source = """
    def foo(bar):
        return str(bar)
    """

    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:32:37.719105
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:32:42.838501
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find

    code = """
    def foo(a):
        return str(a)
    """

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == """
    def foo(a):
        return unicode(a)
    """

# Generated at 2022-06-18 00:32:51.285817
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:32:55.025896
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:32:59.330563
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(bar: str):
        pass
    """)

    tree = StringTypesTransformer.run_pipeline(tree)

    assert tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:33:04.682878
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:33:12.865065
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    expected_tree = source_to_tree("""
    def foo(x):
        return unicode(x)
    """)
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:33:22.777303
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = '''
        def foo(x):
            return str(x)
    '''
    expected_ast = '''
        Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    '''
    tree = source_to_ast(source)

# Generated at 2022-06-18 00:33:35.223758
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    a = str()
    b = str(1)
    c = str(1, 2)
    d = str(1, 2, 3)
    """

    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)

    expected_source = """
    a = unicode()
    b = unicode(1)
    c = unicode(1, 2)
    d = unicode(1, 2, 3)
    """

    expected_tree = source_to_tree(expected_source)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:33:42.090964
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.ast_factory import ast_factory

    tree = ast_factory(
        '''
        def foo(x):
            return str(x)
        '''
    )

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert to_src(result.tree) == to_src(
        ast_factory(
            '''
            def foo(x):
                return unicode(x)
            '''
        )
    )

# Generated at 2022-06-18 00:33:46.809880
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(bar):
            return str(bar)
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(bar):
            return unicode(bar)
    """

# Generated at 2022-06-18 00:33:51.361053
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        a = str(1)
    """
    expected_code = """
        a = unicode(1)
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert ast.dump(result.tree) == expected_code

# Generated at 2022-06-18 00:33:56.806643
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert astor.to_source(new_tree) == source.replace('str', 'unicode')

# Generated at 2022-06-18 00:33:59.220904
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:34:04.550873
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(a: str):
            return a
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        def foo(a: unicode):
            return a
    '''

# Generated at 2022-06-18 00:34:07.005014
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from astor.code_gen import to_source
    from ..utils.ast_helper import generate_ast


# Generated at 2022-06-18 00:34:15.021901
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert tree_to_str(new_tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))

# Generated at 2022-06-18 00:34:18.458311
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo():
            x = str()
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo():
            x = unicode()
    """

# Generated at 2022-06-18 00:34:30.812136
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """
    expected = """
        def foo(bar):
            return unicode(bar)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:34:35.836608
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-18 00:34:41.792545
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(bar):
            return str(bar)
    """)

    assert StringTypesTransformer.transform(tree).tree == source_to_ast("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:34:46.731446
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def f(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def f(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:34:48.098814
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:34:52.909913
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x: str):
            return x
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x: unicode):
            return x
    """

# Generated at 2022-06-18 00:34:56.561728
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
a = str(1)
b = str()
c = str
""")
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
a = unicode(1)
b = unicode()
c = unicode
"""

# Generated at 2022-06-18 00:35:07.632018
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    x = str(1)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
    x = unicode(1)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
    x = str(1)
    """
    tree = source_to_tree(source)

# Generated at 2022-06-18 00:35:12.640810
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    a = str()
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    a = unicode()
    """)

# Generated at 2022-06-18 00:35:14.227115
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:35:32.225243
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.visitor import NodeTransformer

    class TestTransformer(NodeTransformer):
        def visit_Name(self, node):
            if node.id == 'str':
                node.id = 'unicode'
            return node

    tree = ast.parse('str')
    tree = StringTypesTransformer.transform(tree)
    assert to_src(tree) == 'unicode'

    tree = ast.parse('str')
    tree = TestTransformer().visit(tree)
    assert to_src(tree) == 'unicode'

# Generated at 2022-06-18 00:35:37.269487
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    tree = ast.parse("""
        def foo(x):
            return str(x)
    """)

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []

    assert result.tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:35:43.800814
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        x = str(1)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        x = unicode(1)
    """)))

# Generated at 2022-06-18 00:35:49.747390
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import TreeCopyVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree_copy = TreeCopyVisitor().visit(tree)

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert tree_to_str(result.tree) == tree_to_str(tree_copy)

# Generated at 2022-06-18 00:35:53.732938
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:36:02.723771
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        x = str()
    """
    expected_ast = """
        Module(body=[
            Assign(
                targets=[Name(id='x', ctx=Store())],
                value=Call(
                    func=Name(id='unicode', ctx=Load()),
                    args=[],
                    keywords=[]
                )
            )
        ])
    """
    ast = source_to_ast(source)
    new_ast = run_transformer(StringTypesTransformer, ast)
    assert compare_ast(ast, new_ast) == True

# Generated at 2022-06-18 00:36:09.252084
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:36:16.544378
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import NodeVisitor

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)

    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:36:22.268569
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(x):
            return str(x)
    """

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert tree.body[0].body.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:36:28.097785
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(a):
        return str(a)
    """)
    assert StringTypesTransformer.transform(tree).tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse("""
    def foo(a):
        return unicode(a)
    """))

# Generated at 2022-06-18 00:36:57.744057
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.run_pipeline(tree)

    assert tree_to_str(tree) == '''
        def foo(x):
            return unicode(x)
    '''

# Generated at 2022-06-18 00:37:02.225844
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        x = str(1)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == "x = unicode(1)"

# Generated at 2022-06-18 00:37:03.000582
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:37:10.659232
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x: str):
        pass
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert ast.dump(tree) == ast.dump(source_to_ast("""
    def foo(x: unicode):
        pass
    """))

# Generated at 2022-06-18 00:37:19.065484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)))

# Generated at 2022-06-18 00:37:25.409884
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """
    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)

    new_tree, _ = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:37:28.298053
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str')
    tree = StringTypesTransformer.transform(tree).tree
    assert ast.dump(tree) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"

# Generated at 2022-06-18 00:37:36.479112
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer
    from ..utils.dump import dump_tree

    source = """
        def foo(a):
            return str(a)
    """
    expected = """
        def foo(a):
            return unicode(a)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:37:42.319971
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    tree = StringTypesTransformer.transform(tree)
    assert(len(find(tree, ast.Name)) == 1)
    assert(find(tree, ast.Name)[0].id == 'unicode')

# Generated at 2022-06-18 00:37:49.909209
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))

# Generated at 2022-06-18 00:38:46.026281
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(x):
            return str(x)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0
    assert ast.dump(tree) == ast.dump(source_to_ast("""
        def foo(x):
            return unicode(x)
    """))

# Generated at 2022-06-18 00:38:49.890665
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)))

# Generated at 2022-06-18 00:38:54.957698
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    a = str()
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"

# Generated at 2022-06-18 00:39:00.311477
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:39:06.567383
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(a):
        return str(a)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(a):
        return unicode(a)
    """))

# Generated at 2022-06-18 00:39:10.582531
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def f(x):
        return str(x)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def f(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:39:15.244326
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)

    assert compare_trees(tree, """
    def foo(a):
        return unicode(a)
    """)

# Generated at 2022-06-18 00:39:18.820972
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        a = str(b)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:39:22.322040
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:39:28.722167
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_module_transformations

    source = """
    def foo():
        return str(1)
    """

    tree = source_to_tree(source)
    tree = run_module_transformations(tree, [StringTypesTransformer])

    assert compare_trees(tree, source_to_tree("""
    def foo():
        return unicode(1)
    """))