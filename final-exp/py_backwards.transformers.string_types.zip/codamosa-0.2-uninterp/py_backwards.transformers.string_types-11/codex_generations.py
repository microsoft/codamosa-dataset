

# Generated at 2022-06-18 00:30:36.378743
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that the StringTypesTransformer class correctly replaces `str` with `unicode`.
    """
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.tree import find
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    StringTypesTransformer.transform(tree)
    source_transformed = astor.to_source(tree)
    tree_transformed = get_ast(source_transformed)
    assert len(find(tree_transformed, ast.Name)) == 1
    assert find(tree_transformed, ast.Name)[0].id == 'unicode'

# Generated at 2022-06-18 00:30:43.167261
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str(1)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, """
    def foo():
        return unicode(1)
    """)

# Generated at 2022-06-18 00:30:44.353363
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:30:46.814321
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == 'unicode(1)'

# Generated at 2022-06-18 00:30:51.684268
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar: str):
            return bar
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar: unicode):
            return bar
    """)

# Generated at 2022-06-18 00:30:56.870954
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_unicode

    source = source_to_unicode("""
        str
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert node_to_unicode(tree.body[0]) == 'unicode'

# Generated at 2022-06-18 00:31:04.647611
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str()
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed is True
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode()
    """)))

# Generated at 2022-06-18 00:31:14.001189
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find

    tree = ast.parse("""
    def f(x):
        return str(x)
    """)

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert astor.to_source(result.tree) == """
    def f(x):
        return unicode(x)
    """

    # Test that the transformer is idempotent
    result2 = transformer.transform(result.tree)
    assert not result2.tree_changed
    assert result2.messages == []
    assert astor.to_source(result2.tree) == """
    def f(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:31:18.690901
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformed_code_equals
    assert_transformed_code_equals(
        StringTypesTransformer,
        """
        def foo(x):
            return str(x)
        """,
        """
        def foo(x):
            return unicode(x)
        """
    )

# Generated at 2022-06-18 00:31:27.205631
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, """
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:31:36.118478
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet

    snippet = load_example_snippet('string_types.py')
    expected = load_example_snippet('string_types_expected.py')

    assert_transformation_result(StringTypesTransformer, snippet, expected)

# Generated at 2022-06-18 00:31:45.950304
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeCounter
    from ..utils.visitor import NodeFinder
    from ..utils.visitor import NodeReplacer
    from ..utils.visitor import NodeTransformer
    from ..utils.visitor import NodeVisitor
    from ..utils.visitor import VisitorFilter
    from ..utils.visitor import VisitorRunner
    from ..utils.visitor import VisitorRunnerFilter
    from ..utils.visitor import VisitorRunnerTransformer
    from ..utils.visitor import VisitorTransformer
    from ..utils.visitor import VisitorTransformerFilter
    from ..utils.visitor import VisitorTransformerRunner
    from ..utils.visitor import VisitorTransformerRunnerFilter

# Generated at 2022-06-18 00:31:50.486462
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:31:51.371660
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:53.760908
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(a: str):
            pass
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []

# Generated at 2022-06-18 00:31:58.671874
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
    def foo(x):
        return str(x)
    ''')

    new_tree = StringTypesTransformer.transform(tree)
    assert compare_trees(new_tree.tree, source_to_tree('''
    def foo(x):
        return unicode(x)
    '''))
    assert new_tree.tree_changed
    assert new_tree.warnings == []

# Generated at 2022-06-18 00:32:04.029649
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    code = '''
        def foo(x):
            return str(x)
    '''

    expected_code = '''
        def foo(x):
            return unicode(x)
    '''

    assert_transformation_result(
        StringTypesTransformer,
        code,
        expected_code
    )

# Generated at 2022-06-18 00:32:05.293205
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:07.406135
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("str('abc')")) == TransformationResult(ast.parse("unicode('abc')"), True, [])

# Generated at 2022-06-18 00:32:14.703978
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:32:24.622820
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:32:30.496626
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:32:39.320433
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(a, b):
            return str(a) + str(b)
    """)

    tree = ast.parse(source)
    tree = NodeTransformerVisitor(StringTypesTransformer).visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a, b):
            return unicode(a) + unicode(b)
    """)

# Generated at 2022-06-18 00:32:41.890659
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find

    source = """
    def foo(a: str):
        return a
    """
    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.messages) == 0

# Generated at 2022-06-18 00:32:49.069319
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast

    source = """
    def foo(a: str):
        return a
    """
    expected = """
    def foo(a: unicode):
        return a
    """
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:32:55.583948
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name

    # Test 1: Test that the transformer replaces str with unicode
    tree = ast_call(ast_name('str'), [ast_name('x')])
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'unicode(x)'

    # Test 2: Test that the transformer does not replace str if it is not a function call
    tree = ast_name('str')
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'str'

# Generated at 2022-06-18 00:32:56.923261
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:33:05.063161
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])"

# Generated at 2022-06-18 00:33:12.325358
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    expected = """
    def foo(x):
        return unicode(x)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:33:13.586931
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:33:25.638374
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert tree_to_str(new_tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)))

# Generated at 2022-06-18 00:33:28.825047
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(a: str):
            return a
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(a: unicode):
            return a
    """

# Generated at 2022-06-18 00:33:35.899879
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    a = str()
    """

    expected_tree = source_to_tree(source)
    expected_tree.body[0].value.func.id = 'unicode'

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:33:41.646563
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    expected = """
    def foo(x):
        return unicode(x)
    """
    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:33:49.574817
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:33:56.579504
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = '''
    def foo(bar):
        return str(bar)
    '''
    tree = source_to_ast(source)
    print_ast(tree)
    result = StringTypesTransformer.transform(tree)
    print_ast(result.tree)
    assert ast_to_source(result.tree) == '''
    def foo(bar):
        return unicode(bar)
    '''

# Generated at 2022-06-18 00:33:59.406096
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str("test")', 'unicode("test")')

# Generated at 2022-06-18 00:34:05.487812
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(a: str):
            pass
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.tree_changed
    assert tree.messages == []

    assert tree.tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:34:16.049264
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find_all

    code = """
    def foo(a):
        return str(a)
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.messages) == 0
    assert astor.to_source(result.tree) == """
    def foo(a):
        return unicode(a)
    """

    code = """
    def foo(a):
        return str(a)
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.messages) == 0

# Generated at 2022-06-18 00:34:21.976167
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast

    source = '''
    def foo(a):
        return str(a)
    '''

    expected_source = '''
    def foo(a):
        return unicode(a)
    '''

    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert compare_ast(new_tree.tree, source_to_ast(expected_source))

# Generated at 2022-06-18 00:34:44.902343
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.tree import find_all

    source = """
    def foo(x):
        return str(x)
    """

    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, source_to_tree(source)) == True

    source = """
    def foo(x):
        return unicode(x)
    """

    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, source_to_tree(source)) == True

    source = """
    def foo(x):
        return str(x)
    """

    tree = source_

# Generated at 2022-06-18 00:34:52.566950
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, """
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:35:00.948814
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.visitor import NodeTransformer

    class TestTransformer(NodeTransformer):
        def visit_Name(self, node):
            if node.id == 'str':
                node.id = 'unicode'
            return node

    tree = ast.parse('str("abc")')
    tree = StringTypesTransformer.transform(tree)
    assert to_src(tree) == 'unicode("abc")'

    tree = ast.parse('str("abc")')
    tree = TestTransformer().visit(tree)
    assert to_src(tree) == 'unicode("abc")'

# Generated at 2022-06-18 00:35:08.266787
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(s: str):
        pass
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:35:13.777304
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = get_ast(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(new_tree) == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:35:18.126737
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:35:24.953393
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, """
    def foo(a: unicode):
        return a
    """)

# Generated at 2022-06-18 00:35:32.921053
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    expected_ast = """
    Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """

    tree = source_to_ast(source)

# Generated at 2022-06-18 00:35:38.204360
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:35:45.769497
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_str
    from ..utils.visitor import NodeTransformer

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert node_to_str(tree) == node_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))

# Generated at 2022-06-18 00:36:15.439935
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, """
    def foo(a: unicode):
        return a
    """)

# Generated at 2022-06-18 00:36:17.853547
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    tree = ast.parse("""
    a = str()
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    a = unicode()
    """

# Generated at 2022-06-18 00:36:22.754527
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x: str):
        return x
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x: unicode):
        return x
    """)

# Generated at 2022-06-18 00:36:32.150508
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(a: str):
        return a
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=Name(id='unicode', ctx=Load()))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Name(id='a', ctx=Load()))], decorator_list=[], returns=None)])"

# Generated at 2022-06-18 00:36:33.514747
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:36:41.793313
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a: str) -> str:
            return a
    """

    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)

    expected_source = """
        def foo(a: unicode) -> unicode:
            return a
    """

    expected_tree = source_to_tree(expected_source)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:36:49.929941
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeCounter
    from ..utils.visitor import NodeFinder

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)
    assert NodeCounter.count(tree, ast.Name) == 3
    assert NodeFinder.find(tree, ast.Name, id='unicode') is not None
    assert NodeFinder.find(tree, ast.Name, id='str')

# Generated at 2022-06-18 00:36:54.228613
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result

    code = '''
    def foo(x):
        return str(x)
    '''

    expected_code = '''
    def foo(x):
        return unicode(x)
    '''

    assert_transformation_result(StringTypesTransformer, code, expected_code)

# Generated at 2022-06-18 00:37:04.108784
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    from ..utils.tree import ast_from_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_source
    from ..utils.tree import ast_to_source_code
    from ..utils.tree import ast_to_source_code_with_comments
    from ..utils.tree import ast_to_source_code_with_comments_and_newlines
    from ..utils.tree import ast_to_source_code_with_newlines
    from ..utils.tree import ast_to_source_with_comments
    from ..utils.tree import ast_to_source_with_comments_and_newlines
    from ..utils.tree import ast_to_source_with_newlines
    from ..utils.tree import ast_to_source_with_newlines_and_

# Generated at 2022-06-18 00:37:09.749894
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def func(a: str):
        pass
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.code == """
    def func(a: unicode):
        pass
    """

# Generated at 2022-06-18 00:38:07.495279
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a: unicode):
            pass
    """)))

# Generated at 2022-06-18 00:38:13.411525
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode('''
        def foo(x):
            return str(x)
    ''')
    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode('''
        def foo(x):
            return unicode(x)
    ''')

# Generated at 2022-06-18 00:38:18.821131
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a):
        return str(a)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a):
        return unicode(a)
    """)

# Generated at 2022-06-18 00:38:23.771241
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """
    expected = """
        def foo(a):
            return unicode(a)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:38:30.162065
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:38:37.184118
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer
    from ..utils.source import source_to_ast

    source = '''
    def foo(a: str):
        return a
    '''
    expected_source = '''
    def foo(a: unicode):
        return a
    '''
    tree = source_to_ast(source)
    new_tree = run_transformer(tree, StringTypesTransformer)
    expected_tree = source_to_ast(expected_source)
    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:38:42.948325
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(bar):
        return str(bar)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(bar):
        return unicode(bar)
    """))

# Generated at 2022-06-18 00:38:48.410526
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(x: str):
            pass
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x: unicode):
            pass
    """)

# Generated at 2022-06-18 00:38:57.823875
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test case 1
    tree = ast.parse("""
        def foo(x):
            if isinstance(x, str):
                return x
            else:
                return 'bar'
    """)
    expected_tree = ast.parse("""
        def foo(x):
            if isinstance(x, unicode):
                return x
            else:
                return 'bar'
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.messages == []

    # Test case 2
    tree = ast.parse("""
        def foo(x):
            if isinstance(x, str):
                return x
            else:
                return 'bar'
    """)

# Generated at 2022-06-18 00:39:01.290996
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(x):
            return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(x):
            return unicode(x)
    """