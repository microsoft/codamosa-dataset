

# Generated at 2022-06-18 00:30:34.840673
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    code = '''
    def foo(x):
        return str(x)
    '''
    tree = get_ast(code)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == '''
    def foo(x):
        return unicode(x)
    '''

# Generated at 2022-06-18 00:30:42.973310
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str()
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode()
    """)))

# Generated at 2022-06-18 00:30:47.817108
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        def foo(x):
            return unicode(x)
    '''

# Generated at 2022-06-18 00:30:56.584580
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:31:04.326088
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:31:11.772442
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.ast_builder import ast_from_str

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    expected_tree = ast_from_str('''
        def foo(x):
            return unicode(x)
    ''')

    assert compare_trees(StringTypesTransformer.transform(tree).tree, expected_tree)

# Generated at 2022-06-18 00:31:19.245922
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:31:24.911759
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:31:28.083603
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:31:33.195149
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(x):
            return str(x)
    """
    expected_code = """
        def foo(x):
            return unicode(x)
    """
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-18 00:31:40.881595
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:31:46.916221
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('x = str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'x = unicode(1)'

    tree = get_ast('x = str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'x = unicode(1)'

# Generated at 2022-06-18 00:31:52.882683
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(a: str):
            return a
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            return a
    """)

# Generated at 2022-06-18 00:31:57.905289
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(a: str):
        pass
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed

    assert tree.code == """
    def foo(a: unicode):
        pass
    """

# Generated at 2022-06-18 00:32:04.713480
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.source import source_to_unicode
    from ..utils.tree import find

    source = source_to_unicode('''
    def foo(bar):
        return str(bar)
    ''')

    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == source_to_unicode('''
    def foo(bar):
        return unicode(bar)
    ''')

# Generated at 2022-06-18 00:32:09.966046
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_source = """
    def foo(a):
        return unicode(a)
    """
    expected_tree = source_to_tree(expected_source)
    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:32:17.011818
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo():
            return str(1)
    ''')

    expected_tree = source_to_tree('''
        def foo():
            return unicode(1)
    ''')

    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:32:18.830506
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:29.587276
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1:
    # Test that the transformer replaces str with unicode
    tree = ast.parse("""
    def foo(a):
        return str(a)
    """)
    expected_tree = ast.parse("""
    def foo(a):
        return unicode(a)
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.messages == []

    # Test 2:
    # Test that the transformer does not replace str with unicode if str is not used as a type
    tree = ast.parse("""
    def foo(a):
        return str(a) + "bar"
    """)

# Generated at 2022-06-18 00:32:37.891438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test case 1
    test_code = """
    def test_function(a):
        return str(a)
    """
    expected_code = """
    def test_function(a):
        return unicode(a)
    """
    tree = ast.parse(test_code)
    new_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(new_tree.tree) == ast.dump(ast.parse(expected_code))
    assert new_tree.tree_changed == True
    assert new_tree.new_imports == []

    # Test case 2
    test_code = """
    def test_function(a):
        return a
    """
    expected_code = """
    def test_function(a):
        return a
    """

# Generated at 2022-06-18 00:32:48.797997
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    expected_source = """
    def foo(bar):
        return unicode(bar)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected_source))

# Generated at 2022-06-18 00:32:50.778736
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast


# Generated at 2022-06-18 00:32:58.694004
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """

    expected = """
    def foo(x):
        return unicode(x)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:33:04.335080
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    tree = source_to_ast(source)
    t = StringTypesTransformer()
    new_tree, changed = t.transform(tree)

    assert changed
    assert new_tree != tree
    assert new_tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:33:10.533245
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x: str):
        pass
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:33:16.636651
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []
    assert ast.dump(tree.tree) == ast.dump(source_to_ast("""
    def foo(a: unicode):
        return a
    """))

# Generated at 2022-06-18 00:33:20.880353
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str()
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
    def foo():
        return unicode()
    """)

# Generated at 2022-06-18 00:33:25.674476
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a: str):
        pass
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a: unicode):
        pass
    """)

# Generated at 2022-06-18 00:33:30.232340
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:33:31.164267
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:33:42.785081
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:33:49.904600
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.transform(tree)
    expected_source = """
    def foo(bar):
        return unicode(bar)
    """
    expected_tree = source_to_tree(expected_source)
    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:33:54.655216
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    tree = ast.parse('str("hello")')
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='hello')], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-18 00:34:01.345565
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a: str):
        pass
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a: unicode):
        pass
    """)

# Generated at 2022-06-18 00:34:06.568643
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(x):
        return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:34:09.709831
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:34:18.736804
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast

    source = source_to_unicode("""
    def foo(a: str):
        return a
    """)
    tree = source_to_ast(source)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert astor.to_source(result.tree) == source_to_unicode("""
    def foo(a: unicode):
        return a
    """)

# Generated at 2022-06-18 00:34:19.442264
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:34:21.428145
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:34:28.156849
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree_changed, messages = StringTypesTransformer.transform(tree)

    assert tree_changed
    assert len(messages) == 0

    assert tree.body[0].body.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:34:47.713461
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:34:53.684287
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name

    tree = ast_call(
        ast_name('str'),
        [ast_name('x')]
    )

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    assert astor.to_source(result.tree) == 'unicode(x)'

# Generated at 2022-06-18 00:34:58.576708
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name

    tree = ast_call(ast_name('str'), [ast_name('a')])
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == 'unicode(a)'

# Generated at 2022-06-18 00:35:05.655364
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert source_to_ast(result.tree.body[0].body.s) == source_to_ast("return unicode(x)")

# Generated at 2022-06-18 00:35:14.039399
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:35:19.454732
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(1)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        a = unicode(1)
    """)

# Generated at 2022-06-18 00:35:29.934452
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_func_names
    from ..utils.test_utils import get_class_names

    source = '''
        def foo(a: str):
            pass
        '''
    expected_tree = '''
        def foo(a: unicode):
            pass
        '''
    tree = parse_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert_transformation_result(result, expected_tree, [])
    assert get_func_names(result.tree) == ['foo']
    assert get_class_names(result.tree) == []

# Generated at 2022-06-18 00:35:36.821087
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    tree = ast.parse('''
        def foo(x):
            return str(x)
    ''')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse('''
        def foo(x):
            return unicode(x)
    '''))

# Generated at 2022-06-18 00:35:40.890347
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
    a = str(1)
    """
    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, """
    a = unicode(1)
    """)

# Generated at 2022-06-18 00:35:46.505222
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert tree.body[0].body.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:36:16.158542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformer

    source = source_to_unicode("""
    def foo(a: str):
        pass
    """)
    tree = ast.parse(source)
    NodeTransformer(StringTypesTransformer).visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a: unicode):
        pass
    """)

# Generated at 2022-06-18 00:36:19.868752
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []

    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:36:21.224168
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:36:28.058754
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:36:33.469904
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a: str):
            pass
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(tree, """
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:36:42.665466
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str()
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
    def foo():
        return unicode()
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:36:48.124259
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert messages == []
    assert ast.dump(tree) == ast.dump(source_to_ast("""
    def foo(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:36:56.080278
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(x):
            return str(x)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert ast.dump(tree) == ast.dump(source_to_ast("""
        def foo(x):
            return unicode(x)
    """))

# Generated at 2022-06-18 00:37:02.396976
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:37:08.508405
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:38:02.824108
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = '''
        def foo(x):
            return str(x)
    '''
    expected = '''
        def foo(x):
            return unicode(x)
    '''
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:38:06.320352
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    # Define code to transform

# Generated at 2022-06-18 00:38:11.456783
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:38:14.870820
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:38:23.358034
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo(a):
            return str(a)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, source_to_tree('''
        def foo(a):
            return unicode(a)
    '''))

    tree = source_to_tree('''
        def foo(a):
            return str(a)
    ''')

    tree = StringTypesTransformer.transform(tree)

# Generated at 2022-06-18 00:38:30.263134
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def f(x):
        return str(x)
    """

    expected_ast = source_to_ast(source)
    expected_ast.body[0].body[0].value.func.id = 'unicode'

    result_ast, _ = run_transformer(StringTypesTransformer, source)
    assert compare_ast(result_ast, expected_ast)

# Generated at 2022-06-18 00:38:31.971472
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:38:37.195292
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)
    tree = ast.parse(source)

    tree = StringTypesTransformer.run_pipeline(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:38:42.028644
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(a: str):
            pass
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(a: unicode):
            pass
    """

# Generated at 2022-06-18 00:38:46.964266
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert len(tree.messages) == 0
    assert len(find(tree.tree, ast.Name)) == 1
    assert astor.to_source(tree.tree) == 'unicode'