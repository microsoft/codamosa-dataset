

# Generated at 2022-06-18 00:30:35.927425
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')
    assert_transformation(StringTypesTransformer, 'str(x)', 'unicode(x)')
    assert_transformation(StringTypesTransformer, 'x = str(x)', 'x = unicode(x)')

# Generated at 2022-06-18 00:30:42.757531
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x: str):
            pass
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x: unicode):
            pass
    """)

# Generated at 2022-06-18 00:30:45.379243
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:30:51.508903
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_unicode

    source = source_to_unicode("""
        def foo(x: str) -> str:
            return x
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert node_to_unicode(tree.node) == source_to_unicode("""
        def foo(x: unicode) -> unicode:
            return x
    """)

# Generated at 2022-06-18 00:30:58.388127
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    expected_tree = source_to_tree('''
        def foo(bar):
            return unicode(bar)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:31:05.724541
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
    def foo(a):
        return str(a)
    ''')

    new_tree = StringTypesTransformer.transform(tree)
    new_source = tree_to_source(new_tree.tree)

    assert compare_trees(tree, new_tree.tree)
    assert new_source == '''
    def foo(a):
        return unicode(a)
    '''

# Generated at 2022-06-18 00:31:11.532692
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    expected = """
    def foo(bar):
        return unicode(bar)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:31:16.289572
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:31:16.905178
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("""
        a = str(1)
    """)).tree_changed

# Generated at 2022-06-18 00:31:24.298324
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:31:30.398691
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo():
            return str(1)
    """)

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert result.messages == []
    assert result.tree == source_to_ast("""
        def foo():
            return unicode(1)
    """)

# Generated at 2022-06-18 00:31:37.491035
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet

    snippet = load_example_snippet('string_types.py')
    expected_tree = load_example_snippet('string_types_expected.py')

    transformer = StringTypesTransformer()
    result = transformer.transform(snippet)

    assert_transformation_result(result, expected_tree, [])

# Generated at 2022-06-18 00:31:40.199817
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse_to_ast
    from ..utils.tree import print_ast
    from ..utils.tree import compare_trees


# Generated at 2022-06-18 00:31:46.535173
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    from ..utils.tree import parse_ast

    code = """
    def foo(a: str):
        return a
    """
    expected_code = """
    def foo(a: unicode):
        return a
    """
    tree = parse_ast(code)

    # Act
    result = StringTypesTransformer.transform(tree)

    # Assert
    assert result.tree_changed
    assert result.messages == []
    assert astor.to_source(result.tree) == expected_code

# Generated at 2022-06-18 00:31:51.049215
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar: str):
        pass
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, new_tree)

# Generated at 2022-06-18 00:31:54.219310
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.run_pipeline(tree)

    assert tree_to_str(tree) == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:32:01.786818
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        x = str(1)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        x = unicode(1)
    """)

# Generated at 2022-06-18 00:32:08.097682
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:32:16.644780
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    expected_tree = source_to_ast(source)
    expected_tree.body[0].body[0].value.func.id = 'unicode'

    tree = source_to_ast(source)
    new_tree, _ = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:32:22.731118
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:32:30.178602
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformed_code_equals
    assert_transformed_code_equals(
        StringTypesTransformer,
        '''
        def foo():
            return str(1)
        ''',
        '''
        def foo():
            return unicode(1)
        '''
    )

# Generated at 2022-06-18 00:32:34.319760
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(x):
            return str(x)
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:32:37.721289
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(x):
        return str(x)
    """)

    assert StringTypesTransformer.transform(tree).tree == source_to_ast("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:32:44.268182
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(b)
    """)
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(new_tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode(b)
    """)))

# Generated at 2022-06-18 00:32:52.496111
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:32:57.453679
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Test the constructor of class StringTypesTransformer
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer.target == (2, 7)
    assert string_types_transformer.version == (2, 7)


# Generated at 2022-06-18 00:33:03.625134
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """
    expected = """
        def foo(bar):
            return unicode(bar)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:33:07.239241
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo():
            return str(1)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo():
            return unicode(1)
    """

# Generated at 2022-06-18 00:33:12.862646
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str("abc")')
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='abc')], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-18 00:33:18.460933
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:33:31.160530
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    expected = """
    def foo(x):
        return unicode(x)
    """

    tree = source_to_ast(source)
    new_tree, _, _ = StringTypesTransformer.transform(tree)
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:33:38.095315
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo(a: str):
            return a
    ''')

    expected_tree = source_to_tree('''
        def foo(a: unicode):
            return a
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, expected_tree)

    assert tree_to_source(tree) == tree_to_source(expected_tree)

# Generated at 2022-06-18 00:33:43.994859
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = """
        x = str()
    """
    expected_code = """
        x = unicode()
    """
    tree = ast.parse(code)

    # When
    result = StringTypesTransformer.transform(tree)

    # Then
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-18 00:33:50.669850
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
        def foo(x):
            return str(x)
    '''
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, '''
        def foo(x):
            return unicode(x)
    ''')

# Generated at 2022-06-18 00:33:57.973859
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)
    assert tree_to_str(result.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)))

# Generated at 2022-06-18 00:34:05.938234
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)))

# Generated at 2022-06-18 00:34:10.794451
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(a: unicode):
        return a
    """

# Generated at 2022-06-18 00:34:17.480605
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast

    code = '''
    def foo(x):
        return str(x)
    '''

    tree = get_ast(code)
    t = StringTypesTransformer()
    new_tree = t.visit(tree)
    new_code = astor.to_source(new_tree)

    assert new_code == '''
    def foo(x):
        return unicode(x)
    '''

# Generated at 2022-06-18 00:34:18.672245
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:34:19.890479
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-18 00:34:34.013930
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:34:43.287055
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source

    source = '''
        def foo(a):
            return str(a)
    '''

    expected_tree = parse_ast(source)
    expected_tree.body[0].body[0].value.func.id = 'unicode'

    assert_transformation_result(
        StringTypesTransformer,
        parse_source(source),
        expected_tree,
        [],
        target=(2, 7)
    )

# Generated at 2022-06-18 00:34:54.259097
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Test if the transformer works correctly
    code = """
        def foo(x):
            return str(x)
    """
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    assert new_tree.tree.body[0].body.value.func.id == 'unicode'
    assert new_tree.tree_changed == True
    assert new_tree.additional_imports == []

    # Test 2: Test if the transformer works correctly with multiple instances
    code = """
        def foo(x):
            return str(x) + str(x)
    """
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)

# Generated at 2022-06-18 00:34:58.415604
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(a: str):
            pass
    """)

    tree = StringTypesTransformer.run_pipeline(tree)

    assert tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:35:05.523536
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:35:14.653402
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str()
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
    def foo():
        return unicode()
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:35:22.480014
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a: str):
            return a
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_tree = source_to_tree("""
        def foo(a: unicode):
            return a
    """)

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:35:28.392405
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        a = str(b)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:35:36.340781
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, source_to_tree(source.replace('str', 'unicode')))

# Generated at 2022-06-18 00:35:37.358063
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:36:07.333444
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(x):
        return str(x)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:36:17.053188
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """
    expected_ast = """
        Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """
    tree = source_to_ast(source)
    new_tree = run

# Generated at 2022-06-18 00:36:21.900181
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        x = str()
    """)

    tree = StringTypesTransformer.transform(tree).tree

    assert ast.dump(tree) == ast.dump(source_to_ast("""
        x = unicode()
    """))

# Generated at 2022-06-18 00:36:29.536065
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:36:33.103335
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(a: unicode):
        pass
    """

# Generated at 2022-06-18 00:36:38.798636
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:36:47.244115
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_visitor

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    print_visitor(tree)
    tree = StringTypesTransformer.transform(tree)
    print_visitor(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:36:52.657136
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        def foo(x):
            return unicode(x)
    '''

# Generated at 2022-06-18 00:36:58.297261
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:36:59.101243
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-18 00:38:00.165654
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree


# Generated at 2022-06-18 00:38:01.801258
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    """
    # Test case 1

# Generated at 2022-06-18 00:38:08.533334
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
    def foo(bar):
        return unicode(bar)
    """)

# Generated at 2022-06-18 00:38:13.263052
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:38:18.657691
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:38:19.107581
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:38:24.765133
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str(1)
    """
    expected_tree = source_to_tree(source)
    expected_tree.body[0].body.value.func.id = 'unicode'

    tree = source_to_tree(source)
    new_tree, _ = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:38:31.297546
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:38:36.740327
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:38:43.791517
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'