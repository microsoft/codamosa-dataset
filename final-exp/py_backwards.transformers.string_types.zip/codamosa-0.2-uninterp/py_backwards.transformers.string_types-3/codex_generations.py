

# Generated at 2022-06-18 00:30:33.518545
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str("abc")')).tree_changed == True
    assert StringTypesTransformer.transform(ast.parse('str("abc")')).tree == ast.parse('unicode("abc")')
    assert StringTypesTransformer.transform(ast.parse('str("abc")')).messages == []

# Generated at 2022-06-18 00:30:43.910673
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(a: str):
            return a
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=Name(id='unicode', ctx=Load()))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Name(id='a', ctx=Load()))], decorator_list=[], returns=None)])"

# Generated at 2022-06-18 00:30:49.448417
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert tree == source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

# Generated at 2022-06-18 00:30:59.590843
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        a = str(1)
        b = str(2)
        c = str(3)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    compare_trees(new_tree, tree)

    assert new_tree.body[0].value.func.id == 'unicode'
    assert new_tree.body[1].value.func.id == 'unicode'
    assert new_tree.body[2].value.func.id == 'unicode'

# Generated at 2022-06-18 00:31:05.193390
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = '''
        def foo(a: str):
            pass
    '''
    expected = '''
        def foo(a: unicode):
            pass
    '''
    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:31:09.167213
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(x):
            return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:31:14.286474
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-18 00:31:16.630128
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:31:24.117788
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    from ..utils.testing import assert_transformation_result

    assert_transformation(StringTypesTransformer, 'str')
    assert_transformation(StringTypesTransformer, 'str(1)')
    assert_transformation(StringTypesTransformer, 'str(1, 2)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4, 5)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4, 5, 6)')

# Generated at 2022-06-18 00:31:26.498504
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:31:32.566937
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def f(x):
        return str(x)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def f(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:31:38.621838
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_module
    from ..utils.testing import load_transformed_module

    example_module = load_example_module('string_types.py')
    transformed_module = load_transformed_module('string_types.py')

    assert_transformation_result(
        StringTypesTransformer,
        example_module,
        transformed_module
    )

# Generated at 2022-06-18 00:31:43.606659
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo():
            x = str()
    """)
    expected_tree = ast.parse("""
        def foo():
            x = unicode()
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.messages == []

# Generated at 2022-06-18 00:31:44.551079
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:49.129896
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:31:52.763325
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    tree = ast.parse('str(1)')
    expected_tree = ast.parse('unicode(1)')

    # Act
    result = StringTypesTransformer.transform(tree)

    # Assert
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.errors == []

# Generated at 2022-06-18 00:31:53.914392
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:31:55.302592
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:01.880592
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:32:06.859867
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
        def foo(a):
            return unicode(a)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:32:16.645867
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """

    expected_tree = source_to_tree("""
    def foo(bar):
        return unicode(bar)
    """)

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:32:19.968175
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(
        StringTypesTransformer,
        'str',
        'unicode'
    )

# Generated at 2022-06-18 00:32:26.946374
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(bar):
        return str(bar)
    """)
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(bar):
        return unicode(bar)
    """)

# Generated at 2022-06-18 00:32:31.577781
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(a: str):
        pass
    """

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.new_tree) == ast.dump(ast.parse("""
    def foo(a: unicode):
        pass
    """))

# Generated at 2022-06-18 00:32:36.539126
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast

    source = '''
        def foo(bar):
            return str(bar)
    '''
    expected_tree = parse_ast('''
        def foo(bar):
            return unicode(bar)
    ''')
    assert_transformation_result(StringTypesTransformer, source, expected_tree)

# Generated at 2022-06-18 00:32:43.338934
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo():
        return str('bar')
    """)
    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)
    assert tree_to_str(result.tree) == tree_to_str(ast.parse(source_to_unicode("""
    def foo():
        return unicode('bar')
    """)))

# Generated at 2022-06-18 00:32:49.072037
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:32:52.496436
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(a: str, b: str):
        pass
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(a: unicode, b: unicode):
        pass
    """

# Generated at 2022-06-18 00:33:00.117669
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = '''
    a = str(1)
    b = str(2)
    '''
    expected = '''
    a = unicode(1)
    b = unicode(2)
    '''
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:33:05.533269
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
        def foo(bar):
            return str(bar)
    """

    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, """
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:33:13.638958
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    tree = ast.parse("""
    def foo(bar):
        return str(bar)
    """)

    expected_tree = ast.parse("""
    def foo(bar):
        return unicode(bar)
    """)

    assert_transformation_result(StringTypesTransformer, tree, expected_tree)

# Generated at 2022-06-18 00:33:18.551228
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = '''
    def foo(a):
        return str(a)
    '''
    tree = source_to_ast(source)
    StringTypesTransformer.transform(tree)
    assert source_to_ast(source) != tree

# Generated at 2022-06-18 00:33:27.239113
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    a = str()
    b = str(1)
    c = str(1, 2)
    """

    expected_tree = source_to_tree(source)
    expected_tree.body[0].value.func.id = 'unicode'
    expected_tree.body[1].value.func.id = 'unicode'
    expected_tree.body[2].value.func.id = 'unicode'

    tree = source_to_tree(source)
    new_tree, changed = run_transformer(StringTypesTransformer, tree)

    assert changed
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:33:29.042968
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees


# Generated at 2022-06-18 00:33:38.938158
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str(1)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
    def foo():
        return unicode(1)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
    def foo():
        return str(1)
    """
    tree = source_to_tree(source)
    new

# Generated at 2022-06-18 00:33:43.510186
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(bar):
            return str(bar)
    """)

    tree = StringTypesTransformer.run_pipeline(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:33:49.809445
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
a = str(1)
b = str(2)
c = str(3)
""")
    new_tree = StringTypesTransformer.transform(tree)
    assert new_tree.tree.body[0].value.func.id == 'unicode'
    assert new_tree.tree.body[1].value.func.id == 'unicode'
    assert new_tree.tree.body[2].value.func.id == 'unicode'

# Generated at 2022-06-18 00:33:57.826903
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_source = """
    def foo(a):
        return unicode(a)
    """
    expected_tree = source_to_tree(expected_source)

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:34:04.676756
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
    def foo(bar):
        return unicode(bar)
    """)

# Generated at 2022-06-18 00:34:11.031281
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    expected_source = """
    def foo(x):
        return unicode(x)
    """
    tree = source_to_ast(source)
    new_tree, _ = StringTypesTransformer.transform(tree)
    assert astor.to_source(new_tree) == expected_source

# Generated at 2022-06-18 00:34:19.308463
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert len(tree.messages) == 0
    assert len(find(tree.tree, ast.Name)) == 1
    assert astor.to_source(tree.tree).strip() == 'unicode'

# Generated at 2022-06-18 00:34:24.225819
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str(1)')) == TransformationResult(ast.parse('unicode(1)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str')) == TransformationResult(ast.parse('unicode'), True, [])

# Generated at 2022-06-18 00:34:30.847737
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(a: str):
            pass
    ''')

    expected_tree = source_to_tree('''
        def foo(a: unicode):
            pass
    ''')

    tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:34:40.283530
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.visitor import NodeTransformer

    class TestTransformer(NodeTransformer):
        def visit_Name(self, node):
            if node.id == 'str':
                node.id = 'unicode'
            return node

    tree = ast.parse('str')
    tree = StringTypesTransformer.transform(tree)
    assert to_src(tree) == 'unicode'

    tree = ast.parse('str')
    tree = TestTransformer().visit(tree)
    assert to_src(tree) == 'unicode'

# Generated at 2022-06-18 00:34:47.378274
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast

    source = """
        def foo(x):
            return str(x)
    """
    expected = """
        def foo(x):
            return unicode(x)
    """

    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert compare_ast(new_tree, expected)

# Generated at 2022-06-18 00:34:57.776644
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    expected_ast = """
    Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='bar', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='bar', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """

# Generated at 2022-06-18 00:35:02.155183
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:35:08.266678
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(1)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        a = unicode(1)
    """)

# Generated at 2022-06-18 00:35:13.051713
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-18 00:35:17.904792
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(a):
            return str(a)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:35:29.620557
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast

    source = """
        def foo(a: str):
            return a
    """

    expected_tree = """
        def foo(a: unicode):
            return a
    """

    assert_transformation_result(
        StringTypesTransformer,
        source,
        expected_tree
    )

# Generated at 2022-06-18 00:35:33.116366
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:35:40.317713
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name, ast_arg

    # Test 1: Test that the transformer replaces str with unicode
    tree = ast_call(ast_name('str'), [ast_arg(ast_name('x'))])
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'unicode(x)'

    # Test 2: Test that the transformer does not replace str with unicode if it is not a call
    tree = ast_name('str')
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'str'

    # Test 3: Test that the transformer does not replace str with unicode if it is not a call


# Generated at 2022-06-18 00:35:47.638756
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        if isinstance(bar, str):
            return bar
    """

    expected = """
    def foo(bar):
        if isinstance(bar, unicode):
            return bar
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:35:52.110068
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:35:53.098494
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:35:53.947570
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:35:56.249266
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo():
            return str(1)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        def foo():
            return unicode(1)
    '''

# Generated at 2022-06-18 00:35:58.531355
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert len(tree.messages) == 0
    assert len(find(tree.tree, ast.Name)) == 1
    assert astor.to_source(tree.tree) == 'unicode'

# Generated at 2022-06-18 00:36:02.817588
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert source_to_ast(source) != tree

# Generated at 2022-06-18 00:36:19.970134
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    expected = """
    def foo(bar):
        return unicode(bar)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:36:26.839487
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    a = str(1)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
    a = unicode(1)
    """)).body[0])

# Generated at 2022-06-18 00:36:35.534039
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """


# Generated at 2022-06-18 00:36:43.062225
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:36:47.380714
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(bar):
            return str(bar)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(bar):
            return unicode(bar)
    """

# Generated at 2022-06-18 00:36:56.533310
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:37:02.800514
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:37:11.223200
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_visitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    print_visitor(tree)

    result = StringTypesTransformer.transform(tree)
    print(tree_to_str(result.tree))

    assert result.tree_changed
    assert result.warnings == []

# Generated at 2022-06-18 00:37:19.581639
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = '''
    def foo(a):
        return str(a)
    '''

    expected_tree = source_to_ast('''
    def foo(a):
        return unicode(a)
    ''')

    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:37:26.827116
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Test if the class is properly initialized
    assert StringTypesTransformer.target == (2, 7)
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.__doc__ == 'Replaces `str` with `unicode`.'
    # Test 2: Test if the class is properly transforms the tree
    tree = ast.parse('a = str(1)')
    tree_changed, new_tree, _ = StringTypesTransformer.transform(tree)
    assert tree_changed == True
    assert ast.dump(new_tree) == ast.dump(ast.parse('a = unicode(1)'))

# Generated at 2022-06-18 00:38:02.073038
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    result = StringTypesTransformer.transform(tree)
    assert compare_trees(result.tree, source_to_tree('''
        def foo(x):
            return unicode(x)
    '''))
    assert result.tree_changed
    assert result.warnings == []
    assert tree_to_source(result.tree) == tree_to_source(source_to_tree('''
        def foo(x):
            return unicode(x)
    '''))

# Generated at 2022-06-18 00:38:07.622860
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(x):
        return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:38:12.570465
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar: str):
            pass
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar: unicode):
            pass
    """)

# Generated at 2022-06-18 00:38:18.124377
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.run_pipeline(tree)

    assert compare_trees(tree, source_to_tree('''
        def foo(x):
            return unicode(x)
    '''))

# Generated at 2022-06-18 00:38:25.871280
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(StringTypesTransformer, 'str', 'unicode')
    assert_transformation(StringTypesTransformer, 'str(1)', 'unicode(1)')
    assert_transformation(StringTypesTransformer, 'str(1, 2)', 'unicode(1, 2)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3)', 'unicode(1, 2, 3)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4)', 'unicode(1, 2, 3, 4)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4, 5)', 'unicode(1, 2, 3, 4, 5)')
    assert_

# Generated at 2022-06-18 00:38:34.009350
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:38:36.389377
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet

    snippet = load_example_snippet('string_types.py')
    expected = load_example_snippet('string_types.py', target=(2, 7))

    assert_transformation_result(StringTypesTransformer, snippet, expected)

# Generated at 2022-06-18 00:38:39.522426
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:38:46.133569
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))

# Generated at 2022-06-18 00:38:56.661855
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')
    assert_transformation(StringTypesTransformer, 'str()', 'unicode()')
    assert_transformation(StringTypesTransformer, 'str(1)', 'unicode(1)')
    assert_transformation(StringTypesTransformer, 'str(1, 2)', 'unicode(1, 2)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3)', 'unicode(1, 2, 3)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4)', 'unicode(1, 2, 3, 4)')

# Generated at 2022-06-18 00:40:12.075058
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        def foo(bar):
            return unicode(bar)
    '''

# Generated at 2022-06-18 00:40:16.798503
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
    def foo(bar):
        return str(bar)
    '''

    expected_tree = source_to_tree('''
    def foo(bar):
        return unicode(bar)
    ''')

    tree = source_to_tree(source)

    new_tree, _ = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:40:22.091342
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            return a
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            return a
    """)

# Generated at 2022-06-18 00:40:25.793843
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(b)
    """)
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode(b)
    """)))

# Generated at 2022-06-18 00:40:29.568826
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: test the constructor of class StringTypesTransformer
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)
