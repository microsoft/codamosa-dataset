

# Generated at 2022-06-18 00:30:24.994210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def f(x):
            return str(x)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
        def f(x):
            return unicode(x)
    """))

# Generated at 2022-06-18 00:30:25.907572
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:30:33.493104
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.source import source_to_ast
    from ..utils.tree import find

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert len(tree.messages) == 0
    assert astor.to_source(tree.tree).strip() == """
    def foo(a: unicode):
        return a
    """.strip()

# Generated at 2022-06-18 00:30:37.729812
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.visitor import NodeTransformer

    class TestTransformer(NodeTransformer):
        def visit_Name(self, node):
            if node.id == 'str':
                node.id = 'unicode'
            return node

    tree = ast.parse('str')
    tree = StringTypesTransformer.transform(tree)
    assert to_src(tree) == 'unicode'

    tree = ast.parse('str')
    tree = TestTransformer().visit(tree)
    assert to_src(tree) == 'unicode'

# Generated at 2022-06-18 00:30:41.546968
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    tree = ast.parse('str(1)')
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    assert ast.dump(new_tree) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-18 00:30:45.651233
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast

    source = """
        def foo(a):
            return str(a)
    """
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.transform(tree)

    assert compare_ast(new_tree.tree, """
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:30:51.437000
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name, ast_assign

    tree = ast_assign(
        ast_name('a'),
        ast_call(
            ast_name('str'),
            [ast_name('b')]
        )
    )

    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree.tree).strip() == 'a = unicode(b)'

# Generated at 2022-06-18 00:30:59.590286
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_module_as_main
    import astunparse

    source = """
    def foo(x):
        return str(x)
    """

    expected_source = """
    def foo(x):
        return unicode(x)
    """

    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert compare_ast(astunparse.unparse(new_tree), expected_source)

    run_module_as_main(source, expected_source)

# Generated at 2022-06-18 00:31:04.566677
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo(bar):
            return str(bar)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
        def foo(bar):
            return unicode(bar)
    """))

# Generated at 2022-06-18 00:31:10.135024
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = '''
    def foo(a):
        return str(a)
    '''
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
    def foo(a):
        return unicode(a)
    '''

# Generated at 2022-06-18 00:31:14.609735
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)
    assert StringTypesTransformer.transform.__name__ == 'transform'


# Generated at 2022-06-18 00:31:18.536427
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..utils.tree import find

    tree = ast.parse("""
    def foo(a: str):
        pass
    """)

    transformer = StringTypesTransformer()
    tree = transformer.transform(tree)

    assert len(find(tree, ast.Name)) == 1
    assert find(tree, ast.Name)[0].id == 'unicode'

# Generated at 2022-06-18 00:31:24.737632
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(bar):
        return str(bar)
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:31:31.333601
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = '''
    def foo(a):
        return str(a)
    '''

    expected_tree = source_to_ast('''
    def foo(a):
        return unicode(a)
    ''')

    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:31:39.002102
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_module_transformations

    source = """
        def f(x):
            return str(x)
    """
    expected = """
        def f(x):
            return unicode(x)
    """
    tree = source_to_ast(source)
    new_tree = run_module_transformations(tree, [StringTypesTransformer])
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:31:45.407801
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
        def foo(a: str):
            return a
    """
    tree = source_to_tree(source)
    StringTypesTransformer.transform(tree)
    expected_source = """
        def foo(a: unicode):
            return a
    """
    expected_tree = source_to_tree(expected_source)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:31:48.346985
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:31:52.643286
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:31:53.784978
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:57.961513
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:32:04.482441
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        def foo(x):
            return unicode(x)
    '''

# Generated at 2022-06-18 00:32:09.782331
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a: unicode):
            pass
    """)))

# Generated at 2022-06-18 00:32:13.407703
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        StringTypesTransformer,
        'str',
        'unicode'
    )

# Generated at 2022-06-18 00:32:16.376879
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    a = str(1)
    """
    tree = source_to_ast(source)
    assert StringTypesTransformer.transform(tree).tree_changed == True

# Generated at 2022-06-18 00:32:19.097141
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == 'unicode(1)'

# Generated at 2022-06-18 00:32:24.527244
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(x):
        return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:32:29.306335
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(a):
        return str(a)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(a):
        return unicode(a)
    """))

# Generated at 2022-06-18 00:32:33.480099
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def f(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == '''
        def f(x):
            return unicode(x)
    '''

# Generated at 2022-06-18 00:32:39.431147
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))

# Generated at 2022-06-18 00:32:49.693495
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_visitor
    from ..utils.ast_helper import ast_from_str

    source = source_to_unicode("""
    def foo(a):
        return str(a)
    """)

    tree = ast_from_str(source)
    print_visitor(tree)
    tree = StringTypesTransformer.transform(tree)
    print_visitor(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a):
        return unicode(a)
    """)

# Generated at 2022-06-18 00:32:55.080347
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:56.966493
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:33:06.620295
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:33:15.332846
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:33:16.635809
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:33:20.233942
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:33:25.179945
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:33:26.178127
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:33:31.114112
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    StringTypesTransformer.transform(tree)
    source = astor.to_source(tree)
    assert source == get_source(StringTypesTransformer)

# Generated at 2022-06-18 00:33:33.440169
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:33:43.019615
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(a: str):
        return a
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(a: unicode):
        return a
    """

# Generated at 2022-06-18 00:33:51.691835
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import Python2to3Src
    from ..utils.visitor import Python2to3Ast

    src = source_to_unicode("""
        def f(x):
            return str(x)
    """)
    tree = ast.parse(src)
    tree = Python2to3Ast().visit(tree)
    tree = StringTypesTransformer.transform(tree)
    src = Python2to3Src().visit(tree)
    assert tree_to_str(tree) == tree_to_str(ast.parse(src))

# Generated at 2022-06-18 00:33:58.217670
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(x):
        return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []
    assert ast.dump(tree.tree) == ast.dump(source_to_ast("""
    def foo(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:34:06.209541
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = NodeTransformerVisitor(StringTypesTransformer).visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:34:10.071285
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str(1)')) == TransformationResult(ast.parse('unicode(1)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str')) == TransformationResult(ast.parse('unicode'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str(1) + str(2)')) == TransformationResult(ast.parse('unicode(1) + unicode(2)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str(1) + str(2) + str(3)')) == TransformationResult(ast.parse('unicode(1) + unicode(2) + unicode(3)'), True, [])

# Generated at 2022-06-18 00:34:17.804366
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    expected_tree = source_to_tree(source)
    expected_tree.body[0].body[0].value.func.id = 'unicode'

    tree = source_to_tree(source)
    new_tree, changed = run_transformer(tree, StringTypesTransformer)

    assert changed
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:34:22.094949
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast, ast_to_source
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    new_tree, changed = run_transformer(tree, StringTypesTransformer)
    assert changed
    assert ast_to_source(new_tree) == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:34:29.436242
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    expected = """
    def foo(x):
        return unicode(x)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:34:30.282522
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:34:36.517125
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:34:55.673369
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    expected_tree = source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

    tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:35:06.332876
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name, ast_assign, ast_arg

    # Test 1
    code = """
    a = str(1)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == """
    a = unicode(1)
    """

    # Test 2
    code = """
    a = str(1)
    b = str(2)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == """
    a = unicode(1)
    b = unicode(2)
    """

   

# Generated at 2022-06-18 00:35:16.333389
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_module_as_main

    source = """
    def foo():
        return str('foo')
    """
    expected_source = """
    def foo():
        return unicode('foo')
    """
    expected_tree = source_to_ast(expected_source)
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert compare_ast(result.tree, expected_tree)
    assert result.tree_changed
    assert not result.code_changed
    assert run_module_as_main(source) == run_module_as_main(expected_source)

# Generated at 2022-06-18 00:35:23.445754
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    tree = run_transformer(tree, StringTypesTransformer)

    assert compare_trees(tree, source_to_tree('''
        def foo(bar):
            return unicode(bar)
    '''))

# Generated at 2022-06-18 00:35:28.811786
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(a: str):
            return a
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        def foo(a: unicode):
            return a
    '''

# Generated at 2022-06-18 00:35:32.229468
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:35:38.138386
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    assert tree is not None

    transformer = StringTypesTransformer()
    new_tree, changed = transformer.transform(tree)

    assert changed
    assert new_tree is not None

    # Check that the transformation was applied
    assert find(new_tree, ast.Name, id='unicode') is not None

# Generated at 2022-06-18 00:35:44.713274
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, source_to_tree(source.replace('str', 'unicode')))

# Generated at 2022-06-18 00:35:49.574220
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:35:52.670198
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(ast.parse("""
    def foo(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:36:24.267893
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(StringTypesTransformer, 'str', 'unicode')
    assert_transformation(StringTypesTransformer, 'str()', 'unicode()')
    assert_transformation(StringTypesTransformer, 'str(1)', 'unicode(1)')
    assert_transformation(StringTypesTransformer, 'str(1, 2)', 'unicode(1, 2)')
    assert_transformation(StringTypesTransformer, 'str(a=1)', 'unicode(a=1)')
    assert_transformation(StringTypesTransformer, 'str(a=1, b=2)', 'unicode(a=1, b=2)')

# Generated at 2022-06-18 00:36:31.284993
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    expected = """
    def foo(a):
        return unicode(a)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(new_tree, expected)

# Generated at 2022-06-18 00:36:34.667196
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:36:42.664686
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo():
            return str('bar')
    ''')

    expected_tree = source_to_tree('''
        def foo():
            return unicode('bar')
    ''')

    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:36:47.055400
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(a: str):
            pass
    ''')
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        def foo(a: unicode):
            pass
    '''

# Generated at 2022-06-18 00:36:56.728114
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import generate_source

    tree = ast.parse("""
    def foo(x):
        return str(x)
    """)
    print_tree(tree)
    print(generate_source(tree))

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    print_tree(result.tree)
    print(generate_source(result.tree))

    assert result.tree_changed
    assert generate_source(result.tree) == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:36:57.524076
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:37:04.311756
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)))

# Generated at 2022-06-18 00:37:12.066202
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(1)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode(1)
    """)))

# Generated at 2022-06-18 00:37:19.370654
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.ast_factory import ast_factory

    tree = ast_factory('''
        def foo(a: str):
            pass
    ''')

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    assert to_src(result.tree) == '''
        def foo(a: unicode):
            pass
    '''

# Generated at 2022-06-18 00:38:12.508113
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """
    def test(a):
        return str(a)
    """
    tree = astor.parse_file(code)
    StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == """
    def test(a):
        return unicode(a)
    """

# Generated at 2022-06-18 00:38:18.041385
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a: str):
        return a
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a: unicode):
        return a
    """)

# Generated at 2022-06-18 00:38:22.388805
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(bar):
            return str(bar)
    """)

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []

    assert result.tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:38:27.383438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    code = source_to_unicode('''
        def foo(a: str):
            return a
    ''')

    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)

    assert tree_to_str(new_tree.tree) == tree_to_str(ast.parse(source_to_unicode('''
        def foo(a: unicode):
            return a
    ''')))

# Generated at 2022-06-18 00:38:34.314328
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)

    StringTypesTransformer.transform(tree)

    source_transformed = astor.to_source(tree)
    source_expected = get_source(StringTypesTransformer, suffix='expected')

    assert source_transformed == source_expected

# Generated at 2022-06-18 00:38:35.365053
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:38:39.474543
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:38:45.508466
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree.tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:38:50.713634
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeCounter

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    assert NodeCounter(ast.Name).visit(tree) == 3
    assert NodeCounter(ast.Str).visit(tree) == 0

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert NodeCounter(ast.Name).visit(result.tree) == 3
    assert NodeCounter(ast.Str).visit(result.tree) == 0

# Generated at 2022-06-18 00:38:55.141876
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """
    def f(x):
        return str(x)
    """
    tree = astor.parse_file(code)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == """
    def f(x):
        return unicode(x)
    """