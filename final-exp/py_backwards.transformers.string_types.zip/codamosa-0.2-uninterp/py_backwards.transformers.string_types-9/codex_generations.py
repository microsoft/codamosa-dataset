

# Generated at 2022-06-18 00:30:31.745454
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        b = str(a)
        return b
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []

    source = """
    def foo(a: str):
        b = str(a)
        return b
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []

    source = """
    def foo(a: str):
        b = str(a)
        return b
    """
    tree = source_to_ast(source)

# Generated at 2022-06-18 00:30:37.260101
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:30:43.111377
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast

    source = """
        def foo(a: str):
            pass
    """
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.transform(tree)

    assert compare_ast(new_tree.tree, """
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:30:50.143612
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_tree = source_to_tree("""
        def foo(a):
            return unicode(a)
    """)

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:31:00.412281
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(StringTypesTransformer, 'str', 'unicode')
    assert_transformation(StringTypesTransformer, 'str(1)', 'unicode(1)')
    assert_transformation(StringTypesTransformer, 'str(1, 2)', 'unicode(1, 2)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3)', 'unicode(1, 2, 3)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4)', 'unicode(1, 2, 3, 4)')
    assert_transformation(StringTypesTransformer, 'str(1, 2, 3, 4, 5)', 'unicode(1, 2, 3, 4, 5)')
    assert_

# Generated at 2022-06-18 00:31:05.761276
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:31:11.544107
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo():
            return str('foo')
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    compare_trees(new_tree, """
        def foo():
            return unicode('foo')
    """)

# Generated at 2022-06-18 00:31:15.403096
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        a = str(1)
        b = str(2)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        a = unicode(1)
        b = unicode(2)
    '''

# Generated at 2022-06-18 00:31:17.599512
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)


# Generated at 2022-06-18 00:31:21.445215
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet

    snippet = load_example_snippet('string_types.py')
    expected_tree = load_example_snippet('string_types_unicode.py')

    assert_transformation_result(StringTypesTransformer, snippet, expected_tree)

# Generated at 2022-06-18 00:31:30.335020
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_visitor

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    print_visitor(tree)
    tree = StringTypesTransformer.transform(tree)
    print_visitor(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:31:37.018772
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    a = str(1)
    """
    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast("""
    a = unicode(1)
    """))

# Generated at 2022-06-18 00:31:41.572398
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """
    def foo(a):
        return str(a)
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == """
    def foo(a):
        return unicode(a)
    """

# Generated at 2022-06-18 00:31:49.218067
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_visitor
    from ..utils.visitor import visit_and_replace

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)

    tree = ast.parse(source)
    print_visitor(tree)

    tree = visit_and_replace(tree, StringTypesTransformer)

    print_visitor(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:31:53.121454
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo(x: str) -> str:
            return x
        """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
        def foo(x: unicode) -> unicode:
            return x
        """))

# Generated at 2022-06-18 00:31:58.950101
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert len(find(result.tree, ast.Name)) == 1
    assert astor.to_source(result.tree).strip() == 'unicode'

# Generated at 2022-06-18 00:32:05.656234
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = '''
    def foo(x):
        return str(x)
    '''
    expected = '''
    def foo(x):
        return unicode(x)
    '''
    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:32:08.550854
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    tree = ast.parse('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree.body[0].value.id == 'unicode'

# Generated at 2022-06-18 00:32:10.515307
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:17.741726
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import NodeVisitor

    source = source_to_unicode("""
    a = str(1)
    """)
    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    a = unicode(1)
    """)

# Generated at 2022-06-18 00:32:21.331766
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:32:27.249860
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, """
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:32:30.814555
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("""
        a = str(1)
    """)).tree_changed == True
    assert StringTypesTransformer.transform(ast.parse("""
        a = unicode(1)
    """)).tree_changed == False

# Generated at 2022-06-18 00:32:36.789143
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(tree, StringTypesTransformer)
    expected_tree = source_to_tree("""
    def foo(a: unicode):
        pass
    """)
    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:32:40.247710
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(x):
            return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:32:48.006254
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def f(x):
        return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def f(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:32:53.101834
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:32:56.472098
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(
        StringTypesTransformer,
        'str',
        'unicode',
    )

# Generated at 2022-06-18 00:33:00.522727
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:33:06.656698
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a):
        return str(a)
    """

    expected = """
    def foo(a):
        return unicode(a)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:33:10.837296
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    a = str()
    """

    expected_source = """
    a = unicode()
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed == True
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected_source))

# Generated at 2022-06-18 00:33:15.468145
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:33:21.040308
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert len(find(tree.tree, ast.Name)) == 1
    assert astor.to_source(tree.tree).strip() == 'unicode'

# Generated at 2022-06-18 00:33:26.312685
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:33:32.353850
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:33:37.600589
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(bar):
            return str(bar)
    """)

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree == source_to_ast("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:33:47.878137
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    expected_ast = """
    Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """
    ast = source_to_ast(source)
    new_ast = run

# Generated at 2022-06-18 00:33:51.124441
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    tree = ast.parse('str("hello")')
    expected_tree = ast.parse('unicode("hello")')

    assert_transformation_result(StringTypesTransformer, tree, expected_tree)

# Generated at 2022-06-18 00:33:56.579172
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(a):
            return str(a)
    """

    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert new_tree.body[0].body.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:34:00.980817
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """
    def foo(x: str):
        pass
    """
    tree = astor.parse_file(code)
    result = StringTypesTransformer.transform(tree)
    print(astor.to_source(result.tree))

# Generated at 2022-06-18 00:34:05.128567
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        StringTypesTransformer,
        'str(1)',
        'unicode(1)'
    )

# Generated at 2022-06-18 00:34:14.199500
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        import sys
        if sys.version_info[0] == 2:
            str = unicode
        """)
    tree = ast.parse(source)
    tree = NodeTransformerVisitor(StringTypesTransformer).visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        import sys
        if sys.version_info[0] == 2:
            unicode = unicode
        """)

# Generated at 2022-06-18 00:34:21.123410
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x: str):
            return x
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
        def foo(x: str):
            return x
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:34:29.486123
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)))

# Generated at 2022-06-18 00:34:33.115709
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, """
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:34:41.763177
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
    def foo(x):
        return str(x)
    '''

    expected_tree = source_to_tree('''
    def foo(x):
        return unicode(x)
    ''')

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:34:52.910739
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test with a simple program
    tree = ast.parse("""
    a = str(1)
    b = str(2)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    a = unicode(1)
    b = unicode(2)
    """))

    # Test with a program that does not contain any str
    tree = ast.parse("""
    a = 1
    b = 2
    """)
    tree = StringTypesTransformer.transform(tree)
    assert not tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    a = 1
    b = 2
    """))

# Generated at 2022-06-18 00:34:58.511853
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_test_data

    source = get_test_data('string_types_source.py')
    expected = get_test_data('string_types_expected.py')

    tree = parse_ast(source)
    result = StringTypesTransformer.transform(tree)

    assert_transformation_result(result, expected)

# Generated at 2022-06-18 00:35:07.925447
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    a = str()
    """

    expected_ast = """
    Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])
    """

    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_ast, new_tree)

# Generated at 2022-06-18 00:35:14.750402
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast("""
        def foo(bar):
            return str(bar)
    """)

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.messages) == 0
    assert astor.to_source(result.tree) == """
        def foo(bar):
            return unicode(bar)
    """

# Generated at 2022-06-18 00:35:27.584579
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    source = """
    def foo(s: str):
        return s
    """
    tree = source_to_tree(source)
    t = StringTypesTransformer()
    new_tree, changed = t.transform(tree)
    assert changed
    assert new_tree != tree

    source = """
    def foo(s: unicode):
        return s
    """
    tree = source_to_tree(source)
    t = StringTypesTransformer()
    new_tree, changed = t.transform(tree)
    assert not changed
    assert new_tree == tree

# Generated at 2022-06-18 00:35:38.423238
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeCounter
    from ..utils.visitor import NodeReplacer
    from ..utils.visitor import NodeVisitor
    from ..utils.visitor import VisitorFilter

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)

    tree = ast.parse(source)
    tree_changed = False

    for node in find(tree, ast.Name):
        if node.id == 'str':
            node.id = 'unicode'
            tree_changed = True

    assert tree_changed == True

# Generated at 2022-06-18 00:35:44.336612
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_factory
    from ..utils.source_factory import source_factory

    source = source_factory('str')
    tree = ast_factory(source)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'unicode'

# Generated at 2022-06-18 00:35:49.295879
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast

    source = '''
    def foo(bar):
        return str(bar)
    '''
    expected = '''
    def foo(bar):
        return unicode(bar)
    '''

    tree = get_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert astor.to_source(new_tree) == expected

# Generated at 2022-06-18 00:35:51.889403
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(a):
            return str(a)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(a):
            return unicode(a)
    """

# Generated at 2022-06-18 00:36:02.035371
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
        def foo(a):
            return str(a)
    """
    expected_ast = """
        Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """

    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.run_it(tree)

   

# Generated at 2022-06-18 00:36:07.561054
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(a):
        return unicode(a)
    """

# Generated at 2022-06-18 00:36:14.376450
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(s: str):
        return s
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
    def foo(s: unicode):
        return s
    """)

# Generated at 2022-06-18 00:36:21.362913
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(bar):
            return str(bar)
    """)

    new_tree, tree_changed, messages = StringTypesTransformer.transform(tree)

    assert tree_changed
    assert messages == []
    assert ast.dump(new_tree) == ast.dump(source_to_ast("""
        def foo(bar):
            return unicode(bar)
    """))

# Generated at 2022-06-18 00:36:28.809335
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo():
        return str(1)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_tree = source_to_tree("""
    def foo():
        return unicode(1)
    """)
    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:36:37.855064
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    expected = """
    def foo(x):
        return unicode(x)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:36:43.876987
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(bar):
        return str(bar)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(bar):
        return unicode(bar)
    """))

# Generated at 2022-06-18 00:36:48.026889
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(s: str):
            return s
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:36:57.235551
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        pass
    """

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed == True
    assert len(messages) == 0

    source = """
    def foo(a: unicode):
        pass
    """

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed == False
    assert len(messages) == 0

# Generated at 2022-06-18 00:37:05.488455
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("str('hello')")) == TransformationResult(ast.parse("unicode('hello')"), True, [])
    assert StringTypesTransformer.transform(ast.parse("str('hello') + 'world'")) == TransformationResult(ast.parse("unicode('hello') + 'world'"), True, [])
    assert StringTypesTransformer.transform(ast.parse("str('hello') + str('world')")) == TransformationResult(ast.parse("unicode('hello') + unicode('world')"), True, [])
    assert StringTypesTransformer.transform(ast.parse("str('hello') + str('world') + '!'")) == TransformationResult(ast.parse("unicode('hello') + unicode('world') + '!'"), True, [])

# Generated at 2022-06-18 00:37:06.691241
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:37:12.414319
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a: str):
            pass
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:37:13.476831
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:37:19.194299
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:37:25.222060
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(1)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode(1)
    """)))

# Generated at 2022-06-18 00:37:31.062745
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_factory


# Generated at 2022-06-18 00:37:38.525558
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)))

# Generated at 2022-06-18 00:37:46.422556
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:37:51.312312
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, """
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:37:58.859171
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))

# Generated at 2022-06-18 00:38:01.859613
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:38:08.312433
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.errors) == 0
    assert len(find(result.tree, ast.Name)) == 1
    assert astor.to_source(result.tree) == 'unicode'

# Generated at 2022-06-18 00:38:10.260938
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:38:17.335805
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(x: str):
            pass
    ''')

    tree = StringTypesTransformer.transform(tree)

    tree_ = source_to_tree('''
        def foo(x: unicode):
            pass
    ''')

    assert compare_trees(tree, tree_)

# Generated at 2022-06-18 00:38:20.780291
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(
        StringTypesTransformer,
        '''
        def foo(x):
            return str(x)
        ''',
        '''
        def foo(x):
            return unicode(x)
        '''
    )

# Generated at 2022-06-18 00:38:30.056218
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(a: str):
            return a
    ''')

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []

    assert result.tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:38:32.689352
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:38:36.987214
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(1)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == "Module(body=[Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-18 00:38:46.597917
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name

    tree = ast_call(
        ast_name('foo'),
        [
            ast_call(
                ast_name('bar'),
                [
                    ast_name('str'),
                    ast_name('unicode'),
                ]
            ),
            ast_name('str'),
        ]
    )

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed
    assert len(result.messages) == 0

    assert astor.to_source(result.tree) == """foo(bar(unicode, unicode), unicode)"""

# Generated at 2022-06-18 00:38:50.392799
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        StringTypesTransformer,
        'str',
        'unicode'
    )

# Generated at 2022-06-18 00:38:54.107371
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for the constructor of class StringTypesTransformer
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)
    assert StringTypesTransformer.transform.__name__ == 'transform'


# Generated at 2022-06-18 00:38:59.554650
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a: str):
        pass
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a: unicode):
        pass
    """)

# Generated at 2022-06-18 00:39:07.085568
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert len(tree.errors) == 0
    assert len(find(tree.tree, ast.Name)) == 1
    assert astor.to_source(tree.tree) == 'unicode'

# Generated at 2022-06-18 00:39:13.616918
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import TreeVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed

    class Visitor(TreeVisitor):
        def visit_Name(self, node):
            if node.id == 'unicode':
                return True
            return False

    visitor = Visitor()
    assert visitor.visit(tree.tree)

# Generated at 2022-06-18 00:39:18.687456
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(bar):
        return str(bar)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:39:32.665228
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name

    tree = ast_call(ast_name('str'), [ast_name('a')])
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert astor.to_source(result.tree) == 'unicode(a)'

# Generated at 2022-06-18 00:39:38.099686
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    x = str()
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, new_tree)

    source = """
    x = unicode()
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert not compare_trees(tree, new_tree)

# Generated at 2022-06-18 00:39:40.622233
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo():
            return str(1)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:39:50.063453
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    # Test 1: Test that the constructor of class StringTypesTransformer
    # raises an exception when the target version is not a tuple of
    # length 2
    with pytest.raises(ValueError):
        StringTypesTransformer(target=1)

    # Test 2: Test that the constructor of class StringTypesTransformer
    # raises an exception when the target version is not a tuple of
    # integers
    with pytest.raises(ValueError):
        StringTypesTransformer(target=(1, 'a'))

    # Test 3: Test that the constructor of class StringTypesTransformer
    # raises an exception when the target version is not a tuple of
    # positive integers
    with pytest.raises(ValueError):
        StringTypesTransformer(target=(-1, 1))

# Generated at 2022-06-18 00:39:50.884171
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:39:57.813205
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x: str):
        pass
    """

    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)

    expected_source = """
    def foo(x: unicode):
        pass
    """

    expected_tree = source_to_tree(expected_source)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:40:00.528580
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
        def foo(x):
            return unicode(x)
    '''

# Generated at 2022-06-18 00:40:06.947855
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:40:11.541066
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    def foo(a: str):
        return a
    '''
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse('''
    def foo(a: unicode):
        return a
    '''))

# Generated at 2022-06-18 00:40:15.762614
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(b)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode(b)
    """)))