

# Generated at 2022-06-18 00:30:20.757252
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:30:27.604706
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    a = str(1)
    """
    expected = """
    a = unicode(1)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:30:34.931255
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    expected_tree = source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:30:37.743676
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:30:43.141277
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, source_to_tree("""
        def foo(x):
            return unicode(x)
    """))

# Generated at 2022-06-18 00:30:51.845878
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str()
        b = str(a)
        c = str(a, b)
        d = str(a, b, c)
    """)
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode()
        b = unicode(a)
        c = unicode(a, b)
        d = unicode(a, b, c)
    """)))

# Generated at 2022-06-18 00:30:53.673900
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:30:55.759687
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast


# Generated at 2022-06-18 00:31:02.268409
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo(x):
            return str(x)
    """)
    tree_changed, _, _ = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse("""
        def foo(x):
            return unicode(x)
    """))

# Generated at 2022-06-18 00:31:06.091507
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:17.304983
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    tree = ast.parse('x = str("abc")')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse('x = unicode("abc")'))

    # Test 2
    tree = ast.parse('x = str("abc")')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse('x = unicode("abc")'))

    # Test 3
    tree = ast.parse('x = str("abc")')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed


# Generated at 2022-06-18 00:31:18.990462
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, """
        str(1)
    """, """
        unicode(1)
    """)

# Generated at 2022-06-18 00:31:26.818353
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    from ..utils.testing import assert_transformation_result

    code = '''
    def foo(x):
        return str(x)
    '''

    assert_transformation(StringTypesTransformer, code, code.replace('str', 'unicode'))
    assert_transformation_result(StringTypesTransformer, code, code.replace('str', 'unicode'))

# Generated at 2022-06-18 00:31:32.548728
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Replace str with unicode
    tree = ast.parse('str')
    tree_changed, _ = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert ast.dump(tree) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"

    # Test 2: Don't replace unicode
    tree = ast.parse('unicode')
    tree_changed, _ = StringTypesTransformer.transform(tree)
    assert not tree_changed
    assert ast.dump(tree) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"

# Generated at 2022-06-18 00:31:39.002012
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:31:45.407833
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """
    expected = """
        def foo(a):
            return unicode(a)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:31:53.007239
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a: str):
        pass
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
    def foo(a: str):
        pass
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:31:53.863123
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:58.309921
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    tree = ast.parse('str("abc")')
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == 'unicode("abc")'

# Generated at 2022-06-18 00:31:59.585261
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:32:08.006097
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
        def foo(bar: str):
            pass
    """
    expected = """
        def foo(bar: unicode):
            pass
    """
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:32:16.319401
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        if isinstance(x, str):
            return x
    """
    expected = """
    def foo(x):
        if isinstance(x, unicode):
            return x
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:32:23.142544
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert tree.body[0].body.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:32:24.100366
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:29.991250
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x: str):
        return x
    """

    expected = """
    def foo(x: unicode):
        return x
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:32:38.555740
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def f(x):
        return str(x)
    """
    expected_tree = source_to_tree("""
    def f(x):
        return unicode(x)
    """)

    tree = source_to_tree(source)
    new_tree, changed = run_transformer(StringTypesTransformer, tree)

    assert changed
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:32:40.819592
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(
        StringTypesTransformer,
        'str',
        'unicode'
    )

# Generated at 2022-06-18 00:32:49.069667
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo():
        return str()
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))], decorator_list=[])])"

# Generated at 2022-06-18 00:32:51.919226
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer
    from ..utils.source import tree_to_source


# Generated at 2022-06-18 00:33:00.888587
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:33:13.434386
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        str
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        unicode
    """)

# Generated at 2022-06-18 00:33:19.661210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x: str):
        return x
    """
    expected = """
    def foo(x: unicode):
        return x
    """
    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:33:25.728810
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a: str):
        pass
    """)
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert tree_to_str(new_tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
    def foo(a: unicode):
        pass
    """)))

# Generated at 2022-06-18 00:33:30.324799
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(a: str):
        pass
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed

    assert tree.new_code == """
    def foo(a: unicode):
        pass
    """

# Generated at 2022-06-18 00:33:36.033496
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:33:42.187155
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
        def foo(bar):
            return str(bar)
    '''
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(new_tree, '''
        def foo(bar):
            return unicode(bar)
    ''')

# Generated at 2022-06-18 00:33:48.570492
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, source_to_tree(source.replace('str', 'unicode')))

# Generated at 2022-06-18 00:33:51.076159
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:33:59.081530
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import ast_to_source

    source = source_to_unicode('''
        def foo(bar):
            return str(bar)
    ''')
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert ast_to_source(result.tree) == source_to_unicode('''
        def foo(bar):
            return unicode(bar)
    ''')

# Generated at 2022-06-18 00:34:04.853208
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        pass
    """

    expected_source = """
    def foo(a: unicode):
        pass
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == expected_source

# Generated at 2022-06-18 00:34:21.366431
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
    def foo(a: unicode):
        pass
    """)

# Generated at 2022-06-18 00:34:24.225920
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:34:29.886737
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        print(str(1))
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        print(unicode(1))
    """)

# Generated at 2022-06-18 00:34:33.597265
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)))

# Generated at 2022-06-18 00:34:40.495588
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    expected_tree = source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:34:45.242615
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:34:50.786775
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(a: str):
            pass
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == '''
        def foo(a: unicode):
            pass
    '''

# Generated at 2022-06-18 00:34:58.469571
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """
    expected_tree = source_to_ast(source)
    expected_tree.body[0].body[0].value.func.id = 'unicode'

    tree = source_to_ast(source)
    new_tree, _ = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:34:59.296910
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:35:05.085551
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    code = '''
        def foo(bar: str):
            pass
    '''

    expected_code = '''
        def foo(bar: unicode):
            pass
    '''

    assert_transformation_result(StringTypesTransformer, code, expected_code)

# Generated at 2022-06-18 00:35:37.624236
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """

    expected_tree = source_to_tree("""
        def foo(x):
            return unicode(x)
    """)

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:35:46.311315
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_func_names

    source = """
        def foo():
            return str('bar')
    """

    expected_tree = parse_ast(source)
    expected_tree.body[0].body.body[0].value.func.id = 'unicode'
    expected_changed = True
    expected_func_names = get_func_names(expected_tree)

    tree = parse_ast(source)
    result = StringTypesTransformer.transform(tree)

    assert_transformation_result(result, expected_tree, expected_changed, expected_func_names)

# Generated at 2022-06-18 00:35:51.235417
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    new_tree = StringTypesTransformer.transform(tree)
    expected_tree = source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:35:52.651911
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:36:00.148029
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(a: str) -> str:
            return a
    """
    expected = """
        def foo(a: unicode) -> unicode:
            return a
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(new_tree, expected)

# Generated at 2022-06-18 00:36:01.486302
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:36:07.562225
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(bar):
            return str(bar)
    """

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:36:11.546622
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name

    # Test with a simple function

# Generated at 2022-06-18 00:36:15.170151
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo():
        return str(1)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.new_code == """
    def foo():
        return unicode(1)
    """

# Generated at 2022-06-18 00:36:21.696999
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:37:19.896874
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_module_as_main
    from . import fix_missing_locations

    source = """
        def foo(a):
            return str(a)
    """
    expected_source = """
        def foo(a):
            return unicode(a)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    tree = fix_missing_locations(tree)
    assert compare_ast(tree, expected_source)
    assert run_module_as_main(tree) == 0

# Generated at 2022-06-18 00:37:25.559986
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:37:35.390692
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import generate_source

    tree = ast.parse('''
    a = str(1)
    b = str(2)
    ''')

    print_tree(tree)
    print(generate_source(tree))

    new_tree, changed, errors = StringTypesTransformer.transform(tree)

    print_tree(new_tree)
    print(generate_source(new_tree))

    assert changed
    assert not errors
    assert generate_source(new_tree) == '''
    a = unicode(1)
    b = unicode(2)
    '''

# Generated at 2022-06-18 00:37:40.586287
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    expected_tree = source_to_tree("""
    def foo(x):
        return unicode(x)
    """)

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:37:47.955405
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    expected_tree = source_to_tree("""
        def foo(bar):
            return unicode(bar)
    """)

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:37:53.452488
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_node
    from ..utils.visitor import visit_tree

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    visit_tree(tree, print_node)
    print(tree_to_str(tree))
    result = StringTypesTransformer.transform(tree)
    visit_tree(result.tree, print_node)
    print(tree_to_str(result.tree))
    assert result.tree_changed == True
    assert result.errors == []

# Generated at 2022-06-18 00:38:03.182623
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:38:07.956863
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.__doc__ == 'Replaces `str` with `unicode`.'
    assert StringTypesTransformer.target == (2, 7)


# Generated at 2022-06-18 00:38:13.330588
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))

# Generated at 2022-06-18 00:38:14.157480
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-18 00:40:21.851099
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    a = str(1)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, """
    a = unicode(1)
    """)