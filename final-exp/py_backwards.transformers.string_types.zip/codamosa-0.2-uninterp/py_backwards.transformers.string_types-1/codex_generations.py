

# Generated at 2022-06-18 00:30:27.345371
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    expected_tree = source_to_tree("""
        def foo(bar):
            return unicode(bar)
    """)

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:30:30.395748
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:30:31.978325
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:30:36.639729
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_tree = source_to_tree("""
    def foo(a):
        return unicode(a)
    """)

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:30:41.824564
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(a: str):
        pass
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(a: unicode):
        pass
    """))

# Generated at 2022-06-18 00:30:46.344070
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find

    test_code = """
    def test(a):
        b = str(a)
        return b
    """

    expected_code = """
    def test(a):
        b = unicode(a)
        return b
    """

    tree = ast.parse(test_code)
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == expected_code
    assert result.tree_changed == True
    assert result.messages == []

# Generated at 2022-06-18 00:30:52.768622
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(1)
        b = str(2)
    """)

    tree = ast.parse(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode(1)
        b = unicode(2)
    """)))

# Generated at 2022-06-18 00:30:58.541759
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    expected = """
    def foo(x):
        return unicode(x)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:31:04.923680
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """
    expected = """
        def foo(bar):
            return unicode(bar)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(expected, new_tree)

# Generated at 2022-06-18 00:31:10.513656
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:31:12.846985
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:16.076219
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(a):
        b = str(a)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.code == """
    def foo(a):
        b = unicode(a)
    """

# Generated at 2022-06-18 00:31:17.305452
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:24.738329
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x: str) -> str:
            return x
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree.tree) == source_to_unicode("""
        def foo(x: unicode) -> unicode:
            return x
    """)

# Generated at 2022-06-18 00:31:30.880817
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        str('hello')
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        unicode('hello')
    """)))

# Generated at 2022-06-18 00:31:38.134408
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a: str):
        pass
    """)

    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a: unicode):
        pass
    """)

# Generated at 2022-06-18 00:31:42.547270
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:31:50.694242
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, "str", "unicode")
    assert_transformation(StringTypesTransformer, "str()", "unicode()")
    assert_transformation(StringTypesTransformer, "str(1)", "unicode(1)")
    assert_transformation(StringTypesTransformer, "str(1, 2)", "unicode(1, 2)")
    assert_transformation(StringTypesTransformer, "str(1, 2, 3)", "unicode(1, 2, 3)")
    assert_transformation(StringTypesTransformer, "str(1, 2, 3, 4)", "unicode(1, 2, 3, 4)")

# Generated at 2022-06-18 00:31:57.331250
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """

    expected_tree = source_to_tree("""
    def foo(a):
        return unicode(a)
    """)

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:32:04.074760
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
        def foo(x):
            return str(x)
    """

    expected_tree = source_to_tree("""
        def foo(x):
            return unicode(x)
    """)

    tree = source_to_tree(source)
    result = StringTypesTransformer.transform(tree)
    assert compare_trees(result.tree, expected_tree)

# Generated at 2022-06-18 00:32:15.716286
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
        def foo(a):
            return unicode(a)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:32:22.937275
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []
    assert ast.dump(tree.tree) == ast.dump(source_to_ast("""
    def foo(a: unicode):
        return a
    """))

# Generated at 2022-06-18 00:32:27.745751
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet

    snippet = load_example_snippet('str_types.py')
    expected_tree = load_example_snippet('str_types_expected.py')
    assert_transformation_result(StringTypesTransformer, snippet, expected_tree)

# Generated at 2022-06-18 00:32:36.688620
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.visitor import NodeTransformer

    class TestTransformer(NodeTransformer):
        def visit_Name(self, node):
            if node.id == 'str':
                node.id = 'unicode'
            return node

    code = """
    a = str()
    b = str(1)
    c = str(1, 2)
    d = str(1, 2, 3)
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert to_src(tree) == """
    a = unicode()
    b = unicode(1)
    c = unicode(1, 2)
    d = unicode(1, 2, 3)
    """



# Generated at 2022-06-18 00:32:42.639854
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(bar):
            return str(bar)
    """

    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert new_tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:32:52.884511
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """

    expected_ast = """
        Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """

    ast = source_to_ast(source)
    new_ast = run

# Generated at 2022-06-18 00:32:58.862903
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:33:04.926950
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree.tree) == source_to_unicode("""
        def foo(a: unicode):
            pass
    """)

# Generated at 2022-06-18 00:33:15.144902
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('a = str("hello")')
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'a = unicode("hello")'

    tree = get_ast('a = str("hello")')
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'a = unicode("hello")'

    tree = get_ast('a = str("hello")')
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'a = unicode("hello")'

# Generated at 2022-06-18 00:33:24.562023
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse("""
    def foo(x):
        return unicode(x)
    """))

    # Test 2
    code = """
    def foo(x):
        return x
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert not result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse(code))

# Generated at 2022-06-18 00:33:28.975960
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo():
        return str()
    """
    tree = source_to_ast(source)
    assert StringTypesTransformer.transform(tree).tree_changed

# Generated at 2022-06-18 00:33:34.625249
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet

    snippet = load_example_snippet('string_types.py')
    expected_tree = load_example_snippet('string_types_unicode.py')

    assert_transformation_result(
        StringTypesTransformer,
        snippet,
        expected_tree,
    )

# Generated at 2022-06-18 00:33:35.585956
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:33:41.325025
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:33:44.703534
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        StringTypesTransformer,
        '''
        x = str(1)
        ''',
        '''
        x = unicode(1)
        '''
    )

# Generated at 2022-06-18 00:33:50.657616
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(1)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        a = unicode(1)
    """)

# Generated at 2022-06-18 00:34:01.091812
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    from ..utils.testing import assert_transformation_result

    assert_transformation(StringTypesTransformer, 'str', 'unicode')
    assert_transformation(StringTypesTransformer, 'str()', 'unicode()')
    assert_transformation(StringTypesTransformer, 'str(x)', 'unicode(x)')
    assert_transformation(StringTypesTransformer, 'str(x, y)', 'unicode(x, y)')
    assert_transformation(StringTypesTransformer, 'str(x, y, z)', 'unicode(x, y, z)')
    assert_transformation(StringTypesTransformer, 'str(x, y, z, a)', 'unicode(x, y, z, a)')

# Generated at 2022-06-18 00:34:10.632872
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str()
        b = str(a)
        c = str(a, b)
        d = str(a, b, c)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        a = unicode()
        b = unicode(a)
        c = unicode(a, b)
        d = unicode(a, b, c)
    """)

# Generated at 2022-06-18 00:34:20.132929
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
        def foo(bar):
            return str(bar)
    """
    expected_ast = """
        Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='bar', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='bar', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """

    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.transform(tree)

    assert compare

# Generated at 2022-06-18 00:34:28.601344
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a):
        return str(a)
    """)
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert tree_to_str(new_tree) == source_to_unicode("""
    def foo(a):
        return unicode(a)
    """)

# Generated at 2022-06-18 00:34:35.693283
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse("""
    def foo(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:34:43.893070
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name

    tree = ast_call(ast_name('str'), [])
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'unicode()'

    tree = ast_call(ast_name('str'), [])
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == 'unicode()'

# Generated at 2022-06-18 00:34:48.621300
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_builder import build_ast

    tree = build_ast("""
        a = str()
    """)

    tree = StringTypesTransformer.transform(tree).tree

    assert astor.to_source(tree) == "a = unicode()\n"

# Generated at 2022-06-18 00:34:54.440595
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, new_tree)

# Generated at 2022-06-18 00:34:58.646920
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:35:04.326112
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('def foo(x): return str(x)')
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'def foo(x): return unicode(x)'

# Generated at 2022-06-18 00:35:05.265348
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:35:09.163473
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(a: str):
        return a
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(a: unicode):
        return a
    """

# Generated at 2022-06-18 00:35:14.980205
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet
    from ..utils.testing import load_transformed_snippet

    snippet = load_example_snippet('string_types.py')
    expected = load_transformed_snippet('string_types.py')

    assert_transformation_result(StringTypesTransformer, snippet, expected)

# Generated at 2022-06-18 00:35:21.569573
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:35:29.177968
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:35:32.569098
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:35:40.160433
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Test if the transformer works correctly
    tree = ast.parse("""
    def foo(x):
        return str(x)
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse("""
    def foo(x):
        return unicode(x)
    """))

    # Test 2: Test if the transformer works correctly
    tree = ast.parse("""
    def foo(x):
        return x
    """)
    result = StringTypesTransformer.transform(tree)
    assert not result.tree_changed
    assert result.messages == []

# Generated at 2022-06-18 00:35:42.993172
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:35:51.202424
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    tree = ast.parse("""
        def foo(a):
            return str(a)
    """)
    expected_tree = ast.parse("""
        def foo(a):
            return unicode(a)
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.warnings == []

    # Test 2
    tree = ast.parse("""
        def foo(a):
            return str(a)
    """)
    expected_tree = ast.parse("""
        def foo(a):
            return unicode(a)
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True


# Generated at 2022-06-18 00:35:57.787250
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:36:04.026603
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    expected = """
    def foo(bar):
        return unicode(bar)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:36:08.045052
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformed_code_equals
    assert_transformed_code_equals(
        StringTypesTransformer,
        """
        a = str()
        """,
        """
        a = unicode()
        """
    )

# Generated at 2022-06-18 00:36:15.129538
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x: str):
            pass
    """

    expected = """
        def foo(x: unicode):
            pass
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected, new_tree)

# Generated at 2022-06-18 00:36:19.993893
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """

    expected = """
    def foo(x):
        return unicode(x)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:36:27.278985
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    def foo(x):
        return str(x)
    '''
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == '''
    def foo(x):
        return unicode(x)
    '''

# Generated at 2022-06-18 00:36:33.310260
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_factory

    tree = ast_factory('''
    def foo(x):
        return str(x)
    ''')

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert len(result.messages) == 0
    assert astor.to_source(result.tree) == '''
    def foo(x):
        return unicode(x)
    '''

# Generated at 2022-06-18 00:36:41.411064
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:36:44.809447
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:36:49.416063
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            pass
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a: unicode):
            pass
    """)))

# Generated at 2022-06-18 00:36:56.190234
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []
    assert ast.dump(tree.tree) == ast.dump(source_to_ast("""
        def foo(x):
            return unicode(x)
    """))

# Generated at 2022-06-18 00:36:57.917983
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    # Test 1: Test with a simple program

# Generated at 2022-06-18 00:37:02.628158
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(a: str):
            pass
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:37:10.205433
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:37:12.932583
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)


# Generated at 2022-06-18 00:37:20.575764
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(x):
            return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:37:24.951415
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:37:30.698671
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x: str):
            pass
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x: unicode):
            pass
    """)

# Generated at 2022-06-18 00:37:36.242024
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def f(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def f(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:37:40.465422
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:37:49.820106
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast

# Generated at 2022-06-18 00:38:00.454493
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = '''
        def foo(x):
            return str(x)
    '''
    expected_ast = '''
        Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    '''
    tree = source_to_ast(source)
    new

# Generated at 2022-06-18 00:38:07.418797
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, source_to_tree('''
        def foo(x):
            return unicode(x)
    '''))

# Generated at 2022-06-18 00:38:09.226890
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str(1)')) == TransformationResult(ast.parse('unicode(1)'), True, [])

# Generated at 2022-06-18 00:38:13.271099
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = '''
    def foo(bar):
        return str(bar)
    '''

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert find(tree, ast.Name).pop().id == 'unicode'

# Generated at 2022-06-18 00:38:24.324499
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:38:30.409254
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
        def foo(bar):
            return str(bar)
    '''
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:38:34.828499
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(a: str):
            pass
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(a: unicode):
            pass
    """

# Generated at 2022-06-18 00:38:41.329411
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(bar):
        return str(bar)
    """
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed
    assert ast.dump(new_tree) == ast.dump(ast.parse("""
    def foo(bar):
        return unicode(bar)
    """))

# Generated at 2022-06-18 00:38:46.134680
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    tree = source_to_tree('''
        def foo(s: str):
            return s
    ''')
    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, '''
        def foo(s: unicode):
            return s
    ''')

# Generated at 2022-06-18 00:38:56.079203
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet
    from ..utils.testing import load_transformed_snippet

    example_snippet_path = 'examples/string_types.py'
    transformed_snippet_path = 'examples/string_types_transformed.py'

    example_snippet = load_example_snippet(example_snippet_path)
    transformed_snippet = load_transformed_snippet(transformed_snippet_path)

    transformer = StringTypesTransformer()
    result = transformer.transform(example_snippet)

    assert_transformation_result(result, transformed_snippet)

# Generated at 2022-06-18 00:39:01.291327
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:39:07.906934
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, """
    def foo(bar):
        return unicode(bar)
    """)

# Generated at 2022-06-18 00:39:12.896634
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert ast.dump(tree) == ast.dump(source_to_ast("""
    def foo(a: unicode):
        pass
    """))

# Generated at 2022-06-18 00:39:21.638538
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """
    expected_tree = source_to_ast(source)
    expected_tree.body[0].body[0].value.func.id = 'unicode'

    tree = source_to_ast(source)
    new_tree, _ = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:39:44.810554
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo():
        return str(1)
    """
    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert ast.dump(new_tree) == ast.dump(source_to_ast("""
    def foo():
        return unicode(1)
    """))

# Generated at 2022-06-18 00:39:51.192065
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x):
            return str(x)
    """
    expected = """
        def foo(x):
            return unicode(x)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:39:59.871386
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert len(tree.errors) == 0
    assert len(find(tree.tree, ast.Name)) == 1
    assert find(tree.tree, ast.Name)[0].id == 'unicode'
    assert astor.to_source(tree.tree) == 'unicode'

    tree = get_ast('str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert len(tree.errors) == 0
    assert len(find(tree.tree, ast.Name)) == 1

# Generated at 2022-06-18 00:40:09.791170
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast

    source = """
    a = str()
    """

    expected_ast = """
    Module(body=[
        Assign(
            targets=[Name(id='a', ctx=Store())],
            value=Call(
                func=Name(id='unicode', ctx=Load()),
                args=[],
                keywords=[],
                starargs=None,
                kwargs=None
            )
        )
    ])
    """

    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert compare_ast(new_tree.tree, expected_ast)

# Generated at 2022-06-18 00:40:14.930046
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree.tree_changed
    assert len(tree.messages) == 0
    assert len(find(tree.node, ast.Name)) == 1
    assert astor.to_source(tree.node).count('unicode') == 1

# Generated at 2022-06-18 00:40:22.341592
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))