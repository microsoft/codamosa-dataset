

# Generated at 2022-06-18 00:30:34.451205
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    compare_trees(tree, """
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:30:37.407693
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:30:45.593198
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_source = """
    def foo(a):
        return unicode(a)
    """
    expected_tree = source_to_tree(expected_source)
    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:30:52.196783
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def test(x):
            return str(x)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_source = """
        def test(x):
            return unicode(x)
    """
    expected_tree = source_to_tree(expected_source)

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:30:57.270559
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, """
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:31:05.908708
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree).tree

    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=Name(id='unicode', ctx=Load()))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"

# Generated at 2022-06-18 00:31:11.573931
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a):
        return str(a)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
    def foo(a):
        return unicode(a)
    """)

# Generated at 2022-06-18 00:31:15.139783
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
    def foo(a: str):
        pass
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == '''
    def foo(a: unicode):
        pass
    '''

# Generated at 2022-06-18 00:31:18.991759
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:31:27.203714
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo():
        return str(1)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert messages == []
    assert ast.dump(tree) == ast.dump(source_to_ast("""
    def foo():
        return unicode(1)
    """))

# Generated at 2022-06-18 00:31:33.625239
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    source = """
    def foo(x):
        return str(x)
    """

    expected_tree = """
    def foo(x):
        return unicode(x)
    """

    assert_transformation_result(StringTypesTransformer, source, expected_tree)

# Generated at 2022-06-18 00:31:37.821613
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        x = str(y)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        x = unicode(y)
    """

# Generated at 2022-06-18 00:31:39.686100
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:31:40.244479
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:31:46.024445
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
        def foo(a: str):
            return a
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_ast(new_tree, """
        def foo(a: unicode):
            return a
    """)

# Generated at 2022-06-18 00:31:52.630276
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str(1)')) == TransformationResult(ast.parse('unicode(1)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str(1) + str(2)')) == TransformationResult(ast.parse('unicode(1) + unicode(2)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str(1) + str(2) + str(3)')) == TransformationResult(ast.parse('unicode(1) + unicode(2) + unicode(3)'), True, [])

# Generated at 2022-06-18 00:31:58.592974
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    a = str(1)
    """
    expected_ast = """
    Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))])
    """
    ast = source_to_ast(source)
    new_ast = run_transformer(StringTypesTransformer, ast)
    assert compare_ast(ast, expected_ast)

# Generated at 2022-06-18 00:32:04.701660
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(a: str):
        pass
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []
    assert ast.dump(tree.tree) == ast.dump(source_to_ast("""
    def foo(a: unicode):
        pass
    """))

# Generated at 2022-06-18 00:32:06.310391
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:32:13.714240
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

# Generated at 2022-06-18 00:32:17.858227
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)


# Generated at 2022-06-18 00:32:26.384598
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source
    from ..utils.source import source_to_tree
    from ..utils.source import tree_to_source

    source = """
    a = str(b)
    """

    expected_source = """
    a = unicode(b)
    """

    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree_to_source(new_tree.tree), expected_source)

# Generated at 2022-06-18 00:32:32.070554
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
        def foo(a):
            return str(a)
    """
    expected = """
        def foo(a):
            return unicode(a)
    """
    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert compare_ast(new_tree, expected)

# Generated at 2022-06-18 00:32:37.863527
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)))

# Generated at 2022-06-18 00:32:48.842242
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    expected_tree = source_to_ast(source)
    expected_tree.body[0].body.body[0].value.func.id = 'unicode'
    expected_source = """
    def foo(x):
        return unicode(x)
    """

    tree = source_to_ast(source)
    new_tree, changed = run_transformer(StringTypesTransformer, tree)
    assert changed
    assert compare_ast(expected_tree, new_tree)
    assert expected_source == ast.unparse(new_tree)

# Generated at 2022-06-18 00:32:58.547153
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Replace str with unicode
    test_tree = ast.parse("""
    def foo():
        return str()
    """)
    expected_tree = ast.parse("""
    def foo():
        return unicode()
    """)
    result = StringTypesTransformer.transform(test_tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.messages == []

    # Test 2: No change
    test_tree = ast.parse("""
    def foo():
        return unicode()
    """)
    expected_tree = ast.parse("""
    def foo():
        return unicode()
    """)
    result = StringTypesTransformer.transform(test_tree)
    assert result.tree == expected_tree

# Generated at 2022-06-18 00:33:06.093198
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer
    from ..utils.source import tree_to_source

    source = """
    def foo(bar):
        return str(bar)
    """

    expected_source = """
    def foo(bar):
        return unicode(bar)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree_to_source(new_tree), expected_source)

# Generated at 2022-06-18 00:33:15.144909
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_module_as_main
    from ..utils.source import source_to_ast

    source = """
        def foo(a):
            return str(a)
    """
    expected_source = """
        def foo(a):
            return unicode(a)
    """

    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert compare_ast(new_tree, expected_source)

    run_module_as_main(StringTypesTransformer, source)

# Generated at 2022-06-18 00:33:16.787370
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:33:20.334112
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert astor.to_source(tree.tree).strip() == 'unicode'

# Generated at 2022-06-18 00:33:27.510063
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet
    from ..utils.testing import load_transformed_snippet
    from ..utils.testing import load_transformed_tree

    source = load_example_snippet('string_types.py')
    expected_tree = load_transformed_tree('string_types.py')
    expected_source = load_transformed_snippet('string_types.py')

    result = StringTypesTransformer.transform(source)

    assert_transformation_result(result, expected_tree, expected_source)

# Generated at 2022-06-18 00:33:34.766737
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = '''
        def foo(x: str):
            pass
    '''

    expected_tree = source_to_ast('''
        def foo(x: unicode):
            pass
    ''')

    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:33:40.117462
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
    def foo(bar):
        return str(bar)
    '''

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, new_tree)

# Generated at 2022-06-18 00:33:44.222752
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str("foo")')
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == 'unicode("foo")'

# Generated at 2022-06-18 00:33:50.516969
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:33:54.479751
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    source = """
        def foo(x):
            return str(x)
    """
    expected = """
        def foo(x):
            return unicode(x)
    """
    assert_transformation_result(StringTypesTransformer, source, expected)

# Generated at 2022-06-18 00:34:01.143748
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
        def foo(a):
            return str(a)
    """

    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)

    expected_tree = source_to_tree("""
        def foo(a):
            return unicode(a)
    """)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:34:07.083964
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    source = """
        def foo(x):
            return str(x)
    """
    tree = source_to_tree(source)
    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, """
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:34:11.891464
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:34:18.967124
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from ..utils.source import source_to_unicode

    source = source_to_unicode("""
    def foo(bar):
        return str(bar)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    code = astunparse.unparse(new_tree)
    assert code == source_to_unicode("""
    def foo(bar):
        return unicode(bar)
    """)

# Generated at 2022-06-18 00:34:30.703496
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_unicode
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
    def foo(x):
        return str(x)
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)

    expected = source_to_unicode("""
    def foo(x):
        return unicode(x)
    """)

    assert node_to_unicode(tree) == expected

# Generated at 2022-06-18 00:34:36.517012
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = """
    def foo():
        return str()
    """
    expected_code = """
    def foo():
        return unicode()
    """
    tree = ast.parse(code)

    # When
    result = StringTypesTransformer.transform(tree)

    # Then
    assert result.tree_changed
    assert ast.dump(result.tree) == expected_code

# Generated at 2022-06-18 00:34:43.213722
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:34:47.616502
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    import textwrap
    code = textwrap.dedent('''
    def foo(a: str):
        return a
    ''')
    tree = astor.parse_file(code)
    tree = StringTypesTransformer.transform(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-18 00:34:57.971205
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_visitor
    from ..utils.visitor import compare_visitors
    from ..utils.visitor import compare_trees
    from ..utils.visitor import print_visitor
    from ..utils.visitor import compare_visitors
    from ..utils.visitor import compare_trees
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.tree import tree_to_str
    from ..utils.visitor import print_visitor
   

# Generated at 2022-06-18 00:35:04.710275
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(1)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        a = unicode(1)
    """)

# Generated at 2022-06-18 00:35:12.034291
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(a):
        return str(a)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
    def foo(a):
        return unicode(a)
    """)))

# Generated at 2022-06-18 00:35:17.681019
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:35:25.188614
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:35:30.336707
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(x):
            return str(x)
    """

    expected_source = """
        def foo(x):
            return unicode(x)
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)

    assert ast.dump(tree) == ast.dump(source_to_ast(expected_source))

# Generated at 2022-06-18 00:35:41.514542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed

    for node in find(tree.tree, ast.Name):
        assert node.id != 'str'

# Generated at 2022-06-18 00:35:45.772915
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:35:46.883051
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:35:50.665902
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet
    snippet = load_example_snippet('string_types.py')
    expected_tree = load_example_snippet('string_types_unicode.py')
    assert_transformation_result(StringTypesTransformer, snippet, expected_tree)

# Generated at 2022-06-18 00:35:55.821880
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.visitor import NodeTransformer

    class TestTransformer(NodeTransformer):
        def visit_Name(self, node):
            if node.id == 'str':
                node.id = 'unicode'
            return node

    tree = ast.parse('str')
    tree_changed = False
    tree_changed = StringTypesTransformer.transform(tree).tree_changed
    assert tree_changed
    assert to_src(tree) == 'unicode'
    tree = ast.parse('str')
    tree_changed = TestTransformer().visit(tree)
    assert to_src(tree) == 'unicode'

# Generated at 2022-06-18 00:36:01.527601
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:36:10.529796
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Replace str with unicode
    tree = ast.parse("""
    def foo(a):
        return str(a)
    """)
    expected_tree = ast.parse("""
    def foo(a):
        return unicode(a)
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.errors == []

    # Test 2: No replacement
    tree = ast.parse("""
    def foo(a):
        return a
    """)
    expected_tree = ast.parse("""
    def foo(a):
        return a
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == False

# Generated at 2022-06-18 00:36:14.814737
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)
    assert StringTypesTransformer.transform.__name__ == 'transform'
    assert StringTypesTransformer.transform.__doc__ == 'Replaces `str` with `unicode`. '


# Generated at 2022-06-18 00:36:17.345723
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo():
        return str(1)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo():
        return unicode(1)
    """

# Generated at 2022-06-18 00:36:19.767516
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:36:38.150270
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_factory import ast_call, ast_name

    tree = ast_call(
        ast_name('foo'),
        [ast_name('bar')],
        keywords=[ast_name('baz')]
    )
    tree_changed, _ = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert astor.to_source(tree) == 'foo(bar, baz=baz)'

# Generated at 2022-06-18 00:36:42.986069
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("""
        def foo(x: str):
            pass
    """)).tree == ast.parse("""
        def foo(x: unicode):
            pass
    """)

# Generated at 2022-06-18 00:36:48.839873
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.tree import find

    tree = source_to_tree('''
        def foo(a):
            return str(a)
    ''')

    tree = StringTypesTransformer.transform(tree)
    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, source_to_tree('''
        def foo(a):
            return unicode(a)
    '''))

# Generated at 2022-06-18 00:36:53.653399
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo(x):
            return str(x)
    """)
    expected = ast.parse("""
        def foo(x):
            return unicode(x)
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected

# Generated at 2022-06-18 00:37:02.693699
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a: str):
            return a
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
        def foo(a: str):
            return a
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:37:10.328899
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:37:17.908181
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    expected = """
    def foo(a):
        return unicode(a)
    """

    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(new_tree, expected)

# Generated at 2022-06-18 00:37:24.695814
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)))

# Generated at 2022-06-18 00:37:26.794499
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Test the constructor of class StringTypesTransformer
    """
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-18 00:37:34.284414
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x: str):
            return x
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x: unicode):
            return x
    """)

# Generated at 2022-06-18 00:38:03.580832
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(bar):
            return str(bar)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(bar):
            return unicode(bar)
    """

# Generated at 2022-06-18 00:38:10.038807
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)
    assert compare_trees(tree, source_to_tree('''
        def foo(x):
            return unicode(x)
    '''))

# Generated at 2022-06-18 00:38:17.335707
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert messages == []
    assert ast.dump(tree) == ast.dump(source_to_ast("""
    def foo(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:38:19.986492
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:38:23.973662
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result

    code = '''
        def foo(x):
            return str(x)
    '''

    expected_code = '''
        def foo(x):
            return unicode(x)
    '''

    assert_transformation_result(StringTypesTransformer, code, expected_code)

# Generated at 2022-06-18 00:38:29.219969
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    code = """
        def foo(a):
            return str(a)
    """
    expected_code = """
        def foo(a):
            return unicode(a)
    """
    assert_transformation_result(StringTypesTransformer, code, expected_code)

# Generated at 2022-06-18 00:38:33.930072
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        StringTypesTransformer,
        '''
        import sys
        print(str(sys.version_info))
        ''',
        '''
        import sys
        print(unicode(sys.version_info))
        '''
    )

# Generated at 2022-06-18 00:38:37.372438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:38:45.578825
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
    def foo(x: str):
        return x
    """)

    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(x: unicode):
        return x
    """)

# Generated at 2022-06-18 00:38:48.721981
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert tree.body[0].body.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:40:00.770340
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        a = str(1)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode(1)
    """)))

# Generated at 2022-06-18 00:40:04.272937
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(a):
        return str(a)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(a):
        return unicode(a)
    """))

# Generated at 2022-06-18 00:40:10.828928
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(bar):
        return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(bar):
        return unicode(bar)
    """)

# Generated at 2022-06-18 00:40:13.793628
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x: str):
            pass
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x: unicode):
            pass
    """

# Generated at 2022-06-18 00:40:18.802319
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:40:23.378447
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert astor.to_source(new_tree) == source.replace('str', 'unicode')

# Generated at 2022-06-18 00:40:30.425846
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.dump import dump_tree

    tree = source_to_tree('''
        def foo(a: str, b: str):
            return a + b
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, source_to_tree('''
        def foo(a: unicode, b: unicode):
            return a + b
    '''))