

# Generated at 2022-06-18 00:30:27.531912
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str(1)')) == TransformationResult(ast.parse('unicode(1)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str')) == TransformationResult(ast.parse('unicode'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str(1) + str(2)')) == TransformationResult(ast.parse('unicode(1) + unicode(2)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('str(1) + str(2) + str(3)')) == TransformationResult(ast.parse('unicode(1) + unicode(2) + unicode(3)'), True, [])

# Generated at 2022-06-18 00:30:36.989758
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
    a = str()
    ''')

    new_tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, new_tree.tree)

    tree = source_to_tree('''
    a = unicode()
    ''')

    new_tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, new_tree.tree)

    tree = source_to_tree('''
    a = str()
    ''')

    new_tree = StringTypesTransformer.transform(tree)


# Generated at 2022-06-18 00:30:38.889207
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:30:46.990527
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    expected_tree = source_to_tree(source)
    expected_tree.body[0].body.body[0].value.func.id = 'unicode'

    tree = source_to_tree(source)
    new_tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:30:51.546595
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..utils.visitor import NodeTransformer
    from ..utils.source import Source

    source = Source("""
    a = str(1)
    """)

    tree = ast.parse(source.read())
    tree = NodeTransformer().visit(tree)

    assert to_src(tree) == "a = unicode(1)"

# Generated at 2022-06-18 00:30:55.491819
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    # Test 1: Test if the class can be initialized
    try:
        StringTypesTransformer()
    except:
        assert False
    assert True


# Generated at 2022-06-18 00:31:05.498679
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import ast_to_source

    source = source_to_unicode('''
        def foo(a: str):
            return a
    ''')
    tree = source_to_ast(source)
    transformer = StringTypesTransformer()
    new_tree, changed = transformer.transform(tree)
    assert changed
    new_source = ast_to_source(new_tree)
    assert source_to_unicode(new_source) == source_to_unicode('''
        def foo(a: unicode):
            return a
    ''')

# Generated at 2022-06-18 00:31:13.522419
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    # Test 1: Test that the transformer works as expected
    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

    # Test 2: Test that the transformer does not change anything
    tree = source_to_ast("""
        def foo(x):
            return x
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
        def foo(x):
            return x
    """

# Generated at 2022-06-18 00:31:22.365393
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    test_code = """
    a = str()
    """
    expected_code = """
    a = unicode()
    """
    tree = ast.parse(test_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == expected_code

    # Test 2
    test_code = """
    a = str(1)
    """
    expected_code = """
    a = unicode(1)
    """
    tree = ast.parse(test_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == expected_code

    # Test 3


# Generated at 2022-06-18 00:31:29.164622
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    expected = """
    def foo(bar):
        return unicode(bar)
    """
    tree = source_to_ast(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:31:39.351210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = NodeTransformerVisitor(StringTypesTransformer).visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:31:46.529252
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
    a = str(1)
    b = str(2)
    '''
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    expected_tree = source_to_tree('''
    a = unicode(1)
    b = unicode(2)
    ''')

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:31:50.749360
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet

    snippet = load_example_snippet('string_types.py')
    expected_tree = load_example_snippet('string_types.py', target=(2, 7))

    assert_transformation_result(StringTypesTransformer, snippet, expected_tree)

# Generated at 2022-06-18 00:31:54.207973
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast("""
    def foo(a):
        return str(a)
    """)

    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == """
    def foo(a):
        return unicode(a)
    """

# Generated at 2022-06-18 00:32:03.557750
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    expected_tree = source_to_ast(source)
    expected_tree.body[0].body[0].value.func.id = 'unicode'

    tree = source_to_ast(source)
    new_tree, _ = run_transformer(StringTypesTransformer, tree)

    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-18 00:32:06.269850
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(1)')
    new_tree = StringTypesTransformer.transform(tree)
    assert new_tree.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:32:13.252891
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """

    tree = source_to_ast(source)
    t = StringTypesTransformer()
    new_tree, changed = t.transform(tree)

    assert changed
    assert new_tree is not tree

    assert new_tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:32:18.120900
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, source_to_tree('''
        def foo(x):
            return unicode(x)
    '''))

# Generated at 2022-06-18 00:32:19.924046
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:32:24.858722
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Create AST
    tree = ast.parse('str("Hello World")')

    # Apply transformation
    new_tree = StringTypesTransformer.transform(tree)

    # Check if the transformation was applied correctly
    assert new_tree.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:32:29.352680
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:29.962684
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:32:37.122996
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    expected_source = """
    def foo(x):
        return unicode(x)
    """

    tree = source_to_ast(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected_source))

# Generated at 2022-06-18 00:32:43.338577
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x: str):
            return x
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x: unicode):
            return x
    """)

# Generated at 2022-06-18 00:32:49.420453
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(1)')
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-18 00:32:54.273025
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:33:00.888122
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    expected_tree = source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

    tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:33:09.227895
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1:
    # Test that the constructor of class StringTypesTransformer works
    # correctly.
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)

    # Test 2:
    # Test that the method transform of class StringTypesTransformer works
    # correctly.
    tree = ast.parse('str')
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree.body[0].value.id == 'unicode'
    assert result.tree_changed == True
    assert result.messages == []

# Generated at 2022-06-18 00:33:18.749527
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:33:23.836823
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    x = str()
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-18 00:33:36.598349
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a):
            return str(a)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a):
            return unicode(a)
    """)))

# Generated at 2022-06-18 00:33:41.639174
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse
    from ..utils.source import source

    tree = parse(source('''
        def foo(bar):
            return str(bar)
    '''))

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert source(result.tree) == source('''
        def foo(bar):
            return unicode(bar)
    ''')

# Generated at 2022-06-18 00:33:42.644894
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:33:48.969978
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import source_to_tree

    source = """
    def f(x):
        return str(x)
    """
    tree = source_to_tree(source)
    print_tree(tree)
    tree = StringTypesTransformer.transform(tree).tree
    print_tree(tree)
    assert source_to_tree(source) != tree

# Generated at 2022-06-18 00:33:55.263332
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_ast

    source = """
    def test(a):
        return str(a)
    """
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.transform(tree)
    expected_tree = source_to_tree("""
    def test(a):
        return unicode(a)
    """)

    assert compare_ast(new_tree, expected_tree)

# Generated at 2022-06-18 00:33:58.606065
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:34:04.011148
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:34:10.712980
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, source_to_tree("""
    def foo(bar):
        return unicode(bar)
    """))

# Generated at 2022-06-18 00:34:19.345681
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
        def foo(bar):
            return unicode(bar)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:34:21.905419
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:34:34.371908
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:34:43.213774
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(s: str):
            return s
    """)
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert tree_to_str(new_tree.tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(s: unicode):
            return s
    """)))

# Generated at 2022-06-18 00:34:52.210858
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import NodeVisitor

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:35:00.641669
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def foo(x):
            return str(x)
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])"

# Generated at 2022-06-18 00:35:09.394621
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..utils.tree import to_src
    from ..utils.visitor import NodeTransformer

    class TestTransformer(NodeTransformer):
        def visit_Name(self, node):
            if node.id == 'str':
                node.id = 'unicode'
            return node

    tree = ast.parse('str')
    tree = StringTypesTransformer.transform(tree)
    assert to_src(tree) == 'unicode'

    tree = ast.parse('str')
    tree = TestTransformer().visit(tree)
    assert to_src(tree) == 'unicode'

# Generated at 2022-06-18 00:35:18.126498
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:35:19.899995
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(StringTypesTransformer, 'str', 'unicode')

# Generated at 2022-06-18 00:35:27.943787
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, """
    def foo(a):
        return unicode(a)
    """)

# Generated at 2022-06-18 00:35:36.733169
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(a: str):
            return a
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        def foo(a: unicode):
            return a
    """)))

# Generated at 2022-06-18 00:35:40.449141
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet
    snippet = load_example_snippet('string_types.py')
    expected_tree = load_example_snippet('string_types.py', target=(2, 7))
    assert_transformation_result(StringTypesTransformer, snippet, expected_tree)

# Generated at 2022-06-18 00:36:11.865003
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    from ..utils.tree import ast_from_str
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_source
    from ..utils.tree import ast_to_source_code
    from ..utils.tree import ast_to_source_code_with_comments
    from ..utils.tree import ast_to_source_code_with_comments_and_newlines
    from ..utils.tree import ast_to_source_code_with_newlines
    from ..utils.tree import ast_to_source_with_comments
    from ..utils.tree import ast_to_source_with_comments_and_newlines
    from ..utils.tree import ast_to_source_with_newlines
    from ..utils.tree import ast_to_source_with_newlines_and_

# Generated at 2022-06-18 00:36:15.439012
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(s: str):
        return s
    """)

    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
    def foo(s: unicode):
        return s
    """

# Generated at 2022-06-18 00:36:23.730485
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(StringTypesTransformer, 'str', 'unicode')
    assert_transformation(StringTypesTransformer, 'str(x)', 'unicode(x)')
    assert_transformation(StringTypesTransformer, 'str(x, y)', 'unicode(x, y)')
    assert_transformation(StringTypesTransformer, 'str(x, y, z)', 'unicode(x, y, z)')
    assert_transformation(StringTypesTransformer, 'str(x, y, z, a)', 'unicode(x, y, z, a)')
    assert_transformation(StringTypesTransformer, 'str(x, y, z, a, b)', 'unicode(x, y, z, a, b)')
    assert_

# Generated at 2022-06-18 00:36:25.491484
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:36:31.067865
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def foo(x):
            return str(x)
    """)
    expected_tree = ast.parse("""
        def foo(x):
            return unicode(x)
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.messages == []

# Generated at 2022-06-18 00:36:33.548910
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    tree = ast.parse('str')
    transformer = StringTypesTransformer()
    assert transformer.transform(tree) == TransformationResult(ast.parse('unicode'), True, [])

# Generated at 2022-06-18 00:36:37.855074
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
        def foo(x):
            return str(x)
    """)

    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.messages == []

    assert tree.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:36:44.924823
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result
    from ..utils.test_utils import parse_ast

    source = '''
        def foo(a: str):
            pass
    '''

    expected_tree = parse_ast('''
        def foo(a: unicode):
            pass
    ''')

    assert_transformation_result(StringTypesTransformer, source, expected_tree)

# Generated at 2022-06-18 00:36:49.086226
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast

    tree = get_ast('str')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert len(result.errors) == 0
    assert len(find(result.tree, ast.Name)) == 1
    assert astor.to_source(result.tree).strip() == 'unicode'

# Generated at 2022-06-18 00:36:56.808414
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    x = str()
    """

    expected_tree = source_to_tree(source)
    expected_tree.body[0].value.func.id = 'unicode'

    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:37:49.566307
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)
    assert StringTypesTransformer.transform.__name__ == 'transform'
    assert StringTypesTransformer.transform.__doc__ == 'Replaces `str` with `unicode`.'


# Generated at 2022-06-18 00:37:57.603221
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo(a):
            return str(a)
    ''')

    tree = StringTypesTransformer.transform(tree)
    source = tree_to_source(tree)

    assert compare_trees(tree, source_to_tree('''
        def foo(a):
            return unicode(a)
    '''))

# Generated at 2022-06-18 00:38:00.238841
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    assert StringTypesTransformer.transform(ast.parse('str(1)')) == TransformationResult(ast.parse('unicode(1)'), True, [])

# Generated at 2022-06-18 00:38:10.171347
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = '''
    def foo(bar):
        return str(bar)
    '''

    expected_ast = '''
    Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='bar', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='bar', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    '''

    ast = source_to_ast(source)
    new

# Generated at 2022-06-18 00:38:16.527177
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    a = str(1)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:38:17.877105
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:38:24.006155
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    expected_source = source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)

    assert changed is True
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(expected_source))

# Generated at 2022-06-18 00:38:24.800274
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:38:34.035696
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    visitor = NodeTransformerVisitor(StringTypesTransformer)
    visitor.visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:38:37.123487
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(tree, source_to_tree("""
    def foo(x):
        return unicode(x)
    """))