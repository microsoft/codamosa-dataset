

# Generated at 2022-06-18 00:30:35.212091
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
    def foo(x):
        return str(x)
    '''

    expected_tree = source_to_tree('''
    def foo(x):
        return unicode(x)
    ''')

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:30:42.352555
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        return a
    """

    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert new_tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:30:49.387347
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test case 1:
    #   input: 
    #       str
    #   expected output:
    #       unicode
    input_code = "str"
    expected_code = "unicode"
    tree = ast.parse(input_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.new_code == expected_code

    # Test case 2:
    #   input: 
    #       str(1)
    #   expected output:
    #       unicode(1)
    input_code = "str(1)"
    expected_code = "unicode(1)"
    tree = ast.parse(input_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.new_code == expected

# Generated at 2022-06-18 00:30:56.136651
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(bar: str):
        pass
    """)

    tree = StringTypesTransformer.transform(tree).tree

    assert ast.dump(tree) == ast.dump(source_to_ast("""
    def foo(bar: unicode):
        pass
    """))

# Generated at 2022-06-18 00:31:03.231931
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
        def foo(x: str):
            pass
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert len(messages) == 0

    assert tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-18 00:31:11.381422
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast

    source = """
    def foo(x: str):
        pass
    """
    tree = source_to_ast(source)
    print_tree(tree)
    print(ast_to_source(tree))
    result = StringTypesTransformer.transform(tree)
    print_tree(result.tree)
    print(ast_to_source(result.tree))


# Generated at 2022-06-18 00:31:16.716547
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    expected_tree = source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

    tree = run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:31:18.201833
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast("""
    def foo(a: str):
        pass
    """)

    assert StringTypesTransformer.transform(tree).tree_changed == True

# Generated at 2022-06-18 00:31:24.000554
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo():
        return str()
    """)
    expected_tree = ast.parse("""
    def foo():
        return unicode()
    """)
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree

# Generated at 2022-06-18 00:31:28.895378
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x: str):
        return x
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x: unicode):
        return x
    """

# Generated at 2022-06-18 00:31:39.147299
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(a: str):
        pass
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=Name(id='unicode', ctx=Load()))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"

# Generated at 2022-06-18 00:31:45.175099
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(a):
            return str(a)
    """

    tree = source_to_tree(source)
    tree = run_transformer(tree, StringTypesTransformer)

    assert compare_trees(tree, """
        def foo(a):
            return unicode(a)
    """)

# Generated at 2022-06-18 00:31:51.089608
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    def foo(bar):
        return str(bar)
    """)

    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    def foo(bar):
        return unicode(bar)
    """)

# Generated at 2022-06-18 00:31:58.173964
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    expected_tree = source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

    new_tree = run_transformer(tree, StringTypesTransformer)
    assert compare_trees(expected_tree, new_tree)

# Generated at 2022-06-18 00:32:05.890076
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        x = str(1)
        y = str(2)
    """)
    tree = ast.parse(source)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert tree_to_str(new_tree) == tree_to_str(ast.parse(source_to_unicode("""
        x = unicode(1)
        y = unicode(2)
    """)))

# Generated at 2022-06-18 00:32:13.201895
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:32:19.229096
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.__doc__ == 'Replaces `str` with `unicode`. '
    assert StringTypesTransformer.target == (2, 7)
    assert StringTypesTransformer.transform.__doc__ == 'Replaces `str` with `unicode`. '
    # Test for transform method of class StringTypesTransformer
    assert StringTypesTransformer.transform.__name__ == 'transform'
    assert StringTypesTransformer.transform.__doc__ == 'Replaces `str` with `unicode`. '
    assert StringTypesTransformer.transform.__annotations__ == {'tree': ast.AST, 'return': TransformationResult}

# Generated at 2022-06-18 00:32:28.457130
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(x: str):
            return x
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

    source = """
        def foo(x: str):
            return x
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:32:34.192905
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:32:40.090786
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """

    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    compare_trees(new_tree, tree)

# Generated at 2022-06-18 00:32:50.057281
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0

    source = """
    def foo(a: str):
        pass
    """
    tree = source_to_ast(source)
    tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0

# Generated at 2022-06-18 00:32:57.322922
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def foo(a):
        return str(a)
    """
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, source_to_tree(source.replace('str', 'unicode')))

# Generated at 2022-06-18 00:33:02.214258
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_ast(source)
    t = StringTypesTransformer()
    t.transform(tree)
    assert source_to_ast(t.code()) == source_to_ast("""
    def foo(a: unicode):
        return a
    """)

# Generated at 2022-06-18 00:33:10.086304
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(StringTypesTransformer)
    tree = get_ast(source)
    tree = StringTypesTransformer.transform(tree)

    assert len(find(tree, ast.Name)) == 1
    assert find(tree, ast.Name)[0].id == 'unicode'
    assert astor.to_source(tree) == source.replace('str', 'unicode')

# Generated at 2022-06-18 00:33:16.548047
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
    def f(x):
        return str(x)
    """

    expected_tree = source_to_tree(source.replace('str', 'unicode'))
    tree = source_to_tree(source)

    run_transformer(StringTypesTransformer, tree)

    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:33:20.200713
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:33:22.391370
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:33:25.873448
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    a = str(1)
    """
    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert source_to_ast("a = unicode(1)") == new_tree

# Generated at 2022-06-18 00:33:35.586115
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:33:41.325007
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    expected = """
    def foo(bar):
        return unicode(bar)
    """
    tree = source_to_ast(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:33:46.621533
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees


# Generated at 2022-06-18 00:33:52.683308
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:34:00.320766
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(a: str):
        pass
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=Name(id='unicode', ctx=Load()))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"

# Generated at 2022-06-18 00:34:06.478815
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test for constructor of class StringTypesTransformer
    """
    tree = ast.parse("""
        def foo(x):
            return str(x)
    """)
    assert StringTypesTransformer.transform(tree).tree_changed == True
    assert ast.dump(tree) == ast.dump(ast.parse("""
        def foo(x):
            return unicode(x)
    """))

# Generated at 2022-06-18 00:34:16.956186
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: Test if the class is properly initialized
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.tree is None
    assert transformer.tree_changed is False
    assert transformer.logs == []
    assert transformer.errors == []

    # Test 2: Test if the class is properly initialized with a tree
    transformer = StringTypesTransformer(ast.parse('a = 1'))
    assert transformer.target == (2, 7)
    assert transformer.tree is not None
    assert transformer.tree_changed is False
    assert transformer.logs == []
    assert transformer.errors == []

    # Test 3: Test if the class is properly initialized with a tree and target
    transformer = StringTypesTransformer(ast.parse('a = 1'), target=(2, 7))

# Generated at 2022-06-18 00:34:21.500999
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(bar):
        return str(bar)
    """
    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(bar):
        return unicode(bar)
    """

# Generated at 2022-06-18 00:34:25.678465
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("str(1)")).tree_changed == True
    assert StringTypesTransformer.transform(ast.parse("str(1)")).tree == ast.parse("unicode(1)")

# Generated at 2022-06-18 00:34:30.666552
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    code = """
        def foo(x):
            return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
        def foo(x):
            return unicode(x)
    """

# Generated at 2022-06-18 00:34:37.967616
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import ast_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert ast_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:34:39.513014
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:34:47.615944
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:34:54.666245
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = """
        def foo(bar):
            return str(bar)
    """
    expected = """
        def foo(bar):
            return unicode(bar)
    """
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:35:01.279329
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(a: str):
            return a
    ''')

    new_tree = StringTypesTransformer.transform(tree)
    expected_tree = source_to_tree('''
        def foo(a: unicode):
            return a
    ''')

    assert compare_trees(new_tree, expected_tree)

# Generated at 2022-06-18 00:35:06.522232
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(bar):
        return str(bar)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert ast.dump(tree.tree) == ast.dump(ast.parse("""
    def foo(bar):
        return unicode(bar)
    """))

# Generated at 2022-06-18 00:35:10.645897
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x: str):
        return x
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x: unicode):
        return x
    """

# Generated at 2022-06-18 00:35:17.904265
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import TreeVisitor

    source = source_to_unicode("""
        a = str(b)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == tree_to_str(ast.parse(source_to_unicode("""
        a = unicode(b)
    """)))

# Generated at 2022-06-18 00:35:29.307582
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
   

# Generated at 2022-06-18 00:35:39.510033
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
        def foo(a):
            return str(a)
    """
    expected_ast = """
        Module(body=[FunctionDef(name='foo', args=arguments(args=[arg(arg='a', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """
    ast = source_to_ast(source)
    new_ast = StringTypesTransformer.transform(ast)
    assert compare

# Generated at 2022-06-18 00:35:40.296424
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:35:47.034907
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def f(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def f(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:36:06.690485
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    tree = source_to_tree('''
        def foo(x):
            return str(x)
    ''')

    expected_tree = source_to_tree('''
        def foo(x):
            return unicode(x)
    ''')

    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, expected_tree)

# Generated at 2022-06-18 00:36:13.437139
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(a: str):
        return a
    """
    tree = source_to_ast(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert len(messages) == 0
    assert ast.dump(new_tree) == ast.dump(source_to_ast("""
    def foo(a: unicode):
        return a
    """))

# Generated at 2022-06-18 00:36:15.437450
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:36:20.971976
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation_result

    source = """
        def f(x):
            return str(x)
    """
    expected_tree = """
        def f(x):
            return unicode(x)
    """
    assert_transformation_result(StringTypesTransformer, source, expected_tree)

# Generated at 2022-06-18 00:36:27.751123
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:36:33.759366
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
        def foo(x):
            return str(x)
    '''
    expected = '''
        def foo(x):
            return unicode(x)
    '''
    tree = source_to_tree(source)
    new_tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(new_tree, expected)

# Generated at 2022-06-18 00:36:44.966272
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast

    source = """
        def foo(x):
            return str(x)
    """


# Generated at 2022-06-18 00:36:49.907917
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        x = str(1)
        y = str(2)
        z = str(3)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        x = unicode(1)
        y = unicode(2)
        z = unicode(3)
    """)

# Generated at 2022-06-18 00:36:56.340051
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet
    from ..utils.testing import load_transformed_snippet

    snippet = load_example_snippet('string_types.py')
    expected = load_transformed_snippet('string_types.py')

    transformer = StringTypesTransformer()
    result = transformer.transform(snippet)

    assert_transformation_result(result, expected)

# Generated at 2022-06-18 00:37:02.629049
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(bar):
            return str(bar)
    """)

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree_to_str(tree) == source_to_unicode("""
        def foo(bar):
            return unicode(bar)
    """)

# Generated at 2022-06-18 00:37:31.160474
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    tree = ast.parse('str("abc")')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse('unicode("abc")'))

    # Test 2
    tree = ast.parse('str("abc")')
    result = StringTypesTransformer.transform(tree)
    assert not result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse('unicode("abc")'))

# Generated at 2022-06-18 00:37:40.250727
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-18 00:37:47.954290
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.source import tree_to_source

    tree = source_to_tree('''
        def foo():
            return str(1)
        ''')

    expected_tree = source_to_tree('''
        def foo():
            return unicode(1)
        ''')

    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, expected_tree)
    assert tree_to_source(tree) == tree_to_source(expected_tree)

# Generated at 2022-06-18 00:37:52.256399
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer

    source = '''
        def foo(x):
            return str(x)
    '''
    tree = source_to_tree(source)
    tree = run_transformer(StringTypesTransformer, tree)
    assert compare_trees(tree, '''
        def foo(x):
            return unicode(x)
    ''')

# Generated at 2022-06-18 00:37:55.525885
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import find
    from ..utils.ast_helpers import get_ast


# Generated at 2022-06-18 00:37:57.649558
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees
    from ..utils.transform import run_transformer


# Generated at 2022-06-18 00:38:01.465687
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo():
        return str(1)
    """

    tree = source_to_ast(source)
    tree = StringTypesTransformer.transform(tree)

    assert tree.code == """
    def foo():
        return unicode(1)
    """

# Generated at 2022-06-18 00:38:06.275472
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('''
        def foo(a: str):
            pass
    ''')) == TransformationResult(ast.parse('''
        def foo(a: unicode):
            pass
    '''), True, [])

# Generated at 2022-06-18 00:38:13.931901
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    # Test 1
    tree = source_to_ast("""
        def foo(a: str):
            pass
    """)
    tree = StringTypesTransformer.transform(tree)
    assert tree.changed
    assert tree.messages == []
    assert ast.dump(tree.tree) == ast.dump(source_to_ast("""
        def foo(a: unicode):
            pass
    """))

    # Test 2
    tree = source_to_ast("""
        def foo(a: str):
            pass
    """)
    tree = StringTypesTransformer.transform(tree)
    assert not tree.changed
    assert tree.messages == []

# Generated at 2022-06-18 00:38:19.338569
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:39:19.590474
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src

    tree = ast.parse("""
    def foo():
        return str(1)
    """)
    tree = StringTypesTransformer.transform(tree)
    assert to_src(tree) == """
    def foo():
        return unicode(1)
    """

# Generated at 2022-06-18 00:39:23.758136
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    tree = source_to_tree('''
        def foo(bar):
            return str(bar)
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert compare_trees(tree, '''
        def foo(bar):
            return unicode(bar)
    ''')

# Generated at 2022-06-18 00:39:27.913721
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.code == """
    def foo(x):
        return unicode(x)
    """

# Generated at 2022-06-18 00:39:32.936656
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        def foo(x):
            return str(x)
    """)
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        def foo(x):
            return unicode(x)
    """)

# Generated at 2022-06-18 00:39:39.540342
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1:
    # Test that the transformer replaces str with unicode
    tree = ast.parse('str(1)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].value.func.id == 'unicode'
    assert result.tree_changed == True
    assert result.messages == []

    # Test 2:
    # Test that the transformer does not replace str with unicode if it is not a function call
    tree = ast.parse('str')
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].value.id == 'str'
    assert result.tree_changed == False
    assert result.messages == []

# Generated at 2022-06-18 00:39:48.264597
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.transform import run_transformer

    source = """
    def f(x):
        return str(x)
    """

    expected_ast = """
    Module(body=[FunctionDef(name='f', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])
    """

    tree = source_to_ast(source)
    new_tree = run

# Generated at 2022-06-18 00:39:52.889145
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    def foo(x):
        return str(x)
    """
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert result.tree.body[0].body.value.func.id == 'unicode'

# Generated at 2022-06-18 00:39:58.018225
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result

    code = '''
    def foo(a: str):
        return a
    '''
    expected_code = '''
    def foo(a: unicode):
        return a
    '''
    assert_transformation_result(StringTypesTransformer, code, expected_code)

# Generated at 2022-06-18 00:40:00.992374
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(x):
        return str(x)
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse("""
    def foo(x):
        return unicode(x)
    """))

# Generated at 2022-06-18 00:40:06.799280
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation_result
    from ..utils.testing import load_example_snippet
    from ..utils.testing import load_transformed_snippet

    snippet = load_example_snippet('string_types.py')
    expected = load_transformed_snippet('string_types.py')

    result = StringTypesTransformer.transform(snippet)

    assert_transformation_result(result, expected)