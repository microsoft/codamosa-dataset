

# Generated at 2022-06-25 22:42:10.392943
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Part 1 - pass a boolean, result should be an assertion
    with pytest.raises(AssertionError):
        string_types_transformer_1 = StringTypesTransformer(False)

    # Part 2 - pass an int, result should be an assertion
    with pytest.raises(AssertionError):
        string_types_transformer_2 = StringTypesTransformer(1)

    # Part 3 - pass a list, result should be an assertion
    with pytest.raises(AssertionError):
        string_types_transformer_3 = StringTypesTransformer(['a'])

    # Part 4 - pass a float, result should be an assertion
    with pytest.raises(AssertionError):
        string_types_transformer_4 = StringTypesTransformer(1.1)

    # Part 5 - pass a

# Generated at 2022-06-25 22:42:11.137701
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_1 = StringTypesTransformer()
    assert string_types_transformer_1 != None

# Generated at 2022-06-25 22:42:12.729321
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.target == (2, 7)

# Test case for method transform of class StringTypesTransformer

# Generated at 2022-06-25 22:42:16.033150
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse()).transformed_tree == ast.parse()
    assert StringTypesTransformer.transform(ast.parse()).transformed == False
    assert StringTypesTransformer.transform(ast.parse()).failed_transformation == []

# Generated at 2022-06-25 22:42:18.947611
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    if str(string_types_transformer_0) == "<StringTypesTransformer(): []>":
        assert 1
    else:
        assert 0



# Generated at 2022-06-25 22:42:20.720237
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    string_types_transformer_0.transform(tree_0)


# Generated at 2022-06-25 22:42:23.761146
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert type(string_types_transformer_0) is StringTypesTransformer



# Generated at 2022-06-25 22:42:26.010110
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert string_types_transformer_0 is not None


# Generated at 2022-06-25 22:42:27.914183
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:28.853376
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:42:32.120677
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    assert isinstance(StringTypesTransformer(), ast.NodeTransformer)


# Generated at 2022-06-25 22:42:35.756297
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
             abc = str()
    """

    expected = """
             abc = unicode()
    """

    tree = ast.parse(source)

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    assert result.tree_changed
    assert expected == astunparse.unparse(result.new_tree)

# Generated at 2022-06-25 22:42:44.344830
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Test case 1
    module = ast.parse('def func():\n'
                       '    if isinstance(obj, str):\n'
                       '        print("Hi")\n')
    transformer = StringTypesTransformer()
    result = transformer.transform(module)
    assert result.tree_changed
    assert result.messages == [
        'Replaced str with unicode',
    ]
    expected_module = ast.parse('def func():\n'
                                '    if isinstance(obj, unicode):\n'
                                '        print("Hi")\n')
    assert ast.dump(expected_module) == ast.dump(result.tree)

    # Test case 2

# Generated at 2022-06-25 22:42:47.660390
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    # Right now this is the only one unit test.
    # More unit tests should follow up.
    # The unit test below tests if the module can be imported.
    success = True
    return success

# Generated at 2022-06-25 22:42:52.919580
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse('str')
    tree_transformed = StringTypesTransformer.transform(tree).tree
    expected_tree = typed_ast.ast3.parse('unicode')
    assert typed_ast.ast3.dump(tree_transformed) == typed_ast.ast3.dump(expected_tree)

# Generated at 2022-06-25 22:42:59.892593
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.visitor import visit_and_update
    apply_transforms = PartialTransformer.from_transformer(StringTypesTransformer)

    python_code = '''
from typing import List
from future_builtins import filter
from builtins import str

x = str
y = [str, 'other']
    '''
    tree = source_to_unicode(python_code)

    assert tree_to_str(tree) == python_code


# Generated at 2022-06-25 22:43:03.192421
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    raw_code = "foo = str(bar)"
    tree = ast.parse(raw_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    # TODO: test the output of result.tree_changed

# Generated at 2022-06-25 22:43:06.584781
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Ensures that StringTypesTransformer does not throw a
    NameError for the unicode type.

    """
    StringTypesTransformer().transform(ast.parse('str(1)'))

# Generated at 2022-06-25 22:43:07.714104
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:14.087046
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys, os
    current_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, os.path.abspath(os.path.join(current_dir, '../../')))
    import auto_py_to_py.transformer.string_types
    auto_py_to_py.transformer.string_types.StringTypesTransformer = StringTypesTransformer
    import tests.transformer.test_string_types
    tests.transformer.test_string_types.StringTypesTransformer = StringTypesTransformer



# Generated at 2022-06-25 22:43:20.286799
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Test for constructor of class StringTypesTransformer
    """
    assert isinstance(StringTypesTransformer(), StringTypesTransformer)



# Generated at 2022-06-25 22:43:24.012991
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "import sys; def foo(): return str(1)"
    expected = "import sys; def foo(): return unicode(1)"
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-25 22:43:25.887751
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests the constructor of class StringTypesTransformer.

    """
    tr = StringTypesTransformer()
    assert tr.tree is None

# Generated at 2022-06-25 22:43:33.814763
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    import sys
    import astunparse
    from test.fixtures import cpython_27_parser

    class StringTypesTransformerTest(unittest.TestCase):
        def test_StringTypesTransformer(self):

            code = """def f():
    return "hello world"
    """

            tree = cpython_27_parser.parse(code)
            tree = StringTypesTransformer.transform(tree).tree
            output = astunparse.unparse(tree)

            self.assertEqual(output, """def f():
    return u"hello world"
    """)

    suite = unittest.TestLoader().loadTestsFromTestCase(StringTypesTransformerTest)
    result = unittest.TextTestRunner(verbosity=2, stream=sys.stderr).run(suite)
   

# Generated at 2022-06-25 22:43:41.602145
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump

    def check(src, expected):
        tree = ast.parse(src)
        result = dump(StringTypesTransformer.transform(tree).tree)
        assert result == expected

    src = """
    str
    """
    expected = """
    unicode
    """
    check(src, expected)

    src = """
    str == unicode
    """
    expected = """
    unicode == unicode
    """
    check(src, expected)

# Generated at 2022-06-25 22:43:46.117722
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "str('Hello')"
    tree = ast.parse(code, mode='exec')
    tree_changed = StringTypesTransformer.transform(tree)
    assert tree_changed == True
    assert tree == ast.parse("unicode('Hello')", mode='exec')
    tree_changed = StringTypesTransformer.transform(tree)
    assert tree_changed == False
#

# Generated at 2022-06-25 22:43:47.352389
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:51.814445
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "s = str(); print(s)"
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert(compile(tree, "<test>", 'exec').co_code == compile(code, "<test>", 'exec').co_code)

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:43:53.942162
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class SomeClass(object):
        def __init__(self):
            self.some_attribute = "some_value"
        
    assert isinstance(SomeClass, type)

# Generated at 2022-06-25 22:44:03.237535
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        class A:
            def __init__(self):
                self.a = str(1)
    """)
    tree_changed = StringTypesTransformer.transform(tree)
    assert not tree_changed.tree_changed
    assert tree_changed.new_modules == []
    assert tree_changed.visitor_errors == []

    tree = ast.parse("""
        class A:
            def __init__(self):
                self.a = str(1)
        class B:
            def __init__(self):
                self.b = str(2)
    """)
    tree_changed = StringTypesTransformer.transform(tree)
    assert tree_changed.tree_changed
    assert tree_changed.new_modules == []
    assert tree_changed.visitor_errors == []



# Generated at 2022-06-25 22:44:13.699425
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

    source = 'def foo(x: str):\n    return str(x)'
    tree = ast.parse(source)

    new_tree, status, messages = StringTypesTransformer.transform(tree)

    assert status

    assert astunparse.unparse(new_tree) ==\
        'def foo(x: unicode):\n    return unicode(x)'



# Generated at 2022-06-25 22:44:16.928977
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transpiler = StringTypesTransformer()
    result = transpiler.process_code("""
        def test():
            s = str('test')
        """)
    print(result)

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:44:24.970293
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test_str_str()
    test_str = ast.parse('''str''')
    StringTypesTransformer.transform(test_str)
    assert ast.dump(test_str) == "Name(id='unicode', ctx=Load())"
    assert StringTypesTransformer.transform(test_str).changed

    # test_str_function()
    test_str = ast.parse('''str(str)''')
    StringTypesTransformer.transform(test_str)
    assert ast.dump(test_str) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='unicode', ctx=Load())], keywords=[], starargs=None, kwargs=None))"
    assert StringTypesTransformer.transform(test_str).changed
    

# Generated at 2022-06-25 22:44:30.294048
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tr = StringTypesTransformer()
    tree = ast.parse("s = str(s)")
    tr.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='s', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='s', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-25 22:44:34.074129
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_helper import ast_from_str
    from ..utils.tree import to_str

    assert to_str(StringTypesTransformer.transform(
        ast_from_str('str()')
    ).tree) == to_str(ast_from_str('unicode()'))

# Generated at 2022-06-25 22:44:37.103518
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

	filename = 'test.py'
	tree = astor.parse_file(filename)

	tree_changed, messages = StringTypesTransformer.transform(tree)

	code = astor.to_source(tree)

	print(code)

# test_StringTypesTransformer()

# Generated at 2022-06-25 22:44:37.896590
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-25 22:44:42.185747
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    node = ast.Name(id='str', ctx=ast.Load())

    # constructor without parameters
    xformer = StringTypesTransformer()
    assert xformer.transform(node) == \
        TransformationResult(ast.Name(id='unicode', ctx=ast.Load()), True, [])

# Generated at 2022-06-25 22:44:44.172829
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast

    tree = ast.parse('x = "Hello"')
    tree = StringTypesTransformer.transform(tree)

    print(astor.to_source(tree))
    return

# Generated at 2022-06-25 22:44:50.599733
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    node = ast.parse(
        "a = str ( 'something' )\n"
        "b = str ( 'nothing' )\n"
        "c = unicode ( 'something' )\n"
    )
    expected_result = ast.parse(
        "a = unicode ( 'something' )\n"
        "b = unicode ( 'nothing' )\n"
        "c = unicode ( 'something' )\n"
    )

    with StringTypesTransformer as transformer:
        result = transformer.visit(node)
        assert astor.to_source(result) == astor.to_source(expected_result)

# Generated at 2022-06-25 22:45:09.091356
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from . import StringTypesTransformer
    from . import StringFunctionTransformer

    code = '''
str("abc")
'''
    expected_code = '''
unicode("abc")
'''

    tree = ast.parse(code)
    for t in [StringTypesTransformer, StringFunctionTransformer]:
        new_tree, _ = t.transform(tree)
    generated_code = astor.to_source(new_tree)

    assert generated_code == expected_code


# Generated at 2022-06-25 22:45:12.375071
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that `unicode` is produced instead of `str`. """
    transformer = StringTypesTransformer()
    tree = ast.parse("""
    import sys
    import os.path
    file = str('path')
    """)
    assert transformer.transform(tree).tree_changed == True

# Generated at 2022-06-25 22:45:20.627806
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # input
    a = ast.Name(id='str', ctx=ast.Load())
    b = ast.Name(id='str', ctx=ast.Load())
    c = ast.Name(id='str', ctx=ast.Load())
    e = ast.List([a, b, c], ctx=ast.Load())

    # expected output
    a_ = ast.Name(id='unicode', ctx=ast.Load())
    b_ = ast.Name(id='unicode', ctx=ast.Load())
    c_ = ast.Name(id='unicode', ctx=ast.Load())
    e_ = ast.List([a_, b_, c_], ctx=ast.Load())

    my_transformation = StringTypesTransformer()
    tree_changed, x, y = my_trans

# Generated at 2022-06-25 22:45:25.078972
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that the StringTypesTransformer works.

    """
    # StringTypesTransformer.ast_module = ast
    # StringTypesTransformer.ast_StringTypes = ast.Str
    module_code = """
a = 6
b = str(a)
"""
    module_code_expected = """
a = 6
b = unicode(a)
"""
    np = StringTypesTransformer()
    res = np.transform_code(module_code)
    res_expected = module_code_expected

    assert res == res_expected

if __name__ == '__main__':
    StringTypesTransformer.ast_module = ast
    StringTypesTransformer.ast_StringTypes = ast.Str
    expected_code = """
a = 6
b = unicode(a)
"""
    np = StringTypesTransformer()


# Generated at 2022-06-25 22:45:27.083637
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Testing constructor of class StringTypesTransformer"""
    assert inspect.isclass(StringTypesTransformer)
    assert isinstance(StringTypesTransformer, BaseTransformer)


# Generated at 2022-06-25 22:45:29.960615
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test case for StringTypesTransformer.

    """
    tree = ast.parse('z = str(y)')
    assert StringTypesTransformer.transform(tree).tree_changed
    code = compile(tree, '<string>', 'exec')
    assert eval(code) == {'z': 'unicode'}

# Generated at 2022-06-25 22:45:33.009666
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string = 'def test():\n    a = str("abcd")'
    expected = 'def test():\n    a = unicode("abcd")'
    tree = ast.parse(string)

    test_tx = StringTypesTransformer()
    tx_result = test_tx.transform(tree)
    assert expected == astor.to_source(tx_result.tree).strip()


# Generated at 2022-06-25 22:45:39.744346
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('str(3)')
    result = StringTypesTransformer.transform(tree)

    assert isinstance(result.transformed_tree, ast.AST)
    assert result.transformed_tree.body[0].value.func.id == 'unicode'

    tree = ast.parse('str(str)')
    result = StringTypesTransformer.transform(tree)

    assert isinstance(result.transformed_tree, ast.AST)
    assert result.transformed_tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:45:47.241912
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    import sys

    mod = ast.parse(
        """
        x = str('123')
        """
    )

    trans = StringTypesTransformer(sys.version_info)
    mod = trans.visit(mod)

    print(astunparse.unparse(mod))
    assert astunparse.unparse(mod) == "x = unicode('123')\n"

# Unit tests for function transform of  class StringTypesTransformer

# Generated at 2022-06-25 22:45:48.390885
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
   assert StringTypesTransformer.transform(ast.parse('s = 2'))

# Generated at 2022-06-25 22:46:17.444746
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.parse('"Python 2.7"').body[0].value

    t = StringTypesTransformer()
    t.visit(node)
    assert ast.dump(node) == 'Str(s="Python 2.7")'

# Generated at 2022-06-25 22:46:23.727391
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer."""

    code = "print(str(1))"
    tree = ast.parse(code)
    print(ast.dump(tree))
    result = StringTypesTransformer.transform(tree)
    print(ast.dump(result.tree))
    assert ast.dump(result.tree) == ast.dump(ast.parse("print(unicode(1))"))
    #print(result.log)
    assert result.log == []
    assert result.changed == True
    assert result.warnings == []

# Generated at 2022-06-25 22:46:26.264249
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform

    code = """
    str = 'hello'
    """

    new_code = transform(code, [StringTypesTransformer])
    assert new_code == """
    unicode = 'hello'
    """

# Generated at 2022-06-25 22:46:27.781610
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert type(StringTypesTransformer()) is StringTypesTransformer


# Generated at 2022-06-25 22:46:28.257171
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    return True

# Generated at 2022-06-25 22:46:29.082591
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:46:36.071619
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_string = '''
    def function():
        is_str = type("hello") == str
        is_unicode = type("hello") == unicode
        is_unicode = type("hello") == unicode
    '''

    expected_string = '''
    def test():
        is_str = type("hello") == unicode
        is_unicode = type("hello") == unicode
        is_unicode = type("hello") == unicode
    '''

    tree = ast.parse(test_string)
    tree = StringTypesTransformer.transform(tree)
    check_ast(tree.tree, expected_string)

# Generated at 2022-06-25 22:46:43.286701
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as typed_ast
    from typed_ast.ast3 import Str, Name

    tree = typed_ast.parse('a = str(10)')
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)

    assert isinstance(new_tree, typed_ast.Module)
    assert isinstance(new_tree.body[0], typed_ast.Assign)

    assert isinstance(new_tree.body[0].value, typed_ast.Call)
    assert isinstance(new_tree.body[0].value.func, typed_ast.Name)
    assert new_tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:46:51.435571
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print('Testing StringTypesTransformer')
    code1 = '''
    class Foo:
        def bar(self, baz: str) -> str:
            return "hello"

    def baz(a: str):
        a = str(a)
        return a

    def foo(a: str):
        return str(baz(a))
    '''

    code2 = '''
    class Foo:
        def bar(self, baz: str) -> unicode:
            return "hello"

    def baz(a: unicode):
        a = unicode(a)
        return a

    def foo(a: unicode):
        return unicode(baz(a))
    '''

    expected_ast = ast.parse(code2)
    actual_ast = ast.parse(code1)
    print

# Generated at 2022-06-25 22:46:55.136023
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("s = str()")
    expected_tree = ast.parse("s = unicode()")
    actual_tree = StringTypesTransformer.transform(tree).tree
    assert ast.dump(actual_tree) == ast.dump(expected_tree)

# Generated at 2022-06-25 22:48:04.896249
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippets import generate_source
    import cStringIO, tokenize
    source = generate_source(lambda x: f'''
if False:
    x = "abc"
    y = str(x)
    z = x + y
    ''')
    print(source, '\n')
    f = cStringIO.StringIO(source)
    tree  = ast.parse(source)
    tree = StringTypesTransformer.transform(tree).tree
    print(ast.dump(tree), '\n')
    tokens = tokenize.tokenize(f.readline)
    for t in tokens:
        print(t)

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:48:06.980160
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform(ast.parse("int_var = 3")) == None
    assert t.transform(ast.parse("string_var = str(3)")) != None

# Generated at 2022-06-25 22:48:12.365231
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import ModuleTestCase
    from .. import module_to_module

    src = """
    def f(x):
        if type(x) == str:
            return 'str'
    """

    expected = """
    def f(x):
        if type(x) == unicode:
            return 'str'
    """
    case = ModuleTestCase(src, expected)
    result = module_to_module(case.test_module, StringTypesTransformer)
    case.test(result)

# Generated at 2022-06-25 22:48:16.840784
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def foo(s):
        return s + str(10)
    """
    tree = ast.parse(code)
    out = compile(tree, "<ast>", "exec")
    # Ensure the code is valid
    eval(out)
    # Apply the transform
    translator = StringTypesTransformer()
    new_tree = translator.visit(tree)
    out = compile(new_tree, "<ast>", "exec")
    # Ensure the code is valid
    eval(out)

# Generated at 2022-06-25 22:48:18.320294
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Constructor test for StringTypesTransformer
    
    """
    # Test creation of instance
    assert StringTypesTransformer()



# Generated at 2022-06-25 22:48:26.050665
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    builder = Builder()
    builder.parse_expression("str(1)")
    builder.parse_expression("unicode(x,'utf8')")
    builder.parse_expression("1+2")
    builder.parse_expression("'a'+'b'")
    builder.parse_expression("1+2j+3+4j")
    builder.parse_expression("'a'")
    builder.parse_expression('"a"')
    builder.parse_expression("1 if 1 else 2")
    builder.parse_expression("1 if 1 else 2")
    builder.parse_expression("1 if 1 else 2")
    builder.parse_expression("1 if 1 else 2")
    builder.parse_expression("1 if 1 else 2")
    builder.parse_expression("1 if 1 else 2")

# Generated at 2022-06-25 22:48:27.549317
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from typed_ast import ast3 as ast


# Generated at 2022-06-25 22:48:33.595296
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    '''Replaces `str` with `unicode`. '''
    program = ['''x = "test"''', 
               ''''test: %s' % (i, )''', 
               '''if type(x) is str:''']
    
    expected = ['''x = u"test"''', 
                '''u'test: %s' % (i, )''', 
                '''if type(x) is unicode:''']

    for source, tree in zip(program, map(ast.parse, program)):
        with Source(source) as f:
            new_tree = StringTypesTransformer.transform(tree)
            assert str(new_tree.tree) == expected[f.line_number - 1]

# Generated at 2022-06-25 22:48:41.114941
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
if PY2:
    str(1)
    str(2)
"""
    expected_code = """
if PY2:
    unicode(1)
    unicode(2)
"""
    tr = StringTypesTransformer(code, 'module')
    tree = tr.transform()
    assert tree.code == expected_code

# Generated at 2022-06-25 22:48:42.566878
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    #transformed = t.transform("")

    assert True == True


# Generated at 2022-06-25 22:51:15.360337
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
for i in range(0,3):
    print (str(i))
    """
    expect = """
for i in range(0,3):
    print (unicode(i))
    """
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    new_source = astunparse.unparse(new_tree)
    assert new_source == expect

# Generated at 2022-06-25 22:51:19.741381
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_name = StringTypesTransformer.__name__

    # Initializing a StringTypesTransformer instance
    string_types_transformer = StringTypesTransformer()

    # Unit test for method transform
    def test_transform():
        tree_changed = False
        try:
            if (string_types_transformer.transform("tree") == "tree"):
                tree_changed = True
        except AttributeError:
            tree_changed = True
        assert tree_changed == True

    # Running unit tests
    test_transform()

    # Printing successful unit test results
    print(f"ALL {class_name} TESTS PASSED")

# Generated at 2022-06-25 22:51:22.831545
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from .. import parse

    snippet = '''
    def foo(x):
        return x + str(42)
    '''

    expected = '''
    def foo(x):
        return x + unicode(42)
    '''

    tree = parse(snippet)
    tree_changed = transform(tree, [StringTypesTransformer])

    assert tree_changed
    assert ast.dump(tree) == expected

# Generated at 2022-06-25 22:51:23.722761
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typing
    import astor

# Generated at 2022-06-25 22:51:26.414435
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    a = str.split()
    """)
    t = StringTypesTransformer.transform(tree)
    assert t.tree.body[0].value.value.id == 'unicode'
    assert t.tree_changed == True

# Generated at 2022-06-25 22:51:29.980170
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import c2py
    from .unittest_transformer import run_test

    src = '''
    def func(a):
        return str(a)'''

    tree = c2py(src)
    StringTypesTransformer.transform(tree)
    src1 = '''
    def func(a):
        return unicode(a)'''

    run_test(src1, tree)



# Generated at 2022-06-25 22:51:33.982189
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
            x = str()
            """

    expected_code = """
            x = unicode()
            """

    transform = StringTypesTransformer()
    tree = ast.parse(code)

    new_tree, changed = transform.transform(tree)

    assert changed
    assert astor.to_source(new_tree) == expected_code

# Generated at 2022-06-25 22:51:39.066702
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import normalize
    from typed_ast import ast3
    node = ast3.parse("a = str(a)")
    # str type
    StringTypesTransformer.transform(node)
    assert normalize(node) == normalize("a = unicode(a)")
    # string type
    node = ast3.parse("a = string(a)")
    StringTypesTransformer.transform(node)
    assert normalize(node) == normalize("a = string(a)")

# Generated at 2022-06-25 22:51:39.692316
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:51:42.691851
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert ast.dump(StringTypesTransformer.transform(ast.parse('str(1)'))[0]) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))\n"
