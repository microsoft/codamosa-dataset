

# Generated at 2022-06-25 22:42:02.831579
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("test constructor")
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:04.984042
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    string_types_transformer.transform(2,7)


# Generated at 2022-06-25 22:42:06.913611
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert string_types_transformer_0 is not None


# Generated at 2022-06-25 22:42:10.854857
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = StringTypesTransformer()
    source = ast.parse("print '3'")
    out = tt.transform(source)
    assert source.body[0].values[0].s == '3'
    assert out.tree_changed


# Generated at 2022-06-25 22:42:12.513614
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.name == 'STRING_TYPES'
    assert StringTypesTransformer.target == (2, 7)

# Generated at 2022-06-25 22:42:15.531024
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform
    assert StringTypesTransformer.target
    assert StringTypesTransformer.__module__
    assert StringTypesTransformer.__doc__
    assert StringTypesTransformer.__name__


# Generated at 2022-06-25 22:42:22.813285
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()

    code = """
a = str('b')
"""

    tree = ast.parse(code)
    tree_changed, _ = string_types_transformer_0.transform(tree)
    assert tree_changed

    module = ast.Module(body=[ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Call(func=ast.Name(id='unicode', ctx=ast.Load()), args=[ast.Str(s='b')], keywords=[]))])
    assert tree == module

# Generated at 2022-06-25 22:42:26.379304
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    cases = [] # type: List[Tuple[StringTypesTransformer, None]]
    cases.append((StringTypesTransformer(), None))

    for case in cases:
        (actual, expected) = (case[0], case[1])
        assert actual == expected


# Generated at 2022-06-25 22:42:28.320686
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert 2.7 == 2.7
    
    
    
    
    
    

# Generated at 2022-06-25 22:42:31.825888
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    try:
        result0 = StringTypesTransformer()
    except Exception as e:
        print('FAILED: test_StringTypesTransformer()')
        print(e)
    else:
        print('PASSED: test_StringTypesTransformer()')


# Generated at 2022-06-25 22:42:42.070350
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_cases = [
        ("""
            x = str(1)
        """, """
            x = unicode(1)
        """),
        ("""
            from typing import Text
            def foo(x: str):
                pass
        """, """
            from typing import Text
            def foo(x: unicode):
                pass
        """),
        ("""
            def foo(x):
                def bar():
                    return str
            """, """
            def foo(x):
                def bar():
                    return unicode
            """),
    ]

    for test_case in test_cases:
        try:
            transformed = StringTypesTransformer.transform(ast.parse(test_case[0]))
        except SyntaxError:
            continue
        print(transformed.tree)

# Generated at 2022-06-25 22:42:46.577818
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.perf_utils import compare_perf

    tree = ast.parse('def f():\n    return str')
    tree_ = ast.parse('def f():\n    return unicode')

    transformer = StringTypesTransformer()
    assert transformer.transform(tree) == transformer.transform(tree_)

    compare_perf(tree, tree_, StringTypesTransformer)

# Generated at 2022-06-25 22:42:54.078579
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("Testing StringTypesTransformer...")
    python_2_source_code_string = """
from builtins import str

assert isinstance(str, class_)

x = "str"

if isinstance(x, str):
    print(x)
    """
    tree = ast.parse(python_2_source_code_string)
    print("Original:")
    print(ast.dump(tree, include_attributes=True))
    print("Result:")
    print(ast.dump(StringTypesTransformer.transform(tree), include_attributes=True))
    print("Testing StringTypesTransformer complete.")

# Generated at 2022-06-25 22:42:56.930083
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    x = str(1)
    '''
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    tree = result.tree
    assert result.tree_changed
    assert 'unicode(1)' in ast.dump(tree)
    assert 'str(1)' not in ast.dump(tree)

# Generated at 2022-06-25 22:42:59.871914
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("str(a)")).tree_changed == True
    assert StringTypesTransformer.transform(ast.parse("int(a)")).tree_changed == False

# Generated at 2022-06-25 22:43:01.132140
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_astunparse
    import ast


# Generated at 2022-06-25 22:43:08.726925
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from . import parse_to_ast
    from . import print_ast
    from . import transform_ast
    from . import execute_and_print

    code = '''
x = str()
y = 'abc'
    '''
    expected_code = '''
x = unicode()
y = 'abc'
    '''

    ast_tree = parse_to_ast.parse(code)
    ast_tree = transform_ast.transform(ast_tree, StringTypesTransformer)
    assert print_ast.print_ast(ast_tree) == expected_code

    execute_and_print.print_result(ast_tree)

# Generated at 2022-06-25 22:43:12.758177
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .common import assert_transformation_result

    # Simple test of string type
    result = StringTypesTransformer.transform(
        ast.parse("x = 'hello'")
    )
    assert_transformation_result(result, "x = u'hello'")

    # String type in function def

# Generated at 2022-06-25 22:43:14.483458
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer.target == (2, 7)


# Generated at 2022-06-25 22:43:18.580239
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .testutils.str_unicode import StringTypesTransformerTest
    StringTypesTransformerTest.test_StringTypesTransformer()



# Generated at 2022-06-25 22:43:22.285951
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:43:27.629498
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print('In module string_types.py:')
    print('In StringTypesTransformer class:')
    print('Module docstring:')
    print(StringTypesTransformer.__doc__)
    print('Class docstring:')
    print(StringTypesTransformer.__init__.__doc__)
    print('Method transform docstring:')
    print(StringTypesTransformer.transform.__doc__)


# Unit test

# Generated at 2022-06-25 22:43:32.446058
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from .. import dump_python_source
    from . import apply_transformer
    source = '''
    if str is not None:
        print 'ok'
    '''
    tree = source_to_tree(source)
    tree = apply_transformer(StringTypesTransformer, tree)
    assert dump_python_source(tree) == '''
    if unicode is not None:
        print 'ok'
    '''

# Generated at 2022-06-25 22:43:41.282034
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    prgm = ast.parse("s = str(); a = []")
    assert StringTypesTransformer.transform(prgm).changed
    assert ast.dump(prgm) == "Module(body=[Assign(targets=[Name(id='s', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None)), Assign(targets=[Name(id='a', ctx=Store())], value=List(elts=[], ctx=Load()))])"


# Generated at 2022-06-25 22:43:44.838461
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # this should not be changed
    assert StringTypesTransformer.transform(ast.parse('1')) == (ast.parse('1'), False)

    # this should be changed
    assert StringTypesTransformer.transform(ast.parse('str')) == (ast.parse('unicode'), True)

# Generated at 2022-06-25 22:43:50.349177
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Simple test of StringTypesTransformer
    tree_ast = ast.parse("""
test = str("test")
foo = str("foo")
""")

    expected_tree_ast = ast.parse("""
test = unicode("test")
foo = unicode("foo")
""")

    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree_ast)
    assert transformer.tree_changed == True
    assert ast.dump(new_tree.tree) == ast.dump(expected_tree_ast)

# Generated at 2022-06-25 22:43:56.665291
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that each node with class name = str is replaced by unicode.

    """
    import astor
    with_str = ast.parse("def foo():\n    a = str('abc')")
    e = StringTypesTransformer.transform(with_str)
    print(astor.to_source(e.tree))
    assert e.tree_changed == True
    without_str = ast.parse("def foo():\n    a = unicode('abc')")
    e = StringTypesTransformer.transform(without_str)
    assert e.tree_changed == False

# Generated at 2022-06-25 22:44:03.781615
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = textwrap.dedent("""\
    import sys
    x = str(1)
    y = str()
    """)
    expected_code = textwrap.dedent("""\
    import sys
    x = unicode(1)
    y = unicode()
    """)

    # When
    result = StringTypesTransformer.transform(ast.parse(code))

    # Then
    assert expected_code == result.code
    assert result.tree_changed == True
    assert result.transformers_applied == ['unicode']

# Generated at 2022-06-25 22:44:08.982730
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    tree = ast.parse("""
    a = '123'
    b = unicode(a)
    c = str('a')
    d = str(1)
    """)
    expected_tree = ast.parse("""
    a = '123'
    b = unicode(a)
    c = unicode('a')
    d = unicode(1)
    """)
    transformer = StringTypesTransformer()
    assert transformer.transform(tree).tree == expected_tree

# Generated at 2022-06-25 22:44:11.304574
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .helpers import get_ast, compare_asts
    from ..utils.tree import find
    from ..utils.helpers import add_parent_info


# Generated at 2022-06-25 22:44:25.481419
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # This is needed to disable the lambda transformation.
    os.environ["TYPY_DISABLE_LAMBDAS"] = "1"
    transformer_tester = TransformerTester(StringTypesTransformer)
    # @formatter:off
    test_data = [

        # Single line
        [('''x = str''', ''),
         ('''x = unicode''', '''x = str''')],

        # Multiple lines
        [('''
          import sys
          import sys2
          x = str
          ''', ''),
         ('''
          import sys
          import sys2
          x = unicode
          ''', '''
          import sys
          import sys2
          x = str
          ''')],
    ]
    # @formatter:on

    transformer_tester.run_standard

# Generated at 2022-06-25 22:44:26.628851
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:28.430988
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
""")
    assert StringTypesTransformer.transform(tree) == TransformationResult("""
""", False, [])

# Generated at 2022-06-25 22:44:31.221429
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = StringTypesTransformer()
    tree = ast.parse("a: str=None")
    tt.transform(tree)
    assert(isinstance(tree,ast.Module))

# Generated at 2022-06-25 22:44:33.329386
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # unicode is not a keyword in Python 2
    assert 'unicode' in keyword.kwlist


# Generated at 2022-06-25 22:44:41.669811
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Instantiating class
    instance1 = StringTypesTransformer()
    assert isinstance(instance1, StringTypesTransformer)

    instance2 = StringTypesTransformer()
    assert instance1 == instance2

    instance3 = StringTypesTransformer(target=(2, 7))
    assert instance1 == instance3

    # Testing transform method
    ast1 = ast.parse('a = "abc"')
    assert isinstance(ast1, ast.Module)
    result1 = instance1.transform(tree=ast1)
    assert result1.tree_changed == False  # "ast1" has no "unicode"

    ast2 = ast.parse('a = u"abc"')
    assert isinstance(ast2, ast.Module)
    result2 = instance1.transform(tree=ast2)
    assert result2.tree_changed == False

# Generated at 2022-06-25 22:44:45.150744
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
        def my_func(a: str):
            pass
    """

    result = StringTypesTransformer().transform(src)
    module, _ = ast.parse(result)
    assert isinstance(module, ast.Module)
    assert result == "def my_func(a: unicode):\n    pass\n"

# Generated at 2022-06-25 22:44:53.047251
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import generate_test_function
    from ..utils.test_utils import compare_transformation

    source = generate_test_function(
        name='test_func',
        body_stmt=[
            ast.Assign(
                targets=[ast.Name(id='var', ctx=ast.Store())],
                value=ast.Call(
                    func=ast.Name(id="func", ctx=ast.Load()),
                    args=[ast.Str(s='hello')],
                    keywords=[]
                )
            )
        ],
        decorator_list=[ast.Name(id='classmethod', ctx=ast.Load())]
    )


# Generated at 2022-06-25 22:45:01.107271
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:45:10.530301
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    from ..utils.tree import pretty_ast


# Generated at 2022-06-25 22:45:26.058481
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    simple_tree_before = ast.parse('def foo(): return str(1)')
    simple_tree_after = ast.parse('def foo(): return unicode(1)')
    transform_result = StringTypesTransformer.transform(simple_tree_before)
    assert transform_result.tree == simple_tree_after

# Generated at 2022-06-25 22:45:32.437976
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Tests that the constructor of the StringTypesTransformer class is correct
    """
    assert StringTypesTransformer.target == (2, 7)

# Generated at 2022-06-25 22:45:33.028705
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:45:33.967421
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:45:37.676201
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import make_example_python_2_file

    make_example_python_2_file(__file__)
    code = open(__file__, 'r').read()
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.changed == True

# Generated at 2022-06-25 22:45:45.197294
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("x = 'a'")
    xformed = StringTypesTransformer.transform(tree)
    assert not xformed.tree_changed
    assert not xformed.annotations

    tree = ast.parse("from __future__ import unicode_literals\nx = 'a'")
    xformed = StringTypesTransformer.transform(tree)
    assert not xformed.tree_changed
    assert not xformed.annotations

    tree = ast.parse("x = str('a')")
    xformed = StringTypesTransformer.transform(tree)
    assert xformed.tree_changed
    assert not xformed.annotations
    assert isinstance(xformed.tree, ast.AST)
    # assert 'x = unicode' in xformed.tree

    tree = ast.parse("x = unicode('a')")


# Generated at 2022-06-25 22:45:45.776447
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    StringTypesTransformer()

# Generated at 2022-06-25 22:45:56.354810
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import dump
    from ..utils.pytree import Node


# Generated at 2022-06-25 22:45:57.846934
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:45:59.153380
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor


# Generated at 2022-06-25 22:46:25.578642
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-25 22:46:30.816132
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '#!/usr/bin/python\nif True:\n    print "Hello world"\n'
    tree = ast.parse(code)
    
    # before
    print(ast.dump(tree))
    
    # transform
    transformer = StringTypesTransformer()
    tree = transformer.transform(tree)
    print(ast.dump(tree))
    
    # after
    exec(compile(tree, 'test', 'exec'))

# test_StringTypesTransformer()

# Generated at 2022-06-25 22:46:33.839715
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = "abc"', mode='exec')
    StringTypesTransformer.transform(tree)
    assert(str(tree) == "x = u'abc'")

# Generated at 2022-06-25 22:46:41.877664
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = '''def __init__(self, first, last, pay):
            self.first = first
            self.last = last
            self.pay = pay
            self.email = first + '.' + last + '@email.com'
        def fullname(self):
            return '{} {}'.format(self.first,self.last)
        def apply_raise(self):
            self.pay = int(self.pay * 1.04)'''
    tree = ast.parse(s)
    StringTypesTransformer.transform(tree)

# Generated at 2022-06-25 22:46:48.221013
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program = '''
        str = "123"
        print(str)
    '''

    module_name = '__main__'
    result = StringTypesTransformer.transform(ast.parse(program))

    # assert result.tree_changed is True
    assert result.changed_modules == [module_name]

    assert result.tree.body[0].value.s == '123'
    assert type(result.tree.body[0]) == ast.Assign

    assert result.tree.body[1].args[0].s == '123'
    assert type(result.tree.body[1]) == ast.Expr

# Generated at 2022-06-25 22:46:56.727389
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    
    Arguments:
        txt {str} -- Source code
    """
    # Test when we have a single str type
    txt = """
        def my_test(val: str) -> str:
            return val
    """

    expected_result = """
        def my_test(val: unicode) -> unicode:
            return val
    """

    tree = ast.parse(txt)
    actual_result = StringTypesTransformer.transform(tree).tree
    expected_tree = ast.parse(expected_result)

    assert ast.dump(actual_result) == ast.dump(expected_tree)

    # Test when we have no str type
    txt = """
        def my_test(val) -> str:
            return val
    """

    tree

# Generated at 2022-06-25 22:47:05.382443
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test case 1
    test_code = """a = str()"""

    expected_code = """a = unicode()"""

    result, num_changes = StringTypesTransformer.transform(test_code)
    assert result == expected_code
    assert num_changes == 1
    
    # Test case 2
    test_code = """a = 4"""
    result, num_changes = StringTypesTransformer.transform(test_code)
    assert result == test_code
    assert num_changes == 0

    # Test case 3
    test_code = """a = str(4)"""
    expected_code = """a = unicode(4)"""
    result, num_changes = StringTypesTransformer.transform(test_code)
    assert result == expected_code
    assert num_changes == 1

    # Test case 4
    test_

# Generated at 2022-06-25 22:47:07.248419
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Unit test for constructor.
    
    """
    iconstructor = StringTypesTransformer()
    assert iconstructor.__class__ == StringTypesTransformer

# Generated at 2022-06-25 22:47:14.875569
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.loader import loads

    # Test for transforming str to unicode
    module = ast.parse('''
        def fun():
            return str
        ''')
    expected = ast.parse('''
        def fun():
            return unicode
        ''')

    StringTypesTransformer.transform(module)
    # The code of module is changed
    assert module != expected
    # But the code generated by module and expected is the same
    assert loads(module) == loads(expected)

    # Test for transforming str in parameter list to unicode
    module = ast.parse('''
        def fun(str):
            return str
        ''')
    expected = ast.parse('''
        def fun(unicode):
            return unicode
        ''')

    StringTypesTransformer.transform(module)
   

# Generated at 2022-06-25 22:47:16.957542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer

    """
    assert StringTypesTransformer.transform(ast.parse("str")).code == "unicode"

# Generated at 2022-06-25 22:48:28.332598
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  assert '2.7' in StringTypesTransformer.versions()
  assert '3.0' not in StringTypesTransformer.versions()
  mod = ast.parse('str(1)')
  target = ast.parse('unicode(1)')
  result = StringTypesTransformer.transform(mod)
  assert result == TransformationResult(target, True, [])

# Generated at 2022-06-25 22:48:32.543483
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast

    tree = ast.parse("x = str(1)")
    tree = StringTypesTransformer.transform(tree).tree_new

    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-25 22:48:38.393618
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
    """Just a test file."""

    f = str
    ''')
    new_tree = StringTypesTransformer().transform(tree)
    assert new_tree.code == ast.dump(tree)

# Generated at 2022-06-25 22:48:46.643592
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_optics import test_optic
    from ..utils.test_optics.test_optic import assert_equal
    import astunparse

    optics = [optic for optic in StringTypesTransformer.optic()]

    def check(original, expected):
        result = test_optic(StringTypesTransformer, optics, original)
        assert_equal(astunparse.unparse(expected), result)

    check(
        'lambda: str()',
        'lambda: unicode()'
    )

    check(
        'lambda: str[1]',
        'lambda: str[1]'
    )

    check(
        'lambda: (1, str[1])',
        'lambda: (1, str[1])'
    )

# Generated at 2022-06-25 22:48:53.466979
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that the StringTypesTransformer will correctly transform from
    py27 to py3.

    """
    import textwrap
    code = textwrap.dedent('''
    class A:
        def __init__(self, s: str = 'hello'):
            self.s = s
    ''')
    py27_tree = ast.parse(code, mode='exec')
    py3_tree = ast.parse(code.replace('str', 'unicode'), mode='exec')

    py27_tree.body[0].body[1].targets[0].id = 's'

    transformer = StringTypesTransformer()
    transformed_ast = transformer.transform(py27_tree)

    assert transformed_ast.tree == py3_tree
    assert not transformed_ast.changed
    assert transformed_ast.messages

# Generated at 2022-06-25 22:48:55.706106
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    tree = ast.parse('value = str()')
    new_tree = StringTypesTransformer.transform(tree).tree
    assert astor.to_source(new_tree) == 'value = unicode()\n'

# Generated at 2022-06-25 22:48:57.677625
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""x = str(y)""")
    res = StringTypesTransformer.transform(tree)
    assert not res.tree_changed


# Generated at 2022-06-25 22:49:07.110283
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    test for the class StringTypesTransformer.
    """
    class DummyModule:
        def __init__(self):
            self.name = 'dummy_module'

    dummy_module = DummyModule()
    class Dummy:
        def __init__(self):
            self.module = dummy_module
            self.name = 'name'
            self.id = 'str'

    dummy = Dummy()

    tree_changed, _ = StringTypesTransformer.transform(dummy)
    assert tree_changed == True
    assert dummy.id == 'unicode'

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:49:11.975449
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from fixtures import fixture
    from ..utils.tree import print_ast
    from ..utils.context import TranspileContext
    from ..utils.compare import compare_asts

    source = fixture(__file__, "source.py")
    expected = fixture(__file__, "expected.py")
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    context = TranspileContext(target_version=(2, 7))

    new_tree, _ = transformer.transform(tree, context)
    print_ast(new_tree)
    compare_asts(expected, new_tree, __file__)

# Generated at 2022-06-25 22:49:17.319012
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.python import to_ast

    tree1 = to_ast("(a) + str(b)")
    tree2 = StringTypesTransformer().transform(tree1)
    assert(astor.to_source(tree2) == "(a) + unicode(b)")

    tree1 = to_ast("(a) + unicode(b)")
    tree2 = StringTypesTransformer().transform(tree1)
    assert(astor.to_source(tree2) == "(a) + unicode(b)")

# Generated at 2022-06-25 22:51:52.373790
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # unit test to check the constructor of class StringTypesTransformer
    StringTypesTransformer.__init__()
    # case 1: succesfully instantiate the class StringTypesTransformer

# unit test for transform of class StringTypesTransformer

# Generated at 2022-06-25 22:51:55.403906
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = """def foo(bar):
        return str(bar()).split()"""
    tree = ast.parse(code)

    # When
    result = StringTypesTransformer.transform(tree)

    # Then
    assert result.tree is not None
    assert result.tree_changed is True
    assert result.warnings == []

# Generated at 2022-06-25 22:52:03.590540
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import assert_equal_source

    source = """
# comment
x = str()
    """
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    source_transformed = compile(tree, '', 'exec')

    source_transformed_expected = """
# comment
x = unicode()
        """
    assert_equal_source(source_transformed, source_transformed_expected)