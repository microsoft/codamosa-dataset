

# Generated at 2022-06-25 22:42:03.801316
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert callable(StringTypesTransformer.transform())
    assert callable(StringTypesTransformer.transform(ast.parse("x=1")))
    assert callable(ast.parse("z=2"))
    assert callable(ast.parse("x=1"))
    assert callable(ast.parse("x=1"))
    assert callable(ast.parse("x=1"))


# Generated at 2022-06-25 22:42:05.073978
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:06.311631
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()



# Generated at 2022-06-25 22:42:07.266440
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass


# Generated at 2022-06-25 22:42:11.746682
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree= ast.parse('def test():\n    l = []\n    for i in range(10):\n        l.append(str(i))\n    return l')
    string_types_transformer = StringTypesTransformer()
    result = string_types_transformer.transform(tree)
    assert result is not None


# Generated at 2022-06-25 22:42:14.068261
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    global string_types_transformer_0
    string_types_transformer_0 = StringTypesTransformer()
    return string_types_transformer_0


# Generated at 2022-06-25 22:42:18.867538
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('from typing import List, Union\nfrom collections import Counter\nimport math\n')
    expected_result = ast.parse('from typing import List, Union\nfrom collections import Counter\nimport math\n')
    result = string_types_transformer_0.transform(tree)
    result_tree = result.tree

    assert expected_result == result_tree
    assert result.tree_changed is False
    assert result.errors == []

# Generated at 2022-06-25 22:42:23.802324
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree_0 = ast.parse('''
x = 'foo'
''')
    tree_changed, messages = StringTypesTransformer.transform(tree_0)
    if len(messages) != 0:
        for message in messages:
            print(message)
    if tree_changed:
        print(astor.to_source(tree_0))


# Generated at 2022-06-25 22:42:25.723524
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_case_0()

################################################################################
#                              end of file                                     #
################################################################################

# Generated at 2022-06-25 22:42:30.520045
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_1 = StringTypesTransformer()
    string_types_transformer_2 = StringTypesTransformer()
    assert (string_types_transformer_1.target[0] == string_types_transformer_2.target[0] and string_types_transformer_1.target[1] == string_types_transformer_2.target[1])


# Generated at 2022-06-25 22:42:36.011163
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    a = str("asd")
    """

    tree = ast.parse(code)
    transformed_tree, changed = StringTypesTransformer.transform(tree)
    
    assert changed
    assert type(transformed_tree.body[0].value) == ast.Name
    assert transformed_tree.body[0].value.id == 'unicode'

# Generated at 2022-06-25 22:42:44.913468
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import get_tree
    tree = get_tree('''
        import os
        def a():
            return [str(s) for s in os.listdir('.')]
    ''')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed

    # Check that the tree has been modified ('str' replaced with 'unicode')
    assert type(result.tree) == ast.Module
    assert len(result.tree.body) == 2
    assert type(result.tree.body[1]) == ast.FunctionDef
    assert len(result.tree.body[1].body) == 1
    assert type(result.tree.body[1].body[0]) == ast.Return
    assert type(result.tree.body[1].body[0].value) == ast.ListComp

# Generated at 2022-06-25 22:42:46.706208
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("""\
assert isinstance(my_var, str)
""")) == TransformationResul

# Generated at 2022-06-25 22:42:47.247346
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:42:55.016689
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    from ..transpiler import Transpiler
    
    source = '''
print(str(1))
print(str())
print(type(str))
print(type(str()))
'''
    tree = ast.parse(source)
    p = Transpiler()
    p.register(StringTypesTransformer)
    new_tree = p.run(tree)

    # Test
    assert ast.dump(new_tree) == ast.dump(ast.parse('''
print(unicode(1))
print(unicode())
print(type(unicode))
print(type(unicode()))
'''))

# Generated at 2022-06-25 22:43:00.828313
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    from .base import transform_tree
    from ..test_transformer_base import check_transformer

    check_transformer(
        StringTypesTransformer,
        (2, 7),
        ('print("hello")', ast.parse('print("hello")')),
        ('print(str("hello"))', ast.parse('print(str("hello"))')),
        ('print str("hello")', ast.parse('print str("hello")')),
        ('def foo(x: str) -> str: ...',
         ast.parse('def foo(x: str) -> str: ...')),
        ('x = str()', ast.parse('x = str()')),
    )

    # Expected result.
    expected_result = 'print(unicode("hello"))'

    # Source code.

# Generated at 2022-06-25 22:43:04.969424
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """from __future__ import unicode_literals
print("hello")
"""
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert compile(tree, "<test>", "exec").co_flags & 0x4000 != 0

# Generated at 2022-06-25 22:43:14.161531
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Stuff in here."""
    from sys import version_info
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.transform import run_transformers
    from ..utils.visitor import visitor_to_str

    source = source_to_unicode("""
        x = str()
        y = str('test')
        z = str(123)
        """)
    
    tree = ast.parse(source)
    node = tree.body[0].value

    if version_info >= (3, 0):
        expected = "(Name(id='unicode', ctx=Load()))"
    else:
        expected = "(Name(id='str', ctx=Load()))"

    assert expected == visitor_to_str(node)

    results

# Generated at 2022-06-25 22:43:22.151479
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    in_tree = ast.parse("def foo(a, foo):\n    if bar == 'str':\n        return str(a)")
    out_tree, _, _ = StringTypesTransformer.transform(in_tree)
    out_str = astor.to_source(out_tree)
    assert out_str == "def foo(a, foo):\n    if bar == 'str':\n        return unicode(a)"

# Generated at 2022-06-25 22:43:25.529330
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''def test(str2):
                a = str2'''
    node = ast.parse(code)
    StringTypesTransformer.transform(node)
    module_code = compile(node, filename='<test>', mode='exec')
    exec(module_code)

# Generated at 2022-06-25 22:43:33.108340
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program = ast.parse('''class A(object):
    def __init__(self):
        self.a = str()
''')
    tree = StringTypesTransformer().transform(program)
    assert isinstance(tree, TransformationResult)
    assert isinstance(tree.tree, ast.AST)
    str_node = find(tree.tree, ast.Name)[0]
    assert str_node.id == 'unicode'
    assert tree.tree_changed == True

# Generated at 2022-06-25 22:43:44.214520
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import generate_test_case

    generate_test_case(
        StringTypesTransformer,
        True,
        """name = str""",
        """name = unicode""",
    )
    generate_test_case(
        StringTypesTransformer,
        True,
        """x = str(); y = str("string")""",
        """x = unicode(); y = unicode("string")""",
    )
    generate_test_case(
        StringTypesTransformer,
        False,
        """str = unicode""",
        """str = unicode""",
    )

# Generated at 2022-06-25 22:43:46.106349
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert(t.transform_string('f = str(8)') == 'f = unicode(8)')

# Generated at 2022-06-25 22:43:51.267395
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import generate_source

    source = generate_source('def x(y: str): pass')
    module = ast.parse(source)
    assert isinstance(module, ast.Module)

    assert_source = generate_source('def x(y: unicode): pass')

    before = ast.dump(module)
    after = ast.dump(StringTypesTransformer.transform(module).tree)

    assert before != after
    assert after == assert_source

# Generated at 2022-06-25 22:43:52.515749
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:57.970573
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
'abc'
str(1)
str()
"""
    t = ast.parse(code)
    new = StringTypesTransformer.transform(t)
    assert new.changed is True
    assert new.messages == []

    # print new.tree.body[1].value.func.id
    # print new.tree.body[2].value.func.id

    assert new.tree.body[1].value.func.id == 'unicode'
    assert new.tree.body[2].value.func.id == 'unicode'

# Generated at 2022-06-25 22:44:06.987882
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    >>> from typed_ast import ast3
    >>> from typed_ast.ast3 import *
    >>> from typed_astunparse import unparse
    >>> from transform import StringTypesTransformer
    >>> import sys
    >>>
    >>> node = parse("str(1)")
    >>> tree = StringTypesTransformer.transform(node)
    >>> print(unparse(tree))
    unicode(1)
    <BLANKLINE>
    >>>
    >>> node = parse("str(1)").body[0].value
    >>> tree = StringTypesTransformer.transform(node)
    >>> print(unparse(tree))
    unicode(1)
    >>>
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 22:44:08.466140
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    StringTypesTransformer.transform(ast.parse(dedent('''
        str
        ''')))

# Generated at 2022-06-25 22:44:12.613234
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    a = ast.parse('''
    a = str()
    ''')
    b = ast.parse('''
    a = unicode()
    ''')

    assert StringTypesTransformer.transform(a).tree_changed == True
    assert a == b
    assert StringTypesTransformer.transform(b).tree_changed == False
    assert a == b



# Generated at 2022-06-25 22:44:20.194591
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast.parse("def test(a):\n    return str(a)")
    # ast.parse("def test(a):\n    return a")
    # print(ast.dump(ast.parse("def test(a):\n    return a")))
    # print(ast.dump(test_parse(ast.parse("def test(a):\n    return str(a)"))))
    # print(ast.dump(StringTypesTransformer.transform(ast.parse("def test(a):\n    return str(a)"))))
    # print(ast.dump(StringTypesTransformer.transform(ast.parse("def test(a):\n    return a"))))


if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:44:28.218682
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.ast_transformer import AstTransformer 
    from ..utils.ast_inspector import TreeInspector 


# Generated at 2022-06-25 22:44:36.682343
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.fake_tree import FakeTree
    from ..utils.tree_compare import TreeCompare

    fake_tree = FakeTree()
    fake_tree.add_node(ast.Name(id='str', ctx=ast.Load()), (1, 0))

    tree = fake_tree.tree

    actual = StringTypesTransformer.transform(tree)
    expected = TransformationResult(
        tree = FakeTree([
            ast.Name(id='unicode', ctx=ast.Load()),
        ]).tree, 
        tree_changed = True, 
        messages = []
        )

    assert TreeCompare.equals(actual.tree, expected.tree)
    assert actual.tree_changed == expected.tree_changed
    assert actual.messages == expected.messages

# Generated at 2022-06-25 22:44:37.475375
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:42.728110
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    from typed_ast import util
    tree = util.parse("a = str()")
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree).tree
    assert typed_ast.ast3.dump(new_tree) == "Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))"

# Generated at 2022-06-25 22:44:43.775681
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-25 22:44:50.776634
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Testing constructor of class StringTypesTransformer.
    """
    # Creating object and checking it has expected values
    t = StringTypesTransformer((2, 7))
    assert t.target == (2, 7)
    assert t.is_applicable((2, 7)) and not t.is_applicable((2, 8)), \
        "Checking is_applicable()"

    # Checking the generated code with a simple example
    code = "str('hello')"
    expected = "unicode('hello')"
    tree = ast.parse(code)
    result, _, _ = t.transform(tree)
    assert astunparse(result) == expected, \
        "Checking the generated code with a simple example"


# Generated at 2022-06-25 22:44:56.016167
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from collections import OrderedDict
    from typed_ast import ast3 as ast
    from ..utils.testing import assert_transform

    # We require ordered dictionary for testing
    if sys.version_info < (3, 6):
        ast.PyCF_ONLY_AST = 0

    expected = ast.parse("(a).__class__.__name__")
    actual = ast.parse("(a).__class__.__name__", mode='exec')
    assert_transform(actual, expected, StringTypesTransformer)

# Generated at 2022-06-25 22:44:56.800660
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:45:01.437147
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(1)')
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Call(func=Name(id="unicode", ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))])'

# Generated at 2022-06-25 22:45:06.018543
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse("""
x = str(x)
""", 'exec')

    trans = StringTypesTransformer()

    tree, tree_changed = trans.transform(tree)

    assert tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse("""
x = unicode(x)
""", 'exec'))

# Generated at 2022-06-25 22:45:21.016317
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    text = str('a')
    """)
    tree2 = ast.parse("""
    text = unicode('a')
    """)
    t = StringTypesTransformer()
    tree = t.transform(tree)
    assert(ast.dump(tree.tree) == ast.dump(tree2))

# Generated at 2022-06-25 22:45:24.941026
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    in_tree = ast.parse('1 + str(5)').body[0].value
    expected_tree = ast.parse('1 + unicode(5)').body[0].value

    actual_tree, tree_changed = StringTypesTransformer.transform(in_tree)

    assert tree_changed
    assert ast.dump(expected_tree) == ast.dump(actual_tree)

# Generated at 2022-06-25 22:45:31.160544
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Fails if untransformed code does not compile
    exec(compile(ast.parse("assert(str == unicode)"), '', 'exec'))
    exec(compile(ast.parse("assert(isinstance(foo, str))"), '', 'exec'))
    exec(compile(ast.parse("assert(isinstance(foo, str) or isinstance(foo, unicode))"), '', 'exec'))

    # Fails if transformed code does not compile
    exec(compile(ast.parse("assert(isinstance(foo, str))"), '', 'exec'))
    exec(compile(ast.parse("assert(isinstance(foo, str) or isinstance(foo, unicode))"), '', 'exec'))

# Generated at 2022-06-25 22:45:38.006864
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for class StringTypesTransformer.

    """
    # Test case 1:
    test_case_1 = ast.parse(
        "isinstance(year, str)"
    )
    # Expected tree:
    expected_tree_1 = ast.parse(
        "isinstance(year, unicode)"
    )
    # Perform 
    transformed_tree_1 = StringTypesTransformer.transform(test_case_1).tree
    # Compare
    assert ast.dump(transformed_tree_1) == ast.dump(expected_tree_1)

# Generated at 2022-06-25 22:45:41.526605
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name("str", ast.Load())
    new_node = StringTypesTransformer.transform(node)
    assert ast.dump(new_node) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"

# Generated at 2022-06-25 22:45:51.839130
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    def func(a: str, b: int) -> int:
        return a + b
    '''
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)

# Generated at 2022-06-25 22:45:56.247877
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    tree = ast.parse('str(1)')
    tree = StringTypesTransformer.run_on_single_file(tree)
    assert astor.to_source(tree).strip() == 'unicode(1)'

# Generated at 2022-06-25 22:45:57.847222
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    a = StringTypesTransformer()
    assert a

# Generated at 2022-06-25 22:46:07.136444
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # 1. str to unicode
    code = '''
string = "Hello"
'''
    result = StringTypesTransformer.transform(astor.parse_file(code))
    transformed_code = result.tree
    assert result.tree_changed
    assert "unicode" in transformed_code[0].targets[0].id
    assert result.fixup_comments == []

    # 2. str to unicode
    code = '''
string = "Hello"
'''
    result = StringTypesTransformer.transform(astor.parse_file(code))
    transformed_code = result.tree
    assert result.tree_changed
    assert "unicode" in transformed_code[0].value.id
    assert result.fixup_comments == []

# Generated at 2022-06-25 22:46:12.525036
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(
        """
        def func2(a: str, b: str) -> str:
            return a + b
        """
    )

    result = StringTypesTransformer().transform(tree)

    assert result.tree_changed
    print(ast.dump(result.tree, annotate_fields=False, include_attributes=True))

# Generated at 2022-06-25 22:46:39.598631
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = str(y)')
    base.transform(tree, StringTypesTransformer)
    expected = ast.parse('x = unicode(y)')
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-25 22:46:44.983435
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    expected_code = """
result = "Hello" + "World"
    """

    actual_code = """
result = unicode("Hello") + str("World")
    """

    from ..utils.source import source_to_code
    expected_tree = source_to_code(expected_code)
    actual_tree = source_to_code(actual_code)

    result = StringTypesTransformer.transform(actual_tree)
    assert result.tree == expected_tree

# Generated at 2022-06-25 22:46:48.746653
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = 'x = str("y")'
    tree = ast.parse(s)
    new_tree = StringTypesTransformer.transform(tree)
    assert isinstance(new_tree, TransformationResult)
    assert str(new_tree.tree) == s
    assert new_tree.tree_changed is False
    assert new_tree.children == []

# Generated at 2022-06-25 22:46:54.179060
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  import astor
  # input is 'str'
  input_str = """str"""
  # expected_output is 'unicode'
  expected_output_str = """unicode"""
  tree = ast.parse(input_str)
  actual_output_tree = StringTypesTransformer.transform(tree).tree
  actual_output_str = astor.to_source(actual_output_tree).strip()
  assert actual_output_str == expected_output_str

# Generated at 2022-06-25 22:46:55.518658
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_helpers import assert_semantical_equals


# Generated at 2022-06-25 22:47:01.791174
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
        from typing import Union
        '''
        Hello World
        '''
        def hello(name: str) -> str:
            return name
        """
    expected_code = """
        from typing import Union
        '''
        Hello World
        '''
        def hello(name: unicode) -> unicode:
            return name
        """

    tree = ast.parse(source)
    result, _, _ = StringTypesTransformer.transform(tree)
    assert expected_code == astor.to_source(result)

# Generated at 2022-06-25 22:47:03.800418
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""a = str()""")

    assert ast.dump(tree) == ast.dump(StringTypesTransformer.transform(tree).tree)

# Generated at 2022-06-25 22:47:06.375187
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    import inspect
    import textwrap

    code = textwrap.dedent(inspect.getsource(test_StringTypesTransformer))
    tree = ast3.parse(code)

    StringTypesTransformer.transform(tree)

# Generated at 2022-06-25 22:47:09.885423
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("name = 'a'")) == \
            TransformationResult(ast.parse("name = 'a'"), False, [])

    assert StringTypesTransformer.transform(ast.parse("name = str('a')")) == \
            TransformationResult(ast.parse("name = unicode('a')"), True, [])


# Generated at 2022-06-25 22:47:10.618013
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass



# Generated at 2022-06-25 22:48:14.371243
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-25 22:48:19.097261
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import Source

    source = Source("""\
    from __future__ import print_function
    x = 'abc' + str(123)
    y = str(3.14)
    print("finished")
    """)
    tree = source.tree
    tree = StringTypesTransformer.transform(tree)
    assert tree.changed
    source2 = Source(tree.code, "<test>")
    assert source.code != source2.code
    assert 'str' not in source2.code

# Generated at 2022-06-25 22:48:23.523491
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast, typing
    import python_modernize
    import python_modernize.transformers
    src = "assert str"
    expected_dst = "assert unicode"
    tree = ast.parse(src)
    tree = python_modernize.transformers.base.transform_tree(tree, python_modernize.transformers.StringTypesTransformer)
    dst = python_modernize.pgen2.unparse(tree).lstrip().rstrip()
    assert(dst == expected_dst)



# Generated at 2022-06-25 22:48:27.124498
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """
    my_str = str()
    my_var = 12
    """
    
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-25 22:48:32.176903
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    def test(str): 
        return str
    '''
    tree = ast.parse(code)

    tree = StringTypesTransformer.run_for_test(tree)

    assert ast.dump(tree) == "Module(body=[FunctionDef(name='test', args=arguments(args=[arg(arg='str', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Name(id='unicode', ctx=Load()))], decorator_list=[])])"

# Generated at 2022-06-25 22:48:43.980436
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # str(self, s)
    t = ast.parse('str(self, s)')
    t, messages = StringTypesTransformer.transform(t)
    assert t._fields == ('body',)
    assert isinstance(t.body[0], ast.Expr)
    assert t.body[0].value._fields == ('func', 'args', 'keywords', 'starargs', 'kwargs')
    assert t.body[0].value.func._fields == ('id', 'ctx')
    assert t.body[0].value.func.id == 'unicode'
    assert t.body[0].value.func.ctx._fields == ('id', 'ctx')
    assert t.body[0].value.args[0].id == 'self'

# Generated at 2022-06-25 22:48:44.840592
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:48:47.337619
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('print(str)')
    node = tree.body[0].value
    new_node = StringTypesTransformer.transform(node)
    assert new_node.body[0].value.s == 'unicode'

# Generated at 2022-06-25 22:48:53.066113
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .transformer import Transformer

    tree = ast.parse('''
if type(a) == str:
    pass
b = str()
''')

    t = Transformer([StringTypesTransformer])

    t.transform(tree)

    assert ast.dump(tree) == "If(test=Compare(left=Call(func=Name(id='type', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[], starargs=None, kwargs=None), ops=[Eq()], comparators=[Name(id='unicode', ctx=Load())]), body=[Pass()], orelse=[])"

# Generated at 2022-06-25 22:49:03.008721
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import NodeTransformer
    from typed_ast import ast3 as ast

    class TestTransformer(NodeTransformer):
        def visit_Name(self, node):
            return ast.Name(id='foo', ctx=ast.Load())

    test_transformer = TestTransformer()

    class Test(object):
        def example(self):
            return str("abc")

    tree = ast.parse(inspect.getsource(Test.example))
    tree = StringTypesTransformer.transform(tree)
    tree = test_transformer.visit(tree)
    code = compile(tree, '<string>', mode='exec')
    ns = {}
    exec(code, ns)
    assert ns['example'](Test()) == 'foo'

# Generated at 2022-06-25 22:51:30.008202
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("class Test: def test(self): foo = str")
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert(str(result.tree) == "class Test(object): def test(self): foo = unicode")
    assert(not result.errors)
    assert(result.tree_changed)

# Generated at 2022-06-25 22:51:34.007077
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    code = """def foo(a):
    return str(a)
    """

    tree = ast.parse(code)
    transformed_code = StringTypesTransformer.transform(tree)
    assert astor.to_source(transformed_code) == 'def foo(a):\n    return unicode(a)\n    '

# Generated at 2022-06-25 22:51:41.114165
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Note that string literals are represented as String object in python2 in typed_ast. So tests will fail if these objects are not converted to unicode.
    transformer = StringTypesTransformer()
    assert transformer.transform(ast.parse('print(1)')) == TransformationResult(ast.parse('print(1)'), False, [])
    assert transformer.transform(ast.parse('print(str)')) == TransformationResult(ast.parse('print("unicode")'), True, [])
    assert transformer.transform(ast.parse('print("str")')) == TransformationResult(ast.parse('print("unicode")'), True, [])
    assert transformer.transform(ast.parse('print(str(1))')) == TransformationResult(ast.parse('print(unicode(1))'), True, [])

# Generated at 2022-06-25 22:51:45.270679
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

    class_def = ast.parse('class MyClass(): pass')
    assert astunparse.unparse(class_def) == "class MyClass():\n    pass"

    xformer = StringTypesTransformer()
    result = xformer.transform(class_def)

    assert result.transformed_tree == class_def
    assert result.warnings == []
    assert result.tree_changed is True


# Generated at 2022-06-25 22:51:47.514680
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "name = 'py2to3'\nprint(type(name))\n"
    tree = ast.parse(code)
    assert StringTypesTransformer.transform(tree) is not None

# Generated at 2022-06-25 22:51:54.713174
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import os, sys, inspect
    
    current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parent_dir = os.path.dirname(current_dir)
    sys.path.insert(0, parent_dir)
    
    from ..utils.source_code import SourceCode
    from .unittest_transformer import UnitTestTransformer
    from .base import AST_2_7, AST_3_5
    
    source = SourceCode('''
# python 2.7
x = str()
# python 3.5
y = str()
''')

    tree_2_7 = AST_2_7.parse(source)
    tree_3_5 = AST_3_5.parse(source)
    

# Generated at 2022-06-25 22:52:02.963373
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    module = ast.parse('x = "test"')

    tree_changed, warnings, errors = StringTypesTransformer.transform(module)
    assert tree_changed
    assert len(warnings) == 0
    assert len(errors) == 0

    with open(self.dump_dir + 'string_types.py', 'w') as f:
        f.write(astunparse.unparse(module))