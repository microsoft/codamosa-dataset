

# Generated at 2022-06-25 22:41:57.367121
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    tree_0 = ast.parse("a = 'hi'")
    string_types_transformer.transform(tree_0)
    tree_1 = ast.parse("a = 'hi'")
    string_types_transformer.transform(tree_1)
    tree_2 = ast.parse("a = 'hi'")
    string_types_transformer.transform(tree_2)

# Generated at 2022-06-25 22:42:02.014115
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()

# Generated at 2022-06-25 22:42:11.714403
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def do_test(tree, expectedOutput, expectedCode):
        tree_changed, code, output = StringTypesTransformer().transform(tree)
        assert output == expectedOutput
        assert code == expectedCode
        assert tree_changed == True

    # Case 1
    input_1 = ast.parse("""
x = str("hello")
y = str(a + b)
z = str(1)
a = "hello"
b = str("hello")
c = unicode("hello")
""")
    expectedOutput_1 = ["hello", "a + b", "1", "hello", "hello", "hello"]

# Generated at 2022-06-25 22:42:12.481486
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_case_0()


# Generated at 2022-06-25 22:42:21.032427
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test_is_instance_of_BaseTransformer
    string_types_transformer_0 = StringTypesTransformer()
    assert isinstance(string_types_transformer_0, StringTypesTransformer)
    
    # test_is_instance_of_BaseTransformer
    string_types_transformer_1 = StringTypesTransformer()
    assert isinstance(string_types_transformer_1, StringTypesTransformer)
    
    # test_is_instance_of_object
    string_types_transformer_2 = StringTypesTransformer()
    assert isinstance(string_types_transformer_2, object)
    
    # test_is_instance_of_object
    string_types_transformer_3 = StringTypesTransformer()
    assert isinstance(string_types_transformer_3, object)

# Unit

# Generated at 2022-06-25 22:42:23.488404
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    target = (2, 7)
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:26.051817
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_1 = StringTypesTransformer()
    assert string_types_transformer_1.target == (2, 7)


# Generated at 2022-06-25 22:42:28.649368
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert isinstance(string_types_transformer, Object)


# Generated at 2022-06-25 22:42:35.006232
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree_0 = ast.parse("""
# A simple Python program to demonstrate
# variable using in built id() function
a = 5
print("a =", a)
print("a's memory location :", id(a))
print("id() function returns an integer, \
that is unique and constant for this object during the lifetime.\
It is same as 'address of' or 'reference' in other languages.")
    """)
    string_types_transformer_0 = StringTypesTransformer()
    string_types_transformer_0.transform(tree_0)


# Generated at 2022-06-25 22:42:35.955532
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:42:46.707311
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # type: () -> None
    import inspect
    import typed_astunparse
    from ..transforms import anno
    from .. import transforms

    for name, value in dict(inspect.getmembers(transforms)).items():
        if not name.endswith('Transformer'):
            continue
        if name == 'StringTypesTransformer':
            continue

        trans = value()
        if trans.target == (2, 7):
            continue

        filename = '%s.py' % name.lower()
        with open(filename, 'w') as f:
            f.write(dedent(inspect.getsource(value)))


# Generated at 2022-06-25 22:42:50.427095
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program = "a = str('hello')\nb = str('world')\n"
    tree = ast.parse(program)
    tree_expected = ast.parse("a = unicode('hello')\nb = unicode('world')\n")
    res = StringTypesTransformer.transform(tree)
    assert tree_expected == res.tree

# Generated at 2022-06-25 22:42:55.611182
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils import load_example_module
    module = load_example_module('test.py')
    node = module.body[0].value.args[0]
    print(ast.dump(node))
    assert ast.dump(StringTypesTransformer.transform(node).tree) == ast.dump(node), 'Unicode'

# Generated at 2022-06-25 22:42:59.974273
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import os
    import astor
    from .transformations import transformations
    from .utils import transform

    examples = transformations[StringTypesTransformer.__name__]
    for example in examples:
        before = example['before']
        after = example['after']

        if before != after:
            tree = ast.parse(before)
            tree = StringTypesTransformer.transform(tree)
            after_transformed = astor.to_source(tree).strip()
            assert after == after_transformed


# Command-line entry point

# Generated at 2022-06-25 22:43:05.634425
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse("""
x = "Hello, World"
type(x)
""")

    t_expected = ast.parse("""
x = u"Hello, World"
type(x)
""")

    results = list(StringTypesTransformer.transform(t))
    assert len(results) == 1
    assert ast.dump(results[0].tree) == ast.dump(t_expected)

# Generated at 2022-06-25 22:43:11.182664
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform(ast.parse("str(5)")).tree_changed is True
    assert t.transform(ast.parse("unicode(5)")).tree_changed is False
    assert t.transform(ast.parse("unicode_a(5)")).tree_changed is False
    assert t.transform(ast.parse("unicode_b")).tree_changed is False

# Generated at 2022-06-25 22:43:12.019420
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:15.017177
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    input_string = "s = 'this is a string'"

    # Act
    test_string = BaseTransformer.to_2to7_string(input_string)

    # Assert
    assert test_string == "s = u'this is a string'"

# Generated at 2022-06-25 22:43:26.840598
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    # Case 1
    code = """
        a = str('hello')
    """

    t = astor.code_to_ast.code_to_ast(code)
    StringTypesTransformer.transform(t)
    #print(astor.to_source(t))
    assert astor.to_source(t).strip() == "a = unicode('hello')"

    # Case 2
    code = """
        a = str(1) + str(2)
    """

    t = astor.code_to_ast.code_to_ast(code)
    StringTypesTransformer.transform(t)
    #print(astor.to_source(t))
    assert astor.to_source(t).strip() == "a = unicode(1) + unicode(2)"

    #

# Generated at 2022-06-25 22:43:30.090803
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for new_name
    assert StringTypesTransformer.new_name() == 'unicode'
    # Test for transform module
    assert StringTypesTransformer.transform(ast.parse("__"))

################################################################################
#                          Class StringTypesTransformer                              #
################################################################################

# Generated at 2022-06-25 22:43:38.171429
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    node = ast.Str()
    transformer = StringTypesTransformer(tree=node)

    assert transformer.tree is node
    assert transformer.is_valid_tree()

# Generated at 2022-06-25 22:43:43.432251
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
        a = str('hello')
        b = str(123)
        c = unicode('hello')
        d = unicode(123)
    """
    tree = ast.parse(src)
    tree = StringTypesTransformer.transform(tree)[0]
    exec(compile(tree, '<test>', 'exec'))
    assert a == 'hello'
    assert b == '123'
    assert c == 'hello'
    assert d == '123'

# Generated at 2022-06-25 22:43:49.309703
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
            x = str(y)
            y = str
            """
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    assert result.tree_changed
    assert isinstance(result.tree.body[0].value, ast.Call)
    assert isinstance(result.tree.body[0].value.func, ast.Name)
    assert result.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:43:55.122848
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Test case for the StringTypesTransformer class.
    """

    sut = StringTypesTransformer()
    construct_tree = ast.parse("""
        x = str('A')
        """)
    expected_tree = ast.parse("""
        x = unicode('A')
        """)

    actual_result = sut.transform(construct_tree)

    assert actual_result.tree == expected_tree
    assert actual_result.tree_changed == True
    assert actual_result.dependencies == []

# Generated at 2022-06-25 22:43:55.626515
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-25 22:44:01.827439
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_code = ast.parse('''
        a = str()
        b = str(a)
        c = str([1, 2, 3])
    ''')

    expected_result = ast.parse('''
        a = unicode()
        b = unicode(a)
        c = unicode([1, 2, 3])
    ''')

    StringTypesTransformer.transform(test_code)
    assert ast.dump(test_code) == ast.dump(expected_result)

# Generated at 2022-06-25 22:44:06.336960
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Example 1
    code = """
foo = '123'
print(type(foo))
    """
    expected_code = """
foo = u'123'
print(type(foo))
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == expected_code

    # Example 2

# Generated at 2022-06-25 22:44:08.070326
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import inspect

    source = inspect.getsource(StringTypesTransformer.transform)
    assert 'str' in source
    assert 'unicode' not in source

# Generated at 2022-06-25 22:44:08.906296
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:10.919150
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    result = StringTypesTransformer.transform(ast.parse('str'))
    assert str(result.tree) == 'unicode'

# Generated at 2022-06-25 22:44:17.700370
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:20.958507
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(
    """
    string = 'Hello, world!'
    print(type(string))
    """
    )

    result = StringTypesTransformer.transform(tree)
    print(result.tree)
    print(result.tree.body)

    assert result.tree_changed is True

# Generated at 2022-06-25 22:44:22.244481
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-25 22:44:31.295943
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import generate_test_ast, transform_and_test
    test_ast = generate_test_ast()
    tree_before_transformation = test_ast.body[0].body[0]
    transformed_ast = StringTypesTransformer.transform(test_ast).tree
    tree_after_transformation = (transformed_ast.body[0].body[0])

    def test_str():
        assert find(tree_after_transformation, ast.Name) is not None
        assert find(tree_after_transformation, ast.Name).id == 'unicode'

    def test_changed_tree():
        assert tree_before_transformation != tree_after_transformation

    transform_and_test(test_str, test_changed_tree)



# Generated at 2022-06-25 22:44:34.659275
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test with all values
    tree = ast.parse('a = 1 + str()', mode='eval')
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body.value.right.func.id == 'unicode'
    assert result.tree_changed is True

# Generated at 2022-06-25 22:44:39.540772
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str = "hello"')
    result = StringTypesTransformer.transform(tree)
    new_tree = result.tree

    # Test that `str` is replaced by `unicode` in new_tree.
    assert_tree_has_nodes(new_tree, ast.Name)
    name_node = new_tree.body[0].targets[0]
    assert_node(name_node, 'unicode')

# Generated at 2022-06-25 22:44:47.302529
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.sourceforge import get_ast

    # Python 2.7 code
    code = "\n".join([
        "def json_to_str(x):",
        "    return json.dumps(x).decode('utf-8')"
    ])

    expected_code = "\n".join([
        "def json_to_str(x):",
        "    return json.dumps(x).decode('utf-8')"
    ])

    # Parse code into AST
    module = ast.parse(code)

    # Apply transform
    module, tree_changed, messages = StringTypesTransformer.transform(module)

    assert len(messages) == 1
    assert messages[0].code == StringTypesTransformer.code
    assert messages[0].location.line == 2

# Generated at 2022-06-25 22:44:55.338270
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .utils import make_dummy_lambda, make_dummy_assign, make_dummy_call

    assert StringTypesTransformer.transform(make_dummy_lambda(['a'], ast.Name('str', ast.Load()))) == \
        TransformationResult(make_dummy_lambda(['a'], ast.Name('unicode', ast.Load())), True, [])

    assert StringTypesTransformer.transform(make_dummy_lambda(['a'], ast.Name('unicode', ast.Load()))) == \
        TransformationResult(make_dummy_lambda(['a'], ast.Name('unicode', ast.Load())), False, [])


# Generated at 2022-06-25 22:44:55.845506
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:57.867068
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.Name(id = 'str')
    y = ast.Name(id = 'unicode')
    assert StringTypesTransformer.transform(x).tree == y

# Generated at 2022-06-25 22:45:18.002059
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transform, assert_tree
    from ..utils.tree import to_src

    @assert_transform(target_version=(2, 7),
                      expected_src='def foo(a: unicode):',
                      source_version=(3, 7))
    def test_str():
        def foo(a: str): pass

    @assert_tree(target_version=(2, 7),
                 expected_src='msg = str(a) + b',
                 source_version=(3, 7))
    def test_str_assign():
        msg = str(a) + b


# Generated at 2022-06-25 22:45:22.568990
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open('examples/string_types.py', 'rt') as f:
        tree = ast.parse(f.read())
    
    # Confirm that the transformation does not change the AST
    assert tree.body[0].value.args[0].id == 'str'
    
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].value.args[0].id == 'unicode'
    assert result.tree_changed

# Generated at 2022-06-25 22:45:28.038688
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from . import JsonTransformer
    from . import StringTypesTransformer

    code = r"""
        x = str(42) + str(5)
    """

    tree = ast.parse(code)
    tree = transform(tree, [JsonTransformer, StringTypesTransformer])

    # TODO: This is not a good enough test!
    assert tree.body[0].value.left.func.id == 'unicode'
    assert tree.body[0].value.right.func.id == 'unicode'

# Generated at 2022-06-25 22:45:32.773691
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def testfunction(abc):
        def testfunc2():
            abc = str()
        return abc
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    with pytest.raises(NameError) as excinfo:
        exec(compile(result.tree, "<test>", "exec"))
    assert excinfo.value.message == "name 'unicode' is not defined"


# Generated at 2022-06-25 22:45:37.140644
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.target == (2, 7)
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.stringify() == 'StringTypesTransformer()'
    tree_changed, errors, tree, code = transformer.transform("x = 'test'")
    assert errors == []
    assert tree_changed == False


# Generated at 2022-06-25 22:45:38.951856
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..conftest import assert_transformer_basic_behavior
    assert_transformer_basic_behavior(StringTypesTransformer)

# Generated at 2022-06-25 22:45:47.810571
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import make_test, get_test_ast

    make_test(StringTypesTransformer)('''
        x = str("abc")
        def f():
            y = unicode("xyz")
            z = str('foo')
    ''')

    make_test(StringTypesTransformer)('''
        import sys
        import os
        x = 'foo'
        os.listdir('/')
        sys.version_info
    ''', no_transform=True)

# Generated at 2022-06-25 22:45:57.494146
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast_str

    source = """\
if True:
    if True:
        x = str.join
    else:
        if True:
            y = str()"""

    tree = source_to_ast(source)
    tr = StringTypesTransformer()
    new_tree = tr.transform(tree)

    expected_tree = source_to_ast_str("""\
if True:
    if True:
        x = unicode.join
    else:
        if True:
            y = unicode()""")

    assert compare_ast(expected_tree, new_tree.tree)

# Generated at 2022-06-25 22:46:01.838652
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .sample_asts import string_type_sample
    result = StringTypesTransformer.transform(string_type_sample)
    print(ast.dump(result.tree))
    assert result.tree_changed == True
    assert ast.dump(result.tree) == ast.dump(string_type_sample)

# Generated at 2022-06-25 22:46:10.583606
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.fake import FakeModule
    from ..utils.testing import assert_source_equal
    module = FakeModule()
    module.add_function("""
        def foo(s: str) -> str:
            pass
    """)
    module.add_class("""
        class Bar:
            s: str
    """)
    module.add_class("""
        class Baz(object):
            s: str
    """)

    StringTypesTransformer.transform(module.ast)
    assert_source_equal(module, """
        def foo(s: unicode) -> unicode:
            pass
    """)
    assert_source_equal(module, """
        class Bar:
            s: unicode
    """)

# Generated at 2022-06-25 22:46:39.397735
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    source = '''
print(str(123))
    '''

    tree = source_to_tree(source)
    tree, changed, _ = StringTypesTransformer.transform(tree)
    assert changed

    exec(compile(tree, '', 'exec'), {})

# Generated at 2022-06-25 22:46:40.830303
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # not really a test, just a validation of unit test
    pass

# Generated at 2022-06-25 22:46:43.036346
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests the constructor of class StringTypesTransformer."""

    result = StringTypesTransformer()

    assert(result.target == (2, 7))


# Generated at 2022-06-25 22:46:46.072436
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
    s = str('hi')
    '''

    expected_source = '''
    s = unicode('hi')
    '''

    transformed, _ = StringTypesTransformer.transform_source(source)
    assert transformed == expected_source

# Generated at 2022-06-25 22:46:49.283438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_processing import get_tree, render_tree
    
    tree = get_tree(StringTypesTransformer.__name__)
    newtree = StringTypesTransformer().transform(tree)
    
    assert render_tree(tree) == render_tree(newtree)

# Generated at 2022-06-25 22:46:58.145894
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # x = len(str(True))
    program = ast.Module([ast.Assign([ast.Name('x', ast.Store())], ast.Call(func=ast.Attribute(value=ast.Call(func=ast.Name(id='str', ctx=ast.Load()), args=[ast.Name(id='True', ctx=ast.Load())], keywords=[]), attr='__len__', ctx=ast.Load()), args=[], keywords=[]))])

    # x = len(unicode(True))

# Generated at 2022-06-25 22:47:01.189581
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3

    node = ast3.parse('a = str')
    node_transformed = StringTypesTransformer.transform(node)
    assert node_transformed.tree.body[0].value.id == 'unicode'

# Generated at 2022-06-25 22:47:05.986928
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import from_source

    tr = from_source(StringTypesTransformer, '''
        print(str)
        print(unicode)
        ''')
    tree = tr.ast
    assert isinstance(tree, ast.Module)
    assert len(tr.errors) == 0
    assert tr.tree_changed
    assert tree.body[0].value.id == 'unicode'
    assert tree.body[1].value.id == 'unicode'

# Generated at 2022-06-25 22:47:08.352963
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    x = typed_ast.ast3.Name(id='str', ctx=typed_ast.ast3.Load())
    StringTypesTransformer.transform(x)
    assert x.id == 'unicode'

# Generated at 2022-06-25 22:47:16.217147
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    def foo(my_var=''): pass

    def bar(my_var='waaaaa'):
        my_var = str(my_var)

        if isinstance(my_var, str):
            pass
    '''

    expected_code = '''
    def foo(my_var=''): pass

    def bar(my_var='waaaaa'):
        my_var = unicode(my_var)

        if isinstance(my_var, unicode):
            pass
    '''

    tree = ast.parse(code)
    string_types_transformer = StringTypesTransformer()
    tree_changed, _ = string_types_transformer.transform(tree)

    expected_tree = ast.parse(expected_code)
    assert ast.dump(tree) == ast.dump

# Generated at 2022-06-25 22:48:30.626561
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTestTransformer

    # pylint: disable=protected-access

# Generated at 2022-06-25 22:48:33.337508
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = "def f(a: str): print(a)"
    expected_code = "def f(a: unicode): print(a)"
    # When
    actual_code = StringTypesTransformer.transform(code)
    # Then
    assert actual_code == expected_code

# Generated at 2022-06-25 22:48:33.823371
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:48:45.811336
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTransformerTest
    from ..utils import get_ast
    from ..visitors.resolve_names import NameResolver
    from ..visitors.resolve_types import TypeResolver

    class_def = get_ast(
        """
        class StringTypesTransformer(BaseTransformer):
            @classmethod
            def transform(cls, tree: ast.AST) -> TransformationResult:
                pass
        """
    ).body[0]

    constructor = class_def.body[0]
    assert constructor.name == '__init__'
    assert len(constructor.args.args) == 1

    type_resolver = TypeResolver()
    type_resolver.visit(class_def)

    name_resolver = NameResolver()
    name_resolver.visit(class_def)

   

# Generated at 2022-06-25 22:48:52.297737
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests if `StringTypesTransformer` correctly transforms 'str' to 'unicode'.
    """
    # Create a tree of this structure:
    # [Module(body=[Name(id='str', ctx=Load())])]
    tree = ast.Module(body=[ast.Name(id='str', ctx=ast.Load())])

    # Test if the target class correctly transforms the tree to the following structure:
    # [Module(body=[Name(id='unicode', ctx=Load())])]
    assert ast.dump(StringTypesTransformer.transform(tree)) == ast.dump(ast.Module(body=[ast.Name(id='unicode', ctx=ast.Load())]))

# Generated at 2022-06-25 22:49:02.538739
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.ignore import ignore
    from .base import BaseTestTransformer

    class TestStringTypesTransformer(BaseTestTransformer):
        target = (2, 7)

        @classmethod
        def prepare(cls):
            cls.old_tree = ast.parse('''
                def f():
                    def g():
                        x = str(3)
                        y = str(4)
                ''')
            cls.new_tree = ast.parse('''
                def f():
                    def g():
                        x = unicode(3)
                        y = unicode(4)
                ''')

    # Ignore line numbers
    ignore.append('line')
    # Ignore order of definitions
    ignore.append('Def.body.0')
    ignore.append('Def.body.1')
    # Ignore order of

# Generated at 2022-06-25 22:49:05.315005
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse("""a = str()""")

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed is True
    assert result.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:49:06.098512
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor


# Generated at 2022-06-25 22:49:10.388754
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    mod = ast.parse("""a = str(b)""")
    mod = StringTypesTransformer.transform(mod).tree
    assert ast.dump(mod) == "Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='b', ctx=Load())], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-25 22:49:13.583996
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_astunparse
    tree = ast.parse("str = 'str'")
    tree = StringTypesTransformer.transform(tree).tree
    assert typed_astunparse.unparse(tree) == "unicode = 'str'"

# Generated at 2022-06-25 22:51:47.639408
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Try to transform a string literal
    tree = ast.parse('''
        a = "hello world"
    ''')

    # Apply the transformation
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)

    # Check the types of a
    a = new_tree.body[0].value
    assert type(a) == ast.Str
    

# Generated at 2022-06-25 22:51:48.118875
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert False

# Generated at 2022-06-25 22:51:51.038183
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    code_string = """
    a = str("asas")
    """
    tree = ast.parse(code_string)
    transformer.transform(tree)
    #TODO: add test cases

# Generated at 2022-06-25 22:51:51.730066
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:52:02.605933
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.ir import cst_to_ast, ast_to_cst
    from ..utils import run_transformer

    AST_TREE = cst_to_ast(r'''
    class HelloWorld(object):
        def __init__(self):
            self.greeting = str()

        def greet(self):
            print(self.greeting)
    ''')

    NEW_TREE = run_transformer(AST_TREE, StringTypesTransformer)

    assert ast_to_cst(NEW_TREE) == r'''
    class HelloWorld(object):
        def __init__(self):
            self.greeting = unicode()

        def greet(self):
            print(self.greeting)
    '''