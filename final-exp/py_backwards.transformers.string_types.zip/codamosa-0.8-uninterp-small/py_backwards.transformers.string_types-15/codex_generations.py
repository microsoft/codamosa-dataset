

# Generated at 2022-06-25 22:42:00.856482
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:42:01.987459
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer().tree.__doc__ != None


# Generated at 2022-06-25 22:42:03.437467
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:04.539321
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer


# Generated at 2022-06-25 22:42:06.478239
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert string_types_transformer_0.name == 'StringTypesTransformer'

# Generated at 2022-06-25 22:42:10.440482
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer is not None
    assert 'StringTypesTransformer' in str(string_types_transformer)
    assert str(ast.Str) in str(string_types_transformer)


# Generated at 2022-06-25 22:42:11.674384
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Success case, assert an instance of the class
    instance = StringTypesTransformer()
    assert isinstance(instance, StringTypesTransformer)


# Generated at 2022-06-25 22:42:15.530891
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert isinstance(string_types_transformer_0, StringTypesTransformer)

    fake_code = """
b'hello'
"""
    # Unit test for method transform() of class StringTypesTransformer
    def test_transform():
        assert isinstance(string_types_transformer_0.transform(fake_code), TransformationResult)
    test_transform()

# Generated at 2022-06-25 22:42:18.788736
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = ast.parse('s = str(foo)')
    string_types_transformer_1 = StringTypesTransformer()
    assert string_types_transformer_1.transform(s) == TransformationResult(
        ast.parse('s = unicode(foo)'), True, [])

# Generated at 2022-06-25 22:42:19.947557
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:23.285569
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): # TODO: write a test
    pass

# Generated at 2022-06-25 22:42:27.872496
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor 
    code = '''
a = str(1)
b = str('hello')
'''.strip()

    tree = astor.parse_file(code)
    tree = StringTypesTransformer.transform(tree)

    assert astor.to_source(tree) == '''
a = unicode(1)
b = unicode('hello')
'''.strip()

# Generated at 2022-06-25 22:42:36.442124
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:42:40.607417
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    tree = ast3.parse('x = str(y)')
    StringTypesTransformer.transform(tree)
    assert isinstance(tree.body[0].value, ast3.Call)
    assert isinstance(tree.body[0].value.func, ast3.Name)
    assert tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:42:47.505487
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # str is not changed
    code = 'str'
    node = ast.parse(code)
    res = StringTypesTransformer.transform(node)
    assert res.tree_changed == False
    assert len(res.errors) == 0
    assert isinstance(res.tree, ast.AST)

    # str is changed
    code = 'str'
    node = ast.parse(code)
    res = StringTypesTransformer.transform(node)
    assert res.tree_changed
    assert len(res.errors) == 0
    assert isinstance(res.tree, ast.AST)

# Generated at 2022-06-25 22:42:49.957963
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """

    """
    t = StringTypesTransformer()
    tree = ast.parse('''a = str(b)''')
    t.transform(tree)
    return True

# Generated at 2022-06-25 22:42:55.759870
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        var1 = str()
        var2 = "abc"
    """
    expected = """
        var1 = unicode()
        var2 = "abc"
    """
    tree = ast.parse(code)
    new_tree = ast.fix_missing_locations(StringTypesTransformer.transform(tree).tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-25 22:43:05.288664
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test case 1
    input_src = 'a = str(1)'
    expected_src = 'a = unicode(1)'
    node = ast.parse(input_src)
    res = StringTypesTransformer.transform(node)
    assert ast.dump(res.tree) == expected_src

    # Test case 2
    input_src = 'a = b.str()'
    expected_src = 'a = b.unicode()'
    node = ast.parse(input_src)
    res = StringTypesTransformer.transform(node)
    assert ast.dump(res.tree) == expected_src

    # Test case 3
    input_src = 'a = str(1) + str(b)'
    expected_src = 'a = unicode(1) + unicode(b)'

# Generated at 2022-06-25 22:43:08.276271
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = inspect.getsource(StringTypesTransformer)
    #print(code)  # Tracing
    #test = StringTypesTransformer()
    #test.transform()

# Generated at 2022-06-25 22:43:12.401860
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # type: () -> None
    code = '''
    f = str('foobar')
    '''
    expected = '''\
f = unicode('foobar')
'''
    res = StringTypesTransformer.transform(ast.parse(code))
    assert res.tree_changed == True
    assert ast.unparse(res.tree) == expected



# Generated at 2022-06-25 22:43:27.629966
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tr = StringTypesTransformer()
    assert tr.tree.body[0].body[0].value.s == 'Hello, World!'
    tr.transform()
    assert tr.tree.body[0].body[0].value.s == 'Hello, World!'
    assert tr.tree_changed is True
    # print(ast.dump(tr.tree))
    # output: 'Module(body=[FunctionDef(name='test', args=arguments(args=[]), body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Str(s='Hello, World!', unicode='Hello, World!', bytes='Hello, World!', raw='Hello, World!', begin=(2, 16), end=(2, 32))], keywords=[], starargs=None, kwargs=None, begin=(2, 4

# Generated at 2022-06-25 22:43:30.332628
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
        a = str(b)
    """

    tree = ast.parse(src)
    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:43:31.167446
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:38.309758
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .transformations_test import create_test_string
    changes = StringTypesTransformer.transform(create_test_string())
    assert changes.tree_changed
    assert len(changes.tokens) == 0
    assert str(changes.tree) == "from __future__ import unicode_literals; astring = unicode('this is a string');"

# Generated at 2022-06-25 22:43:45.238714
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
foo = str(bar)
""")

    transformed = StringTypesTransformer.transform(tree)[0]

    # assert transformed.body[0] == ast.Name(id='unicode')
    assert ast.dump(transformed) == textwrap.dedent("""\
    <Module>
      <Assign>
        <AssignName ctx="Store">foo</AssignName>
        <Call>
          <Name ctx="Load">unicode</Name>
          <Name ctx="Load">bar</Name>
        </Call>
      </Assign>
    </Module>""")

# Generated at 2022-06-25 22:43:54.059883
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1:
    source = """
    def x(z):
        y = str(z)
        y = str()
        y = str
        print(y)
    """
    expected = """
    def x(z):
        y = unicode(z)
        y = unicode()
        y = unicode
        print(y)
    """
    tree = ast.parse(source)
    new_tree = StringTypesTransformer().visit(tree)
    assert astor.to_source(new_tree) == expected
    # Test 2:
    source = """
    def x(z):
        y = unicode(z)
        y = unicode()
        y = unicode
        print(z)
    """

# Generated at 2022-06-25 22:43:58.942625
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_str, get_ast

    source = '''
        def foo() -> str:
            return 'abc'
    '''
    expected = '''
        def foo() -> unicode:
            return 'abc'
    '''
    tree = get_ast(source)
    result, tree_changed, _ = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert source_to_str(result) == expected

# Generated at 2022-06-25 22:44:03.237347
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
string = str(variable)
'''
    tree = ast.parse(code)
    ret = StringTypesTransformer.transform(tree)
    #print(ret)
    assert ret.tree_changed
    assert 'unicode' in ret.code

# Generated at 2022-06-25 22:44:09.377769
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Test if StringTypesTransformer can properly replace 'str' with 'unicode'.
    """
    test_ast = ast.parse('''
        x = str(1)
    ''')

    t = StringTypesTransformer()
    result = t.transform(test_ast)
    assert result.tree_changed
    assert result.node_names == []
    for_node = result.tree.body[0]
    assign_node = for_node.value
    call_node = assign_node.value
    assert call_node.func.id == 'unicode'


# Generated at 2022-06-25 22:44:14.571006
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert 'str' == ast.Name('str').id
    node1 = ast.Name('Unicode')
    tree_changed, _ = StringTypesTransformer.transform(node1)
    assert tree_changed == False
    assert node1.id == 'Unicode'

    node2 = ast.Name('str')
    tree_changed, _ = StringTypesTransformer.transform(node2)
    assert tree_changed == True
    assert node2.id == 'unicode'

# Generated at 2022-06-25 22:44:24.688689
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    src = """
    a = str(2)
    """
    tree = ast.parse(src)
    expected_code = """
    a = unicode(2)
    """
    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert(astor.to_source(new_tree) == expected_code)

# Generated at 2022-06-25 22:44:30.330983
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Define source
    src = """
    class A(object):
        def __init__(self):
            s = str(42)

    """

    # Define expected result
    expected_result = """
    class A(object):
        def __init__(self):
            s = unicode(42)

    """

    # Perform transformation
    result, num_changes = StringTypesTransformer.transform_source(src)

    # Perform tests
    assert num_changes == 1
    assert result == expected_result

# Generated at 2022-06-25 22:44:32.821056
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testutils import create_test_tree, print_tree, compare_py_code
    import os


# Generated at 2022-06-25 22:44:37.702804
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..utils.test_utils import AutoNamer, mock_node

    node = mock_node(
        ast.Name, 'str', {'id': 'str'}
    )
    with AutoNamer('test'):
        trans_tree = StringTypesTransformer.get_transformed_tree(node)
    assert isinstance(trans_tree, ast.Name)
    assert trans_tree.id == 'unicode'

# Generated at 2022-06-25 22:44:44.706976
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import round_trip
    from ..utils.parsers.python import parse_python

    def check_type_equal(source):
        tree = parse_python(source)
        new_tree = StringTypesTransformer.transform(tree)
        assert source != round_trip(new_tree.tree)

    source = '''
a = str
b = str()
c = str(1)
x = "Hello" + "World!"
'''
    target = '''
a = unicode
b = unicode()
c = unicode(1)
x = u"Hello" + u"World!"
'''
    check_type_equal(source)

# Generated at 2022-06-25 22:44:47.821490
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
num = 10
text = str(num)
    '''
    trans = StringTypesTransformer()
    result = trans.transform(code)
    assert result.code == '''
num = 10
text = unicode(num)
    '''
    assert result.report == []

# Generated at 2022-06-25 22:44:48.876123
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    StringTypesTransformer.transform(ast.parse('name = "Joe"'))

# Generated at 2022-06-25 22:44:49.472163
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:54.795398
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
import sys
a = 'foo'
print a
    """
    expected_src = """
import sys
a = u'foo'
print a
    """
    tree = ast.parse(src)
    expected_tree = ast.parse(expected_src)
    transformer = StringTypesTransformer()
    res = transformer.transform(tree)
    assert ast.dump(res.tree) == ast.dump(expected_tree)
    assert res.tree is not tree
    assert res.tree_changed

# Generated at 2022-06-25 22:45:02.908966
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test class StringTransformer.

    """
    # create tree
    string_node = ast.Name('str')
    literal_node = ast.Str('test')
    call_node = ast.Call(string_node, [literal_node], [], None, None)
    function_node = ast.FunctionDef('test_func', ast.arguments([], None, None, []), [ast.Return(call_node)], [])
    tree = ast.Module([function_node])

    # initialize transformer and assert that is has no effect
    transformer = StringTypesTransformer()
    transformed_tree, _, _ = transformer.transform(tree)
    print(ast.dump(transformed_tree))
    assert transformer.target == (2, 7)

    # change target and assert that the transformer has an effect

# Generated at 2022-06-25 22:45:19.869712
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_code = r'''
        def greet(name: str):
            return 'Hello, {}'.format(name)
    '''
    expected_code = r'''
        def greet(name: unicode):
            return 'Hello, {}'.format(name)
    '''
    # Test
    transformer = StringTypesTransformer()
    actual_code = transformer.transform(test_code)
    assert actual_code == expected_code

# Generated at 2022-06-25 22:45:20.908308
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    str
    """)
    result = StringTypesTransformer.transform(tree)
    print(ast.dump(result.tree))

# Generated at 2022-06-25 22:45:25.244501
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = "a = 'test'; a2 = 'test2'"
    test_tree = ast.parse(s)
    result = StringTypesTransformer.transform(test_tree)
    assert(result.transformed_tree.body[0].value.s == u'test')
    assert(result.transformed_tree.body[1].value.s == u'test2')
    assert(result.new_imports == [])
    assert(result.tree_changed)

    # Test if multiple changes can be done
    s = "a = 'test'; a2 = 'test2'"
    test_tree = ast.parse(s)
    result = StringTypesTransformer.transform(test_tree)
    assert(result.transformed_tree.body[0].value.s == u'test')

# Generated at 2022-06-25 22:45:28.350677
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast import parse
    from ..utils.tree import to_string
    from ..transpiler import Transpiler
    
    tree = parse('str(1)')
    transformed, *_ = Transpiler(tree).get_output()

    assert to_string(transformed) == 'unicode(1)'

# Generated at 2022-06-25 22:45:31.503196
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        target = (2, 7)
        transformer = StringTypesTransformer
        suite = (
            """
            x = 'hello'
            print "world"
            """,
            """
            x = u'hello'
            print "world"
            """
            )
    return Test()

# Generated at 2022-06-25 22:45:38.804062
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    # Test 1 - an example tree without string types
    test_tree = ast.parse('list = [1, 2]')
    result = StringTypesTransformer.transform(test_tree)
    desired_tree = ast.parse('list = [1, 2]')
    assert result.tree == desired_tree

    # Test 2 - an example tree with string types
    test_tree = ast.parse('list = [1, 2, str]')
    result = StringTypesTransformer.transform(test_tree)
    desired_tree = ast.parse('list = [1, 2, unicode]')
    assert result.tree == desired_tree

# Generated at 2022-06-25 22:45:41.042761
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
x = str()
"""
    t = StringTypesTransformer()
    t.transform(ast.parse(src))

# Generated at 2022-06-25 22:45:47.583224
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests the constructor of class StringTypesTransformer.

    """
    code = 'str_var = str()'
    tree = ast.parse(code)
    StringTypesTransformer(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='str_var', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"

# Generated at 2022-06-25 22:45:55.623158
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''def bar() -> str:
    return "hello"'''
    t = StringTypesTransformer()
    tree = ast.parse(source)
    t.visit(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='bar', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Return(value=Str(s='hello'))], decorator_list=[], returns=Name(id='unicode', ctx=Load()))])"

# Generated at 2022-06-25 22:46:02.122990
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # P=AST Node of the module after string_types transformation
    p = ast.parse("a = str()")
    StringTypesTransformer.transform(p)
    assert isinstance(p.body[0].value,ast.Call)
    assert isinstance(p.body[0].value.func,ast.Name)
    assert p.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:46:34.235561
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''class Cls:
        def method(self):
            return str("hello world")
    '''
    expected_code = '''class Cls:
        def method(self):
            return unicode("hello world")
    '''
    tree = ast.parse(code)
    tree_changed, errors, _ = StringTypesTransformer.transform(tree)
    compiled = compile(tree, '', 'exec')
    assert tree_changed == True
    assert errors == []
    assert expected_code == code_gen.to_source(tree)

# Generated at 2022-06-25 22:46:37.679019
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree1 = ast.parse("s = 'a' + u'b'; s = s.encode('utf-8')")
    transformer = StringTypesTransformer()
    new_tree1 = transformer.visit(tree1)
    print(ast.dump(new_tree1))
    assert len(ast.dump(new_tree1)) > 0



# Generated at 2022-06-25 22:46:45.975071
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """StringTypesTransformer is a class that represents AST Node objects.
    """
    assert isinstance(str, unicode)  # noqa
    node = ast.Name(id="str")
    assert isinstance(node, ast.Name)  # noqa
    if isinstance(node, ast.Name):
        assert node.id == "str"
        node.id = "unicode"
        assert node.id == "unicode"
    node.id = "str"
    assert node.id == "str"

    def change_name(node):
        node.id = "unicode"
        return node.id == "unicode"

    assert change_name(node)
    assert node.id == "unicode"
    assert not isinstance(node, ast.Str)  # noqa

# Generated at 2022-06-25 22:46:51.535261
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from textwrap import dedent
    from ..utils.tree import get_ast

    # Add the correct imports for this transformer
    import_from_future = dedent('''
    from __future__ import annotations
    ''')

    code = dedent('''
    def foo():
        return str('value')
    ''')

    tree = get_ast(import_from_future + code)
    tt = StringTypesTransformer()
    tt.transform(tree)
    assert "unicode('value')" in code

# Generated at 2022-06-25 22:46:54.957527
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast_2_7 = ast.parse('"abcdef"')
    ast_3_0 = ast.parse('b"abcdef"')
    assert StringTypesTransformer.transform(ast_2_7) == ast_3_0

# Generated at 2022-06-25 22:47:00.356080
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_string = "if not isinstance(x, str): pass"
    tree = ast.parse(code_string)
    try:
        # The tree is not changed
        tr_result = StringTypesTransformer.transform(tree)
        assert tr_result.tree_changed == False
        assert tr_result.report == []
        assert tr_result.tree == tree
        
    except:
        assert False, "StringTypesTransformer constructor should not throw errors"



# Generated at 2022-06-25 22:47:03.556429
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  code = "a = str"
  tree = ast.parse(code)
  result, changed = StringTypesTransformer.transform(tree)
  assert changed == True
  exec(compile(result, filename="", mode="exec"))
  assert a == 'unicode'

# Generated at 2022-06-25 22:47:08.051947
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = str('hello') + 'world'")

    # This is a workaround because class is a callable but pytest considers it a class
    transformer = StringTypesTransformer()
    tree = transformer.transform(tree)

    assert isinstance(tree, ast.AST)
    assert tree.body[0].value.left.func.id == 'unicode'
    assert tree.body[0].value.right.s == 'world'



# Generated at 2022-06-25 22:47:11.754534
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    import astor
    tree = ast.parse('x = str(1) + unicode(2)')
    tree2 = ast.parse('x = u"%d" % 1 + unicode(2)')
    t = StringTypesTransformer(tree)
    print(astor.dump_tree(tree))
    t = StringTypesTransformer(tree2)
    print(astor.dump_tree(tree2))

# Generated at 2022-06-25 22:47:16.414482
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = 'def test(hello: str): return hello'
    ast_tree = ast.parse(s)
    trans = StringTypesTransformer.transform(ast_tree)
    assert trans.tree_changed is True
    ast.fix_missing_locations(trans.tree)
    assert_code(compile(trans.tree, '<string>', 'exec'), s.replace('str', 'unicode'))

# Generated at 2022-06-25 22:48:25.382101
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse

    assert StringTypesTransformer.transform(
        parse("""
        str b = "a"
        """)
    ) == TransformationResult(
        parse("""
        unicode b = "a"
        """),
        tree_changed=True,
        errors=[]
    )


# Generated at 2022-06-25 22:48:25.870865
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:48:26.292666
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    return None

# Generated at 2022-06-25 22:48:33.173335
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from .transformations_util import roundtrip_unparse
    source = """
    import sys
    if sys.version_info[0] < 3:
        def __unicode__(self):
            pass
        def __long__(self):
            pass
        def __oct__(self):
            pass
        def __hex__(self):
            pass
    else:
        def __str__(self):
            pass
        def __bytes__(self):
            pass
        def __index__(self):
            pass
        def __complex__(self):
            pass
    """
    tree = ast3.parse(source)
    transformed_tree, tree_changed = StringTypesTransformer.transform(tree)
    unmodified_tree = roundtrip_unparse(tree)
    modified_tree

# Generated at 2022-06-25 22:48:41.483574
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..dummy_module import dummy_module

    ast_tree = dummy_module('str')
    res = StringTypesTransformer.transform(ast_tree)
    #print(astor.to_source(res.transformed_ast))
    assert res.tree_changed is True
    assert res.messages == []
    assert res.transformed_ast == dummy_module('unicode')
#test_StringTypesTransformer()

# Generated at 2022-06-25 22:48:48.254284
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_source = """
        a = str(1234)
        b = str()
    """
    desired_output_source = """
        a = unicode(1234)
        b = unicode()
    """
    tree = ast.parse(input_source)
    StringTypesTransformer.transform(tree)
    tree_source = compile(tree, filename="<ast>", mode="exec")
    iter_source = iter(str(tree_source).splitlines(True))

    for desired_line in desired_output_source.splitlines(True):
        generated_line = next(iter_source)
        assert desired_line == generated_line, "Failed formatting."

# Generated at 2022-06-25 22:48:51.949130
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree_before = ast.parse('str()')
    tree_after = ast.parse('unicode()')
    result = StringTypesTransformer.transform(tree_before)
    assert result.tree_changed
    assert ast.dump(result.tree) == ast.dump(tree_after)

# Generated at 2022-06-25 22:48:55.159186
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert_equal(StringTypesTransformer.transform(ast.parse("a = str('Hi')")),
                 ast.parse("a = unicode('Hi')"))

    assert_equal(StringTypesTransformer.transform(ast.parse("b = str('Hi1', 'utf8')")),
                 ast.parse("b = unicode('Hi1', 'utf8')"))

# Generated at 2022-06-25 22:49:01.843466
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
   from ..utils import parse
   from .base import run_transformer

   code = '''
   def foo(s):
       return type(s) is str
   '''

   tree = parse(code)
   out, _ = run_transformer(StringTypesTransformer, tree)
   assert out == "def foo(s):\n    return type(s) is unicode\n"

# Generated at 2022-06-25 22:49:09.669993
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Initialization
    code = "a=str('ciao')\n b=str()"
    expected_code="a=unicode('ciao')\n b=unicode()"
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)

    # remove old test file if exists
    try:
        os.remove("test.py")
    except OSError:
        pass
    open("test.py", 'a').close()

    # dump ast tree in a test file
    with open("test.py", "w") as test_file:
        test_file.write(astor.to_source(tree))

    # Assert
    assert(astor.code_to_ast(expected_code).body[0]==ast.parse(expected_code).body[0])

# Generated at 2022-06-25 22:51:48.769035
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    expected = ast.Module(
        body = [
            ast.FunctionDef(
                name = 'f',
                args = ast.arguments(
                    args = [
                        ast.Name(id = 'x', ctx = ast.Param())
                    ],
                    vararg = None,
                    kwarg = None,
                    defaults = []
                ),
                body = [],
                decorator_list = []
            ),
            ast.FunctionDef(
                name = 'g',
                args = ast.arguments(
                    args = [
                        ast.Name(id = 'x', ctx = ast.Param())
                    ],
                    vararg = None,
                    kwarg = None,
                    defaults = []
                ),
                body = [],
                decorator_list = []
            )
        ]
    )

    source

# Generated at 2022-06-25 22:51:52.198030
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('import six\nsix.string_types')
    expected_tree = ast.parse('import six\nsix.text_type')

    result = StringTypesTransformer.transform(tree)

    assert result.tree == expected_tree
    assert result.tree_changed



# Generated at 2022-06-25 22:52:03.337704
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.ast_builder import build

    # No transformation
    tree = build('''
        import sys
        import os
        ''', 'ast')
    res = StringTypesTransformer.transform(tree)
    assert res.tree == tree
    assert not res.tree_changed
    assert res.hints == []

    # With transformation
    tree = build('''
        import sys
        import os
        a = str(1)
        b = str(1.0)
        c = str('a')
        d = str(b'a')
        ''', 'ast')
    res = StringTypesTransformer.transform(tree)
    assert res.tree is not tree
    assert res.tree_changed