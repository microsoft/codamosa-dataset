

# Generated at 2022-06-25 22:42:03.482251
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass


if __name__ == "__main__":
    test_case_0()
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:42:04.584569
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert not StringTypesTransformer()

# Generated at 2022-06-25 22:42:05.845129
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()



# Generated at 2022-06-25 22:42:13.081036
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(
        """
        a = 'string'
        if isinstance(a, str):
            print(a)
        else:
            print(a[0])

        b = 42
        if isinstance(b, int):
            while b > 0:
                print(b)
                b -= 1

        """
    )
    string_types_transformer = StringTypesTransformer()
    string_types_transformer.visit(tree)

    assert tree.body[1].test.args[1].id == 'unicode'
    assert tree.body[2].body[0].value.s == 'string'

# Generated at 2022-06-25 22:42:14.804097
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer != None


# Generated at 2022-06-25 22:42:18.988653
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input = ast.parse('''a = str''', mode='exec')
    input_changed = ast.parse('''a = unicode''', mode='exec')
    assert input.body[0] == input_changed.body[0]
    transformed, _, _ = StringTypesTransformer.transform(input)
    assert transformed.body[0] == input_changed.body[0]

# Generated at 2022-06-25 22:42:22.432777
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str()")
    tree_changed = string_types_transformer_0.transform(tree)
    assert tree_changed
    assert string_types_transformer_0.target == (2, 7)


# Generated at 2022-06-25 22:42:23.684635
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_1 = StringTypesTransformer()

# Generated at 2022-06-25 22:42:26.967628
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Constructor test
    try: 
        string_types_transformer_0 = StringTypesTransformer()
    except NameError as e:
        print("Error: lack of module " + e.__str__())


# Generated at 2022-06-25 22:42:28.238211
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert isinstance(StringTypesTransformer, object)


# Generated at 2022-06-25 22:42:34.851221
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Sample code used for testing the class StringTypesTransformer"""
    code = """
    str('hello')
    """
    expected_result = """
    unicode('hello')
    """
    tree = ast.parse(code)
    new_tree, tree_changed, msg = StringTypesTransformer.transform(tree)
    assert expected_result == astor.to_source(new_tree)
    print(msg)

# Generated at 2022-06-25 22:42:37.052400
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests constructor of class StringTypesTransformer.

    """
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer.target == (2, 7)


# Generated at 2022-06-25 22:42:45.227678
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    module_name = ast.Module([])
    module_name.body = [ast.FunctionDef('test',
                                        ast.arguments(),
                                   [ast.Expr(ast.Call(ast.Name('print',ast.Load()),
                                                      [ast.Str('Hello world', ast.Load())],
                                                      [],
                                                      None,
                                                      None))],
                                   [],
                                   None)]
    assert all(StringTypesTransformer.transform(module_name))
    assert module_name.body[0].body[0].value.func.id == 'print'
    assert isinstance(module_name.body[0].body[0].value.args[0], ast.Unicode)

# Generated at 2022-06-25 22:42:50.229630
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Foo:
        def bar(self, x: str):
            return

    tree = ast.parse(inspect.getsource(Foo))
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True

    # ast.dump(result.tree, include_attributes=True)
    # print(dump(result.tree))
    transformed_source = astor.to_source(result.tree)

# Generated at 2022-06-25 22:42:54.187048
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_type_transformer = StringTypesTransformer()
    assert string_type_transformer.__class__.__name__ == 'StringTypesTransformer'
    assert string_type_transformer.target == (2, 7)


# Generated at 2022-06-25 22:42:58.187698
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def f(arg):
        print(str(arg))
    """
    tree = ast.parse(code)
    expected_code = """
    def f(arg):
        print(unicode(arg))
    """
    result = StringTypesTransformer.transform(tree)
    print(result.tree)
    assert expected_code == result.tree_repr
    assert result.tree_changed

# Generated at 2022-06-25 22:43:00.606034
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str s = "abc"')).tree_changed
    assert StringTypesTransformer.transform(ast.parse('int s = 123')).tree_changed == False

# Generated at 2022-06-25 22:43:05.532308
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string = "var = str(abc)"
    tree = ast.parse(string)
    assert ast.dump(StringTypesTransformer.transform(tree)) == ast.dump(tree)

    string = "var = str()"
    tree = ast.parse(string)
    assert ast.dump(StringTypesTransformer.transform(tree)) == ast.dump(tree)

# Generated at 2022-06-25 22:43:07.235593
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(None).changed == False



# Generated at 2022-06-25 22:43:09.371181
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    stringTypesTransformer = StringTypesTransformer()
    assert stringTypesTransformer.name == "StringTypesTransformer"

# Generated at 2022-06-25 22:43:20.185613
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = ["a = 'hello world'",
            "print str(b)",
            'c = b + " world"']
    tree = ast.parse('\n'.join(code))

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed is True
    for node in find(result.tree, ast.Name):
        assert node.id != 'str'

    exec(compile(result.tree, '<ast>', 'exec'))

# Generated at 2022-06-25 22:43:22.105893
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  "This tests the constructor."
  fake = StringTypesTransformer() # user has to construct the object
  pass

# Generated at 2022-06-25 22:43:22.681410
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:43:28.927026
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.fixtures import get_test_module

    source = get_test_module(__name__, 'source.py')
    expected = get_test_module(__name__, 'expected.py')
    tree = ast.parse(source)
    results = StringTypesTransformer.transform(tree)

    assert results.tree is not None
    assert results.tree_changed is True
    assert results.messages == []
    assert ast.dump(results.tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-25 22:43:32.485842
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''def foo(s):
    return str(s)'''

    expected = '''def foo(s):
    return unicode(s)'''

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree).tree

    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-25 22:43:39.235012
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    tree = ast.parse('''
    x = str
    ''')
    t = StringTypesTransformer()
    tree_changed, _ = t.transform(tree)
    assert isinstance(tree.body[0].value.id, type('')) and tree.body[0].value.id == 'unicode'

# Generated at 2022-06-25 22:43:46.343460
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_helpers import parse
    from textwrap import dedent
    from ..utils.text import dedent_docstring

    # Test that unicode is properly inserted
    assert StringTypesTransformer.transform(parse(dedent('''
        str('foo')
    '''))).tree.body[0].value.s == 'foo'

    # Test that the docstring modification is correct

# Generated at 2022-06-25 22:43:47.583805
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert('unicode' == find(ast.parse("str"), ast.Name).id)

# Generated at 2022-06-25 22:43:52.856158
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree_str = '''
    def f(a: str, b: int) -> str:
        return a
    '''
    tree = ast.parse(tree_str)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(ast.parse('''
    def f(a: unicode, b: int) -> unicode:
        return a
    '''))

# Generated at 2022-06-25 22:43:54.930038
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    result = StringTypesTransformer(ast.parse('a = str(b)')).transform()
    assert result.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:44:03.318150
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from .utils import round_trip

# Generated at 2022-06-25 22:44:08.824914
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse("""
        str = 1
    """)
    assert StringTypesTransformer(2, 7).transform(tree).errors == []

    with pytest.raises(ValueError):
        StringTypesTransformer(2, 6).transform(typed_ast.ast3.parse("str = 1"))

    with pytest.raises(ValueError):
        StringTypesTransformer(3, 5).transform(typed_ast.ast3.parse("str = 1"))

# Generated at 2022-06-25 22:44:13.229940
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = "def f(x: str):\n    pass\n"
    tree = ast.parse(s)
    res = StringTypesTransformer.transform(tree)
    assert res.tree_changed
    assert type(res.tree)==ast.Module
    assert len(res.errors)==0
    assert res.tree.body[0].args.args[0].annotation.id=='unicode'


# Generated at 2022-06-25 22:44:14.656286
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import node_factory


# Generated at 2022-06-25 22:44:21.102079
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that StringTypesTransformer replaces str with unicode in type annotations.

    """
    code1 = """
    def foo(bar: str): pass
    """
    t1 = ast.parse(code1)
    expected_code1 = """
    def foo(bar: unicode): pass
    """
    expected_t1 = ast.parse(expected_code1)
    result1, changed1 = StringTypesTransformer.transform(t1)
    if changed1:
        result1.show()
    assert changed1 == True
    assert ast.dump(result1) == ast.dump(expected_t1)



# Generated at 2022-06-25 22:44:23.255166
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse('a = "hello"')
    assert tree.body[0].value.s == 'hello'

# Generated at 2022-06-25 22:44:27.270361
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
	input_code = 'x = "abc"; print(str(5))'
	expected_code = 'x = unicode("abc"); print(unicode(5))'
	tree = ast.parse(input_code)
	tree = StringTypesTransformer.transform(tree)
	assert astor.to_source(tree).strip() == expected_code

# Generated at 2022-06-25 22:44:33.252901
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test data
    testCode = """
    s = str(1)
    """

    # Expected output
    expectedCode = """
    s = unicode(1)
    """

    # Perform test
    astTree = ast.parse(testCode)
    treeChanged, errors, warnings, fixups = StringTypesTransformer.transform(astTree)

    # Verify output
    assert(compile(astTree, "<test>", "exec") == compile(ast.parse(expectedCode), "<expected>", "exec"))

# Generated at 2022-06-25 22:44:41.596700
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import TransformResult
    from ..utils.tree import ast_to_str
    node_1 = ast.Name(id='str', ctx=ast.Load())
    node_1_changed = ast.Name(id='unicode', ctx=ast.Load())
    assert ast_to_str(node_1) == 'str'
    assert ast_to_str(node_1_changed) == 'unicode'
    dummy_node =ast.Name(id='dummy', ctx=ast.Load())
    assert ast_to_str(dummy_node) == 'dummy'
    assert 'dummy' in ast_to_str(dummy_node)
    transform_result = StringTypesTransformer.transform(node_1)
    assert isinstance(transform_result, TransformResult)

# Generated at 2022-06-25 22:44:45.075605
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = "string"\nprint(type(x))')
    expected_tree = ast.parse('x = u"string"\nprint(type(x))')

    res = StringTypesTransformer.transform(tree)
    assert res.tree == expected_tree
    assert res.tree_changed



# Generated at 2022-06-25 22:45:00.922293
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""\
# Your code goes here!
name = str(input('What is your name?'))
print('Hi, %s.' % name)"""
    )

    tree = StringTypesTransformer.transform(tree)

    assert "unicode" in ast.dump(tree)

# Generated at 2022-06-25 22:45:03.632190
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    class X:
        def f(a):
            return str(a)

    tree = ast.parse('acbac')

    # Before transformation
    print(ast.dump(tree))

    result = Strin

# Generated at 2022-06-25 22:45:12.631542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typing import Dict
    from typed_ast import ast3 as ast

    DummyClass = ast.ClassDef(name='DummyClass', bases=[], keywords=[], body=[], decorator_list=[], name='DummyClass')
    DummyClass.body = [ast.Pass()]

    func_args = ast.arguments(args=[], vararg=None, kwarg=None, defaults=[])
    FunctionDef = ast.FunctionDef(name='FunctionDef', args=func_args, body=[], decorator_list=[], returns=None)
    FunctionDef.body = [ast.Pass()]


    # Test to ensure that string "str" is replaced with "unicode"
    # and that objects of class ast.Name with arg "str" are replaced with "unicode"
    # root1 = ast.parse("s = str

# Generated at 2022-06-25 22:45:19.677226
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    comments = []
    tree = ast.parse('def fn(x: str = "foo"): pass')
    tr = StringTypesTransformer.transform(tree)
    assert not tr.tree_changed
    ast.fix_missing_locations(tree)
    assert compile(tree, "<?>", 'exec') is not None

    tree = ast.parse('def fn(x: str = "foo"): pass')
    tr = StringTypesTransformer.transform(tree)
    assert tr.tree_changed
    ast.fix_missing_locations(tree)
    assert compile(tree, "<?>", 'exec') is not None
    # TODO assert tr.comments == comments

# Generated at 2022-06-25 22:45:21.727454
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..main import transform
    from textwrap import dedent

    code = dedent('''\
    x = str
    y = unicode
    ''')

    tree = ast.parse(code)
    assert transform(tree) == dedent('''\
    x = unicode
    y = unicode
    ''')

# Generated at 2022-06-25 22:45:28.350112
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import TransformationResult

    # Program that uses `str`
    tup = ("str", ast.Name(id="str", ctx=ast.Load()))
    expected_tup = ("unicode", ast.Name(id="unicode", ctx=ast.Load()))

    # Sample program
    sample_program = ast.Module([
        ast.Assign([tup[0]], tup[1])
    ])

    t = StringTypesTransformer()

    result = t.transform(sample_program)

    assert result == TransformationResult(ast.Module([ast.Assign([expected_tup[0]], expected_tup[1])]), True, [])

# Generated at 2022-06-25 22:45:34.382649
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = StringTypesTransformer()
    #(1) name of python file:
    filename = "macro/python/tests/test_transformer/test_StringTypesTransformer.py"
    #(2) macro of this file:
    macroname = "PY2UNICODE"
    #(3) run the macro:
    beforecode = open(filename, "rt").read()
    aftercode = tt.run_macro(macroname, beforecode)
    #(4) compare result with expected output:
    expected_file = open("macro/python/tests/test_transformer/expected_StringTypesTransformer.py")
    expected_code = expected_file.read()
    assert aftercode == expected_code

# Generated at 2022-06-25 22:45:38.879242
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typing
    # FIXME: bug in typed_ast causes SyntaxError here
    # code = typing.cast(str, "def f(): return str(1)") 
    code = "def f(): return str(1)"
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert compile(tree, "<test>", "exec").co_consts[0] == unicode

# Generated at 2022-06-25 22:45:45.882121
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    imp = ast.Import([ast.alias('sys', None)])
    code_str = """
abc = 'abc'
abc_b = str(abc)
abc_c = str(u"abc")
abc_d = str([])
"""
    import_str = ast.ImportFrom(module='builtins', names=[ast.alias('str', None)], level=0)
    module = ast.Module([imp, import_str, ast.parse(code_str)])
    result = StringTypesTransformer.transform(module)
    # Check that the transformation works
    assert result.tree_changed == True
    assert isinstance(result.tree, ast.AST)
    # Check that the import statement is not in the tree
    node = ast.Module([imp, ast.parse(code_str)])
    assert node == result.tree

# Generated at 2022-06-25 22:45:50.318969
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    # setup
    tree = ast.parse('x = str(0)')
    new_tree = StringTypesTransformer.transform(tree)
    # assert
    assert type(new_tree.tree) == ast.Module
    assert astunparse.unparse(new_tree.tree) == "x = unicode(0)\n"

# Generated at 2022-06-25 22:46:18.210911
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    stringTypesTransformer = StringTypesTransformer()
    assert stringTypesTransformer is not None


# Generated at 2022-06-25 22:46:22.240208
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    import os

    full_path = os.path.realpath(__file__)
    path, filename = os.path.split(full_path)

    sys.path.append(path)
    from ..utils.tree import dump_tree


# Generated at 2022-06-25 22:46:25.341379
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import parse
    tree = parse('"test"')
    tree = StringTypesTransformer.transform(tree).tree

    assert str(tree) == 'u"test"'
    assert repr(tree) == "Module(body=[Expr(value=Str(s=u'test'))])"

# Generated at 2022-06-25 22:46:30.691660
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from astor.code_gen import to_source
    transformer = StringTypesTransformer(target=(2,7))
    with open(os.path.join(os.path.dirname(__file__), '..', '..',
                        'examples', '3.1', 'str_function.py')) as f:
        source = f.read()
    tree = ast.parse(source)
    transformer.visit(tree)
    print(to_source(tree))

# Generated at 2022-06-25 22:46:38.603492
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = ast.Str
    target_ast = ast.Module(
        body=[ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Str(s='string')
        )]
    )
    expected_ast = ast.Module(
        body=[ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Str(s='string')
        )]
    )
    expected_macros = []

    tr = StringTypesTransformer(target_ast)
    assert tr.tree == expected_ast
    assert tr.macros == expected_macros
    assert tr.tree_changed == False


# Generated at 2022-06-25 22:46:41.717649
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    result = StringTypesTransformer.transform(ast.parse("str(123)"))
    assert result.tree_changed
    transformed_tree_str = astor.to_source(result.tree)
    assert transformed_tree_str == "unicode(123)"

# Generated at 2022-06-25 22:46:45.419437
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_program

    from typed_ast import ast3 as ast
    from typed_ast import conversions

    tree = ast.parse('a = str(1)')
    expected_tree = ast.parse('a = unicode(1)')

    assert_program(StringTypesTransformer.transform, tree, expected_tree)

# Generated at 2022-06-25 22:46:54.178086
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import mypy.api
    from typing import List

    from typed_ast.ast3 import parse
    from typed_ast.ast3 import (PyCF_ONLY_AST, Str, Module)
    from typed_ast.ast3 import Leaf, Name
    import typed_astunparse as astunparse
    import textwrap

    program = textwrap.dedent('''
        def test(string: str) -> str:
            return string
    ''')

    tree = parse(program)

    node_types: List[str] = [type(node).__name__ for node in find(tree, ast.Name)]
    print(f"Before transformation: {node_types}")

    result = StringTypesTransformer().transform(tree)


# Generated at 2022-06-25 22:47:02.816654
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest

    class TestStringTypesTransformer(unittest.TestCase):
        def test_transform_string(self):
            import typed_ast.ast3 as ast

            tree = ast.parse('str()')
            result = StringTypesTransformer.transform(tree)
            self.assertEqual(result.tree.body[0].value.func.id, 'unicode')
            self.assertTrue(result.tree_changed)

        def test_transform_no_string(self):
            import typed_ast.ast3 as ast

            tree = ast.parse('foo()')
            result = StringTypesTransformer.transform(tree)
            self.assertEqual(result.tree.body[0].value.func.id, 'foo')
            self.assertFalse(result.tree_changed)

    unittest.main

# Generated at 2022-06-25 22:47:10.156543
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    transformer = StringTypesTransformer()
    tree = ast.parse('''
        def fn():
            a = str()

        def fn_2():
            a = str(b)

        def fn_3():
            a = str.upper('a')

        def fn_4():
            a = str
    ''')

    # When
    result = transformer.transform(tree)

    # Then
    assert result.tree_changed == True
    assert len(result.errors) == 0

# Generated at 2022-06-25 22:48:19.740606
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformer_results
    from ..parser import parse_ast
    from ..utils.tree import to_string

    # test replacements
    tree = parse_ast("""class Foo(str): pass""")
    result = StringTypesTransformer.transform(tree)
    assert_transformer_results(
        result,
        """
        class Foo(unicode): pass
        """,
        [],
        True,
    )

# Generated at 2022-06-25 22:48:21.214448
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    StringTypesTranformer_class = StringTypesTransformer() 

# Generated at 2022-06-25 22:48:22.098741
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import TransformationInput


# Generated at 2022-06-25 22:48:22.981306
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.target == (2,7)

# Generated at 2022-06-25 22:48:23.411567
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:48:28.300203
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import get_test_data
    from ..types import TransformationResult
    from typed_ast import ast3 as ast

    data_path = 'data/string_types_transformer.py'
    data = get_test_data(data_path, __file__)

    sut = StringTypesTransformer
    tree = ast.parse(data)
    result = sut.transform(tree)
    assert result == TransformationResult(tree, True, [])

# Generated at 2022-06-25 22:48:29.274261
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert 'str' in dir(ast)

# Generated at 2022-06-25 22:48:30.508456
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astroid
    assert isinstance(astroid.parse(r"a = str()"), astroid.Module)

# Generated at 2022-06-25 22:48:31.636629
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    '''transformer = StringTypesTransformer()
    transformer.transform(node)
    transformer.transform(node)'''

# Generated at 2022-06-25 22:48:42.995057
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing_utils import test_node_transform

    code = '''def f(x): return str(x)'''
    tree = test_node_transform(code, StringTypesTransformer)
    assert isinstance(tree, ast.AST)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert tree.body[0].name == 'f'
    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.Return)
    assert isinstance(tree.body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].value.func, ast.Name)

# Generated at 2022-06-25 22:51:10.858978
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:51:16.835492
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """py2to3/transformers/string_types.py
    
    This method is called by TestTransforming/test_transformer.py 
    via TestTransforming/latest_code.py
    """
    import ast
    from py2to3.main import get_tree

    # Test "transform" method of class StringTypesTransformer
    tree = get_tree('''
    def foo():
        return str('test')
    ''')
    
    updated = StringTypesTransformer.transform(tree)
    
    # find all instances of the "Name" node, check if id is unicode
    for node in find(tree, ast.Name):
        assert node.id == 'unicode'

# Generated at 2022-06-25 22:51:19.740812
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # ARRANGE #
    code = "a = str(b) "
    expected_code = "a = unicode(b) "
    tree = ast.parse(code)

    # ACT #
    result = StringTypesTransformer.transform(tree)

    # ASSERT #
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree_code[0] == expected_code

# Generated at 2022-06-25 22:51:21.968975
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """s = str(s)"""
    tree = ast.parse(source)
    transformed_src, _, _ = StringTypesTransformer.transform(tree)
    assert ast.dump(transformed_src) == ast.dump(ast.parse("""s = unicode(s)"""))

# Generated at 2022-06-25 22:51:27.691805
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3

    class Foo(object):
        pass
    class Bar(object):
        pass

    tree = typed_ast.ast3.parse("a = 'foo'")
    tree = StringTypesTransformer.transform(tree)[0]
    exec(compile(tree, filename="", mode="exec"))
    assert type(a) == unicode # nosec -- This is an expected result

    tree = typed_ast.ast3.parse("b = str('foo')")
    tree = StringTypesTransformer.transform(tree)[0]
    exec(compile(tree, filename="", mode="exec"))
    assert type(b) == unicode # nosec -- This is an expected result

# Generated at 2022-06-25 22:51:30.841223
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    text = '''\
    def test():
        print(str(1))'''
    tree = ast.parse(text)
    new_tree = StringTypesTransformer.transform(tree).tree
    assert astor.to_source(new_tree) == '''\
    def test():
        print(unicode(1))\
    '''
    return new_tree

# Generated at 2022-06-25 22:51:34.519979
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    result = StringTypesTransformer.transform(tree_2_7)
    assert result.tree_changed
    
    nodes = find(result.tree, ast.Name)
    assert len(nodes) == 1
    assert nodes[0].id == 'unicode'

# Generated at 2022-06-25 22:51:39.721736
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    #  Code example without type annotations
    code = '''
    def f():
        var = str()
    '''
    # Parse code and create AST
    tree = ast.parse(code)
    # Create an instance of a class that implements Transformer interface
    transformer = StringTypesTransformer()
    # Call Transformer.transform method to apply transformations to the AST
    transformed_tree, modified, messages = transformer.transform(tree)
    # Print the code of the modified AST
    print(astor.to_source(transformed_tree))

# Generated at 2022-06-25 22:51:42.002517
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("def foo(x : str) -> str: pass")
    tree = StringTypesTransformer.transform(tree)['tree']
    assert 'def foo(x : unicode) -> unicode:' in ast.dump(tree)



# Generated at 2022-06-25 22:51:42.899391
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)