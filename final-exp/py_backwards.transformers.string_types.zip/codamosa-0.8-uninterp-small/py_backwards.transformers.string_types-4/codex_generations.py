

# Generated at 2022-06-25 22:42:02.160892
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:42:05.456578
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_1 = StringTypesTransformer()
    string_types_transformer_2 = StringTypesTransformer()
    assert str(string_types_transformer_1) == '<StringTypesTransformer>'


# Generated at 2022-06-25 22:42:07.400120
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer.target == (2, 7)


# Generated at 2022-06-25 22:42:09.322816
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()



# Generated at 2022-06-25 22:42:11.153527
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert(string_types_transformer_0 != None)


# Generated at 2022-06-25 22:42:15.571201
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("tree = ast.parse('x = str(y)')")
    string_types_transformer = StringTypesTransformer()

    assert string_types_transformer.transform(tree)[0] == ast.parse("tree = ast.parse('x = unicode(y)')")

test_StringTypesTransformer()
test_case_0()

# Generated at 2022-06-25 22:42:16.770175
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()


# Generated at 2022-06-25 22:42:17.737819
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer is not None


# Generated at 2022-06-25 22:42:20.795392
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    dictionary = {'key': 'value'}
    string_types_transformer_1 = StringTypesTransformer()

    assert isinstance(string_types_transformer_1, StringTypesTransformer)


# Unit tests for transform() method of class StringTypesTransformer

# Generated at 2022-06-25 22:42:22.813333
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()

# Generated at 2022-06-25 22:42:29.875171
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    code_tree = ast.parse(
         """
         x = 'a string literal'
         s = str()
         """
     )

    transformed_tree, changed = StringTypesTransformer.transform(code_tree)

    assert changed == True

    # Output is the same
    assert ast.dump(transformed_tree) == ast.dump(code_tree)

    # Make sure the code is valid
    code_object = compile(transformed_tree,filename="<test>", mode="exec")

# Generated at 2022-06-25 22:42:35.536546
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tb = """
    def foo(bar):
        if isinstance(bar, str):
            print('baz')
    """
    expected = """
    def foo(bar):
        if isinstance(bar, unicode):
            print('baz')
    """
    tt = StringTypesTransformer()
    tt.target = (2, 7)
    assert tt.transform(tb) == expected



if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:42:39.607159
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    # import ast
    txt = "a = str(2)"
    tree = ast.parse(txt)
    r = StringTypesTransformer.transform(tree)
    print(astor.to_source(r.tree))
    assert r.tree_changed == True # no changes
    assert len(r.errors) == 0

if __name__ == "__main__":
    print(test_StringTypesTransformer.__doc__)
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:42:45.342237
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..parser import parse
    from ..serializer import to_source
    from .base import STDLIB_DIR

    test_file = os.path.join(STDLIB_DIR, 'os.py')
    with open(test_file) as f:
        test_data = f.read()

    ast_tree = parse(test_data)
    StringTypesTransformer.transform(ast_tree)
    assert to_source(ast_tree) is not None

# Generated at 2022-06-25 22:42:54.791846
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Test that class StringTypesTransformer behaves as expected:
      - Transform a simple string.
      - Transform the same string multiple times.
    """
    tree = ast.parse("str("+str("'")+"Hello World"+str("'")+")")
    expected_result = ast.parse("unicode("+str("'")+"Hello World"+str("'")+")")
    result = StringTypesTransformer.transform(tree)
    assert result.changes_made == 1
    assert result.tree.body[0] == expected_result.body[0]
    
    #Reset the counters.
    result = StringTypesTransformer.transform(tree)
    assert result.changes_made == 1
    assert result.tree.body[0] == expected_result.body[0]

# Generated at 2022-06-25 22:42:58.032142
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(
        ast.parse(
            '''
            a = "abc"
            if type(a) is str:
                print(a)
            '''
        )
    ).code == '''
            a = u"abc"
            if type(a) is unicode:
                print(a)
            '''

# Generated at 2022-06-25 22:43:07.290683
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # This test is only executed if the platform is Windows
    if platform.system() == 'Windows':
        python2_code = '''
            def test():
                s = str('test')
                t = unicode('test')
        '''
        python2_code_expected = '''
            def test():
                s = unicode('test')
                t = unicode('test')
        '''
        tree = ast.parse(python2_code)
        expected = ast.parse(python2_code_expected)

        result = StringTypesTransformer.transform(tree)

        # Check if StringTypesTransformer transformed the code correctly
        assert ast.dump(result.new_tree) == ast.dump(expected), \
            'StringTypesTransformer did not transform code correctly'

# Generated at 2022-06-25 22:43:08.702476
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

# Generated at 2022-06-25 22:43:13.336288
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.sample_code import class_with_string_types as sample_code
    from ..utils.python_source import PythonSource

    source = PythonSource(sample_code)
    node = source.tree
    transformer = StringTypesTransformer()
    result_node, is_changed = transformer.transform(node)

    assert is_changed
    assert 'unicode' in str(result_node)
    assert 'str' not in str(result_node)

# Generated at 2022-06-25 22:43:25.001352
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()

    module = ast.parse('''str')''', '<test>', 'exec')
    expected = ast.parse('''unicode')''', '<test>', 'exec')
    actual = t.transform(module)
    assert actual == expected, f'Expected {expected} actual {actual}'

    module = ast.parse('''from typing import str''', '<test>', 'exec')
    expected = ast.parse('''from typing import unicode''', '<test>', 'exec')
    actual = t.transform(module)
    assert actual == expected, f'Expected {expected} actual {actual}'
    
    module = ast.parse('''str("str")''', '<test>', 'exec')

# Generated at 2022-06-25 22:43:28.602655
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:43:29.112812
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-25 22:43:33.604794
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse('print(str(1))')
    new_tree = StringTypesTransformer().transform(tree)
    assert typed_ast.ast3.dump(new_tree) == "Module(body=[Expr(value=Print(values=[Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[])], nl=True))])"

# Generated at 2022-06-25 22:43:39.478408
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    import ast
    
    tree = ast.parse('str(x)')
    assert(tree.body[0].value.func.id == 'str')

    ast_transformer = StringTypesTransformer()
    tree = ast_transformer.transform(tree)
    assert(tree.body[0].value.func.id == 'unicode')

# Generated at 2022-06-25 22:43:48.345972
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    def test_single_assign_statement():
        tree = ast.parse('''a = str(3)''')
        result, tree_changed, messages = StringTypesTransformer.transform(tree)
        assert tree_changed
        assert result.body[0].value.func.id == 'int'

    def test_single_function_definition():

        tree = ast.parse('''def f(s):\n return s''')
        result, tree_changed, messages = StringTypesTransformer.transform(tree)
        assert not tree_changed

        tree = ast.parse('''def f(s):\n return str(s)''')
        result, tree_changed, messages = StringTypesTransformer.transform(tree)
        assert tree_changed

# Generated at 2022-06-25 22:43:49.769187
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTransformerTester
    BaseTransformerTester(StringTypesTransformer)

# Generated at 2022-06-25 22:43:50.384918
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:52.345418
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:55.046338
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = "s = str()"
    tree = astor.parse_file(code)
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == "s = unicode()"

# Generated at 2022-06-25 22:44:03.405734
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from .test_base import generate_test_string

    code = '''
a = str(b)
x = "hello"
c = "world"
y = b"hello"
d = u"world"
z = b"world"
'''
    expected = '''
a = unicode(b)
x = "hello"
c = "world"
y = b"hello"
d = u"world"
z = b"world"
'''

    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    print(astor.to_source(result.tree))
    assert astor.to_source(result.tree) == expected

# Generated at 2022-06-25 22:44:15.659783
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_input = """
        def func(arg : str) -> unicode:
            return arg + "str"
        """
    expected_ast = ast.parse(test_input, mode='exec')
    expected_ast = StringTypesTransformer.transform(expected_ast)
    expected_ast = expected_ast.tree

    test_ast = ast.parse(test_input, mode='exec')
    test_ast = StringTypesTransformer.transform(test_ast)
    test_ast = test_ast.tree
    assert test_ast == expected_ast

test_StringTypesTransformer()

# Generated at 2022-06-25 22:44:18.957032
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    tree = ast.parse("a = 'abc'")
    print(ast.dump(tree))
    transformer.transform(tree)
    print(ast.dump(tree))

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:44:22.465511
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  assert(str(ast.parse('str_var', mode='eval').body) == "Name(id='str_var', ctx=Load())")
  assert(str(StringTypesTransformer().transform(ast.parse('str_var', mode='eval').body)) == "Name(id='unicode', ctx=Load())")

# Generated at 2022-06-25 22:44:23.547114
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:24.616032
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # No test available, because this transformer is trivial
    pass
# ------------------------------------------------------------------------------

# Generated at 2022-06-25 22:44:25.938342
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import _ast

# Generated at 2022-06-25 22:44:28.678626
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
test = 'foo'
"""
    expected = """
test = u'foo'
"""
    transformed = StringTypesTransformer().transform(src)
    assert str(ast.parse(transformed)) == expected

# Generated at 2022-06-25 22:44:33.407254
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "s = 'abc'\nx = str()\ny = str"
    expected = "s = 'abc'\nx = unicode()\ny = unicode"
    tree = ast.parse(code)
    tree_changed, _ = StringTypesTransformer.transform(tree)
    assert str(tree) == expected
    assert tree_changed == True

# Generated at 2022-06-25 22:44:37.933683
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input = '''
        def foo(x: str):
            y = x + 'a'
    '''
    expect = '''
        def foo(x: unicode):
            y = x + u'a'
    '''
    tree = ast.parse(input)
    result = StringTypesTransformer.transform(tree)
    assert result.is_changed
    assert expect == astunparse.unparse(result.tree)

# Generated at 2022-06-25 22:44:45.227438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # The following snippet is python 2.7 compliant
    source = """\
x = str(23)
"""
    tree = ast.parse(source)
    new_tree, changed, issues = StringTypesTransformer.transform(tree)

    assert changed is True
    assert len(issues) == 0
    assert ast.dump(new_tree, include_attributes=False) == """\
Module(body=[
    Assign(targets=[
        Name(id='x', ctx=Store())
    ], value=Call(func=Name(id='unicode', ctx=Load()), args=[
        Num(n=23)
    ], keywords=[], starargs=None, kwargs=None))
])
"""

# Generated at 2022-06-25 22:45:03.898250
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    T = StringTypesTransformer

    code = """
        a = str('foobar')
    """
    tree = ast.parse(code)
    
    assert [node.id for node in find(
        T.transform(tree).tree, ast.Name)] == ['unicode']

    code = """
        b = dict(a='foo', b=str('bar'))
    """
    tree = ast.parse(code)
    
    assert [node.id for node in find(
        T.transform(tree).tree, ast.Name)] == ['dict', 'unicode']

# Generated at 2022-06-25 22:45:08.899105
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .util import generate_module_no_imports
    from ..utils.tree import to_src

    x = StringTypesTransformer.transform(generate_module_no_imports(
        '''
        z = str()
        '''
    ))

    assert to_src(x.tree) == '''
        def test_func():
            z = unicode()
        '''

# Generated at 2022-06-25 22:45:14.311262
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class MyString():
        """MyString docstring"""
        my_attribute = 'Test value'

        def __init__(self, attr1, attr2):
            self.attr1 = attr1
            self.attr2 = attr2

        def __repr__(self):
            return f'{self.attr1}, {self.attr2}, {self.my_attribute}'

    import astunparse
    import re


# Generated at 2022-06-25 22:45:16.048270
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("b = str('hello')")).tree == ast.parse("b = unicode('hello')")

# Generated at 2022-06-25 22:45:16.857449
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:45:24.792295
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as typed_ast
    from dtreeplacement import StringTypesTransformer

    class TestStringTypesTransformerMethods(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestStringTypesTransformerMethods, self).__init__(*args, **kwargs)
            self.maxDiff = None

        def test__transform(self):
            code = """
            def foo(x):
                return str(x)
            """
            tree = ast.parse(code)
            string_types_transformer = StringTypesTransformer()
            transformed_tree = string_types_transformer.transform(tree)

# Generated at 2022-06-25 22:45:27.932832
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer."""
    
    stringTypesTransformer = StringTypesTransformer(7,8,9)
    assert stringTypesTransformer.lowest_python_version == 7
    assert stringTypesTransformer.highest_python_version == 8
    assert stringTypesTransformer.line_number == 9

# Generated at 2022-06-25 22:45:29.445418
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("str(3)")) == TransformationResult(ast.parse("unicode(3)"), True, [])

# Generated at 2022-06-25 22:45:33.192853
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():    
    tree_orig1 = ast.parse("""
    def func():
        print(str(chr(32)))
    """)
    tree_orig2 = ast.parse("""
    def func():
        print(str(chr(32)))
    """)
    print('Original code:')
    print(ast.dump(tree_orig1))
    print('============================================================')
    print('Transformed code:')
    print(ast.dump(StringTypesTransformer.transform(tree_orig2)))

# Generated at 2022-06-25 22:45:38.805067
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  from ast_toolbox import ast_to_str
  import ast
  from .test_helpers import transform

  stmt_1 = ast.parse("""
  a = str()
  """).body[0]
  assert ast_to_str(stmt_1) == 'a = str()'

  res = transform(stmt_1, StringTypesTransformer)
  assert ast_to_str(res.tree) == 'a = unicode()'
  assert res.tree_changed == True

# Generated at 2022-06-25 22:46:09.783173
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "def func(): return str('foo')"

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    fixed_code = compile(tree, __file__, mode='exec')

    ns = {}
    exec(fixed_code, ns)

    assert ns['func'].__code__.co_argcount == 0



# Generated at 2022-06-25 22:46:17.741070
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    a = str(b)
    """ 

    tree = AnnotatedTree.from_yaml(code)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    assert result.tree_changed
    assert result.messages == []

# Generated at 2022-06-25 22:46:24.372728
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
assert isinstance('abc', str)
assert isinstance(b'abc', str)
assert not isinstance(u'abc', str)
'''

    expected = '''
assert isinstance('abc', unicode)
assert isinstance(b'abc', unicode)
assert not isinstance(u'abc', unicode)
'''

    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    actual = ast.dump(result.tree, include_attributes=False)
    assert actual == expected

# Generated at 2022-06-25 22:46:25.988671
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse("str = 'str'")
    _, changed = StringTypesTransformer.transform(t)
    assert changed

# Generated at 2022-06-25 22:46:34.926223
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    # Test1: Test case of str present
    tree_1 = ast.parse("""
    def my_method():
        x = []
        x.append(str(x))
        """, mode='exec')
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree_1)
    assert(new_tree.body[0].body[1].value.args[0].id == "unicode")

    # Test2: Test case of str not present
    tree_2 = ast.parse("""
    def my_method():
        x = []
        x.append(x)
        """, mode='exec')
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree_2)

# Generated at 2022-06-25 22:46:35.692353
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:46:40.867795
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """ Test that unicode (2.7) is replace with str (3.5).
    """
    tree = ast.parse("""
    class Test:
        def __init__(self):
            self.name = unicode()
    """)
    t = StringTypesTransformer()
    result = t.transform(tree)
    assert result == TransformationResult(ast.parse("""
    class Test:
        def __init__(self):
            self.name = str()
    """), True, [])

# Generated at 2022-06-25 22:46:46.210450
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import UnitTest
    from ..utils.codegen import to_source
    from .string_transformer import StringTransformer

    # Create code

# Generated at 2022-06-25 22:46:47.740510
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import run_transformer_test
    run_transformer_test(StringTypesTransformer)

# Generated at 2022-06-25 22:46:49.361283
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..testing import test_2to3


# Generated at 2022-06-25 22:47:58.986500
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    if 1:
        foo = str(1)
        bar = 'str'
        baz = str
    """
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    new_tree = ast.fix_missing_locations(new_tree)
    print(new_tree)
    exec(compile(new_tree, filename="<ast>", mode="exec"))


# For testing only
if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:48:01.640111
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""x = str(y)""")
    tree = StringTypesTransformer.transform(tree)
    assert tree.tree_changed
    assert tree.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:48:05.078750
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('"Hello World!"')
    assert ast.dump(tree) == "Expr(value=Str(s='Hello World!'))"

    result = StringTypesTransformer.transform(tree)
    assert ast.dump(result.tree) == "Expr(value=Str(s=u'Hello World!'))"

# Generated at 2022-06-25 22:48:07.745200
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = "foo"')
    tree = StringTypesTransformer().transform(tree)
    assert(compile(tree, '<ast>', 'exec'))
    assert(eval(compile(tree, '<ast>', 'exec')))

# Generated at 2022-06-25 22:48:15.541997
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_result_contains

    transformation = StringTypesTransformer.transform(ast.parse('"abc".upper()'))
    assert_result_contains(
        transformation, '"abc".upper()', 'u"abc".upper()')
    assert_result_contains(
        transformation, '"abc".upper()', "u'abc'.upper()")
    
    transformation = StringTypesTransformer.transform(ast.parse('a = str()'))
    assert_result_contains(
        transformation, 'a = str()', 'a = unicode()')

    transformation = StringTypesTransformer.transform(ast.parse('def f(a: str): pass'))
    assert_result_contains(
        transformation, 'def f(a: str): pass', 'def f(a: unicode): pass')

# Generated at 2022-06-25 22:48:21.339572
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name()
    node.id = 'str'
    node2 = ast.Name()
    node2.id = 'str'
    node3 = ast.Name()
    node3.id = 'str'
    node4 = ast.Name()
    node4.id = 'int'
    node5 = ast.Name()
    node5.id = 'str'
    myModule = ast.Module(body=[node, node2, node3, node4, node5])
    tree = ast.fix_missing_locations(myModule)

    result = StringTypesTransformer.transform(tree)
    assert node.id == 'unicode'

# Generated at 2022-06-25 22:48:28.971596
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    test = ast.parse('x = 1')
    result = StringTypesTransformer.transform(test)
    assert result.tree_changed == False
    test = ast.parse('x = "ABC"')
    result = StringTypesTransformer.transform(test)
    assert result.tree_changed == False
    test = ast.parse('x = str')
    result = StringTypesTransformer.transform(test)
    assert result.tree_changed == True
    assert astor.to_source(result.tree) == 'x = unicode'
    test = ast.parse('x = str()')
    result = StringTypesTransformer.transform(test)
    assert result.tree_changed == True
    assert astor.to_source(result.tree) == 'x = unicode()'

# Generated at 2022-06-25 22:48:39.672884
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # without default argument
    test_input = """
x = str('foo')
y = 'bar'
"""
    expected_output = """
x = unicode('foo')
y = 'bar'
"""
    test_tree = ast.parse(test_input)
    updated_tree, transformer, _ = StringTypesTransformer.transform(test_tree)
    assert ast.unparse(updated_tree) == expected_output


if __name__ == "__main__":
    import os
    import sys
    # Set top level directory as base path so we can import our transformer 
    # module
    sys.path.append(os.path.abspath('../../'))
    from transformers import StringTypesTransformer
    # Run test on StringTypesTransformer
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:48:46.602056
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import path
    import astor

    base_path = path.Path(__file__).parent / './test_files/string_type_transformer_test'

    source_code = (base_path / './version_2_7.py').read_text('utf-8')
    expected_code = (base_path / './expected.py').read_text('utf-8')

    tree = astor.parse_file(source_code)
    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert astor.to_source(result.tree) == expected_code

    assert StringTypesTransformer.transform(tree).tree_changed

# Generated at 2022-06-25 22:48:53.110681
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert "str" in astor.to_source(
        ast.parse('''str'''))
    assert "str" not in astor.to_source(
        StringTypesTransformer.transform(ast.parse('''str''')).tree)
    assert "str" not in astor.to_source(
        StringTypesTransformer.transform(ast.parse('''str(1)''')).tree)
    assert "str" not in astor.to_source(
        StringTypesTransformer.transform(ast.parse('''x.str''')).tree)
    assert "str" not in astor.to_source(
        StringTypesTransformer.transform(ast.parse('''x.str()''')).tree)
    asse

# Generated at 2022-06-25 22:51:33.212081
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import inspect
    import astor
    from .base import BaseTransformer

    # TransformationResult = collections.namedtuple('TransformationResult', ['tree', 'tree_changed', 'messages'])

    class_ = StringTypesTransformer
    src = inspect.getsource(class_)

    # Test for class existence
    assert class_ is not None

    # Test for parent class
    assert issubclass(class_, BaseTransformer)

    # Test for class name
    assert class_.__name__ == class_.__qualname__ == 'StringTypesTransformer'

    # Test for class docstring
    assert class_.__doc__ == 'Replaces `str` with `unicode`.'

    # Test for module
    assert class_.__module__ == __name__

    # Test for constructor existence

# Generated at 2022-06-25 22:51:40.533646
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from astor.code_gen import to_source
    from .unicode_literals import UnicodeLiteralsTransformer

    source = '''"a"b"c"'d'u"e"f"g"'h'f'i"j"u'k'l"m"'n'o'"'''
    
    # Fisrt we make sure this test case is not affected by another transformers
    # (other tests will take care of that)
    tree = ast.parse(source)
    assert to_source(tree) == source
    
    # Now we check that the actual transformation is being made
    annotated_tree = UnicodeLiteralsTransformer.annotate(tree)
    annotated_tree = StringTypesTransformer.transform(annotated_tree).tree
    annotated_source = to_source(annotated_tree)
    assert annot

# Generated at 2022-06-25 22:51:41.156935
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:51:43.457476
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
foo = str('bar')
''')

    new_tree = StringTypesTransformer.transform(tree)
    assert new_tree.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-25 22:51:51.328984
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test if StringTypesTransformer successfully replaces all
    str declarations with unicode. 
    
    """

    # Create a sample module

# Generated at 2022-06-25 22:51:52.228883
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:51:53.554148
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer.target == (2, 7)


# Generated at 2022-06-25 22:52:02.345477
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test parameters
    tree = ast.fix_missing_locations(ast.parse('''
    def foo(bar):
        str(bar)
    '''))
    # Perform test
    out = StringTypesTransformer.transform(tree).tree
    # Check results
    assert len(find(out, ast.Name)) == 1
    assert find(out, ast.Name)[0].id == 'unicode'
    assert len(find(out, ast.Name)) == 1