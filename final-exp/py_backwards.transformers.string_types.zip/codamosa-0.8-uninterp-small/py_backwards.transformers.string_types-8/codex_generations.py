

# Generated at 2022-06-25 22:41:53.959225
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform([]) == ([], False, [])

# Generated at 2022-06-25 22:41:55.792584
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Constructor does not have any parameters or arguments; but would have
    # been coded as follows:
    string_types_transformer_0 = StringTypesTransformer()
    string_types_transformer_0.transform()

# Generated at 2022-06-25 22:41:56.726500
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:10.306684
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with pytest.raises(TypeError):
        string_types_transformer_0 = StringTypesTransformer("1")
    with pytest.raises(TypeError):
        string_types_transformer_1 = StringTypesTransformer(1)
    with pytest.raises(TypeError):
        string_types_transformer_2 = StringTypesTransformer(False)
    with pytest.raises(TypeError):
        string_types_transformer_3 = StringTypesTransformer("")
    with pytest.raises(TypeError):
        string_types_transformer_4 = StringTypesTransformer(2.3)
    with pytest.raises(TypeError):
        string_types_transformer_5 = StringTypesTransformer({"key": "value"})

# Generated at 2022-06-25 22:42:17.938958
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTransformer
    from ..types import TransformationResult
    # constructor should return an instance of StringTypesTransformer
    assert type(StringTypesTransformer()) == StringTypesTransformer
    # constructor should return an instance of BaseTransformer
    assert isinstance(StringTypesTransformer(), BaseTransformer)
    # constructor should return an instance of ast.AST
    assert isinstance(StringTypesTransformer().tree, ast.AST)
    # constructor should return an instance of TransformationResult
    assert isinstance(StringTypesTransformer().transform(ast.parse("")), TransformationResult)
    assert type(StringTypesTransformer().transform(ast.parse(""))) == TransformationResult

# Unit tests for method transform of class StringTypesTransformer.
# The method should return a TransformationResult instance.

# Generated at 2022-06-25 22:42:19.104077
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()



# Generated at 2022-06-25 22:42:20.571056
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Run test
    obj = StringTypesTransformer()
    # Verify outcome
    assert obj is not None

# Generated at 2022-06-25 22:42:22.431982
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer(2, 7)


# Generated at 2022-06-25 22:42:23.685184
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.target == (2, 7)


# Generated at 2022-06-25 22:42:25.267159
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()



# Generated at 2022-06-25 22:42:32.079935
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    tree = astor.parse_file('test_files/StringTypesTransformer/file.py')

    str_types_trans = StringTypesTransformer()
    str_types_trans.transform(tree)
    a = astor.to_source(tree)
    with open('test_files/StringTypesTransformer/file.py', 'r') as f:
        b = f.read()
    assert a == b

# Generated at 2022-06-25 22:42:32.677379
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'


# Generated at 2022-06-25 22:42:34.342079
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('mystring = str("")')
    new_tree = StringTypesTransformer.transform(tree).tree
    assert new_tree.body[0].value.func.id == 'unicode'


# Generated at 2022-06-25 22:42:41.043617
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    my_visitor = ast.NodeVisitor()
    tree_changed = False
    for node in find(ast.parse("""
hello = str * 2
hello_bytes = hello.encode()
"""), ast.Name):
        if node.id == 'str':
            node.id = 'unicode'
            tree_changed = True
    # The tree is mutated in-place.
    assert(tree_changed)
    my_visitor.visit(ast.parse("""
hello = unicode * 2
hello_bytes = hello.encode()
"""))

# Generated at 2022-06-25 22:42:49.536652
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "def foo(a: str) -> str: return a"
    res = StringTypesTransformer.transform(ast.parse(code))
    assert res.tree_changed == True and res.errors == []
    assert ast.dump(res.tree) == 'Module(body=[FunctionDef(name=\'foo\', args=arguments(args=[arg(arg=\'a\', annotation=Name(id=\'unicode\', ctx=Load()))], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Name(id=\'a\', ctx=Load()))], decorator_list=[], returns=Name(id=\'unicode\', ctx=Load()))])'

# Generated at 2022-06-25 22:42:58.495014
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Test with a simple python file
    # ==============================
    test_file = """my_string = 'text'"""
    tree = ast.parse(test_file)
    assert ast.dump(tree) == ast.dump(StringTypesTransformer.transform(tree).tree)

    # Test with a python file using both types
    # ========================================
    test_file = """my_string = 'text'
    my_unicode = u'text'"""
    tree = ast.parse(test_file)
    assert ast.dump(tree) == ast.dump(StringTypesTransformer.transform(tree).tree)

    # Test with a python file using both types like var names
    # ========================================

# Generated at 2022-06-25 22:43:07.994472
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_str_string = ast.parse('x = "123"', mode='eval').body
    assert isinstance(test_str_string, ast.Expr)
    assert isinstance(test_str_string.value, ast.Str)

    transformer = StringTypesTransformer()

    # Should replace str with unicode
    str_result = transformer.transform(test_str_string)
    assert isinstance(str_result, TransformationResult)
    assert hasattr(str_result.transformed, ast.Str)

    # Should not replace unicode with str
    test_unicode_string = ast.parse('x = u"123"', mode='eval').body
    assert isinstance(test_unicode_string, ast.Expr)
    assert isinstance(test_unicode_string.value, ast.Str)

    unicode_result

# Generated at 2022-06-25 22:43:13.414682
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Create instance of class StringTypesTransformer
    string_types_transformer = StringTypesTransformer()

    # Create AST for "str"
    string_node = ast.Name(id='str', ctx=ast.Load())

    # Run renaming
    result = string_types_transformer.run(string_node)

    # Check if renaming was successful
    assert result.tree.id == 'unicode'
    assert result.transformation_applied == True
    assert result.transformation_errors == []

# Generated at 2022-06-25 22:43:21.970978
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test if the correct tree is returned when a str is found
    tree = ast.parse("str=''")
    result = StringTypesTransformer().transform(tree)

    assert result.tree.body[0].value.id == 'unicode'
    assert result.tree_changed == True

    # test if the correct tree is returned when no str is found
    tree = ast.parse("unicode=''")
    result = StringTypesTransformer().transform(tree)

    assert result.tree_changed == False

# Generated at 2022-06-25 22:43:30.809426
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  src = """
        def function():
            #example of str
            variable = str()
            variable2 = 'some string'
            variable3 = variable2.replace('e','E')
            variable4 = variable2.replace('e','E').split(' ')
            variable5 = variable[0]
            variable6 = 'abc' * 10
            variable6.upper()
            variable6.startswith('a')
            variable7 = variable + variable2
            variable8 = variable2 + variable
            return variable
        """

# Generated at 2022-06-25 22:43:38.401623
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    string = '''
    def foo(x: str) -> str:
        return str(x)
    '''

    tree = ast.parse(string)
    StringTypesTransformer.transform(tree)

    assert string != ast.dump(tree)

# Generated at 2022-06-25 22:43:45.345426
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Verify behavior is not changed for targets less than 2.7
    assert StringTypesTransformer.transform(ast.parse('str', '<test>', 'eval'), target=(2, 6)) == \
                      TransformationResult(ast.parse('str', '<test>', 'eval'), tree_changed=False, warnings=[])
    # Verify str is replaced with unicode for target 2.7
    assert StringTypesTransformer.transform(ast.parse('str', '<test>', 'eval'), target=(2, 7)) == \
                      TransformationResult(ast.parse('unicode', '<test>', 'eval'), tree_changed=True, warnings=[])

# Generated at 2022-06-25 22:43:48.156244
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert transform('str') == 'unicode'

    code = """
    s = "test"
    """.strip()
    expected_code = """
    s = "test"
    """.strip()
    assert transform(code) == expected_code

# Generated at 2022-06-25 22:43:49.002765
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:53.553113
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    
    src = "str('string')"
    src = source_to_unicode(src)
    tree = source_to_ast(src)
    tr = StringTypesTransformer()
    tr.transform(tree)

# Generated at 2022-06-25 22:44:00.249280
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import run_python_source_code_test
    from ..utils.testing import run_python_ast_test

    result = run_python_source_code_test(__file__, 'StringTypesTransformer')
    assert result.tree_changed == True
    # We could implement a source-code test here to assert that 
    # the transformation really took place. However, this would be 
    # unnecessarily repetitive at the moment, since we already 
    # tested the same thing in NodeTransformer.

    result = run_python_ast_test(__file__, 'StringTypesTransformer')
    assert result.tree_changed == True
    assert result.warnings == []

# Generated at 2022-06-25 22:44:08.269603
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests for `StringTypesTransformer`. 

    """
    from ..utils.test import transform_test

    tree = ast.parse("""
a = str(x)
b = unicode(y)
c = str
d = unicode
    """)
    new_tree = transform_test(StringTypesTransformer, tree)
    assert new_tree.body[0].value.func.id == 'unicode'
    assert new_tree.body[1].value.func.id == 'unicode'
    assert new_tree.body[2].value.id == 'unicode'
    assert new_tree.body[3].value.id == 'unicode'

# Generated at 2022-06-25 22:44:12.137479
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def f(x: str):
            return x
    """
    tree = ast.parse(code)
    print(ast.dump(tree))
    transformer = StringTypesTransformer()
    print(ast.dump(transformer.transform(tree)))

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:44:16.595780
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
	testfunc = """
	def func():
		return str("hello")
	"""
	testtree = ast.parse(testfunc)
	transformed_tree = StringTypesTransformer.transform(testtree)
	assert transformed_tree.tree.body[0].body.value.func.id == 'unicode'
	assert not transformed_tree.changed

# Integration test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:20.761893
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from .ast_builder import build_ast

    # Test for constructor of class StringTypesTransformer
    tree = build_ast('''
    x = str('abc')
    ''')

    StringTypesTransformer.transform(tree)
    expected = build_ast('''
    x = unicode('abc')
    ''')

    assert str(expected) == str(tree)

# Generated at 2022-06-25 22:44:31.591720
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer(2, 7)
    code = """
            def test():
                str(2)
            """
    tree = ast.parse(code)
    result = transformer.transform(tree)
    module = ast.parse(result.code)
    assert any(find(module, ast.Name)) == True
    assert any(find(module, ast.Name, id='unicode')) == True

# Generated at 2022-06-25 22:44:34.621166
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree_to_test = ast.parse("a = str(r'Hello')")
    transformer = StringTypesTransformer()
    result, changed = transformer.transform(tree_to_test)
    assert changed == True
    assert result == ast.parse("a = unicode(r'Hello')")

# Generated at 2022-06-25 22:44:38.201484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast_tree = ast.parse(
        """
        "test"
        """
    )
    tree = StringTypesTransformer.transform(ast_tree)
    code = compile(tree.ast, '', 'exec')

    assert eval(code) == "test"
    assert tree.tree_changed == True
    assert tree.dependencies == []

# Generated at 2022-06-25 22:44:42.185188
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    source = 'def foo(a: str):\n    return a'
    tree = typed_ast.ast3.parse(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert new_tree.tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-25 22:44:49.796484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import string_types
    from ..utils.tree import ast2str

    str_code = '''
        a = str()
        b = str(1)
        c = str(a, b)
    '''

    # Transformed code is expected to be
    # a = unicode()
    # b = unicode(1)
    # c = unicode(a, b)
    expected = '''
        a = unicode()
        b = unicode(1)
        c = unicode(a, b)
    '''

    # Compile code to AST
    str_tree = ast.parse(str_code)

    # Transform AST
    transformer = StringTypesTransformer()
    result = transformer.transform(str_tree)

    # Check tree has been transformed

# Generated at 2022-06-25 22:44:52.343294
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print('Testing class StringTypesTransformer')
    tree = ast.parse('x = str(1); y = str(2)')

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True

# Generated at 2022-06-25 22:44:53.864922
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    instance_transformer = StringTypesTransformer()
    assert instance_transformer is not None

# Generated at 2022-06-25 22:44:58.249072
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program_code = '''
foo = "hello, my dear str"
bar = str(foo)
'''

    expected = '''
foo = "hello, my dear str"
bar = unicode(foo)
'''

    tree = ast.parse(program_code)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert astor.to_source(new_tree) == expected

# Generated at 2022-06-25 22:45:05.121030
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    # Looks like this is the only way to create an ast.Name node with
    # a string in Python 2.7.
    tree = ast.parse("str")
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert isinstance(result.tree, ast.Module)
    assert len(result.tree.body) == 1
    assert isinstance(result.tree.body[0], ast.Expr)
    assert isinstance(result.tree.body[0].value, ast.Name)
    assert result.tree.body[0].value.id == 'unicode'
    assert result.errors == []

# Generated at 2022-06-25 22:45:10.764245
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform('import os') == (
        [], [], 'import os'
    )

    assert StringTypesTransformer.transform('def foo():\n    str()') == (
        [], [], 'def foo():\n    unicode()'
    )

    assert StringTypesTransformer.transform('str(foo)').code.strip() == (
        'unicode(foo)'
    )



# Generated at 2022-06-25 22:45:23.102548
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-25 22:45:24.640092
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .transformer_unit_test import TransformerUnitTest
    TransformerUnitTest(StringTypesTransformer).test()

# Generated at 2022-06-25 22:45:27.514862
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_node_transformed

    assert_node_transformed(
        StringTypesTransformer,
        """
        def foo():
            return str()
        """, """
        def foo():
            return unicode()
        """
    )

# Generated at 2022-06-25 22:45:30.833730
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "def f(): return str()"
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)
    assert transformer.tree_changed == True
    assert transformer.num_errors == 0
    assert astor.to_source(new_tree.tree) == "def f(): return unicode()"

# Generated at 2022-06-25 22:45:40.219846
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast import parse
    from ..utils.dump import dump_ast
    from ..utils.json_loader import dump_json_ast
    from ..utils import parse_python
    from ..utils.compare_ast import compare_ast

    source = '''
s = str()
    
'''

    correct_tree = parse('''
s = unicode()
    
''')

    tree = parse_python(source)

    result = StringTypesTransformer.transform(tree)

    # Test AST Tree
    assert compare_ast(result.tree, correct_tree, True)
    assert result.tree is not tree

    # Test Message
    assert result.messages == []

    # Test JSON
    correct_json = dump_json_ast(tree)
    result_json = dump_json_ast(result.tree)

    assert correct

# Generated at 2022-06-25 22:45:42.329646
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str')).tree_changed

# Generated at 2022-06-25 22:45:50.717313
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests for StringTypesTransformer.
    """
    from .test_data import STRING_TYPES
    from ..utils.recompiler import recompile_code
    from ..utils.visitor import dump_ast

    new_tree = StringTypesTransformer.transform(STRING_TYPES)
    assert not new_tree.tree_changed
    new_code = recompile_code(STRING_TYPES)
    assert new_code == 'value = unicode("string")'
    assert new_tree.trees == []
    assert dump_ast(new_tree.tree) == dump_ast(STRING_TYPES)

# Generated at 2022-06-25 22:45:59.795440
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    program_code = "print(str(''))"
    tree = ast.parse(program_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert astor.to_source(result.new_tree) == "print(unicode(''))"
    
    program_code = "print('hello')"
    tree = ast.parse(program_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == False
    assert astor.to_source(result.new_tree) == program_code

# Generated at 2022-06-25 22:46:09.008692
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for class `StringTypesTransformer`.

    """
    code = '''
        a = str(b)
        c = str.isupper("HELLO")
    '''
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree).tree
    res = compile(tree, '<string>', 'exec')
    res_vars = {}
    exec(res, None, res_vars)
    assert res_vars['a'] == res_vars['b']
    assert res_vars['c'] is True

    code = '''
        a = str(b)
        c = str.isupper("HELLO")
    '''
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree).tree

# Generated at 2022-06-25 22:46:13.346793
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open("samples/str_i_file.py", "r") as f:
        tree = ast.parse(f.read())
    assert(StringTypesTransformer.transform(tree).tree_changed)
    with open("outputs/str_i_file_output.py", "r") as f:
        output = ast.parse(f.read())
    assert(output == StringTypesTransformer.transform(tree).tree)

# Generated at 2022-06-25 22:46:42.973627
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from tests.test_transformer import run_test

    code = """
            variable = str(1)
            """

    expected_code = """
            variable = unicode(1)
            """

    run_test(code, expected_code, StringTypesTransformer)

# Generated at 2022-06-25 22:46:50.534451
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest

    class StringTypesTransformerTest(unittest.TestCase):
        def test_string(self):
            tree_to_transform = ast.parse("str(x)")
            expected_transformed_tree = ast.parse("unicode(x)")
            transformer = StringTypesTransformer()
            actual_transformed_tree = transformer.transform(tree_to_transform)
            self.assertEqual(
                ast.dump(actual_transformed_tree.tree),
                ast.dump(expected_transformed_tree)
            )
            self.assertTrue(actual_transformed_tree.tree_changed)
            self.assertEqual(actual_transformed_tree.warnings, [])
    
    unittest.main()

# Generated at 2022-06-25 22:46:52.852505
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    stringtypes_transform = StringTypesTransformer()
    assert stringtypes_transform.transform(ast.parse('"Hello"')) == TransformationResult(
            ast.parse('u"Hello"'), True, [])

# Generated at 2022-06-25 22:46:56.864103
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    aast = ast.parse('foo = str(42)')
    t = StringTypesTransformer()
    taast, changed, info = t.transform(aast)
    assert changed
    assert(
        astunparse.unparse(taast) == 
        'foo = unicode(42)'
    )



# Generated at 2022-06-25 22:47:05.493729
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.target == (2, 7)
    assert StringTypesTransformer.transform(ast.parse("str(3)")) == \
        TransformationResult(ast.parse("unicode(3)"), True, [])
    assert StringTypesTransformer.transform(ast.parse("str()+str()")) == \
        TransformationResult(ast.parse("unicode()+unicode()"), True, [])
    assert StringTypesTransformer.transform(ast.parse("""
    print (str('New', 'York'))
    """)) == TransformationResult(ast.parse("print (unicode('New', 'York'))"), True, [])

# Generated at 2022-06-25 22:47:06.550889
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print(__name__)
    exit()

# unit test for 

# Generated at 2022-06-25 22:47:07.085080
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:47:14.686853
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..tests import run_transformer_test

    # Single name node. 
    result = run_transformer_test(StringTypesTransformer, 'str')
    assert result == 'unicode'

    # Two name nodes. 
    result = run_transformer_test(StringTypesTransformer, 'str, unicode')
    assert result == 'unicode, unicode'

    # Nested name nodes. 
    result = run_transformer_test(StringTypesTransformer, 'str(unicode)')
    assert result == 'unicode(unicode)'

    # Name in comment
    result = run_transformer_test(StringTypesTransformer, '# str')
    assert result == '# unicode'

    # Check that different nodes are left unchanged

# Generated at 2022-06-25 22:47:20.022722
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.fixtures import get_test_case_ast
    from ..utils.tree import print_tree

    ttree = get_test_case_ast('2.7', 'string_types.py')
    ttree2 = get_test_case_ast('2.7', 'string_types_result.py')
    ttf = StringTypesTransformer()

    result, tree_changed = ttf.transform(ttree)
    if tree_changed:
        print_tree(result)

    assert result == ttree2

# Generated at 2022-06-25 22:47:27.131775
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert issubclass(StringTypesTransformer, BaseTransformer)
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.target == (2, 7)

    assert StringTypesTransformer.transform(ast.parse('s = str()'))
    assert StringTypesTransformer.transform(ast.parse('s = str("hello")')) == \
        TransformationResult(ast.parse('s = unicode()'), True, [])
    assert StringTypesTransformer.transform(ast.parse('s = str("hello")')) == \
        TransformationResult(ast.parse('s = unicode()'), True, [])

# Generated at 2022-06-25 22:48:34.549585
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "str('1')"
    expected_code = "unicode('1')"
    module = ast.parse(code)
    tree = StringTypesTransformer.transform(module)
    assert str(tree.tree) == expected_code

# Generated at 2022-06-25 22:48:46.317289
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..utils.ast_factory import ast_factory

    # unused_import = 1
    unused_import = ast.Assign(targets=[ast.Name(id='unused_import', ctx=ast.Store())],
                               value=ast.Num(n=1),
                               type_comment=None)
    # str = 1
    str_assign = ast.Assign(targets=[ast.Name(id='str', ctx=ast.Store())],
                            value=ast.Num(n=1),
                            type_comment=None)
    # print(str)
    str_print = ast.Print(dest=None, values=[ast.Name(id='str', ctx=ast.Load())], nl=True)
    # 
   

# Generated at 2022-06-25 22:48:49.815037
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
a = 'abc'
b = str
str = 123
"""

    expected_result = """
a = u'abc'
b = unicode
unicode = 123
"""

    tree = ast.parse(src)
    StringTypesTransformer.run_test(tree, expected_result)

# Generated at 2022-06-25 22:48:53.628759
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse(dedent('''\
        def f():
            x = str()
        '''))) == TransformationResult(ast.parse(dedent('''\
        def f():
            x = unicode()
        ''')), True, [])


# Generated at 2022-06-25 22:48:57.344607
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(
        """
        def main():
            a = str('a')
        """
    )
    exp_tree = ast.parse(
        """
        def main():
            a = unicode('a')
        """
    )
    trans = StringTypesTransformer()
    tree = trans.transform(tree)
    assert ast.dump(tree) == ast.dump(exp_tree)

# Generated at 2022-06-25 22:49:06.035620
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("a = str(1)")) == TransformationResult(ast.parse("a = unicode(1)"), True, [])
    assert StringTypesTransformer.transform(ast.parse("a = str(1)"), {'unicode': 'int'}) == TransformationResult(ast.parse("a = int(1)"), True, [])
    assert StringTypesTransformer.transform(ast.parse("a = str(1)"), {'str': 'int'}) == TransformationResult(ast.parse("a = int(1)"), True, [])

# Generated at 2022-06-25 22:49:12.234418
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..testing_utils import make_test_tree
    import sys

    tree = make_test_tree(
        """
        def foo(a: str) -> str:
            b = a.join(('a', 'b'))
            return b.lower()
        """
    )

    from .base import transform_text
    new_tree = transform_text(tree, 2, 7, StringTypesTransformer)

    assert new_tree.body[0].args[0].annotation.id == 'unicode'
    assert new_tree.body[0].returns.id == 'unicode'

    assert new_tree.body[0].body[0].value.func.value.func.id == 'u'

# Generated at 2022-06-25 22:49:12.787160
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert False

# Generated at 2022-06-25 22:49:19.842342
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1 - No transformation needed
    code = "a = 2"
    tree = ast.parse(code)
    xformed = StringTypesTransformer.transform(tree)
    assert xformed.tree_changed == False

    # Test 2 - Simple case
    code = "def foo(a: str) -> str:\n  return a"
    tree = ast.parse(code)
    xformed = StringTypesTransformer.transform(tree)
    assert xformed.tree_changed == True
    assert isinstance(xformed.warnings[0], TypeWarning)
    assert isinstance(xformed.warnings[0].node, ast.FunctionDef)
    assert xformed.warnings[0].node.name == 'foo'
    assert xformed.warnings[0].node.args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-25 22:49:20.624861
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert isinstance(StringTypesTransformer(), BaseTransformer)


# Generated at 2022-06-25 22:51:53.019939
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    t = StringTypesTransformer()
    r = t.transform(typed_ast.ast3.parse("a='b'"))
    assert r.transformed_tree.body[0].value.s == 'b'
    assert r.transformed_tree.body[0].value.__class__.__name__ == 'Unicode'