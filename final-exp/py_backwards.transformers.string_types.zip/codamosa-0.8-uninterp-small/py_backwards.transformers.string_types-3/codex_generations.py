

# Generated at 2022-06-25 22:41:56.809641
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    string_types_transformer_0 = StringTypesTransformer()
    assert string_types_transformer_0 is not None


# Generated at 2022-06-25 22:42:03.215423
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree_0 = ast.parse('x = "he"')
    tree_1 = StringTypesTransformer.transform(tree_0)
    assert(len(tree_1.to_apply) == 4)

# Generated at 2022-06-25 22:42:06.063164
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast_0 = ast.parse("x = str()")
    assert ast.dump(ast_0) == ast.dump(StringTypesTransformer.transform(ast_0)[0])


# Generated at 2022-06-25 22:42:10.035314
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = "a = str(1)"
    expected = "a = unicode(1)"
    tree = ast.parse(source)
    tree_changed = StringTypesTransformer.transform(tree)
    assert expected == astor.to_source(tree_changed)


# Generated at 2022-06-25 22:42:10.893264
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_0 = StringTypesTransformer()

# Generated at 2022-06-25 22:42:12.833922
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    string_types_transformer_0 = StringTypesTransformer.transform(ast.parse('str(1)'))


# Generated at 2022-06-25 22:42:14.917939
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer.target == (2, 7)


# Generated at 2022-06-25 22:42:16.717276
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("str('foo')"))[0] == ast.parse("str('foo')")

# Generated at 2022-06-25 22:42:26.420089
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Try to create an instance of the above class. Try pass an incorrect value to its constructor.
    # Should raise an exception
    exception_raised = False
    try:
        string_types_transformer = StringTypesTransformer(None)
    except Exception:
        exception_raised = True
    assert exception_raised == True
    #end try
    
    # Try to create an instance of the above class. Try pass an incorrect value to its constructor.
    # Should raise an exception
    exception_raised = False
    try:
        string_types_transformer = StringTypesTransformer('')
    except Exception:
        exception_raised = True
    assert exception_raised == True
    #end try
    
    exception_raised = False

# Generated at 2022-06-25 22:42:28.650507
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with pytest.raises(TypeError):
        StringTypesTransformer(target=1)
    assert StringTypesTransformer().target == (2, 7)

# Generated at 2022-06-25 22:42:32.253349
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.target == (2, 7)
 

# Generated at 2022-06-25 22:42:32.575363
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:42:40.048582
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert isinstance(string_types_transformer_0, StringTypesTransformer)
# Test for method transform of class StringTypesTransformer

# Generated at 2022-06-25 22:42:41.719962
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer is not None

# Generated at 2022-06-25 22:42:42.628385
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:42:43.583330
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_case_0()

# Generated at 2022-06-25 22:42:45.068896
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:54.501092
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_1 = StringTypesTransformer()
    tree = ast.parse(textwrap.dedent('''
    import sys
    from six import binary_type

    as_bytes = binary_type
    as_text = str
    to_bytes = binary_type
    to_text = str
    b = str
    def f():
        return str
    '''))
    transformation_result_1 = string_types_transformer_1.transform(tree)
    tree = transformation_result_1.tree
    assert tree is not None

    assert transformation_result_1 is not None
    assert transformation_result_1.tree is not None
    assert transformation_result_1.affected_module_names is not None
    assert transformation_result_1.affected_module_names == []

# Generated at 2022-06-25 22:42:56.652305
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert {'__module__': 'py2to3.transformer.string_types', '__qualname__': 'StringTypesTransformer', 'target': (2, 7)} == string_types_transformer_0.__dict__


# Generated at 2022-06-25 22:42:58.453229
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:43:02.656234
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = parse('str')
    StringTypesTransformer.transform(tree)

# Generated at 2022-06-25 22:43:07.691631
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str("abc")')
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='abc')], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-25 22:43:18.167940
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_templates import case_1, case_2, case_3, case_4, case_5, case_6

    expected_tree_1 = case_1()
    tree_1 = case_1()
    result_1 = StringTypesTransformer.transform(tree_1)
    assert result_1.tree == expected_tree_1
    assert result_1.tree_changed == False

    expected_tree_2 = case_2()
    tree_2 = case_2()
    result_2 = StringTypesTransformer.transform(tree_2)
    assert result_2.tree == expected_tree_2
    assert result_2.tree_changed == True

    expected_tree_3 = case_3()
    tree_3 = case_3()

# Generated at 2022-06-25 22:43:19.737209
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(None)


# Generated at 2022-06-25 22:43:21.720192
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_nodes
    from .base import BaseNodeTest


# Generated at 2022-06-25 22:43:29.657209
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import parse
    from ..utils.source import generate_code
    from ..utils.ast import compare_asts

    source = 'def test_func():\n  a = str()'
    expected_ast = parse(source)
    expected_ast.body[0].body[0].value.func.id = 'unicode'
    
    tree = parse(source)
    replacer = StringTypesTransformer()
    tree, changed = replacer.transform(tree)
    assert changed == True
    generated_code = generate_code(tree)
    expected_code = generate_code(expected_ast)
    assert generated_code == expected_code
    assert compare_asts(tree, expected_ast)

# Generated at 2022-06-25 22:43:33.315623
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "def foo(x: str): return x != type(x)"
    t = ast.parse(code)
    new_t = StringTypesTransformer.transform(t)
    new_code = compile(new_t.tree, '<test>', 'exec')
    c = {}
    e = {}
    exec(new_code, c, e)

# Generated at 2022-06-25 22:43:34.667505
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:45.109916
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .utils import assert_transformation
    from typed_ast import ast3 as ast

    assert_transformation(
        StringTypesTransformer,
        before="""
            import datetime

            foo = str()
            bar = 'hello world'
        """,
        after = """
            import datetime

            foo = unicode()
            bar = u'hello world'
        """,
        # No module-level changes
        module_level = False)

    assert_transformation(
        StringTypesTransformer,
        before="""
            import datetime

            foo = str()
            bar = 'hello world'
        """,
        after = """
            import datetime

            foo = unicode()
            bar = u'hello world'
        """,
        # No module-level changes
        module_level = False)


# Generated at 2022-06-25 22:43:45.938316
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:54.786267
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    """
    node = ast.parse('str')
    tree = StringTypesTransformer.transform(node)
    assert(tree.tree.body[0].value.id == 'unicode')

# Generated at 2022-06-25 22:44:04.049016
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
from __future__ import unicode_literals
a = str(154)
b = str.__class__
c = str()
''')

    tree_changed, messages, _ = StringTypesTransformer.transform(tree)
    assert tree_changed == True
    assert messages == []

    tree = ast.parse('''
from __future__ import unicode_literals
a = unicode(154)
b = unicode.__class__
c = unicode()
''')

    tree_changed, messages, _ = StringTypesTransformer.transform(tree)
    assert tree_changed == False
    assert messages == []


# Generated at 2022-06-25 22:44:05.445528
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for StringTypesTransformer.
    
    """

# Generated at 2022-06-25 22:44:13.627406
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test transform "str(a)" => "unicode(a)"
    test_tree = ast.parse('str(a)')
    expected_tree_before = ast.parse('str(a)')
    expected_tree_after = ast.parse('unicode(a)')
    actual_tree_after, tree_changed, _ = StringTypesTransformer.transform(test_tree)
    assert ast.dump(actual_tree_after) == ast.dump(expected_tree_after)
    assert tree_changed

    # test transform "str" => "unicode"
    test_tree = ast.parse('str')
    expected_tree_before = ast.parse('str')
    expected_tree_after = ast.parse('unicode')

# Generated at 2022-06-25 22:44:19.373954
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
            x = str()
            z = str(2)
            w = str(z)
        '''
    expected_code = '''
            x = unicode()
            z = unicode(2)
            w = unicode(z)
        '''
    tree = ast.parse(code)
    tree_changed, new_tree, _ = StringTypesTransformer.transform(tree)
    assert tree_changed is True
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-25 22:44:21.842814
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_str  = 'str(1)'
    expected_str  = 'unicode(1)'
    input_ast = ast.parse(input_str)
    expected_ast = ast.parse(expected_str)
    with pytest.raises(TypeError):
        StringTypesTransformer.transform(input_ast)
    assert ast.dump(expected_ast) == ast.dump(StringTypesTransformer.transform(input_ast)[0])

# Generated at 2022-06-25 22:44:23.241825
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from . import run_transformer_test

    run_transformer_test(StringTypesTransformer)

# Generated at 2022-06-25 22:44:28.519057
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    cls = StringTypesTransformer()
    tree_changed, transformation_class_list = cls.transform(ast.parse('''a = 5
b = str(6)
c = 7
'''))    
    expected_str = '''a = 5
b = unicode(6)
c = 7
'''

    print(ast.dump(tree_changed))
    assert ast.dump(tree_changed) == expected_str
    assert transformation_class_list == []

# Generated at 2022-06-25 22:44:29.947268
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test case for constructor of class StringTypesTransformer."""
    _ = StringTypesTransformer()


# Generated at 2022-06-25 22:44:34.037600
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        target_tree = ast.parse("dict(a=str(x))")
        expected_tree = ast.parse("dict(a=unicode(x))")
        transformer = StringTypesTransformer

    Test().run()

# Generated at 2022-06-25 22:44:50.343575
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = textwrap.dedent('''\
        s = str(5)
        ''')
    tree = ast.parse(code)
    # Before
    assert_code(tree, code)
    # After
    StringTypesTransformer.transform(tree)
    assert_code(tree, textwrap.dedent('''\
        s = unicode(5)
        '''))

# Generated at 2022-06-25 22:44:52.008372
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    """

# Generated at 2022-06-25 22:44:59.944204
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Instance of StringTypesTransformer.
    string_transformer = StringTypesTransformer()
    # First test.
    first_test = ast.parse("x = 'hello'", mode="exec")
    assert string_transformer.transform(first_test).tree_changed == False
    # Second test.
    second_test = ast.parse("x = 'hello'", mode="eval")
    assert string_transformer.transform(second_test).tree_changed == False
    # Third test.
    third_test = ast.parse("def testFunc(): return 'hello'", mode="exec")
    assert string_transformer.transform(third_test).tree_changed == False
    # Fourth test.
    fourth_test = ast.parse("def testFunc(): return 'hello'", mode="eval")

# Generated at 2022-06-25 22:45:03.331107
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
x = 'Hello'
type(x)
""")
    
    tree_changed = StringTypesTransformer.transform(tree)
    assert tree_changed.tree_changed
    assert tree_changed.node_count == 2


# Generated at 2022-06-25 22:45:08.320082
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_helpers import build_and_run_ast

    code = \
    """
    x = str('test')
    """

    tree = build_and_run_ast(code, StringTypesTransformer)
    assert isinstance(tree.body[0].value, ast.Name)
    assert tree.body[0].value.id == 'unicode'

# Generated at 2022-06-25 22:45:14.091961
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    input_tree = ast.parse("""
        x = str()
        x = str('hello', 'world')
        x = str(1)
        """)
    expected_tree = ast.parse("""
        x = unicode()
        x = unicode('hello', 'world')
        x = unicode(1)
        """)
    result = StringTypesTransformer.transform(input_tree)
    assert astunparse.unparse(result.tree) == astunparse.unparse(expected_tree)

# Generated at 2022-06-25 22:45:16.163007
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that StringTypesTransformer replaces 'str' with 'unicode'."""
    from typed_ast import ast3 as ast

    # The code we will test

# Generated at 2022-06-25 22:45:20.421934
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tr_f = "    return str(val) + 1\n"
    tr = StringTypesTransformer()
    tree = ast.parse(tr_f)
    tree_tr = tr.transform(tree)
    tr_tr_f = astor.to_source(tree_tr.tree)
    assert tr_tr_f == "    return unicode(val) + 1\n"
    return True


# Generated at 2022-06-25 22:45:22.216130
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    import astunparse
    code = 'str("hi")'
    tree = ast.parse(code)
    node = StringTypesTransformer.transform(tree)
    assert astunparse.unparse(node) == "unicode('hi')"

# Generated at 2022-06-25 22:45:27.407156
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    code = """
        x = 'test'
        y = str(1)
    """

    expected_code = """
        x = 'test'
        y = unicode(1)
    """

    node = ast.parse(code)
    transformed_node, is_changed = StringTypesTransformer.transform(node)
    print(ast.dump(transformed_node))
    assert is_changed
    assert ast.dump(transformed_node) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-25 22:46:00.019218
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str("foo")')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    #ast.dump(result.tree)

# Generated at 2022-06-25 22:46:04.965110
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_code = """
x = str()
"""
    expected_code = """
x = unicode()
"""
    r = StringTypesTransformer.transform(ast.parse(input_code))
    assert r.tree.body[0].value.func.id == 'unicode'
    generated_code = astor.to_source(r.tree)
    assert generated_code == expected_code

# Generated at 2022-06-25 22:46:10.416108
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        a = isinstance(x, str)
    """
    expected_code = """
        a = isinstance(x, unicode)
    """
    test_node = astor.parse_file(io.StringIO(code)).body[0]
    result = StringTypesTransformer.transform(test_node)
    assert astor.to_source(result.tree).rstrip() == astor.to_source(expected_code).rstrip()
    assert result.tree_changed is True

# Generated at 2022-06-25 22:46:14.290672
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseTransformer
    from ..types import TransformationResult

    class TestTransformer(BaseTransformer):
        target = (2, 7)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            pass

    assert TestTransformer.target == (2, 7)

# Generated at 2022-06-25 22:46:21.832726
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast

    input_code = '''
from __future__ import unicode_literals

a = b.decode('utf-8')
c = d.encode('utf-8')
    '''
    expected_code = '''
from __future__ import unicode_literals

a = b.decode('utf-8')
c = d.encode('utf-8')
    '''
    tree = ast.parse(input_code)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert ast.dump(new_tree) == expected_code

# Generated at 2022-06-25 22:46:29.743785
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open('tests/samples/2.7/escape.py') as f:
        tree = ast.parse(f.read())

    print(ast.dump(tree))


    transformer = StringTypesTransformer()
    tree = transformer.transform(tree)


# Generated at 2022-06-25 22:46:35.352259
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
        def foo():
            x = str(1)
            print(x)
    '''
    tree = ast.parse(source)
    expected_source = '''
        def foo():
            x = unicode(1)
            print(x)
    '''
    expected_tree = ast.parse(expected_source)

    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed

# Generated at 2022-06-25 22:46:40.098782
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_before = """
        if isinstance(x, str):
            return x.decode('utf-8')
    """
    code_after = """
        if isinstance(x, unicode):
            return x.decode('utf-8')
    """.lstrip()

    t = StringTypesTransformer()
    res = t.transform(code_before)
    assert res.new_code.strip() == code_after.strip()
    assert res.tree_changed

# Generated at 2022-06-25 22:46:44.694779
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program_text = "a = str('hello'); b = unicode('hello')"
    tree = ast.parse(program_text)

    print(ast.dump(tree))

    transformed_program = StringTypesTransformer.transform(tree)

    print(ast.dump(transformed_program.tree))

if __name__ == '__main__':
    # test_StringTypesTransformer()
    pass

# Generated at 2022-06-25 22:46:45.444752
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # todo
    pass

# Generated at 2022-06-25 22:47:51.228927
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
    a = str(b)
    """
    expected = """
    a = unicode(b)
    """
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.run(tree)
    assert ast.dump(new_tree) == expected

# Generated at 2022-06-25 22:47:56.742016
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    
    code = '''x = "Hello" + "World" '''
    process_2to3_result = transform(code, target=(2, 7))

    # check output
    assert process_2to3_result.code == 'x = unicode("Hello") + unicode("World") '

    # check that result is a valid python2 code
    assert compile(process_2to3_result.code, 'stringTypes_test', 'exec', dont_inherit=True) is not None
    
    

# Generated at 2022-06-25 22:48:02.618459
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test tree
    test_tree = ast.Str("test")

    # Test for target
    assert StringTypesTransformer.target == (2, 7)

    # Test for transformation
    result = StringTypesTransformer.transform(test_tree)
    assert result.tree != test_tree
    assert result.tree_changed == True

    # Test for constructor of class StringTypesTransformer
    test_tree2 = ast.Str("test")
    test = StringTypesTransformer(test_tree2)
    assert test.transformation == StringTypesTransformer.transform
    assert test.result.tree == result.tree
    assert test.result.tree_changed == True

# Generated at 2022-06-25 22:48:08.272178
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast.ast3 import parse
    from ..utils.ast_factory import ast_factory

    tree_str = '''def test():
        x = str(1)
        y = str(x)
        return y
    '''
    tree = parse(tree_str)

    transformer = StringTypesTransformer()
    transformed_tree, tree_changed, _ = transformer.transform(tree)
    assert tree_changed is True

    tree_str_expected = '''def test():
        x = unicode(1)
        y = unicode(x)
        return y
    '''
    tree_expected = p

# Generated at 2022-06-25 22:48:16.063298
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    class TestStringTypesTransformer(unittest.TestCase):
        def test_replace_str(self):
            tree = ast.parse("a = str")
            self.assertFalse(StringTypesTransformer.transform(tree).changed)

            tree = ast.parse("a = unicode")
            self.assertFalse(StringTypesTransformer.transform(tree).changed)

            tree = ast.parse("a = str(a)")
            self.assertTrue(StringTypesTransformer.transform(tree).changed)

            tree = ast.parse("a = unicode(a)")
            self.assertFalse(StringTypesTransformer.transform(tree).changed)

            tree = ast.parse("if str: pass")
            self.assertTrue(StringTypesTransformer.transform(tree).changed)

            tree = ast.parse("if unicode: pass")

# Generated at 2022-06-25 22:48:19.846780
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_code = """
            def f(x):
                return str(x)
            """

    expected_output = """
            def f(x):
                return unicode(x)
            """
    tree = ast.parse(input_code)
    transformed_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert astor.to_source(transformed_tree) == expected_output

# Generated at 2022-06-25 22:48:20.626019
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import parse

    tree = pa

# Generated at 2022-06-25 22:48:23.925798
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .string_types import StringTypesTransformer
    from .utils import test_transformer
    node = ast.parse('type(x) is str')
    node = StringTypesTransformer.transform(node)
    assert ast.dump(node) == ast.dump(ast.parse('type(x) is unicode'))


# Generated at 2022-06-25 22:48:26.955537
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform(
        ast.Str("example")
    ) == TransformationResult(
        ast.Str("example"), False, []
    )



# Generated at 2022-06-25 22:48:30.568948
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode_str

    the_source = source_to_unicode_str(u'''
    x=str()
    ''')

    the_t = StringTypesTransformer.transform(ast.parse(the_source))

    assert find(the_t.tree, ast.Name, lambda x: x.id == 'unicode')


StringTypesTransformer.complete_tests()

# Generated at 2022-06-25 22:51:01.877392
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # No carets
    result_tree, _, transformation_result = StringTypesTransformer.transform(ast.parse("""
    a = str(1)
    """))
    assert result_tree.body[0].value.func.id == 'unicode'

    assert transformation_result == []

# Generated at 2022-06-25 22:51:02.722319
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-25 22:51:03.541010
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

# Generated at 2022-06-25 22:51:04.771313
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert_transformation(
        StringTypesTransformer,
        'str(foo)',
        'unicode(foo)'
    )

# Generated at 2022-06-25 22:51:05.378209
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:51:08.178301
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    f_tree = astor.parse_file('tests/input/string_types.py')
    t_tree = StringTypesTransformer().transform(f_tree)
    assert astor.to_source(t_tree.tree) == astor.to_source(astor.parse_file('tests/output/string_types.py'))

# Generated at 2022-06-25 22:51:10.551480
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse('str(2)')
    t_expected = ast.parse('unicode(2)')

    transformer = StringTypesTransformer()
    t = transformer.visit(t)

    ast.fix_missing_locations(t)
    assert ast.dump(t) == ast.dump(t_expected)

# Generated at 2022-06-25 22:51:13.253847
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import inspect, ast
    source = inspect.getsource(test_StringTypesTransformer)
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert compile(tree, '', 'exec').co_consts[2] == 'str'

# Generated at 2022-06-25 22:51:15.382728
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_parses_to

    assert_parses_to(
        'str',
        """class str:
            def __init__(self):
                pass
        """
    )

# Generated at 2022-06-25 22:51:16.442512
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from .unicode_literals import UnicodeLiteralsTransformer