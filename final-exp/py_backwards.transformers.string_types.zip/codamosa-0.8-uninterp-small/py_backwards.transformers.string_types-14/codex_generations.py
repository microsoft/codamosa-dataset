

# Generated at 2022-06-25 22:41:54.923918
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:41:56.026395
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert issubclass(StringTypesTransformer, BaseTransformer)

# Unit tests for constructor of class TransformationResult

# Generated at 2022-06-25 22:42:01.185579
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert isinstance(string_types_transformer_0, StringTypesTransformer)


# Generated at 2022-06-25 22:42:02.264708
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:03.613484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()



# Generated at 2022-06-25 22:42:06.062679
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert hasattr(string_types_transformer, 'target')
    assert hasattr(string_types_transformer, 'transform')

# Generated at 2022-06-25 22:42:06.963133
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:42:08.197996
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:09.779578
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = StringTypesTransformer()

# Generated at 2022-06-25 22:42:12.410131
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert_equal(string_types_transformer_0.target, (2, 7))


# Generate input for function _apply_transformer
from random import choice, randint

# Generated at 2022-06-25 22:42:19.304212
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    expected_result = string_types_transformer_0.transform(ast.parse("s = str(s)"))

    # Act
    actual_result = string_types_transformer_0.transform(ast.parse("s = str(s)"))

    # Assert
    assert expected_result == actual_result

# Generated at 2022-06-25 22:42:26.701505
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    tests = [
        'string_types_transformer_%d' % i for i in range(0, 1)
    ]
    loader = unittest.TestLoader()
    suites_list = []
    for test in tests:
        suite = loader.loadTestsFromName(test)
        suites_list.append(suite)

    big_suite = unittest.TestSuite(suites_list)

    runner = unittest.TextTestRunner()
    results = runner.run(big_suite)

test_StringTypesTransformer()

# Generated at 2022-06-25 22:42:30.848599
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert string_types_transformer_0 != None

    loader = unittest.TestLoader()

    # Get the suite from the loader
    suite = loader.loadTestsFromModule(test_case_0)

    # Use the basic test runner to run the suite
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-25 22:42:34.119487
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_1 = StringTypesTransformer()
    assert isinstance(string_types_transformer_1.target, tuple)
    assert string_types_transformer_1.target[0] == 2
    assert string_types_transformer_1.target[1] == 7

# Generated at 2022-06-25 22:42:36.612688
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ...types import TransformationResult
    assert StringTypesTransformer().transform(ast3.parse("")) == TransformationResult(ast3.parse(""), False, [])

# Generated at 2022-06-25 22:42:39.055206
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str a = 'hello'")
    tree_changed = True
    changes = []
    assert (StringTypesTransformer.transform(tree)
            == TransformationResult(tree, tree_changed, changes))

# Generated at 2022-06-25 22:42:40.410804
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer().target == (2, 7)


# Generated at 2022-06-25 22:42:41.358095
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()

# Generated at 2022-06-25 22:42:42.626828
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()

# Generated at 2022-06-25 22:42:44.268421
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert_equal(string_types_transformer_0.target, (2, 7))


# Generated at 2022-06-25 22:42:58.184113
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """class Foo(object):
    def function(self):
        print("Hello, world")
        return 'string'
    def function2(self):
        return str(123)
    def function3(self, x):
        return str(x)
"""
    tree = ast.parse(code)
    assert string_types_transformer_0.transform(tree) == 'class Foo(object):\n\tdef function(self):\n\t\tprint ("Hello, world")\n\t\treturn \'string\'\n\tdef function2(self):\n\t\treturn unicode(123)\n\tdef function3(self, x):\n\t\treturn unicode(x) '

# Generated at 2022-06-25 22:43:07.724941
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    dict = {}
    dict['python_version'] = (2, 7)
    dict['skip_list'] = None
    dict['only_list'] = None
    dict['tree'] = None
    dict['tree_changed'] = None
    dict['warnings'] = None
    string_types_transformer_0 = StringTypesTransformer()
    assert (string_types_transformer_0.python_version == dict['python_version'])
    assert (string_types_transformer_0.skip_list == dict['skip_list'])
    assert (string_types_transformer_0.only_list == dict['only_list'])
    assert (string_types_transformer_0.tree == dict['tree'])
    assert (string_types_transformer_0.tree_changed == dict['tree_changed'])
   

# Generated at 2022-06-25 22:43:10.067077
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    # The target field should be initialized properly
    assert string_types_transformer.target == (2, 7)


# Generated at 2022-06-25 22:43:11.537400
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer(version = (2, 7), target = (2, 7)) == StringTypesTransformer


# Generated at 2022-06-25 22:43:13.298030
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert string_types_transformer_0 is not None


# Generated at 2022-06-25 22:43:14.764215
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
#test_StringTypesTransformer()

# Generated at 2022-06-25 22:43:15.587733
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer is not None


# Generated at 2022-06-25 22:43:19.620748
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert isinstance(StringTypesTransformer(), StringTypesTransformer)


# Generated at 2022-06-25 22:43:21.255333
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.target == (2, 7)


# Generated at 2022-06-25 22:43:23.813367
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert string_types_transformer_0.target == (2, 7)


# Generated at 2022-06-25 22:43:31.245506
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer. 
    
    """
    StringTypesTransformer()

# Generated at 2022-06-25 22:43:34.416801
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 22:43:36.144835
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert repr(StringTypesTransformer) == '<StringTypesTransformer>'

# Generated at 2022-06-25 22:43:38.999318
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform(ast.parse("str('test')")).tree.body[0].value.func.id

# Generated at 2022-06-25 22:43:44.461912
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
import sys
       
'''
    # the ast of source code
    tree = ast.parse(source)
    # print(ast.dump(tree))
    expected_result = '''
import sys
       
'''
    result, tree_changed, _ = StringTypesTransformer.transform(tree)
    print(ast.dump(result))
    assert ast.dump(result) == expected_result
    assert tree_changed == False



# Generated at 2022-06-25 22:43:46.342514
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print('Testing constructor of class StringTypesTransformer')
    t = StringTypesTransformer()
    assert t.target == (2, 7)


# Generated at 2022-06-25 22:43:50.147530
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    line = 'x = "123"'
    tree = ast.parse(line)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    assert isinstance(result.tree, ast.AST)
    assert result.tree_changed
    assert line.strip().count(' ') + 1 == len(StringTypesTransformer.get_stats())

# Generated at 2022-06-25 22:43:50.958242
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:57.586763
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert (StringTypesTransformer.transform(
        ast.parse("print('string')")
    ).tree_changed == True)
    assert (StringTypesTransformer.transform(
        ast.parse("print('string')")
    ).codemod_commands == [])
    assert (StringTypesTransformer.transform(
        ast.parse("print('string')")
    ).tree == ast.parse("print(unicode('string'))"))

    assert (StringTypesTransformer.transform(
        ast.parse("assert isinstance(var, str)")
    ).tree == ast.parse("assert isinstance(var, unicode)"))

# Generated at 2022-06-25 22:44:04.386393
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.tree import pprint
    from .unicode_literals import UnicodeLiteralInserter

    code = '''
    def func(s: str):
        assert isinstance(s, str)
    '''
    tree = source_to_tree(code, 2)
    UnicodeLiteralInserter().visit(tree)
    pprint(tree)
    print('-' * 40)
    pprint(StringTypesTransformer().visit(tree))

# Generated at 2022-06-25 22:44:20.167430
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('"a str"'))[0] == ast.parse('"a str"')
    assert StringTypesTransformer.transform(ast.parse('type("a string")'))[0] == ast.parse('type("a string")')
    assert StringTypesTransformer.transform(ast.parse('str'))[0] == ast.parse('unicode')

# Generated at 2022-06-25 22:44:26.787387
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import load_tree
    from ..utils.ast_helpers import ast_repr

    transformer = StringTypesTransformer()

    tree = load_tree('test/fixtures/string_types/fixture.py')
    unparsed = ast.dump(tree)
    new_tree = transformer.transform(tree)
    unparsed2 = ast.dump(new_tree.tree)
    assert unparsed == unparsed2

    # TODO: Add more tests

    if (new_tree.changed):
        print("New code:\n%s\n" % (ast_repr(tree)))

# Generated at 2022-06-25 22:44:27.624648
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:28.477104
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:30.215630
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_cases.string_types import string_types_test

    trans = StringTypesTransformer()

    trans.transform(string_types_test)

# Generated at 2022-06-25 22:44:33.681179
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def function(a_str):
        return str
    """

    t = StringTypesTransformer.transform(ast.parse(code))
    assert 'unicode' in astor.to_source(t.tree)

# Generated at 2022-06-25 22:44:36.053870
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(5)')
    expected = ast.parse('unicode(5)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected

# Generated at 2022-06-25 22:44:40.331226
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_code_equal
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseTransformer):
        target = (2, 7)

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])


# Generated at 2022-06-25 22:44:40.910847
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str')).tree_changed == True

# Generated at 2022-06-25 22:44:44.743182
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transform = StringTypesTransformer.transform
    source = "x = str()"
    tree = ast.parse(source)
    new_tree, changed, messages = transform(tree)
    new_source = astor.to_source(new_tree).strip()
    print(new_source)
    assert changed
    assert new_source == "x = unicode()"

# Generated at 2022-06-25 22:45:12.003234
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    node=ast.Name(ctx=ast.Load(), id="str", lineno=1, col_offset=2)
    assert node.id=="str"
    newnode=StringTypesTransformer.transform(node)
    assert newnode.tree.id=="unicode"

# Generated at 2022-06-25 22:45:17.092178
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import create_test_tree, compare_ast
    from ..migrations.string_types import StringTypesTransformer

    tree = create_test_tree(
        """
        str = 'foo'
        type(str)
        """)

    new_tree = StringTypesTransformer().transform(tree)

    assert compare_ast(new_tree, 
        """
        unicode = 'foo'
        type(unicode)
        """)

# Generated at 2022-06-25 22:45:20.416848
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.snippet import snippet_from_ast

    snippet = """
        x = str(1)
    """

    result, _ = StringTypesTransformer.transform(
        snippet_from_ast(snippet)
    )

    assert result[0].get('value') == 'unicode(1)'

# Generated at 2022-06-25 22:45:24.602262
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    r = StringTypesTransformer.transform(ast.parse("x = str(1)"))
    assert r.tree_changed
    assert ast.dump(r.tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[]))])"

# Generated at 2022-06-25 22:45:26.327636
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test the class constructor
    try:
        StringTypesTransformer()
        assert True
    except:
        assert False


# Generated at 2022-06-25 22:45:32.438079
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import parse
    from ..fixers import fix_print_function, fix_unicode_literals


# Generated at 2022-06-25 22:45:34.852719
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_transformer_shared_tests import verify_ast_transformer_class
    verify_ast_transformer_class(StringTypesTransformer)


# Generated at 2022-06-25 22:45:40.632364
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    import textwrap

    class_code = textwrap.dedent('''
    class Foo:
        def __init__(self, x):
            self.x = x

    def bar(self):
        return self.x
    ''')

    tree = ast.parse(class_code)
    transformer = StringTypesTransformer()
    transformed_tree = transformer.transform(tree)

    import astor
    code = astor.to_source(transformed_tree.tree)
    print(code)

# Generated at 2022-06-25 22:45:51.417085
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3

# Generated at 2022-06-25 22:45:52.190046
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:46:47.166164
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
        def hello():
            mystr = str()
    '''
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    tree_str = ast.dump(tree)
    assert "mystr = unicode()" in tree_str

# Generated at 2022-06-25 22:46:47.876201
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:46:50.031089
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('a = str("test")')) == \
     TransformationResult(ast.parse('a = unicode("test")'), True, [])

# Generated at 2022-06-25 22:46:51.635900
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.python_source import to_source
    from ..utils.python_tree import parse

# Generated at 2022-06-25 22:46:52.072349
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:47:01.368120
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert TransformationResult
    test1 = """str"""
    test2 = """str"""
    test3 = """str"""
    test4 = """str"""
    test5 = """str"""
    test6 = """str"""
    test7 = """str"""
    test8 = """str"""
    test9 = """str"""
    test10 = """str"""
    test11 = """str"""
    test12 = """str"""
    assert StringTypesTransformer.transform(ast.parse(test1)) == TransformationResult(ast.parse("""unicode"""), True, [])
    assert StringTypesTransformer.transform(ast.parse(test2)) == TransformationResult(ast.parse("""unicode"""), True, [])

# Generated at 2022-06-25 22:47:02.157490
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:47:08.186355
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTransformerTest
    
    class Test(BaseTransformerTest):
        target_version = (2, 7)
        transform = StringTypesTransformer.transform

        def test_simple_case(self):
            before = """
            x = str(42)
            """

            after = """
            x = unicode(42)
            """

            self.assertTransformEqual(before, after)

        def test_no_change(self):
            before = """
            from typing import List
            """

            after = """
            from typing import List
            """
            
            self.assertTransformEqual(before, after)

# Generated at 2022-06-25 22:47:15.607799
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Before
    code = """
if isinstance(x, str):
    pass
"""
    expected_code = """
if isinstance(x, unicode):
    pass
"""

    tree = ast.parse(code)
    new_tree, tree_changed = StringTypesTransformer.transform(tree)
    assert tree_changed == True
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_code))

    # After
    code = """
if isinstance(x, unicode):
    pass
"""
    tree = ast.parse(code)
    new_tree, tree_changed = StringTypesTransformer.transform(tree)
    assert tree_changed == False
    assert ast.dump(new_tree) == ast.dump(tree)

# Generated at 2022-06-25 22:47:20.022102
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    from typed_ast import parse
    
    tree = parse('a = str(1)')
    tree_transformed = StringTypesTransformer.transform(tree)
    tree_transformed[0].body[0].value.args = [ast.Num(2)]
    exec(compile(tree_transformed[0], filename="", mode="exec"),globals())
    assert a == "2"

# Generated at 2022-06-25 22:49:37.990744
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str(\"test\") + str")
    transformer = StringTypesTransformer()

    new_tree, tree_changed, _ = transformer.transform(tree)
    assert tree_changed
    
    # New tree: unicode(\"test\") + unicode
    assert ast.dump(new_tree, annotate_fields=False) == (
        "Module(body=[Expr(value=BinOp(left=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='test')], keywords=[], starargs=None, kwargs=None), op=Add(), right=Name(id='unicode', ctx=Load())))])"
    )

# Generated at 2022-06-25 22:49:45.625065
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('1 + 2')
    tree_changed, warnings = StringTypesTransformer.transform(tree)
    assert str(tree) == 'Module(body=[Expr(value=BinOp(left=Num(n=1), op=Add(), right=Num(n=2)))])'
    assert tree_changed == False
    assert warnings == []

    tree = ast.parse('a = 2')
    tree_changed, warnings = StringTypesTransformer.transform(tree)
    assert str(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=2))])'
    assert tree_changed == False
    assert warnings == []


# Generated at 2022-06-25 22:49:52.156932
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ..types import apply_transformer
    #
    tree = ast3.parse("x = str()")
    # tree has the following structure
    """
    Module(body=[
        Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='str', ctx=Load()), args=[], keywords=[]))
    ])
    """
    result = apply_transformer(tree, StringTypesTransformer)
    #
    # has the following structure
    """
    Module(body=[
        Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))
    ])
    """

# Generated at 2022-06-25 22:49:54.457513
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from .. import transform

    code = 'str()'
    tree = ast.parse(code)
    new_tree, *_ = transform(tree, StringTypesTransformer)
    assert astunparse.unparse(new_tree) == 'unicode()'

# Generated at 2022-06-25 22:49:58.201770
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    tree = ast.parse('hello = "world"')
    result = StringTypesTransformer.transform(tree)
    assert str(result.tree) == "hello = u'world'"

    # Test 2
    tree = ast.parse('typing.List[int]')
    result = StringTypesTransformer.transform(tree)
    assert str(result.tree) == 'typing.List[int]'

# Generated at 2022-06-25 22:49:59.680523
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('b = str(a)')) == \
        TransformationResult(ast.parse('b = unicode(a)'), True, [])

# Generated at 2022-06-25 22:50:00.244383
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:50:02.250079
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    doctest = [
        """
        def test():
            return str(5)
        """,
        """
        def test():
            return unicode(5)
        """
    ]

    assert str(StringTypesTransformer.transform(ast.parse(doctest[0]))) == str(ast.parse(doctest[1]))

# Generated at 2022-06-25 22:50:04.887113
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """a = str('test')"""
    expected = """a = unicode('test')"""
    tree = astor.parse_string(code)
    tree = StringTypesTransformer.run_on_single_file(tree)
    assert astor.to_source(tree) == expected

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:50:08.081020
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        a = 'hello'
        b = str(c) + ' world'
    """
    expected_code = """
        a = 'hello'
        b = unicode(c) + ' world'
    """
    t = StringTypesTransformer(2, 7)
    t.transform_source(code) == expected_code