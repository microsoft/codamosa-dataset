

# Generated at 2022-06-25 22:42:03.075246
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer()

# Generated at 2022-06-25 22:42:03.615777
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:42:05.029488
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_1 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:05.946716
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer()

# Generated at 2022-06-25 22:42:07.522660
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor of class StringTypesTransformer
    string_types_transformer_1 = StringTypesTransformer()

# Generated at 2022-06-25 22:42:09.440753
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()


# Generated at 2022-06-25 22:42:13.450716
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    ''' Tests for the constructor of class StringTypesTransformer '''
    
    # Test: Instantiate object

    string_types_transformer_0 = StringTypesTransformer()
    
    # Test: Instantiate object

    string_types_transformer_1 = StringTypesTransformer()
    
    # Test: Instantiate object

    string_types_transformer_2 = StringTypesTransformer()

# Generated at 2022-06-25 22:42:15.378323
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer0 = StringTypesTransformer()


    assert string_types_transformer0 != None


# Generated at 2022-06-25 22:42:17.978463
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:42:19.146349
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()



# Generated at 2022-06-25 22:42:23.643329
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()


# Generated at 2022-06-25 22:42:25.081986
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()



# Generated at 2022-06-25 22:42:26.340760
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:27.296963
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-25 22:42:28.576536
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:29.753055
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_1 = StringTypesTransformer()

# Generated at 2022-06-25 22:42:31.957984
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('"%s"' % ('a'))
    string_types_transformer_0 = StringTypesTransformer()


# Generated at 2022-06-25 22:42:33.136568
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests for constructor of class StringTypesTransformer."""
    pass

# Generated at 2022-06-25 22:42:35.196244
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer_0 = StringTypesTransformer()
    assert repr(string_types_transformer_0) == '<StringTypesTransformer>'


# Generated at 2022-06-25 22:42:35.974235
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True


# Generated at 2022-06-25 22:42:47.087899
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test converting str to unicode
    original = [
        "import sys",
        "print(sys.stdout.read())",
    ]
    test_tree = ast.parse("\n".join(original))
    transformer = StringTypesTransformer()
    result = transformer.transform(test_tree)
    expected = [
        "import sys",
        "print(sys.stdout.read())",
    ]
    assert result.tree_changed is True
    assert len(result.warnings) == 0
    assert result.tree.body[0].names[0].name == 'sys'
    assert result.tree.body[1].value.value.args[0].s == expected[1]

# Generated at 2022-06-25 22:42:47.928035
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import parse


# Generated at 2022-06-25 22:42:54.148217
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("\n\nRunning test for StringTypesTransformer")
    test_tree = ast.parse("print('hello')")
    print("pre-transform:\n")
    print(ast.dump(test_tree))
    assert StringTypesTransformer.transform(test_tree)
    print("post-transform:\n")
    print(ast.dump(test_tree))

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-25 22:42:54.929512
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:42:58.328524
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..tests.test_utils import compare_ast
    from .. import parse

    source = "str('test')"
    expected = "unicode('test')"

    tree = parse(source)
    new_tree = StringTypesTransformer.run_pipeline(tree)
    assert compare_ast(new_tree, expected)

# Generated at 2022-06-25 22:43:02.752327
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Set up
    tree = ast.parse('''\
a = str('test')
b = str(2)''')

    # Run
    result = StringTypesTransformer.transform(tree)

    # Make assertions
    assert_equal(result.tree.body[0].value.func.id, 'unicode')
    assert_equal(result.tree.body[1].value.func.id, 'unicode')

# Generated at 2022-06-25 22:43:10.496941
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def test_str(x):
        return str(x)
    """
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    tree = transformer.visit(tree)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert tree.body[0].name == "test_str"
    assert isinstance(tree.body[0].body[0], ast.Return)
    assert isinstance(tree.body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].value.func, ast.Name)
    assert tree.body[0].body[0].value.func.id == "unicode"


# Generated at 2022-06-25 22:43:11.339821
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:20.384413
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str(1)")
    expected_tree = ast.parse("unicode(1)")

    # Type check original tree
    assert type(tree) == ast.AST

    # Convert tree with StringTypesTransformer
    tree_converted = StringTypesTransformer.transform(tree)

    # Type check converted tree
    assert type(tree_converted) == TransformationResult
    assert type(tree_converted._new_tree) == ast.AST

    # Assert that converted tree is equal to the expected tree
    assert ast.dump(tree_converted._new_tree) == ast.dump(expected_tree)

# Generated at 2022-06-25 22:43:26.481923
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that StringTypesTransformer transforms string type to unicode type
    """
    class_definition = ast.parse('class A: def __init__(self, a: str): self.a = a')
    tree = StringTypesTransformer.transform(class_definition)
    assert isinstance(tree.tree.body[0].body[0].args.args[0].annotation, ast.Name)
    assert tree.tree.body[0].body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-25 22:43:40.603549
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = inspect.cleandoc("""
    x = str('text')
    print(x)
    """)

    expected_code = inspect.cleandoc("""
    x = unicode('text')
    print(x)
    """)

    tree = ast.parse(code)
    transformer = StringTypesTransformer(tree)
    new_tree = transformer.transform()
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_code))
    assert transformer.report == []

# Generated at 2022-06-25 22:43:41.800035
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests StringTypesTransformer"""

# Generated at 2022-06-25 22:43:46.592339
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = r'''
    s = str(123)
    '''

    tree = ast.parse(code)

    expected = ast.parse(r'''
    s = unicode(123)
    ''')

    result = (StringTypesTransformer.transform(tree))
    assert result.tree_changed == True
    assert ast.dump(result.tree) == ast.dump(expected)

# Generated at 2022-06-25 22:43:50.498513
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class MyTypeChecker(TypeChecker):
        def __init__(self):
            tr = StringTypesTransformer()
            super(MyTypeChecker, self).__init__(transformers=[tr])


# Generated at 2022-06-25 22:43:54.966134
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = "def a():\n\treturn 'foo' == str('bar')"
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    transformed_tree, _ = transformer.transform(tree)
    assert astor.to_source(transformed_tree).strip() == "def a():\n\treturn 'foo' == unicode('bar')"

# Generated at 2022-06-25 22:43:55.777889
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse


# Generated at 2022-06-25 22:43:56.292025
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:43:59.586924
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as fast
    tree = ast.parse('''s = str(42)''')
    expected = fast.parse('''s = unicode(42)''')
    assert StringTypesTransformer.transform(tree).tree == expected

# Generated at 2022-06-25 22:44:02.963410
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        class MyClass:
            """
    new_tree = StringTypesTransformer.transform(ast.parse(code))
    assert new_tree.changed

# Generated at 2022-06-25 22:44:05.293884
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import TransformationResult
    from .test_utils import generate_syntax_tree
    from ..utils.tree import check_structure, get_ast_nodes


# Generated at 2022-06-25 22:44:21.652350
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    l = ast.Str('Test')
    k = ast.Name('str', ast.Load())
    m = ast.Name('unicode', ast.Load())
    assert not isinstance(StringTypesTransformer.transform(l), 
        TransformationResult)
    assert isinstance(StringTypesTransformer.transform(k), 
        TransformationResult)
    assert isinstance(StringTypesTransformer.transform(m), 
        TransformationResult)

# Generated at 2022-06-25 22:44:26.042896
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # setup
    source = """
    my_str = str(x)
    """
    expected = """
    my_str = unicode(x)
    """
    # exercise
    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)
    generated = astor.to_source(result.tree)
    # verify
    assert generated == expected
    # cleanup - done automatically

# Generated at 2022-06-25 22:44:31.379972
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as typed_ast
    import ast

    test_tree = ast.parse("""
x = str
y = unicode
""")
    expected_tree = ast.parse("""
x = unicode
y = unicode
""")

    transformer = StringTypesTransformer()
    result = transformer.transform(test_tree)
    assert result.transformed == expected_tree

# Generated at 2022-06-25 22:44:32.232856
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:33.418800
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:44:37.016355
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    import typed_ast.ast3 as ast

    code = "obj = str('asd')"
    tree = ast.parse(code)
    tree = transform(tree, StringTypesTransformer)
    exec(compile(tree, '<string>', 'exec'))
    assert obj == 'asd'


# Generated at 2022-06-25 22:44:41.633513
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''\
    x = str
    '''
    tree = ast.parse(code)

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    new_code = ''.join(astor.to_source(result.tree).rstrip()).strip()

    assert(new_code == 'x = unicode' == code.replace('str', 'unicode').strip())

# Generated at 2022-06-25 22:44:46.002681
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ...types import SourceCode

    source = '''
    def foo(a: str, b: str) -> str:
        pass
    '''
    source_code = SourceCode('test.py', source)
    transformed_source_code = StringTypesTransformer().transform(source_code)

    assert transformed_source_code.source == '''
    def foo(a: unicode, b: unicode) -> unicode:
        pass
    '''

# Generated at 2022-06-25 22:44:54.044190
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Dummy(): pass
    Dummy.__name__ = 'Dummy'
    Dummy.__bases__ = ()
    Dummy.__doc__ = None
    Dummy.__dict__ = {}
    Dummy.__module__ = 'test_StringTypesTransformer'
    node = ast.Str(s='a')
    assert(isinstance(node, ast.Str))
    assert(node.s == 'a')
    tran = StringTypesTransformer()
    result = tran.transform(node)
    assert(isinstance(result, ast.Str))
    assert(result.s == 'a')
    node = ast.Name(id='str')
    assert(isinstance(node, ast.Name))
    assert(node.id == 'str')
    result = tran.transform(node)

# Generated at 2022-06-25 22:44:57.218506
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    module = ast.parse('''
        def foo(str_):
            return str_
        ''')
    node = import_local_ast()
    assert astor.to_source(node) == astor.to_source(StringTypesTransformer.transform(module).tree)
    assert True

# Generated at 2022-06-25 22:45:24.740552
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from typed_ast import ast3
    from ..utils.tests import get_test_path

    tree = astor.parse_file(get_test_path("basics/tree_import_string_types.py"))
    new_node = StringTypesTransformer.transform(tree)

    expected_tree = astor.parse_file(get_test_path(
        "basics/tree_import_string_types_expected_result.py"))

    assert ast.dump(ast3.parse(expected_tree.dump())) == ast.dump(
        ast3.parse(new_node.tree.dump()))

# Generated at 2022-06-25 22:45:25.866015
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TODO: Add tests for StringTypesTransformer
    assert True

# Generated at 2022-06-25 22:45:26.656916
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.token_test('')

# Generated at 2022-06-25 22:45:31.049617
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()


# Generated at 2022-06-25 22:45:39.125209
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    import sys

    tree = ast.parse(
        '''def alpha(a: str, b: str):
            c: str = a
            d = b
            return c''')
    expected_tree = ast.parse(
        '''def alpha(a: unicode, b: unicode):
            c: unicode = a
            d = b
            return c''')
    
    res = StringTypesTransformer.transform(tree)

    if res.tree_changed:
        assert astunparse.unparse(expected_tree) == astunparse.unparse(tree)
    else:
        assert astunparse.unparse(tree) == astunparse.unparse(expected_tree)

# Generated at 2022-06-25 22:45:51.201094
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    from typed_ast import ast3

    # Act
    class Sample:
        def __init__(self, noc: str):
            pass

    sample_tree = ast.parse(inspect.getsource(Sample))

    # Assert
    transformer = StringTypesTransformer()
    changed_tree = transformer.visit(sample_tree)

    # Verify whether types are converted
    assert(changed_tree.body[0].body[0].value.args[0] == ast3.Name(id='unicode', ctx=ast3.Load()))
    assert(changed_tree.body[0].body[0].value.keywords[0].arg == 'noc')

# Generated at 2022-06-25 22:45:56.808808
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Instance to use as argument in the tests
    instance = StringTypesTransformer()
    # Test method isTransformable
    try:
        instance.isTransformable(1, 2, (1, 2))
        assert False
    except TypeError:
        pass
    # Test method transform
    try:
        instance.transform(1)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-25 22:45:59.972853
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Verify that constructor of class `StringTypesTransformer` throws `NotImplementedError`."""
    with pytest.raises(NotImplementedError):
        StringTypesTransformer()

# Generated at 2022-06-25 22:46:00.505102
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:46:09.042416
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name('str', ast.Load(), lineno=1, col_offset=0)
    assert isinstance(node, ast.AST)
    assert isinstance(node, ast.expr)
    assert isinstance(node, ast.Name)
    assert node.id == 'str'
    tree = ast.parse('a = str(2) + "3"')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.warnings == []
    assert result.tree.body[0].value.left.id =='unicode'
    assert result.tree.body[0].value.op.s == '+'
    assert result.tree.body[0].value.right.s == '3'

# Generated at 2022-06-25 22:47:02.955184
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer is not None

# Generated at 2022-06-25 22:47:10.287943
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    # Create AST of:
    # def x():
    #     x = str(2)

# Generated at 2022-06-25 22:47:13.395030
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_code = """x = str('hello')"""
    expected_code = """x = unicode('hello')"""
    output_code = StringTypesTransformer().transform(input_code)
    assert output_code == expected_code, f'Actual: {output_code}'

# Generated at 2022-06-25 22:47:19.959957
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test case for StringTypesTransformer"""
    pycode = """
        import unicode
        print(str('Hello world'))
    """
    astree = ast.parse(pycode)

    new_ast = StringTypesTransformer.transform(astree)

    assert "import unicode" in new_ast.get_source()
    assert "unicode" in new_ast.get_source()
    assert "import str" not in new_ast.get_source()
    assert "unicode('Hello world')" in new_ast.get_source()
    assert "str('Hello world')" not in new_ast.get_source()

# Generated at 2022-06-25 22:47:24.700100
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test replacement of unicode type."""
    code = "foo = str()"
    tree = ast.parse(code)

    new_tree, changed = StringTypesTransformer.transform(tree)
    
    assert changed
    assert code != ast.dump(new_tree)

    fixed_code = "foo = unicode()"
    fixed_tree = ast.parse(fixed_code)

    assert ast.dump(new_tree) == ast.dump(fixed_tree)

# Generated at 2022-06-25 22:47:31.719122
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import parse
    from .. import type_inference
    from . import fix_code
    from . import fix_ast

    code = '''
        def convert(a): #@
            return str(a) #@
    '''

    new_code = '''
        def convert(a): #@
            return unicode(a) #@
    '''

    tree = parse.parse(code)

    tree = type_inference.resolve(tree)

    tree, changed = fix_code(tree, [StringTypesTransformer])

    assert code != fix_ast.dumps_code(tree)
    assert new_code == fix_ast.dumps_code(tree)
    assert changed

    # Testing that the tree is converted without errors
    parse.parse(new_code)

# Generated at 2022-06-25 22:47:39.015056
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from os import path
    from ..test.test_utils import compile_with_pyversion

    # The file to test
    filePath = path.join(path.dirname(path.abspath(__file__)), '..', '..', 'test', 'examples',
                         'string_transform_before.py')
    # Compile the file with Python 3
    file_py3 = compile_with_pyversion(filePath, pyversion=(3, 6))
    # Compile the file with Python 2
    file_py2 = compile_with_pyversion(filePath, pyversion=(2, 7))
    # Take the first statement
    file_py3_code = file_py3.body[0].body
    file_py2_code = file_py2.body[0].body
    # Run the code of the first statement

# Generated at 2022-06-25 22:47:41.317492
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'def foo(s: str): pass'

    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)

    assert result.modified
    assert result.node_descriptions == []

# Generated at 2022-06-25 22:47:47.866701
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_cases.test_10_string_types_transformer import code
    from ..utils.fake import FakeFile
    from ..utils.source_code import SourceCode
    from ..utils.ast_compare import compare_ast
    import ast
    import textwrap
    with open("test/test_cases/test_10_string_types_transformer/expected_code.txt") as f:
        expected_code = f.read()
    fake_file = FakeFile("test", code)
    source_code = SourceCode.from_file(fake_file)
    expected_tree = ast.parse(textwrap.dedent(expected_code))
    tree = source_code.tree
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

# Generated at 2022-06-25 22:47:52.623429
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def some_function(param: str):
        pass
    """
    tree = astor.parse_file(io.StringIO(code))
    
    transformer = StringTypesTransformer()
    result_tree, tree_changed = transformer.transform(tree)
    assert tree_changed == True

    expected_output = """
    def some_function(param: unicode):
        pass
    """
    output = astor.to_source(result_tree)
    assert expected_output.strip() == output.strip()

# Generated at 2022-06-25 22:50:18.787067
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(
        ast.parse('a = str(b)')) == \
        TransformationResult(
            ast.parse('a = unicode(b)'), True, [])
    assert StringTypesTransformer.transform(
        ast.parse('a = "str"')) == \
        TransformationResult(
            ast.parse('a = "str"'), False, [])

# Generated at 2022-06-25 22:50:19.401572
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:50:23.897682
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    source = '''
from __future__ import unicode_literals
a = str("test string")
b = unicode("test string")
'''
    tree = astor.parse_file(StringIO(source))
    tree = StringTypesTransformer.transform(tree)
    tree = astor.to_source(tree)
    assert tree.strip() == '''
from __future__ import unicode_literals

a = unicode("test string")
b = unicode("test string")
'''.strip()

# Generated at 2022-06-25 22:50:29.079262
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # for testing error messages
    str_node = ast.Name(id="str")
    # for testing error messages
    unicode_node = ast.Name(id="unicode")
    # for testing error messages
    class_node = ast.Name(id="class")
    # for testing error messages
    def_node = ast.Name(id="def")

    tree = ast.parse("x = str(10)")
    result = StringTypesTransformer.transform(tree)
    assert str(result.tree) == str(ast.parse("x = unicode(10)"))
    assert str(result.error_nodes) == str(set())


# Generated at 2022-06-25 22:50:29.707235
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-25 22:50:35.778923
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('s = str(0)')
    expected = ast.parse('s = unicode(0)')
    transformer = StringTypesTransformer(tuple(), {'src': '<string>'})

    actual, tree_changed, _ = transformer.transform(tree)

    assert tree_changed
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-25 22:50:39.590342
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        thing = 8
        other = 'a string'
    """

    transformed = StringTypesTransformer.transform(ast.parse(code))

    result = compile(transformed.tree, '<string>', 'exec')

    exec(result)
    assert(thing == 8)
    assert(other == 'a string')

# Generated at 2022-06-25 22:50:42.421530
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    # pylint: disable=unused-variable
    # pylint: disable=invalid-name
    a_str = str("abcd")
    case = StringTypesTransformer.transform(a_str)
    assert case is not None

test_StringTypesTransformer()

# Generated at 2022-06-25 22:50:43.538077
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    StringTypesTransformer.transform(ast.parse("""
        str()
        str("a")
    """))

# Generated at 2022-06-25 22:50:45.814652
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_code = "2"
    expected_code = "2"
    tree = ast.parse(input_code)
    tree_changed, errors, code = StringTypesTransformer.transform(tree)
    assert str(tree) == expected_code
    assert len(errors) == 0