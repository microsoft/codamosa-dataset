

# Generated at 2022-06-23 23:10:18.080907
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-23 23:10:19.997395
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test constructing a StringTypesTransformer object"""
    transformer = StringTypesTransformer()
    assert transformer is not None


# Generated at 2022-06-23 23:10:23.465515
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("my_str = str('a')")
    tree = StringTypesTransformer.transform(tree).tree
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='my_str', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='a')], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-23 23:10:31.750566
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..main import transform_file
    from ..utils.codetree import CodeTree
    from . import transform_and_compare_trees

    def do_test(source: str, expected: str) -> None:
        tree = CodeTree.build(source)
        transformed = transform_and_compare_trees(tree, ('StringTypesTransformer', ))
        assert transformed.source == expected

    # `str` in argument annotation
    do_test('def func(p: str): ...', 'def func(p: unicode): ...')

    # `str` in return annotation
    do_test('def func() -> str: ...', 'def func() -> unicode: ...')


# Generated at 2022-06-23 23:10:36.228630
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    testtree = ast.parse('''
    a = str(b)
    a = b + str(b)''')
    ans = StringTypesTransformer.transform(testtree)
    expected = '''
    a = unicode(b)
    a = b + unicode(b)'''
    assert ans == expected

# Generated at 2022-06-23 23:10:44.951530
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("def f(a): return str(a)")
    tree_changed, _ = StringTypesTransformer.transform(tree)
    print(ast.dump(tree))
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='f', args=arguments(args=[arg(arg='a', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))], decorator_list=[])])\n"
    assert tree_changed == True

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:10:51.203351
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from . import builtins
    from . import string

    src = """x = str('a')"""
    expected_src = """x = unicode('a')"""

    tree = ast.parse(src)
    expected_tree = ast.parse(expected_src)
    transformed = transform(tree, trans_list=[
        builtins,
        string
        ])
    assert transformed == expected_tree

# Generated at 2022-06-23 23:11:00.655057
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class MyType(ast.AST):
        _fields = ('name',)


# Generated at 2022-06-23 23:11:01.048372
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:11:09.404478
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source_code = '''
        " \x80 "
        a = type(str("aa"))
        a = type(str(b"aa"))
        a = bytes("aa", "ascii")
        a = bytes("aa", "ascii", "strict")
        '''

    expected_ast = ast.parse(source_code)
    expected_code = dedent("""
        " \x80 "
        a = type(unicode("aa"))
        a = type(unicode(b"aa"))
        a = bytes("aa", "ascii")
        a = bytes("aa", "ascii", "strict")
        """).strip()

# Generated at 2022-06-23 23:11:14.102526
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open("examples/2to3/StringTypes.py") as input:
        tree = ast.parse(input.read())
    tree_changed, num_changes, _ = StringTypesTransformer.transform(tree)
    assert(num_changes == 2)

# Generated at 2022-06-23 23:11:19.735117
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ..toolbox.ast_helper import dump_tree
    source = 'CONSTANT = "abc"; variable = str(CONSTANT)'
    tree = ast3.parse(source)
    result, _ = StringTypesTransformer.transform(tree)
    assert dump_tree(tree) != dump_tree(result)
    assert dump_tree(result) == source.replace('str', 'unicode')

# Generated at 2022-06-23 23:11:23.898963
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    def assert_transform(old, new):
        t = StringTypesTransformer.transform(ast.parse(old))
        assert t.tree_changed == True
        assert ast.dump(t.tree) == ast.dump(ast.parse(new))
    assert_transform("def f():\n    pass", "def f():\n    pass")

test_StringTypesTransformer()

# Generated at 2022-06-23 23:11:31.876988
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.parse("str(1)")
    assert ast.dump(node) == "Module(body=[Expr(value=Call(func=Name(id='str', ctx=Load()), args=[Num(n=1)], keywords=[]))])"
    assert ast.dump(StringTypesTransformer.run(node)) == "Module(body=[Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[]))])"

# Generated at 2022-06-23 23:11:38.842059
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer. 
    
    """
    def check(node, tr):
        (changed, new_node), issues = StringTypesTransformer.transform(node)
        assert changed == tr
        return new_node

    check(
        ast.parse("def foo(x: str):\n    pass"),
        1,
    )
    check(
        ast.parse("from typing import List\n\nList[str]"),
        1,
    )

# Generated at 2022-06-23 23:11:40.801327
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Try to create a StringTypesTransformer object
    t = StringTypesTransformer()

    assert t.target == (2, 7)


# Generated at 2022-06-23 23:11:41.673175
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TODO: Add tests
    assert False

# Generated at 2022-06-23 23:11:47.380623
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
print('str')
# this is a comment
'''
    new_code = '''
print(unicode('str'))
# this is a comment
'''
    result = StringTypesTransformer.transform(code)
    assert result.code == new_code

# Generated at 2022-06-23 23:11:49.734844
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.python_source import PythonSource

# Generated at 2022-06-23 23:11:51.210818
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast

    # Example code

# Generated at 2022-06-23 23:11:57.342644
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    source = '''
str1 = ''
str2 = "helo"
str3 = "helo" + str1 + "helo"
'''
    expected = '''
unicode1 = ''
unicode2 = "helo"
unicode3 = "helo" + unicode1 + "helo"
'''

    tree = astor.parse_file(StringIO(source))
    new_tree, _ = StringTypesTransformer.transform(tree)
    assert astor.to_source(new_tree) == expected

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:12:07.964321
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test Python 2 code
    tree = ast.parse("str()")
    result = StringTypesTransformer.transform(tree)
    expected = ast.parse("unicode()").body[0]
    assert result.tree.body[0] == expected
    assert result.tree_changed
    tree = ast.parse("a = 'hi'")
    result = StringTypesTransformer.transform(tree)
    expected = ast.parse("a = 'hi'").body[0]
    assert result.tree.body[0] == expected
    assert not result.tree_changed
    # Test Python 3 code
    tree = ast.parse("a = 'hi'")
    result = StringTypesTransformer.transform(tree)
    expected = ast.parse("a = 'hi'").body[0]
    assert result.tree.body[0] == expected

# Generated at 2022-06-23 23:12:18.234829
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:21.151366
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    trans = StringTypesTransformer()

# Generated at 2022-06-23 23:12:26.044607
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_string = "def foo(x): return str(x)"
    expected_output = "def foo(x): return unicode(x)"

    actual_output = StringTypesTransformer.transform(ast.parse(input_string))

    print(actual_output)

    assert ast.dump(ast.parse(expected_output)) == ast.dump(actual_output)

# Generated at 2022-06-23 23:12:31.501755
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    # Arrange
    ast_node = ast.Name(id='str')
    expected_tree = ast.Name(id='unicode')

    # Act
    actual_tree, tree_changed, messages = StringTypesTransformer.transform(ast_node)

    # Assert
    assert (actual_tree == expected_tree)
    assert (tree_changed == True)
    assert (messages == [])

# Generated at 2022-06-23 23:12:32.675368
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:33.238742
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-23 23:12:36.010508
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    result = StringTypesTransformer().transform(ast.parse("str.upper(s)"))
    assert result.tree_changed == True
    assert name == 'unicode'

# Generated at 2022-06-23 23:12:40.155726
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    result = StringTypesTransformer().transform(ast.parse('print(str)'))
    assert result.tree_changed == True
    assert str(getattr(result.tree.body[0].value, 'func')) == '<_ast.Name object at 0x7f7e06a49b50>'

# Generated at 2022-06-23 23:12:47.470403
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse(
'''
a = str(1)
b = str()
c = isinstance(a, str)
d = str
e = type(str)
''')

    result, changed = StringTypesTransformer.transform(tree)

    expected = ast.parse(
'''
a = unicode(1)
b = unicode()
c = isinstance(a, unicode)
d = unicode
e = type(unicode)
''').body

    assert result.body == expected
    assert changed


# Generated at 2022-06-23 23:12:56.090233
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        # Comment
        import os
        import string
        os.path.abspath('')
        string.replace('', '')
        str('abc')
        str(str(''))
    """, mode='exec')
    expected_tree = ast.parse("""
    # Comment
    import os
    import string
    os.path.abspath('')
    string.replace('', '')
    unicode('abc')
    unicode(unicode(''))
    """, mode='exec')
    t = StringTypesTransformer()
    t.transform(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)
    assert t.result() == {'changed': True, 'skipped': []}

# Generated at 2022-06-23 23:13:02.884062
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .utils import round_trip
    from ..utils import parse

    code = 'str(1)'
    t = parse(code)
    r = round_trip(t, StringTypesTransformer)
    assert str(r) == 'unicode(1)'

    code = 'a.__name__'
    t = parse(code)
    r = round_trip(t, StringTypesTransformer)
    print(r)
    assert str(r) == 'a.__name__'

# Generated at 2022-06-23 23:13:06.449536
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str(s)')
    transformed_tree = StringTypesTransformer().transform(tree)
    assert transformed_tree.tree.body[0].value.func.id == 'unicode'
    assert transformed_tree.tree_changed == True

# Generated at 2022-06-23 23:13:14.837172
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
    def g():
        return 'hello, world'
    ''')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.tree != tree
    assert ast.dump(result.tree) == ast.dump(ast.parse('''
    def g():
        return u'hello, world'
    '''))
    assert ast.dump(tree) == ast.dump(ast.parse('''
    def g():
        return 'hello, world'
    '''))


# Generated at 2022-06-23 23:13:19.234284
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    import astunparse

    code = '''x = str('x')'''
    
    tree = ast.parse(code)

    test = code == astunparse.unparse(StringTypesTransformer.transform(tree).tree)
    assert test, 'Transformation error'

# Generated at 2022-06-23 23:13:21.519397
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from .base import make_module
    

# Generated at 2022-06-23 23:13:23.595026
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import check_equal_ast
    from pathlib import Path
    import tempfile


# Generated at 2022-06-23 23:13:33.298959
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    '''
    In [1]: import typed_ast.ast3 as ast
    In [2]: from typed_ast import transformers
    In [3]: from typed_ast import conversions
    In [4]: node = ast.parse("str()")
    In [5]: typed_ast.ast3.dump(node)
Out[5]: 'Expr(value=Call(func=Name(id='str', ctx=Load()), args=[], keywords=[]))'
    In [6]: transformer = transformers.StringTypesTransformer()
    In [7]: transformer.visit(node)
    In [8]: typed_ast.ast3.dump(node)
Out[8]: 'Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))'
    '''

#

# Generated at 2022-06-23 23:13:34.003073
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:13:38.969507
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program = """
    def transform(tree: str):
        return 0
    """
    tree = ast.parse(program)
    result = StringTypesTransformer.transform(tree)
    new_program = astor.to_source(result.tree, indent_with='    ')
    assert new_program == """
    def transform(tree: unicode):
        return 0
    """, new_program



# Generated at 2022-06-23 23:13:42.665878
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast as pyast
    import typed_ast.ast3 as ast3

    code = """x = str(1)"""
    expected_code = """x = unicode(1)"""

    tree = pyast.parse(code)
    assert ast3.dump(tree) == ast3.dump(pyast.parse(expected_code))

# Generated at 2022-06-23 23:13:49.213744
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class AliasImporter(ast.NodeTransformer):
        target = (3, 0)

        def visit_alias(self, node: ast.alias):
            node.name = "unicode"
            return node

    from typed_ast import parse
    tree = parse("print('test')")
    tree = StringTypesTransformer.transform(tree).tree
    tree = AliasImporter.visit(tree)

    expected = ast.Module(
        body=[
            ast.Expr(
                value=ast.Call(
                    func=ast.Name(id='print', ctx=ast.Load()),
                    args=[
                        ast.Str(s="test")
                    ],
                    keywords=[],
                    starargs=None,
                    kwargs=None
                )
            )
        ]
    )

    assert ast.dump

# Generated at 2022-06-23 23:13:59.027698
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # no changes to tree for None
    assert StringTypesTransformer.transform(None).tree_changed == False

    # tree changed, no warnings created for the tree with type str
    tree = ast.parse("s = str('abc')")
    assert StringTypesTransformer.transform(tree).tree_changed == True
    assert StringTypesTransformer.transform(tree).warnings == []

    # no changes to tree for unicode
    tree = ast.parse("s = unicode('abc')")
    assert StringTypesTransformer.transform(tree).tree_changed == False

    # no changes to tree for bytearray
    tree = ast.parse("s = bytearray('abc')")
    assert StringTypesTransformer.transform(tree).tree_changed == False

    # no changes to tree for bytes

# Generated at 2022-06-23 23:13:59.445732
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:14:03.359197
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # before
    code = """
x = str(5) + '5'
    """

    # after
    expected_code = """
x = unicode(5) + '5'
    """

    tree = ast.parse(code)
    StringTypesTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected_code.strip()

# Generated at 2022-06-23 23:14:08.005542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    ast_py2 = ast.parse('assert isinstance(x, str)')
    ast_py3 = ast.parse('assert isinstance(x, str)')
    tree_py2 = StringTypesTransformer.transform(ast_py2)
    tree_py3 = StringTypesTransformer.transform(ast_py3)
    assert tree_py2.tree is None
    assert isinstance(tree_py3.tree, ast.AST)
    assert ast.dump(tree_py3.tree) == 'Module(body=[Assert(test=Compare(left=Name(id="x", ctx=Load()), ops=[Is()], comparators=[Name(id="str", ctx=Load())]))])'

# Generated at 2022-06-23 23:14:13.992472
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # pylint: disable=undefined-variable
    source = """
    def testMethod(b):
        return (str)(b)
    """
    tree = ast.parse(source)
    transformer = StringTypesTransformer()
    for node in find(tree, ast.Name):
        if node.id == 'str':
            node.id = 'unicode'
    expected = ast.parse(source)
    tree = transformer.transform(tree)
    assert (tree == expected)

# Generated at 2022-06-23 23:14:20.503454
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = '''
    def a(x):
        if not isinstance(x, str):
            raise
    '''

    # When
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    code_after_transformation = compile(tree.body[0], '', mode='exec')

    # Then
    assert code_after_transformation.co_names == ('isinstance', 'unicode', 'raise')

# Generated at 2022-06-23 23:14:27.385016
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..main import transform_tree
    import astunparse
    import textwrap
    code = textwrap.dedent("""
    print("hello, world!")
    """)
    print("junk")
    expected_output = textwrap.dedent("""
    print("hello, world!")
    """)
    result = transform_tree(code, 2.7)
    #print(ast.dump(result))
    print(astunparse.dump(result))
    assert astunparse.unparse(result) == expected_output

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:14:29.528132
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    check_test_data(
        StringTypesTransformer,
        'test_string_types.py',
        'test_string_types_target.py'
    )

# Generated at 2022-06-23 23:14:33.652282
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformed
    assert_transformed(StringTypesTransformer, 'a = str')
    assert_transformed(StringTypesTransformer, 'def f(x: str)\n    return x')
    assert_transformed(StringTypesTransformer, 'import str')

# Generated at 2022-06-23 23:14:44.077869
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ..utils.ast import ast_to_str

    tree = ast3.parse('x = str()')
    tree_changed, new_tree, messages = StringTypesTransformer.transform(tree)
    assert ast_to_str(new_tree) == 'x = unicode()'
    assert tree_changed == True

    tree = ast3.parse('x = str(a, b, c)')
    tree_changed, new_tree, messages = StringTypesTransformer.transform(tree)
    assert ast_to_str(new_tree) == 'x = unicode(a, b, c)'
    assert tree_changed == True

    tree = ast3.parse('x = unicode()')
    tree_changed, new_tree, messages = StringTypesTransformer.transform(tree)

# Generated at 2022-06-23 23:14:51.395803
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import sample_code
    from ..utils.tree import get_ast, get_source_code
    myfile = sample_code.SamplePythonFile('str_types.py')
    expected_file = sample_code.SamplePythonFile('str_types_unicode.py')
    tree_test = get_ast(myfile.contents)
    tree_expected = get_ast(expected_file.contents)
    tree_changed, _ = StringTypesTransformer.transform(tree_test)
    assert get_source_code(tree_changed) == get_source_code(tree_expected)

# Generated at 2022-06-23 23:15:01.748494
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(
        'def f1(x: str):\n'
        '    print(x)\n'
        '\n'
        'def f2(x: unicode):\n'
        '    print(x)')

    transformer = StringTypesTransformer()

    new_tree, transformation_made = transformer.transform_code(tree)

    assert transformation_made is False
    assert ast.dump(new_tree) == ast.dump(tree)

    new_tree, transformation_made = transformer.transform_code(tree, target=(2, 8))

    assert transformation_made is True

# Generated at 2022-06-23 23:15:07.459851
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    #We begin by constructing the string to transform
    code = """str('hello')"""
    # We turn it into a AST tree
    tree = ast.parse(code)

    #We apply our transformation to the tree
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)

    #We get the source code of the new tree
    source = compile(new_tree, '', 'exec')
    #We execute the code
    exec(source)


if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:15:08.655713
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:15:12.296051
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
           identifier = str(1)
           '''
    expected_code = '''
                   identifier = unicode(1)
                   '''
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(new_tree, include_attributes=True) == ast.dump(ast.parse(expected_code), include_attributes=True)

# Generated at 2022-06-23 23:15:17.216798
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import to_source

    ex = """
a = str(1) # -> a = unicode(1)
"""
    tree = ast.parse(ex)

    result = StringTypesTransformer.transform(tree)
    assert to_source(result.tree) == ex.replace(
        'str', 'unicode').strip()

# Generated at 2022-06-23 23:15:18.630098
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    target = (2, 7)


# Generated at 2022-06-23 23:15:19.218253
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:15:26.130771
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    import astor
    code = """
    x = str(a)
    y = str(b)
    """
    expected_code = """
    x = unicode(a)
    y = unicode(b)
    """
    tree = typed_ast.ast3.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    assert(astor.to_source(new_tree.tree).strip() == expected_code)
    assert(new_tree.tree_changed == True)
    assert(new_tree.shim_imports == [])

# Generated at 2022-06-23 23:15:26.898913
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:15:29.477900
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str("a")')
    tree = StringTypesTransformer.transform(tree)
    assert(compile(tree.tree, '', 'exec').body[0].value.args[0].s == 'a')


# Generated at 2022-06-23 23:15:30.298723
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Add test here
    return

# Generated at 2022-06-23 23:15:32.677223
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = str('ok');")
    tree = StringTypesTransformer.transform(tree)
    assert tree.code.to_source() == "a = unicode('ok');"

# Generated at 2022-06-23 23:15:36.041767
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    code1 = """
_str = str("yes")
"""
    tree1 = ast.parse(code1)
    assert StringTypesTransformer.validate(tree1)

    code2 = """
_str = str("yes")
"""
    tree2 = ast.parse(code2)
    assert StringTypesTransformer.transform(tree2)

    # FIXME test here

# Generated at 2022-06-23 23:15:41.261023
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from typed_ast import ast3 as ast
    program_code = 'a = str'
    tree = ast.parse(program_code)
    StringTypesTransformer.transform(tree)
    program_code_transformed = astunparse.unparse(tree)
    expected_output = 'a = unicode'
    assert program_code_transformed == expected_output



# Generated at 2022-06-23 23:15:46.894408
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    input = ast.parse(
        """
        def foo():
            bar = str()
        """
    )

    # Act
    result = StringTypesTransformer.transform(input)

    # Assert
    assert result.tree_changed == True
    assert ast.dump(result.tree) == ast.dump(
        ast.parse(
            """
            def foo():
                bar = unicode()
            """
        )
    )

# Generated at 2022-06-23 23:15:55.756861
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        class Foo():
            def bar(self, myVar=str):
                return myVar()
    """

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree).tree

    # Check that "myVar()" is not changed

# Generated at 2022-06-23 23:16:01.759735
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3; from typed_ast import ast3; from typed_ast.ast3 import *
    import sys; from nuitka.transforms.StringTypesTransformer import StringTypesTransformer

    test_node = parse('''
    a = str('Hello')
    ''')
    print(test_node); print()

    StringTypesTransformer.transform(test_node)
    print(test_node)

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:16:07.074627
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import can_transform

    tree = ast.parse('"hello world"')
    assert can_transform(StringTypesTransformer, tree)

    tree = ast.parse('print(str(42))')
    assert can_transform(StringTypesTransformer, tree)

    tree = ast.parse('print(unicode(42))')
    assert not can_transform(StringTypesTransformer, tree)



# Generated at 2022-06-23 23:16:10.445501
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'y = "hello world!"\n'
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert "unicode('hello world!')" == astunparse.unparse(tree)

# Generated at 2022-06-23 23:16:18.995581
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()

    # Test normal string
    tree_before = ast.parse('x = str(4)')
    transformer.visit(tree_before)
    assert ast.dump(tree_before) == ast.dump(ast.parse('x = unicode(4)'))

    # Test a string in the parameters of a method
    tree_before = ast.parse('x.str(4)')
    transformer.visit(tree_before)
    assert ast.dump(tree_before) == ast.dump(ast.parse('x.unicode(4)'))

    # Test a string in the parameters of a method
    tree_before = ast.parse('x.str(4, str=1)')
    transformer.visit(tree_before)

# Generated at 2022-06-23 23:16:23.468506
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .utils import generate_dumped_ast, compare_ast
    from . import parse

    tree_before = generate_dumped_ast(parse('a = str()'))
    tree_after = generate_dumped_ast(parse('a = unicode()'))
    _, tree_changed, _ = StringTypesTransformer.transform(tree_before)

    assert tree_changed == True
    assert compare_ast(tree_before, tree_after) == True



# Generated at 2022-06-23 23:16:24.084279
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:16:29.887059
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    e = ast.parse('str', mode='eval')
    result = StringTypesTransformer.transform(e)
    correct_tree = ast.parse('unicode', mode='eval')
    assert result.tree == correct_tree
    assert result.tree_changed
    assert result.messages == []

    s = ast.parse('print(str(3))')
    result = StringTypesTransformer.transform(s)
    correct_tree = ast.parse('print(unicode(3))')
    assert result.tree == correct_tree
    assert result.tree_changed
    assert result.messages == []

# Generated at 2022-06-23 23:16:34.605518
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Test simple case with 3 in the code.
    """

    input_code = "a = str('string')"
    expected_output = "a = unicode('string')"

    # Run the test
    result = StringTypesTransformer.transform(ast.parse(input_code))
    output = astunparse.unparse(result.node)
    assert output == expected_output

# Generated at 2022-06-23 23:16:37.747182
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    """Test constructor of class StringTypesTransformer.
    """ 

    # Arrange
    stringTYPES_transformer = StringTypesTransformer()
  
    # Act

    # Assert
    assert stringTYPES_transformer is not None


# Generated at 2022-06-23 23:16:45.152527
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()

    tree = ast.parse('str(1)')
    expected = ast.parse('unicode(1)')
    assert transformer.transform(tree) == expected

    tree = ast.parse('a = str(1)')
    expected = ast.parse('a = unicode(1)')
    assert transformer.transform(tree) == expected

    tree = ast.parse('a = b.str(1)')
    expected = ast.parse('a = b.unicode(1)')
    assert transformer.transform(tree) == expected

# Generated at 2022-06-23 23:16:46.074061
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer
    return True

# Generated at 2022-06-23 23:16:48.520821
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
# Python 2.7 code
s = str('test string')
"""
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)
    source = astunparse.unparse(tree)

    assert source == """\
s = unicode('test string')
"""

# Generated at 2022-06-23 23:16:51.379628
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    str
    """

    tree = ast.parse(code)
    fixed_tree = StringTypesTransformer.transform(tree)
    fixed_code = astunparse.unparse(fixed_tree)

    assert fixed_code == """
unicode
"""

# Generated at 2022-06-23 23:16:55.888795
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = "abc" + str(1)')
    t = StringTypesTransformer()
    result = t.transform(tree)
    assert isinstance(result, TransformationResult)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree.body[0].value.left.s == 'abc'
    assert result.tree.body[0].value.right.func.id == 'unicode'

# Generated at 2022-06-23 23:17:01.719205
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('foo = str(23)')
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='foo', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=23)], keywords=[], starargs=None, kwargs=None))])"



# Generated at 2022-06-23 23:17:07.570954
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    source = """
from typing import List

lst: List[str]
"""

    expected = """
from typing import List

lst: List[unicode]
"""

    tree = ast.parse(textwrap.dedent(source))
    xformer = StringTypesTransformer()

    result = xformer.transform(tree)
    assert astor.to_source(result.tree) == expected

# Generated at 2022-06-23 23:17:08.191760
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:17:13.645264
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    with open("tests/fixtures/stringtypes.py") as f:
        tree = ast.parse(f.read())
        t.visit(tree)

    names = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and node.id == 'unicode':
            names.append(node)
    assert len(names) == 2

# Generated at 2022-06-23 23:17:18.139796
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_str = 'str1 = "Hello"\nstr2 = str(123)'
    test_tree = ast.parse(test_str)
    result = StringTypesTransformer.transform(test_tree)

    assert 'unicode' in result.tree.body[0].value.s
    assert 'unicode' in result.tree.body[1].value.args[0].id



# Generated at 2022-06-23 23:17:18.552477
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:17:21.343935
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    tree = astor.parse("str(1) + '2'")
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == "unicode(1) + u'2'"
    assert result.tree_changed == True

# Generated at 2022-06-23 23:17:30.968081
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_test_str = """
    def test_str():
        return "test str"
    """
    assert StringTypesTransformer.transform(ast.parse(class_test_str)) == \
        TransformationResult(ast.parse("""
    def test_str():
        return "test str"
    """), True, [])

    class_test_str_2 = """
    def test_str():
        return "test str"
        a = str(123)
    """
    assert StringTypesTransformer.transform(ast.parse(class_test_str_2)) == \
        TransformationResult(ast.parse("""
    def test_str():
        return "test str"
        a = unicode(123)
    """), True, [])


# Generated at 2022-06-23 23:17:35.683713
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..loader import loads
    from ..dumper import dump_ast

    source = "str('str')"
    tree = loads(source, ignore_errors=True)
    tree = StringTypesTransformer.transform(tree)
    assert dump_ast(tree) == "unicode('str')"


# Generated at 2022-06-23 23:17:41.114636
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .sample_ast import string_types_sample_ast

    tree = ast.parse(string_types_sample_ast)
    res = StringTypesTransformer.transform(tree)

    assert res.tree_changed
    assert len(res.nodes_changed) == 2
    assert res.tree.body[0].value.s == 'foobar'
    assert res.tree.body[1].keyword.arg == 'foobar'

# Generated at 2022-06-23 23:17:45.524531
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import update_ast
    source = '''
    x = str()
    '''
    expected = '''
    x = unicode()
    '''
    tree = ast.parse(source)
    new_tree = update_ast(tree, StringTypesTransformer)
    assert ast.dump(new_tree, include_attributes=True) == ast.dump(ast.parse(expected), include_attributes=True)

# Generated at 2022-06-23 23:17:55.919176
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test StringTypesTransformer.

    """
    # Test on code with only one str variable
    code = ''' 
    x = str(1) 
    ''' 
    tree = ast.parse(code)
    new_ast_tree, changed = StringTypesTransformer().transform(tree)
    assert changed
    assert type(new_ast_tree) == ast.Module
    ast.fix_missing_locations(new_ast_tree)
    code = compile(new_ast_tree,'<string>','exec')
    exec(code)
    assert type(x) == unicode

    # Test on code with two str variables
    code = '''
    x = str(1) 
    y = str(2) 
    ''' 
    tree = ast.parse(code)
    new_ast_tree,

# Generated at 2022-06-23 23:18:04.031265
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Unit test: initialize
    _StringTypesTransformer = StringTypesTransformer()

    # Unit test: is_target_version
    assert _StringTypesTransformer.is_target_version((2, 7)) == True
    assert _StringTypesTransformer.is_target_version((3, 8)) == False

    # Unit test: transform
    import astor
    input_code = "print(str(100))"
    tree = ast.parse(input_code)
    _StringTypesTransformer.transform(tree)
    output_code = astor.to_source(tree)
    assert output_code == "print(unicode(100))\n"

# Generated at 2022-06-23 23:18:13.845691
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:18:16.479292
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Test(StringTypesTransformer):
        def test(self, tree):
            self.transform(tree)
        pass
    Test().test(ast.parse("str"))
    Test().test(ast.parse("str.strip()"))

# Generated at 2022-06-23 23:18:20.950925
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_code = """def foo():
        mystr = str('universe')
        print('hello ' + mystr)
        """

    expected_code = """def foo():
        mystr = unicode('universe')
        print('hello ' + mystr)
        """

    result = StringTypesTransformer.transform(input_code)
    print(result.tree)
    assert expected_code == result.code

# Generated at 2022-06-23 23:18:28.148994
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    # Given the following Python 3 code:      
    input_code = """
        def func(arg):
            return str(arg)
    """
    # When I use StringTypesTransformer to transform it,
    result = StringTypesTransformer.transform(ast.parse(input_code))
    # Then I get the following Python 2 code:
    expected_code = """
        def func(arg):
            return unicode(arg)
    """
    assert result.code == expected_code

# Generated at 2022-06-23 23:18:29.111340
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:18:35.211845
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(1)')
    transformed_tree, _, _ = StringTypesTransformer.transform(tree)
    assert ast.dump(transformed_tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))])"
    print(ast.dump(transformed_tree))

# Generated at 2022-06-23 23:18:43.296690
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Sample code
    source = '''
        str = 'Python 2.7'
    '''
    expected = '''
        unicode = 'Python 2.7'
    '''

    # Load ASTs & parse code
    tree = ast.parse(source)

    # Transform tree and process result
    result = StringTypesTransformer.transform(tree)
    tree = result.tree
    tree_changed = result.tree_changed
    errors = result.errors

    # Convert back to code and compare to original
    code = compile(tree, '', 'exec')
    source = source.strip()
    transformed = source.strip()

    assert code.co_code != expected
    assert tree_changed == False
    assert errors == []

# Generated at 2022-06-23 23:18:49.495038
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    s = str()
    """)
    res = ast.dump(StringTypesTransformer.transform(tree).tree, True)
    assert res == "Module(body=[Assign(targets=[Name(id='s', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-23 23:18:50.546271
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-23 23:18:57.781566
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_2to3 import parse
    from .misc import AstOutput

    tree_src = parse('str')
    expected_output = AstOutput(tree_src)
    tree, changed = StringTypesTransformer.transform(tree_src)
    output = AstOutput(tree)

    assert changed
    assert output == expected_output

    tree_src = parse('""')
    expected_output = AstOutput(tree_src)
    tree, changed = StringTypesTransformer.transform(tree_src)
    output = AstOutput(tree)

    assert not changed
    assert output == expected_output

# Generated at 2022-06-23 23:19:06.064306
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse
    from .reindent import ReindentTransformer
    from .as_import import AsImportTransformer
    from .dynamic_attributes import DynamicAttributesTransformer
    from ..fixes.bytearray_encoding import ByteArrayEncodingFixer
    from ..fixes.unicode_in_transformation import UnicodeInTransformationFixer
    from ..fixes.builtin_type_identifiers import BuiltinTypeIdentifiersFixer

    source = r'''
s = str()
'''

    tree = parse(source)
    tree = StringTypesTransformer.transform(tree)
    tree = ReindentTransformer.transform(tree)
    tree = AsImportTransformer.transform(tree)
    tree = DynamicAttributesTransformer.transform(tree)
    tree = ByteArrayEncodingFixer.transform(tree)

# Generated at 2022-06-23 23:19:07.608463
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformed_code


# Generated at 2022-06-23 23:19:12.231158
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_str = "str('')"
    tree = ast.parse(code_str)
    assert code_str == astunparse.unparse(tree)
    tree_changed, _, _ = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert astunparse.unparse(tree) == "unicode('')"

# Generated at 2022-06-23 23:19:19.129678
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("from builtins import str")
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.warnings == []
    assert result.tree._fields == ('body',)
    assert result.tree.body[0]._fields == ('names',)
    assert result.tree.body[0].names[0]._fields == ('name', 'asname')
    assert result.tree.body[0].names[0].name._fields == ('id',)
    assert result.tree.body[0].names[0].name.id == 'unicode'

# Generated at 2022-06-23 23:19:25.473212
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for `StringTypesTransformer` class.

    """
    
    # Before transformation
    test_source = """
        import django

        def test():
            a = str()
            b = "string"
            c = str(b)
    """
    test_tree = ast.parse(test_source)

    # During transformation
    transformer = StringTypesTransformer()
    transformed_tree, transformed = transformer.transform(test_tree)

    # After transformation
    expected_source = """
        import django

        def test():
            a = unicode()
            b = "string"
            c = unicode(b)
    """
    expected_tree = ast.parse(expected_source)

    # Compare the result.
    assert ast.dump(transformed_tree) == ast.dump(expected_tree)


# Generated at 2022-06-23 23:19:35.177424
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = '1234'\nb = str(a)")
    t = StringTypesTransformer()
    res = t.transform(tree)
    assert(str(res.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Str(s='1234')), Assign(targets=[Name(id='b', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))])")
    assert(res.changed)
    assert(res.warnings == [])

# Test that transformer changes expected number of nodes

# Generated at 2022-06-23 23:19:40.130570
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import transform
    from ..utils.tree import print_tree

    input = """
    import sys
    from sklearn.decomposition import PCA
    def f(x: str):
        pass
    """

    output = """
    import sys
    from sklearn.decomposition import PCA
    def f(x: unicode):
        pass
    """
    print_tree(transform(input))
    assert transform(input) == output

# Generated at 2022-06-23 23:19:43.000993
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as typed_ast
    import astunparse
    import sys

    code = """
    def test(x):
        print(str(x))
    """

    tree = typed_ast.parse(code)
    new_tree, tree_changed, info = StringTypesTransformer.transform(tree)
    assert tree_changed

# Generated at 2022-06-23 23:19:45.194876
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import Source
    from ..utils.snippet import to_functional_snippet
    from ..utils.visitor import Python2to3SchedulingVisitor


# Generated at 2022-06-23 23:19:52.222076
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    
    """
    # Define code to transform
    code = "def f(a: str)\n\treturn a"

    # Define expected transformed code
    expected_code = "def f(a: unicode)\n\treturn a"

    # Perform transformation
    actual_code = transform_code(code, StringTypesTransformer)

    # Assert transformed code is as expected
    assert actual_code == expected_code

# Generated at 2022-06-23 23:19:56.508411
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class DummyTransformer(BaseTransformer):
        def transform_Name(self, node):
            return node
    transformer = DummyTransformer()
    tree = ast.parse('str')
    res = transformer.visit(tree)
    assert(res.changed == True)
    assert(res.result.body[0].value.id == 'unicode')

# Generated at 2022-06-23 23:20:03.986523
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    import astor

    with open("tests/resources/string_types.py", "r") as f:
        file_contents = f.read()

    if PY2:
        new_file_contents = file_contents.replace("str", "unicode")
    else:
        new_file_contents = file_contents

    tree = source_to_ast(file_contents)
    print_tree(tree)

    transformed, did_change, _ = StringTypesTransformer.transform(tree)
    print("Changed: " + str(did_change))
    print(astor.to_source(transformed))

    assert(not did_change)

# Generated at 2022-06-23 23:20:12.634800
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(
        'var = "a string"\n' +
        'var2 = str(var)\n' +
        'var3 = "a str"\n'
    )

    tree_changed, new_tree, messages = \
        StringTypesTransformer.transform(tree)

    assert tree_changed == True
    assert messages == [
        'Replaced <StringTypesTransformer>: str -> unicode',
        'Replaced <StringTypesTransformer>: str -> unicode'
    ]
    assert ast.dump(BitEdgeTransformer.transform(tree)[1]) == ast.dump(new_tree)

# Generated at 2022-06-23 23:20:22.446230
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        import sys
        import os
        import string
        import sys.path

        def f(x):
            return str(x) + str(x)
    """

    expected_code = """
        import sys
        import os
        import string
        import sys.path

        def f(x):
            return unicode(x) + unicode(x)
    """
    tree = ast.parse(textwrap.dedent(code))
    transformed_tree = StringTypesTransformer.transform(tree).tree
    transformed_code = astor.to_source(transformed_tree)
    assert transformed_code == textwrap.dedent(expected_code)
