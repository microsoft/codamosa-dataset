

# Generated at 2022-06-23 23:10:18.155107
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_helpers import get_ast
    tree = get_ast('print(str(5))')
    print(ast.dump(tree))
    trf = StringTypesTransformer()
    trf.transform(tree)
    print(ast.dump(tree))
    assert ast.dump(tree) == u"Module(body=[Print(values=[Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=5)], keywords=[], starargs=None, kwargs=None)], nl=True)])"

# Generated at 2022-06-23 23:10:27.238810
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""def func(s):
    return str(s)""")

    # Call constructor of class StringTypesTransformer
    stri = StringTypesTransformer()

    # Call function transform of class StringTypesTransformer
    result = stri.transform(tree)

    # Check result
    assert(result.tree == ast.parse("""def func(s):
    return unicode(s)"""))
    assert(result.tree_changed == True)
    assert(result.log == [])

    # Check that this transformator is targetted for version 2.7 and 2.6
    target = list(StringTypesTransformer.target)
    assert(target == [2, 7])

# Generated at 2022-06-23 23:10:32.394067
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "str()"
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    transformed_tree, tree_changed = transformer.transform(tree)

    assert tree_changed == True
    tree_str = ast.dump(transformed_tree)
    assert tree_str == "Module(body=[Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"

# Generated at 2022-06-23 23:10:36.186200
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("Test for StringTypesTransformer")
    code = "a = ['a', 'b', 'c']"
    tree = ast.parse(code)
    transformer = StringTypesTransformer(2.7)
    tree = transformer.transform(tree)

# Generated at 2022-06-23 23:10:42.309748
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import generate_valid_python_script, compare_asts

    parser = ast.PyCF_ONLY_AST
    tree = ast.parse(generate_valid_python_script('str'), 'test', parser)
    tree_changed = StringTypesTransformer.transform(tree).tree_changed
    assert tree_changed == True
    tree = ast.parse(generate_valid_python_script('unicode'), 'test', parser)
    tree_changed = StringTypesTransformer.transform(tree).tree_changed
    assert tree_changed == False


# Generated at 2022-06-23 23:10:47.621504
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test case for StringTypesTransformer."""
    test_code = """
x = str()
"""
    ast_tree = parser.parse(test_code)
    ast_tree = StringTypesTransformer.transform(ast_tree)
    assert ast.dump(ast_tree) == \
    "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"

# Generated at 2022-06-23 23:10:49.649418
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    #Act
    a = StringTypesTransformer()

    #Assert
    assert a

# Generated at 2022-06-23 23:10:59.423789
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    from ..utils.tree import find
    from ..utils.test_utils import transform

    node = ast.Name(id='str', ctx=ast.Load())
    assert isinstance(node, ast.Name)
    assert isinstance(node.ctx, ast.expr_context)
    assert node.id == 'str'

    # Test usage of decorator @classmethod
    tree = StringTypesTransformer.transform(node)

    assert isinstance(tree, ast.Name)
    assert isinstance(tree.ctx, ast.expr_context)
    assert tree.id == 'unicode'

    # Test usage of decorator @transform
    tree = transform(node, StringTypesTransformer)

    assert isinstance(tree, ast.Name)
    assert isinstance(tree.ctx, ast.expr_context)

# Generated at 2022-06-23 23:11:00.260027
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert(str(StringTypesTransformer) == "StringTypesTransformer")

# Generated at 2022-06-23 23:11:06.922697
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    from ..utils.source import source_to_unicode, source_to_ast

    source = source_to_unicode("""
    s = str("Hello World")
    """)

    old_tree = source_to_ast(source)
    new_tree = StringTypesTransformer.transform(old_tree).new_tree
    generated_source = ast.unparse(new_tree, encoding="utf-8")
    generated_source = textwrap.dedent(generated_source)

    expected_source = textwrap.dedent("""
    s = unicode("Hello World")
    """)

    assert generated_source == expected_source

# Generated at 2022-06-23 23:11:09.219075
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(1);')
    expected_tree = ast.parse('a = unicode(1);')
    xformer = StringTypesTransformer()
    result = xformer.transform(tree)
    assert result.tree == expected_tree

# Generated at 2022-06-23 23:11:14.935586
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = 'name = "foo"'

    # When
    tree = ast.parse(code)
    tree_transformed = StringTypesTransformer.transform(tree)

    # Then
    assert tree_transformed.tree.body[0].value.s == u'foo'
    assert tree_transformed.tree_changed is True

# Generated at 2022-06-23 23:11:21.629723
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str = 'str'")
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='str', ctx=Store())], value=Str(s='str'))])"
    checker = StringTypesTransformer()
    res = checker.transform(tree)
    assert ast.dump(res.tree) == "Module(body=[Assign(targets=[Name(id='unicode', ctx=Store())], value=Str(s='str'))])"

# Generated at 2022-06-23 23:11:27.203023
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    import textwrap

    source = textwrap.dedent("""
    def a(b):
        c = str()
        return d
    """)
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert astunparse.unparse(new_tree.tree).strip() == textwrap.dedent("""
    def a(b):
        c = unicode()
        return d
    """).strip()
    assert new_tree.tree_changed
    assert new_tree.new_imports == []

# Generated at 2022-06-23 23:11:38.008551
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    m = ast.Module([
        ast.FunctionDef(
            'f',
            ast.arguments([], None, None, []),
            [],
            [],
            ast.Name('str'))
    ])

    # Transpile
    result = StringTypesTransformer.transform(m)

    # Ensure the result is what we expect
    assert isinstance(result.tree, ast.Module)
    assert len(result.tree.body) == 1
    assert isinstance(result.tree.body[0], ast.FunctionDef)
    assert len(result.tree.body[0].body) == 1
    assert isinstance(result.tree.body[0].body[0], ast.Name)
    assert result.tree.body[0].body[0].id == 'unicode'

    # Ensure the test tool thinks it is equal

# Generated at 2022-06-23 23:11:44.426053
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    import typed_ast.ast3 as ast
    from ..utils.source import source_to_tree
    from ..utils.tree import to_source
    from .base import BaseTransformer

    class DummyTransformer(BaseTransformer):
        @classmethod
        def transform(cls, tree):
            return TransformationResult(tree, False, [])

    dummy_transformer = DummyTransformer()

    # Act
    transformer = StringTypesTransformer(pre=[dummy_transformer])

    # Assert
    assert transformer.pre == [dummy_transformer]


# Generated at 2022-06-23 23:11:45.079684
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:11:46.150221
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    print(t)

# Generated at 2022-06-23 23:11:52.009825
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Code Snippet
    code = 'def function(string: str):\n    pass\n'
    
    # Parse code into ast
    module_node = ast.parse(code)

    # Apply the StringTypesTransformer
    new_code = StringTypesTransformer.run(code)

    assert new_code == "def function(string: unicode):\n    pass\n"

# Generated at 2022-06-23 23:11:58.532457
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from typed_ast import ast3 as ast
    load = ast.Name(id = 'load', ctx = ast.Load())
    call = ast.Call(func = load, 
                    args = [ast.Name(id = 'string', ctx = ast.Load())], 
                    keywords = [])
    assign = ast.Assign(targets = [ast.Name(id = 'x', ctx = ast.Store())], value = call)
    expr = ast.Expr(value = assign)
    module = ast.Module(body = [expr])
    print(astor.to_source(module))

    t = StringTypesTransformer()
    module = t.visit(module)
    print(astor.to_source(module))

# Generated at 2022-06-23 23:12:04.347484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Create AST for test
    with open('tests/fixtures/code_examples/test_StringTypesTransformer.py') as f:
        tree = ast.parse(f.read())

    # Transform AST
    result = StringTypesTransformer.transform(tree)
    assert not result.changed
    assert result.messages == []

    # Check that all expected changes have been made
    assert ast.dump(tree) == ast.dump(result.tree)

# Generated at 2022-06-23 23:12:09.391149
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    import os
    import re
    import sys

    # Do nothing if we don't have desired modules
    try:
        import json
    except ImportError:
        print('Module not found')
        raise
    else:
        # Do something but not too much
        print('Json module found')
        print(str(42))

    # Do everything if we have desired modules
    try:
        from json import loads
    except ImportError:
        print('Module not found')
        raise
    else:
        # Do something very much
        print('Json module found')
        print(str(42))
    """

    transformer = StringTypesTransformer()
    tree = ast.parse(code)
    new_tree = transformer.transform(tree)
    print(new_tree)

# Generated at 2022-06-23 23:12:09.982325
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:12:19.654381
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Code to be tested
    string_types_transformer = StringTypesTransformer()

    # Define test strings
    str1 = 'str()'
    str2 = 'isinstance(obj, str)'
    str3 = 'str, unicode = "str", "unicode"'
    str4 = 'import str'
    str5 = 'from str import str as newStr'
    str6 = 'from str import unicode as newUnicode'
    str7 = 'from str import str, unicode'
    str8 = 'from str import str as newStr, unicode as newUnicode'
    str9 = 'from str import str, unicode as newUnicode'
    str10 = 'from str import str as newStr, unicode'
    str11 = '''from str import (str, unicode)'''
   

# Generated at 2022-06-23 23:12:22.742465
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def test_transformation():
        """
        Test that it can transform a function definition correctly.
        """

# Generated at 2022-06-23 23:12:29.337033
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import get_AST

    # Should not change
    src = '''
    class SomeClass(str):
        pass
    '''
    tree = get_AST(src)
    StringTypesTransformer.transform(tree)
    assert src == tree.body[0].bases[0].id

    # Should replace
    src = '''
    class SomeClass(str):
        pass
    '''
    tree = get_AST(src)
    StringTypesTransformer.transform(tree)
    assert src == str(tree.body[0].bases[0].id)

# Generated at 2022-06-23 23:12:31.427194
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for constructor
    transformer = StringTypesTransformer()
    assert transformer.__class__.__name__ == 'StringTypesTransformer'


# Generated at 2022-06-23 23:12:35.810937
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    from typed_ast import ast3 as ast
    from transformer.typing import StringTypesTransformer as STT
    node = ast.Name(id="str", ctx=typed_ast.ast3.Load())
    node2 = STT.transform(node)
    assert node2.tree.id == "unicode"

# Generated at 2022-06-23 23:12:46.091075
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Create an AST
    module = ast.parse("x = 'hello'")

    # Transform AST
    res = StringTypesTransformer.transform(module)

    # Check result
    if not isinstance(res.tree, ast.AST):
        raise AssertionError("Expected ast.AST as result of transformation")

    if not isinstance(res.tree.body[0], ast.Assign):
        raise AssertionError("Expected ast.Assign as result of transformation")

    if not isinstance(res.tree.body[0].value, ast.Str):
        raise AssertionError("Expected ast.Str as result of transformation")

    if res.tree.body[0].value.s != "'hello'":
        raise AssertionError("Expected string 'hello' as result of transformation")


# Generated at 2022-06-23 23:12:46.989988
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:48.860422
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_string_types_transformations

    assert_string_types_transformations(StringTypesTransformer())

# Generated at 2022-06-23 23:12:50.437760
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 23:12:55.251183
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
a = str("hello")
b = str("world")
    """

    expected_transformed_code = """
a = unicode("hello")
b = unicode("world")
    """
    tree = ast.parse(code)
    tree_changed = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == expected_transformed_code

# Generated at 2022-06-23 23:13:02.074915
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    code = """\
    x = str
    """
    tree = ast.parse(code)
    tree = StringTypesTransformer().visit(tree)
    assert ast.dump(tree) == textwrap.dedent("""\
    Module(body=[
        Assign(targets=[Name(id='x', ctx=Store())], value=Name(id='unicode', ctx=Load()))
    ])
    """)



# Generated at 2022-06-23 23:13:04.996830
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    dsl = """
    def foo(x):
        return str(x)
    """
    python_ast = ast.parse(dsl)
    transformed_ast = StringTypesTransformer.transform(python_ast)
    assert transformed_ast.tree.body[0].body.value.func.id == "unicode"

# Generated at 2022-06-23 23:13:08.252459
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name(id='str')
    result = StringTypesTransformer.transform(node)
    assert result.tree == ast.Name(id='unicode')
    assert not result.errors

# Generated at 2022-06-23 23:13:10.217548
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # without argument
    transformer = StringTypesTransformer()

    assert transformer.target == (2, 7)



# Generated at 2022-06-23 23:13:11.888861
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """No runtime test as transformer only replaces `str` with `unicode`."""
    pass

# Generated at 2022-06-23 23:13:17.489897
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Test(object):
        def string_types_transformer(self, tree: ast.AST) -> TransformationResult:
            return StringTypesTransformer.transform(tree)

    t = Test()
    test = ast.parse("str('')").body[0]
    assert isinstance(t.string_types_transformer(test), TransformationResult)

# Generated at 2022-06-23 23:13:20.445868
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.ast import parse_string_to_ast_node


# Generated at 2022-06-23 23:13:25.624882
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer(2, 7)

    # Create tree
    tree = ast.parse("x = str(y)")

    # Call transform
    string_types_transformer.transform(tree)

    # Assert result
    assert str(tree) == "x = unicode(y)"


# Generated at 2022-06-23 23:13:33.011419
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test if code can be transformed by StringTypesTransformer.
    """

    from typing import List, Dict, Any

    code_str = r"""
    s = 'abc'
    x = str(1)
    y = (1, 2)
    """

    # Parse
    tree = ast.parse(code_str)

    # Apply transformation
    result = StringTypesTransformer.transform(tree)
    resulting_code = compile(result.tree, filename="<ast>", mode="exec")
    exec(resulting_code)

    # Check result
    y: List[int] = result.globals['y']
    assert y == [1, 2]

# Generated at 2022-06-23 23:13:40.460989
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import TransformedSource
    from ..utils.source import Source

    source = Source.from_string('x = str(y)')
    expected = Source.from_string('x = unicode(y)')
    tree = ast.parse(source.string)
    t = StringTypesTransformer()
    new_tree, tree_changed, messages = t.transform(tree)
    assert tree_changed == True
    assert new_tree != tree
    transformed_source = TransformedSource(new_tree, messages, source)
    assert transformed_source.string == expected.string

# Unit tests for method transform() of class StringTypesTransformer

# Generated at 2022-06-23 23:13:42.849793
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_name = 'StringTypesTransformer'
    # Unit test for constructor
    instance = globals()[class_name]()
    assert instance.__class__.__name__ == class_name


# Generated at 2022-06-23 23:13:43.545616
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:13:46.934855
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    tree = source_to_tree('''
        def my_function():
            return "my string"
    ''')

    tree = StringTypesTransformer.transform(tree)

    assert tree == source_to_tree('''
        def my_function():
            return u"my string"
    ''')



# Generated at 2022-06-23 23:13:51.386303
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
    str
    ''')

    tree = ast.parse(source, mode='exec')
    assert StringTypesTransformer.transform(tree).tree.body[0].id == 'unicode'

# Generated at 2022-06-23 23:13:51.944785
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
   pass

# Generated at 2022-06-23 23:14:01.682979
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Just to show how to use the StringTypesTransformer.
    """
    import astor
    from typing import List

    # Make a script from some Python code
    script = astor.parse_file(__file__)

    # Remove comments
    script = StripCommentsTransformer.transform(script)
    # Transform to Python ast v2
    script = Python2Transformer.transform(script)
    # Replace "int" with "long"
    script = LongIntTransformer.transform(script)
    # Replace "str" with "unicode"
    script = StringTypesTransformer.transform(script)
    # Transform to Python ast v3
    script = Python3Transformer.transform(script)
    # So we can see Python 2 code again
    script = astor.to_source(script, True).lstrip()
    print(script)

# Generated at 2022-06-23 23:14:03.509990
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = str('abc')", mode='exec')
    result = StringTypesTransformer.transform(tree)
    assert result.changed
    assert result.tree.body[0].value.func.id == 'unicode'


# Generated at 2022-06-23 23:14:12.657178
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..utils.tests import build_and_run_transformer_test

    import_node = ast.Import(names=[ast.alias(name='unicode', asname=None)])
    assign_node = ast.Assign(targets=[ast.Name(id='s', ctx=ast.Store())],
                             value=ast.Call(func=ast.Name(id='unicode',
                                                          ctx=ast.Load()),
                                            args=[ast.Str(s='Hello')],
                                            keywords=[]))
    mod_node = ast.Module(body=[import_node, assign_node])
    expected_node = mod_node
    build_and_run_transformer_test(mod_node, expected_node, [StringTypesTransformer])

# Generated at 2022-06-23 23:14:17.432809
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast('''def f():
    return str()
    ''')
    print(ast.dump(tree))
    tree, changed = StringTypesTransformer.transform(tree)
    print(ast.dump(tree))

# Generated at 2022-06-23 23:14:19.004218
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    _test_StringTypesTransformer(StringTypesTransformer)



# Generated at 2022-06-23 23:14:28.006071
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform_file
    import os
    this_dir = os.path.dirname(__file__)

    input_file = os.path.join(this_dir, '../', 'sample/python2/string_types.py')
    result_file = os.path.join(this_dir, '../', 'sample/python2/string_types_result.py')

    with open(input_file) as f1, open(result_file) as f2:
        dict_result = eval(f2.read())
        dict1 = transform_file(f1, StringTypesTransformer, print_result=False).__dict__
        dict1.pop('tree')
        dict1.pop('tree_changed')
        dict_sorted = {}
        for key, value in dict1.items():
            dict_s

# Generated at 2022-06-23 23:14:31.510653
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.parse('str.format()')
    result = StringTypesTransformer.transform(node)
    assert result.tree.body[0].value.func.value.id == 'unicode'
    assert not result.tree_changed
    assert len(result.messages) == 0

# Generated at 2022-06-23 23:14:35.097201
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    code = ast.parse("x = str(1)")
    transformed, tree_changed, messages = StringTypesTransformer.transform(code)

    assert tree_changed
    assert transformed.body[0].value.func.id == 'unicode'

# Generated at 2022-06-23 23:14:40.420237
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_string = """
    def test_function(param: str) -> str:
        return str(param)"""
    test_ast = ast.parse(test_string)
    transformer = StringTypesTransformer()
    result = transformer.transform(test_ast)
    assert len(result.warnings) == 0
    assert result.tree_changed == True

# Generated at 2022-06-23 23:14:42.530141
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = str')
    new_tree = StringTypesTransformer().visit(tree)
    # Check that the result is correct
    assert ast.dump(new_tree) == ast.dump(ast.parse('x = unicode'))

# Generated at 2022-06-23 23:14:51.844862
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = "a = 'Hello World'"

    # we compile the code to ensure that it is valid python code
    mod = compile(s, "<test>", "exec")

    tree = ast.parse(s)

    result = StringTypesTransformer.transform(tree)

    # verify that tree has changed
    assert result.tree != tree

    # verify that the code of the new tree is valid
    new_mod = compile(str(result.tree), "<test>", "exec")

    # verify that the two trees are different
    str_new_mod = str(result.tree)
    str_mod = str(tree)
    assert str_mod != str_new_mod

    # verify that the two modules are the same
    assert mod.co_code == new_mod.co_code

# Generated at 2022-06-23 23:14:52.779354
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert(StringTypesTransformer)


# Generated at 2022-06-23 23:14:55.189970
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_helper import ast_to_str
    from typed_ast import ast3

# Generated at 2022-06-23 23:15:03.829400
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('def abc(): return str')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.log == []

    tree = ast.parse('def abc(): return str(1)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.log == []

    tree = ast.parse('def abc(): return unicode(1)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == False
    assert result.log == []


if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:15:04.828100
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.target == (2, 7)

# Generated at 2022-06-23 23:15:14.648446
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Build AST
    tree = ast.Module(body=[
        ast.FunctionDef(
            name='foo',
            args=ast.arguments(
                args=[
                    ast.arg(arg='a', annotation=None)
                ],
                defaults=[],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]
            ),
            body=[
                ast.Return(value=ast.Str(s="test"))
            ],
            decorator_list=[],
            returns=ast.Name(id='str', ctx=ast.Load())
        )
    ])
    # Apply transformation
    results = StringTypesTransformer.transform(tree)
    # Test if transformation was correctly applied

# Generated at 2022-06-23 23:15:20.374090
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def test_code_gen(tree):
        from ..utils.codegen import to_source
        return to_source(tree)

    code = """a = str('b')"""
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)['tree']
    assert test_code_gen(tree) == 'a = unicode(\'b\')\n'


# Generated at 2022-06-23 23:15:20.807396
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:15:25.913044
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import Transformation

    data = '''
if __name__ == "__main__":
    print('Hello')
    '''
    expected = '''
if __name__ == "__main__":
    print(u'Hello')
    '''
    trf = Transformation.from_string(2, 7, data)
    trf.apply(StringTypesTransformer)
    actual = str(trf.tree)
    assert actual == expected

# Generated at 2022-06-23 23:15:33.016281
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..transforms.string_types import StringTypesTransformer
    from ..transforms.mock_builtins import MockBuiltinsTransformer

    code = '''
    class Test(object):
        def func(self):
            return str()
    '''.strip()

    tree = ast.parse(code)
    tree = MockBuiltinsTransformer.transform(tree)
    tree = StringTypesTransformer.transform(tree)
    assert ast_to_str(tree) == ast_to_str(ast.parse('''
    class Test(object):
        def func(self):
            return unicode()
    '''.strip()))

# Generated at 2022-06-23 23:15:41.550321
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class TestClass:
        def method(self):
            pass
        @staticmethod
        def staticmethod():
            pass
        @classmethod
        def classmethod(cls):
            pass
        def annotated_method(self, param: str):
            pass

    module = ast.parse(dedent(inspect.getsource(TestClass)))
    print(ast.dump(module))
    tree = module

    tree = StringTypesTransformer.transform(tree).tree
    print(ast.dump(tree))
    assert ast.dump(tree) == dedent("""\
    <_ast.Module object at 0x7f8cce6d70b8>
    """)

# Generated at 2022-06-23 23:15:49.590622
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_base import generate_test_ast
    from ..utils.tree import find_all, to_source

    test_tree = generate_test_ast()

    # Test the str -> unicode replacement
    str_type_nodes = find_all(test_tree, ast.Name)
    assert any('str' in to_source(node) for node in str_type_nodes)

    StringTypesTransformer.transform(test_tree)

    assert not any('str' in to_source(node) for node in str_type_nodes)
    assert any('unicode' in to_source(node) for node in str_type_nodes)

# Generated at 2022-06-23 23:15:52.926334
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

    code = "foo = str('')"
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    output = astunparse.unparse(tree)
    assert output == "foo = unicode('')"

# Generated at 2022-06-23 23:15:59.611737
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    exec("""
    def func(a, b, c):
        val = 1
        return b
    """, {'str': str, 'unicode': str, 'int': int, 'float': float, 'complex': complex})
    stringTypesTransformer = StringTypesTransformer()
    transformedTree = stringTypesTransformer.transform(ast.parse("def func(a, b, c):\n    val = 1\n    return b"))
    code = compile(transformedTree, '', 'exec')
    mod = {'str': str, 'unicode': str, 'int': int, 'float': float, 'complex': complex}
    exec(code, {'str': str, 'unicode': str, 'int': int, 'float': float, 'complex': complex})

# Generated at 2022-06-23 23:16:04.735302
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
s = str()
"""
    expected_result = """
s = unicode()
"""
    tree = ast.parse(src)
    new_tree = StringTypesTransformer.run(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_result))


# Generated at 2022-06-23 23:16:06.839709
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def test_code(tree):
        assert tree.body[0].value.value == u'ExampleString'


# Generated at 2022-06-23 23:16:13.128023
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
str('hello')
str(2)
str(x)
'''
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    compiled_code = compile(new_tree.tree, filename='<ast>', mode='exec')
    exec(compiled_code)
    assert type(str("hello")) == unicode
    assert type(str(2)) == unicode
    assert type(str(x)) == unicode

# Generated at 2022-06-23 23:16:15.363812
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    t = '''
a = str()
b = str
'''

    t = ast.parse(t)
    t = StringTypesTransformer.transform(t)
    assert t.tree_changed
    assert 'unicode' in ast.dump(t.tree)

# Generated at 2022-06-23 23:16:19.620173
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from _ast import parse as ast_parse
    from typed_ast import ast3 as ast_types

    tree = ast_parse('str')
    tree = ast_types.fix_missing_locations(tree)

    transformer = StringTypesTransformer()
    new_tree, *_ = transformer.transform(tree)

    assert transformer.tree_changed
    assert new_tree.body[0].value.id == 'unicode'


# Generated at 2022-06-23 23:16:25.438903
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class TestTransformer(StringTypesTransformer):
        pass

    tree = ast.parse('''class TestClass:
    """Test doc"""
    def __init__(self):
        """doc"""
        self.attr = str(1)
        print(str)
        print(str())
        print(str.__add__(1, 2))
        ''')
    tree_changed, error_msgs = TestTransformer.apply(tree, {}, {})
    assert tree_changed
    assert len(error_msgs) == 0

# Generated at 2022-06-23 23:16:26.259774
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TODO: Implement tests!
    assert False

# Generated at 2022-06-23 23:16:33.820827
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # string_types.py
    #
    # a = str()
    # b = unicode()
    code = (
        "a = str()\n"
        "b = unicode()"
    )
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert tree.body[0].value.func.id == 'unicode'
    assert tree.body[1].value.func.id == 'unicode'
    assert StringTypesTransformer.transform(tree).tree_changed == False

# Generated at 2022-06-23 23:16:36.808802
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """str("Hello world!")"""
    
    expected_code = """unicode("Hello world!")"""

    # Parse code into AST
    tree = ast.parse(code)

    # Optimize the AST
    res = StringTypesTransformer.transform(tree)

    assert res.changed
    assert ast.dump(res.tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-23 23:16:43.821227
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_code = """
    x = str()
    """
    test_ast = ast.parse(test_code)
    transformer = StringTypesTransformer()
    transformed_ast, _, _ = transformer.transform(test_ast)
    assert ast.dump(test_ast) != ast.dump(transformed_ast)
    exec(compile(test_ast, "<string>", "exec"))
    exec(compile(transformed_ast, "<string>", "exec"))

# Generated at 2022-06-23 23:16:50.681382
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = ast.parse("print 'hello' + 'world'")
    tt = StringTypesTransformer.transform(tt)
    assert tt.tree_changed
    assert tt.tree.body[0].values[0].s == "hello"
    assert tt.tree.body[0].values[1].s == "world"
    assert tt.tree.body[0].values[0].s == "hello"
    assert tt.messages == []

##

# Generated at 2022-06-23 23:16:58.987209
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("Unit test for constructor of class StringTypesTransformer")
    # Case 1: normal case that there is no error
    code = "a = str()"
    expected_code = "a = unicode()"
    expected_result = True
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    transformed_code = result.get_code()
    assert expected_result == result.is_changed()
    assert transformed_code == expected_code
    print("Case 1 passed")

    # Case 2: normal case that there is no error
    code = "str()"
    expected_code = "unicode()"
    expected_result = True
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    transformed_code = result.get_code()
   

# Generated at 2022-06-23 23:17:02.686812
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import build_ast
    from ..utils.source import generate_code
    code = generate_code(build_ast("s: str = 'Hello'"))
    assert code == "s: unicode = 'Hello'"

# Generated at 2022-06-23 23:17:13.374996
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
            a = str()
            b = str(b)
            """
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    
    assert(isinstance(new_tree.tree, ast.Module))
    assert(new_tree.tree_changed)
    
    node = ast.parse('a = unicode()')
    assert(isinstance(new_tree.tree.body[0], type(node.body[0])))
    assert(new_tree.tree.body[0].value.func.id == node.body[0].value.func.id)

    node = ast.parse('b = unicode(b)')
    assert(isinstance(new_tree.tree.body[1], type(node.body[0])))

# Generated at 2022-06-23 23:17:18.801329
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .unittest_tools import should_not_change, should_raise_syntax_error

    should_not_change(StringTypesTransformer, """
s = 'this string'
""")

    should_not_change(StringTypesTransformer, """
s = b'this string'
""")

    should_not_change(StringTypesTransformer, """
s = u'this string'
""")

    should_not_change(StringTypesTransformer, """
s = r'this string'
""")

# Generated at 2022-06-23 23:17:19.854767
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    trns = StringTypesTransformer()
    assert trns.target == (2, 7)

# Generated at 2022-06-23 23:17:20.580661
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:17:27.590198
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    name_node = ast.Name('str', ast.Store())
    tree = ast.Module([
        ast.Expr(ast.Call(
            func=ast.Name('func', ast.Load()),
            args=[name_node],
            keywords=[ast.keyword(arg='arg', value=name_node)],
            starargs=name_node, kwargs=name_node,
        )),
    ])
    res = StringTypesTransformer.transform(tree)
    if res.tree_changed:
        # print(ast.dump(res.tree))
        pass
    assert res.tree_changed

# Generated at 2022-06-23 23:17:29.316142
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    obj = StringTypesTransformer()
    assert obj.target == (2,7)


# Generated at 2022-06-23 23:17:30.762080
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str')).tree_changed == True

# Generated at 2022-06-23 23:17:34.773585
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = """a = str(1)"""
    expected = """a = unicode(1)"""
    
    # When
    actual = astor.to_source(StringTypesTransformer.run(code))

    # Then
    assert expected == actual


# Generated at 2022-06-23 23:17:39.170079
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    from copy import deepcopy
    tree = ast.parse('x = str(y, encoding=\'utf-8\')')
    tree_copy = deepcopy(tree)

    result = StringTypesTransformer().transform(tree)

    assert result.tree == tree_copy
    assert result.tree_changed is True
    assert result.messages == []

# Generated at 2022-06-23 23:17:41.782161
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    
    tree = ast.parse("str()") 
    tree = StringTypesTransformer().transform(tree)
    assert astor.to_source(tree) == 'unicode()'



# Generated at 2022-06-23 23:17:46.185666
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import parse_ast, dump_tree

    source = source_to_unicode("""{'x': str(x) for x in a}
    def f(x: str):
        b: str = 'abc'
        c = str(b)
        return str
    """)

    tree = parse_ast(source)
    print(dump_tree(tree))
    StringTypesTransformer.transform(tree)
    print(dump_tree(tree))
    # Raises AssertionError(ast.dump(tree))



# Generated at 2022-06-23 23:17:51.326403
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
        def f(a: str):
            pass
    """
    expected_result = """
        def f(a: unicode):
            pass
    """
    tree = ast.parse(src)
    result = StringTypesTransformer.transform(tree)

    assert ast.dump(result.tree) == expected_result

# Generated at 2022-06-23 23:17:56.118391
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that the StringTypesTransformer does transform the tree
    as expected.
    """
    for target_version in [(2, 7)]:
        code = "str('Hello')"
        tree = ast.parse(code, target_version)
        transformed = StringTypesTransformer.transform(tree)
        assert unicode(transformed[0]) == "unicode('Hello')"

# Generated at 2022-06-23 23:18:03.092308
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import run_test_with_compat_ast
    from ..utils.tree import find

    ast_original: ast.AST = ast.Str(s='Hello')
    ast_transformed = ast.Str(s='Hello')
    ast_transformed.unicode = ast.Name(id='unicode', ctx=ast.Load())

    tree_changed, transformed_ast = run_test_with_compat_ast(StringTypesTransformer, ast_original)
    assert tree_changed 
    assert transformed_ast == ast_transformed

# Generated at 2022-06-23 23:18:07.577413
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = ast.parse('print(str(1))')
    t = StringTypesTransformer.transform(s)
    assert ast.dump(t.ast) == ast.dump(ast.parse('print(unicode(1))'))
    assert t.tree_changed, 'Expected tree to be modified'


# Generated at 2022-06-23 23:18:07.874229
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:18:14.965755
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program_code = """
    def foo( args ):
      if isinstance(args, str):
        return 'Foo'
    """
    result_code = """
    def foo( args ):
      if isinstance(args, unicode):
        return 'Foo'
    """

    tree = ast.parse(program_code)
    result_tree, tree_changed, messages = StringTypesTransformer.transform(tree)
    assert messages == []
    assert tree_changed
    result_code_obtained = astor.to_source(result_tree).strip()
    assert result_code_obtained == result_code.strip()

# Generated at 2022-06-23 23:18:18.871438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from asttools import parse

    tree = parse('foo = str()')
    tree = StringTypesTransformer.transform(tree).new_tree
    assert(parse('foo = unicode()') == tree)

    tree = parse('foo = str(42)')
    tree = StringTypesTransformer.transform(tree).new_tree
    assert(parse('foo = unicode(42)') == tree)

# Generated at 2022-06-23 23:18:23.621723
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    example = '''
        def f():
            return str('a')
    '''
    target = '''
        def f():
            return unicode('a')
    '''
    t = StringTypesTransformer.transform(ast.parse(example))
    t_ast = astor.to_source(t.tree)
    assert t_ast == target

# Generated at 2022-06-23 23:18:30.994531
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Test(metaclass=StringTypesTransformer):
        def __init__(self, x: str, y: unicode):
            self.x = x
            self.y = y

    assert Test.__annotations__['x'] == 'unicode'
    assert Test.__annotations__['y'] == 'unicode'

    t1 = Test('something', 'else')
    assert isinstance(t1.x, unicode)
    assert isinstance(t1.y, unicode)

# Generated at 2022-06-23 23:18:35.211580
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
    s = str(u"Hola")
    '''
    expected = '''
    s = unicode(u"Hola")
    '''
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    print(ast.dump(tree))
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 23:18:39.832397
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test function. 

    """
    t = StringTypesTransformer()

    ast_1 = ast.parse('''
x = "hello"
''')
    assert t.find_targets(ast_1) == [ast_1.body[0]]
    assert str(t.transfrom_target(ast_1.body[0])) == '''
x = u'hello'
'''

# Generated at 2022-06-23 23:18:50.352111
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    import io
    from contextlib import redirect_stdout
    from ..basic_transformer import BasicTransformer
    from ..utils.ast_helper import parse

    ast_str = """
        some_str = str(thing)

        def func(x: str, y: str) -> str:
            return x + y
        """

    tree = parse(ast_str)
    BasicTransformer.transform(tree)

    f = io.StringIO()
    with redirect_stdout(f):
        print(ast.dump(tree))

    new_ast_str = """
        some_unicode = unicode(thing)

        def func(x: unicode, y: unicode) -> unicode:
            return x + y
        """

    assert new_ast_str == f.getvalue()


# Generated at 2022-06-23 23:18:50.966752
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:18:54.892702
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    string_types_transformer_test = StringTypesTransformer()
    assert string_types_transformer.target == string_types_transformer_test.target
    assert string_types_transformer.transform == string_types_transformer_test.transform

# Generated at 2022-06-23 23:19:01.785407
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from asttokens import ASTTokens
    
    code = '''
a = str("abc")
    '''

    expected_code = '''
a = unicode("abc")
    '''
    
    tree = ast3.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert ASTTokens(tree=result.tree).get_text() == expected_code
    
    tree = ast3.parse(expected_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == False
    assert ASTTokens(tree=result.tree).get_text() == expected_code

# Generated at 2022-06-23 23:19:09.756858
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    tree = ast.parse("""
    def my_function(a):
        return str(a)
    """)
    t.visit(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='my_function', args=arguments(args=[arg(arg='a', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])"

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:19:10.745422
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    #TODO: Unit test
    pass

# Generated at 2022-06-23 23:19:13.233048
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform('''
        x = str()
    ''') == '''
        x = unicode()
    '''

# Generated at 2022-06-23 23:19:18.443319
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse("""output = str(input)
    """)
    expected_tree = ast.parse("""output = unicode(input)
    """)
    tree_changed, messages, new_tree = StringTypesTransformer.transform(tree)
    assert messages == []
    assert tree_changed == True
    assert ast.dump(new_tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:19:19.108654
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:19:26.465006
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for StringTypesTransformer.

    """
    # Test 'str' => 'unicode'
    code = 'str(5)'
    tree = ast.parse(code)
    r = StringTypesTransformer.transform(tree)
    assert r.tree_changed == True
    assert r.tree_transformed.body[0].value.func.id == 'unicode'

    # Test string which does not contain 'str'.
    code = 'other(5)'
    tree = ast.parse(code)
    r = StringTypesTransformer.transform(tree)
    assert r.tree_changed == False
    assert r.tree_transformed.body[0].value.func.id == 'other'

    # Test different statement, unrelated to the transformer
    code = 'from typing import List'
    tree = ast.parse(code)

# Generated at 2022-06-23 23:19:36.864770
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..managers.format_manager import FormatManager
    from ..indexer.indexer import Indexer
    from ..indexer.search_result import SearchResult
    from ..utils.logger import Logger
    from ..utils.tree import print_tree
    from ..types import Language as Lang
    from ..utils.typing import NO_INDEXER
    from ..transformer.base import BaseTransformer
    from ..visitors.base import BaseNodeVisitor

    TREE_CHANGED, INDEX_CHANGED = True, True
    lang = Lang.PYTHON

    # Test the constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:19:42.666955
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test the function of StringTypesTransformer
    """
    import typed_ast.ast3 as ast
    from typed_ast import ast3
    import textwrap
    import sys

    #The string type is converted to unicode
    code = textwrap.dedent("""
        def f():
            a = 'str'
            return a
    """)
    tree = ast.parse(code)
    transformer = StringTypesTransformer(tree, target_version=sys.version_info)
    new_tree = transformer.run()
    assert textwrap.dedent("""
        def f():
            a = 'str'
            return a
    """) == ast.unparse(new_tree)
    assert transformer.tree_changed

    #It has no effect when the input is correct

# Generated at 2022-06-23 23:19:48.144470
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from test.fixtures.typed_ast import Test_StringTypesTransformer

    tree = Test_StringTypesTransformer.test_basic()
    assert(find(tree, ast.Name).pop().id == 'str')

    new_tree, tree_changed, messages = \
        StringTypesTransformer.transform(tree)

    assert(tree_changed)
    assert(find(new_tree, ast.Name).pop().id == 'unicode')
    assert(messages == [])

# Generated at 2022-06-23 23:19:51.409213
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    '''
    Test for constructor of class StringTypesTransformer
    '''

    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 23:19:53.756905
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("a = 10\nstr(a)")) == TransformationResult(ast.parse("a = 10\nunicode(a)"), True, [])

# Generated at 2022-06-23 23:19:54.726529
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:20:01.025894
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from . import ast_utils
    source = """
        def tes(num):
            a = str(num)
            return a
    """
    tree = astor.parse_file(ast_utils.increment_first_argument(source))
    new_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(new_tree.tree) == ast.dump(astor.parse_file(
        """
        def tes(num):
            a = unicode(num)
            return a
        """))

# Generated at 2022-06-23 23:20:07.464335
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
a = 2
""")
    tree_mod = StringTypesTransformer.transform(tree)
    assert (ast.dump(tree_mod.tree, include_attributes=True) ==
"""Module(body=[Assign(targets=[Name(id='a', ctx=Store(), annotation=None)], value=Num(n=2), type_comment=None)])
""")

    return True

# Generated at 2022-06-23 23:20:16.088789
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str', "<test>", "exec")
    tree = StringTypesTransformer.transform(tree)
    
    name = list(find(tree, ast.Name))[0]
    assert name.id == "unicode"


if __name__ == '__main__':
    tree = ast.parse('str', "<test>", "exec")
    tree = StringTypesTransformer.transform(tree)

    # ast.fix_missing_locations(tree)
    code = compile(tree, "<test>", "exec")

    print(tree)
    exec(code)
    # print(tree)