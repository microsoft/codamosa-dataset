

# Generated at 2022-06-23 23:10:20.508609
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..unit import run_local_tests
    run_local_tests(StringTypesTransformer)

# Generated at 2022-06-23 23:10:25.608919
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_text = """help(str)"""
    expected_output = """help(unicode)"""
    tree = ast.parse(input_text)
    transformed_tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(transformed_tree.tree) == expected_output


# Generated at 2022-06-23 23:10:33.852328
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .transformation_factory import get_transformers, get_transformed_ast
    from typed_ast import ast3 as ast

    transformer_cls = StringTypesTransformer
    transformer_classes = get_transformers([transformer_cls])
    assert transformer_cls in transformer_classes
    assert transformer_classes[transformer_cls].target == (2, 7)

    # Testing of all essential methods
    tree = ast.parse('str(a)')
    transformer = get_transformed_ast(transformer_cls, tree)

    assert transformer.transform.__name__ == 'transform'
    assert isinstance(transformer, transformer_cls)
    assert isinstance(transformer.transform(tree), TransformationResult)

    tree_2 = ast.parse('str(a)')
    transformer = get_transformed_ast

# Generated at 2022-06-23 23:10:36.564188
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str()')) == TransformationResult(ast.parse('unicode()'), True, [])

# Generated at 2022-06-23 23:10:41.314526
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..unit import parse
    from . import assert_equal_ast

    code = """
        'some-string'
        a_str = 'other-string'
        """

    transformed_code = """
        u'some-string'
        a_str = u'other-string'
        """

    tree = parse(code)
    assert_equal_ast(StringTypesTransformer.transform(tree).transformed_tree,
                     transformed_code)

# Generated at 2022-06-23 23:10:44.493881
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    a = ast.parse('str(123)')
    b = ast.parse('unicode(123)')

    assert StringTypesTransformer.transform(a) == TransformationResult(b, True, [])
    assert StringTypesTransformer.transform(b) == TransformationResult(b, False, [])

# Generated at 2022-06-23 23:10:48.143112
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
        import sys
        print(str([1]))
    '''
    tree = ast.parse(source)
    tree = StringTypesTransformer.run_pipeline(tree)
    module_code = compile(tree, '<string>', 'exec')
    exec(module_code)



# Generated at 2022-06-23 23:10:52.320070
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    """
    string_types_transformer = StringTypesTransformer()
    assert isinstance(string_types_transformer, StringTypesTransformer)
    assert string_types_transformer.target == (2, 7)


# Generated at 2022-06-23 23:10:54.504026
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..upgrade import upgrade_tree
    from ..utils.tree import parse_into_ast

# Generated at 2022-06-23 23:11:03.312056
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse('x = "foo" + "bar"')
    assert isinstance(tree, typed_ast.ast3.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], typed_ast.ast3.Assign)
    assert len(tree.body[0].targets) == 1
    assert isinstance(tree.body[0].targets[0], typed_ast.ast3.Name)
    assert tree.body[0].targets[0].id == 'x'
    assert isinstance(tree.body[0].value, typed_ast.ast3.BinOp)
    assert isinstance(tree.body[0].value.left, typed_ast.ast3.Str)
    assert tree

# Generated at 2022-06-23 23:11:10.798055
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast.ast3 import parse
    from ..types import parse_version, get_parser
    
    for version in ((2, 6), (2, 7)):
        tree = parse(
            '''
            def foo():
                print(str(42))
            '''
        )
        version_str = '.'.join(map(str, version))
        parser = get_parser(version_str) 
        res = parser.parse(tree)
        assert res['py_version'] == version_str
        trans = StringTypesTransformer(version_str)
        trans_res = trans.transform(res['tree'])
        assert not trans_res.changed
        assert not trans_res.additional_import_stmts
        

# Generated at 2022-06-23 23:11:21.344963
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transform = StringTypesTransformer()

    # Test no conversion
    assert "class Foo():\n\tdef __init__(self, a: str):\n\t\tpass" == \
        astor.to_source(ast.parse("class Foo():\n\tdef __init__(self, a: str):\n\t\tpass"))
    assert astor.to_source(transform(ast.parse("class Foo():\n\tdef __init__(self, a: str):\n\t\tpass"))) == \
        "class Foo():\n\tdef __init__(self, a: unicode):\n\t\tpass"

    # Test with conversion

# Generated at 2022-06-23 23:11:25.272036
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast_tree = ast.parse(
        'a = str(5)'
    )
    
    result = StringTypesTransformer.transform(ast_tree)
    new_tree = result.tree

    assert isinstance(new_tree.body[0].value.func, ast.Name)
    assert new_tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-23 23:11:32.653143
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing_utils import generate_source_code
    from ..utils.tree import get_node
    from ..utils.source_code_utils import compare_asts

    source_code = generate_source_code(ast.parse("""
x = str()
y = x
"""), ['x', 'y'])

    tree_before = get_node(source_code, 'x')
    tree_after = get_node(StringTypesTransformer.transform(source_code).tree, 'x')

    assert compare_asts(tree_after, tree_before)

# Generated at 2022-06-23 23:11:38.400237
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
        x = str()
    '''
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == '''Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])'''

# Generated at 2022-06-23 23:11:42.351638
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    tree = ast.parse('''\
        def A(self):
            return str(self)''', mode='exec')
    tree = StringTypesTransformer.transform(tree).tree
    assert astunparse.unparse(tree) == '''\
        def A(self):
            return unicode(self)'''

# Generated at 2022-06-23 23:11:49.010575
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_node = ast.parse("x == 'y' and len(z) == 2")
    expected_node = ast.parse("x == u'y' and len(z) == 2")
    transformer = StringTypesTransformer()
    actual_node = transformer.transform(input_node)
    assert ast.dump(actual_node) == ast.dump(expected_node)

# Generated at 2022-06-23 23:11:50.098185
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:11:54.051872
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(textwrap.dedent(
        """
        def hello():
            str(1)
        """
    ))
    tree_out = StringTypesTransformer.transform(tree)
    assert tree_out.tree.body[0].body[0].func.id == 'unicode'

# Generated at 2022-06-23 23:11:55.587381
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Constructor test
    assert StringTypesTransformer



# Generated at 2022-06-23 23:11:58.238437
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_transformer import run_test_on_string


# Generated at 2022-06-23 23:12:07.460745
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = textwrap.dedent('''\
        def x(a: str):
            pass
    ''')
    tree = ast.parse(code)
    transformer_class = StringTypesTransformer()
    expected_code = textwrap.dedent('''\
        def x(a: unicode):
            pass
    ''')
    tree_changed, new_tree, _ = transformer_class.transform(tree)
    assert tree_changed
    assert astor.to_source(new_tree) == expected_code
    # Round trip from source code to AST.
    roundtrip_tree = ast.parse(astor.to_source(new_tree))
    assert ast.dump(roundtrip_tree) == ast.dump(new_tree)

# Generated at 2022-06-23 23:12:17.943098
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3, parse
    from ..utils.codegen import code_gen
    from test.parser.utils import compare_ast

    # Basic test
    node = parse('def foo(): pass')
    node = ast.fix_missing_locations(node)
    node_transformed = ast.fix_missing_locations(StringTypesTransformer.transform(node).tree)
    expected = parse('def foo(): pass')
    compare_ast(node_transformed, expected)
    assert code_gen(node_transformed) == code_gen(expected)

    # Basic test
    node = parse('def foo(x: str): pass')
    node = ast.fix_missing_locations(node)
    node_transformed = ast.fix_missing_locations(StringTypesTransformer.transform(node).tree)
   

# Generated at 2022-06-23 23:12:18.740971
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass
    # TODO: should probably be implemented

# Generated at 2022-06-23 23:12:21.002729
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:25.176427
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()

    source = """
            s = str("hello")
            """
    tree = ast.parse(source)
    transformer.apply(tree)
    source = """
            s = unicode("hello")
            """
    assert codegen.to_source(tree) == source

# Generated at 2022-06-23 23:12:32.268990
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source_code = """
        def foo(a: str, b: unicode):
            print(b)
            return a + b
    """
    expected_code = """
        def foo(a: unicode, b: unicode):
            print(b)
            return a + b
    """
    tree = ast.parse(expected_code)
    tree_changed = False
    log_messages = []

    result = StringTypesTransformer.transform(tree)
    tree_changed = result.tree_changed
    log_messages = result.log_messages
    
    assert tree_changed == False
    assert log_messages == []

# Generated at 2022-06-23 23:12:34.885093
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse('str')
    t = StringTypesTransformer.transform(t)
    assert t.tree.body[0].value.id == 'unicode'

# Generated at 2022-06-23 23:12:44.822753
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit tests for the StringTypesTransformer class.
    """
    from .test_base import _check_transform, CodeExample

    from_py_ver = (2, 7)
    to_py_ver = (3, 5)

    examples = [
        CodeExample("""
            from foo import bar
            class Foo:
                def __init__(self):
                    s = str("hello")
        """, """
            from foo import bar
            class Foo:
                def __init__(self):
                    s = unicode("hello")
        """)
    ]

    _check_transform(StringTypesTransformer, examples, from_py_ver, to_py_ver)


if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:12:45.775136
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:47.998555
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    import sys
    # Tree before the transformation

# Generated at 2022-06-23 23:12:53.855806
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import get_node_types, parse_ast
    from ..utils.tree import get_node_names

    def check_transformed(before, after):
        tree = parse_ast(before)
        result = StringTypesTransformer.transform(tree)
        assert result.tree_changed == (after != before)
        assert get_node_types(result.tree) == get_node_types(parse_ast(after))

    check_transformed('''
        x = str()
        x = str(1)
    ''', '''
        x = unicode()
        x = unicode(1)
    ''')

# Generated at 2022-06-23 23:13:00.943220
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    old_code = """
        s = str('string')
        a = str(1.2)
        b = str(b'bytes')
    """
    
    new_code = """
        s = unicode('string')
        a = unicode(1.2)
        b = unicode(b'bytes')
    """
    
    t = StringTypesTransformer()
    assert t.transform(old_code) == new_code


# Generated at 2022-06-23 23:13:01.339637
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # missing
    pass

# Generated at 2022-06-23 23:13:06.393265
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Foo(object):
        def bar(self, label: str) -> str:
            return label

    code = dedent(Foo.bar.__doc__)

    t = StringTypesTransformer()
    tree = ast.parse(code)
    tree, changed, messages = t.transform(tree)

    assert changed
    assert not messages

    fixed_code = dedent('''
        def bar(self, label: unicode) -> unicode:
            return label
    ''').strip()

    assert astor.to_source(tree).strip() == fixed_code

# Generated at 2022-06-23 23:13:15.152885
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    from .string_io_transformer import StringIOTransformer

    source = """
        class A(object):
            def __init__(self):
                pass
    """

    old_tree = ast.parse(source)
    new_tree, tree_changed, messages = StringTypesTransformer.transform(old_tree)
    module = ast.Module(body=new_tree.body)

    assert tree_changed == True
    assert isinstance(new_tree, ast.Module)
    assert isinstance(new_tree.body[0].body[0].args, ast.arguments)
    assert module

# Generated at 2022-06-23 23:13:22.343875
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string = """
    def func():
        print str('test')
    """
    tree = ast.parse(string)
    assert isinstance(tree, ast.Module)
    t = StringTypesTransformer()
    t.visit(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='func', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Print(dest=None, values=[Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='test')], keywords=[], starargs=None, kwargs=None)], nl=True)], decorator_list=[])])"

# Generated at 2022-06-23 23:13:23.733771
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TODO: Make unit tests for StringTypesTransformer
    return True

# Generated at 2022-06-23 23:13:28.834345
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = "def _(): return str('a')\n"
    tree = ast.parse(code)
    expected = "def _(): return unicode('a')\n"
    StringTypesTransformer.transform(tree)
    result = astor.to_source(tree)
    assert result == expected

# Generated at 2022-06-23 23:13:30.319720
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tr = StringTypesTransformer()

# Generated at 2022-06-23 23:13:38.887854
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
a = str(1)
"""
    tree = ast.parse(code)
    results = StringTypesTransformer.transform(tree)
    assert results.tree_changed
    assert isinstance(results.tree, ast.AST)
    module = ast.parse(compile(results.tree, '', 'exec'))
    assert isinstance(module, ast.Module)
    statements = module.body
    assert len(statements) == 1
    statement = statements[0]
    assert isinstance(statement, ast.Assign)
    value = statement.value
    assert isinstance(value, ast.Call)
    name = value.func
    assert isinstance(name, ast.Name)
    assert name.id == 'unicode'

# Generated at 2022-06-23 23:13:41.980491
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from typed_ast import ast3
    t = ast3.parse("str = 'text'", mode="exec")
    tree_changed = StringTypesTransformer.transform(t)
    assert astor.to_source(t) == "unicode = 'text'\n"

# Generated at 2022-06-23 23:13:47.420064
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import build_program_from_snippet, get_changed_variable_names

    program = build_program_from_snippet('''
        a = str('A')
        b = str(a)
        c = str(b)
    ''')

    program, changed = StringTypesTransformer.transform(program)

    assert changed

    assert get_changed_variable_names(program) == {'a', 'b', 'c'}
    assert program == build_program_from_snippet('''
        a = unicode('A')
        b = unicode(a)
        c = unicode(b)
    ''')

# Generated at 2022-06-23 23:13:51.771438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    try:
        StringTypesTransformer.transform(ast.parse('x = str()'))
        StringTypesTransformer.transform(ast.parse('x = str'))
        StringTypesTransformer.transform(ast.parse('x = str()'))
    except:
        return False
    return True

# Generated at 2022-06-23 23:13:57.894896
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseAPITransformerTest

    class Test(BaseAPITransformerTest):
        target_transformer = StringTypesTransformer
        def test_basic(self):
            tree = ast.parse('"abc", str(123)')
            expected_tree = ast.parse('"abc", unicode(123)')
            self.check_expected(tree, expected_tree)
    return Test

# Generated at 2022-06-23 23:13:58.809554
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer != ''

# Generated at 2022-06-23 23:14:02.215096
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
print str(foo)
    """
    expected = """
print unicode(foo)
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].value.func.id == "unicode"

# Generated at 2022-06-23 23:14:06.336824
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    example_test = """
    def hello():
        return 'test'
    """
    tree = ast.parse(example_test)
    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='hello', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Return(value=Str(s='test'))], decorator_list=[])])"

# Generated at 2022-06-23 23:14:09.246122
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    prog = ast.parse("""
from __future__ import unicode_literals
x = str('nihao')
""")
    expected = ast.parse("""
from __future__ import unicode_literals
x = unicode('nihao')
""")

    assert ast.dump(expected) == ast.dump(StringTypesTransformer.transform(prog)[0])

# Generated at 2022-06-23 23:14:10.813170
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer is not None

# Generated at 2022-06-23 23:14:18.351880
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_source = """
str = 'qwerty'
str = str + 'asdf'
str()
ord(str)
"""
    expected_result = """
unicode = 'qwerty'
unicode = unicode + 'asdf'
unicode()
ord(unicode)
"""
    result = StringTypesTransformer.transform(test_source)
    assert result.source == expected_result
    assert result.tree_changed == True
    assert result.tokens_changed == False
    assert result.warnings == []

# Generated at 2022-06-23 23:14:23.074204
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = '''
        def foo(a: str):
            b = str(bar)
    '''

    # When
    result = StringTypesTransformer.transform(code)

    # Then
    assert result.code == '''\
        def foo(a: unicode):
            b = unicode(bar)
    '''
    assert result.did_change

# Generated at 2022-06-23 23:14:27.679087
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input = """
    def f(x):
        return str(x)
    """
    desired = """
    def f(x):
        return unicode(x)
    """

    tree = ast.parse(input)
    tr = StringTypesTransformer()
    new_tree = tr.visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse(desired))

# Generated at 2022-06-23 23:14:30.041626
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class TestTransformer(StringTypesTransformer):
        pass
    TestTransformer.test()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:14:37.887928
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_code = """
        def func(a: str):
            pass
            
        def func(a: int):
            pass
            
        def func(a: unicode):
            pass
    """
    expected_output = """
        def func(a: unicode):
            pass
            
        def func(a: int):
            pass
            
        def func(a: unicode):
            pass
    """

    tree = ast.parse(input_code)
    tree = StringTypesTransformer.transform(tree)

    assert expected_output == astor.to_source(tree)

# Generated at 2022-06-23 23:14:41.082488
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'def method(arg: str):\n    return arg.upper()'
    expected = 'def method(arg: unicode):\n    return arg.upper()'

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree).tree

    result = compile(tree, 'test', 'exec')
    assert expected == ''.join(inspect.getsourcelines(result)[0])

# Generated at 2022-06-23 23:14:47.746113
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
a = str("unicode")
b = str(1)
""")
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed, "Tree changed must be True."
    assert result.tree.body[1].value.args[0].id == 'unicode', "arg[0] must be unicode"
    assert result.tree.body[1].value.args[1].id == 'unicode', "arg[0] must be unicode"

# Generated at 2022-06-23 23:14:55.732995
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        def f(a: str, b: unicode):
            return b
    """)
    new_tree, changed, error = StringTypesTransformer.transform(tree)

    assert not changed

    tree = ast.parse("""
        def f(a: str):
            return a
    """)

    new_tree, changed, error = StringTypesTransformer.transform(tree) 

    assert changed

# Generated at 2022-06-23 23:15:04.830769
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse, dump
    from ..utils import format_code

    code = '''
    from __future__ import unicode_literals
    from collections import defaultdict
    import typing

    def my_func(x: int) -> str:
        return "hello, world!"
    '''

    expected_code = '''
    from __future__ import unicode_literals
    from collections import defaultdict
    import typing

    def my_func(x: int) -> unicode:
        return "hello, world!"
    '''

    tree = parse(code)
    transformed, _ = StringTypesTransformer.transform(tree)
    assert format_code(dump(tree)) == format_code(expected_code)

# Generated at 2022-06-23 23:15:09.074214
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from dumpast import dump
    t = ast3.parse('str(123)')
    first = StringTypesTransformer.transform(t)
    assert isinstance(first.tree, ast3.Module)
    dump(first.tree)
    assert first.tree_changed == True



# Generated at 2022-06-23 23:15:09.790545
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:15:14.987877
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests valid python code. 

    """
    from typed_ast import ast3 as ast

    code = 'x = str("Hello, World!")'
    tree = ast.parse(code)
    new_tree, tree_changed, messages = StringTypesTransformer.transform(tree)
    exec(compile(new_tree, '', 'exec'))

    assert tree_changed
    assert x == "Hello, World!"

# Generated at 2022-06-23 23:15:23.135461
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that the method transform of class StringTypesTransformer
    works correctly.

    """
    from ..utils import parse

    # Tests that 'str' is replaced with 'unicode' if given as the name of an
    # argument of a function
    code = 'def func(variable):\n    pass'
    parsed_code = parse(code)
    assert parsed_code is not None
    tree_changed, tree, messages = (
        StringTypesTransformer.transform(parsed_code))
    assert tree_changed
    assert len(messages) == 0

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:15:26.710542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        x = "str"
        y = str(1)
    """

    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree).tree

    expected = """
        x = "str"
        y = unicode(1)
    """

    assert ast.dump(new_tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 23:15:33.016502
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.testing import assert_program

    source = """
    x = str(2)
    """

    expected = """
    x = unicode(2)
    """

    tree = astor.parse_file(source)
    result = StringTypesTransformer.transform(tree)
    # print(f"Tree: \n{astor.dump_tree(tree)}")     # <-- uncomment to see the original tree
    # print(f"Tree transformed: \n{astor.dump_tree(result.tree)}")      # <-- uncomment to see the transformed tree
    assert_program(result.tree, expected)

# Generated at 2022-06-23 23:15:35.665666
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test constructor of class StringTypesTransformer
    """
    try:
        StringTypesTransformer()
    except Exception as e:
        assert(False)


# Generated at 2022-06-23 23:15:42.554463
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string1 = ast.parse('str(3)')
    string1 = ast.fix_missing_locations(string1)
    string2 = ast.parse('print(unicode(2))')
    string2 = ast.fix_missing_locations(string2)
    tree = ast.parse('str(print(str(x + "dfsd")))')
    tree = ast.fix_missing_locations(tree)
    result = StringTypesTransformer.transform(tree)
    assert ast.dump(result.tree) == ast.dump(string2)

# Generated at 2022-06-23 23:15:49.464880
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Note: use exec to ensure static analysis tools can analyze this code.
    # fmt:off
    examples = [
        'str(0)',
        'type("foo") is str',
        ]
    # fmt:on
    for example in examples:
        tree = ast.parse(example)
        after, _ = StringTypesTransformer.transform(tree)
        fixed = astor.to_source(after)
        assert fixed == 'unicode(0)' or fixed == 'type("foo") is unicode'

        exec(fixed)

# Generated at 2022-06-23 23:15:54.444252
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_str = '''
        print str(5)[0]
        s = str(5)
        '''
    transformed_ast, tree_changed = StringTypesTransformer().visit(parse(code_str))
    assert str(transformed_ast) == str(parse(
        '''
        print unicode(5)[0]
        s = unicode(5)
        '''))
    assert tree_changed == True



# Generated at 2022-06-23 23:15:56.650287
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
for s in x:
    pass
'''
    expected = '''
for s in x:
    pass
'''
    StringTypesTransformer.assert_transformed(code, expected)



# Generated at 2022-06-23 23:16:00.504633
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from textwrap import dedent

    before = dedent("""
    def f(x: str, y: str = 'something'):
        return x * 2
    """)
    expected = dedent("""
    def f(x: unicode, y: unicode = 'something'):
        return x * 2
    """)
    tree = ast.parse(before)
    tree = StringTypesTransformer.transform(tree)
    assert astunparse.unparse(tree.node) == expected

# Generated at 2022-06-23 23:16:08.672951
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = TEXTWRAP.dedent(r'''
    """This is a sample.

    """
    def sayHello(a:str):
        print('hello world!' + a)
    ''')

    new_code = TEXTWRAP.dedent(r'''
    """This is a sample.

    """
    def sayHello(a:unicode):
        print('hello world!' + a)
    ''')

    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    assert StringTypesTransformer.backport(new_tree) == new_code

# Generated at 2022-06-23 23:16:10.355673
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    stringTypeTransformer = StringTypesTransformer()
    assert stringTypeTransformer is not None


# Generated at 2022-06-23 23:16:14.821776
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import TransformationResult

    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import find_all_nodes_of_type


# Generated at 2022-06-23 23:16:20.963467
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode, Source
    from ..utils.tree import find
    from ..types import TransformationResult, GenerationResult
    from ..transformers.string_types import StringTypesTransformer

    source_code = source_to_unicode(Source('tests/fixtures/string_types.py'))
    transformed = StringTypesTransformer.transform(source_code)
    assert transformed.tree_changed

    source_code = source_to_unicode(Source('tests/fixtures/no_string_types.py'))
    transformed = StringTypesTransformer.transform(source_code)
    assert not transformed.tree_changed

# Generated at 2022-06-23 23:16:24.146097
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('print(str(1))')
    tt = StringTypesTransformer()
    new_tree = tt.visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse('print(unicode(1))'))

# Generated at 2022-06-23 23:16:25.290912
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:16:28.570389
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str')
    transformer = StringTypesTransformer()
    tree = transformer.visit(tree)
    assert (tree.body[0].value.id == 'unicode')

# Generated at 2022-06-23 23:16:31.754326
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str')).tree == ast.parse('unicode')
    assert StringTypesTransformer.transform(ast.parse('str()')).tree == ast.parse('unicode()')

# Generated at 2022-06-23 23:16:35.547353
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    import os
    import cStringIO
    import string

    def test():
        s = str("Hello, World!")
        return str(s)
    """)
    tree = StringTypesTransformer.run(tree)
    print(ast.dump(tree))

# Generated at 2022-06-23 23:16:42.580578
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import python_to_python_ast, transform_ast
    from ..converter import PythonConverter
    c = PythonConverter()
    ast_tree = python_to_python_ast("x = str('hello')")
    tree = [x for x in transform_ast(ast_tree, [StringTypesTransformer])]
    assert c.ast_to_target_python(tree[0]).strip() == "x = unicode('hello')"

# Generated at 2022-06-23 23:16:43.195392
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:16:48.028444
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'a = str(None)'
    expected_code = 'a = unicode(None)'

    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    ret_tree = result.tree
    assert result.tree_changed
    assert ast.dump(ret_tree) == expected_code

# Generated at 2022-06-23 23:16:55.197589
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests for constructor of `StringTypesTransformer` class.
    
    """
    expected_tree = ast.Module([
        ast.FunctionDef(
            'foo',
            ast.arguments(
                args=[ast.Name('x', ast.Param())],
                vararg=None,
                kwarg=None,
                defaults=[]),
            body=[
                ast.Return(
                    value=ast.Call(
                        fn=ast.Name('unicode', ast.Load()),
                        args=[ast.Name('unicode', ast.Load())],
                        keywords=[]))],
            decorator_list=[],
            returns=None)])

    tree = ast.parse("def foo(x):\n  return unicode(str)")
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

# Generated at 2022-06-23 23:17:03.338079
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("str()")) == TransformationResult(ast.parse("unicode()"), True, [])
    assert StringTypesTransformer.transform(ast.parse("foo = str()")) == TransformationResult(ast.parse("foo = unicode()"), True, [])
    assert StringTypesTransformer.transform(ast.parse("foo.bar(str)")) == TransformationResult(ast.parse("foo.bar(unicode)"), True, [])
    assert StringTypesTransformer.transform(ast.parse("foo.bar(\"str\")")) == TransformationResult(ast.parse("foo.bar(\"str\")"), False, [])

# Generated at 2022-06-23 23:17:06.119374
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    a = ast.parse("print 'abc'")
    a = StringTypesTransformer.transform(a)
    assert str(a) == "print(u'abc')"

# Generated at 2022-06-23 23:17:12.529493
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class X:
        def foo(self):
            return str(42) 
    transformer = StringTypesTransformer()
    source = inspect.getsource(X)
    tree = ast.parse(source)
    result = transformer.transform(tree)
    code = compile(result.tree, filename='<test>', mode='exec')
    ns = {}
    exec(code, ns, ns)
    x = ns['X']()
    assert x.foo() == '42'

# Generated at 2022-06-23 23:17:15.350695
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = StringTypesTransformer()
    node = ast.parse('a = str(1)')
    assert tt.transform(node) == TransformationResult(ast.parse('a = unicode(1)'), True, [])

# Generated at 2022-06-23 23:17:21.183243
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    for tree_string in ['str', 'unicode', 'a = str']:
        tree = ast.parse(tree_string)
        tree_changed, errors, transformations = StringTypesTransformer.transform(tree)
        tree = ast.parse('unicode')
        assert ast.dump(tree) == ast.dump(tree_changed)
        assert not errors
        assert transformations

    tree = ast.parse('a = str')
    tree_changed, errors, transformations = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == ast.dump(tree_changed)
    assert not errors
    assert transformations

# Generated at 2022-06-23 23:17:30.594406
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform(ast.parse("str", mode='eval')) == TransformationResult(ast.parse("unicode", mode='eval'), True, [])
    assert t.transform(ast.parse("unicode", mode='eval')) == TransformationResult(ast.parse("unicode", mode='eval'), False, [])
    assert t.transform(ast.parse("x", mode='eval')) == TransformationResult(ast.parse("x", mode='eval'), False, [])
    assert t.transform(ast.parse("a = str", mode='single')) == TransformationResult(ast.parse("a = unicode", mode='single'), True, [])

# Generated at 2022-06-23 23:17:35.456249
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    code = """
        def foo(a):
            return str(a)
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    print(result)
    assert result.tree_changed == True

test_StringTypesTransformer()

# Generated at 2022-06-23 23:17:40.220257
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(StringTypesTransformer, ast.parse("""
        if (isinstance(x, str)):
            return 'asdf'
        else:
            return 'asdf'
    """)).code == """
        if (isinstance(x, unicode)):
            return 'asdf'
        else:
            return 'asdf'
    """

# Generated at 2022-06-23 23:17:44.040037
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(b)')
    tree = StringTypesTransformer.transform(tree)
    assert tree.changed
    assert ast.dump(tree.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='b', ctx=Load())], keywords=[]))])"

# Generated at 2022-06-23 23:17:47.052988
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse('str(1)')
    expected_tree = typed_ast.ast3.parse('unicode(1)')
    t = StringTypesTransformer()
    new_tree = t.visit(tree)
    assert(expected_tree == new_tree)

# Generated at 2022-06-23 23:17:48.626857
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert eval(StringTypesTransformer.transform_single_expression("str")) == unicode

# Generated at 2022-06-23 23:17:50.712623
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..unit_test_ast import parse, compare_ast


# Generated at 2022-06-23 23:17:55.176703
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    "abc"
    '''

    expected_code = '''
    u"abc"
    '''
    tree = ast.parse(code)
    new_tree, _, _ = StringTypesTransformer.transform(tree)
    assert astunparse.unparse(new_tree) == expected_code

# Generated at 2022-06-23 23:17:57.833461
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Constructor of StringTypesTransformer has no arguments
    StringTypesTransformer()

if __name__ == "__main__":
    py2to3.main()

# Generated at 2022-06-23 23:18:02.448119
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
my_str = str()
'''
    expected = '''
my_str = unicode()
'''
    tree = ast.parse(source)
    assert StringTypesTransformer.transform(tree).tree_changed == True
    assert strip_newlines(str(tree)) == strip_newlines(expected)

# Generated at 2022-06-23 23:18:08.871048
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_from = """if isinstance(foo, str):
        bar = foo.encode()
    """

    code_to = """if isinstance(foo, unicode):
        bar = foo.encode()
    """

    tree_from = ast.parse(code_from)
    tree_to = ast.parse(code_to)
    obj = StringTypesTransformer()
    assert obj.transform(tree_from) == (tree_to, True, ['Name'])

# Generated at 2022-06-23 23:18:13.617411
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test if StringTypesTransformer works correctly
    data = dedent("""\
    abc = 'abc'
    """)
    exp_data = dedent("""\
    abc = unicode('abc')
    """)
    tree = ast.parse(data)
    tree = StringTypesTransformer.transform(tree)
    assert exp_data == tree.body[0].value.s

# Generated at 2022-06-23 23:18:15.558473
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('''s = str(s)''')).tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-23 23:18:17.092409
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Check if the StringTypesTransformer class is working properly.

    """
    assert issubclass(StringTypesTransformer, BaseTransformer)


# Generated at 2022-06-23 23:18:21.907278
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    def f(a: str):
        pass
    """
    tree = ast.parse(code)
    result = StringTypesTransformer().transform(tree)
    print(result)
    assert result.tree_changed
    assert result.messages
    assert(code.replace('str', 'unicode') == result.tree.body[0].args[0].annotation.id)

# Generated at 2022-06-23 23:18:28.926779
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test on a StringTypesTransformer instance
    tree = ast.parse("x = 'foo'")

    t = StringTypesTransformer()
    t.tree = tree
    t.transform()

    assert t.tree_changed

    # Test on the class
    tree = ast.parse("x = str('foo')")
    new_tree, tree_changed, messages = StringTypesTransformer.transform(tree)

    assert tree_changed
    assert len(messages) == 0

# Generated at 2022-06-23 23:18:29.881708
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass #TODO



# Generated at 2022-06-23 23:18:33.635763
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str')).tree.body[0].value.id == 'unicode'
    assert StringTypesTransformer.transform(ast.parse('str')).tree_changed == True
    assert StringTypesTransformer.transform(ast.parse('unicode')).tree_changed == False

# Generated at 2022-06-23 23:18:36.144523
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform(str(ast.parse('str()', mode='eval'))).tree_changed
    assert not t.transform(str(ast.parse('unicode()', mode='eval'))).tree_changed

# Generated at 2022-06-23 23:18:42.435361
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test for transforming str to unicode
    tree = ast.parse('str_value = str("test")')
    transformed_tree, tree_changed, error_messages = StringTypesTransformer.transform(tree)
    transformed_source_code = ast.unparse(transformed_tree)
    expected_source_code = 'unicode_value = unicode("test")'
    assert transformed_source_code == expected_source_code
    assert tree_changed == True
    assert error_messages == []

    # test for not transforming str to unicode
    tree = ast.parse('str_value = str("test")')
    transformed_tree, tree_changed, error_messages = StringTypesTransformer.transform(tree)
    transformed_source_code = ast.unparse(transformed_tree)

# Generated at 2022-06-23 23:18:47.751124
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_base import CodeForTesting

    code = CodeForTesting.class_func()

    t = StringTypesTransformer.transform(code)
    assert(type(t.new_tree) is ast.Module)
    assert(t.tree_changed is True)
    assert(t.new_code == "class TestClass(object):\n\t'''Test docstring'''\n\t\n\tdef __init__(self):\n\t\tself.attr1 = unicode()\n\t\tself.attr2 = unicode()\t\n\t\n\tdef test_method(self):\n\t\tprint(self.attr1)\n\t\tprint(self.attr2)")

# Generated at 2022-06-23 23:18:52.864686
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    sample = """
    s = str()
    """
    expected = """
    s = unicode()
    """
    tree = ast.parse(sample)
    t = StringTypesTransformer()
    new_tree = t.transform(tree)
    print(ast.dump(new_tree))
    assert ast.dump(tree) == expected

test_StringTypesTransformer()

# Generated at 2022-06-23 23:19:00.515057
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Initialization
    stringtypetransformer = StringTypesTransformer()

    # Test simple case
    code = """
    str
    """
    tree = ast.parse(code)
    result = stringtypetransformer.transform(tree)
    assert result.tree_changed == True
    assert result.module_changed == True
    assert result.result == "unicode"

    # Test multiple cases
    code = """
    str
    str
    """
    tree = ast.parse(code)
    result = stringtypetransformer.transform(tree)
    assert result.tree_changed == True
    assert result.module_changed == True
    assert result.result == "unicode\nunicode"

# Generated at 2022-06-23 23:19:05.759779
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    import inspect
    import textwrap
    sample_python_code = '''def test(x): return str(x)'''
    tree = typed_ast.ast3.parse(textwrap.dedent(sample_python_code))
    transformed_tree, tree_changed = StringTypesTransformer().transform(tree)
    if(tree_changed):
        print("Changed")
    exec(compile(transformed_tree, filename="", mode="exec"))
    print(test(4))

# Generated at 2022-06-23 23:19:06.207311
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-23 23:19:11.361157
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    import typed_ast.ast3 as ast
    
    node = ast.Name(id='str', ctx=ast.Load())
    assert isinstance(node, ast.AST)
    assert isinstance(node, ast.Name)
    
    x = StringTypesTransformer(node)
    assert isinstance(x, StringTypesTransformer)
    
    assert node == x.node
    


# Generated at 2022-06-23 23:19:19.024069
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..test_utils import transform_and_test
    from ast_baker import bake
    from math import sqrt
    source = '''
        a = str(sqrt(4))
        b = str(a)
        '''
    new_source = '''
        a = unicode(sqrt(4))
        b = unicode(a)
        '''
    ast_tree = bake(source)
    new_ast_tree, tree_changed, issues = StringTypesTransformer.transform(ast_tree)
    transform_and_test(source, new_source, ast_tree, new_ast_tree, tree_changed, issues)

# Generated at 2022-06-23 23:19:26.438645
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(1)')
    tree_changed, messages = StringTypesTransformer.transform(tree)
    assert tree_changed == True
    assert messages == []
    assert type(tree) == ast.Module
    assert type(tree.body[0]) == ast.Assign
    assert type(tree.body[0].value) == ast.Call
    assert type(tree.body[0].value.func) == ast.Name
    assert tree.body[0].value.func.id == 'unicode'
    assert type(tree.body[0].value.args[0]) == ast.Num
    assert tree.body[0].value.args[0].n == 1
    # no changes
    tree_changed, messages = StringTypesTransformer.transform(tree)
    assert tree_changed == False

# Generated at 2022-06-23 23:19:27.091329
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:19:28.392605
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:19:34.403898
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_str = "a = str(b)"
    tree = ast.parse(code_str)
    result = StringTypesTransformer.transform(tree)
    result_code = compile(result.tree, '', mode='exec')
    _globals = {}
    _locals = {}
    exec(result_code, _globals, _locals)
    assert _locals['a'] == unicode(b)

# Generated at 2022-06-23 23:19:36.507082
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  print("StringTypesTransformer running...")
  StringTypesTransformer()
  print("StringTypesTransformer ran successfully")
  pass

# Generated at 2022-06-23 23:19:43.399904
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_transformer_support import transform_and_compile
    import logging

    def test_test_StringTypesTransformer_lambda(i):
        return str(i)

    # (float) -> unicode
    expected_typing_function_def = ast.FunctionDef(
        name='test_test_StringTypesTransformer_lambda',
        args=ast.arguments(
            args=[ast.Name(id='i', ctx=ast.Param())],
            defaults=[],
            kw_defaults=[],
            vararg=None,
            kwarg=None
        ),
        body=[
        ],
        decorator_list=[],
        returns=ast.Name(id='unicode', ctx=ast.Load())
    )

    # (float

# Generated at 2022-06-23 23:19:44.137665
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit testing for constructor."""
    pass

# Generated at 2022-06-23 23:19:48.786163
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    
    tree = ast3.parse("a == '123'")
    assert isinstance(tree,ast3.Module)
    assert isinstance(tree.body[0],ast3.Expr)
    assert isinstance(tree.body[0].value,ast3.Compare)
    assert isinstance(tree.body[0].value.left,ast3.Name)
    assert tree.body[0].value.left.id=='a'    
    
    # Replace str with unicode
    tree = StringTypesTransformer.transform(tree)
    assert isinstance(tree,ast3.Module)
    assert isinstance(tree.body[0],ast3.Expr)
    assert isinstance(tree.body[0].value,ast3.Compare)

# Generated at 2022-06-23 23:19:49.736883
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:19:51.783984
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with pytest.raises(TypeError):
        StringTypesTransformer()

# Generated at 2022-06-23 23:19:56.426279
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from astor.astunparse import unparse
    code = 'str\n'
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    # Test for the constructor with the result for the code above.
    assert(unparse(tree) == "unicode\n")


# Generated at 2022-06-23 23:20:00.557633
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Expression(ast.Name(id='str', ctx=ast.Load()))
    expected = TransformationResult(ast.Expression(ast.Name(id='unicode', ctx=ast.Load())), True, [])
    result = StringTypesTransformer.transform(node)
    assert result == expected

# Unit tests for find

# Generated at 2022-06-23 23:20:10.594623
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode, source_to_ast

    code = '''
a = str()
b = str(x)
c = str(x, y)
'''
    expected = '''
a = unicode()
b = unicode(x)
c = unicode(x, y)
'''
    tree = source_to_ast(source_to_unicode(code))
    transformer = StringTypesTransformer()
    transformed, _ = transformer.transform(tree)
    actual = transformed.body
    ast.fix_missing_locations(actual)
    assert ast.dump(actual) == ast.dump(source_to_ast(source_to_unicode(expected)))

# Generated at 2022-06-23 23:20:13.101085
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str(1)')) == TransformationResult(ast.parse('unicode(1)'), True, [])

# Generated at 2022-06-23 23:20:19.657123
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from .base import BaseTransformerTest

    class Test(BaseTransformerTest):
        target_transformer = StringTypesTransformer
        def test_string(self):
            code = """
            foo = str()
            """
            tree = ast.parse(code)

            # This should not raise anything
            self.transform(tree)

    t = Test()
    t.test_string()