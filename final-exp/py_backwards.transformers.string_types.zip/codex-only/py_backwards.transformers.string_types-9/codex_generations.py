

# Generated at 2022-06-23 23:10:21.940689
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.transform is StringTypesTransformer.transform
    assert transformer.target is StringTypesTransformer.target

# Generated at 2022-06-23 23:10:23.327476
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import run_local_tests
    run_local_tests()

# Generated at 2022-06-23 23:10:30.137609
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    from ..parser import parse
    from ..utils.source import source_to_unicode
    from ..visitor import CodeVisitor
    from ..utils.source import source_to_unicode
    code = """
    print str()
    """
    trans = StringTypesTransformer()
    tree = parse(source_to_unicode(code))
    transformed, c = trans.transform(tree)
    # print (source_to_unicode(transformed))
    
    class TestVisitor(CodeVisitor):
        def visit_Name(self, n):
            pass
        def visit_Str(self, n):
            pass
        def visit_Module(self, n):
            pass
    TestVisitor().visit(transformed)
    

# Generated at 2022-06-23 23:10:38.100659
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def func(s):
            if isinstance(s, str):
                return s.encode()
    """
    expected = """
        def func(s):
            if isinstance(s, unicode):
                return s.encode()
    """
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.changed
    assert ast.dump(result.tree) == ast.dump(ast.parse(expected))

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:10:39.197656
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:10:45.417662
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast_node = ast.parse('a = str(b)')
    tree_changed, _, _ = StringTypesTransformer.transform(ast_node)
    assert tree_changed
    assert ast.dump(ast_node) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='b', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-23 23:10:56.215741
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import shutil, sys
    from ..utils.code_gen import to_source
    from ..utils.tree_compare import tree_compare, tree_compare_no_ids
    from ..utils.tree_from_source import build_ast
    from .string_literals import StringLiteralsTransformer

    if sys.version_info < (3, 0):
        print("Unable to run tests for this transformer, as it is a Python 3-only transformer.")
        return

    # Test __init__
    assert StringTypesTransformer.target == (2, 7)

    # Test transform
    # Normal operation on a tree which matches the target version
    # before:
    # import os
    # print str(sys.maxunicode)
    # after:
    # import os
    # print unicode(sys.maxunicode)
   

# Generated at 2022-06-23 23:10:59.681016
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """str(x)"""
    tree = ast.parse(code)
    tree_changed, errors = (
        StringTypesTransformer.transform(tree)
    )

    assert code == astor.to_source(tree_changed)


# Generated at 2022-06-23 23:11:04.556382
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name(lineno=0, col_offset=0, id='str', ctx=ast.Load())
    new_node = ast.Name(lineno=0, col_offset=0, id='unicode', ctx=ast.Load())

    transformer = StringTypesTransformer()
    result = transformer.transform(node)

    assert result.new_tree == new_node    
    assert result.tree_changed == True
    assert result.errors == []

# Generated at 2022-06-23 23:11:10.616633
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert 'unicode' == StringTypesTransformer.transform(ast.parse('str')).tree.body[0].value.id
    assert not StringTypesTransformer.transform(ast.parse('str')).tree_changed
    assert 'unicode' ==  StringTypesTransformer.transform(ast.parse('str.split()')).tree.body[0].value.func.value.id
    assert not StringTypesTransformer.transform(ast.parse('str.split()')).tree_changed
    assert 'unicode' == StringTypesTransformer.transform(ast.parse('str(5)')).tree.body[0].value.args[0].n

# Generated at 2022-06-23 23:11:12.230409
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:11:16.833025
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    s = 'foo'
    """
    expected_code = """
    s = u'foo'
    """
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)

    assert result.tree == expected_tree


# Generated at 2022-06-23 23:11:17.755100
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

# Generated at 2022-06-23 23:11:23.472654
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test case for testing that the constructor of class is working."""
    # Arrange
    expected_2_7 = True
    expected_3_8 = False

    # Act
    result_2_7 = StringTypesTransformer(2, 7)
    result_3_8 = StringTypesTransformer(3, 8)

    # Assert
    assert result_2_7.target == (2, 7)
    assert result_3_8.target == (3, 8)


# Generated at 2022-06-23 23:11:29.767961
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
	
	module = ast.parse("x = b'abc'\nprint(x)")

	tree_changed, new_module = StringTypesTransformer.transform(module)

	assert(tree_changed)

	assert(new_module.body[1].value.s == "abc")
	assert(new_module.body[1].value.lineno == 2)
	assert(new_module.body[1].value.col_offset == 7)
	assert(str(new_module) == "x = 'abc'\nprint(x)\n")

	module = ast.parse("x = str('abc')\nprint(x)")

	tree_changed, new_module = StringTypesTransformer.transform(module)

	assert(tree_changed)

	assert(new_module.body[1].value.s == "abc")

# Generated at 2022-06-23 23:11:39.947375
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ss = StringTypesTransformer()
    assert len(ss.transform(ast.parse('''
str = 'hi'
str = str(1)
str = [str(s) for s in [str(s)]]
str = (str(1), str(2))
str = {str(1): str(2)}
str = '' in str''')).changed_trees) == 1
    assert len(ss.transform(ast.parse('''
str = 'hi'
str = str(1)
str = [str(s) for s in [str(s)]]
str = (str(1), str(2))
str = {str(1): str(2)}
str = '' in str''')).changed_trees) == 1


# Generated at 2022-06-23 23:11:42.855483
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    code = '''x = "asd"'''
    tree = ast.parse(code).body[0]
    tree = StringTypesTransformer.transform(tree)
    assert tree.body[0].value.s == u'asd'
    assert tree.body[0].value.__class__.__name__ == 'Str'

# Generated at 2022-06-23 23:11:45.604393
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import compare_ast
    from ..utils.static_analysis_utils import StaticAnalysisVisitor


# Generated at 2022-06-23 23:11:46.198268
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:11:56.093976
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:01.381873
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tests import get_test_ast

    module = get_test_ast('tuple_lib.py')

    assert module is not None
    assert isinstance(module, ast.AST)

    transformer = StringTypesTransformer(module)
    transformer.transform()

    assert transformer.tree_changed

# Generated at 2022-06-23 23:12:10.699916
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test transformation with constructors
    t1 = ast.parse('''str(obj)''')
    assert StringTypesTransformer.transform(t1).tree_changed == True, "Test 1," \
            " tree should have changed"

    # Test transformation with other str types
    t2 = ast.parse('''x = "test"''')
    assert StringTypesTransformer.transform(t2).tree_changed == False, "Test 2," \
            " tree should not have changed"

    # Test transformation with other str types
    t3 = ast.parse('''x = "test"''')
    assert StringTypesTransformer.transform(t3).tree_changed == False, "Test 3," \
            " tree should not have changed"

# Generated at 2022-06-23 23:12:20.136712
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_source_equal

    # Test the transformation of 'str'
    source = """
        str()
        str(42)
        str()
    """
    expected = """
        unicode()
        unicode(42)
        unicode()
    """
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert_source_equal(tree, expected)

    # Test the transformation of 'str'
    source = """
        type(foo) is str
        type(bar) == str
    """
    expected = """
        type(foo) is unicode
        type(bar) == unicode
    """
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)
    assert_source_equal(tree, expected)

# Generated at 2022-06-23 23:12:21.552615
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-23 23:12:28.457605
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    import inspect
    import _ast
    tree = ast3.parse('result = str(3)')
    node = tree.body[0].value
    module = ast3.parse('from __future__ import unicode_literals\n' + inspect.getsource(ast3))
    new_node = StringTypesTransformer.transform(node).tree
    exec(compile(module, filename="<ast>", mode="exec"))
    assert eval(compile(new_node, filename="<ast>", mode="exec")) == unicode(3)


# Generated at 2022-06-23 23:12:32.105870
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ...utils.testing import verify_transformer

    def test_case(text):
        """Returns a `str` instead of a `unicode` string."""
        the_str = str()
        return the_str

    verify_transformer(test_case, 2, 7, StringTypesTransformer)

# Generated at 2022-06-23 23:12:34.098128
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests StringTypesTransformer constructor.

    """
    print('Testing StringTypesTransformer constructor.')
    StringTypesTransformer()


# Generated at 2022-06-23 23:12:35.633472
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:37.836088
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('a = str(b)')).code == 'a = unicode(b)'

# Generated at 2022-06-23 23:12:43.366330
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    code = '''
    def foo(s: str) -> str:
        return s
    '''
    tree = ast.parse(textwrap.dedent(code))
    new_tree, tree_changed, messages = StringTypesTransformer.transform(tree)
    code = compile(new_tree, filename='<ast>', mode='exec')
    exec(code, dict())

# Generated at 2022-06-23 23:12:49.609817
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def _transform(source):
        tree = ast.parse(source)
        transformer = StringTypesTransformer()
        new_tree = transformer.visit(tree)
        gen = ast.NodeVisitor()
        return gen.visit(new_tree)

    assert ("x = unicode(1)" == _transform("x = str(1)"))
    assert ("x = unicode(1, 2, 3)" == _transform("x = str(1, 2, 3)"))
    assert ("x = 'unicode'" == _transform("x = 'str'"))

# Generated at 2022-06-23 23:12:53.008811
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # construct an AST node
    node = ast.Name()
    node.id = 'str'
    assert node.id == 'str'
    assert StringTypesTransformer.transfrom(node) == 'unicode'

# Generated at 2022-06-23 23:12:55.400128
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("str('string')"))[0] == ast.parse("unicode('string')")

# Generated at 2022-06-23 23:13:01.796033
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    code = """
a = str('1')
b = "str"
    """
    tree = ast.parse(code)

    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)

    assert new_tree.body[0].value.args[0].s == '1'
    assert new_tree.body[1].value.s == 'str'

# Generated at 2022-06-23 23:13:04.519924
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree1 = ast.parse("str(x)")

    transformed_tree1 = StringTypesTransformer.transform(tree1)

    tree2 = ast.parse("unicode(x)")

    assert ast.dump(transformed_tree1.tree) == ast.dump(tree2)

# Generated at 2022-06-23 23:13:15.904371
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test Module
    test_ast_Module = ast.Module(body=[
        ast.FunctionDef(
            name='asd',
            args=ast.arguments(
                args=[],
                vararg=None,
                kwarg=None,
                kwonlyargs=[],
                defaults=[],
                kw_defaults=[]
            ),
            body=[
                ast.Return(
                    value=ast.Name(
                        id='str',
                        ctx=ast.Load()
                    )
                )
            ],
            decorator_list=[],
            returns=None
        )
    ])

# Generated at 2022-06-23 23:13:17.006332
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:13:19.728892
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.python_src_parser import parse

    tree = parse('something = str(value)')
    tree_changed, messages = StringTypesTransformer.transform(tree)
    assert 'unicode' in str(tree)

# Generated at 2022-06-23 23:13:30.461268
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class MockTransformer(BaseTransformer):

        def __init__(self, version: int) -> None:
            self.tree_changed: bool = False
            super().__init__(version)

        def visit_Name(self, node: ast.Name) -> None:
            node.id = 'unicode'
            self.tree_changed = True

    mock = MockTransformer(version=3)

    ast_tree = ast.parse("s = str('hello world')")
    print(astor.to_source(ast_tree))
    mock.transform(ast_tree)
    print(astor.to_source(ast_tree))

    assert mock.tree_changed == True
    assert astor.to_source(ast_tree) == "s = unicode('hello world')\n"

# Generated at 2022-06-23 23:13:35.069363
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that `str` is replaced by `unicode`. """
    code = """
        str
    """
    ast_tree = parse(code)
    tree_changed, _ = StringTypesTransformer.transform(ast_tree)
    assert tree_changed, "StringTypesTransformer should have changed the tree."
    assert compile(ast_tree, "<test>", "exec")

# Generated at 2022-06-23 23:13:37.495859
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode


# Generated at 2022-06-23 23:13:45.438431
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Str

    class Test(ast.AST):
        _fields = ('a',)
        def __init__(self, a, **kwargs):
            self.a = a
            super(Test, self).__init__(**kwargs)

    class StrWrapper(ast.AST):
        _fields = ('a', 'b',)
        def __init__(self, a, b ,**kwargs):
            self.a = a
            self.b = b
            super(StrWrapper, self).__init__(**kwargs)

    class Test2(ast.AST):
        _fields = ('a',)
        def __init__(self, a, **kwargs):
            self.a = a

# Generated at 2022-06-23 23:13:47.377427
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_in = """
a = str(1)
b = str()
"""
    code_out = """
a = unicode(1)
b = unicode()
"""
    trans = StringTypesTransformer()
    trans.transform_code(code_in)
    assert code_out == trans.new_src

# Generated at 2022-06-23 23:13:54.759118
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import os, sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    from ..utils.source_code import SourceCode
    from ..utils.tree import dump

    code = SourceCode.from_statement("a = str(123) + 'abc'")
    tree = code.parse()
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    dump(new_tree)
    assert code.is_unchanged()

# Generated at 2022-06-23 23:13:57.480748
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("s = str()")
    new_tree = StringTypesTransformer.transform(tree)
    assert str(new_tree.tree) == "s = unicode()"

# Generated at 2022-06-23 23:13:58.424446
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:14:02.475898
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node1 = ast.ClassDef(name='Cls', body=[], decorator_list=[])
    mod = ast.Module(body=[node1])

    tr = StringTypesTransformer()
    res = tr.transform(mod)
    assert not res.tree_changed
    assert not res.details


# Unit test that checks if string constants will be converted to unicode

# Generated at 2022-06-23 23:14:06.431599
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""def f(x):
    return str(x)""")

    result, changed = StringTypesTransformer.transform(tree)

    corrected_tree = ast.parse("""def f(x):
    return unicode(x)""")

    assert changed
    assert ast.dump(result, include_attributes=False) == \
           ast.dump(corrected_tree, include_attributes=False)


# Generated at 2022-06-23 23:14:10.816960
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Consider a tree as follows: 
    tree = ast.Str('test')

    # Let's apply the transformation
    result_tree, tree_changed, messages = StringTypesTransformer.transform(tree)

    assert tree_changed is False
    assert result_tree.s == 'test'


# Generated at 2022-06-23 23:14:18.718398
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
        def f():
            str('a')
            str(x)

    """
    expected = """
        def f():
            unicode('a')
            unicode(x)

    """

    tree = ast.parse(source)
    tree = StringTypesTransformer.run_on(tree)
    tree = ast.fix_missing_locations(tree)
    result = compile(tree, mode='exec', filename='<string>')
    module = {}
    exec(result, module)
    assert expected == str(module['f'].__code__)

# Generated at 2022-06-23 23:14:19.732858
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform


# Generated at 2022-06-23 23:14:26.416116
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = str('a')")
    transformed = StringTypesTransformer.transform(tree)
    assert transformed.tree_changed
    assert transformed.node_count == 0
    assert isinstance(transformed.tree, ast.AST)
    assert ast.dump(transformed.tree) == "Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='a')], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-23 23:14:28.139745
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert hasattr(StringTypesTransformer, 'transform')


# Unit test class StringTypesTransformer

# Generated at 2022-06-23 23:14:28.618538
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:14:30.771954
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    temp = StringTypesTransformer()
    assert temp.target == (2, 7)
    assert temp.verbose == 0

# Generated at 2022-06-23 23:14:31.731264
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:14:32.530087
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:14:40.325026
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Code to be transformed:
    code = 'a = str(1)'
    # Expected transformed code:
    expected_res = 'a = unicode(1)'
    # AST of code to be transformed:
    code_ast = ast.parse(code)
    # Making transformation using the Transformer class:
    result = StringTypesTransformer.transform(code_ast)
    # Getting back the modified code from the AST:
    res = astor.to_source(result.tree).strip()
    # Assertions:
    assert result.tree_changed == True
    assert res == expected_res

# Generated at 2022-06-23 23:14:44.890564
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = "str()"
    tree = ast.parse(s)
    tree = StringTypesTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"


# Generated at 2022-06-23 23:14:50.724085
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    import ast

    tree = ast.parse(textwrap.dedent(r'''
        s = str()
        '''))

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed is True

    tree = ast.parse(textwrap.dedent(r'''
        s = unicode()
        '''))

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed is False

# Generated at 2022-06-23 23:14:51.269560
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:14:57.556470
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # arranges
    input_program = '''
        def a(b: str):
            print(b)
    '''
    expected_output = '''
        def a(b: unicode):
            print(b)
    '''
    tree = ast.parse(input_program)

    # acts
    result = StringTypesTransformer.transform(tree)

    # asserts
    assert result.tree_changed
    assert ast.dump(result.tree) == expected_output

# Generated at 2022-06-23 23:15:02.206061
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    source = """
# Prints 'Hello World'
print str('Hello World')
    """
    expected = """
# Prints 'Hello World'
print unicode('Hello World')
    """

    # Act
    actual = StringTypesTransformer.transform(source)

    # Assert
    assert expected == actual

# Generated at 2022-06-23 23:15:06.635154
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "a = str('text')"
    expected = "a = unicode('text')"
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    new_code = compile(new_tree.tree, '', 'exec')
    namespace = {}
    exec(new_code, {}, namespace)
    assert namespace['a'] == 'text'

# Generated at 2022-06-23 23:15:17.105643
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    from ..utils.general import get_func_body

    assert StringTypesTransformer(target_version=(2, 6))
    assert StringTypesTransformer(target_version=(2, 7))
    with pytest.raises(ValueError):
        StringTypesTransformer(target_version=(2, 5))
    with pytest.raises(ValueError):
        StringTypesTransformer(target_version=(2, 8))

    assert not StringTypesTransformer(2, 7).visit(get_func_body('''
    def foo(a: str) -> str:
        return 1
    ''')).tree_changed


# Generated at 2022-06-23 23:15:22.630617
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_tree = ast.parse('def test(thing): return str(thing)')
    expected_tree = ast.parse('def test(thing): return unicode(thing)')

    # Call the test method
    transformer = StringTypesTransformer()
    actual_tree = transformer.visit(input_tree)

    # Make sure the ASTs are equal
    assert ast.dump(actual_tree) == ast.dump(expected_tree)


# Generated at 2022-06-23 23:15:26.281601
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        a = str()
    """)
    tree2 = ast.parse("""
        a = unicode()
    """)

    tt = StringTypesTransformer()
    tt.transform(tree)

    assert ast.dump(tree) == ast.dump(tree2)

# Generated at 2022-06-23 23:15:30.174689
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    x = str(x)
    """
    tree = source_to_ast(source)

    new_tree, tree_changed, messages = StringTypesTransformer.transform(tree)
    assert tree_changed

    assert find(new_tree, ast.Name) == [ast.Name(id='unicode', ctx=ast.Load())]
    assert messages == []


# Generated at 2022-06-23 23:15:33.164286
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class FakeModule(object):
        pass
    module = FakeModule()
    module.node = ast.parse('str(1)')
    StringTypesTransformer.transform(module)
    assert module.node.body[0].value.func.id == 'unicode'

# Generated at 2022-06-23 23:15:34.641864
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 23:15:38.964382
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    import textwrap
    source = textwrap.dedent(
        """
        """
    )
    tree = ast.parse(source)
    result = StringTypesTransformer.transform(tree)
    print(astor.to_source(result.tree))
    assert result.tree_changed is True

# Generated at 2022-06-23 23:15:40.712978
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import check_transformer
    from pprint import pprint


# Generated at 2022-06-23 23:15:50.597228
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import build_ast
    from ..utils.compat import force_unicode

    string_type_transformer = StringTypesTransformer()
    string_type_transformer.set_target(2, 7)

    code_1 = force_unicode("if type(myvar) == str:")
    code_1_transformed = force_unicode("if type(myvar) == unicode:")

    # The following should not trigger
    code_2 = force_unicode("if type(myvar) == bytes:")
    code_3 = force_unicode("if type(myvar) == str and name == 'some str':")

    ast_1 = build_ast(code_1)
    ast_1_transformed = build_ast(code_1_transformed)
    ast_2 = build_ast

# Generated at 2022-06-23 23:15:53.515119
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        x = "str"
        """
    expected = """
        x = "unicode"
        """

    tree = ast.parse(code)
    transformed = StringTypesTransformer.transform(tree)
    assert transformed.code == expected

# Generated at 2022-06-23 23:15:54.979974
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
   tree = ast.parse('x = str(1)')
   assert StringTypesTransformer.transform(tree)

# Generated at 2022-06-23 23:15:55.470985
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:15:56.212152
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:16:02.865234
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from ..utils.render import pprint_ast

    tree = source_to_ast("""
        print("hello")
        user_input = str(input("Enter your name: "))
    """)
    print("Before: ")
    print(pprint_ast(tree))
    print("After: ")
    print(pprint_ast(StringTypesTransformer.transform(tree).tree))


if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:16:10.505222
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree

    code = """
            a = str()
        """

    tree = source_to_tree(code)
    tree = StringTypesTransformer.transform(tree).tree

    a = tree.body[0].targets[0]
    assert isinstance(a, ast.Name)
    assert a.id == 'a'

    a_value = tree.body[0].value
    assert isinstance(a_value, ast.Call)
    assert isinstance(a_value.func, ast.Name)
    assert a_value.func.id == 'unicode'

# Generated at 2022-06-23 23:16:13.309867
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    from ..utils.source import source_to_unicode as to_uni
    from ..utils.source import source_to_ast as to_ast


# Generated at 2022-06-23 23:16:17.216954
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.sample_code import sample_code
    from ..utils.ast_converter import AstConverter

    tree = AstConverter.parse_ast(sample_code)

    transformations = StringTypesTransformer.transform(tree)
    # tree_changed = next(transformations)

    # assert tree_changed
    # assert len(list(transformations)) == 1

# Generated at 2022-06-23 23:16:20.606220
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

    test_str = 'a = str("test")'
    test_ast = ast.parse(test_str)
    result = StringTypesTransformer.transform(test_ast)
    assert result.tree_changed == True
    assert astunparse.unparse(result.tree).strip() == 'a = unicode("test")'

# Generated at 2022-06-23 23:16:24.416510
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
    def foo():
        a = str()
        return a
    """

    expected = """
    def foo():
        a = unicode()
        return a
    """

    tr = StringTypesTransformer.transform(ast.parse(src))
    assert ast.dump(tr.tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 23:16:28.610144
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert ast.dump(
        StringTypesTransformer.transform(ast.parse('str "test"'))[0]) == 'Module(body=[Expr(value=Call(func=Name(id=unicode, ctx=Load()), args=[Str(s=test)], keywords=[], starargs=None, kwargs=None))])'

# Returns a str with the function to test

# Generated at 2022-06-23 23:16:29.853089
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tf = StringTypesTransformer()


# Generated at 2022-06-23 23:16:32.371205
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """str("")"""
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert code == astor.to_source(tree)

# Generated at 2022-06-23 23:16:40.587842
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    test_code = """
    """
    run_test(test_code, StringTypesTransformer)

    # Test 2
    test_code = """
    s = str(1)
    if (s == '1'):
        print(s)
    """
    run_test(test_code, StringTypesTransformer)

    # Test 3
    test_code = """
    s = '1'
    if (str(1) == s):
        print(s)
    """
    run_test(test_code, StringTypesTransformer)

    # Test 4
    test_code = """
    s = ''
    if (str(1) != s):
        print(s)
    """
    run_test(test_code, StringTypesTransformer)

    # Test 5
    test_code

# Generated at 2022-06-23 23:16:51.151712
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    code = 'def foo(bar: str = "baz"):\n    quux = str(bar)'
    tree = astor.parse_string(code)
    transformer = StringTypesTransformer()
    new_tree = transformer.transform(tree)

    assert new_tree.tree_changed == True

    # Get new code string and compare to expected
    transformed_code = astor.to_source(new_tree.new_tree)
    expected_code = 'def foo(bar=unicode("baz")):\n    quux = unicode(bar)'

    assert transformed_code == expected_code

    # Unit test for string args to call
    def_code = 'def bar(bar: unicode = "baz"):\n    quux = unicode(bar)'

# Generated at 2022-06-23 23:16:52.759758
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import bytes_to_ast_tree, tree_to_bytes
    from ..types import TransformationResult


# Generated at 2022-06-23 23:16:53.708456
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class `StringTypesTransformer`.

    """
    pass

# Generated at 2022-06-23 23:17:02.011013
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests for `StringTypesTransformer`"""
    transformer = StringTypesTransformer()
    import astunparse
    parsed_ast = ast.parse(
        '''
        class Test(object):
            """This is a test."""
            def __init__(self, a: str) -> str:
                return str(a)
        '''
    )
    result = transformer.transform(parsed_ast)
    print(
        astunparse.unparse(result.tree)
    )
    # TODO: add assert.


if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:17:12.729423
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    import inspect
    import re

    source_code_string = r'''
    def k():
        pass
    '''

    py_version = sys.version_info[0:2]
    if py_version[0] == 2:
        target = py_version
    else:
        target = (2, 7)

    ast_2 = compile(source_code_string, filename="<ast>", mode="exec", dont_inherit=True)
    tree_2 = ast.fix_missing_locations(ast_2)

    trans = StringTypesTransformer(target)
    trans.transform(tree_2)

    # check if the source code string is changed
    code_object = compile(tree_2, filename="<ast>", mode="exec", dont_inherit=True)
    source_

# Generated at 2022-06-23 23:17:19.789144
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from astor.code_gen import to_source
    
    t = StringTypesTransformer.transform

    # Simple case
    source = """
    A = "test"
    """
    tree = ast.parse(source)
    transformed_res = t(tree)
    assert len(transformed_res.failures) == 0
    assert transformed_res.tree_changed == True
    assert to_source(transformed_res.tree) == "A = u'test'"

    # More complicated case
    source = """
    def has_non_ascii(x):
        return any(ord(c) not in range(128) for c in x)
    """
    tree = ast.parse(source)
    transformed_res = t(tree)
    assert len(transformed_res.failures) == 0
    assert transformed

# Generated at 2022-06-23 23:17:21.053485
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  # We need to make sure that the class can be initialized
  transformer = StringTypesTransformer()
  assert transformer is not None

# Generated at 2022-06-23 23:17:21.762056
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    _ = StringTypesTransformer()

# Generated at 2022-06-23 23:17:23.237641
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()

# Generated at 2022-06-23 23:17:25.593698
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # from typed_ast import ast3
    from .base import BaseAPITransformer
    from .unicode_literals_transformer import UnicodeLiteralsTransformer


# Generated at 2022-06-23 23:17:33.227225
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer(2.6)

    t_node = ast.parse('a = 1\nstr(a)\n')
    t_tree = t.visit(t_node)
    assert 'unicode(a)' in ast.dump(t_tree)
    assert t.tree_changed == True

    t_node = ast.parse('a = 1\nb = 2')
    t_node = t.visit(t_node)
    assert 'str' not in ast.dump(t_node)
    assert t.tree_changed == False

# Generated at 2022-06-23 23:17:42.523628
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test string-only
    source = 'x = "Test"\n'
    expected_result = 'x = unicode("Test")\n'
    result = StringTypesTransformer.transform_source(source)
    assert result.source == expected_result
    assert result.tree_changed

    # Test multiple string-only
    source = 'x = "Test"\nprint "Test"\n'
    expected_result = 'x = unicode("Test")\nprint unicode("Test")\n'
    result = StringTypesTransformer.transform_source(source)
    assert result.source == expected_result
    assert result.tree_changed

    # Test function definition without parameter
    source = 'def addition():\n  n = "Test"\n'

# Generated at 2022-06-23 23:17:45.310241
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test on target
    code = '''if isinstance(i, str):'''

    expected_code = '''if isinstance(i, unicode):'''

    tr = StringTypesTransformer.transform(code)
    tree = tr.tree

    assert astor.to_source(tree) == expected_code

# test on other version

# Generated at 2022-06-23 23:17:52.346792
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    def foo(a: str):
        x = "abc"
        return y
    '''

    transformed_tree = StringTypesTransformer.transform(ast.parse(code))
    assert isinstance(transformed_tree, TransformationResult)

    class_construction = ast.parse('StringTypesTransformer()')
    class_construction_transformed = StringTypesTransformer.transform(
        class_construction)

    assert isinstance(class_construction_transformed, TransformationResult)

# Generated at 2022-06-23 23:17:52.921714
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:17:58.920241
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # get AST sample
    input_str = 'str'
    tree = ast.parse(input_str)
    # run constructor
    result = StringTypesTransformer.transform(tree)
    # test it
    print(result.tree)
    print(type(result.tree))
    assert isinstance(result.tree, ast.Module)
    assert isinstance(result.tree._fields[0], ast.Name)
    assert result.tree._fields[0].id == 'unicode'

# Generated at 2022-06-23 23:18:06.784553
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transform, assert_not_transform
    from ..utils.testing import assert_warnings

    assert_transform(
        StringTypesTransformer(2, 7), """
        import builtins
        def f(x):
            assert isinstance(x, str)
        """, """
        import builtins
        def f(x):
            assert isinstance(x, unicode)
        """
    )

    assert_not_transform(
        StringTypesTransformer(2, 7), """
        import builtins
        def f(x):
            x = str(x)
        """
    )

# Generated at 2022-06-23 23:18:12.089389
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
    a = str("123")
    """
    res = StringTypesTransformer.transform(ast.parse(src))
    if res.tree_changed:
        print(astunparse.unparse(res.tree))
    assert astunparse.unparse(res.tree).strip() == "a = unicode('123')"


# auto registration of class
StringTypesTransformer.register()

# Generated at 2022-06-23 23:18:12.921928
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TODO: implement
    pass

# Generated at 2022-06-23 23:18:17.572912
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_code = """
    a = str("Apple")
    """
    expected_output = """
    a = unicode("Apple")
    """
    tree = ast.parse(input_code)
    expected_tree = ast.parse(expected_output)

    tree_changed, errors, output_code = StringTypesTransformer.transform(tree)
    assert(tree_changed == True)

    exec(output_code)
    assert(a == "Apple")

test_StringTypesTransformer()

# Generated at 2022-06-23 23:18:22.085193
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    tree = ast.parse("""a = str(int(1 + 0.7))""")
    new_tree = t.transform(tree)
    new_code = astor.to_source(new_tree)
    assert(new_code.strip() == """a = unicode(int(1 + 0.7))""")

# Generated at 2022-06-23 23:18:28.684590
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
    a = str(4) + "4"
    ''')
    result = StringTypesTransformer.transform(tree)
    assert compile(result.tree, '', 'exec') == compile(
        ast.parse('''
    a = unicode(4) + "4"
    '''), '', 'exec')
    assert result.tree_changed == True
    assert result.messages == []

# Generated at 2022-06-23 23:18:32.547419
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
        str(1)
        str('a')
        str(bytes('a', 'utf-8'))
    """)
    new_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(tree) != ast.dump(new_tree)

# Generated at 2022-06-23 23:18:39.255366
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # "str" -> "unicode"
    tree = ast.parse("""s = str("abc")""")
    expected = ast.parse("""s = unicode("abc")""")

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert ast.dump(tree) == ast.dump(expected)

    # "str" -> "unicode", but only "str" is replaced
    tree = ast.parse("""s = str("abc")""")
    expected = ast.parse("""s = unicode("abc")""")

    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-23 23:18:40.546863
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert(isinstance(StringTypesTransformer(), BaseTransformer))


# Generated at 2022-06-23 23:18:49.830160
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.FunctionDef('test', ast.arguments([], None, None, [], None, [], []), [], [], None)
    assert StringTypesTransformer.transform(node) == TransformationResult(node, False, [])

    node = ast.FunctionDef('test', ast.arguments([], None, None, [ast.Name('str', ast.Load())], None, [], []), [], [], None)
    expected = ast.FunctionDef('test', ast.arguments([], None, None, [ast.Name('unicode', ast.Load())], None, [], []), [], [], None)
    assert StringTypesTransformer.transform(node) == TransformationResult(expected, True, [])

# Generated at 2022-06-23 23:18:52.077583
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a == str(b)')
    tree = StringTypesTransformer.transform(tree)
    assert tree.body[0].value.left.id == 'a'
    assert tree.body[0].value.comparators[0].func.id == 'unicode'

# Generated at 2022-06-23 23:18:53.056694
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:18:57.899328
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from astunparse import unparse
    input_string = "str(1)"
    astree = ast3.parse(input_string)
    expected_output = "unicode(1)"

    tree = StringTypesTransformer.transform(astree)
    tree_changed = tree.changed
    treeprinter = unparse(tree.tree)
    assert treeprinter == expected_output
    assert tree_changed == True

# Generated at 2022-06-23 23:18:59.781921
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTestTransformer
    BaseTestTransformer.test(StringTypesTransformer, '{}')


# Generated at 2022-06-23 23:19:02.644754
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from ..utils.output import dump

    t = ast.parse('x = str(y)')
    print(dump(t))

    t = transform(ast.parse('x = str(y)'))
    print(dump(t))

# Generated at 2022-06-23 23:19:03.299288
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:19:05.974909
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): # TODO: PY2-3
    a = ast.parse('str(x)')
    b = ast.parse('''
        from __future__ import unicode_literals
        unicode(x)
    ''')
    assert StringTypesTransformer.transform(a) == TransformationResult(b, True, [])

# Generated at 2022-06-23 23:19:16.148694
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from ..types import TransformationResult


    source = """
            def add(x, y):
                return x + y

            class StringTest(object):
                def __init__(self):
                    self.value = 'z'

                def __str__(self):
                    return '<' + self.value + '>'

                def __repr__(self):
                    return '<' + self.value.upper() + '>'

                def f(self):
                    return add(1, 2)
            """
    

# Generated at 2022-06-23 23:19:22.186260
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    print('Python version:', sys.version)
    # parse code string
    root = ast.parse(textwrap.dedent('''\
    s = str(foo)
    bar(str)
    '''))
    print('Before:')
    print(ast.dump(root), end='')

    # run transformation
    t = StringTypesTransformer()
    _, _, error_messages = t.transform(root)
    print('After:')
    print(ast.dump(root), end='')

    # print error messages
    if error_messages:
        print('\nErrors:')
        for m in error_messages:
            print('  {}'.format(m))


if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:19:23.016370
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:19:27.495290
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        a = str(something)
    """

    tree = ast.parse(code)
    expected_tree = ast.parse("""
        a = unicode(something)
    """)

    result, _ = StringTypesTransformer.transform(tree)
    ast.fix_missing_locations(result)

    assert ast.dump(result) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:19:31.667054
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that StringTypesTransformer replaces str with unicode."""
    tree = ast.parse("str(5)")
    StringTypesTransformer.transform(tree)
    new_tree = ast.parse("unicode(5)")
    assert ast.dump(tree) == ast.dump(new_tree)

# Generated at 2022-06-23 23:19:40.767018
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # noinspection PyUnresolvedReferences
    import typing
    # noinspection PyUnresolvedReferences
    from typed_ast import ast3 as ast
    # noinspection PyUnresolvedReferences
    from typed_ast import convert
    from .base import BaseASTCase

    class SampleAstCase(BaseASTCase):
        def test_return_string(self):
            code = 'def foo():\n return "Hello world."'
            tree = ast.parse(code)
            self.assert_transformation(StringTypesTransformer, code, tree)

        def test_return_unicode(self):
            code = 'def foo():\n return "Hello world."'
            tree = ast.parse(code)
            self.assert_no_transformation(StringTypesTransformer, code, tree)


# Generated at 2022-06-23 23:19:44.449567
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from ..utils.source import Source
    source = Source('''
s = str(123)
''')
    expected_source = Source('''
s = unicode(123)
''')
    tree = source.ast
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert astunparse.unparse(result.tree) == expected_source.text


# Generated at 2022-06-23 23:19:44.935117
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:19:47.007211
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
z = str(string)
'''

# Generated at 2022-06-23 23:19:51.778779
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert(str == unicode)
    assert(str(ast.Name('str', ast.Load())) == unicode(ast.Name('unicode', ast.Load())))
    assert(ast.Name('str', ast.Load()) == ast.Name('unicode', ast.Load()))

# Generated at 2022-06-23 23:20:00.980255
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    line_1 = 'a = str(123)'
    line_2 = 'b = "str"'
    line_3 = 'c = "str"'
    line_4 = 'd = unicode(123)'
    line_5 = 'e = "unicode"'
    lines = '\n'.join([line_1, line_2, line_3, line_4, line_5])
    
    tree = ast.parse(lines)
    new_tree, tree_changed = StringTypesTransformer.transform(tree)
    assert tree_changed == True
    assert isinstance(new_tree, ast.AST)
    code = compile(new_tree, filename='<string>', mode='exec')
    exec(code)
    assert a == '123'
    assert b == str
    assert c == 'str'

# Generated at 2022-06-23 23:20:08.769557
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

    source = """
    def f(a, b):
        c = a + b
        return c
    """

    expected_transformed_source = """
    def f(a, b):
        c = a + b
        return c
    """

    tree = ast.parse(source)
    tree_transformed = StringTypesTransformer.transform(tree)
    source_transformed = astunparse.unparse(tree_transformed.tree)

    assert source_transformed == expected_transformed_source


# Generated at 2022-06-23 23:20:11.282975
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    transformer = StringTypesTransformer()

    assert transformer is not None

# Generated at 2022-06-23 23:20:19.248842
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    tree = ast.parse(
        """
        def foo(a):
            return str(a)
        """
    )

    # print(ast.dump(tree))
    res = StringTypesTransformer.transform(tree)
    # print(ast.dump(res.node))

    tree_res = ast.parse(
        """
        def foo(a):
            return unicode(a)
        """
    )

    assert ast.dump(res.node) == ast.dump(tree_res)
    assert res.tree_changed == True