

# Generated at 2022-06-23 23:10:26.292326
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test import make_test_tree, compare_trees, transform_file

    # Make input tree
    test_tree = make_test_tree('''
        import random as r
        random.randint(1, 100)
    ''')
    # Make expected result tree
    expected_tree = make_test_tree('''
        import random as r
        random.randint(1, 100)
    ''')

    # Perform transformation and make sure it worked
    new_tree = StringTypesTransformer.transform(test_tree)
    new_tree, tree_changed, messages = new_tree
    assert tree_changed is True
    compare_trees(new_tree, expected_tree)

    # Make sure the transformation works on a file

# Generated at 2022-06-23 23:10:26.980495
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:10:27.700789
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:10:30.665740
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    tree = ast.parse('str(1)')

    # Act
    result = StringTypesTransformer.transform(tree)

    # Assert
    assert result.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-23 23:10:35.426084
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = 'str(number)'
    expected = 'unicode(number)'
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.run_it(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected))
 

# Generated at 2022-06-23 23:10:36.456753
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    # Act
    # Assert
    assert True

# Generated at 2022-06-23 23:10:38.722166
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    NAME = 'unicode'
    NAME_TO_NID = {'unicode': 1}
    LINENO = 2
    COL_OFFSET = 3

# Generated at 2022-06-23 23:10:46.655873
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    from ...context import Context
    from ...environment import Environment
    from ...manager import Manager
    from ...utils import make_trio

    context = Context(Environment(Manager()))
    context.add_transformer(StringTypesTransformer.get_name(), StringTypesTransformer())

    source = make_trio('''
        class MyClass(object):
            def __init(self):
                self.name = str()
    ''')

    # When
    trio = context.transform(source)
    exec(trio, globals())

    # Then
    assert MyClass.__name__ == 'MyClass'
    assert isinstance(MyClass(), MyClass)
    assert isinstance(MyClass().name, unicode)

# Generated at 2022-06-23 23:10:51.695438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ..utils.testing import dump_to_string
    from .base import BaseTransformer

    tree = ast3.parse('x = str()')
    tree2 = StringTypesTransformer.transform(tree)

    assert 'unicode()' in dump_to_string(tree2)

# Generated at 2022-06-23 23:10:53.561089
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.

    """
    assert StringTypesTransformer.targe

# Generated at 2022-06-23 23:10:58.848791
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        for i in range(10):
            str(i)
    """
    module = ast.parse(code)
    transformer = StringTypesTransformer()
    new_module = transformer.transform(module)
    assert(transformer.tree_changed)
    assert("for i in range(10):" in astor.to_source(new_module))
    assert("unicode(i)" in astor.to_source(new_module))

# Generated at 2022-06-23 23:11:05.833845
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree_before = """
        from regex import regex
        from regex import regex

        s = str(regex.findall(r'\w+', 'hello world'))
        if len(s) == 1:
            s = str(s[0])
        print(s)
    """
    tree_after = """
        from regex import regex
        from regex import regex

        s = unicode(regex.findall(r'\w+', 'hello world'))
        if len(s) == 1:
            s = unicode(s[0])
        print(s)
    """

    tree = ast.parse(tree_before)
    tree = StringTypesTransformer.run_on_single_file(tree)
    assert astor.to_source(tree) == tree_after

# Generated at 2022-06-23 23:11:11.793204
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_before = '''
a = str(a)
b = str
b = str(b)
c = str('a')
d = str('b')
'''

    code_after = '''
a = unicode(a)
b = unicode
b = unicode(b)
c = unicode('a')
d = unicode('b')
'''

    tr = StringTypesTransformer()
    tr.target = (2, 7)
    tree_before = ast.parse(code_before)
    tree_after = ast.parse(code_after)
    res = tr.transform(tree_before)
    assert res.tree == tree_after

# Generated at 2022-06-23 23:11:19.321210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    import inspect

    from typed_ast import ast3
    from typed_ast import util
    from typed_ast import ast27
    from ..utils.source_code import get_ast

    class StringTypesTransformerTest(unittest.TestCase):
        def test_zero(self):
            tree = get_ast(inspect.getsource(test_StringTypesTransformer))

            result = StringTypesTransformer.transform(tree)
            self.assertEqual(get_ast(result.tree), tree)


# Generated at 2022-06-23 23:11:28.257448
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # print(ast.dump(tree))
    tree = ast.parse(textwrap.dedent('''
        from __future__ import unicode_literals
        x = str('asdf')
        '''))
    expected = ast.parse(textwrap.dedent('''
        from __future__ import unicode_literals
        x = str('asdf')
        '''))
    assert StringTypesTransformer.transform(tree) == (expected, False)

    tree = ast.parse(textwrap.dedent('''
        from __future__ import unicode_literals
        x = str('asdf')
        '''))
    expected = ast.parse(textwrap.dedent('''
        from __future__ import unicode_literals
        x = unicode('asdf')
        '''))
   

# Generated at 2022-06-23 23:11:34.960899
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    test_input = ast3.parse("def foo(a):\n return str(a)")
    test_output = StringTypesTransformer.transform(test_input)
    assert test_output.is_changed is True
    assert test_output.calls == []
    assert test_output.tree == ast3.parse("def foo(a):\n return unicode(a)")
    assert test_output.tree == test_input

# Generated at 2022-06-23 23:11:39.903065
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Make sure that tree has been changed
    node = ast.Str('test')
    result = StringTypesTransformer.transform(node)
    assert result.tree_changed

    # Make sure that name has not been changed
    node = ast.Name('test', ast.Load())
    result = StringTypesTransformer.transform(node)
    assert not result.tree_changed

# Generated at 2022-06-23 23:11:41.882138
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import parse
    tree = parse("s = str(b)")

    result = StringTypesTransformer.transform(tree)

    assert(isinstance(result.tree, ast.AST))
    assert(result.tree_changed == True)

# Generated at 2022-06-23 23:11:52.704754
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "str('abc')"
    tree = ast.parse(code)
    res = StringTypesTransformer.transform(tree)
    assert res.tree_changed is True
    print(res.tree)
    print(ast.dump(res.tree))
    # See https://stackoverflow.com/questions/29203298/statements-and-expressions-in-ast-module-of-python
    assert ast.dump(res.tree) == "Module(body=[Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='abc')], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-23 23:11:56.437134
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_tools import modify
    from ..utils.ast_builder import cst_to_ast

    cst = cst_to_ast("""
        a = str("hello")
    """)

    transformed, _ = modify(cst, [StringTypesTransformer])

    assert transformed == cst_to_ast("""
        a = unicode("hello")
    """)

# Generated at 2022-06-23 23:12:04.535512
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = str('hello')")
    result = StringTypesTransformer.transform(tree)
    assert result.changed
    assert result.messages == []
    assert isinstance(result.tree, ast.AST)
    assert str(result.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='hello')], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-23 23:12:08.398389
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_toolbox import ast_to_code

    source = """j = str()"""
    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert ast_to_code(tree) == "j = unicode()"



# Generated at 2022-06-23 23:12:10.126463
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.name in transformer.__class__.__name__

# Generated at 2022-06-23 23:12:17.080944
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'a = str("123")'
    tree = ast.parse(code)

    StringTypesTransformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='123')], keywords=[], starargs=None, kwargs=None))])"


__transformer__ = StringTypesTransformer

# Generated at 2022-06-23 23:12:21.251786
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # arrange
    from typed_ast import ast3 as ast
    from ..utils.source import Source

    source = Source('def test(): return 1')
    tree = ast.parse(source.read())

    # act
    result = StringTypesTransformer.transform(tree)

    # assert
    assert not result.tree_changed

# Generated at 2022-06-23 23:12:26.137895
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap

    code = """x = str()"""
    tree = ast.parse(textwrap.dedent(code))

    expected = """x = unicode()"""
    expected_tree = ast.parse(textwrap.dedent(expected))

    tree = StringTypesTransformer.run(tree)

    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:12:29.872384
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open('test/testcases/2to3/StringTypes.py', 'r') as f:
        code = f.read()
        tree = ast.parse(code)
        StringTypesTransformer.transform(tree)
        assert compile(tree, '<test>', 'exec')
        exec(compile(tree, '<test>', 'exec'))

# Generated at 2022-06-23 23:12:34.010821
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Setup
    source = '''
    s = str
    '''

    # Execute
    tree = ast.parse(source)
    StringTypesTransformer.transform(tree)

    # Verify
    expected = '''
    s = unicode
    '''

    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 23:12:35.163869
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:45.534206
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys, io, unittest

    class StringTypesTransformerTest(unittest.TestCase):
        """Unit test class for StringTypesTransformer

        """
        def setUp(self):
            self._maxDiff = None

        def test_transform(self):
            test_code = \
            """
            a = str()
            b = str('abc')
            """

            expected_code = \
            """
            a = unicode()
            b = unicode('abc')
            """

            tree = ast.parse(test_code)
            new_tree, is_changed, _ = StringTypesTransformer.transform(tree)
            self.assertTrue(is_changed)


# Generated at 2022-06-23 23:12:48.904259
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    source = '''a = str("a")'''
    expected = '''a = unicode("a")'''
    assert StringTypesTransformer.transform(ast3.parse(source)).code == expected

# Generated at 2022-06-23 23:12:56.957240
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
str()
str.lower()
str.upper()
str.capitalize()
str.isspace()
str.endswith()
str.translate()
str.replace()
str.ljust()
str.rjust()
str.count()
str.split()
str.join()
str.splitlines()
str.rsplit()
str.partition()
str.rpartition()
str.lstrip()
str.rstrip()
str.strip()
str.swapcase()
"""


# Generated at 2022-06-23 23:13:02.074592
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import ast_to_str

    module = ast.parse('print str("hello")')
    module_transformed = StringTypesTransformer.transform(module)
    module_transformed_str = ast_to_str(module_transformed)
    assert module_transformed_str == 'print unicode("hello")'



# Generated at 2022-06-23 23:13:05.220008
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform(ast.parse("a = str('Hello')")) == TransformationResult(ast.parse("a = unicode('Hello')"), True, [])


# Generated at 2022-06-23 23:13:12.998624
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str("foo")')
    tree = StringTypesTransformer.transform(tree)

    assert tree.body[0].value.args[0].s == 'foo'
    assert isinstance(tree.body[0].value.args[0], ast.Str)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert tree.body[0].value.func.id == 'unicode'



# Generated at 2022-06-23 23:13:13.695212
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:13:19.903069
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import run_transformer_on_code

    # Test on code
    assert run_transformer_on_code(StringTypesTransformer,
    """
    import bar
    a = {}
    if isinstance(a, str):
        a = '3'
    a.upper()
    """) == \
    """
    import bar
    a = {}
    if isinstance(a, unicode):
        a = '3'
    a.upper()
    """.strip()

# Generated at 2022-06-23 23:13:20.646311
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:13:25.888735
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.Name('str', ast.Load())
    transformer = StringTypesTransformer()
    result = transformer.transform_tree(x)
    node = result[0]
    assert isinstance(result[0], ast.Name)
    assert node.id == 'unicode'
    assert result[1] == True
    assert result[2] == []

# Generated at 2022-06-23 23:13:31.617838
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.data_structures import Node  # noqa
    from ..utils.data_structures import tree_from_string  # noqa
    from ..utils.testing import get_node_of_type  # noqa

    string_bef = '''
import os
print(str(12))
'''

    expected_after = '''
import os
print(unicode(12))
'''

    after, ch = StringTypesTransformer.transform(tree_from_string(string_bef))
    assert ch
    assert after == tree_from_string(expected_after)

# Generated at 2022-06-23 23:13:36.679167
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import parse

    ast_orig = parse('s = str("abc")')
    ast_expected = parse('s = unicode("abc")')

    tree_changed, messages = StringTypesTransformer.transform(ast_orig)
    assert tree_changed is True
    assert ast.dump(ast_expected) == ast.dump(ast_orig)

# Generated at 2022-06-23 23:13:43.705447
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    import textwrap
    source = textwrap.dedent("""
        class Foo:
            def __init__(self):
                self.bar = str()
    """)

    tree = astor.parse_file(source)
    transformed, _ = StringTypesTransformer.transform(tree)

    expected_source = textwrap.dedent("""
        class Foo:
            def __init__(self):
                self.bar = unicode()
    """)

    expected_tree = astor.parse_file(expected_source)

    assert astor.to_source(transformed) == astor.to_source(expected_tree)

# Generated at 2022-06-23 23:13:44.701305
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Class instantiation unit test
    x = StringTypesTransformer()


# Generated at 2022-06-23 23:13:45.702635
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print('Testing StringTypesTransformer...')

# Generated at 2022-06-23 23:13:48.690076
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''str(3)''')
    expected = '''unicode(3)'''

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    print(result.tree)
    print(result.tree_changed)
    print(expected)
    assert(str(result.tree) == expected)

# Generated at 2022-06-23 23:13:49.902910
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert "unicode" in str(StringTypesTransformer)


# Generated at 2022-06-23 23:13:51.771369
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..transformations.string_types import StringTypesTransformer


# Generated at 2022-06-23 23:13:55.944372
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
        a = str()
    """

    tree = ast.parse(source)
    tree = StringTypesTransformer.transform(tree)

    assert ast.dump(tree) == ast.dump(ast.parse("a = unicode()"))



# Generated at 2022-06-23 23:14:00.486639
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    py2 = """
s = str(2.2)
"""
    py3 = """
s = unicode(2.2)
"""
    assert StringTypesTransformer.transform(ast.parse(py2)) == \
        ast.parse(py3)
    assert StringTypesTransformer.transform(ast.parse(py3)) == \
        ast.parse(py3)



# Generated at 2022-06-23 23:14:04.785515
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        def f(x: str):
            print("x")
    """
    c = compile(code, '<string>', 'exec')
    tree = ast.parse(c)
    trans = StringTypesTransformer()
    result = trans.transform(tree)
    print("******************************")
    print(result.tree)
    print("******************************")
    print(ast.dump(result.tree))

# Generated at 2022-06-23 23:14:06.920000
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from . import assert_equal_ast
    from . import is_string_types_transformer_applied

    transformer = StringTypesTransformer()


# Generated at 2022-06-23 23:14:12.451253
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from textwrap import dedent
    code = dedent("""\
    print(str(42))
    """)

    tree_before = ast.parse(code)
    tree_after = ast.parse(code)
    tree_after.body[0].value.func.id = 'unicode'

    transformer = StringTypesTransformer()
    assert transformer.transform(tree_before).tree == tree_after

# Generated at 2022-06-23 23:14:16.192370
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    module = '''
a = str()
'''

    mod = ast.parse(module)

    transformer = StringTypesTransformer()
    transformer.transform_ast(mod)

    code = to_source(mod)

    assert code == '''\
a = unicode()
'''

# Generated at 2022-06-23 23:14:21.102565
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast, typed_ast.ast3 as typed_ast
    tree = typed_ast.parse("str()")
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    assert (ast.dump(new_tree) == ast.dump(typed_ast.parse("unicode()")))

# Generated at 2022-06-23 23:14:24.302208
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name('str', ast.Load())
    assert node != None

    tree_changed, _, _ = StringTypesTransformer.transform(node)
    assert tree_changed == True
    assert node.id == 'unicode'

# Generated at 2022-06-23 23:14:28.041648
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    f = StringTypesTransformer.transform(ast.parse('''
    x = str(3)
    y = int(x)
    '''))

    assert "unicode" in str(f)
    assert "y = int(x)" in str(f)


if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:14:37.752709
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """These unit tests only make sure that the transformer does not throw
    exception.

    """
    def check1(tree):
        """Check that `str` is replaced with `unicode`.

        """
        result = StringTypesTransformer.transform(tree)

        assert result.tree_changed == True
        assert result.messages == []

        call = result.tree.body[0].body[0]
        assert isinstance(call, ast.Expr)
        assert isinstance(call.value, ast.Call)
        assert isinstance(call.value.func, ast.Name)
        assert call.value.func.id == 'unicode'

    def check2(tree):
        """Check that `str` is not replaced with `unicode`.

        """
        result = StringTypesTransformer.transform(tree)

        assert result.tree

# Generated at 2022-06-23 23:14:48.257651
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    """

# Generated at 2022-06-23 23:14:52.943352
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = "a = str(3)"
    expected_code = "a = unicode(3)"

    # When
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)

    # Then
    assert result.tree_changed
    assert result.inserted_lines == []
    assert len(result.removed_lines) == 0
    assert astunparse.unparse(result.tree) == expected_code

# Generated at 2022-06-23 23:14:56.405885
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformation

    assert_transformation(
        StringTypesTransformer, """
        def foo():
            return str('')
        """, """
        def foo():
            return unicode('')
        """
    )

# Generated at 2022-06-23 23:14:57.804948
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that the transformer can load."""
    assert StringTypesTransformer

# Generated at 2022-06-23 23:15:03.484519
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(string.Template('''
        from __future__ import division, print_function

        def func():
            no_str = list()
            is_str = str(no_str)
            return is_str
    ''').substitute(globals()))

    result = StringTypesTransformer.transform(tree)

    for node in find(result.tree, ast.Name):
        assert node.id != 'str'

# Generated at 2022-06-23 23:15:10.266752
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from . import sample
    from . import expect

    test_input = """
        x = str()
        a = str.join(' ', 'hello', 'world')
    """

    expected_output = """
        x = unicode()
        a = unicode.join(' ', 'hello', 'world')
    """

    tree = sample.string_ast(test_input)
    expr_transformer = StringTypesTransformer(tree)
    expr_transformer.run()
    assert(expect.string_ast(tree) == expected_output)

# Generated at 2022-06-23 23:15:20.231464
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # test_direct_str
    code = """str"""
    result = StringTypesTransformer().visit(ast.parse(code))
    assert result == TransformationResult(ast.parse("unicode"), True, [])

    # test_direct_str_id
    code = """a = str"""
    result = StringTypesTransformer().visit(ast.parse(code))
    assert result == TransformationResult(ast.parse("a = unicode"), True, [])

    # test_indirect_str
    code = """a = foo"""
    result = StringTypesTransformer().visit(ast.parse(code))
    assert result == TransformationResult(ast.parse("a = foo"), False, [])


# Test StringTypesTransformer
# pytest tests/transformers/test_stringtype.py -vv

# Generated at 2022-06-23 23:15:24.077772
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """a = str"""
    expected = """a = unicode"""
    tree = ast.parse(source)

    tree = StringTypesTransformer.transform(tree.body[0])['tree']
    result = astor.to_source(tree).strip()

    print(result)
    assert result == expected

# Generated at 2022-06-23 23:15:29.705030
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(dedent(r'''
        def a(x):
            print(str)
            print(str is int)
            x = str
            x = str()
        '''))
    tt = StringTypesTransformer()
    tt.transform(tree)
    #print(astunparse.unparse(tree))
    assert astunparse.unparse(tree) == dedent(r'''
        def a(x):
            print(unicode)
            print(unicode is int)
            x = unicode
            x = unicode()
        ''')

# Generated at 2022-06-23 23:15:33.682811
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # GIVEN
    code = "a = 'a'\nb = str(a)\n"
    # runs the transformer
    result = StringTypesTransformer.transform(ast.parse(code))

    # THEN
    # check the result
    expected = "a = u'a'\nb = unicode(a)\n"
    assert result.transformed_code == expected

# Generated at 2022-06-23 23:15:35.748011
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    a = StringTypesTransformer()
    b = StringTypesTransformer()
    assert a != b

# Generated at 2022-06-23 23:15:44.695264
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  from collections import namedtuple
  from ..utils import make_callable
  from ..tests.utils import get_ast, compare_ast
  Code = namedtuple('Code', ['python2', 'python3'])
  test_cases = {
      Code('type(123) is str',
           'isinstance(123, unicode)'):
          Code('isinstance(123, unicode)',
               'isinstance(123, str)'),
  }

  for code in test_cases:
    result = StringTypesTransformer.transform(get_ast(code.python2))
    compare_ast(make_callable(code.python3, 'x'),
                make_callable(result.edited_source, 'x'))

# Generated at 2022-06-23 23:15:45.613850
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:15:49.671129
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  '''
  Testing constructor for class StringTypesTransformer
  '''
  tree1 = ast.parse("str")
  tree2 = ast.parse("unicode")
  test1 = StringTypesTransformer.transform(tree1)
  test2 = StringTypesTransformer.transform(tree2)
  assert test1 == test2

# Generated at 2022-06-23 23:15:52.628694
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.Name(id = 'str', ctx = ast.Load())
    assert x.id == 'str'
    x = StringTypesTransformer.transform(x)
    assert x.tree.id == 'unicode'
    return

# Generated at 2022-06-23 23:15:58.579688
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # create empty AST
    tree = ast.Module([])

    # create a Identifier 'str'
    node = ast.Name()
    node.id = 'str'

    # create an Assign node
    assign = ast.Assign()
    assign.targets.append(node)

    # append assign node to the tree
    tree.body.append(assign)

    # transform
    res = StringTypesTransformer.transform(tree)

    assert res.tree_changed
    assert type(res.tree) == ast.Module
    assert res.tree.body[0].targets[0].id == 'unicode'

# Generated at 2022-06-23 23:16:08.918132
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class DummyNode(ast.AST):
        _fields = ('node',)
        _attributes = ('id',)

    assert StringTypesTransformer.can_be_applied(DummyNode(), [])
    assert not StringTypesTransformer.can_be_applied(ast.Module(), [])

    assert StringTypesTransformer.transform(
        ast.Module(body=[
            ast.ImportFrom(module='typed_ast', names=[
                ast.alias(name='ast3', asname='ast')
            ], level=0)
        ])) == TransformationResult(
            ast.Module(body=[
                ast.ImportFrom(module='typed_ast', names=[
                    ast.alias(name='ast3', asname='ast')
                ], level=0)
            ]),
            True,
            []
        )



# Generated at 2022-06-23 23:16:17.825484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast
    from .remove_PrintFunction import RemovePrintFunctionTransformer
    from .remove_ParenthesesAroundConditionalExpression import RemoveParenthesesAroundConditionalExpressionTransformer
    from ..utils.tree import ast_to_source

    source1 = '''
if isinstance(self.__r, str):
    return [self.__r]
'''
    source2 = '''
if(isinstance(self.__r, str)):
    return[self.__r]
'''
    source3 = '''
if (print(isinstance(self.__r, str))):
    print(return [self.__r])
'''

    print(ast_to_source(RemovePrintFunctionTransformer.transform(source_to_ast(source3))['tree']))


# Generated at 2022-06-23 23:16:20.606232
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # arranges
    source_code = 'str'
    expected_code = 'unicode'

    # acts
    actual_node = StringTypesTransformer.run(source_code)

    # asserts
    assert ast.dump(actual_node) == expected_code

# Generated at 2022-06-23 23:16:28.962088
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    import unittest

    class TestStringTypesTransformer(unittest.TestCase):
        def test_transformer__with_none(self):
            input_data = None
            expexted_output = None
            appropriate_transformer = StringTypesTransformer()
            result, is_changed = appropriate_transformer.transform(input_data)
            self.assertEqual(result,expexted_output)

        def test_transformer__with_a_simple_string(self):
            input_data = 'abc'
            expexted_output = None
            appropriate_transformer = StringTypesTransformer()
            result, is_changed = appropriate_transformer.transform(input_data)
            self.assertEqual(result,expexted_output)


# Generated at 2022-06-23 23:16:32.232210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """x = str(x)""" # noqa
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)

    assert ast.dump(tree) == """""" # noqa

# Generated at 2022-06-23 23:16:36.987233
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    old_tree = ast.parse('''
    print str(1)
    print str(1)
    ''')
    new_tree = ast.parse('''
    print unicode(1)
    print unicode(1)
    ''')
    transformer = StringTypesTransformer()
    assert transformer.transform(old_tree) == TransformationResult(new_tree, True, [])

# Generated at 2022-06-23 23:16:40.545311
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("assert isinstance(s, str)")
    transformer = StringTypesTransformer()
    tree = transformer.visit(tree)
    exec(compile(tree, "<test>", "exec"))

# Generated at 2022-06-23 23:16:51.104427
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # In[1]
    import ast
    import typed_ast.ast3


# Generated at 2022-06-23 23:16:53.779601
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import sys
    import io
    sys.stdout = io.StringIO()

    tree = ast.parse('''str()''')
    new_tree = StringTypesTransformer.transform(tree)

    assert ast.dump(new_tree.tree) == ast.dump(ast.parse('''unicode()'''))
    assert new_tree.tree_changed

    print("Everything passed")

# Generated at 2022-06-23 23:16:55.799868
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import make_test, run_test
    from ...tests.fixtures import empty_test_file

    run_test(make_test(empty_test_file("""
x = str("")
""")))

# Generated at 2022-06-23 23:17:02.011823
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast

    code = '''
            x = str("hello")
            '''
    tree = source_to_ast(source_to_unicode(code))
    result = StringTypesTransformer.transform(tree)
    assert result.changed
    assert source_to_unicode(result.tree) == '''
            x = unicode("hello")
            '''

# Generated at 2022-06-23 23:17:07.930187
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..test_utils import make_test_instance
    from ..stubgen import PythonCodeGenerator
    from ..types import Module, TransformationContext


# Generated at 2022-06-23 23:17:17.462279
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1: check if the tranformer correctly replaces string types
    tree = ast.parse(
        '''
x = "aa"
y = z = text = str()
        ''')
    expected_tree = ast.parse(
        '''
x = "aa"
y = z = text = unicode()
        ''')
    transformer = StringTypesTransformer()
    result_tree = transformer.transform(tree)[0]
    assert ast.dump(result_tree) == ast.dump(expected_tree)

    # Test 2: Check if the transformer does not replace the string type in comments
    tree = ast.parse(
        '''
x = "aa"
y = z = text = str()
# check if str() == "str"
        ''')

# Generated at 2022-06-23 23:17:19.044264
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Unit test for constructor of class StringTypesTransformer
    """
    t = StringTypesTransformer()
    assert t.target == (2, 7)


# Generated at 2022-06-23 23:17:21.693267
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer."""
    string_types_transformer = StringTypesTransformer()
    assert (string_types_transformer is not None)
    assert (string_types_transformer.target == (2, 7))

    return


# Generated at 2022-06-23 23:17:27.568976
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse('''a=str()''')
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(t)
    assert (ast.dump(new_tree) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Call(func=Name(id=\'unicode\', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))])' or 
            ast.dump(new_tree) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Call(func=Name(id=\'unicode\', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))])')

# Unit

# Generated at 2022-06-23 23:17:35.859326
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_before = "def test_function():\n\tfor i in range(100):\n\t\tprint(str(i))\n"
    code_after = "def test_function():\n\tfor i in range(100):\n\t\tprint(unicode(i))\n"
    tree_before = ast.parse(code_before)
    tree_after = ast.parse(code_after)
    tree_transformed, tree_changed, lines_changed = StringTypesTransformer.transform(tree_before)
    assert ast.dump(tree_after) == ast.dump(tree_transformed)

# Generated at 2022-06-23 23:17:41.284957
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    import textwrap
    source = textwrap.dedent("""
    def func():
        x = str(5)
    """)

    tree = astor.parse_file(source)
    res, _ = StringTypesTransformer.transform(tree)
    assert astor.to_source(res).strip() == textwrap.dedent("""
    def func():
        x = unicode(5)
    """).strip()

# Generated at 2022-06-23 23:17:44.573092
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open("./tests/cfg/example.py") as py_file:
        code = py_file.read()
        tree = ast.parse(code)
        tree = StringTypesTransformer.transform(tree=tree)
    assert "str" not in code
    assert "unicode" in code

# Generated at 2022-06-23 23:17:46.562511
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_code_1 = """
name = str("string")
"""
    expected_code_1 = """
name = unicode("string")
"""


# Generated at 2022-06-23 23:17:51.177536
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from ..utils.source import deparse_python27


# Generated at 2022-06-23 23:17:52.541141
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("Testing constructor of class StringTypesTransformer")
    assert True


# Generated at 2022-06-23 23:17:56.564272
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from .annotations import AnnotationTransformer

    tree = ast.parse('str(42)')
    tree = StringTypesTransformer.transform(tree).tree
    tree = AnnotationTransformer.transform(tree).tree
    assert astor.to_source(tree) == "u'42'"

# Generated at 2022-06-23 23:18:03.410584
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    result = StringTypesTransformer.transform(ast.parse('str'))
    assert not result.tree_changed
    assert result.tree == ast.parse('str')

    result = StringTypesTransformer.transform(ast.parse('unicode'))
    assert not result.tree_changed
    assert result.tree == ast.parse('unicode')

    result = StringTypesTransformer.transform(ast.parse('yyy = str'))
    assert result.tree_changed
    assert result.tree == ast.parse('yyy = unicode')

# Generated at 2022-06-23 23:18:05.219483
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert(StringTypesTransformer.transform(ast.parse("str('')", mode="exec")) == None)

# Generated at 2022-06-23 23:18:08.916744
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import assert_transformed_tree
    from typed_ast import parse

    tree = parse("""
        x = str(123)
    """)

    assert_transformed_tree(tree, StringTypesTransformer)


# Generated at 2022-06-23 23:18:17.028087
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..transforms.future.six_string_types import StringTypesTransformer
    from ..utils.ast_helpers import get_ast
    from .test_future_imports import test_future_imports
    # Test Case 1:
    # Test Case 2:
    # Test Case 3:
    # Test Case 4:
    # Test Case 5:
    initial_ast = get_ast(
        """
for x in str:
    print str
s = str.replace("a", "b", 2)
        """)
    expected_ast = get_ast(
        """
for x in unicode:
    print unicode
s = unicode.replace("a", "b", 2)
        """)
    transformed_ast, _ = StringTypesTransformer.transform(
        initial_ast)

# Generated at 2022-06-23 23:18:19.836467
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    source = ast.parse('''str(5)''')
    actual = transformer.transform(source)
    assert actual.tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-23 23:18:20.734648
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test is incomplete
    assert False

# Generated at 2022-06-23 23:18:23.819879
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('"some str".decode()')
    tree = StringTypesTransformer.transform(tree)
    print(ast.dump(tree.tree))
    assert tree.tree_changed

# Generated at 2022-06-23 23:18:26.075225
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:18:33.051176
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('def f(s=str): pass').body[0]
    assert isinstance(tree.args.defaults[0], ast.Name)
    assert tree.args.defaults[0].id == 'str'

    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed is True
    assert isinstance(result.tree, ast.FunctionDef)
    assert isinstance(result.tree.args.defaults[0], ast.Name)
    assert result.tree.args.defaults[0].id == 'unicode'

# Generated at 2022-06-23 23:18:33.484811
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:18:41.994677
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    a = str('abc')
    try:
        x = str(str(str(str(str(str(str(str(str('abc'))))))))))
    except:
        pass
    '''
    expected_code = '''
    a = unicode('abc')
    try:
        x = unicode(unicode(unicode(unicode(unicode(unicode(unicode(unicode(unicode('abc'))))))))))
    except:
        pass
    '''
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree).tree
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))

# Run unittests
if __name__ == '__main__':
    import sys
    import pytest
    py

# Generated at 2022-06-23 23:18:46.823206
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    t = ast.parse('a = str(b) + str(c)')
    desired = ast.parse('a = unicode(b) + unicode(c)')
    StringTypesTransformer.transform(t)
    assert ast.dump(t) == ast.dump(desired)

# Generated at 2022-06-23 23:18:51.207275
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
foo = str(1)
"""
    expect = """
foo = unicode(1)
"""

    nodes = ast.parse(src)
    tree_changed, new_src, _ = StringTypesTransformer.transform(nodes)
    assert tree_changed == True
    assert new_src == expect

# Generated at 2022-06-23 23:18:51.842358
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:18:55.611065
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test replacing `str` with `unicode`."""
    input = """
    str()
    """
    expected = """
    unicode()
    """
    tree = ast.parse(input)
    new, changed, not_changed = StringTypesTransformer.transform(tree)
    assert_output(new, expected)

# Generated at 2022-06-23 23:19:02.952437
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('x = "5"', '<test>', 'exec')) == \
        TransformationResult(ast.parse('x = u"5"', '<test>', 'exec'), True, [])
    assert StringTypesTransformer.transform(ast.parse('def f(a: str): return a', '<test>', 'exec')) == \
        TransformationResult(ast.parse('def f(a: unicode): return a', '<test>', 'exec'), True, [])
    assert StringTypesTransformer.transform(ast.parse('class A(str): pass', '<test>', 'exec')) == \
        TransformationResult(ast.parse('class A(unicode): pass', '<test>', 'exec'), True, [])

# Generated at 2022-06-23 23:19:09.085714
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Confirm that unicode is replaced with str
    def check(before, after):
        assert ast.dump(StringTypesTransformer.transform(ast.parse(before)).tree) == after

    check("type('')", "type(u'')")
    check("print(type(s))", "print(type(s))")
    check("print('hello there, str')", "print(u'hello there, str')")
    check("print(x)", "print(x)")
    check("print(str(i))", "print(unicode(i))")


# Generated at 2022-06-23 23:19:18.667053
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class TestVisitor(ast.NodeVisitor):
        def visit_Name(self, node):
            if node.id == 'unicode':
                self.is_pass = True
                return

        def generic_visit(self, node):
            for field, value in ast.iter_fields(node):
                if isinstance(value, list):
                    for item in value:
                        if isinstance(item, ast.AST):
                            self.visit(item)
                elif isinstance(value, ast.AST):
                    self.visit(value)


    # Test case: Python 2 code
    tree = ast.parse("""
        def test_string():
            s = str()
    """)
    tree = StringTypesTransformer.transform(tree)
    test_visitor = TestVisitor()
    test_vis

# Generated at 2022-06-23 23:19:26.180345
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import check_ast, get_ast
    from ..types import TEST_CASES
    
    code = """
    def add_num(a, b):
        print(a + b)

    def string_add(s):
        s = s + 'string'

    def string_isinstance(s):
        return isinstance(s, str)
    """

    test_tree = get_ast(code)

    add_num = test_tree.body[0]
    string_add = test_tree.body[1]
    string_isinstance = test_tree.body[2]

    check_ast(StringTypesTransformer.transform(add_num), TEST_CASES['StringTypesTransformer']['add_num'], astor.to_source)
    check_ast

# Generated at 2022-06-23 23:19:34.357198
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    tree =  ast.parse("""
print("aaa")
for i in range(5):
    print("Hello str world", str("hello"))
    a = 5
    c = 7
    a = a + c
print("aaa")
    """)
    new_tree = StringTypesTransformer().transform(tree)
    print(astor.to_source(new_tree))

    assert "print('aaa')" in astor.to_source(new_tree)
    assert "unicode('hello')" in astor.to_source(new_tree)


# Generated at 2022-06-23 23:19:35.735905
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert str(StringTypesTransformer.__init__).lower().find('assert') == -1

# Generated at 2022-06-23 23:19:37.552857
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .transformers.utils import get_ast_from_source
    from .transformers.utils import transform


# Generated at 2022-06-23 23:19:38.349146
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

# Generated at 2022-06-23 23:19:38.992500
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:19:39.740538
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  assert StringTypesTransformer.transform('') is not None

# Generated at 2022-06-23 23:19:40.996272
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..unpack import unpack_module
    from ..pack import pack_module


# Generated at 2022-06-23 23:19:46.148754
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..visitor import Visitor
    class PrintNames(Visitor):
        def __init__(self):
            self.names = []
        def visit_Name(self, node): 
            self.names.append(node.id)
            self.generic_visit(node)
    for version in [(2, 7), (3, 0), (3, 1), (3, 2), (3, 3), (3, 4), (3, 5), (3, 6), (3, 7), (3, 8)]:
        tree = ast.parse("""if isinstance(a, str): print(a)""", version)
        a = [x for x in find(tree, ast.Name)]
        assert a[1].id == 'str'
        assert a[0].id == 'isinstance'
        assert a[2].id

# Generated at 2022-06-23 23:19:56.627727
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # build test AST
    # test replacement of "str" with "unicode"
    test_ast = ast.Module(body=[ast.Assign(targets=[ast.Name(id="x", ctx=ast.Store())], value=ast.Name(id="str", ctx=ast.Load()))])
    # perform transformation
    transformer = StringTypesTransformer()
    result = transformer.transform(test_ast)
    # check tree was changed
    assert result.tree_changed
    # check tree content
    x = find(result.tree, ast.Name, id="x")
    assert isinstance(x, list)
    assert len(x) == 1
    assert isinstance(x[0], ast.Name)
    assert x[0].id == "unicode"
    assert x[0].ctx == ast.Store()

# Generated at 2022-06-23 23:20:01.624806
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from .. import ast_utils
    from .. import main

    code = """
    from __future__ import unicode_literals

    x = str()
    """

    tree = ast.parse(code)
    tree = main.transform(tree, 2, 7)
    assert astunparse.unparse(tree) == """
from __future__ import unicode_literals

x = unicode()
"""

# Generated at 2022-06-23 23:20:07.515306
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
    x = 'Hello World'
    # comment
    """
    result = StringTypesTransformer.transform(ast.parse(code))
    assert result.tree_changed
    expected_code = """
    x = u'Hello World'
    # comment
    """
    assert ast.dump(result.tree) == ast.dump(ast.parse(expected_code))
    assert result.warnings == []

# Generated at 2022-06-23 23:20:16.952123
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from astor.source_repr import dump_tree

    test_code = '''
arr = [str(a) for a in range(10)]
if type(a) == str:
    return str(b)
else:
    return unicode(b)
'''

    tree = ast.parse(test_code)
    result = StringTypesTransformer.transform(tree)

    assert dump_tree(result.tree) == dump_tree(ast.parse('''
arr = [unicode(a) for a in range(10)]
if type(a) == str:
    return unicode(b)
else:
    return unicode(b)
'''))