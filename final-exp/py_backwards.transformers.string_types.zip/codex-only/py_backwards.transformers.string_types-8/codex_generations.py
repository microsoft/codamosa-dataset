

# Generated at 2022-06-23 23:10:17.184184
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils import get_ast

    tree = "{}".format(astor.code_to_ast("x = str('abc')"))
    tree = get_ast(tree)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    
    assert result
    assert astor.to_source(tree) == "x = unicode('abc')"

# Generated at 2022-06-23 23:10:23.099789
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """\
handles = []
for s in strings:
    handles.append(
        types.FunctionType(
            s,
            globals()
        )
    )
"""

    transformed_code = """\
handles = []
for s in strings:
    handles.append(
        types.FunctionType(
            unicode(s),
            globals()
        )
    )
"""

    parsed_code = ast.parse(code)

    expected_parsed_code = ast.parse(transformed_code)

    transformer = StringTypesTransformer()

    actual_result = transformer.transform(parsed_code)

    assert actual_result.tree == expected_parsed_code

# Generated at 2022-06-23 23:10:32.374727
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from typed_ast import convert
    import sys
    import textwrap
    #from .compat import decode_utf8

    class Dummy():
        pass

    sys.modules['__builtin__'] = Dummy()
    code = textwrap.dedent(decode_utf8('''\
        import __builtin__

        mystr = 'Ein String'
        print(type(mystr))

        mystr2 = str(mystr)
        print(type(mystr2))

        mystr3 = __builtin__.str('Foo')
        print(type(mystr3))

        myunicode = unicode(mystr)
        print(type(myunicode))
    '''))

    tree_orig = ast3.parse(code)

# Generated at 2022-06-23 23:10:39.615689
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    # Test find_set_target_nodes()
    tree = ast.parse('b = str("1")')
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    assert result.tree_changed
    assert isinstance(result.new_tree, ast.AST)
    assert ast.dump(result.new_tree) == "Module(body=[Assign(targets=[Name(id='b', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='1')], keywords=[]))])"

# Generated at 2022-06-23 23:10:43.199177
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = 'x = str("foo")'

    tree = ast.parse(src)    
    t = StringTypesTransformer()
    t.transform(tree)

    trg = astor.to_source(tree)
    assert trg == 'x = unicode("foo")'

# Generated at 2022-06-23 23:10:50.664499
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that `str` is replaced by `unicode` in simple examples.

    """
    tree = ast.parse('a = str')
    transformed_tree, tree_changed, _ = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert ast.dump(transformed_tree) == "Assign(targets=[Name(id='a', ctx=Store())], value=Name(id='unicode', ctx=Load()))"

    tree = ast.parse('a = str(42)')
    transformed_tree, tree_changed, _ = StringTypesTransformer.transform(tree)
    assert tree_changed

# Generated at 2022-06-23 23:10:55.901744
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    expression = '''def test():
        a = str()'''
    expected_transformed_expression = '''def test():
        a = unicode()'''
    transformer = StringTypesTransformer()
    # Act
    transformed_expression = transformer.run_single_expression(expression)
    # Assert
    assert transformed_expression == expected_transformed_expression


# Generated at 2022-06-23 23:10:57.207049
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert 'str' == 'unicode'


# Generated at 2022-06-23 23:10:59.939287
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.transform_test import make_test_function
    make_test_function(StringTypesTransformer)


if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:11:03.710192
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = 'def test(a: str) -> str: return a'
    fixed_code = 'def test(a: unicode) -> unicode: return a'
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == fixed_code

# Generated at 2022-06-23 23:11:06.948515
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    tree = ast.parse('1')
    assert t.transform(tree) == TransformationResult(tree, False, [])

    tree = ast.parse('def a(): return str(1)')
    assert t.transform(tree) == TransformationResult(tree, True, [])

# Generated at 2022-06-23 23:11:08.857806
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = \
"""
a = str(1)
"""
    expected_code = \
"""
a = unicode(1)
"""
    tree = ast.parse(code)
    transformed_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(transformed_tree, include_attributes=True) == expected_code

# Generated at 2022-06-23 23:11:14.102459
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    real_node = ast.Name(id="str", ctx=ast.Load())
    desired_node = ast.Name(id="unicode", ctx=ast.Load())
    StringTypesTransformer.transform(real_node) == TransformationResult(desired_node, True, [])


# Generated at 2022-06-23 23:11:17.582090
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import equivalence_test

    def A():
        a = "Hello"
        return str(a)

    def B():
        a = u"Hello"
        return str(a)

    equivalence_test(StringTypesTransformer, A, B)



# Generated at 2022-06-23 23:11:26.259579
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    
    """
    import ast
    import inspect
    import sys
    import unittest

    # Hack to load module from parent directory
    module_name = 'python2to3transformer'
    pkg_dir = os.path.join(os.path.dirname(__file__), '..')
    sys.path.insert(0, pkg_dir)

    m = __import__(module_name)
    for k, v in m.__dict__.items():
        globals()[k] = v

    del sys.path[0]

    class TestStringTypesTransformer(unittest.TestCase):
        def test_transform(self):
            """Unit test for method StringTypesTransformer.transform()

            """

# Generated at 2022-06-23 23:11:29.064542
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str')).tree_changed == True
    assert StringTypesTransformer.transform(ast.parse('unicode')).tree_changed == False

# Generated at 2022-06-23 23:11:37.813353
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from .test_utils import generate_test_code
    
    code = generate_test_code(
        """
        i = str(i)
        """)
    tree = ast.parse(code)

    expected_code = generate_test_code(
        """
        i = unicode(i)
        """)
    expected_tree = ast.parse(expected_code)

    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert astor.to_source(result.tree) == astor.to_source(expected_tree)

# Generated at 2022-06-23 23:11:40.885903
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
a = str()
""")
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed == True
    assert result.tree.body[0].value.func.id == "unicode"

# Generated at 2022-06-23 23:11:46.810872
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Tests that the transformer class that replaces `str` with `unicode`.
    """
    tree_in = ast.parse("""
        a = str()
        b = str(b)
        c = str(b, encoding='utf-8', errors='strict')
    """)

    expected_out = ast.parse("""
        a = unicode()
        b = unicode(b)
        c = unicode(b, encoding='utf-8', errors='strict')
    """)

    transformer = StringTypesTransformer()
    output = transformer.transform(tree_in)

    assert(expected_out == output)

# Generated at 2022-06-23 23:11:51.401188
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    expected = ast.Name(id='unicode', ctx=ast.Load())
    actual = StringTypesTransformer(None).transform(ast.Name(id='str', ctx=ast.Load()))
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-23 23:11:57.471165
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test_tree is the code we want to transform
    test_tree = ast.parse(
        # Line 1
        """
        string_literal = 'hello world'
        """
    )

    # expected_tree is the expected result after transformation
    expected_tree = ast.parse(
        # Line 1
        """
        unicode_literal = 'hello world'
        """
    )

    # Call the transform method
    transformation_result = StringTypesTransformer.transform(test_tree)
    # Assert that the ast is transformed as expected.
    assert ast.dump(transformation_result.tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:11:58.947089
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:05.768687
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from astunparse import unparse

    tree = ast.parse('''
    x = "123" 
    y = str(x) + "456"
    ''')

    print('Original tree:')
    print(unparse(tree))

    result = StringTypesTransformer.transform(tree)
    
    print('Resulting tree:')
    print(unparse(result.tree))

    assert ('unicode' in unparse(result.tree)) and (result.header == [])

# Test cases for class StringTypesTransformer

# Generated at 2022-06-23 23:12:15.444583
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
a: str
b = str(1)
'''
    tree = ast.parse(code)
    res = StringTypesTransformer.transform(tree)
    new_tree = res.tree
    assert new_tree is not None
    assert res.tree_changed
    assert code == astor.to_source(new_tree)

    code = '''
a: str
b = unicode(1)
'''
    tree = ast.parse(code)
    res = StringTypesTransformer.transform(tree)
    new_tree = res.tree
    assert new_tree is not None
    assert not res.tree_changed
    assert code == astor.to_source(new_tree)

# Generated at 2022-06-23 23:12:16.754179
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:17.807715
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typing import List
    from ..utils.source import source_to_nodes


# Generated at 2022-06-23 23:12:19.404687
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Declare test variables
    instance = StringTypesTransformer()
    assert(instance != None)


# Generated at 2022-06-23 23:12:25.081538
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer.from_version(version(2, 7))

    tree = ast.parse(
        "str"
    )

    expected = ast.parse(
        "unicode"
    )

    transformed = transformer.transform(tree)

    assert ast.dump(transformed, include_attributes=True) == ast.dump(expected, include_attributes=True)

# Generated at 2022-06-23 23:12:33.415389
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    import os
    import ast
    from typed_ast import ast3 as typed_ast
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
    from python_to_python.transformers.string_types import StringTypesTransformer

    class_name = "StringTypesTransformer"
    base_class_name = "BaseTransformer"
    module = "string_types"
    class_doc_string = "Replaces `str` with `unicode`."
    tree = ast.parse("x = str('abc')")
    typed_tree = typed_ast.ast3.parse("x = str('abc')")
    transformed_tree = ast.parse("x = unicode('abc')")

    transformer = StringTypes

# Generated at 2022-06-23 23:12:42.289047
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unittest for class StringTypesTransformer"""
    from ..utils.source import source_to_ast

    node = source_to_ast('x = str(1)')
    result = StringTypesTransformer.transform(node)
    print(ast.dump(node))
    print(result)
    print(ast.dump(result.tree))

    # Print the diff
    import difflib
    print(''.join(difflib.unified_diff(
        ast.dump(node).splitlines(True),
        ast.dump(result.tree).splitlines(True),
        fromfile = 'before.py',
        tofile = 'after.py'
    )))

# Generated at 2022-06-23 23:12:43.708599
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:47.762548
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from sys import version_info as pv
    from .test_utils import assert_transformed, assert_no_transformation
    
    for v in [(2, 7), (3, 0), (3, 1), (3, 2), (3, 3)]:
        for (original, expected) in [
                ("x = str()", "x = unicode()"),
                ("def x(): return str()", "def x(): return unicode()"),
                ("def x():\n x = str\n return x", "def x():\n x = unicode\n return x"),
                ("@str\ndef x(): return 0", "@unicode\ndef x(): return 0")
        ]:
            if pv >= v:
                assert_no_transformation(original, StringTypesTransformer, v)
           

# Generated at 2022-06-23 23:12:49.667452
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:12:52.446544
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open('example.py', 'r') as f:
        tree = ast.parse(f.read())
    StringTypesTransformer.transform(tree)

# Generated at 2022-06-23 23:12:57.975243
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    original_tree = ast.parse(
        "assert(isinstance(instance, str))"
    )
    transformed_tree = ast.parse(
        "assert(isinstance(instance, unicode))"
    )
    tree_changed, new_tree = StringTypesTransformer.transform(original_tree)
    assert tree_changed
    assert ast.dump(new_tree) == ast.dump(transformed_tree)

# Generated at 2022-06-23 23:13:03.098102
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_case_source_code = """
x = unicode
y = str
    """
    expected_transformed_source_code = """
x = unicode
y = unicode
    """
    utils.run_test_case(StringTypesTransformer, 
                        test_case_source_code, 
                        expected_transformed_source_code)

# Generated at 2022-06-23 23:13:08.415099
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('v = str()')
    assert isinstance(tree, ast.Module)
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.tree_changed is False
    assert transformer.warnings == []
    transformer.transform(tree)
    assert transformer.tree_changed is True
    assert transformer.warnings == []
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='v', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"

# Generated at 2022-06-23 23:13:14.990254
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    tup = ('Spam', 123, 1.23)
    str1 = str(tup)
    '''
    ast_tree = ast.parse(code)
    StringTypesTransformer.transform(ast_tree)
    x = compile(ast_tree, '', 'exec')
    exec(x)
    assert str1 == "(u'Spam', 123, 1.23)"


# Generated at 2022-06-23 23:13:18.996633
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def _assert(line, expected):
        t = StringTypesTransformer()
        assert t.transform(ast.parse(line)) == expected

    line = "from foo import str"
    expected = "from foo import unicode"
    _assert(line, expected)


# Generated at 2022-06-23 23:13:30.101120
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""x = "Hello"\n""")
    assert tree.body[0].value.s == 'Hello'
    assert isinstance(tree.body[0].value, ast.Str)
    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed == True
    print(ast.dump(new_tree))
    assert ast.dump(new_tree) == \
    "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Unicode(s='Hello'))])"
    assert new_tree.body[0].value.s == 'Hello'
    assert isinstance(new_tree.body[0].value, ast.Unicode)

# Manual tests for class StringTypesTransformer

# SyntaxError: expected an ind

# Generated at 2022-06-23 23:13:39.288463
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ...tests.test_utils import generate_source_code
    from ...tests.test_utils import get_ast

    for version in range(2, 7):
        source_code_old = '''
        def foo(): 
            x = str() 
            return x
        '''
        source_code_new = '''
        def foo(): 
            x = unicode() 
            return x
        '''
        tree = get_ast(source_code_old, version)
        transformed = generate_source_code(StringTypesTransformer.transform(tree).tree, version)
        assert transformed == source_code_new, f'Failed test for Python version {version}'

        source_code_old = '''
        def foo(): 
            x = str
            return x
        '''
        source_code_new

# Generated at 2022-06-23 23:13:46.792994
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # x = "a"
    x = ast.Name(id='unicode', ctx=ast.Load)
    x_assign = ast.Assign(targets=[
        ast.Name(id='x', ctx=ast.Store)],
        value=ast.Str(s="a"))
    x_assign.type_comment = "# type: unicode"
    x_decl = ast.Name(id='x', ctx=ast.Load)
    x_decl.type_comment = "# type: unicode"

    # y = "b"
    y = ast.Name(id='unicode', ctx=ast.Load)

# Generated at 2022-06-23 23:13:50.547844
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..component import Component
    from ..config import Config
    
    transformer = StringTypesTransformer(Config(target_version=(2, 7)))

    s = """def foo(a: str, b: int) -> int: return a + b"""
    tree = ast.parse(s)
    comp = Component(tree)
    comp2 = transformer.transform(comp)
    
    assert comp.tree != comp2.tree
    assert comp2.tree.body[0].args.args[0].annotation.id == 'unicode'

# Generated at 2022-06-23 23:13:56.082264
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    test_source = '''
    a = str()
    b = str(x, y)
    '''
    module_code = compile(test_source, '<string>', mode='exec')
    module = ast.parse(module_code)
    module = StringTypesTransformer.transform(module)

    assert str(module).strip() == "a = unicode()\nb = unicode(x, y)"

# Generated at 2022-06-23 23:14:04.447376
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = '''
    def func1(s):
        return s.encode('utf-8')
    '''
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    assert astor.to_source(new_tree.node) == '''
    def func1(s):
        return s.encode('utf-8')
    '''.strip()
    assert not new_tree.modified
    code = '''
    def func1(s):
        return s+'string'
    '''
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)

# Generated at 2022-06-23 23:14:09.703145
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    class A(object):
        def __init__(self):
            pass
    
    tree = ast.parse('a = str(2)')
    tree = StringTypesTransformer.transform(tree)
    expected_tree = ast.parse('a = unicode(2)')
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:14:20.102811
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.parse('str')
    x = StringTypesTransformer.transform(x)
    assert not x.tree_changed
    assert x.messages == []

    # We should not transform str if it is used as a method
    x = ast.parse('a_string.str()')
    x = StringTypesTransformer.transform(x)
    assert not x.tree_changed
    assert x.messages == []

    x = ast.parse('blub = str')
    x = StringTypesTransformer.transform(x)
    assert x.tree_changed
    assert x.messages == []

    x = ast.parse('def blub(s: str):\n    pass')
    x = StringTypesTransformer.transform(x)
    assert not x.tree_changed
    assert x.messages == []

    x

# Generated at 2022-06-23 23:14:24.784133
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str')
    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert str(result.tree) == 'unicode'

    tree = ast.parse('type(str)')
    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert str(result.tree) == 'type(unicode)'

# Generated at 2022-06-23 23:14:26.338669
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(None) == \
            TransformationResult(None, False, [])

# Generated at 2022-06-23 23:14:29.656317
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
            a = str(1)
            ''')

    exp_tree = ast.parse('''
            a = unicode(1)
            ''')

    transformer = StringTypesTransformer()
    res = transformer.transform(tree)

    assert(res.tree == exp_tree)

# Generated at 2022-06-23 23:14:34.995597
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import _utils
    from .. import _generic_ast

    code = 'print(str("abc"))'
    tree = _utils.build_ast(code, version='2.7')
    new_tree = _generic_ast.transform(tree, StringTypesTransformer)
    new_code = _utils.dump_code(new_tree)

    assert new_code == 'print(unicode("abc"))'

# Generated at 2022-06-23 23:14:41.817849
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    raw_code = """
        class Foo:
            def hello(self, name: str):
                print('Hello, {0}'.format(name))
    """

    result, changed = StringTypesTransformer.transform(astor.parse_file(raw_code))

    assert changed
    assert ast_to_string(result) == """
        class Foo:
            def hello(self, name: unicode):
                print('Hello, {0}'.format(name))
    """


# Generated at 2022-06-23 23:14:43.552056
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = StringTypesTransformer()
    assert tt.transform(ast.parse('str'))

# Generated at 2022-06-23 23:14:52.991908
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    class A:
        def foo(self, s: str):
            return str(s)'''

    tree = ast.parse(code, mode='exec')
    new_tree = StringTypesTransformer.transform(tree)
    assert new_tree.tree_changed

# Generated at 2022-06-23 23:15:02.429367
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import subprocess
    import astunparse
    from ..utils.tree import compare_trees

    test = subprocess.Popen(['python', '-c', 'a = str()'], stdout=subprocess.PIPE)
    test_out, err = test.communicate()

    fixed = subprocess.Popen(['python', '-c', 'a = unicode()'], stdout=subprocess.PIPE)
    fixed_out, err = fixed.communicate()

    test_ast = ast.parse(test_out)
    fixed_ast = ast.parse(fixed_out)

    assert compare_trees(StringTypesTransformer.transform(test_ast).tree, fixed_ast)



# Generated at 2022-06-23 23:15:05.221219
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """a = str()"""
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree) == """a = unicode()"""

if __name__ == '__main__':
    StringTypesTransformer.main()

# Generated at 2022-06-23 23:15:08.746296
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str('foo')")
    tree_changed = StringTypesTransformer.transform(tree)

    assert isinstance(tree_changed, TransformationResult)
    assert tree_changed.tree_changed == True

    assert isinstance(tree_changed.tree, ast.AST)
    assert isinstance(tree_changed.transformations, list)

# Generated at 2022-06-23 23:15:11.017421
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = StringTypesTransformer()
    assert tt.tree_changed is False
    assert tt.trees_affected == []

# Generated at 2022-06-23 23:15:14.007638
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from py2to3.fixes import ast

    tree = ast.parse("a='str'")
    result = StringTypesTransformer.transform(tree)
    # print(result)



# Generated at 2022-06-23 23:15:18.139694
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('foo = str("abc")')
    expected = ast.parse('foo = unicode("abc")')

    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected
    assert result.tree_changed
    assert result.messages == []

# Generated at 2022-06-23 23:15:27.071227
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    # Example 1:
    # -------------
    # input : (x==1)
    # expected output : (x==1)

    # Declaration of Input:
    input_code = '(x==1)'
    input_ast = ast.parse(input_code)
    expected_output_code = '(x==1)'
    expected_output_ast = ast.parse(expected_output_code)

    # Test:
    result = StringTypesTransformer.transform(input_ast)
    result.tree == expected_output_ast
    result.tree_changed == False
    result.used_transformers == []


    # Example 2:
    # -------------
    # input : str(x)
    # expected output : unicode(x)

    # Declaration of Input:
    input_code = 'str(x)'
    input

# Generated at 2022-06-23 23:15:29.102214
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.parse("""a = str""")
    t = StringTypesTransformer.transform(t)
    assert t.tree.body[0].value.id == 'unicode'

# Generated at 2022-06-23 23:15:34.599704
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Foo:
        pass

    class Bar:
        pass

    tree = ast.parse("a = 'hello'")
    tree = StringTypesTransformer.transform(tree)
    assert eval(compile(tree, filename="<ast>", mode="exec")) == {'a': Foo()}
    tree = ast.parse("a = u'hello'")
    tree = StringTypesTransformer.transform(tree)
    assert eval(compile(tree, filename="<ast>", mode="exec")) == {'a': Bar()}

# Generated at 2022-06-23 23:15:36.004604
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tr = StringTypesTransformer()
    assert tr.target == (2, 7)

# Generated at 2022-06-23 23:15:39.010451
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert_equal(
        StringTypesTransformer.transform(ast.parse("str = 'str'")),
        TransformationResult(ast.parse("unicode = 'str'"), True, [])
    )

# Generated at 2022-06-23 23:15:47.645309
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import (
        get_node_by_lineno,
        get_nodes_of_type,
        get_node_type,
        test_ast_transformer,
    )

    tree = ast.parse('''
        a = 'foo'

        # "str" is also a variable name
        b = str
    ''')

    transformer = StringTypesTransformer()

    # Confirm that "str" is replaced.
    expected_tree = ast.parse('''
        a = u'foo'

        # "unicode" is also a variable name
        b = unicode
    ''')

    test_ast_transformer(tree, expected_tree, transformer)

# Generated at 2022-06-23 23:15:50.597077
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for StringTypesTransformer.

    Note:
        This is not a thorough unit test. Rather, it just tests
        that the class can be instantiated.

    """
    StringTypesTransformer()

# Generated at 2022-06-23 23:15:51.637148
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.transform(ast.parse('str')) == ast.parse('unicode')

# Generated at 2022-06-23 23:15:55.796600
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_string = ast.parse('print(str(5))')
    test_StringTypesTransformer = StringTypesTransformer()
    new_test_string = test_StringTypesTransformer.visit(test_string)
    assert(str(new_test_string) == "Module(body=[Print(dest=None, values=[Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=5)], keywords=[])], nl=True)])")

# Generated at 2022-06-23 23:15:59.188198
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Note: This test implicitly tests NameTransformer.
    before = """x = str(y)"""
    after = """x = unicode(y)"""
    tr = StringTypesTransformer()
    tr.transform_string(before) == after
    tr.transform_string(after) == after


# Generated at 2022-06-23 23:16:06.473912
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    astree = astor.parse_file('fibonacci.py')
    exploded_ast = astor.explode_topretty(astree)
    assert "str" in exploded_ast

    rv = StringTypesTransformer.transform(astree)
    assert rv.tree is not None

    exploded_ast = astor.explode_topretty(rv.tree)
    assert "str" not in exploded_ast
    assert "unicode" in exploded_ast

    # Sanity check
    assert rv.tree != astree

# Generated at 2022-06-23 23:16:13.128396
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    #Arrange
    code = textwrap.dedent('''\
    a = str("abc")''')
    
    expected = textwrap.dedent('''\
    a = unicode("abc")''')

    tree = ast.parse(code)

    #Act
    transf = StringTypesTransformer()
    new_tree = transf.transform(tree)

    #Assert
    result = compile(new_tree, '<test>', 'exec')
    exec(result)
    assert a == expected

# Generated at 2022-06-23 23:16:17.077005
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = inspect.cleandoc(
        """
        def f(s: str) -> str:
            return s
        """
    )
    tree = ast.parse(code, mode='exec')
    tree = StringTypesTransformer.transform(tree)
    tree = ast.fix_missing_locations(tree)
    code2 = compile(tree, '<string>', 'exec')
    exec(code2)

    assert(globals()['f']('foo') == 'foo')

# Generated at 2022-06-23 23:16:22.176155
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    import inspect
    from textwrap import dedent
    source = dedent(inspect.getsource(ast3))
    tree = ast3.parse(source)
    tree = StringTypesTransformer.run_pipeline(tree)
    assert source.count('str') > source.count('unicode')
    source = source.replace('str', 'unicode')
    assert ast3.dump(tree) == ast3.dump(ast3.parse(source))


# Generated at 2022-06-23 23:16:29.887496
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    import os
    import unittest

    class StringTypesTransformerTest(unittest.TestCase):
        def setUp(self):
            self.test_file_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_resources_dir = os.path.join(self.test_file_dir, '..', '..', 'test_resources')
            sys.path.append(self.test_resources_dir)

        def test_StringTypesTransformer(self):
            import test_string_types
            import test_string_types2
            from typed_ast import ast3
            f = open(os.path.join(self.test_resources_dir, 'test_string_types.py'), 'r')

# Generated at 2022-06-23 23:16:30.886239
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:16:34.779467
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string1 = "text = str(5)"
    string2 = "text = unicode(5)"
    test1 = ast.parse(string1)
    test2 = ast.parse(string2)
    result2 = StringTypesTransformer.transform(test1)
    assert result2.tree == test2

# Generated at 2022-06-23 23:16:39.667051
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    def run_actual():
        class_tree = ast.parse('return x+1').body[0].value
        tr = StringTypesTransformer.transform(class_tree)
        class_tree = tr.tree
        class_tree_code = astor.to_source(class_tree)
        print(class_tree_code)
    run_actual()

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:16:46.064285
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest

    class StringTypesTransformerTest(unittest.TestCase):
        def test(self):
            src = """
                str('a')
                type('a') is str
                """
            expected_result = """
                unicode('a')
                type('a') is unicode
                """
            t = StringTypesTransformer(None)
            self.assertEqual(str(t.transform(src)), expected_result)

    unittest.main()

# Generated at 2022-06-23 23:16:49.847291
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    tree = ast.parse("a = str()")
    StringTypesTransformer.transform(tree)
    expected = ast.parse("a = unicode()")
    assert astor.to_source(tree) == astor.to_source(expected),\
        "Adding paranthesis did not work"

    tree = ast.parse("a = str")
    StringTypesTransformer.transform(tree)
    expected = ast.parse("a = unicode")
    assert astor.to_source(tree) == astor.to_source(expected)

# Generated at 2022-06-23 23:16:52.182279
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
        a = str(b)
    """

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)

    print(ast.dump(tree.tree))
    exec(compile(tree, filename="", mode="exec"))
    assert (a == unicode(b))


# Generated at 2022-06-23 23:16:55.926534
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = u"""some_str = 'c'"""
    expected_src = u"""some_str = 'c'"""
    tree = ast.parse(src)
    new_tree = StringTypesTransformer.transform(tree)
    print(ast.dump(new_tree))
    assert ast.dump(new_tree) == expected_src

# Generated at 2022-06-23 23:17:00.208085
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
"abc"
"""
    )

    tree2 = ast.parse("""
u"abc"
"""
    )

    t = StringTypesTransformer()
    result = t.transform(tree)
    assert result.tree != tree
    assert ast.dump(result.tree) == ast.dump(tree2)

# Generated at 2022-06-23 23:17:03.288626
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    source = "a = str('foo') + str('bar')"
    tree = ast.parse(source)
    res = StringTypesTransformer.transfor

# Generated at 2022-06-23 23:17:04.350588
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:17:14.795528
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    from typed_ast import ast3 as ast
    from ..conversion import Converter


    tree = ast.parse("""
    s = "hello"
    i = 123
    f = 1.0
    b = True
    assert isinstance(s, str)
    assert isinstance(i, int)
    assert isinstance(f, float)
    assert isinstance(b, bool)
    """, "", "exec")
    typed_ast.ast3.fix_missing_locations(tree)

    tt = Converter(tree)
    root = tt.converted_tree
    tt.transform(StringTypesTransformer)
    assert tt.converted_tree.body[0].value.s == "hello"

# Generated at 2022-06-23 23:17:18.769455
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    tree = ast.parse("x = 'str'")
    result = transformer.transform(tree)
    assert type(result.tree.body[0]) == ast.Assign
    assert result.tree_changed
    assert type(find(result.tree, ast.Name)[0]) == ast.Name
    assert find(result.tree, ast.Name)[0].id == 'unicode'

# Generated at 2022-06-23 23:17:25.247779
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert find(StringTypesTransformer.transform(parse("from __future__ import unicode_literals")).tree, ast.Name) == []

    assert find(StringTypesTransformer.transform(parse("from __future__ import unicode_literals\nstr is not unicode")).tree, ast.Name)[0].id == 'unicode'

    assert find(StringTypesTransformer.transform(parse("from __future__ import unicode_literals\nstr is unicode")).tree, ast.Name)[0].id == 'unicode'

    assert find(StringTypesTransformer.transform(parse("from __future__ import unicode_literals\nstr = unicode")).tree, ast.Name)[0].id == 'unicode'


# Generated at 2022-06-23 23:17:35.595625
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseTransformer):

        @classmethod
        def transform(cls, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree, False, [])

    code = """
a = str(10)
"""
    tree = ast.parse(code)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)

    assert messages == []
    assert changed
    assert ast.dump(new_tree) == ast.dump(ast.parse("""
a = unicode(10)
"""))

    new_tree, changed, messages = DummyTransformer.transform(new_tree)

    assert messages == []
    assert not changed

# Generated at 2022-06-23 23:17:42.359332
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import fix_assertEqual
    from typed_ast import ast3 as ast
    from ..utils.testing import roundtrip
    from ..conversion.string_types import StringTypesTransformer

    source = """
    def foo(a: str):
        pass
    """

    expected = """
    def foo(a: unicode):
        pass
    """

    tree = ast.parse(source)
    fixed_tree = roundtrip(tree)

    StringTypesTransformer.transform(fixed_tree)

    fix_assertEqual(fixed_tree, expected)

# Generated at 2022-06-23 23:17:46.306420
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # code = '''
    #     def this_is_my_function(text: str) -> str:
    #         return text
    # '''
    tree = ast.parse('str("Hello")')
    StringTypesTransformer.transform(tree)
    assert dump_python_source(tree) == 'unicode("Hello")'


# Generated at 2022-06-23 23:17:54.955398
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import random
    import string
    from ..utils.tree import find, dump

    # Create a 'str' node
    st = ast.Name(id = 'str', ctx = ast.Load())

    # Build up an AST from 'st' node
    tree = ast.Module(body = [st])

    # Transform the tree
    res = StringTypesTransformer.transform(tree)

    # Check that the tree was transformed
    assert res.tree_changed

    # Check that the node was changed
    result = ast.dump(tree)
    assert ast.dump(st) != ast.dump(res.tree.body[0])

# Generated at 2022-06-23 23:17:55.528993
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:18:05.639415
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # type: () -> None
    
    from ..utils.source import source_to_tree, tree_to_source
    from ..errors import UnsupportedPythonFeature
    from typing import Any

    source = "str"
    expected_source = "unicode"
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert len(new_tree.errors) == 0
    actual_source = tree_to_source(new_tree.tree)
    assert actual_source == expected_source

    source = """
    def f(x: str):
        pass
    """
    expected_source = """
    def f(x: unicode):
        pass
    """
    tree = source_to_tree(source)
    new_tree = StringTypesTransformer.transform(tree)

# Generated at 2022-06-23 23:18:06.878391
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:18:07.632233
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:18:12.004081
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .fixtures import python_source_tree
    tree = python_source_tree()
    t = StringTypesTransformer()
    result = t.transform(tree)
    assert result.tree_changed == True
    assert result.messages == []
    assert result.tree.body[0].body[0].value.left.id == 'unicode'

# Generated at 2022-06-23 23:18:14.072346
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    assert transformer.__name__ == 'StringTypesTransformer'
    assert transformer.__doc__ == 'Replaces `str` with `unicode`.'

# Generated at 2022-06-23 23:18:14.672394
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:18:15.115011
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:18:24.057557
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test if it works with the files in the test_files folder"""
    # path to the file that needs to be transformed
    # 1. Create a stringtypes python file that needs to be transformed
    # 2. Create a version of this file with the correct 2to3 transformations
    fileToTransform = "StringTypesTransformer.py"
    # Path to the correct version of the file
    correctFilePath = "StringTypesTransformer-correct.py"

    # This is where you should put the correct file for comparison
    # Locations of the files to compare
    testFilePath = "StringTypesTransformer-test.py"
    # opens the testfile and correctfile, reads them and stores them
    f = open(testFilePath, 'r')
    filedata = f.read()
    f.close()

    c = open(correctFilePath, 'r')

# Generated at 2022-06-23 23:18:28.342331
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from astor.code_gen import to_source

    module = ast.parse('a = str')
    StringTypesTransformer.transform(module)
    assert to_source(module) == 'a = unicode'

# Generated at 2022-06-23 23:18:33.260164
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test StringTypesTransformer.
    """
    from ..tools import transform_file
    from .asserts import assert_transformation_result

    source = """
s = str('hello')
    """.strip()

    expected = """
s = unicode('hello')
    """.strip()

    result = transform_file(source, [StringTypesTransformer])

    assert_transformation_result(result, expected)

# Generated at 2022-06-23 23:18:36.247865
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
s = 'hello'
s2 = "world"
    """
    tree = ast.parse(code)
    tt = StringTypesTransformer()
    tt.transform(tree)
    tt.transform(tree)
    assert compile(tree, '', 'exec')

# Generated at 2022-06-23 23:18:42.641730
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.snippets import (
        snippet_1,
        snippet_2,
        snippet_3,
    )

    for code_snippet in [snippet_1, snippet_2, snippet_3]:
        tree = ast.parse(code_snippet)
        result = StringTypesTransformer.transform(tree)
        print(ast.dump(result.tree))
        assert result.tree_changed is True

# Run unit tests
if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:18:46.332526
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(3)')
    transformer = StringTypesTransformer()
    transformed_tree, tree_changed, _ = transformer.transform(tree)
    assert tree_changed
    assert ast.dump(transformed_tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=3)], keywords=[]))])"

# Generated at 2022-06-23 23:18:46.920998
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-23 23:18:52.914086
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
s = str(s)
""")
    expected_source = """
s = unicode(s)
"""
    new_tree = StringTypesTransformer.transform(tree)[0]
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_source))
    print("Test passed")

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-23 23:18:56.624383
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Instantiating the class
    string_types = StringTypesTransformer()

    # Testing the string transformation
    sample = ast.parse('str = "hello, world"')
    string_types.transform(sample)

    expected = ast.parse('unicode = "hello, world"')
    assert ast.dump(sample) == ast.dump(expected)

# Generated at 2022-06-23 23:19:00.514383
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from .utils import roundtrip
    inp = """
    a = str
    """
    tree = ast.parse(inp)
    tree = roundtrip(tree)
    assert astor.to_source(tree) == 'a = unicode\n'
    assert StringTypesTransformer.transform(tree).tree_changed

# Generated at 2022-06-23 23:19:02.324339
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
  # Arrange
  from .utils.messages import Message
  from .utils.tree import generate_tree


# Generated at 2022-06-23 23:19:10.609647
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # empty AST
    assert StringTypesTransformer.transform(ast.Module(body=[])).tree_changed == False

    # case 1
    tree = ast.parse("x = str(y)")
    tree = StringTypesTransformer.transform(tree).tree
    assert tree.body[0].value.func.id == 'unicode'

    # case 2
    tree = ast.parse("if a == str(b): pass")
    tree = StringTypesTransformer.transform(tree).tree
    assert tree.body[0].test.left.id == 'a'
    assert tree.body[0].test.ops[0].__class__.__name__ == 'Eq'
    assert tree.body[0].test.comparators[0].func.id == 'unicode'

    # case 3

# Generated at 2022-06-23 23:19:15.625802
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    code = """
    x = str()
    """

    # Act
    result = StringTypesTransformer.transform(ast.parse(code))

    # Assert
    assert result.tree_changed
    assert result.messages == []
    assert ast.dump(result.tree) == ast.dump(ast.parse("""
    x = unicode()
    """))

# Generated at 2022-06-23 23:19:17.371237
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    
    """
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'

# Generated at 2022-06-23 23:19:18.776121
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer()

# Unit test - replaces `str` with `unicode`

# Generated at 2022-06-23 23:19:20.578426
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_ast = ast.parse("print ('hello')")
    tree_changed = StringTypesTransformer.transform(test_ast)[1]
    assert tree_changed == False

# Generated at 2022-06-23 23:19:24.332616
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import sys
    import textwrap

    code = textwrap.dedent("""\
    x = str('abc')
    """)

    tree = ast.parse(code)
    trans = sys.modules[__name__]
    transformed = trans.StringTypesTransformer().visit(tree)
    gen = ast.get_source(transformed)
    for ln in gen:
        print(ln)

#test_StringTypesTransformer()

# Generated at 2022-06-23 23:19:31.079065
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_helper import ast_parse, ast_to_source
    from ..transformation import TransformationContext
    from ..utils.tree import ast_equal

    source = """
        x = str()
        y = str(x)

    """
    tree = ast_parse(source)
    tree = StringTypesTransformer.transform(tree)
    result = ast_to_source(tree)
    assert ast_equal(tree, ast_parse(result))
    expected = """
        x = unicode()
        y = unicode(x)

    """
    assert result == expected

# Generated at 2022-06-23 23:19:32.119220
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:19:41.040595
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    from .StringTypesTransformer import StringTypesTransformer
    from .base import BaseTransformer
    import inspect

    assert inspect.isclass(StringTypesTransformer)
    assert issubclass(StringTypesTransformer, BaseTransformer)

    assert hasattr(StringTypesTransformer, "target")
    assert hasattr(StringTypesTransformer, "transform")

    assert inspect.ismethod(StringTypesTransformer.transform)
    assert inspect.getsource(StringTypesTransformer.transform)

    # Test transform()

    assert isinstance(StringTypesTransformer.transform(typed_ast.ast3.parse("x")), tuple)
    assert StringTypesTransformer.transform(typed_ast.ast3.parse("x")) == (typed_ast.ast3.parse("x"), False, [])


# Generated at 2022-06-23 23:19:42.936009
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Declares an instance of the class StringTypesTransformer
    t = StringTypesTransformer()

    # Checks if an instance of the class StringTypesTransformer
    assert isinstance(t, StringTypesTransformer)

# Generated at 2022-06-23 23:19:53.006547
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Before the transformation, the string will be printed
    input1 = """x = str('Hello')"""
    # After the transformation, the unicode string will be printed
    output1 = """x = unicode('Hello')"""
    # Before the transformation, the string will be printed
    input2 = """def func(x: str):\n  return x"""
    # After the transformation, the unicode string will be printed
    output2 = """def func(x):\n  return x"""
    # Before the transformation, the string will be printed and True will be returned
    input3 = """def func(x: str):\n  print(x)\n  return True"""
    # After the transformation, the unicode string will be printed and True will be returned
    output3 = """def func(x):\n  print(x)\n  return True"""



# Generated at 2022-06-23 23:19:58.206994
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import parse

    source_code = '''
    def foo():
        return str == unicode
    '''

    target_code = '''
    def foo():
        return unicode == unicode
    '''    

    tree = parse(source_code)
    result = StringTypesTransformer.transform(tree)

    assert result.tree != tree
    assert ast.dump(result.tree) == target_code

# Generated at 2022-06-23 23:19:59.402017
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast


# Generated at 2022-06-23 23:20:00.526736
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-23 23:20:07.895905
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    from ..utils.source import source_to_unicode

    source = u"""
    name = str(42)
    """
    tree = ast.parse(source_to_unicode(textwrap.dedent(source)))

    StringTypesTransformer.transform(tree)

    source = u"""
    name = unicode(42)
    """
    reference = ast.parse(source_to_unicode(textwrap.dedent(source)))

    assert ast.dump(tree) == ast.dump(reference)

# Generated at 2022-06-23 23:20:19.455845
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Create an instance of class StringTypesTransformer
    transformer = StringTypesTransformer.__new__(StringTypesTransformer)
    # The following 3 method calls are necessary for the unit test
    transformer.__init__()
    transformer.transformed_targets = set()
    transformer.transformed_abstract_syntax_trees = dict()
    assert transformer.target == (2, 7)
    
    # Transform the following test code
    test_tree = ast.parse("foo = str('bar')")
    expected_tree = ast.parse("foo = unicode('bar')")
    output_tree, tree_changed, modules_changed = transformer.transform(test_tree)
    
    # The unit test
    assert tree_changed == True
    assert compare_ast(expected_tree, output_tree) == True