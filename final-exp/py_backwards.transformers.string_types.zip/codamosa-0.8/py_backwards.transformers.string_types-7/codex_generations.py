

# Generated at 2022-06-12 04:01:57.615460
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    r"""Unit test for constructor of class StringTypesTransformer

    .. code-block:: python

        assert True

    """
    import ast as std_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast27

    std_tree = std_ast.parse('s = str("Hello, world!")', mode='exec')
    typed_tree = typed_ast.ast3.parse('s = str("Hello, world!")', mode='exec')
    typed_ast27_tree = ast27.parse('s = str("Hello, world!")', mode='exec')

    t = StringTypesTransformer()

    # typed_ast27 -> std_ast
    transformed, _ = t.visit(typed_ast27_tree)
    assert transformed == std_tree

    # typed_ast -> std_ast


# Generated at 2022-06-12 04:02:00.160438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
	tree = ast.parse("str")
	StringTypesTransformer.transform(tree)
	assert(astunparse(tree) == "unicode")

# Generated at 2022-06-12 04:02:07.587584
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typing
    import typed_ast.ast3 as ast
    from .utils import roundtrip, compare_ast

    code = '''
        import sys
        from unicode_literals import *
        def foo(x: str) -> str:
            y = str()
        '''

    compare_ast(StringTypesTransformer.transform(ast.parse(code, mode='exec')),
                ast.parse(code, mode='exec'),
                ignore_fields=['lineno', 'col_offset', 'ctx'])

# Generated at 2022-06-12 04:02:08.153384
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:02:10.761665
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert repr(StringTypesTransformer) == 'StringTypesTransformer()'
    assert str(StringTypesTransformer) == 'StringTypesTransformer()'


# Generated at 2022-06-12 04:02:16.240534
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    def test_case(input, expected):
        tree = ast.parse(input)
        new_tree, tree_changed, messages = StringTypesTransformer.transform(tree)
        assert tree_changed == (expected != input)
        assert compile(new_tree, "<string>", "exec") == compile(expected, "<string>", "exec")

    input = '''
x = str(5)
y = str(12)
    '''
    expected = '''
x = unicode(5)
y = unicode(12)
    '''
    test_case(input, expected)

# Generated at 2022-06-12 04:02:18.499786
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert eval(StringTypesTransformer.run_example_code()) == "Hello, World!"

# Generated at 2022-06-12 04:02:21.092489
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:02:25.221185
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Set up test arguments
    tree = ast.parse('print(str(2))')

    # Run test
    result = StringTypesTransformer.transform(tree)

    # Verify results
    assert result.tree.body[0].value.args[0].n == 2
    assert result.tree.body[0].value.func.id == 'unicode'
    assert result.tree_changed

# Generated at 2022-06-12 04:02:30.328107
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = ast.Name(id='str')
    tree = ast.parse(
        'x = "abc" + "def"')
    result = StringTypesTransformer.transform(tree)
    assert(result.tree == ast.parse('x = "abc" + "def"'))
    assert(result.tree_changed == False)

# Generated at 2022-06-12 04:02:35.157893
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TODO: Finish unit test for StringTypesTransformer
    pass

# Generated at 2022-06-12 04:02:45.400418
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = '''
        a = "힝"
        if isinstance(a, str):
            print("힝")
    '''
    t = ast.parse(s)
    transformer = StringTypesTransformer()
    result = transformer.transform(t)
    assert result.tree_changed
    assert result.messages == []
    s = '''
        a = "힝"
        if isinstance(a, unicode):
            print("힝")
    '''
    t = ast.parse(s)
    assert t == result.tree
    s = '''
        a = "힝"
        if isinstance(a, str):
            print("힝")
        print(a)
    '''
    t = ast.parse(s)

# Generated at 2022-06-12 04:02:52.716263
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    tree = ast.parse('str("Hi")')
    tree_changed, new_tree, imports = StringTypesTransformer.transform(tree)
    asdl_ast = ast.dump(new_tree)
    assert asdl_ast == "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='Hi')], keywords=[], starargs=None, kwargs=None), lineno=1, col_offset=0)"
    assert tree_changed == True

# Generated at 2022-06-12 04:03:02.999377
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test class StringTypesTransformer.

    """
    node = ast.Name(id='str', ctx=ast.Load())
    tree = ast.Module(body=[])
    tree.body.append(node)

    # Test before transformation
    assert type(node) == ast.Name
    assert node.id == 'str'
    assert node.ctx == ast.Load()

    # Test after transformation
    result = StringTypesTransformer.transform(tree)
    new_node = result.tree.body[0]

    assert result.tree_changed
    assert type(new_node) == ast.Name
    assert new_node.id == 'unicode'
    assert new_node.ctx == ast.Load()

# Generated at 2022-06-12 04:03:06.121638
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''def foo(x: str) -> str:
    return x
    '''
    assert (StringTypesTransformer.transform(ast.parse(code)).code ==
            'def foo(x: unicode) -> unicode:\n    return x\n')



# Generated at 2022-06-12 04:03:12.258630
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree
    from ..utils.compare import compare_trees

    src = """def foo():
    f"Hello, {x}!"
"""
    expected_src = """def foo():
    u"Hello, {x}!".format(x=x)
"""

    tree = source_to_tree(src)
    new_tree = StringTypesTransformer.transform(tree).tree

    compare_trees(expected_src, new_tree)



# Generated at 2022-06-12 04:03:14.678165
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str("a")')) == 1
    assert StringTypesTransformer.transform(ast.parse('unicode("a")')) == 0

# Generated at 2022-06-12 04:03:15.658399
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:25.677522
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input = """
        def test(s):
            pass
    """

    tree = ast.parse(input)
    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert result.dependencies == []

    output = ast.fix_missing_locations(result.tree)
    assert ast.dump(output) == "Module(body=[FunctionDef(name='test', args=arguments(args=[arg(arg='s', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)])"

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:03:28.736927
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'a = str(1)'
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    transformer.transform(tree)

    assert 'unicode' == tree.body[0].value.func.id

# Generated at 2022-06-12 04:03:40.455360
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..types import zero_linter

    tree = ast.parse("""
i = str(s)
""")

    # Apply transformation
    result = StringTypesTransformer.transform(tree)

    # Make sure number of replacements is correct
    assert len(result.replacements) == 1

    # And replacement is correct
    assert result.replacements[0] == (1, 0, 1, 4, 'unicode')

    # Check if resulting tree is correct
    zero_linter.linter.set_params(linter_params={'import_unicode_literals': False})
    assert zero_linter.run_linter(result.tree) == []


# Generated at 2022-06-12 04:03:49.715109
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open("../samples/sample_4_for_StringTypesTransformer.py") as f:
        sample_4_contents = f.read()
    sample_4_tree = ast.parse(sample_4_contents)
    transformer = StringTypesTransformer()
    expected_contents = sample_4_contents.replace("str", "unicode")
    expected_tree = ast.parse(expected_contents)
    actual_result = transformer.transform(sample_4_tree)
    assert isinstance(actual_result.new_tree, ast.AST)
    assert actual_result.tree_changed == True
    assert actual_result.num_changes == 4
    print("Success for StringTypesTransformer!")

# Generated at 2022-06-12 04:03:54.761955
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..tests.test_utils import assert_transformation
    from ..tests.test_utils import get_test_case_parser
    from .default import DefaultTransformer

    parser = get_test_case_parser()

    for test in parser.get_test_cases():
        transformer = StringTypesTransformer()

        assert_transformation(transformer, None, test)

# Generated at 2022-06-12 04:03:57.655783
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass
# This file was generated automatically by GenerateSourceCode.py
# from /Users/cacreggi/Documents/research/m2cgen/steps/typed_ast/transformers/StringTypesTransformer.py
# DO NOT EDIT!

# Generated at 2022-06-12 04:03:59.149814
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    _ = StringTypesTransformer()

# Generated at 2022-06-12 04:04:00.974393
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor


# Generated at 2022-06-12 04:04:04.877467
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
a = str()
""")

    actual = StringTypesTransformer.transform(tree).tree

    expected = ast.parse("""
a = unicode()
""")

    assert ast.dump(expected, include_attributes=False) == ast.dump(actual, include_attributes=False)

# Generated at 2022-06-12 04:04:11.253958
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("a = str()")
    t = StringTypesTransformer()
    res = t.visit(tree)
    print(res)
    assert res.tree_changed == True
    assert len(res.additions) == 0
    assert str(res.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"

# Generated at 2022-06-12 04:04:20.643536
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('""')
    obj = StringTypesTransformer.transform(tree)
    tree = obj.tree
    assert(isinstance(tree, ast.AST) == True)
    assert(obj.tree_changed == False)
    assert(obj.warnings == [])

    tree = ast.parse('a = str')
    obj = StringTypesTransformer.transform(tree)
    tree = obj.tree
    assert(isinstance(tree, ast.AST) == True)
    assert(obj.tree_changed == True)
    assert(obj.warnings == [])

    tree = ast.parse('a = "str"')
    obj = StringTypesTransformer.transform(tree)
    tree = obj.tree
    assert(isinstance(tree, ast.AST) == True)

# Generated at 2022-06-12 04:04:25.472232
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name(id='str')
    res = StringTypesTransformer.transform(node)
    assert res.changed
    assert res.tree.id == 'unicode'
    res = StringTypesTransformer.transform(ast.Name(id='unicode'))
    assert not res.changed

# Generated at 2022-06-12 04:04:40.711695
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse('print(str)')
    tree = StringTypesTransformer().visit(tree)
    assert typed_ast.ast3.dump(tree) == "Module(body=[Print(dest=None, values=[Name(id='unicode', ctx=Load())], nl=True)])"
    tree = typed_ast.ast3.parse('from typing import TYPE_CHECKING')
    tree = StringTypesTransformer().visit(tree)
    assert typed_ast.ast3.dump(tree) == "Module(body=[ImportFrom(module='typing', names=[alias(name='TYPE_CHECKING', asname=None)], level=0)])"



# Generated at 2022-06-12 04:04:47.496878
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''def f(x: str):
     return x'''
    tree = ast.parse(code)
    assert tree.body[0].args.args[0].annotation.id == 'str'
    t = StringTypesTransformer()
    transformed_tree = t.transform(copy.deepcopy(tree))
    assert transformed_tree.tree.body[0].args.args[0].annotation.id == 'unicode'


if __name__ == '__main__':
    code = '''def f(x: str):
     return x'''
    tree = ast.parse(code)
    assert tree.body[0].args.args[0].annotation.id == 'str'
    UnicodeFunctionParameterAnnotationsTransformer.transform(tree)
    assert tree.body[0].args.args[0].ann

# Generated at 2022-06-12 04:04:52.587459
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str()')
    assert find(tree, ast.Name).id == 'str'
    tree_ = ast.parse('unicode()')
    assert find(tree_, ast.Name).id == 'unicode'

    trans = StringTypesTransformer()
    result = trans.transform(tree)
    assert result.tree == tree_

# Generated at 2022-06-12 04:04:56.677670
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ...tests.transformer_test import run_test_for

    source = """
    s = str("test")
    """

    expected = """
    s = unicode("test")
    """

    source, expected = source.split("\n"), expected.split("\n") 
    run_test_for(StringTypesTransformer, source, expected)

# Generated at 2022-06-12 04:05:05.310099
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # This transformer should remain unchanged
    tree = ast.parse("str('str')")
    uut = StringTypesTransformer()
    assert uut.transform(tree) == TransformationResult(tree, False, [])

    # This transformer should be changed
    tree = ast.parse("str('str')")
    uut = StringTypesTransformer()
    assert uut.transform(tree) == TransformationResult(tree, True, [])

    # This transformer should not be changed
    tree = ast.parse("str('str')")
    uut = StringTypesTransformer()
    assert uut.transform(tree) == TransformationResult(tree, False, [])

# Generated at 2022-06-12 04:05:06.639388
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.construct() == StringTypesTransformer()

# Generated at 2022-06-12 04:05:13.722941
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Set tree and expected result
    tree = ast.parse("""def test_it(a):\n b = str(a)""")
    expected_tree = ast.parse("""def test_it(a):\n b = unicode(a)""")

    # Get actual result
    actual_result = StringTypesTransformer.transform(tree)

    # Assert
    assert actual_result.tree == expected_tree
    assert actual_result.tree_changed == True
    assert actual_result.warnings == []

# Generated at 2022-06-12 04:05:22.678239
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from typed_ast import ast3
    import sys
    import unittest

    class TestStringTypesTransformer(unittest.TestCase):
        def _test_case(self, before, after):
            self.assertEqual(str(ast.parse(after)),
                             str(transform(ast.parse(before),
                                           StringTypesTransformer)))

        def test_non_substituted(self):
            code = 'a = 1\n'
            self._test_case(code, code)

        def test_substitution(self):
            code = 'a = str(1)\nb = str(2)\n'
            self._test_case(code, 'a = unicode(1)\nb = unicode(2)\n')

    unittest.main()

# Generated at 2022-06-12 04:05:28.047174
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
x = 'Hello world'
y = str(5)
z = '5'
"""
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.transformed_code == """
x = 'Hello world'
y = unicode(5)
z = '5'
"""

# Generated at 2022-06-12 04:05:29.286456
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer(2, 7).tree != None

# Generated at 2022-06-12 04:05:45.032540
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str')
    actual = StringTypesTransformer.transform(tree)
    assert actual.tree_changed
    expected_code = 'a = unicode'
    actual_code = astor.to_source(actual.tree).rstrip()
    assert actual_code == expected_code

# Generated at 2022-06-12 04:05:50.021503
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    test_code = '''
    x = str(10)
    class Y(str):
        pass
    '''
    expected_code = '''
    x = unicode(10)
    class Y(unicode):
        pass
    '''
    test_tree = ast.parse(test_code)
    tree_changed, errors, new_tree = StringTypesTransformer.transform(test_tree)
    assert tree_changed
    assert not errors
    assert astor.to_source(new_tree) == expected_code

# Generated at 2022-06-12 04:05:57.560462
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s ="""
    def foo():
        return str(1)
    """
    t = ast.parse(s)
    c = StringTypesTransformer.transform(t)
    assert isinstance(c, TransformationResult)
    assert str(c.tree) == """Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Return(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[]))], decorator_list=[], returns=None)])"""

# Generated at 2022-06-12 04:06:02.886791
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('print(str)')
    new_tree, changed, _ = StringTypesTransformer.transform(tree)

    assert changed
    assert ast.dump(new_tree) == 'Module(body=[Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Name(id=\'unicode\', ctx=Load())], keywords=[]))])'

# Generated at 2022-06-12 04:06:08.512251
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
    def foo(a: str):
        pass
    """)

    fixed_tree = ast.parse("""
    def foo(a: unicode):
        pass
    """)

    result = StringTypesTransformer.transform(tree)
    assert ast.dump(result.tree) == ast.dump(fixed_tree)
    asse

# Generated at 2022-06-12 04:06:13.743059
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """
for i in range(10):
    s = str(i)
    """
    expected_code = """
for i in range(10):
    s = unicode(i)
    """
    tree = astor.parse_file(code)
    trans = StringTypesTransformer()
    trans.visit(tree)
    print(astor.to_source(tree))
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-12 04:06:19.167111
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    assert not StringTypesTransformer.transform(ast.parse("x + 1")).changed
    assert StringTypesTransformer.transform(ast.parse("'x' + 1")).tree == \
        ast.parse("u'x' + 1")
    assert StringTypesTransformer.transform(ast.parse("'x' + str(1)")).tree == \
        ast.parse("u'x' + unicode(1)")

# Generated at 2022-06-12 04:06:23.327541
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    myStr = ast.Name(id = "str", ctx = ast.Load())
    assert isinstance(myStr, ast.AST)
    assert isinstance(myStr, ast.Name)
    assert myStr.id == "str"
    assert myStr.ctx == ast.Load()
    tree = ast.Assign(targets = [ast.Name(id = "x", ctx = ast.Store())], value = myStr)
    #print(ast.dump(tree))
    transformed_tree = StringTypesTransformer.transform(tree)
    #print(ast.dump(transformed_tree))
    assert transformed_tree.tree.value.id == 'unicode'


# Generated at 2022-06-12 04:06:25.653327
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:06:29.727054
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    tree = astor.parse("""
        print(str(3))
    """)

    # Check if we can transform this node
    assert StringTypesTransformer.can_handle(tree)

    result = StringTypesTransformer.transform(tree)

    # Check that the transformation is successful and that
    # the output is what we expect it to be.
    assert result.tree_changed
    assert astor.to_source(result.tree).strip() == 'print(unicode(3))'

# Generated at 2022-06-12 04:06:55.234880
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:06:57.230136
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:06:57.845155
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:07:01.932603
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("""
result = str(1)
""")
    expected_tree = ast.parse("""
result = unicode(1)
""")
    result = StringTypesTransformer.transform(tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.messages == []

# Generated at 2022-06-12 04:07:06.449950
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typing
    import typed_ast.ast3 as ast

    tree = ast.parse("""var = 'Hello'""")
    transformer = StringTypesTransformer()

    newTree, treeChanged = transformer.transform(tree)

    if(treeChanged):
        print("The following tree was changed by this transformer:")
    
    print(ast.dump(newTree))

# Generated at 2022-06-12 04:07:16.809189
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class TestStringTypesTransformer(unittest.TestCase):
        def setUp(self):
            self.transformer = StringTypesTransformer()

        def test_transform_literal(self):
            code = 'a = str("hello")'
            tree = ast.parse(code)
            tree_changed, _, _ = self.transformer.transform(tree)
            self.assertTrue(tree_changed)
            new_code = astor.to_source(tree)
            self.assertEqual(new_code, 'a = unicode("hello")')

        def test_transform_name(self):
            code = 'a = str'
            tree = ast.parse(code)
            tree_changed, _, _ = self.transformer.transform(tree)
            self.assertTrue(tree_changed)
            new_

# Generated at 2022-06-12 04:07:24.984631
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    source = """
    a = str()
    b = x + str(y)
    """
    
    tree = source_to_ast(source)
    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed == True
    assert result.name_changes == []
    assert result.level == TransformationResult.BODY
    assert ast.dump(result.tree) == ast.dump(source_to_ast("""
    a = unicode()
    b = x + unicode(y)
    """))


# Generated at 2022-06-12 04:07:25.931367
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer() is not None

# Generated at 2022-06-12 04:07:29.534885
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = '''
    d = ["abc", "def", "ghi"]
    x = str(1)
    '''
    result = transform_source(src, StringTypesTransformer)
    assert result == '''
    d = [u"abc", u"def", u"ghi"]
    x = unicode(1)
    '''

# Generated at 2022-06-12 04:07:38.869648
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    given = ast.parse("""
if isinstance(var1, str):
    print(var1)
else:
    print(var2)

if isinstance(var3, str):
    print(var3)

if var4 is str:
    print(var4)
else:
    print(var5)
""")

    expected = ast.parse("""
if isinstance(var1, unicode):
    print(var1)
else:
    print(var2)

if isinstance(var3, unicode):
    print(var3)

if var4 is unicode:
    print(var4)
else:
    print(var5)
""")

    # When
    actual = StringTypesTransformer.transform(given)

    # Then
    assert actual.tree == expected

# Generated at 2022-06-12 04:08:43.746975
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        def test_simple(self):
            self.do_test(
                before='''str = 1''',
                after='''unicode = 1''',
                transformer=StringTypesTransformer
            )

        def test_double(self):
            self.do_test(
                before='''
                str = 1
                str = 2
                ''',
                after='''
                unicode = 1
                unicode = 2
                ''',
                transformer=StringTypesTransformer
            )

# Generated at 2022-06-12 04:08:48.623322
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert_tree_equality(
        'a=str(1)',
        'a=unicode(1)',
        StringTypesTransformer,
    )
    assert_tree_equality(
        'def f(a:str): pass',
        'def f(a:unicode): pass',
        StringTypesTransformer,
    )
    assert_tree_equality(
        'a="string"',
        'a="string"',
        StringTypesTransformer,
    )

# Generated at 2022-06-12 04:08:53.721935
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    sample_code = """
        x = str(1)
    """
    tree = ast.parse(sample_code)
    result = StringTypesTransformer.transform(tree)
    print(astor.to_source(result.tree))
    assert astor.to_source(result.tree) == "x = unicode(1)\n"

# Generated at 2022-06-12 04:09:03.560615
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # from ..utils.tree import dump
    from ..utils.tree import build

    tree = build("name = str(a)")

    # print("Before transform: \n{}".format(dump(tree)))
    result = StringTypesTransformer.transform(tree)
    # print("After transform: \n{}".format(dump(result.new_tree)))

    assert isinstance(result.new_tree, ast.Module)
    assert len(result.new_tree.body) == 1
    assert isinstance(result.new_tree.body[0], ast.Assign)
    assert len(result.new_tree.body[0].targets) == 1
    assert isinstance(result.new_tree.body[0].targets[0], ast.Name)
    assert result.new_tree.body[0].t

# Generated at 2022-06-12 04:09:04.496995
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:09:09.540808
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    cls = StringTypesTransformer()
    tree = ast.parse("""\
try:
    from builtins import str
except ImportError:
    pass
""")
    result = cls.transform(tree)
    expected = ast.parse("""\
try:
    from builtins import unicode
except ImportError:
    pass
""")
    assert ast.dump(result.tree) == ast.dump(expected)

# Generated at 2022-06-12 04:09:16.324910
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_src
    from ..types import TransformationResult

    src = """
    def f():
        x = str("ok")
        return len(x)
    """
    tree = ast.parse(src)
    t = StringTypesTransformer()
    result = t.transform(tree)
    expected_src = """
    def f():
        x = unicode("ok")
        return len(x)
    """
    assert to_src(result.tree) == expected_src

# Generated at 2022-06-12 04:09:17.734247
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.node import find_all_by_type, compare_nodes


# Generated at 2022-06-12 04:09:23.405619
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    origin_source = '''
    import base64
    a = str()
    '''

    expected = '''
    import base64
    a = unicode()
    '''

    # Act
    comp_unit = ast.parse(origin_source)
    #print(ast.dump(comp_unit))
    result = StringTypesTransformer.transform(comp_unit)

    # Assert
    #print(ast.dump(result.tree))
    assert ast.dump(comp_unit) == expected

# Generated at 2022-06-12 04:09:27.538367
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 

    code = """str = 'hello'""" 

    # parse the code string into a AST object 
    root_node = ast.parse(code) 

    # initialize the constructor 
    assert(str(StringTypesTransformer.transform(root_node)[0]) == "str = u'hello'")

# Generated at 2022-06-12 04:11:45.178333
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse_str

    s = parse_str('str')
    assert isinstance(s, ast.Name)

    tree_changed, tree, messages = StringTypesTransformer(
        tree=s, target=(2, 7)).transform()
    assert tree_changed
    assert isinstance(tree, ast.Name)
    assert tree.id == 'unicode'

    messages_expected = []
    assert messages == messages_expected


"""DisabledContent
"""

# Generated at 2022-06-12 04:11:52.951621
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # 1) Transforming Test1

    # Creating AST
    string_types_transformer = StringTypesTransformer()

    tree = ast.parse('1')

    # Transforming AST
    result = string_types_transformer.transform(tree)

    # Testing if result is correct
    test1_transformed_tree = ast.parse('1')

    assert result.tree == test1_transformed_tree

    # 2) Transforming Test2

    # Creating AST
    string_types_transformer = StringTypesTransformer()

    tree = ast.parse('p')

    # Transforming AST
    result = string_types_transformer.transform(tree)

    # Testing if result is correct
    test2_transformed_tree = ast.parse('p')

    assert result.tree == test2_transformed_tree

    # 3) Trans