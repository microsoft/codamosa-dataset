

# Generated at 2022-06-12 04:01:52.647415
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str("hello world")')
    result = StringTypesTransformer.transform(tree)
    assert result.tree == ast.parse('unicode("hello world")')

# Generated at 2022-06-12 04:01:56.375784
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
    a = 'hello'
    b = str(a)
    """
    expects = """
    a = 'hello'
    b = unicode(a)
    """
    tree = ast.parse(src)
    StringTypesTransformer.transform(tree)
    assert astunparse.unparse(tree).strip() == expects.strip()

# Generated at 2022-06-12 04:02:03.010025
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTester
    from ..utils.source import Source

    source_code = """
        def x():
            return str(1)
    """

    # Note: We want to make sure that the transformer has no issues with
    #       unicode characters
    assert isinstance(source_code, str)

    BaseTester.test_transformer(source_code, StringTypesTransformer, """
        def x():
            return unicode(1)
    """)

# Generated at 2022-06-12 04:02:04.018343
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test for constructor"""
    assert (StringTypesTransformer.name == "StringTypesTransformer")
    assert (StringTypesTransformer.target == (2, 7))

# Generated at 2022-06-12 04:02:10.807201
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.python import get_ast
    import textwrap
    tree = get_ast(textwrap.dedent("""
                                 def x():
                                 return str(1)
                                 """))
    StringTypesTransformer(tree).transform()

    result = get_ast(textwrap.dedent("""
                                 def x():
                                 return unicode(1)
                                 """))

    assert result ==  tree
    print(ast.dump(tree))

# Generated at 2022-06-12 04:02:11.393410
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:02:17.433207
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import build_ast
    from ..utils.dump_ast import dump_ast
    code = """
    class A(str):
        pass
    a = str(123)
    """
    tree = build_ast(code)
    res = StringTypesTransformer.transform(tree)
    assert res.code == """
    class A(unicode):
        pass
    a = unicode(123)
    """

# Generated at 2022-06-12 04:02:22.010653
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name()
    node.id = 'str'
    # print (node.id)
    result = StringTypesTransformer.transform(node)
    assert result.tree == node
    # print(result.tree)
    assert result.tree.id == 'unicode'

# Generated at 2022-06-12 04:02:28.394619
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input = """import six\n
s = str('foo')
six.add_move(str)
six.add_metaclass(str)
six.assertRegex(str, str)
six.assertRaisesRegex(str, str, str, str)
six.reraise(str, str)
six.text_type(str)
six.StringIO(str)
six.StringIO()
six.BytesIO(str)
six.BytesIO()
six.moves.map(str, str)"""

# Generated at 2022-06-12 04:02:30.981041
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test object creation
    transformer = StringTypesTransformer()
    assert transformer is not None
    # test transform method exists (ok if no exception)
    StringTypesTransformer.transform(None)

# Generated at 2022-06-12 04:02:36.958806
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "result = str('string')"
    tree = ast.parse(code, mode='exec')
    tree = StringTypesTransformer()(tree)
    assert compile(tree, '<test>', 'exec').co_code.decode('utf-8').strip() == "result = unicode('string')"

# Generated at 2022-06-12 04:02:39.507949
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import run_transform

    run_transform(StringTypesTransformer, 'string_types.py', 2)

# Generated at 2022-06-12 04:02:46.035460
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''def foo():
    bar = str()
    baz = str
'''
    expected_target = '''def foo():
    bar = unicode()
    baz = unicode
'''
    source_tree = ast.parse(source)
    expected_tree = ast.parse(expected_target)
    transformer = StringTypesTransformer()
    result = transformer.transform(source_tree)
    assert result.tree == expected_tree
    assert result.tree_changed == True
    assert result.added_imports == []



# Generated at 2022-06-12 04:02:55.132881
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .typed_ast_unparse import unparse

    tree = ast.parse('import string\n'
                     'def test(x: str):\n'
                     '    print(string)\n'
                     '    return x\n')

    tree = StringTypesTransformer.transform(tree)[0]
    print(unparse(tree))
    assert unparse(tree) == 'import string\n\n' \
                            'def test(x: unicode):\n' \
                            '    print(string)\n' \
                            '    return x'

# Generated at 2022-06-12 04:03:04.467089
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode, source_to_ast
    from ..transformers.string_types import StringTypesTransformer

    source = source_to_unicode(
        """
        def do_stuff():
            return str(foo)
        """
    )
    expected = source_to_unicode(
       """
        def do_stuff():
            return unicode(foo)
        """
    )

    tree = source_to_ast(source)
    tree = StringTypesTransformer.run_pipeline(tree)
    tree = ast.fix_missing_locations(tree)
    assert expected == ast.unparse(tree)

# Generated at 2022-06-12 04:03:10.304816
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse
    from ..types import TransformationResult

    tree = parse("""
    def str_func():
        x = str(1)
    """)

    t = StringTypesTransformer()
    t.transform(tree)

    expected = """
    def str_func():
        x = unicode(1)
    """

    assert expected == t.module.as_string()
    #assert isinstance(t.module, ast.AST)
    assert isinstance(t.transform(tree), TransformationResult)

# Generated at 2022-06-12 04:03:17.332972
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test if the transformation is correctly carried out."""
    transformer = StringTypesTransformer()
    code_before = '''
    def my_function():
        my_str = str(42)'''
    code_after = '''
    def my_function():
        my_str = unicode(42)'''
    tree = ast.parse(code_before)
    tree_after = ast.parse(code_after)
    transformer.transform(tree)
    assert astor.to_source(tree) == astor.to_source(tree_after)



# Generated at 2022-06-12 04:03:18.320549
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:22.461132
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Foo:
        def bar(self, b: str):
            pass

    f = Foo()
    f.bar(b=42)
    assert f.b == 42

    f = Foo()
    f.bar(b='foo')
    assert f.b == 'foo'



# Generated at 2022-06-12 04:03:29.541677
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.fake_ast import fake_tree_builder
    from astpretty import pprint
    tree = fake_tree_builder(
        '''
        str
        (str, str)
        '''
    )
    tree2 = fake_tree_builder(
        '''
        unicode
        (unicode, unicode)
        '''
    )
    tree_changed, _, _ = StringTypesTransformer.transform(tree)
    assert tree_changed
    pprint(tree)
    assert tree == tree2

# Generated at 2022-06-12 04:03:34.415847
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # assert that the constructor of the class is not broken
    assert StringTypesTransformer(None) is not None

# Generated at 2022-06-12 04:03:36.184815
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = StringTypesTransformer(target = (2, 7))
    assert x.target == (2, 7)

# Generated at 2022-06-12 04:03:47.306410
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Create a test file
    input = """
a = 'abcdefg'
b = str(a)
c = ''.join(b)
d = str()
e = unicode()
    """
    tree = astor.parse_file(StringIO(input))

    # Define expected output
    expected_output = """
a = 'abcdefg'
b = unicode(a)
c = ''.join(b)
d = unicode()
e = unicode()
    """
    expected_tree = astor.parse_file(StringIO(expected_output))
    expected_report = []

    # Perform transformation
    result = StringTypesTransformer.transform(tree)

    # Assert that the transformation is correct

# Generated at 2022-06-12 04:03:50.257360
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """str("some string")"""
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    assert astor.to_source(tree) == "unicode(\"some string\")"

# Generated at 2022-06-12 04:03:59.316555
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for StringTypesTransformer.
    """
    from typed_ast import ast3
    from typed_ast import convert
    from astunparse import unparse
    from ..unparser import IndentationUnparser

    code1 = """
    ''' This is a docstring.'''
    # This is a comment.
    a = str(1)
    b = str('a')
    c = 1
    """

    test1 = ast.parse(code1)

    result = StringTypesTransformer.transform(test1)

    print(unparse(result.tree))
    print('')

    expected1 = """
    ''' This is a docstring.'''
    # This is a comment.
    a = unicode(1)
    b = unicode('a')
    c = 1
    """
    assert unparse

# Generated at 2022-06-12 04:04:05.553493
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    from .. import case

    class StringTypesTransformerTest(unittest.TestCase):
        def test_StringTypesTransformer(self):
            trans = case.from_file(case.FILES['str_types'], StringTypesTransformer)
            exec(case.to_code(trans))
            self.assertIsInstance(my_string, unicode)

    return StringTypesTransformerTest

# Generated at 2022-06-12 04:04:11.893243
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
            x = str()
            y = str(x)
            '''

    tree = ast.parse(code, 'exec')
    reference_code = '''
            x = unicode()
            y = unicode(x)
            '''

    dummy_transformation = StringTypesTransformer()
    result = dummy_transformation.transform(tree)
    print(result.tree)
    print(ast.dump(ast.parse(reference_code)))
    assert ast.dump(result.tree) == ast.dump(ast.parse(reference_code))

# Generated at 2022-06-12 04:04:20.081864
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Unit test for constructor of class StringTypesTransformer
    """
    import ast
    from . import transformations
    from .transformer import Transformer

    a = ast.parse("""
b = str()
c = str(1)
d = str(1,2,3)
e = str(a,b,c,d)
""")

    transformer = Transformer(transformations)
    transformer.transform_file(a)

    b = ast.parse("""
b = unicode()
c = unicode(1)
d = unicode(1,2,3)
e = unicode(a,b,c,d)
""")

    assert ast.dump(a) == ast.dump(b)

# Generated at 2022-06-12 04:04:23.091176
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.ast_builder import build_ast
    from ..transformers.from_unicode import FromUnicodeTransformer


# Generated at 2022-06-12 04:04:28.558165
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # this test will not compile with python3, but it is not the point
    source = """a = str(a)"""
    expected = """a = unicode(a)"""

    tree = ast.parse(source)
    new_tree = StringTypesTransformer.run(tree)

    assert ast.dump(new_tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 04:04:39.123786
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer.target == (2, 7)
    assert string_types_transformer.name == 'StringTypesTransformer'
    assert string_types_transformer.description == 'Replaces str with unicode.'

# Generated at 2022-06-12 04:04:40.804202
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with pytest.raises(TypeError):
        StringTypesTransformer()


# Generated at 2022-06-12 04:04:44.560307
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    source = '''
import datetime
str(datetime.datetime.now())
'''

    tree = ast.parse(source)
    transformer.transform(tree)

    source = ast.unparse(tree)
    expected = """
import datetime
unicode(datetime.datetime.now())
"""

    assert source == expected

# Generated at 2022-06-12 04:04:48.147675
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_source = """
    import sys
    print(str(sys.version_info))
    """

    expected_output = """
    import sys
    print(unicode(sys.version_info))
    """
    out_tree = StringTypesTransformer.run_it(test_source)
    compare_ast(out_tree, expected_output)

# Generated at 2022-06-12 04:04:48.727205
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:04:54.857151
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("my_string = str()")
    tree = StringTypesTransformer.transform(tree).tree

    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='my_string', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-12 04:04:58.191485
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    @StringTypesTransformer.make_test
    def transform_test():
        l1 = 1
        l2 = str(1)
        l3 = l2
        l3 = 1
        return l1, l2, l3

    transform_test()


# Generated at 2022-06-12 04:05:04.919256
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
        def foo():
            s = str()
    '''

    new_code = '''
        def foo():
            s = unicode()
    '''

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    
    assert str(ast.Module(body=ast.parse(new_code).body).body[0]) == str(tree.tree.body[0])
    assert tree.tree_changed == True

# Generated at 2022-06-12 04:05:08.051665
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer().__class__.__name__ == 'StringTypesTransformer'
    instance = StringTypesTransformer()
    assert 'str' in inspect.getsource(instance.transform)


# Generated at 2022-06-12 04:05:14.540824
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse
    from textwrap import dedent

    source = dedent("""\
    def foo():
        x = str('xxx')
        return str(x)
    """)
    tree = ast.parse(source)
    print(astunparse.unparse(tree))

    tree2 = StringTypesTransformer.transform(tree).tree
    print(astunparse.unparse(tree2))

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:05:33.140183
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from ..utils.tree import get_ast
    source = """
    a = str()
    """
    tree = get_ast(source)
    result = StringTypesTransformer(tree)
    expected = """
    import builtins
    a = builtins.unicode()
    """
    assert str(result.tree) == expected
    assert result.tree_changed is True
    assert len(result.warnings) == 1

# Generated at 2022-06-12 04:05:35.079476
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    
    tree = ast.parse('str(42)')

    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed

# Generated at 2022-06-12 04:05:36.493370
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform('''str''')[0].body[0].value.id == 'unicode'

# Generated at 2022-06-12 04:05:46.503067
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:05:47.821019
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    import typed_ast.ast3 as ast


# Generated at 2022-06-12 04:05:56.720988
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1:
    tree = ast.parse("""
        from __future__ import unicode_literals
        filter(lambda item: item is not str, items)
    """)
    tree_changed, messages = StringTypesTransformer.transform(tree)
    print(ast.dump(tree))
    assert not tree_changed
    assert messages == []

    # Test 2:
    tree = ast.parse("""
        filter(lambda item: item is not str, items)
    """)
    tree_changed, messages = StringTypesTransformer.transform(tree)
    print(ast.dump(tree))
    assert tree_changed
    assert messages == []

# Generated at 2022-06-12 04:05:57.413932
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:06:05.854781
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..ast_parser import AstParser
    from ..unparser import Unparser
    from ..utils.dummy_context import DummyContext

    source = """\
    from builtins import str

    def my_function(my_string: str):
        return str(my_string)
    """
    tree = AstParser.parse(source)
    transformer = StringTypesTransformer.from_version(2, 7)
    transformer.transform(tree)
    unparser = Unparser(tree, DummyContext(2, 7))
    assert unparser.get_source() == """\
    from builtins import unicode

    def my_function(my_string: unicode):
        return unicode(my_string)
    """

# Generated at 2022-06-12 04:06:09.677580
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    from typing import List, Dict


# Generated at 2022-06-12 04:06:11.010733
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-12 04:06:39.370276
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = 'a = str(b)'
    tree = ast.parse(source)
    assert source == tree_to_str(tree)

    tree = StringTypesTransformer.transform(tree).tree
    assert tree_to_str(tree) == 'a = unicode(b)'

# Generated at 2022-06-12 04:06:41.418036
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # if __name__ == '__main__'
    #     exec(open('../../tests/transformers/test_StringTypesTransformer.py').read())
    print('')

# Generated at 2022-06-12 04:06:44.969697
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('x = str(b"xyz")')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert str(result.tree) == 'x = unicode(b"xyz")'

# Generated at 2022-06-12 04:06:51.610832
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    tree = ast.parse('if name == str: print(name)')
    new_tree = string_types_transformer.visit(tree)
    assert ast.dump(new_tree) == "Module(body=[If(test=Compare(left=Name(id='name', ctx=Load()), ops=[Eq()], comparators=[Name(id='unicode', ctx=Load())]), body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Name(id='name', ctx=Load())], keywords=[]))], orelse=[])])"

# Generated at 2022-06-12 04:07:00.168291
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_str = """
        class Person(object):
            def __init__(self, first_name, last_name):
                self.first_name = first_name
                self.last_name = last_name
        
        class Female(Person):
            def __init__(self, first_name, last_name):
                super(Female, self).__init__(first_name, last_name)
    """

# Generated at 2022-06-12 04:07:01.780191
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """

# Generated at 2022-06-12 04:07:02.308443
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:07:07.281319
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """str(2)"""
    if sys.version_info >= (3, 0):
        expect = "'2'"
    else:
        expect = "u'2'"
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    assert compile(tree, '', 'exec') == compile(expect, '', 'exec')

# Generated at 2022-06-12 04:07:15.380027
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    sample = ast.parse('print str')
    ast.fix_missing_locations(sample)
    transformed = StringTypesTransformer.transform(sample)
    assert isinstance(transformed, TransformationResult)
    assert isinstance(transformed.tree, ast.AST)
    assert transformed.tree_changed
    assert transformed.errors == []
    assert ast.dump(transformed.tree) == 'Expr(value=Call(func=Name(id="print", ctx=Load()), args=[Name(id="unicode", ctx=Load())], keywords=[], starargs=None, kwargs=None))'
    print(ast.dump(transformed.tree))

# Generated at 2022-06-12 04:07:21.456256
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input = """class Foo(str): pass"""
    expected = """class Foo(unicode): pass"""

    tree = ast.parse(input)
    transformed = StringTypesTransformer.transform(tree)
    actual = ast.unparse(transformed.tree)
    assert actual == expected

    input = """class Foo(object): def __init__(self, x): self.x = str(x)"""
    expected = """class Foo(object): def __init__(self, x): self.x = unicode(x)"""

    tree = ast.parse(input)
    transformed = StringTypesTransformer.transform(tree)
    actual = ast.unparse(transformed.tree)
    assert actual == expected

# Generated at 2022-06-12 04:08:29.138362
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_tree, tree_to_source
    from . import remove_imports_transformer
    from .import_transforms import import_transformer
    from ..test_transforms import python_source_samples
    for sample in python_source_samples:
        if sample["version"] == (2,7):
            print("checking: "+str(sample["source"]))
            tree = source_to_tree(sample["source"])
            tree = remove_imports_transformer.transform(tree)
            tree = import_transformer.transform(tree)
            assert not StringTypesTransformer.transform(tree).tree_changed
            print(tree_to_source(tree))

# Generated at 2022-06-12 04:08:36.447730
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """a, b = str(), u'foo'"""
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].targets[0].id == 'a'
    assert result.tree.body[0].targets[1].id == 'b'
    assert result.tree.body[0].value.func.id == 'unicode'
    assert isinstance(result.tree.body[0].value.args[0], ast.Str)
    assert result.tree.body[0].value.args[0].s == ''
    assert result.tree.body[0].value.keywords[0].value.s == u'foo'

# Generated at 2022-06-12 04:08:37.035224
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-12 04:08:39.514440
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("x = str('hello')", "<ast>", 'exec')).new_tree.body[0].value.func.id == "unicode"

# Generated at 2022-06-12 04:08:48.566877
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # arg: str
    tree = ast.parse('func(str)')
    tree = StringTypesTransformer.run(tree)
    assert ast.dump(tree, include_attributes=True) == \
        "Module(body=[FunctionDef(args=arguments(args=[arg(arg=str, annotation=None)], vararg=None, kwarg=None, defaults=[]), body=[], decorator_list=[])], type_ignores=[])\n"
    
    # arg: str = ...
    tree = ast.parse('func(str = ...)')
    tree = StringTypesTransformer.run(tree)

# Generated at 2022-06-12 04:08:58.464457
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:09:02.790582
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = '''
        a = str('a')
    '''
    module = ast.parse(code)
    result = StringTypesTransformer.transform(module)
    assert astor.to_source(result.tree) == "a = unicode('a')\n"

# Generated at 2022-06-12 04:09:04.052486
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:09:09.910803
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_utils import check_samples
    from .test_utils import get_ast_equal
    from .test_utils import get_ast_str_equals
    from .test_utils import get_ast_str_in
    from .test_utils import get_ast_match
    from .test_utils import change_ast_node
    from ..utils.tree import find
    from ..utils.misc import generate_random_id

    sample_code = 'import sys\n' \
                  'def foo():\n' \
                  '    s = str("abc")\n' \
                  '    print(s)\n'
    expected_code = 'import sys\n' \
                    'def foo():\n' \
                    '    s = unicode("abc")\n' \
                    '    print(s)\n'


# Generated at 2022-06-12 04:09:18.740927
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode, source_to_ast
    from ..utils.compare import compare_ast

    sample_code = source_to_unicode(
        """
        def foo(bar):
            print(bar == str)
        """
    )
    expected_code = source_to_unicode(
        """
        def foo(bar):
            print(bar == unicode)
        """
    )

    ast_tree = source_to_ast(sample_code)
    transformer = StringTypesTransformer()
    new_ast_tree = transformer.transform(ast_tree)

    assert compare_ast(expected_code, new_ast_tree) is True
    
test_StringTypesTransformer()

# Generated at 2022-06-12 04:11:39.722105
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:11:43.265744
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
 
    code = '''
name = str(1)
'''
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    new_code = compile(tree, '', 'exec')
    exec(new_code)

    assert name == '1'

# Generated at 2022-06-12 04:11:47.593111
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Single string
    code = """
            s = str()
            """
    # Transform
    res = StringTypesTransformer.transform(code)
    transformed_code = res.code
    # Assert
    assert "s = unicode()" in transformed_code
    # Restore
    restored = res.restore()
    assert "s = str()" in restored.code

# Generated at 2022-06-12 04:11:48.396703
# Unit test for constructor of class StringTypesTransformer