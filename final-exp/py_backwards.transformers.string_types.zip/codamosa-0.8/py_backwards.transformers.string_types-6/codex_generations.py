

# Generated at 2022-06-12 04:01:56.991591
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that `str` is replaced with `unicode`."""
    import astor

    source = textwrap.dedent('''
        def foo():
            print(str(2))
    ''')

    expected_source = textwrap.dedent('''
        def foo():
            print(unicode(2))
    ''')

    tree = astor.parse_file(source)

    transformed_tree, tree_changed, _ = StringTypesTransformer.transform(tree)
    generated_source = astor.to_source(transformed_tree)
    assert generated_source == expected_source
    assert tree_changed

# Generated at 2022-06-12 04:02:08.240821
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Trivial unit test for class StringTypesTransformer 

    """
    from .. import utils
    from ..utils.tree import ast_to_source
    from ..utils.typed_ast import ast3 as ast

    # Code to transform
    code = """
    x = str(1)
    """
    # transforming
    tree = utils.load_ast(code)
    transformer = StringTypesTransformer()
    result = transformer.transform(tree)
    tree = result.tree

    # Validating
    assert isinstance(tree, ast.Module)

    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert tree.body[0].value

# Generated at 2022-06-12 04:02:12.174528
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree1 = ast.parse("""
a = 'abc'
""")
    tree2 = ast.parse("""
a = unicode('abc')
""")
    class_ = StringTypesTransformer
    instance = class_()
    instance.transform(tree1)
    assert tree1 == tree2

# Generated at 2022-06-12 04:02:17.430983
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str(1)')).tree_changed is True
    assert StringTypesTransformer.transform(ast.parse('str(1)')).tree.body[0].value.args[0].n == 1
    assert isinstance(StringTypesTransformer.transform(ast.parse('str(1)')).tree.body[0].value, ast.Call)

# Generated at 2022-06-12 04:02:23.717184
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("if type(x) == str:\n  print 'success'")).tree \
      == ast.parse("if type(x) == unicode:\n  print 'success'")
    assert StringTypesTransformer.transform(ast.parse("if x is not None and type(x) == str")).tree \
      == ast.parse("if x is not None and type(x) == unicode")


# Generated at 2022-06-12 04:02:30.111630
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = '''
for x in y:
    print(str(x))
'''
    expected_s = '''
for x in y:
    print(unicode(x))
'''
    import python_minifier
    t = python_minifier.parse(s)
    assert ast.dump(t) == ast.dump(python_minifier.parse(expected_s))

# Generated at 2022-06-12 04:02:32.861557
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Get transformer
    transformer = StringTypesTransformer()
    # Simple test
    assert transformer.transform(ast.parse('str')) == (ast.parse('unicode'), True)


# Generated at 2022-06-12 04:02:37.137627
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import __version__
    from typed_ast import ast3
    from typed_ast import activate
    activate(__version__)
    tree = ast3.parse("'string'")
    tree = StringTypesTransformer.transform(tree)
    print(ast3.dump(tree.tree))


# Generated at 2022-06-12 04:02:42.099021
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str()')
    result = StringTypesTransformer.transform(tree)
    assert result.tree.body[0].value.func.id == 'unicode'


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-12 04:02:42.647863
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:02:47.292451
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..unittest_tools import assert_transformation_result


# Generated at 2022-06-12 04:02:47.828570
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:02:48.916416
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:02:56.350812
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_ast

    tree = source_to_ast.parse('''
        a = str(2)
    ''')

    assert StringTypesTransformer.transform(tree).tree_changed
    assert StringTypesTransformer.transform(tree).tree == \
        source_to_ast.parse('''
            a = unicode(2)
        ''')


__transformer__ = StringTypesTransformer

# Generated at 2022-06-12 04:03:00.976091
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that `str` is replaced with `unicode`. 

    """
    tree = ast.parse('str;')

    returned_tree, tree_changed, log = StringTypesTransformer.transform(tree)

    assert tree_changed
    assert returned_tree.body[0].value.id == 'unicode'
    assert len(log) == 0

# Generated at 2022-06-12 04:03:05.635320
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
my_string = "Hello"
print my_string
    """

    expected = """
my_string = unicode("Hello")
print my_string
    """

    transformer = StringTypesTransformer()
    actual = transformer.transform(code)
    assert actual.code == expected
    assert actual.tree_changed

# Generated at 2022-06-12 04:03:09.267260
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    source = 'str'
    expected_source = 'unicode'

    # Act
    result = StringTypesTransformer.transform(source)

    # Assert
    assert result.tree == expected_source
    assert result.tree_changed == True
    assert result.errors == []

# Generated at 2022-06-12 04:03:14.295418
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Specify the input file to be used for the test
    input_file = 'test1.py'

    # Specify the output file to be used for the test
    output_file = 'test1_out.py'

    # Specify the transformer to be used for the test
    transformer = StringTypesTransformer

    # Run the unit test
    BaseTransformer.test_transformer(input_file, output_file, transformer)

# Generated at 2022-06-12 04:03:24.750881
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    str_node = ast.Name('str', ast.Load())
    name_node = ast.Name('name', ast.Load())
    funcdef_node = ast.FunctionDef('foo', ast.arguments([], None, None, []), [ast.Return(str_node)], [], None)

    tree = ast.Module([ast.Expr(str_node)])
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert isinstance(result.tree.body[0].value, ast.Name)
    assert result.tree.body[0].value.id == 'unicode'

    tree = ast.Module([ast.Assign([name_node], str_node)])
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed

# Generated at 2022-06-12 04:03:26.149319
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:34.789841
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
        import sys as system
        import collections.abc as abc
    
        if sys.version_info >= (3, 0):
            abc.Sequence.register(str)
        else:
            abc.Sequence.register(unicode)
    ''')
    
    tree_changed = StringTypesTransformer.transform(tree)
    
    assert tree_changed.tree_changed is True
    assert tree_changed.tree.body[2].body[0].body[0].value.elts[0].value.value.elts[0].id == 'unicode'
    assert tree_changed.tree.body[2].body[0].body[0].value.elts[1].value.value.elts[0].id == 'unicode'

# Generated at 2022-06-12 04:03:36.184504
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("Testing StringTypesTransformer...")

# Generated at 2022-06-12 04:03:44.333493
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.example import PythonCodeExample

    code = PythonCodeExample.from_string("""
    class A(object):
        def __init__(self):
            name = str("a")
            a = str("a")
            self.name = name
            self.a = a
    """)

    result = StringTypesTransformer.transform(code.tree)

    assert code.string != result.tree.source
    assert code.string != result.new_tree.source
    assert result.tree.source != result.new_tree.source

# Generated at 2022-06-12 04:03:53.322829
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TransformationResult = namedtuple('TransformationResult', ['tree', 'changed', 'messages'])

    tree = ast.parse('"Hello World"')
    t = StringTypesTransformer()
    assert t.transform(tree) == TransformationResult(ast.parse('"Hello World"'), False, [])

    tree = ast.parse('"Hello World"')
    t = StringTypesTransformer()
    assert t.transform(tree) == TransformationResult(ast.parse('"Hello World"'), False, [])

    tree = ast.parse('str("Hello World")')
    t = StringTypesTransformer()
    assert t.transform(tree) == TransformationResult(ast.parse('unicode("Hello World")'), True, [])

# Generated at 2022-06-12 04:03:54.946285
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('''
a = str()
''')).tree_changed

# Generated at 2022-06-12 04:04:01.849215
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest

    from typed_ast import ast3 as ast

    from ..utils.source import source_to_tree
    from ..utils.dump import dump_tree

    class TestStringTypesTransformer(unittest.TestCase):
        def test_method_def(self):
            code = """
            def test_function(a: str):
                return a
            """
            expected = """
            def test_function(a: unicode):
                return a
            """
            tree = source_to_tree(code)
            tree2 = StringTypesTransformer.transform(tree)
            expected_tree = source_to_tree(expected)
            self.assertEqual(
                dump_tree(tree2.tree),
                dump_tree(expected_tree),
            )


# Generated at 2022-06-12 04:04:09.108536
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test that a class called 'str' is changed to unicode
    node = ast.Name(id='str', ctx=ast.Load())
    # Calling the transform method of the class
    result = StringTypesTransformer.transform(node)
    # Asserting the result of transformed node
    assert result.tree.id == 'unicode'
    # Asserting the value of the tree_changed
    assert result.tree_changed == True
    # Asserting the value of the error_messages
    assert result.error_messages == []


# Generated at 2022-06-12 04:04:13.977567
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from .. import transformer_from_str
    tfs = transformer_from_str(StringTypesTransformer)
    name_node = ast.Name("str", ast.Load)
    tree = ast.Module([ast.Expr(name_node)])
    new_ast = tfs(tree)
    assert isinstance(new_ast, ast.AST)

    # ast.dump(new_ast)
    assert ast.dump(new_ast) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"

# Generated at 2022-06-12 04:04:18.467089
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''
    str("test")
    ''')
    expected_tree = ast.parse('''
    unicode("test")
    ''')
    assert(ast.dump(StringTypesTransformer.transform(tree).new_tree) == ast.dump(expected_tree))

# Generated at 2022-06-12 04:04:27.984018
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    code_str = ("str_str = 'str'\n" +
                "str_func = str\n" +
                "str_type = type(str)\n" +
                "str_type2 = type('str')\n" +
                "str_type3 = type('str'())\n")

    # transform code_str from source code to AST
    tree = ast.parse(code_str)

    # run the transformer
    tree = StringTypesTransformer.run_pipeline(tree)

    # obtain modified source code
    code_out = str(astor.to_source(tree))

    print(code_out)
    print(code_str == code_out)

# Generated at 2022-06-12 04:04:43.389589
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass
    # assert str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str(str

# Generated at 2022-06-12 04:04:46.520562
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str')
    result = StringTypesTransformer.transform(tree)
    assert result.ast != tree
    tree = result.ast

    assert isinstance(tree.body[0].value, ast.Name)
    assert tree.body[0].value.id == 'unicode'


# Generated at 2022-06-12 04:04:56.524761
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast


# Generated at 2022-06-12 04:05:05.901463
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..python_versions import get_python_version
    from .python3 import PrintTransformer, FormatStringTransformer
    from ..utils.tree import check_equal

    tree = ast.parse('print str(a)')
    old_tree = copy.deepcopy(tree)
    check_equal(tree, old_tree)

    tree = PrintTransformer.transform(tree)
    tree = FormatStringTransformer.transform(tree)

    tree = FormatStringTransformer.transform(tree)
    tree = StringTypesTransformer.transform(tree)

    assert check_equal(ast.parse('''
print unicode(a)
'''), 
                       tree.tree)

    print('test_StringTypesTransformer ok.')

# Generated at 2022-06-12 04:05:07.618485
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str()'))[0] == ast.parse('unicode()')

# Generated at 2022-06-12 04:05:09.119791
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:05:14.335379
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor, random
    from .v2_7_to_3_0 import V2_7To3_0
    from ..utils.randomize import random_ast

    random.seed(0)
    for _ in range(1000):
        tree = random_ast(random.choice([2, 7]))
        tr = StringTypesTransformer.transform(tree)

        V2_7To3_0.transform(tr.tree)

# Generated at 2022-06-12 04:05:19.178859
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from .base import BaseTransformerTestCase

    class TestCase(BaseTransformerTestCase):
        target_version = (2, 7)
        transformer = StringTypesTransformer
        input_source = """
            a = str('b')
        """
        expected_source = """
            a = unicode('b')
        """
    
    test = TestCase()
    test.run_test()

# Generated at 2022-06-12 04:05:24.077207
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Input
    s = """
        def foo(x, y):
            return str(x)
        """
    tree = ast.parse(s)
    # Call the function
    StringTypesTransformer.transform(tree)
    # Assert the result
    assert tree_to_str(tree) == "def foo(x, y):\n    return unicode(x)\n"


# Generated at 2022-06-12 04:05:29.475321
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast27

    print(ast27.parse('a = str(1)'))
    print(StringTypesTransformer.transform(ast27.parse('a = str(1)')))
    print(ast27.parse('a = str()'))
    print(StringTypesTransformer.transform(ast27.parse('a = str()')))

# Generated at 2022-06-12 04:05:43.999316
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    sample = ast.parse('''
    x = "a"
    y = str("b")
    ''')
    c = StringTypesTransformer.transform(sample)
    assert c.tree_changed == True

# Generated at 2022-06-12 04:05:49.177826
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.unparse import unparse
    from ..utils.source import source
 
    class A(object): pass
    a = A()
    a.x = 42

    tree = ast.parse('def f():\n    x = str(a.x)')
    r = StringTypesTransformer.transform(tree)

    print(unparse(r.tree))
    assert r.tree_changed == True
    assert r.messages == []

# Generated at 2022-06-12 04:05:54.871664
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import get_tst_program, assert_equal
    from ..utils.tree import print_tree
    
    p = get_tst_program(StringTypesTransformer)
    print_tree(p)
    assert_equal(p.body[0].test.left.id, 'unicode')
    print('test_StringTypesTransformer ok')

# Generated at 2022-06-12 04:05:58.004638
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_case = "str()"
    expected_result = "unicode()"
    actual_result = StringTypesTransformer.transform(ast.parse(test_case)).tree
    # print(ast.dump(actual_result))

    assert ast.dump(actual_result) == expected_result

# Generated at 2022-06-12 04:06:02.612689
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    code = """x = str(1)"""
    tree = astor.parse_file(code)
    result = StringTypesTransformer.transform(tree)
    print(astor.to_source(result.tree))

# Unit test to run
if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:06:03.568283
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    StringTypesTransformer()


# Generated at 2022-06-12 04:06:05.854864
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('"string"')
    tr = StringTypesTransformer.transform(tree)
    assert tr.tree_changed and tr.nodes_changed == 0

# Generated at 2022-06-12 04:06:13.450946
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Initializing the AST
    node = ast.parse("str('str')")
    StringTypesTransformer.transform(node)
    assert(node._fields == ('body',))
    assert(type(node.body[0]) == ast.Expr)
    assert(node.body[0].value._fields == ('value', 'func', 'args', 'keywords', 'starargs', 'kwargs'))
    assert(type(node.body[0].value.func) == ast.Name)
    assert(type(node.body[0].value.args[0]) == ast.Str)

# Generated at 2022-06-12 04:06:18.255818
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('"Hello world!"')) == TransformationResult(ast.parse('u"Hello world!"'),
                                                                                                  True, [])
    assert StringTypesTransformer.transform(ast.parse('str("Hello world!")')) == TransformationResult(ast.parse('unicode("Hello world!")'),
                                                                                                        True, [])

# Generated at 2022-06-12 04:06:27.184863
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import dump_tree
    from ..utils.snippet import extract_function

    TREE = """
    def f(a):
        return str(a)
    """
    TREE_EXPECTED = """
    def f(a):
        return unicode(a)
    """

    tree = ast.parse(TREE)
    refactored_tree, refactored_code, success = StringTypesTransformer.refactor(TREE)
    if not success:
        print("fail")

    assert dump_tree(refactored_tree) == dump_tree(ast.parse(TREE_EXPECTED))



# Generated at 2022-06-12 04:06:56.097165
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("x = str()")
    tree_changed, _, _ = StringTypesTransformer.transform(tree)

    assert tree_changed
    tree_str = ast.dump(tree)

    assert ast.parse("x = unicode()") == ast.parse(tree_str)


# Generated at 2022-06-12 04:07:00.623099
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import from_str

    source = """
str = None
str = 'abc'
str('abc')
"""
    tree = from_str(source)
    t = StringTypesTransformer()
    new_tree, changed = t.transform(tree)
    assert changed
    assert source != new_tree


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 04:07:02.517641
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from .. import transform
    from ..utils.tree import find

# Generated at 2022-06-12 04:07:03.084356
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:07:08.708423
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str()')
    transformed_tree, tree_changed, _ = StringTypesTransformer.transform(tree)
    assert tree_changed
    assert ast.dump(transformed_tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[]))])"

# Generated at 2022-06-12 04:07:12.792619
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.parse("""x = 'test' + str(True)""", mode='single')
    transformed = StringTypesTransformer.transform(node)
    assert ast.dump(transformed.tree) == ast.dump(ast.parse("""x = 'test' + unicode(True)""", mode='single'))

# Generated at 2022-06-12 04:07:16.018554
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = \
    """
    def func(a: str, b: int = 0) -> str:
        return a
    """
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)

# Generated at 2022-06-12 04:07:18.460544
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .class_transformer import ClassTransformer
    from .mock import MockPipeline
    from ..utils.trees import print_tree


# Generated at 2022-06-12 04:07:22.794231
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # code to be transformed
    src = "str"

    # expected result after transformation
    dest = "unicode"

    # transform the code
    res, _ = StringTypesTransformer.transform(src)

    # make sure the transformation worked
    assert dest == res


# Generated at 2022-06-12 04:07:25.702717
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("def foo(x):\n    return str(x)")
    res = StringTypesTransformer.transform(tree)
    assert "unicode" in res.tree._fields

# Generated at 2022-06-12 04:08:33.270397
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    trans1 = ast.parse('''str(b'a')''')
    trans2 = ast.parse('''str(b'a')''')

    t1 = StringTypesTransformer.transform(trans1)
    t2 = StringTypesTransformer.transform(trans1)

    assert t1.tree_changed
    assert t2.tree_changed

    assert trans1.body[0].value.func.id == 'unicode'
    assert trans2.body[0].value.func.id == 'unicode'

# why this is needed
# https://stackoverflow.com/questions/15233340/getting-attributes-of-a-class-that-is-passed-as-a-parameter
if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:08:36.620799
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open('tests/resources/sample_2_7.py') as f:
        text = f.read()
    
    compiled = ast.parse(text)
    transformer = StringTypesTransformer()
    result = transformer.transform(compiled)

    for node in find(result.node, ast.Name):
        if node.id == 'str':
            assert False

    assert True

# Generated at 2022-06-12 04:08:41.542532
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    source='''
    a = str(b)
    '''
    fixed_source='''
    a = unicode(b)
    '''
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.transform(tree).tree
    assert(astor.to_source(new_tree) == fixed_source)

# Generated at 2022-06-12 04:08:49.669610
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input1 = """
    class foo:
        def __init__(self, name):
            return name
    """
    tree = ast.parse(input1)
    new_tree = StringTypesTransformer.transform(tree).new_tree
    assert ast.dump(new_tree) == ast.dump(ast.parse(input1))

    input2 = """
    def foo():
        return 'hi'
    """
    tree = ast.parse(input2)
    new_tree = StringTypesTransformer.transform(tree).new_tree
    assert ast.dump(new_tree) == ast.dump(ast.parse(input2))

    input3 = """
    def foo(variable):
        return variable.id
    """
    tree = ast.parse(input3)

# Generated at 2022-06-12 04:08:53.811600
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(1)')
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert ast.dump(result.tree) == ast.dump(ast.parse('a = unicode(1)'))

# Generated at 2022-06-12 04:09:01.361421
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer."""
    from ..unit import prepare_test, run_test
    import astunparse

    code = '''
        # Python 2.7 code
        x = str(12)
    '''

    tree = ast.parse(prepare_test(code))
    new_tree = StringTypesTransformer.run_on_file(tree)
    expected_code = '''
        # Python 2.7 code
        x = unicode(12)
    '''

    assert astunparse.unparse(new_tree) == prepare_test(expected_code)


# Generated at 2022-06-12 04:09:02.357983
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:09:06.900377
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    from ..utils.tree import print_tree, find
    tree = ast.parse('print(str, str())')
    transformed = StringTypesTransformer.transform(tree)
    assert (transformed.changed == True)
    assert (print_tree(transformed.tree).strip() == 'print(unicode, unicode())')
    assert (len(transformed.warnings) == 0)

# Generated at 2022-06-12 04:09:12.648183
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Basic smoke test for the ``StringTypesTransformer``.
    
    """
    tree = ast.parse('a = str()')
    tf = StringTypesTransformer()
    tf.transform(tree)

    res = ast.dump(tree)
    assert res == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-12 04:09:19.170854
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    #Given
    class test:
        def test(self):
            return str("test")

    #When
    tree = ast.parse("class test:\n    def test(self):\n           return str(\"test\")")
    transformed_tree = StringTypesTransformer.transform(tree)

    #Then
    # tree is not changed
    assert(transformed_tree.tree_changed == True)
    # tree not changed
    assert(transformed_tree.tree.body[0].body[0].value.func.id == "unicode")

# Generated at 2022-06-12 04:11:34.269632
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from typed_ast.simple_ast import parse, dump # type: ignore


# Generated at 2022-06-12 04:11:43.134658
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Source code to test on
    code = """
    x = str(2)
    """

    # Instantiate transformer class
    test_obj = StringTypesTransformer()

    # Parse code
    tree = ast.parse(code)

    # Transform tree
    transformed_tree, tree_changed, codemod_warnings = test_obj.transform(tree)

    # Assert tree has changed
    assert tree_changed

    # Assert no codemod warnings
    assert codemod_warnings == []

    # Assert node with name `str` has changed
    assert find(transformed_tree, ast.Name, id="str") == []
    assert find(transformed_tree, ast.Name, id="unicode") != []

# Generated at 2022-06-12 04:11:43.784907
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:11:51.895044
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.ast_inspector import get_ast_raw

    code = '''
    def print_str(str_):
        print(str_)
        '''
    expected_code = '''
    def print_str(str_):
        print(str_)
        '''
    actual_code = str(StringTypesTransformer.transform(get_ast_raw(code))[0])
    print('#' * 20)
    print(actual_code)
    assert actual_code == expected_code

    code = '''
    def print_str(str_):
        print(str_)

    def print_int(int_):
        print(int_)
        '''