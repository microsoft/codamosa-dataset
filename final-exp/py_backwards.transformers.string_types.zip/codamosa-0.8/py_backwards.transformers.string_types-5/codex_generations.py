

# Generated at 2022-06-12 04:01:54.133849
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..pygram import python_grammar

    code = """
        from __future__ import unicode_literals
        a = str(b + c)
    """
    tree = compile(code, '<string>', 'exec', _ast.PyCF_ONLY_AST,
                   True)  # type: ast.AST
    result = tree.body[-1]
    assert isinstance(result, ast.Assign)
    assert isinstance(result.value, ast.Call)
    assert isinstance(result.value.func, ast.Name)
    assert result.value.func.id == 'unicode'
    assert isinstance(result.value.args[0], ast.BinOp)

# Generated at 2022-06-12 04:01:54.604516
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:01:55.101312
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-12 04:02:02.338790
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class SomeClass:
        def __init__(self, x: str):
            self.x = x

    tree = ast.parse(textwrap.dedent(inspect.getsource(SomeClass)))
    tree = ast.fix_missing_locations(tree)
    assert 'str' in str(tree)

    result = StringTypesTransformer.transform(tree)
    assert 'str' not in str(result.tree)
    assert result.tree_changed


if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:02:03.863938
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert isinstance(t, BaseTransformer)

# Generated at 2022-06-12 04:02:10.260086
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_astunparse
    from .sample_asts import sample_ast

    source = "str = unicode('hello')"
    expected = "unicode = unicode('hello')"

    tree = ast.parse(source)
    new_tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed == True
    assert messages == []
    assert typed_astunparse.unparse(new_tree) == expected

# Generated at 2022-06-12 04:02:14.288271
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import assert_transformation
    from .. import utils
    from .base import TargetVersion
    import ast

    assert_transformation(
        utils.build_ast("""
            s = str(1)
        """),
        """
            s = unicode(1)
        """,
        target_versions=[TargetVersion.PY27],
    )

# Generated at 2022-06-12 04:02:23.319614
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.python_source import to_python_source
    from ..transforms import transform

    source = """
        def test(input):
            if isinstance(input, str):
                input = input.decode('utf8')
            return input
    """
    expected_source = """
        def test(input):
            if isinstance(input, unicode):
                input = input.decode('utf8')
            return input
    """
    module_ast = ast.parse(source)
    transformed_module_ast, _ = transform(module_ast, [StringTypesTransformer])
    assert to_python_source(module_ast) == expected_source

# Generated at 2022-06-12 04:02:26.785797
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Checks that the constructor of class StringTypesTransformer does not raise an error."""
    assert isinstance(StringTypesTransformer(), StringTypesTransformer)


# Generated at 2022-06-12 04:02:33.017286
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.sample_programs import print_string
    from ..utils.symbol_table import SymbolTable

    tree = ast.parse(print_string.PYTHON_3)
    sym_table = SymbolTable()

    new_tree, _, _ = StringTypesTransformer.transform(
        tree,
        sym_table=sym_table
    )

    assert ast.dump(new_tree) == ast.dump(ast.parse(print_string.PYTHON_2))

# Generated at 2022-06-12 04:02:38.694424
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("Running unit test for StringTypesTransformer")
    t = ast.parse("x = str(y) + 'a'", mode='eval')
    t1 = StringTypesTransformer().visit(t)
    t2 = ast.parse("x = unicode(y) + 'a'", mode='eval')
    assert ast.dump(t1, include_attributes=True) == ast.dump(t2, include_attributes=True)



# Generated at 2022-06-12 04:02:43.010596
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
    str
    """
    dst = """
    unicode
    """
    result = StringTypesTransformer.transform(ast.parse(src))
    assert result.changed
    assert result.tree is not None
    assert ast.dump(result.tree) == ast.dump(ast.parse(dst))

# Generated at 2022-06-12 04:02:47.442431
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import compile_to_ast

    source = 'x = "test"'
    expected = 'x = unicode("test")'
    tree = compile_to_ast(source, 'exec')
    transformer = StringTypesTransformer()
    tree_changed, messages, new_tree = transformer.transform(tree)
    assert tree_changed
    assert messages == []
    assert expected == ast.dump(new_tree)

# Generated at 2022-06-12 04:02:51.398396
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tester = StringTypesTransformer
    assert tester.priority == 0.1

    assert tester.target == (2, 7)
    assert tester.transform(ast.parse("str")).changed
    assert not tester.transform(ast.parse("int")).changed

# Generated at 2022-06-12 04:02:53.513988
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass # TODO write this test

# Generated at 2022-06-12 04:03:00.025433
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''f = str(1)''')
    t = StringTypesTransformer()
    t.transform(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='f', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-12 04:03:00.974290
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass # TODO: write unit tests


# Generated at 2022-06-12 04:03:05.635594
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.parse("str('hello')")
    y = ast.parse("unicode('hello')")
    result = StringTypesTransformer.transform(x)
    assert result.tree != x
    assert ast.dump(result.tree) == ast.dump(y)
    assert result.tree_changed == True

# Generated at 2022-06-12 04:03:11.327005
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.example_models import python2_example_2
    translator = StringTypesTransformer()
    tree = ast.parse(python2_example_2)
    transform_result = translator.transform(tree)
    new_source = astor.to_source(transform_result.tree).strip()
    assert new_source == "def does_not_work_in_py3():\n  _me = 'unicode'\n  print(_me)\n"

# Generated at 2022-06-12 04:03:12.217810
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    obj = StringTypesTransformer()

# Generated at 2022-06-12 04:03:16.519826
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import os.path
    import ast
    import typing


# Generated at 2022-06-12 04:03:27.045352
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import typed_ast.ast3 as ast3
    source_1 = '''
    s = str()
    '''
    expected_1 = '''
    s = unicode()
    '''
    source_2 = '''
    s = str
    '''
    expected_2 = '''
    s = unicode
    '''
    source_3 = '''
    s = str("hello")
    '''
    expected_3 = '''
    s = unicode("hello")
    '''
    source_4 = '''
    s = str("hello", a=True)
    '''
    expected_4 = '''
    s = unicode("hello", a=True)
    '''

# Generated at 2022-06-12 04:03:32.202673
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str(arg)")
    result_tree = ast.parse("unicode(arg)")
    assert StringTypesTransformer.transform(tree).tree == result_tree
    tree = ast.parse('''
    from __future__ import unicode_literals
    str(arg)
    ''')
    result_tree = ast.parse('''
    from __future__ import unicode_literals
    unicode(arg)
    ''')
    assert StringTypesTransformer.transform(tree).tree == result_tree

# Generated at 2022-06-12 04:03:42.459706
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ..utils.source import source_to_unicode

    source = source_to_unicode("""x = str()""")
    root_node = ast3.parse(source)
    res = StringTypesTransformer.transform(root_node)
    assert res.tree_changed
    assert source_to_unicode(res.tree) == source_to_unicode("x = unicode()")

    # Check that the transformer has no effect at all if the reserved word
    # `str` is not used
    source = source_to_unicode("""x = unicode()""")
    root_node = ast3.parse(source)
    res = StringTypesTransformer.transform(root_node)
    assert res.tree_changed == False

# Generated at 2022-06-12 04:03:49.149489
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer(ast.parse("a = str('Hello, World!')"))
    t.transform()
    assert ast.dump(t.tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='Hello, World!')], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-12 04:03:50.210271
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:50.797641
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:52.031945
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:54.277154
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(
        ast.parse('str()')
    ).tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-12 04:03:57.234002
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    check_transformer(
        StringTypesTransformer, '''
        s = str()
        t = type(s)
        ''', '''
        s = unicode()
        t = type(s)
        '''
    )

# Generated at 2022-06-12 04:04:12.144511
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print('Test StringTypesTransformer')
    node = ast.parse('print(str())')
    new_node = StringTypesTransformer.transform(node)
    print(ast.dump(new_node.tree))
    assert ast.dump(new_node.tree) == "Module(body=[Print(dest=None, values=[Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None)], nl=True)])"
    node = ast.parse('print((str(),))')
    new_node = StringTypesTransformer.transform(node)
    print(ast.dump(new_node.tree))

# Generated at 2022-06-12 04:04:19.747379
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import load_tests, load, dump
    from ..utils.python2to3 import convert_code
    from ..types import TransformationResult

    for test in load_tests(__file__):
        tree = load(test)
        expected_result, trasformation_result = tree[1], tree[2]

        # Test against expected result
        assert(convert_code(dump(expected_result)) ==
               convert_code(dump(StringTypesTransformer.transform(tree[0]).tree)))

        # Test against transformation result
        assert(dump(trasformation_result) ==
               dump(StringTypesTransformer.transform(tree[0]).tree))

# Generated at 2022-06-12 04:04:30.330029
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse("""
    a = str(1)
    """)
    assert StringTypesTransformer.transform(tree).tree._fields == (
        'body', 'type_ignores', 'str_type', 'filename', 'scope', 'type_comment_prefix'
    )
    assert StringTypesTransformer.transform(tree).tree.body[0]._fields == (
        'targets', 'value', 'type_comment'
    )
    assert StringTypesTransformer.transform(tree).tree.body[0].value._fields == (
        'func', 'args', 'keywords', 'starargs', 'kwargs', 'type_comment'
    )

# Generated at 2022-06-12 04:04:36.693770
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..armi import Armi
    from ..utils.tree import ast_to_str

    input_str = """if isinstance(str, unicode):\n    pass"""
    for version in range(*StringTypesTransformer.target):
        print("\nInput: {}".format(input_str))
        print("Output: {}".format(ast_to_str(Armi(
            input_str, StringTypesTransformer).result()).strip()))


# Generated at 2022-06-12 04:04:40.117619
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import put_together_from_source

    # Define python source code as a string

# Generated at 2022-06-12 04:04:42.657374
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer
    """
    ast_tree = ast.parse("some_string = 'hello'")
    assert isinstance(ast_tree, ast.Module)
    assert isinstance(ast_tree.body[0], ast.Assign)

    StringTypesTransformer.transform(ast_tree)
    assert ast_tree.body[0].value.s == 'hello'

# Generated at 2022-06-12 04:04:45.350101
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # given
    tree = ast.parse('''
        a = str()
    ''')

    # when
    result = StringTypesTransformer.transform(tree)

    # then
    tree.body[0].value.func.id == 'unicode'

# Generated at 2022-06-12 04:04:55.387274
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): 
    somecode = '''
    def test_function():
        thing = str('Hello')
        thing = int('123')
        str2 = 'Hello'
        thing = str(str2)
        thing2 = unicode(str2)
        thing = str.upper()
    '''
    test_code = ast.parse(somecode)
    expected_code = '''
    def test_function():
        thing = unicode('Hello')
        thing = int('123')
        str2 = 'Hello'
        thing = unicode(str2)
        thing2 = unicode(str2)
        thing = str.upper()
    '''
    expected_tree = ast.parse(expected_code) 
    expected, changed, errors = StringTypesTransformer.transform(test_code)
    assert(changed == 1)


# Generated at 2022-06-12 04:05:01.634575
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    tree = ast3.parse('str("hello")').body[0]
    transformer = StringTypesTransformer(tree)
    tree, changed, messages = transformer.transform()
    assert not changed
    tree = ast3.parse('str("hello")', mode='exec').body[0]
    transformer = StringTypesTransformer(tree)
    tree, changed, messages = transformer.transform()
    assert tree.value.func.id == 'unicode'
    assert changed
    assert not messages

# Generated at 2022-06-12 04:05:05.663149
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    my_str = ast.Name(id='str', ctx=ast.Load())
    t = StringTypesTransformer.transform(my_str)
    assert t.tree.id == 'unicode'
    assert t.tree_changed == True

# Generated at 2022-06-12 04:05:22.981719
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree_input = ast.parse("""
a = 'test'
s = str
s2 = str(a)
n = int(s2)
""")
    tree_expected = ast.parse("""
a = 'test'
s = unicode
s2 = unicode(a)
n = int(s2)
""")
    tree_actual = StringTypesTransformer.apply(tree_input)
    assert ast.dump(tree_actual) == ast.dump(tree_expected)

# Generated at 2022-06-12 04:05:27.208499
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """ 
    Compare output to input. Output should be identical to input 
    """
    a = {
        'a': 'b'
    }
    assert StringTypesTransformer(a).transform() == TransformationResult(
        {'a': 'b'}, False, [])



# Generated at 2022-06-12 04:05:33.670470
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer"""
    module_ast = ast.parse("a = str('Hello world')")
    StringTypesTransformer.transform(module_ast)
    assert ast.dump(module_ast) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), \
args=[Str(s='Hello world')], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-12 04:05:37.870290
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils.tree import to_tree

    code = """
        a = str('text')
        test_str = str()
    """

    tree = to_tree(code, 2, 7)
    StringTypesTransformer.transform(tree)
    assert code == astor.to_source(tree)


# Generated at 2022-06-12 04:05:46.024861
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    statements = [
        'class A: pass',
        'a = str("abc")',
        'b = str.join("1", "2")',
        'c = int("1")',
        'd = str()',
    ]
    a, b, c, d, e = statements
    ref = ast.parse(c + d + e).body
    tree = ast.parse(a + b + c + d + e)
    transformed_tree, changed = StringTypesTransformer.transform(tree)
    assert changed and not StringTypesTransformer.transform(tree)[1]
    assert ref == transformed_tree.body[-3:]


# Generated at 2022-06-12 04:05:48.142161
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert 'str' in ast.parse('str').body[0].value.id
    assert 'unicode' in StringTypesTransformer.transform(ast.parse('str')).tree.body[0].value.id

# Generated at 2022-06-12 04:05:58.237409
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    def test(code, expected_code):
        tree = ast.parse(code)
        tree = StringTypesTransformer.transform(tree)
        code = ast_to_str(tree)
        if code != expected_code:
            raise Exception("Produced %s, expected %s" % (code, expected_code))

    test("class Foo: pass",
         "class Foo: pass")


# Generated at 2022-06-12 04:06:04.893636
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    def check(code, expected):
        tree = ast.parse(code)
        print(code)
        print(expected)
        StringTypesTransformer.transform(tree)
        # print(pretty_printer.fmt(tree))
        assert_equals(code, expected)
        
    check(
        '''
        str
        ''',
        '''
        unicode
        '''
    )
    # print(type(pretty_printer.fmt(tree)))
    
    
    


# test_StringTypesTransformer()

# Generated at 2022-06-12 04:06:14.408428
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    """
    def foo(self, name: str, program) -> str:
        return name
    """
    tree = ast3.parse('def foo(self, name: str, program) -> str: \n    return name')
    result = StringTypesTransformer.transform(tree)
    assert result.transformed == True

# Generated at 2022-06-12 04:06:25.653219
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test string_types_transformer
    import os
    import sys

    file_dir = os.path.dirname(__file__)
    sys.path.append(os.path.join(file_dir, "../.."))
    from src.transformers.string_types_transformer import StringTypesTransformer
    input_file = "test/data/test_string_types_transformer.py"
    output_file = "test/outputs/test_string_types_transformer.py"
    tree_in = ast.parse(open(input_file).read())
    tree_out = ast.parse(open(output_file).read())
    t = StringTypesTransformer()
    new_tree, _ = t.transform(tree_in)

# Generated at 2022-06-12 04:06:55.053164
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..tests.utils import generate_transformed_ast
    from ..tests.utils import round_trip_dump_and_parse

    code = '''
    x = str()
    '''
    tree = ast.parse(code)
    expected = '''
    x = unicode()
    '''
    assert expected == generate_transformed_ast(tree)
    round_trip_dump_and_parse(tree)

# Generated at 2022-06-12 04:06:58.659732
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import as_python
    from ..main import transform

    code = as_python(
        """
        a = str(1)
        b = 1
        """
    )
    tree = transform(code)
    assert as_python(tree) == as_python(code).replace('str', 'unicode')

# Generated at 2022-06-12 04:07:08.375501
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
     class x:
        def y(self, z: str):
            pass

# Generated at 2022-06-12 04:07:18.136316
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:07:22.023863
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str()")
    assert not  StringTypesTransformer.transform(tree).tree_changed 

    tree = ast.parse("y = str(x)")
    assert StringTypesTransformer.transform(tree).tree_changed

# Generated at 2022-06-12 04:07:23.844449
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    # We first construct a sample Python source code program as a string

# Generated at 2022-06-12 04:07:27.287618
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """a = str("hello")"""
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    new_code = compile(tree, 'file.py', 'exec')
    exec(new_code, globals())
    assert a == 'hello'

# Generated at 2022-06-12 04:07:29.432273
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    s = "a = str(b)"
    expected = "a = unicode(b)"
    tree = astor.parse_strea

# Generated at 2022-06-12 04:07:38.774702
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    #testcase 1
    tree = ast.parse("x = 1")
    tree_changed, messages = StringTypesTransformer.transform(tree)
    assert(hasattr(tree, 'body') == True)
    assert(hasattr(tree.body[0], 'value') == True)
    assert(hasattr(tree.body[0], 'targets') == True)
    assert(hasattr(tree.body[0].targets[0], 'id') == True)
    assert(hasattr(tree.body[0].value, 'n') == True)
    print('Passing testcase 1')

    #testcase 2
    tree = ast.parse("x = 'abc'")
    tree_changed, messages = StringTypesTransformer.transform(tree)
    assert(hasattr(tree, 'body') == True)
   

# Generated at 2022-06-12 04:07:40.655820
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test that `str` is transformed to `unicode` in Python 2.

    """

# Generated at 2022-06-12 04:08:39.893104
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("Testing StringTypesTransformer")
    tree = ast.parse("str", mode="exec")
    new_tree, tree_changed, _ = StringTypesTransformer.transform(tree)
    assert tree_changed == True
    assert astunparse.unparse(new_tree)[0] == "unicode"

# Generated at 2022-06-12 04:08:40.883913
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:08:41.596198
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:08:42.182782
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:08:49.972569
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert type(StringTypesTransformer.transform(ast.parse('''2''')).tree) is ast.Expression
    assert type(StringTypesTransformer.transform(ast.parse('''x''')).tree) is ast.Expression
    assert type(StringTypesTransformer.transform(ast.parse('''str(x)''')).tree) is ast.Expression
    assert type(StringTypesTransformer.transform(ast.parse('''help(str)''')).tree) is ast.Expression
    assert type(StringTypesTransformer.transform(ast.parse('''str()''')).tree) is ast.Expression
    assert type(StringTypesTransformer.transform(ast.parse('''str.__doc__''')).tree) is ast.Expression

# Generated at 2022-06-12 04:08:55.963405
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str")
    new_tree = StringTypesTransformer.transform(tree)
    assert "unicode" in ast.dump(new_tree[0])
    assert new_tree[1]

    tree = ast.parse("foo")
    new_tree = StringTypesTransformer.transform(tree)
    assert "foo" in ast.dump(new_tree[0])
    assert not new_tree[1]

# Generated at 2022-06-12 04:09:02.413420
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """x = str(1)"""
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    new_tree = transformer.visit(tree)
    gen = ast.get_source(new_tree)
    assert next(gen) == "x = "
    assert next(gen) == "unicode"
    assert next(gen) == "("
    assert next(gen) == "1"
    assert next(gen) == ")\n"
    assert list(gen) == []

# Generated at 2022-06-12 04:09:04.982505
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = str(a)')
    assert StringTypesTransformer.transform(tree) == (ast.parse('a = unicode(a)'), True, [])

# Generated at 2022-06-12 04:09:09.904543
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(0) == (0, False)
    assert StringTypesTransformer.transform([]) == ([], False)
    assert StringTypesTransformer.transform(None) == (None, False)
    assert StringTypesTransformer.transform(True) == (True, False)
    assert StringTypesTransformer.transform(False) == (False, False)

# Generated at 2022-06-12 04:09:15.143376
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
        s = str()
        '''
    tree = ast.parse(code)
    tr = StringTypesTransformer.transform(tree)

    assert 'unicode()' in astor.to_source(tr.tree)
    assert 'str()' not in astor.to_source(tr.tree)
    assert tr.tree_changed == True

# Generated at 2022-06-12 04:11:25.011587
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer.
    """
    # pylint: disable=R0201
    StringTypesTransformer()

# Generated at 2022-06-12 04:11:28.333202
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform({"name": "str"}) == {"name": "unicode"}
    assert StringTypesTransformer.transform({"name": "stR"}) == {"name": "stR"}

# Generated at 2022-06-12 04:11:29.099280
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:11:37.313002
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree_to_transform = ast.parse("""
        s = str(1)
        int(s)
        """)
    expected_transformed_tree = ast.parse("""
        s = unicode(1)
        int(s)
        """)
    expected_imports = []
    expected_warnings = []

    transformer = StringTypesTransformer()

    actual_transformed_tree, actual_imports, actual_warnings = transformer.transform(tree_to_transform)

    assert ast.dump(actual_transformed_tree) == ast.dump(expected_transformed_tree)
    assert actual_imports == expected_imports
    assert actual_warnings == expected_warnings

# Generated at 2022-06-12 04:11:44.243088
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open("tests/transformation/examples/StringTypesTransformer.py") as f:
        tree = ast.parse(f.read())
    tree_1 = tree.body[1]

    # Test: Sure the test script is properly written
    assert find(tree_1, ast.Name).pop().id == 'str'

    # Test: Run transformation on the test script
    res = StringTypesTransformer.transform(tree)

    # Test: string names are changed to unicode
    assert find(res.transformed, ast.Name).pop().id == 'unicode'

# Generated at 2022-06-12 04:11:48.100037
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = """
        x = str(5)
    """
    tree = ast.parse(s)
    tree = StringTypesTransformer.transform(tree).tree
    code = compile(tree, '', 'exec')
    globals = {}
    exec(code, globals)
    assert isinstance(globals['x'], unicode)