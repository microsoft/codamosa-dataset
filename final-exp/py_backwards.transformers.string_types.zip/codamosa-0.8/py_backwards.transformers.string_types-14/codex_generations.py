

# Generated at 2022-06-12 04:01:49.838337
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import python_modernize
    import ast


# Generated at 2022-06-12 04:01:57.525106
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class TestTransformer(StringTypesTransformer):
        """Test class of StringTypesTransformer

        """
        pass

    tree_1 = ast.parse(
        "s = 'abc'\n"+
        "t = 'abc'\n"+
        "s = 'abc'"
    )

    result_1 = TestTransformer.transform(tree_1)
    tree_2 = ast.parse(
        "s = 'abc'\n"+
        "t = 'abc'"
    )

    result_2 = TestTransformer.transform(tree_2)
    tree_3 = ast.parse(
        "s = 'abc'"
    )

    result_3 = TestTransformer.transform(tree_3)

# Generated at 2022-06-12 04:02:06.536730
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # init class
    transformer = StringTypesTransformer()

    # init test values
    input_value = ast.parse("json.dumps(xml.dom.minidom.parseString(string).toxml())") # type: ignore
    expected_value = ast.parse("json.dumps(xml.dom.minidom.parseString(unicode).toxml())") # type: ignore
    # do transformation
    output_value = transformer.visit(input_value) # type: ignore
    # make sure the output value equals the expected value
    assert ast.dump(output_value) == ast.dump(expected_value)

# Generated at 2022-06-12 04:02:11.619632
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_code = '''
    def foo():
        return str(1)'''

    expected_ast = b'''
    def foo():
        return unicode(1)'''

    tree = ast.parse(input_code)
    new_tree = StringTypesTransformer().transform(tree)
    new_code = astunparse.unparse(new_tree.tree)

    assert new_code == expected_ast

# Generated at 2022-06-12 04:02:16.783146
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.codegen import to_source

    source = """
a = str
b = 'b'
c = "c"
"""
    tree = ast.parse(source)
    StringTypesTransformer.run_pipeline(tree)
    expected = """
a = unicode
b = 'b'
c = "c"
"""
    assert to_source(tree) == expected

# Generated at 2022-06-12 04:02:23.755807
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    tree = ast.parse('bla = str(bla)')
    string_types_transformer.visit(tree)
    assert ast.dump(tree, annotate_fields=False) == "Module(body=[Assign(targets=[Name(id='bla', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='bla', ctx=Load())], keywords=[]))])"

# Generated at 2022-06-12 04:02:27.785502
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()
    assert t.target == (2, 7)
    assert t.__class__.__name__ == "StringTypesTransformer"



# Generated at 2022-06-12 04:02:29.525197
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer(): # folder name(file name).class name .function name
    stt = StringTypesTransformer()
    assert not stt.transform

# Generated at 2022-06-12 04:02:36.833849
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    import typed_astunparse
    from textwrap import dedent

    code = dedent('''\
        def foo():
            s = str(42)
        ''')
    expected_code = dedent('''\
        def foo():
            s = unicode(42)
        ''')

    # Act
    module = typed_astunparse.ast_parse(code)
    StringTypesTransformer.transform(module)

    # Assert
    expected_module = typed_astunparse.ast_parse(expected_code)
    assert ast.dump(module, include_attributes=True) == ast.dump(expected_module, include_attributes=True)

# Generated at 2022-06-12 04:02:41.259681
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Name('str', ast.Load())
    print(ast.dump(node))
    transformed_node, tree_changed = StringTypesTransformer.transform(node)
    print(ast.dump(transformed_node))
    assert(not tree_changed)

# Generated at 2022-06-12 04:02:44.846544
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    print("UnitTest: StringTypesTransformer")
    trans = StringTypesTransformer()

# Generated at 2022-06-12 04:02:48.031632
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    from ..grouper import TransformationGrouper

    source = """
    s = "text"
    s = str()
    """

    tree = ast.parse(source)

    grouper = TransformationGrouper()
    new_tree = grouper.visit(tree)

    assert new_tree == tree

# Generated at 2022-06-12 04:02:57.255949
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    module = ast.parse("""
a = str()
b = (isinstance(x, str))
c = (type(x) == str)
d = (x is str)

""")
    module_new = StringTypesTransformer.transform(module)
    assert module_new.tree_changed is True
    assert ast.dump(module_new.tree) == ast.dump(ast.parse("""
a = unicode()
b = (isinstance(x, unicode))
c = (type(x) == unicode)
d = (x is unicode)

"""))

# Generated at 2022-06-12 04:02:58.141067
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    
    assert StringTypesTransformer is not None

# Generated at 2022-06-12 04:03:07.520937
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    module = ast.parse(textwrap.dedent('''
        import abc
        def f():
            return 42
        class A(object):
            def __init__(self):
                self.abc = abc.abc
                self.str = str
                self.unicode = unicode
    '''))

    # Before
    func_def = find(module, ast.FunctionDef, name='f')
    name = find(func_def.body[0].value, ast.Name, id='str')
    assert name.id == 'str'

    class_def = find(module, ast.ClassDef, name='A')
    attr = find(class_def.body[1], ast.Attribute, attr='str')
    assert attr.attr == 'str'

    # After
    result = StringTypesTransformer

# Generated at 2022-06-12 04:03:13.546534
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import code_to_ast

    code = """
    a = str('abc')
    b = type(str)
    """
    expected_code = """
    a = unicode('abc')
    b = type(unicode)
    """

    ast_ = code_to_ast.parse_ast(code)
    new_ast = StringTypesTransformer.transform(ast_)

    assert code_to_ast.unparse_ast(ast_) == expected_code

# Generated at 2022-06-12 04:03:19.309169
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = '''
    #! python
    def hello():
        x = str("abc")
    '''

    expected_code = '''
    #! python
    def hello():
        x = unicode("abc")
    '''

    tree = ast.parse(source)
    t = StringTypesTransformer()
    t.transform(tree)
    code = astor.to_source(tree)

    assert code == expected_code

# Generated at 2022-06-12 04:03:24.181963
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.Name(id='str', ctx=ast.Load())
    tree = ast.Constant(value=x)
    refactored_tree = StringTypesTransformer().transform(tree)
    assert(eval(ast.dump(refactored_tree)) == unicode)

# Unit test: verify that no unnecessary changes are made to the AST

# Generated at 2022-06-12 04:03:29.737601
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Input
    in_str = """
    print(str('Hello, World'))
    
    """
    expected_out_str = """
    print(unicode('Hello, World'))
    
    """
    # Run the test
    out_tree = StringTypesTransformer.run_test(in_str)
    # Assert
    assert expected_out_str == astunparse.unparse(out_tree).strip()

# Generated at 2022-06-12 04:03:30.573976
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:38.125757
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from . import test_str_strings

    with StringTypesTransformer.apply_to_file(test_str_strings.__file__) as result:
        assert result.tree_changed
    
    with StringTypesTransformer.apply_to_file(test_str_strings.__file__) as result:
        assert result.tree_changed == False

# Generated at 2022-06-12 04:03:49.031464
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    from ..utils.source import source_to_unicode
    from ..utils.tree import ast_from_str, dump_ast
    from ..utils.visitor import Searcher
    from .utils import round_trip, round_trip_dump

    code = textwrap.dedent("""
    str = 5
    str_ = "str"
    """)
    assert find(ast_from_str(code), (ast.Name, ast.Assign)).pop().id == 'str'

    round_trip_dump(code, StringTypesTransformer.transform)

    code = textwrap.dedent("""
    str
    """)
    assert find(ast_from_str(code), ast.Name).pop().id == 'str'
    round_trip_dump(code, StringTypesTransformer.transform)


# Generated at 2022-06-12 04:03:53.120634
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    expected_code = "def foo():\n   unicode"

    tree = ast.parse(expected_code)
    tree = StringTypesTransformer.transform(tree)
    generated_code = astor.to_source(tree)

    assert generated_code == expected_code

# Generated at 2022-06-12 04:03:54.407159
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .classdoctest import doctest
    doctest(StringTypesTransformer())

# Generated at 2022-06-12 04:03:59.844198
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open('tests/inputs/string_types.py') as f:
        before = f.read()
    with open('tests/inputs/string_types_py2.py') as f:
        after = f.read()
    tree_before = ast.parse(before)
    tree_after = ast.parse(after)
    transformer = StringTypesTransformer()
    tree_changed = transformer.transform(tree_before)
    assert ast.dump(tree_after) == ast.dump(tree_changed.new_tree)

# Generated at 2022-06-12 04:04:03.668090
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = \
    """
    print str
    """
    tree = ast.parse(code)
    transformer = StringTypesTransformer(2, 7)
    new_tree = transformer.transform(tree)
    assert new_tree.body[0].value.id == 'unicode'

# Generated at 2022-06-12 04:04:09.746430
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Simple test
    code = '''
print("Unicode")
'''
    expected_code = '''
print(u"Unicode")
'''
    tree = ast.parse(code)
    tree_transformer = StringTypesTransformer()
    tree_transformer.transform(tree)
    generated_code = compile(tree, filename="<ast>", mode="exec")
    exec(generated_code)
    assert code == expected_code

# Generated at 2022-06-12 04:04:12.237772
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..functions import ast2
    from ..types import TypeError, TransformationError, TreeVisitError


# Generated at 2022-06-12 04:04:14.647927
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
a = str()
"""
    tree = ast.parse(source)
    t = StringTypesTransformer().visit(tree)
    assert t.code == """
a = unicode()
"""

# Generated at 2022-06-12 04:04:19.182929
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = ast.parse("""x = str(foo)""")
    tt = StringTypesTransformer.transform(tt)
    assert isinstance(tt.tree.body[0].value, ast.Name)
    assert tt.tree.body[0].value.id == "unicode"

# Generated at 2022-06-12 04:04:32.083689
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import to_src
    from ..utils.visitor import TransformerVisitor

    code = to_src(ast.parse('"test".encode()'))
    expected_output = to_src(ast.parse('u"test".encode()'))

    visitor = TransformerVisitor()
    visitor.register_transformer(StringTypesTransformer)
    visitor.visit(ast.parse(code))
    result = to_src(visitor.module)

    assert result == expected_output

# Generated at 2022-06-12 04:04:38.827968
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from .utils import roundtrip

    source = '''
    from builtins import bytes
    from builtins import str

    s = str.encode('Hello World!')
    '''
    expected = '''
    from builtins import bytes
    from builtins import unicode

    s = unicode.encode('Hello World!')
    '''

    tree = ast.parse(source)
    out = StringTypesTransformer.transform(tree)
    assert astor.to_source(out.tree) == expected

# Generated at 2022-06-12 04:04:39.612751
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    my_class = StringTypesTransformer()
    assert issubclass(my_class.__class__, BaseTransformer)


# Generated at 2022-06-12 04:04:42.657686
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    lines = ['import re', 'import os', 'if isinstance(thing, str): return str(thing)']
    tree = ast.parse('\n'.join(lines))
    new_tree, tree_changed = transformer.transform(tree)
    assert tree_changed
    assert new_tree is not tree
    assert ast.dump(tree) != ast.dump(new_tree)
    assert ast.dump(tree).count('str ') == 4
    assert ast.dump(new_tree).count('unicode ') == 4

# Generated at 2022-06-12 04:04:45.672280
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = ast.parse("str")
    t = StringTypesTransformer.transform(s)
    assert(len(t.log) == 0)
    assert(t.tree_changed == True)
    assert(ast.dump(t.node) == ast.dump(ast.parse("unicode")))

# Generated at 2022-06-12 04:04:55.724315
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor.
    """
    # Case 1: When tree is not of type ast.AST
    with pytest.raises(TypeError) as exception_info:
        StringTypesTransformer(1)
    assert str(exception_info.value) == 'tree should be of type typed_ast.ast3.AST'

    # Case 2: When tree is of type ast.AST
    tree = ast.parse('x = "quine"')
    transformed_tree = StringTypesTransformer(tree)
    assert isinstance(transformed_tree, ast.AST)
    assert type(transformed_tree) == ast.Module
    assert ast.dump(transformed_tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Str(s='quine'))])"

# Generated at 2022-06-12 04:05:00.443232
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.tree import parse_code_as_module

    code = """
    print str(42)
    """

    tree = parse_code_as_module(code)
    tree, changed, messages = StringTypesTransformer.transform(tree)

    assert changed
    assert str(tree).strip() == """
print unicode(42)"""
    assert messages == []



# Generated at 2022-06-12 04:05:05.263210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''def foo(x: str) -> str:
    return x'''
    new_code = '''def foo(x: unicode) -> unicode:
    return x'''
    
    t = StringTypesTransformer()
    res = t.transform_code(code)
    assert res == new_code

# Generated at 2022-06-12 04:05:10.984096
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = 'str(5)'
    exp_source = 'unicode(5)'
    tree = ast.parse(source, '', 'eval')

    transformer = StringTypesTransformer()
    actual_tree, changed = transformer.transform(tree)
    actual_source=astor.to_source(actual_tree)

    assert changed
    assert actual_source == exp_source

# Generated at 2022-06-12 04:05:13.704768
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    original_ast = ast.parse("foo = str(something)")
    expected_ast = ast.parse("foo = unicode(something)")

    transformer = StringTypesTransformer()
    res, tree_changed = transformer.transform(original_ast)
    assert tree_changed
    assert ast.dump(res) == ast.dump(expected_ast)

# Generated at 2022-06-12 04:05:32.520839
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("x = str(y)")
    transformed_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed
    assert ast.dump(transformed_tree) == \
        "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='y', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-12 04:05:35.863253
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = StringTypesTransformer()

    # No check because there is no difference between 2 and 3.
    t.check = lambda tree: True

    assert t.ast2to3('''
        def func(a: str):
            pass
    ''') == '''
        def func(a: unicode):
            pass
    '''

# Generated at 2022-06-12 04:05:38.316565
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("a = 2 + str(5)")) == TransformationResult(ast.parse("a = 2 + unicode(5)"), True, [])

# Generated at 2022-06-12 04:05:44.704461
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    arg = "str = u'hello world'\nstr = 'str'\nstr = unicode(str)\n"
    output = "str = u'hello world'\nstr = u'str'\nstr = unicode(str)\n"
    tree = ast.parse(arg)
    tree = StringTypesTransformer.transform(tree)
    assert astunparse.unparse(tree) == output


if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:05:48.941535
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest

    # Constructor test
    class StringTypesTransformerTest(unittest.TestCase):
        def test(self):
            pass

    # Construct object
    t = StringTypesTransformer()


# Collect test cases
test_cases = [
    (StringTypesTransformer, "test_StringTypesTransformer")
]

# Collect test classes
test_classes = [
    StringTypesTransformerTest
]

# Generated at 2022-06-12 04:05:52.481332
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert isinstance(string_types_transformer, BaseTransformer)
    assert string_types_transformer.versions() == (2, 7)


# Generated at 2022-06-12 04:05:53.529426
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert isinstance(StringTypesTransformer(), BaseTransformer)

# Generated at 2022-06-12 04:05:57.302299
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.ast_builder import build

    t = StringTypesTransformer.transform(
        build(2, 7, """
        x = str
        y = "Hello"
        """))[0]

    assert 'unicode' in t.body[0].value.id

# Generated at 2022-06-12 04:06:04.731564
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_in = r"""
s = 'abc'
"""
    code_out = r"""
s = 'abc'
"""
    tree_in = ast.parse(code_in)
    tf = StringTypesTransformer()
    tree_out = tf.visit(tree_in)
    code_out_generated = astor.to_source(tree_out)
#    print(code_out)
#    print(code_out_generated)
    assert(code_out == code_out_generated)

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:06:10.361239
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import render_ast

    code = 'def foo(arg): return str(arg)'

    tree = ast.parse(code)
    t = StringTypesTransformer()
    t.visit(tree)

    assert render_ast(tree) == render_ast(ast.parse('def foo(arg): return unicode(arg)'))

# Generated at 2022-06-12 04:06:38.304522
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('''print('Hi')''')

    transformer = StringTypesTransformer()
    res = transformer.transform(tree)

    assert res.tree_changed
    assert len(res.import_names) == 0
    assert res.tree != tree

# Generated at 2022-06-12 04:06:39.337209
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..parser import PythonParser

# Generated at 2022-06-12 04:06:44.041317
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    import inspect
    import textwrap
    tree = ast.parse(textwrap.dedent("""\
    def main(x: str):
        return x
    """))
    tree = StringTypesTransformer.transform(tree)
    assert inspect.getsource(tree.tree) == textwrap.dedent("""\
    def main(x: unicode):
        return x
    """)

# Generated at 2022-06-12 04:06:46.345191
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given

    # When
    transformer = StringTypesTransformer()

    # Then
    assert transformer is not None

# Generated at 2022-06-12 04:06:47.803678
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = StringTypesTransformer()
    assert not tt.tree_changed

# Generated at 2022-06-12 04:06:49.812680
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.test_utils import compare_transformation
    compare_transformation(StringTypesTransformer, """
        s = str("hello, world")
    """)

# Generated at 2022-06-12 04:06:58.623863
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = '''
    if x is str: # 1
        pass
    elif x is not str: # 2
        pass
    else:
        pass
    assert x is str # 3
    assert x is not str # 4
    assert not x is str # 5
    assert not x is not str # 6
    '''
    expected_code = '''
    if x is unicode: # 1
        pass
    elif x is not unicode: # 2
        pass
    else:
        pass
    assert x is unicode # 3
    assert x is not unicode # 4
    assert not x is unicode # 5
    assert not x is not unicode # 6
    '''

    # When
    result = StringTypesTransformer.run(code)

    # Then

# Generated at 2022-06-12 04:06:59.880103
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:07:04.961370
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = textwrap.dedent("""
    def f(<s: str>s: str) -> int:
        return len(s)

    """)
    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)
    exec(compile(tree, '<string>', 'exec'))
    assert f('a') == 1

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:07:11.011932
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    input_source = textwrap.dedent("""
    x = str()
    """)
    expected_output = textwrap.dedent("""
    x = unicode()
    """)
    tree = ast.parse(input_source)
    tree = StringTypesTransformer.transform(tree)
    output_source = compile(tree, filename='<tmp>', mode="exec")
    assert output_source == expected_output

# Generated at 2022-06-12 04:08:11.078122
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .transformer import Transformer
    from typed_ast import ast3 as ast
    import sys

    tree = ast.parse(
        """
        if True:
            a = str()
        """
    )
    Transformer.transform(tree, sys.version_info, [StringTypesTransformer])
    assert(str(tree) == "Module(body=[\n    If(test=NameConstant(value=True), body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))], orelse=[])])")

# Generated at 2022-06-12 04:08:18.918342
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    tree = ast.parse("from typing import Literal, Union\n" +
                     "foo: Union[str, Literal['x']]")
    actual = StringTypesTransformer.transform(tree)
    expected = TransformationResult(ast.parse("from typing import Union\n" +
                                              "foo: Union[unicode, 'x']"),
                                    actual.tree_changed,
                                    [])
    assert actual == expected
    
    # Test 2
    tree = ast.parse("foo: str")
    actual = StringTypesTransformer.transform(tree)
    expected = TransformationResult(ast.parse("foo: unicode"),
                                    actual.tree_changed,
                                    [])
    assert actual == expected

# Generated at 2022-06-12 04:08:24.420209
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
a = str('abc')
"""

    module = ast.parse(code)
    StringTypesTransformer.transform(module)
    assert ast.dump(module) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Str(s='abc')], keywords=[], starargs=None, kwargs=None))])\n"

# Generated at 2022-06-12 04:08:26.870322
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_type = ast.Name(id = "str")
    assert StringTypesTransformer.transform(string_type) == TransformationResult(ast.Name(id = "unicode"), True, [])


# Generated at 2022-06-12 04:08:33.428287
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    result = StringTypesTransformer.transform(ast.parse('"string".encode("utf-8")'))

    assert result.tree_changed == True
    assert ast.dump(result.tree, annotate_fields=False) == "Expr(value=Call(func=Attribute(value=Str(s='string'), attr='encode', ctx=Load()), args=[Str(s='utf-8')], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-12 04:08:39.152479
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = textwrap.dedent(
        """
        def foo():
            print(str(12))
        """
    )
    tree = ast.parse(code)
    tree_changed, messages = StringTypesTransformer.transform(tree)
    assert len(messages) == 0

    expected_code = textwrap.dedent(
        """
        def foo():
            print(unicode(12))
        """
    )

    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-12 04:08:46.959980
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str()")
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert tree.body[0].value.func.id == "str"

    new_tree, changed = StringTypesTransformer.transform(tree)
    assert changed
    assert isinstance(new_tree.body[0].value, ast.Call)
    assert isinstance(new_tree.body[0].value.func, ast.Name)
    assert new_tree.body[0].value.func.id == "unicode"


# Generated at 2022-06-12 04:08:51.497520
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    a = ast.parse('str is str')
    t = StringTypesTransformer.transform(a)
    t.tree._fields
    b = ast.parse('str is unicode')
    assert(ast.dump(t.tree) == ast.dump(b))
    assert(t.tree_changed)
    assert(t.nodes_transformed == [])



# Generated at 2022-06-12 04:08:59.077959
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from textwrap import dedent
    from ..utils.test_utils import assert_transformed_code

    assert_transformed_code(
        StringTypesTransformer,
        dedent("""
        some_variable = str(foo)
        """),
        dedent("""
        some_variable = unicode(foo)
        """)
    )

    assert_transformed_code(
        StringTypesTransformer,
        dedent("""
        import string
        some_function('string')
        """),
        dedent("""
        import string
        some_function('string')
        """)
    )

# Generated at 2022-06-12 04:09:03.250072
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseTransformerTestCase, TransformTestCase, Transformer

    class TestCase(BaseTransformerTestCase, TransformTestCase):
        transformer_class = StringTypesTransformer
        transformer = Transformer(StringTypesTransformer)

    test_case = TestCase()
    test_case.test_transform()

# Generated at 2022-06-12 04:11:17.059676
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    data = """\
        def foo(bar):
            return bar
        """

    tree = ast.parse(data)
    transformer = StringTypesTransformer()
    result, _ = transformer.transform(tree)

    for node in find(result, ast.Name):
        if node.id == 'str':
            assert False

    for node in find(result, ast.Name):
        if node.id == 'unicode':
            assert True

# Generated at 2022-06-12 04:11:21.621388
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from unittest.mock import Mock
    from typed_ast import ast3 as ast
    from .utils import assert_node
    from .utils import get_transformer

    transformer = get_transformer(StringTypesTransformer)
    
    source = '''
    a = str()
    '''

    tree = ast.parse(source)
    target = '''
    a = unicode()
    '''

    assert_node(transformer(tree), target)


# Generated at 2022-06-12 04:11:25.225829
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test StringTypesTransformer."""
    tree = ast.parse('str(a)')
    tree = StringTypesTransformer.transform(tree)
    assert 'unicode' in tree.body[0].value.func.id

    tree = ast.parse('str')
    tree = StringTypesTransformer.transform(tree)
    assert 'unicode' in tree.body[0].id

# Generated at 2022-06-12 04:11:29.310748
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('str("Test")')
    tree_changed, fixed_nodes = StringTypesTransformer.transform(tree)
    tree_changed_str = True
    fixed_nodes_str = []
    assert tree_changed == tree_changed_str
    assert fixed_nodes == fixed_nodes_str

# Generated at 2022-06-12 04:11:29.800925
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert False

# Generated at 2022-06-12 04:11:30.507747
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:11:38.489695
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    x = ast.Name(id="str", ctx=ast.Load())
    y = ast.Name(id="str", ctx=ast.Load())

    tree = ast.BinOp(x, ast.Add(), y)
    (tree_changed, tree_transformed, changes_made) = StringTypesTransformer.transform(tree)
    print(tree_changed)
    print(tree_transformed)
    print(changes_made)
    # assert EncodingFormatter.transform('utf-8', tree) == u"utf-8".encode('utf-8')
    # assert EncodingFormatter.transform('utf-8', tree) == u"utf-8"

# Generated at 2022-06-12 04:11:42.449009
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..parsers import Python27Parser

    tree = Python27Parser.parse('str("hello")')
    transformer = StringTypesTransformer()
    transformed, _ = transformer.transform(tree)
    assert (transformed.body[0].value.elts[0].s == 'hello')

# Generated at 2022-06-12 04:11:44.557265
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """py2app/lib/python2.7/site-packages/typed_ast/ast3.py
    """

# Generated at 2022-06-12 04:11:50.550562
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
        d = {
            'a': "a",
            'b': "b"
        }
    '''
    tree = ast.parse(code)
    t = StringTypesTransformer()
    t.transform(tree)

    assert(t.transform(tree).tree_changed)
    assert(t.transform(tree).string == 'd = {\n            \'a\': \'a\',\n            \'b\': \'b\'\n        }')

if __name__ == "__main__":
    test_StringTypesTransformer()