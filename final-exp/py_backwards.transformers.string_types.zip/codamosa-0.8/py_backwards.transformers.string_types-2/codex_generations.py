

# Generated at 2022-06-12 04:01:44.894756
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

  # Arrange
  import typed_ast.ast3 as ast
  import sys

# Generated at 2022-06-12 04:01:51.641688
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    node1 = ast.BinOp(op=ast.Add(), left=ast.Name(id='str'), right=ast.Str(s='hi'))
    node2 = ast.BinOp(op=ast.Add(), left=ast.Str(s='hi'), right=ast.Name(id='str'))

    tree = ast.BinOp(op=ast.Add(), left=node1, right=node2)

    # Tests tree
    assert isinstance(tree, ast.BinOp)
    assert isinstance(tree.left, ast.BinOp)
    assert isinstance(tree.right, ast.BinOp)
    assert isinstance(tree.left.left, ast.Name)
    assert isinstance(tree.right.right, ast.Name)
    assert tree.left.left.id == 'str'


# Generated at 2022-06-12 04:01:58.471781
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_nodes_typed
    from ..utils.tree import nodes_to_source, node_to_source
    with open('test/test_files/test_StringTypesTransformer.py') as f:
        source = f.read()
    nodes = source_to_nodes_typed(source, 'Python27')
    assert type(nodes) is ast.Module
    
    assert node_to_source(nodes).strip() == source.strip()

    transformed_nodes = StringTypesTransformer.transform(nodes)
    
    assert transformed_nodes.tree is not nodes
    assert node_to_source(transformed_nodes.tree).strip() == source.replace('str', 'unicode').strip()

    assert transformed_nodes.tree_changed
    assert transformed_n

# Generated at 2022-06-12 04:02:06.345489
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils import dump 
    from ..utils import run_to_output
    from .base import BasePhase

    class Phase(BasePhase):
        @property
        def name(self) -> str:
            return 'test'

        @property
        def target(self) -> tuple:
            return (2, 7)

        def apply(self, tree: ast.AST) -> TransformationResult:
            return StringTypesTransformer.transform(tree)


# Generated at 2022-06-12 04:02:07.677903
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    from ..utils.tree import dump
  

# Generated at 2022-06-12 04:02:12.681433
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer 
    """
    transformer = StringTypesTransformer()
    assert transformer.name == 'StringTypesTransformer'
    assert transformer.target == (2, 7)
    assert transformer.description == (
        'Replaces `str` with `unicode`.')

# Can be run with 'python -m pyups.transformers.string_types_transformer'

# Generated at 2022-06-12 04:02:18.402256
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test the class StringTypesTransformer
    """
    # Test the string
    test_string = "def helloworld(string): print(str)"

    # transform
    tree = ast.parse(test_string)
    trans = StringTypesTransformer()
    result = trans.transform(tree)
    codeobj = compile(result.tree, '<string>', 'exec')
    exec(codeobj)

# Generated at 2022-06-12 04:02:26.943522
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ...tests.fixtures import parametrization_basic_module
    from ...tests.fixtures import parametrization_numpy_module
    from ...tests.helpers import normalized_ast

    from_version, to_version = StringTypesTransformer.target
    for tree in parametrization_basic_module(from_version, to_version):
        tree = StringTypesTransformer.transform(tree)
        assert normalized_ast(tree) == normalized_ast(parametrization_basic_module(to_version))

    for tree in parametrization_numpy_module(from_version, to_version):
        tree = StringTypesTransformer.transform(tree)
        assert normalized_ast(tree) == normalized_ast(parametrization_numpy_module(to_version))

# Generated at 2022-06-12 04:02:33.312893
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import os, ast
    from ..utils.ast import parse_ast

    file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'examples', 'string_types.py')
    example_tree = parse_ast(file_path)
    tree = StringTypesTransformer.transform(example_tree)

    for node in ast.walk(tree.tree):
        if isinstance(node, ast.Name):
            assert node.id != 'str'

# Generated at 2022-06-12 04:02:34.854031
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse


# Generated at 2022-06-12 04:02:42.098186
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t = """
    a = str(1)
    b = str
    """
    expected = """
    a = unicode(1)
    b = unicode
    """
    res = StringTypesTransformer.transform(ast.parse(t))
    assert expected == astunparse.unparse(res.tree)
    assert res.applied_transformation == [StringTypesTransformer]

# Generated at 2022-06-12 04:02:43.798218
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..conversions import convert
    from ..utils import parse_ast, compare_nodes


# Generated at 2022-06-12 04:02:53.909604
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import PYTHON_VERSION, run_transformer

    if PYTHON_VERSION < (3, 0):
        assert run_transformer(StringTypesTransformer, '''
            def test():
                x = str
            ''').changed == False
        assert run_transformer(StringTypesTransformer, '''
            def test():
                x = unicode
            ''').changed == False
        assert run_transformer(StringTypesTransformer, '''
            def test():
                x = unicode()
            ''').changed == False
        assert run_transformer(StringTypesTransformer, '''
            def test():
                x = unicode(''' + "''" + ''')
            ''').changed == False

# Generated at 2022-06-12 04:02:59.352268
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # mod1 = ast.parse("str('text')")
    mod2 = ast.parse("str('text')")
    # print(ast.dump(mod1))
    # print(ast.dump(mod2))
    # mod1 = StringTypesTransformer.transform(mod1)
    mod2 = StringTypesTransformer.transform(mod2)
    print(ast.dump(mod2))

# Generated at 2022-06-12 04:03:02.737094
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = """str"""
    result = StringTypesTransformer.transform(ast.parse(s))
    assert result.tree.body[0].value.id == 'unicode'

# Generated at 2022-06-12 04:03:06.454275
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tr = StringTypesTransformer()
    assert tr.from_version == (2, 7)
    assert tr.to_version == (3,)
    assert tr.description == 'Replaces `str`\'s with `unicode`\'s.'
    assert tr.transform(ast.parse('str()')) == (ast.parse('unicode()'), True, [])

# Generated at 2022-06-12 04:03:07.277850
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:11.886964
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .utils import get_ast
    from .test_base import BaseTransformerTest
    from .test_base import BasicSourceFactory
    
    class Test(BaseTransformerTest, unittest.TestCase):
        transformer = StringTypesTransformer
        path = __file__
        factory = BasicSourceFactory

    unittest.main()

# Generated at 2022-06-12 04:03:18.273701
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import parse
    import sys
    import astor

    test_ast = parse('a = str()')

    assert astor.to_source(test_ast) == "a = str()\n"

    expected_ast = parse('a = unicode()')

    actual_ast = StringTypesTransformer.transform(test_ast).tree

    assert astor.to_source(actual_ast) == astor.to_source(expected_ast)

    print(astor.to_source(actual_ast))

# Generated at 2022-06-12 04:03:19.573012
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:29.885577
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..tester import transform_test
    from ..utils.tree import to_src
    from ..utils.fixtures import get_test_fixture
    
    tree = get_test_fixture('StringTypesTransformerExample.py')
    tree1 = get_test_fixture('StringTypesTransformerExampleV1.py')

    new_tree, tree_changed, _, _ = transform_test(StringTypesTransformer, tree)
    assert to_src(new_tree) == to_src(tree1)
    assert tree_changed == True



# Generated at 2022-06-12 04:03:33.917691
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    with open("tests/resources/class_transformer.py") as f:
        tree = ast.parse(f.read())
    transformer = StringTypesTransformer()
    results = transformer.transform(tree)
    assert results[1] is True
    visitor = ast.NodeVisitor()
    results[0].body[0].body[0].value.func.id == "unicode"

# Generated at 2022-06-12 04:03:42.821983
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Test suite for the constructor of class StringTypesTransformer.
    """
    ts_transformer = StringTypesTransformer()
    code_str = 'a = str(1)'
    tree = ast.parse(code_str, mode="exec")
    tree = ts_transformer.visit(tree)
    assert ts_transformer.tree_changed is True
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Call(func=Name(id="unicode", ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))])'

# Generated at 2022-06-12 04:03:44.087080
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:03:54.141714
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
	#Initialisation
	tree = ast.parse('''
	def test(a):
		b = str(a)
		c = "hello " + str(a) + " world"
	''')
	tree_changed, new_tree = StringTypesTransformer.transform(tree)
	pprint(ast.dump(new_tree))

	#Expected result
	tree_expected = ast.parse('''
	def test(a):
		b = unicode(a)
		c = "hello " + unicode(a) + " world"
	''')
	pprint(ast.dump(tree_expected))

	assert ast.dump(tree_expected) == ast.dump(new_tree)
	print("test_StringTypesTransformer ok")


# Generated at 2022-06-12 04:03:54.717692
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert True

# Generated at 2022-06-12 04:03:59.569484
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # 2.7
    tree = ast.parse("a = 'string'\nprint(str(5))")
    new_tree = StringTypesTransformer.transform(tree)

    assert isinstance(find(new_tree.tree, ast.Str)[0], ast.Str)
    assert isinstance(find(new_tree.tree, ast.Call)[0].func, ast.Name)
    assert find(new_tree.tree, ast.Name)[0].id == 'unicode'

# Generated at 2022-06-12 04:04:01.070795
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass


# Generated at 2022-06-12 04:04:01.944711
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:04:11.594913
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from textwrap import dedent
    from ..utils.cst import parse_module
    from ..utils.ast import dump_ast

    source = dedent('''
    def foo(s):
        assert isinstance(s, str)

    print(str(1))
    ''')


# Generated at 2022-06-12 04:04:17.964841
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:04:18.818316
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:04:22.257316
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test all transformations of class StringTypesTransformer.
    """
    a = ast.parse('str')
    result = StringTypesTransformer.transform(a)
    assert result.tree.body[0].value.id == 'unicode'
    assert result.tree_changed

# Generated at 2022-06-12 04:04:23.588726
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:04:34.416123
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils import test_resources as res
    from ..utils import test_utils as tu
    from importlib import resources

    source = res.read_resource(res.py3, 'string_types')

    tree = tu.parse_code(source)
    StringTypesTransformer.transform(tree)
    result = tu.compile_and_import(tree, 'string_types')

    assert result.__doc__ == 'module docstring'
    assert result.cls.__doc__ == 'class docstring'
    assert isinstance(result.cls().f('42'), basestring)
    assert isinstance(result.cls2([1,2]).f2('bob'), basestring)
    assert isinstance(result.cls3().f3(), basestring)

# Generated at 2022-06-12 04:04:43.803551
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    #
    # class A:
    #     def __init__(self):
    #         self.a = str("abcd")
    #         self.b = str(1)
    #

# Generated at 2022-06-12 04:04:45.744457
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.Str(s='a')
    res = StringTypesTransformer().visit(node)
    assert res is node
    assert type(node) is ast.Str

# Generated at 2022-06-12 04:04:55.797394
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..tstypes import ClassType, AttributeType, MethodType
    from .base import TransformerInfo
    from .. import utils

    class A:
        pass

    class B:
        pass

    class C:
        pass

    src = '''
        import typing

        class A:
            def a():
                return str
            def b():
                return str()
            def c(x):
                return isinstance(x, str)
            def d(x):
                return issubclass(x, str)

        class B:
            a: str

        class C():
            a: str
    '''
    info = TransformerInfo(src, globals(), 'str', 'unicode')
    tree, symbol_table = utils.parse_src(src, info.mode)

    cls = StringTypesTransformer

# Generated at 2022-06-12 04:05:00.535779
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    def foo(bar: str) -> str:
        pass
    '''
    tree = ast.parse(code)
    res = StringTypesTransformer.transform(tree)

    assert "".join(list(res.code.split())) == '''
    def foo(bar: unicode) -> unicode:
        pass
    '''

# Generated at 2022-06-12 04:05:06.134508
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.samples import SampleFile
    from ..utils.tree import to_string
    from ..utils import loader
    from ..parser import parse

    for sample in SampleFile('string_types'):
        tree = parse(sample.source)
        loader.apply(tree, [StringTypesTransformer])
        assert to_string(tree).strip() == sample.target.strip()

# Generated at 2022-06-12 04:05:26.865239
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_before = '''
import sys
assert sys.version_info[0] == 2
assert sys.version_info[1] == 7
text = str()
'''

    code_after = '''
import sys
assert sys.version_info[0] == 2
assert sys.version_info[1] == 7
text = unicode()
'''

    tree = ast.parse(code_before)
    tree_after = ast.parse(code_after)
    transformer = StringTypesTransformer()
    _, changed = transformer.transform(tree)

    assert changed  # StringTypeTransformer changed the tree
    assert ast.dump(tree) == ast.dump(tree_after)  # tree is not changed

# Generated at 2022-06-12 04:05:35.667007
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
str
"""
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    tree_changed, python_version_changed, file_changed = transformer.transform(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=Name(id='unicode', ctx=Load()))])"
    assert tree_changed == True
    assert python_version_changed == False
    assert file_changed == []
    code = """
if 1:
    str
"""
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    tree_changed, python_version_changed, file_changed = transformer.transform(tree)

# Generated at 2022-06-12 04:05:43.135700
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests if StringTypesTransformer works.

    """
    from ..parser import Parser

    source = 'def foo(bar=str):\n    print(str(""))'
    parser = Parser()
    parser.parse(source)
    tree = parser.tree
    assert len(find(tree, ast.Name)) == 4

    transformer = StringTypesTransformer()
    transformed_tree = transformer.transform(tree)
    assert len(find(transformed_tree, ast.Name)) == 4
    assert find(transformed_tree, ast.Name, id='unicode') != []

# Generated at 2022-06-12 04:05:49.366747
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for transformation
    import typed_ast.ast3 as ast
    from transformers.string_types import StringTypesTransformer

    test_tree = ast.parse("a = str(a)")
    StringTypesTransformer.transform(test_tree)
    assert ast.dump(test_tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-12 04:05:56.310736
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from textwrap import dedent

    code = dedent('''
    x = str('abc')
    ''')

    tree = ast3.parse(code)

    expected_code = dedent('''\
    x = unicode('abc')
    ''')

    trans = StringTypesTransformer()
    new_tree, tree_changed, _ = trans.transform(tree)
    assert tree_changed
    assert ast3.dump(new_tree) == expected_code

# Generated at 2022-06-12 04:05:56.948014
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert isinstance(StringTypesTransformer(), BaseTransformer)

# Generated at 2022-06-12 04:06:06.783407
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    program_ast = ast.parse(
        'def foo():\n'
        '    x: str = 3')
    transformed_ast = StringTypesTransformer.transform(program_ast)
    assert ast.dump(transformed_ast.tree) == \
        "Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwarg=None, kwonlyargs=[], defaults=[], kw_defaults=[]), body=[Assign(targets=[Name(id='x', ctx=Store(), annotation=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=3)], keywords=[]))], value=Num(n=3))], decorator_list=[])])"
    assert transformed_ast.tree_changed is True
    assert transformed_ast

# Generated at 2022-06-12 04:06:11.241215
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform()
    assert StringTypesTransformer.transform(StringTypesTransformer)

# this is the pytest for the StringTypesTransformer
# pytest --capture=no tests/transforms/test_py2_string_types.py::test_StringTypesTransformer

# Generated at 2022-06-12 04:06:15.126519
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_tree = ast.parse('isinstance(x, str)')

    result = StringTypesTransformer.transform(test_tree)

    assert result.tree_changed == True

    assert ast.dump(result.tree) == ast.dump(ast.parse('isinstance(x, unicode)'))

# Generated at 2022-06-12 04:06:24.687897
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3
    # Test replacement of str to unicode
    tree = typed_ast.ast3.parse('str')
    new_tree = StringTypesTransformer.transform(tree)
    assert(isinstance(new_tree.tree, typed_ast.ast3.Module))
    assert(isinstance(new_tree.tree.body[0].value, typed_ast.ast3.Name))
    assert(new_tree.tree.body[0].value.id == 'unicode')
    assert(new_tree.tree_changed == True)
    assert(new_tree.used_imports == [])


# Generated at 2022-06-12 04:06:51.065950
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:06:52.504923
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    print(transformer.transform('print("Hello" + str(123))'))

# Generated at 2022-06-12 04:06:57.097990
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = "print('Existing string')\n"
    new_s = "print(u'Existing string')\n"
    tree = ast.parse(s)
    res = StringTypesTransformer.transform(tree)
    assert res.tree_changed == True
    assert ast.dump(res.tree) == ast.dump(ast.parse(new_s))

# Generated at 2022-06-12 04:06:57.976135
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:07:07.192624
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    code = """
    str()
    str(1)
    str = unicode
    """

    expected_ast = """
        Module(body=[
            Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[])), 
            Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[])), 
            Assign(targets=[Name(id='str', ctx=Store())], value=Name(id='unicode', ctx=Load()))])
    """

    transformer = StringTypesTransformer()
    result = transformer.transform(code)
    assert(result.tree_changed)

    compare_asts(result.tree, expected_ast)

# Generated at 2022-06-12 04:07:09.316438
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests constructor for class StringTypesTransformer.
    """
    assert StringTypesTransformer.__name__ == "StringTypesTransformer"


# Generated at 2022-06-12 04:07:17.914342
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astunparse

    test_code = """
str()
str(foo)
str(foo=42)
str(foo, bar)
str(foo, bar=1)
str(foo, bar, baz)
str(foo, bar, baz=1)
"""

    tree = ast.parse(test_code)
    tree = StringTypesTransformer.transform(tree).tree

    assert astunparse.unparse(tree) == """
unicode()
unicode(foo)
unicode(foo=42)
unicode(foo, bar)
unicode(foo, bar=1)
unicode(foo, bar, baz)
unicode(foo, bar, baz=1)
"""

# Generated at 2022-06-12 04:07:19.873684
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # when
    transformer = StringTypesTransformer()
    # then
    assert transformer.target == (2, 7)


# Generated at 2022-06-12 04:07:25.517614
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('''x = str(1)''')) == TransformationResult(ast.parse('''x = unicode(1)'''), True, [])

# Generated at 2022-06-12 04:07:29.721416
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
   a = ast.parse("print('Hello world')")
   b = ast.parse("print(unicode('Hello world'))")
   print("Test for StringTypesTransformer")
   assert(ast.dump(StringTypesTransformer.transform(a)[0]) == ast.dump(b))
   print("Passed")

if __name__ == "__main__":
   test_StringTypesTransformer()

# Generated at 2022-06-12 04:08:30.182460
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from .. import transform


# Generated at 2022-06-12 04:08:37.486671
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_tree = ast.parse("a = str()")
    transformer = StringTypesTransformer()
    result = transformer.transform(test_tree)
    assert result.tree_changed
    assert result.warnings == []
    assert type(result.tree) == ast.Module
    assert type(result.tree.body[0]) == ast.Assign
    assert type(result.tree.body[0].value) == ast.Call
    assert result.tree.body[0].value.func.id == 'unicode'
    assert len(result.tree.body[0].value.args) == 0
    assert len(result.tree.body[0].value.keywords) == 0
    assert type(result.tree.body[0].targets[0]) == ast.Name

# Generated at 2022-06-12 04:08:42.447504
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree_in = ast.parse("type1 = str\ntype2 = unicode\ntype3")
    tree_out = ast.parse("type1 = unicode\ntype2 = unicode\ntype3")
    trans = StringTypesTransformer()
    tree_changed, messages = trans.transform(tree_in)
    assert tree_out == tree_changed

# Generated at 2022-06-12 04:08:47.566047
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = ast.parse('name = str(1)')
    StringTypesTransformer().transform(s)
    assert ast.dump(s) == "Module(body=[Assign(targets=[Name(id='name', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-12 04:08:49.826816
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("var = isinstance(var, str)")
    assert(StringTypesTransformer.transform(tree).tree) == ast.parse("var = isinstance(var, unicode)")

# Generated at 2022-06-12 04:08:55.760170
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t1 = ast.parse("x = 'a'")
    t2 = ast.parse("x = u'a'")
    assert StringTypesTransformer.transform(t1).tree == t2

    t1 = ast.parse("def f():\n    x = 'a'")
    t2 = ast.parse("def f():\n    x = u'a'")
    assert StringTypesTransformer.transform(t1).tree == t2

# Generated at 2022-06-12 04:08:59.356435
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    code = 'a = str(\"s\")'
    expected = 'a = unicode(\"s\")'

    # Act
    result = StringTypesTransformer.transform(code)

    # Assert
    assert result == expected


# Generated at 2022-06-12 04:09:03.203773
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    t1 = ast.parse('str')
    t2 = ast.parse('unicode')
    assert StringTypesTransformer.transform(t1).tree == t2
    t3 = ast.parse('unicode')
    assert StringTypesTransformer.transform(t2).tree == t3

# Generated at 2022-06-12 04:09:09.601218
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast, source_to_module
    from . import TransformationsApplier, apply_transformations

    def assert_transform(source, expected_source):
        module = source_to_module(source)
        tree_changed, _ = TransformationsApplier(
            (StringTypesTransformer,),
            target=(2, 7),
        ).apply(module)
        assert tree_changed, 'AST tree should have been modified.'
        assert(
            source_to_ast(expected_source) ==
            apply_transformations(module, target=(2, 7))
        )
    
    assert_transform(
        'def f(x: str): pass',
        'def f(x: unicode): pass',
    )


# Generated at 2022-06-12 04:09:19.134111
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ..utils import ast_checker

    tree = ast.parse("""
        def x():
            a = 'a'
            b = u'b'
            c = str('c')
            d = str('d')
            print(str(a))
            print(str(b))
            print(str(c))
            print(str(d))
        """)

    node_types = {type(x).__name__ for x in ast.iter_child_nodes(tree)}

    assert 'FunctionDef' in node_types
    assert 'Assign' in node_types
    assert 'Str' in node_types
    assert 'Name' in node_types
    assert 'Print' in node_types


# Generated at 2022-06-12 04:11:33.371777
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:11:36.302617
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "a = 'hello'\n"
    tree = ast.parse(code)

    new_tree, changed, messages = StringTypesTransformer.transform(tree)
    assert changed == True

# Generated at 2022-06-12 04:11:36.867315
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:11:41.229101
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
a = str()
"""
    current_version, new_version = 2, 7
    expected_ast =  ast.parse("""
a = unicode()
""")
    result_ast = StringTypesTransformer.transform(ast.parse(code)).tree
    assert ast.dump(expected_ast) == ast.dump(result_ast)

# Generated at 2022-06-12 04:11:47.083817
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ... import run_transformer

    code = """
    a = str(1)
    b = 'str' if True else 'str'
    if isinstance(b, str):
        1
    """
    expected_code = """
    a = unicode(1)
    b = 'str' if True else 'str'
    if isinstance(b, unicode):
        1
    """

    result = run_transformer(StringTypesTransformer, code)
    assert result == expected_code