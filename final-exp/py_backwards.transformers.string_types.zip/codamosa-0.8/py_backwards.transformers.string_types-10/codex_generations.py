

# Generated at 2022-06-12 04:01:50.314663
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    str_node = ast.Name(id='str', ctx=ast.Load())
    tree = ast.Module(body=[str_node])

    actual = StringTypesTransformer.transform(tree)
    expected = TransformationResult(ast.Module(body=[ast.Name(id='unicode', ctx=ast.Load())]), True, [])

    assert actual == expected

# Generated at 2022-06-12 04:01:52.877015
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import typed_astunparse
    resultCode = StringTypesTransformer.transform(ast.parse("a = str()"))
    print(typed_astunparse.unparse(resultCode.node))

# Generated at 2022-06-12 04:01:59.198447
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests that the `str` type annotation is rewritten
    to `unicode`.
    """
    tree = ast.parse('from something import str as unicode\n' +
        'def bar(a: str) -> str: pass'
    )
    result = StringTypesTransformer().transform(tree)
    source = ast.dump(result.tree)
    expected = 'from something import unicode\n' + \
        'def bar(a: unicode) -> unicode: pass' 
    assert source == expected

# Generated at 2022-06-12 04:02:10.308016
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test for transform
    ast_1 = ast.parse("hello = 'world'", mode="exec")
    ast_2 = ast.parse("hello = u'world'", mode="exec")
    ast_3 = ast.parse("hello = u'str'", mode="exec")
    ast_4 = ast.parse("hello = unicode('str')", mode="exec")
    ast_5 = ast.parse("hello = str('str')", mode="exec")
    ast_6 = ast.parse("hello = unicode(u'str')", mode="exec")
    ast_7 = ast.parse("""class Test:
                        def __init__(self, a):
                            self.name = a
                            """, mode="exec")
    ast_8 = ast.parse("hello = 'world'", mode="eval")
    ast

# Generated at 2022-06-12 04:02:14.073610
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from .harness import round_trip
    import sys


    class MyTransformer(ast3.NodeTransformer):
        def visit_Call(self, node):
            return ast3.copy_location(
                ast3.Str('bar'), node)


    round_trip(MyTransformer())



# Generated at 2022-06-12 04:02:20.762444
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_helper import ast_to_str

    source = """
        x = str()
    """
    expected = """
        x = unicode()
    """
    tree = ast.parse(source)
    result = ast_to_str(tree)
    print(result)
    assert result == expected
    assert len(list(find(tree, ast.Name))) == 1


# Generated at 2022-06-12 04:02:25.246887
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class Py27Transformation(Transformer):
        pass

    # singleton
    assert StringTypesTransformer() is StringTypesTransformer()
    # correct transformation
    assert len(Py27Transformation(_ast.parse('str')).transform(StringTypesTransformer)) == 1
    # no transformation
    assert len(Py27Transformation(_ast.parse('unicode')).transform(StringTypesTransformer)) == 0

# Generated at 2022-06-12 04:02:26.686943
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_astunparse

# Generated at 2022-06-12 04:02:31.309926
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    src = """
    x = str
    """

    tree = ast.parse(src)
    r = StringTypesTransformer.transform(tree)
    assert r.tree_changed

    assert astor.to_source(r.new_tree).strip() == """
    x = unicode
    """.strip()

# Generated at 2022-06-12 04:02:35.975746
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """'string'"""
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    assert transformer.transform(tree).tree_changed == False

    code = """'string' + str ('string')"""
    tree = ast.parse(code)
    transformer = StringTypesTransformer()
    assert transformer.transform(tree).tree_changed == True

# Generated at 2022-06-12 04:02:43.752606
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse(
        """def foo():
            x = str(42)
        """
    )

    tree_ = tree
    m = StringTypesTransformer(2, 7)
    t = m.transform(tree)
    assert t.tree is not tree_
    assert str(tree_) == str(ast.parse(
        """def foo():
            x = unicode(42)
        """
    ))

# Generated at 2022-06-12 04:02:47.122600
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    node = ast.parse("x = str(y)")
    res = StringTypesTransformer.transform(node)
    assert res.tree_changed is True
    assert "x = unicode(y)" == astor.to_source(res.tree)
    assert res.warnings == []


# Generated at 2022-06-12 04:02:54.988300
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_astunparse
    source = '''
a = str(b)
'''
    expected_source = '''
a = unicode(b)
'''
    tree = ast.parse(source)
    new_tree = StringTypesTransformer.transform(tree)
    assert typed_astunparse.unparse(new_tree.tree) == expected_source
    assert new_tree.tree_changed
    assert new_tree.dependent_trees == []

# Generated at 2022-06-12 04:02:58.361424
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str('hello')")
    res, _, _ = StringTypesTransformer.transform(tree)

    assert ast.dump(res) == ast.dump(ast.parse("unicode('hello')"))


# Generated at 2022-06-12 04:03:04.466943
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # input
    code = '''
a = str(1)
'''
    # expected output
    expected_code = '''
a = unicode(1)
'''

    # check
    result = StringTypesTransformer.transform(ast.parse(code))
    transformed_code = astor.to_source(result.tree).rstrip()
    assert transformed_code == expected_code
    assert result.report == []

# Generated at 2022-06-12 04:03:08.833372
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    code = "xs = [str(x) for x in xs]"
    expected_code = "xs = [unicode(x) for x in xs]"

    # When
    actual_tree = ast.parse(code)
    StringTypesTransformer.transform(actual_tree)
    actual_code = astor.to_source(actual_tree)

    # Then
    assert actual_code == expected_code

# Generated at 2022-06-12 04:03:17.192715
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer."""

    # Set up the input and expected output
    code = ("a = str('1')\n"
            "b = unicode('2')")
    expected_code = ("a = unicode('1')\n"
                     "b = unicode('2')")

    # Parse the code
    module_ast = ast.parse(code)

    class MockFile():
        pass

    # Perform the transformation
    transformer = StringTypesTransformer()
    result = transformer.transform(module_ast, MockFile())

    # Assert that the code was changed appropriately
    assert expected_code == astor.to_source(result.tree)

# Generated at 2022-06-12 04:03:23.923867
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
      class Test():
          def __init__(self):
              self.test = str()
    """
    tree = ast.parse(code)
    res = StringTypesTransformer.transform(tree)
    assert res.tree_changed
    assert res.warnings == []
    assert res.tree.body[0].body[0].value.keywords[0].value.id == 'unicode'
    assert res.tree.body[0].body[0].value.id == 'unicode'

# Generated at 2022-06-12 04:03:27.558096
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    #from ...unit_test_utils import get_ast

# Generated at 2022-06-12 04:03:28.446898
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:33.041683
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('a = unicode()')
    assert StringTypesTransformer.transform(tree).tree_changed

# Generated at 2022-06-12 04:03:33.779392
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:03:37.026858
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = \
"""
str(1)
"""
    expectation = \
"""
unicode(1)
"""
    with_change = StringTypesTransformer.transform(code)
    assert_node(with_change.tree, expectation)

# Generated at 2022-06-12 04:03:37.897595
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:03:48.860796
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:55.793767
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ..utils.source_code import source_to_ast
    import textwrap
    source = textwrap.dedent("""
        code = str(1)
        """)
    expected = ast3.parse(textwrap.dedent("""
        code = unicode(1)
        """))
    transformed, lines_to_patch = StringTypesTransformer.transform(source_to_ast(source))
    assert ast3.dump(transformed) == ast3.dump(expected)
    assert lines_to_patch == []

# Generated at 2022-06-12 04:03:56.366224
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:03:59.221526
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """TestClass for StringTypesTransformer."""
    transformer = StringTypesTransformer()
    assert transformer.target == (2, 7)
    assert transformer.name == 'StringTypesTransformer'
    assert transformer.description ==\
        'Replaces str with unicode. '


# Generated at 2022-06-12 04:04:06.928737
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3
    from ..utils.tree import compare

    # Test function
    def test_func():
        str_1 = 'hello'
        str_2 = 'world'
        return str_1 + str_2
    tree = ast3.parse(inspect.getsource(test_func))

    # Apply the transformer
    tree_modified = StringTypesTransformer.transform(tree)
     
    # Construction check

# Generated at 2022-06-12 04:04:10.261757
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_code = """
    x = str(4)
    """

    expected_code = """
    x = unicode(4)
    """

    result = StringTypesTransformer.transform(ast.parse(test_code))
    assert result.tree == ast.parse(expected_code)

# Generated at 2022-06-12 04:04:21.053619
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer
    code = """a = str('hello')\n"""
    expected_code = """a = unicode('hello')\n"""
    tree = ast.parse(code)
    new_tree = transformer.transform(tree)
    #print(ast.dump(new_tree))
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-12 04:04:21.782402
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:04:30.412136
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test = """
        class MyClass:
            def __init__(self):
                self.value = 'test'
                print('test')

        def foo(x: str) -> None:
            pass

        print('test')
        """

    expected_result = """
        class MyClass:
            def __init__(self):
                self.value = u'test'
                print(u'test')

        def foo(x: unicode) -> None:
            pass

        print(u'test')
        """

    tree = ast.parse(test)
    assert str(StringTypesTransformer.transform(tree).tree) == expected_result

# Generated at 2022-06-12 04:04:33.562909
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """This is a test method to test the constructor of class
    StringTypesTransformer.
    """
    transformer = StringTypesTransformer()
    assert (transformer.target_versions == (2, 7))

# Generated at 2022-06-12 04:04:40.576996
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import textwrap
    code_snippet = textwrap.dedent('''\
        print(str)
        ''')
    desired_code_snippet = textwrap.dedent('''\
        print(unicode)
        ''')
    ast_tree = ast.parse(code_snippet)
    ast_tree = StringTypesTransformer.transform(ast_tree)
    desired_ast_tree = ast.parse(desired_code_snippet)
    assert ast_tree.code == desired_ast_tree.code

# Generated at 2022-06-12 04:04:47.428228
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import unittest
    from typed_ast.ast3 import Str, Name

    class TestStringTypesTransformer(unittest.TestCase):
        def test_transform(self):
            from ..utils.source import source_to_ast
            from .backport_inspect import InspectTransformer

            source_1 = ("print str('Hello world')\n")
            tree_1 = source_to_ast(source_1)
            tree_1 = StringTypesTransformer.transform(tree_1)[0]
            tree_1 = InspectTransformer.transform(tree_1)[0]

            self.assertEqual(tree_1.body[0].value.s, 'Hello world')
            self.assertEqual(type(tree_1.body[0].value), Str)

            # Test a simple case

# Generated at 2022-06-12 04:04:48.684027
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:04:57.313435
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .test_base import test_transformer
    from tools.pytree import pytree

    test_tree = pytree("""
    def test(a: str) -> str:
        return a
    """)

    test_transformer(StringTypesTransformer, test_tree, """
    def test(a: unicode) -> unicode:
        return a
    """)

    test_tree = pytree("""
    def test(a: str) -> str:
        b = 'ok'
        return b
    """)

    test_transformer(StringTypesTransformer, test_tree, """
    def test(a: unicode) -> unicode:
        b = 'ok'
        return b
    """)

# Generated at 2022-06-12 04:05:03.422418
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code_fragment = '''
    def my_function():
        return "Hello"
    '''

    tree = ast.parse(code_fragment)

    result_tree = StringTypesTransformer.transform(tree)

    as_expected = ast.parse('''
    def my_function():
        return "Hello"
    ''')

    assert ast.dump(result_tree.tree) == ast.dump(as_expected)

# Generated at 2022-06-12 04:05:11.967105
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typing import Any
    from ..utils.tree import dump
    from ..types import TransformationResult
    import unittest

    class TestStringTypesTransformer(unittest.TestCase):
        def runTest(self):
            tree = ast.parse("assert isinstance(x, str)")
            expected = ast.parse("assert isinstance(x, unicode)")
            actual = StringTypesTransformer.transform(tree)
            assert isinstance(actual, TransformationResult)
            assert actual.tree != tree
            assert dump(actual.tree) == dump(expected)

    test = TestStringTypesTransformer()
    test.runTest()

# Generated at 2022-06-12 04:05:25.400948
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass

# Generated at 2022-06-12 04:05:31.847698
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class TestTransformerGenerator(StringTypesTransformer):
        def __init__(self):
            self.test_variable = 1
        
    tree = ast.parse('str_variable = "test"')
    expected_tree = ast.parse('str_variable = "test"')
    transformer = TestTransformerGenerator()
    transformed_tree, tree_changed, messages = transformer.transform(tree)
    assert transformed_tree == expected_tree

# Generated at 2022-06-12 04:05:36.671442
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .. import transform
    from ..utils import dump_ast
    from ..utils.test_fixtures import with_fixtures
    from ..migrate_tools_test import assert_equivalent_asts

    @with_fixtures(['StringTypesTransformer_001.py'])
    def test(before, after):
        """Replace all occurrences of `str` with `unicode`."""
        tree = transform(
            before,
            transformers=[StringTypesTransformer])
        assert_equivalent_asts(tree, after)

    test()


# Generated at 2022-06-12 04:05:38.094813
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert isinstance(StringTypesTransformer, type)


# Generated at 2022-06-12 04:05:42.663368
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    code = '''
            def my_func(a: str, b: str) -> str:
                c = a + b
                return c
            '''
    tree = ast.parse(code)
    new_tree, tree_changed, error_msgs = StringTypesTransformer.transform(tree)
    assert tree_changed

# Generated at 2022-06-12 04:05:43.958941
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Tested by StringTypesTest in test_transformers.py
    assert StringTypesTransformer

# Generated at 2022-06-12 04:05:49.177685
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Setup
    test_input = '''
            class testStringTypes(object):
                def __init__(self, someStr: str):
                    pass
            '''
    expected_output = '''
            class testStringTypes(object):
                def __init__(self, someStr: unicode):
                    pass
            '''
    # Exercise
    actual_output = StringTypesTransformer.transform(test_input, (3, 0))
    # Verify
    assert expected_output == actual_output

# Generated at 2022-06-12 04:05:58.106196
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..modifiers.basic import BaseModifier
    from ..modifiers.sample import SampleModifier
    from ..modifiers.transformer import TransformerModifier
    from ..context import Context
    from ..utils.tree import to_source
    from .base import generate_transformer_test

    source = """
x = str(2)
"""
    expected_source = """
x = unicode(2)
"""
    tree = ast.parse(source)
    modifier = TransformerModifier(BaseModifier([StringTypesTransformer()]))
    ctx = Context()

    new_tree = modifier.modify(tree, ctx)
    assert to_source(new_tree) == expected_source


# Generated at 2022-06-12 04:06:02.981052
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_code = "from __future__ import print_function\nprint isinstance('Hello, World!', str)"
    tree = ast.parse(test_code)
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    exec(compile(result.tree, filename="<ast>", mode="exec"), {})
    assert result.warnings == []

# Generated at 2022-06-12 04:06:10.514468
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():                                                                                                                                             
    from ..utils import test_utils
    test_utils.run_test_str(StringTypesTransformer,
                            """                                               
                            class A():                                         
                                def test(self):                                
                                    a = str(1)                                 
                            """,
                            """                                               
                            class A():                                         
                                def test(self):                                
                                    a = unicode(1)                              
                            """)

# Generated at 2022-06-12 04:06:40.030755
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = """
    def foo(a='a'):
        return str(a)
    """
    tree = ast.parse(source)
    tr = StringTypesTransformer.transform(tree)
    assert tr.tree_changed
    assert tr.import_statements == []
    assert tr.source == """
    def foo(a='a'):
        return unicode(a)
    """

# Generated at 2022-06-12 04:06:49.569796
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast_pprint import dump
    from ..utils.test import assert_transformation
    from ...tests.test_transformers.test_helpers import assert_code_same
    from ...tests.test_transformers.test_helpers import assert_code_different

    assert_transformation(StringTypesTransformer, 'str')
    assert_transformation(StringTypesTransformer, 'a = str()')
    assert_transformation(StringTypesTransformer, 'a = str("string")')
    assert_transformation(StringTypesTransformer, 'a = str("string").split("r")')
    
    assert_code_same(StringTypesTransformer, 'a = 1')
    assert_code_same(StringTypesTransformer, 'a = "str"')

# Generated at 2022-06-12 04:06:51.699255
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class_ = StringTypesTransformer()
    assert class_.replace_type == ast.Name
    assert class_.replace_with == 'unicode'
    assert class_.target == (2, 7)

# Generated at 2022-06-12 04:06:54.369926
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('hello = "world!"')
    new_tree = StringTypesTransformer.transform(tree)

    assert new_tree.tree_transformed == True, "StringTypesTransformer did not transform a tree"

# Generated at 2022-06-12 04:07:01.180403
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    "Testing StringTypesTransformer class"
    class A:
        pass

    assert StringTypesTransformer.transform(ast.parse('a = str(1)')) == TransformationResult(ast.parse('a = unicode(1)'), True, [])
    assert StringTypesTransformer.transform(ast.parse('a = A')) == TransformationResult(ast.parse('a = A'), False, [])
    assert StringTypesTransformer.transform(ast.parse('a = 1')) == TransformationResult(ast.parse('a = 1'), False, [])
    assert StringTypesTransformer.transform(ast.parse('a = A()')) == TransformationResult(ast.parse('a = A()'), False, [])

# Generated at 2022-06-12 04:07:04.540116
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'a = str()'
    tree = ast.parse(code)
    StringTypesTransformer.transform(tree)
    code = compile(tree, '<string>', 'exec')
    exec(code)
    assert a == unicode()
    return True


# Generated at 2022-06-12 04:07:08.750272
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # pylint: disable=no-init
    assert issubclass(StringTypesTransformer, BaseTransformer)
    assert StringTypesTransformer.__name__ == 'StringTypesTransformer'
    assert StringTypesTransformer.__doc__ is not None
    assert StringTypesTransformer.transform.__doc__ is not None

# Generated at 2022-06-12 04:07:10.406489
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    a = StringTypesTransformer()
    assert(a)


# Generated at 2022-06-12 04:07:11.996209
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    string_types_transformer = StringTypesTransformer()
    assert string_types_transformer.target == (2, 7)

# Generated at 2022-06-12 04:07:14.175029
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests instantiating `StringTypesTransformer`.
    """
    assert StringTypesTransformer(True)

# Generated at 2022-06-12 04:08:13.092119
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_ast = ast.parse("str")
    expected_ast = ast.parse("unicode")
    assert StringTypesTransformer.transform(input_ast) == TransformationResult(expected_ast, True, [])

# Generated at 2022-06-12 04:08:14.114089
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Tests for constructor of class StringTypesTransformer"""


# Generated at 2022-06-12 04:08:20.169334
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast27
    from .base import BaseASTRewriter
    code = "def f(): return str('')\n"
    tree = ast.parse(code)
    rewriter = BaseASTRewriter()
    tree = rewriter.visit(tree)
    assert code == ast27.unparse(tree)
    rewriter.rewrite(tree, StringTypesTransformer)
    assert 'def f(): return unicode(\'\')\n' == ast27.unparse(tree)

# vim: et sw=4 sts=4

# Generated at 2022-06-12 04:08:29.671411
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = '''
    class Test:
        def __init__(self, name: str):
            print(name)

        def test(self, name: str):
            print(name)

    Test("s")
    '''
    node = ast.parse(code)
    StringTypesTransformer.transform(node)
    print(ast.dump(node))

    class_def_node = node.body[0]

    assert type(class_def_node) is ast.ClassDef and class_def_node.name == 'Test'
    assert len(class_def_node.body) == 2
    assert type(class_def_node.body[0]) is ast.FunctionDef and class_def_node.body[0].name == '__init__'

# Generated at 2022-06-12 04:08:34.837264
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = 'x = str("a")'
    tree = ast.parse(code, mode='exec')

    transformer = StringTypesTransformer()
    new_tree, _ = transformer.transform(tree)

    import astpp
    print(astpp.dump(new_tree))

    exec(compile(new_tree, filename="<ast>", mode="exec"))

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:08:44.494584
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ast import parse
    from .base import BaseTestTransformer
    source = '''
        a = str(1)
        b = str()
        c = str(b)
        d = ""
        e = 'c'
        f = "str"
        
        class G:
            pass
    '''
    tree = parse(source)
    result = StringTypesTransformer.transform(tree)
    expected_source = '''
        a = unicode(1)
        b = unicode()
        c = unicode(b)
        d = u""
        e = u'c'
        f = u"str"
        
        class G:
            pass
    '''
    assert(expected_source == BaseTestTransformer.reconstruct_source(result.new_tree))

test_StringTypesTransformer()

# Generated at 2022-06-12 04:08:50.877157
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for the constructor of class StringTypesTransformer
    """
    t = StringTypesTransformer()
    assert t.target == (2, 7)

    # no output file name specificed
    with pytest.raises(Exception) as e:
        t.transform(None)
    assert "Output file name is not set" in str(e.value)
    assert t.transform(ast.parse("str")) == TransformationResult(ast.parse("str"), False, [])

    # invalid file extension
    with pytest.raises(Exception) as e:
        t.transform(ast.parse("str"), "tmp")
    assert "Only .py files are allowed" in str(e.value)
    assert t.transform(ast.parse("str"), "tmp.txt") == TransformationResult(ast.parse("str"), False, [])



# Generated at 2022-06-12 04:08:58.199972
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # NOTE: Some tests, like this one, do not work anymore, due to the fact that eval(...)
    # does not work anymore in Python 3.8. Using the compiler library to compile the code
    # and get the AST does not help, because for this case the compiler library does not 

    # Success case
    assert eval(repr(StringTypesTransformer.transform(parse('str(1)'))[0])) == unicode(1)
    assert eval(repr(StringTypesTransformer.transform(parse('len(str(1))'))[0])) == len(unicode(1))

# Generated at 2022-06-12 04:08:59.991837
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tt = StringTypesTransformer()
    assert tt.target == (2, 7)


# Generated at 2022-06-12 04:09:04.775160
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert_equal(str(StringTypesTransformer.transform(ast.parse("str(x)")[0])), "Expr(value=Call(func=Name(id='unicode', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[], starargs=None, kwargs=None))")

# Generated at 2022-06-12 04:11:20.093591
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:11:22.468633
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    node = StringTypesTransformer.transform(
        ast.parse('a = str(b)', mode='exec')).tree
    assert astor.to_source(node) == 'a = unicode(b)'

# Generated at 2022-06-12 04:11:26.974911
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    old_tree = ast.parse(
        """
a = str(a)
b = str()
c = str
"""
    )
    new_tree = ast.parse(
        """
a = unicode(a)
b = unicode()
c = unicode
"""
    )
    transformer = StringTypesTransformer()
    assert transformer.transform(old_tree) == new_tree

# Generated at 2022-06-12 04:11:30.130897
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = "str()"
    tree = ast.parse(code)
    new_tree = StringTypesTransformer.transform(tree)
    new_code = compile(new_tree, '', 'exec').body.s
    assert new_code == "unicode()"

# Generated at 2022-06-12 04:11:39.454054
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from typed_ast import ast3 as ast
    from .utils import ast_to_str, _compare, check_annotation

    source = "foo = str()"
    expected = "foo = unicode()"
    _compare(ast_to_str(source), ast_to_str(expected),
             lambda node: StringTypesTransformer.transform(node))

    source = "def foo():\n    return (str, False)"
    expected = "def foo():\n    return (unicode, False)"
    _compare(ast_to_str(source), ast_to_str(expected),
             lambda node: StringTypesTransformer.transform(node))

    source = "def foo():\n    str = None"
    expected = "def foo():\n    str = None"

# Generated at 2022-06-12 04:11:46.200628
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    tt = StringTypesTransformer()
    tree = astor.parse("""
        str('hello')
        """

        )
    tree2 = tt.transform(tree)
    assert astor.to_source(tree2) == """
    unicode('hello')
    """
    # Do a second time to test if the object is callable
    tree3 = tt.transform(tree2)
    assert astor.to_source(tree2) == """
    unicode('hello')
    """
    # Test if the object is callable