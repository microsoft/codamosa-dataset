

# Generated at 2022-06-12 04:01:52.521650
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer"""
    # Test Python version
    assert StringTypesTransformer.transform(2, 7)

    # Test Python version
    assert not StringTypesTransformer.transform(3, 5)

    # Test transformation
    original_code = """
        def foo(name):
            return 'Hello ' + name
    """
    transformed_code = """
        def foo(name):
            return u'Hello ' + name
    """
    tree = ast.parse(original_code)
    assert StringTypesTransformer.transform(tree) == transformed_code


# Generated at 2022-06-12 04:01:55.773410
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # a very simple test, more will be added soon
    class TestStringTypes(StringTypesTransformer):
        @property
        def target_ast_version(self):
            return (2,7)

# Generated at 2022-06-12 04:02:03.149171
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .fake_ast import FakeNode

    tree = FakeNode("f",
                    args = FakeNode("args1", args = [FakeNode("a", id = "str")]),
                    kwargs = FakeNode("kwargs1", keywords = [FakeNode("kwarg", arg = "str", value = 3)]))

    tr = StringTypesTransformer.transform(tree)
    assert tr.tree.args.args[0].id == "unicode"
    assert tr.tree.kwargs.keywords[0].arg == "unicode"

# Generated at 2022-06-12 04:02:10.852384
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class MyClass:
        pass

    assert str(MyClass) == "<class '__main__.MyClass'>"
    assert type(str(MyClass)) == str
    assert isinstance(str(MyClass), str)

    # Can't do this.
    #class MyClass:
    #    def __init__(self):
    #        self.__doc__ = str(MyClass)
    #
    #assert MyClass.__doc__ == "<class '__main__.MyClass'>"


# Generated at 2022-06-12 04:02:16.513420
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for class StringTypesTransformer.

    """
    import six
    import io

    code = six.u('my_string = "hello"')
    expected = six.u('my_string = u"hello"')

    tree = ast.parse(code)
    out = io.StringIO()

    t = StringTypesTransformer()
    result = t.transform(tree)

    if result.changed:
        ast.fix_missing_locations(result.tree)
        six.exec_(compile(result.tree, '<ast>', 'exec'))

    assert out.getvalue() == expected

# Generated at 2022-06-12 04:02:21.645070
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    code = """str()"""

    tree = ast.parse(code)
    tree = StringTypesTransformer.transform(tree)

    expected_code = """unicode()"""

    assert normalize_code(expected_code) == normalize_code(astunparse.unparse(tree[0]))

# Generated at 2022-06-12 04:02:22.552553
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:02:29.580015
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    cls = StringTypesTransformer
    assert cls.target == (2, 7)

    @cls()
    def test_foo():
        return str('string')  # noqa

    assert test_foo.func_code.co_consts[0] == 'string'
    assert test_foo() == 'string'

    @cls(target=(3, 5))
    def test_foo():
        return str('string')  # noqa

    # transformer shouldn't be applied because target is above the
    # version of the transformer
    assert test_foo.func_code.co_consts[0] == 'string'
    assert test_foo() == 'string'

    @cls(target=(2, 7), no_default=True)
    def test_foo():
        return str('string')  # noqa

   

# Generated at 2022-06-12 04:02:38.039694
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # The test code
    statement = "print('Hi')"
    expected_string = "print(u'Hi')"
    # Use astor to parse string into code object
    expected_object = astor.code_to_ast.parse_string(expected_string)
    expected_object.body[0].lineno = 1
    expected_object.body[0].col_offset = 0
    # Expected object is a call object with 2 arguments
    assert len(expected_object.body) == 1
    # First argument is 'print'
    first_arg = expected_object.body[0].value.func
    assert type(first_arg) is ast.Name
    # The function called is called 'print'
    assert first_arg.id == 'print'
    # The second argument is 'u'
    second_arg = expected_

# Generated at 2022-06-12 04:02:46.941459
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import typed_ast.ast3 as ast
    from os import path
    from .base import BaseASTVisitor

    class TestVisitor(BaseASTVisitor):
        def visit_Name(self, node):
            if node.id == 'str':
                node.id = 'unicode'

    tree = ast.parse('a = str()')
    TestVisitor().visit(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='unicode', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-12 04:03:00.433399
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .testutils import make_basic_block, make_class_def_node, make_function_def_node

    # Checking transformation of class
    tree = make_basic_block(['', 'class StrClass(str):', ' pass'])
    new_tree, tree_changed = StringTypesTransformer.transform(tree)
    assert tree_changed
    st = ast.Str('unicode')
    class_node = make_class_def_node(name='StrClass', args=st)
    assert new_tree.body[0].body[0] == class_node

    # Checking transformation of functions
    tree = make_basic_block(['', 'def my_func(a, b, str):', ' pass'])
    new_tree, tree_changed = StringTypesTransformer.transform(tree)
    assert tree_changed
   

# Generated at 2022-06-12 04:03:01.360237
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:08.375870
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Create a StringTypesTransformer object
    StringTypesTransformer_obj = StringTypesTransformer()
    assert StringTypesTransformer_obj
    # Test if object's transformation method works as expected
    tree = ast.parse('a = [str(x) for x in range(3)]')
    assert not StringTypesTransformer_obj.transform(tree).tree_changed
    tree = ast.parse('print(str(x))')
    assert not StringTypesTransformer_obj.transform(tree).tree_changed
    tree = ast.parse('b = [str(x) for x in range(3)]')
    assert not StringTypesTransformer_obj.transform(tree).tree_changed

# Generated at 2022-06-12 04:03:14.626781
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    source = ''' 
    my_str = str(12)
    print(type(my_str))
    '''
    tree = ast.parse(source)
    res = StringTypesTransformer().transform(tree)
    code = compile(res.tree, '', 'exec')
    ns = {}
    exec(code, ns)
    assert ns['my_str'] == u'12'
    assert type(ns['my_str']) == type(u'here')



# Generated at 2022-06-12 04:03:24.978802
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .utils import make_call_expression
    from .test_base import BaseTransformerTestCase

    class TestStringTypesTransformer(BaseTransformerTestCase):
        def setUp(self):
            self.transformer = StringTypesTransformer()

        def test_Name(self):
            src = 'str'
            expected = 'unicode'
            self.assertEqual(self.transform(src), expected)

        def test_TypeFunction(self):
            src = 'def foo(bar: str): pass'
            expected = 'def foo(bar: unicode): pass'
            self.assertEqual(self.transform(src), expected)

        def test_CallFunction(self):
            src = 'foo(str)'
            expected = 'foo(unicode)'
            self.assertEqual(self.transform(src), expected)



# Generated at 2022-06-12 04:03:29.501536
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    ast_code = """
    def func():
        a = str()
        return str('hello')
    """
    ast_tree = ast.parse(ast_code)
    t = StringTypesTransformer()
    new_ast_tree = t.transform(ast_tree)
    assert new_ast_tree.tree_changed == True



# Generated at 2022-06-12 04:03:30.502668
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # TODO: Test
    pass

# Generated at 2022-06-12 04:03:34.279416
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    test_code = '''
test = str('test')
    '''
    expected_result = '''
test = unicode('test')
    '''
    tree = ast.parse(test_code)
    new_tree = StringTypesTransformer.transform(tree)
    assert ast.dump(new_tree.tree) == expected_result



# Generated at 2022-06-12 04:03:35.181526
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:36.559962
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor


# Generated at 2022-06-12 04:03:47.754625
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Create an instance of StringTypesTransformer class
    transformer = StringTypesTransformer()
    # Assert the transformer class name is as expected
    assert transformer.__class__.__name__ == 'StringTypesTransformer'
    # Assert the target tuple is as expected
    assert transformer.target == (2, 7)
    # Assert the transformer method name is as expected
    assert transformer.transform.__name__ == 'transform'
    # Assert the documentation string of the transformer method is as expected
    assert transformer.transform.__doc__ == 'Replaces `str` with `unicode`.'

# Generated at 2022-06-12 04:03:48.700995
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:50.077319
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:03:56.848537
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor

    # Test with a single-line code fragment and should not be changed except removing redundant space:
    code = 'str(a)'
    tree = ast.parse(code)
    expected = 'unicode(a)'
    new_tree, is_changed, report_or_code = StringTypesTransformer.transform(tree)
    assert astor.to_source(new_tree).strip() == expected
    assert is_changed == True

    # Test with a multi-line code fragment and should not be changed:

# Generated at 2022-06-12 04:04:08.810848
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .declaration import declarations
    from .miscellaneous import imports_from

    from ..utils.tree import to_dot
    from ..utils.source import gen_source

    # NOTE: we want to keep the actual node object reference,
    # so be careful when modifying the tree

    tree1 = ast.parse("""
x = str(12)
""")

    tree1 = ast.fix_missing_locations(tree1)
    tree1 = imports_from.transform(tree1)[0]
    tree1 = declarations.transform(tree1)[0]
    tree1 = StringTypesTransformer.transform(tree1)[0]

    assert gen_source(tree1) == """\
from __future__ import absolute_import, division, print_function, unicode_literals

x = unicode(12)
"""

    # The example from

# Generated at 2022-06-12 04:04:09.352497
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    pass



# Generated at 2022-06-12 04:04:11.894452
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str('test')")
    result = StringTypesTransformer.transform(tree)
    try:
        assert result.tree_changed
    except AssertionError:
        print("StringTypesTransformer not working")

# Generated at 2022-06-12 04:04:12.769425
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:04:21.321042
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:04:25.570388
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = "a = str()"
    result = "a = unicode()"

    tree = ast.parse(s)
    tree = StringTypesTransformer.transform(tree).tree

    assert ast.dump(tree) == ast.dump(ast.parse(result))

# Generated at 2022-06-12 04:04:32.959776
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Test string type transformer.
    """

# Generated at 2022-06-12 04:04:37.161232
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse('def func():\n  return str()')
    new_tree = StringTypesTransformer.transform(tree)

    assert new_tree.tree_changed
    assert ast.dump(new_tree.tree) == ast.dump(ast.parse('def func():\n  return unicode()'))

# Generated at 2022-06-12 04:04:42.568565
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    stringTypesTransformer = StringTypesTransformer()
    code = """
    def head(config):
        name = "Hello World"
        print(name)
    """
    tree = ast.parse(code)
    assert stringTypesTransformer.transform(tree) == TransformationResult(
        ast.parse("""
    def head(config):
        name = u"Hello World"
        print(name)
    """), True, []
    )

# Generated at 2022-06-12 04:04:46.849719
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    module_ast = ast.parse("""
a = str(234)
b = str(2.3)
    """)
    tree_changed, messages, new_tree = StringTypesTransformer.transform(module_ast)
    assert new_tree is not module_ast
    assert tree_changed
    assert len(messages) == 0
    assert ast.dump(new_tree) == ast.dump(ast.parse("""
a = unicode(234)
b = unicode(2.3)
    """))

# Generated at 2022-06-12 04:04:49.824225
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astpretty
    tree = ast.parse('a = str(b)')
    tree = StringTypesTransformer.transform(tree).tree
    print(astpretty.pprint(tree))


# Unit test.
# verbose=True

# Generated at 2022-06-12 04:04:51.242180
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:04:56.220868
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """\
    def foo():
        s = str()
        assert isinstance(s, str)
    """
    ref_code = """\
    def foo():
        s = unicode()
        assert isinstance(s, unicode)
    """
    tt = pytransformer.from_string(StringTypesTransformer)
    assert tt.transform_code(code) == ref_code

# Generated at 2022-06-12 04:05:02.917299
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import ast
    import typed_ast.ast3 as ast3
    import typed_astunparse as astunparse
    tree = ast3.parse('''f('abc')''', mode='exec')
    ast.fix_missing_locations(tree)
    print(astunparse.unparse(tree))
    tree = StringTypesTransformer.transform(tree)
    print(astunparse.unparse(tree.tree))

if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:05:10.385633
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    source_code = """
    string = str()
    """

    # Transform source code
    tree = ast.parse(source_code)
    result = StringTypesTransformer.transform(tree)
    gen_code = compile(result.tree, filename="<ast>", mode="exec")

    # Execute code
    scope = {}
    exec(gen_code, {}, scope)

    # Result
    assert (scope['string'] == u"")

# StringTypesTransformer
test_StringTypesTransformer()

# Generated at 2022-06-12 04:05:16.016003
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Arrange
    program = textwrap.dedent('''\
    def func(s):
        return type(s)
    ''')
    tree = ast.parse(program)

    # Act
    new_program = StringTypesTransformer.transform(tree)

    # Assert
    assert(new_program.tree_changed is True)
    assert(ast.dump(new_program.tree) == ast.dump(ast.parse(textwrap.dedent('''\
    def func(s):
        return type(s)
    '''))))

# Generated at 2022-06-12 04:05:36.578681
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Test 1
    # Test case:
    #
    # str()
    #
    # Expected result:
    # 
    # unicode()
    
    tree = ast.parse('str()')
    tree_changed = StringTypesTransformer.transform(tree)

    tree_expected = ast.parse('unicode()')

    assert ast.dump(tree_changed, annotate_fields=False) == ast.dump(tree_expected, annotate_fields=False)
    assert tree_changed.tree_changed == True

    # Test 2
    # Test case:
    #
    # print str
    #
    # Expected result:
    # 
    # print unicode
    
    tree = ast.parse('print str')
    tree_changed = StringTypesTransformer.transform(tree)


# Generated at 2022-06-12 04:05:46.581985
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    transformer = StringTypesTransformer()
    # tree = ast.parse('str')
    # print(ast.dump(transformer.transform(tree)[0]))
    assert str(transformer.transform(ast.parse('str'))[0]) == \
           str(ast.parse('unicode'))
    # print(ast.dump(ast.parse('str')))
    assert str(transformer.transform(ast.parse('var = str()'))[0]) == \
           str(ast.parse('var = unicode()'))
    assert str(transformer.transform(ast.parse('var = str(12)'))[0]) == \
           str(ast.parse('var = unicode(12)'))

if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:05:50.217775
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """
    Unit test for constructor of class StringTypesTransformer
    """

    tree = ast.parse('str(5) + "hello"', mode="exec")
    trans = StringTypesTransformer()
    assert trans.transform(tree)
    assert not trans.errors


# Generated at 2022-06-12 04:05:52.710269
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_str


# Generated at 2022-06-12 04:05:59.118149
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    input_ast = ast.parse("bar = str(foo)")
    expected_ast = ast.parse("bar = unicode(foo)")
    expected_diff = ""

    actual_result = StringTypesTransformer.transform(input_ast)
    actual_ast, actual_diff = actual_result.tree, actual_result.diff

    print("actual_ast")
    print(ast.dump(actual_ast))
    print("expected_ast")
    print(ast.dump(expected_ast))
    assert ast.dump(actual_ast) == ast.dump(expected_ast)

# Generated at 2022-06-12 04:06:04.173210
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Given
    tree = ast.parse('str is a type')
    transformer = StringTypesTransformer()

    # When
    result = transformer.transform(tree)
    actual = compile(result.tree, '', 'exec')

    # Then
    ns = {}
    exec(actual, ns)
    assert ns['__builtins__']['unicode'] is unicode

# Generated at 2022-06-12 04:06:11.430321
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    import astor
    from ast_helper import parse

    input_str = '''
a = str(1)
b = str(3.0)
    '''
    expected_output_src = '''
a = unicode(1)
b = unicode(3.0)
    '''
    tree = parse(input_str)
    result = StringTypesTransformer.transform(tree)
    assert astor.to_source(result.tree) == expected_output_src
    assert result.tree_changed == True

# Generated at 2022-06-12 04:06:13.020859
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('str')).tree == ast.parse('unicode')

# Generated at 2022-06-12 04:06:16.835718
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse('''
        def foo(bar):
            return str(bar)
    ''')) == TransformationResult(ast.parse('''
        def foo(bar):
            return unicode(bar)
    '''), True, [])

# Generated at 2022-06-12 04:06:23.909258
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    tree = ast.parse("str('test')")
    result = StringTypesTransformer.transform(tree)
    assert result.tree_changed
    assert result.added_imports == []
    assert result.tree.body[0].value.func.id == 'unicode'
    print("test_StringTypesTransformer: PASS")

# Invoke test for class StringTypesTransformer
if __name__ == '__main__':
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:06:55.111297
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():

    # Making an AST
    tree = ast.parse('var = str(123)')

    # Transforming it
    tree_transformed, changed, issues = \
        StringTypesTransformer.transform(tree)

    # Checking the transformation
    assert changed
    assert issues == []
    assert ast.dump(tree_transformed) \
        == ast.dump(ast.parse('var = unicode(123)'))

# Generated at 2022-06-12 04:07:01.437161
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = textwrap.dedent("""
        a = str(1)
        b = "a".decode("ascii")
        c = isinstance(b, str)
    """)
    tree = ast.parse(code)
    result = StringTypesTransformer.transform(tree)

    assert result.tree_changed
    assert result.migration_error_infos == []
    assert result.tree.body[0].value.func.id == 'unicode'
    assert result.tree.body[1].value.func.attr == 'decode'
    assert result.tree.body[2].value.args[1].id == 'unicode'

# Generated at 2022-06-12 04:07:07.797409
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.source import generate_source
    from ..utils.tree import print_to_string
    
    tree = ast.parse('''
        def foo(s: str):
            return s + 's'
        ''')

    print(print_to_string(tree))
    new_tree = StringTypesTransformer.transform(tree)
    print(print_to_string(new_tree.tree))
    print(generate_source(new_tree.tree))

test_StringTypesTransformer()

# Generated at 2022-06-12 04:07:11.538381
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from collections import namedtuple
    MyChange = namedtuple('MyChange', 'old new')

    assert StringTypesTransformer.transform(ast.parse('str')) == TransformationResult(
        ast.parse('unicode'), True, [MyChange('str', 'unicode')])

# Generated at 2022-06-12 04:07:13.071256
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    assert StringTypesTransformer.transform(ast.parse("str('hello')").body[0].value)

# Generated at 2022-06-12 04:07:14.272288
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:07:19.818773
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    code = """
name = str(42)
if type(name) == str:
    print('hello')
test = name.strip('test')
"""
    transformed_code = """
name = unicode(42)
if type(name) == unicode:
    print('hello')
test = name.strip('test')
"""
    tree = ast.parse(code)

    transformed_tree = ast.parse(transformed_code)

    transformer = StringTypesTransformer()
    assert transformer.transform(tree) == transformer.transform(transformed_tree)

# Generated at 2022-06-12 04:07:29.556395
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..transforms import transform
    from ..utils.testing import ParseTestCase

    test_cases = [
        ('s = str()', 's = unicode()'),
        ('def foo(s: str):\n    print(s)',
         'def foo(s: unicode):\n    print(s)'),
        ('def foo(s: str, bar: str) -> str:\n    print(s)\n    return bar',
         'def foo(s: unicode, bar: unicode) -> unicode:\n    print(s)\n    return bar')
    ]

    for before, after in test_cases:
        class TestCase(ParseTestCase):
            transform = staticmethod(transform)
            target_version = (2, 7)
            transformer = StringTypesTransformer
            expected_output = after

       

# Generated at 2022-06-12 04:07:35.321896
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from libcst import parse_module
    from .utils import compare_ast
    string_types_transformer = StringTypesTransformer()
    for target_version in string_types_transformer.target:
        module_ast = parse_module("")
        transformed_ast, changed = string_types_transformer.transform(module_ast)
        assert changed is False
        assert compare_ast(module_ast, transformed_ast)



# Generated at 2022-06-12 04:07:41.542077
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test case 01
    tree = ast.parse("""\
        foo(a)
    """)
    tree_expected = ast.parse("""\
        foo(a)
    """)
    result = StringTypesTransformer.transform(tree)
    result_expected = TransformationResult(tree, False, [])
    assert result == result_expected

    # test case 02
    tree = ast.parse("""\
        foo(str(a))
    """)
    tree_expected = ast.parse("""\
        foo(unicode(a))
    """)
    result = StringTypesTransformer.transform(tree)
    result_expected = TransformationResult(tree_expected, True, [])
    assert result == result_expected

    # test case 03

# Generated at 2022-06-12 04:08:46.482215
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    original_code = \
"""
a = str(3)
"""
    expected_code = \
"""
a = unicode(3)
"""
    original_ast = ast.parse(original_code)
    expected_ast = ast.parse(expected_code)
    t = StringTypesTransformer()
    result, tree_changed = t.transform(original_ast)
    assert tree_changed
    assert ast.dump(result) == ast.dump(expected_ast)

# Generated at 2022-06-12 04:08:50.598687
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    s = "print(str(42))"
    tree = ast.parse(s)

    new_tree, _, errors = StringTypesTransformer().transform(tree)

    assert not errors

    import typed_ast.ast3 as ast3
    from ..utils.tree import compare_ast

    assert compare_ast(ast3.parse("print(unicode(42))"), new_tree)

# Generated at 2022-06-12 04:08:56.565600
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from . import compile_source
    from ..utils.tree import node_to_str
    tree = compile_source('''if isinstance(x, str):
    x = ''
else:
    x = u""''')
    tree = StringTypesTransformer.transform(tree)
    assert node_to_str(tree) == '''if isinstance(x, unicode):
    x = ''
else:
    x = u""'''

# Generated at 2022-06-12 04:08:58.245022
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # Transformer settings
    target = (2, 7)

    # Input

# Generated at 2022-06-12 04:09:02.556654
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from .base import BaseASTTest

    class Test(BaseASTTest):
        target_tree = ast.parse("def f(arg: str):\n    return arg")
        expected_tree = ast.parse("def f(arg: unicode):\n    return arg")

    Test().run(StringTypesTransformer)

# Generated at 2022-06-12 04:09:05.703142
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    '''string_types.py:To test the constructor of class StringTypesTransformer'''
    str_types_transformer = StringTypesTransformer()
    assert isinstance(str_types_transformer, StringTypesTransformer)


# Generated at 2022-06-12 04:09:15.684991
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
	class_name = "StringTypesTransformer"
	input_code = """
a = 1
b = "faisal"
c = str(a) + b
"""
	expect_code = """
a = 1
b = "faisal"
c = unicode(a) + b
"""
	utrans = StringTypesTransformer()
	py_version = "2"		
	utrans.set_py_version(py_version)
	trans_res = utrans.transform(input_code)
	trans_res.show_transformation(class_name, py_version, input_code, expect_code, trans_res.trans_tree)
	assert trans_res.trans_tree == expect_code



if __name__ == "__main__":
    test_StringTypesTransformer()

# Generated at 2022-06-12 04:09:16.472748
# Unit test for constructor of class StringTypesTransformer

# Generated at 2022-06-12 04:09:18.421239
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    from ..utils.testing import check_transformer

    check_transformer(StringTypesTransformer, 2, 7, 'x = str("x")')

# Generated at 2022-06-12 04:09:20.385167
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    # test for constructor
    a=StringTypesTransformer()
    assert(a.target==(2, 7))


# Generated at 2022-06-12 04:11:40.840392
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    class B: pass

    class A(B): pass

    assert issubclass(A, B)


# Generated at 2022-06-12 04:11:42.535304
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Simple unit testing for StringTypesTransformer class.
    
    """

# Generated at 2022-06-12 04:11:51.016148
# Unit test for constructor of class StringTypesTransformer
def test_StringTypesTransformer():
    """Unit test for constructor of class StringTypesTransformer"""
    # pylint: disable=protected-access
    assert StringTypesTransformer._target_version == (2, 7)