

# Generated at 2022-06-18 02:41:26.476871
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the test FX rate service.
            """
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:41:35.539082
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    service = TestFXRateService()
    rate

# Generated at 2022-06-18 02:41:43.140552
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))

# Generated at 2022-06-18 02:41:54.493500
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import InMemoryFXRateService

    ## Create an FX rate service:

# Generated at 2022-06-18 02:42:05.413311
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries]

    ## Create the FX rate service:
    service = TestFXRateService()

    ## Query the FX rate:

# Generated at 2022-06-18 02:42:14.904340
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    ## Create a test FX rate service:
    fx = TestFXRateService()

    ## Create a test query:

# Generated at 2022-06-18 02:42:26.462945
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    # Import required modules:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    # Define the FX rate service:
    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            # Return the FX rate:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:42:34.348561
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:42:45.365275
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService
    from pypara.fx.services import FXRateServiceImpl
    from pypara.fx.rates import FXRates
    from decimal import Decimal
    import datetime

    # Create the FX rate service
    service = FXRateServiceImpl(FXRates)

    # Query a rate
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date(datetime.date.today()))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == Date(datetime.date.today())
    assert rate.value == Decimal("1.12")

    # Query a rate with strict flag

# Generated at 2022-06-18 02:42:47.067251
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    pass


# Generated at 2022-06-18 02:43:01.149196
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from unittest import TestCase, mock
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:43:12.424733
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    service = TestFXRateService()

# Generated at 2022-06-18 02:43:14.702318
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    pass


# Generated at 2022-06-18 02:43:22.629034
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define the test case class:
    class FXRateServiceTestCase(TestCase):
        """
        Defines a test case for the queries method of the FXRateService class.
        """

        @mock.patch.object(FXRateService, "query")
        def test_queries_method(self, mock_query):
            """
            Tests the queries method of the FXRateService class.
            """
            ## Create the FX rate service:
            service = FXRateService()

            ## Create the queries:

# Generated at 2022-06-18 02:43:31.592226
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None] * len(queries)

    fxrates = TestFXRateService()
    assert list(fxrates.queries([(Currencies["EUR"], Currencies["USD"], Date.today())])) == [None]

# Generated at 2022-06-18 02:43:42.832266
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class FXRateServiceStub(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    service = FXRateServiceStub()
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today()) == FX

# Generated at 2022-06-18 02:43:55.310617
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    ## Create a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:44:01.211962
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    service = TestFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today()) is None
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today(), strict=True) is None


# Generated at 2022-06-18 02:44:12.666887
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    service = TestFXRateService()

# Generated at 2022-06-18 02:44:23.075730
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1"))


# Generated at 2022-06-18 02:44:41.096928
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates import FXRateLookupError
    from .fxrates import FXRate
    from decimal import Decimal

    class FXRateServiceMock(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2019, 1, 1), Decimal("1.1"))

# Generated at 2022-06-18 02:44:49.418559
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:44:58.047258
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:45:10.297156
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("1")) for ccy1, ccy2, asof in queries]

    service = TestFXRateService()

# Generated at 2022-06-18 02:45:17.582520
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None] * len(queries)

    assert list(TestFXRateService().queries([(Currencies["EUR"], Currencies["USD"], Temporal.today())])) == [None]

# Generated at 2022-06-18 02:45:26.995932
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    # Import required modules:
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    # Define a test FX rate service:
    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:45:38.380543
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.5"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    service = TestFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today()) == FXRate

# Generated at 2022-06-18 02:45:46.494327
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))
            elif ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("0.8"))

# Generated at 2022-06-18 02:45:57.100042
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries]

    ## Create a test FX rate service:
    service = TestFXRateService()

   

# Generated at 2022-06-18 02:46:04.782620
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceInMemory
    from .fxrates.models import FXRate

    # Create a foreign exchange rate service:
    fxrs = FXRateServiceInMemory()

    # Create a foreign exchange rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))

    # Add the foreign exchange rate to the service:
    fxrs.add(rate)

    # Query the foreign exchange rate:
    qrate = fxrs.query(Currencies["EUR"], Currencies["USD"], Date.today())

    # Check the foreign exchange rate:
    assert qrate == rate

    # Check the default foreign exchange rate service:
    assert FXRateService

# Generated at 2022-06-18 02:46:30.852800
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Create a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            return

# Generated at 2022-06-18 02:46:42.564199
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Date, Temporal
    from .fxrates import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the mock FX rate service.
            """
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:46:51.029292
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:47:02.493360
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:47:12.429413
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    ## Create the FX rate service:
    fxrs = TestFXRateService()

    ## Query the FX rate

# Generated at 2022-06-18 02:47:24.100062
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates.services import FXRateServiceImpl
    from .fxrates.repositories import FXRateRepositoryImpl

    ## Create the FX rate repository:
    repo = FXRateRepositoryImpl()

    ## Create the FX rate service:
    service = FXRateServiceImpl(repo)

    ## Create the queries:

# Generated at 2022-06-18 02:47:32.698177
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None] * len(queries)

    assert list(TestFXRateService().queries([(Currencies["EUR"], Currencies["USD"], Date.today())])) == [None]

# Generated at 2022-06-18 02:47:41.336277
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError
    from .commons.numbers import ONE, ZERO
    from .commons.zeitgeist import Date

    class TestFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)

# Generated at 2022-06-18 02:47:48.276816
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import InMemoryFXRateService
    from decimal import Decimal
    import datetime
    import unittest

    class TestFXRateService(unittest.TestCase):
        def test_queries(self):
            ## Create an FX rate service:
            fxrates = InMemoryFXRateService()

            ## Add some FX rates:
            fxrates.add(FXRate(Currencies["EUR"], Currencies["USD"], Date(datetime.date(2018, 1, 1)), Decimal("1.2")))
            fxrates.add(FXRate(Currencies["USD"], Currencies["EUR"], Date(datetime.date(2018, 1, 1)), Decimal("0.8")))


# Generated at 2022-06-18 02:47:59.306159
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """


# Generated at 2022-06-18 02:48:44.839400
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:48:52.714570
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.25"))

# Generated at 2022-06-18 02:49:02.957049
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    ## Create a mock FX rate service:
    service = MockFXRateService()

    ## Query a rate:

# Generated at 2022-06-18 02:49:12.447168
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    from unittest import TestCase, mock
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.2"))


# Generated at 2022-06-18 02:49:23.973300
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        def __init__(self, rates):
            self.rates = rates

        def query(self, ccy1, ccy2, asof, strict=False):
            if (ccy1, ccy2, asof) in self.rates:
                return self.rates[(ccy1, ccy2, asof)]
            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None

        def queries(self, queries, strict=False):
            for query in queries:
                yield self.query(query[0], query[1], query[2], strict)

   

# Generated at 2022-06-18 02:49:36.057099
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries]

    service = FXRateServiceImpl()

# Generated at 2022-06-18 02:49:41.026345
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates.services import FXRateService
    from .fxrates.services.memory import MemoryFXRateService
    from .fxrates.services.memory.loader import FXRateLoader
    from .fxrates.services.memory.loader.csv import CSVFXRateLoader
    from .fxrates.services.memory.loader.csv.reader import CSVFXRateReader
    from .fxrates.services.memory.loader.csv.reader.stream import CSVFXRateStreamReader
    from .fxrates.services.memory.loader.csv.reader.stream.file import CSVFXRateFileStreamReader
    from .fxrates.services.memory.loader.csv.reader.stream.file.path import CSVFXRateFilePathStreamReader

# Generated at 2022-06-18 02:49:46.319938
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """


# Generated at 2022-06-18 02:49:57.697440
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import InMemoryFXRateService
    from decimal import Decimal
    import datetime
    import pytest

    ## Create a service:
    service = InMemoryFXRateService()

    ## Add some rates:
    service.add(Currency("EUR"), Currency("USD"), Date(datetime.date(2019, 1, 1)), Decimal("1.2"))
    service.add(Currency("EUR"), Currency("USD"), Date(datetime.date(2019, 1, 2)), Decimal("1.3"))
    service.add(Currency("EUR"), Currency("USD"), Date(datetime.date(2019, 1, 3)), Decimal("1.4"))

# Generated at 2022-06-18 02:50:08.987230
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None
