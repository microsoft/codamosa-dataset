

# Generated at 2022-06-18 02:41:22.751146
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-18 02:41:32.088374
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Create a mock FX rate service:
    service = Mock(spec=FXRateService)

    ## Create a query:
    query = (Currencies["EUR"], Currencies["USD"], Date(2020, 1, 1))

    ## Create a rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(2020, 1, 1), Decimal("1.1"))

    ## Create a query collection:
    queries = [query]

    ## Create a rate collection:
    rates = [rate]

    ## Set the mock:
    service.queries.return_value = rates

    ## Test the

# Generated at 2022-06-18 02:41:39.344475
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof.date, Decimal("1.2"))

    service = TestFXRateService()
    assert service.query(Currencies["USD"], Currencies["EUR"], Temporal.now()) == FXRate(Currencies["USD"], Currencies["EUR"], Temporal.now().date, Decimal("1.2"))


# Generated at 2022-06-18 02:41:44.983551
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (None for _ in queries)

    assert list(TestFXRateService().queries([])) == []
    assert list(TestFXRateService().queries([(Currency("EUR"), Currency("USD"), Date.today())])) == [None]

# Generated at 2022-06-18 02:41:54.833961
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:42:01.376548
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-18 02:42:11.154900
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == date(2019, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            elif ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == date(2019, 1, 1):
                return

# Generated at 2022-06-18 02:42:18.261398
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries]

    service = MockFXRateService()
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date.today())
    assert rate.ccy

# Generated at 2022-06-18 02:42:28.913269
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fx import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))
            else:
                return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    service = TestFXRateService()


# Generated at 2022-06-18 02:42:41.265065
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.5"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("1.5")) for ccy1, ccy2, asof in queries]

    service = MockFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today()) == FXRate

# Generated at 2022-06-18 02:42:56.446583
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from .currencies import Currency
    from .temporal import Temporal
    from .fxrates import FXRateService, FXRateLookupError

    ## Define a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None


# Generated at 2022-06-18 02:43:05.354116
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal
    from .temporal import TemporalType
    from .temporal import TemporalUnit
    from .temporal import Temporals
    from .temporal import TemporalValue
    from .temporal import TemporalValueType
    from .temporal import TemporalValueUnit
    from .temporal import TemporalValueUnitType
    from .temporal import TemporalValueUnitType
    from .temporal import TemporalValueUnitType
    from .temporal import TemporalValueUnitType
    from .temporal import TemporalValueUnitType
    from .temporal import TemporalValueUnitType
    from .temporal import TemporalValueUnitType
    from .temporal import TemporalValueUnitType
    from .temporal import TemporalValueUnitType
    from .temporal import TemporalValueUnitType

# Generated at 2022-06-18 02:43:16.509949
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock

    from .currencies import Currency, Currencies

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:43:26.706526
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService

    class MockFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return next((rate for rate in self.rates if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof), None)


# Generated at 2022-06-18 02:43:37.740546
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """


# Generated at 2022-06-18 02:43:47.925620
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
           

# Generated at 2022-06-18 02:43:58.911135
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """


# Generated at 2022-06-18 02:44:11.271558
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.temporals import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:44:22.027976
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService
    from pypara.fx.services import InMemoryFXRateService

    ## Create an FX rate service:
    fxrs = InMemoryFXRateService()

    ## Create an FX rate:
    fxr = FXRate(Currencies["EUR"], Currencies["USD"], Temporal.today(), Decimal("2"))

    ## Add the FX rate to the FX rate service:
    fxrs.add(fxr)

    ## Query the FX rate service:
    assert fxrs.query(Currencies["EUR"], Currencies["USD"], Temporal.today()) == fxr

# Generated at 2022-06-18 02:44:29.436174
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService
    from .fxrates.services import InMemoryFXRateService
    from .fxrates.models import FXRate
    from datetime import date
    from decimal import Decimal
    from typing import Iterable, Optional

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict)

    ## Create a test FX rate service:
    service = TestFXRateService()

    ## Create

# Generated at 2022-06-18 02:44:43.506845
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2"))
            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None

    service = TestFXRateService()

# Generated at 2022-06-18 02:44:50.722186
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof.date, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries)

    ## Create the FX rate service:
    fx = TestFX

# Generated at 2022-06-18 02:45:00.321242
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    ## Create a test FX rate service:
    fxrs = TestFXRateService()

    ## Test the queries method:

# Generated at 2022-06-18 02:45:11.659482
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """


# Generated at 2022-06-18 02:45:23.385455
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            else:
                return None


# Generated at 2022-06-18 02:45:33.659532
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:45:44.598484
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service for testing purposes.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the mock FX rate service.
            """
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:45:55.287429
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:46:03.384623
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict)

    ## Create the FX rate service:
    fxrates = MockFXRateService()

    ## Create the queries:

# Generated at 2022-06-18 02:46:13.844541
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceMemory

    ## Create a service:
    service = FXRateServiceMemory()

    ## Add some rates:
    service.add(FXRate(Currencies["EUR"], Currencies["USD"], Temporal.today(), Decimal("1.2")))
    service.add(FXRate(Currencies["USD"], Currencies["EUR"], Temporal.today(), Decimal("0.8")))
    service.add(FXRate(Currencies["EUR"], Currencies["USD"], Temporal.today() + 1, Decimal("1.3")))

# Generated at 2022-06-18 02:46:41.314445
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.currencies.services import CurrencyService
    from pypara.temporals import Temporals
    from pypara.temporals.services import TemporalService

    ## Create a currency service:
    ccy_service = CurrencyService()

    ## Create a temporal service:
    temporal_service = TemporalService()

    ## Create a FX rate service:
    fx_rate_service = FXRateService()

    ## Create a currency pair:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    ## Create a date:
    asof = Temporals.today()

    ## Query the FX rate:
    fx_rate = fx_rate_service.query(ccy1, ccy2, asof)

   

# Generated at 2022-06-18 02:46:50.258560
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService
    from pypara.fxrates.services import FXRateServiceImpl
    import datetime
    from decimal import Decimal

    class TestFXRateService(FXRateServiceImpl):
        def __init__(self):
            super().__init__()

# Generated at 2022-06-18 02:46:56.630000
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Date

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
           

# Generated at 2022-06-18 02:47:08.243500
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None


# Generated at 2022-06-18 02:47:19.885923
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    from pypara.temporal import Dates

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, queries, strict=False):
            return [None] * len(queries)

    class TestFXRateServiceTestCase(TestCase):
        def test_queries(self):
            fxrate_service = TestFXRateService()
            fxrate_service.query = Mock()
            fxrate_service.queries([(Currencies["EUR"], Currencies["USD"], Dates.today())])

# Generated at 2022-06-18 02:47:31.639105
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("1.25"))
            else:
                return None

    ## Test the query method:
    service = TestFXRateService()
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1))

# Generated at 2022-06-18 02:47:41.703565
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict)

    # Test with an empty query list:
    assert list(TestFXRateService().queries([])) == []

    # Test with a single query:
    assert list(TestFXRateService().queries([(Currencies["EUR"], Currencies["USD"], Date.today())])) == [None]

    # Test with multiple queries

# Generated at 2022-06-18 02:47:52.476535
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import FXRateService
    from pypara.temporal import Date

    class MyFXRateService(FXRateService):
        """
        Provides a dummy implementation of FXRateService.
        """


# Generated at 2022-06-18 02:48:03.789759
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .temporal.date import Date
    from .temporal.date_time import DateTime
    from .temporal.time import Time
    from .temporal.time_zone import TimeZone
    from .temporal.time_zone_info import TimeZoneInfo
    from .temporal.time_zone_offset import TimeZoneOffset
    from .temporal.time_zone_offset_info import TimeZoneOffsetInfo
    from .temporal.time_zone_offset_info_collection import TimeZoneOffsetInfoCollection
    from .temporal.time_zone_offset_info_collection_builder import TimeZoneOffsetInfoCollectionBuilder
    from .temporal.time_zone_offset_info_collection_builder_options import TimeZoneOffsetInfoCollectionBuilderOptions

# Generated at 2022-06-18 02:48:10.253938
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class FXRateServiceTest(FXRateService):
        """
        Provides a test implementation of the FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:49:01.298771
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            return None


# Generated at 2022-06-18 02:49:11.617396
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import InMemoryFXRateService
    from .fxrates.models import FXRate
    from decimal import Decimal
    import datetime

    ## Create the FX rate service:
    service = InMemoryFXRateService()

    ## Add some FX rates:
    service.add(FXRate(Currencies["EUR"], Currencies["USD"], Date(datetime.date(2018, 1, 1)), Decimal("1.25")))
    service.add(FXRate(Currencies["EUR"], Currencies["USD"], Date(datetime.date(2018, 1, 2)), Decimal("1.26")))

# Generated at 2022-06-18 02:49:23.891293
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:49:36.011479
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
            elif ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 2):
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))

# Generated at 2022-06-18 02:49:46.325901
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the mock FX rate service.
            """
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:49:52.310430
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None


# Generated at 2022-06-18 02:50:00.433889
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from decimal import Decimal
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))
    fxrates = TestFXRateService()
    assert fxrates.query(Currencies["EUR"], Currencies["USD"], Date.today()) == FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("1.0"))


# Generated at 2022-06-18 02:50:10.997258
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("1.0"))

    service = TestFXRateService()

# Generated at 2022-06-18 02:50:21.809523
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            return

# Generated at 2022-06-18 02:50:29.710760
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceInMemory
    from decimal import Decimal
    import datetime

    # Create a service
    service = FXRateServiceInMemory()

    # Add some rates
    service.add(Currencies["EUR"], Currencies["USD"], Temporal.of(datetime.date(2019, 1, 1)), Decimal("1.1"))
    service.add(Currencies["EUR"], Currencies["USD"], Temporal.of(datetime.date(2019, 1, 2)), Decimal("1.2"))
    service.add(Currencies["EUR"], Currencies["USD"], Temporal.of(datetime.date(2019, 1, 3)), Decimal("1.3"))