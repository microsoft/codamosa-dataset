

# Generated at 2022-06-18 02:41:29.834417
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Temporal

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """


# Generated at 2022-06-18 02:41:38.043974
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase
    from unittest.mock import Mock, patch

    from .currencies import Currencies
    from .temporal import Temporal

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, ONE)


# Generated at 2022-06-18 02:41:44.711534
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """


# Generated at 2022-06-18 02:41:54.804971
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class MockFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield self.query(*query)

   

# Generated at 2022-06-18 02:42:05.502527
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.5"))

# Generated at 2022-06-18 02:42:16.173209
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """


# Generated at 2022-06-18 02:42:27.535896
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates import FXRateLookupError
    from .fxrates import FXRate
    from decimal import Decimal
    import datetime
    import pytest

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            else:
                return None


# Generated at 2022-06-18 02:42:35.048203
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the :class:`FXRateService` class.
    """
    from .currencies import Currencies
    from .temporal import Temporals
    from .fxrates import FXRateService, FXRateLookupError

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:42:45.917047
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2"))

# Generated at 2022-06-18 02:42:52.402319
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:43:05.140999
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    ## Import modules:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    ## Create a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:43:16.394812
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from unittest import TestCase
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the mock FX rate service.
            """
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:43:26.646916
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """


# Generated at 2022-06-18 02:43:37.655117
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (None, None)

    ## Test strict mode:
    service = TestFXRateService()
    try:
        list(service.queries([(Currencies["EUR"], Currencies["USD"], Temporal.now())], strict=True))
    except FXRateLookupError:
        pass

# Generated at 2022-06-18 02:43:47.863180
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    ## Create a mock FX rate service:
    service = MockFXRateService()

    ## Create a query:

# Generated at 2022-06-18 02:43:50.388680
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    pass


# Generated at 2022-06-18 02:44:00.429906
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof.date, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof.date, Decimal("2"))

    ## Create the FX rate service:
    fx

# Generated at 2022-06-18 02:44:12.179378
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import Curve, CurveService
    from pypara.temporal import Period, Temporal
    from pypara.temporal.curves import CurveInterpolator

    class FXRateService(FXRateService):
        def __init__(self, curve_service: CurveService) -> None:
            self.curve_service = curve_service

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)

            curve = self.curve_service.query(ccy1, ccy2, asof, strict)
           

# Generated at 2022-06-18 02:44:22.654690
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of the FXRateService class.
        """


# Generated at 2022-06-18 02:44:29.761021
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRate, FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date.of(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date.of(2018, 1, 1), Decimal("2"))
            else:
                return None


# Generated at 2022-06-18 02:44:43.892861
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))
            return None

    service = TestFXRateService()

# Generated at 2022-06-18 02:44:50.926867
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx.services import InMemoryFXRateService

    ## Create a service:
    service = InMemoryFXRateService()

    ## Add a couple of rates:
    service.add(Currencies["EUR"], Currencies["USD"], Temporal.of(2018, 1, 1), Decimal("1.5"))
    service.add(Currencies["EUR"], Currencies["USD"], Temporal.of(2018, 1, 2), Decimal("1.6"))
    service.add(Currencies["EUR"], Currencies["USD"], Temporal.of(2018, 1, 3), Decimal("1.7"))

# Generated at 2022-06-18 02:45:00.474067
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError
    from decimal import Decimal
    import datetime
    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(datetime.date.today()):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            elif ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == Date(datetime.date.today()):
                return FXRate(ccy1, ccy2, asof, Decimal("0.5"))

# Generated at 2022-06-18 02:45:07.795025
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of the FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:45:17.166578
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    ## Create a mock FX rate service:
    fx_rate_service = Mock(spec=FXRateService)

    ## Create a list of queries:
    queries = [
        (Currencies["EUR"], Currencies["USD"], Date.of(2020, 1, 1)),
        (Currencies["EUR"], Currencies["USD"], Date.of(2020, 1, 2)),
        (Currencies["EUR"], Currencies["USD"], Date.of(2020, 1, 3)),
    ]

    ## Create a list of FX rates:

# Generated at 2022-06-18 02:45:26.705229
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService
    from pypara.fx.services import InMemoryFXRateService

    ## Create the FX rate service:
    fxrs = InMemoryFXRateService()

    ## Add some FX rates:
    fxrs.add(FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2")))
    fxrs.add(FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 2), Decimal("1.3")))

# Generated at 2022-06-18 02:45:38.025356
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """


# Generated at 2022-06-18 02:45:46.286231
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:45:57.061441
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None] * len(queries)

    ## Test strict mode:
    service = MockFXRateService()
    queries = [
        (Currency("EUR"), Currency("USD"), Date.today()),
        (Currency("USD"), Currency("EUR"), Date.today()),
    ]

# Generated at 2022-06-18 02:46:04.753636
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService
    from .fxrates.memory import MemoryFXRateService

    ## Create a service:
    service = MemoryFXRateService()

    ## Add some rates:
    service.add(Currencies["EUR"], Currencies["USD"], Temporal.of(2018, 1, 1), Decimal("1.2"))
    service.add(Currencies["EUR"], Currencies["USD"], Temporal.of(2018, 1, 2), Decimal("1.3"))
    service.add(Currencies["EUR"], Currencies["USD"], Temporal.of(2018, 1, 3), Decimal("1.4"))

    ## Query the rates:

# Generated at 2022-06-18 02:46:30.634025
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService
    from pypara.fxrates.services import FXRateServiceImpl
    from pypara.fxrates.stores import FXRateStoreImpl

    # Create a store
    store = FXRateStoreImpl()

    # Create a service
    service = FXRateServiceImpl(store)

    # Create a query
    query = (Currencies["EUR"], Currencies["USD"], Date.today())

    # Create a rate
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))

    # Store the rate
    store.store(rate)

    # Query the rate
    result = service.query(*query)

    # Check the result

# Generated at 2022-06-18 02:46:42.338558
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fx import FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2020, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
            else:
                return None

    service = MockFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], Date(2020, 1, 1)) == FXRate(Currencies["EUR"], Currencies["USD"], Date(2020, 1, 1), Decimal("1.1"))
   

# Generated at 2022-06-18 02:46:50.865854
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the test FX rate service.
            """
            self._rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:47:02.492192
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

    fxrate_service = TestFXRateService()

# Generated at 2022-06-18 02:47:12.441131
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currency
    from pypara.temporal import Date

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    ## Create the mock FX rate service:
    service = MockFXRateService()

    ## Create a mock currency:
    ccy = mock.Mock(spec=Currency)

    ## Create

# Generated at 2022-06-18 02:47:24.100864
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.fxrates.services import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:47:33.773542
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    fxrates = TestFXRateService()
    assert fxrates.query(Currencies["EUR"], Currencies["USD"], Date.today())

# Generated at 2022-06-18 02:47:42.615160
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceImpl
    from .fxrates.sources import FXRateSource
    from .fxrates.sources.fxcm import FXCM

    ## Create the FX rate source:
    source = FXRateSource(FXCM())

    ## Create the FX rate service:
    service = FXRateServiceImpl(source)

    ## Create the queries:

# Generated at 2022-06-18 02:47:53.836773
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRate, FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None


# Generated at 2022-06-18 02:48:05.128223
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    ## Create a test FX rate service:
    fx = TestFXRateService()

    ## Test the query

# Generated at 2022-06-18 02:48:53.437590
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-18 02:49:02.999583
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

    assert TestFXRateService().query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) == FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))


# Generated at 2022-06-18 02:49:12.481296
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.finance.fxrates import FXRateService
    from pypara.zeitgeist import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    ## Create the FX rate service:
    fxrates = TestFXRateService()

    ## Query the FX rate:
    fxrate = fxrates.query(Currencies["EUR"], Currencies["USD"], Date.today())



# Generated at 2022-06-18 02:49:23.973243
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.25"))
            else:
                return None


# Generated at 2022-06-18 02:49:36.056708
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import InMemoryFXRateService
    from decimal import Decimal
    import datetime
    ## Create a service:
    service = InMemoryFXRateService()
    ## Add some rates:
    service.add(Currencies["EUR"], Currencies["USD"], Date(datetime.date(2019, 1, 1)), Decimal("1.1"))
    service.add(Currencies["EUR"], Currencies["USD"], Date(datetime.date(2019, 1, 2)), Decimal("1.2"))
    service.add(Currencies["EUR"], Currencies["USD"], Date(datetime.date(2019, 1, 3)), Decimal("1.3"))

# Generated at 2022-06-18 02:49:40.968335
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Temporal.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

    fxrates = TestFXRateService()
    assert fxrates.query(Currencies["EUR"], Currencies["USD"], Temporal.today()) == FXRate(Currencies["EUR"], Currencies["USD"], Temporal.today(), Decimal("2"))

# Generated at 2022-06-18 02:49:47.093133
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("2"))

    ## Create a test FX rate service:
    service = TestFXRateService()

    ## Query the service

# Generated at 2022-06-18 02:49:58.238601
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1"))


# Generated at 2022-06-18 02:50:09.068587
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:50:15.951939
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of the FXRateService class.
        """
