

# Generated at 2022-06-18 02:41:30.610824
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
           

# Generated at 2022-06-18 02:41:38.789598
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict)

    ## Create a mock FX rate service:
    service = MockFXRateService()

    ## Create a collection of queries:

# Generated at 2022-06-18 02:41:45.238986
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService.
    """
    from unittest import TestCase, mock
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    ## Mock the FXRateService:
    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:41:54.873095
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service.
        """


# Generated at 2022-06-18 02:42:03.816451
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test foreign exchange rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:42:13.543462
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    ## Test the query method:
    service = TestFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], Temporal.today(), strict=False) is None
    assert service.query(Currencies["EUR"], Currencies["USD"], Temporal.today(), strict=True) is None

    ##

# Generated at 2022-06-18 02:42:25.546813
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """


# Generated at 2022-06-18 02:42:33.716005
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:42:39.000428
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceImpl
    from .fxrates.sources import FXRateSource
    from .fxrates.sources.memory import FXRateSourceMemory
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl

# Generated at 2022-06-18 02:42:48.891424
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None


# Generated at 2022-06-18 02:43:02.405914
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate.of(ccy1, ccy2, asof, Decimal("2"))
            return None


# Generated at 2022-06-18 02:43:14.075721
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class FXRateServiceStub(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    ## Test the query method:
    service = FXRateServiceStub()
    rate

# Generated at 2022-06-18 02:43:22.086499
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService
    from pypara.fxrates.services import InMemoryFXRateService
    from decimal import Decimal
    import datetime
    import unittest

    class TestFXRateService(unittest.TestCase):
        def setUp(self):
            self.service = InMemoryFXRateService()

        def test_query(self):
            self.service.add(Currencies["EUR"], Currencies["USD"], Date(datetime.date.today()), Decimal("2"))

# Generated at 2022-06-18 02:43:32.583911
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None


# Generated at 2022-06-18 02:43:40.561024
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))
            elif ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("0.8"))
            el

# Generated at 2022-06-18 02:43:49.764429
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries)

    ## Test the query method:

# Generated at 2022-06-18 02:43:57.771405
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.2"))


# Generated at 2022-06-18 02:44:08.127901
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceImpl

    # Create a dummy FX rate service:
    service = FXRateServiceImpl()

    # Query the FX rate service:
    rate = service.query(Currencies["USD"], Currencies["EUR"], Date.today())

    # Check the result:
    assert rate is not None
    assert rate.ccy1 == Currencies["USD"]
    assert rate.ccy2 == Currencies["EUR"]
    assert rate.date == Date.today()
    assert rate.value > ZERO



# Generated at 2022-06-18 02:44:19.837467
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fx import FXRateService

    class FXRateServiceStub(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    fx_rate_service = FXRateServiceStub()

# Generated at 2022-06-18 02:44:28.546644
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class FXRateServiceMock(FXRateService):
        """
        Provides a mock implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:44:45.926197
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:44:56.836421
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from .currencies import Currencies
    from .temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-18 02:45:04.842317
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None

    service = TestFXRateService()
    rate = service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-18 02:45:09.869954
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Create a mock FX rate service:
    service = Mock(spec=FXRateService)

    ## Create a mock FX rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(2020, 1, 1), Decimal("2"))

    ## Create a mock FX rate query:
    query = (Currencies["EUR"], Currencies["USD"], Date(2020, 1, 1))

    ## Set the mock FX rate service to return the mock FX rate:
    service.query.return_value = rate

    ## Test the queries method:

# Generated at 2022-06-18 02:45:20.570906
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

    fx_service = TestFXRateService()
    assert fx_service.query(Currencies["EUR"], Currencies["USD"], Date.today()) == FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))


# Generated at 2022-06-18 02:45:31.694064
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Create a mock FX rate service:
    service = mock.Mock(spec=FXRateService)

    ## Create a mock FX rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))

    ## Create a mock query:
    query = (Currencies["EUR"], Currencies["USD"], Date.today())

    ## Create a mock query collection:
    queries = [query]

    ## Create a mock query result:
    result = [rate]

    ## Create a mock query result collection:
    results = [result]

    ## Set the mock query result:
    service

# Generated at 2022-06-18 02:45:43.414602
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date
    from pypara.testing import assert_raises

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    service = TestFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today()) is None

# Generated at 2022-06-18 02:45:54.266938
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of class FXRateService.
    """
    from .currencies import Currencies
    from .temporal import Date

    class FXRateServiceMock(FXRateService):
        """
        Provides a mock implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """

# Generated at 2022-06-18 02:46:03.174139
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRate, FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2019, 1, 1), Decimal("2"))
            return None


# Generated at 2022-06-18 02:46:12.621023
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None] * len(queries)

    service = TestFXRateService()
    assert service.queries([(Currencies["EUR"], Currencies["USD"], Date.today())]) == [None]

# Generated at 2022-06-18 02:46:38.239435
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the :method:`FXRateService.query` method.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currency
    from pypara.temporal import Date
    from pypara.fx import FXRate, FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of :class:`FXRateService`.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1"))


# Generated at 2022-06-18 02:46:45.622264
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    service = MockFXRateService()

# Generated at 2022-06-18 02:46:54.702771
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.fxrates.services import InMemoryFXRateService

    ## Create a service:
    service = InMemoryFXRateService()

    ## Add some rates:
    service.add(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    service.add(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    ## Query the rates:
    rate = service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]

# Generated at 2022-06-18 02:47:06.985393
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof.date, Decimal("2"))


# Generated at 2022-06-18 02:47:19.044940
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceImpl

    ## Create a service:
    service = FXRateServiceImpl()

    ## Query a rate:
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date.today())
    assert rate is not None
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == Date.today()
    assert rate.value > ZERO

    ## Query a rate with strict mode:
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date.today(), strict=True)
    assert rate is not None

# Generated at 2022-06-18 02:47:30.812498
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    # Test the query method:
    service = MockFXRateService()

# Generated at 2022-06-18 02:47:41.112920
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceImpl
    from .fxrates.sources import FXRateSource
    from .fxrates.sources.memory import FXRateSourceMemory
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl
    from .fxrates.sources.memory import FXRateSourceMemoryImpl

# Generated at 2022-06-18 02:47:48.158322
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2"))
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None

    service = TestFXRateService()
    assert service.query

# Generated at 2022-06-18 02:47:59.192744
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Temporal

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1"))


# Generated at 2022-06-18 02:48:09.977631
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            return []

# Generated at 2022-06-18 02:49:01.391891
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    service = TestFXRateService()

# Generated at 2022-06-18 02:49:08.965403
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries]

    service = TestFXRateService()

# Generated at 2022-06-18 02:49:15.995879
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest.mock import MagicMock
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRate

    ## Create a mock FX rate service:
    fx_rate_service = MagicMock()

    ## Create a mock FX rate:
    fx_rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2"))

    ## Create a mock query:
    query = (Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1))

    ## Set the mock FX rate service to return the mock FX rate for the mock query:
    fx_rate_service.query.return_value

# Generated at 2022-06-18 02:49:25.756436
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceImpl

    # Create a FX rate service:
    service = FXRateServiceImpl()

    # Query a FX rate:
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date.today())
    assert rate is not None

    # Query a FX rate with strict mode:
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date.today(), strict=True)
    assert rate is not None

    # Query a FX rate with strict mode:

# Generated at 2022-06-18 02:49:37.090768
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    ## Create a test FX rate service:
    service = TestFXRateService()

    ## Create a query:

# Generated at 2022-06-18 02:49:47.754642
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define the test case class:
    class Test(TestCase):
        """
        Provides the unit tests for method query of class FXRateService.
        """

        def test_query_with_strict_mode(self):
            """
            Tests the method query of class FXRateService with strict mode.
            """
            ## Create a mock FX rate service:
            service = mock.Mock(spec=FXRateService)

            ## Create a mock FX rate:
            rate = mock.Mock(spec=FXRate)

            ## Set the return value of the mock FX rate service:

# Generated at 2022-06-18 02:49:58.666197
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("2"))

    ## Create the test FX rate service:
    fx_service = TestFXRateService()

    ##

# Generated at 2022-06-18 02:50:09.302886
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates import FXRateLookupError
    from .fxrates import FXRate

    class MockFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-18 02:50:16.101860
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof.date, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries)

    service = TestFXRateService()

# Generated at 2022-06-18 02:50:25.344572
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None] * len(queries)

    assert list(TestFXRateService().queries([(Currencies["EUR"], Currencies["USD"], Date.today())])) == [None]