

# Generated at 2022-06-18 02:41:31.488035
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from unittest import TestCase
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:41:39.671951
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .temporal.dates import Date
    from .temporal.times import Time
    from .temporal.timestamps import Timestamp
    from .temporal.timezones import Timezone

    import datetime
    from decimal import Decimal

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(datetime.date.today()):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-18 02:41:45.742981
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Create a mock FX rate service:
    service = Mock(spec=FXRateService)

    ## Create a mock FX rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("2"))

    ## Create a mock query:
    query = (Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1))

    ## Set the side effect:
    service.queries.side_effect = lambda q, strict: [rate] if q == [query] else []

    ## Test the mock:

# Generated at 2022-06-18 02:41:54.361241
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.5"))

    service = TestFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today()) == FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("1.5"))


# Generated at 2022-06-18 02:42:05.373315
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))
            else:
                return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries]

    service

# Generated at 2022-06-18 02:42:14.869045
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class FXRateServiceMock(FXRateService):
        """
        Provides a mock implementation of the FXRateService.
        """


# Generated at 2022-06-18 02:42:26.461067
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.25"))
            elif ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("0.8"))

# Generated at 2022-06-18 02:42:34.376966
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currency
    from .temporal import Temporal
    from .temporal.date import Date
    from .temporal.time import Time
    from .temporal.datetime import DateTime
    from .temporal.timezone import TimeZone
    from .temporal.temporals import Temporals
    from .temporal.temporal_types import TemporalTypes
    from .temporal.temporal_types import TemporalType
    from .temporal.temporal_types import TemporalTypeError
    from .temporal.temporal_types import TemporalTypeLookupError
    from .temporal.temporal_types import TemporalTypeNotFoundError
    from .temporal.temporal_types import TemporalTypeRegisterError

# Generated at 2022-06-18 02:42:45.419544
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:42:56.538723
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date
    from pypara.temporal import Temporal
    from pypara.temporal import Time
    from pypara.temporal import TimeZone
    from pypara.temporal import TimeZoneOffset
    from pypara.temporal import TimeZoneOffsetType
    from pypara.temporal import TimeZoneRegion
    from pypara.temporal import TimeZoneTransition
    from pypara.temporal import TimeZoneTransitionType
    from pypara.temporal import TimeZoneType
    from pypara.temporal import TimeZoneVersion
    from pypara.temporal import TimeZoneVersionType
    from pypara.temporal import TimeZoneVersionYear

# Generated at 2022-06-18 02:43:11.305044
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:43:19.898859
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    ## Test the query method:
    fx_service = TestFXRateService()
    assert fx_service

# Generated at 2022-06-18 02:43:27.654456
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:43:38.743500
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError
    from decimal import Decimal

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None

    service = TestFXRateService()

# Generated at 2022-06-18 02:43:48.550721
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:43:57.267713
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Temporal
    import datetime

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Temporal.of(datetime.date.today()):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None


# Generated at 2022-06-18 02:44:05.891888
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError


# Generated at 2022-06-18 02:44:18.036234
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.25"))
            elif ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("0.80"))

# Generated at 2022-06-18 02:44:27.600197
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of the FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.1"))


# Generated at 2022-06-18 02:44:38.630972
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("1.1"))

        def queries(self, queries, strict=False):
            return [FXRate(ccy1, ccy2, asof, Decimal("1.1")) for ccy1, ccy2, asof in queries]

    service = MockFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today()) == FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("1.1"))


# Generated at 2022-06-18 02:44:56.830906
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1"))


# Generated at 2022-06-18 02:45:04.842446
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None


# Generated at 2022-06-18 02:45:15.222693
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("2"))

    fx_rate_service = TestFXRateService()
    assert fx

# Generated at 2022-06-18 02:45:19.273025
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the mock FX rate service.
            """
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:45:27.721130
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from .currencies import Currencies
    from .temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            return

# Generated at 2022-06-18 02:45:39.087353
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService
    from pypara.fx.services import InMemoryFXRateService

    ## Create a service:
    service = InMemoryFXRateService()

    ## Add some rates:
    service.add(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2"))
    service.add(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 2), Decimal("1.3"))
    service.add(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 3), Decimal("1.4"))

    ## Query the rates:

# Generated at 2022-06-18 02:45:46.885369
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.25"))

# Generated at 2022-06-18 02:45:57.377571
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService


# Generated at 2022-06-18 02:46:05.003785
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:46:16.108818
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceImpl
    from decimal import Decimal
    from datetime import date
    from pytest import raises
    fxrates = FXRateServiceImpl()
    fxrates.add(Currency("USD"), Currency("EUR"), date(2020, 1, 1), Decimal("0.9"))
    assert fxrates.query(Currency("USD"), Currency("EUR"), Date(date(2020, 1, 1))) == FXRate(Currency("USD"), Currency("EUR"), Date(date(2020, 1, 1)), Decimal("0.9"))
    assert fxrates.query(Currency("USD"), Currency("EUR"), Date(date(2020, 1, 2))) is None
    assert fx

# Generated at 2022-06-18 02:46:43.319498
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class FXRateServiceMock(FXRateService):
        """
        Provides a mock implementation of the FXRateService class.
        """


# Generated at 2022-06-18 02:46:51.125749
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    service = FXRateServiceImpl()
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today()) is None
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today(), strict=True) is None


# Generated at 2022-06-18 02:46:57.127975
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

    service = TestFXRateService()

# Generated at 2022-06-18 02:47:08.058253
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    # Create a mock FX rate service:
    service = mock.Mock(spec=FXRateService)

    # Create a mock FX rate:
    rate = mock.Mock(spec=FXRate)

    # Create a mock query:
    query = (Currencies["EUR"], Currencies["USD"], Date.today())

    # Create a mock query result:
    result = (rate, None)

    # Configure the mock FX rate service:
    service.queries.return_value = result

    # Call the queries method:
    assert service.queries([query]) == result

# Generated at 2022-06-18 02:47:19.806199
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Temporals
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, ONE)

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, ONE)

    fx = TestFXRateService()

# Generated at 2022-06-18 02:47:31.544629
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2"))
            else:
                return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

# Generated at 2022-06-18 02:47:41.654915
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None


# Generated at 2022-06-18 02:47:48.422201
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService.
    """
    from unittest import TestCase, mock
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries, strict=False):
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    ## Create the mock FX rate service:
    service = MockFXRateService()



# Generated at 2022-06-18 02:47:59.626169
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from .currencies import Currency
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import FXRateServiceImpl

    ## Create a dummy FX rate service:
    fxrates = FXRateServiceImpl()

    ## Create a query:
    query = (Currency.of("EUR"), Currency.of("USD"), Date.of(2020, 1, 1))

    ## Create a query collection:
    queries = [query]

    ## Query the FX rate service:
    rates = fxrates.queries(queries)

    ## Check the result:
    assert rates is not None
    assert len(rates) == 1
    assert rates[0] is not None
    assert rates[0].ccy1 == Currency.of

# Generated at 2022-06-18 02:48:10.262556
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """

    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define a test FX rate service:
    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:49:02.841391
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateService

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == date(2020, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("1.2"))
            else:
                return None


# Generated at 2022-06-18 02:49:12.340484
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService, FXRateLookupError
    import datetime
    from decimal import Decimal

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(datetime.date.today()):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None


# Generated at 2022-06-18 02:49:23.971555
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class MyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None] * len(queries)

    service = MyFXRateService()
    assert list(service.queries([(Currencies["USD"], Currencies["EUR"], Date.today())], strict=True)) == [None]

# Generated at 2022-06-18 02:49:36.070527
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Create a mock FX rate service:
    fx_rate_service = mock.Mock(spec=FXRateService)

    ## Create a mock FX rate:
    fx_rate = mock.Mock(spec=FXRate)

    ## Create a mock FX rate query:
    fx_rate_query = (Currencies["EUR"], Currencies["USD"], Date.today())

    ## Create a mock FX rate query result:
    fx_rate_query_result = (fx_rate, None)

    ## Create a mock FX rate query result iterator:

# Generated at 2022-06-18 02:49:40.995066
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService.
    """
    from unittest import TestCase, mock
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:49:47.133534
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:49:52.664602
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the test FX rate service.
            """
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:50:01.410371
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """

    from .currencies import Currencies
    from .temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:50:11.834636
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest.mock import MagicMock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Create a mock FX rate service:
    fx_rate_service = MagicMock(spec=FXRateService)

    ## Create a mock FX rate:
    fx_rate = MagicMock(spec=FXRate)

    ## Create a mock query:
    query = (Currencies["EUR"], Currencies["USD"], Date.today())

    ## Create a mock query result:
    query_result = (fx_rate, None)

    ## Create a mock query result iterator:
    query_result_iterator = iter(query_result)

    ## Create a mock query iterator:

# Generated at 2022-06-18 02:50:22.394101
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService
    from pypara.fxrates.services import FXRateServiceImpl
    from pypara.fxrates.sources import FXRateSource

    # Create a dummy FX rate source:
    class DummyFXRateSource(FXRateSource):
        """
        Provides a dummy FX rate source.
        """
