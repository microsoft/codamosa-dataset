

# Generated at 2022-06-18 02:41:30.687088
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:41:38.860150
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    fx_rate_service = TestFXRateService()

# Generated at 2022-06-18 02:41:45.285413
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-18 02:41:54.948031
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("1.0")) for ccy1, ccy2, asof in queries]

    ## Create a mock FX rate service:
    fx_rate

# Generated at 2022-06-18 02:42:03.885502
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currency.of("EUR") and ccy2 == Currency.of("USD") and asof == Date.of("2018-01-01"):
                return FXRate(ccy1, ccy2, asof, Decimal("1.25"))
            else:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                else:
                    return None

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self

# Generated at 2022-06-18 02:42:13.624485
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1"))


# Generated at 2022-06-18 02:42:25.642078
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase
    from unittest.mock import Mock, patch

    from pypara.currencies import Currency

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    class TestCase(TestCase):
        def test_query(self):
            with patch.object(TestFXRateService, "query", return_value=None):
                service = TestFXRateService()
                self.assertIsNone(service.query(Currency("EUR"), Currency("USD"), Date.today()))

    Test

# Generated at 2022-06-18 02:42:33.780589
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:42:44.879136
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the test FX rate service.
            """
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:42:52.097865
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2"))

# Generated at 2022-06-18 02:43:04.828638
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date
    from decimal import Decimal
    from unittest import TestCase

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries]


# Generated at 2022-06-18 02:43:16.323076
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService


# Generated at 2022-06-18 02:43:24.107219
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            return None


# Generated at 2022-06-18 02:43:35.271924
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date

    class FXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries)

    ## Create a service:
    service = FXRateService()

    ## Query a rate:
    rate = service.query

# Generated at 2022-06-18 02:43:46.190237
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService.
        """


# Generated at 2022-06-18 02:43:57.095844
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2019, 1, 1), Decimal("1.1"))

# Generated at 2022-06-18 02:44:05.807662
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    ## Create the service:
    service = TestFXRateService()

    ## Query the service:
   

# Generated at 2022-06-18 02:44:17.990419
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of the FXRateService class.
        """


# Generated at 2022-06-18 02:44:27.567092
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates.services import InMemoryFXRateService
    from decimal import Decimal
    import datetime
    import unittest

    class TestFXRateService(unittest.TestCase):

        def test_queries(self):
            # Create an FX rate service:
            service = InMemoryFXRateService()

            # Add some FX rates:
            service.add(Currencies["EUR"], Currencies["USD"], Date(datetime.date(2018, 1, 1)), Decimal("1.2"))
            service.add(Currencies["EUR"], Currencies["USD"], Date(datetime.date(2018, 1, 2)), Decimal("1.3"))

# Generated at 2022-06-18 02:44:38.626134
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """


# Generated at 2022-06-18 02:44:56.692614
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of the FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof.date, Decimal("1.0"))


# Generated at 2022-06-18 02:45:04.777680
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """


# Generated at 2022-06-18 02:45:15.221964
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the functionality of method query of class FXRateService.
    """
    from unittest import TestCase
    from unittest.mock import Mock

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of class FXRateService.
        """


# Generated at 2022-06-18 02:45:19.273447
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("2"))
            else:
                return None


# Generated at 2022-06-18 02:45:24.404402
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock

    from .currencies import Currencies
    from .temporal import Temporal

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FXRateService.
        """


# Generated at 2022-06-18 02:45:34.268630
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries)

    service = TestFXRateService()

# Generated at 2022-06-18 02:45:44.949607
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class FXRateServiceImpl(FXRateService):
        """
        Provides a dummy implementation of the FXRateService class.
        """


# Generated at 2022-06-18 02:45:55.585855
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """


# Generated at 2022-06-18 02:46:02.874743
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

    fx = TestFXRateService()
    assert fx.query(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1)) == FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("2"))


# Generated at 2022-06-18 02:46:13.289153
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService
    from .fxrates import FXRateLookupError
    from .fxrates import FXRate

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2"))
            else:
                return None


# Generated at 2022-06-18 02:46:35.196095
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    ## Create the mock FX rate service:
    fx_service = MockFXRateService()

    ## Create the queries:


# Generated at 2022-06-18 02:46:44.125353
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None


# Generated at 2022-06-18 02:46:52.351385
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService

    class FXRateServiceTest(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return map(lambda q: self.query(*q), queries)

    fxrate_service = FXRateServiceTest()

# Generated at 2022-06-18 02:47:03.673803
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None] * len(queries)

    ## Create a mock FX rate service:
    service = MockFXRateService()

    ## Test the queries method:

# Generated at 2022-06-18 02:47:13.253942
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateService, FXRate

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries)

    fxrate_service = MockFXRateService()
    assert fx

# Generated at 2022-06-18 02:47:18.152931
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService, FXRateLookupError
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-18 02:47:28.447551
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

    fxrs = MockFXRateService()
    assert fxrs.query(Currencies["EUR"], Currencies["USD"], Date.today()) == FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("1.0"))


# Generated at 2022-06-18 02:47:35.977877
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2019, 1, 1), Decimal("2"))
            else:
                return None


# Generated at 2022-06-18 02:47:44.557010
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRate, FXRateService


# Generated at 2022-06-18 02:47:56.253600
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    ##

# Generated at 2022-06-18 02:48:36.359327
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fxrates import FXRateService

    ## Define a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))


# Generated at 2022-06-18 02:48:47.395955
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of the FXRateService class.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the mock FX rate service.
            """
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-18 02:48:58.738402
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof.date, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries]

    service = MockFXRateService()

# Generated at 2022-06-18 02:49:10.899067
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2"))
            else:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                else:
                    return None

    service = TestFXRateService()

    assert service.query

# Generated at 2022-06-18 02:49:23.188226
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, 1)

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    fx_rate_service = TestFXRateService()

# Generated at 2022-06-18 02:49:30.032381
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            return None


# Generated at 2022-06-18 02:49:40.661129
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, asof, Decimal("2")) for ccy1, ccy2, asof in queries]

    service = TestFXRateService()

# Generated at 2022-06-18 02:49:45.018652
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService
    from pypara.fx.services import FXRateServiceImpl
    from pypara.fx.rates import FXRateImpl
    from decimal import Decimal
    import datetime
    fx_rate_service = FXRateServiceImpl()
    fx_rate_service.add(FXRateImpl(Currencies["EUR"], Currencies["USD"], Date(datetime.date.today()), Decimal("2")))
    fx_rate_service.add(FXRateImpl(Currencies["USD"], Currencies["EUR"], Date(datetime.date.today()), Decimal("0.5")))

# Generated at 2022-06-18 02:49:56.687231
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("1.0"))

    fx = TestFXRateService()

# Generated at 2022-06-18 02:49:58.820074
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    pass


# Generated at 2022-06-18 02:51:14.995485
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test method queries of class FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            if (ccy1, ccy2, asof) == (Currencies["EUR"], Currencies["USD"], datetime.date.today()):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return