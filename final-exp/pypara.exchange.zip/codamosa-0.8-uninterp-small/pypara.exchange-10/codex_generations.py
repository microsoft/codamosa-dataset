

# Generated at 2022-06-26 00:51:47.203788
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.fx_rates.indexed_services import IndexedFXRateService

    indexed_f_x_rate_service_0 = IndexedFXRateService()
    assert all(isinstance(indexed_f_x_rate_service_0.queries([]), type([])) for _ in range(10))


# Generated at 2022-06-26 00:51:49.248909
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Unit test for method queries of class FXRateService
    def test_FXRateService_queries(self):
        raise Exception('test should be implemented here')



# Generated at 2022-06-26 00:51:55.486564
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Define a fx rate service
    f_x_rate_service_0 = FXRateService()
    # Call the method query of fx_rate_service_0
    arg_0 = None
    arg_1 = None
    arg_2 = None
    arg_3 = False
    result = f_x_rate_service_0.query(arg_0, arg_1, arg_2, arg_3)


# Generated at 2022-06-26 00:52:03.097265
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    def check_fx_rate_service(fx_rate_service: FXRateService):
        fx_rate = fx_rate_service.query(Currencies["USD"], Currencies["EUR"], Date(2015, 1, 1))
        assert fx_rate is not None
        assert fx_rate.ccy1 == Currencies["USD"]
        assert fx_rate.ccy2 == Currencies["EUR"]
        assert fx_rate.date == Date(2015, 1, 1)
        assert fx_rate.value == Decimal("0.89540615")  # source: yahoo.finance

    from pypara.services.fx import DefaultFXRateService
    check_fx_rate_service(DefaultFXRateService())


# Generated at 2022-06-26 00:52:03.905441
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert test_case_0()


# Generated at 2022-06-26 00:52:11.818586
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(((Currency.of('NOK'), Currency.of('EUR'), Date(2018, 12, 31)),))
    f_x_rate_service_1 = FXRateService()
    f_x_rate_service_1.queries(((Currency.of('EUR'), Currency.of('NOK'), Date(2018, 12, 31)),))
    f_x_rate_service_2 = FXRateService()
    f_x_rate_service_2.queries(((Currency.of('EUR'), Currency.of('EUR'), Date(2018, 12, 31)),))

# Generated at 2022-06-26 00:52:12.894349
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # TODO: implement
    raise NotImplementedError


# Generated at 2022-06-26 00:52:16.242730
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    with pytest.raises(TypeError):
        f_x_rate_service_0 = FXRateService()
        a_fx_rate_service_query_0 = f_x_rate_service_0.query('ccy1','ccy2','asof','strict')


# Generated at 2022-06-26 00:52:18.213199
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    try:
        test_case_0()
    except TypeError as err:
        if err.args[0] != NotImplemented:
            raise err


# Generated at 2022-06-26 00:52:24.419417
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    from pypara.temporal import Date
    import random

    fx_rate_service = FXRateService()

    for i in range(0, 100):
        currency_1 = Currency(random.randint(0, 999))
        currency_2 = Currency(random.randint(0, 999))
        date = Date(random.randint(0, 999))
        strict = random.choice([True, False])
        fx_rate = fx_rate_service.query(currency_1, currency_2, date, strict)



# Generated at 2022-06-26 00:52:34.873492
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = "^V;5u5ip23iyQ7, e]{$&F8Dp!@n*M7b0Y5Z5"
    list_0 = [str_0, str_0, str_0, str_0]
    f_x_rate_service_0 = FXRateService(*list_0)
    f_x_rate_service_1 = FXRateService(*list_0)
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13

# Generated at 2022-06-26 00:52:41.362615
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    int_0 = 47761
    list_1 = [int_0, list_0, int_0, list_0]
    f_x_rate_0 = FXRate(*list_1)
    list_2 = [f_x_rate_0]
    list_3 = [list_2]
    f_x_rate_service_0 = FXRateService(*list_3)
    list_4 = [f_x_rate_service_0]
    f_x_rate_service_1 = f_x_rate_service_0.__class__(*list_4)
    list_5 = [f_x_rate_service_1]

# Generated at 2022-06-26 00:52:43.319760
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    list_0 = []
    f_x_rate_service_0.queries(list_0)


# Generated at 2022-06-26 00:52:54.037110
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    from pypara.commons.zeitgeist import Date
    from decimal import Decimal
    ccy1 = Currency.of("ABCD")
    ccy2 = Currency.of("ABCD")
    asof = Date(year = 9146, month = 51, day = 7)
    strict = True
    f_x_rate_service_0 = FXRateService()
    f_x_rate_0 = f_x_rate_service_0.query(ccy1, ccy2, asof, strict)
    print(f_x_rate_0)


# Generated at 2022-06-26 00:53:02.263267
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = []
    int_0 = (2 * 3) + (((7 - 9) - 2) - 1)
    int_1 = (2 * 3) + (((7 - 9) - 2) - 1)
    list_1 = [int_0, list_0, int_1, list_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_3 = f_x_rate_2.__invert__()
    f_x_rate_4 = f_x_rate_3.__invert__()
    f_x_rate_5 = f_x

# Generated at 2022-06-26 00:53:11.180101
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    print("Testing FXRateService.query")
    f_x_rate_0 = FXRate(Currency("BMX"), Currency("NDX"), Date(2015, 1, 1), Decimal("0.1379882796904626"))
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_3 = f_x_rate_2.__invert__()
    f_x_rate_4 = f_x_rate_3.__invert__()
    f_x_rate_5 = f_x_rate_4.__invert__()
    f_x_rate_6 = f_x_rate_5.__invert__()
    f_x_

# Generated at 2022-06-26 00:53:20.785960
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    int_0 = 4811
    list_1 = [int_0, list_0, int_0, list_0]
    f_x_rate_0 = FXRate(*list_1)
    list_2 = [f_x_rate_0]
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(list_2)
    f_x_rate_0 = FXRate(*list_1)
    list_3 = [f_x_rate_0]
    f_x_rate_service_1 = FXRateService()
    f_x_rate_service_1.queries(list_3)
    f_x_rate_0 = FXRate(*list_1)

# Generated at 2022-06-26 00:53:22.596210
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    int_0 = 2054
    for i in range(int_0):
        test_case_0()


# Generated at 2022-06-26 00:53:23.394845
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:53:27.235777
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    f_x_rate_service_0 = FXRateService()
    list_1 = [f_x_rate_service_0]
    list_2 = [list_0, list_1]
    any_0 = f_x_rate_service_0.queries(*list_2)


# Generated at 2022-06-26 00:53:37.816663
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    for _ in range(1000):
        test_case_0()

# Generated at 2022-06-26 00:53:44.237479
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    def query_fake(ccy1, ccy2, asof, strict = False):
        return FXRate(ccy1, ccy2, asof, Decimal(1))
    class f_x_rate_service_0(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False): return query_fake(ccy1, ccy2, asof, strict)
        def queries(self, queries, strict = False): return map(query_fake, queries)
    f_x_rate_service_0().queries(['val'])

# Generated at 2022-06-26 00:53:45.033378
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:53:46.090170
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_0 = test_case_0()



# Generated at 2022-06-26 00:53:55.017994
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.utils.fxconverter import FXRate

    from datetime import date
    from decimal import Decimal as D
    from pypara.currencies import Currencies as C
    from typing import Tuple

    # given
    class MyFXRateService(FXRateService):
        def query(
            self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False
        ) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, value)

        def queries(
            self, queries: Iterable[TQuery], strict: bool = False
        ) -> Iterable[Optional[FXRate]]:
            return map(self.query, *zip(*queries))

    #

# Generated at 2022-06-26 00:54:01.470853
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    int_0 = 8201
    list_1 = [int_0, list_0, int_0, list_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_3 = f_x_rate_2.__invert__()
    f_x_rate_4 = f_x_rate_3.__invert__()
    f_x_rate_5 = f_x_rate_4.__invert__()
    f_x_rate_6 = f_x_rate_5.__invert__()
    f_x_rate

# Generated at 2022-06-26 00:54:11.079969
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = FXRate(*list_0)
    f_x_rate_2 = FXRate(*list_0)
    f_x_rate_3 = FXRate(*list_0)
    list_1 = [f_x_rate_0, f_x_rate_1, f_x_rate_2, f_x_rate_3]
    f_x_rate_4 = FXRate(*list_1)
    list_2 = []
    int_0 = 4811
    f_x_rate_5 = FXRate.of(int_0, int_0, int_0, int_0)
    int_1 = 3670

# Generated at 2022-06-26 00:54:18.291476
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    test_FXRateService_queries_0()
    test_FXRateService_queries_1()
    test_FXRateService_queries_2()
    test_FXRateService_queries_3()
    test_FXRateService_queries_4()
    test_FXRateService_queries_5()
    test_FXRateService_queries_6()
    test_FXRateService_queries_7()
    test_FXRateService_queries_8()
    test_FXRateService_queries_9()
    test_FXRateService_queries_10()
    test_FXRateService_queries_11()


# Generated at 2022-06-26 00:54:28.492196
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = []
    int_0 = 0
    list_0.append(int_0)
    int_1 = 7947
    list_0.append(int_1)
    int_2 = 1960
    list_0.append(int_2)
    int_3 = 66544
    list_0.append(int_3)
    f_x_rate_0 = FXRate(*list_0)
    dict_0 = {}
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = []
    int_4 = 40330
    list_1.append(int_4)
    int_5 = 22251
    list_1.append(int_5)
    int_6 = 12111
    list_1.append(int_6)

# Generated at 2022-06-26 00:54:36.078179
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    tuple_0 = ()
    dict_0 = {}
    f_x_rate_0 = FXRate(*tuple_0, **dict_0)
    tuple_1 = (f_x_rate_0, f_x_rate_0, f_x_rate_0, f_x_rate_0, f_x_rate_0, f_x_rate_0)
    iterations_0 = 0
    while iterations_0 < 4:
        try:
            f_x_rate_service_0.queries(tuple_1)
        except LookupError:
            pass
        iterations_0 += 1


# Generated at 2022-06-26 00:55:01.375740
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = []
    list_1 = []
    int_0 = 47
   # list_2 = [int_0, list_1, list_0, list_1]
   # f_x_rate_0 = FXRate(*list_2)
   # bool_0 = f_x_rate_0 is not None
   # bool_1 = not bool_0
    bool_2 = True
    #assert bool_2
    #assert bool_1
    list_3 = []
    list_4 = []
    int_1 = 15
    list_5 = [int_1, list_4, list_3, list_4]
    f_x_rate_1 = FXRate(*list_5)
    list_6 = []
    list_7 = []
    int_2 = 458
    list_8

# Generated at 2022-06-26 00:55:04.844133
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    try:
        f_x_rate_service_0.queries("", "", "", "")
    except AssertionError:
        return
    raise AssertionError("assertion error")

# Generated at 2022-06-26 00:55:13.481806
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # create instance of class FXRateService
    f_x_rate_service_0 = FXRateService()
    # create arg of class Currency
    currency_0 = Currency()
    # create arg of class Currency
    currency_1 = Currency()
    # create arg of class Temporal
    temporal_0 = Temporal()
    # create arg of class bool
    bool_0 = True
    # call method query of class FXRateService with args
    f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_1, temporal_0, bool_0)


# Generated at 2022-06-26 00:55:22.728534
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    int_0 = 4175
    int_1 = -5065
    int_2 = 14
    list_0 = [int_0, int_1, int_2, int_2]
    f_x_rate_0 = FXRate(*list_0)
    int_3 = -4916
    int_4 = -2316
    int_5 = -2028
    list_1 = [int_1, int_0, int_2, int_1]
    f_x_rate_1 = FXRate(*list_1)
    int_6 = 229
    list_2 = [int_0, int_1, int_5, int_6]
    f_x_rate_2 = FXRate(*list_2)

# Generated at 2022-06-26 00:55:29.331677
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Initialize the test
    f_x_rate_service_0 = FXRateService()
    list_0 = []
    int_0 = 4811
    list_1 = [int_0, list_0, int_0, list_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_3 = f_x_rate_2.__invert__()
    f_x_rate_4 = f_x_rate_3.__invert__()
    f_x_rate_5 = f_x_rate_4.__invert__()
    f_x_rate

# Generated at 2022-06-26 00:55:38.456771
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    #fxrateservice0 =
    f_x_rate_0 = FXRate(None, None, None, None)
    f_x_rate_1 = FXRate(None, None, None, None)
    int_0 = -17
    f_x_rate_2 = FXRate(None, None, None, int_0)
    str_0 = ""
    f_x_rate_3 = FXRate(None, None, str_0, None)
    f_x_rate_4 = FXRate(None, None, None, None)
    f_x_rate_5 = FXRate(None, None, None, None)
    f_x_rate_6 = FXRate(None, None, None, None)
    int_1 = 814

# Generated at 2022-06-26 00:55:48.902177
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = []
    dict_0 = {}
    f_x_rate_0 = FXRate(*list_0, **dict_0)
    list_1 = []
    dict_1 = {}
    f_x_rate_1 = FXRate(*list_1, **dict_1)
    list_2 = []
    dict_2 = {}
    f_x_rate_2 = FXRate(*list_2, **dict_2)
    list_3 = []
    dict_3 = {}
    f_x_rate_3 = FXRate(*list_3, **dict_3)
    list_4 = []
    dict_4 = {}
    f_x_rate_4 = FXRate(*list_4, **dict_4)
    list_5 = []
    dict_5 = {}
    f_x_

# Generated at 2022-06-26 00:55:50.331452
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = None
    list_0 = []
    f_x_rate_service_0.queries(list_0)


# Generated at 2022-06-26 00:55:52.116873
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert True


# Generated at 2022-06-26 00:55:52.918505
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:56:22.872834
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:56:32.373479
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    cls = type(rate)
    assert rate == cls.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    from pypara.service.fxrates import SimpleFXRateService
    serv = SimpleFXRateService()
    assert rate == serv.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate.__invert__() == serv.query(Currencies["USD"], Currencies["EUR"], datetime.date.today())

# Generated at 2022-06-26 00:56:41.836638
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    int_0 = 6372
    list_1 = [int_0, list_0, int_0, list_0]
    f_x_rate_0 = FXRate(*list_1)
    list_2 = []
    int_1 = 4597
    list_3 = [int_1, list_2, int_1, list_2]
    f_x_rate_1 = FXRate(*list_3)
    list_4 = []
    int_2 = 6018
    list_5 = [int_2, list_4, int_2, list_4]
    f_x_rate_2 = FXRate(*list_5)
    list_6 = []
    int_3 = 3939

# Generated at 2022-06-26 00:56:51.223103
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from math import pi
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.currencies.currency import Currency
    qrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("2"))
    srate = FXRate.of(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("2"))
    wrate = FXRate(Currencies["USD"], Currencies["TRY"], date.today(), Decimal("0.33"))
    erate = FXRate.of(Currencies["USD"], Currencies["TRY"], date.today(), Decimal("0.33"))

# Generated at 2022-06-26 00:56:52.124569
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-26 00:57:04.116216
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = Currency('GBP')
    currency_1 = Currency('CAD')
    currency_2 = Currency('EUR')
    from datetime import date
    date_0 = date(2020, 8, 9)
    f_x_rate_0 = FXRate(currency_2, currency_1, date_0, -14)
    f_x_rate_1 = FXRate(currency_2, currency_0, date_0, -6)
    f_x_rate_2 = FXRate(currency_2, currency_1, date_0, -4)
    f_x_rate_3 = FXRate(currency_1, currency_0, date_0, -3)
    f_x_rate_4 = FXRate(currency_2, currency_1, date_0, -1)
    f_x_

# Generated at 2022-06-26 00:57:07.984664
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    fx_rate_service_0 = FXRateService.default
    ccy1_0 = Currencies['EUR']
    ccy2_0 = Currencies['USD']
    asof_0 = datetime.date.today()
    f_x_rate_0 = fx_rate_service_0.query(ccy1_0, ccy2_0, asof_0, False)
    f_x_rate_1 = f_x_rate_0.__invert__()
    

# Generated at 2022-06-26 00:57:09.024376
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    test_case_0()

# Generated at 2022-06-26 00:57:20.886706
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    int_0 = 5743
    list_1 = [int_0, list_0, int_0, list_0]
    f_x_rate_0 = FXRate(*list_1)
    list_2 = [f_x_rate_0]
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_1 = f_x_rate_service_0.queries(list_2)
    f_x_rate_service_1 = f_x_rate_service_0.queries(list_1)
    f_x_rate_service_2 = f_x_rate_service_1.queries(list_1)


# Generated at 2022-06-26 00:57:21.730420
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:58:27.477152
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = []
    int_0 = 28441
    list_1 = [int_0, list_0, int_0, list_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_3 = f_x_rate_2.__invert__()
    f_x_rate_4 = f_x_rate_3.__invert__()
    f_x_rate_5 = f_x_rate_4.__invert__()
    f_x_rate_6 = f_x_rate_5.__invert__()
    f_x_rate

# Generated at 2022-06-26 00:58:28.726442
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries of the FXRateService class.
    """
    pass

# Generated at 2022-06-26 00:58:35.639884
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test method FXRateService.query
    """
    # creating f_x_rate_service_0
    list_0 = [None, None, None, None]
    f_x_rate_service_0 = FXRateService(*list_0)

    # creating var_0
    list_1 = []
    int_0 = 4811
    list_2 = [int_0, list_1, int_0, list_1]
    f_x_rate_0 = FXRate(*list_2)
    var_0 = f_x_rate_0.__invert__()

    # calling FXRateService.query
    f_x_rate_service_0.query(var_0)

    # creating var_1
    list_3 = []
    int_1 = 8157

# Generated at 2022-06-26 00:58:43.401480
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    int_0 = 6489
    list_1 = [int_0, list_0, list_0]
    list_2 = [list_1, list_0, list_0]
    f_x_rate_0 = FXRate(*list_2)
    list_3 = [f_x_rate_0, list_0, f_x_rate_0]
    list_4 = [list_3, list_0, list_0]
    f_x_rate_1 = FXRate(*list_4)
    list_5 = [f_x_rate_1, list_0, f_x_rate_1]
    dict_0 = {}
    f_x_rate_2 = FXRate(*list_0, **dict_0)

# Generated at 2022-06-26 00:58:50.787591
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Additional test to ensure that queries method calls
    # the query method of the derived class
    class FXRateService0(FXRateService) :

        def __init__(self) :
            self.query_called = False

        def query(self, ccy1, ccy2, asof, strict = False) :
            self.query_called = True
            return None

        def queries(self, queries, strict = False) :
            for q in queries :
                self.query(q[0], q[1], q[2], strict)
            return []

    fx_rate_service0 = FXRateService0()
    fx_rate_service0.queries([])
    assert fx_rate_service0.query_called


# Generated at 2022-06-26 00:58:57.037081
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    list_0 = []
    int_0 = 92
    list_1 = [int_0, list_0, int_0, list_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_service_0.query(*list_0)
    f_x_rate_2 = FXRate(*list_0)
    f_x_rate_3 = f_x_rate_service_0.query(*list_0)


# Generated at 2022-06-26 00:58:58.915538
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    FXRateService.queries(list_0, True)
    list_1 = []
    FXRateService.queries(list_1)


# Generated at 2022-06-26 00:59:08.175416
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_inst = mock.Mock(spec_set=FXRateService)
    # mock up the queries method
    def queries_side_effect(*args, **kwargs):
        return args, kwargs
    f_x_rate_service_inst.queries = mock.Mock(side_effect=queries_side_effect)

    ccy_0 = Currency
    ccy_1 = Currency
    ccy_2 = Currency
    ccy_3 = Currency
    ccy_4 = Currency
    ccy_5 = Currency
    ccy_6 = Currency
    ccy_7 = Currency
    ccy_8 = Currency
    ccy_9 = Currency
    ccy_10 = Currency
    ccy_11 = Currency
    ccy_12 = Currency
    temporal_0 = Date
   

# Generated at 2022-06-26 00:59:15.656698
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # AssertionError: assert <filter object at 0x054D4B70> is not None
    list_0 = []
    int_0 = 4374
    list_1 = [int_0, list_0, int_0, list_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    dict_0 = {}
    f_x_rate_3 = FXRate(*list_0, **dict_0)
    f_x_rate_4 = f_x_rate_3.__invert__()
    f_x_rate_5 = f_x_rate_4.__invert__

# Generated at 2022-06-26 00:59:25.230660
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pytest

    ## Import the module under test:
    from pypara.fx import FXRateService, FXRateLookupError, FXRate

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        __rates: tuple[FXRate] = (
            FXRate("EUR", "USD", "2020-01-01", 0.91),
            FXRate("TRY", "USD", "2020-01-01", 0.13),
            FXRate("EUR", "TRY", "2020-01-01", 7.37),
            FXRate("TRY", "EUR", "2020-01-01", 0.14),
        )
