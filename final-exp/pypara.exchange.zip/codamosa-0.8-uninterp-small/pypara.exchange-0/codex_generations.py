

# Generated at 2022-06-26 00:51:49.386131
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-26 00:51:51.769698
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Assert attribute default is of class NoneType.
    assert isinstance(FXRateService.default, type(None))

# Generated at 2022-06-26 00:51:57.980479
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from mock import MagicMock
    from datetime import date

    fxrateservice = FXRateService()
    fxrateservice.query = MagicMock(return_value=None)
    fxrateservice.query(Currencies['USD'], Currencies['EUR'], date.today())
    fxrateservice.query.assert_called_with(Currencies['USD'], Currencies['EUR'], date.today())


# Generated at 2022-06-26 00:52:02.150077
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-26 00:52:10.246787
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    print("\nUnit test for method queries of class FXRateService")
    from dateutil.parser import parse
    from typing import Tuple
    from pypara.currencies import Currency, Currencies
    from pypara.curves import DateCurve
    from pypara.deposits import Deposit
    from pypara.fx import FXRate,FXRateService

    class FXRateServiceImpl(FXRateService):
        """
        A foreign exchange rate service implementation that works with regard to a given
        FX rate curve.
        """

        def __init__(self, curve: DateCurve[FXRate]) -> None:
            """
            Initializes the FX rate service.
            """
            self.curve = curve


# Generated at 2022-06-26 00:52:18.712055
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Create two FX rates to EUR:
    rate_0 = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("2"))
    rate_1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0.5"))

    # Create an FX rate service implementation:
    class MyFXRateService(FXRateService):

        # query implementation

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict=False):
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                return rate_0

# Generated at 2022-06-26 00:52:19.774689
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.fx import FXRateService
    FXRateService()


# Generated at 2022-06-26 00:52:26.477568
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """

    """
    class FXRateServiceImp(FXRateService):
        """
        Provides an implementation of foreign exchange rate service.
        """

        def query(
            self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False
        ) -> Optional[FXRate]:
            # TODO: Implement this method.
            return None

        def queries(
            self, queries: Iterable[TQuery], strict: bool = False
        ) -> Iterable[Optional[FXRate]]:
            # TODO: Implement this method.
            return []
            # TODO: Fill in this test case.

# Generated at 2022-06-26 00:52:34.714689
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-26 00:52:39.133645
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert_equals(nrate.__invert__(), rrate)


# Generated at 2022-06-26 00:52:55.602972
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporal import TimeStamp
    from .currencies import Currency
    from .commons.zeitgeist import date

    cur1 = Currency("EUR")
    cur2 = Currency("USD")
    dt = date(2017, 1, 1)
    fxr = FXRate(cur1, cur2, dt, 2)
    queries = [(cur1, cur2, TimeStamp(dt))]
    FXRateService.queries(queries, False)

# Generated at 2022-06-26 00:52:59.690768
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    fx_rate_service_0 = FXRateService()
    try:
        fx_rate_service_0.query(currency_0, currency_0, date_0, strict_0)
    except Exception as e_query_0:
        pass
    # TODO: Add test to check if no exception was raised


# Generated at 2022-06-26 00:53:01.010046
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:53:03.103929
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    rate = FXRate()
    FXRateService.queries([rate])


# Generated at 2022-06-26 00:53:11.812881
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ## Let's mock some FX rates with a list:
    fx_rates = [
        FXRate.of(Currency("EUR"), Currency("USD"), Date(2018, 1, 1), Decimal("1.25")),
        FXRate.of(Currency("EUR"), Currency("USD"), Date(2018, 2, 1), Decimal("1.30")),
        FXRate.of(Currency("EUR"), Currency("USD"), Date(2018, 3, 1), Decimal("1.35")),
        FXRate.of(Currency("EUR"), Currency("USD"), Date(2018, 4, 1), Decimal("1.40")),
    ]

    ## Let's mock a FX rates service with a class:

# Generated at 2022-06-26 00:53:21.246841
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class fxRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
            queries = None
            strict = True
            strict = False
            queries = [None]
            queries = [1]
            queries = [Currency, Currency, Datetime.date.today()]
    fxRateService = fxRateService()
    fxRateService_query = fxRateService.query(Currency, Currency, Datetime.date.today())
    assert fxRateService_query is None
    fxRateService_query_0 = fxRateService.query

# Generated at 2022-06-26 00:53:29.409324
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .currencies import Currencies
    from .fx import FXRate

    from .currencies import Currency
    from .currencies import Currencies
    from .currencies import CurrencyName
    from .currencies import CurrencyCode
    from .currencies import CurrencyUnit
    from .fx import FXRate
    from .fx import FXRateService

    import datetime

    service1 = FXRateService()
    ccy1 = Currency(CurrencyName("EUR"), CurrencyCode("EUR"), CurrencyUnit("1"), 100)
    ccy2 = Currency(CurrencyName("USD"), CurrencyCode("USD"), CurrencyUnit("1"), 100)
    date = datetime.date.today()
    strict = False
    service1.query(ccy1, ccy2, date, strict)


# Generated at 2022-06-26 00:53:30.471205
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:53:31.394537
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:53:32.176779
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert False, "Not implemented."


# Generated at 2022-06-26 00:53:44.924417
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ccy1_0 = Currency('', '', 0, CurrencyType.ALTERNATIVE, None, 0)
    ccy2_0 = Currency('', '', 0, CurrencyType.ALTERNATIVE, None, 0)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    strict_0 = False
    optional_f_x_rate_0 = f_x_rate_service_0.query(ccy1_0, ccy2_0, date_0, strict_0)
    assert optional_f_x_rate_0 is None


# Generated at 2022-06-26 00:53:53.045180
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\t'
    int_0 = -1995961982
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = -1009651376
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    currency_1 = currency_0
    query_0 = (currency_0, currency_1, None)
    f_x_rate_service_0 = FXRateService()
    result = f_x_rate_service_0.queries((query_0, query_0), True)


# Generated at 2022-06-26 00:53:59.028631
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'Q\\qK&dtjdC{`\x0bh/]h[O2'
    int_0 = -1174
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 00:54:06.619461
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\x17\x0b\x1e\x12\x0c'
    decimal_0 = None
    int_1 = -1533
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    str_1 = '\n\x1f\x1e\n"\x0e\r\r'
    int_2 = -1377
    currency_1 = module_0.Currency(str_0, str_0, int_1, currency_type_0, decimal_0, int_2)
    f_x_rate_service_1 = FXRateService()

# Generated at 2022-06-26 00:54:08.504598
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: implement test for method query of class FXRateService
    pass


# Generated at 2022-06-26 00:54:18.213503
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'L\teA_'
    int_0 = -1149
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 285
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'K:^i@T=V\x0bRR\x1aK'
    int_2 = -1847
    currency_type_1 = module_0.CurrencyType.SPECIALDRAWINGRIGHTS
    decimal_1 = None
    int_3 = 648

# Generated at 2022-06-26 00:54:22.971905
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries = []
    f_x_rate_service_0 = FXRateService()
    queries.append(FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.1")))
    assert(list(f_x_rate_service_0.queries(queries)) == [None])


# Generated at 2022-06-26 00:54:32.566734
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'aFzs\x19\x0bK%t\x7fZ*\tA\x1e@n'
    int_0 = -1286
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = -1255
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()
    strict_0 = True

# Generated at 2022-06-26 00:54:40.778929
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'Q\\qK&dtjdC{`\x0bh/]h[O2'
    int_0 = -1174
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    assert_raises(f_x_rate_service_0.query, f_x_rate_lookup_error_0)



# Generated at 2022-06-26 00:54:49.491064
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'q-jKV7O&-'
    int_0 = -3211
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 405
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()


# Generated at 2022-06-26 00:55:08.822960
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 00:55:19.440423
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # initialize value and expected value
    str_0 = '7pjh^!uR\\j1i\x0b.^x\x0c'
    int_0 = -1234
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = -18
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    date_1 = None
    f_x_rate_lookup_error_1 = FXRateLookupError(currency_0, currency_0, date_0)
    # call function and test results
    result = f_x_

# Generated at 2022-06-26 00:55:26.841098
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '7DU6nF\x7f4'
    int_0 = -1174
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()


# Generated at 2022-06-26 00:55:35.806783
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'q\x1a1|>8W[o'
    int_0 = -937
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'k'
    int_2 = -225
    currency_type_1 = module_0.CurrencyType.OFFICIAL
    decimal_1 = None
    int_3 = 360
    currency_1 = module_0.Currency(str_1, str_1, int_2, currency_type_1, decimal_1, int_3)
    date_0 = None
    bool

# Generated at 2022-06-26 00:55:36.648997
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:55:47.590080
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'Xs{\\A|U6mJj'
    int_0 = -1230
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 666
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()
    strict_0 = True

# Generated at 2022-06-26 00:55:58.144724
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # queries
    queries_0 = [['G', 'Y', 'wk$']]
    queries_1 = [['{', ']', '^']]
    queries_2 = [[' ', '*', 'NkU']]
    queries_3 = [['f', 'M', '%']]
    queries_4 = [['O', 'u', 'x']]
    queries_5 = [['/', '|', '>B']]
    queries_6 = [['l', 'S', '1{X']]
    queries_7 = [['M', 'K', 'y']]
    queries_8 = [['C', '9', 'R[a']]
    queries_9 = [['&', 'y', 'Nw']]
    queries_10 = [['l', '#', 'm']]
   

# Generated at 2022-06-26 00:56:07.296966
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'Q\\qK&dtjdC{`\x0bh/]h[O2'
    int_0 = -1174
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    tuple_0 = (currency_0, currency_0, date_0)
    iterable_0 = (tuple_0,)
    bool_0 = False
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(iterable_0, bool_0)

# Unit

# Generated at 2022-06-26 00:56:17.054988
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'A|\x0f\x14\x05\x1e\x12\x10\x1e\x1f`\x17\x1b\x16'
    int_0 = -1174
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = '9#\x1dBR\x1d\x1b\x1f\r\x04\x01\x1b\x0e\x1e'
    int_2 = -1174
    currency_type_1 = module_0.Currency

# Generated at 2022-06-26 00:56:26.635377
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\x0f\x04\r\x06T\x0f'
    str_1 = '\x0f\x04\r\x06T\x0f'
    int_0 = 474
    currency_type_0 = module_0.CurrencyType.ALT_COIN
    decimal_0 = None
    int_1 = 885
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    int_2 = -24
    str_2 = '\x0f\x04\r\x06T\x0f'
    str_3 = '\x0f\x04\r\x06T\x0f'
    currency

# Generated at 2022-06-26 00:56:52.918427
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '`\x0ak\x1d/q*nD/\x1eV\\\x0fv\\'
    int_0 = -5105
    currency_type_0 = module_0.CurrencyType.COMMODITY
    decimal_0 = None
    int_1 = -561
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    str_1 = 'b'
    int_2 = -9857
    currency_type_1 = module_0.CurrencyType.FIAT
    decimal_1 = None
    int_3 = -28

# Generated at 2022-06-26 00:57:04.906974
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'oL=4\x0b[a1${zZ9~c/'
    int_0 = -1570
    currency_type_0 = module_0.CurrencyType.VIRTUAL
    decimal_0 = None
    int_1 = 332
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    int_2 = 9370
    str_1 = '\\j\x1b6U}0oC,\x1a}|,`N'
    int_3 = -5171
    currency_type_1 = module_0.CurrencyType.REAL
    decimal_1 = None
    int_4 = -6513
    currency_

# Generated at 2022-06-26 00:57:11.196070
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\x19\x1e\r'
    str_1 = ''
    currency = module_0.Currency(str_0, str_1, -650, module_0.CurrencyType.ALTERNATIVE, None, 1045)
    date_0 = None
    query = (currency, currency, date_0)
    iterable = [query]
    f_x_rate_service = FXRateService()
    f_x_rate_service.queries(iterable)

# Generated at 2022-06-26 00:57:22.030153
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_2 = '5'
    int_5 = -961
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    decimal_1 = None
    int_6 = -1038
    currency_2 = module_0.Currency(str_2, str_2, int_5, currency_type_1, decimal_1, int_6)

# Generated at 2022-06-26 00:57:34.442681
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import pypara.dates as module_1
    import pypara.fxrates as module_2

# Generated at 2022-06-26 00:57:43.292818
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '?0MM+{)>/^Dhq'
    int_0 = -1621
    currency_type_0 = module_0.CurrencyType.COMMODITY
    decimal_0 = Decimal('Infinity')
    int_1 = 1248
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = date(year=2030, month=1, day=1)
    f_x_rate_service_0 = FXRateService()
    str_1 = '#D@'
    int_2 = -1856
    currency_type_1 = module_0.CurrencyType.BOND
    decimal_1 = Decimal('Infinity')

# Generated at 2022-06-26 00:57:48.560434
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # f_x_rate_service_0 = FXRateService(), ccy1 = 'H\r\r\x0c', ccy2 = 'Y\x0b\n\x0e', ccy2 = '\x0c\x0b\x07\x0b\r\r', asof = '\x0e', strict = '\x0f\x07\x0f\x0f'
    pass


# Generated at 2022-06-26 00:57:52.365047
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries_0 = [tuple(), (tuple(),), tuple()]
    print('Testing method queries of class FXRateService')
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(queries_0)


# Generated at 2022-06-26 00:58:01.699087
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    str_0 = 'f\'@gM\x0bPo\x07'
    int_0 = -4319
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 702
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'js_=4]q~;\x06'
    int_2 = -26115
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    decimal_1 = None
    int_3 = 2423

# Generated at 2022-06-26 00:58:11.153471
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 00:58:57.925683
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_2
    str_1 = '1\n;*c\x7f`M\x0f'
    int_3 = -742
    decimal_1 = None
    int_4 = -12
    currency_1 = module_2.Currency(str_1, str_1, int_3, module_2.CurrencyType.ALTERNATIVE, decimal_1, int_4)
    date_1 = None
    f_x_rate_service_1 = FXRateService()
    args_1 = (currency_1, currency_1, date_1, False)
    query_0 = f_x_rate_service_1.query(*args_1)
    assert query_0 == None
    import pypara.currencies as module_3

# Generated at 2022-06-26 00:59:06.120362
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'B!h\x0cD4xPd\x0ce'
    int_0 = -741
    currency_type_0 = module_0.CurrencyType.COMMODITY
    decimal_0 = None
    int_1 = 988
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = '\x18\t"\x13Q'
    int_2 = -841
    currency_type_1 = module_0.CurrencyType.CRYPTO
    decimal_1 = None
    int_3 = 224

# Generated at 2022-06-26 00:59:13.443071
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 's?0b{'
    int_0 = -1467
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 69
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()


# Generated at 2022-06-26 00:59:19.326365
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'p/G\x7fUi\rN7\x7f|Y\rN7\x7f|Y\x0c'
    int_0 = 668
    currency_type_0 = module_0.CurrencyType.FIXED
    decimal_0 = None
    int_1 = 90
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    currency_1 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    decimal_1 = None

# Generated at 2022-06-26 00:59:27.726143
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\x16\x1f\x13\x0b\n\x03\x06\x17\x02'
    int_0 = -1174
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = '\x16\x1f\x13\x0b\n\x03\x06\x17\x02'
    int_2 = -1174
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    decimal_1 = None
    int_3 = 360
    currency_1

# Generated at 2022-06-26 00:59:38.238518
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'Q\\qK&dtjdC{`\x0bh/]h[O2'
    int_0 = -1174
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    currency_1 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_1 = None
    f_x_rate_service_0 = FXRateService()
    strict = False

# Generated at 2022-06-26 00:59:49.432066
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'q|,@'
    int_0 = -1174
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    currency_1 = currency_0
    date_0 = None
    tuple_0 = (currency_1, currency_0, date_0)
    list_0 = [tuple_0]
    f_x_rate_service_0 = FXRateService()
    if __debug__:
        f_x_rate_service_0.queries(list_0)



# Generated at 2022-06-26 01:00:01.788095
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\x01\x05\x1b\x1e'
    int_0 = 1405
    currency_type_0 = module_0.CurrencyType.CURRENCY
    decimal_0 = None
    int_1 = 791
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    date_1 = None
    tuple_0 = (currency_0, currency_0, date_1)
    iterable_0 = (tuple_0,)
    f_x_rate_service_0 = FXRateService()
    int_2 = 1
    f_x_rate_service_0.queries(iterable_0, int_2)

    int_

# Generated at 2022-06-26 01:00:13.073786
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'Q\\qK&dtjdC{`\x0bh/]h[O2'
    int_0 = -1174
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 360
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 01:00:23.527880
# Unit test for method query of class FXRateService