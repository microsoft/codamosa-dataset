

# Generated at 2022-06-26 00:51:44.041782
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:51:46.131153
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert f_x_rate_service_0.query(ccy1=Currency, ccy2=Currency, asof=Date, strict=bool) in (None, FXRate)


# Generated at 2022-06-26 00:51:55.756238
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # test function.
    f_x_rate_service_0 = FXRateService()
    # f_x_rate
    f_x_rate_0 = FXRate(Currency("USD"), Currency("EUR"), Date(), Decimal("2.0"))
    f_x_rate_1 = FXRate(Currency("USD"), Currency("EUR"), Date(), Decimal("0.5"))
    # f_x_rate_service_0.query(Currency("USD"), Currency("EUR"), Date(2017, 5, 16, 23, 34, 5, 6))
    assert f_x_rate_service_0.query(Currency("USD"), Currency("EUR"), Date(2017, 5, 16, 23, 34, 5, 6)) == ~f_x_rate_0
    # f_x_rate_service_0.query(

# Generated at 2022-06-26 00:51:56.982403
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:52:04.675744
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .fx_services import HistoricalFXRateService
    fx_rate_service = HistoricalFXRateService('./data/fx_data.csv')

    # Check that the error is properly raised
    try:
        fx_rate_service.query(Currency('CAD'), Currency('USD'), date(2007, 1, 3))
    except FXRateLookupError as e:
        pass
    else:
        # Calling assertTrue raises AssertionError within pytest
        assert True == False

    # Check if the rate is properly calculated
    result = fx_rate_service.query(Currency('CAD'), Currency('USD'), date(2007, 1, 4))
    assert result == FXRate(Currency('CAD'), Currency('USD'), date(2007, 1, 4), 1.163)


# Generated at 2022-06-26 00:52:13.455689
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    currency_0 = Currency('EUR')
    currency_1 = Currency('USD')
    date_0 = Date(2019, 12, 12)
    date_1 = Date(2020, 11, 10)
    FXRateService.TQuery.__getitem__ = Mock(side_effect=[currency_0, currency_1, date_0, currency_1, currency_0, date_1])
    f_x_rate_service_0.query = Mock(side_effect=[None, None])
    queries_0 = [FXRateService.TQuery]
    queries_1 = f_x_rate_service_0.queries(queries_0, False)
    queries_2 = f_x_rate_service_0.query.call_args_list[0]


# Generated at 2022-06-26 00:52:21.531277
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # ============================================================================
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # Case 0: No queries.
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    f_x_rate_service_0 = FXRateService()

    assert list(f_x_rate_service_0.queries([])) == []

    # ============================================================================
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # Case 1: One query.
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    f_x_rate_service_1 = FXRateService()

    assert list(f_x_rate_service_1.queries([(Currency("EUR"), Currency("USD"), Date.today())])) == [None]

    # ============================================================================
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


# Generated at 2022-06-26 00:52:24.188096
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    temp_list_0 = (1,)
    try:
        f_x_rate_service_0.queries(temp_list_0)
    except TypeError as e:
        pass

# Generated at 2022-06-26 00:52:32.646750
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporals
    ccy1 = Currencies['EUR']
    ccy2 = Currencies['TRY']
    temporal = Temporals.today()
    fx_rate_s = FXRateService()
    queries = [(ccy1, ccy2, temporal)]
    rate = fx_rate_s.queries(queries)

# Generated at 2022-06-26 00:52:33.495130
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:52:51.524361
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_type_0 = module_0.CurrencyType.METAL
    str_0 = '\x1b\x1c\x0b\x1c\x1e\x1c\x1f\x1e\x0b\x0b\x1c\x1e\x13\x0f\x1e\n\n\x1d\x1e\x1c\x1f\n\r\r\x0e\x16\x1e'
    decimal_0 = module_1.Decimal()

# Generated at 2022-06-26 00:53:00.339512
# Unit test for method query of class FXRateService

# Generated at 2022-06-26 00:53:09.998803
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    #//
    #// [query - FXRateService.query]
    #//
    str_0 = 'mpA 4x+f'
    str_1 = 'Q0=D$+`0&?j'
    int_0 = 1441
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = '3'
    str_3 = 'T:y%t{0w!_'
    int_1 = 2
    currency_type_1 = module_0.CurrencyType.METAL

# Generated at 2022-06-26 00:53:19.619790
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'wFxr'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2290
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal(0)
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()
    str

# Generated at 2022-06-26 00:53:28.042873
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\x04'
    str_1 = '\x04'
    decimal_0 = module_1.Decimal(str_0)
    currency_0 = module_0.Currency(str_1, str_1, str_0, str_0, decimal_0, str_0)
    int_0 = 0
    currency_1 = module_0.Currency(str_0, str_0, str_0, str_0, decimal_0, int_0)
    f_x_rate_0 = FXRate(currency_0, currency_1, str_0, str_0)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(currency_0, currency_1, str_0)


# Generated at 2022-06-26 00:53:36.816533
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'Z'
    str_1 = 'j'
    int_0 = 0
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_2 = '`[k^R'
    set_0 = {str_2}
    f_x

# Generated at 2022-06-26 00:53:45.292736
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'ocoEhz1_].OG{'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()


# Generated at 2022-06-26 00:53:54.294548
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'ocoEhz1_].OG{'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()


# Generated at 2022-06-26 00:54:00.138551
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create the FX service for testing purposes:

# Generated at 2022-06-26 00:54:08.236076
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'ocoEhz1_].OG{'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()


# Generated at 2022-06-26 00:54:28.182466
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    list_0 = []
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [f_x_rate_1, f_x_rate_0, list_0, list_0]
    f_x_rate_service_1 = FXRateService(*list_1)
    str_0 = '6Z9[1H'
    str_1 = 'yc^'
    int_0 = 681
    currency_type_0 = module_0.CurrencyType.COUNTRY_SPECIFIC
    decimal_0 = module_1.Decimal()

# Generated at 2022-06-26 00:54:36.730326
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'l@sQ7,#]\x1d7'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__

# Generated at 2022-06-26 00:54:45.225140
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(decimal_0, decimal_0, decimal_0, currency_type_0, decimal_0, decimal_0)
    currency_1 = module_0.Currency(decimal_0, decimal_0, decimal_0, currency_type_0, decimal_0, decimal_0)
    iterable_0 = [currency_0, currency_1]
    iterable_1 = iterable_0
    iterable_2 = iterable_1
    iterable_3 = iterable_2
    currency_2 = module_0.Currency(decimal_0, decimal_0, decimal_0, currency_type_0, decimal_0, decimal_0)

# Generated at 2022-06-26 00:54:56.668499
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    decimal_0 = module_1.Decimal()
    str_0 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    str_1 = 'ocoEhz1_].OG{'
    int_0 = 1578
    currency_type_0 = module_0.CurrencyType.METAL
    currency_0 = module_0.Currency(str_1, str_0, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_0 = FXRate(currency_0, currency_0, date_0, decimal_0)
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 00:55:07.745045
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'ocoEhz1_].OG{'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()


# Generated at 2022-06-26 00:55:18.654389
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '7)P'
    int_0 = 443
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_1 = '{<'
    set_0 = {str_1}
    f_x_rate_service_0 = FXRate

# Generated at 2022-06-26 00:55:21.487334
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = [None, None, None]
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(list_0)


# Generated at 2022-06-26 00:55:23.847810
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = {FXRate()}
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(set_0, list())

# Generated at 2022-06-26 00:55:29.856486
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'lY}d8'
    list_0 = [str_0]
    currency_1 = module_0.Currency(*list_0)
    date_0 = None
    f_x_rate_0 = FXRate(currency_1, currency_1, date_0, 2)
    f_x_rate_service_0 = FXRateService(*list_0)
    fx_rate_service_1 = FXRateService()
    f_x_rate_1 = f_x_rate_service_0.query(currency_1, currency_1, date_0)
    assert(f_x_rate_1 is None)
    f_x_rate_2 = fx_rate_service_1.query(currency_1, currency_1, date_0)

# Generated at 2022-06-26 00:55:38.800655
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '-A8'
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_0 = 1836
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_1 = '\x1a6\x1a"'
    set_0 = {str_1}
    f_x_rate

# Generated at 2022-06-26 00:56:04.835699
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = [True, True]
    f_x_rate_service_0 = FXRateService(*list_0)
    f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_0, date_0)
    str_0 = 'ocoEhz1_].OG{'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x

# Generated at 2022-06-26 00:56:10.231733
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    set_0 = {None}
    iterable_0 = f_x_rate_service_0.queries(set_0)
    assert iterable_0 != iterable_0
    assert len(iterable_0) == 0
    assert list(iterable_0) == [None]
    assert next(iterable_0) == None


# Generated at 2022-06-26 00:56:19.708338
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Implicit parameter 'self'
    set_0 = {str_2}
    f_x_rate_service_0 = FXRateService()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    currency_1 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    fx_rate_service = FXRateService(currency_0, currency_1, date_0, int_0)
    fx_rate_service.query(currency_0, currency_1, date_0, int_0)
    fx_rate_service.query(currency_1, currency_0, date_0, int_0)
    f

# Generated at 2022-06-26 00:56:29.145448
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Setup
    type_0 = int
    type_1 = decimal.Decimal 
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    string_0 = 'y'
    string_1 = 'G*'
    int_0 = 4800
    currency_0 = module_0.Currency(string_0, string_1, int_0, currency_type_0, decimal_0, int_0)
    int_1 = 1915
    currency_1 = module_0.Currency(string_1, string_0, int_1, currency_type_0, decimal_0, int_1)
    date_time_0 = datetime.date.today()
    decimal_1 = module_1.Decimal()
    f_x_rate

# Generated at 2022-06-26 00:56:38.386109
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'ocoEhz1_].OG{'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()


# Generated at 2022-06-26 00:56:47.983679
# Unit test for method query of class FXRateService

# Generated at 2022-06-26 00:56:51.945419
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_0 = FXRate()
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(f_x_rate_0, f_x_rate_0, f_x_rate_0, True)


# Generated at 2022-06-26 00:57:03.899450
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Tests that a FXRateLookupError is thrown when no 'FXRate' can be found.
    import pypara.currencies as module_0
    import decimal as module_1
    import datetime as module_2
    str_0 = 'ocoEhz1_].OG{'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = module_2.date.today()
    f_x_rate_lookup

# Generated at 2022-06-26 00:57:11.653037
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'ocoEhz1_].OG{'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_1 = f_x_rate_0.__invert__()


# Generated at 2022-06-26 00:57:22.232644
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Test when 'self' is not of type FXRateService
    set_0 = set()
    try:
        raise ValueError('exception raised')
        raise RuntimeError('exception raised')
    except Exception as e:
        print('exception handling works')
    try:
        raise ValueError('exception raised')
    except Exception as e:
        print('exception handling works')
    # Test when 'queries' is not of type Iterable
    decimal_0 = module_1.Decimal()
    decimal_1 = decimal_0.__invert__()
    f_x_rate_0 = FXRate(decimal_1, decimal_1, decimal_1, decimal_0)
    try:
        raise ValueError('exception raised')
        raise RuntimeError('exception raised')
    except Exception as e:
        print

# Generated at 2022-06-26 00:57:51.972189
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
   pass


# Generated at 2022-06-26 00:58:01.356916
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    print("Testing method query of type FXRateService")
    currency_type_0 = module_0.CurrencyType.CRYPTO
    currency_1 = module_0.Currency(None, None, None, currency_type_0, None, None)
    currency_2 = module_0.Currency()
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_1 = FXRateService()
    f_x_rate_1 = f_x_rate_service_1.query(currency_1, currency_2, date_0)
    assert (f_x_rate_1 is None)
    currency_3 = module_0.Currency()
    currency_4 = module_0.Currency()
    f_x_rate_2 = f_x

# Generated at 2022-06-26 00:58:10.968152
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '^4_}d)a'
    str_1 = '\x1a'
    int_0 = -13383
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal('-0.02699')
    currency_1 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    int_1 = 0
    currency_type_1 = module_0.CurrencyType.METAL
    decimal_1 = module_1.Decimal()
    currency_2 = module_0.Currency(str_1, str_1, int_1, currency_type_1, decimal_1, int_0)
    date_0 = None
    f

# Generated at 2022-06-26 00:58:19.916175
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Test with the default value of arguments:
    currency_0 = module_0.Currencies['EUR']
    currency_1 = module_0.Currencies['USD']
    date_0 = Date('2018-01-01')
    set_0 = {(currency_0, currency_1, date_0)}
    f_x_rate_0 = FXRate(currency_0, currency_1, date_0, Decimal('0.5'))
    f_x_rate_service_0 = TestFXRateService(f_x_rate_0)
    iterable_0 = f_x_rate_service_0.queries(set_0, False)
    __result_expected = [f_x_rate_0]
    list_0 = []
    for i_0 in iterable_0:
        list_0

# Generated at 2022-06-26 00:58:29.956557
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import random
    # Setup
    FXRateService_class_type = FXRateService()
    # Assert pre-conditions
    list_0 = []
    decimal_0 = module_1.Decimal(list_0)
    currency_0 = module_0.Currency(list_0, list_0, int(list_0), 
                                   module_0.CurrencyType.FIAT, decimal_0, int(list_0))
    list_1 = [currency_0, currency_0, list_0]
    list_2 = [list_1, list_1, list_1]
    FXRate_0 = FXRate(*list_2)
    assert (FXRateService_class_type.query(currency_0, currency_0, list_0, bool(list_0)) == 
            FXRate_0)

# Generated at 2022-06-26 00:58:31.454454
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method `queries` of class `FXRateService`
    """

    test_case_0()



# Generated at 2022-06-26 00:58:32.305040
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:58:40.001802
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\x1c'
    int_0 = -291
    str_1 = 'Z=/[\\L\\'
    int_1 = 0
    decimal_0 = module_1.Decimal()
    currency_type_0 = module_0.CurrencyType.METAL
    str_2 = 'S'
    currency_0 = module_0.Currency(str_2, str_0, int_1, currency_type_0, decimal_0, int_0)
    currency_1 = module_0.Currency(str_1, str_0, int_1, currency_type_0, decimal_0, int_0)
    f_x_rate_0 = FXRate.of(currency_1, currency_0, module_0.Date(int_1, int_1), decimal_0)

# Generated at 2022-06-26 00:58:47.832964
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '$<#KGHB'
    str_1 = '9Q['
    int_0 = 1739
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = '8W5Y'
    str_3 = '<Mc'
    int_1 = 1216
    currency_type_1 = module_0.CurrencyType.METAL
    decimal_1 = module_1.Decimal()

# Generated at 2022-06-26 00:58:55.775837
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import decimal as module_1
    str_0 = 'ocoEhz1_].OG{'
    str_1 = '\n    Type of functions which read chart-of-accounts from a source.\n    '
    int_0 = 2045
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f

# Generated at 2022-06-26 01:00:09.533409
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'N\'q^'
    set_0 = {str_0}
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(set_0)


# Generated at 2022-06-26 01:00:11.447039
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # dist/build/test/test-inplace: FXRateService.query: FAIL
    assert False


# Generated at 2022-06-26 01:00:14.355234
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert True


# Generated at 2022-06-26 01:00:24.128562
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ';`n{'
    str_1 = 'Fv<Jh'
    int_0 = 516
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    currency_1 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    bool_0 = False
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 01:00:29.418140
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = Currencies['USD']
    currency_1 = Currencies['CAD']
    date_0 = Date()
    tuple_0 = (currency_0, currency_1, date_0)
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries((tuple_0,))
    assert iterable_0 == [None]


# Generated at 2022-06-26 01:00:35.204691
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    FXRateService_instance = FXRateService()
    queries = None
    strict = None
    try:
        FXRateService_instance.queries(queries, strict)
        print("Success")
    except LookupError as e:
        print(e)
    except TypeError as e:
        print(e)
    except ValueError as e:
        print(e)


# Generated at 2022-06-26 01:00:42.213196
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'Default'
    int_0 = 2045
    set_0 = set()
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(set_0)
    list_0 = [int_0]
    tuple_0 = (str_0, list_0)
    tuple_1 = (str_0, list_0)
    set_1 = {tuple_0, tuple_1}
    f_x_rate_service_1 = FXRateService()
    iterable_1 = f_x_rate_service_1.queries(set_1)


# Generated at 2022-06-26 01:00:51.857502
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '_v%^[h9'
    int_0 = -14
    currency_type_0 = module_0.CurrencyType.FIAT
    decimal_0 = module_1.Decimal()
    date_0 = None
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_0, date_0)
    str_1 = '.`\\c%'
    int_1 = -45
    decimal_1 = module_1.Decimal()
    currency_1 = module_0.Currency(str_1, str_0, int_0, currency_type_0, decimal_1, int_0, date_0, decimal_1)
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 01:00:58.533802
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from .currencies import Currencies
    from .exchange.rates import FXRate, FXRateService

    ## Create a service which returns a fixed rate:
    class MockService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
            else:
                return FXRate(ccy1, ccy2, asof, Decimal("0.9"))


# Generated at 2022-06-26 01:01:03.959132
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_name_0 = '\n        Kind of the abovementioned object.\n        '
    currency_code_0 = '\r\r    '
    currency_symbol_0 = '\r\r    '
    currency_0 = module_0.Currency(currency_name_0, currency_code_0, 2045, None, None, 2045, currency_symbol_0, None)
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(iterable_0)
