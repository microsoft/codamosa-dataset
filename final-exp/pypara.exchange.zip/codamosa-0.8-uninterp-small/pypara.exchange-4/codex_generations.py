

# Generated at 2022-06-26 00:51:46.879323
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:51:52.842828
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    start_time = datetime.date.today() 
    end_time = datetime.date.today()
    asof = datetime.date.today()
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    strict = True
    FXRateService.query(ccy1,ccy2,asof,strict)
    return True


# Generated at 2022-06-26 00:51:58.694539
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import now
    f_x_rate_service_0 = FXRateService()
    list_0 = [FXRate(Currencies["EUR"], Currencies["USD"], now(), Decimal('0.5'))]
    list_1 = f_x_rate_service_0.queries([Currencies["EUR"], Currencies["USD"], now()])
    assert list_0 == list_1


# Generated at 2022-06-26 00:52:06.602416
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    f_x_rate_0 = FXRate(Currencies['EUR'],Currencies['USD'],Date(2016,11,12),Decimal(2))
    f_x_rate_1 = f_x_rate_service_0.query(Currencies['EUR'],Currencies['USD'],Date(2016,11,12))
    f_x_rate_2 = f_x_rate_service_0.query(Currencies['USD'],Currencies['EUR'],Date(2016,11,12))
    assert f_x_rate_0 == f_x_rate_1
    assert  ~f_x_rate_0 == f_x_rate_2

# Generated at 2022-06-26 00:52:15.166909
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.fx.services import InMemoryFXRateService
    import datetime

    f_x_rate_service_0 = InMemoryFXRateService()
    try:
        f_x_rate_service_0.query(Currencies.EUR, Currencies.USD, Date(datetime.date(2000, 1, 1)))
        assert False, "Should not succeed"
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies.EUR
        assert e.ccy2 == Currencies.USD
        assert e.asof == Date(datetime.date(2000, 1, 1))


# Generated at 2022-06-26 00:52:17.999637
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Step 1
    f_x_rate_service_1 = FXRateService()
    f_x_rate_service_1.queries([(Currency.USD, Currency.EUR, Date.of(2019, 7, 1))])



# Generated at 2022-06-26 00:52:19.635027
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    instance = f_x_rate_service_0()
    assert isinstance(instance.queries(iterable_0), Iterable)


# Generated at 2022-06-26 00:52:31.946709
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.fx.repository import InMemoryFXRateRepository
    from pypara.fx.service import FXRateServiceImpl

    ## Set up the FX rate repository:
    f_x_rate_repository_0 = InMemoryFXRateRepository()

    ## Set up the FX rate service:
    f_x_rate_service_1 = FXRateServiceImpl(f_x_rate_repository_0)

    ## List of queries to be made:

# Generated at 2022-06-26 00:52:32.899210
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:52:36.235611
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_1 = FXRateService()
    result = f_x_rate_service_1.query(ccy1=None,ccy2=None,asof=None,strict=False)
    assert isinstance(result, Optional[FXRate])


# Generated at 2022-06-26 00:52:53.047408
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Testcase_0
    # Testcase_0_0
    class f_x_rate_service_0(FXRateService):
        def __init__(self):
            super().__init__()
            self._rates = {}
        def query(self, ccy1, ccy2, asof, strict=False):
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
        def queries(self, queries, strict=False):
            return ()

    class f_x_rate_0(FXRate):
        def __init__(self):
            self._ccy1 = object()
            self._ccy2 = object()
            self._date = object()
            self._value = object()
        @property
        def ccy1(self):
            return self.__cc

# Generated at 2022-06-26 00:53:01.708310
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    float_0 = 4472.25934
    dict_0 = {}
    list_0 = [dict_0, dict_0, float_0, float_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_service_0 = FXRateService(**dict_0)

# Generated at 2022-06-26 00:53:07.972665
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    dict_0 = {}
    list_0 = [dict_0, dict_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_service_0 = FXRateService(**dict_0)
    list_1 = []
    bool_0 = f_x_rate_service_0.queries(list_1)
    bool_1 = f_x_rate_service_0.queries(list_1, bool_0)


# Generated at 2022-06-26 00:53:14.499453
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    float_0 = 4472.25934
    dict_0 = {}
    list_0 = [dict_0, dict_0, float_0, float_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_service_0 = FXRateService(**dict_0)
    assert f_x_rate_service_0.query(f_x_rate_0, float_0, float_0) == f_x_rate_0


# Generated at 2022-06-26 00:53:22.888917
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ### Initialization:
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService
    from pypara.fxrates.sources import FXRateSource

    ## (1): Class level:
    source = FXRateSource.from_csv()
    FXRateService.from_source(source)

    ## (2): Instance level:
    fxrate_svc = FXRateService()

    ## (3): Query FX rate:
    fxrate = fxrate_svc.query(Currencies["EUR"], Currencies["USD"], date(2019, 1, 1))
    assert fxrate is not None and isinstance(fxrate, FXRate)
    assert fxrate.ccy1 == Currencies["EUR"]

# Generated at 2022-06-26 00:53:30.581425
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    float_0 = 4975.2175
    dict_0 = {}
    list_0 = [dict_0, dict_0, float_0, float_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_service_0 = FXRateService(**dict_0)
    bool_0 = f_x_rate_service_0.query(**dict_0)
    bool_1 = f_x_rate_service_0.query(**dict_0)
    bool_2 = f_x_rate_service_0.query(**dict_0)


# Generated at 2022-06-26 00:53:39.149393
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    float_0 = 24.78645
    str_0 = 'j1"*l`aG>;,|'
    list_0 = [float_0, str_0]
    int_0 = 6988
    str_1 = '`|yt9XD|'
    float_1 = 2.0678
    list_1 = [float_1, int_0, str_1]
    str_2 = 'HaN'
    int_1 = 9
    list_2 = [int_1, str_2, float_0]
    str_3 = "#Y1i7^s'C4[4/"
    float_2 = 28.6
    int_2 = 68
    float_3 = 4.0
    int_3 = 79
    str_4 = '!'
    float_4 = 15.

# Generated at 2022-06-26 00:53:47.602130
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    float_0 = 4472.25934
    dict_0 = {}
    list_0 = [dict_0, dict_0, float_0, float_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_service_0 = FXRateService(**dict_0)
    list_1 = [float_0]
    str_0 = 'qmJ#3pWQmG7Qn#w'
    dict_1 = {str_0: float_0}
    f_x_rate_2 = FXRate(*list_1, **dict_1)


# Generated at 2022-06-26 00:53:55.749634
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Runs this method's kind of unit test.
    from .commons.zeitgeist import now
    from .currencies import Currency, Currencies
    from .exchange.rates import FXRateService, FXRateServiceError
    # Test definition of `FXRateService` and its default property.
    assert FXRateService.default is None
    # Set up an instance of `NullFXRateService`.
    null_fx_rate_service = FXRateService()
    assert null_fx_rate_service.default is None
    # Fetch the default `FXRateService`.
    try:
        FXRateService.default
    except FXRateServiceError as e:
        assert str(e) == "No default FX rate service available. Make sure you set up one."
        assert isinstance(e, FXRateServiceError)

# Generated at 2022-06-26 00:53:59.795097
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    float_0 = 4472.25934
    dict_0 = {}
    list_0 = [dict_0, dict_0, float_0]
    f_x_rate_0 = FXRate(*list_0)
    list_1 = [f_x_rate_0]
    f_x_rate_service_0 = FXRateService(**dict_0)
    f_x_rate_1 = f_x_rate_service_0.queries(list_1, **dict_0)


# Generated at 2022-06-26 00:54:13.371693
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    Date_0 = Date.of(2019, 3, 25)
    Currency_0 = Currency("AUD")
    Currency_1 = Currency("CAD")
    FXRateService_0 = FXRateService()
    FXRateService_0.query(Currency_0, Currency_1, Date_0)


# Generated at 2022-06-26 00:54:18.764884
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## Creating the instance of FXRateService
    f_x_rate_service_0 = FXRateService("EUR", "USD", "2019-05-25")
    ## Checking the type of the instance
    assert isinstance(f_x_rate_service_0, FXRateService)
    ## Calling the method query of the instance
    f_x_rate_service_0.query("EUR", "USD", "2019-05-25", False)


# Generated at 2022-06-26 00:54:28.973887
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from collections import OrderedDict
    from django.test import TestCase
    from django.conf import settings
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies


# Generated at 2022-06-26 00:54:37.486627
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    import random
    import unittest
    import unittest.mock

    from decimal import Decimal

    from pypara.currencies import Currencies

    class LocalFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(random.uniform(1, 100)))

    class TestFXRateService(unittest.TestCase):
        def setUp(self):
            self.fx_rate_service = LocalFXRateService()

        def test_query(self):
            for i in range(1, 10):
                date = datetime.date.today()

# Generated at 2022-06-26 00:54:47.352934
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    float_0 = 4472.25934
    dict_0 = {}
    list_0 = [dict_0, dict_0, float_0, float_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_service_0 = FXRateService(**dict_0)
    list_1 = [float_0]
    str_0 = 'qmJ#3pWQmG7Qn#w'
    dict_1 = {str_0: float_0}
    f_x_rate_2 = FXRate(*list_1, **dict_1)
    list_2 = [f_x_rate_1]

# Generated at 2022-06-26 00:54:51.000469
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    dict_0 = {}
    f_x_rate_service_0 = FXRateService(**dict_0)
    try:
        f_x_rate_service_0.query(**dict_0)
    except:
        return False
    return True


# Generated at 2022-06-26 00:54:59.645984
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    tuple_0 = (['Z', 'P', 'j', 'Y'], ['p', 'y', 'j', 'V', 'Z'], ['p', 'B', 'j', 'V', 'Z'])
    str_0 = 'N'
    int_0 = -10979
    list_0 = [tuple_0, (int_0, str_0, 'm')]
    float_0 = 4472.25934
    dict_0 = {}
    list_1 = [dict_0, dict_0, float_0, float_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_service_0 = FXRateService(**dict_0)
    list

# Generated at 2022-06-26 00:55:09.313377
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    float_0 = 4410.452142
    float_1 = 4621.639255
    float_2 = 4147.82453
    float_3 = 4265.331208
    float_4 = 4468.348152
    float_5 = 4760.711349
    float_6 = 4408.192574
    float_7 = 4554.73966
    float_8 = 4579.094785
    float_9 = 4756.335586
    float_10 = 4146.382358
    float_11 = 4868.91956
    float_12 = 4887.975074
    float_13 = 4599.052634
    float_14 = 4523.695807
    float_15 = 4236.499732
    float_16 = 4692.48

# Generated at 2022-06-26 00:55:20.176943
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    float_0 = 4472.25934
    dict_0 = {}
    list_0 = [dict_0, dict_0, float_0, float_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_service_0 = FXRateService(**dict_0)
    list_1 = [float_0]
    str_0 = 'qmJ#3pWQmG7Qn#w'
    dict_1 = {str_0: float_0}
    f_x_rate_2 = FXRate(*list_1, **dict_1)
    list_2 = [f_x_rate_0, f_x_rate_2]

# Generated at 2022-06-26 00:55:27.146915
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    float_0 = 9205.87224
    float_1 = 2476.385215
    float_2 = 9700.959613
    float_3 = 2828.061238
    float_4 = 4866.785815
    float_5 = 3645.361741
    float_6 = 7293.561659
    float_7 = 6078.040074
    float_8 = 693.563624
    float_9 = 2983.215257
    float_10 = 6586.326801
    float_11 = 5701.231842
    float_12 = 8046.557458


# Generated at 2022-06-26 00:55:51.763614
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    float_0 = 4472.25934
    dict_0 = {}
    list_0 = [dict_0, dict_0, float_0, float_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_service_0 = FXRateService(**dict_0)

    list_1 = [float_0]
    str_0 = 'qmJ#3pWQmG7Qn#w'
    dict_1 = {str_0: float_0}
    f_x_rate_2 = FXRate(*list_1, **dict_1)

    list_2 = [f_x_rate_0, f_x_rate_1]

    list_

# Generated at 2022-06-26 00:55:59.910335
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Test that checks both a valid return value and that the query method was invoked. This is needed as the default
    #   implementation of the query method returns None.
    f_x_rate_0 = FXRate(1, 1, 1, 1)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query = f_x_rate_service_0.query.wrapped(lambda self, ccy1, ccy2, asof, strict=False: f_x_rate_0)
    assert f_x_rate_service_0.query(1, 1, 1, strict=False) == f_x_rate_0


# Generated at 2022-06-26 00:56:09.546349
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = ['Z', 'z', 'z', 'Z']
    list_1 = ['(', 'z', 'z', 'Z']
    f_x_rate_0 = FXRate(*list_1)
    float_0 = -0.526
    f_x_rate_1 = FXRate(1.0, float_0, 'Z', '[')
    f_x_rate_2 = FXRate('W', 1.0, 'Z', '[')
    f_x_rate_3 = FXRate(*list_0)
    list_2 = ['(', 'z', 'z', 'Z']
    f_x_rate_4 = FXRate(*list_2)
    list_3 = ['(', 'z', 'z', 'Z']
    f_x_rate_5 = FXRate(*list_3)

# Generated at 2022-06-26 00:56:19.071970
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 00:56:19.635328
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-26 00:56:21.160054
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    FXRateService.query(currencies_0, currencies_0, date_2)


# Generated at 2022-06-26 00:56:30.705738
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # establish context
    queries = [(Currency.USD, Currency.EUR, Date(2016, 1, 1)),
               (Currency.USD, Currency.EUR, Date(2016, 1, 2))]
    from pypara.fx.services.static import FXRateServiceStatic

    # create a fixture
    fx_rate_service = FXRateServiceStatic()

    # exercise the SUT
    rates = fx_rate_service.queries(queries, strict=True)

    # verify the outcome
    try:
        rates.__next__()
        rates.__next__()
        pytest.fail()
    except FXRateLookupError:
        pass

    # verify the outcome
    assert len(list(fx_rate_service.queries(queries, strict=False))) == 2



# Generated at 2022-06-26 00:56:33.904281
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = [None]
    dict_0 = {}
    dict_0 = {}
    f_x_rate_service_0 = FXRateService(**dict_0)
    f_x_rate_service_0.queries(list_0, False)


# Generated at 2022-06-26 00:56:40.626310
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    try:
        f_x_rate_service_0 = FXRateService(**{})
        ccy1 = Currency.split('USD')
        ccy2 = Currency.split('USD')
        f_x_rate_0 = f_x_rate_service_0.query(ccy1, ccy2, Date.split(','), False)
        assert f_x_rate_0.get_value() == 1.0
    except Exception as e:
        print('EXCEPTION:', e)
        assert False


# Generated at 2022-06-26 00:56:42.533826
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): # note the method name is "test_[name of the method to be tested]"
    print("test_FXRateService_queries not implemented")

# Generated at 2022-06-26 00:57:21.476429
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal  # noqa: E402
    from pypara.currencies import Currencies  # noqa: E402
    from pypara.fx.hdf5_store import FXRatesHDF5Store  # noqa: E402

    ## Create the underlying store:
    rates = FXRatesHDF5Store("/tmp/test.hdf", "test", mode="w")
    rates.append("EUR/USD", Decimal("0.5"), datetime.date(2018, 1, 1))
    rates.append("EUR/USD", Decimal("0.6"), datetime.date(2018, 2, 1))
    rates.append("EUR/USD", Decimal("0.7"), datetime.date(2018, 3, 1))
    rates.flush()

    ## Create and

# Generated at 2022-06-26 00:57:22.859482
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = [None]
    f_x_rate_service_0 = FXRateService.default


# Generated at 2022-06-26 00:57:23.691927
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:57:37.905422
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    float_0 = 1.2
    str_0 = 'ODDf7#'
    str_1 = ''
    dict_0 = {str_1: float_0, str_0: float_0, float_0: float_0}
    f_x_rate_0 = FXRate(**dict_0)
    float_1 = 1.0
    int_0 = 0
    list_0 = [float_1, int_0, [float_0]]
    f_x_rate_1 = FXRate(*list_0, **dict_0)
    float_2 = 0.6
    str_2 = 'Z'
    dict_1 = {float_2: float_0, str_2: float_0}
    list_1 = [float_2, float_2, float_1, float_0]

# Generated at 2022-06-26 00:57:45.138217
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    float_0 = -4372.89488
    dict_0 = {}
    list_0 = [dict_0, dict_0, float_0, float_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_service_0 = FXRateService(**dict_0)


# Generated at 2022-06-26 00:57:50.152201
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    dict_0 = {}
    f_x_rate_0 = FXRate(**dict_0)
    dict_1 = {}
    f_x_rate_service_0 = FXRateService(**dict_1)
    f_x_rate_service_0.query(**dict_0)
    f_x_rate_1 = f_x_rate_service_0.query(**dict_0)


# Generated at 2022-06-26 00:57:59.704786
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    dict_0 = {}
    f_x_rate_service_0 = FXRateService(**dict_0)

    try:
        temp = f_x_rate_service_0.query(**dict_0)
    except KeyError as e:
        print(e)
    float_0 = 0.946563205
    float_1 = 0.834262522
    str_0 = 'FXRateService.query'
    str_1 = 'BACc%ZKk2R#Cg,@T}'
    str_2 = ''
    dict_1 = {str_0: str_1, str_2: float_0}
    dict_2 = {str_1: float_1, str_2: float_0}
    dict_3 = {}
    dict_4 = {}
    dict_

# Generated at 2022-06-26 00:58:08.398153
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
  print("Testing method queries of class FXRateService")
  dict_0 = {}
  list_0 = [dict_0, dict_0]
  str_0 = 'qmJ#3pWQmG7Qn#w'
  dict_1 = {str_0: 0.0}
  f_x_rate_0 = FXRate(*list_0, **dict_1)
  f_x_rate_service_0 = FXRateService(**dict_0)
  set_0 = {f_x_rate_0}
  f_x_rate_service_0.queries(set_0)

if __name__ == '__main__':
    test_FXRateService_queries()

# Generated at 2022-06-26 00:58:12.571860
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    dict_0 = {}
    f_x_rate_service_0 = FXRateService(**dict_0)
    dict_1 = {}
    f_x_rate_1 = FXRate.of(**dict_1)
    f_x_rate_service_0.query(**dict_1)
    dict_0 = {}
    f_x_rate_service_1 = FXRateService(**dict_0)
    dict_0 = {}
    f_x_rate_0 = FXRate.of(**dict_0)
    f_x_rate_service_1.query(**dict_0)


# Generated at 2022-06-26 00:58:16.972367
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert isinstance(FXRateService.query(), FXRateService)
    assert isinstance(FXRateService.query(**dict_1), FXRateService)
    assert isinstance(FXRateService.query(*list_1), FXRateService)
    assert isinstance(FXRateService.query(*list_0), FXRateService)


# Generated at 2022-06-26 00:59:27.976823
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    fx_rate_service_1 = FXRateService()

    fx_rate_service = FXRateService()

    ccy1 = ccy2 = None
    asof = Date()
    strict = True

    # The test code from the specification
    assert fx_rate_service.query(ccy1, ccy2, asof, strict) == fx_rate_service_1.query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-26 00:59:31.189962
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    dict_0 = {}
    list_0 = [dict_0, dict_0, dict_0]
    f_x_rate_service_0.queries(list_0)



# Generated at 2022-06-26 00:59:32.737186
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_3 = FXRate()
    f_x_rate_4 = f_x_rate_3.query()


# Generated at 2022-06-26 00:59:37.481908
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    dict_0 = {}
    f_x_rate_service_0 = FXRateService(**dict_0)
    f_x_rate_0 = FXRate(**dict_0)
    float_0 = 8.02319
    list_1 = [float_0]
    dict_1 = {}
    f_x_rate_1 = FXRate(*list_1, **dict_1)
    float_1 = 7.81319
    list_2 = [float_1]
    dict_2 = {}
    f_x_rate_2 = FXRate(*list_2, **dict_2)
    list_0 = [f_x_rate_0, f_x_rate_1, f_x_rate_2]

# Generated at 2022-06-26 00:59:49.622167
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    dict_0 = {}
    float_0 = 5678.723021
    float_1 = 4244.637015
    float_2 = 5404.476214
    float_3 = 8863.434513
    float_4 = 7976.348643
    float_5 = 8633.973851
    float_6 = 2768.132336
    float_7 = 1415.486411
    float_8 = 6118.066629
    float_9 = 939.281988
    float_10 = 8174.17657
    float_11 = 4794.564562
    float_12 = 3452.578829
    float_13 = 8542.112428
    float_14 = 5900.299711
    float_15 = 1330.70175
    float_16

# Generated at 2022-06-26 01:00:02.009460
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    dict_0 = {'0': 4472.25934}
    f_x_rate_0 = FXRate(Currency(*dict_0), *dict_0)
    f_x_rate_service_0 = FXRateService(**dict_0)
    dict_1 = {'0': dict_0}
    dict_2 = {'0': dict_1}
    dict_3 = {'0': dict_2}
    dict_4 = {'0': dict_3}
    dict_5 = {'0': dict_4}
    dict_6 = {'0': dict_5}
    dict_7 = {'0': dict_6}
    dict_8 = {'0': dict_7}
    dict_9 = {'0': dict_8}

# Generated at 2022-06-26 01:00:06.355683
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    dict_0 = {}
    f_x_rate_service_0 = FXRateService()
    list_0 = [dict_0]
    f_x_rate_service_0.queries(list_0)


# Generated at 2022-06-26 01:00:15.221766
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test method query of class FXRateService
    """
    method_name = "query"
    signature = "unittest_" + method_name + "()"

    # Test Case 001:
    #
    # Input:
    #     strict=False
    # Expected Output:
    #     None
    #
    # Call Method to Test:
    #
    # f_x_rate_1 = f_x_rate_service_0.query()
    #
    # Assertions - Expected Output:
    #
    # assert f_x_rate_1 == None
    #
    # Test Case 002:
    #
    # Input:
    #     strict=True
    # Expected Output:
    #      FXRateLookupError
    #
    # Call Method to Test:
   

# Generated at 2022-06-26 01:00:24.547386
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_4 = [()]
    f_x_rate_service_2 = FXRateService(*list_4)
    float_6 = 4472.25934
    str_1 = 'qmJ#3pWQmG7Qn#w'
    float_2 = -0.243598
    float_8 = 4472.25934
    float_9 = 4472.25934
    float_7 = 4472.25934
    float_10 = 4472.25934
    float_11 = 4472.25934
    float_3 = -0.243598
    float_12 = 4472.25934
    float_13 = 4472.25934
    float_4 = -0.243598
    float_5 = -0.243598

# Generated at 2022-06-26 01:00:31.896720
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    dict_0 = {}
    list_0 = [dict_0]
    f_x_rate_service_0 = FXRateService(*list_0)
    int_0 = 4472.25934
    dict_1 = {}
    f_x_rate_service_1 = FXRateService(*list_0, **dict_1)
    dict_2 = {}
    float_0 = 4472.25934
    tuple_0 = (int_0, float_0)
    dict_3 = {}
    f_x_rate_service_2 = FXRateService(*tuple_0, **dict_3)
