

# Generated at 2022-06-26 00:51:48.428230
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:51:49.279725
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert False


# Generated at 2022-06-26 00:51:56.532580
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    fx_rate_service = FXRateService()
    fx_rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rate = fx_rate_service.query(Currencies["EUR"],Currencies["USD"],datetime.date.today(),strict=true)
    assert rate == fx_rate


# Generated at 2022-06-26 00:51:57.334087
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:52:05.043671
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import sys

    ## Define the FX rate service:
    class MyFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                if len(query) == 3:
                    yield self.query(*query, strict)

    ## Create a FX rate service instance:
    fx_service = MyFXRateService()

    ## Verify the method queries of class FXRateService:
    if sys.version_info < (3, 6):
        assert isinstance(fx_service.queries([]), list)

# Generated at 2022-06-26 00:52:06.590253
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ## Arrange ##
    ## Act ##
    ## Assert ##
    pass


# Generated at 2022-06-26 00:52:15.173840
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main
    from unittest.mock import patch

    from .commons.zeitgeist import Date
    from .currencies import Currency, Currencies

    from pypara.services.fx import FXRateService

    class DummyFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    class TestCaseDummyFXRateServiceQueries(TestCase):

        @patch("pypara.services.fx.FXRateService.queries")
        def test(self, mock_queries):
            f_x_

# Generated at 2022-06-26 00:52:23.317230
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # initialization
    orders = [
        FXRate('A', 'B', '1/1/2019', 1.1),
        FXRate('C', 'D', '2/2/2019', 1.2),
        FXRate('D', 'E', '3/3/2019', 1.3),
        FXRate('G', 'H', '4/4/2019', 1.4),
        FXRate('B', 'A', '5/5/2019', 5.5),
    ]
    queries = [
        ('A', 'B', '1/1/2019'),
        ('B', 'C', '1/1/2019'),
        ('G', 'H', '4/4/2019'),
        ('B', 'A', '5/5/2019')
    ]
    service = FXRateService()

    # mock queries
   

# Generated at 2022-06-26 00:52:24.797673
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    fx_rate_service = FXRateService()
    print(fx_rate_service.queries('USD'))

# Generated at 2022-06-26 00:52:34.279872
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class TestFXRateService(FXRateService):
        @staticmethod
        def query(ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass
    test_fx_rate_service = TestFXRateService
    test_currency = Currency
    test_date = Date
    # Replace test_bool =
    assert(test_fx_rate_service.query(test_currency, test_currency, test_date))

# Generated at 2022-06-26 00:52:52.028670
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '0;g)"$\x0b|gdp'
    decimal_0 = module_1.Decimal(str_0)
    str_1 = "\n=fNvzGQ"
    date_0 = module_3.date()
    int_0 = 4
    str_2 = '"m@!lFm\x0bS'
    currency_type_0 = module_0.CurrencyType.CRYPTO
    int_1 = 1
    str_3 = 'Yb?f+'
    currency_0 = module_0.Currency(str_2, str_2, int_1, currency_type_0, decimal_0, int_0)
    str_4 = ':yh/XOH'

# Generated at 2022-06-26 00:53:00.858960
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import typing
    import pypara.currencies as module_0
    import decimal as module_1
    import datetime as module_3
    cfg_0 = module_0.CurrencyConfig()
    int_0 = 82
    decimal_0 = module_1.Decimal()
    int_1 = None
    currency_0 = module_0.Currency(None, None, int_0, None, decimal_0, int_1)
    int_2 = 34
    decimal_1 = module_1.Decimal()
    int_3 = None
    currency_1 = module_0.Currency(None, None, int_2, None, decimal_1, int_3)
    date_0 = module_3.date()
    tuple_0 = (currency_0, currency_1, date_0)
    queries_

# Generated at 2022-06-26 00:53:10.255277
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    date_0 = module_3.date()
    str_0 = 'z|{dW8J:P'
    currency_type_0 = module_0.CurrencyType.METAL
    int_0 = 4
    decimal_0 = module_1.Decimal()
    int_1 = 9
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    f_x_rate_service_0 = FXRateService()
    str_1 = '/h4p<\x0c=y*t&9'
    currency_type_1 = module_0.CurrencyType.PRIVATE
    int_2 = 0

# Generated at 2022-06-26 00:53:19.879759
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'f\x0b(|@`]D\n'
    str_1 = 't)C'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    f_x_rate_service_0 = FXRateService()
    str_2 = '\x0b'
    int_2 = 5
    currency_type_1 = module_0.CurrencyType.METAL
    decimal_1 = module_1.Decimal()
    int_3 = 204

# Generated at 2022-06-26 00:53:23.682575
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ccy1 = None
    ccy2 = None
    asof = None
    strict = False
    f_x_rate_service_0 = FXRateService()
    f_x_rate_0 = f_x_rate_service_0.query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-26 00:53:25.653354
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Setup test fixtures
    # Setup

    # Assertion pre-conditions
    # Exercise

    # Verify post-conditions
    assert True


# Generated at 2022-06-26 00:53:34.115537
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 476
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 3
    str_1 = '\r|UU\n1\t `s'
    currency_0 = module_0.Currency(str_1, str_0, int_1, currency_type_0, decimal_0, int_0)
    currency_1 = module_0.Currency(str_0, str_1, int_1, currency_type_0, decimal_1, int_0)
    int_2 = 476

# Generated at 2022-06-26 00:53:43.330510
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class FXRateService_0(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    int_0 = None
    str_0 = '/{z!\x0b\x0bFJ\tO%s'
    str_1 = 'X*aS1!|^T\x0b/\x0b'
    decimal_0 = module_1.Decimal()
    int_1 = 6
    f_x_rate_lookup_error_0 = FXRateLookupError(str_1, str_1, int_0)
   

# Generated at 2022-06-26 00:53:52.313604
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Imports
    import pypara.fxrates as module_0
    from pypara.currencies import Currency, Currencies
    from pypara.time import Temporal, TemporalCoordinateSystem
    # Setup
    f_x_rate_service_0 = module_0.FXRateService()
    currency_0 = Currencies['EUR']
    currency_1 = Currencies['USD']
    temporal_0 = Temporal(temporal_coordinate_system=TemporalCoordinateSystem.ACTUAL)
    currency_2 = Currencies['EUR']
    currency_3 = Currencies['USD']
    currency_4 = Currencies['GBP']
    currency_5 = Currencies['EUR']
    currency_6 = Currencies['USD']
    currency_7 = Currencies['EUR']
    currency_8 = Currencies

# Generated at 2022-06-26 00:53:56.497809
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    try:
        f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
        f_x_rate_service_0 = FXRateService()
        f_x_rate_service_0.query(currency_0, currency_0, date_0)
    except:
        print(sys.exc_info()[1]) # currency_type_1
    else:
        assert False


# Generated at 2022-06-26 00:54:17.816539
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    var_0 = None
    var_1 = var_0
    strict = var_1
    var_2 = None
    var_3 = var_2
    queries = var_3
    queries = module_0.Currency.__iter__(queries)
    if queries:
        for var_4 in queries:
            var_4 = module_0.Currency(var_4)
            var_5 = None
            var_6 = var_5
            asof = var_6
            var_7 = None
            var_8 = var_7
            ccy2 = var_8
            var_9 = None
            var_10 = var_9
            ccy1 = var_10
            ccy1 = module_0.Currency(ccy1)

# Generated at 2022-06-26 00:54:27.985600
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    try:
        int_0 = 4
        currency_type_0 = module_0.CurrencyType.METAL
        decimal_0 = module_1.Decimal()
        int_1 = 723
        currency_0 = module_0.Currency.of(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
        date_0 = module_3.date()
        f_x_rate_service_0 = None
        f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_0, date_0)
        assert f_x_rate_0 is not None
    except AssertionError:
        raise RuntimeError('AssertionError raised')
    except Exception:
        raise RuntimeError('Exception raised')


#

# Generated at 2022-06-26 00:54:36.501026
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ';^\x0cP'
    decimal_0 = module_1.Decimal()
    currency_type_0 = module_0.CurrencyType.OFFICIAL
    str_1 = '7q3zF$\x7f_'
    int_0 = 345
    currency_1 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0)
    str_2 = '\n"P'
    str_3 = '+I2)AA}X&r\r_'
    int_1 = 875
    currency_type_1 = module_0.CurrencyType.CRYPTO

# Generated at 2022-06-26 00:54:37.302821
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert False


# Generated at 2022-06-26 00:54:47.000104
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    int_2 = None
    currency_type_1 = module_0.CurrencyType.CRYPTO
    str

# Generated at 2022-06-26 00:54:57.192524
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    int_2 = None
    currency_type_1 = module_0.CurrencyType.CRYPTO
    str

# Generated at 2022-06-26 00:55:08.697988
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_2 = 0
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    currency_1 = module_0.Currency(str_0, str_0, int_2, currency_type_0, decimal_0, int_1)
    date_1 = module_3.date()
    currency_

# Generated at 2022-06-26 00:55:19.332276
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pypara.currencies as module_0
    import decimal as module_1
    import datetime as module_3
    int_0 = 520
    str_0 = '\nH'
    str_1 = '\\x0b&'
    decimal_0 = module_1.Decimal()
    currency_type_0 = module_0.CurrencyType.CRYPTO
    int_1 = 48
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    currency_1 = None
    date_0 = module_3.date()
    bool_0 = False
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 00:55:27.605604
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import decimal as module_1
    import datetime as module_3
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None

# Generated at 2022-06-26 00:55:36.649453
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # 1. Arrange
    str_0 = 'c,V+0~\x0c1u_\rs@\x0b,'
    str_1 = '-T|:s;s)43_!b'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.VIRTUAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    int_2 = 3
    currency_type_1 = module_0.CurrencyType.CRYPTO
    str_2 = '5+])oh^7ck|\x0bps/0\x0b?'
    int_3 = 7

# Generated at 2022-06-26 00:56:01.970356
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # 1
    str_0 = 'p`)A.n:.\x0c<k\n*|\x0c"\x0b'
    int_0 = 5
    decimal_0 = module_1.Decimal(int_0)
    currency_type_0 = module_0.CurrencyType.CRYPTO
    currency_1 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_0)
    str_1 = 'L%c)X2d.|5.5$^ k'
    int_1 = 1
    currency_type_1 = module_0.CurrencyType.FIAT

# Generated at 2022-06-26 00:56:10.175470
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # UUT
    from pypara.fx import FXRateService
    from pypara.commons.zeitgeist import Temporal
    from pypara.currencies import Currency

    # Setup
    ccy1 = Currency.of(name="EUR")
    ccy2 = Currency.of(name="USD")
    temporal = Temporal.today()
    queries = [(ccy1, ccy2, temporal)]
    strict = False
    service = FXRateService()

    # Expectation
    rates = None

    # Exercise
    rates = service.queries(queries, strict)

    # Verify
    assert rates is None


# Generated at 2022-06-26 00:56:12.367883
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Test the method to see if the code raise expected exceptions.
    # raise RuntimeError('The test fails!')

    # Test if the test itself fails!
    assert True


# Generated at 2022-06-26 00:56:21.900715
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\n|4B\t{'
    str_1 = 'Z/D:<j\th3\x0b+e'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = '\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f'
    int_2 = 255
    currency_type_1 = module_0.CurrencyType.METAL
    str

# Generated at 2022-06-26 00:56:31.423907
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '2\x0c\x0e-`p;\x0b\x0e6U\x0e3!\x0b\x0b#'
    str_1 = '\x0b\x0e-\x0e)5Y\x0b\x0b\x0c\x0e4\x0e#\x0c\x0b/\n#'
    int_0 = 7
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 5
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    decimal_1 = module_1.Decimal

# Generated at 2022-06-26 00:56:40.832554
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pypara.currencies as module_0
    import decimal as module_1
    import datetime as module_3
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None

# Generated at 2022-06-26 00:56:50.178873
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    int_2 = None
    currency_type_1 = module_0.CurrencyType.CRYPTO
    str

# Generated at 2022-06-26 00:56:54.654904
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    bool_0 = True
    iterable_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(iterable_0, bool_0)
    f_x_rate_service_0.query(currency_0, currency_0, date_0, bool_0)

# Generated at 2022-06-26 00:57:07.055165
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'r'
    str_1 = 'v5Az2?Wc3z#x2B.e?v'
    int_0 = 98
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    int_1 = 4
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    int_2 = None
    str_2 = 'fg'
    int_3 = 87
    currency_type_1 = module_0.CurrencyType.METAL
    decimal_1 = module_1.Decimal()
    int_4 = 14

# Generated at 2022-06-26 00:57:14.846967
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import decimal as module_1
    import datetime as module_3
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None

# Generated at 2022-06-26 00:57:44.831827
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # FIXME
    pass


# Generated at 2022-06-26 00:57:45.658266
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:57:48.018705
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: Implement unit test for method query of class FXRateService
    raise NotImplementedError("Method test_FXRateService_query is not implemented.")


# Generated at 2022-06-26 00:57:57.695117
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime as module_1
    date_0 = module_1.date()
    str_0 = 'This is an FX rate service.'
    f_x_rate_service_0 = FXRateService(str_0)
    currency_0 = Currency("EUR", "EUR", 18, CurrencyType.STANDARD, Decimal("0.5"), 978)
    currency_1 = Currency("USD", "USD", 2, CurrencyType.METAL, Decimal("1"), 840)
    exception_0 = None
    try:
        f_x_rate_service_0.query(currency_0, currency_1, date_0)
    except FXRateLookupError as exception_0:
        pass
    assert isinstance(exception_0, FXRateLookupError)
    assert type(exception_0) == FXRateLook

# Generated at 2022-06-26 00:58:07.385279
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    int_2 = None
    currency_type_1 = module_0.CurrencyType.CRYPTO
    str

# Generated at 2022-06-26 00:58:12.489176
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'R>0Jf&t%sK'
    str_1 = '$aHz :Kj\x0c2rP\x0e-{'
    int_0 = 1
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    int_1 = 541
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = '6yhV6U5:4\x0cC4\x0bV7)F'
    str_3 = '6yhV6U5:4\x0cC4\x0bV7)F'
    int_2 = 4

# Generated at 2022-06-26 00:58:22.389040
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    decimal_0 = module_1.Decimal()
    str_0 = 'KxBf\\+V7c'
    str_1 = 'HjP2zVl@o}'
    int_0 = 6
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_1 = module_1.Decimal()
    int_1 = 843
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_1, int_1)
    int_2 = None
    decimal_2 = module_1.Decimal()
    str_2 = '\x7f\x0b?\x7f\x0b?\x7f\x0b?\x7f\x0b?'
    str_

# Generated at 2022-06-26 00:58:31.240327
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    date_2 = None
    decimal_1 = module_1.Decimal()
    currency_1 = module_0.Currency(str_0, str_2, int_2, currency_type_1, decimal_1, int_1)
    decimal_2 = module_1.Decimal()
    f_x_rate_0 = FXRate(currency_0, currency_1, date_1, decimal_2)
    f_x_rate_service_0 = None
    str_3 = 'CcH`Bl\nqvg"-'
    str_4 = '\n\rcF9\t]n@xM]\x0b}'
    str_5 = 'n5Dd2i'

# Generated at 2022-06-26 00:58:38.891849
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '-\x0b}nA\x0bY%b\x0b`}0-^|v@'
    str_1 = 'r)~(Q$<H,T%h?_'
    int_0 = 684
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    int_1 = None
    currency_0 = module_0.Currency(str_1, str_0, int_0, currency_type_0, decimal_0, int_1)
    currency_1 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = module_3.date()

# Generated at 2022-06-26 00:58:46.740645
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    tuple_0 = ('\x0b', '', module_3.datetime())
    str_0 = '\x0bu'
    str_1 = '\x0b'
    str_2 = ''
    str_3 = ''
    module_0.Currency(str_3, str_3, int_0, currency_type_0, decimal_0, int_1)
    date_0 = module_3.datetime()
    tuple_1 = (str_0, str_1, date_0)
    tuple_2 = (str_2, str_1, date_0)
    tuple_3 = (str_0, str_0, date_0)

# Generated at 2022-06-26 01:00:12.906428
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = "2\x0c\\\x1f\"\t\x1f\x1f\x0bM\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f"
    decimal_0 = module_1.Decimal('0.0000000000000000')
    int_0 = 8
    currency_type_0 = module_0.CurrencyType.PAPER

# Generated at 2022-06-26 01:00:23.450329
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    date_0 = module_3.date()
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    int_2 = None
    currency_type_1 = module_0.CurrencyType.CRYPTO
    str_2 = '5+])oh^7ck|\x0bps/0\x0b?'
    t_query

# Generated at 2022-06-26 01:00:32.319229
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    int_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(int_0, int_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_1 = FXRateLookupError(int_0, int_0, date_0)
    module_0.Currency.__init__()
    date_1 = module_3.date()
    f_x_rate_lookup_error_2 = FXRateLookupError(int_0, int_0, date_1)
    f_x_rate_lookup_error_3 = FXRateLookupError(int_0, int_0, date_1)
    module_0.Currency.__init__()
    f_x_rate_lookup_error_4 = FX

# Generated at 2022-06-26 01:00:33.487863
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
  pass

# Generated at 2022-06-26 01:00:42.786208
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '48\x7f\x0b'
    str_1 = '8y_W'
    str_2 = 'm\x0b'
    int_0 = 901
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal(-6)
    int_1 = 7
    currency_0 = module_0.Currency(str_2, str_2, int_0, currency_type_0, decimal_0, int_1)
    str_3 = '\x7f\x0bx\x7f\x0b'
    str_4 = '\x7f\x0b:\x7f\x0b'
    str_5 = '8y_W'
    int_2 = None
    currency

# Generated at 2022-06-26 01:00:49.515639
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    int_2 = None
    currency_type_1 = module_0.CurrencyType.CRYPTO
    str

# Generated at 2022-06-26 01:00:57.313587
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '8%F}L-?[5\x0b'
    str_1 = 'MB.U6/9cg'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = 'H9k|U?a6>'
    int_2 = 3
    currency_type_1 = module_0.CurrencyType.METAL
    decimal_1 = module_1.Decimal()
    int_3 = 476

# Generated at 2022-06-26 01:01:04.321945
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'a'
    str_1 = '\nK\t\x0b\x0b'
    int_0 = 9
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 9
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = "8Uv7 \x0b\x0b\n\n@B^\x0bY\t"
    str_3 = '_\x0c\x0c\x0b\x0b\x0c\x0c'
    int_2 = 4

# Generated at 2022-06-26 01:01:11.549362
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\r|UU\n1\t `s'
    str_1 = 'Pn#a<h+twQ\n,Ps@%*K7j'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    int_2 = None
    currency_type_1 = module_0.CurrencyType.CRYPTO
    str

# Generated at 2022-06-26 01:01:19.501479
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '{}T"T\x18b3y'
    str_1 = '[eO;mFq1h]p'
    int_0 = 3
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    int_1 = 476
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    int_2 = None
    currency_type_1 = module_0.CurrencyType.CRYPTO