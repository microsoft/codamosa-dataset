

# Generated at 2022-06-26 00:51:49.103125
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(nrate.__invert__() == rrate)


# Generated at 2022-06-26 00:51:55.331397
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert( ~nrate == rrate )


# Generated at 2022-06-26 00:52:02.670183
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .currencies import Currency, Currencies
    from .date import Temporal

    # Create the FX rate service instance
    svc = FXRateService()

    # Create queries
    q1 = (Currencies["USD"], Currencies["EUR"], Temporal.today())
    q2 = (Currencies["USD"], Currencies["TRY"], Temporal.today())
    q3 = (Currencies["EUR"], Currencies["USD"], Temporal.today())

    # Execute the queries and report results
    for q, r in zip((q1, q2, q3), svc.queries((q1, q2, q3))):
        print(f"{q}: {r}")



# Generated at 2022-06-26 00:52:09.447625
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    from .currencies import Currency
    from .commons.zeitgeist import Date

    class _TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        @abstractmethod
        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    class _TestCase(unittest.TestCase):
        def test_case_0(self):
            service = _TestFXRateService()
            self.assertIsNotNone(service)

# Generated at 2022-06-26 00:52:12.226567
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    assert f_x_rate_service_0.queries(1) is None


# Generated at 2022-06-26 00:52:16.456988
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporals import Date
    from pypara.fx import FXRateService
    import typing
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(typing.Iterable[typing.Tuple[Currencies, Currencies, Date]], False)


# Generated at 2022-06-26 00:52:17.252486
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Test
    pass


# Generated at 2022-06-26 00:52:18.887029
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries()


# Generated at 2022-06-26 00:52:20.243033
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: Implement Test
    raise TypeError("Not Implemented")


# Generated at 2022-06-26 00:52:21.414211
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    pass


# Generated at 2022-06-26 00:52:34.857503
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    from pypara.curves import FXRateLookupError, FXRateService
    from pypara.curves.local import DataFrameFXRateService

    # Positive Test Case:
    service = DataFrameFXRateService({"EURUSD": [{"asof": datetime.date.today(), "value": Decimal("1.0")}]})
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) == FXRate(Currencies["EUR"],
                                                                                                Currencies["USD"],
                                                                                                datetime.date.today(),
                                                                                                Decimal("1.0"))

# Generated at 2022-06-26 00:52:40.109139
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # Test query of class FXRateService with only required and default args
    currency_0 = None
    currency_1 = None
    f_x_rate_1 = FXRate(currency_0, currency_1, currency_0, currency_0)
    f_x_rate_service_1 = FXRateService()
    currency_2 = None
    f_x_rate_2 = f_x_rate_service_1.query(currency_0, currency_0, currency_2)
    assert f_x_rate_1 == f_x_rate_2


# Generated at 2022-06-26 00:52:43.378013
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ccy1 = None
    ccy2 = None
    asof = None
    strict = None
    fxrateservice = FXRateService()
    fxrateservice.query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-26 00:52:55.946075
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    str_1 = '\n'
    str_2 = ';'
    str_3 = ':'
    str_4 = '\x1d'
    str_5 = 'k'
    str_6 = '\x18'
    str_7 = '\n'
    str_8 = 'k'
    str_9 = 'O'
    str_10 = '\n'
    str_11 = '\x1d'
    str_12 = 'k'
    str_13 = '\x18'
    str_14 = 'k'
    str_15 = ';'
    str_16 = ':'
    str_17 = 'k'
    str_18 = '\n'
    str_19 = 'k'
    str_20 = 'k'


# Generated at 2022-06-26 00:53:01.250091
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Make an instance of FXRateService
    FXRateService_instance_0 = FXRateService()
    # Make an instance of Tuple[Currency, Currency, Temporal]
    Tuple_Currency_Currency_Temporal_instance_0 = (None, None, None)
    # Call method queries of FXRateService instance_0
    FXRateService_instance_0.queries(Tuple_Currency_Currency_Temporal_instance_0)


# Generated at 2022-06-26 00:53:07.967322
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_2 = None
    date_2 = None
    f_x_rate_lookup_error_2 = FXRateLookupError(currency_2, currency_2, date_2)
    str_1 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_1 = None
    f_x_rate_service_1 = FXRateService()
    iterable_1 = f_x_rate_service_1.queries(str_1, bool_1)


# Generated at 2022-06-26 00:53:09.076568
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 00:53:16.234891
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)

# Generated at 2022-06-26 00:53:20.316729
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = Currency()
    currency_1 = Currency()
    date_0 = Date()
    iterable_0 = (currency_1,)
    f_x_rate_service_0 = FXRateService()
    iterable_1 = f_x_rate_service_0.queries(iterable_0)


# Generated at 2022-06-26 00:53:25.937384
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)


# Generated at 2022-06-26 00:53:35.953651
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
   pass


# Generated at 2022-06-26 00:53:44.453867
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies, Currency

    class TestRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            assert ccy1 == Currencies["EUR"]
            assert ccy2 == Currencies["USD"]
            assert asof == date(2019, 5, 1)
            assert strict

            return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))

    service = TestRateService()

    rate = service.query(Currencies["EUR"], Currencies["USD"], date(2019, 5, 1))
    assert isinstance(rate, FXRate)

# Generated at 2022-06-26 00:53:48.327131
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    currency_1 = None
    f_x_rate_service_0 = FXRateService()
    date_0 = None
    bool_0 = None
    f_x_rate_service_0.query(currency_0, currency_1, date_0, bool_0)


# Generated at 2022-06-26 00:53:52.789768
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    str_0 = '7\\\x19[d\x0fM\x11&}\n\t\x05\x1e'
    bool_0 = None
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)


# Generated at 2022-06-26 00:53:58.922905
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    service = FXRateService()
    try:
        service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=True)
    except FXRateLookupError as e:
        if not e.ccy1 == rate.ccy1:
            raise AssertionError('e.ccy1 == rate.ccy1')
        if not e.ccy2 == rate.ccy2:
            raise AssertionError('e.ccy2 == rate.ccy2')

# Generated at 2022-06-26 00:54:00.881386
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries = (1, 2, 3)
    strict = True
    fx_rate_service = FXRateService()
    assert fx_rate_service.queries(queries, strict) == None
    print("Passed all tests for method queries of class FXRateService")


# Generated at 2022-06-26 00:54:10.072687
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # unique rates
    rates = [
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 1, 1), Decimal("2")),
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 1, 2), Decimal("4")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date(2018, 1, 1), Decimal("0.5")),
    ]

    # the same collection with duplicates

# Generated at 2022-06-26 00:54:18.696181
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    # result = f_x_rate_service_0.query(date_0, date_0, date_0, bool_0)
    # print(result)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_0.__invert__()
    f_

# Generated at 2022-06-26 00:54:24.783694
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Tests for different argument values
    currency_0 = '*e'
    currency_1 = '*e'
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(currency_0, currency_1, date_0)
    f_x_rate_service_1 = FXRateService()
    f_x_rate_service_1.query(currency_0, currency_1, date_0)


# Generated at 2022-06-26 00:54:34.335347
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    count_0 = 0
    f_x_rate_service_0 = FXRateService()
    assert f_x_rate_service_0.queries(iterable_0, bool_0) is iterable_0
    assert f_x_rate_service_0.queries(str_0, bool_0) is iterable_0
    assert f_x_rate_service_0.queries(str_0, bool_0) is iterable_0
    assert f_x_rate_service_0.queries(iterable_0, bool_0) is iterable_0
    assert f_x_rate_service_0.queries(str_0, bool_0) is iterable_0
    assert f_x_rate_service_0.queries(str_0, bool_0) is iterable_0


# Generated at 2022-06-26 00:54:57.843259
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    result = FXRateService().queries(currency = "Currency", currency = "Currency", temporal = "Temporal", strict = "bool")
    assert True
    result = FXRateService().queries(currency = "Currency", currency = "Currency", temporal = "Temporal", strict = "bool")
    assert True
    result = FXRateService().queries(currency = "Currency", currency = "Currency", temporal = "Temporal", strict = "bool")
    assert True


# Generated at 2022-06-26 00:55:03.887634
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    currency_1 = None
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    bool_0 = None
    f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_1, date_0, bool_0)


# Generated at 2022-06-26 00:55:14.478161
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_1 = FX

# Generated at 2022-06-26 00:55:21.996759
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)
    assert f_x_rate_service_0 is not None


# Generated at 2022-06-26 00:55:28.993799
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_1 = FX

# Generated at 2022-06-26 00:55:38.422885
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    with raises(LookupError, match=r'Foreign exchange rate for None/None not found as of None'):
        f_x_rate_service_0.query(currency_0, currency_0, date_0, bool_0)
    f_x_rate_lookup_error_1 = FXRateLookupError(currency_0, currency_0, date_0)

# Generated at 2022-06-26 00:55:44.938746
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Setup
    currency_0 = Currency()
    currency_1 = Currency()
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    tuple_0 = (currency_0, currency_1, date_0)
    iterable_0 = (tuple_0,)

    # Invocation
    iterable_1 = f_x_rate_service_0.queries(iterable_0)

    # Verification
    assert iterable_1 == (None,)


# Generated at 2022-06-26 00:55:50.136042
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_1 = FX

# Generated at 2022-06-26 00:55:53.918461
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_0, currency_0)


# Generated at 2022-06-26 00:56:02.046053
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Check the return value against the expected result.
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    result = f_x_rate_service_0.query(str_0, currency_0, date_0, bool_0)
    assert result == None


# Generated at 2022-06-26 00:56:40.129965
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_1 = FX

# Generated at 2022-06-26 00:56:44.690905
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    r = FXRate(Currency("USD"), Currency("EUR"), Date(2019,1,1), Decimal(0.88))
    ccy1 = r.ccy1
    ccy2 = r.ccy2
    asof = r.date
    strict = False

    FXRateService.query()


# Generated at 2022-06-26 00:56:53.951803
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_0 = FXRate()
    f_x_rate_2 = f_x_rate_0.__invert__()
    f_x_rate_3 = f_x_rate_0.__invert__()
    f_x_rate_4 = f_x_rate_0.__invert__()
    f_x_rate_5 = f_x_rate_0.__invert__()
    f_x_rate_6 = f_x_rate_0.__invert__()
    f_x_rate_7 = f_x_rate_0.__invert__()
    f_x_rate_8 = f_x_rate_0.__invert__()
    f_x_rate_9 = f_x_rate_0.__invert__()
    f

# Generated at 2022-06-26 00:57:05.911540
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_1 = f_x_rate_service_0.query(str_0, bool_0)
    f_x_rate_2 = FXRate()
    f_x_rate_service_1 = FXRateService()
    f_x_rate_3 = f_x_rate_service_1.query(str_0, bool_0)


# Generated at 2022-06-26 00:57:14.404493
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime, decimal, unittest
    from pypara.currencies import EUR, USD
    from pypara.fxrates import FXRateService
    class TestFixture(unittest.TestCase, FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            if ccy1 == EUR and ccy2 == USD and asof == datetime.date(2018,1,15):
                return FXRate(EUR, USD, asof, Decimal("1.23"))
            return None
        def test(self):
            queries = [
                (EUR, USD, datetime.date(2018,1,15)),
                (EUR, USD, datetime.date(2018,1,16))
            ]
            actual = self.queries(queries)

# Generated at 2022-06-26 00:57:19.152966
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # SUT
    f_x_rate_service = FXRateService()

    # Expected result
    expected = None

    # Actual result
    result = f_x_rate_service.query(None, None, None)

    # Test
    assert result is expected


# Generated at 2022-06-26 00:57:30.669146
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from typing import Iterable
    from pypara.currencies import Currency
    queries = (
        (Currency("EUR"), Currency("USD"), datetime.date.today()),
        (Currency("GBP"), Currency("USD"), datetime.date.today()),
    )
    results = (
        FXRate(Currency("EUR"), Currency("USD"), datetime.date.today(), Decimal("2")),
        FXRate(Currency("GBP"), Currency("USD"), datetime.date.today(), Decimal("1")),
    )
    fx_rate_service = FXRateService()
    results = fx_rate_service.queries(queries)
    assert results == results


# Generated at 2022-06-26 00:57:39.127260
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    currency_1 = None
    date_0 = None
    bool_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_1, date_0)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_1, date_0, bool_0)


# Generated at 2022-06-26 00:57:48.913022
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)
    f_x_rate_2 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_1 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_

# Generated at 2022-06-26 00:57:58.505294
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_1 = FX

# Generated at 2022-06-26 00:59:10.123887
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_lookup_error_0 = FXRateLookupError('currency_0', 'currency_0', 'date_0')
    f_x_rate_0 = FXRate('currency_0', 'currency_0', 'date_0', '2')
    f_x_rate_1 = FXRate('currency_0', 'currency_0', 'date_0', '2')
    f_x_rate_2 = FXRate('currency_0', 'currency_0', 'date_0', '2')

    assert f_x_rate_0 == f_x_rate_1 
    assert f_x_rate_1 != f_x_rate_2 
    assert f_x_rate_0 != f_x_rate_2 
    assert f_x_rate_0 == f_x_rate_1

# Generated at 2022-06-26 00:59:16.996630
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    print('# Unit test for method queries of class FXRateService')
    # Declarations
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)
    # Setup
    # Unit test operation
    iterable_1 = f_x_rate_service_0.queries(str_0, bool_0)
    #

# Generated at 2022-06-26 00:59:22.343278
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, bool_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate

# Generated at 2022-06-26 00:59:25.291636
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    query_str_array = []
    # Loop through array of queries
    for query in query_str_array:
        queries_result = FXRateService.queries(query)
        assert queries_result is not None, "Failed to return foreign exchange rate for query: " + query

# Randomly generated test case for FXRateService

# Generated at 2022-06-26 00:59:33.942834
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = Currency()
    date_0 = Date()
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    str_0 = '&}\ty g@;#~*gc8F+\x0c^b'
    bool_0 = None
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(str_0, int_0=bool_0)



# Generated at 2022-06-26 00:59:41.489772
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## A missing rate:
    fxrates = [
        FXRate(Currencies["EUR"], Currencies["CAD"], datetime.date(2020, 1, 2), Decimal("1.50")),
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2020, 1, 2), Decimal("1.10")),
        FXRate(Currencies["USD"], Currencies["CHF"], datetime.date(2020, 1, 2), Decimal("0.95")),
    ]

    ## A FX rate service that will retrieve rates from the fxrates list. It will iterate the list every time:

# Generated at 2022-06-26 00:59:50.787923
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.dates import Dates
    from pypara.fx import FXRates
    import datetime

    ## Find EUR/USD rates as of 2020-01-05 and 2020-02-01:
    rate_1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2020, 1, 5), Decimal("1.111111111"))
    rate_2 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2020, 2, 1), Decimal("1.222222222"))
    queries = [
        (rate_1[0], rate_1[1], rate_1[2]),
        (rate_2[0], rate_2[1], rate_2[2]),
    ]

    ## Query the FX rate service

# Generated at 2022-06-26 01:00:03.181340
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import random
    import decimal
    import datetime
    from pypara.currencies import Currency
    from pypara.temporal import Temporal
    from pypara.temporal import Date
    from pypara.currencies import currency_iso_codes
    f_x_rate_service = FXRateService()
    ccy_codes = currency_iso_codes()
    ccy1 = Currency(ccy_codes[random.randint(0, len(ccy_codes) - 1)])
    ccy_codes = currency_iso_codes()
    ccy2 = Currency(ccy_codes[random.randint(0, len(ccy_codes) - 1)])
    temporal = Temporal()
    date = temporal.today()
    queries = (ccy1, ccy2, date)
    iterable = f

# Generated at 2022-06-26 01:00:13.598118
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_0 = FXRate()
    f_x_rate_service_0 = FXRateService()
    str_0 = f_x_rate_service_0.query(currency_0, currency_0, date_0, True)
    assert str_0 is None
    str_1 = f_x_rate_service_0.query(currency_0, currency_0, date_0)
    assert str_1 is None
    bool_0 = None
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_

# Generated at 2022-06-26 01:00:15.026387
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass
