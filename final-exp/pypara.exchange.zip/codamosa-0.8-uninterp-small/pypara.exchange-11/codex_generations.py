

# Generated at 2022-06-26 00:51:57.258986
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Test API
    t_fx_rate_service_0 = FXRateService()
    t_fx_rate_service_1 = FXRateService()
    t_currency_0 = Currency(None)
    t_currency_1 = Currency(None)
    t_date_0 = Date(None)
    t_iterable_0 = FXRateService.queries(t_fx_rate_service_0, None, None)

    # Test fixture
    t_fixture_0 = FXRateService()
    t_fixture_1 = FXRateService()
    t_fixture_2 = FXRateService()

    # Test: Bound method
    assert(hasattr(t_fixture_0.queries, '__call__'))
    assert(callable(t_fixture_0.queries))

    # Test: Super

# Generated at 2022-06-26 00:51:58.052221
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert True == True


# Generated at 2022-06-26 00:52:02.634114
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Create a fake foreign exchange rate service instance
    f_x_rate_service_1 = FXRateService()
    # Verify if is an instance of class FXRateService
    assert isinstance(f_x_rate_service_1, FXRateService)
    # Call queries
    f_x_rate_service_1.queries([(Currency, Currency, Date), (Currency, Currency, Date), (Currency, Currency, Date)])


# Generated at 2022-06-26 00:52:06.451398
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Local variables
    queries = []
    strict = False
    f_x_rate_service_0 = FXRateService()
    expected_result = ()
    actual_result = ()

    # Function call
    actual_result = f_x_rate_service_0.queries(queries, strict)

    # Result assertion
    assert actual_result == expected_result


# Generated at 2022-06-26 00:52:15.025073
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    f_x_rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 00:52:23.160137
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date, Temporal
    from pypara.fxrateservices import FXRate, FXRateService

    class FXRateServiceStub(FXRateService):
        def query(self, ccy1, ccy2, asof):
            return FXRate(ccy1, ccy2, asof, Decimal(1.25))


# Generated at 2022-06-26 00:52:33.936834
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService, FXRate
    fx_rate_service_0 = FXRateService()
    query_0 = (Currencies['EUR'], Currencies['USD'], date(2018, 5, 9))
    expected = [FXRate.of(Currencies['EUR'], Currencies['USD'], date(2018, 5, 9), Decimal('1.16'))]
    actual = fx_rate_service_0.queries([query_0])
    assert actual == expected



# Generated at 2022-06-26 00:52:36.269694
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    fx_rate_0 = f_x_rate_service_0.query("USD", "USD", "")



# Generated at 2022-06-26 00:52:38.355584
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(None, None, None)


# Generated at 2022-06-26 00:52:39.707804
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:52:56.827294
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    currency_1 = None
    date_0 = None
    boolean_0 = True
    tuple_0 = ()
    list_0 = [currency_0, currency_1, date_0, boolean_0]
    f_x_rate_0 = FXRate(*list_0)
    tuple_1 = ()
    list_1 = [currency_0, currency_1, date_0, tuple_1]
    f_x_rate_1 = FXRate(*list_1)
    tuple_2 = ()
    list_2 = [currency_0, currency_1, date_0, tuple_2]
    f_x_rate_2 = FXRate(*list_2)
    tuple_3 = ()
    list_3 = [currency_0, currency_1, date_0, tuple_3]


# Generated at 2022-06-26 00:53:00.121514
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries = []
    strict = False
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(queries, strict)

test_case_0()
test_FXRateService_queries()

# Generated at 2022-06-26 00:53:09.892750
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_1 = module_1.date(**dict_0)
    currency_1 = None
    f_

# Generated at 2022-06-26 00:53:19.509101
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    date_0 = module_1.date(**{})
    str_0 = 'b"\n\x06\x14'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    currency_1 = None
    currency_2 = None
    f_x_rate_service_0.query(currency_1, currency_2, date_0)
    currency_3 = None
    currency_4 = None

# Generated at 2022-06-26 00:53:27.926816
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    tuple_0 = (currency_0, None, None)
    list_0 = [tuple_0]
    bool_0 = False
    str_0 = 'pf^\nw_\x19\x1e\x1f'
    dict_0 = {str_0: bool_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    f_x_rate_service_0.queries(list_0, bool_0)
    tuple_1 = (currency_0, None, None, bool_0)
    list_1 = [tuple_1]
    f_x_rate_service_0.queries(list_1, bool_0)

# Generated at 2022-06-26 00:53:36.665304
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Getting the type
    type_of_param = typeof(self)
    self.__class__.__dict__[type_of_param].__dict__.update(locals())
    method_param = FXRateService.query
    arg_types = [type_of_param, CodeType]
    arg_type = None
    for arg in arg_types:
        if typeof(arg) == type_of_param:
            arg_type = arg
            break
    # Setting the method parameters
    method_param.argtypes = [arg_type, CodeType]
    # Getting the method return type
    return_type = FXRateService.query(self.__class__.__dict__[type_of_param])
    if return_type == None:
        # Setting the return type
        FXRateService.query.__annot

# Generated at 2022-06-26 00:53:43.289561
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    currency_1 = None
    date_0 = module_1.date(**{'apm!\x0b1zN/*X': 'apm!\x0b1zN/*X'})
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    f_x_rate_service_0.query(currency_0, currency_1, date_0, False)


# Generated at 2022-06-26 00:53:51.651386
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency
    FXRateService.default = _TestFXRateService()
    queries = [
        (Currency("EUR"), Currency("USD"), date(2020, 1, 1)),
        (Currency("USD"), Currency("EUR"), date(2020, 1, 1)),
    ]
    answer = [
        FXRate(Currency("EUR"), Currency("USD"), date(2020, 1, 1), Decimal("1.1234")),
        FXRate(Currency("USD"), Currency("EUR"), date(2020, 1, 1), Decimal("0.8900")),
    ]
    assert FXRateService.default.queries(queries) == answer


# Generated at 2022-06-26 00:53:58.346737
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_1 = module_1.date(**dict_0)

# Generated at 2022-06-26 00:54:01.067007
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries_0 = ()
    list_0 = [queries_0, queries_0]
    f_x_rate_service_1 = FXRateService.__new__(FXRateService, *list_0)
    queries_1 = ()
    iterable_0 = FXRateService.queries(f_x_rate_service_1, queries_1)
    print(type(iterable_0))


# Generated at 2022-06-26 00:54:15.629944
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    ccy1 = Currency("CUR")
    ccy2 = Currency("EUR")
    from .commons.zeitgeist import Date
    from datetime import date
    asof = Date(date(2020, 1, 1))
    strict = True
    FXRateService.query(ccy1, ccy2, asof, strict=strict)
    strict = False
    FXRateService.query(ccy1, ccy2, asof, strict=strict)


# Generated at 2022-06-26 00:54:24.889973
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime as module_1
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_1 = module_1.date(**dict_0)
   

# Generated at 2022-06-26 00:54:34.568445
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    
    with pytest.raises(NotImplementedError):
        f_x_rate_service_0

# Generated at 2022-06-26 00:54:42.544789
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_1 = module_1.date(**dict_0)
    currency_1 = None
    f_

# Generated at 2022-06-26 00:54:44.743502
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # TODO: Write unit test for method queries of class FXRateService
    assert 1


# Generated at 2022-06-26 00:54:56.329182
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-26 00:55:05.236596
# Unit test for method query of class FXRateService
def test_FXRateService_query():
  str_0 = 'apm!\x0b1zN/*X'
  dict_0 = {str_0: str_0}
  f_x_rate_service_0 = FXRateService(**dict_0)
  currency_0 = None
  tuple_0 = ()
  list_0 = [currency_0, currency_0, tuple_0, tuple_0]
  f_x_rate_0 = FXRate(*list_0)
  f_x_rate_service_0.query(currency_0, currency_0, f_x_rate_0)


# Generated at 2022-06-26 00:55:14.824475
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_0 = module_1.date(**dict_0)
    currency_1 = None
    f_x_rate_1 = f_x_rate_service_0.query(currency_0, currency_1, date_0, True)


# Generated at 2022-06-26 00:55:24.403390
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    currency_1 = None
    currency_2 = None
    tuple_0 = (currency_0, currency_0, currency_0)
    list_0 = [currency_0, currency_0, currency_1, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    tuple_1 = (f_x_rate_0, currency_2)
    list_1 = [currency_0, currency_1, tuple_1]
    f_x_rate_service_0 = FXRateService(*list_1)
    tuple_2 = (currency_0, currency_1, currency_0)
    f_x_rate_lookup_error_0 = FXRateLookupError(*tuple_2)

# Generated at 2022-06-26 00:55:30.377981
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_0 = FXRate(None, None, None, None)
    f_x_rate_1 = FXRate(None, None, None, None)
    f_x_rate_2 = FXRate(None, None, None, None)
    list_0 = [f_x_rate_0, f_x_rate_1, f_x_rate_2]


# Generated at 2022-06-26 00:55:44.941898
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:55:55.202447
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)

# Generated at 2022-06-26 00:56:00.320072
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import datetime

    from pypara.currencies import Currency, Currencies

    fx = FXRateService.default

    fx = fx.query(Currencies.USD, Currencies.JPY, datetime.now())

    assert fx is not None
    assert isinstance(fx, FXRate)
    assert fx.value > 0

# Generated at 2022-06-26 00:56:01.121132
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:56:10.891152
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime as module_0
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_0.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_1 = module_0.date(**dict_0)
   

# Generated at 2022-06-26 00:56:20.433407
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate1 = FXRate(Currencies['EUR'], Currencies['USD'], datetime.date(2014, 11, 22), Decimal('1.25000'))
    rate2 = FXRate(Currencies['CHF'], Currencies['USD'], datetime.date(2014, 11, 22), Decimal('1.12349'))
    rate3 = FXRate(Currencies['EUR'], Currencies['USD'], datetime.date(2014, 11, 23), Decimal('1.26854'))
    rate4 = FXRate(Currencies['CHF'], Currencies['USD'], datetime.date(2014, 11, 23), Decimal('1.14254'))

# Generated at 2022-06-26 00:56:29.838256
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    currency_1 = None
    currency_2 = None
    ccy1_0, ccy2_0,

# Generated at 2022-06-26 00:56:33.554299
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # TODO: Implement unit tests for methods queries of class FXRateService
    # This method is part of an abstract class and currently not implemented
    # It is not completely clear how these tests are supposed to work
    raise NotImplementedError("Tests for method queries of class FXRateService are not yet implemented")


# Generated at 2022-06-26 00:56:43.316103
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    bool_0 = bool('A/\x1a')

# Generated at 2022-06-26 00:56:52.626741
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    tuple_0 = ()
    f_x_rate_0 = FXRate(currency_0, currency_0, tuple_0, tuple_0)
    tuple_1 = (currency_0, currency_0, tuple_0)
    str_0 = 'n\x1eX\x01@\x00\x19\x17\x1c*'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    f_x_rate_service_0.queries((tuple_1,))
    f_x_rate_service_0.queries([tuple_1])
    f_x_rate_service_0.queries((tuple_1,), True)
    f_x_

# Generated at 2022-06-26 00:57:21.591763
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    module_0 = sys.modules[__name__]
    test_case_0()
    module_0.test_case_0()


# Generated at 2022-06-26 00:57:24.385919
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    fx_rate = FXRateService.default.query(Currency.of("EUR"), Currency.of("USD"), Date.today())

    assert(fx_rate.value is not None)


# Generated at 2022-06-26 00:57:38.320412
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    date_0 = module_1.date(**dict({'day': 17}))
    f_x_rate_1 = FXRate.of(currency_0, currency_0, date_0, Decimal('-3955'))
    f_x_rate_1 = FXRate(**dict({'ccy2': currency_0}))
    date_1 = module_1.date(**dict({'year': 2002}))
    f_x_rate_service_0 = FXRateService()
    currency_1 = None

# Generated at 2022-06-26 00:57:46.861556
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # param: queries: An iterable of :class:`Currency`, :class:`Currency` and :class:`Temporal` tuples.
    date_0 = datetime.date.today()
    fx_rate_0 = FXRate(Currencies["EUR"], Currencies["USD"], date_0, Decimal("2"))
    queries = [(Currencies["EUR"], Currencies["USD"], date_0, fx_rate_0)]
    strict = True
    service = FXRateService()
    result = service.queries(queries, strict)
    assert result == queries


# Generated at 2022-06-26 00:57:50.789920
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    currency_0 = Currency()
    currency_1 = Currency()
    date_0 = Date()
    f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_1, date_0, True)


# Generated at 2022-06-26 00:57:56.033452
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    tuple_0 = (currency_0, currency_0, currency_0)
    list_0 = [tuple_0, tuple_0, tuple_0]
    f_x_rate_2 = FXRateService(**{})
    f_x_rate_3 = f_x_rate_2.query(*list_0)


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-26 00:58:06.117664
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_1 = module_1.date(**dict_0)
    currency_1 = None
    f_

# Generated at 2022-06-26 00:58:11.096894
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime as module_1
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_1 = module_1.date(**dict_0)
   

# Generated at 2022-06-26 00:58:20.031286
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_1 = module_1.date(**dict_0)
    currency_1 = None
    f_

# Generated at 2022-06-26 00:58:30.051151
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    currency_1 = None
    date_0 = module_1.date(**FXRateService.__dict__.get('__annotations__'))
    str_0 = 'n7\u0017\xa5\x89\x80y>9\x84\x8d\x1f\x1d\x030u'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_1, date_0)

# Generated at 2022-06-26 00:59:49.676322
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    tuple_0 = ()
    f_x_rate_0 = FXRate(*tuple_0)
    dict_0 = {'\x1f': None, '\x1e': f_x_rate_0, '\x1d': f_x_rate_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    tuple_1 = ()
    tuple_2 = (tuple_1, tuple_0, True)
    tuple_3 = (tuple_0, tuple_0, True)
    list_0 = [tuple_2, tuple_3]
    dict_1 = {'\x1f': None, '\x1e': f_x_rate_0, '\x1d': f_x_rate_0}
    f_x_rate_service

# Generated at 2022-06-26 00:59:54.972325
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ccy1 = ccy2 = asof = strict = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(ccy1, ccy2, asof, strict)



# Generated at 2022-06-26 01:00:04.092925
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = Currency("", "", "")
    tuple_0 = (currency_0, currency_0, currency_0)
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)

# Generated at 2022-06-26 01:00:09.699370
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_0 = FXRate()
    tuple_0 = (f_x_rate_0, f_x_rate_0, f_x_rate_0)
    iterable_0 = []
    bool_0 = True
    iterable_1 = f_x_rate_service_0.queries(iterable_0, bool_0, *tuple_0)


# Generated at 2022-06-26 01:00:16.983111
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = None
    tuple_0 = ()
    list_0 = [currency_0, currency_0, tuple_0, tuple_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [currency_0, currency_0, currency_0, tuple_0]
    date_0 = module_1.date(*list_1)
    str_0 = 'apm!\x0b1zN/*X'
    dict_0 = {str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_1 = module_1.date(**dict_0)
    currency_1 = None
    f_

# Generated at 2022-06-26 01:00:20.158761
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    list_0 = []
    f_x_rate_service_0.queries(list_0)


# Generated at 2022-06-26 01:00:29.091861
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime as module_0
    list_0 = [module_0.date(2020, 7, 3)]
    tuple_0 = (list_0, [list_0], [list_0])
    list_1 = [tuple_0, tuple_0, tuple_0]
    tuple_1 = (list_1, list_1, list_1)
    list_2 = [tuple_1, tuple_1]
    list_3 = [list_2, list_2]
    list_4 = []
    for list_5 in list_3:
        for list_6 in list_5:
            for tuple_2 in list_6:
                for list_7 in tuple_2:
                    for date_0 in list_7:
                        list_4.append(date_0)
    list_8 = []

# Generated at 2022-06-26 01:00:39.084887
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## Case 0
    # Constructor
    currency_1 = None
    tuple_1 = ()
    list_2 = [currency_1, currency_1, tuple_1, tuple_1]
    f_x_rate_2 = FXRate(*list_2)
    f_x_rate_3 = f_x_rate_2.__invert__()
    list_3 = [currency_1, currency_1, currency_1, tuple_1]
    date_2 = module_1.date(*list_3)
    str_1 = 'apm!\x0b1zN/*X'
    dict_1 = {str_1: str_1}
    f_x_rate_service_1 = FXRateService(**dict_1)
    date_3 = module_1.date(**dict_1)


# Generated at 2022-06-26 01:00:40.552876
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    try:
        assert False
    except AssertionError as e:
        raise e


# Generated at 2022-06-26 01:00:44.323374
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = [currency_0, currency_1, date_1]
    tuple_0 = tuple(list_0)
    iterable_0 = [tuple_0]
    f_x_rate_service_0.queries(iterable_0, False)
    print("FXRateService.queries(...): ", "OK")
