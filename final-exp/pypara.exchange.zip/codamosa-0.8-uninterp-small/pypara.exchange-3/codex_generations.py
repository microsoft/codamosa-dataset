

# Generated at 2022-06-26 00:51:46.013391
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit Test for method queries of class FXRateService.
    """
    class TestFXRateService(FXRateService):
        def __init__(self):
            pass

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass


# Generated at 2022-06-26 00:51:51.454573
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    n_rate_0 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    r_rate_0 = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(not ~n_rate_0 == r_rate_0)


# Generated at 2022-06-26 00:52:00.466352
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from fractions import Fraction
    from pypara.currencies import Currencies

    from .fxrates.queries import FXRateQuery

    service = FXRateQuery.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=True)
    service.query(Currencies["USD"], Currencies["EUR"], datetime.date.today(), strict=True)
    service.query(Currencies["USD"], Currencies["EUR"], datetime.date.today(), strict=False)


# Generated at 2022-06-26 00:52:00.975943
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert True

# Generated at 2022-06-26 00:52:07.133778
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    import pytest

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    nrate = ~rate

    assert nrate.ccy1 == Currencies["USD"]
    assert nrate.ccy2 == Currencies["EUR"]
    assert nrate.date == datetime.date.today()
    assert nrate.value == Decimal("0.5")

    pytest.raises(TypeError, ~"EUR/USD")


# Generated at 2022-06-26 00:52:08.029842
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:52:13.067139
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-26 00:52:21.025880
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.market.fx import FXRateService

    class FxRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass


# Generated at 2022-06-26 00:52:26.593096
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    import datetime
    from decimal import Decimal

    fxrateservice_obj_0 = FXRateService()
    fxrateservice_obj_0.query(Currency('EUR'),Currency('USD'),datetime.date(2019, 5, 6),True)
    fxrateservice_obj_0.query(Currency('EUR'),Currency('USD'),datetime.date(2019, 5, 6),False)


# Generated at 2022-06-26 00:52:38.474190
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    from .commons.zeitgeist import Date

    class FXRateService_0(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            if not isinstance(ccy1, Currency):
                raise ValueError("CCY/1 must be of type `Currency`.")
            if not isinstance(ccy2, Currency):
                raise ValueError("CCY/2 must be of type `Currency`.")
            if not isinstance(asof, Date):
                raise ValueError("As-of date must be of type `date`.")

# Generated at 2022-06-26 00:52:53.154396
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:53:01.809569
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:53:10.732484
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'YQW8\x0b[Z<K:.|$d2f>K'
    currency_type_0 = module_0.CurrencyType.MONEY
    int_0 = -3305
    str_1 = 'p7!S\\#PJ'
    list_0 = [str_1]
    str_2 = 'yyTz9t2'
    str_3 = '3q\r=Z:KpZw'
    dict_0 = {str_0: currency_type_0, str_2: int_0, str_0: str_1, str_2: list_0, str_0: str_3}
    currency_0 = module_0.Currency(**dict_0)

# Generated at 2022-06-26 00:53:20.467752
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # arrange
    str_0 = ':m\x0b3q_#/^Bg'
    int_0 = 3679
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    int_1 = -1914
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = '^tP>/y[\x0bf'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_2 = -4655
    currency_1 = module_0.Currency(str_0, str_1, int_0, currency_type_1, decimal_0, int_2)
    date_0 = None

# Generated at 2022-06-26 00:53:28.633037
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = ']&\x0cN9I\'H>n=5YgA;'
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    int_1 = -3801
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'

# Generated at 2022-06-26 00:53:37.374215
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:53:45.839373
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 00:53:54.793762
# Unit test for method query of class FXRateService

# Generated at 2022-06-26 00:54:00.522743
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    print("[*] Running Test: test_FXRateService_queries")

    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    currency_0 = module_0.Currency("\t\x0b$*W\x0b", "t6\x0bFOx)8!6*L#[N", 1102, currency_type_0, None, -1272)
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    currency_1 = module_0.Currency("\t\x0b$*W\x0b", "$Q:g:%c,\ntK]Vu\r^", 1102, currency_type_1, None, -3801)
    date_0 = module_3.date(0, 0, 0)
    query_

# Generated at 2022-06-26 00:54:08.586910
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'J5`\x0bZ\tB1C#Q'
    str_1 = '',
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    currency_0 = module_0.Currency(str_1, str_0, str_0, currency_type_0, str_0, str_0)
    str_2 = '\x0c\x0b-\x0c\x0b-\x0c\x0b-'
    name_0 = 'y'
    dict_0 = {name_0: str_2}
    date_0 = module_3.date(**dict_0)
    str_3 = '\x0bvj+W<'
    list_0 = [str_3]

# Generated at 2022-06-26 00:54:28.233984
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_8 = 'NTl$:hjr<r@,l]\r\x0b'
    str_9 = '1,c9\r\x0bKr`r\r,M=5P@'
    int_4 = 1313
    currency_type_3 = module_0.CurrencyType.ALTERNATIVE
    list_1 = [currency_type_3]
    str_10 = '"7V\x0b)K7V'
    str_11 = 'A0v&4\x0b\x0b[-0\t@'
    dict_2 = {str_10: list_1, str_11: str_8, str_11: int_4, str_9: currency_type_3}

# Generated at 2022-06-26 00:54:36.755885
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '6*)'
    str_1 = 'X;RV7wJ=E*yq]L8'
    int_0 = 4063
    currency_type_0 = module_0.CurrencyType.MONEY
    list_0 = [currency_type_0, currency_type_0, currency_type_0, currency_type_0]
    str_2 = 't6\x0bFOx)8!6*L#[N'
    dict_0 = {str_2: currency_type_0, str_2: currency_type_0, str_2: str_1, str_1: int_0}
    decimal_0 = module_2.Decimal(*list_0, **dict_0)
    int_1 = -3834

# Generated at 2022-06-26 00:54:45.624141
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '|>w*ml-1^,=+@[rM\r'
    str_1 = '=P43;U/\x0b7Nu>T#'
    int_0 = 3939
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 't^:i]hR\x0bLNl$[^g\x0b'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -1475

# Generated at 2022-06-26 00:54:56.705533
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:55:07.784333
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_2 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_3 = -3801

# Generated at 2022-06-26 00:55:14.053855
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = [-6913, None, -6913, -6913, -6913, -6913, None, None]
    bool_0 = list_0[-1]
    f_x_rate_service_0 = FXRateService()
    optional_0 = f_x_rate_service_0.queries(list_0, bool_0)


# Generated at 2022-06-26 00:55:23.261690
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '9E7Vu(<PaJ}oT(mEwPf_'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:55:29.545591
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ':sH>+k-*>|@,"!1'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:55:38.496078
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\x0b\\2>\r\r3s\r'
    str_1 = '$H+p>0R@!,;'
    int_0 = 0
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = None
    int_1 = 0
    currency_0 = module_0.Currency(str_0, str_1, int_1, currency_type_0, decimal_0, int_1)
    str_2 = 'l'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_2 = -4198
    currency_1 = module_0.Currency(str_2, str_2, int_2, currency_type_1, decimal_0, int_1)
    str_

# Generated at 2022-06-26 00:55:48.939301
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    int_0 = -7475
    str_0 = 'h(DZl\r\r'
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    int_1 = 7461
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    currency_type_1 = module_0.CurrencyType.MONEY
    str_1 = "3TqXf,~z'S"
    int_2 = -8984
    currency_1 = module_0.Currency(str_1, str_0, int_0, currency_type_1, decimal_0, int_2)
    date_0 = None
    f_x_rate_lookup

# Generated at 2022-06-26 00:56:15.876148
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '8\x0b@';
    str_1 = '\x0b\x0b#-&'
    int_0 = 3990
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    int_1 = 0
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = '.>T;O'
    str_3 = '|*B!\tY#@;(Np'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_2 = 0

# Generated at 2022-06-26 00:56:25.553566
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = ';$h*}yc5@5Q1r-\n{o'
    str_1 = '_n&\\h`#d)B\\&y_]W'
    int_0 = 4341
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    list_0 = [currency_type_0]
    str_2 = 'h?6X'
    str_3 = 'u-\tSV[3u'
    dict_0 = {str_2: list_0, str_3: str_0, str_3: int_0, str_1: currency_type_0}
    decimal_0 = module_2.Decimal(*list_0, **dict_0)
    int_1 = 1201

# Generated at 2022-06-26 00:56:34.473815
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """Tests the queries method of class FXRateService"""
    # str : '&N4ouz)ZpNi'
    str_0 = '&N4ouz)ZpNi'
    # str : 'JLz4?}v@)X`Y'
    str_1 = 'JLz4?}v@)X`Y'
    # str : '+'
    str_2 = '+'
    # str : '<-v"d\x0b1%*gm-c'
    str_3 = '<-v"d\x0b1%*gm-c'
    # str : '`'
    str_4 = '`'
    # str : '?O~O!\x0c\x0c)L4zE$wo'

# Generated at 2022-06-26 00:56:44.363288
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_5 = '&vwCYc%ZNxhC\x0b'
    str_6 = '<+,pA\x0b)h\t{4V2'
    int_7 = 697
    currency_type_3 = module_0.CurrencyType.MONEY
    list_1 = [currency_type_3]
    str_7 = 'S[l<\x0b@[Y,!wPQFV*'
    str_8 = '4,;<:hq'
    dict_2 = {str_7: list_1, str_8: str_5, str_8: int_7, str_6: currency_type_3}
    decimal_2 = module_2.Decimal(*list_1, **dict_2)
    int_8 = 3630

# Generated at 2022-06-26 00:56:53.621827
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\x1e\x12\t\x18t\x0b'
    int_0 = -2055
    currency_type_0 = module_0.CurrencyType.MONEY
    list_0 = [currency_type_0]
    str_1 = 'H]k=hqFy2B<)K/:R'
    str_2 = "3N1+Np"
    dict_0 = {str_1: list_0, str_2: str_0, str_2: int_0, str_2: currency_type_0}
    decimal_0 = module_2.Decimal(*list_0, **dict_0)

# Generated at 2022-06-26 00:57:05.621838
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\x0bvr5"5H5y1h_d'
    str_1 = ':AMt0^0h$@=\x0bC\x0b'
    int_0 = 3053
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_2.Decimal()
    int_1 = -4246
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = 'x\'i$z/~A\rr'
    str_3 = '\\iPIMh\\`Rj7Vu'
    currency_type_1 = module_0.CurrencyType.UNIT

# Generated at 2022-06-26 00:57:14.168746
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService
    """
    # Create an instance of class FXRateService to test
    decimal_0 = None
    int_0 = 9089
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    str_0 = '\x19(\\N*\\$h(>_M<\x0c;'
    str_1 = '\x0bUe7Vp=10m64w'
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    currency_type_1 = module_0.CurrencyType.COMMODITY
    str_2 = '\\#x<\tXioN\\\x0b\\z'
    int_1

# Generated at 2022-06-26 00:57:23.103212
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:57:23.972979
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert True == True


# Generated at 2022-06-26 00:57:38.117994
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:58:14.371874
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = [100]
    dict_0 = {}
    decimal_0 = module_2.Decimal(*list_0, **dict_0)
    str_0 = ',6U1}6U>'
    str_1 = 'z6Xn\x0bT?Z2T'
    int_0 = -3987
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'a[{3!yiJ}X+Nz4'
    currency_type_1 = module_0.CurrencyType.MONEY

# Generated at 2022-06-26 00:58:24.166479
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:58:32.393968
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:58:40.108606
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
  dict_0 = dict()
  dict_0['b'] = 2
  dict_0['a'] = 1
  dict_0['c'] = 3
  dict_0['d'] = 4
  dict_0['e'] = 5
  dict_0['f'] = 6
  dict_0['g'] = 7
  dict_0['h'] = 8
  dict_0['i'] = 9
  dict_0['j'] = 10
  dict_0['k'] = 11
  dict_0['l'] = 12
  list_0 = list()
  list_0.append(1)
  list_0.append(2)
  list_0.append(3)
  list_0.append(4)
  list_0.append(5)
  list_0.append(6)
  list_

# Generated at 2022-06-26 00:58:47.896769
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\x0b\rP\rT*\\6X.'
    str_1 = '\rQ:b-i<^'
    int_0 = -1409
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = '\x0b\x0b;\'N\x0b&\x0b\x0b\x0bC\x0b1'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -9289

# Generated at 2022-06-26 00:58:55.973273
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 00:59:03.536018
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import decimal as module_2
    import datetime as module_3
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERN

# Generated at 2022-06-26 00:59:13.019632
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ## Define a mock FX rate service:
    class TestFXRateService(FXRateService):
        def __init__(self, data: dict = None) -> None:
            self.data = data or {}

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            try:
                return self.data[(ccy1.code, ccy2.code)]
            except KeyError:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-26 00:59:15.598285
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    tuple_0 = (None, None, None)
    list_0 = [tuple_0]
    optional_0 = f_x_rate_service_0.queries(list_0)


# Generated at 2022-06-26 00:59:25.178973
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 01:00:37.233973
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'BF*6$+y'
    str_1 = '(N:J~.\\]_<+a2\\J\x0b0g'
    int_0 = -2956
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = '^{,X\\c%g{aTv2H\\:W'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801

# Generated at 2022-06-26 01:00:45.058011
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'hK1@Qq3<r)/P,o'
    str_1 = 'jK\n\x0bx\\C,f\x0b1Kg~a'
    int_0 = 4966
    currency_type_0 = module_0.CurrencyType.MONEY
    list_0 = [currency_type_0]
    str_2 = 'SpopRWf1$mjn2Q3E'
    str_3 = '!nWU\x0b?4ejw'
    dict_0 = {str_2: str_3, str_3: list_0, str_3: str_0, str_0: int_0}
    decimal_0 = module_2.Decimal(*list_0, **dict_0)

# Generated at 2022-06-26 01:00:52.415705
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0)
    currency_1 = module_0.Currency(str_0, str_2, int_0, currency_type_1, decimal_0, int_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_1, date_0)
    currency_2 = module_0.Currency(str_3, str_4, int_2, currency_type_2, decimal_1, int_3)
    date_1 = module_3.date(**dict_0)
    str_7 = '<-v"d\x0b1%*gm-c'

# Generated at 2022-06-26 01:00:56.525229
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    dict_0 = {}
    f_x_rate_service_0 = FXRateService(**dict_0)
    queries_0 = []
    list_0 = []
    queries_0.append(list_0)
    strict_0 = True
    f_x_rate_service_0.queries(queries_0, strict_0)


# Generated at 2022-06-26 01:01:03.673815
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\t?yAAk>CkX\n4@WDL'
    str_1 = '<-v"d\x0b1%*gm-c'
    currency_type_0 = module_0.CurrencyType.MONEY
    int_0 = 1185
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, int_0, int_0)
    date_0 = None
    date_1 = None
    list_0 = [currency_type_0, currency_type_0, currency_type_0, currency_type_0, currency_type_0, currency_type_0]
    tuple_0 = (module_0.Currency, module_0.Currency, currency_type_0)
    tuple_

# Generated at 2022-06-26 01:01:10.980353
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    print("Test for method queries of class FXRateService")

    int_1 = 1445
    str_0 = '\x0e+]\'$J9\x0cD:<1{N-p0'
    list_0 = [str_0]
    str_1 = 'J`z1:<~'
    int_0 = 2555
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = '_jm*x~2D>|F'
    list_1 = [currency_0]
    int_2 = 1038
    currency_type_1 = module_0

# Generated at 2022-06-26 01:01:18.920243
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'Xh=Z:O<,)5_5l|Ft'
    str_1 = 'b;Q,\x0c@8aD^I=\t'
    int_0 = -3044
    currency_type_0 = module_0.CurrencyType.MONEY
    list_0 = [currency_type_0]
    str_2 = 'M[2&I\n'
    str_3 = '-g~fD'
    str_4 = "3{9'<u"
    dict_0 = {str_2: list_0, str_4: int_0, str_4: str_0, str_3: str_3}
    decimal_0 = module_2.Decimal(*list_0, **dict_0)
    int_1 = 4183


# Generated at 2022-06-26 01:01:26.025256
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '\x0c@\x0b'
    str_1 = 'I\t'
    int_0 = 1178
    currency_type_0 = module_0.CurrencyType.PREPAID_CARD
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'Fxw5-*\'qo'
    str_3 = '4*`^h'
    str_4 = r'#{Dw\&-z7hAb'
    str_5 = '<\x0b\x0c-0\x0bt'
    int_1 = -891
    currency_type_1 = module_0.Currency

# Generated at 2022-06-26 01:01:33.614611
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 't6\x0bFOx)8!6*L#[N'
    str_1 = '\n    Provides a *defined* price object model.\n    '
    int_0 = -1272
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'w1m2WK^d,Wn<Pz\r\x0b(xq)'
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    int_1 = -3801