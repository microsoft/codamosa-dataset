

# Generated at 2022-06-26 00:51:51.975472
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert FXRateService().query(Currency('USD'), Currency('TRY'), Date(2016, 10, 4)) == Decimal('3.0591')
    assert FXRateService().query(Currency('TRY'), Currency('USD'), Date(2016, 10, 4)) == Decimal('0.3265')

# Generated at 2022-06-26 00:52:00.797924
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_0 = FXRate.of(None, None, None, None)
    f_x_rate_1 = FXRate.of(None, None, None, None)
    f_x_rate_2 = FXRate.of(None, None, None, None)
    f_x_rate_3 = FXRate.of(None, None, None, None)
    f_x_rate_4 = FXRate.of(None, None, None, None)
    f_x_rate_5 = FXRate.of(None, None, None, None)
    f_x_rate_6 = FXRate.of(None, None, None, None)
    f_x_rate_7 = FXRate.of(None, None, None, None)

# Generated at 2022-06-26 00:52:04.776762
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate = FXRate(Currency("USD"),Currency("EUR"),Date("1991-01-01"),Decimal("1.0"))
    service = FXRateService()
    service.queries([("USD", "EUR", Date("1991-01-01")),("EUR", "USD", Date("1991-01-01"))],strict=False)
    assert(True)

# Generated at 2022-06-26 00:52:13.561124
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import datetime
    from pypara.currencies import Currency
    from pypara.finance.fx.fx_rates_mem import InMemoryFXRateService
    imfrs = InMemoryFXRateService()
    imfrs.add(Currency("USD"), Currency("EUR"), datetime(2020, 1, 1), Decimal("1.1"))
    imfrs.add(Currency("USD"), Currency("EUR"), datetime(2020, 1, 2), Decimal("1"))

# Generated at 2022-06-26 00:52:21.646485
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Testing the FXRateService query method in case the FX rate is found
    service = FXRateService()
    result = service.query(Currency, Currency, Date)
    assert result != None
    # Testing the FXRateService query method in case the FX rate is not found
    service = FXRateService()
    result = service.query(Currency, Currency, Date)
    assert result == None
    # Testing whether an error is thrown when a FXRateService is not initialized
    service = FXRateService()
    success = False
    try:
        result = service.query(Currency, Currency, Date)
    except:
        success = True
    assert success
    # Testing whether an error is thrown when the input argument of a query does not satisfy the
    # necessary requirements
    service = FXRateService()
    success = False

# Generated at 2022-06-26 00:52:33.936591
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.zeitgeist import Date
    from decimal import Decimal
    from datetime import datetime

    from .currencies import Currency, Currencies

    from .fx import FXRate, FXRateService

    euro = Currency("EUR", "EUR", "Euro", "978")
    usd = Currency("USD", "USD", "US Dollar", "840")

    class _MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == euro and ccy2 == usd:
                return FXRate(ccy1, ccy2, asof, Decimal("1.25"))
            else:
                return None

    fx_rate_service = _MockFXRate

# Generated at 2022-06-26 00:52:34.748225
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:52:35.365025
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-26 00:52:36.644829
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: Implement Unit test for method query of class FXRateService
    raise NotImplementedError()


# Generated at 2022-06-26 00:52:42.297802
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    import datetime
    from decimal import Decimal
    from pypara.finance.fx.rates.ecb import ECBRateService
    ecb_rate_service = ECBRateService()
    ecb_rate_service.query(Currency('USD'),Currency('EUR'),datetime.date(2018,12,31))
    ecb_rate_service.query(Currency('USD'),Currency('EUR'),datetime.date(2018,12,31),strict=False)
    ecb_rate_service.query(Currency('XXX'),Currency('XXX'),datetime.date(2018,12,31),strict=False)

# Generated at 2022-06-26 00:52:53.896963
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:53:02.216489
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:53:11.145217
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:53:20.786609
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:53:28.966346
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Test cases
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:53:30.097322
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    yes = False
    if yes:
        raise Exception


# Generated at 2022-06-26 00:53:38.711099
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:53:47.805922
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:53:50.013093
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # DEBUG: Method 'query(ccy1,ccy2,asof,strict)' not defined in 'FXRateService'
    assert False


# Generated at 2022-06-26 00:53:57.438122
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:54:17.777297
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Tests whether queries raises FXRateLookupError when strict is set to True and the rate is not found
    import datetime as module_1
    import pypara.currencies as module_2

    dict_0 = dict()
    date_0 = module_1.date(**dict_0)
    date_1 = module_1.date(**dict_0)

# Generated at 2022-06-26 00:54:27.944107
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    def test_case_0():
        str_0 = "5gP?Z\x0cQ~H\x0c\x0cI4\x0bi\x0c"
        dict_0 = {str_0: str_0}
        int_0 = -1449
        int_1 = -2406
        decimal_0 = module_3.Decimal(**dict_0)
        str_1 = '\x0c\x0c\x0b\x0c\x0c\x0c\x0b\x0c\x0b'
        currency_type_0 = module_2.CurrencyType.FIAT
        decimal_1 = module_3.Decimal(**dict_0)

# Generated at 2022-06-26 00:54:36.464212
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    date_0 = module_1.date(2370, 11, 3)
    dict_0 = {False: date_0}
    str_0 = 'g{3'
    f_x_rate_lookup_error_0 = FXRateLookupError(None, None, None)
    dict_1 = {}
    int_0 = 1462
    list_0 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]
    f_x_rate_service_0 = FXRateService(*list_0)
    list_1 = [date_0, str_0]
    f_x_rate_service_1 = FXRateService(*list_1, **dict_0)
    f_x_rate_service_2 = FXRateService(*list_1)
    iter

# Generated at 2022-06-26 00:54:44.956259
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_0, dict_0, int_0]
    f_x_rate_service_0 = FXRateService(*list_1, **dict_0)
    list_2 = [date_0, str_0]
    f_x_rate_service_1 = FXRateService(*list_2, **dict_0)
   

# Generated at 2022-06-26 00:54:56.516942
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:55:07.479542
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This is unit test for fx_rate_service.queries(self, *args, **kwargs) function. Verify that method queries
    returns an iterable of FX rates for given currency rates.

    The unit test case is implemented in 4 steps as follows:

        1. Create an FX rate service implementation, which returns constant FX rates.
        2. Create a list of FX rate queries with various currency pairs and dates.
        3. Invoke the ``queries`` method to process the list of queries and make sure that it is returning a list
           of rates with the same length as the query list.
        4. Verify that all rates in the returned list are matching with the expected results.

    """
    ## Step 1: Create an FX rate service implementation, which returns constant FX rates:

# Generated at 2022-06-26 00:55:18.412467
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    decimal_0 = module_3.Decimal(**{'context': None})
    f_x_rate_service_0 = FXRateService(*[])
    dict_0 = {'prec': module_3.Decimal(**{'context': None})}
    currency_type_0 = module_2.CurrencyType.CRYPTO
    str_0 = "i9g'~c%WT6=D"
    dict_1 = dict(**{str_0: module_3.Decimal(**{'context': None})})
    str_1 = 'Dv/p"0jU!g'
    decimal_1 = module_3.Decimal(**dict_1)
    int_0 = -2270

# Generated at 2022-06-26 00:55:26.991925
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 00:55:35.954772
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    try:
        assertEqual(optional_0, f_x_rate_2)
    except:
        raise RuntimeError('Expected: FXRate(), instead got: {}'.format(optional_0))
    try:
        assertEqual(optional_0, f_x_rate_2)
    except:
        raise RuntimeError('Expected: FXRate(), instead got: {}'.format(optional_0))
    try:
        assertEqual(optional_0, f_x_rate_2)
    except:
        raise RuntimeError('Expected: FXRate(), instead got: {}'.format(optional_0))
    try:
        assertEqual(optional_0, f_x_rate_2)
    except:
        raise RuntimeError('Expected: FXRate(), instead got: {}'.format(optional_0))


# Unit

# Generated at 2022-06-26 00:55:46.754577
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:56:13.977037
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    date_0 = datetime.date(2019, 12, 24)
    decimal_0 = Decimal("12345678901234567890.1234")
    currency_0 = Currencies["USD"]
    currency_1 = Currencies["EUR"]
    fx_rate = FXRate.of(ccy1=currency_0, ccy2=currency_1, date=date_0, value=decimal_0)

    ## Test for Spot:
    assert fx_rate == FXRate.of(ccy1=currency_1, ccy2=currency_0, date=date_0, value=ONE / decimal_0)

    ## Test for date equality:
    assert fx_rate.date == date_0

    ## Test for currency equality:
    assert fx_rate.ccy1 == currency_0

# Generated at 2022-06-26 00:56:22.993619
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime as module_0
    import pypara.currencies as module_1
    import decimal as module_2
    str_0 = 'C'
    dict_1 = {}
    date_0 = module_0.date(**dict_1)
    currency_type_0 = module_1.CurrencyType.FIAT
    int_0 = 18
    int_1 = 2672
    decimal_0 = module_2.Decimal()
    currency_0 = module_1.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'X,xxZH{z\"}R'

# Generated at 2022-06-26 00:56:32.528797
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:56:41.996192
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [f_x_rate_1]
    tuple_0 = (date_0, dict_0)
    iterable_1 = f_x_rate_service_2.queries(tuple_0)
    str_1 = '[k4g~*;>}L\x0b'
    str_2 = 'MAD'
    int_1 = -2969
    bool_0 = False
    iterable_2 = f_x_rate_service_1.queries(bool_0)
    currency

# Generated at 2022-06-26 00:56:44.250227
# Unit test for method query of class FXRateService
def test_FXRateService_query():
  # Define a FXRateService object
  f_x_rate_service_0 = FXRateService()


# Generated at 2022-06-26 00:56:53.497397
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import os
    import random
    import json
    
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService, FXRateLookupError

    # Load the test data
    with open(os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'fxrates.json')), mode = 'r') as fxrates_file:
        fxrates = json.load(fxrates_file)

    # Create a currency pair
    ccy_pair = random.choice(list(fxrates))
    

# Generated at 2022-06-26 00:57:05.456872
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:57:14.047737
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime as module_1
    import pypara.currencies as module_2
    import decimal as module_3
    list_0 = [3158, 4908]
    dict_0 = {'\x09R\x60\x1b\x16\x0bDm\x5e': '\x09R\x60\x1b\x16\x0bDm\x5e', '\x0b`\x05\x1e\x08":jS*n': '\x0b`\x05\x1e\x08":jS*n'}
    date_0 = module_1.date(**dict_0)
    str_0 = '\x0b`\x05\x1e\x08":jS*n'

# Generated at 2022-06-26 00:57:15.346780
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:57:23.480085
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    tuple_0 = (module_1.date, module_2.Currency, module_2.Currency, module_3.Decimal)
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 35
    list_0 = [str_0, f_x_rate_lookup_error_3, dict_0, int_0]
    f_x_rate_lookup_error_0 = FXRateLookupError(*list_0, **dict_0)
    str_1 = '<3*l0h0`D-`>1x'
    bool_0 = True

# Generated at 2022-06-26 00:58:03.642659
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:58:05.237406
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert False


# Generated at 2022-06-26 00:58:13.950893
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    bool_0 = False
    f_x_rate_service_0 = FXRateService()
    tuple_0 = (dict, f_x_rate_service_0)
    iterable_0 = f_x_rate_service_0.queries(tuple_0, bool_0)
    f_x_rate_service_1 = FXRateService()
    tuple_1 = (f_x_rate_service_1, iterable_0)
    iterable_1 = f_x_rate_service_0.queries(tuple_1)
    iterable_2 = f_x_rate_service_0.queries(iterable_1)
    iterable_3 = f_x_rate_service_1.queries(iterable_0)
    iterable_4 = f_x_rate_service_1

# Generated at 2022-06-26 00:58:23.741692
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = [set(), set(), set(), set()]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]
    f_x_rate_service_0 = FXRateService(*list_1, **dict_0)

# Generated at 2022-06-26 00:58:32.163091
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Define test variables:
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]
    f_x_rate_service_0 = FXRateService

# Generated at 2022-06-26 00:58:39.826262
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:58:47.623095
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 00:58:49.675677
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    module_0 = module_import_7()
    class_0 = module_0.FXRateService
    method_0 = module_0.FXRateService.queries


# Generated at 2022-06-26 00:58:57.734581
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '[k4g~*;>}L\x0b'
    currency_type_0 = module_2.CurrencyType.CRYPTO
    str_1 = 'MAD'
    int_0 = -1437
    int_1 = -2969
    decimal_0 = module_3.Decimal(**{str_0: str_0})
    currency_0 = module_2.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__

# Generated at 2022-06-26 00:59:05.803993
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 01:00:28.562422
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Test error cases
    str_0 = "FXRateService.queries"
    # Create FXRateService
    currency_0 = __get_currency()
    currency_1 = __get_currency()
    tuple_0 = (currency_0, currency_1, currency_1)
    f_x_rate_service_0 = FXRateService(currency_0, currency_1, currency_1)
    # Try calling queries with three positional arguments, expecting TypeError
    with raises(TypeError):
        f_x_rate_service_0.queries(currency_1, currency_1, currency_1)
    # Try calling queries with two positional arguments, expecting TypeError
    with raises(TypeError):
        f_x_rate_service_0.queries(currency_0, currency_1)
    # Try calling queries with one positional argument

# Generated at 2022-06-26 01:00:38.635637
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime as module_1
    import pypara.currencies as module_2
    import decimal as module_3
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137

# Generated at 2022-06-26 01:00:46.113808
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 01:00:53.305599
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]

# Generated at 2022-06-26 01:00:55.186137
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert callable(getattr(module_0.FXRateService, "query"))


# Generated at 2022-06-26 01:00:59.784866
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]
    f_x_rate_service_0 = FXRateService(*list_1, **dict_0)

    currency_type_0 = module_2.CurrencyType.CRYPTO
    decimal_0 = module_3.Decimal(*list_2)
    str_3 = 'EhsMQYc*U_fx]t}"vM7'
    int_2 = -1437
    decimal_1 = module_3.Decimal(**dict_0)
    currency_0 = module_2.Currency(str_3, str_0, int_2, currency_type_0, decimal_1, int_1)

    bool_1 = True
    optional_0 = f_x_rate

# Generated at 2022-06-26 01:01:07.037202
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # We instantiate a new FX rate service:
    ## We import the module:
    import pypara.services.fx as module

    ## We instantiate the service:
    service = module.FXRateService()

    # AAA: we specify the cases we want to cover and test:
    ## We create a test case:
    from datetime import date
    from pypara.currencies import Currencies
    from .commons.numbers import ONE, ZERO
    from .services.fx import FXRate, FXRateLookupError

    ## We define the cases as a list of tuples in the following format:
    ## (Currency, Currency, date, Decimal, <expected type>, <expected value>)
    #

# Generated at 2022-06-26 01:01:12.014524
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    tuple_0 = (date_0, dict_0)
    iterable_0 = f_x_rate_service_0.queries(tuple_0)
    tuple_1 = (date_0, dict_0)
    iterable_1 = f_x_rate_service_1.queries(tuple_1)
    tuple_2 = (date_0, dict_0)
    iterable_2 = f_x_rate_service_2.queries(tuple_2)



# Generated at 2022-06-26 01:01:19.807444
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Code coverage for class FXRateService
    from pypara.currencies import Currency, Currencies
    from pypara.temporals import Date, Period
    from pypara.fx import FXRate, FXRateLookupError, FXRateService

    ## Try single query with empty service:
    class EmptyFXRateService(FXRateService):
        def __init__(self) -> None:
            super().__init__(Date.MIN, Date.MAX)

        def _query(self, ccy1: Currency, ccy2: Currency, asof: Date) -> Optional[FXRate]:
            return None

    service = EmptyFXRateService()

    eur_usd = FXRate(Currencies["EUR"], Currencies["USD"], Date.parse("01-01-2019"), ONE)

# Generated at 2022-06-26 01:01:26.912141
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    set_0 = set()
    list_0 = [set_0, set_0, set_0, set_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_lookup_error_0 = None
    str_0 = ";\x0cd>Y'Dc_"
    dict_0 = {str_0: str_0}
    date_0 = module_1.date(**dict_0)
    int_0 = 137
    list_1 = [str_0, f_x_rate_lookup_error_0, dict_0, int_0]