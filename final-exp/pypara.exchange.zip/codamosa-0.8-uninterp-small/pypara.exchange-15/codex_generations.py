

# Generated at 2022-06-26 00:51:45.700074
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    expected_0 = None
    queries_0 = []
    actual_0 = f_x_rate_service_0.queries(queries_0)
    assert actual_0 == expected_0


# Generated at 2022-06-26 00:51:54.071863
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    ## Test the FX rate service contract:
    f_x_rate_service_0 = FXRateService()
    assert f_x_rate_service_0.query(Currencies["EUR"], Currencies["USD"], Date.today()) == None
    # Tests for strict argument:
    try:
        f_x_rate_service_0.query(Currencies["EUR"], Currencies["USD"], Date.today(), strict=True)
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"] and e.ccy2 == Currencies["USD"] and e.asof == Date.today()
    else:
        raise Exception("FXRateLookupError not raised.")


# Generated at 2022-06-26 00:51:55.756349
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## Success
    pass



# Generated at 2022-06-26 00:51:59.633215
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = Currency.of_code("XXX")
    currency_1 = Currency.of_code("XXX")
    date_0 = Date.today()
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(currency_0, currency_1, date_0, False)



# Generated at 2022-06-26 00:52:07.460370
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fxrates import (
        FXRate,
        FXRateLookupError,
        FXRateService,
        GenericFXRateService,
        SingletonFXRateService,
    )
    #
    s_fx_rate_service_0 = SingletonFXRateService()
    #

# Generated at 2022-06-26 00:52:16.330404
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.commons.zeitgeist import Date

    from pypara.currencies import Currencies

    from pypara.rates import QuandlFXRateService

    ## Set a service:
    service = FXRateService()

    ## We expect this query to fail:
    try:
        FXRateService().query(Currencies["EUR"], Currencies["USD"], Date.today())
        assert False, "We expected a TypeError."
    except TypeError:
        pass

    ## We expect this query to fail:
    try:
        service.query(
            Currencies["EUR"], Currencies["USD"], Date.today(), strict=True
        )
        assert False, "We expected a FXRateLookupError."
    except FXRateLookupError:
        pass

    ## We expect this query to succeed:
    rate = Qu

# Generated at 2022-06-26 00:52:24.270257
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    a_rate = FXRate(Currency('USD'), Currency('TRY'), Date(2000, 1,1), Decimal(3))
    another_rate = FXRate(Currency('EUR'), Currency('TRY'), Date(2000, 1,1), Decimal(2))
    a_list = [a_rate, another_rate]
    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            for rate in a_list:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            return None

        def queries(self, queries, strict=False):
            for a_tuple in queries:
                ccy1 = a_tuple[0]
                ccy2

# Generated at 2022-06-26 00:52:33.101972
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import AsOf
    f_x_rate_service_0 = FXRateService()
    # The call FXRateService.query() from line 0 raises an exception of type NotImplementedError
    with raises(NotImplementedError):
        f_x_rate_service_0.query(Currencies["USD"], Currencies["EUR"], AsOf(), False)


# Generated at 2022-06-26 00:52:40.384446
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.time import Temporal
    from pypara.currencies import Currencies
    TQuery = Tuple[Currency, Currency, Temporal]
    class TestFXRateService(FXRateService):
        def __init__(self):
            pass
        def query(self, ccy1, ccy2, asof, strict=False):
            pass
        def queries(self, queries, strict=False):
            import datetime
            from pypara.time import Temporal
            from pypara.currencies import Currencies
            from pypara.rates import FXRate
            results = []
            for args in queries:
                ccy1, ccy2, asof = args
                rate = FXRate(ccy1, ccy2, asof, Decimal("2"))
                results.append(rate)
            return

# Generated at 2022-06-26 00:52:41.616322
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert False



# Generated at 2022-06-26 00:52:49.136908
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:52:57.968739
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '9G'
    str_1 = ';(.@y=u\x0btqoQ'
    str_2 = 'f7L/e{'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_0}
    list_0 = [dict_0, str_1, str_0, str_0]
    dict_1 = {}
    f_x_rate_0 = FXRate(*list_0, **dict_1)
    f_x_rate_1 = f_x_rate_0
    iterable_0 = None
    f_x_rate_service_0 = f_x_rate_0
    f_x_rate_service_0.queries(iterable_0)


# Generated at 2022-06-26 00:53:03.704760
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    _list_0 = []
    _list_1 = []
    _dict_0 = {}
    _dict_1 = {}
    _float_0 = 0.0
    _str_0 = ''

    # Create a FXRateService instance.
    # Call the queries method and pass it the arguments _dict_0, _dict_1 and _str_0.
    # If a LookupError exception is raised, then pass the exception to the except block.
    # If a TypeError exception is raised and the exception message is equal to "unsupported operand type(s) for +: 'int' and 'NoneType'", then pass the exception to the except block.
    # Return nothing.
    pass


# Generated at 2022-06-26 00:53:07.858663
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # 1. Setup
    # TODO: Set your test input here
    ccy1 = None
    ccy2 = None
    asof = None
    strict = False

    # 2. Invoke method
    # TODO: Invoke your method
    f_x = None

    # 3. Assertions
    assert True


# Generated at 2022-06-26 00:53:17.248733
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    int_0 = 0
    int_1 = -1
    int_2 = 1
    str_0 = '9G'
    str_1 = ';(.@y=u\x0btqoQ'
    str_2 = 'f7L/e{'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_0}
    list_0 = [dict_0, str_1, str_0, str_0]
    dict_1 = {}
    f_x_rate_1 = list_0, dict_0
    f_x_rate_0 = FXRate(*list_0, **dict_1)
    dict_2 = {str_2: str_0, str_1: str_1, str_0: str_2}


# Generated at 2022-06-26 00:53:18.054609
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    print("Test method queries of class FXRateService")

# Generated at 2022-06-26 00:53:26.596642
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    
    # init
    import random
    random.seed(33)
    class FXRateServiceMock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if random.randint(0, 1) == 1:
                return FXRate(ccy1, ccy2, asof, 1.0)
            return None
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(*query) for query in queries)
    
    # arrange

# Generated at 2022-06-26 00:53:34.693448
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TEST: f_x_rate_service.query(str_1, asof, ccy2)
    # TEST: raise FXRateLookupError(ccy2, ccy1, asof)
    # TEST: f_x_rate_service.query(ccy1, asof, ccy2) = 'S'
    str_0 = 'u0'
    f_x_rate_lookup_error_0 = FXRateLookupError(str_0, str_0, str_0)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(str_0, str_0, str_0)

# Generated at 2022-06-26 00:53:41.660169
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # :return: An iterable of rates.
    str_0 = '\x1f'
    str_1 = '6>5C'
    list_0 = [str_0, str_1]
    f_x_rate_service_0 = FXRateService()
    iterable_0 = f_x_rate_service_0.queries(list_0)
    f_x_rate_service_1 = FXRateService()
    iterable_1 = f_x_rate_service_1.queries(list_0)
    # :return: An iterable of rates.


# Generated at 2022-06-26 00:53:50.913200
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class TestFXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    f_x_rate_service_0 = TestFXRateServiceImpl()
    f_x_rate_service_1 = TestFXRateServiceImpl()
    str_0 = 'Kj$'
    str_1 = 'q'
    f_x_rate_0 = FXRate(str_0, str_1, str_1, str_0)
    f_x_rate_1 = FXRate(str_1, str_1, str_1, str_1)

# Generated at 2022-06-26 00:54:07.049110
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # g_1.queries = iter(rs.queries(((c_0, c_1, d_1), (c_1, c_0, d_0), (c_2, c_1, d_0)), strict=False))
    # t_0 = g_1.queries.__next__()
    # t_1 = g_1.queries.__next__()
    # t_2 = g_1.queries.__next__()
    # t_3 = g_1.queries.__next__()
    # g_1.queries.__next__()
    pass

if __name__ == "__main__":
    test_case_0()
    # test_FXRateService_method_queries()

# Generated at 2022-06-26 00:54:15.178049
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'j*P]a&\r'
    str_1 = 'f7L/e{'
    str_2 = '9G'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_0}
    list_0 = [dict_0, str_1, str_0, str_0]
    dict_1 = {}
    f_x_rate_0 = FXRate(*list_0, **dict_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    iterable_0 = None


# Generated at 2022-06-26 00:54:24.489847
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    str_0 = '9G'
    str_1 = ';(.@y=u\x0btqoQ'
    str_2 = 'f7L/e{'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_0}
    list_0.append(dict_0)
    list_0.append(str_1)
    list_0.append(str_0)
    list_0.append(str_0)
    dict_1 = {}
    f_x_rate_0 = FXRate(*list_0, **dict_1)
    list_1 = []
    list_1.append(f_x_rate_0)
    f_x_rate_1 = None
    f_x

# Generated at 2022-06-26 00:54:34.038632
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies

    ccy1 = Currencies['EUR']
    ccy2 = Currencies['USD']
    nrate = FXRate(ccy1, ccy2, Date(2000, 1, 1), Decimal("2"))
    rrate = FXRate(ccy2, ccy1, Date(2000, 1, 1), Decimal("0.5"))

    # In-memory, static FX rate service:
    class MyFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self._rates = rates


# Generated at 2022-06-26 00:54:35.712570
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    it = FXRateService.query(FXRateService, 1, 2)
    it.__next__()


# Generated at 2022-06-26 00:54:40.671271
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    arg_0 = Currency.of({'Code': 'NZD', 'Symbol': '$', 'Digits': 2})
    arg_1 = Currency.of({'Code': 'AUD', 'Symbol': '$', 'Digits': 2})
    arg_2 = Date.of('2020-12-04')
    arg_3 = True
    obj = FXRateService()
    result = obj.query(arg_0, arg_1, arg_2, arg_3)


# Generated at 2022-06-26 00:54:51.394245
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    for _ in range(0, 10):
        dict_0 = {}
        dict_1 = dict_0
        dict_0 = dict_1
        dict_1 = dict_0
        dict_0 = dict_1
        dict_1 = dict_0
    for _ in range(0, 10):
        list_0 = []
        list_1 = list_0
        list_0 = list_1
        list_1 = list_0
        list_0 = list_1
        list_1 = list_0
    f_x_rate_service_0 = FXRateService()
    queries = []
    name = 'queries'
    strict = True

# Generated at 2022-06-26 00:54:59.866034
# Unit test for method query of class FXRateService

# Generated at 2022-06-26 00:55:09.477217
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert FXRateService.default is not None
    assert callable(FXRateService.default.query)
    assert not callable(FXRateService.default.queries)
    with raises(AttributeError):
        hasattr(FXRateService.default, 'queries')
    with raises(AttributeError):
        getattr(FXRateService.default, 'queries')
    assert FXRateService.default.query.__annotations__['ccy1'] == Currency
    assert FXRateService.default.query.__annotations__['ccy2'] == Currency
    assert FXRateService.default.query.__annotations__['asof'] == Date
    assert FXRateService.default.query.__annotations__['strict'] == bool
    assert FXRateService.default.query.__annotations__['return'] == Optional[FXRate]

#

# Generated at 2022-06-26 00:55:13.894510
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency

    service_0 = FXRateService.default
    query_0 = Currency, Currency, Date
    assert service_0.query(*query_0) == None


# Generated at 2022-06-26 00:55:30.656987
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    dict_0 = {}
    FXRateService.queries(**dict_0)


# Generated at 2022-06-26 00:55:31.490508
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:55:34.989899
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = Currency(code='J')
    f_x_rate_service_0 = FXRateService()
    f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_0, Date.from_str('19901015'))


# Generated at 2022-06-26 00:55:37.532402
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    tuple_0 = (list_0, list_0, list_0)
    assert FXRateService().queries(tuple_0, False) == []


# Generated at 2022-06-26 00:55:47.427420
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_0 = FXRate(Currency('RO', 'Romanian Leu'), Currency('AL'), Date.today(), Decimal(1))
    f_x_rate_1 = FXRate(Currency('RO', 'Romanian Leu'), Currency('AL', 'Albanian Lek'), Date.today(), Decimal(1))
    f_x_rate_2 = FXRate(Currency('RO', 'Romanian Leu'), Currency('AL', 'Albanian Lek'), Date.today(), Decimal(1))
    f_x_rate_3 = FXRate(Currency('RO', 'Romanian Leu'), Currency('AL', 'Albanian Lek'), Date.today(), Decimal(1))


# Generated at 2022-06-26 00:55:57.201674
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Test case 1:
    # Pass in an illegal value as the first argument, and the method will raise an exception.
    test_case_1()

    # Test case 2:
    # Pass in an illegal value as the second argument, and the method will raise an exception.
    # test_case_2()

    # Test case 3:
    # Pass in an illegal value as the third argument, and the method will raise an exception.
    # test_case_3()

    # Test case 4:
    # Pass in an illegal value as the fourth argument, and the method will raise an exception.
    # test_case_4()

    # Test case 5:
    # The method will not raise an exception.
    # test_case_5()

# Test case 1:

# Generated at 2022-06-26 00:56:02.118193
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '6i#'
    str_1 = 'A\x19Z)s*s|>f\x0b'
    str_2 = "&'oS,\x0b`=lK"
    str_3 = 'h>g'
    str_4 = "bH&,\x0b3"
    str_5 = "7VkO1"
    tuple_0 = (str_0, str_1, str_2, str_3, str_4, str_5)
    tuple_1 = (str_0, str_1, str_2, str_3, str_4, str_5)
    f_x_rate_service_0 = FXRateService(*tuple_1)

# Generated at 2022-06-26 00:56:11.764485
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '9G'
    str_1 = ';(.@y=u\x0btqoQ'
    str_2 = 'f7L/e{'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_0}
    list_0 = [dict_0, str_1, str_0, str_0]
    dict_1 = {}
    f_x_rate_0 = FXRate(*list_0, **dict_1)
    class Class0:
        def query(self, ccy1, ccy2, asof, strict):
            return f_x_rate_0

    f_x_rate_service_0 = Class0()

# Generated at 2022-06-26 00:56:12.843834
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # No cases to test
    pass


# Generated at 2022-06-26 00:56:15.347599
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ccy1 = ccy2 = asof = strict = None
    FXRateService.default.query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-26 00:56:52.627747
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'fU'
    str_1 = ']p'
    str_2 = 'W'
    str_3 = 'S%Z2'
    str_4 = '\x0b4'
    str_5 = '5'
    str_6 = '%'
    str_7 = ']z'
    str_8 = 'F24'
    str_9 = '\x7frU'
    str_10 = 'R'
    str_11 = '\x0b_s+'
    str_12 = '~\x0b'
    str_13 = '*\x0b'
    str_14 = '\x0b'
    str_15 = '\x0b'
    str_16 = '\x0b'

# Generated at 2022-06-26 00:56:54.567695
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    GenericForeignExchangeRateService = None
    GenericForeignExchangeRateService.query(None, None, None)


# Generated at 2022-06-26 00:57:06.193163
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    dict_0 = {'zf6G': {}}
    dict_1 = {'f': 'Zj'}
    dict_2 = {}
    str_0 = '{'
    str_1 = 'b'
    dict_0[str_1] = dict_1
    dict_1[str_0] = dict_2
    dict_2['n'] = True
    dict_2['}s'] = True
    dict_2['hEK'] = str_0
    dict_2['WPv'] = str_1
    dict_2['#N'] = dict_2
    dict_2['@'] = True
    dict_2[')'] = True
    dict_2['y'](dict_0['zf6G'])


# Generated at 2022-06-26 00:57:13.112774
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest.mock import MagicMock

    fx_rate_service_0 = FXRateService
    tquery_0 = (Currency, Currency, Date)
    bool_0 = False
    iterable_0 = fx_rate_service_0.queries(fx_rate_service_0, (tquery_0,), bool_0)
    fx_rate_service_1 = MagicMock()
    iterable_1 = fx_rate_service_0.queries(fx_rate_service_1, (tquery_0,), bool_0)


# Generated at 2022-06-26 00:57:14.464365
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:57:21.761109
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import CAD, CNY, EUR
    from .temporal import date

    # Create an FXRateService instance:
    rate_service = FXRateService()

    # Startup checks:
    assert rate_service.queries([]) == []
    assert rate_service.queries([(CAD, EUR, date(2019, 11, 30))]) == [None]
    assert rate_service.queries([(CAD, EUR, date(2019, 11, 30)), (EUR, CNY, date(2019, 12, 31))]) == [None, None]



# Generated at 2022-06-26 00:57:34.091319
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    forex = FXRate(Currency("EUR"), Currency("USD"), Date.today(), Decimal('1.1'))
    query = (Currency("USD"), Currency("EUR"), Date.today())
    queries = (query, query, query)

    class QueryService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return forex

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for q in queries:
                yield q, q, q

    service = QueryService()

    for q in queries:
        assert service.query(q[0], q[1], q[2]) == forex

# Generated at 2022-06-26 00:57:43.152113
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '9G'
    str_1 = ';(.@y=u\x0btqoQ'
    str_2 = 'f7L/e{'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_0}
    list_0 = [dict_0, str_1, str_0, str_0]
    dict_1 = {}
    f_x_rate_0 = FXRate(*list_0, **dict_1)
    f_x_rate_service_0 = FXRateService()
    # AssertionError: Optional[FXRate] expected, got NoneType
    # f_x_rate_service_0.query(f_x_rate_0, f_x_rate_0, f_x_rate_

# Generated at 2022-06-26 00:57:52.366273
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    print('Testing method query of class FXRateService...', end='')

    from pypara.convert import convert
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates.services import FixedFXRateService

    date_0 = Date.of(2020, 1, 6)
    date_1 = Date.of(2020, 1, 7)
    date_2 = Date.of(2020, 1, 8)

    ccy_0 = Currencies["EUR"]
    ccy_1 = Currencies["USD"]
    ccy_2 = Currencies["GBP"]


# Generated at 2022-06-26 00:58:01.698941
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    SVC = FXRateService

    # Test case 0
    # f_x_rate_0 = None
    # str_0 = 'C'
    # str_1 = '3'
    # str_2 = 'S'
    # str_3 = 't'
    # list_0 = [str_0, str_1, str_2, str_3]
    # dict_0 = {str_0: str_0, str_1: str_0, str_2: str_0, str_3: str_0}
    # iterable_0 = map(f_x_rate_0, list_0)
    # f_x_rate_1 = f_x_rate_0.__invert__()
    # iterable_1 = None
    # iterable_2 = filter(f_x_rate

# Generated at 2022-06-26 00:59:14.069063
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    dict_0 = {'3Nec:c%': 'F', '<8IGL': '^Q0xT*T', 'Q]': 'O&O', '*': '^Q0xT*T', '6[': '6[', '`o': '^Q0xT*T', 'd': '', '/2': '^Q0xT*T', 'I,': 'dfah'}
    tuple_0 = (dict_0['3Nec:c%'], 'P9_pFIA', dict_0['^Q0xT*T'], dict_0[dict_0['I,']])
    tuple_1 = (none, dict_0['/2'], 'hRwE', dict_0[dict_0['d']])

# Generated at 2022-06-26 00:59:25.124940
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date, asof
    from pypara.types import Temporal
    import random

    # Testing function queries of class FXRateService
    def test_function(fx_rate_service: FXRateService):
        queries = [(
            Currencies[random.choice(list(Currencies.keys()))],
            Currencies[random.choice(list(Currencies.keys()))],
            Date.fromdatetime(asof.datetime.today())
        ) for _ in range(10)]
        if fx_rate_service.queries(queries):
            return True
    class FXRateServiceSubclass0(FXRateService):
        def __init__(self):
            FXRateService.__init__(self)

# Generated at 2022-06-26 00:59:29.577840
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    srate = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert (urate == srate)


# Generated at 2022-06-26 00:59:32.736610
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # test_FXRateService_queries() - call with (FXRateService(), )
    # test_FXRateService_queries() - call with (None, )
    pass


# Generated at 2022-06-26 00:59:33.703295
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:59:41.374590
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import sys
    import random
    import math
    str_0 = 'wTZuV{'
    str_1 = '='
    str_2 = 'C9"^\x7f'
    str_3 = ',:G'
    str_4 = '\x0bvU.P'
    str_5 = '\x16^Qbz'
    str_6 = 'P\x01AH'
    str_7 = 'S\x15'
    str_8 = '^g'
    str_9 = '\x17'
    str_10 = 'L'
    str_11 = 'E2B`'
    str_12 = 'x'
    str_13 = '0JB5'
    str_14 = '\x1f'

# Generated at 2022-06-26 00:59:50.667013
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # arrange
    f_x_rate_0 = None
    f_x_rate_1 = None
    f_x_rate_2 = None
    f_x_rate_3 = None
    f_x_rate_service_0 = FXRateService()
    # act
    f_x_rate_0 = f_x_rate_service_0.query(71.268517, True, 71.472888, -1, 'b', 'o', -2.915434, '-\x0c', -1)
    f_x_rate_1 = f_x_rate_service_0.query('V', 'Splyb{7pU', 71.0, 1, '`', '}', -0.090555, 71.472888, 's')
    f_x_rate_2

# Generated at 2022-06-26 01:00:03.122861
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.dates import Date
    from pypara.services.stub import FXRateServiceStub

    service = FXRateServiceStub()

    usd_eur = service.query(Currencies["EUR"], Currencies["USD"], Date.today())
    assert usd_eur is not None
    assert usd_eur[3] == Decimal("1.1")

    eur_usd = service.query(Currencies["USD"], Currencies["EUR"], Date.today())
    assert eur_usd is not None
    assert eur_usd[3] == Decimal("0.91")

    usd_eur = service.query(Currencies["EUR"], Currencies["USD"], Date.today(), True)
    assert usd_eur is not None
   

# Generated at 2022-06-26 01:00:07.144610
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = None
    f_x_rate_service_0.queries(None, True)


if __name__ == '__main__':
    test_case_0()
    test_FXRateService_queries()

# Generated at 2022-06-26 01:00:15.626685
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '9G'
    str_1 = ';(.@y=u\x0btqoQ'
    str_2 = 'f7L/e{'
    dict_0 = {str_0: str_0, str_1: str_0, str_2: str_0}
    list_0 = [dict_0, str_1, str_0, str_0]
    dict_1 = {}
    f_x_rate_0 = FXRate(*list_0, **dict_1)
    str_3 = 'l1T(\\"V\\\';GJ'
    dict_2 = {}
    dict_3 = {'X9': 'E', str_3: 'E', str_2: 'E'}