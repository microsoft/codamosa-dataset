

# Generated at 2022-06-26 00:51:48.324567
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from copy import copy
    from unittest.mock import MagicMock
    from pypara.currencies import Currency
    service = FXRateService()
    original_queries = [('EUR', 'USD', '2019-01-01')]
    service.queries = MagicMock(side_effect=[copy(original_queries)])
    assert service.queries(original_queries) == [('EUR', 'USD', '2019-01-01')]


# Generated at 2022-06-26 00:51:58.299857
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .commons.zeitgeist import Temporal
    from .commons.numbers import ONE, TWO
    from .commons.temporal import Degenerate
    from .commons.sets import frozendict
    from .banking.currencies import FXRateService

    class FXRateServiceAllTest(unittest.TestCase):
        def setUp(self):
            self.ccy1 = Currencies["EUR"]
            self.ccy2 = Currencies["USD"]
            self.date = datetime.date.today()
            self.date = date = Temporal(self.date)
            self.date = date = Degenerate(self.date)
            self.rate = ONE
            self

# Generated at 2022-06-26 00:52:06.007969
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currency
    from pypara.finance.fx import FXRate, FXRateService
    from pypara.temporal import Date

    # Define the queries:
    queries = [
        (Currency("EUR"), Currency("USD"), Date(day=1, month=1, year=2017)),
        (Currency("USD"), Currency("EUR"), Date(day=2, month=2, year=2018)),
        (Currency("EUR"), Currency("USD"), Date(day=3, month=3, year=2019)),
        (Currency("USD"), Currency("EUR"), Date(day=4, month=4, year=2020)),
    ]

    # Define the FX rate service:
    f_x_rate_service_0 = FXRateService()

    # Invoke method queries for instance f

# Generated at 2022-06-26 00:52:14.667402
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    from pypara.rates.fx import FXRateService
    from pypara.zeitgeist import Date
    
    
    fx_rate_service = FXRateService()
    
    
    # Case 0 - Default case
    currency1 = Currency.of("USD")
    currency2 = Currency.of("EUR")
    date = Date.today()
    
    fx_rate = fx_rate_service.query(currency1, currency2, date)
    
    
    # Case 1 - Different currency
    currency1 = Currency.of("USD")
    currency2 = Currency.of("TRY")
    date = Date.today()
    
    fx_rate = fx_rate_service.query(currency1, currency2, date)
    
    
    # Case 2

# Generated at 2022-06-26 00:52:19.529389
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## Given a FXRateService instance
    f_x_rate_service_0: FXRateService = None
    ## When the method query of the FXRateService instance f_x_rate_service_0 is called with the parameters ccy1=Unknown(0), ccy2=Unknown(0), asof=Unknown(0), strict=True
    test_case_0_query(f_x_rate_service_0)
    ## Then the output should be None
    pass


# Generated at 2022-06-26 00:52:24.609777
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class Test(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import now
    assert Test().query(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], asof=now()) is None


# Generated at 2022-06-26 00:52:36.772270
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Setup
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.valuation import FXRateService

    # Setup
    f_x_rate_0 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    class f_x_rate_service_1(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            pass
        def queries(self, queries, strict = False):
            pass
    f_x_rate_service_1 = f_x_rate_service_1()

    # Exercise
    result = f_x_rate_service_1.queries(queries=tuple())

    # Verify:
    assert tuple() == result

# Generated at 2022-06-26 00:52:39.854712
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class FXRateServiceA(FXRateService):
        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    instance = FXRateServiceA()

    assert([r for r in instance.queries([], False)] == [])

# Generated at 2022-06-26 00:52:43.225715
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService
    :return:
    """
    print("Test method queries of class FXRateService")
    FXRateService().queries(queries = Tuple[Currency, Currency, Date])
    pass


# Generated at 2022-06-26 00:52:54.724985
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.commons.zeitgeist import Date, Temporal
    from pypara.currencies import Currency
    from pypara.services.fxrateservice import FXRateService

    queries = (
        (Currency("EUR"), Currency("USD"), Temporal("2019-12-31")),
        (Currency("USD"), Currency("EUR"), Temporal("2019-12-31")),
        (Currency("EUR"), Currency("USD"), Temporal("2019-10-31")),
    )
    f_x_rate_service = FXRateService()

    result_0 = f_x_rate_service.queries(queries) # noqa: F841


# Generated at 2022-06-26 00:53:10.070509
# Unit test for method query of class FXRateService

# Generated at 2022-06-26 00:53:19.694386
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\'Y'
    currency_type_0 = module_0.CurrencyType.FIAT
    decimal_0 = module_1.Decimal()
    int_0 = 2369
    str_1 = '~n'
    currency_0 = module_0.Currency(str_1, str_0, int_0, currency_type_0, decimal_0, int_0)
    str_2 = '1I\x0cW\x0c'
    currency_type_1 = module_0.CurrencyType.CRYPTO
    currency_1 = module_0.Currency(str_2, str_0, int_0, currency_type_1, decimal_0, int_0)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
   

# Generated at 2022-06-26 00:53:28.116572
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '|-#>!Q#'
    int_0 = 4423
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    str_1 = 'f'
    str_2 = 'n`R8W'
    currency_0 = module_0.Currency(str_1, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_3 = 'W2'
    str_4 = '0v'
    currency_1 = module_0.Currency(str_3, str_4, int_0, currency_type_0, decimal_0, int_0)
    str_5 = 'v<ZQP'
    str_6 = 't^KM'

# Generated at 2022-06-26 00:53:36.892349
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_type_0 = module_0.CurrencyType.CRYPTO
    currency_0 = module_0.Currency('N/5\x7f', '', 5696, currency_type_0, 4, 5696)
    decimal_0 = module_1.Decimal()
    date_0 = None
    f_x_rate_0 = FXRate(currency_0, currency_0, date_0, decimal_0)
    f_x_rate_1 = FXRate(currency_0, currency_0, date_0, decimal_0)
    f_x_rate_2 = FXRate(currency_0, currency_0, date_0, decimal_0)
    tuple_0 = (f_x_rate_2, f_x_rate_0, f_x_rate_1)
    f_x_

# Generated at 2022-06-26 00:53:45.364806
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'Iam'
    str_1 = '\x0cnhoG'
    int_0 = 2538
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    str_2 = '~*A'
    decimal_1 = module_1.Decimal()
    currency_0 = module_0.Currency(str_2, str_1, int_0, currency_type_0, decimal_1, int_0)
    decimal_2 = currency_0.quantize(decimal_0)
    currency_1 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_2, int_0)
    date_0 = None
    boolean_0 = True
   

# Generated at 2022-06-26 00:53:54.362758
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Setup mock service
    class MockService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return ccy1 * ccy2 * asof

        def queries(self, queries, strict=False):
            return [ccy1 * ccy2 * asof for (ccy1, ccy2, asof) in queries]

    # Setup query collection
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    date = Date.today()
    queries = [(ccy1, ccy2, date), (ccy2, ccy1, date)]

    # Test queries
    expected = [ccy1 * ccy2 * date, ccy2 * ccy1 * date]
    sut = MockService()

# Generated at 2022-06-26 00:54:00.209547
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = module_0.Currency.__new__(module_0.Currency)
    decimal_0 = module_1.Decimal()
    decimal_1 = decimal_0.quantize(decimal_0)
    currency_0.__init__('u5\x02PXED&{', '!', 8705, 0, decimal_1, 4637)
    currency_1 = module_0.Currency.__new__(module_0.Currency)
    currency_1.__init__('s%1', 'b+l6[', 3318, 0, decimal_0, 9162)
    date_0 = module_0.Temporal.__new__(module_0.Temporal)
    date_0.__init__(decimal_0)

# Generated at 2022-06-26 00:54:02.297354
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # FIXME implement this test to work with FXRateService
    # asserter = Asserter('fails')
    # assert_equals(asserter.expected, asserter.actual)
    pass


# Generated at 2022-06-26 00:54:12.140987
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'k$\x0b'
    str_1 = 'L'
    int_0 = 1620444423
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    str_2 = '%cQ~'
    decimal_1 = module_1.Decimal()
    currency_0 = module_0.Currency(str_2, str_0, int_0, currency_type_0, decimal_1, int_0)
    str_3 = '*Mx'
    str_4 = 'ZN\x0b'
    int_1 = -2044444423
    currency_type_1 = module_0.CurrencyType.CASH
    decimal_2 = module_1.Decimal()
   

# Generated at 2022-06-26 00:54:20.469294
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'C}-gN'
    str_1 = '/H0pU'
    int_0 = 1331
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = module_1.Decimal()
    str_2 = '-<\x0e'
    decimal_1 = module_1.Decimal()
    currency_0 = module_0.Currency(str_2, str_0, int_0, currency_type_0, decimal_1, int_0)
    decimal_2 = currency_0.quantize(decimal_0)
    decimal_3 = module_1.Decimal()
    decimal_4 = currency_0.quantize(decimal_3)
    str_3 = 'y'
    decimal_5 = module_1.Decimal

# Generated at 2022-06-26 00:54:29.683337
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:54:38.178195
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_type_1 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    decimal_1 = module_1.Decimal()
    decimal_2 = currency_0.quantize(decimal_0)
    currency_0 = module_0.Currency('Nn:H3V7>sg', '\<W7XDf', 1271, currency_type_1, decimal_1, 1271)
    date_0 = None
    f_x_rate_0 = FXRate(currency_0, currency_0, date_0, decimal_2)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = 'i*R'
    str_1 = 'n3m'

# Generated at 2022-06-26 00:54:48.157520
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class TestRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(1))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof)

    service = TestRateService()

    # Assert the lookup

# Generated at 2022-06-26 00:54:58.000065
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Implementation of user defined function 'query'
    # Raise exception if the foreign exchange rate is not found.
    str_3 = '4U'
    str_4 = 'e'
    str_5 = '!'
    int_1 = 2288
    currency_type_1 = module_0.CurrencyType.COMMODITY
    decimal_3 = module_1.Decimal()
    str_6 = '\x7f\x1c\x0a'
    decimal_4 = module_1.Decimal()
    currency_2 = module_0.Currency(str_6, str_5, int_1, currency_type_1, decimal_4, int_1)
    decimal_5 = currency_2.quantize(decimal_3)

# Generated at 2022-06-26 00:55:05.197899
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Get the class for the unit test
    target_class = get_class('FXRateService')

    # Create an instance
    fx_rate_service_instance = target_class()

    # Get the method
    queries_method = target_class.queries

    # Execute the method
    queries_method_output = queries_method(fx_rate_service_instance)

    # Assert that the method returned something
    assert (queries_method_output != None)


# Generated at 2022-06-26 00:55:16.029067
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # 1: Initialization
    # 1.1: Initialize currency members
    str_0 = '0l>+'
    str_1 = '\x1f'
    int_0 = 728
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    str_2 = 'YAa?\x1f,/'
    decimal_1 = module_1.Decimal()
    currency_0 = module_0.Currency(str_2, str_1, int_0, currency_type_0, decimal_1, int_0)
    str_3 = 'N,z\x1d'
    str_4 = '5'
    int_1 = 528
    currency_type_1 = module_0.CurrencyType.CR

# Generated at 2022-06-26 00:55:25.234153
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\x0b\x0b)'
    int_0 = -13
    currency_type_0 = module_0.CurrencyType.CRYPTO
    str_1 = '*U'
    str_2 = 'y9'
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_1, str_0, int_0, currency_type_0, decimal_0, int_0)
    currency_1 = module_0.Currency(str_2, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = datetime.date(1, 12, 12)
    decimal_1 = module_1.Decimal(12)
    f_x_rate_0 = FXRate.of

# Generated at 2022-06-26 00:55:30.399216
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService.default
    currency_0 = module_0.Currency.default
    temporal_0 = None
    currency_1 = module_0.Currency.default
    temporal_1 = None
    currency_2 = module_0.Currency.default
    temporal_2 = None
    tuple_0 = (temporal_0, currency_0, currency_1)
    tuple_1 = (temporal_1, currency_1, currency_2)
    tuple_2 = (temporal_2, currency_2, currency_0)
    list_0 = [tuple_0, tuple_1, tuple_2]
    str_0 = '<_F!=%c$'
    dict_0 = {str_0: str_0}
    f_x_rate_0

# Generated at 2022-06-26 00:55:33.879473
# Unit test for method query of class FXRateService

# Generated at 2022-06-26 00:55:40.664376
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_type_0 = FXRateService
    f_x_rate_service_0 = f_x_rate_service_type_0()
    t_query_0 = None
    iter_0 = []
    bool_0 = True
    f_x_rate_service_0.queries(iter_0, bool_0)
    iter_1 = [t_query_0]
    f_x_rate_service_0.queries(iter_1, bool_0)



# Generated at 2022-06-26 00:56:05.695170
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ccy1_0 = Currency(code='$', name='', digits=8, type=CurrencyType.CRYPTO, tick_size=8.396818444444445, rounding=0)
    ccy_0 = Currency(code='*', name='', digits=8, type=CurrencyType.CRYPTO, tick_size=8.396818444444445, rounding=0)
    date_0 = None
    obj_0 = FXRateService.default.query(ccy1_0, ccy_0, date_0)
    obj_1 = FXRateService.default.query(ccy1_0, ccy_0, date_0, strict=False)
    obj_2 = FXRateService.default.query(ccy1_0, ccy_0, date_0, strict=True)


# Generated at 2022-06-26 00:56:11.400531
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import typing
    f_x_rate_service_type_0 = typing.Optional[FXRateService]
    f_x_rate_service_0 = f_x_rate_service_type_0()
    f_x_rate_service_1 = FXRateService.default
    f_x_rate_service_2 = f_x_rate_service_1.queries(queries=f_x_rate_service_1.TQuery)


# Generated at 2022-06-26 00:56:18.042527
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    fx_rate_service_0 = FXRateService()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_2, int_0)
    currency_1 = module_0.Currency(str_2, str_1, int_0, currency_type_0, decimal_2, int_0)
    date_0 = None
    fx_rate_service_0.query(currency_0, currency_1, date_0, False)


# Generated at 2022-06-26 00:56:22.139610
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class SomeFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            return None
    some_f_x_rate_service_0 = SomeFXRateService()
    some_f_x_rate_service_0.query(None, None, None, None)


# Generated at 2022-06-26 00:56:25.469572
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = module_0.Currency()
    with pytest.raises(ValueError):
        FXRateService.query(currency_0, currency_0, currency_0)


# Generated at 2022-06-26 00:56:29.451106
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Note: constructor signature of class FXRateService is currently not implemented in runtimes other than CPython, so we can only create a dummy instance.
    f_x_rate_service_0 = FXRateService()
    list_0 = []
    f_x_rate_service_0.queries(list_0)


# Generated at 2022-06-26 00:56:38.842232
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Input parameters
    queries = [
        (module_0.Currency('HUF', 'HUF', 0, module_0.CurrencyType.LEGACY, module_1.Decimal(1), 0), module_0.Currency('HUF', 'HUF', 0, module_0.CurrencyType.LEGACY, module_1.Decimal(1), 0), None)
    ]

    # Expected result: FXRate instance

# Generated at 2022-06-26 00:56:48.317902
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'W8Qe%~'
    decimal_0 = module_1.Decimal()
    decimal_1 = decimal_0.__pow__(decimal_0)
    int_0 = 2
    currency_type_0 = module_0.CurrencyType.CRYPTO
    int_1 = 1
    currency_0 = module_0.Currency(str_0, str_0, int_1, currency_type_0, decimal_1, int_0)
    currency_1 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_1, int_0)
    int_2 = 3
    date_0 = module_0.Date(int_2)
    decimal_2 = module_1.Decimal()

# Generated at 2022-06-26 00:56:50.890547
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries = ()
    strict = False
    f_x_rate_service_0 = object
    f_x_rate_service_0.queries(queries, strict)


# Generated at 2022-06-26 00:56:53.992150
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = module_0.Currency
    decimal_0 = module_1.Decimal
    FXRate.of(currency_0, currency_0, None, decimal_0)


# Generated at 2022-06-26 00:57:32.781271
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_4 = '0lB'
    dict_1 = {str_4: str_4}
    f_x_rate_2 = FXRate(**dict_1)
    str_5 = '0lB'
    dict_2 = {str_5: str_5}
    f_x_rate_3 = FXRate(**dict_2)
    str_6 = '0lB'
    dict_3 = {str_6: str_6}
    f_x_rate_4 = FXRate(**dict_3)
    str_7 = '0lB'
    dict_4 = {str_7: str_7}
    f_x_rate_5 = FXRate(**dict_4)
    str_8 = '0lB'

# Generated at 2022-06-26 00:57:42.421137
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'k\x13\x7f.'
    int_0 = 0
    str_1 = 'k\x13\x7f.'
    dict_0 = {str_1: str_1}
    decimal_0 = module_1.Decimal()
    currency_type_0 = module_0.CurrencyType.CRYPTO
    str_2 = 'k\x13\x7f.'
    dict_1 = {str_2: str_2}
    currency_0 = module_0.Currency(**dict_1)
    currency_1 = module_0.Currency(**dict_1)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_1, currency_0, date_0)
    date_1 = None

# Generated at 2022-06-26 00:57:51.408511
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'GnWiD'
    int_0 = 1614
    currency_type_0 = module_0.CurrencyType.GENERIC
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_0)
    list_0 = [currency_0]
    tuple_0 = (currency_0,)
    list_1 = [list_0, tuple_0]
    list_2 = [dict_0, list_0]
    str_1 = ''
    list_3 = [str_1, currency_0]
    tuple_1 = (currency_0, currency_0)
    tuple_2 = (currency_0, str_1)
    list_4

# Generated at 2022-06-26 00:58:00.978850
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'B]z'
    str_1 = '2lBH'
    int_0 = -1
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'Jw3nq'
    currency_1 = module_0.Currency(str_2, str_2, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_1, currency_0, date_0)

# Generated at 2022-06-26 00:58:10.621440
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '8*2W\<fX'
    decimal_0 = module_1.Decimal()
    currency_type_0 = module_0.CurrencyType.CRYPTO
    int_0 = 2538
    str_1 = 'N'
    str_2 = 'P'
    currency_0 = module_0.Currency(str_2, str_1, int_0, currency_type_0, decimal_0, int_0)
    currency_1 = module_0.Currency(str_2, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_1, date_0)
    date_1 = None
   

# Generated at 2022-06-26 00:58:18.112701
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    int_0 = 8
    str_0 = '!_V'
    str_1 = 'c'
    str_2 = 'sA'
    int_1 = 3
    int_2 = 0
    int_3 = 1
    int_4 = 4
    f_x_rate_service_0 = FXRateService
    decimal_0 = f_x_rate_service_0.query(int_0, str_0, str_1, str_2, int_1, int_2, int_3, int_4)
    decimal_1 = module_1.Decimal()
    decimal_0.__mod__(decimal_1)


# Generated at 2022-06-26 00:58:28.410818
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pypara.currencies as module_0
    import decimal as module_1
    import pypara.fx.services as module_2
    import datetime as module_3

    str_0 = '1'
    str_1 = '<'
    int_0 = 2395
    currency_type_0 = module_0.CurrencyType.FIAT
    decimal_0 = module_1.Decimal()
    str_2 = 'fX0gT'
    decimal_1 = module_1.Decimal()
    currency_0 = module_0.Currency(str_2, str_0, int_0, currency_type_0, decimal_1, int_0)
    str_3 = '{][];<s.R&}'
    int_1 = 1612
    currency_type_1 = module

# Generated at 2022-06-26 00:58:33.455036
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries = ((Currency(name="Euro", code="EUR", decimals=2, type=CurrencyType.FIAT, tick_size=Decimal(0), point_value=1), Currency(name="Euro", code="EUR", decimals=2, type=CurrencyType.FIAT, tick_size=Decimal(0), point_value=1), Date(year=2020, month=11, day=24)),)
    strict = False
    queries = queries
    strict = strict
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(queries, strict)



# Generated at 2022-06-26 00:58:37.914771
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    tquery_0 = FXRateService.TQuery
    tuple_0 = (None, None, None)
    tquery_1 = tquery_0(tuple_0)
    f_x_rate_service_0 = FXRateService()
    list_0 = [tquery_0, ]
    f_x_rate_service_1 = f_x_rate_service_0.queries(list_0, False)

# Generated at 2022-06-26 00:58:42.303859
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    currency_0 = module_0.Currency.USD
    currency_1 = module_0.Currency.USD
    date_0 = None
    tuple_0 = (currency_1, currency_0, date_0)
    iterable_0 = [tuple_0]
    iterable_1 = f_x_rate_service_0.queries(iterable_0)

# Generated at 2022-06-26 01:00:04.045578
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_1 = '6U'
    str_2 = "0iQ|&Vy"
    decimal_0 = module_1.Decimal()
    decimal_1 = module_1.Decimal()
    currency_type_0 = module_0.CurrencyType.CRYPTO
    int_0 = 30
    currency_1 = module_0.Currency(str_1, str_2, int_0, currency_type_0, decimal_0, int_0)
    str_3 = 'c,N"Nn'
    str_4 = '$b'
    int_1 = 13
    currency_type_1 = module_0.CurrencyType.COMMODITY

# Generated at 2022-06-26 01:00:13.998681
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    module_2 = module_1
    str_4 = 'dCkF&w'
    str_5 = 'zt+S'
    int_1 = 2822
    currency_type_1 = module_0.CurrencyType.CRYPTO
    decimal_3 = module_2.Decimal()
    str_6 = '4%c'
    decimal_4 = module_2.Decimal()
    currency_2 = module_0.Currency(str_6, str_5, int_1, currency_type_1, decimal_4, int_1)
    str_7 = '|n\x7f,G'
    str_8 = 'h5\x7fP'
    int_2 = 3
    currency_type_2 = module_0.CurrencyType.CRYPTO
    decimal_5

# Generated at 2022-06-26 01:00:14.925554
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
	# TODO: Implement Unit test
	return


# Generated at 2022-06-26 01:00:18.256973
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries_0 = []
    f_x_rate_service_1 = FXRateService()
    f_x_rate_service_1.queries(queries_0)


# Generated at 2022-06-26 01:00:27.261711
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '3(0'
    tuple_0 = (str_0,)
    date_0 = None
    dict_0 = {str_0: date_0}
    decimal_0 = module_1.Decimal()
    str_1 = 'v)'
    int_0 = 7
    int_1 = 9
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_1 = module_1.Decimal()
    str_2 = '3(0'
    currency_0 = module_0.Currency(str_2, str_1, int_0, currency_type_0, decimal_1, int_1)
    decimal_2 = currency_0.quantize(decimal_0)

# Generated at 2022-06-26 01:00:37.318791
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'D:Q'
    str_1 = ';/'
    int_0 = 4970
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    list_0 = [currency_0]
    list_1 = [currency_0]
    tuple_0 = (currency_0, currency_0, date_0)
    tuple_1 = (currency_0, currency_0, date_0)
    list_2 = [tuple_1, tuple_0]
    f_x_rate_service_0 = FXRateService()


# Generated at 2022-06-26 01:00:43.845829
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    tuple_0 = (None, None, None)
    list_0 = [tuple_0]
    bool_0 = False
    try:
        f_x_rate_service_0.queries(list_0, bool_0)
        f_x_rate_service_0.queries(list_0)
    except LookupError as e_0:
        is_instance(e_0, Exception)
    except Exception as e_1:
        raise e_1
    except AssertionError as e_2:
        raise e_2


# Generated at 2022-06-26 01:00:47.948828
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import typing
    import pypara.commons.zeitgeist as zeitgeist
    import pypara.currencies as currencies
    import pypara.fxrates as fxrates

    #TODO: Implement this method.
    pass



# Generated at 2022-06-26 01:00:52.031095
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_0 = Currency("USD")
    currency_1 = Currency("EUR")
    date_0 = Date()
    bool_0 = True
    service_0 = FXRateService()
    f_x_rate_0 = service_0.query(currency_0, currency_1, date_0, bool_0)


# Generated at 2022-06-26 01:00:58.613020
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    date_0 = None
    decimal_0 = module_1.Decimal()
    currency_type_0 = module_0.CurrencyType.CRYPTO
    str_0 = 'iv'
    int_0 = 998
    decimal_1 = module_1.Decimal()
    str_1 = 'o(OdJY'
    currency_0 = module_0.Currency(str_1, str_0, int_0, currency_type_0, decimal_1, int_0)
    str_2 = '`u^,:'
    str_3 = 'G!m-L'
    int_1 = 6
    currency_1 = module_0.Currency(str_3, str_2, int_1, currency_type_0, decimal_0, int_0)
    f_x_rate