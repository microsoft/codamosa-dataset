

# Generated at 2022-06-26 00:51:53.508823
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # test_case_0
    f_x_rate_s_0 = FXRateService(None)
    f_x_rate_s_0.query(None, None, None, False)


# Generated at 2022-06-26 00:51:58.778225
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Set up arguments
    ccy1 = Currencies["USD"]
    ccy2 = Currencies["EUR"]
    asof = Date(1985, 10, 26)
    strict = True

    # Invoke method
    result = FXRateService.query(ccy1, ccy2, asof, strict)

    # Check result
    assert isinstance(result, Optional[FXRate] == True)


# Generated at 2022-06-26 00:51:59.621146
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:52:07.460397
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests for the method query of class FXRateService
    """
    # Unit test for method query of class FXRateService
    from pypara.currencies import Currency, Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.markets.fx import FXRate, FXRateService, FXRateLookupError
    from pypara.markets.fx.impls import EZBFXRateService

    # Case 0:
    #
    # Query a currency pair that the service provides FX rate for.
    #
    service_0 = EZBFXRateService()
    f_x_rate_0 = service_0.query(Currencies["EUR"], Currencies["USD"], Date.today(), strict=False)
    assert isinstance(f_x_rate_0, FXRate)
    assert f_

# Generated at 2022-06-26 00:52:16.318770
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Create an instance of class FXRateService
    self = FXRateService()

    # Get the number of method arguments
    arg_count = FXRateService.queries.__code__.co_argcount

    # Assert that the number of method arguments is two
    assert arg_count == 2

    # Get the method argument names
    arg_names = FXRateService.queries.__code__.co_varnames

    # Assert that the method argument names are queries and strict
    assert arg_names == ('self', 'queries', 'strict')

    # Get the method argument annotation values
    arg_annotation_values = FXRateService.queries.__annotations__.values()

    # Assert that the method argument annotation values are Iterable[Tuple], bool and Iterable[Optional[FXRate]]
    assert arg_annotation_

# Generated at 2022-06-26 00:52:17.179274
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:52:25.266628
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Create instance of class FXRateService
    class fx_rate_service(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return

        def queries(self, queries, strict=False):
            return

    f_x_rate_service_0 = fx_rate_service()

    # Invoke method queries of f_x_rate_service_0
    f_x_rate_service_0.queries(queriess=())

    # Invoke method queries of f_x_rate_service_0
    f_x_rate_service_0.queries(queriess=())

    # Invoke method queries of f_x_rate_service_0
    f_x_rate_service_0.queries(queriess=())


# Unit test

# Generated at 2022-06-26 00:52:25.829416
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

# Generated at 2022-06-26 00:52:26.776446
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    pass


# Generated at 2022-06-26 00:52:38.632779
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class FXRateService_0(FXRateService):
        def __init__(self,):
            self.queries = FXRateService.queries
        def query(self, ccy1, ccy2, asof, strict):
            return FXRate(ccy1, ccy2, asof, Decimal("1.1"))

    f_x_rate_service_0 = FXRateService_0()

    Currency_0 = Currency
    f_x_rate_3 = FXRate(Currency_0("USD"), Currency_0("EUR"), Date(1, 1, 1), Decimal("1")) # type: FXRate
    f_x_rate_4 = FXRate(Currency_0("USD"), Currency_0("EUR"), Date(2, 2, 2), Decimal("2")) # type: FXRate
    f_x

# Generated at 2022-06-26 00:52:49.951454
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # AssertionError: "abstract method queries"
    try:
        FXRateService().queries(None)
    except AssertionError:
        pass


# Generated at 2022-06-26 00:52:58.564853
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'pA&1z(.4m^]P'
    int_0 = -64
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = -565
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'Posting'
    int_2 = -514
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None
    bool_0 = True
    f_x_rate_service_0 = FXRateService()
    f_x_rate

# Generated at 2022-06-26 00:53:09.360173
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Setup of the unit test
    str_0 = 'zg:8'
    str_1 = 'S*Y1'
    int_0 = 9
    currency_type_0 = module_0.CurrencyType.MONEY
    int_1 = 7
    decimal_0 = module_1.Decimal()
    int_2 = 6
    int_3 = 2
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1, int_2, int_3)
    str_2 = 'hB5n)$'
    str_3 = 'D2@6Z-(F'
    int_4 = 7
    int_5 = 9
    int_6 = 0
    currency_1 = module_0.Currency

# Generated at 2022-06-26 00:53:18.713432
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'R!'
    int_0 = -6675
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = -50
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'zH'
    int_2 = 41
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_1)
    date_0 = None
    bool_0 = False

# Generated at 2022-06-26 00:53:27.278773
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '"*'
    int_0 = -985
    currency_2 = module_0.Currency(str_0, str_0, int_0, currency_0, decimal_0, int_0)
    int_1 = -2
    module_0.Currency(str_0, str_0, int_1, currency_1, decimal_0, int_0)
    date_0 = None
    decimal_0 = module_1.Decimal()
    f_x_rate_0 = FXRate(currency_2, currency_2, date_0, decimal_0)
    f_x_rate_service_0 = None
    bool_0 = f_x_rate_service_0.query(currency_2, currency_2, date_0, bool_0)
    module_0.Currency

# Generated at 2022-06-26 00:53:36.069503
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    fx_rate_service = FXRateService()
    str_0 = 'mQj}&'
    int_0 = -8
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = -3
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'U;'
    int_2 = 8
    currency_type_1 = module_0.CurrencyType.MONEY
    int_3 = 63
    currency_1 = module_0.Currency(str_1, str_1, int_2, currency_type_1, decimal_0, int_3)
    date_0 = None

# Generated at 2022-06-26 00:53:44.557488
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date(2019, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1), Decimal("1.15"))
            else:
                return None


# Generated at 2022-06-26 00:53:52.042238
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Prepare fx rate service
    fx_rate_service_0 = FXRateService()
    currency_0 = module_0.Currency()
    currency_1 = module_0.Currency()
    date_0 = None
    queries_0 = ( ( currency_0, currency_1, date_0 ), )
    strict_0 = True
    try:
        fx_rate_service_0.queries(queries_0, strict_0)
        raise RuntimeError('Assertion error expected!')
    except NotImplementedError:
        pass
    except:
        raise RuntimeError('Unexpected exception raised!')


# Generated at 2022-06-26 00:53:53.193107
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method FXRateService.queries.
    """
    pass


# Generated at 2022-06-26 00:53:59.388367
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
        str_0 = 'FxRates'
        int_0 = -159
        int_1 = 812
        currency_type_0 = module_0.CurrencyType.MONEY
        decimal_0 = module_1.Decimal()
        int_2 = -29
        currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
        currency_1 = module_0.Currency(str_0, str_0, int_1, currency_type_0, decimal_0, int_2)
        currency_2 = module_0.Currency(str_0, str_0, int_2, currency_type_0, decimal_0, int_0)

# Generated at 2022-06-26 00:54:18.256191
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest

    class FXRateService_queries_TestCase(unittest.TestCase):
        def runTest(self):
            return

        @staticmethod
        def test_FXRateService_queries_TestCase(self = None):
            f_x_rate_service_0 = module_0.FXRateService()
            int_0 = 1
            currency_2 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
            int_1 = 2
            currency_3 = module_0.Currency(str_0, str_0, int_1, currency_type_0, decimal_0, int_1)

# Generated at 2022-06-26 00:54:22.077091
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    decimal_0 = module_1.Decimal()
    f_x_rate_0 = FXRate.of(';O{f?b%5.o55', 'Posting', 30, decimal_0)
    f_x_rate_1 = FXRateService.queries(decimal_0)


# Generated at 2022-06-26 00:54:31.974261
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ';O{f?b%5.o55'
    int_0 = 4
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = 30
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'Posting'
    int_2 = -514
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_1, date_0)

# Generated at 2022-06-26 00:54:33.166790
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Code for method queries of class FXRateService
    pass



# Generated at 2022-06-26 00:54:41.334569
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import collections
    import datetime
    import enum
    import typing
    import pypara
    import pypara.commons.collections
    import pypara.commons.zeitgeist
    import pypara.currencies
    import pypara.finance.currencies
    import pypara.finance.periods
    import pypara.finance.fx
    pypara.logging.set_log_level("DEBUG")

# Generated at 2022-06-26 00:54:52.828589
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import datetime
    import decimal as module_1
    import pypara.fx as module_2
    decimal_0 = module_1.Decimal()
    decimal_1 = module_1.Decimal()
    decimal_2 = module_1.Decimal()
    decimal_3 = module_1.Decimal()
    decimal_4 = module_1.Decimal()
    decimal_5 = module_1.Decimal()
    currency_0 = module_0.Currency('XXX', 'XXX', -2, module_0.CurrencyType.MONEY, decimal_0, 0)
    currency_1 = module_0.Currency('XXX', 'XXX', -2, module_0.CurrencyType.MONEY, decimal_1, 0)
    currency_2 = module_

# Generated at 2022-06-26 00:55:00.347472
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_0 = FXRate(module_0.Currencies['RON'], module_0.Currencies['RON'], datetime.date.today(), Decimal('1.0'))
    f_x_rate_1 = FXRate(module_0.Currencies['RON'], module_0.Currencies['USD'], datetime.date.today(), Decimal('0.23564'))
    f_x_rate_2 = FXRate(module_0.Currencies['USD'], module_0.Currencies['RON'], datetime.date.today(), Decimal('4.2323'))
    f_x_rate_3 = FXRate(module_0.Currencies['EUR'], module_0.Currencies['USD'], datetime.date.today(), Decimal('1.12312'))
    f_

# Generated at 2022-06-26 00:55:04.406276
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Arrange
    queries = ([])
    fx_rate_service_0 = FXRateService
    # Act
    iterable_0 = fx_rate_service_0.queries(queries)
    # Assert
    assert iterable_0 == ([])


# Generated at 2022-06-26 00:55:14.992452
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ';O{f?b%5.o55'
    int_0 = 4
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = 30
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'Posting'
    int_2 = -514
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_1, date_0)

# Generated at 2022-06-26 00:55:24.444649
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import unittest
    
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.fx.rates import FXRateService
    from pypara.localization import Locale
    
    class FXRateServiceTest(unittest.TestCase):
    
        class TestRateService(FXRateService):
    
            def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
    
                if ccy1 == Currencies["USD"] and ccy2 == Currencies["TRY"]:
                    return FXRate(Currencies["USD"], Currencies["TRY"], date(2020, 3, 13), Decimal("6.9604"))
    

# Generated at 2022-06-26 00:55:49.303049
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## FX rate resolutions:

# Generated at 2022-06-26 00:55:53.675340
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import datetime as module_1
    import decimal as module_2
    str_0 = 'OiY5ZzCPI'
    int_0 = -49
    currency_type_0 = module_0.CurrencyType.CREDIT
    decimal_0 = module_2.Decimal()
    int_1 = -37
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = '""mx):}"'
    int_2 = 92
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    str_2 = 'FXRate'

# Generated at 2022-06-26 00:56:03.823330
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import datetime as module_1
    import decimal as module_2
    int_0 = 17
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_2.Decimal()
    int_1 = -1
    currency_0 = module_0.Currency('!2', 'Ó', int_0, currency_type_0, decimal_0, int_1)
    str_0 = ','
    int_2 = -1
    currency_1 = module_0.Currency('', '', int_2, currency_type_0, decimal_0, int_2)
    date_0 = None

# Generated at 2022-06-26 00:56:06.161009
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    handler_0 = FXRateService()
    with raises(NotImplementedError):
        handler_0.query(None, None, None)


# Generated at 2022-06-26 00:56:15.836548
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    str_2 = '~fg)-eC(tfx'
    str_3 = 'FXRateService'
    int_3 = 1
    currency_type_1 = module_0.CurrencyType.PURCHASING_POWER
    decimal_1 = module_1.Decimal('-0.0443')
    int_4 = -119
    currency_2 = module_0.Currency(str_2, str_3, int_3, currency_type_1, decimal_1, int_4)
    currency_3 = module_0.Currency(str_3, str_3, int_3, currency_type_1, decimal_1, int_3)
    date_1 = None
    bool_0 = False
    f_x_rate

# Generated at 2022-06-26 00:56:23.493334
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    curr_0 = Currency("EUR", "Euro", 978, CurrencyType.MONEY, Decimal("1.95583"), 2)
    curr_1 = Currency("USD", "US Dollar", 840, CurrencyType.MONEY, Decimal("1.95583"), 2)
    date_0 = Date(2017, 1, 1)
    rate = FXRate(curr_0, curr_1, date_0, Decimal("1.1"))
    fx_rate_service_0 = FXRateService()
    assert fx_rate_service_0.query(curr_0, curr_1, date_0, strict=False) is None


# Generated at 2022-06-26 00:56:32.756645
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    int_0 = -27
    date_0 = None
    decimal_0 = module_1.Decimal()
    int_1 = -15
    currency_type_0 = module_0.CurrencyType.MONEY
    currency_0 = module_0.Currency(str(int_0), str(int_0), int_1, currency_type_0, decimal_0, int_1)
    str_0 = '2b5C!8d?5'
    int_2 = 2
    currency_1 = module_0.Currency(str_0, str_0, int_2, currency_type_0, decimal_0, int_2)
    f_x_rate_0 = FXRate(currency_0, currency_1, date_0, decimal_0)

# Generated at 2022-06-26 00:56:35.650886
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Generate the code for the test case:
    service_0 = None
    queries_0 = ()
    strict_0 = True
    queries(service_0, queries_0, strict_0)

# Generated at 2022-06-26 00:56:45.376021
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ';O{f?b%5.o55'
    int_0 = 4
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = 26
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'Posting'
    int_2 = -514
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None
    date_1 = None

# Generated at 2022-06-26 00:56:54.661619
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'O{f?b%5.o55'
    int_0 = 4
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = 30
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'Posting'
    int_2 = -514
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None
    bool_0 = False
    f_x_rate_service_0 = None

# Generated at 2022-06-26 00:57:35.804045
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    int_0 = -4
    str_0 = '5YWL$'
    str_1 = 'v=F]<W#'
    decimal_0 = module_1.Decimal()
    currency_type_0 = module_0.CurrencyType.MONEY
    int_1 = -3
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = 'aM+J'
    int_2 = -4
    currency_1 = module_0.Currency(str_0, str_2, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None
    f_x_rate_service_0 = None
    bool_0 = False

# Generated at 2022-06-26 00:57:41.049208
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: Add unit tests.
    pass


# Generated at 2022-06-26 00:57:49.957209
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'FQ{Z?}4Lq>'
    str_1 = '+'
    int_0 = -926
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = -12
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    str_2 = '--'
    int_2 = -926
    currency_1 = module_0.Currency(str_0, str_2, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None

# Generated at 2022-06-26 00:57:50.788797
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # TODO: Fix test
    pass


# Generated at 2022-06-26 00:57:54.286913
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    service = FXRateService()
    with pytest.raises(NotImplementedError):
        service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-26 00:58:03.719762
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '2'
    int_0 = -265
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_1 = module_1.Decimal()
    int_1 = -1
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_1, int_1)
    str_1 = 'z]n16\u00172_$'
    int_2 = -2
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_1, int_2)
    decimal_0 = module_1.Decimal()
    date_0 = None

# Generated at 2022-06-26 00:58:07.385957
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'FXRateService.query() test'
    print_0 = print(str_0)
    f_x_rate_service_0 = FXRateService()


# Generated at 2022-06-26 00:58:15.695408
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\-\x14\x08\x1f:OQ\x05\x05j\x16\x0c'
    decimal_0 = module_1.Decimal('-0.011748118041577536')
    int_0 = -5
    currency_type_0 = module_0.CurrencyType.MONEY
    int_1 = 10
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = '\x7f\x04t\x7f9\x1e\x7fL\x0f\x16\x17,\x7f'
    decimal_1 = module_1.Decimal('-1.2')
    int_

# Generated at 2022-06-26 00:58:25.674001
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '>G`y'
    int_0 = 4
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = 30
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'Posting'
    int_2 = -514
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None
    f_x_rate_service_0 = None
    f_x_rate_service_0.query(currency_0, currency_1, date_0)


# Generated at 2022-06-26 00:58:29.492733
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries_0 = []
    strict_0 = False
    instance_0 = FXRateService()
    FXRateService.queries(instance_0, queries_0, strict_0)

import pypara.currencies as module_0
import decimal as module_1


# Generated at 2022-06-26 00:59:51.573830
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = './St^C&h~|Zu'
    int_0 = -9
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = -97
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = ':F6[.L|&/B*{X'
    int_2 = 64
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    str_2 = 'j(dL'
    int_3 = -56
    currency_type_1 = module_

# Generated at 2022-06-26 01:00:03.493819
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'h%'
    int_0 = -493460050
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = 0
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = '!+uk;N'
    int_2 = -63
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_1)
    date_0 = None
    int_3 = 0

# Generated at 2022-06-26 01:00:13.743697
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.exchanges import FXRateService
    class TestFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            ## Keep the rates:
            self._rates = rates
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            ## Find the rate:
            rate = next((rate for rate in self._rates if rate[0] == ccy1 and rate[1] == ccy2 and rate[2] == asof), None)

            ## If no rate is found, raise an error if needed:
            if rate is None and strict:
                raise FXRateLookupError

# Generated at 2022-06-26 01:00:23.870331
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '&szc%56l'
    int_0 = -21
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = -24
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'Posting'
    int_2 = -514
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_1, date_0)
   

# Generated at 2022-06-26 01:00:32.732646
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Default arguments
    decimal_0 = module_1.Decimal()
    date_0 = None
    f_x_rate_0 = FXRate.of(currency_0, currency_1, date_0, decimal_0)
    decimal_1 = module_1.Decimal()
    date_1 = None
    f_x_rate_1 = FXRate.of(currency_0, currency_1, date_1, decimal_1)
    f_x_rate_service_0 = FXRateService()
    result = f_x_rate_service_0.query(currency_0, currency_1, date_0)
    assert f_x_rate_0 == result
    assert f_x_rate_1 != result
    assert f_x_rate_0 != f_x_rate_1


# Generated at 2022-06-26 01:00:35.882517
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test the public method queries of class FXRateService.
    """
    raise NotImplementedError


# Generated at 2022-06-26 01:00:41.391265
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    try:
        TQuery = Tuple[Currency, Currency, Date]
    except ValueError as e:
        print("ValueError:")
        print(str(e))
    except NameError as e:
        print("NameError:")
        print(str(e))
    except TypeError as e:
        print("TypeError:")
        print(str(e))
    except AttributeError as e:
        print("AttributeError:")
        print(str(e))


# Generated at 2022-06-26 01:00:51.820592
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    int_0 = 25
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = 11
    currency_0 = module_0.Currency('$tEf;gK]_S{QZ#', '@<u|P', int_0, currency_type_0, decimal_0, int_1)
    str_0 = '!'
    int_2 = -213
    currency_1 = module_0.Currency(str_0, 'o`jUK*<', int_2, currency_type_0, decimal_0, int_2)
    str_1 = 'Invoice'
    int_3 = -35

# Generated at 2022-06-26 01:00:58.512381
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Test for method query of class FXRateService
    str_0 = ';O{f?b%5.o55'
    int_0 = 4
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = 30
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'Posting'
    int_2 = -514
    currency_1 = module_0.Currency(str_0, str_1, int_2, currency_type_0, decimal_0, int_2)
    date_0 = None
    decimal_1 = module_1.Decimal('-2.4824')
   

# Generated at 2022-06-26 01:01:05.623727
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = '*'
    int_0 = 1
    currency_type_0 = module_0.CurrencyType.MONEY
    decimal_0 = module_1.Decimal()
    int_1 = -1
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_1)
    str_1 = 'Y*t0}z5A'
    decimal_1 = module_1.Decimal()
    currency_1 = module_0.Currency(str_1, str_1, int_1, currency_type_0, decimal_1, int_0)
    int_2 = 0
    decimal_2 = module_1.Decimal()