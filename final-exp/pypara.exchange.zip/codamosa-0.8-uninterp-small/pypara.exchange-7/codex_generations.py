

# Generated at 2022-06-26 00:51:56.605574
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .zeitgeist import Date
    tmp = FXRateService()
    tmp.queries([
        (Currency.of("TRY"), Currency.of("TRY"), Date(2019, 1, 1)),
        (Currency.of("USD"), Currency.of("EUR"), Date(2019, 1, 1)),
        (Currency.of("USD"), Currency.of("USD"), Date(2019, 1, 1))])
    # 3rd arg to the queries method, strict, may be omitted (it is 'false' by default)


# Generated at 2022-06-26 00:52:03.484771
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.commons.temporality import Date
    from pypara.currencies import Currency
    from pypara.fxrates import FXRate
    from pypara.fxrates.services import FXRateService

    f_x_rate_service_0 = FXRateService()
    ## Invalid queries:
    queries = [
        (1, 2, Date.now())
    ]

    ## Run the test:
    for query in queries:
        try:
            f_x_rate_service_0.queries(queries)
        except Exception as e:
            assert isinstance(e, TypeError)
        else:
            raise RuntimeError("Unable to reproduce expected behaviour.")


# Generated at 2022-06-26 00:52:12.261862
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx_rate_services import FXRateService
    from pypara.fx_rates import FXRate
    from pypara.zeitgeists import Today

    # Given an FX rate service
    fx_rate_service = FXRateService()

    # Then it can be queried for EUR/USD FX rate as of today
    euro = Currencies['EUR']
    usd = Currencies['USD']
    usd_euro_rate = Decimal('1.10')
    fx_rate = FXRate(euro, usd, Today(), usd_euro_rate)

    fx_rate_service.query(euro, usd, Today()) == fx_rate
    fx_rate_service.query

# Generated at 2022-06-26 00:52:17.369882
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    f_x_rate_service_0 = FXRateService()
    f_x_rate_0 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert f_x_rate_service_0.queries([(Currencies["EUR"], Currencies["USD"], datetime.date.today())]) == [Optional[FXRate]]


# Generated at 2022-06-26 00:52:19.846296
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    queries = [("EUR/USD", "2005/Jan/01")]
    f_x_rate_service_0.queries(queries, False)


# Generated at 2022-06-26 00:52:32.274266
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    import datetime
    from decimal import Decimal

    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.default = f_x_rate_service_0

    f_x_rate_0 = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    f_x_rate_1 = FXRate.of(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    results = list(f_x_rate_service_0.queries())
    assert results == []

    results = list(f_x_rate_service_0.queries([(None, None, None)]))

# Generated at 2022-06-26 00:52:36.042283
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    assert f_x_rate_service_0.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), True) == FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1"))


# Generated at 2022-06-26 00:52:36.742059
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    test_case_0()


# Generated at 2022-06-26 00:52:42.366292
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .fx import FXRateService
    from .temporal import REFERENCE
    from datetime import date
    from decimal import Decimal
    from collections import namedtuple
    class MockRateService(FXRateService):
        FXRate = namedtuple("FXRate", ["ccy1", "ccy2", "date", "value"])

        def query(self, ccy1: Currency, ccy2: Currency, asof: date) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                if asof == date(2017, 10, 24):
                    return self.FXRate(ccy1, ccy2, asof, Decimal("0.876"))

# Generated at 2022-06-26 00:52:54.701109
# Unit test for method query of class FXRateService

# Generated at 2022-06-26 00:53:06.550792
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    F_X_RATE_SERVICE_0 = FXRateService()
    assert F_X_RATE_SERVICE_0.query(Currency.of('EUR'), Currency.of('EUR'), Date.of('2019-11-18')) == None


# Generated at 2022-06-26 00:53:15.613656
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Setup test
    f_x_rate_service_0 = FXRateService()

    # Invoke operation
    f_x_rate_0 = f_x_rate_service_0.query(ccy1=Currency("USD"), ccy2=Currency("EUR"), asof=Date("2019-01-01"))

    # Verify outcome
    assert f_x_rate_0 is not None
    assert f_x_rate_0.ccy1 == Currency("USD")
    assert f_x_rate_0.ccy2 == Currency("EUR")
    assert f_x_rate_0.date == Date("2019-01-01")
    assert f_x_rate_0.value == Decimal("0.6153312")



# Generated at 2022-06-26 00:53:19.727755
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    currency1 = Currency.of('EUR')
    currency2 = Currency.of('USD')
    date = Date(2001, 1, 1)
    result = f_x_rate_service_0.query(currency1, currency2, date, False)
    expected = None
    assert result == expected


# Generated at 2022-06-26 00:53:23.860957
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # define the expected output
    expected_output = None
    # call the method
    actual_output = f_x_rate_service_0.queries(queries=(), strict=False)
    # check the output against the expected
    assert expected_output == actual_output, "Expected {}, but got {}".format(expected_output, actual_output)


# Generated at 2022-06-26 00:53:32.248328
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ## Define a foreign exchange rate service stub for testing:
    class FXRateServiceStub(FXRateService):
        def __init__(self):
            super().__init__()

# Generated at 2022-06-26 00:53:35.915371
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # Create mock object
    f_x_rate_service_1 = FXRateService()
    # Call method query of f_x_rate_service_1
    assert f_x_rate_service_1.query(None, None, None) is None


# Generated at 2022-06-26 00:53:39.595862
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    ccy1_0 = Currency()
    ccy2_0 = Currency()
    temporal_0 = Date.today()
    assert f_x_rate_service_0.query(ccy1_0, ccy2_0, temporal_0) == None


# Generated at 2022-06-26 00:53:44.312173
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Initialize
    f_x_rate_service_0 = FXRateService()
    ccy1 = Currency("EUR")
    ccy2 = Currency("EUR")
    asof = Date("today")
    strict = True

    # Invoke method
    f_x_rate_0 = f_x_rate_service_0.query(ccy1, ccy2, asof, strict)



# Generated at 2022-06-26 00:53:45.105628
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:53:54.086332
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    _context_0 = {'__name__': '__main__'}
    import datetime as __datetime_0
    import pypara as __pypara_0
    import sys as __sys_0
    f_x_rate_service_0 = __pypara_0.FXRateService()
    f_x_rate_service_1 = type(f_x_rate_service_0)
    f_x_rate_service_2 = f_x_rate_service_0.queries
    f_x_rate_service_3 = (__datetime_0.date(2020, 1, 8), __pypara_0.Currencies["EUR"], __pypara_0.Currencies["USD"])
    f_x_rate_service_4 = [f_x_rate_service_3]


# Generated at 2022-06-26 00:54:05.519323
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 00:54:14.935556
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    arg_0 = []
    arg_1 = True
    f_x_rate_service_0 = FXRateService()
    function_0 = module_0.Currency
    str_0 = 'p'
    str_1 = 'e'
    int_0 = 0
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = Decimal('0')
    int_1 = 0
    currency_0 = function_0(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    function_1 = module_0.Currency
    str_2 = 't'
    str_3 = 'r'
    int_2 = 0
    currency_type_1 = module_0.CurrencyType.METAL

# Generated at 2022-06-26 00:54:17.421218
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    result = FXRateService.query(FXRateService)
    if result != None:
        print("FXRateService.query() did not return the expected results.")


# Generated at 2022-06-26 00:54:25.939753
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    error_msg = "Wrong number of outputs"
    assert len(f_x_rate_service_0.queries(queries=tuple(), strict=False)) == 0
    error_msg = "Wrong number of outputs"
    assert len(f_x_rate_service_0.queries(queries=tuple(), strict=True)) == 0
    error_msg = "Wrong number of outputs"
    assert len(f_x_rate_service_0.queries(queries=tuple(), strict=False)) == 0
    error_msg = "Wrong number of outputs"
    assert len(f_x_rate_service_0.queries(queries=tuple(), strict=True)) == 0


# Generated at 2022-06-26 00:54:35.356099
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    query = (1, 2, 3)
    strict = True

    # Method query has been tested in unit test for method query of class FXRateService
    result = FXRateService.query(FXRateService, query)

    # Check if query(query) raise expected error for an invalid logical input
    try:
        pass
    except Exception as e:
        pass    
    
    # Check if FXRateService.query(query) return the expected value for a valid logical input
    assert result

    # Method queries has been tested in unit test for method query of class FXRateService
    result = FXRateService.queries(FXRateService, query, strict)

    # Check if queries(query, strict) raise expected error for an invalid logical input
    try:
        pass
    except Exception as e:
        pass    
    
    # Check if FXRateService.

# Generated at 2022-06-26 00:54:36.645411
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    try:
        raise Exception
    except:
        pass


# Generated at 2022-06-26 00:54:45.155815
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'y'
    str_1 = 'zg'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.FIAT
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    currency_1 = currency_0
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_1, date_0)
    f_x_rate_service_0 = FXRateService()
    optinal_0 = f_x_rate_service_0.query(currency_0, currency_1, date_0, True)
    assert optinal_0 is None

#

# Generated at 2022-06-26 00:54:56.054936
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()
    t_query_0 = None
    f_x_rate_service_0.queries(t_query_0)


# Generated at 2022-06-26 00:55:07.255888
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.commons.temporal import Temporal
    from pypara.markets.fx import FXRateService, FXRateLookupError
    from pypara.currencies import Currency
    from datetime import date
    from io import StringIO
    from decimal import Decimal


# Generated at 2022-06-26 00:55:16.028848
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(currency_0, currency_0, date_0, True)


# Generated at 2022-06-26 00:55:39.003376
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '='
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(currency_0, currency_0, date_0, f_x_rate_lookup_error_0)


# Generated at 2022-06-26 00:55:48.708777
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries([(currency_0, currency_0, date_0)], True)


# Generated at 2022-06-26 00:55:49.765691
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # TODO: implement this test
    assert True


# Generated at 2022-06-26 00:55:57.859415
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = Currency('USD', 'Dollar', 2)
    currency_1 = Currency('EUR', 'Euro', 2)
    currency_2 = Currency('GBP', 'Pound', 2)
    asof = Date.today()
    queries = [(currency_0, currency_1, asof), (currency_2, currency_0, asof)]
    iterator_0 = FXRateService().queries(queries)
    list_0 = next(iterator_0)
    list_1 = next(iterator_0)


# Generated at 2022-06-26 00:56:06.990763
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()
    ccy1 = module_0.Currency("st$", "x", None, module_0.CurrencyType.METAL, None, None)
   

# Generated at 2022-06-26 00:56:12.165162
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currency

    fxrateservice_0 = FXRateService()
    iterable_0 = (('t', 'x', None),)
    bool_0 = True
    try:
        fxrateservice_0.queries(iterable_0, strict=bool_0)
    except FXRateLookupError:
        pass


# Generated at 2022-06-26 00:56:14.837315
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    method_under_test = module_0.FXRateService.__abstractmethods__["query"]
    assert(method_under_test is not None)


# Generated at 2022-06-26 00:56:24.597893
# Unit test for method query of class FXRateService

# Generated at 2022-06-26 00:56:31.383447
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'r$'
    str_1 = 'a'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.UPPERCASE_LETTER
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(currency_0, currency_0, date_0, False)


# Generated at 2022-06-26 00:56:38.965682
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    optional_decimal_0 = f_x_rate_service_0.query(currency_0, currency_0, date_0, True)


# Generated at 2022-06-26 00:57:12.437957
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'f$'
    int_0 = 1
    currency_type_0 = module_0.CurrencyType.CRYPTO
    int_1 = 1
    currency_0 = module_0.Currency(str_0, 'h9', int_0, currency_type_0, int_1, int_0)
    date_0 = None
    f_x_rate_service_0 = FXRateService()


# Generated at 2022-06-26 00:57:22.653365
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '#'
    str_1 = 'r'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = '='
    str_3 = '-.'
    int_1 = None
    currency_type_1 = module_0.CurrencyType.METAL
    decimal_1 = None
    currency_1 = module_0.Currency(str_2, str_3, int_1, currency_type_1, decimal_1, int_1)
    date_0 = None
    strict_0 = None
    f_x_rate_service

# Generated at 2022-06-26 00:57:35.181576
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    int_1 = None
    str_0 = 'st$'
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_0 = FXRate(currency_0, currency_0, date_0, decimal_0)
    f_x_rate_service_1 = FXRateService()
    f_x_rate_service_1.query(currency_0, currency_0, date_0, False)

# Generated at 2022-06-26 00:57:43.687207
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Testing with:
    #           queries = ( Iterable[TQuery], strict = False )
    #   Expecting:
    #           Iterable[Optional[FXRate]]

    str_0 = 'jN.X'
    str_1 = '@<'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = '7osU'
    str_3 = 'Y'
    int_1 = None
    currency_type_1 = module_0.CurrencyType.METAL
    decimal_1 = None
    currency_1 = module_0.Currency

# Generated at 2022-06-26 00:57:52.609698
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    tuple_0 = (currency_0, currency_0, date_0)
    list_0 = [tuple_0]
    iterator_0 = list_0.__iter__()
    iterator_0.__next__()
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 00:58:00.364310
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'QA'
    str_1 = 'GsQt'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_0, date_0)


# Generated at 2022-06-26 00:58:04.000502
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    queries_0 = []
    strict_0 = False
    try:
        result_0 = f_x_rate_service_0.queries(queries_0, strict_0)
    except:
        pass


# Generated at 2022-06-26 00:58:13.485756
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'd'
    str_1 = "%"
    int_1 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_1, currency_type_0, decimal_0, int_1)
    currency_1 = module_0.Currency(str_1, str_1, int_1, currency_type_0, decimal_0, int_1)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_1 = FXRateService()
    f_x_rate_service_2 = FXRateService()
    fx_rate_service_query_0 = f_x_rate

# Generated at 2022-06-26 00:58:22.509716
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(currency_0, currency_0, date_0)


# Generated at 2022-06-26 00:58:31.331989
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 've$'
    str_1 = 'j'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    str_2 = 'uR'
    decimal_1 = None
    currency_1 = module_0.Currency(str_2, str_0, int_0, currency_type_0, decimal_0, int_0)
    f_x_rate_0 = FXRate(currency_0, currency_1, date_0, decimal_1)
    f_x_rate_service_0 = FXRateService()
   

# Generated at 2022-06-26 00:59:50.924735
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_lookup_error_0 = FXRateLookupError(currency_0, currency_0, date_0)
    date_1 = None
    f_x_rate_service_0 = FXRateService()

    with raises(TypeError):
        f_x_rate_service_0.query(currency_0, currency_0, date_0, True, f_x_rate_service_0)


# Generated at 2022-06-26 00:59:57.336012
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    queries_0 = tuple()
    strict_0 = None
    try:
        f_x_rate_service_0.queries(queries_0, strict_0)
    except NotImplementedError:
        pass


# Generated at 2022-06-26 01:00:03.652815
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    decimal_0 = Decimal('0')
    decimal_1 = Decimal('1')
    decimal_2 = Decimal('2')
    date_0 = Date(2018, 1, 1)
    date_1 = Date(2018, 1, 2)
    date_2 = Date(2018, 1, 3)
    date_3 = Date(2018, 1, 4)
    date_4 = Date(2018, 1, 5)


# Generated at 2022-06-26 01:00:11.824947
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    f_x_rate_service_0 = FXRateService()
    optional_0 = f_x_rate_service_0.query(currency_0, currency_0, date_0)


# Generated at 2022-06-26 01:00:13.963819
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries_0 = None
    strict_0 = None
    assert f_x_rate_service_0.queries(queries_0, strict_0) is not None


# Generated at 2022-06-26 01:00:16.728633
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries_0 = None
    strict_0 = None
    iterable_0 = FXRateService.queries(queries_0, strict_0)


# Generated at 2022-06-26 01:00:18.335742
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 01:00:27.297503
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'i'
    str_1 = 'SXz'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = -0.13270193042086923
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    str_2 = 'Mh(0'
    str_3 = '~'
    int_1 = None
    currency_type_1 = module_0.CurrencyType.METAL
    decimal_1 = None
    currency_1 = module_0.Currency(str_2, str_3, int_1, currency_type_1, decimal_1, int_1)
    date_0 = None


# Generated at 2022-06-26 01:00:37.316120
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'st$'
    str_1 = 'x'
    int_0 = None
    currency_type_0 = module_0.CurrencyType.METAL
    decimal_0 = None
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    date_0 = None
    ccy1_0 = currency_0
    ccy2_0 = currency_0
    asof_0 = date_0
    strict_0 = False
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 01:00:42.280989
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries_0 = ((module_0.Currency('', '', None, module_0.CurrencyType.METAL, None, None), module_0.Currency('', '', None, module_0.CurrencyType.METAL, None, None), None))
    strict_0 = False
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(queries_0, strict_0)
