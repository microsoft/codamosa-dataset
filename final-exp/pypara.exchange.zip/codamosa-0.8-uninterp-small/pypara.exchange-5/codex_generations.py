

# Generated at 2022-06-26 00:51:53.830011
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    fx_query_0 = (Currencies["USD"], Currencies["EUR"], DATES.date_0)
    fx_query_1 = (Currencies["EUR"], Currencies["USD"], DATES.date_0)
    fx_query_2 = (Currencies["USD"], Currencies["EUR"], DATES.date_1)
    fx_query_3 = (Currencies["EUR"], Currencies["USD"], DATES.date_1)
    fx_query_4 = (Currencies["EUR"], Currencies["EUR"], DATES.date_0)
    fx_query_5 = (Currencies["USD"], Currencies["USD"], DATES.date_0)
    fx_query_6 = (Currencies["EUR"], Currencies["USD"], DATES.date_2)
    fx

# Generated at 2022-06-26 00:51:58.551056
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert f_x_rate_service_0.query(ccy1=currency_0, ccy2=currency_1, asof=date_0, strict=bool_0) == FXRate(ccy1=currency_0, ccy2=currency_1, date=date_0, value=Decimal('1'))

# Generated at 2022-06-26 00:52:06.450380
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx_rates import (
        FXRateLookupError,
        FXRate,
        FXRateService,
    )
    fx_rate_service_0 = FXRateService()
    fx_rate_tqs_0 = [
        (Currencies["EUR"], Currencies["USD"], datetime.datetime(2020, 1, 1)),
        (Currencies["USD"], Currencies["EUR"], datetime.datetime(2020, 1, 1)),
        (Currencies["EUR"], Currencies["USD"], datetime.datetime(2020, 1, 2)),
    ]
    result_0 = fx_rate_service_0.queries(fx_rate_tqs_0)

# Generated at 2022-06-26 00:52:12.512899
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    #test_case_0
    f_x_rate_service_0 = FXRateService()
    #test_case_1
    f_x_rate_service_1 = FXRateService()
    #test_case_2
    f_x_rate_service_2 = FXRateService()
    #test_case_3
    f_x_rate_service_3 = FXRateService()
    #test_case_4
    f_x_rate_service_4 = FXRateService()


# Generated at 2022-06-26 00:52:20.171861
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies import FXRate

    fx_rate_0 = FXRate(Currencies["TRY"], Currencies["USD"], date.today(), Decimal("2"))
    fx_rate_1 = FXRate(Currencies["USD"], Currencies["TRY"], date.today(), Decimal("0.5"))
    fx_rate_2 = FXRate(Currencies["USD"], Currencies["TRY"], date.today(), Decimal("0.5"))

    assert fx_rate_0 != fx_rate_1
    assert fx_rate_1 == fx_rate_2
    assert ~fx_rate_0 == fx_rate_1
    assert ~fx_rate_1 == fx_rate_0



# Generated at 2022-06-26 00:52:24.072297
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    query_tuple = (None, None, None)
    strict = False
    ret = f_x_rate_service_0.query(query_tuple[0], query_tuple[1], query_tuple[2], strict=strict)



# Generated at 2022-06-26 00:52:36.304257
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 00:52:40.084142
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    fx_rate = FXRate(Currency("XXX", "XXX", "XXX", "XXX", "XXX"),
                     Currency("XXX", "XXX", "XXX", "XXX", "XXX"),
                     Date('2019-10-15'), 1)
    f_x_rate_service_0 = FXRateService()
    result = f_x_rate_service_0.queries([], strict=False)


# Generated at 2022-06-26 00:52:49.600052
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    (ccy1, ccy2, asof) = (None, None, None)
    strict = False
    try:
        f_x_rate_service_0.query(ccy1, ccy2, asof, strict)
    except NotImplementedError as var_0:
        print("Method query of class FXRateService not implemented")
    else:
        print("Method query of class FXRateService not implemented")


# Generated at 2022-06-26 00:52:51.286056
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    with pytest.raises(TypeError):
        FXRateService.query(None)


# Generated at 2022-06-26 00:52:57.712629
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    a = 0 # noqa: F841



# Generated at 2022-06-26 00:53:03.986440
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_services = [
        FXRateService()
    ]
    try:
        for f_x_service in f_x_services:
            assert f_x_service.queries([], strict=False) == iter([])
    except AssertionError as e:
        print("\nAssertionError: ", e)
        print("\nError in test_FXRateService_queries.")
        print("\n\tThis error is caused by either a bug in code or a missing test case.")
        print("\tPlease, report this issue on the project's issue tracker:")
        print("\thttps://github.com/Mtiilc/pypara/issues/new")
        print("\tMore information about this error should be printed out above.")

# Generated at 2022-06-26 00:53:13.530366
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate

    ## Create an FX rate service with a couple of FX rates
    fx_rate_service = FXRate.of(Currencies["EUR"], Currencies["USD"], Date.now(), Decimal("2"))
    fx_rate_service = FXRate.of(Currencies["EUR"], Currencies["GBP"], Date.now(), Decimal("2"))
    fx_rate_service = FXRate.of(Currencies["USD"], Currencies["EUR"], Date.now(), Decimal("0.5"))

    ## Query FX rates
    f_x_rate0 = fx_rate_service.query(Currencies["EUR"], Currencies["USD"], Date.now(), True)

# Generated at 2022-06-26 00:53:15.977519
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    temp = f_x_rate_service_0.query(None, None, None, False)
    assert temp == None


# Generated at 2022-06-26 00:53:24.287277
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies

    # >>> fx_rate_service = FXRateService()
    fx_rate_service = FXRateService()

    # >>> fx_rate = fx_rate_service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    # >>> fx_rate != None
    # True
    import datetime
    fx_rate = fx_rate_service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert fx_rate != None
    assert fx_rate != None

    # >>> fx_rate = fx_rate_service.query(Currencies["USD"], Currencies["EUR"], datetime.date.today())
    # >>> fx_rate != None
    # True
    f

# Generated at 2022-06-26 00:53:27.925823
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    queries = [(Currency("USD"), Currency("EUR"), Date()), (Currency("GBP"), Currency("USD"), Date())]
    result = f_x_rate_service_0.queries(queries)
    assert result == None

# Generated at 2022-06-26 00:53:32.314241
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ccy1 = Currency('DUMMY')
    ccy2 = Currency('DUMMY')
    asof = Date('DUMMY')
    f_x_rate_service_0 = FXRateService()
    strict = bool()
    f_x_rate = f_x_rate_service_0.query(ccy1,ccy2,asof,strict)


# Generated at 2022-06-26 00:53:35.719730
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


if __name__ == "__main__":
    from pypara.commons import set_default_logging_config

    set_default_logging_config()

    test_case_0()
    test_FXRateService_queries()

# Generated at 2022-06-26 00:53:44.239104
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from collections import Iterable
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency
    from pypara.markets.fx import FXRate
    from pypara.markets.fx import FXRateService
    f_x_rate_service_0 = FXRateService()
    t_query_0 = FXRateService.TQuery(Currency.EUR, Currency.SAR, date(2015, 12, 15))
    t_query_1 = FXRateService.TQuery(Currency.NOK, Currency.USD, date(2015, 7, 31))
    t_query_2 = FXRateService.TQuery(Currency.RUB, Currency.USD, date(2015, 7, 10))

# Generated at 2022-06-26 00:53:53.230339
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRateService, FXRateLookupError
    # FX rate service that returns exact matches

# Generated at 2022-06-26 00:54:00.812400
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    f_x_rate_service_0 = FXRateService()
    list_1 = list_0
    iterator_0 = f_x_rate_service_0.queries(list_1)


# Generated at 2022-06-26 00:54:10.040111
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import datetime as module_1
    import decimal as module_2
    decimal_0 = module_2.Decimal()
    decimal_1 = decimal_0.__add__(decimal_0)
    decimal_2 = decimal_1.__add__(decimal_1)
    decimal_3 = decimal_2.__add__(decimal_2)
    decimal_4 = decimal_3.__add__(decimal_3)
    decimal_5 = decimal_4.__add__(decimal_4)
    decimal_6 = decimal_5.__add__(decimal_5)
    decimal_7 = decimal_6.__add__(decimal_6)
    decimal_8 = decimal_7.__add__(decimal_7)
    decimal_9

# Generated at 2022-06-26 00:54:18.695775
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_3 = ''
    int_2 = 107
    currency_type_2 = module_0.CurrencyType.CRYPTO
    decimal_3 = module_1.Decimal()
    list_1 = []
    decimal_4 = module_1.Decimal(*list_1)
    currency_2 = module_0.Currency(str_3, str_3, int_2, currency_type_2, decimal_4, int_2)
    str_4 = 'gR'
    int_3 = 741
    currency_type_3 = module_0.CurrencyType.ALTERNATIVE
    decimal_5 = currency_2.quantize(decimal_3)

# Generated at 2022-06-26 00:54:28.901380
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    decimal_0 = module_1.Decimal()
    decimal_1 = module_1.Decimal((57, (1,), -1))
    list_0 = []
    decimal_2 = module_1.Decimal(*list_0)
    list_1 = [str_0, str_0, int_0, currency_type_0, decimal_2, int_1]
    decimal_3 = module_1.Decimal(*list_1)
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_3, int_1)
    list_2 = [decimal_1, decimal_1, decimal_2]
    decimal_4 = module_1.Decimal(*list_2)

# Generated at 2022-06-26 00:54:29.425093
# Unit test for method query of class FXRateService
def test_FXRateService_query():
  pass


# Generated at 2022-06-26 00:54:37.928560
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'lookup_error'
    int_0 = 266
    currency_type_0 = module_0.CurrencyType.ASSET
    decimal_0 = module_1.Decimal()
    str_1 = 'WTkZ'
    str_2 = 'YbPu'
    int_1 = -9
    currency_type_1 = module_0.CurrencyType.ASSET
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_0)
    int_2 = -494
    currency_type_2 = module_0.CurrencyType.ALTERNATIVE
    decimal_2 = currency_0.quant

# Generated at 2022-06-26 00:54:40.910439
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries = Iterable
    strict = True
    f_x_rate_service_0 = FXRateService()
    try:
        f_x_rate_service_0.queries(queries, strict)
    except NotImplementedError:
        pass


# Generated at 2022-06-26 00:54:50.870968
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    currency_2 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_2, int_1)
    date_1 = None
    f_x_rate_service_0 = None
    f_x_rate_service_0.query(currency_1, currency_1, date_0, True)
    f_x_rate_service_0.query(currency_1, currency_1, date_1, True)
    f_x_rate_service_0.query(currency_1, currency_1, date_1, False)
    f_x_rate_service_0.query(currency_1, currency_2, date_1, True)


# Generated at 2022-06-26 00:54:59.618861
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ''
    int_0 = 614
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = 'l_sR'
    int_1 = 669
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_1)
    decimal_2 = currency_0.quantize(decimal_0)

# Generated at 2022-06-26 00:55:04.725866
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Initialize the FXRateService
    fx_rate_service_0 = None

    # Test method case: fx_rate_service_0.query(...)
    try:
        fx_rate_service_0.query()
    except TypeError:
        pass
    except AttributeError:
        pass
    except ValueError:
        pass


# Generated at 2022-06-26 00:55:21.170160
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'q'
    currency_type_0 = module_0.CurrencyType.COMMODITY
    list_0 = []
    decimal_0 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_0, str_0, 0, currency_type_0, decimal_0, 0)
    date_0 = None
    list_1 = [currency_0, currency_0, date_0]
    queries_0 = list_1
    f_x_rate_service_0 = FXRateService()
    list_2 = [None]
    f_x_rate_service_0.queries(queries_0)


# Generated at 2022-06-26 00:55:28.474792
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Case 0:
    assert FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) is not None

    ## Case 1:
    assert FXRateService.default.query(Currencies["EUR"], Currencies["USD"],
                                       datetime.date(2020, 4, 1)) is None or \
           FXRateService.default.query(Currencies["EUR"], Currencies["USD"],
                                       datetime.date(2020, 4, 1)).value < Decimal("0")

    ## Case 2:

# Generated at 2022-06-26 00:55:38.077229
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Test case: query for single FX rate
    str_0 = 'Q'
    int_0 = 373
    currency_type_0 = module_0.CurrencyType.NATIONAL
    decimal_0 = module_1.Decimal()
    currency_0 = module_0.Currency(str_0, str_0, int_0, currency_type_0, decimal_0, int_0)

# Generated at 2022-06-26 00:55:48.033766
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Dummy class for testing.
    class DummyClass(FXRateService):
        # Dummy method for testing.
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

    dummy_class_0 = DummyClass()
    decimal_0 = module_1.Decimal()
    currency_0 = Currency('t=\x1a', '\x001', decimal_0, module_0.CurrencyType.FUNGIBLE, decimal_0, decimal_0)
    date_0 = None
    f_x_rate_service_0 = dummy_class_0.query(currency_0, currency_0, date_0, False)



# Generated at 2022-06-26 00:55:52.548623
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ''
    int_1 = 787
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = 'tQ_ZBw'
    int_2 = 682
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_1, int_2, currency_type_1, decimal_1, int_2)
    decimal_2 = currency_0.quantize(decimal_0)

# Generated at 2022-06-26 00:55:53.389292
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:56:03.575167
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ''
    int_0 = 728
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = 'Kxe;'
    int_1 = 636
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_1)
    decimal_2 = currency_0.quantize(decimal_0)

# Generated at 2022-06-26 00:56:12.932019
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO check if all coverages are reached, check if all exceptions are raised
    str_0 = ''
    int_0 = 614
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = 'l_sR'
    int_1 = 669
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_1)

# Generated at 2022-06-26 00:56:22.222545
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import decimal as module_1
    str_0 = ''
    int_0 = 614
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = 'l_sR'
    int_1 = 669
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_1)
    decimal_2 = currency_0.quant

# Generated at 2022-06-26 00:56:31.781225
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ''
    int_0 = 614
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = 'nK[m'
    int_1 = 669
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_0, int_0, currency_type_0, decimal_1, int_1)
    decimal_2 = currency_0.quantize(decimal_0)

# Generated at 2022-06-26 00:56:57.862005
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_1 = 'b{:<'
    int_0 = 690

# Generated at 2022-06-26 00:57:10.573654
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ''
    int_0 = 868
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = 'l_sR'
    int_1 = 464
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_1)
    decimal_2 = currency_0.quantize(decimal_0)

# Generated at 2022-06-26 00:57:21.822765
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.registry import CurrencyRegistry
    from pypara.fx import FXRateService
    from pypara.testing import Date

    ## Initialize the currency registry:
    CurrencyRegistry().reset(clear=True)
    CurrencyRegistry().register(Currencies["EUR"], Currencies["USD"], date=Date.today(), value=Decimal("2"))

    ## Create an FX rate service for testing:
    class TestFXRate(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: datetime.date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError("It is not the business of the test.")


# Generated at 2022-06-26 00:57:34.136876
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = ''
    int_0 = 258
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = 'DEo'
    int_1 = 905
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_1)
    decimal_2 = currency_0.quantize(decimal_0)

# Generated at 2022-06-26 00:57:40.706288
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    tuple_0 = (None, None, None)
    list_0.append(tuple_0)
    int_0 = 1
    boolean_0 = int_0 == 0
    iterable_0 = list_0
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(iterable_0, boolean_0)


# Generated at 2022-06-26 00:57:49.719875
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pypara.currencies as module_0
    import pypara.finance as module_1
    import decimal as module_2
    import datetime as module_3
    import pypara.finance.foreign_exchange as module_4
    decimal_0 = module_2.Decimal()
    decimal_1 = module_2.Decimal(str_0)
    decimal_2 = decimal_0.to_integral_value(module_1.ROUND_HALF_UP)
    str_0 = 'X9:B'
    int_0 = 658
    currency_type_0 = module_0.CurrencyType.COMMODITY
    decimal_3 = decimal_1.from_float(1.0)
    decimal_4 = decimal_3.to_integral_value(decimal_0)

# Generated at 2022-06-26 00:57:59.302503
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    str_0 = ''
    int_0 = 614
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = 'l_sR'
    int_1 = 669
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_1)

# Generated at 2022-06-26 00:58:08.916207
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    int_0 = 913
    decimal_0 = module_1.Decimal()
    decimal_1 = decimal_0.quantize(decimal_0)
    list_0 = []
    decimal_2 = module_1.Decimal(*list_0)
    date_0 = None
    int_1 = 489
    str_0 = '\n        Returns foreign exchange rates for a given collection of currency pairs and dates.\n\n        :param queries: An iterable of :class:`Currency`, :class:`Currency` and :class:`Temporal` tuples.\n        :param strict: Indicates if we should raise a lookup error if that the foreign exchange rate can not be found.\n        :return: An iterable of rates.\n        '
    str_1 = 'r_JU'
    currency_type

# Generated at 2022-06-26 00:58:13.587452
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '$'
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = 'l_sR'
    int_0 = 614
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    list_0 = []
    list_1 = []
    decimal_1 = module_1.Decimal(*list_1)
    currency_0 = module_0.Currency(str_0, str_2, int_0, currency_type_0, decimal_1, int_0)
    int_1 = 669
    currency_type_1 = module_0.CurrencyType.CRYPTO
    decimal_2 = module_1.Decimal(*list_0)

# Generated at 2022-06-26 00:58:23.215753
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    int_0 = 79
    list_0 = []
    decimal_0 = module_1.Decimal(*list_0)
    str_0 = '<module>'
    int_1 = 538
    currency_type_0 = module_0.CurrencyType.COMMEMORATIVE
    currency_0 = module_0.Currency(str_0, str_0, int_1, currency_type_0, decimal_0, int_1)
    str_1 = 'i'
    int_2 = 927
    currency_type_1 = module_0.CurrencyType.SECURED
    decimal_1 = module_1.Decimal(int_2)

# Generated at 2022-06-26 00:59:11.937547
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ''
    str_1 = ''
    int_0 = 531
    int_1 = 28
    currency_type_0 = module_0.CurrencyType.COMMODITY
    currency_type_1 = module_0.CurrencyType.FIAT
    str_2 = '"J\n\x17'
    str_3 = 'n'

# Generated at 2022-06-26 00:59:25.071769
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'PRS'
    str_1 = '\x12\xea\x90\x9b\xcd\x1a\n\xfae'
    int_0 = 963
    currency_type_0 = module_0.CurrencyType.CRYPTO
    decimal_0 = module_1.Decimal()
    str_2 = 'a\x9a\xfb\xb3\xbaw\x1e\x1d'
    currency_0 = module_0.Currency(str_0, str_1, int_0, currency_type_0, decimal_0, int_0)
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)

# Generated at 2022-06-26 00:59:36.078257
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Prepare the mocks:
    urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    mrate = FXRate(Currencies["EUR"], Currencies["MXN"], datetime.date.today(), Decimal("0.2"))

    ## Prepare the mock lookup table:
    table = [urate, mrate]

    ## Prepare the mock service:
    class MockService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            (rate,) = [rate for rate in table if rate.ccy1 == ccy1 and rate.ccy2 == ccy2]

# Generated at 2022-06-26 00:59:36.996385
# Unit test for method query of class FXRateService
def test_FXRateService_query():
  pass


# Generated at 2022-06-26 00:59:49.555242
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test for method query of class FXRateService.
    """
    import pypara.currencies as module_0
    import decimal as module_1
    decimal_0 = module_1.Decimal()
    str_0 = '\n        Initializes the registry.\n        '
    str_1 = 'T\n{\x1d'
    int_0 = 433
    currency_type_0 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_0, int_0, currency_type_0, decimal_1, int_0)
    str_2 = '\n        Initializes the registry.\n        '

# Generated at 2022-06-26 01:00:01.937960
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = '\x00'
    int_0 = 614
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = module_1.Decimal()
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = 'l_sR'
    int_1 = 669
    currency_type_1 = module_0.CurrencyType.CRYPTO
    list_0 = []
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_1)
    decimal_2 = currency_0.quantize(decimal_0)

# Generated at 2022-06-26 01:00:13.074511
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = Currency(__doc__, __name__, 614, CurrencyType.ALTERNATIVE)
    currency_1 = Currency(__doc__, __name__, 669, CurrencyType.CRYPTO)
    date_0 = Date(2019, 1, 1)
    forex_rate_service = FXRateService()
    iterable_0 = ((currency_0, currency_1, date_0), (currency_1, currency_0, date_0))
    iterable_1 = forex_rate_service.queries(iterable_0)
    assert isinstance(iterable_1, Iterable)
    assert isinstance(iterable_1, Iterable)
    for x in iterable_1:
        assert isinstance(x, Optional)
        assert isinstance(x, Optional)

# Generated at 2022-06-26 01:00:23.526993
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Initialize the currency registry.
    # See https://github.com/OpenBookPrices/country-and-currency-names
    import pypara.currencies as cc

# Generated at 2022-06-26 01:00:32.394114
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Initialize classes
    Currency = module_0.Currency
    Date = module_1.date
    Decimal = module_1.Decimal
    FXRate = module_0.FXRate
    Currency = module_0.Currency
    Date = module_1.date
    Decimal = module_1.Decimal
    FXRateService = module_0.FXRateService
    Currency = module_0.Currency
    Date = module_1.date
    Decimal = module_1.Decimal
    # Test method
    str_0 = '_Hk'
    int_0 = 824
    currency_type_0 = module_0.CurrencyType.OFFICIAL
    list_0 = []
    decimal_0 = Decimal(*list_0)
    list_1 = []

# Generated at 2022-06-26 01:00:42.141305
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = ''
    int_0 = 909
    currency_type_0 = module_0.CurrencyType.ALTERNATIVE
    decimal_0 = currency_type_0.name
    str_1 = '\n        Initializes the registry.\n        '
    str_2 = '\x7f'
    int_1 = 722
    currency_type_1 = module_0.CurrencyType.ALTERNATIVE
    list_0 = [int_1]
    decimal_1 = module_1.Decimal(*list_0)
    currency_0 = module_0.Currency(str_1, str_2, int_1, currency_type_1, decimal_1, int_1)
    decimal_2 = currency_0.from_decimal(decimal_0)
    currency_1 = module_