

# Generated at 2022-06-26 00:51:57.371163
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main
    from pypara.currencies import Currency
    import datetime
    from decimal import Decimal

    class FXRateServiceMock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: datetime.date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[Tuple[Currency, Currency, datetime.date]], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return FXRate(Currency("EUR"), Currency("USD"), datetime.date(2020, 1, 1), Decimal(2))


# Generated at 2022-06-26 00:52:01.320677
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    try:
        f_x_rate_service_0 = FXRateService()
        (ccy1, ccy2, asof) = (Currency.NIL, Currency.NIL, Date.NIL)
        strict = 0
        f_x_rate_service_0.query(ccy1, ccy2, asof, strict)
    except TypeError:
        assert False


# Generated at 2022-06-26 00:52:09.563414
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    q1 = (Currency("EUR"), Currency("USD"), Date(2018, 1, 1))
    q2 = (Currency("USD"), Currency("EUR"), Date(2018, 1, 1))
    q3 = (Currency("TUR"), Currency("EUR"), Date(2018, 1, 1))
    qs = [q1, q2, q3]
    f_x_rate_service_0 = FXRateService()

# Generated at 2022-06-26 00:52:13.734099
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests queries of class FXRateService
    """
    ### Don't move this line!!
    f_x_rate_service_0 = FXRateService()

    print("\n\n === TEST Method queries of class FXRateService ===")
    print("\n")
    print(" Todo: Create tests.")



# Generated at 2022-06-26 00:52:21.834537
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    ## Create FX rates with FXRate class:
    eur_usd_fx_rate = FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 7, 1), Decimal("1.5"))
    gbp_usd_fx_rate = FXRate(Currencies["GBP"], Currencies["USD"], date(2020, 7, 1), Decimal("1.7"))
    chf_usd_fx_rate = FXRate(Currencies["CHF"], Currencies["USD"], date(2020, 7, 1), Decimal("1.0"))

    ## Create FX rates with FXRate.of:

# Generated at 2022-06-26 00:52:34.126936
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    fx_rate_service_0 = FXRateService()
    ccy1_0 = Currencies["EUR"]
    ccy2_0 = Currencies["USD"]
    asof_0 = date.today()
    strict_0 = True

    # Call method query of class FXRateService
    try:
        result_0 = fx_rate_service_0.query(ccy1_0, ccy2_0, asof_0, strict_0)
    except FXRateLookupError as e:
        # Check if exception's arguments are correct
        assert(e.ccy1 == ccy1_0)
        assert(e.ccy2 == ccy2_0)

# Generated at 2022-06-26 00:52:36.166219
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert f_x_rate_service_0.query(Currency.of("USD"), Currency.of("CHF"), Date.now(), False) is None



# Generated at 2022-06-26 00:52:38.845649
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Initialize empty class
    f_x_rate_service_1 = FXRateService()
    f_x_rate_service_1.query(Currency("JPY"), Currency("USD"), Date("2016-01-01"))




# Generated at 2022-06-26 00:52:51.800565
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # test_FXRateService_queries.py
    import datetime
    from decimal import Decimal
    from typing import Iterable, Tuple
    from typing import TypeVar, Generic
    from pypara.finance.fx import FXRateService
    from pypara.currencies import Currency
    from pypara.time import Temporal, Date
    from pypara.commons.numbers import ONE
    from pypara.commons.zeitgeist import date
    FXRateService_T = TypeVar('FXRateService_T', bound='FXRateService')

# Generated at 2022-06-26 00:53:00.664652
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    tmp_req = f_x_rate_service.queries([(2.701081348, -1.350193006, datetime.date(2002, 9, 1))])
    actual = [elem for elem in tmp_req]
    expected = [None]
    assert expected == actual
    del tmp_req, actual, expected

    tmp_req = f_x_rate_service.queries([(2.701081348, -1.350193006, datetime.date(2002, 9, 1)), (2.701081348, -1.350193006, datetime.date(2002, 9, 1)), (-1.350193006, 2.701081348, datetime.date(2002, 9, 1))])
    actual = [elem for elem in tmp_req]

# Generated at 2022-06-26 00:53:13.151009
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    int_0 = 14
    str_0 = ']'
    dict_0 = {str_0: int_0, 'M': str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    date_0 = None
    currency_0 = None
    currency_1 = None
    bool_0 = None
    f_x_rate_0 = f_x_rate_service_0.query(currency_0, currency_1, date_0, bool_0)


# Generated at 2022-06-26 00:53:21.728533
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    bool_0 = None
    list_0 = [None, None]
    bytes_0 = None
    list_1 = [list_0, list_0, None, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}
    f_x

# Generated at 2022-06-26 00:53:29.885281
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = ''
    int_0 = 2697
    set_0 = {int_0, int_0, str_0, str_0}
    bool_0 = None
    str_1 = ''
    str_2 = 'CDF'
    currency_type_0 = module_1.CurrencyType.CRYPTO
    list_0 = [currency_type_0, currency_type_0, str_2]
    decimal_0 = module_2.Decimal(*list_0)
    int_1 = 30
    currency_0 = module_1.Currency(str_0, str_2, int_0, currency_type_0, decimal_0, int_1)
    list_1 = [currency_0, currency_type_0, str_0, str_0, str_0]
    f_

# Generated at 2022-06-26 00:53:38.638102
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # test 1 - old coverage: 0.0
    # inputs:
    #   fx_rate_service: FXRateService
    #   ccy1: Currency
    #   ccy2: Currency
    #   asof: Temporal
    #   strict: bool
    # outputs:
    #   fx: FXRate or None

    if False:
        pass  # TODO: implement this test
    fx_rate_service_0 = FXRateService()
    ccy1_0 = Currency()
    ccy2_0 = Currency()
    asof_0 = Temporal()
    strict_0 = bool()

    fx_0 = fx_rate_service_0.query(ccy1_0, ccy2_0, asof_0, strict_0)
    assert fx_0 is None



# Generated at 2022-06-26 00:53:47.725309
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 00:53:55.843416
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = [None, None]
    bytes_0 = None
    list_1 = [list_0, list_0, None, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {2697, None, None, 2697}
    bool_0 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}
    f_x_rate_2 = FXRate(**dict_0)

# Generated at 2022-06-26 00:54:02.386587
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # test for query(ccy1:Currency, ccy2:Currency, asof:Date, strict:bool=False) -> Optional[FXRate]:
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    import datetime
    from pypara.fx.services.fixer import FixerFXRateService

    service = FixerFXRateService(api_key="cbd01b0d0778a2d9af1b8e47aec73da6", debug=True)
    rates = [
        (Currencies["USD"], Currencies["EUR"], datetime.date.today()),
        (Currencies["EUR"], Currencies["TRY"], datetime.date.today()),
        (Currencies["USD"], Currencies["TRY"], datetime.date.today()),
    ]
   

# Generated at 2022-06-26 00:54:12.253663
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 00:54:13.617051
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Implementation of the unit test goes here
    raise NotImplementedError()


# Generated at 2022-06-26 00:54:17.851035
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class_under_test = FXRateService()
    FXRateService_queries_arg = FXRateService.queries()
    FXRateService_queries_return = class_under_test.queries( FXRateService_queries_arg )
    #assert( FXRateService_queries_return == "Expected value from test" )


# Generated at 2022-06-26 00:54:36.150293
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 00:54:44.576101
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 00:54:56.172095
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 00:55:07.254732
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    module_0 = None
    list_0 = [module_0, module_0]
    bytes_0 = None
    list_1 = [list_0, list_0, module_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_0 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 00:55:18.225261
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 00:55:26.811198
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    float_0 = 2.2
    decimal_0 = module_2.Decimal(float_0)
    date_0 = None
    bool_0 = False
    str_0 = 'r'
    currency_type_0 = module_1.CurrencyType.CRYPTO
    currency_2 = module_1.Currency(str_0, str_0, float_0, currency_type_0, decimal_0, float_0)
    currency_3 = module_1.Currency(str_0, str_0, float_0, currency_type_0, decimal_0, float_0)
    int_0 = 12
    f_x_rate_0 = FXRate.of(currency_2, currency_3, date_0, decimal_0)

# Generated at 2022-06-26 00:55:35.756349
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fx_services.endpoint import (
        FXRateEndpointService,
        FXRateEndpointServiceError
    )

    ## Create a connection to the endpoint service:
    service = FXRateEndpointService()

    ## Find the FX rate and convert to EUR:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()
    rate = service.query(ccy1, ccy2, date)
    assert rate.ccy1 == ccy1
    assert rate.ccy2 == ccy2
    assert rate.date == date
    assert isinstance(rate.value, Decimal)

    ## Find the inverted FX rate and convert

# Generated at 2022-06-26 00:55:46.505279
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 00:55:51.062871
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Tests: (bool, List[Tuple[Currency, Currency, Temporal]])
    #   Correct return type: (str, List[Tuple[Currency, Currency, Temporal]]) -> List[Optional[FXRate]]
    #   Invalid input type: (Currency, Currency, Currency) -> ValueError

    method_tests = [
        True,
        False
    ]

# Generated at 2022-06-26 00:56:00.806541
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_type_2 = module_1.CurrencyType.COMMODITY
    list_2 = [currency_type_2, currency_type_2, currency_type_2]
    str_3 = 'dfjltn'
    list_3 = [currency_type_2, currency_type_2, str_3]
    bytes_0 = None
    list_3.append(bytes_0)
    bytes_1 = None
    list_3.append(bytes_1)
    int_0 = 2344
    list_3.append(int_0)
    str_0 = 'zskvohy'
    list_3.append(str_0)
    int_1 = 3793
    list_3.append(int_1)
    str_1 = 'D'

# Generated at 2022-06-26 00:56:20.801291
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    try:
        test_case_0()
    except (TypeError, ValueError, AttributeError, LookupError, RuntimeError, KeyError, NameError, IndexError, UnboundLocalError, ImportError, ArithmeticError) as err:
        print(err)
    else:
        pass


if __name__ == '__main__':
    test_FXRateService_queries()

# Generated at 2022-06-26 00:56:30.147982
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}
    f_x_rate_service_0 = FXRateService

# Generated at 2022-06-26 00:56:39.671283
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Define test values
    import dateutil.parser
    date_0 = dateutil.parser.parse('2017-01-25T21:04:21.1566227-07:00')
    decimal_0 = decimal.Decimal('-0.647824')
    f_x_rate_0 = FXRate(currency_0, currency_1, date_0, decimal_0)
    f_x_rate_1 = FXRate(currency_0, currency_0, date_0, decimal_0)
    f_x_rate_2 = FXRate(currency_0, currency_1, date_0, decimal_0)
    f_x_rate_3 = FXRate(currency_1, currency_0, date_0, decimal_0)
    f_x_rate_4 = f_x_rate_0.__

# Generated at 2022-06-26 00:56:49.022178
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 00:56:50.595680
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    FXRateService.default.query(Currency.USD, Currency.EUR, Date.today())


# Generated at 2022-06-26 00:56:54.705440
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    dict_0 = {}
    set_0 = {dict_0}
    f_x_rate_service_0 = FXRateService()
    with raises(NotImplementedError):
        iterable_0 = f_x_rate_service_0.queries(set_0)


# Generated at 2022-06-26 00:57:07.101624
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    str_0 = 'u:7M'
    str_1 = 'q3WpX8'
    str_2 = 'I-f'
    str_3 = 'QC0'
    str_4 = ''
    str_5 = 'NoCTf,]{'
    int_0 = 8
    list_0 = [str_5, str_5, str_5, str_5, str_5, str_5, str_5, str_5, str_5, str_5]
    int_1 = 4
    list_1 = [int_1]
    set_0 = {int_0}
    int_2 = 5
    tuple_0 = (int_1, int_0, int_0, int_2)
    str_6 = 'T'
    str_7 = '-('

# Generated at 2022-06-26 00:57:14.456880
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    bool_0 = None
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    iterable_0 = f_x_rate_service_0.queries(set_0, bool_1)
    # tests that the __init__ method of FXRateService class is implemented correctly
    assert(True == bool_1)


# Generated at 2022-06-26 00:57:15.679610
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert True


# Generated at 2022-06-26 00:57:17.897047
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert callable(getattr(FXRateService, "query", None))


# Generated at 2022-06-26 00:57:56.867390
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 00:57:57.775008
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-26 00:58:02.451618
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    int_0 = 11
    int_1 = -15
    tuple_0 = (int_0, int_1)
    query_list = list(tuple_0)
    fx_rate = query_list[0][2]
    if fx_rate < 1:
        fx_rate = 1
    strict = True
    FXRateService.queries(query_list, strict)


# Generated at 2022-06-26 00:58:08.284872
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ## Initialize:
    service = None  # type: FXRateService

    ## Create test query set:
    queries = [None] * 0

    ## Run the method under test:
    try:
        result = service.queries(queries)
    except Exception as e:
        print(e)
        raise AssertionError()

    ## Check that we have the right result:
    assert result is not None


# Generated at 2022-06-26 00:58:17.083740
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = [None, None, None, None]
    f_x_rate_0 = FXRate(*list_0)
    str_0 = None
    int_0 = 2708
    set_0 = {int_0, str_0, str_0, int_0}
    bool_0 = None
    str_1 = 'foC7m'
    dict_0 = {str_1: int_0, str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    currency_type_0 = module_1.CurrencyType.CRYPTO
    list_1 = [currency_type_0, currency_type_0, str_0]
    decimal_0 = module_2.Decimal(*list_1)
    int_1 = -76

# Generated at 2022-06-26 00:58:27.324095
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Declarations
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    # Setup
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    iterable_0 = f

# Generated at 2022-06-26 00:58:28.257360
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert True


# Generated at 2022-06-26 00:58:34.184727
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = None
    bool_1 = None
    int_0 = 8552
    str_0 = ''
    str_1 = 'sc4'
    str_2 = 'N{NuO7`N:UV'
    dict_0 = {str_1: int_0, str_0: bool_1, str_2: str_2}
    f_x_rate_service_0 = FXRateService(**dict_0)
    str_3 = '1yL'
    str_4 = '=`tgx`&'
    list_0 = [str_2, str_2, str_2, str_2]
    list_1 = [str_3, str_3, str_3, str_3]

# Generated at 2022-06-26 00:58:42.304298
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 00:58:50.063347
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = f_x_rate_0.__invert__()
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}

# Generated at 2022-06-26 01:00:13.254783
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    str_0 = 'M'
    str_1 = 'kK'
    str_2 = ''
    int_0 = -200
    temporal_0 = Date(str_2, str_2, str_1, str_1, str_1, str_1, int_0)
    currency_type_0 = module_1.CurrencyType.CRYPTO
    str_3 = '\xba\x13\x1f'
    int_1 = 2749
    str_4 = 'K'
    bool_0 = None
    dict_0 = {str_0: bool_0, str_2: str_2, str_4: str_3}
    decimal_0 = module_2.Decimal(**dict_0)
    int_2 = -78
    currency_0 = module_1.Currency

# Generated at 2022-06-26 01:00:23.598157
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Setup
    module_0 = None
    module_1 = None
    # Test
    set_0 = {module_0, module_1}
    # Module: pypara.currencies.__main__
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''

# Generated at 2022-06-26 01:00:32.431322
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = [None] * 4
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    list_1 = [None] * 4
    f_x_rate_2 = FXRate(*list_1)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.queries(((f_x_rate_0, f_x_rate_1), (f_x_rate_2, f_x_rate_2)))
    f_x_rate_service_0.queries(((f_x_rate_2, f_x_rate_0), (f_x_rate_1, f_x_rate_1)))
    f_x_rate

# Generated at 2022-06-26 01:00:42.213068
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    int_0 = 0
    int_1 = -3651
    int_2 = -3651
    int_3 = -3651
    int_4 = 0
    int_5 = -3651
    int_6 = -3651
    int_7 = -3651
    int_8 = -3651
    int_9 = -3651
    int_10 = 0
    str_0 = '6'
    str_1 = 'KjZ!z'
    str_2 = 'KjZ!z'
    str_3 = 'KjZ!z'
    str_4 = '6'
    str_5 = 'KjZ!z'
    str_6 = 'KjZ!z'
    str_7 = 'KjZ!z'

# Generated at 2022-06-26 01:00:49.113093
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_1 = None
    list_0 = [bool_1, bool_1]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_1, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_0 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)

# Generated at 2022-06-26 01:00:50.651326
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    FXRateService.query()


# Generated at 2022-06-26 01:00:57.706109
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    int_0 = 10
    str_0 = 'th=70C'
    bool_0 = None
    tuple_0 = (bool_0,)
    set_0 = {tuple_0, str_0}
    dict_0 = {int_0: set_0, str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    str_1 = 'gJ0F;E=*W<'
    tuple_1 = (str_0,)
    set_1 = {str_1, tuple_1}
    list_0 = [int_0, str_0, dict_0, set_1]
    f_x_rate_0 = FXRate(*list_0)

# Generated at 2022-06-26 01:00:58.421712
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-26 01:01:05.538854
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_1 = [bool, False]
    list_0 = [list_1, list_1]
    f_x_rate_1 = FXRate(*list_0)
    f_x_rate_0 = f_x_rate_1.__invert__()
    str_1 = 'A'
    str_0 = ''
    dict_1 = {str_0: str_0, str_1: int}
    f_x_rate_service_0 = FXRateService(**dict_1)
    str_2 = 'CDF'
    int_0 = 2697
    set_1 = {int_0, str_0, str_0, int_0}
    bool_0 = None
    iterable_0 = f_x_rate_service_0.queries(set_1, bool_0)

# Generated at 2022-06-26 01:01:13.213305
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = None
    list_0 = [bool_0, bool_0]
    bytes_0 = None
    list_1 = [list_0, list_0, bool_0, bytes_0]
    f_x_rate_0 = FXRate(*list_1)
    str_0 = None
    str_1 = 'CDF'
    int_0 = 2697
    set_0 = {int_0, str_0, str_0, int_0}
    bool_1 = None
    str_2 = ''
    dict_0 = {str_2: int_0, str_1: str_0, str_0: str_0}
    f_x_rate_service_0 = FXRateService(**dict_0)
    bool_2 = None
    f_x_rate_service_