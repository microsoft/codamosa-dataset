

# Generated at 2022-06-26 00:51:43.108235
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())

# Generated at 2022-06-26 00:51:48.148354
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_queries_0 = FXRateService()
    queries = iter([(Currency, Currency, Date)])
    queries0 = iter([(Currency, Currency, Date)])
    strict = False
    strict0 = False
    assert iter([(Optional[FXRate], ...)]) == f_x_rate_service_queries_0.queries(queries, strict)
    assert iter([(Optional[FXRate], ...)]) == f_x_rate_service_queries_0.queries(queries0, strict0)



# Generated at 2022-06-26 00:51:58.124911
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.utils.temporal import Date
    from pypara.utils.temporal.asof import AsOf
    import datetime

    date = datetime.date(2019, 4, 21)
    temporal = Date(date=date)
    asof = AsOf(temporal)
    ccy1 = Currencies['USD']
    ccy2 = Currencies['EUR']
    query1 = (ccy1, ccy2, asof)
    query2 = (ccy1, ccy2, asof)
    queries = [query1, query2]

    f_x_rate_service_0 = FXRateService()
    exception = FXRateLookupError(ccy1, ccy2, date)

    actual = f_

# Generated at 2022-06-26 00:52:00.935447
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    t1 = FXRateService.TQuery
    f_x_rate_service = FXRateService()
    queries = [t1(1,2,3)]
    strict = True
    f_x_rate_service.queries(queries, strict)


# Generated at 2022-06-26 00:52:07.097706
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    asof = Date(year=2018, month=5, day=9)
    f_x_rate_service_0 = FXRateService()
    strict_0 = True
    rate = f_x_rate_service_0.query(Currency.of("EUR"), Currency.of("USD"), asof=asof, strict=strict_0)
    assert rate is None
    strict_1 = False
    rate = f_x_rate_service_0.query(Currency.of("EUR"), Currency.of("USD"), asof=asof, strict=strict_1)
    assert rate is None

# Generated at 2022-06-26 00:52:15.997940
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    from .commons.numbers import ONE,ZERO,Decimal
    #from .readers.rates import CcyPair, CcyPairList, FXRate, FXRateLookupError
    #from .readers.rates import FXRateService  # noqa: F401
    #from .readers.rates import FXRateService
    #from .readers.rates import CcyPair, CcyPairList, FXRate, FXRateLookupError

    ## Initialize the CcyPairList with a list of CcyPairs:
    fx_rate_lookup_error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())

# Generated at 2022-06-26 00:52:21.798247
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): 
    from pypara.fxt import FXRateService
    from datetime import date
    from pypara.currencies import Currency
    fxr = FXRateService()
    queries = [(Currency.of(code=code), Currency.of(code=code), date(2018, 12, 31)) for code in ['TRY', 'USD']]  # noqa: E501
    results = list(fxr.queries(queries=queries))
    assert len(results) == 2
    assert results[0].value == 1.0
    assert results[1].value == 1.0

# Generated at 2022-06-26 00:52:26.354722
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert (~nrate == rrate)


# Generated at 2022-06-26 00:52:33.975167
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    list_0 = [FXRate(ccy1=Currency.USD, ccy2=Currency.USD, date=Date.today(), value=0.0)]
    iterable_0 = f_x_rate_service_0.queries(list_0, False)

# Generated at 2022-06-26 00:52:40.839705
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        ## Test initialization:
        from .currencies import Currencies
        from .commons.zeitgeist import Date

        asof = Date()
        ccy1 = Currencies["EUR"]
        ccy2 = Currencies["USD"]

        ## Test basic attributes:
        error = FXRateLookupError(ccy1, ccy2, asof)
        assert(isinstance(error, FXRateLookupError))
        assert(isinstance(error, LookupError))
        assert(error.ccy1 == ccy1)
        assert(error.ccy2 == ccy2)
        assert(error.asof == asof)
    except Exception as exception:
        assert (False), exception

## This is the test-case to check if there is any error in the FXRate class

# Generated at 2022-06-26 00:52:52.340894
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_1 = FXRateService()
    assert f_x_rate_service_1.query("ccy1", "ccy2", "asof", "strict") == None


# Generated at 2022-06-26 00:53:01.130761
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Generating an object of the class
    f_x_rate_service = FXRateService()
    
    
    
    
    
    
    
    
    
    
    # Testing with invalid input parameter value
    cnt = 0
    for invalid_in_param in ([None, None, None], ["x", "x", "x"], [None, None, "x"], ["x", None, None], [None, "x", None], ["x", "x", None], [None, "x", "x"], ["x", None, "x"]):
        invalid_in_param_0, invalid_in_param_1, invalid_in_param_2 = invalid_in_param #unpacking

# Generated at 2022-06-26 00:53:05.708772
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    c1 = Currency('GBP')
    c2 = Currency('USD')
    d1 = Date(1,1,1)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(c1, c2, d1, False)



# Generated at 2022-06-26 00:53:07.309125
# Unit test for method queries of class FXRateService

# Generated at 2022-06-26 00:53:13.835328
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    import datetime

    temporal1 = Temporal.today()
    temporal2 = Temporal.of(date=datetime.date(2018, 8, 11))

    m = FXRateService()
    m.queries([
        (Currencies['EUR'], Currencies['USD'], temporal1),
        (Currencies['EUR'], Currencies['USD'], temporal2)], strict=False)

    pass



# Generated at 2022-06-26 00:53:18.640103
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Case fx_rate_service = FXRateService()
    f_x_rate_service_0 = FXRateService()
    ccy1 = Currency()
    ccy2 = Currency()
    asof = Date()
    strict = False
    query_response_0 = f_x_rate_service_0.query(ccy1,ccy2,asof,strict)
    assert isinstance(query_response_0,(None))


# Generated at 2022-06-26 00:53:22.065746
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ccy1 = None
    ccy2 = None
    asof = None
    strict = True
    fxrateservice_instance = FXRateService()
    fxrateservice_instance.queries(ccy1, ccy2, asof, strict)

# Generated at 2022-06-26 00:53:30.436450
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currency
    from pypara.temporals import Temporal
    from pypara.currencies.ccy_codes import CcyCodes
    from pypara.temporals.date_utils import DateUtils

    class FXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            if asof == DateUtils.today(DateUtils.DATE_FORMATTER_1) and ccy1 == CcyCodes.USD and ccy2 == CcyCodes.EUR:
                return None

# Generated at 2022-06-26 00:53:33.314443
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    actual_result = f_x_rate_service_0.query(1, 1, 1, False)
    expected_result = None
    assert expected_result == actual_result


# Generated at 2022-06-26 00:53:42.477273
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .services import FXRateDataService
    from .test.test_fx_rates import test_fx_rates
    f_x_rate_service_0 = FXRateDataService(test_fx_rates(as_dict=True))
    f_x_rate_service_1 = f_x_rate_service_0
    strict_0 = False
    queries_0 = ((Currency('USD'), Currency('EUR'), Date(year=2013, month=12, day=27)), (Currency('GBP'), Currency('USD'), Date(year=2013, month=12, day=27)), (Currency('USD'), Currency('EUR'), Date(year=2013, month=12, day=26)))
    f_x_rate_service_1.queries(queries_0)
    strict_1 = True

# Generated at 2022-06-26 00:53:55.405642
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Provides the unit test for the method query of class FXRateService.
    """

    ## Create and initialize an FX rate service:
    from .currencies import Currencies
    from .services.fxrates import FXRateServiceMemory


# Generated at 2022-06-26 00:54:01.952398
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = FXRateService()
    boolean_0 = True
    list_0 = [1, 1, 1]
    f_x_rate_0 = FXRate(*list_0)
    list_1 = ["", "", ""]
    f_x_rate_1 = FXRate(*list_1)
    list_2 = [1, 1, 1]
    f_x_rate_2 = FXRate(*list_2)
    list_3 = [1, 1, 1]
    f_x_rate_3 = FXRate(*list_3)
    list_4 = [1, 1, 1]
    f_x_rate_4 = FXRate(*list_4)
    list_5 = [1, 1, 1]

# Generated at 2022-06-26 00:54:05.554038
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # args:
    queries = [(0, 1, 2), (2, 1, 0)]
    strict = 0
    # f_x_rate_service_0 = FXRateService()
    # f_x_rate_service_0.queries(queries, strict=strict)



# Generated at 2022-06-26 00:54:14.975847
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    fx_rates_0 = FXRateService().queries([tuple()], False)
    FXRateService().queries((tuple(),))
    fx_rates_1 = FXRateService().queries(tuple())
    FXRateService().queries(tuple())
    fx_rates_2 = FXRateService().queries(tuple())
    fx_rates_3 = FXRateService().queries(tuple())
    fx_rates_4 = FXRateService().queries(tuple())
    FXRateService().queries(tuple())
    fx_rates_5 = FXRateService().queries(tuple())
    FXRateService().queries(tuple())
    fx_rates_6 = FXRateService().queries(tuple())
    fx_rates_7 = FXRateService().queries

# Generated at 2022-06-26 00:54:19.379573
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    t_query_0 = FXRateService.TQuery
    f_x_rate_service_0 = FXRateService()
    bool_0 = False
    FXRateService.query = f_x_rate_service_0.query
    f_x_rate_0 = FXRateService.query(bool_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-26 00:54:29.606948
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency

    fx_rate_service = FXRateService()
    ccy1 = Currency("USD")
    ccy2 = Currency("TRY")

    # Check if method raises error for None type
    try:
        fx_rate_service.query(None, ccy2, date.today())
    except ValueError:
        pass
    except BaseException as e:
        raise AssertionError("Expected ValueError, got %s" % e)

    # Check if method raises error for None type
    try:
        fx_rate_service.query(ccy1, None, date.today())
    except ValueError:
        pass

# Generated at 2022-06-26 00:54:38.106766
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = [bool_1, bool_2, True, True]
    list_1 = [Decimal('8.764040994057486E+162'), Decimal('8.1E+307'), Decimal('-1E+1'), Decimal('-1E+1')]
    list_2 = [None, 'G', 'S', 'S']
    tuple_0 = (list_0, list_1, list_2)
    f_x_rate_3 = FXRate(*tuple_0)
    f_x_rate_4 = f_x_rate_3.__invert__()
    f_x_rate_service_1 = FXRateService()
    currency_0 = Currency()
    today = 'K'
    today_0 = Date.of_str(today)

# Generated at 2022-06-26 00:54:41.085862
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ccy1 = None
    ccy2 = None
    asof = Date()
    strict = False
    return_value = False
    return_value = FXRateService.query(ccy1, ccy2, asof, strict)
    assert return_value is None


# Generated at 2022-06-26 00:54:42.148802
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    >>> test_case_0()
    """
    pass



# Generated at 2022-06-26 00:54:42.979605
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    return


# Generated at 2022-06-26 00:54:56.015434
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    f_x_rate_service_0 = None
    bool_0 = False
    f_x_rate_service_1 = FXRateService.queries(f_x_rate_service_0, bool_0)


# Generated at 2022-06-26 00:55:00.301813
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    service = TestService([nrate])
    rrate = service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    if rrate is not None and rrate != nrate:
        raise RuntimeError("Unit test for method query of class FXRateService failed!")


# Generated at 2022-06-26 00:55:10.045840
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    f_x_rate_service_0 = FXRateService()
    # queries()
    list_0 = [Currencies["EUR"], Currencies["USD"], datetime.date.today()]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = FXRate(*list_0)
    list_1 = [f_x_rate_0]
    list_2 = [f_x_rate_1]
    f_x_rate_2 = FXRate(*list_0)
    list_3 = [f_x_rate_2]
    f_x_rate_3 = FXRate(*list_0)
    list_4 = [f_x_rate_3]


# Generated at 2022-06-26 00:55:16.545304
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import random
    f_x_rate_service_0 = FXRateService()
    list_0 = [None] * 3
    tuple_0 = tuple(list_0)
    list_1 = [tuple_0] * 5
    iterable_0 = iter(list_1)
    assert f_x_rate_service_0.queries(iterable_0) == list_1

# Generated at 2022-06-26 00:55:25.729621
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_service_0 = FXRateService()
    bool_1 = False
    bool_2 = False
    queries = f_x_rate_service_0.queries(tuple_0, bool_1)
    assert list_0[:2] == [f_x_rate_0, f_x_rate_1]
    assert len(list_0) == 3
    assert list_0[2] == f_

# Generated at 2022-06-26 00:55:30.541786
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    cur_0 = Currency('', '', )
    cur_1 = Currency('', '', )
    dt_0 = Date()
    bool_0 = False
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(cur_0, cur_1, dt_0, bool_0)


# Generated at 2022-06-26 00:55:38.156410
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_service_0 = FXRateService()
    bool_1 = False
    bool_2 = False
    str_0 = f_x_rate_service_0.query(bool_2, bool_1, bool_2, bool_0)
    assert str_0 == None


# Generated at 2022-06-26 00:55:44.423203
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    int_0 = 2
    int_1 = 4
    int_2 = 4
    int_3 = 5
    int_4 = 2
    str_0 = ''
    int_5 = 4
    int_6 = 6
    int_7 = 6
    f_x_rate_service_method_0 = FXRateService.query
    # Test for method query of class FXRateService
    f_x_rate_service_method_0()



# Generated at 2022-06-26 00:55:46.503016
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 00:55:53.465272
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from operator import truth
    from pypara.currencies import Currencies

    # test case1
    f_x_rate_service_0 = FXRateService()
    f_x_rate_0 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    list_0 = [f_x_rate_0]
    bool_0 = all(list(map(truth, list_0)))
    assert bool_0


# Generated at 2022-06-26 00:56:19.624580
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Arguments:
    queries = [(None, None, None)]
    strict = False

    # Locals:
    fxr_0 = FXRate("ccy1", "ccy2", "date", "value")
    fxr_1 = FXRate("ccy1", "ccy2", "date", "value")
    fxr_2 = FXRate("ccy1", "ccy2", "date", "value")
    fx_rate_service_0 = FXRateService()

    # Test:
    iterable_0 = fx_rate_service_0.queries(queries, strict)
    # Assertion:
    assert iterable_0 == [fxr_0, fxr_1, fxr_2]


# Generated at 2022-06-26 00:56:25.594644
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    fx_rate_service_0 = FXRateService()
    fx_rate_0 = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    f_x_rate_service_0 = fx_rate_service_0.query(*fx_rate_0).__invert__()


# Generated at 2022-06-26 00:56:34.520250
# Unit test for method query of class FXRateService

# Generated at 2022-06-26 00:56:44.403537
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("1.12"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    f_x_rate_service_0 = FXRateServiceImpl()
    ccy_0 = Currencies["USD"]
    ccy_1 = Currencies["USD"]

# Generated at 2022-06-26 00:56:53.704114
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = []
    f_x_rate_service_0 = FXRateService()
    bool_0 = False
    bool_1 = False
    f_x_rate_service_0.queries(list_0, bool_0)
    f_x_rate_service_0.queries(list_0, bool_1)
    list_1 = []
    f_x_rate_0 = FXRate(*list_1)
    f_x_rate_1 = FXRate(*list_1)
    f_x_rate_2 = FXRate(*list_1)
    f_x_rate_3 = FXRate(*list_1)
    f_x_rate_4 = FXRate(*list_1)
    bool_2 = False

# Generated at 2022-06-26 00:56:56.178706
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    args_0 = [Currency, Currency, Date, bool]
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(*args_0)


# Generated at 2022-06-26 00:57:05.872252
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    bool_0 = False
    f_x_rate_0 = f_x_rate_service_0.query(bool_0, bool_0, bool_0, bool_0)
    f_x_rate_1 = f_x_rate_service_0.query(bool_0, bool_0, bool_0, bool_0)
    f_x_rate_2 = f_x_rate_service_0.query(bool_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-26 00:57:14.357787
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Pre Function Initialization
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    # Pre Function Initialization

    # Function Initialization
    f_x_rate_service_0 = FXRateService()
    bool_0 = False
    bool_1 = False
    # Function Initialization End

    # Test Body
    test_list_0 = [Currencies["USD"], Currencies["JPY"], datetime.date.today()]
    queries_result_0 = f_x_rate_service_0.queries(test_list_0, bool_0)
    queries_result_1 = f_x_rate_service_0.queries(test_list_0, bool_1)
    # Test Body End

    # Assertions
    assert queries_result_0 == queries_result

# Generated at 2022-06-26 00:57:23.170924
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    bool_0 = False
    bool_1 = bool_0
    f_x_rate_0 = f_x_rate_service_0.query(bool_0, bool_1, bool_1, bool_1)
    bool_2 = not bool_0
    assert f_x_rate_0 == f_x_rate_0
    bool_3 = bool_2
    bool_4 = bool_1
    f_x_rate_1 = f_x_rate_service_0.query(bool_3, bool_4, bool_4, bool_3)
    bool_5 = bool_2
    bool_6 = not bool_1

# Generated at 2022-06-26 00:57:35.727000
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    line_0 = ['FXRateService', 'queries']
    line_1 = ['FXRateService', 'default']
    line_2 = ['Currency', 'None']
    list_0 = [line_2, line_2, line_1]
    f_x_rate_0 = FXRate(*list_0)
    list_1 = [f_x_rate_0]
    f_x_rate_service_0 = FXRateService()
    bool_0 = True
    list_2 = f_x_rate_service_0.queries(list_1, bool_0)
    var_0 = 'QUERIES'
    var_1 = 'Strict lookup'
    var_2 = 8
    var_3 = f_x_rate_service_0.queries(list_1, bool_0)


# Generated at 2022-06-26 00:58:11.459501
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # all_keys() returns keys, which is extremely slow. Use all_keys_view().
    obj = FXRateService()
    ccy1 = obj.fx_rates.keys()
    ccy2 = obj.fx_rates[ccy1]
    date = ccy1.date()
    fx_rate = obj.query(ccy1, ccy2, date)
    assert fx_rate is not None, "expected fx_rate to not be None, but got %s" % fx_rate


# Generated at 2022-06-26 00:58:20.463963
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test queries of class FXRateService
    """
    import unittest

    from .currencies import Currencies

    from .temporal import Date

    from . import fx

    from .fx import FXRateService

    from .fx import FXRateLookupError

    from . import market

    from .market import MarketService

    class FBRateService(FXRateService):

        def __init__(self, fx_rates: Iterable[fx.FXRate]) -> None:
            self.fx_rates = tuple(fx_rates)

        def query(self, ccy1: currencies.Currency, ccy2: currencies.Currency, asof: temporal.Temporal, strict: bool = False) -> Optional[fx.FXRate]:
            f_x_rate_service_1 = self
            f_x_rate_0 = f

# Generated at 2022-06-26 00:58:23.895541
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    f_x_rate_service_0 = FXRateService()
    bool_0 = False
    f_x_rate_service_0.query(bool_0, bool_0, bool_0)


# Generated at 2022-06-26 00:58:26.979581
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService
    """
    test_FXRateService_queries_0()
    test_FXRateService_queries_1()


# Generated at 2022-06-26 00:58:33.225587
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Happy path:
    fxrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    fxrates = [fxrate]
    fxrateservice = FXRateService()
    ccy1 = fxrate[0]
    ccy2 = fxrate[1]
    date = fxrate[2]
    strict = True

    # Failure path:
    queries = [(ccy1, ccy2, date)]  # Wrong type: list
    result = fxrateservice.queries(queries, strict)
    assert result == []



# Generated at 2022-06-26 00:58:39.650018
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from ..currencies import Currency
    from ..commons import DATE_TEST
    assert FXRateService.default.query(Currency.CHF, Currency.EUR, DATE_TEST, False) is not None
    assert FXRateService.default.query(Currency.CHF, Currency.EUR, DATE_TEST, True) is not None
    assert FXRateService.default.query(Currency.CHF, Currency.CHF, DATE_TEST, False) is not None
    assert FXRateService.default.query(Currency.CHF, Currency.CHF, DATE_TEST, True) is not None

# Generated at 2022-06-26 00:58:46.624942
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()
    value = Decimal("0.784")
    fxr = FXRate(ccy1, ccy2, asof, value)
    fxrs = [fxr]
    fxrss = FXRateService()
    # fxrss.queries([(ccy1, ccy2, asof)], strict=False)
    fxrss.queries([(ccy1, ccy2, asof)], strict=True)


# Generated at 2022-06-26 00:58:50.785386
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    try:
        f_x_rate_service_0 = FXRateService()
        bool_0 = False
        tuple_0 = (bool_0, bool_0, bool_0)
        list_0 = [tuple_0]
        f_x_rate_service_0.queries(list_0, bool_0)
    except (AttributeError, TypeError):
        pass


# Generated at 2022-06-26 00:58:54.182381
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    list_0 = [1, 1, 1]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_0.query(f_x_rate_0)


# Generated at 2022-06-26 00:59:01.604861
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pytest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    f_x_rate_service_0 = FXRateService()
    # Raise TypeError
    with pytest.raises(TypeError):
        f_x_rate_service_0.queries(Currencies['XCD'], Currencies['BRL'], datetime.date.today())
    # Raise TypeError
    with pytest.raises(TypeError):
        f_x_rate_service_0.queries(Currencies['XCD'], Currencies['BRL'], datetime.date.today(), 1.0)
    f_x_rate_service_1 = FXRateService()
    # Raise TypeError
    with pytest.raises(TypeError):
        f_x_rate_service

# Generated at 2022-06-26 01:00:22.443601
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_service_0 = FXRateService()
    bool_1 = False
    bool_2 = True
    f_x_rate_service_0.queries(iterable=FXRateService.TQuery(bool_1, bool_0, bool_2), strict=bool_2)


# Generated at 2022-06-26 01:00:24.510046
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # param queries
    queries = list()
    # param strict
    strict = False
    FXRateService.queries(queries, strict)


# Generated at 2022-06-26 01:00:31.856116
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    import datetime
    from pypara.services.fxrateservices import InMemoryFXRateService
    f_x_rate_service_0 = InMemoryFXRateService()
    f_x_rate_0 = FXRate(Currencies["USD"], Currencies["USD"], datetime.date.today(), 1.0)
    f_x_rate_service_0.add(f_x_rate_0)
    f_x_rate_1 = f_x_rate_service_0.query(Currencies["USD"], Currencies["EUR"], datetime.date.today())
    pass


# Generated at 2022-06-26 01:00:40.704931
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_service_0 = FXRateService()
    bool_1 = False
    bool_2 = False
    f_x_rate_service_0.queries([(f_x_rate_0, f_x_rate_1, f_x_rate_2)], bool_1)


# Generated at 2022-06-26 01:00:47.588822
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    f_x_rate_4 = FXRate(Currencies["PLN"], Currencies["USD"], Temporal.today(), Decimal("2"))
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_1 = FXRateService()
    f_x_rate_service_1.query(Currencies["PLN"], Currencies["USD"], Temporal.today())
    f_x_rate_service_1.query(Currencies["PLN"], Currencies["USD"], Temporal.today(), False)
    f_x_rate_service_1.query(Currencies["PLN"], Currencies["USD"], Temporal.today(), True)


# Generated at 2022-06-26 01:00:50.409072
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # obj = FXRateService()
    # Iterable[Optional[FXRate]] =
    # obj.queries([], strict=False)
    pass


# Generated at 2022-06-26 01:00:57.526723
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    currency_0 = Currency(code="EUR")
    currency_1 = Currency(code="USD")
    temporal_0 = Date.today()
    f_x_rate_service_0 = FXRateService()
    f_x_rate_service_1 = FXRateService()
    list_0 = [currency_0, currency_1, temporal_0]
    list_1 = [currency_1, currency_0, temporal_0]
    list_2 = [currency_0, currency_0, temporal_0]
    list_3 = [list_0, list_1, list_2]
    list_4 = f_x_rate_service_0.queries(list_3)
    list_5 = f_x_rate_service_1.queries(list_3, True)


# Generated at 2022-06-26 01:01:02.685056
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_service_0 = FXRateService()
    f_x_rate_1 = f_x_rate_service_0.query(f_x_rate_0[0], f_x_rate_0[1], f_x_rate_0[2], True)
    bool_1 = f_x_rate_1 is None


# Generated at 2022-06-26 01:01:09.954001
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    f_x_rate_0 = FXRate(*list_0)
    f_x_rate_1 = f_x_rate_0.__invert__()
    f_x_rate_2 = f_x_rate_1.__invert__()
    f_x_rate_service_0 = FXRateService()
    bool_1 = False
    bool_2 = False
    tuple_0 = (f_x_rate_service_0, bool_1, bool_2)
    list_1 = [tuple_0, tuple_0, tuple_0, tuple_0]
    f_x_rate_service_0.queries(list_1, bool_2)


# Generated at 2022-06-26 01:01:17.672350
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    print("Testing FXRateService.query")
    f_x_rate_2 = FXRate(*[False, False, False, False])
    f_x_rate_service_0 = FXRateService()
    bool_0 = False
    f_x_rate_0 = FXRate(*[bool_0, bool_0, bool_0, bool_0])
    f_x_rate_1 = FXRate.of(Currency, Currency, Date, Decimal)
    f_x_rate_service_0.query(f_x_rate_0.ccy1, f_x_rate_0.ccy2, f_x_rate_0.date)