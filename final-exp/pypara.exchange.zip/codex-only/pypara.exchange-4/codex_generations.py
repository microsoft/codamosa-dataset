

# Generated at 2022-06-24 01:18:36.364952
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .time_series import Series
    from .time_series.series import SeriesLookupError

    import datetime

    class TestSeriesService(Series):
        def query(self, index: Temporal, strict: bool = False) -> Optional[Decimal]:
            return Decimal("1.1") if index.date == datetime.date(2018, 1, 1) else None

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError()


# Generated at 2022-06-24 01:18:49.169323
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from unittest import TestCase
    from pypara.currencies import Currencies
    from pypara.currencies.errors import CurrencyRateNotFoundError
    from pypara.services import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            raise CurrencyRateNotFoundError(ccy1, ccy2, asof)

    ## Set up the mock service:
    service = MockFXRateService()

    ## Arrange:
    ccy1 = Currencies["USD"]
    ccy2 = Currencies

# Generated at 2022-06-24 01:18:56.446815
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:01.220582
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:13.058156
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Case 1:
    rate1 = FXRate(Currencies["USD"], Currencies["USD"], datetime.date.today(), Decimal("1"))
    # In case of assert statement, type hinting in Python 3.6+ for assert statement is broken.
    assert rate1.value == Decimal("1")

    ## Case 2:
    rate2 = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate2.value == Decimal("2")

    ## Case 3:
    try:
        FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("-2"))
    except ValueError:
        pass


# Generated at 2022-06-24 01:19:18.522391
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from pypara.currency import Currency
    from pypara.fx import FXRate
    EUR = Currency(b'EUR')
    USD = Currency(b'USD')
    assert ~FXRate(EUR, USD, 0, 1) == FXRate(USD, EUR, 0, 1)


# Generated at 2022-06-24 01:19:19.363274
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D103
    pass


# Generated at 2022-06-24 01:19:27.223197
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:19:28.756518
# Unit test for constructor of class FXRateService
def test_FXRateService():
    ## Constructor:
    with raises(TypeError):
        FXRateService()


# Generated at 2022-06-24 01:19:35.362125
# Unit test for constructor of class FXRate
def test_FXRate():

    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (nrate == FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")))
    assert (~nrate == rrate)

# Generated at 2022-06-24 01:19:46.252489
# Unit test for method query of class FXRateService

# Generated at 2022-06-24 01:19:53.643007
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import PiecewiseLinearCurve, ZeroRateCurve
    from pypara.types.dates import DaycountBasis, Period

    ## Create an FX rate curve:

# Generated at 2022-06-24 01:19:56.834088
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Test constructor.
    """
    from pypara.currencies import Currencies

    ## Test exception:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    except FXRateLookupError as e:  # noqa: F841
        pass
    else:
        assert False



# Generated at 2022-06-24 01:20:02.300086
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    class Mock(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["USD"]:
                return FXRate(Currencies["USD"], Currencies["USD"], asof, ONE)
            elif ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("1.5"))

# Generated at 2022-06-24 01:20:08.254357
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:20:13.193713
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:20:14.873323
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService.
    """
    FXRateService()

# Generated at 2022-06-24 01:20:24.958411
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Runs unit tests for the class :class:`FXRateService`.
    """
    from .testing import make_temporal

    # fxrates is of type Iterable[Optional[FXRate]]
    FXRateService.queries(fxrates=[])

    fxrates = (
        (Currency.NONE, Currency.NONE, make_temporal(), Decimal("0.99")),
        (Currency.USD, Currency.USD, make_temporal(), Decimal("1")),
        (Currency.EUR, Currency.EUR, make_temporal(), Decimal("1")),
    )

    # fxrates is of type Iterable[Optional[FXRate]]
    FXRateService.queries(fxrates=map(lambda tup: FXRate(*tup), fxrates))


# Generated at 2022-06-24 01:20:27.970857
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:20:34.326507
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate, "Opposite FX rates are not equivalent."



# Generated at 2022-06-24 01:20:39.787096
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import pytest
    from datetime import date
    from pypara.currencies import Currency, Currencies
    with pytest.raises(TypeError):
        class BadFXRateService(FXRateService):
            pass
    class GoodFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: date) -> Optional[Decimal]:
            return None
        def queries(self, queries: Iterable[Tuple[Currency, Currency, Date]]) -> Iterable[Optional[Decimal]]:
            return []
    with pytest.raises(TypeError):
        FXRateService.query(GoodFXRateService, Currencies['EUR'], Currencies['CHF'], date.today())

# Generated at 2022-06-24 01:20:45.257849
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for the constructor of class FXRateLookupError.
    """
    from .currencies import Currencies
    from .temporal import Date

    ## Create the error object:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date("2020-01-01"))

    ## Check type and message for the object:
    assert isinstance(error, FXRateLookupError)
    assert isinstance(error, LookupError)
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2020-01-01"


# Generated at 2022-06-24 01:20:47.271063
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Temporal
    try:
        raise FXRateLookupError(Currencies["USD"], Currencies["EUR"], Temporal.asof())
    except FXRateLookupError as err:
        assert str(err) == "Foreign exchange rate for USD/EUR not found as of today"


# Generated at 2022-06-24 01:20:54.523830
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from .currencies import EUR, USD, NZD
    from .temporal import Date, today
    from .fx import FXRate

    import pytest

    from .fx import FXRateLookupError

    class NullFXRateService(FXRateService):

        def __init__(self):
            super().__init__()

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    # 1. Test invalid arguments:
    svc = NullFXRateService()
    assert(svc.query(None, None, None) is None)

    # 2. Test that the default FX rate service raises a

# Generated at 2022-06-24 01:21:00.831819
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:09.418563
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests :method:`FXRateService.query` method.
    """

    ## Create a foreign exchange rate service:
    from pypara.services.fxrates import DummyFXRateService
    service = DummyFXRateService()

    ## Note that for the unit test, we are using 'None' as the strict argument.
    ## This is because we want to see the behaviour of the method in both cases.
    ## In real life, you would never use 'None' as the strict parameter.
    rate = service.query(Currency("EUR"), Currency("USD"), Date(2018, 1, 1))
    assert rate == FXRate(Currency("EUR"), Currency("USD"), Date(2018, 1, 1), Decimal("1.123"))


# Generated at 2022-06-24 01:21:16.382817
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """

    from datetime import date

    from pypara.currencies import Currencies

    from pypara.services.in_memory.fxrate import InMemoryFXRateService

    # Create an FXRate service
    service = InMemoryFXRateService(
        FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 1), Decimal("1.1")),
        FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 2), Decimal("1.2")),
        FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 3), Decimal("1.3"))
     )

    # Query the FXRate service

# Generated at 2022-06-24 01:21:20.862640
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of :class:`FXRateLookupError`.
    """
    from .commons.zeitgeist import TODAY
    from .currencies import Currencies

    ## Build a foreign exchange rate lookup error instance:
    err = FXRateLookupError(Currencies["EUR"], Currencies["USD"], TODAY)

    ## Check properties:
    assert err.ccy1 == Currencies["EUR"]
    assert err.ccy2 == Currencies["USD"]
    assert err.asof == TODAY

    ## Check error message:
    assert str(err) == "Foreign exchange rate for EUR/USD not found as of 2018-01-01"



# Generated at 2022-06-24 01:21:21.614556
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    pass

# Generated at 2022-06-24 01:21:26.564515
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # ~~> Expected outcome
    with pytest.raises(TypeError):
        FXRateService()  # pragma: no cover

# Generated at 2022-06-24 01:21:37.573028
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # Import
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import FxRateCurve

    # Create the curve
    curve = FxRateCurve()

    # Add a few rates
    curve.add(Currencies.EUR, Currencies.USD, "2018-01-02", Decimal("1.1"))
    curve.add(Currencies.EUR, Currencies.USD, "2018-01-03", Decimal("1.2"))
    curve.add(Currencies.EUR, Currencies.USD, "2018-01-04", Decimal("1.3"))
    curve.add(Currencies.EUR, Currencies.USD, "2018-01-05", Decimal("1.4"))

# Generated at 2022-06-24 01:21:43.966917
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()
    nrate = FXRate(ccy1, ccy2, asof, Decimal("2"))
    rrate = FXRate(ccy2, ccy1, asof, Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:21:56.225660
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the FXRateService.query method.
    """

    from .commons.zeitgeist import Temporal
    from .currencies import Currency, CurrencySet

    ## Create a DUMMIE FX rate service:
    class DummyFXRateService(FXRateService):
        """
        Defines a dummy FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            ## Filter out cases that would raise a ValueError:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)

# Generated at 2022-06-24 01:22:05.072130
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from datetime import date
    from decimal import Decimal
    import pytest
    from pypara.fx.services import InMemoryFXRateService

    FXRateService.default = InMemoryFXRateService(
        [
            FXRate(Currencies["USD"], Currencies["EUR"], date(2017, 12, 31), Decimal("0.83638")),
            FXRate(Currencies["EUR"], Currencies["USD"], date(2017, 12, 31), Decimal("1.19357")),
        ]
    )
    assert FXRateService.default.query(Currencies["EUR"], Currencies["USD"], date(2017, 12, 31)) == FXRate(
        Currencies["EUR"], Currencies["USD"], date(2017, 12, 31), Decimal("1.19357")
    )

# Generated at 2022-06-24 01:22:10.660273
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.exchange import FXRate, FXRateLookupError

    class FXRateTests(unittest.TestCase):
        def test_FXRate___invert__(self):
            nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
            self.assertTrue(~nrate == rrate)
    unittest.main()


# Generated at 2022-06-24 01:22:16.310068
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # Test for abstract class
    assert FXRateService.__abstractmethods__ != set()
    # Test import
    from pypara.fxrates.services import FXRateService

# Generated at 2022-06-24 01:22:22.906187
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    fxrates = {
        (Currencies["EUR"], Currencies["USD"], Date("2018-01-01")): Decimal("1.23"),
        (Currencies["EUR"], Currencies["USD"], Date("2018-01-02")): Decimal("2.34"),
        (Currencies["EUR"], Currencies["USD"], Date("2018-01-03")): Decimal("3.45")
    }

    class FxRateService(FXRateService):
        """
        A mock FX rate service.
        """


# Generated at 2022-06-24 01:22:25.742375
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:31.698768
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)



# Generated at 2022-06-24 01:22:39.198110
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies, Currency
    from datetime import date
    ccy1 = Currency.of("EUR", "EUR")
    ccy2 = Currency.of("USD", "USD")
    asof = date.today()
    message = "Foreign exchange rate for EUR/USD not found as of " + str(asof)
    exception = FXRateLookupError(ccy1, ccy2, asof)
    assert(str(exception) == message)


# Generated at 2022-06-24 01:22:40.282761
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.__init__


# Generated at 2022-06-24 01:22:50.439931
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from datetime import date
    from pypara.currencies import Currencies

    exc = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.from_string("2017-01-01"))
    assert exc.ccy1 == Currencies["EUR"]
    assert exc.ccy2 == Currencies["USD"]
    assert exc.asof == Date.from_string("2017-01-01")
    assert exc.args == (
        'Foreign exchange rate for Euro/United States Dollar not found as of 2017-01-01 00:00:00',
    )


# Unit tests for method __invert__ of class FXRate

# Generated at 2022-06-24 01:22:51.633041
# Unit test for constructor of class FXRateService
def test_FXRateService():
    def fx_rate_service(): pass
    assert fx_rate_service() is None


# Generated at 2022-06-24 01:23:02.047563
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency

    class FXRateServiceImpl(FXRateService):
        """
        Provides an implementation of :class:`FXRateService` for testing.
        """


# Generated at 2022-06-24 01:23:13.245514
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import unittest as ut
    import datetime as dt
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .commons.zeitgeist import Temporal, Date

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == dt.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal(2))

# Generated at 2022-06-24 01:23:19.139220
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # pylint: disable=missing-docstring
    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    FXRateServiceImpl()


# Generated at 2022-06-24 01:23:29.429525
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test queries method of FXRateService
    """
    from pypara.fxrates import FXRates, FXRatesService
    from .currencies import Currencies

    service = FXRatesService(FXRates.of(["EUR", "USD"], [Date(1, 1, 2019), Date(2, 1, 2019)],
                                        [ONE, ONE.ONE]))

    expected_rates = [FXRate(Currencies["EUR"], Currencies["USD"], Date(1, 1, 2019), ONE),
                      FXRate(Currencies["EUR"], Currencies["USD"], Date(2, 1, 2019), ONE.ONE)]


# Generated at 2022-06-24 01:23:32.832983
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:23:33.457737
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-24 01:23:41.870876
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.model import FXRate
    from pypara.services import MemoryFXRateService, FXRateLookupError

    rates = [
        FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 12, 23), Decimal("2")),
        FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 2), Decimal("1.9")),
        FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 15), Decimal("1.8")),
    ]

    service = MemoryFXRateService(rates)

# Generated at 2022-06-24 01:23:47.890995
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Add a dummy fxrate service
    from .utils.testing import DummyService
    FXRateService.default = DummyService

    # Test queries method
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Temporal, Temporals
    queries = [(Currencies["EUR"], Currencies["USD"], Temporals.now())]
    assert list(FXRateService.default.queries(queries)) == [None]


# Generated at 2022-06-24 01:23:59.044009
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests multiple queries functionality of an FX rate service.

    >>> import datetime
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currencies
    >>> from pypara.fx import FXRateService
    >>> class NoOpFXRateService(FXRateService):
    ...     def query(self, ccy1, ccy2, asof, strict=False):
    ...         return None
    ...     def queries(self, queries, strict=False):
    ...         return None
    ...
    >>> service = NoOpFXRateService()
    >>> queries = [(Currencies["EUR"], Currencies["USD"], datetime.date.today())] * 1000
    >>> results = service.queries(queries)
    >>> len(results) == len(queries)
    True
    """
    pass

# Generated at 2022-06-24 01:24:11.122543
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests method __invert__ of class FXRate.
    """

    from unittest import TestCase, main

    ## Test class:
    class FXRateTest(TestCase):

        def setUp(self):
            self.date = Date.parse("2018-11-18")
            self.eur = Currency("EUR")
            self.usd = Currency("USD")

        def test_invert(self):
            fxrate = FXRate(self.eur, self.usd, self.date, Decimal("2"))
            fxrate_inv = FXRate(self.usd, self.eur, self.date, Decimal("0.5"))
            self.assertEqual(fxrate_inv, ~fxrate)

    ## Run the unit tests:
    main()


# Generated at 2022-06-24 01:24:19.693890
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class :class:`FXRateService`.
    """
    import datetime
    from decimal import Decimal
    from typing import Iterable, List, Tuple
    from pypara.currencies import Currencies
    from pypara.currencies.fx import FXRate, FXRateLookupError, FXRateService

    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service.
        """
        __rates: List[FXRate]

        def __init__(self):
            """
            Initializes the dummy FX rate service.
            """

# Generated at 2022-06-24 01:24:32.117167
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.forex import FXRateService
    from collections import namedtuple

    class MyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))
            return None


# Generated at 2022-06-24 01:24:44.545261
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    # Imports:
    from decimal import Decimal
    import datetime
    from pypara.currencies import Currencies

    # Test:
    class MockFXRateService(FXRateService):  # noqa: N801
        def __init__(self, *ranges: Tuple[Date, Date, Decimal]) -> None:
            self.ranges = ranges


# Generated at 2022-06-24 01:24:51.112213
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and date == datetime.date.today() \
        and value == Decimal("2")


# Generated at 2022-06-24 01:24:56.100288
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:25:00.814833
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)

# Generated at 2022-06-24 01:25:04.897973
# Unit test for constructor of class FXRateService
def test_FXRateService():
    try:
        assert issubclass(FXRateService, ABCMeta)
        assert issubclass(FXRateService, ABCMeta)
        assert FXRateService.__abstractmethods__
        assert FXRateService.query.__isabstractmethod__
        assert FXRateService.queries.__isabstractmethod__
    except AssertionError:
        print("FXRateService Init Failed")
        raise
    print("FXRateService Init Success")

# Generated at 2022-06-24 01:25:14.018051
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """Unit test for method queries  of class FXRateService"""
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fxrates import FXRateService, FXRateLookupError

    class RateServiceImpl(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == date(2020, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 1), Decimal("0.90"))
            else:
                return None

        def queries(self, queries, strict=False):
            for query in queries:
                yield self.query(*query)

# Generated at 2022-06-24 01:25:17.360233
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0.5"))
    ccy1, ccy2, date, value = rate
    assert (ccy1 == Currencies["EUR"])
    assert (ccy2 == Currencies["USD"])
    assert (date == datetime.date.today())
    assert (value == Decimal("0.5"))


# Generated at 2022-06-24 01:25:27.282258
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    from pypara.currencies.service import CurrencyService

    ## Test init:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert isinstance(e, FXRateLookupError)
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == datetime.date.today()
        assert e.args == ("Foreign exchange rate for EUR/USD not found as of 2020-04-14",)
        assert e.__class__.__name__ == "FXRateLookupError"

# Generated at 2022-06-24 01:25:28.528354
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass
    

# Generated at 2022-06-24 01:25:36.908208
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # pylint: disable=unused-import, unused-argument
    from .services.fx import FXRateService, FXRateNotFoundError
    from .services.fx.yahoo import FXRateService as YahooFXRateService

    def on_error(ccy1: Currency, ccy2: Currency, asof: Date) -> FXRate:  # noqa: E999
        raise FXRateLookupError(ccy1, ccy2, asof)

    service: FXRateService = YahooFXRateService()

    try:
        service.query(Currency("USD"), Currency("TRY"), Date.today())
    except FXRateLookupError as e:
        assert e
        return
    except Exception as e:
        print(e)
        assert False, "Must be raising an `FXRateLookupError`."

# Generated at 2022-06-24 01:25:43.899626
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal

    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Unit test of method FXRate.of

# Generated at 2022-06-24 01:25:47.124883
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["USD"], Currencies["EUR"], date(2010, 1, 1), Decimal("2"))
    print(rate)
    raise NotImplementedError

# Generated at 2022-06-24 01:25:52.348900
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-24 01:26:02.350061
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .service.fx import StaticFXRateService
    from .temporal import Day

    ## Build a service for unit testing:

# Generated at 2022-06-24 01:26:08.416923
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__(): # noqa: D103
    from .currencies import Currencies
    from decimal import Decimal
    import datetime
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:26:16.321545
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:26:23.429550
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """

    from .currencies import Currencies
    from .time.temporals import dates

    ## Check for success:
    test = lambda: FXRateLookupError(Currencies["USD"], Currencies["EUR"], dates.Tomorrow)
    assert test() is not None

    ## Check for failure:
    test = lambda: FXRateLookupError(Currencies["USD"], Currencies["EUR"], dates.Yesterday)
    assert test()


# Generated at 2022-06-24 01:26:29.035948
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Test the constructor of the class FXRate.
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert isinstance(rate, FXRate)


# Generated at 2022-06-24 01:26:30.144919
# Unit test for constructor of class FXRateService
def test_FXRateService():
    FXRateService()


# Generated at 2022-06-24 01:26:35.838322
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class FXRateService.
    """

    # Create FXRateService
    fx_rate_service = FXRateService()

    # Check the type
    assert isinstance(fx_rate_service, FXRateService)

# Generated at 2022-06-24 01:26:44.585603
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    from pypara.temporal import Temporal
    from datetime import date

    ## Reference rates:

# Generated at 2022-06-24 01:26:51.662756
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests method __invert__ of class FXRate.
    """
    # Import required packages:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    # Assert the inversion:
    assert ~FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-24 01:26:52.316923
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:27:00.302876
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate, "Invalid inverted FX rate."


# Generated at 2022-06-24 01:27:09.130849
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """Unit test for constructor of class FXRateLookupError."""
    from pypara.currencies import Currencies
    e = FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date("2000-01-01"))
    assert str(e) == "Foreign exchange rate for USD/EUR not found as of 2000-01-01"
    assert e.ccy1 == Currencies["USD"]
    assert e.ccy2 == Currencies["EUR"]
    assert e.asof == Date("2000-01-01")


# Generated at 2022-06-24 01:27:14.380928
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.numbers import ONE, ZERO
    from .commons.zeitgeist import Date
    from .currencies import Currency
    from .exchanges import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of :class:`FXRateService` for testing purposes.
        """
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currency("TRY") and ccy2 == Currency("USD") and asof == Date(2019, 10, 4):
                return FXRate.of(ccy1, ccy2, asof, Decimal("0.14"))

# Generated at 2022-06-24 01:27:19.821866
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from decimal import Decimal
    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    ccy1 == Currencies["EUR"]
    ccy2 == Currencies["USD"]
    date == datetime.date.today()
    value == Decimal("2")


# Generated at 2022-06-24 01:27:31.261928
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.exchanges.services import FXRateService
    from pypara.futures.contracts import FuturesContract
    from pypara.quotes.services import QuoteService
    from pypara.quotes.types import Quote

    # Create the foreign exchange rate service:

# Generated at 2022-06-24 01:27:37.915478
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import EUR, USD
    from .datetime import date

    subject = FXRateLookupError(EUR, USD, date.today())

    assert isinstance(subject, FXRateLookupError)
    assert isinstance(subject, LookupError)
    assert str(subject) == "Foreign exchange rate for EUR/USD not found as of 2019-04-18"
    assert subject.ccy1 == EUR
    assert subject.ccy2 == USD
    assert subject.asof == date.today()



# Generated at 2022-06-24 01:27:49.676082
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies, Currency
    from pypara.core.temporal import Date, Temporal
    from pypara.core.exchange import FXRateService, FXRate

    ccy1 = Currencies["USD"]
    ccy2 = Currencies["EUR"]
    date = Date(2011, 1, 1)
    rate = FXRate(ccy1, ccy2, date, Decimal(0.5))

    class TestService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return rate

    queries = [(ccy1, ccy2, date)]
    service = TestService()

    assert [rate] == list(service.queries(queries))

# Generated at 2022-06-24 01:27:54.703142
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.zeitgeist import today
    from .currencies import Currency

    # Set up a mock FX rate service:
    from unittest.mock import Mock
    svc = Mock(FXRateService)

    # Test that mock service will raise FXRateLookupError when not found:
    svc.configure_mock(query=lambda ccy1, ccy2, asof, strict=False: None if strict else (ccy1, ccy2, asof, ZERO))

    # Query EUR/USD as of today:
    ccy1, ccy2, asof = Currency("EUR"), Currency("USD"), today()

    # Try to fetch a rate with strict lookup:
    assert svc.query(ccy1, ccy2, asof, strict=True) is None

    # Try to fetch a rate without

# Generated at 2022-06-24 01:27:57.477758
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currency, Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of {}".format(datetime.date.today())

# Generated at 2022-06-24 01:28:09.685401
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Setup:
    from .currencies import Currencies
    from .dates import Date
    from .exceptions import MarketDataError
    from .market_data import MarketData
    from .market_data_frameworks import MarketDataFrameworks
    from .services import Services

    # Setup the testing framework:
    ccy1, ccy2 = Currencies["USD"], Currencies["GBP"]
    query = (ccy1, ccy2, Date.now())
    result = FXRate(ccy1, ccy2, Date.today(), Decimal("6"))
    md = MarketData(MarketDataFrameworks.yfinance, Services.FXRateServices)
    provider = md.providers["FXRate"]["YFinance"]

    # Test: Run queries with a non-existing provider

# Generated at 2022-06-24 01:28:10.721314
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass



# Generated at 2022-06-24 01:28:16.511070
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class MyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    m = MyService()
    assert isinstance(m, MyService)


# Generated at 2022-06-24 01:28:27.355720
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from pypara.commons.zeitgeist import Date

    asof = Date.of("2012-07-20")
    fxerr = FXRateLookupError(Currencies["EUR"], Currencies["USD"], asof)
    assert str(fxerr) == "Foreign exchange rate for EUR/USD not found as of 2012-07-20"  # noqa: E704

    assert fxerr.ccy1 == Currencies["EUR"]  # noqa: E704
    assert fxerr.ccy2 == Currencies["USD"]  # noqa: E704
    assert fxerr.asof == asof  # noqa: E704
