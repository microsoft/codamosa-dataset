

# Generated at 2022-06-24 01:18:32.794075
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.curves import FXRates

    lookup_error = FXRateLookupError(Currencies["AUD"], Currencies["JPY"], date(2018, 1, 1))
    assert lookup_error.ccy1 == Currencies["AUD"] and lookup_error.ccy2 == Currencies["JPY"]
    assert lookup_error.asof == date(2018, 1, 1)


# Generated at 2022-06-24 01:18:41.763060
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    import decimal
    import pytest

    from pypara.currencies import Currencies

    # Test the constructor of class FXRate
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), decimal.Decimal('2')).value == \
        decimal.Decimal('2')

    # Check if the constructor of class FXRate raises an exception when invalid values are used
    with pytest.raises(ValueError):
        FXRate('A', 'B', datetime.date.today(), decimal.Decimal('2'))

# Generated at 2022-06-24 01:18:47.109595
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    from .testing.fixtures import TicTacToe, TestFXRates
    from .currencies import Currencies
    from .commons.zeitgeist import Dates
    from .commons.numbers import ONE, TWO

    ## No default FX rate services and FX rate not found:
    TicTacToe.reset()
    rates = TestFXRates.instance()
    FXRateService.default = None

    ## FX rate to the same currency must always be one:
    assert rates.query(Currencies["USD"], Currencies["USD"], Dates.today(), strict=True) == ONE
    assert rates.query(Currencies["USD"], Currencies["USD"], Dates.today(), strict=False) == ONE

    ## Try to find a valid rate:
    assert rates.query

# Generated at 2022-06-24 01:18:59.050477
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.forex.fxrate import FXRate, FXRateLookupError
    from pypara.forex.fxrateservice import FXRateService

    class FXRateServiceMock(FXRateService):
        """
        Mocks :class:`FXRateService`.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-24 01:19:11.562806
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency, Currencies
    from .datetime import Temporal, Month, Date
    from .fxrates import FXRate
    from .timegen import TimeGenerator
    from .timeseries import TimeSeries

    class TestFXRateService(FXRateService):

        def __init__(self, rates: TimeSeries[Date, FXRate]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            if asof not in self.rates.keys():
                return None
            return self.rates[asof]


# Generated at 2022-06-24 01:19:22.243231
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Create a query:
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Temporal

# Generated at 2022-06-24 01:19:25.052489
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import doctest
    doctest.testmod(name="__invert__", optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS, extraglobs=dict())


# Generated at 2022-06-24 01:19:34.645142
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")
    assert rate.ccy1 == rate[0]
    assert rate.ccy2 == rate[1]
    assert rate.date == rate[2]
    assert rate.value == rate[3]


# Generated at 2022-06-24 01:19:45.601332
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    import datetime

    ## Setup the service:
    class DummyRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            elif ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None


# Generated at 2022-06-24 01:19:52.836634
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from .currencies import Currencies

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    rate = Decimal("2")
    fxrate = FXRate(ccy1, ccy2, Date(2018, 1, 1), rate)

    assert fxrate.ccy1 == ccy1
    assert fxrate.ccy2 == ccy2
    assert fxrate.date == Date(2018, 1, 1)
    assert fxrate.value == rate



# Generated at 2022-06-24 01:19:54.311323
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    This function unit tests the constructors of class FXRateService
    """
    assert FXRateService

# Test for constructor of class FXRateLookupError

# Generated at 2022-06-24 01:19:57.870733
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as ex:
        assert ex.args[0] == "Foreign exchange rate for EUR/USD not found as of 2016-12-25"
        assert ex.ccy1 == Currencies["EUR"]
        assert ex.ccy2 == Currencies["USD"]
        assert ex.asof == datetime.date.today()


# Generated at 2022-06-24 01:20:03.810185
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:04.863320
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None
    assert FXRateService.TQuery.__name__ == "TQuery"


# Generated at 2022-06-24 01:20:12.151682
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:20:22.139218
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import date
    from .quantities import Quantity

    ## Define a currency pair and date:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = date(2020, 1, 1)

    ## Create an instance:
    error = FXRateLookupError(ccy1, ccy2, date)

    ## Check the exception message:
    assert str(error) == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {date}"

    ## Check the instance properties:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == date


# Generated at 2022-06-24 01:20:27.228010
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    eur = Currency.of("EUR")
    usd = Currency.of("USD")
    today = Date.today()
    e = FXRateLookupError(eur, usd, today)
    assert e.ccy1 is eur
    assert e.ccy2 is usd
    assert e.asof is today


# Generated at 2022-06-24 01:20:33.865044
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():              # noqa
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:39.035970
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from .currencies import Currency
    from .temporals import Date

    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, 1.)

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(*q, 1.) for q in queries]

    ## Actual tests ##
    ## Assert that FX rate service query method just works:
    from .currencies import Currencies
    from .temporals import Dates

# Generated at 2022-06-24 01:20:44.622928
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == datetime.date.today()
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of " + str(datetime.date.today())


# Generated at 2022-06-24 01:20:50.595506
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .currencies import Currencies
    from .temporals import Today
    from .fxtrades import FXTrade

    from collections import Counter
    from decimal import Decimal
    from decimal import ROUND_HALF_EVEN
    from pytest import raises
    from pytest import mark
    from pytest import param


# Generated at 2022-06-24 01:20:57.140723
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-24 01:21:07.139683
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate
    class a(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            rate = FXRate.of(ccy1, ccy2, asof, Decimal("2"))
            return rate if ccy1!=ccy2 else None

        def queries(self, queries, strict=False):
            yield from map(lambda query: self.query(*query, strict=False), queries)
    querys = [(Currencies["EUR"], Currencies["USD"], datetime.date.today()), (Currencies["EUR"], Currencies["USD"], datetime.date.today())]
    fxrate = a()
    ret=fxrate

# Generated at 2022-06-24 01:21:13.014423
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .commons.numbers import ZERO
    from .commons.zeitgeist import Date
    from decimal import Decimal
    import sys
    try:
        rate = FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))
    except TypeError:
        print(sys.exc_info)


# Generated at 2022-06-24 01:21:20.580303
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .commons.zeitgeist import now
    from .templates import FXRateServiceTemplate, FXRatesTemplate
    import decimal

    # Create the foreign exchange rate service.
    fxrs = FXRateServiceTemplate(FXRatesTemplate())

    # Check arguments.
    try:
        fxrs.query(1, 2, now(0), True)
        raise Exception("Should have raised.")
    except ValueError:
        pass
    try:
        fxrs.query(Currencies["EUR"], "", now(0), True)
        raise Exception("Should have raised.")
    except ValueError:
        pass

# Generated at 2022-06-24 01:21:29.585421
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.tests.helpers.fx_rate_service import TestFXRateService
    from unittest import TestCase, main as ut_main

    # noinspection PyArgumentList
    class TestFXRateServiceImpl(TestFXRateService, TestCase):
        def test_sameness(self):
            self.assertTrue(self.is_same_service(self))
            self.assertFalse(self.is_same_service(None))

    # noinspection PyTypeChecker
    ut_main(module="test_FXRateService")

# Generated at 2022-06-24 01:21:31.255314
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # TODO: Test me
    pass



# Generated at 2022-06-24 01:21:37.663910
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:21:41.784168
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies

    fxerr = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date())
    assert str(fxerr) == "Foreign exchange rate for EUR/USD not found as of today"

# Generated at 2022-06-24 01:21:42.361909
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert True

# Generated at 2022-06-24 01:21:53.920504
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .zeitgeist import Date
    from decimal import Decimal
    from pypara.fxrates import FXRateService, FXRate, FXRateLookupError
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency["BRL"] and ccy2 == Currency["USD"] and asof == Date(2019, 6, 5):
                return FXRate.of(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None
    fx_rate_service = MockFXRateService()

# Generated at 2022-06-24 01:22:04.934828
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.
    """
    # Import libraries:
    import datetime

    # Import testing targets:
    from pypara.currencies import Currencies

    # Test:
    err = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    # Assert:
    assert err.ccy1 == Currencies["EUR"]
    assert err.ccy2 == Currencies["USD"]
    assert err.asof == datetime.date.today()
    assert err.args == (f"Foreign exchange rate for {err.ccy1}/{err.ccy2} not found as of {err.asof}",)



# Generated at 2022-06-24 01:22:09.771280
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:17.003457
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
test_FXRate()


# Generated at 2022-06-24 01:22:23.790962
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests :class:`FXRateService` class.
    """
    # Get the logger:
    import logging
    logger = logging.getLogger(__name__)

    # The code to be tested follows:
    class MockFXRateService(FXRateService):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def query(self, ccy1, ccy2, asof, strict=False):
            pass

        def queries(self, queries, strict=False):
            pass

    # Done:
    logger.info("Done.")


# Generated at 2022-06-24 01:22:32.434389
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError` class.
    """

    ## Create an exception and test it:
    from .currencies import Currencies
    from .commons import Temporals
    lookup_exception = FXRateLookupError(Currencies["USD"], Currencies["JPY"], Temporals.today())
    assert lookup_exception.ccy1 == Currencies["USD"]
    assert lookup_exception.ccy2 == Currencies["JPY"]
    assert lookup_exception.asof == Temporals.today()
    assert lookup_exception.args == ("Foreign exchange rate for USD/JPY not found as of 2020-11-12",)


# Generated at 2022-06-24 01:22:43.742855
# Unit test for constructor of class FXRateService
def test_FXRateService():

    # Import required modules and classes
    from abc import ABC
    import unittest
    from unittest.mock import Mock

    # Here we go ...
    class TestObject(ABC, FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    assert issubclass(TestObject, ABC)
    assert issubclass(TestObject, FXRateService)

    tester = TestObject()
    assert isinstance(tester, ABC)
    assert isinstance(tester, FXRateService)

    # Run tests
    unittest.main()

# Generated at 2022-06-24 01:22:50.554286
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:23:01.104276
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.zeitgeist import Temporal
    from .fx.rateservice import HistoricalFXRateService, LiveFXRateService
    from .currencies import Currencies
    import datetime
    import os
    ccy1, ccy2, ccy3 = Currencies["USD"], Currencies["EUR"], Currencies["GBP"]
    date = Temporal(datetime.date.today())
    fxrate = HistoricalFXRateService(os.path.join(os.path.dirname(os.path.realpath(__file__)), "data/fxdata.csv"))
    rate = fxrate.query(ccy1, ccy2, date, strict=False)
    assert rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.value > ZERO

# Generated at 2022-06-24 01:23:12.135099
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # This test is OK.
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    # Define a test FX rate service:
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof,  ONE)

    # Define the test FX rate service:
    service = TestFXRateService()

    # Assert queries:

# Generated at 2022-06-24 01:23:20.851180
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    from .commons.numbers import ONE
    from .currencies import Currency
    from .temporal import Date
    class test(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            if ccy1 != ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            else:
                return FXRate(ccy1, ccy2, asof, ONE)
        def queries(self, queries, strict):
            return []
    t = test()

# Generated at 2022-06-24 01:23:31.426127
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies, Currency
    from .time import Date

    ccy1: Currency = Currencies["USD"]
    ccy2: Currency = Currencies["TRY"]
    date: Date = Date.today()

    try:
        raise FXRateLookupError(ccy1, ccy2, date)
    except FXRateLookupError as error:
        assert error.ccy1 == ccy1
        assert error.ccy2 == ccy2
        assert error.asof == date
        assert error.args == (f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {date}",)



# Generated at 2022-06-24 01:23:37.425745
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests the :method:`FXRate.__invert__` method.
    """
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate

# Generated at 2022-06-24 01:23:45.446650
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate.of(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    result = ~nrate
    assert result == rrate

# Generated at 2022-06-24 01:23:48.242194
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of the FXRateService class.
    """


# Generated at 2022-06-24 01:23:59.302096
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from datetime import date
    import pytest
    pytest.importorskip("pypara.currencies")
    from pypara.currencies import Currency

    # Negative cases:
    with pytest.raises(ValueError):
        FXRate(None, None, None, None)
    with pytest.raises(ValueError):
        FXRate(Currency.of("USD"), None, None, None)
    with pytest.raises(ValueError):
        FXRate(None, Currency.of("USD"), None, None)
    with pytest.raises(ValueError):
        FXRate(Currency.of("USD"), Currency.of("USD"), None, None)

# Generated at 2022-06-24 01:24:00.232418
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService


# Generated at 2022-06-24 01:24:11.973474
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.marketdata.providers import BuiltinFXRateService
    from pypara.marketdata.providers.types import FXRateTuple
    from pypara.zeitgeist import Date

    # Set up
    service = BuiltinFXRateService()
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))
    query = (rate[0], rate[1], rate[2])
    service.rates.add(FXRateTuple(*rate))

    # Call query method of FXRateService
    rsp_rate = service.query(*query)

    # Assert result
    assert rsp_rate is not None
    assert rsp_rate == rate


# Generated at 2022-06-24 01:24:21.124615
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies

    class FXRateServiceMock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield self.query(*query)

    FXRateServiceMock().queries(
        [(Currencies["EUR"], Currencies["USD"], Date.today()),
         (Currencies["USD"], Currencies["EUR"], Date.today())])


### EOF.EOF.EOF.EOF.EOF.EOF.EOF.EOF.EOF.EOF.EOF.EOF.EOF.

# Generated at 2022-06-24 01:24:27.601692
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D103
    from .commons.zeitgeist import Date
    from .currencies import Currencies
    from .market_refs import FXRates
    fx_rate = FXRateService.default.query(Currencies["EUR"], Currencies["USD"], date=Date.today(), strict=True)
    assert fx_rate == FXRates["EUR/USD"]

# Generated at 2022-06-24 01:24:33.305630
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:45.455679
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from pypara.currencies import Currencies
    from pypara.dates import DateService
    from pypara.fxtrade import FXTrade

    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    other = ~rate
    print(rate, other)

    fx_trade1 = FXTrade(DateService.today(), Currencies["EUR"], ONE, rate)
    fx_trade2 = fx_trade1.fx(other)

    print(fx_trade1)
    print(fx_trade2)

    assert fx_trade1.proceeds.ccy == Currencies["USD"]
    assert fx_trade1.proceeds.amount == Decimal("2")

    assert fx_trade2.proceeds

# Generated at 2022-06-24 01:24:50.571096
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:56.483956
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:25:04.559069
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate, "Inverting a rate should provide the inverse."

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0.5"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("2"))
    assert ~nrate == rrate, "Inverting a rate should provide the inverse."


# Generated at 2022-06-24 01:25:13.061258
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class FXRateLookupError.
    """
    import datetime
    from pypara.currencies import Currencies
    ccy1, ccy2, asof = Currencies['EUR'], Currencies['USD'], datetime.date.today()
    e = FXRateLookupError(ccy1, ccy2, asof)
    assert e.ccy1 == ccy1
    assert e.ccy2 == ccy2
    assert e.asof == asof
    assert str(e) == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}"


# Generated at 2022-06-24 01:25:25.558439
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    class FakeService(FXRateService):
        """
        Provides a dummy foreign exchange rate service.
        """

        def __init__(self, rates):
            self._rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            key = (ccy1, ccy2, asof)
            if key in self._rates:
                return self._rates[key]
            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None


# Generated at 2022-06-24 01:25:32.481725
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:25:35.097814
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """

    # Test empty input
    assert ([], False) == list(FXRateService().queries([]))

    # Test invalid input
    with pytest.raises(ValueError):
        FXRateService().queries([(1, 2, 3)])



# Generated at 2022-06-24 01:25:35.965174
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:25:41.318169
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:25:51.025671
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fin.fx import FXRateLookupError
    lookuperr = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert str(lookuperr) == f"Foreign exchange rate for EUR/USD not found as of {datetime.date.today()}"


# Generated at 2022-06-24 01:25:52.215755
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    raise NotImplementedError()


# Generated at 2022-06-24 01:25:53.374421
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    #TODO
    """
    pass

# Generated at 2022-06-24 01:25:58.052896
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D102
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create a rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    irate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 1, 1), Decimal("2"))

    ## Create a rate service:
    class RT(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return nrate if asof == datetime.date.today() else irate if asof == datetime.date(2018, 1, 1) else None

        def queries(self, queries, strict=False):
            pass


# Generated at 2022-06-24 01:26:09.548136
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for foreign exchange rates querying.
    """
    from .currencies import Currency
    from .temporal import Temporal
    from unittest import TestCase

    ## Create a temporary FX rate service:
    class TempFXRateService(FXRateService):
        """
        Provides a temporary FX rate service.
        """


# Generated at 2022-06-24 01:26:16.059973
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test case for method queries of class FXRateService
    """

    from .currencies import Currencies
    from .temporals.dates import Date as DDate
    from typing import Any

    class TestFXRateService(FXRateService):
        """
        A dummy FX rate service for testing.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == DDate(2017, 12, 31):
                return FXRate(ccy1, ccy2, asof, Decimal(1.25))


# Generated at 2022-06-24 01:26:26.105369
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.zeitgeist import Date
    from .currencies import Currencies
    from .fx import FXRate

    # Imports
    from decimal import Decimal
    from datetime import date

    class QueryService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate.of(ccy1, ccy2, asof, Decimal("2"))

    # Setup
    service = QueryService()

    # Test: query(ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Decimal:
    #   returns the rate of a currency pair as of a given date

# Generated at 2022-06-24 01:26:36.621449
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    #
    # Properties:
    #
    # >>> nrate.ccy1 == Currencies["EUR"]
    # True
    # >>> nrate.ccy2 == Currencies["USD"]
    # True
    # >>> nrate.date == datetime.date.today()
    # True
    # >>> nrate.value == Decimal("2")
    # True

    #
    # Indexed Access:
    #
    # >>> nrate[0]

# Generated at 2022-06-24 01:26:39.103346
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:26:42.338612
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    "Defines test for constructor of class `FXRateLookupError`."
    from .currencies import Currencies # noqa: E402

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    except FXRateLookupError as error:
        assert error.ccy1 == Currencies["EUR"]
        assert error.ccy2 == Currencies["USD"]
        assert error.asof == Date.today()
    else:
        assert False, "exception was not raised"


# Generated at 2022-06-24 01:26:51.488204
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    This unit test is generated via the unit test generator in Zeetick. To regenerate this test, please visit:
    https://github.com/akhavr/zeetick
    """
    from pypara.currencies import Currencies
    from pypara.finmath import Date

    expectedCcy1 = Currencies["EUR"]
    expectedCcy2 = Currencies["USD"]
    expectedAsOf = Date.today()
    expectedMessage = f"Foreign exchange rate for {expectedCcy1}/{expectedCcy2} not found as of {expectedAsOf}"

    error = FXRateLookupError(expectedCcy1, expectedCcy2, expectedAsOf)
    assert expectedMessage == error.args[0]
    assert expectedCcy1 == error.ccy1
    assert expectedCcy2 == error.ccy2


# Generated at 2022-06-24 01:26:55.429142
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    :return: `None`
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# This is the standard boilerplate that calls the main() function.
if __name__ == '__main__':
    test_FXRate___invert__()

# Generated at 2022-06-24 01:26:59.734417
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    msg = "Foreign exchange rate for EUR/USD not found as of 2017-10-10."
    exc = FXRateLookupError(Currency("EUR"), Currency("USD"), Date("2017-10-10"))
    assert str(exc) == msg

# Generated at 2022-06-24 01:27:08.598093
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:27:14.542295
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class :class:`FXRateService`.
    """
    from pypara.fi import FXRateService
    from pypara.currencies import Currency

    # Query for GBP/USD as of 1st of January 2018:
    response = FXRateService.default.find(Currency("GBP"), Currency("USD"), Date(2018, 1, 1))
    print(response)

# Generated at 2022-06-24 01:27:17.444901
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:27:25.447245
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:27:33.289539
# Unit test for constructor of class FXRateService
def test_FXRateService():
    ## Import for test:
    from ..currencies import Currencies
    from ..commons.zeitgeist import now

    ## Construct FX rate service:
    fxrs = FXRateService()

    ## Test the abstract methods:
    assert fxrs.query(Currencies["EUR"], Currencies["USD"], now()) is None
    assert list(fxrs.queries([(Currencies["EUR"], Currencies["USD"], now())], False)) == [None]

# Generated at 2022-06-24 01:27:40.810463
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .fxrates.dummy import DummyFXRateService
    from .currencies import Currencies, Currency
    from .commons.zeitgeist import LocalDate

    # Initialize an FX rate service instance

# Generated at 2022-06-24 01:27:45.420141
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    try:
        FXRateService(Currencies["EUR"], Currencies["USD"], date.today(), ONE)

        assert False, "Expected a `ValueError` exception to be raised."

    except ValueError as e:
        assert str(e) == "FX rate value can not be equal to or less than `zero`.", "Unexpected error message."


# Generated at 2022-06-24 01:27:50.378339
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:27:54.879544
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from datetime import date
    from pypara.currencies import Currencies
    exception = FXRateLookupError(Currencies["EUR"], Currencies["USD"], date.today())
    assert exception.ccy1 == Currencies["EUR"]
    assert exception.ccy2 == Currencies["USD"]
    assert exception.asof == date.today()


# Generated at 2022-06-24 01:28:05.885427
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    class FXRateService_query(FXRateService):
        """
        Provides an implementation of foreign exchange service for unit testing.
        """

        def __init__(self, fxrates: Iterable[FXRate]) -> None:
            """
            Initializes the FX rate service.
            """
            self._fxrates = fxrates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            for fxrate in self._fxrates:
                if fxrate[0] == ccy1 and fxrate[1] == ccy2 and fxrate[2] <= asof:
                    return fxrate

            if strict:
                raise

# Generated at 2022-06-24 01:28:13.340822
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:28:18.810590
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Period
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Period.now().begin)
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == Period.now().begin


# Generated at 2022-06-24 01:28:19.552478
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    pass


# Generated at 2022-06-24 01:28:21.870062
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None
    assert FXRateService.TQuery is tuple

# Generated at 2022-06-24 01:28:29.624136
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method 'query' of class 'FXRateService'
    """
    # Test preparation
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    from pypara.finance.temporals import Periods
    fx_rate_service = Mock(FXRateService)