

# Generated at 2022-06-24 01:18:30.237563
# Unit test for constructor of class FXRateService
def test_FXRateService():
    try:
        FXRateService()
        raise ValueError("Type FXRateService is not abstract.")
    except TypeError:
        pass
    except BaseException as e:
        raise e

# Generated at 2022-06-24 01:18:35.191078
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:18:47.890421
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .markets import Markets
    from .temporals import Time
    from .timeseries import TimeSeries
    from .value import Amount
    import datetime
    from decimal import Decimal

    ## Create the timeseries:
    times = [datetime.date(2017, 9, 1), datetime.date(2017, 9, 2), datetime.date(2017, 9, 3)]
    data = [10, 11, 12]
    svc = Markets.get_fx_service(Currencies["EUR"], Currencies["USD"])
    series = TimeSeries.from_tuples(times, data)

    ## Query the foreign exchange rate with a date value:

# Generated at 2022-06-24 01:18:59.800148
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from . import currencies as ccy
    from . import zeitgeist as t
    from .fxrates import DataFeedFXRateService

    ## Create the rate service:
    rates = DataFeedFXRateService()

    ## Test the cases:
    queries = [(ccy.EUR, ccy.USD, t.Date(2018, 6, 22)), (ccy.USD, ccy.EUR, t.Date(2018, 6, 22))]
    results = rates.queries(queries)
    assert results == [
        FXRate(ccy.EUR, ccy.USD, t.Date(2018, 6, 22), Decimal("1.1800")),
        FXRate(ccy.USD, ccy.EUR, t.Date(2018, 6, 22), Decimal("0.8475")),
    ]

    ## Test with

# Generated at 2022-06-24 01:19:01.260418
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    raise NotImplementedError()


# Generated at 2022-06-24 01:19:02.951061
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    assert str(FXRateLookupError(Currency(), Currency(), Date.today())) == "Foreign exchange rate for currencycode//currencycode not found as of 2000-01-01"


# Generated at 2022-06-24 01:19:15.049108
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    from .currencies import Currencies
    from .services.memory import MemoryFXRateService
    from .services.loader import FXRateLoader
    from .services.smart import SmartFXRateService

    ## Create a service:
    loader = FXRateLoader("./pypara/tests/data/rates.csv")
    memory = MemoryFXRateService(loader)
    service = SmartFXRateService(memory)

    ## Define a query:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = Date(2018, 1, 29)

    ## Query a rate:
    rate = service.query(ccy1, ccy2, date)
    assert rate is not None
    assert rate.ccy1 == ccy1


# Generated at 2022-06-24 01:19:21.253620
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:19:30.616743
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.exchanges import FXRateLookupError
    from pypara.commons.zeitgeist import Date

    ## Initialize the error:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Date(2018, 10, 1)
    error = FXRateLookupError(ccy1, ccy2, asof)

    ## Check the error:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2018-10-01"



# Generated at 2022-06-24 01:19:34.731341
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # Note that there is no way to test the abstract class, just instantiation check:
    try:
        FXRateService()
    except TypeError:
        pass
    else:
        raise AssertionError("Abstract class `FXRateService` can be instantiated")


# Generated at 2022-06-24 01:19:45.696820
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from os import path
    from pypara.fx.rates import CSVFXRateService
    from pypara.currencies import Currencies

    # get the directory this module is in.
    current_module = path.dirname(__file__)

    # initialize the FX rate service from a test rates file
    fx_rates = CSVFXRateService(path.join(current_module, "data", "test_fx_rates.csv"))


# Generated at 2022-06-24 01:19:50.195882
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    from .currencies import Currencies
    from .temporal import Date

    from .fx.rate import FXRateService

    fx = FXRateService()
    assert fx.query(Currencies["EUR"], Currencies["USD"], Date(2019, 8, 31)) == ONE

# Generated at 2022-06-24 01:20:00.131043
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.

    :return: `None`
    :rtype: None
    """
    from unittest import TestCase, mock

    ## Define a mock class that provides a method queries:
    class FXRateServiceMock(FXRateService):
        def queries(self, queries, strict=False):
            for query in queries:
                yield FXRate(query[0], query[1], query[2], Decimal(2))

    ## Test the method:
    queries = [(Currency("TRY"), Currency("USD"), Date(2018, 1, 1)),
               (Currency("EUR"), Currency("USD"), Date(2018, 1, 2))]
    rates = list(FXRateServiceMock().queries(queries))
    assert queries[0][0] == rates[0].ccy1


# Generated at 2022-06-24 01:20:04.904965
# Unit test for constructor of class FXRate
def test_FXRate():

    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == FXRate.of(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")
    )


# Generated at 2022-06-24 01:20:10.196560
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .fx.services import DummyFXRateService
    svc = DummyFXRateService()
    assert svc is not None

if __name__ == "__main__":
    test_FXRateService()

# Generated at 2022-06-24 01:20:15.623950
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and date == datetime.date.today() and value == Decimal("2")


# Generated at 2022-06-24 01:20:25.802680
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Date(2018, 1, 1)
    value = Decimal("2")

    fx1 = FXRate(ccy1, ccy2, asof, value)
    fx2 = FXRate(ccy2, ccy1, asof, value ** -1)

    assert fx1[0] == ccy1
    assert fx1[1] == ccy2
    assert fx1[2] == asof
    assert fx1[3] == value
    assert ~fx1 == fx2



# Generated at 2022-06-24 01:20:28.686772
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit tests :class:`Q.FXRate` class.
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 01:20:33.545463
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:20:42.519003
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.money import Money
    import datetime

    assert ~FXRate(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")
    ) == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~FXRate(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")
    ) == ~Money(Currencies["USD"], Decimal(200))

    assert ~FXRate(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")
    ) == ~Money(Currencies["EUR"], Decimal(100))

# Generated at 2022-06-24 01:20:51.184416
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    queries = [(Currencies["EUR"], Currencies["USD"], datetime.date.today())]

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] \
                    and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            rates = []

# Generated at 2022-06-24 01:21:02.168140
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit tests method queries of class FXRateService
    """

    ## Import the modules under test
    import pytest
    from pypara.currencies import Currency
    from pypara.currencies import CurrencyLookupError
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateLookupError
    from pypara.fxrates import FXRateService

    # Define a stub FX rate service
    class StubFXRateService(FXRateService):
        def __init__(self, rates: Iterable[Optional[str]]) -> None:
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None


# Generated at 2022-06-24 01:21:09.797773
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Verifies that the constructor of `FXRate` works as expected.
    """
    import datetime

    from decimal import Decimal

    from .currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:21:15.744962
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.currencies import Currency
    from pypara.datetime import Date

    X = FXRateService()

    # Check the type is correct
    assert type(X) is FXRateService
    assert issubclass(type(X), FXRateService)
    assert isinstance(X, FXRateService)

    # Check the abstract methods are implemented
    assert FXRateService.__abstractmethods__ == {'query', 'queries'}
    assert X.query(Currency("EUR"), Currency("USD"), Date.today()) is None
    assert X.queries(((Currency("EUR"), Currency("USD"), Date.today()),)) is None


# Generated at 2022-06-24 01:21:24.967323
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the :meth:`FXRateService.queries` method.
    """
    ## Dummy implementation of the class:
    from pypara.currencies import Currencies
    from pypara.utils import Temporal
    from .fxtypes import FXRate
    from typing import Tuple, Iterable


    class DummyFXRateService(FXRateService):
        """
        A dummy FX rate service for testing purposes.
        """
        def query(self, ccy1: Currencies, ccy2: Currencies, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[Tuple[Currencies, Currencies, Temporal]],
                    strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    ## Test

# Generated at 2022-06-24 01:21:31.678748
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:43.190480
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    from pypara.currencies import Currencies, Currency
    import datetime, unittest

    class MockFXRateService(FXRateService):
        """
        Provides a mock foreign exchange rate service.
        """

        def __init__(self, rates: Iterable[FXRate]):
            super().__init__()
            self.__rates = rates

        def query(self, ccy1, ccy2, asof, strict=False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            for rate in self.__rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date <= asof:
                    return rate


# Generated at 2022-06-24 01:21:55.101981
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create an FX rate instance
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Access properties of the FX rate instance:
    if not rate[0] == Currencies["EUR"]:
        raise AssertionError("Currency is not retrieved successfully.")
    if not rate[1] == Currencies["USD"]:
        raise AssertionError("Currency is not retrieved successfully.")
    if not rate[2] == datetime.date.today():
        raise AssertionError("AsOf date is not retrieved successfully.")
    if not rate[3] == Decimal("2"):
        raise AssertionError("FX rate value is not retrieved successfully.")


#

# Generated at 2022-06-24 01:22:01.470791
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today()).ccy1 == Currencies["EUR"]
    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today()).ccy2 == Currencies["USD"]
    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today()).asof == datetime.date.today()



# Generated at 2022-06-24 01:22:07.334464
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # pylint: disable=too-few-public-methods
    class FXRateServiceStub(FXRateService):
        """
        Provides a stub class for testing :class:`FXRateService`.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            pass

        def queries(self, queries, strict=False):
            pass
    # pylint: enable=too-few-public-methods
    FXRateServiceStub()

# Generated at 2022-06-24 01:22:15.534589
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .types import Date
    from .services import FXRateService

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof):
            return None

        def queries(self, queries):
            return []

    tfxr = TestFXRateService()
    assert tfxr.query(Currencies["USD"], Currencies["EUR"], Date(2018, 1, 1)) is None


# Generated at 2022-06-24 01:22:20.166742
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date

    eur, usd, asof = Currencies["EUR"], Currencies["USD"], Date.today()
    error = FXRateLookupError(eur, usd, asof)
    assert error.ccy1 == eur
    assert error.ccy2 == usd
    assert error.asof == asof


# Generated at 2022-06-24 01:22:28.910273
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests the method __invert__ of class FXRate.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:34.143827
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class FXRateServiceImpl(FXRateService):
        def __init__(self):
            super().__init__()

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    FXRateServiceImpl()

# Generated at 2022-06-24 01:22:41.898395
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:22:45.000779
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class :class:`FXRateService`.
    """
    assert FXRateService.default is None

# Generated at 2022-06-24 01:22:49.658956
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    from pypara.market.fx import FXRateLookupError
    assert isinstance(FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        FXRateLookupError)

# Generated at 2022-06-24 01:23:00.347042
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    from pypara.fx import FXRateService, FXRateLookupError

    class Testable(FXRateService):

        def query(self, ccy1, ccy2, asof, strict):
            if date(2020, 1, 1) <= asof.tomorrow() < date(2020, 1, 3):
                return FXRate(ccy1, ccy2, asof, Decimal("1"))
            elif date(2020, 1, 3) <= asof.tomorrow() < date(2020, 1, 5):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-24 01:23:11.786996
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara import currenciestestdata
    from pypara.temporal import DateTime
    from pypara.datetimeextensions import to_date

    ## Create some FX rates:

# Generated at 2022-06-24 01:23:20.145935
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")
    assert (ccy1, ccy2, date, value) == rate
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

# Generated at 2022-06-24 01:23:31.713559
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import DateTime
    from .utils import BaseTest

    class MockService (FXRateService):  # noqa: N801
        def query(self, ccy1: Currency, ccy2: Currency, asof: DateTime, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2, asof) in [
                (Currencies["EUR"], Currencies["USD"], DateTime.of(2020, 1, 1)),
            ]:
                return FXRate.of(ccy1, ccy2, asof, Decimal("2"))
            return None

    # Safe query:
    service = MockService()
    result = service.query(Currencies["EUR"], Currencies["USD"], DateTime.of(2020, 1, 1))

# Generated at 2022-06-24 01:23:33.310974
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None, "default FX rate service is not defined"



# Generated at 2022-06-24 01:23:38.279706
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from .currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:23:41.912432
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of FXRateService.
    """
    # TODO: Implement
    pass



# Generated at 2022-06-24 01:23:48.192036
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:23:53.885255
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-24 01:23:59.856452
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:11.740836
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from unittest import mock
    from pypara.currencies import Currencies
    from .temporal import Date

    queries = [
        (Currencies["EUR"], Currencies["USD"], Date.today()),
        (Currencies["USD"], Currencies["EUR"], Date.today()),
    ]

    fx_rate_service = mock.MagicMock()
    fx_rate_service.query = mock.MagicMock(side_effect=[
        FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("1.5")),
        FXRate(Currencies["USD"], Currencies["EUR"], Date.today(), Decimal("0.5")),
    ])

    rates = list(fx_rate_service.queries(queries))

    assert fx_

# Generated at 2022-06-24 01:24:16.327676
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # noinspection PyAbstractClass
    class TestService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass

        def queries(self, queries, strict=False):
            pass

    ts = TestService()
    assert issubclass(TestService, FXRateService)
    assert isinstance(ts, FXRateService)

# Generated at 2022-06-24 01:24:18.150425
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """Unit test for constructor of class FXRateService"""
    assert isinstance(FXRateService(), FXRateService)


# Generated at 2022-06-24 01:24:20.254161
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test method query of class FXRateService.
    """
    pass



# Generated at 2022-06-24 01:24:32.507056
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Date
    from .fx import FXRateLookupError

    ## Empty initialization:
    assert FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date.today()) is not None

    ## Argument checks:
    try:
        FXRateLookupError(Currencies["USD"], Currencies["EUR"], None)
        assert False, "Should have raised a `TypeError`."
    except TypeError:
        pass

    ## Message check:
    try:
        raise FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date.today())
    except FXRateLookupError as error:
        assert error.ccy1 == Currencies["USD"]
        assert error.ccy2 == Currencies["EUR"]

# Generated at 2022-06-24 01:24:44.893753
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class MyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("2.9"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return iter((
                FXRate.of(ccy1, ccy2, date, Decimal("3.9"))
                for ccy1, ccy2, date in queries
            ))

    service = MyService()

# Generated at 2022-06-24 01:24:50.103985
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit tests :class:`FXRateLookupError` constructor.
    """
    import unittest
    from .currencies import Currency

    ## Create a lookup error:
    raise FXRateLookupError(Currency("EUR"), Currency("USD"), Date("1976-08-03"))



# Generated at 2022-06-24 01:24:55.961341
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = ~rate
    expected = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    actual = rrate
    assert expected == actual


# Generated at 2022-06-24 01:25:04.227770
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class MemoryFXRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]):
            self._rates = dict(((rate.ccy1, rate.ccy2, rate.date), rate) for rate in rates)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            key = (ccy1, ccy2, asof)
            if key in self._rates:
                return self._rates[key]
            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None


# Generated at 2022-06-24 01:25:12.655902
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:25:25.513756
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MockedFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 != Currencies["EUR"] and ccy2 != Currencies["USD"]:
                return None
            elif asof != datetime.date.today():
                return None
            return FXRate(ccy1, ccy2, asof, Decimal("2.5"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield self.query(*query)

    fxrateservice = Mocked

# Generated at 2022-06-24 01:25:33.495024
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, object)
    assert FXRateService.default is None
    assert FXRateService.TQuery is Tuple[Currency, Currency, Date]
    try:
        assert FXRateService.query is not None
    except AttributeError:
        pass
    else:
        raise AssertionError("FXRateService.query should NOT be implemented!")
    try:
        assert FXRateService.queries is not None
    except AttributeError:
        pass
    else:
        raise AssertionError("FXRateService.queries should NOT be implemented!")



# Generated at 2022-06-24 01:25:39.958717
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateLookupError
    from pypara.fx.services_memory import FXRateServiceMemory

    ## Initialize an in-memory FX rate service:
    svc = FXRateServiceMemory()

    ## Add some FX rates:
    svc.add(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    svc.add(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    svc.add(Currencies["EUR"], Currencies["TRY"], datetime.date.today(), Decimal("7"))

# Generated at 2022-06-24 01:25:42.562564
# Unit test for constructor of class FXRate
def test_FXRate():
    ## Constructor
    #noinspection PyProtectedMember
    assert FXRate._fields == ('ccy1', 'ccy2', 'date', 'value')



# Generated at 2022-06-24 01:25:53.022518
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal

    from .currencies import Currencies

    # Create an instance of the class
    rate = FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 8, 18), Decimal("2"))

    # Check the currency first
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]

    # Check the date
    assert rate.date == date(2020, 8, 18)

    # Check the rate
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:26:00.888282
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():  # noqa: D103
    import datetime
    from pypara.currencies import Currencies

    # Constructor should be able to construct:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert isinstance(error, LookupError)

    # Currency 1 should be preserved:
    assert error.ccy1 == Currencies["EUR"]

    # Currency 2 should be preserved:
    assert error.ccy2 == Currencies["USD"]

    # Date should be preserved:
    assert error.asof == datetime.date.today()

# Generated at 2022-06-24 01:26:03.244624
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    with pytest.raises(FXRateLookupError):
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())

# Generated at 2022-06-24 01:26:11.959294
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from unittest import TestCase

    from pypara.currencies import Currencies  # noqa: E402
    from pypara.markets.fx import FXRateService, FXRateLookupError  # noqa: E402

    EUR = Currencies["EUR"]
    USD = Currencies["USD"]
    GBP = Currencies["GBP"]


# Generated at 2022-06-24 01:26:24.772233
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            if ccy1 == Currencies["EUR"] and asof == datetime.date.today():
                return FXRate(ccy1, Currencies["USD"], asof, Decimal("2"))
            if ccy2 == Currencies["EUR"]:
                return ~(self.query(ccy1, Currencies["USD"], asof, strict))
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return

# Generated at 2022-06-24 01:26:31.785644
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:26:43.404098
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    # pylint: disable=unused-variable

    import datetime

    from .currencies import Currencies

    ## Create FX rate lookup errors:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except LookupError:
        pass

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["EUR"], datetime.date.today())
    except LookupError:
        pass

    try:
        raise FXRateLookupError("EUR", Currencies["USD"], datetime.date.today())
    except LookupError:
        pass


# Generated at 2022-06-24 01:26:44.173181
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass
    # TODO

# Generated at 2022-06-24 01:26:53.370017
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This unit test verifies the functionality of the queries method of the FXRateService class.

    >>> import datetime
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currencies
    >>> rates = [FXRateService.TQuery(Currencies["EUR"], Currencies["USD"], datetime.date.today())]
    >>> service = MockFXRateService(rates)
    >>> list(service.queries(rates)) == [FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))]
    True
    >>> list(service.queries(rates, strict=True)) == [FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))]  # noqa: E501
    True
    """
    pass

# Generated at 2022-06-24 01:27:04.050835
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies as CCY
    from .temporals import Temporals as DATE
    from .services.fxrates import InMemoryFXRateService

    ## The FX rate service
    fx = InMemoryFXRateService()

    ## Prepare the lookups:
    queries = ((CCY["EUR"], CCY["USD"], DATE[2018, 9, 21]),
               (CCY["USD"], CCY["EUR"], DATE[2018, 9, 21]),
               (CCY["EUR"], CCY["TRY"], DATE[2018, 9, 21]))

    ## Print the results:
    for q in queries:
        print(q, fx.query(*q))

    ## Print the results (strict mode):
    for q in queries:
        print(q, fx.query(*q, strict=True))

# Generated at 2022-06-24 01:27:11.856895
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:27:17.443925
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:27:28.688465
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests queries method of class FXRateService
    """
    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of FXRateService.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("1"))

    ## Test queries method:

# Generated at 2022-06-24 01:27:30.410525
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    ## No asserts. Just checking if invert works as expected.
    pass


# Generated at 2022-06-24 01:27:40.107857
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate == FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()

# Generated at 2022-06-24 01:27:52.152830
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests if the constructor of FXRateLookupError class works properly.
    """
    from .currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    except FXRateLookupError as error:
        assert error.ccy1 == Currencies["EUR"]
        assert error.ccy2 == Currencies["USD"]
        assert error.asof == Date.today()
        assert error.args[0] == error.__str__()
        assert str(error) == f"Foreign exchange rate for {error.ccy1}/{error.ccy2} not found as of {error.asof}"
    else:
        raise AssertionError("FXRateLookupError constructor did not report an error.")


# Generated at 2022-06-24 01:28:04.488936
# Unit test for method queries of class FXRateService

# Generated at 2022-06-24 01:28:16.278655
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    # Import:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService
    from pypara.temporals import Temporals
    # Initialize a requested date:
    date = datetime.date.today()
    # Initialize a FX rate service:
    class MyFXRateService(FXRateService):
        def __init__(self, *args):
            super().__init__(*args)

# Generated at 2022-06-24 01:28:25.417755
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    nrate = FXRate(
        Currencies["EUR"],
        Currencies["USD"],
        datetime.date.today(),
        Decimal("2")
    )
    rrate = FXRate(
        Currencies["USD"],
        Currencies["EUR"],
        datetime.date.today(),
        Decimal("0.5")
    )
    assert ~nrate == rrate


# Generated at 2022-06-24 01:28:30.714464
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)
