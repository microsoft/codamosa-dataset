

# Generated at 2022-06-24 01:18:33.409540
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from datetime import date

    asof = date(year=2020, month=1, day=1)
    exc = FXRateLookupError(Currencies["EUR"], Currencies["USD"], asof)
    assert exc.ccy1 == Currencies["EUR"]
    assert exc.ccy2 == Currencies["USD"]
    assert exc.asof == asof

# Unit tests for class FXRate

# Generated at 2022-06-24 01:18:46.072103
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import DefaultFXRateService

    service = DefaultFXRateService()
    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1)),
        (Currencies["USD"], Currencies["EUR"], datetime.date(2019, 1, 1)),
        (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 12, 31)),
        (Currencies["USD"], Currencies["EUR"], datetime.date(2019, 12, 31)),
    ]

    for rate in service.queries(queries):
        assert isinstance(rate, FXRate)


# Generated at 2022-06-24 01:18:54.270571
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Test converting singe rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Unit tests for method of of class FXRate

# Generated at 2022-06-24 01:19:01.524580
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    This test unit tests the constructor of class :class:`FXRateLookupError`.
    """
    from datetime import date
    from pypara.currencies import Currencies
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], date(2020, 1, 1))
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == date(2020, 1, 1)
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2020-01-01"


# Generated at 2022-06-24 01:19:08.071296
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:15.589287
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class DerivedFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None
        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    assert issubclass(DerivedFXRateService, FXRateService)
    assert isinstance(DerivedFXRateService(), FXRateService)
    return

# Generated at 2022-06-24 01:19:23.114863
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .exchanges import FXRateServiceFactory
    from .temporal import Temporal

    # Get the service instance
    service = FXRateServiceFactory.new(Currency.USD)

    # Provide a valid currency pair:
    assert service.query(Currency.EUR, Currency.USD, Temporal.today(), strict=False) is not None

    # Provide an invalid currency pair:
    assert service.query(Currency.USD, Currency.EUR, Temporal.today(), strict=False) is None

    # Provide a valid currency pair with a given date:
    assert service.query(Currency.EUR, Currency.USD, Temporal.today().shift(years=-1), strict=False) is not None

    # Provide an invalid currency pair with a given date:

# Generated at 2022-06-24 01:19:33.596873
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime

    from pypara.currencies import Currencies

    from .currencies import Currency
    from .commons.zeitgeist import Date

    ## Initialize the error:
    err = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(datetime.date.today()))

    ## Check the error:
    assert isinstance(err, FXRateLookupError)
    assert isinstance(err, LookupError)
    assert issubclass(FXRateLookupError, LookupError)
    assert issubclass(FXRateLookupError, Exception)
    assert err.ccy1 == Currencies["EUR"]
    assert err.ccy2 == Currencies["USD"]
    assert err.asof == Date(datetime.date.today())

# Generated at 2022-06-24 01:19:36.407320
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    assert issubclass(FXRateService, metaclass=ABCMeta)

# Generated at 2022-06-24 01:19:41.381989
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(rrate == ~nrate)


# Generated at 2022-06-24 01:19:49.619353
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method.

    **Test Scenario**

    - Instantiate a dummy FX rate service.
    - Query foreign exchange rates.
    """

    # Instantiate a dummy FX rate service.
    fx_rates = FXRateService()

    # Query foreign exchange rates.
    rates = list(fx_rates.queries([
        (Currency("EUR"), Currency("USD"), Date("2018-01-05")),
        (Currency("EUR"), Currency("USD"), Date("2018-01-05")),
        (Currency("EUR"), Currency("USD"), Date("2018-01-05"))
    ]))



# Generated at 2022-06-24 01:19:56.402689
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    ## Define a test FX rate class:
    class TestFXRateService(FXRateService):
        """
        Provides a test foreign exchange rate service.
        """

        def __init__(self):
            """
            Initializes the test foreign exchange rate service.
            """
            self.dummy = 1

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            fx_rate = None
           

# Generated at 2022-06-24 01:20:02.898258
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    class TestError(FXRateLookupError):
        pass

    from .currencies import Currencies

    try:
        raise TestError(Currencies.USD, Currencies.EUR, Date.today())
    except TestError as ex:
        assert ex.args[0] == "Foreign exchange rate for USD/EUR not found as of 2012-12-21"

# Generated at 2022-06-24 01:20:07.869420
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    assert isinstance(e, LookupError)
    assert isinstance(e, FXRateLookupError)
    assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2019-07-13"



# Generated at 2022-06-24 01:20:14.852418
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.timing import Temporals

    ## Initialize the FX rates:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Temporals.today, Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], Temporals.today, Decimal("0.5"))
    nrate = ~rate

    ## Check the result:
    assert nrate == rrate
    assert nrate[0] == rrate[0]
    assert nrate[1] == rrate[1]
    assert nrate[2] == rrate[2]
    assert nrate[3] == rrate[3]

    ## Check with mismatching currencies:

# Generated at 2022-06-24 01:20:24.956430
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .currencies import Currencies
    from .time import Time
    from .services.simple_fx_rate_service import SimpleFXRateService
    from .services.parallel_fx_rate_service import ParallelFXRateService

    ## Inputs:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date1 = Time.at("2020-01-01")
    date2 = Time.at("2020-01-02")
    date3 = Time.at("2020-01-03")
    date4 = Time.at("2020-01-04")

    ## Define a dictionary for FX rates:

# Generated at 2022-06-24 01:20:30.856390
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .commons.zeitgeist import Date
    error = FXRateLookupError(Currency("X"), Currency("Y"), Date(2020, 1, 1))
    assert error.ccy1 == Currency("X")
    assert error.ccy2 == Currency("Y")
    assert error.asof == Date(2020, 1, 1)
    assert error.args[0] == "Foreign exchange rate for X/Y not found as of 2020-01-01"



# Generated at 2022-06-24 01:20:37.926075
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    err = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert isinstance(err, LookupError)
    assert isinstance(err, FXRateLookupError)
    assert str(err) == "Foreign exchange rate for EUR/USD not found as of ...TODAY..."


# Generated at 2022-06-24 01:20:49.582873
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests for method querries of class FXRateService.
    """

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    from .commons.zeitgeist import Date

    from .services.dict import DictService


# Generated at 2022-06-24 01:21:00.831504
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.currencies import CurrencyService, CurrencyServiceDefault
    from pypara.commons.zeitgeist import Date, Today
    from pypara.fxrates import FXRate, FXRateService, FXRateServiceDefault
    from pypara.fxrates.sources.dfs import FXRateServiceDFS
    from decimal import Decimal, getcontext

    # Set the decimal context:
    getcontext().prec = 8

    # First create the currency service:
    ccy_service	= CurrencyServiceDefault()

    # Get the rates:

# Generated at 2022-06-24 01:21:10.049075
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the foreign exchange rate query method.
    """
    from ..fx.rates import FXRateAdapter

    ## Initialize a very simple FX rate service:
    fxrate_service = FXRateAdapter()

    ## Query the FX rate from EUR to USD as of today:
    from ..currencies import Currencies
    from ..temporal import Today
    fxrate = fxrate_service.query(Currencies["EUR"], Currencies["USD"], Today)

    ## Check the FX rate:
    fxrate.ccy1 == Currencies["EUR"]
    fxrate.ccy2 == Currencies["USD"]
    fxrate.date == Today
    assert fxrate.value is not None



# Generated at 2022-06-24 01:21:14.133371
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    service = FXRateService()
    ccy1 = Currencies['EUR']
    ccy2 = Currencies['USD']
    date = Date()
    expected = FXRate(ccy1, ccy2, date, Decimal('2'))
    actual = service.query(ccy1, ccy2, date)
    assert actual == expected


# Generated at 2022-06-24 01:21:17.712896
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert(~nrate == rrate)


# Generated at 2022-06-24 01:21:20.400657
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for :class:`FXRateService`.
    """
    import doctest
    doctest.testmod(extraglobs={"FXRateService": FXRateService})

# Generated at 2022-06-24 01:21:23.926179
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:31.344415
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:43.037270
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from datetime import datetime
    from decimal import Decimal

    class TestService(FXRateService):
        def __init__(self, **rates):
            self.rates = rates

        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, Decimal("1"))

            key = (ccy1, ccy2, asof)
            rate = self.rates.get(key)

            if rate is None and strict:
                raise FXRateLookupError(ccy1, ccy2, asof)

            return rate


# Generated at 2022-06-24 01:21:54.908397
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    ##
    ## Define a FX rate service implementation:
    ##

    class TestFXRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]) -> None:
            self._rates: dict = dict([((rate.ccy1, rate.ccy2, rate.date), rate) for rate in rates])


# Generated at 2022-06-24 01:22:03.942108
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from random import seed, randint

    class MyFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return ccy1

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return iter(queries)

    ## Create a random seed:
    seed(0)

    ## Create a random FX rate service:
    fxrateservice = MyFXRateService()

    ## Create a set of queries:
    queries = [tuple([randint(0, 10 ** 9) for _ in range(3)]) for _ in range(1)]

    ## Run the queries:
    results = fxrateservice

# Generated at 2022-06-24 01:22:09.710068
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-24 01:22:19.750895
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    from pypara.zeitgeist import Date

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:22:28.814743
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class FXRateLookupError.
    """
    from .currencies import Currency
    from .commons.zeitgeist import Date
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date(2019, 1, 1)
    error = FXRateLookupError(ccy1, ccy2, asof)
    assert str(error) == f"Foreign exchange rate for EUR/USD not found as of 2019-01-01."


# Generated at 2022-06-24 01:22:34.422607
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    import datetime
    from pypara.currencies import Currencies
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as fxrle:
        assert str(fxrle) == "Foreign exchange rate for EUR/USD not found as of 2019-01-06"


# Generated at 2022-06-24 01:22:44.760501
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    from .currencies import Currencies

    ## Define the currency pair:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    ## Define the effective date:
    from .commons.zeitgeist import Date, NOW
    asof = NOW

    ## Create the service:
    from .services import FXRateServiceImpl
    service = FXRateServiceImpl()

    ## Find the rate:
    rate = service.query(ccy1, ccy2, asof, strict=True)
    if rate is not None:
        assert rate[0] == ccy1
        assert rate[1] == ccy2
        assert rate[2] == asof
        assert rate[3] > ZERO



# Generated at 2022-06-24 01:22:46.641439
# Unit test for constructor of class FXRateService
def test_FXRateService():
    o = FXRateService()
    assert isinstance(o, FXRateService)


# Generated at 2022-06-24 01:22:58.580427
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """Unit test for constructor of class :class:`FXRateLookupError`."""
    import datetime
    from pypara.currencies import Currencies
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except LookupError as exception:
        assert type(exception) == FXRateLookupError
        assert exception.args == (f"Foreign exchange rate for {Currencies['EUR']}/{Currencies['USD']} "
                                  f"not found as of {datetime.date.today()}",)
        assert str(exception) == (f"Foreign exchange rate for {Currencies['EUR']}/{Currencies['USD']} "
                                  f"not found as of {datetime.date.today()}")

# Unit test

# Generated at 2022-06-24 01:23:04.766920
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class FXRateServiceMock(FXRateService):
        """
        Provides a mock for foreign exchange rate service.
        """


# Generated at 2022-06-24 01:23:08.926557
# Unit test for constructor of class FXRate
def test_FXRate():
    assert FXRate("aaa", "bbb", "ccc", "ddd")

# Generated at 2022-06-24 01:23:20.051027
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Base FX rate service, returning EUR/USD rates.

# Generated at 2022-06-24 01:23:20.472096
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): pass

# Generated at 2022-06-24 01:23:32.050223
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): #ignoring: E1101, E302, E501, W0621
    import unittest
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.models import FXRate
    from pypara.currencies.rates_dict import FXRateDict


# Generated at 2022-06-24 01:23:38.756578
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(ccy1 = Currencies["EUR"],
                   ccy2 = Currencies["USD"],
                   date = datetime.date.today(),
                   value = Decimal("2"))
    rrate = FXRate(ccy1 = Currencies["USD"],
                   ccy2 = Currencies["EUR"],
                   date = datetime.date.today(),
                   value = Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-24 01:23:46.862323
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit tests the constructor of class :class:`FXRateLookupError`.
    """
    # noinspection PyUnresolvedReferences
    from pypara.currencies import Currencies
    import datetime

    ## Check message:
    with pytest.raises(FXRateLookupError) as e:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert "Foreign exchange rate for EUR/USD not found as of" in str(e.value)


# Generated at 2022-06-24 01:23:49.609179
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:23:58.112130
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .currencies.iso import ISO4217
    import datetime
    eur = Currencies[ISO4217.EUR]
    usd = Currencies[ISO4217.USD]
    ex = FXRateLookupError(eur, usd, datetime.date.today())
    assert ex.ccy1 == eur
    assert ex.ccy2 == usd
    assert ex.asof == datetime.date.today()
    assert str(ex) == "Foreign exchange rate for EUR/USD not found as of {0}".format(datetime.date.today())


# Generated at 2022-06-24 01:24:06.369425
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:24:17.801980
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["USD"], 'Expected USD but got {curr}'.format(curr=ccy1)
    assert ccy2 == Currencies["EUR"], 'Expected EUR but got {curr}'.format(curr=ccy2)
    assert date == datetime.date.today(), 'Expected {today} but got {dt}'.format(today=datetime.date.today(), dt=date)
    assert value == Decimal("2"), 'Expected 2 but got {val}'.format(val=value)

# Generated at 2022-06-24 01:24:21.266798
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests constructor of class FXRateLookupError
    """
    import datetime
    from pypara.currencies import Currencies
    err = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-24 01:24:33.274912
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Test the decorator:
    with pytest.raises(ValueError) as e:
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0"))
    assert str(e.value) == "FX rate value can not be equal to or less than `zero`."

    with pytest.raises(ValueError) as e:
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("-1"))
    assert str(e.value) == "FX rate value can not be equal to or less than `zero`."


# Generated at 2022-06-24 01:24:45.461250
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from ..currencies import Currencies
    from ..temporal import Dates
    from .temporal.calendars import Calendars
    from .temporal.calendars.weekdays import Weekdays

    class FakeFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, 1)

    rtcal = Calendars.get("RTC")
    rtcal.holiday_calendar.holiday("2018-01-08", "2018-01-09")
    rtcal.holiday_calendar.holiday("2018-02-04", "2018-02-05")
    rtcal.holiday_calendar.holiday("2018-03-19", "2018-03-20")

# Generated at 2022-06-24 01:24:55.560237
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currency, Currencies
    from pypara.fx.services import InMemoryFXRateService
    from pypara.zeitgeist import Date
    import datetime

    ## Create an FX rate service:
    service = InMemoryFXRateService([
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 3, 1), 1.200),
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 3, 2), 1.203),
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 3, 3), 1.207)
    ])

    ## Check if we can query for multiple rates:

# Generated at 2022-06-24 01:25:03.911685
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test of method queries of class FXRateService
    """
    
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    
    ## Define the queries:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()
    queries = [(ccy1, ccy2, asof)]
    
    ## Define the rate:
    rate = FXRate(ccy1, ccy2, asof, Decimal("2"))
    
    ## Define the query object:

# Generated at 2022-06-24 01:25:11.138953
# Unit test for constructor of class FXRateService
def test_FXRateService():  # noqa: D102
    class TestFXRateService(FXRateService):  # noqa: D101

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Date]], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    # Sanity check
    assert isinstance(TestFXRateService(), FXRateService)


# Generated at 2022-06-24 01:25:17.505150
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:25:20.651029
# Unit test for constructor of class FXRateService
def test_FXRateService():                                       # noqa: D202
    import unittest

    class TestFXRateService(unittest.TestCase):

        def test_constructor(self):
            pass

    unittest.main()



# Generated at 2022-06-24 01:25:31.273506
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal, InvalidOperation
    from pypara.currencies import Currencies
    # Test 1
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate
    # Test 2
    try:
        ~FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0"))
        raise ValueError("Should have raised an exception due to invalid FX rate value.")
    except InvalidOperation:
        pass
    # Test 3

# Generated at 2022-06-24 01:25:35.731446
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    mock = FXRateService()
    def mock_query(ccy1, ccy2, asof, strict): return FXRate(ccy1, ccy2, asof, Decimal(0))
    mock.query = mock_query
    rate = next(mock.queries([(Currency.USD, Currency.EUR, Date.today())]))
    assert isinstance(rate, FXRate)

# Generated at 2022-06-24 01:25:39.783686
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    ## Create the FX rate lookup error:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    ## Ensure that the error is properly formed:
    assert isinstance(error, FXRateLookupError)
    assert isinstance(error, LookupError)
    assert isinstance(error, Exception)
    assert isinstance(error, BaseException)
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == datetime.date.today()
    assert isinstance(str(error), str)
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of {}".format(datetime.date.today())

# Generated at 2022-06-24 01:25:44.629427
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == \
           FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))


# Generated at 2022-06-24 01:25:51.982018
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import CCY
    from .currencies import CCYUSD
    from .currencies import CCYEURO
    from .currencies import CCYJPY
    from .services.fx import FXRateService_Mock
    from .temporal import Date

    fxs = FXRateService_Mock()

    rate = fxs.query(CCYEURO, CCYUSD, Date(2018, 1, 1), True)
    assert rate == FXRate(CCYEURO, CCYUSD, Date(2018, 1, 1), Decimal('1.2000'))

    rate = fxs.query(CCYEURO, CCYJPY, Date(2018, 1, 1), True)
    assert rate == FXRate(CCYEURO, CCYJPY, Date(2018, 1, 1), Decimal('130.0000'))



# Generated at 2022-06-24 01:26:03.348825
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from functools import partial
    from pypara.currencies import Currencies
    from pypara.curves import Curve
    from pypara.market.quotes.fx import FXRate
    from pypara.market.quotes.fx import FXRateService
    from pypara.market.quotes.fx import FXRateLookupError

    # Unit test for strict mode

# Generated at 2022-06-24 01:26:11.319800
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    try:
        raise FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date.current())
    except FXRateLookupError as e:
        assert isinstance(e, LookupError)
        assert isinstance(e, FXRateLookupError)
        assert isinstance(e, Exception)
        assert isinstance(e, BaseException)
        assert e.ccy1 == Currencies["USD"]
        assert e.ccy2 == Currencies["EUR"]
        assert isinstance(e.asof, Date)
    else:
        raise AssertionError("Exception not raised")


# Generated at 2022-06-24 01:26:24.033978
# Unit test for constructor of class FXRateService
def test_FXRateService():
    FXRateService
    # noinspection PyAbstractClass
    class _TestFXRateService(FXRateService):
        """
        Provides a dummy foreign exchange rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Date]], strict: bool = False) -> Iterable[Optional[FXRate]]:
            yield None

    service = _TestFXRateService()
    service.query(Currency("EUR", "EURO"), Currency("USD", "DOLLAR"), Date())
    service.queries([(Currency("EUR", "EURO"), Currency("USD", "DOLLAR"), Date())])


# Unit test

# Generated at 2022-06-24 01:26:33.792629
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest
    from .currencies import Currency, CurrencyLookupError

    # Test that FXRateLookupError gets initialized correctly
    with pytest.raises(FXRateLookupError):
        raise FXRateLookupError(Currency("XXX"), Currency("YYY"), Date(2020, 1, 31))
    with pytest.raises(FXRateLookupError):
        raise FXRateLookupError(Currency("USD"), Currency("EUR"), Date(2020, 3, 31))
    with pytest.raises(CurrencyLookupError):
        raise FXRateLookupError(Currency("XXX"), Currency("YYY"), Date(2020, 1, 31))


# Generated at 2022-06-24 01:26:38.050919
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():  # noqa: D102
    from .currencies import Currency
    import datetime
    
    from decimal import Decimal
    
    from pypara.fxrates import FXRate
    
    
    
    rate = FXRate(Currency("EUR"), Currency("USD"), datetime.datetime.today(), Decimal("2"))
    inverted_rate = FXRate(Currency("USD"), Currency("EUR"), datetime.datetime.today(), Decimal("0.5"))
    
    __test_equal(inverted_rate, ~rate, "Inversion of foreign exchange rate.")


# Generated at 2022-06-24 01:26:45.252474
# Unit test for constructor of class FXRate
def test_FXRate():
    ## Test the underlying tuple:
    from datetime import date
    from decimal import Decimal
    from .currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == date.today()
    assert rate.value == Decimal("2")
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == date.today()
    assert rate[3] == Decimal("2")
    

# Generated at 2022-06-24 01:26:52.029485
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """

    # pylint: disable=missing-docstring
    # pylint: disable=too-few-public-methods

    import datetime

    from pypara.currencies import Currencies

    class CurrencyPair:
        """
        Provides a currency pair class.
        """

        def __init__(self, ccy1, ccy2):
            self.ccy1 = ccy1
            self.ccy2 = ccy2

        def __eq__(self, other):
            return self.ccy1 == other.ccy1 and self.ccy2 == other.ccy2

        def __str__(self):
            return f"{self.ccy1}/{self.ccy2}"


# Generated at 2022-06-24 01:27:03.374121
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """

    ## Local imports:
    from pypara.currencies import Currencies
    from pypara.history import Temporal

    ## Create a simple service:
    class SimpleService(FXRateService):
        """
        Provides a simple, in-memory foreign exchange rate service.
        """

        ## Backing FX rate map.

# Generated at 2022-06-24 01:27:10.233343
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest
    from .currencies import Currency
    from .commons.zeitgeist import Date
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date.today()
    with pytest.raises(FXRateLookupError, match="Foreign exchange rate for EUR/USD not found as of "):
        raise FXRateLookupError(ccy1, ccy2, asof)


# Generated at 2022-06-24 01:27:19.896792
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pytest
    from datetime import date

    ## Test invalid arguments:
    from .currencies import Currencies
    from .fx import FXRateService
    from .fx import FXRateLookupError

    fxservice = FXRateService()
    with pytest.raises(ValueError):
        fxservice.query(None, Currencies['USD'], None, strict=False)
    with pytest.raises(ValueError):
        fxservice.query(Currencies['USD'], None, None, strict=False)
    with pytest.raises(ValueError):
        fxservice.query(Currencies['USD'], Currencies['EUR'], None, strict=False)


# Generated at 2022-06-24 01:27:26.464557
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .commons.zeitgeist import Date
    from .fxrates import FXRateLookupError
    ccy1 = Currency("USD")
    ccy2 = Currency("EUR")
    asof = Date(2019, 2, 1)
    error = FXRateLookupError(ccy1, ccy2, asof)
    assert repr(error) == "Foreign exchange rate for USD/EUR not found as of 2019-02-01"


# Generated at 2022-06-24 01:27:35.177664
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """

    ## Test with a null service:
    service = None
    ccy1 = "USD"
    ccy2 = "EUR"
    asof = Date.of(2020, 8, 15)
    assert service.query(ccy1, ccy2, asof) is None
    assert service.query(ccy1, ccy2, asof, strict=False) is None
    assert service.query(ccy1, ccy2, asof, strict=True) is None



# Generated at 2022-06-24 01:27:42.971192
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from typing import List
    from unittest.mock import MagicMock
    from pypara.currencies import Currencies
    from pypara.time_utils import now
    from pypara.fx.rates import FXRateLookupError

    ## Set up:
    service = FXRateService()
    service.query = MagicMock()
    service.query.side_effect = [LookupError(), FXRate(Currencies["EUR"], Currencies["USD"], now(), 2)]

    ## Query:
    queries = [(Currencies["EUR"], Currencies["USD"], now()), (Currencies["USD"], Currencies["EUR"], now())]
    results: List[Optional[FXRate]] = list(service.queries(queries, strict=False))

    ## Assert:
    assert len(results) == 2
    assert results

# Generated at 2022-06-24 01:27:45.123031
# Unit test for constructor of class FXRate
def test_FXRate():
    rate = FXRate('1', '2', '3', '4')
    assert rate.ccy1 == '1'
    assert rate.ccy2 == '2'
    assert rate.date == '3'
    assert rate.value == '4'


# Generated at 2022-06-24 01:27:49.972228
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    currency1 = Currencies["EUR"]
    currency2 = Currencies["USD"]
    date = datetime.date.today()
    value = Decimal("1.2")

    rate = FXRate(currency1, currency2, date, value)

    assert rate.ccy1 == currency1
    assert rate.ccy2 == currency2
    assert rate.date == date
    assert rate.value == value

# Generated at 2022-06-24 01:28:00.699226
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .zeitgeist import Date
    from .commons.numbers import ONE

    date = Date.today()
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    # Initialize the FX rate lookup error
    error = FXRateLookupError(ccy1, ccy2, date)

    # Check the slots of the FX rate lookup error
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == date



# Generated at 2022-06-24 01:28:01.516606
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert True

# Generated at 2022-06-24 01:28:13.575961
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests method __invert__ of class FXRate.
    """
    from datetime import date
    from pypara.currencies import Currencies

    ## Test cases:
    rates = [
        (Currencies["EUR"], Currencies["USD"], date.today(), 1.0),
        (Currencies["USD"], Currencies["EUR"], date.today(), 1.0),
        (Currencies["USD"], Currencies["GBP"], date.today(), 1.25),
        (Currencies["USD"], Currencies["CHF"], date.today(), 1.1)
    ]

    ## Test:
    for ccy1, ccy2, dt, value in rates:
        rate = FXRate.of(ccy1, ccy2, dt, Decimal(value))
        rate_ = ~rate

# Generated at 2022-06-24 01:28:18.105931
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:28:24.986119
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:28:32.154487
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from .commons.zeitgeist import Date

    from .errors import FXRateLookupError

    try:
        raise FXRateLookupError(Currencies["USD"], Currencies["JPY"], Date.today())
    except FXRateLookupError as error:
        assert error.ccy1 == Currencies["USD"]
        assert error.ccy2 == Currencies["JPY"]
        assert error.asof == Date.today()
        assert str(error) == "Foreign exchange rate for USD/JPY not found as of 2018-03-03"
