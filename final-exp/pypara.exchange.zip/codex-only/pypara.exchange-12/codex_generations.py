

# Generated at 2022-06-24 01:18:36.465070
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commons import Temporal

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False):
            pass

        def queries(self, queries, strict: bool = False):
            for ccy1, ccy2, asof in queries:
                pass

    ## Test query of a single item:
    queries = [
        (Currencies["EUR"], Currencies["USD"], Temporal.now()),
    ]
    service = TestFXRateService()
    assert len(list(service.queries(queries, strict=False))) == 1

    ## Test query of an iterable of items:

# Generated at 2022-06-24 01:18:45.408343
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:18:52.758341
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxtrx.fxrates import FXRate

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert(~rate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5")))


# Generated at 2022-06-24 01:18:56.753161
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        raise FXRateLookupError(Currency("USD"), Currency("EUR"), Date(2018, 2, 28))
    except Exception as e:
        assert e.args[0] == "Foreign exchange rate for USD/EUR not found as of 2018-02-28"

# Generated at 2022-06-24 01:18:59.294383
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, ABCMeta)
    assert FXRateService.default is None
    assert FXRateService.TQuery == Tuple[Currency, Currency, Date]

# Generated at 2022-06-24 01:19:11.770748
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.exchanges import FXRateService as FXRateServiceImp

    # Create a foreign exchange rate service that returns EUR/USD FX rates:
    service = FXRateServiceImp(lambda *_: FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.now(), Decimal("1.31")))

    # Test the FX rate query for EUR/USD:
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.now()) == FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.now(), Decimal("1.31"))

    # Test the FX rate query for EUR/USD as of today's date:

# Generated at 2022-06-24 01:19:17.925675
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:24.500931
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method for the FXRateService abstract class.
    """
    from pypara.commons.numbers import ONE, TWO
    from pypara.currencies import Currency, Currencies
    from pypara.currencies.fx import FXRateService
    from pypara.currencies.fx.stub import FXRateServiceStub
    from pypara.currencies.fx.util import FXRateServiceDecorator

    # Test an FX rate service that provides rates inline:
    class TestFXRateServiceInline(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, ONE)


# Generated at 2022-06-24 01:19:35.419501
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currency, Currencies
    from pypara.fx.fxrates import FXRateService
    from .fxrates import FXRateServiceTestImpl

    fx = FXRateServiceTestImpl()

    queries = [
        (Currencies["EUR"], Currencies["USD"], Date.today()),
        (Currencies["USD"], Currencies["EUR"], Date.today()),
        (Currencies["USD"], Currencies["GBP"], Date.today())
    ]
    rates = fx.queries(queries, True)
    assert rates is not None
    assert len(rates) == 3
    assert rates[0] is not None
    assert rates[1] is not None
    assert rates[2] is not None


# Generated at 2022-06-24 01:19:41.678928
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    ## Imports:
    import datetime
    from decimal import Decimal
    from random import seed, choice
    from pypara.currencies import Currencies
    from pypara.pricing import FXRateService

    ## Prepare input:
    seed(42)
    currencies = list(Currencies.values())
    dates = [datetime.date(2018, 1, 1) + datetime.timedelta(i) for i in range(365)]
    queries = [(ccy1, ccy2, date) for ccy1 in currencies for ccy2 in currencies for date in dates]

    ## Prepare FX rate service:

# Generated at 2022-06-24 01:19:50.882366
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Foreign exchange rate service mock:
    class FXRateServiceMock(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

            return None

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                rate = self.query(ccy1, ccy2, asof, strict)
                yield rate

    ## Test
    fxrate_service

# Generated at 2022-06-24 01:19:57.074726
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .services import FXRateService as Service

    service = Service()
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    date = Date("2019-12-10")
    rate = service.query(ccy1, ccy2, date)
    assert rate, "Rated returned by `test_FXRateService_query` should NOT be `None`."


# Generated at 2022-06-24 01:20:08.052051
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currencies
    from .temporal import Date
    from .temporal import Temporals
    from unittest import TestCase
    from unittest.mock import MagicMock, patch

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == Temporals["2019-08-14"]:
                return FXRate(ccy1, ccy2, asof.date, Decimal("0.9"))

# Generated at 2022-06-24 01:20:15.045586
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .commons.numbers import ONE, ZERO
    from .currencies import Currencies, Currency
    from .currencies.temporal import CurrencyPair
    import datetime
    from decimal import Decimal
    from pypara.currencies.temporal import CurrencyConversion
    today = datetime.date.today()
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    value = Decimal("2")
    rate = FXRate(ccy1, ccy2, today, value)
    assert ~rate == FXRate(ccy2, ccy1, today, 1 / value)
    csnv = CurrencyConversion(cur=CurrencyPair(ccy1, ccy2), rate=rate, asof=today)

# Generated at 2022-06-24 01:20:17.958530
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, ABCMeta)

# Generated at 2022-06-24 01:20:28.954290
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import unittest
    from pypara.currencies import Currency
    from pypara.currencies.currencies import Currencies

    class FXRateLookupErrorTestCase(unittest.TestCase):

        def test_FXRateLookupError(self):
            """
            Tests FXRateLookupError.

            See Also:
                - https://docs.python.org/3.8/library/exceptions.html#bltin-exceptions
            """
            from pypara.currencies.temporal import Date

            ## Arguments
            ccy1 = Currencies["EUR"]
            ccy2 = Currencies["USD"]
            asof = Date.today()

            ## Run the test
            self.assertRaises(FXRateLookupError, FXRateLookupError, ccy1, ccy2, asof)

   

# Generated at 2022-06-24 01:20:36.210658
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Assert that `None` is returned for each query when the service is not set
    def mock_query(self, *args, **kwargs):
        return None

    service = FXRateService()
    service.query = mock_query
    assert list(service.queries((("USD", "EUR", "2019-12-13"), ("USD", "EUR", "2019-09-23")))) == [None, None]



# Generated at 2022-06-24 01:20:41.162110
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:48.101916
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .temporal import Temporal, DATE
    from .currencies.exchange.rates import FXRate, FXRateService  # noqa: F401

    from decimal import Decimal
    from datetime import date

    class FXRateServiceMock(FXRateService):

        # noinspection PyMethodParameters
        def __init__(self):
            self.data = [
                FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 1, 1), Decimal("2")),
                FXRate(Currencies["USD"], Currencies["EUR"], date(2019, 1, 1), Decimal("0.5")),
                FXRate(Currencies["USD"], Currencies["TRY"], date(2019, 1, 1), Decimal("5")),
            ]

        # noinspection

# Generated at 2022-06-24 01:20:49.703927
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class :class:`FXRateService`.
    """
    # Create FX rate service:
    fx_rate_service = FXRateService()

# Generated at 2022-06-24 01:21:00.921889
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    from .currencies import Currency, Currencies

    # Initialize some local variables
    ccy1=Currency('EUR')
    ccy2=Currency('USD')
    asof=Date('2019-05-10')

    # Initialize a FXRateLookupError object
    FXRateLookupError1 = FXRateLookupError(ccy1, ccy2, asof)

    # Check if FXRateLookupError1 has the correct values
    assert (FXRateLookupError1.ccy1 == ccy1) and (FXRateLookupError1.ccy2 == ccy2) and (FXRateLookupError1.asof == asof)

    # Check if FXRateLookupError1 has the correct super class
    assert issubclass

# Generated at 2022-06-24 01:21:09.484537
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    import unittest
    from pypara.currencies import Currencies
    from pypara.exchanges.fxtr import FxTRService

    ## Building the service:
    service = FxTRService()

    ## Setting test conditions:

# Generated at 2022-06-24 01:21:12.395262
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))


# Generated at 2022-06-24 01:21:18.188608
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # noinspection PyAbstractClass
    class Foo(FXRateService):
        @staticmethod
        def query(ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, ONE)

        @staticmethod
        def queries(queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for (ccy1, ccy2, asof) in queries:
                yield FXRate.of(ccy1, ccy2, asof, ONE)

    assert isinstance(Foo(), FXRateService)

# Generated at 2022-06-24 01:21:19.158110
# Unit test for constructor of class FXRateService
def test_FXRateService():

    assert FXRateService.default is None



# Generated at 2022-06-24 01:21:23.912966
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currency
    from pypara.dates import Date
    from pypara.fx import FXRateLookupError

    ## Confirm that `ccy1`, `ccy2` and `asof` are set:
    try:
        raise FXRateLookupError(Currency('EUR'), Currency('USD'), Date(2010, 1, 1))
    except FXRateLookupError as ex:
        assert ex.ccy1 == Currency('EUR')
        assert ex.ccy2 == Currency('USD')
        assert ex.asof == Date(2010, 1, 1)
        assert str(ex).startswith('Foreign exchange rate for EUR/USD not found as of')
        assert str(ex) == 'Foreign exchange rate for EUR/USD not found as of 2010-01-01'


# Generated at 2022-06-24 01:21:35.811007
# Unit test for constructor of class FXRate
def test_FXRate():
    from pypara.currencies import Currencies
    from datetime import date

    assert FXRate("EUR", "USD", date.today(), Decimal("2")) == FXRate(Currencies['EUR'], Currencies['USD'], date.today(), Decimal("2"))
    assert FXRate("EUR", "USD", date.today(), Decimal("2")) != FXRate(Currencies['USD'], Currencies['USD'], date.today(), Decimal("2"))

    assert FXRate("EUR", "USD", date.today(), Decimal("2")).ccy1 == Currencies["EUR"]
    assert FXRate("EUR", "USD", date.today(), Decimal("2")).ccy2 == Currencies["USD"]
    assert FXRate("EUR", "USD", date.today(), Decimal("2")).date == date

# Generated at 2022-06-24 01:21:42.717059
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == date.today()
    assert value == Decimal("2")

# Generated at 2022-06-24 01:21:54.432908
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    from .currencies import Currencies
    from .temporal import Date
    from .services.fxrateservice import InMemoryFXRateService

    ## Define the FX rate query:
    queries = [
        (Currencies["EUR"], Currencies["USD"], Date.today()),
        (Currencies["USD"], Currencies["EUR"], Date.today()),
        (Currencies["USD"], Currencies["EUR"], Date.today())
    ]

    ## Create and populate the FX rate service:
    fxrates = InMemoryFXRateService()
    fxrates.add(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))

# Generated at 2022-06-24 01:22:03.583935
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.types.fxrates import FXRate

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert (Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == rate

# Generated at 2022-06-24 01:22:07.675507
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    # Initialize the error:
    error = FXRateLookupError("USD", "EUR", "Y")

    # Check the properties:
    assert error.ccy1 == "USD"
    assert error.ccy2 == "EUR"
    assert error.asof == "Y"
    assert str(error) == "Foreign exchange rate for USD/EUR not found as of Y"


# Generated at 2022-06-24 01:22:09.887996
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Unit tests for class FXRate

# Generated at 2022-06-24 01:22:19.448355
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime as dt
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            return FXRate(ccy1, ccy2, dt.date.today(), Decimal('2'))
    
        def queries(self, queries, strict = False):
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    service = TestFXService()
    assert service.query(Currencies['EUR'], Currencies['USD'], dt.date.today()) == FXRate(Currencies['EUR'], Currencies['USD'], dt.date.today(), Decimal('2'))

# Generated at 2022-06-24 01:22:32.174494
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    # Import and initialize modules:
    import datetime
    import pytest
    from decimal import Decimal
    from pypara.calendars import Calendars
    from pypara.currencies import Currencies
    from pypara.sources import FXRateServices

    # Set the current date:
    today = datetime.date.today()
    
    # Create a default FXRateService instance:
    service = FXRateServices.default

    # Query the EUR/USD FX rate of today:
    query = service.query(Currencies["EUR"], Currencies["USD"], today)

    # Make sure that the FX rate is correctly returned:
    assert isinstance(query, FXRate)
    assert query[0] == Currencies["EUR"]

# Generated at 2022-06-24 01:22:42.462892
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D103
    from decimal import Decimal
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currencies
    import datetime
    from pypara.exchanges.fx import FXRateService, FXRateLookupError

    class FXRateServiceImpl(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                if asof == datetime.date(2016, 1, 1):
                    return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("1.1"))

# Generated at 2022-06-24 01:22:55.272061
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.query`.
    """
    ## Import the module:
    import logging
    import random
    import unittest
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency, Currencies
    from pypara.fx import FXRate, FXRateService


    class TestFXRateService(FXRateService):
        """
        Provides an FX rate service for testing purposes.
        """

        #: Keeps the logger for this class.
        _logger: logging.Logger


        def __init__(self) -> None:
            """
            Initializes the FX rate service.
            """
            self._logger = logging.getLogger(self.__class__.__qualname__)



# Generated at 2022-06-24 01:23:02.440707
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fx.stub import StubFXRateService
    from .maths.exceptions import MathsError
    from .portfolio import cash_flows

    ## Get a service that happens not to support any query:
    service = StubFXRateService(rate=None)

    ## Build a CASH-FLOW query:
    amount = 1000
    currency = Currencies["EUR"]
    date = Date.today()
    cash_flow = cash_flows(amount=amount, ccy=currency, date=date)

    ## The CASH-FLOW is queried in an iterable with an FX rate query:
    queries = (cash_flow, ("query-date", currency, currency, date))

    ## The service fails to calculate NPV of the CASH-FLOW:
   

# Generated at 2022-06-24 01:23:05.635614
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert(~nrate == rrate)



# Generated at 2022-06-24 01:23:11.363669
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency, Currencies
    from .commons.zeitgeist import Date

    fxerror = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    assert fxerror.ccy1 == Currencies["EUR"]
    assert fxerror.ccy2 == Currencies["USD"]
    assert fxerror.asof == Date.today()


# Generated at 2022-06-24 01:23:17.762534
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:23:23.909555
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    import pytest
    from pypara.currencies import Currencies

    ## Check construction:
    ## -------------------
    FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    FXRate("EUR", "USD", datetime.date.today(), Decimal("2"))
    FXRate("EUR", "USD", datetime.date(2019, 11, 10), Decimal("2"))
    FXRate("EUR", "USD", datetime.date(2019, 11, 10), 2)

    ## Check type validation:
    ## ----------------------
    with pytest.raises(ValueError):
        FXRate("EUR", "USD", datetime.date(2019, 11, 10), "2")

    ## Check consistency checks:
   

# Generated at 2022-06-24 01:23:30.628897
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))


# Generated at 2022-06-24 01:23:39.553192
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import random
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies, Currency
    from pypara.time import today
    from pypara.rates.fx import FXRateService, FXRateLookupError

    class CurrencyDatum(NamedTuple):
        """
        Defines a sample currency datum.
        """
        #: Defines the currency of the datum.
        ccy1: Currency

        #: Defines the currency of the datum.
        ccy2: Currency

        #: Defines the date of the datum.
        date: Date

        #: Defines the value of the datum.
        value: Decimal

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        #: Defines the hard

# Generated at 2022-06-24 01:23:40.672441
# Unit test for constructor of class FXRate
def test_FXRate():
    assert FXRate.__doc__ is not None


# Generated at 2022-06-24 01:23:46.176748
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:23:56.285751
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency

    ## Assert that FXRateLookupError is an exception:
    assert issubclass(FXRateLookupError, LookupError)
    assert isinstance(FXRateLookupError(Currency(), Currency(), Date.today()), LookupError)

    ## Assert that FXRateLookupError is a subclass of LookupError:
    error = FXRateLookupError(Currency(), Currency(), Date.today())
    assert issubclass(error.__class__, LookupError)

    ## Assert that FXRateLookupError message is not exception name:
    assert isinstance(error.__str__(), str)
    assert error.__str__().find(error.__class__.__name__) == -1


# Generated at 2022-06-24 01:23:59.368446
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query.
    """
    assert True


# Generated at 2022-06-24 01:24:11.365205
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from unittest import TestCase
    from pypara.currencies import Currency
    from pypara.dates import Date

    class MyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-24 01:24:19.065354
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for class FXRateLookupError.
    """
    import datetime
    from pypara.currencies import Currencies

    ## Check the existence of exception:
    try:
        raise FXRateLookupError(
            Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert repr(e) == "FXRateLookupError(ccy1=EUR, ccy2=USD, asof=2019-01-26)"
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == datetime.date.today()


# Generated at 2022-06-24 01:24:25.641912
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:24:32.655417
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    from .dates import LocalDate

    rate = FXRate(Currencies["EUR"], Currencies["USD"], LocalDate.today(), Decimal("2"))
    inverse = ~rate
    assert inverse.ccy1 == Currencies["USD"]
    assert inverse.ccy2 == Currencies["EUR"]
    assert inverse.date == LocalDate.today()
    assert inverse.value == Decimal("0.5")


# Generated at 2022-06-24 01:24:40.443146
# Unit test for constructor of class FXRate
def test_FXRate():

    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:24:46.777678
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError(): # noqa: D103
    from .currencies import Currencies
    from .commons.zeitgeist.date import Date

    try:
        raise FXRateLookupError(ccy1=Currencies["USD"], ccy2=Currencies["EUR"], asof=Date.now())
    except FXRateLookupError as ex:
        assert str(ex) == "Foreign exchange rate for USD/EUR not found as of today."



# Generated at 2022-06-24 01:24:50.843004
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import sys
    class DummyFXRateService(FXRateService):
        pass

    dummy_fx_rate_service = DummyFXRateService()
    assert sys.getrefcount(dummy_fx_rate_service) == 2
    assert isinstance(dummy_fx_rate_service, FXRateService)


# Generated at 2022-06-24 01:24:54.087588
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.__doc__ is not None
    assert FXRateService.query.__doc__ is not None
    assert FXRateService.queries.__doc__ is not None
    assert FXRateService.TQuery is not None
    assert FXRateService.default is None
    return 0


# Generated at 2022-06-24 01:25:00.112611
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    a = FXRate(Currencies['EUR'], Currencies['USD'], Date(2018, 1, 1), Decimal(1.5))
    assert a.ccy1.code == 'EUR'
    assert a.ccy2.code == 'USD'
    assert a.date.year == 2018
    assert a.value == Decimal(1.5)


# Generated at 2022-06-24 01:25:11.664352
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    except FXRateLookupError as fxerr:
        assert fxerr.ccy1 == Currencies["EUR"]
        assert fxerr.ccy2 == Currencies["USD"]
        assert fxerr.asof == Date.today()
        assert str(fxerr) == "Foreign exchange rate for EUR/USD not found as of " + str(fxerr.asof)
        assert repr(fxerr) == "Foreign exchange rate for EUR/USD not found as of " + str(fxerr.asof)


# Generated at 2022-06-24 01:25:17.705657
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:25:23.175688
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:25:29.778252
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert nrate[0] == Currencies["EUR"]
    assert nrate[1] == Currencies["USD"]
    assert nrate[2] == datetime.date.today()
    assert nrate[3] == Decimal("2")



# Generated at 2022-06-24 01:25:33.499621
# Unit test for constructor of class FXRateService
def test_FXRateService():
    try:
        FXRateService()
    except NotImplementedError as e:
        assert "abstract methods" in str(e) or "this is an abstract base class" in str(e)
    else:
        assert "abstract class can not be instantiated"

# Generated at 2022-06-24 01:25:42.788357
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporals import DateRange
    from .currencies import Currency
    from .fxrates import FXRateService, FXRate
    from .currencies import Currencies

    # Arrange
    class MockRateService(FXRateService):

        TQuery = FXRateService.TQuery

        def query(self, ccy1: Currency, ccy2: Currency, asof: DateRange, strict: bool = False) -> Optional[FXRate]:
            return FXRate(Currencies["USD"], Currencies["TRY"], asof.start, Decimal(5))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return map(self.query, queries)

    service = MockRateService()

    # Assert

# Generated at 2022-06-24 01:25:55.527202
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporal import Temporal
    from .currencies import Currencies
    from .markets.fx import FXMarket
    from decimal import Decimal
    from datetime import date
    fxMkt = FXMarket()
    fxMkt.queries([
        (Currencies["EUR"], date(2019, 10, 10), Decimal("1.1")),
        (Currencies["EUR"], date(2019, 10, 20), Decimal("1.2"))
    ])
    rate = fxMkt.queries([
        (Currencies["EUR"], Currencies["USD"], date(2019, 10, 10)),
        (Currencies["EUR"], Currencies["USD"], date(2019, 10, 20))
    ])
    assert len(rate) == 2

# Generated at 2022-06-24 01:26:02.550234
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of class :class:`FXRateService`.
    """
    # Import extended modules:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Initialize a local FX rate service:
    fxrates = [(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))]
    fxrsvc = DictFXRateService(fxrates)

    # The FX rate service should have a value for EUR/USD as of today:
    rate = fxrsvc.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate is not None
    assert rate[3] == Decimal("2")

    # The FX rate service should raise an error for EUR/USD as of tomorrow:
   

# Generated at 2022-06-24 01:26:05.772741
# Unit test for constructor of class FXRate
def test_FXRate():
    assert FXRate(Currency("EUR"), Currency("USD"), Date.today(), Decimal("1.3")) == \
           FXRate.of(Currency("EUR"), Currency("USD"), Date.today(), Decimal("1.3"))

# Generated at 2022-06-24 01:26:11.898372
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from unittest import TestCase
    from .currencies import Currencies
    from .temporal import Time
    class Test(TestCase):
        def runTest(self):
            nrate = FXRate(Currencies["EUR"], Currencies["USD"], Time.now(), Decimal("2"))
            rrate = FXRate(Currencies["USD"], Currencies["EUR"], Time.now(), Decimal("0.5"))
            self.assertEqual(~nrate, rrate)
    test = Test()
    test.runTest()


# Generated at 2022-06-24 01:26:24.657513
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    r"""
    Tests constructor of class `FXRateLookupError`.

    Execute this with

    .. code-block:: bash

        $ python -m unittest tests.test_fx.test_FXRateLookupError
    """

    ## Import the module:
    import unittest as ut
    from pypara.currencies import Currencies as C

    ## Define the unit-test class:
    class FXRateServiceTest(ut.TestCase):
        """
        Tests constructor of class `FXRateLookupError`.
        """

        def test_ctor(self):
            """
            Tests the constructor of the class `FXRateLookupError`.
            """

            ## Import the module
            from pypara.fx import FXRateLookupError

            ## Create an exception:

# Generated at 2022-06-24 01:26:35.031106
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    ## Imports:
    import datetime
    from pypara.currencies import Currencies

    ## Setup:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()

    ## Test:
    error = FXRateLookupError(ccy1, ccy2, asof)

    ## Asserts:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert error.args[0] == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}"

# Test for class FXRate using: doctest

# Generated at 2022-06-24 01:26:42.919827
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest

    from pypara.currencies import Currencies
    from pypara.dates import Dates
    from pypara.fx import FXRateLookupError

    with pytest.raises(FXRateLookupError) as exc:
        raise FXRateLookupError(Currencies["USD"], Currencies["EUR"], Dates["NOW"])

    assert exc.value.ccy1 == Currencies["USD"]
    assert exc.value.ccy2 == Currencies["EUR"]
    assert exc.value.asof == Dates["NOW"]
    assert str(exc.value) == "Foreign exchange rate for USD/EUR not found as of NOW"


# Unit test of class FXRate

# Generated at 2022-06-24 01:26:48.592503
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:26:53.887400
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """ Tests the constructor of class FXRateLookupError. """
    import datetime

    from pypara.currencies import Currencies

    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == datetime.date.today()


# Generated at 2022-06-24 01:26:56.502385
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, object)


# Generated at 2022-06-24 01:27:01.731890
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from unittest import TestCase
    from datetime import date
    from pypara import FXRate, Currencies

    ## Define the test case class:
    class TestFXRate___invert__(TestCase):

        def test_positive(self):
            ## Given
            nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
            rrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))

            ## When
            rate = ~nrate

            ## Then
            self.assertEqual(rate, rrate)


# Generated at 2022-06-24 01:27:10.231470
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    import doctest
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Init:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    ## Test:
    assert ~nrate == rrate
    assert ~rrate == nrate

    doctest.testmod()


# Generated at 2022-06-24 01:27:19.896328
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currency

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: datetime.date, strict: bool = False) \
                -> Optional[FXRate]:
            if (ccy1, ccy2, asof) == (Currency("USD"), Currency("EUR"), datetime.date(2018, 12, 31)):
                return FXRate(ccy1, ccy2, asof, Decimal("0.91"))

# Generated at 2022-06-24 01:27:23.589620
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class :class:`FXRateService`.

    >>> test_FXRateService()
    True
    """
    return FXRateService() is not None


# Generated at 2022-06-24 01:27:24.595317
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None


# Generated at 2022-06-24 01:27:36.042215
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """

    class MockFXRateService(FXRateService):
        """Provides a mock FX rate service."""

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate.of(ccy1, ccy2, asof, ONE)

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            return (self.query(*query) for query in queries)

    from .currencies import Currency

# Generated at 2022-06-24 01:27:36.869288
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass



# Generated at 2022-06-24 01:27:49.570358
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fxrates import FXRateService

    class FXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("0.5"))

# Generated at 2022-06-24 01:27:52.894554
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests foreign exchange rate service class.
    """
    # noinspection PyUnusedLocal
    class _Service(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    service = _Service()

# Generated at 2022-06-24 01:27:56.007322
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:28:08.093381
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D103
    from .services import FXRateService
    from .currencies import Currencies
    from .dates import Date
    from .commons.numbers import ZERO
    from .exceptions import FXRateLookupError
    # Load the FX rate service:
    fx_service = FXRateService.default
    assert fx_service is not None
    # FX rate to the same currency should be `one`:
    assert fx_service.query(Currencies["EUR"], Currencies["EUR"], Date.today()) == 1
    # FIXME:
    # is it still supported by Bloomberg?
    # Query some exchange rate:
    # assert fx_service.query(Currencies["EUR"], Currencies["USD"], Date.today()) == 1.11
    # Unknown currency pair should return None:
    assert fx_

# Generated at 2022-06-24 01:28:16.669717
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate.
    """
    import datetime

    from decimal import Decimal

    from .currencies import Currencies
    from .commons.zeitgeist import Date

    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(datetime.date.today()), Decimal("2"))
    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == Date(datetime.date.today())
    assert value == Decimal("2")



# Generated at 2022-06-24 01:28:28.296317
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .time import Date, now, today
    from .temporal import Temporal
    from .periods import Periods
    from .commons.numbers import to_decimal as decimal
    from decimal import Decimal
    from datetime import date
    import numpy as np

    class MyFXRateService(FXRateService):
        def __init__(self, rates_: np.matrix, dates_: np.array, currencies_: np.array):
            self.rates = rates_
            self.dates = dates_
            self.currencies = currencies_

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[Decimal]:
            ccy1_index = self.currencies == ccy1
            c