

# Generated at 2022-06-24 01:18:37.123616
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.fx_rates import FXRate, FXRateService

    ## Define a mock currency pair service:
    class FX(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self._rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self._rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            return None


# Generated at 2022-06-24 01:18:49.956459
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from datetime import date
    from decimal import Decimal
    from typing import List
    from pypara.currencies import Currency
    from pypara.fx_rates.services import FXRateService, FXRateLookupError
    from pypara.temporals import Date

    class MockRateService(FXRateService):
        """
        Provides a mock FX rate service class.
        """


# Generated at 2022-06-24 01:18:57.301679
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:03.993130
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .services.fx import FXRateService, FXRateLookupError

    class DummyFXRateService(FXRateService):
        """
        Provides a dummy foreign exchange rate service.
        """


# Generated at 2022-06-24 01:19:13.662851
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase  # noqa: E402
    from unittest.mock import Mock  # noqa: E402

    cls = FXRateService
    self = TestCase()

    self.assertFalse(hasattr(cls, "__abstractmethods__"))

    ## Check consistency of interface:
    mock = Mock()
    mock.query.side_effect = NotImplementedError
    self.assertRaises(NotImplementedError, mock.query)
    mock.queries.side_effect = NotImplementedError
    self.assertRaises(NotImplementedError, mock.queries)


# Generated at 2022-06-24 01:19:16.834451
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")

# Generated at 2022-06-24 01:19:22.510933
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .services import HistoricalFXRateService
    service = HistoricalFXRateService.default()
    rates = list(service.queries([(Currencies["EUR"], Currencies["USD"], Date(2017, 10, 10)),
                                  (Currencies["USD"], Currencies["EUR"], Date(2017, 10, 10))]))
    assert len(rates) == 2
    rate1, rate2 = rates
    assert rate1.value != rate2.value
    assert rate1.value != Decimal("1")
    assert rate2.value != Decimal("1")

# Generated at 2022-06-24 01:19:33.062473
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies

    test_fx_rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(2016, 5, 4), Decimal("1.1114"))
    ref_fx_rate = FXRate(Currencies["USD"], Currencies["EUR"], Date(2016, 5, 4), Decimal("0.90000"))
    assert ~test_fx_rate == ref_fx_rate

    test_fx_rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(2016, 5, 4), Decimal("0.90000"))
    ref_fx_rate = FXRate(Currencies["USD"], Currencies["EUR"], Date(2016, 5, 4), Decimal("1.1114"))
    assert ~test_fx_rate == ref_fx_

# Generated at 2022-06-24 01:19:44.186654
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
  import sys
  import datetime
  from decimal import Decimal
  from pypara.currencies import Currencies
  from pypara.fx import FXRate, FXRateService
  qss = FXRateService()
  rates = [
    FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 12, 24), Decimal("1.107"))
  ]
  qss.default = qss
  queries = iter([
    (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
    (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 12, 24))
  ])

# Generated at 2022-06-24 01:19:50.118563
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:55.645475
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    assert isinstance(rate, FXRate)

    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == date.today()
    assert value == Decimal("2")

if __name__ == "__main__":
    # Unit test this module by executing it.
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 01:20:03.181601
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.temporals import today
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], today())
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == today()
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of today"

if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 01:20:05.494654
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    try:
        FXRateService()
    except Exception:
        pass
    else:
        pass

# Generated at 2022-06-24 01:20:13.193297
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate1 = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    assert rate1[0] == Currencies["EUR"]
    assert rate1[1] == Currencies["USD"]
    assert rate1[2] == date.today()
    assert rate1[3] == Decimal("2")

# Generated at 2022-06-24 01:20:18.558908
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == date.today()
    assert rate.value == Decimal("2")

# Generated at 2022-06-24 01:20:24.476952
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    from decimal import Decimal
    import datetime
    r = FXRate(Currencies["EUR"], Currencies["USD"], Date(datetime.date.today()), Decimal("2"))
    assert r[0] == Currencies["EUR"]
    assert r[1] == Currencies["USD"]
    assert r[2] == Date(datetime.date.today())
    assert r[3] == Decimal("2")


# Generated at 2022-06-24 01:20:33.089715
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method.
    """
    from collections import namedtuple
    from decimal import Decimal
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.currencies.rates import FXRates

    # Create some test data:

# Generated at 2022-06-24 01:20:38.462060
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2) == (Currencies["EUR"], Currencies["USD"]) and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return map(lambda query: self.query(*query), queries)

    service = TestFXRateService()

    rate = service

# Generated at 2022-06-24 01:20:42.554642
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:20:48.335707
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:20:53.750640
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .rabies import Bites
    from .commons.zeitgeist import LocalDate

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], LocalDate.of(2019, 2, 1))
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2019-02-01"
        assert isinstance(e.asof, LocalDate)
        assert e.asof == LocalDate.of(2019, 2, 1)
        assert isinstance(e.ccy1, Currency)
        assert e.ccy1 == Currencies["EUR"]
        assert isinstance(e.ccy2, Currency)
        assert e.ccy2 == Currencies["USD"]

# Generated at 2022-06-24 01:21:01.664326
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    # Import
    from datetime import date
    from decimal import Decimal
    from typing import Tuple
    from pypara.currencies import Currencies
    from pypara.finance import FXRate

    # Test
    rate   = FXRate(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], date=date(2019,1,1), value=Decimal("2"))
    invrat = FXRate(ccy1=Currencies["USD"], ccy2=Currencies["EUR"], date=date(2019,1,1), value=Decimal("0.5"))
    assert ~rate == invrat


# Generated at 2022-06-24 01:21:10.033505
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit tests of class FXRateService
    """
    class _FXRateService(FXRateService):
        """
        Provides an abstract class for serving foreign exchange rates.
        """
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    assert isinstance(FXRateService.default, FXRateService)
    assert issubclass(_FXRateService, FXRateService)
    assert isinstance(FXRateService.TQuery, tuple)
    assert _FXRateService().query(Currency("CCY/1"), Currency("CCY/2"), Date.now()) is None
    assert _FX

# Generated at 2022-06-24 01:21:10.750345
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:21:13.776349
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        raise FXRateLookupError("ccy1", "ccy2", "asof")
    except Exception as e:
        assert isinstance(e, FXRateLookupError)
        assert e.args == ("Foreign exchange rate for ccy1/ccy2 not found as of asof",)


# Generated at 2022-06-24 01:21:17.721580
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from .currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:26.606510
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:21:29.253598
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, ABCMeta)
    assert FXRateService.__abstractmethods__ == frozenset(["query", "queries"])
    assert FXRateService.default is None

# Generated at 2022-06-24 01:21:31.299393
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test method queries of class FXRateService
    """

    # TODO: Should be implemented

# Generated at 2022-06-24 01:21:42.996349
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):
        def __init__(self):
            self.rates = [
                FXRate.of(Currencies["EUR"], Currencies["TRY"], datetime.date(2018, 1, 1), Decimal(4.00)),
                FXRate.of(Currencies["USD"], Currencies["TRY"], datetime.date(2018, 1, 1), Decimal(4.00)),
                FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 1, 1), Decimal(1.00)),
            ]


# Generated at 2022-06-24 01:21:43.734575
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:21:55.906937
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    from pypara.currencies import Currencies
    from pypara.finance.fx.services import StaticFXRateService
    import datetime
    from decimal import Decimal
    import unittest

    class DummyFXRateService(StaticFXRateService):
        """
        Dummy FX rate service for unit tests.
        """

        def __init__(self, **kwargs):
            """
            Initializes the static FX rate service.
            """

# Generated at 2022-06-24 01:22:01.515731
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:22:06.179340
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert(~nrate == rrate)


# Generated at 2022-06-24 01:22:11.676312
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .currencies import Currencies
    from .zeitgeist import Date
    from .fx import FXRateLookupError

    ccy1 = Currency(code="EUR", country="EUROPEAN UNION")
    ccy2 = Currency(code="USD", country="UNITED STATES OF AMERICA")

    try:
        raise FXRateLookupError(ccy1, ccy2, Date.today())
    except FXRateLookupError as exception:
        assert str(exception) == "Foreign exchange rate for EUR/USD not found as of {}".format(Date.today())
        assert exception.ccy1 == Currencies["EUR"]
        assert exception.ccy2 == Currencies["USD"]
        assert exception.asof == Date.today()


# Generated at 2022-06-24 01:22:19.943132
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    ## Import modules:
    import datetime
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create an FX rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    ## Invert the FX rate:
    irate = ~nrate

    ## Check the inverse of the FX rate:
    assert irate == rrate


# Generated at 2022-06-24 01:22:32.262965
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.fx.services import FXRateService, FXRateServiceCache

    # Create a dummy service:
    class DummyFXRateService(FXRateService):
        # noinspection PyMethodParameters
        def query(self, ccy1: Currency, ccy2: Currency, asof: datetime.date, strict: bool = False) -> Decimal:
            # pylint: disable=unused-argument
            return Decimal("1.0")

        # noinspection PyMethodParameters

# Generated at 2022-06-24 01:22:43.621128
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .commons import Temporal
    from .currencies import Currency
    from .dates import Date
    from .fx import FXRateService, FXRate
    from .money import Money
    from datetime import date
    from decimal import Decimal
    from pytest import raises

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("2.5"))

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Temporal]], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return FXRateService.queries(self, queries, strict)

    mock = MockFX

# Generated at 2022-06-24 01:22:53.393660
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import pytest
    from unittest.mock import Mock
    
    fxRateService = Mock(spec=FXRateService)
    fxRateService.query.side_effect = fxRateService.queries
    ccy1 = Currency("AAA", "AAA", "A")
    ccy2 = Currency("BBB", "BBB", "B")
    asof = Date("20190101")
    strict = True
    expected = [None, FXRate(ccy1, ccy2, asof, 1)]
    actual = fxRateService.query(ccy1, ccy2, asof, strict)
    assert expected[0] == actual

    actual = list(fxRateService.queries([(ccy1, ccy2, asof), (ccy2, ccy1, asof)], strict))


# Generated at 2022-06-24 01:22:59.716253
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.zeitgeist import Temporal

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            pass

        def queries(self, queries, strict = False):
            pass

    mrs = MockFXRateService()
    assert isinstance(mrs.query(None, None, Temporal(Date(2000, 1, 1))), Optional[FXRate])
    assert isinstance(mrs.queries([(None, None, Temporal(Date(2000, 1, 1)))]), Iterable[Optional[FXRate]])



# Generated at 2022-06-24 01:23:05.671932
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Create a mock instance:
    class MyService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.rates = {(rate[0], rate[1], rate[2]): rate[3] for rate in rates}
            self.rate_ccy = {rate[0]: rate[3] for rate in rates}
            self.rate_date = {rate[2]: rate[3] for rate in rates}

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date,
                  strict: bool = False) -> Optional[FXRate]:
            if ccy1 and ccy2 in self.rates and asof in self.rates:
                return self.rates[(ccy1, ccy2, asof)]
            else:
                return None

       

# Generated at 2022-06-24 01:23:16.833538
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """
    from .currencies import Currency, Currencies
    from .commons.zeitgeist import Date

    ## Make a lookup error:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())

    ## Check properties:
    assert error.ccy1 == Currencies["EUR"], "CCY/1 is wrong."
    assert error.ccy2 == Currencies["USD"], "CCY/2 is wrong."
    assert error.asof == Date.today(), "Date is wrong."
    assert error.asof.date == Date.today().date == Date.today(org="UTC").date, "Date value is wrong."


# Generated at 2022-06-24 01:23:26.030145
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:23:37.731035
# Unit test for method query of class FXRateService

# Generated at 2022-06-24 01:23:50.058267
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Now
    e = FXRateLookupError(Currencies["USD"], Currencies["EUR"], Now)
    assert isinstance(e, FXRateLookupError)
    assert isinstance(e, LookupError)
    assert e.ccy1 == Currencies["USD"]
    assert e.ccy2 == Currencies["EUR"]
    assert e.asof == Now
    assert str(e) == "Foreign exchange rate for USD/EUR not found as of 2019-05-18 01:57:58.562574"
    assert repr(e) == "FXRateLookupError(ccy1=USD, ccy2=EUR, asof=2019-05-18 01:57:58.562574)"



# Generated at 2022-06-24 01:23:55.980105
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Tests the constructor of foreign exchange rate model.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create a valid instance:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Assertions:
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")
    assert not rate[0] == Currencies["USD"]
    assert not rate[1] == Currencies["EUR"]
    assert not rate[2] == datetime.date.min
    assert not rate[3] == Decimal("1")



# Generated at 2022-06-24 01:24:04.091158
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method.
    """
    # Import modules
    import itertools
    import unittest
    from datetime import date
    from decimal import Decimal
    from unittest.mock import Mock, patch

    # Import from package
    from pypara.currencies import Currencies as C

    # Patch FXRateService instance
    mock = Mock(spec=FXRateService)
    # mock.query.side_effect = lambda cc1, cc2, dt, st: Decimal("0.5") if cc1 == C["EUR"] and cc2 == C["USD"] else Decimal("1" / 0.7) if cc1 == C["USD"] and cc2 == C["EUR"] else Decimal("1" / 0.4) if cc1 == C["GBP

# Generated at 2022-06-24 01:24:14.446660
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    import datetime
    from decimal import Decimal

    class TestFXRateService(FXRateService):

        def __init__(self, cache=None):
            if cache is None:
                self.cache = dict()
            else:
                self.cache = cache

        def query(self, ccy1, ccy2, asof, strict=False):
            key = (ccy1, ccy2, asof)
            if key not in self.cache:
                if strict:
                    raise FXRateLookupError(ccy1.code, ccy2.code, asof)
                else:
                    return None
            else:
                return self.cache[key]


# Generated at 2022-06-24 01:24:16.749825
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest

    with pytest.raises(ValueError):
        r = FXRateLookupError("EUR", "USD", "2020-01-01")



# Generated at 2022-06-24 01:24:23.499484
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import CurrencyPair, Currencies
    from .temporal import Days, TimePeriod
    from .tenors import Tenors
    from .temporal import Today
    fx_rate_service = FXRateService()
    ccy_pair: CurrencyPair = CurrencyPair(Currencies["EUR"], Currencies["USD"])
    asof: Date = ccy_pair.tenor.date(Today())
    rate: Optional[FXRate] = fx_rate_service.query(ccy_pair.ccy1, ccy_pair.ccy2, asof)
    asof2: Date = ccy_pair.tenor.date(Today().offset(TimePeriod(timedelta=Days(1))))

# Generated at 2022-06-24 01:24:31.451444
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class X(FXRateService):
        def __init__(self):
            self.default = None
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict=False):
            pass
        def queries(self, queries: Iterable[Tuple[Currency, Currency, Date]], strict: bool=False) -> Iterable[Optional[FXRate]]:
            pass
    pass



# Generated at 2022-06-24 01:24:39.241371
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-24 01:24:44.408228
# Unit test for constructor of class FXRateService
def test_FXRateService():  # pragma: no cover
    from .currencies import Currency, Currencies
    import datetime
    from decimal import Decimal

    fxrate = FXRate(Currency("EUR"), Currency("USD"), datetime.date.today(), Decimal("2.00"))
    assert fxrate is not None


# Generated at 2022-06-24 01:24:53.399582
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currency
    from pypara.foreign_exchange import FXRateLookupError

    ## Create the error:
    error = FXRateLookupError(Currency("EUR"), Currency("USD"), Date.today())

    ## Check its properties:
    assert error.ccy1 == Currency("EUR")
    assert error.ccy2 == Currency("USD")
    assert error.asof == Date.today()

    ## Check its message:
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of {}".format(Date.today())

# Generated at 2022-06-24 01:24:58.978513
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate

    >>> from datetime import date
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currency
    >>> fxrate = FXRate(Currency("EUR"), Currency("USD"), date(2020, 1, 1), Decimal(1.123))
    >>> fxrate[0]
    Currency(CCY='EUR', DECIMAL='2')
    >>> fxrate[1]
    Currency(CCY='USD', DECIMAL='2')
    >>> fxrate[2]
    date(2020, 1, 1)
    >>> fxrate[3]
    Decimal('1.123')
    """


# Generated at 2022-06-24 01:25:04.175988
# Unit test for constructor of class FXRateService
def test_FXRateService():
    with pytest.raises(TypeError) as error:
        class Test(FXRateService):
            pass

    assert str(error.value) == "Can't instantiate abstract class Test with abstract methods query"

# Generated at 2022-06-24 01:25:12.824329
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## We can construct an instance:
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1))

    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == Date(2018, 1, 1)
    assert error.args[0] == "Foreign exchange rate for EUR/USD not found as of 2018-01-01"
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2018-01-01"


# Generated at 2022-06-24 01:25:25.514624
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies import Currency

    class FXRateBehavior(unittest.TestCase):
        # Initializes a FXRate instance with EUR/USD.
        rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

        def test_of(self):
            # Test if classmethod `of` initializes FXRate instances correctly
            rate = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

            self.assertIsInstance(rate, FXRate)
            self.assertEqual(Currencies["EUR"], rate.ccy1)

# Generated at 2022-06-24 01:25:34.802110
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import mock
    from abc import ABC
    from typing import Optional

    class _FXRateService(FXRateService, ABC):
        @property
        def default(self) -> Optional["_FXRateService"]:
            pass

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery],
                    strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    assert issubclass(FXRateService, ABC)
    assert _FXRateService.__abstractmethods__ == {"query", "queries"}



# Generated at 2022-06-24 01:25:40.634357
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # Instantiate an FX rate service instance with an invalid query method:
    class x(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError("This is just a test.")
    # Execute the test:
    with raises(NotImplementedError):
        x().query("blah", "blah", "blah")


# Generated at 2022-06-24 01:25:46.191879
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .sources import FXSource
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    service = FXSource("https://api.exchangeratesapi.io", "EUR")
    assert service.query(ccy1, ccy2, Date.today().date) is not None
    assert service.query(ccy1, ccy2, Date(2020, 2, 15).date) is not None

# Generated at 2022-06-24 01:25:47.367104
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, metaclass=ABCMeta)

# Generated at 2022-06-24 01:25:53.034333
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:25:56.437274
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert isinstance(FXRateService(), FXRateService)

# Generated at 2022-06-24 01:26:05.507979
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:26:11.811044
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests foreign exchange rate lookup error.
    """
    import datetime
    from pypara.currencies import Currencies
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == datetime.date.today()
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of %s" % str(datetime.date.today())


# Unit tests for `FXRate` class

# Generated at 2022-06-24 01:26:21.802222
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.fx.mock import MockFXRateService  # noqa: F401

    # Variable initialization
    mfxrs = MockFXRateService()

    # mfxrs is of typ FXRateService
    assert isinstance(mfxrs, FXRateService)

    # mfxrs.query is of type method
    assert callable(mfxrs.query)

    # mfxrs.TQuery is of type Tuple
    assert isinstance(mfxrs.TQuery, tuple)

    # test query method
    assert isinstance(mfxrs.query("EUR", "USD", "2019-01-01"), FXRate)



# Generated at 2022-06-24 01:26:28.108437
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency, Currencies
    from .zeitgeist import Date
    eur = "EUR"
    usd = "USD"
    date = Date.today()
    ccy1 = Currencies[eur]
    ccy2 = Currencies[usd]
    fxel = FXRateLookupError(ccy1, ccy2, date)
    assert fxel.ccy1 == ccy1
    assert fxel.ccy2 == ccy2
    assert fxel.asof == date
    assert str(fxel) == f"Foreign exchange rate for {eur}/{usd} not found as of {date}"


# Generated at 2022-06-24 01:26:31.063430
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-24 01:26:43.033815
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    from .currencies.data import COUNTRIES

    from .foreignexchange.memory import InMemoryFXRateService

    # Create the FX rate service:
    fx_rate_service = InMemoryFXRateService()

    # Prepare the FX rates:
    fx_rates = (
        FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
        FXRate.of(Currencies["USD"], Currencies["GBP"], datetime.date.today(), Decimal("0.5")),
        FXRate.of(Currencies["EUR"], Currencies["GBP"], datetime.date.today(), Decimal("2") / Decimal("0.5")),
    )

   

# Generated at 2022-06-24 01:26:50.326936
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    import unittest

    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestCase(unittest.TestCase):
        def test_invert(self):
            nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
            self.assertEqual(~nrate, rrate)

    return unittest.makeSuite(TestCase, "test")


# Generated at 2022-06-24 01:27:03.199278
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Import built-in dependencies:
    import datetime

    # Import package dependencies:
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Create FXRateService,
    class MyFXRateService(FXRateService):
        """
        Provides a custom FX rate service implementation.
        """


# Generated at 2022-06-24 01:27:11.934429
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query for class FXRateService.
    """
    ## Query for a missing FX rate causes a lookup error:
    from pypara.currencies import Currencies
    from pypara.finance import FXRateServiceImplementation
    from .commons.zeitgeist import Date
    from .exceptions import LookupError
    sut = FXRateServiceImplementation()
    try:
        sut.query(Currencies["EUR"], Currencies["USD"], Date.of("2020-08-01"), strict=True)
    except LookupError:
        assert True
    except:
        assert False, "Failed to raise a lookup error."
    else:
        assert False, "Failed to raise a lookup error."

    ## Querying a missing FX rate returns None:

# Generated at 2022-06-24 01:27:16.089716
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Test that the constructor of class FXRateService is protected.
    """
    # pylint: disable=protected-access

    # Act and assert:
    try:
        FXRateService()
    except TypeError:
        pass
    else:
        raise AssertionError("The constructor should be protected.")

# Generated at 2022-06-24 01:27:18.067759
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    assert issubclass(FXRateService, FXRateService)


# Generated at 2022-06-24 01:27:26.859760
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    from .metrics import Metrics

    ## EUR/USD:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = Metrics.today()
    eur_usd_rate = FXRate(ccy1, ccy2, date, Decimal("2"))
    usd_eur_rate = FXRate(ccy2, ccy1, date, Decimal("0.5"))

    assert eur_usd_rate == ~usd_eur_rate
    assert usd_eur_rate == ~~eur_usd_rate



# Generated at 2022-06-24 01:27:37.342243
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D102
    import datetime
    from decimal import Decimal
    from itertools import starmap
    from pypara.currencies import Currencies

    ## Define FX rate provider:
    class FXRateProvider(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict=False) -> Iterable[Optional[FXRate]]:
            return starmap(self.query, queries)

    ## Create the FX rate provider:
    provider = FXRateProvider()

    ## Provide foreign exchange rates:

# Generated at 2022-06-24 01:27:46.553938
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .temporal.datetime import DateTime
    from .commons.numbers import Decimal

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: DateTime, strict: bool = False) -> Optional[Decimal]:
            return 1

    service = TestFXRateService()
    assert service.query(Currency, Currency, DateTime) == 1


# Generated at 2022-06-24 01:27:51.606181
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:28:04.444702
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import random
    import unittest

    from .currencies import Currencies

    class Test(unittest.TestCase):
        def test(self):
            class Service(FXRateService):
                def query(self, ccy1, ccy2, asof, strict=False):
                    return None

                def queries(self, queries, strict=False):
                    for query in queries:
                        yield None
            service = Service()

            self.assertEqual(service.query(Currencies["USD"], Currencies["EUR"], Date(2020, 4, 7)), None)
            self.assertEqual(list(service.queries([(Currencies["USD"], Currencies["EUR"], Date(2020, 4, 7))])), [None])

# Generated at 2022-06-24 01:28:11.540828
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:28:20.177105
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .temporal import Temporal
    from .currencies import Currency
    from .time.clock import SystemClock
    from .time.calendar import Weekday
    from .time.calendars.WeekendCalendar import WeekendCalendar
    from .time.date import Date
    from .time.calendars.Calendars import Calendars
    from .curves import Curve
    from .curves.curve_factory import bootstrap_fx_curve
    from .curves.curve_factory import fx_curve_builder
    from .curves.curve_factory import bootstrap_fx_curve
    from pypara.time.calendars.WeekdayCalendar import WeekdayCalendar
    import numpy as np
    import pytest
    import datetime
    import matplotlib.pyplot as plt
    import sys

# Generated at 2022-06-24 01:28:26.981894
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")
