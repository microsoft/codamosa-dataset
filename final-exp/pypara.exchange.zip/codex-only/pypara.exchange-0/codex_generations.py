

# Generated at 2022-06-24 01:18:35.008661
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .commons.temporal import Dates

    ## Create an FX rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Dates.today(), 1)

    ## Make sure the currency properties match:
    assert(rate.ccy1 == Currencies["EUR"])
    assert(rate.ccy2 == Currencies["USD"])

    ## Make sure the date and value properties match:
    assert(rate.date == Dates.today())
    assert(rate.value == 1)

# Generated at 2022-06-24 01:18:47.707454
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    # Imports
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.market.fxrates import FXRate, FXRateService
    #
    # Test data

# Generated at 2022-06-24 01:18:54.910079
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:00.125518
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-24 01:19:03.972816
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))



# Generated at 2022-06-24 01:19:10.116615
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class FXRateServiceTest(unittest.TestCase):

        def test_service(self) -> None:
            # Arrange
            class StubService(FXRateService):

                def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
                    if ccy1 is Currencies["EUR"] and ccy2 is Currencies["USD"] and asof == datetime.date.today():
                        return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
                    return None


# Generated at 2022-06-24 01:19:19.854683
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import sys
    import pytest
    import pytest_check as check
    from pypara.finance.currencies import Currency
    from pypara.finance.services.fxrates import FXRateService

    # Class definition for an implementation of class FXRateService
    class FXRateTestService(FXRateService):
        #
        # Override functions from class FXRateService
        #
        def query(self, ccy1, ccy2, asof, strict=False):
            from pypara.finance.services.fxrates import FXRateLookupError
            from pypara.finance.services.fxrates import FXRate

            #
            # TODO: Implement a proper service
            #

# Generated at 2022-06-24 01:19:22.889900
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    from .currencies import Currencies
    from .commons.zeitgeist import Today

    ## Create a foreign exchange rate lookup error:
    err = FXRateLookupError(ccy1=Currencies["USD"], ccy2=Currencies["GBP"], asof=Today())

    ## Check if we can access the message:
    assert str(err) == "Foreign exchange rate for USD/GBP not found as of 2018-08-08"

# Generated at 2022-06-24 01:19:23.970130
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the :method:`FXRateService.query` method.
    """
    pass


# Generated at 2022-06-24 01:19:34.873537
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporals import Date

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    # Instantiating test service:
    service = TestFXRateService

# Generated at 2022-06-24 01:19:41.902994
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert nrate != rrate
    assert ~nrate == rrate

# Test cases for method of of class FXRate

# Generated at 2022-06-24 01:19:43.569794
# Unit test for constructor of class FXRate
def test_FXRate():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 01:19:48.855260
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## Define the foreign exchange (FX) rate lookup error:
    error = FXRateLookupError(Currency("ABC"), Currency("DEF"), Date(2000, 1, 1))

    ## Access the properties:
    assert error.ccy1.code == "ABC"
    assert error.ccy2.code == "DEF"
    assert error.asof == Date(2000, 1, 1)


# Generated at 2022-06-24 01:19:49.317781
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-24 01:19:50.156211
# Unit test for constructor of class FXRateService
def test_FXRateService(): # noqa: D103
    pass

# Generated at 2022-06-24 01:19:55.272448
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .commons.zeitgeist import Today
    from decimal import Decimal
    import datetime

    rate1 = FXRate(Currencies['EUR'], Currencies['USD'], datetime.date(2019, 1, 1), Decimal('1.15'))
    rate2 = FXRate.of(Currencies['EUR'], Currencies['USD'], datetime.date(2019, 1, 1), Decimal('1.15'))
    rate3 = FXRate.of(Currencies['EUR'], Currencies['USD'], Today, Decimal('1.15'))
    assert rate1 == rate2
    assert rate1 != rate3


# Generated at 2022-06-24 01:20:03.898559
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal


# Generated at 2022-06-24 01:20:10.518318
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(nrate == rrate ** -1)


# Generated at 2022-06-24 01:20:11.497759
# Unit test for constructor of class FXRateService
def test_FXRateService():
    service: FXRateService = FXRateService()
    assert service




# Generated at 2022-06-24 01:20:16.734207
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:22.960069
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate.of(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:32.442264
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """Unit test for method `queries` of class `FXRateService`."""
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create a mock FX rate service:
    class MockFXRateService(FXRateService):
        """
        This class provides a mock foreign exchange rate service.
        """

        def __init__(self) -> None:
            """
            Initializes the mock foreign exchange rate service.
            """
            self._rates = {
                (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1)): Decimal("1.25")
            }


# Generated at 2022-06-24 01:20:38.240323
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:45.868315
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.numbers import ROUNDING
    from .commons.zeitgeist import Date, LocalDateTime
    from .currencies import Currencies

    from .fxrateservices import HistoricalFXRateService, HistoricalFXRateServiceOptions

    ## Create a service:
    service: FXRateService = HistoricalFXRateService(options=HistoricalFXRateServiceOptions(ROUNDING))

    ## Query the service:
    rate: Optional[FXRate] = service.query(Currencies.EUR, Currencies.USD, Date(LocalDateTime.now()))

    ## Check the rate:
    assert isinstance(rate, FXRate)
    assert rate.ccy1.name == Currencies.EUR.name, "Rate first currency name is not expected."

# Generated at 2022-06-24 01:20:51.971556
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    ## Normal case:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ~nrate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    ## Edge case:
    nrate = FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), Decimal("1"))
    assert ~nrate == FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), Decimal("1"))



# Generated at 2022-06-24 01:20:56.850587
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from tempfile import TemporaryDirectory
    from .commons.numbers import ZERO
    from .currencies import Currency, Currencies
    from .db import DB
    from .fxrates import FXRateService
    from .services import ServiceFactory
    from .temporal import Date

    with TemporaryDirectory() as temp:
        db = DB(temp)
        currencies = db.get_or_create(Currencies)
        assert currencies.count() == 0
        assert db.store(
            currencies,
            Currency(Currencies["USD"], "United States Dollar"),
            Currency(Currencies["TRY"], "Turkish Lira"),
            Currency(Currencies["EUR"], "Euro"),
        )
        assert currencies.count() == 3

        fxrates = db.get_or_create(FXRateService.__name__)
        assert fxrates.count()

# Generated at 2022-06-24 01:20:58.741647
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert ~FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

# Generated at 2022-06-24 01:21:07.958399
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for :method:`query` of class :class:`FXRateService`.
    """

    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    ## Create the query collection:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Date.today()

    ## Create a custom FX rate service:
    class CustomFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("12.345"))

    ## Create an instance of the custom FX rate service:
    CustomFXRateService()

    ## Make sure that query method returns the same instance in both cases

# Generated at 2022-06-24 01:21:15.261838
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError(): # noqa: D103
    from pypara.currencies import Currencies
    from pypara.currencies import UnitTestCurrencies
    import datetime
    error = FXRateLookupError(Currencies[UnitTestCurrencies.EUR], Currencies[UnitTestCurrencies.USD], datetime.date.today())
    assert isinstance(error, FXRateLookupError)


# Generated at 2022-06-24 01:21:17.390311
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .fx import FXRates
    from .currencies import Currencies
    from .datetime import Date
    
    assert (FXRateService.of(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("1.25")) is not None)

# Generated at 2022-06-24 01:21:29.196836
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method :method:`FXRateService.query`.
    """
    # First, the case where we do not want to raise any exception:
    assert FXRateService.default.query(Currency("USD"), Currency("TRY"), Date(2000, 1, 1)) is None

    # Now, we want to raise an exception for missing FX rate:
    try:
        FXRateService.default.query(Currency("USD"), Currency("TRY"), Date(2000, 1, 1), strict=True)
    except FXRateLookupError as error:
        assert error.ccy1 == Currency("USD")
        assert error.ccy2 == Currency("TRY")
        assert error.asof == Date(2000, 1, 1)



# Generated at 2022-06-24 01:21:38.777797
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test of the constructor of class FXRate.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()
    value = Decimal("2")
    fxrate = FXRate(ccy1, ccy2, date, value)
    assert ccy1 == fxrate.ccy1
    assert ccy2 == fxrate.ccy2
    assert date == fxrate.date
    assert value == fxrate.value


# Generated at 2022-06-24 01:21:46.943019
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Prepare:
    import datetime

    from decimal import Decimal

    from unittest import TestCase
    from unittest.mock import Mock

    from pypara.currencies import Currencies

    # Step 1:
    # Prepare test data:
    queries = [
        (Currencies["EUR"], Currencies["TRY"], datetime.date.today()),
        (Currencies["USD"], Currencies["TRY"], datetime.date.today()),
        (Currencies["EUR"], Currencies["TRY"], datetime.date.today())
    ]

    # Step 2:
    # Create a mock FX rate service and configure expectations:
    service = Mock(FXRateService)

# Generated at 2022-06-24 01:21:54.714376
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.valuations import Temporal
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Temporal.today().date, Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == Temporal.today().date
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:22:02.816775
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase, mock
    from pypara.fx import FXRateService

    class TestService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    rate_service = TestService()
    assert rate_service.default is None

    rate_service = TestService()
    assert rate_service.default is None

    rate_service.default = TestService()
    assert rate_service.default is not None


# Generated at 2022-06-24 01:22:06.411369
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of FXRateLookupError.
    """

    # For coverage of the class; pylint: disable=unused-variable
    lerr = FXRateLookupError(Currency.from_string("USD"), Currency.from_string("EUR"), Date())


# Unit tests for properties of class FXRate

# Generated at 2022-06-24 01:22:15.065845
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:22:21.927551
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests the __invert__ method of the FXRate class.
    """
    ## Import modules:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency

    ## Create an object:
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = datetime.date.today()
    rate = Decimal("2")
    nrate = FXRate(ccy1, ccy2, asof, rate)

    ## Create the expected object:
    rrate = FXRate(ccy2, ccy1, asof, rate ** -1)

    ## Assert:
    assert ~nrate == rrate, "The inverted rate is not correct."


# Generated at 2022-06-24 01:22:30.153320
# Unit test for constructor of class FXRate
def test_FXRate():
    # Given
    from decimal import Decimal

    import datetime

    from pypara.currencies import Currencies

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()
    value = Decimal("2")

    # When
    rate = FXRate(ccy1, ccy2, date, value)

    # Then
    assert rate[0] == ccy1
    assert rate[1] == ccy2
    assert rate[2] == date
    assert rate[3] == value



# Generated at 2022-06-24 01:22:35.707776
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and value == Decimal("2") and date == datetime.date.today()


# Generated at 2022-06-24 01:22:44.794577
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the implementation of method queries of class FXRateService
    """
    import unittest

    import datetime
    from decimal import Decimal
    from typing import List, Tuple

    from .currencies import Currency, Currencies

    from .commons.classes import Singleton
    from .commons.numbers import ONE, ZERO


    class MockFXRateService(FXRateService, metaclass=Singleton):
        """
        Provides a mock foreign exchange rate service.
        """

        # Define the FX rates:

# Generated at 2022-06-24 01:22:52.116598
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert error.ccy1 == Currencies['EUR']
    assert error.ccy2 == Currencies['USD']
    assert error.asof == datetime.date.today()


# Generated at 2022-06-24 01:22:58.092005
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-24 01:23:01.704484
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 1, 1), Decimal("2"))
    rrate = FXRate.of(Currencies["USD"], Currencies["EUR"], date(2019, 1, 1), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-24 01:23:11.726854
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.fx import FXRate, FXRateService

    class MockRateService(FXRateService):
        def __init__(self):
            self.__rates = []
            self.__rates.append(FXRate(Currency("EUR"), Currency("USD"), datetime.date(2020, 1, 3), Decimal("1.11")))
            self.__rates.append(FXRate(Currency("EUR"), Currency("USD"), datetime.date(2020, 1, 6), Decimal("1.12")))
            self.__rates.append(FXRate(Currency("EUR"), Currency("USD"), datetime.date(2020, 1, 7), Decimal("1.13")))

# Generated at 2022-06-24 01:23:20.696522
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Construction of the FX rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Indexed access to properties:
    ccy1, ccy2, date, value = rate

    # Check the properties:
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

    ## Invert the FX rate:
    nrate = rate
    rrate = ~nrate

    # Check the inverted FX rate:
    assert rrate.ccy1 == Currencies["USD"]
    assert rrate.ccy2 == Currencies

# Generated at 2022-06-24 01:23:28.386437
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    import datetime

    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == datetime.date.today()


# Generated at 2022-06-24 01:23:38.899379
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.
    """

    from .currencies import Currency
    from .temporals import Date

    ccy1 = Currency("CHF")
    ccy2 = Currency("EUR")
    date = Date.of(1977, 4, 24)
    err = FXRateLookupError(ccy1, ccy2, date)

    ## Check error message:
    assert err.args[0] == f"Foreign exchange rate for CHF/EUR not found as of 1977-04-24"

    ## Check slots:
    assert err.ccy1 == ccy1
    assert err.ccy2 == ccy2
    assert err.asof == date


# Generated at 2022-06-24 01:23:45.685155
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.default_rates import DefaultFXRateService

    fx_rate_service = DefaultFXRateService()
    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        (Currencies["USD"], Currencies["EUR"], datetime.date.today()),
        (Currencies["EUR"], Currencies["GBP"], datetime.date.today()),
        (Currencies["EUR"], Currencies["TRY"], datetime.date.today()),
        (Currencies["EUR"], Currencies["TRY"], datetime.date(2020, 9, 1))
    ]

    results = fx_rate_service.queries(queries, strict=False)

   

# Generated at 2022-06-24 01:23:57.750626
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import unittest
    import random
    import datetime
    from decimal import Decimal

    ## Define a random FX rate service:
    class RandomFXRateService(FXRateService):
        def __init__(self, corpus: Iterable[FXRate]) -> None:
            self.corpus = list(corpus)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for fx in self.corpus:
                if fx.ccy1 == ccy1 and fx.ccy2 == ccy2 and fx.date == asof:
                    return fx
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-24 01:24:10.200817
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.curves import FXRateService

    class MyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            rate = FXRate(ccy1, ccy2, asof, Decimal("2"))
            return rate

    service = MyService()
    rate = service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()

# Generated at 2022-06-24 01:24:18.072001
# Unit test for constructor of class FXRate
def test_FXRate():
    # Case 1
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import now
    rate = FXRate(Currencies["EUR"], Currencies["USD"], now(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == now().date
    assert value == Decimal("2")


# Generated at 2022-06-24 01:24:24.225389
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:24:34.567603
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D103
    """
    Unit test for method queries of class FXRateService
    """
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.services.fxrates import MockFXRateService
    from pypara.services.fxrates.mocks import mock_fx_rates

    ## Update the mock FX rate data:
    mock_fx_rates.push(
        FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2")),
        FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5")),
        FXRate(Currencies["USD"], Currencies["TRY"], date.today(), Decimal("4.5"))
    )

    ## Prepare the queries:

# Generated at 2022-06-24 01:24:35.892764
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # TODO: Implement
    pass


# Generated at 2022-06-24 01:24:48.778568
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Test a regular FX rate
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(2017, 1, 1), Decimal("1.1"))
    assert rate[0] is Currencies["EUR"]
    assert rate[1] is Currencies["USD"]
    assert rate[2] == Date(2017, 1, 1)
    assert rate[3] == Decimal("1.1")
    assert len(rate) == 4

    # Test an inverse FX rate
    invRate = ~rate
    assert invRate[0] is Currencies["USD"]
    assert invRate[1] is Currencies["EUR"]
    assert invRate[2] == Date(2017, 1, 1)

# Generated at 2022-06-24 01:24:52.849630
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.currencies import Currency, Currencies

    ccy1 = Currency("CCY/1", "Currency / 1")
    ccy2 = Currency("CCY/2", "Currency / 2")

    # query
    result = FXRateService.query(ccy1, ccy2, Date())
    assert result is None

    # queries
    result = FXRateService.queries([(ccy1, ccy2, Date())])
    assert result is None

    test_FXRateService()

# Generated at 2022-06-24 01:24:59.382286
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .time import today
    from decimal import Decimal
    rate = FXRate(Currencies["EUR"], Currencies["USD"], today(), Decimal("2"))
    assert rate[1] == Currencies["EUR"]
    assert rate[2] == Currencies["USD"]
    assert rate[3] == today()
    assert rate[4] == Decimal("2")
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], today(), Decimal("0.5"))


# Generated at 2022-06-24 01:25:08.298187
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-24 01:25:18.973860
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for class `FXRate`.

    >>> import datetime as dt
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currencies
    >>> fxrate = FXRate(Currencies.EUR, Currencies.USD, date=dt.date.today(), value=Decimal("2"))
    >>> fxrate.ccy1 == Currencies.EUR
    True
    >>> fxrate.ccy2 == Currencies.USD
    True
    >>> fxrate.date == dt.date.today()
    True
    >>> fxrate.value == Decimal("2")
    True
    """

    pass



# Generated at 2022-06-24 01:25:27.695311
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1 = rate[0]
    ccy2 = rate[1]
    date = rate[2]
    value = rate[3]

    assert(ccy1 == Currencies["EUR"])
    assert(ccy2 == Currencies["USD"])
    assert(date == datetime.date.today())
    assert(value == Decimal("2"))


# Generated at 2022-06-24 01:25:34.050616
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:25:38.511582
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:25:48.006167
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import CURRENCIES
    from datetime import date
    from decimal import Decimal
    from pypara.finance.fx import FXRateService
    from unittest import TestCase
    class FXRates(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass
        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    class TestFXRateService(TestCase):
        def test_query_should_should_raise_TypeError_if_ccy1_is_not_an_instance_of_Currency(self):
            fxrate_service = FXRates()

# Generated at 2022-06-24 01:25:54.166444
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.finance import FXRateService

    # class definition
    class Stub(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    class SubStub(Stub):
        pass

    # test FXRateService is subclass of ABCMeta
    assert issubclass(FXRateService, ABCMeta)
    assert issubclass(SubStub, ABCMeta)

    # test abstract methods
    assert 'query' in dir(Stub)
    assert 'queries' in dir(Stub)
    assert 'query' in dir(SubStub)

# Generated at 2022-06-24 01:26:02.456164
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class FXRateLookupError.
    """
    ## Define a currency:
    from pypara.currencies import Currencies

    ## Define a date:
    from datetime import date

    ## Create a lookup error:
    lkpErr = FXRateLookupError(Currencies["EUR"], Currencies["USD"], date.today())

    ## Check the attributes:
    assert lkpErr.ccy1 == Currencies["EUR"]
    assert lkpErr.ccy2 == Currencies["USD"]
    assert lkpErr.asof == date.today()

    ## Check the message:
    assert lkpErr.__str__() == "Foreign exchange rate for EUR/USD not found as of {0}".format(date.today())


# Generated at 2022-06-24 01:26:09.176972
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:26:19.564539
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class `FXRateService`.
    """

    import unittest

    from abc import ABC

    # Define a fake FX rate service class:
    class Fake(FXRateService, ABC):
        """
        Fake service provider.
        """
        pass

    # Check that the definition is of the right type:
    assert issubclass(Fake, FXRateService)
    assert isinstance(Fake, ABC)
    assert issubclass(Fake, ABC)

    # Check that it is not possible to instantiate the class:
    with unittest.TestCase().assertRaises(TypeError):
        Fake()

# Generated at 2022-06-24 01:26:28.402891
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    from .utils.testing import assertObjectsAreOfSameType, assertObjectsAreEqual

    ## Prepare the data (zero):
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = Date.today()
    value = Decimal("0")

    ## Prepare the data (not-zero):
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = Date.today()
    value = Decimal("2")

    ## Create the first FX rate:
    rate1 = FXRate(ccy1, ccy2, date, value)

    ## Create the second FX rate:
    rate2 = FXRate(ccy2, ccy1, date, value ** -1)

    ## Invert the first FX

# Generated at 2022-06-24 01:26:37.444646
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.financial import FXRate

    class MockRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return ()

    rate_service = MockRateService()
    rate = rate_service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.cc

# Generated at 2022-06-24 01:26:38.423474
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    pass



# Generated at 2022-06-24 01:26:44.639489
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests `FXRateLookupError` constructor.
    """
    ## Btw, there is no way to test str representation of an exception.
    ## http://stackoverflow.com/questions/5800427/how-to-test-a-string-representation-of-an-exception
    err = FXRateLookupError("USD", "EUR", "2016-09-30")
    assert err.ccy1 == "USD"
    assert err.ccy2 == "EUR"
    assert err.asof == "2016-09-30"

# Generated at 2022-06-24 01:26:51.500984
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate1.ccy1 == Currencies["EUR"]
    assert rate1.ccy2 == Currencies["USD"]
    assert rate1.date == datetime.date.today()
    assert rate1.value == Decimal("2")

# Generated at 2022-06-24 01:26:56.440238
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests basic functionality of :method:`FXRateService.queries`.
    """
    import datetime
    from decimal import Decimal
    from itertools import zip_longest
    from pypara.currencies import Currencies
    from pypara.datetime import Temporal

    class _MockService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return super().query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-24 01:26:58.758912
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxts import InMemoryFXRateService

    assert InMemoryFXRateService().queries([(Currencies["EUR"], Currencies["USD"], Temporal.now())]).next()



# Generated at 2022-06-24 01:27:07.467980
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies

    import datetime

    from decimal import Decimal

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert(rate.ccy1 == Currencies["EUR"])
    assert(rate.ccy2 == Currencies["USD"])
    assert(rate.date == datetime.date.today())
    assert(rate.value == Decimal("2"))


# Generated at 2022-06-24 01:27:10.358724
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:27:15.542390
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    ## Load the market data:
    from pypara.calendars import Calendars
    from pypara.currencies import Currencies
    from pypara.curves.market_data import (
        FXRateDataLoader,
        ZeroCurveDataLoader,
    )

    loader = ZeroCurveDataLoader(calendar=Calendars["TR"], start=Date("2020-05-11"))
    loader.load("http://www.tcmb.gov.tr/kurlar/today.xml")

    FXRateDataLoader("http://www.tcmb.gov.tr/kurlar/today.xml").load()

    ## Create the FX rate service:
    from pypara.curves.fx_rate_services import TCMBFXRateService

    tcmb = TCMBFXRateService(loader.asof)

    ## Query the FX rates:

# Generated at 2022-06-24 01:27:23.593651
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:27:31.616300
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from abc import abstractmethod

    from .commons.zeitgeist import Temporal

    from .currencies import USD
    from .currencies.iso import EUR

    class QueryableFXRateService(FXRateService):
        @abstractmethod
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal) -> Optional[Decimal]:
            pass

    service = QueryableFXRateService()

    assert service.query(EUR, USD, Date.today()) is None
    assert service.query(EUR, USD, Date.today(), True) is None

# Generated at 2022-06-24 01:27:33.081465
# Unit test for constructor of class FXRateService
def test_FXRateService():
    lookup = FXRateService() # NOQA
    lookup.query
    lookup.queries



# Generated at 2022-06-24 01:27:37.657023
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate

# Generated at 2022-06-24 01:27:48.739796
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

    nrate = FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), Decimal("1"))
    rrate = FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), Decimal("1"))
    assert ~nrate == rrate



# Generated at 2022-06-24 01:27:53.348959
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currency

    e = FXRateLookupError(Currency.of("EUR"), Currency.of("USD"), datetime.date.today())
    assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2020-05-01"
    assert e.ccy1 == Currency.of("EUR")
    assert e.ccy2 == Currency.of("USD")
    assert e.asof == datetime.date.today()


# Generated at 2022-06-24 01:28:01.726590
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests method __invert__ of FXRate.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:28:09.468720
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    test = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert test.ccy1 == Currencies["EUR"]
    assert test.ccy2 == Currencies["USD"]
    assert test.date == datetime.date.today()
    assert test.value == Decimal("2")


# Generated at 2022-06-24 01:28:20.151526
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """Unit test for method query of class FXRateService"""
    ## Imports:
    from unittest import TestCase, main
    from unittest.mock import Mock

    ## Create a mock fx rate service:
    fx = Mock(spec=FXRateService)

    ## Test the strict case:
    fx.query.side_effect = FXRateLookupError(Currency('A'), Currency('B'), Date(2019, 1, 1))
    with TestCase().assertRaises(FXRateLookupError):
        fx.query(Currency('A'), Currency('B'), Date(2019, 1, 1))

    ## Test the default case:
    fx.query.side_effect = FXRateLookupError(Currency('A'), Currency('B'), Date(2019, 1, 1))

# Generated at 2022-06-24 01:28:29.251674
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class :class:`FXRateLookupError`
    """
    class Test:
        """
        Provides a test exception class.
        """

        #: Defines an exception message.
        message = "test"

        def __init__(self):
            """
            Initializes the test exception.
            """
            super().__init__(self.message)

    ## Make sure that class FXRateLookupError is a subclass of test exception class:
    assert issubclass(FXRateLookupError, Test)

    ## Make sure that the message of FXRateLookupError is correctly set:
    assert FXRateLookupError("ccy", "ccy", "asof").message == "Foreign exchange rate for ccy/ccy not found as of asof"
