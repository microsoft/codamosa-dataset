

# Generated at 2022-06-24 01:18:37.040421
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from typing import cast
    from unittest.mock import MagicMock, Mock

    mock = Mock(spec=FXRateService)
    mock.query = MagicMock(return_value=None)

    queries = [(1, 2, 3)]
    assert list(cast(FXRateService, mock).queries(queries, strict=False)) == [None]

    queries = [(1, 2, 3)]
    assert list(cast(FXRateService, mock).queries(queries, strict=True)) == [None]

    mock.query = MagicMock(side_effect=[None, None])
    queries = [(1, 2, 3), (4, 5, 6)]
    assert list(cast(FXRateService, mock).queries(queries, strict=False)) == [None, None]


# Generated at 2022-06-24 01:18:46.405323
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-24 01:18:58.383787
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, mock
    from unittest.mock import MagicMock
    from pypara.currencies import Currencies
    from datetime import date
    from decimal import Decimal
    from pypara.finance.fx import FXRateService
    import pypara.finance.fx as fx

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == date(2019, 1, 1):
                return fx.FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 1, 1), Decimal(2))

# Generated at 2022-06-24 01:19:02.230930
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:19:05.862841
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.time import date

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date(2018, 1, 1), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], date(2018, 1, 1), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:16.151545
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of :class:`FXRateService`.
    """
    from ._util import UnitTests
    from .currencies import Currencies

    ## Test:
    service = UnitTests.fx_rate_service
    fx_rate1 = service.query(Currencies["USD"], Currencies["TRL"], Date(2018, 3, 31))
    fx_rate2 = service.query(Currencies["USD"], Currencies["TRY"], Date(2018, 3, 30))
    assert fx_rate1 is not None
    assert fx_rate2 is not None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 01:19:22.043847
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Checks if the constructor of class FXRateLookupError works correctly.
    """
    import datetime
    from pypara.currencies import Currencies

    error = FXRateLookupError(Currencies["USD"], Currencies["JPY"], datetime.date.today())
    assert str(error) == "Foreign exchange rate for USD/JPY not found as of " + str(datetime.date.today())
    assert error.ccy1 == Currencies["USD"]
    assert error.ccy2 == Currencies["JPY"]
    assert error.asof == datetime.date.today()


# Generated at 2022-06-24 01:19:29.084749
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    # Perform the actual unit test
    ccy1: Currency = Currency("EUR")
    ccy2: Currency = Currency("USD")
    asof: Date = Date("20191231")
    ex = FXRateLookupError(ccy1, ccy2, asof)

    # Check attributes
    assert ex.ccy1 == ccy1
    assert ex.ccy2 == ccy2
    assert ex.asof == asof
    assert ex.args == (f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}",)


# Generated at 2022-06-24 01:19:37.847956
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .datetime import Temporal
    from .temporal import Date
    from .fx import FXRateService

    import datetime
    import decimal

    class Temp(metaclass=ABCMeta):
        T = Temporal

        @abstractmethod
        def __init__(self):
            pass

        @abstractmethod
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal):
            pass

        @abstractmethod
        def queries(self, queries: Iterable[Tuple[Currency, Currency, Temporal]]):
            pass

    class Test(Temp, FXRateService):
        def __init__(self):
            super().__init__()


# Generated at 2022-06-24 01:19:45.990944
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currency, Currencies
    from .commons.zeitgeist import Date
    from .commons.numbers import Decimal

    ccy1 = Currency.of("EUR")
    ccy2 = Currency.of("USD")
    ccyx = ccy2
    date = Date(2019, 1, 1)
    rate = Decimal("2")
    nrate = FXRate(ccy1, ccy2, date, rate)

    ccy1, ccy2, date, value = nrate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == Date(2019, 1, 1)
    assert value == Decimal("2")

    rrate = FXRate(ccyx, ccy1, date, rate ** -1)

# Generated at 2022-06-24 01:19:55.268059
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """
    import datetime
    from pypara.currencies import Currencies

    ccy1, ccy2, asof = Currencies["EUR"], Currencies["USD"], datetime.date.today()
    message = f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}"
    exc = FXRateLookupError(ccy1, ccy2, asof)

    assert issubclass(exc.__class__, LookupError)
    assert exc.args == (message,)
    assert exc.ccy1 == ccy1
    assert exc.ccy2 == ccy2
    assert exc.asof == asof


# Generated at 2022-06-24 01:20:03.873144
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")).ccy1.equals(Currencies["EUR"])
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")).ccy2.equals(Currencies["USD"])
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")).date == datetime.date.today()
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")).value == Decimal("2")



# Generated at 2022-06-24 01:20:10.196716
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-24 01:20:10.887751
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService is FXRateService


# Generated at 2022-06-24 01:20:11.390011
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-24 01:20:21.029622
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests FXRateService's abstract method queries.
    """
    from unittest import TestCase, mock

    from datetime import date

    from decimal import Decimal
    from typing import Any

    from pypara.currencies import Currency, Currencies

    # Mocks the FXRate class:
    fxrate = mock.MagicMock()

    # Creates the FXRateService instance:
    svc = mock.MagicMock(spec=["queries"])
    svc.queries.return_value = (fxrate, )

    # Calls the method:
    assert svc.queries(iter([(Currencies["EUR"], Currencies["USD"], date.today()), ])) == (fxrate, )



# Generated at 2022-06-24 01:20:27.431704
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finmath import FXRate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(FXRate.__invert__(nrate) == rrate)


# Generated at 2022-06-24 01:20:29.734882
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .mock import FXRateService
    fx = FXRateService()
    assert fx.query(None, None, None) is None


# Unit tests for class FXRate

# Generated at 2022-06-24 01:20:41.043101
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency, Currencies
    from .fxrates import FXRate, FXRateService
    from .temporal import Date, Period, Periods

    class TestService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries, strict=False):
            return (self.query(*query) for query in queries)

    service = TestService()


# Generated at 2022-06-24 01:20:43.613337
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest
    from pypara.currencies import Currencies
    with pytest.raises(ValueError):
        FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date(1, 1, 2000))


# Generated at 2022-06-24 01:20:46.956820
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    ## Initialize the exception:
    error = FXRateLookupError(Currency("EUR"), Currency("USD"), Date(2014, 1, 1))

    ## Check the slots:
    assert error.ccy1 == Currency("EUR")
    assert error.ccy2 == Currency("USD")
    assert error.asof == Date(2014, 1, 1)


# Generated at 2022-06-24 01:20:50.132761
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)



# Generated at 2022-06-24 01:20:59.905353
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of the class FXRateLookupError.
    """
    # Test if the constructor of class `FXRateLookupError` returns the expected error message.
    EUR = Currency.of("EUR")
    USD = Currency.of("USD")
    date = Date.of(2018, 1, 1)
    error = FXRateLookupError(EUR, USD, date)

    # Test if the exception has the expected type:
    assert isinstance(error, LookupError)

    # Test if the object has the expected message:
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2018-01-01"



# Generated at 2022-06-24 01:21:08.367339
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.currencies import Currency
    from pypara.fx.rate_services import DummyFXRateService
    from pypara.temporal import Date

    ###
    ### Unit tests for FXRateService.query
    ###

    # Create a service
    service = DummyFXRateService()

    # Call the service with invalid arguments:
    assert service.query(None, None, None) is None

    # Call the service with valid arguments:
    assert service.query(Currency("USD"), Currency("EUR"), Date(2018, 1, 1)) is None

    ###
    ### Unit tests for FXRateService.queries
    ###

    # Create a service
    service = DummyFXRateService()

    # Call the service with invalid arguments:
    assert list(service.queries(None)) == [None]

    # Call the

# Generated at 2022-06-24 01:21:15.835450
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert nrate != rrate
    assert ~nrate == rrate


# Generated at 2022-06-24 01:21:21.044524
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    date = datetime.date.today()
    error = FXRateLookupError(Currencies["USD"], Currencies["EUR"], date)
    assert isinstance(error.ccy1, Currency)
    assert error.ccy1 == Currencies["USD"]
    assert isinstance(error.ccy2, Currency)
    assert error.ccy2 == Currencies["EUR"]
    assert isinstance(error.asof, Date)
    assert error.asof == date
    assert isinstance(error.message, str)
    assert error.message == f"Foreign exchange rate for USD/EUR not found as of {date}"


# Generated at 2022-06-24 01:21:31.921754
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currency
    from .temporal import Temporal
    from .utils import test_fxrateservice
    from .temporal import Date
    import datetime
    from decimal import Decimal

    class MyFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self._rates = rates

        def query(self, ccy1, ccy2, asof, strict=False):
            for rate in self._rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)


# Generated at 2022-06-24 01:21:39.974431
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:41.100161
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    FXRateService.queries(None, None)

# Generated at 2022-06-24 01:21:45.685480
# Unit test for constructor of class FXRate
def test_FXRate():
    assert not __debug__  # Not in debug mode

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:21:53.452347
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Test constructor of class FXRateLookupError
    """
    from .currencies import Currencies

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Date.today()
    err = FXRateLookupError(ccy1, ccy2, asof)
    assert err is not None and err.ccy1 == ccy1 and err.ccy2 == ccy2 and err.asof == asof


# Generated at 2022-06-24 01:22:02.732774
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rate2 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rate3 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("3"))
    rate4 = FXRate(Currencies["EUR"], Currencies["GBP"], datetime.date.today(), Decimal("0.8"))
    rate5 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert rate1 == rate2
    assert rate1 != rate3
   

# Generated at 2022-06-24 01:22:09.616822
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:19.431006
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest.mock import Mock

    ## Define the test data:
    queries = [(Currency("USD"), Currency("EUR"), Date(2019, 10, 7)), (Currency("EUR"), Currency("USD"), Date(2019, 10, 7))]  # noqa: E501

    ## Define the expected results:
    expected = [FXRate(Currency("EUR"), Currency("USD"), Date(2019, 10, 7), Decimal("0.9")),
                FXRate(Currency("USD"), Currency("EUR"), Date(2019, 10, 7), Decimal("1.1"))]

    ## Try with a mock FX rate service:
    mock = Mock()
    mock.queries.return_value = iter(expected)
    actual = list(mock.queries(queries))

    ## Check the results:
   

# Generated at 2022-06-24 01:22:32.175951
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .temporal import Temporal

    ## Test query:
    from .currencies import Currencies
    from .services.rates.ecb import EuroFXRefService

    sdate = Temporal.now().date()

# Generated at 2022-06-24 01:22:34.934335
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:46.787574
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateService

    class MockFXRateService(FXRateService):
        def __init__(self):
            self.rates = {
                (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1)): FXRate(
                    Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1), Decimal("2")
                )
            }

        def query(
            self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False
        ) -> Optional[FXRate]:
            return self.rates.get((ccy1, ccy2, asof), None)


# Generated at 2022-06-24 01:22:55.736616
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    "Checks that :class:`FXRateLookupError` constructor works as designed."

    ## Basic test:
    from .commons.zeitgeist import Date
    from .currencies import USD, EUR

    try:
        raise FXRateLookupError(USD, EUR, Date(2016, 1, 1))
    except FXRateLookupError as error:
        assert error.ccy1 == USD
        assert error.ccy2 == EUR
        assert error.asof == Date(2016, 1, 1)
        assert str(error) == "Foreign exchange rate for USD/EUR not found as of 2016-01-01"


# Generated at 2022-06-24 01:23:03.262060
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test the queries() method of class FXRateService
    """
    class TestService(FXRateService):
        def __init__(self):
            self._rates: Dict[Tuple[Currency, Currency, Date], Decimal] = OrderedDict()

        def add(self, ccy1: Currency, ccy2: Currency, date: Date, value: Decimal) -> "TestService":
            self._rates[(ccy1, ccy2, date)] = value
            return self

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            res = self._rates[(ccy1, ccy2, asof)] if (ccy1, ccy2, asof) in self._rates else None

# Generated at 2022-06-24 01:23:07.668302
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.date import Date
    from pypara.exchange import FXRate

    ## Create the FX rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))

    ## Invert:
    irate = ~rate

    ## Check consistency of the inverted rate:
    assert irate[0] == Currencies["USD"]
    assert irate[1] == Currencies["EUR"]
    assert irate[2] == Date.today()
    assert irate[3] == Decimal("0.5")



# Generated at 2022-06-24 01:23:16.145029
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:23:20.725678
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Invert rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:23:32.049672
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest
    from .currencies import Currency
    from .commons.zeitgeist import Today
    today = Today()
    ccy1 = ccy2 = Currency("EUR")
    date = today.date
    fxrle = FXRateLookupError(ccy1, ccy2, date)
    assert str(fxrle) == 'Foreign exchange rate for EUR/EUR not found as of {}'.format(today)
    assert fxrle.ccy1 == ccy1
    assert fxrle.ccy2 == ccy2
    assert fxrle.asof == date
    assert pytest.raises(FXRateLookupError, FXRateLookupError, Currency("USD"), Currency("EUR"), today.date)



# Generated at 2022-06-24 01:23:33.724909
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from . import FXRateServices

    assert FXRateServices.default is not None



# Generated at 2022-06-24 01:23:43.890727
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies

    class Test(unittest.TestCase):

        def test_ok(self):
            nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
            self.assertEqual(~nrate, rrate)

    suite = unittest.TestSuite()
    suite.addTest(Test("test_ok"))
    unittest.TextTestRunner().run(suite)


# Generated at 2022-06-24 01:23:52.988791
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")



# Generated at 2022-06-24 01:23:58.935216
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:08.032541
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    a = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1), Decimal(2))
    assert a.ccy1 == Currencies["EUR"]
    assert a.ccy2 == Currencies["USD"]
    assert a.date == datetime.date(2019, 1, 1)
    assert a.value == Decimal(2)



# Generated at 2022-06-24 01:24:12.763981
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert nrate[0] == Currencies["EUR"]
    assert nrate[1] == Currencies["USD"]
    assert nrate[2] == datetime.date.today()
    assert nrate[3] == Decimal("2")


# Generated at 2022-06-24 01:24:18.313534
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["TRL"], Date.today())
    except LookupError as error:
        assert isinstance(error, FXRateLookupError)
        assert error.ccy1 == Currencies["EUR"]
        assert error.ccy2 == Currencies["TRL"]

# Generated at 2022-06-24 01:24:22.628627
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    from .zeitgeist import now
    rate = FXRate(Currencies["EUR"], Currencies["USD"], now(), 0.5)
    assert ~rate == FXRate(rate[1], rate[0], rate[2], rate[3] ** -1)


# Generated at 2022-06-24 01:24:30.660935
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate) == rrate


# Generated at 2022-06-24 01:24:37.899598
# Unit test for constructor of class FXRate
def test_FXRate():  # noqa: D102
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-24 01:24:39.250413
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:24:43.897573
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .commons.zeitgeist import Date
    import pytest
    fx1 = Currency('USD')
    fx2 = Currency('EUR')
    fx3 = Date.of('2019-02-26')
    with pytest.raises(Exception):
        FXRateLookupError(fx1, fx2, fx3)

# Generated at 2022-06-24 01:24:55.385990
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """

    # This is a workaround to enable accessing FXRateService.TQuery in a convenient way:
    TQuery = FXRateService.TQuery

    # Define an FX rate service:

# Generated at 2022-06-24 01:25:01.127489
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:25:06.728306
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method.
    """
    ## Test implementation:
    from .testobjects import TestObjects
    from .testutils import assert_quantities_equal

    ## Create the FX rate service:
    service = TestObjects.fx_rate_service()

    ## Get the queries and the expected results:
    queries = TestObjects.fx_rate_queries()
    expected = TestObjects.fx_rates()

    ## Get the actual results:
    actual = tuple(service.queries(queries, True))

    ## Assert equality on each rate:
    for rate, erate in zip(actual, expected):
        assert_quantities_equal(rate, erate)

# Generated at 2022-06-24 01:25:15.950364
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal, getcontext
    from pypara.currencies import Currencies
    from pypara.markets.fx import FXRate, FXRateService
    from pypara.temporals import Date
    from unittest import TestCase
    from unittest.mock import Mock

    getcontext().prec = 4

    class TCurves(TestCase):

        def test__query_fails(self):
            service = FXRateService.__new__(Mock)
            service.query = Mock(return_value=None)

            queries = [
                (Currencies["USD"], Currencies["EUR"], Date.today()),
                (Currencies["USD"], Currencies["EUR"], Date.today() + datetime.timedelta(days=1))
            ]


# Generated at 2022-06-24 01:25:26.691023
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import EUR
    from .currencies import USD
    from .currencies import JPY
    from .temporal import Temporal
    temporal = Temporal(Temporal.GREGORIAN, Temporal.START_EPOCH)
    today = temporal.today()
    # Test argument type checking:
    with pytest.raises(TypeError, match=r"CCY_CCY_\d+\(\)"):
        FXRateLookupError(None, None, None)
    with pytest.raises(TypeError, match=r"CCY_CCY_\d+\(\)"):
        FXRateLookupError(EUR, None, None)

# Generated at 2022-06-24 01:25:36.143228
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import DateRange
    from .reporting import FXRateServiceInMemory
    from .testing import assert_collection_equal
    from . import FX_SPOT

    ## Create the sample FX rates:
    rates = [
        FX_SPOT(Currencies["EUR"], Currencies["USD"], date=DateRange(date(2019, 1, 1))),
        FX_SPOT(Currencies["EUR"], Currencies["USD"], date=DateRange(date(2019, 2, 1))),
        FX_SPOT(Currencies["EUR"], Currencies["USD"], date=DateRange(date(2019, 3, 1))),
    ]

    ## Generate a sample query set:

# Generated at 2022-06-24 01:25:44.038635
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate
    nrate = FXRate(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0.1111")
    )
    rrate = FXRate(
        Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("9.0")
    )
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:25:51.378668
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .zeitgeist import Date
    from decimal import Decimal

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = Date.current()
    value = Decimal("1.25")
    fxrate = FXRate(ccy1, ccy2, date, value)

    assert fxrate.ccy1 == ccy1
    assert fxrate.ccy2 == ccy2
    assert fxrate.date == date
    assert fxrate.value == value

    assert fxrate[0] == ccy1
    assert fxrate[1] == ccy2
    assert fxrate[2] == date
    assert fxrate[3] == value



# Generated at 2022-06-24 01:25:59.298688
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    ## If a currency pair is not found, raise an error:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == datetime.date.today()
        assert e.args[0] == "Foreign exchange rate for EUR/USD not found as of 2019-02-05"


# Generated at 2022-06-24 01:26:01.454700
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    # Import TESTED module:
    from pypara.markets.fx import FXRateLookupError

    # Make a test, then check the result:
    assert FXRateLookupError("EUR", "USD", Date())



# Generated at 2022-06-24 01:26:05.704848
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    error = FXRateLookupError(Currencies["USD"], Currencies["GBP"], datetime.date.today())
    assert("Foreign exchange rate for USD/GBP not found as of " + str(datetime.date.today()) in str(error))

# Generated at 2022-06-24 01:26:11.333059
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    # Given
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    # When
    fxrate = ~nrate
    # Then
    assert fxrate == rrate


# Generated at 2022-06-24 01:26:24.079968
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## fx rate between EUR/USD as of today
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

    ## inverted FX rate must correspond to the inverse of the value
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

# Generated at 2022-06-24 01:26:28.600944
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    try:
        class Test(FXRateService):  # type: ignore
            pass
        raise AssertionError("Class FXRateService must be abstract.")
    except TypeError:
        pass

# Generated at 2022-06-24 01:26:38.106977
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate

    # Test most basic scenario:
    class TestService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            return FXRate(ccy1, ccy2, asof, Decimal('1'))
        def queries(self, queries, strict):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)
    queries = [(Currencies["USD"], Currencies["EUR"], datetime.date.today()),]
    results = list(TestService().queries(queries))
    assert(len(results) == len(queries))

# Generated at 2022-06-24 01:26:43.765346
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:26:51.571861
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Definition of unit tests for class :class:`FXRateService`.
    """
    import unittest

    class DummyFXRateService(FXRateService):
        """
        Provides a dummy implementation of :class:`FXRateService` for unit testing.
        """

        def __init__(self) -> None:
            self.rates = {}


# Generated at 2022-06-24 01:27:03.308863
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    # Test 1
    # Test with invalid inputs
    # Expected Result: Should raise error
    from .currencies import Currencies
    from .commons.zeitgeist import Day
    import datetime
    try:
        FXRateLookupError(Currencies["EUR"], Currencies["USD"], Day(datetime.datetime.today()))
    except:
        assert True
    
    # Test 2
    # Test with valid inputs
    # Expected Result: Should return FXRateLookupError
    from .currencies import Currencies
    from .commons.zeitgeist import Day
    import datetime
    try:
        FXRateLookupError(Currencies["EUR"], Currencies["USD"], Day(datetime.date.today()))
        assert True
    except:
        assert False


# Generated at 2022-06-24 01:27:09.138868
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from pypara.currencies import Currencies
    ccy1, ccy2 = Currencies["EUR"], Currencies["USD"]
    rate = FXRate(ccy1, ccy2, Date.now(), Decimal("2"))
    assert ~rate == FXRate(ccy2, ccy1, Date.now(), Decimal("0.5"))



# Generated at 2022-06-24 01:27:14.679263
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .zeitgeist import Date
    from .finance.fx import FXRateLookupError
    assert FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date(1,1,2017))


# Generated at 2022-06-24 01:27:17.731348
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    This function performs unit tests for class `FXRateService`.
    """
    from pypara.commons.testing import assert_object_interface
    assert_object_interface(FXRateService, "FXRateService")

# Unit test this module:
if __name__ == "__main__":
    test_FXRateService()
    print("All unit tests successful.")

# Generated at 2022-06-24 01:27:27.437103
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:27:38.608185
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():  # noqa: D103
    import datetime
    import pytest
    from pypara.currencies import Currencies

    # Define arguments and expected message:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()
    message = f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}"

    # Construct FX rate lookup error:
    error = FXRateLookupError(ccy1, ccy2, asof)

    # Verify state:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof

    # Verify message:
    assert str(error) == message


# Generated at 2022-06-24 01:27:43.343183
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from .commons.zeitgeist import Date
    from .currencies import Currency, Currencies
    class TestService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(Currencies["EUR"], Currencies["USD"], Date.now(), Decimal("1.2"))
    assert FXRateService.default is None
    fx = TestService().query(Currencies["EUR"], Currencies["USD"], Date.now())
    assert isinstance(fx, FXRate)


# Generated at 2022-06-24 01:27:49.935681
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class :class:`FXRateLookupError`
    """
    from .currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    except FXRateLookupError as e:
        assert isinstance(e, FXRateLookupError)
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == Date.today()
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2020-05-25"



# Generated at 2022-06-24 01:27:54.908166
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from unittest.mock import MagicMock
    from pypara.sources.rates.services.fxrate import FXRateService

    ## Mock an FX rate service:

# Generated at 2022-06-24 01:28:05.883921
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    "Test if FXRateService.queries behaves as specified."

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Temporal
    from pypara.fx.services import StaticFXRateService

    # Test with no queries.
    frs = StaticFXRateService({})
    results = list(frs.queries(tuple()))
    assert len(results) == 0, "Expected an iterable with no elements"

    # Test with a query with invalid ccy1 (not of type Currency)
    query = ("EUR", Currencies["USD"], datetime.date.today())
    results = list(frs.queries([query, ]))
    assert len(results) == 1, "Expected an iterable with one element"

# Generated at 2022-06-24 01:28:13.342260
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    assert FXRate(
        Currencies["EUR"],
        Currencies["USD"],
        date.today(),
        Decimal("2"),
    ) == FXRate.of(
        Currencies["EUR"],
        Currencies["USD"],
        date.today(),
        Decimal("2"),
    )

# Generated at 2022-06-24 01:28:18.506371
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert nrate.ccy1 == Currencies["EUR"]
    assert nrate.ccy2 == Currencies["USD"]
    assert nrate.date == datetime.date.today()
    assert nrate.value == Decimal("2")


# Generated at 2022-06-24 01:28:20.060993
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: Implement
    pass


# Generated at 2022-06-24 01:28:28.692322
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fxrates import FXRateService

    class MockFxRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(2))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (None, None)

    ## Test against a mock FX rate service that always return 2.0 :
    fxrs = MockFxRateService()