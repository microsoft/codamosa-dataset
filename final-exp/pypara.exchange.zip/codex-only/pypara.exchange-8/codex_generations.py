

# Generated at 2022-06-24 01:18:31.992015
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from .fxtrade import FXTrade

    # pylint: disable=protected-access

    #
    # 1) No default FX rate service set: Called directly
    #
    try:
        FXRateService()
    except NotImplementedError as exception:
        assert str(exception) == "FXRateService is an abstract base class and can not be instantiated directly."

    #
    # 2) No default FX rate service set: Called through subclass
    #
    class FXRateServiceSubClass(FXRateService):
        """
        Provides a concrete subclass of :class:`FXRateService`.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            return None


# Generated at 2022-06-24 01:18:34.703315
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Unit test for method __invert__ of class FXRate.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:18:47.427295
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    queries = {(Currencies["EUR"], Currencies["USD"], datetime.date.today() + datetime.timedelta(days=1))}
    rates = []  # type: Iterable[Optional[FXRate]]

    ## Test "strict" query:
    service = FXRateService()
    try:
        rates = service.queries(queries, strict=True)
    except FXRateLookupError:
        assert True
    else:
        assert False

    ## Test "non strict" query:
    rates = service.queries(queries, strict=False)
    assert None in rates

    ## Test "non strict" query:
    rates = service.queries(queries, strict=False)

# Generated at 2022-06-24 01:18:50.419884
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import unittest

    ## Make sure we can not initialize the class or any instance:
    with unittest.TestCase().assertRaises(TypeError):
        FXRateService()

    with unittest.TestCase().assertRaises(NotImplementedError):
        FXRateService().query(None, None, None)

    with unittest.TestCase().assertRaises(NotImplementedError):
        FXRateService().queries(None)


# Generated at 2022-06-24 01:18:57.727016
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:04.114174
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance import FXRate
    from pypara.finance.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock class for FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate.of(ccy1, ccy2, asof, Decimal("1.1") if ccy1 == Currencies["USD"] else Decimal("0.9"))


# Generated at 2022-06-24 01:19:12.797039
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Arrange
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    class MyFXRateService(FXRateService):
        @staticmethod
        def query(ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))
    fxrs = MyFXRateService()

    # Act
    fx1 = fxrs.query(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 2, 1))
    fx2 = fxrs.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    # Assert
    assert fx1 == fx2
    assert f

# Generated at 2022-06-24 01:19:23.293240
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService
    from pypara.zeitgeist import Date

    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("1"))

    ## Double-checking the positive

# Generated at 2022-06-24 01:19:33.813597
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D103
    # pylint: disable=missing-function-docstring

    # Import required modules:
    import datetime
    from decimal import Decimal
    from unittest import TestCase
    from unittest.mock import MagicMock

    # Import required entities:
    from pypara.currencies import Currencies
    from pypara.markets.fx import FXRateService
    from pypara.commons.zeitgeist import Date, Temporal

    # Test case class:
    class TestFXRateService(TestCase):

        # noinspection PyMissingOrEmptyDocstring
        def setUp(self) -> None:
            self.ccy1 = Currencies["EUR"]
            self.ccy2 = Currencies["USD"]
            self.date = Date(datetime.date.today())
            self

# Generated at 2022-06-24 01:19:41.098753
# Unit test for constructor of class FXRate
def test_FXRate():

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    rate: FXRate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:19:50.436021
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test the methods of class :class:`FXRateService`.
    """
    import datetime
    from decimal import Decimal
    from unittest import TestCase, mock

    from pypara.currencies import Currencies

    class DummyFXRateService(FXRateService):
        """
        Provides a dummy foreign exchange rate service for testing.
        """


# Generated at 2022-06-24 01:20:00.275302
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D102
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return map(lambda _: None, queries)

    ## Queries can go empty:
    assert list(TestFXRateService().queries([])) == []

    ## Queries go as expected:

# Generated at 2022-06-24 01:20:09.177466
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.

    >>> from pypara.currencies import Currency
    >>> from pypara.fx import FXRateLookupError
    >>> ex = FXRateLookupError(Currency("EUR"), Currency("USD"), Date(2020, 1, 1))
    >>> ex.ccy1 == Currency("EUR")
    True
    >>> ex.ccy2 == Currency("USD")
    True
    >>> ex.asof == Date(2020, 1, 1)
    True
    >>> ex.args == ("Foreign exchange rate for EUR/USD not found as of 2020-01-01",)
    True
    >>> str(ex)
    'Foreign exchange rate for EUR/USD not found as of 2020-01-01'
    """
    pass



# Generated at 2022-06-24 01:20:13.607494
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:20.280338
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:20:26.942922
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:20:36.367802
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    from pypara.finance.curve import Curve

    from pypara.finance.fx import FXRateService

    from pypara.utils.temporal import Period


# Generated at 2022-06-24 01:20:44.485767
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # Define a valid FXRate query tuple:
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import now
    FXRateService.TQuery = Tuple[Currency, Currency, Date]
    qry = Tuple[Currency, Currency, Date](Currencies['EUR'], Currencies['USD'], now())
    assert type(qry) == FXRateService.TQuery

    # Define a non-valid FXRate query tuple:
    try:
        qry = Tuple[Currency, Currency](Currencies['EUR'], Currencies['USD'])
        assert False
    except TypeError:
        assert True

    # Define a non-valid FXRate query tuple:

# Generated at 2022-06-24 01:20:55.219187
# Unit test for constructor of class FXRate
def test_FXRate():
    # Arrange
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    # Act
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    # Assert
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:21:04.236931
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the type requirements of the constructor of :class:`FXRateService`.
    """
    # pylint: disable=unused-variable
    class DummyFXRateService(FXRateService):
        """
        Defines a dummy implementation of the :class:`FXRateService` class.
        """


# Generated at 2022-06-24 01:21:12.842696
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Define the test data:
    queries = [
        (Currencies["USD"], Currencies["EUR"], datetime.date.today()),
        (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        (Currencies["USD"], Currencies["EUR"], datetime.date.today() + datetime.timedelta(days=1))
    ]

# Generated at 2022-06-24 01:21:16.024247
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """

    from .currencies import Currency
    from .zeitgeist import Date

    assert str(FXRateLookupError(Currency("EUR"), Currency("USD"), Date(2017, 12, 31))) \
        == "Foreign exchange rate for EUR/USD not found as of 2017-12-31"

# Generated at 2022-06-24 01:21:23.817691
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    # Set the date:
    date = Date.today()

    # Operate on EUR/USD FX rate:
    ccy1 = Currency.EUR
    ccy2 = Currency.USD

    # Assert object creation:
    e = FXRateLookupError(ccy1, ccy2, date)
    assert e.ccy1 == ccy1
    assert e.ccy2 == ccy2
    assert e.asof == date
    assert str(e) == "Foreign exchange rate for EUR/USD not found as of {}".format(date)


# Generated at 2022-06-24 01:21:29.501341
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    assert (~FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))) == \
           (FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5")))


# Generated at 2022-06-24 01:21:33.222398
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # Run PyCharm doctest
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    # Run PyCharm doctest
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 01:21:42.266111
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .temporal import Date
    from .finance.fxrates import FXRate, FXRateService, FXRateServiceDefault

    service = FXRateServiceDefault()

# Generated at 2022-06-24 01:21:45.746000
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-24 01:21:52.767154
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    return ~nrate == rrate


# Generated at 2022-06-24 01:22:01.021686
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:22:08.634280
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.currencies import Currencies
    from pypara.temporal import now

    class SampleFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == now().date:
                return FXRate.of(ccy1, ccy2, asof, Decimal("4.0"))
            else:
                return None

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    # Set the default FXRateService:
    FXRateService.default = SampleFXRateService()

    # Test query single

# Generated at 2022-06-24 01:22:15.130683
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from random import choice, randint
    from datetime import date
    from pypara.currencies import CURRENCIES
    for ccy1, ccy2 in ((choice(CURRENCIES), choice(CURRENCIES)) for _ in range(100)):
        if ccy1 == ccy2:
            value = Decimal(1)
        else:
            value = Decimal(randint(1, 100))
        fxr = FXRate(ccy1, ccy2, date.today(), value)
        if ccy1 == ccy2:
            assert fxr.value == Decimal(1)
            assert ~fxr.value == Decimal(1)
        else:
            assert ~fxr.value == Decimal(1) / value


# Generated at 2022-06-24 01:22:19.626135
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:22:31.120081
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.currencies.currency import Currency
    from pypara.currencies.currencies import Currencies
    from pypara.commons.zeitgeist import Date

    class FXRateService(object):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    assert FXRateService().query(Currencies["EUR"], Currencies["USD"], Date.today()) is None
    assert next(FXRateService().queries(None)) is None

# Generated at 2022-06-24 01:22:37.931102
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    lookup_error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    assert lookup_error.ccy1 == Currencies["EUR"]
    assert lookup_error.ccy2 == Currencies["USD"]
    assert lookup_error.asof == Date.today()


# Generated at 2022-06-24 01:22:45.583253
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """
    from .currencies import Currency

    eur = Currency("EUR")
    usd = Currency("USD")
    date = Date.now()
    error = FXRateLookupError(ccy1=eur, ccy2=usd, asof=date)
    assert error.ccy1 == eur
    assert error.ccy2 == usd
    assert error.asof == date

# Generated at 2022-06-24 01:22:50.960914
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class ConcreteFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    assert isinstance(ConcreteFXRateService(), FXRateService)

# Generated at 2022-06-24 01:22:58.291050
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:23:08.296781
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from collections import namedtuple
    from itertools import repeat
    from typing import Optional as Opt, Tuple as Tup
    from unittest.mock import Mock

    from pypara.currencies import Currency
    from pypara.exchanges.fxrates import FXRate, FXRateService

    # Mock the FXRateService: Note that we are not mocking the abstract base class, but the derived
    # class. This is because `mypy` will complain about an invalid abstract base class if we try to do
    # so.
    class MockFXRateService(FXRateService):
        def __init__(self) -> None:
            self.query = Mock()


# Generated at 2022-06-24 01:23:08.787799
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-24 01:23:12.718524
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    assert FXRateLookupError(Currency("EUR"), Currency("USD"), Date("2019-09-08")) is not None


# Generated at 2022-06-24 01:23:21.181794
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests constructor of class FXRateService.
    """

    ## The class is not intented to be instantiated directly:
    class _Service(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    ## The class must be a subclass of `ABCMeta`:
    assert issubclass(_Service, FXRateService)

    ## The class must have defined abstractmethods:
    assert hasattr(_Service, "query")
    assert hasattr(_Service, "queries")
    assert callable(_Service.query)
    assert callable(_Service.queries)
   

# Generated at 2022-06-24 01:23:21.999167
# Unit test for constructor of class FXRate
def test_FXRate():
    assert FXRate(None, None, None, None)

# Generated at 2022-06-24 01:23:27.644098
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests whether :method:`FXRate.__invert__` works as expected.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert(~nrate == rrate)


# Generated at 2022-06-24 01:23:37.065709
# Unit test for constructor of class FXRate
def test_FXRate():
    # Given rate
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import FXRate

    # When rate is created
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    # Then value should be expected
    assert(rate[0] == Currencies["EUR"])
    assert(rate[1] == Currencies["USD"])
    assert(rate[2] == datetime.date.today())
    assert(rate[3] == Decimal("2"))
    

# Generated at 2022-06-24 01:23:50.022748
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    from datetime import date
    from decimal import Decimal
    from typing import Iterable
    
    _dummy_queries = [
        (1, "A", date(2020, 1, 1)),
        (2, "B", date(2020, 2, 1)),
        (3, "C", date(2020, 3, 1)),
        (4, "D", date(2020, 4, 1))
    ]
    
    def _dummy():
        """
        Unit test specific dummy FX rate service.
        """
        from dataclasses import dataclass
        from pypara.currencies import Currency
        from pypara.util.temporal import Temporal
        

# Generated at 2022-06-24 01:24:00.741599
# Unit test for constructor of class FXRate
def test_FXRate():

    # Good:
    assert FXRate(Currency("EUR"), Currency("USD"), Date(2018, 12, 31), Decimal("2.5"))

    # Bad:
    try:
        FXRate(None, Currency("USD"), Date(2018, 12, 31), Decimal("2.5"))
        assert False
    except ValueError:
        pass

    try:
        FXRate(Currency("EUR"), None, Date(2018, 12, 31), Decimal("2.5"))
        assert False
    except ValueError:
        pass

    try:
        FXRate(Currency("EUR"), Currency("USD"), None, Decimal("2.5"))
        assert False
    except ValueError:
        pass


# Generated at 2022-06-24 01:24:09.740851
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    :return:
    """
    from .currencies import Currency as cls

    # test code
    from .currencies import Currency as cls

    # test code
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency as cls
    from pypara.fx.services import InMemoryFXRateService

    # prepare an in-memory FX rate service
    EUR = cls("EUR")
    USD = cls("USD")
    GBP = cls("GBP")
    JPY = cls("JPY")
    TRY = cls("TRY")
    CNY = cls("CNY")
    NOK = cls("NOK")

# Generated at 2022-06-24 01:24:18.390040
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

    nrate = FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), Decimal("1"))
    rrate = FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), Decimal("1"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:24.869434
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert nrate == ~rrate



# Generated at 2022-06-24 01:24:34.206266
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.fx.default import FXRateLookupError
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], date.today())
    except FXRateLookupError as ex:
        assert ex.ccy1 == Currencies["EUR"]
        assert ex.ccy2 == Currencies["USD"]
        assert ex.asof == date.today()
        assert ex.args == ("Foreign exchange rate for EUR/USD not found as of {}".format(date.today()),)


# Generated at 2022-06-24 01:24:46.227939
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """It tests the contructor of class FXRateLookupError."""
    from .currencies import Currencies
    from .commons.zeitgeist import Date, Datetime

    ## Trivial:
    assert(FXRateLookupError(Currencies.USD, Currencies.EUR, Date.today()).__str__() == "Foreign exchange rate for USD/EUR not found as of 2018-11-12")
    assert(FXRateLookupError(Currencies.USD, Currencies.EUR, Date.parse("2018-11-12")).__str__() == "Foreign exchange rate for USD/EUR not found as of 2018-11-12")

# Generated at 2022-06-24 01:24:52.391908
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:53.478627
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO(tugrulaslan): Implement ...
    pass


# Generated at 2022-06-24 01:25:02.498872
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .fxrates import FIXingFXRateService
    from .temporals import Date
    from decimal import Decimal
    service = FIXingFXRateService()
    rate1 = service.query(Currencies["EUR"], Currencies["USD"], Date.today())
    assert isinstance(rate1, FXRate)
    assert rate1[0] == Currencies["EUR"]
    assert rate1[1] == Currencies["USD"]
    assert rate1[2] == Date.today()
    assert isinstance(rate1[3], Decimal)
    rate2 = service.query(Currencies["USD"], Currencies["EUR"], Date.today())
    assert isinstance(rate2, FXRate)
    assert rate2[0] == Currencies["USD"]
    assert rate2[1] == Currencies

# Generated at 2022-06-24 01:25:13.141430
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): # noqa: D103
    from .currencies import Currency
    from .temporal import Date

    from decimal import Decimal

    from unittest import TestCase

    ## A mock implementation:
    class MockFXRateService(FXRateService):

        TQuery = FXRateService.TQuery

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal(1.0))

    ## Create the mock service:
    service = MockFXRateService()

    ## Create the

# Generated at 2022-06-24 01:25:25.558666
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fx.db import FXRateDB

    ## Initialize the DB:
    DB = FXRateDB.from_csv()

    ## Test None strict lookup:
    xrate = DB.query(Currencies["CHF"], Currencies["USD"], Date.today())
    print(xrate)
    assert xrate is not None
    assert isinstance(xrate, FXRate)
    assert xrate[0] == Currencies["CHF"]
    assert xrate[1] == Currencies["USD"]
    assert xrate[2] == Date.today()
    assert xrate[3] == Decimal("1.0912")

    ## Test strict lookup:

# Generated at 2022-06-24 01:25:32.481110
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests method __invert__ of class FXRate.

    >>> import datetime
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currencies
    >>> nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    >>> rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    >>> ~nrate == rrate
    True
    """


# Generated at 2022-06-24 01:25:33.925358
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for :meth:`FXRateService.queries` method.
    """
    ## TODO: Implement
    pass

# Generated at 2022-06-24 01:25:43.309532
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    :return:
    """
    # Setup
    from .currencies import Currency
    from .temporal import Temporal
    from .rates.fxrateservice import FXRateService as FXRateServiceImpl

    service = FXRateServiceImpl()
    queries = ((Currency.EUR, Currency.USD, Temporal.now()), (Currency.USD, Currency.EUR, Temporal.now()), (Currency.EUR, Currency.GBP, Temporal.now()))
    dates = (Temporal.now(), Temporal.now(), Temporal.now())

    # Invoke
    rates = service.queries(queries, strict=False)

    # Assert
    assert [r.ccy1 == q[0] for r, q in zip(rates, queries)]
   

# Generated at 2022-06-24 01:25:51.800481
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import TheNow

    ## Test constructor:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], TheNow())
    except FXRateLookupError as exc:
        ## Assertions:
        assert (
            str(exc) ==
            "Foreign exchange rate for EUR/USD not found as of 2018-09-05"
        )


# Generated at 2022-06-24 01:25:59.624088
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .commons.zeitgeist import Date

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert nrate == rrate


# Generated at 2022-06-24 01:26:09.918121
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import unittest
    from decimal import Decimal
    class TestFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return next((rate for rate in self.rates if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof), None)

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof)


# Generated at 2022-06-24 01:26:22.027106
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests for method queries of class FXRateService.
    """
    from .currencies import Currencies
    from .temporal import Dates

    from datetime import date
    from decimal import Decimal

    from unittest import TestCase, main

    from unittest.mock import patch

    class Test(TestCase):
        """
        Unit test for method queries of class FXRateService.
        """

        def test_method_queries(self) -> None:
            """
            Tests for method queries of class FXRateService.
            """
            # Arrange:

# Generated at 2022-06-24 01:26:28.769641
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:26:37.464237
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for the constructor of class FXRateService.
    """
    from .commons.zeitgeist import Temporal
    from .currencies import Currency, Currencies
    from .exchanges import FXRateExchange
    from .markets.trading import Market
    from .products import Asset, TradeExchangePair

    ## Prepare the FX rate service:
    FXRateService.default = FXRateExchange(Market.default, Currencies.default, Temporal.default)

    ## Get the FX rate:
    rate = FXRateService.default(Currencies["EUR"], Currencies["USD"], Temporal.default)
    assert isinstance(rate, FXRate)
    assert rate == FXRate(Currencies["EUR"], Currencies["USD"], Temporal.default, Decimal("1.1517"))

    ## Get the inverted FX rate:


# Generated at 2022-06-24 01:26:45.545159
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .commons.numbers import Decimal
    from .commons.zeitgeist import Date
    from .currencies import Currency, Currencies
    from .services.simple_fx_rate_service import SimpleFXRateService

    ## Create a service:
    service = SimpleFXRateService(
        [
            (Currencies["EUR"], Currencies["USD"], Date(2019, 1, 1), Decimal(2)),
            (Currencies["USD"], Currencies["EUR"], Date(2019, 1, 1), Decimal(0.5)),
        ]
    )

    ## Query rates:

# Generated at 2022-06-24 01:26:51.310164
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-24 01:26:58.537461
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the :method:`FXRateService.queries` method.
    """
    from .commons.zeitgeist import Temporal
    from .currencies import Currencies

    ## Define an FX rate lookup service:
    class FXRateServiceMock(FXRateService):
        def __init__(self, rates: Iterable[Tuple[Currency, Currency, Temporal, float]]) -> None:
            self.rates = [(ccy1, ccy2, date, Decimal(str(value))) for ccy1, ccy2, date, value in rates]


# Generated at 2022-06-24 01:27:03.711223
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, metaclass=ABCMeta)
    assert FXRateService.default == None
    assert FXRateService.TQuery == tuple


# Generated at 2022-06-24 01:27:10.183804
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate) == rrate

# Generated at 2022-06-24 01:27:15.415259
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert ~FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == \
           FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-24 01:27:20.333320
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:27:28.541588
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests the __init__ method of class FXRate.
    """
    # Import packages:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Create a rate instance to be inverted:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    # Create an inverted rate instance:
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    # Assert the inversion:
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:27:37.915190
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of the class :class:`FXRateLookupError`, by creating an instance and checking its
    properties.
    """
    from .currencies import Currencies
    from .calendars import BusinessCalendar
    from .zeitgeist import Date

    ## Create the object:
    today = Date(Date.today(), calendar=BusinessCalendar.default)
    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], today)

    ## Check the properties:
    assert e.ccy1 == Currencies["EUR"]
    assert e.ccy2 == Currencies["USD"]
    assert e.asof == today

# Generated at 2022-06-24 01:27:47.261144
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:27:51.910584
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:28:02.522262
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError` class.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Assign
    try:
        rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
        raise AssertionError("Lookup error expected")
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == date.today()


# Generated at 2022-06-24 01:28:10.208834
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest
    from .currencies import Currency

    with pytest.raises(FXRateLookupError) as exc:
        raise FXRateLookupError(Currency("EUR"), Currency("USD"), Date("2019-01-01"))

    assert str(exc.value) == "Foreign exchange rate for EUR/USD not found as of 2019-01-01"

if __name__ == "__main__":
    import pytest
    pytest.main(args=[__file__])

# Generated at 2022-06-24 01:28:19.339084
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    class MockFXRateService(FXRateService):
        """
        Provides a mock FXRateService implementation.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            for query in queries:
                yield None

    ## Run the test:

# Generated at 2022-06-24 01:28:28.799799
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date, Period
    from pypara.currencies.fxrates import FXRateService

    # Local import
    from .currencies.fxrates import FXRateService

    class TestRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date,
                  strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and asof == Date(2000, 1, 1):
                return FXRate(Currencies["USD"], Currencies["EUR"], asof, 2)
            else:
                return None

    rsvc = TestRateService()
