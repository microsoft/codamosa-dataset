

# Generated at 2022-06-24 01:18:37.123714
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import collections
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.forex.rates import FXRate
    from pypara.forex.rates import FXRateService

    class MyFXService(FXRateService):
        def __init__(self):
            self.rates = collections.defaultdict(list)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            query = (ccy1, ccy2, asof)
            rate = None
            try:
                rate = next(r for r in self.rates[query] if r[0] >= asof)
            except StopIteration:
                pass
            if strict and not rate:
                raise FXRateLookup

# Generated at 2022-06-24 01:18:49.965618
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Tests that a foreign exchange rate object is correctly constructed.
    """
    ## Successful construction:
    assert FXRate(Currency.of("EUR"), Currency.of("USD"), Date.of("2018-07-01", "%Y-%m-%d"), Decimal("2"))

    ## Raise errors:
    #: Invalid `Currency` instance:
    try:
        FXRate(Currency.of("EUR"), Currency.of("USD"), Date.of("2018-07-01", "%Y-%m-%d"), Decimal("1"), "Foo")
        assert False
    except TypeError:
        assert True
    #: Invalid `Currency` instance:

# Generated at 2022-06-24 01:18:59.188907
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Tests the constructor of the :class:`FXRate` class.
    """
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:19:05.733708
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate

# Generated at 2022-06-24 01:19:12.890568
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """
    ## Check the existence of the constructor:
    assert hasattr(FXRateLookupError, "__init__")

    ## Invoke the constructor and check the result:
    import datetime

    from pypara.currencies import Currencies

    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert error
    assert isinstance(error, LookupError)
    assert isinstance(error, FXRateLookupError)
    assert error.ccy1 is Currencies["EUR"]
    assert error.ccy2 is Currencies["USD"]
    assert error.asof is datetime.date.today()

# Generated at 2022-06-24 01:19:19.274513
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:19:25.298219
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fxrates import FXRateService as _FXRateService

    class _Impl(_FXRateService):
        def __init__(self, fxrates):
            self._fxrates = fxrates

        def query(self, ccy1, ccy2, asof, strict=False):
            try:
                return self._fxrates[(ccy1, ccy2, asof)]
            except KeyError as e:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof) from e
                else:
                    return None

        def queries(self, queries, strict=False):
            for query in queries:
                yield self.query(*query, strict)

    f

# Generated at 2022-06-24 01:19:31.727849
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    return ~nrate == rrate


# Generated at 2022-06-24 01:19:36.763337
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    luerr = FXRateLookupError(Currency.of("USD"), Currency.of("EUR"), Date.today())
    assert luerr.ccy1 == Currency.of("USD")
    assert luerr.ccy2 == Currency.of("EUR")
    assert luerr.asof == Date.today()


# Generated at 2022-06-24 01:19:47.788398
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Define test cases:

# Generated at 2022-06-24 01:19:54.668504
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FixedFXRateService

    # Create an FX rate service:
    service = FixedFXRateService(
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 1, 2), Decimal("0.8")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date(2018, 1, 2), Decimal("1.25")),
    )

    # Lookup an existing EUR/USD FX rate:

# Generated at 2022-06-24 01:19:57.470547
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None
    assert FXRateService.TQuery == Tuple[Currency, Currency, Date]


# Generated at 2022-06-24 01:20:03.765168
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Temporal
    from .datetime.datetime import Date

    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    assert e.ccy1 == Currencies["EUR"]
    assert e.ccy2 == Currencies["USD"]
    assert e.asof == Date.today()


# Generated at 2022-06-24 01:20:11.741762
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.time import Date
    from pypara.fxrates import FXRateLookupError
    from pypara.fxrates import FXRate

    ## Test the constructor of FXRateLookupError:
    ##
    ## Instantiate an empty instance:
    try:
        ccy1 = Currencies["USD"]
        ccy2 = Currencies["EUR"]
        asof = Date.today()
        rate = FXRateLookupError(ccy1, ccy2, asof)
    except Exception:
        assert False, "Unable to instantiate an empty instance of class `FXRateLookupError`"

    ## Check the type of the instance:
    assert isinstance(rate, FXRateLookupError), "Instantiated instance is not of type `FXRateLookupError`"

# Generated at 2022-06-24 01:20:19.740091
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create an FX rate service:
    class _FXRateService(FXRateService):
        """
        Provides a dummy FX rate service.
        """
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

        ## Implement the method:

# Generated at 2022-06-24 01:20:22.441696
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    # The following statement must not fail:
    FXRateLookupError(Currency("EUR"), Currency("USD"), Date.today())


# Generated at 2022-06-24 01:20:26.306857
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Timestamps
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Timestamps["2018-01-02"])
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == Timestamps["2018-01-02"]
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2018-01-02"


# Generated at 2022-06-24 01:20:32.963926
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`:
    """
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date.today()
    try:
        raise FXRateLookupError(ccy1, ccy2, asof)
    except FXRateLookupError as fxl:
        ## Make sure the exception is raised:
        assert True
        ## Make sure the data is kept:
        assert fxl.ccy1 == ccy1
        assert fxl.ccy2 == ccy2
        assert fxl.asof == asof


# Generated at 2022-06-24 01:20:39.308775
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests the :method:`FXRate.__invert__` method.
    """
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:45.089284
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        raise FXRateLookupError("EUR", "USD", "2019-01-01")
    except FXRateLookupError as ex:
        assert ex.ccy1 == "EUR"
        assert ex.ccy2 == "USD"
        assert ex.asof == "2019-01-01"
    else:
        assert False


# Generated at 2022-06-24 01:20:51.849895
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from datetime import date

    from .currencies import Currencies
    from .foreignexchange import FXRate, FXRateLookupError

    EUR = Currencies["EUR"]
    USD = Currencies["USD"]
    DATE = date(year=2019, month=1, day=1)
    VALUE = Decimal("2")

    assert FXRate(EUR, USD, DATE, VALUE) == ~FXRate(USD, EUR, DATE, Decimal("0.5"))

# Generated at 2022-06-24 01:20:54.365968
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    err = FXRateLookupError(ccy1="ccy1", ccy2="ccy2", asof=Date.today())
    assert err.ccy1 == "ccy1"
    assert err.ccy2 == "ccy2"
    assert err.asof == Date.today()
    assert str(err) == "Foreign exchange rate for ccy1/ccy2 not found as of 2020-01-02"


# Generated at 2022-06-24 01:20:59.088528
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    assert ~FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-24 01:21:06.668988
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.core.temporal import Time

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Time.now())
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == Time.now()
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2018-02-24T18:53:53.364426"
    else:
        assert False

# Unit tests for class FXRate

# Generated at 2022-06-24 01:21:17.783794
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.datetime import Date

    from .datastores import MemoryDataStore

    from .services import FXRateServiceImpl

    queries = [
        (Currencies["EUR"], Currencies["USD"], Date.today()),
        (Currencies["EUR"], Currencies["USD"], Date.today() - 1),
        (Currencies["EUR"], Currencies["USD"], Date.today() + 1),
    ]

    datastore = MemoryDataStore()
    datastore.save(FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), 1.23))
    datastore.save(FXRate(Currencies["EUR"], Currencies["USD"], Date.today() - 1, 1.32))

# Generated at 2022-06-24 01:21:26.240031
# Unit test for constructor of class FXRate
def test_FXRate():
    from pypara.currencies import Currencies
    import datetime

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:21:37.299441
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService.
    """

    # Imports:
    from pypara.currencies import Currencies
    import datetime

    # Create a Foreign Exchange Rate :
    rate = FXRate(Currencies["EUR"],Currencies["USD"],datetime.date.today(),Decimal("2"))
    assert rate.date == datetime.date.today()
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.value == Decimal("2")

    # Invert the Foreign Exchange Rate :
    rate = ~rate
    assert rate.date == datetime.date.today()
    assert rate.ccy1 == Currencies["USD"]
    assert rate.ccy2 == Currencies["EUR"]
    assert rate.value

# Generated at 2022-06-24 01:21:41.261164
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.env import Env
    env = Env()
    assert isinstance(env, FXRateService)

# Generated at 2022-06-24 01:21:44.869014
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)

# Generated at 2022-06-24 01:21:54.478884
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ##
    ## Constructor
    ##
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    lerror = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert lerror.ccy1 == Currencies["EUR"]
    assert lerror.ccy2 == Currencies["USD"]
    assert lerror.asof == datetime.date.today()
    assert str(lerror) == "Foreign exchange rate for EUR/USD not found as of " + datetime.date.today().isoformat()



# Generated at 2022-06-24 01:21:55.486269
# Unit test for constructor of class FXRateService
def test_FXRateService():
    FXRateService()


# Generated at 2022-06-24 01:22:04.458813
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from datetime import date
    import pytest

    from pypara.currencies import Currencies

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.25"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    with pytest.raises(ValueError, match="CCY/1 must be of type `Currency`."):
        rate = FXRateServiceImpl().query(None, None, None)


# Generated at 2022-06-24 01:22:11.020372
# Unit test for constructor of class FXRateService
def test_FXRateService():

    # Create objects to be used within tests:
    class Mock(metaclass=ABCMeta):
        @abstractmethod
        def query(self, ccy1, ccy2, asof):
            pass

        @abstractmethod
        def queries(self, cqs):
            pass

    c = Mock()

    # Test default value of attribute default:
    assert FXRateService.default is None

    # Test default value of attribute default:
    assert FXRateService.default is None

    # test attribute TQuery
    assert FXRateService.TQuery == (Currency, Currency, Date)


# Generated at 2022-06-24 01:22:19.697133
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries for class FXRateService.
    """
    from unittest import TestCase
    from unittest.mock import Mock, patch
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date, Temporal

    ## Define the test case class:
    class FXRateServiceTest(TestCase):
        pass

    ## Define a test for querying:
    def test_query(self):
        """
        Tests query method for class FXRateService.
        """
        ## Mock the service:
        service = Mock(spec=FXRateService)

        ## Mock the query result:
        result = Mock(spec=FXRate)

        ## Create the query tuple:
        query = (Currency(code="EUR"), Currency(code="USD"), Date.today())

        ##

# Generated at 2022-06-24 01:22:21.535523
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-24 01:22:28.866344
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert nrate[0] == Currencies["EUR"]
    assert nrate[1] == Currencies["USD"]
    assert nrate[2] == datetime.date.today()
    assert nrate[3] == Decimal("2")


# Generated at 2022-06-24 01:22:30.559003
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Testing this method is not possible without creating a concrete implementation
    pass


# Generated at 2022-06-24 01:22:42.373877
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests class :class:`FXRateService` method :meth:`FXRateService.query`.
    """

    ## Mock the foreign exchange rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency.of("EUR") and ccy2 == Currency.of("USD"):
                return FXRate(ccy1, ccy2, asof, Decimal("1.34"))
            elif ccy1 == Currency.of("USD") and ccy2 == Currency.of("EUR"):
                return FXRate(ccy1, ccy2, asof, Decimal("0.74"))
            else:
                return None


# Generated at 2022-06-24 01:22:44.202290
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert True == True


# Generated at 2022-06-24 01:22:50.690774
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert (~nrate == rrate)


# Generated at 2022-06-24 01:23:01.183087
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .dates import Period, TimeUnits
    from .temporal import Temporal

    from .sources import HistoricalFXRateService

    rate_service = HistoricalFXRateService("rates.csv")
    rate_queries = [
        (Currencies["EUR"], Currencies["USD"], Temporal("2018-12-31")),
        (Currencies["EUR"], Currencies["USD"], Temporal("2019-12-31")),
    ]
    rates = rate_service.queries(rate_queries, strict=True)
    assert rates

    rates = rate_service.queries(rate_queries, strict=False)
    assert rates

    rates = rate_service.queries(rate_queries)
    assert rates


# Generated at 2022-06-24 01:23:11.249163
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.finance.currencies import Currency
    from pypara.finance.temporal import Date
    from pypara.finance.services import FXRateService, FXRateServiceImpl
    from pypara.finance.rates import FXRate, FXRateLookupError
    from pypara.commons.intersperser import interspersed

    ## Initialize the rate service:
    rate_service = FXRateServiceImpl()

    ## Test FXRateService.queries:
    ## - should return None for unknown FX rates:
    assert tuple(rate_service.queries(
        iter(interspersed((Currency[1], Currency[2], Date[0]))))) == (None,)

    ## - should return known FX rates as of a given date:

# Generated at 2022-06-24 01:23:20.768317
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.financial.fx_rates import FXRate, FXRateService

    class FXRateServiceMock(FXRateService):
        """
        Mocks foreign exchange rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    # Mock FXRateService.query

# Generated at 2022-06-24 01:23:32.328841
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pytest
    from pypara.currencies import Currencies
    from pypara.curves.fx import FXRateService
    from pypara.curves.fx import FXRateLookupError
    from pypara.commons.zeitgeist import now

    class BadService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

    class GoodService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, ONE)

    bad_service = BadService()
    good_service = GoodService()
    c

# Generated at 2022-06-24 01:23:38.698518
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:23:45.491598
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:23:53.428863
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fx import FXRate

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], Date.now(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], Date.now(), Decimal("0.5"))

    if not (~nrate == rrate):
        raise AssertionError("Invalid inversion")


# Generated at 2022-06-24 01:23:54.257290
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService is not None

# Generated at 2022-06-24 01:24:02.701960
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.
    """
    import datetime

    fxrate_error = FXRateLookupError(Currency("EUR"), Currency("USD"), datetime.date(year=2020, month=1, day=1))
    assert fxrate_error.ccy1 == Currency("EUR")
    assert fxrate_error.ccy2 == Currency("USD")
    assert fxrate_error.asof == datetime.date(year=2020, month=1, day=1)
    assert fxrate_error.args == (
        "Foreign exchange rate for EUR/USD not found as of 2020-01-01",
    )



# Generated at 2022-06-24 01:24:11.261718
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-24 01:24:19.838143
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from .currencies import Currencies
    from .finance.curves import FXCurve
    from .finance.curves import FXCurveNode
    from .finance.curves import FXCurveSampling
    from .finance.curves import FXCurveService
    from .finance.curves import FXCurveTimeDimension
    from .tolerance import Tolerance

    ## Create the FX curve:

# Generated at 2022-06-24 01:24:23.125506
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:31.408449
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)



# Generated at 2022-06-24 01:24:43.831116
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currencies    # noqa: F401
    from pypara.fx import FXRate, FXRateService
    from datetime import date

    class RateService(FXRateService):
        """
        A simple foreign exchange rate service that returns hard-coded FX rates.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            rates = self._get_rates()
            rate = rates.get((ccy1, ccy2, asof))

# Generated at 2022-06-24 01:24:55.398676
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .zeitgeist import today
    from .products import FXRate

    ## Prepare the fx rates:
    rates = [
        FXRate.of(Currencies["EUR"], Currencies["USD"], today(), Decimal("2")),
        FXRate.of(Currencies["USD"], Currencies["EUR"], today(), Decimal("0.5")),
    ]

    ## Define a test service:
    class FXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            rate = super().query(ccy1, ccy2, asof, strict)
            return rate if rate is not None else rates[0]


# Generated at 2022-06-24 01:25:00.506190
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    from .zeitgeist import Date

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], Date.today(), Decimal("0.5"))
    assert ~nrate == rrate, "Foreign exchange rate with currencies in reverse order must be inversed."



# Generated at 2022-06-24 01:25:12.761110
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporal import Temporal
    from .currencies import Currencies
    from .fx import FXRateLookupError, FXRateService, FXRate

    now = Temporal.now()

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == now:
                return FXRate(Currencies["USD"], Currencies["EUR"], asof, Decimal("0.5"))
            else:
                return None


# Generated at 2022-06-24 01:25:19.702130
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit-test for the constructor of class :class:`FXRateLookupError`.
    """
    import datetime

    ## Create an FX rate lookup error object:
    error = FXRateLookupError(Currency.of_code("EUR"), Currency.of_code("USD"), datetime.date.today())

    #: Make sure the required attributes are set:
    assert error.ccy1 == Currency.of_code("EUR")
    assert error.ccy2 == Currency.of_code("USD")
    assert error.asof == datetime.date.today()
    assert isinstance(error.args[0], str)



# Generated at 2022-06-24 01:25:25.289250
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:25:36.863049
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.

    >>> test_FXRateLookupError()
    """
    from pypara.currencies import Currency, Currencies
    from typing import TYPE_CHECKING

    if TYPE_CHECKING:
        from pypara.misc.datetime import Date

    ccy1 = Currency("EUR", "EUR")
    ccy2 = Currency("USD", "USD")
    date = Date()

    error = FXRateLookupError(ccy1, ccy2, date)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == date
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 0001-01-01"


# Generated at 2022-06-24 01:25:43.833933
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:25:46.838798
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    rate = FXRate(Currency("EUR"), Currency("USD"), datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currency("EUR")
    assert ccy2 == Currency("USD")
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:25:50.379824
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    assert FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2")) is not None


# Generated at 2022-06-24 01:26:00.117768
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Test the abstract class FXRateService.
    """
    import unittest

    class TestFXRateService(FXRateService):
        """
        Defines a test class for FXRateService.
        """


# Generated at 2022-06-24 01:26:08.552613
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from datetime import date
    from .currencies import Currency, Currencies

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = date.today()
    r0 = Decimal("2")
    r1 = Decimal("0.5")
    x0 = FXRate(ccy1, ccy2, asof, r0)
    x1 = FXRate(ccy2, ccy1, asof, r1)
    assert x0 == ~x1
    assert x1 == ~x0


# Generated at 2022-06-24 01:26:21.409219
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Provides unit tests for the abstract class :class:`FXRateService`.
    """
    from abc import ABCMeta
    from inspect import isabstract

    from .currency import Currencies
    from .commons.zeitgeist import asof_today

    # Assert that the class is abstract:
    assert issubclass(FXRateService, ABCMeta), "Class FXRateService must be abstract."
    assert isabstract(FXRateService), "Class FXRateService must be abstract."

    # Assert queries method:
    assert FXRateService.queries(FXRateService, [], True) is not None, "Abstract method `queries` must be implemented."

    # Assert query method:

# Generated at 2022-06-24 01:26:30.410271
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for the method query of class FXRateService
    """
    ## Test class:
    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass

        def queries(self, queries, strict=False):
            pass
    ## Test assertions:
    try:
        TestFXRateService().query("", "", "", False)
        raise AssertionError("The abstract method should have been called.")
    except NotImplementedError:
        pass


# Generated at 2022-06-24 01:26:36.390379
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))


# Generated at 2022-06-24 01:26:44.743099
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies

    FAIL = None
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date("2017-12-31"))
    except Exception as ex:
        FAIL = ex

    assert FAIL is not None
    assert str(FAIL) == "Foreign exchange rate for EUR/USD not found as of 2017-12-31"
    assert FAIL.ccy1 == Currencies["EUR"]
    assert FAIL.ccy2 == Currencies["USD"]
    assert FAIL.asof == Date("2017-12-31")


# Generated at 2022-06-24 01:26:45.691282
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    pass


# Generated at 2022-06-24 01:26:52.229470
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from pypara.dao import inmemory
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService
    import pytest

    ## Create a dummy FX rate service provider:
    class TestProvider(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            self.rates = rates


# Generated at 2022-06-24 01:26:59.821985
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    # Create a dummy class inheriting from FXRateService
    class Service(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            pass

        def queries(self, queries, strict):
            pass

    service = Service()
    assert service, 'unit test failed.'


# Generated at 2022-06-24 01:27:04.103811
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():     # noqa: D103
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:27:10.508934
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:27:17.154517
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:27:24.365121
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    This method tests the initialization of FXRateLookupError class.
    """
    import datetime
    from pypara.currencies import Currencies

    ## Check the error construction:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    ## Check the error message:
    assert error.message == "Foreign exchange rate for EUR/USD not found as of " + str(datetime.date.today())  # noqa: E501

    ## Check the slots:
    ccy1 = error.ccy1
    ccy2 = error.ccy2
    date = error.asof
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()



# Generated at 2022-06-24 01:27:27.546789
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.value == Decimal("2")

# Generated at 2022-06-24 01:27:33.996864
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test that checks the functionality of :class:`FXRateService`.

    >>> from pypara.fxrates import FXRateService
    >>> from pypara.mock import MockFXRateService
    >>> service = MockFXRateService()
    >>> FXRateService.default = service
    >>> isinstance(service, FXRateService)
    True
    >>> service.default is FXRateService.default
    True
    """
    pass


# Generated at 2022-06-24 01:27:42.888986
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .temporal import Dates
    # Test for case 'ccy1' is of wrong type Currency
    try:
        FXRate('EUR', Currencies['USD'], Dates['2019-01-01'], 1)
        assert False, 'Expected ValueError to be raised for wrong type argument.'
    except ValueError:
        pass
    # Test for case 'ccy2' is of wrong type Currency
    try:
        FXRate(Currencies['EUR'], 'USD', Dates['2019-01-01'], 1)
        assert False, 'Expected ValueError to be raised for wrong type argument.'
    except ValueError:
        pass
    # Test for case 'date' is of wrong type Temporal

# Generated at 2022-06-24 01:27:45.669790
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert isinstance(FXRateService, ABCMeta)
    assert isinstance(FXRateService.query, abstractmethod)
    assert isinstance(FXRateService.queries, abstractmethod)
    assert isinstance(FXRateService.default, Optional["FXRateService"])
    assert len(FXRateService.__abstractmethods__) == 2

# Local test for FXRate.of

# Generated at 2022-06-24 01:27:48.885254
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    # The class FXRateService is abstract, so this test has no expectation of successful execution.
    try:
        FXRateService.query(None, None, None, None)
    except NotImplementedError:
        pass



# Generated at 2022-06-24 01:27:49.613968
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """

    pass

# Generated at 2022-06-24 01:27:54.637291
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporal import Temporal
    from .currencies import Currencies
    from .fx import FXRateService

    class MockService(FXRateService):
        def __init__(self):
            self._rates = [
                FXRate.of(Currencies["USD"], Currencies["EUR"], Date("2018-12-31"), Decimal("0.8")),
                FXRate.of(Currencies["EUR"], Currencies["USD"], Date("2018-12-31"), Decimal("1.25")),
            ]


# Generated at 2022-06-24 01:28:05.840298
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.commons.zeitgeist import Date
    from pypara.fx.fx_rates import FXRateService

    # A demo class implementing the FXRateService:
    class DemoFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            self._rates = {}
            for rate in rates:
                self._rates[(rate.ccy1, rate.ccy2, rate.date)] = rate


# Generated at 2022-06-24 01:28:14.755182
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate
    """
    from .currencies import Currencies
    from .commons.zeitgeist import today

    ccy1, ccy2 = Currencies["EUR"], Currencies["USD"]
    date, value = today(), Decimal("2")
    rate = FXRate(ccy1, ccy2, date, value)

    assert ccy1 == rate.ccy1
    assert ccy2 == rate.ccy2
    assert date == rate.date
    assert value == rate.value


# Generated at 2022-06-24 01:28:15.723491
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None



# Generated at 2022-06-24 01:28:17.814062
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass


# Generated at 2022-06-24 01:28:19.982775
# Unit test for constructor of class FXRateService
def test_FXRateService():
    with raises(TypeError):
        FXRateService()

# Generated at 2022-06-24 01:28:26.899085
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.currencies import Currencies

    class Dummy(FXRateService):
        def __init__(self):
            self.rates = list()

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    dummy = Dummy()

    assert dummy is not None