

# Generated at 2022-06-24 01:18:32.698338
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-24 01:18:45.329799
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method of :class:`FXRateService`
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService

    class FXRateServiceFake(FXRateService):
        """
        Provides a fake FX rate service.
        """


# Generated at 2022-06-24 01:18:53.474145
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert(ccy1 == Currencies["EUR"])
    assert(ccy2 == Currencies["USD"])
    assert(date == datetime.date.today())
    assert(value == Decimal("2"))


# Generated at 2022-06-24 01:19:00.958003
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    # import necessary
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    # make sure that invert of 1 unit rate is equal to itself, invert of inverted rate is equal to original rate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1"))
    rrate = FXRate.of(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("1"))
    assert (~nrate == nrate)
    assert (~~nrate == rrate)


# Generated at 2022-06-24 01:19:02.088529
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__(): pass  # pragma: no cover


# Generated at 2022-06-24 01:19:04.025609
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    pass


# Generated at 2022-06-24 01:19:11.504439
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## Initialize currencies:
    from .currencies import Currencies
    eur = Currencies["EUR"]
    usd = Currencies["USD"]
    date = Date.today()

    ## Create the error:
    error = FXRateLookupError(eur, usd, date)

    ## Check the slots:
    assert error.ccy1 == eur
    assert error.ccy2 == usd
    assert error.asof == date

    ## Check the message:
    assert str(error) == f"Foreign exchange rate for EUR/USD not found as of {date}"


# Generated at 2022-06-24 01:19:18.162050
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:19:24.653368
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Set the unit test scope:
    scope = {}

    # Execute the unit test:

# Generated at 2022-06-24 01:19:27.097120
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:33.464862
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .services import FixedFXRateService

    # Fixed FX Rate Service:
    svc = FixedFXRateService()

    # FX rate class:
    from .currencies import Currencies
    from .commons.zeitgeist import Now

    # Create a query:
    query = (Currencies["EUR"], Currencies["USD"], Now)

    # Query a rate:
    assert isinstance(svc.query(*query), FXRate)


# Generated at 2022-06-24 01:19:40.064955
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:46.086038
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService.
    """

    ## Make the compiler happy:
    class Service(FXRateService):
        """
        Provides an empty implementation of an FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass  # pragma: no cover

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass  # pragma: no cover

    service = Service()

    return service


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 01:19:53.130284
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():  # noqa: E501
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    nrate = ~rate
    assert nrate.ccy1 == Currencies["USD"]
    assert nrate.ccy2 == Currencies["EUR"]
    assert nrate.date == rate.date
    assert nrate.value == Decimal("0.5")


# Generated at 2022-06-24 01:19:58.411242
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .commons.zeitgeist import Date

    ## No Argument
    try:
        FXRateLookupError()
        assert False
    except TypeError:
        pass

    ## Currency Argument
    try:
        FXRateLookupError(currency, currency, date)
        assert False
    except TypeError:
        pass

    ## Date Argument
    try:
        FXRateLookupError(Currency, Currency, date)
        assert False
    except TypeError:
        pass

    # Valid
    try:
        FXRateLookupError(Currency, Currency, Date)
        assert True
    except TypeError:
        assert False



# Generated at 2022-06-24 01:20:05.081471
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test the queries method of FXRateService
    """
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara import Temporal
    from pypara.test.test_FXRateService import Source

    s = Source()
    dates = [date(2020, 1, 1), date(2020, 1, 2)]
    queries = [
        (Currencies["EUR"], Currencies["USD"], Temporal(dates[0])),
        (Currencies["USD"], Currencies["EUR"], Temporal(dates[1])),
        (Currencies["EUR"], Currencies["USD"], Temporal(dates[1]))
    ]
    rates = s.queries(queries)

# Generated at 2022-06-24 01:20:11.337265
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    assert FXRate(Currencies["EUR"], "USD", datetime.date.today(), Decimal("2.1")) == (Currencies["EUR"], "USD", datetime.date.today(), Decimal("2.1"))

# Generated at 2022-06-24 01:20:19.168557
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.temporal import Temporal
    from .services import StaticFXRateService
    from .currencies import Currency

    s = StaticFXRateService({
        (Currency("EUR"), Currency("USD"), Temporal("2019-01-01")): FXRate(Currency("EUR"), Currency("USD"), Temporal("2019-01-01"), Decimal("2"))
    })

    assert s.query(Currency("EUR"), Currency("USD"), Temporal("2019-01-01")) == FXRate(Currency("EUR"), Currency("USD"), Temporal("2019-01-01"), Decimal("2"))

# Generated at 2022-06-24 01:20:26.342569
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert(rate[0] == Currencies["EUR"])
    assert(rate[1] == Currencies["USD"])
    assert(rate[2] == datetime.date.today())
    assert(rate[3] == Decimal("2"))


# Generated at 2022-06-24 01:20:34.914495
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():  # noqa: D103
    from .currencies import Currencies

    ccy1, ccy2, asof = Currencies["EUR"], Currencies["USD"], Date.today()
    error = FXRateLookupError(ccy1, ccy2, asof)

    assert error.ccy1 is ccy1
    assert error.ccy2 is ccy2
    assert error.asof == asof
    assert error.args[0] == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}"


# Generated at 2022-06-24 01:20:35.514416
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-24 01:20:43.854791
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):

            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))

            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("0.8"))

            if strict:
                raise FXRateLook

# Generated at 2022-06-24 01:20:45.157257
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    assert issubclass(FXRateService, object)

# Generated at 2022-06-24 01:20:49.437815
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporal import Temporal
    from .commons.types import T
    from .currencies import Currencies
    from .marketdata import (
        MarketData,
        MarketDataType,
    )

    mdata = MarketData(
        type = MarketDataType.FX_RATE,
        provider = "EURONEXT",
        currency1 = Currencies["EUR"],
        currency2 = Currencies["USD"],
        value = Decimal("1"),
        exdate = Date(2016, 1, 4),
        term = Temporal(Date(2016, 1, 6), Date(2016, 1, 6)),
    )

# Generated at 2022-06-24 01:20:56.458748
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate.of(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:21:01.838139
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:21:10.161226
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency  # noqa: E402
    from .temporal import Date  # noqa: E402
    from .commons import Decimal  # noqa: E402
    from .static.fxrateservice import FXRateService as StaticFXRateService  # noqa: E402
    queries = (
        (Currency["EUR"], Currency["USD"], Date(2017, 11, 25)),
        (Currency["EUR"], Currency["USD"], Date(2017, 11, 26)),
        (Currency["EUR"], Currency["USD"], Date(2017, 11, 27)),
    )

# Generated at 2022-06-24 01:21:12.954093
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class FXRateLookupError.
    """

    # Import:
    from .currencies import Currencies
    from .zerod import Date

    # Create an FX rate lookup error:
    excp = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())

    # Check attributes:
    assert excp.ccy1 == Currencies["EUR"]
    assert excp.ccy2 == Currencies["USD"]
    assert excp.asof == Date.today()


# Generated at 2022-06-24 01:21:16.465673
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .currencies.zeitgeist import Date

    try:
        raise FXRateLookupError(ccy1=Currencies["USD"], ccy2=Currencies["EUR"], asof=Date.today())
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["USD"]
        assert e.ccy2 == Currencies["EUR"]
        assert e.asof == Date.today()


# Generated at 2022-06-24 01:21:19.341175
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:24.775860
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import today
    from .finance import Money

    class StubRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["TRY"]:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Date]], strict: bool = False) -> \
                Iterable[Optional[FXRate]]:
            rates = []

# Generated at 2022-06-24 01:21:35.948843
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporal import Temporal
    from .currencies import EUR, USD

    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.5"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict=strict)

    service = MockFXRateService()

    # Test single tuple:

# Generated at 2022-06-24 01:21:39.211534
# Unit test for constructor of class FXRateService
def test_FXRateService(): # pragma: no cover
    from unittest import TestCase

    class Test(TestCase):
        def test_abstract_methods(self):
            self.assertRaises(TypeError, FXRateService)
            self.assertRaises(NotImplementedError, FXRateService().query, None, None, None)
            self.assertRaises(NotImplementedError, FXRateService().queries, None)

    return Test


# Generated at 2022-06-24 01:21:45.170878
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:50.938222
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    assert (
        FXRate(
            Currency("EUR"),
            Currency("USD"),
            Date.today(),
            Decimal("2"),
        ).__invert__()
        == FXRate(
            Currency("USD"),
            Currency("EUR"),
            Date.today(),
            Decimal("0.5"),
        )
    )

# Generated at 2022-06-24 01:22:00.921302
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    class MockFXRateService(FXRateService):
        def query(
                self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False
        ) -> Optional[FXRate]:
            raise FXRateLookupError(ccy1, ccy2, asof)

        def queries(
                self, queries: Iterable[Tuple[Currency, Currency, Date]], strict: bool = False
        ) -> Iterable[Optional[FXRate]]:
            raise NotImplementedError()

    FXRateService.default = MockFXRateService()

    try:
        FXRateService.default.query(Currency("EUR"), Currency("USD"), Date(1980, 11, 14))
    except FXRateLookupError as e:
        assert e.ccy1 == Currency("EUR")
        assert e.cc

# Generated at 2022-06-24 01:22:08.577388
# Unit test for method queries of class FXRateService

# Generated at 2022-06-24 01:22:19.318352
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # Abstract class definition check.
    try:
        FXRateService()
        assert False
    except TypeError:
        assert True
    # Test query method.
    try:
        FXRateService.query(Currency('AAA', 'XXX', 'ZZZ'), Currency('BBB', 'YYY', 'UUU'),
                            Date.from_iso_string('2099-12-31'))
        assert False
    except TypeError:
        assert True
    # Test queries method.
    try:
        FXRateService.queries(((Currency('AAA', 'XXX', 'ZZZ'), Currency('BBB', 'YYY', 'UUU'),
                                Date.from_iso_string('2099-12-31'),),))
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-24 01:22:32.175816
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Query the single FX rate:
    date = datetime.date.today()
    fxrate = FXRateService.default.queries([(Currencies["USD"], Currencies["EUR"], date)])
    assert isinstance(fxrate, Iterable)
    fxrate = next(fxrate)
    assert isinstance(fxrate, FXRate)
    assert fxrate.ccy1 == Currencies["USD"]
    assert fxrate.ccy2 == Currencies["EUR"]
    assert fxrate.date == date
    assert isinstance(fxrate.value, Decimal)
    assert fxrate.value > ZERO

    ## Query the non-existing FX rate:

# Generated at 2022-06-24 01:22:40.282955
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:22:42.580266
# Unit test for constructor of class FXRateService
def test_FXRateService():
    with raises(TypeError):
        FXRateService()


# Generated at 2022-06-24 01:22:53.262575
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .temporal import Temporal, Date

    rate = FXRate(Currencies["EUR"], Currencies["USD"], Temporal.of(Date(2019, 1, 1)), Decimal("2"))
    assert (rate.ccy1, rate.ccy2, rate.date, rate.value) == (Currencies["EUR"], Currencies["USD"], Temporal.of(Date(2019, 1, 1)), Decimal("2"))

    rate = FXRate(Currencies["USD"], Currencies["EUR"], Temporal.of(Date(2019, 1, 1)), Decimal("0.5"))

# Generated at 2022-06-24 01:23:03.094597
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from datetime import date
    from decimal import Decimal
    from unittest import TestCase, main

    from pypara.currencies import Currency
    from pypara.fx import FXRate

    class Test(TestCase):
        def test_invert_unchanged_rate(self):
            rate = FXRate(Currency("USD"), Currency("EUR"), date(2000, 1, 1), Decimal("1.95"))
            irate = FXRate(Currency("EUR"), Currency("USD"), date(2000, 1, 1), Decimal("0.51"))
            self.assertEqual(~rate, irate)

        def test_invert_reversed_rate(self):
            rate = FXRate(Currency("EUR"), Currency("USD"), date(2000, 1, 1), Decimal("0.51"))
            ir

# Generated at 2022-06-24 01:23:09.049181
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from unittest import mock, TestCase
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    ## Mocked FXRateService:
    class MockFXRateService(FXRateService):

        # noinspection PyPep8Naming
        @classmethod
        def _FXRateService__new__(cls, *args, **kwargs) -> FXRateService:
            return mock.Mock(**kwargs)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return mock.Mock()

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return

# Generated at 2022-06-24 01:23:11.785017
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass



# Generated at 2022-06-24 01:23:12.672360
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

# Generated at 2022-06-24 01:23:21.157793
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from itertools import islice, repeat
    from unittest import TestCase, main

    from .commons.converters import DateConverter
    from .currencies import Currency, Currencies

    from .services.inmemory import FXRateQuery, FXRatesInMemoryService

    class TestFXRatesInMemoryService(FXRatesInMemoryService):
        def __init__(self, *rates):
            super().__init__(rates)

        def queries_native(self, queries: Iterable[FXRateQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict)

    EUR = Currencies["EUR"]
    USD = Currencies["USD"]

    class TestFXRateService(TestCase):

        def test_empty_fails(self):
            service

# Generated at 2022-06-24 01:23:27.066670
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Custom tests for constructor of class :class:`FXRateLookupError`.
    """
    raise Exception("Custom tests for constructor of class :class:`FXRateLookupError` are not implemented.")

# Generated at 2022-06-24 01:23:38.522401
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries`.
    """

    from .currencies import Currency, CurrencyPair

    from .fxrates import FXRate, FXRateService

    from .money import Money

    from .temporal import Period

    from unittest import TestCase

    import datetime

    from decimal import Decimal

    ## Define a money factory:
    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def __init__(self) -> None:

            self.rates = [
                FXRate(Currency["EUR"], Currency["USD"], Date(2018, 1, 1), Decimal("1.2")),
                FXRate(Currency["EUR"], Currency["USD"], Date(2018, 1, 2), Decimal("1.5"))
            ]

# Generated at 2022-06-24 01:23:43.092646
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    import unittest
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    unittest.TestCase().assertEqual(~nrate, rrate)


# Generated at 2022-06-24 01:23:52.251323
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:00.027699
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class Mock(FXRateService):

        def query(self, ccy1, ccy2, asof, strict):
            return 1

        def queries(self, queries, strict):
            return map(self.query, *zip(*queries))

    m = Mock()

    assert [1, 1, 1] == list(m.queries([(1, 1, 1), (1, 1, 1), (1, 1, 1)]))



# Generated at 2022-06-24 01:24:07.969797
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Date

    ## Create a lookup error instance:
    asof = Date.today()
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    message = f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}"
    error = FXRateLookupError(ccy1, ccy2, asof)

    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert str(error) == message



# Generated at 2022-06-24 01:24:13.505992
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    # noinspection PyStatementEffect
    """
    >>> import datetime
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currencies
    >>> nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    >>> rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    >>> ~nrate == rrate
    True
    """


# Generated at 2022-06-24 01:24:21.236939
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    ## Arrange: Set up an FX rate service:
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):
        """
        Provides a test foreign exchange rate service.
        """


# Generated at 2022-06-24 01:24:33.034818
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Test for None
    assert not FXRateService.query(None, None, None)
    assert FXRateService.query(None, None, None, False) is None

    # Test for string
    assert not FXRateService.query("FOO", "FOO", "BAR")
    assert FXRateService.query("FOO", "FOO", "BAR", False) is None

    # Test for datetime.date
    assert not FXRateService.query(1, 1, datetime.date.today())
    assert FXRateService.query(1, 1, datetime.date.today(), False) is None

    # Test for decimal.Decimal
    assert not FXRateService.query(1, 1, 1)
    assert FXRateService.query(1, 1, 1, False) is None

# Generated at 2022-06-24 01:24:40.271208
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    FXRateService.default = TestFXRateService()

# Generated at 2022-06-24 01:24:48.184550
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:24:57.743261
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """

    ## Importing modules:
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Getting services:
    service = FXRateService()

    ## Testing invalid arguments:
    with pytest.raises(TypeError):
        service.query(None, None, None)

    with pytest.raises(TypeError):
        service.query(Currencies["EUR"], None, None)

    with pytest.raises(TypeError):
        service.query(None, Currencies["EUR"], None)

    with pytest.raises(TypeError):
        service.query(None, None, "2018/01/01")


# Generated at 2022-06-24 01:25:10.927869
# Unit test for constructor of class FXRateService
def test_FXRateService():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # The only way we can unit test an abstract class to check if it raised a `TypeError`.
    try:
        FXRateService()
        raise RuntimeError("Constructor of `FXRateService` does not raise `TypeError` as expected.")
    except TypeError:
        pass

    # Unit test for `query` method:
    class MockRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]):
            self.rates = {
                (rate[0].code, rate[1].code, rate[2]): rate for rate in rates
            }


# Generated at 2022-06-24 01:25:17.535997
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate, "inverted rate failed"


# Generated at 2022-06-24 01:25:25.934591
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currency, Currencies

    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    assert isinstance(error, LookupError)
    assert isinstance(error.args, tuple)
    assert error.args == ("Foreign exchange rate for EUR/USD not found as of {0}".format(datetime.date.today()), )
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == datetime.date.today()


# Generated at 2022-06-24 01:25:33.234353
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRate

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:25:37.797141
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .sources import get_fx_rate_service  # noqa: F401
    from .currencies import Currencies  # noqa: F401
    from .temporal import asof  # noqa: F401
    service = get_fx_rate_service("fxcm")  # noqa: F821
    assert isinstance(service.query(Currencies["USD"], Currencies["EUR"], asof("2020-02-01")), FXRate)

# Generated at 2022-06-24 01:25:47.406038
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import TimePoint
    from .commons.decimals import decimals
    from .services import service, FXRateService

    EURUSD_20190101 = FXRate(Currencies["EUR"], Currencies["USD"], TimePoint.of("2019-01-01"), Decimal("1.2"))

    # noinspection DuplicatedCode
    class test_fx_service(FXRateService):
        def __init__(self):
            self.ccy_rate = {
                ("EUR", "USD"): [
                    (
                        decimals.date("2019-01-01"),
                        decimals.decimal("1.2"),
                    )
                ]
            }


# Generated at 2022-06-24 01:25:56.975687
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .currencies import Currency
    from .commons.zeitgeist import Date
    from decimal import Decimal
    from collections import OrderedDict
    
    class MockFXRateService(FXRateService):
        def __init__(self, rates: OrderedDict[Tuple[Currency, Currency, Date], FXRate]):
            self.rates = rates
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            fxrate = self.rates.get((ccy1, ccy2, asof))
            if fxrate is not None:
                return fxrate
            else:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                else:
                    return None


# Generated at 2022-06-24 01:26:08.458302
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from .services.fxfeed import FXRateService

    # Configure test parameters:
    ccy_pairs = [
        ("EUR", "USD"),
        ("EUR", "TRY"),
        ("USD", "TRY"),
        ("EUR", "EUR")
    ]

    asof_dates = [
        Date(2017, 1, 1),
        Date.today()
    ]

    fx_rate_service = FXRateService()

    # Test FX rate lookups:
    for ccy1, ccy2 in ccy_pairs:
        for asof in asof_dates:
            fx_rate_service.query(ccy1, ccy2, asof)



# Generated at 2022-06-24 01:26:21.406886
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class FXService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    fx_service = FXService()
    rate = fx_service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate.ccy1 == Currencies["EUR"]
    assert rate

# Generated at 2022-06-24 01:26:27.733282
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    exc = FXRateLookupError(ccy1=1, ccy2=2, asof="today")
    assert exc.ccy1 == 1
    assert exc.ccy2 == 2
    assert exc.asof == "today"
    assert exc.args == (f"Foreign exchange rate for 1/2 not found as of today",)

# Unit tests for methods of class FXRate

# Generated at 2022-06-24 01:26:37.414029
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .markets import Exchanges
    from .timeseries.utils import to_timestamp
    from .currencies import Currencies
    import datetime

    class DummyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, ONE)

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-24 01:26:38.714388
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    <Description of the Unit Test>
    """
    pass



# Generated at 2022-06-24 01:26:48.503575
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate == FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")

# Generated at 2022-06-24 01:26:51.371370
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests constructor of class FXRateService.
    """
    ## Creates an FX rate and runs assertions:
    assert FXRateService.default is None



# Generated at 2022-06-24 01:26:58.569786
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): # noqa: E302
    import itertools
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    class FXRateServiceMock(FXRateService):
        def __init__(self, rates):
            super().__init__()
            self.rates = rates

        def query(self, ccy1, ccy2, asof, strict=False):
            found = next((rate for rate in self.rates if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof), None)
            if found is None and strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return found


# Generated at 2022-06-24 01:27:06.569556
# Unit test for method queries of class FXRateService

# Generated at 2022-06-24 01:27:13.327796
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class FXRateService(metaclass=ABCMeta):
        @abstractmethod
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date) -> Optional[FXRate]:
            pass

        @abstractmethod
        def queries(self, queries: Iterable[TQuery]) -> Iterable[Optional[FXRate]]:
            pass

    assert FXRateService.__name__ == "FXRateService"

# Generated at 2022-06-24 01:27:19.005119
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert urate.ccy1 == Currencies["EUR"]
    assert urate.ccy2 == Currencies["USD"]
    assert urate.date == datetime.date.today()
    assert urate.value == Decimal("2")


# Generated at 2022-06-24 01:27:24.595492
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-24 01:27:31.939319
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-24 01:27:40.366850
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries`.
    """
    from datetime import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .currencies import Currency
    from .fx import FXRateService

    ## Create a foreign exchange rate service that throws an exception for any lookup:
    class ThrowingFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date,
                  strict: bool = False) -> Optional[FXRate]:
            """Returns None for any FX rate."""
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-24 01:27:46.948903
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Date

    ## Create the lookup error:
    error = FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date.today())

    ## Check the attributes:
    assert error.ccy1 == Currencies["USD"]
    assert error.ccy2 == Currencies["EUR"]
    assert error.asof == Date.today()



# Generated at 2022-06-24 01:27:52.371901
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Initialize objects:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    ## Check equality:
    assert ~nrate == rrate
    print("Passed tests for method `__invert__` of class `FXRate`.")



# Generated at 2022-06-24 01:28:02.992189
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")
    assert rate.__invert__() == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-24 01:28:04.021521
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    pass


# Generated at 2022-06-24 01:28:07.496005
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-24 01:28:13.897887
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:28:25.706089
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal

    from pypara.currencies import Currencies

    assert FXRate(Currencies["EUR"], Currencies["USD"], Date(2019,6,1), Decimal(2)) == \
        FXRate.of(Currencies["EUR"], Currencies["USD"], Date(2019,6,1), Decimal(2))

    try:
        FXRate.of(Currencies["EUR"], Currencies["USD"], Date(2019,6,1), Decimal(0))
    except ValueError:
        pass
    else:
        assert False

    try:
        FXRate.of(Currencies["EUR"], Currencies["EUR"], Date(2019,6,1), Decimal(2))
    except ValueError:
        pass
    else:
        assert False

    from zeitgeist import Date

    eur_