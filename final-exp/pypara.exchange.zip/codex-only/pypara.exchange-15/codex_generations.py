

# Generated at 2022-06-24 01:18:38.254604
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies import FXRateLookupError
    from pypara.fxrates import DictFXRateService, FXRate

    ## Create the FX rate service:

# Generated at 2022-06-24 01:18:50.324358
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    class Mock(FXRateService):
        """
        Provides a mock implementation of an abstract base class.
        """


# Generated at 2022-06-24 01:19:01.679207
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.currencies.exchange import FXRate, FXRateService

    class TestService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.23"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (FXRate(ccy1, ccy2, asof, Decimal("1.23")) for ccy1, ccy2, asof in queries)

    fxrs = TestService()
    assert fxrs

# Generated at 2022-06-24 01:19:09.556802
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:19:19.825234
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fxrates import FXRate, FXRateService

    class MockRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("1.25"))

    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.date(year=2019, month=1, day=1))
    ]

    results = MockRateService().queries(queries)


# Generated at 2022-06-24 01:19:31.520500
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests functionality of method queries of class FXRateService.
    """
    from datetime import date
    from .currencies import Currencies
    from .sources.mapping import FXRateMapping

    # Create some currency pairs
    ccy_pairs = [
        (Currencies["EUR"], Currencies["USD"]),
        (Currencies["USD"], Currencies["JPY"]),
        (Currencies["EUR"], Currencies["USD"])
    ]

    # Create some dates
    dates = [date.today(), date(2020, 1, 2), date(2020, 1, 1)]

    # Create a FX rate mapping service
    service = FXRateMapping.instance()

    # Create and test the queries

# Generated at 2022-06-24 01:19:42.845331
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    from .tests.fxts import TestFXRateService
    from .time import Date
    import datetime
    from decimal import Decimal
    assert FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2")) == \
        FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == \
        FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))

# Generated at 2022-06-24 01:19:51.655625
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## A foreign exchange was not found:
    e = FXRateLookupError(Currency("EUR"), Currency("USD"), Date(2019, 12, 31))

    ## Check message:
    assert e.args[0] == "Foreign exchange rate for EUR/USD not found as of 2019-12-31"

    ## Check members:
    assert e.ccy1 == Currency("EUR")
    assert e.ccy2 == Currency("USD")
    assert e.asof == Date(2019, 12, 31)



# Generated at 2022-06-24 01:19:58.331025
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .commons.zeitgeist import Date
    from .currencies import Currency

    ccy1: Currency = Currency("USD")
    ccy2: Currency = Currency("EUR")
    asof: Date = Date.today()

    with pytest.raises(FXRateLookupError) as e:
        raise FXRateLookupError(ccy1, ccy2, asof)

    assert isinstance(e.value, FXRateLookupError)
    assert e.value.ccy1 == ccy1
    assert e.value.ccy2 == ccy2
    assert e.value.asof == asof


# Generated at 2022-06-24 01:20:08.150266
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Create and test an :class:`FXRateService` that returns predefined FX rates.
    """

    # Import statements:
    from pypara.currencies import Currencies
    from pypara.values import Temporal
    from pypara.rates import FXRateService
    from pypara.curves import Curve

    # Define the FX rates to be used by the FXRateService:
    rates = [  # noqa: E131
        (Currencies["EUR"], Currencies["USD"], Temporal.of(2017, 1, 1), 2),  # noqa: E231
        (Currencies["EUR"], Currencies["USD"], Temporal.of(2017, 1, 2), 4),  # noqa: E231
    ]


# Generated at 2022-06-24 01:20:17.969081
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This unit test is to make sure that the implementation of FXRateService.queries is correct.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.forex import FXRateLookupError, FXRateService
    from pypara.temporal import Temporal

    ## Get the default FX rate service instance:
    srvc = FXRateService.default

    ## Create a not existing FX rate object:
    fx = FXRate(Currencies["USD"], Currencies["EUR"], Temporal.of(datetime.date.today()) - 1, Decimal("2"))

    ## The following should raise an FXRateLookupError:
    assert all([r is None for r in srvc.queries((fx, fx), strict=True)])

# Generated at 2022-06-24 01:20:28.235461
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.graphs import Graphs
    result = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Graphs["T"].of(2020, 1, 1))
    assert result.ccy1 == Currencies["EUR"]
    assert result.ccy2 == Currencies["USD"]
    assert result.asof == Graphs["T"].of(2020, 1, 1)
    error_msg = "Foreign exchange rate for EUR/USD not found as of 2020-01-01"
    assert str(result) == error_msg
    assert repr(result) == f"{type(result).__name__}('{error_msg}')"


# Generated at 2022-06-24 01:20:33.728777
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:38.894124
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():  # noqa: E501
    """
    Tests the constructor of class FXRateLookupError
    """
    from .currencies import Currencies

    ## Test the constructor:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date())
    ## Check the message:
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 1969-12-31"


# Generated at 2022-06-24 01:20:41.640745
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime as dt
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    ## TODO: Add a test in-memory FXRateService.
    pass

# Generated at 2022-06-24 01:20:48.458129
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pytest
    from pypara.currencies import Currency
    from pypara.commons.numbers import ONE
    from pypara.commons.zeitgeist import Date
    from pypara.fxrates import FXRate, FXRateLookupError, FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency("EUR") and ccy2 == Currency("USD") and asof == Date(2018, 9, 1):
                return FXRate(ccy1, ccy2, asof, ONE)
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-24 01:20:52.111295
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert(nrate[0] == Currencies["EUR"])
    assert(nrate[1] == Currencies["USD"])
    assert(nrate[2] == datetime.date.today())
    assert(nrate[3] == Decimal("2"))


# Generated at 2022-06-24 01:20:58.471765
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from .currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal(2))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal(2)


# Generated at 2022-06-24 01:21:04.631752
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:21:06.309614
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    pass


# Generated at 2022-06-24 01:21:14.277086
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import now

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], now())
    except FXRateLookupError as e:
        assert(e.ccy1 == Currencies["EUR"])
        assert(e.ccy2 == Currencies["USD"])
        assert(e.asof == now())


# Generated at 2022-06-24 01:21:19.862235
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .commons.unittest_mixins import TestCaseBase

    from mock import MagicMock, patch

    from .currencies import Currencies
    from .temporal import Temporal

    from pypara.fxtrade import FXRateService

    from pypara.fxtrade import FXRateLookupError

    class FXRateServiceTest(TestCaseBase):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._fxrate_service = MagicMock(spec=FXRateService)

        def test_queries_default(self):
            """
            Test default foreign exchage rate service query method.
            """
            from decimal import Decimal

            from .currencies import Currency

            from .temporal import Temporal


# Generated at 2022-06-24 01:21:31.171461
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    """

    from decimal import Decimal
    from unittest import TestCase
    from pypara.currencies import Currencies
    from pypara.times import Dates
    from pypara.fxrates import FXRate, FXRateLookupError
    from _test_case import TestCaseMixin

    class TestClass(TestCase, TestCaseMixin):
        """
        """

        def test_with_all_rates_found(self):
            """
            """
            ## Mocking the query method of the FX rate service
            def mock_query(ccy1, ccy2, asof, strict=False):
                return FXRate.of(ccy1, ccy2, asof, Decimal("1.23"))

            ## Make the mock query method available to the instance of FX rate service
            fxrates = FXRate

# Generated at 2022-06-24 01:21:33.039553
# Unit test for constructor of class FXRateService
def test_FXRateService():
    ## This function does not contain any actual test since the abstract class does not provide any concrete
    ## implementation.
    pass

# Generated at 2022-06-24 01:21:44.247201
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Tests the constructor of class :class:`FXRate`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Success:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Failure:
    try:
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0"))
        raise RuntimeError("I should not be here.")
    except ValueError:
        pass
    try:
        FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), Decimal("2"))
        raise RuntimeError("I should not be here.")
    except ValueError:
        pass

# Generated at 2022-06-24 01:21:56.508778
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pytest import raises
    from .currencies import Currencies
    from .temporals import Temporals
    from .exchanges import FXRateService as MockFXRateService
    from .exchanges import FXRateLookupError as FXRateLookupError1

    # Test empty queries
    service = MockFXRateService()
    rates = service.queries([])
    assert [] == list(rates)
    with raises(FXRateLookupError1):
        list(service.queries([], strict=True))

    # Test single query
    ccy1 = Currencies.EUR
    ccy2 = Currencies.USD
    asof = Temporals.today()
    service = MockFXRateService()
    rates = service.queries([(ccy1, ccy2, asof)])

# Generated at 2022-06-24 01:21:59.300608
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest.mock import Mock
    svc = Mock(spec=FXRateService)
    assert isinstance(svc, FXRateService)


# Generated at 2022-06-24 01:22:07.510982
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import datetime
    from decimal import Decimal
    from pypara.fxrates.service import FXRateService
    from pypara.currencies import Currencies

    class MockFxRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-24 01:22:19.171894
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currencies
    from .temporal import Date, Period
    from .fx import FXRateService, FXRate

    class MyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    assert issubclass(MyService, FXRateService)
    assert MyService.__bases__ == (FXRateService,)
    assert MyService.__mro__ == (MyService, FXRateService, object,)

    assert FXRateService.__abstractmethods__ == frozenset({"query", "queries"})

# Generated at 2022-06-24 01:22:32.174497
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.finance.fx import FXRateService
    from pypara.finance.fx import FXRateLookupError

    ## Test if FX rate service raises an error if strict is True and the FX rate is not found:
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

    fxService = TestFXRateService()

    try:
        fxService.query(Currencies["USD"], Currencies["EUR"], Date.today(), strict=True)
        assert False, "Expected lookup error."
    except FXRateLookupError:
        pass

    ## Test if

# Generated at 2022-06-24 01:22:43.558689
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    test_queries = (
        (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        (Currencies["USD"], Currencies["EUR"], datetime.date.today()),
        (Currencies["EUR"], Currencies["EUR"], datetime.date.today().replace(year=2020)),
    )
    for test_query in test_queries:
        test_fxrates = [Optional[Decimal], None, Optional[Decimal]]
        assert test_query == (Currencies["EUR"], Currencies["USD"], datetime.date.today())
        test_fxrates = [Optional[Decimal], None, Optional[Decimal]]

# Generated at 2022-06-24 01:22:53.368896
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporals

    from decimal import Decimal

    from typing import Tuple

    class Subclass(FXRateService):
        def __init__(self, rates: Tuple[Tuple[Currency, Currency, Decimal]]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for x, y, r in self.rates:
                if (ccy1, ccy2, asof) == (x, y, asof):
                    return FXRate.of(x, y, asof, r)
            return None


# Generated at 2022-06-24 01:23:00.475756
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    #
    import datetime
    #
    from decimal import Decimal
    #
    from pypara.currencies import Currencies
    #
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    #
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    #
    assert ~nrate == rrate


# Generated at 2022-06-24 01:23:12.043377
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method :meth:`FXRateService.query`.
    """

    ## Import:
    import datetime
    from decimal import Decimal
    from unittest import mock
    from pypara.currencies import Currency, Currencies
    from pypara.fx import FXRate

    ## Mock with context manager:
    with mock.patch("pypara.fx.FXRateService.query") as query:
        query.return_value = None
        assert FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), False) is None

        query.return_value = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

# Generated at 2022-06-24 01:23:20.852944
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from unittest.mock import MagicMock

    from pypara.currencies import Currencies
    from pypara.fx.rates import FXRateLookupError
    from pypara.fx.rates import FXRateService

    class MockedFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield self.query(query[0], query[1], query[2], strict)

    mocked = MockedFXRateService()
    mocked.query = MagicM

# Generated at 2022-06-24 01:23:32.378757
# Unit test for method queries of class FXRateService

# Generated at 2022-06-24 01:23:37.773721
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Date
    lookup_error = FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date(2017, 12, 31))
    assert lookup_error.ccy1 == Currencies["USD"]
    assert lookup_error.ccy2 == Currencies["EUR"]
    assert lookup_error.asof == Date(2017, 12, 31)


# Generated at 2022-06-24 01:23:40.828238
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass


# Generated at 2022-06-24 01:23:46.397672
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:23:53.387574
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    assert rate
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == date.today()
    assert rate[3] == Decimal("2")



# Generated at 2022-06-24 01:24:02.756179
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from .currencies import Currencies

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            return FXRate(ccy1, ccy2, asof, Decimal(2))

        def queries(self, queries, strict = False):
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal(2))

    fxrs = TestFXRateService()
    assert fxrs.query(Currencies["EUR"], Currencies["USD"], date.today()) == FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal(2))


# Generated at 2022-06-24 01:24:11.560399
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.exchanges.local import LocalFXRateService
    from pypara.currencies import Currencies
    from pypara.temporal import today

    service = LocalFXRateService()
    ccy1, ccy2 = Currencies["EUR"], Currencies["USD"]
    result = service.query(ccy1, ccy2, today)
    assert isinstance(result, FXRate)
    assert ~result == result
    assert ~result.value == result.value ** -1



# Generated at 2022-06-24 01:24:17.398444
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from .currencies import Currencies
    from .time import Date

    ccy1, ccy2 = Currencies["EUR"], Currencies["USD"]
    d = Date(2020, 11, 21)
    r = Decimal("0.5")

    fx1 = FXRate(ccy1, ccy2, d, r)
    fx2 = FXRate(ccy2, ccy1, d, r ** -1)

    assert ~fx1 == fx2


# Generated at 2022-06-24 01:24:22.994331
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate.of(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:24:24.533819
# Unit test for method query of class FXRateService
def test_FXRateService_query():
  pass

# Generated at 2022-06-24 01:24:32.520195
# Unit test for constructor of class FXRate
def test_FXRate():
    r1 = FXRate("EURUSD", 2)
    r2 = FXRate("EURUSD", 2)
    r3 = FXRate("USDJPY", 2)
    assert r1 == r2
    assert r1 != r3
    assert hash(r1) == hash(r2)
    assert hash(r1) != hash(r3)
    assert r1.ccy1 == "EUR"
    assert r1.ccy2 == "USD"
    assert r1.value == 2


# Generated at 2022-06-24 01:24:44.894663
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency, Currencies
    from .commons.zeitgeist import Date

    ccy1, ccy2 = Currencies["EUR"], Currencies["USD"]
    date = Date.from_iso8601("2019-09-06")
    error = FXRateLookupError(ccy1, ccy2, date)

    assert error.ccy1 == ccy1, "Expected currency `EUR`."
    assert error.ccy2 == ccy2, "Expected currency `USD`."
    assert error.asof == date, "Expected date 2019-09-06."
    assert "EUR/USD" in str(error), "Expected currency pair `EUR/USD`."
    assert "2019-09-06" in str(error), "Expected date `2019-09-06`."



# Generated at 2022-06-24 01:24:52.356268
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    ## Test case 1:
    ccy1, ccy2, date, value = 'ccy1', 'ccy2', 'date', 'value'
    rate = FXRate(ccy1, ccy2, date, value)
    nrate = rate.__invert__()
    assert nrate is not rate
    assert nrate[0] == ccy2
    assert nrate[1] == ccy1
    assert nrate[2] == date
    return

## Unit tests for method of of class FXRate

# Generated at 2022-06-24 01:24:58.770245
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:25:00.322861
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService().queries([(None, None, None)])


# Generated at 2022-06-24 01:25:12.310701
# Unit test for constructor of class FXRate
def test_FXRate():
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal

    ## Test invalid currency:
    with self.assertRaises(ValueError):
        FXRate(None, Currencies["USD"], Temporal.today(), Decimal("2"))
    with self.assertRaises(ValueError):
        FXRate(Currencies["EUR"], None, Temporal.today(), Decimal("2"))

    ## Test invalid currencies:
    with self.assertRaises(ValueError):
        FXRate(Currencies["EUR"], Currencies["EUR"], Temporal.today(), Decimal("2"))
    with self.assertRaises(ValueError):
        FXRate(None, None, Temporal.today(), Decimal("2"))

    ## Test invalid FX rate:
   

# Generated at 2022-06-24 01:25:17.911478
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    #
    from .currencies import Currencies
    from .commons.dates import TODAY
    from decimal import Decimal
    #
    # Test one:
    assert ~FXRate(Currencies["EUR"], Currencies["USD"], TODAY, Decimal(2)) == \
           FXRate(Currencies["USD"], Currencies["EUR"], TODAY, Decimal(0.5))


# Generated at 2022-06-24 01:25:29.027079
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the FXRateService.query method.
    """
    from unittest import TestCase, main
    from unittest.mock import MagicMock, create_autospec

    from pypara.currencies import Currency, Currencies
    from pypara.money import Money

    ## Defines the test case class:
    class Test(TestCase):
        """
        Tests the FXRateService.query method.
        """

        def test_passing(self) -> None:
            """
            Tests the query method with passing cases.
            """
            ## Prepare the test subject:
            service = create_autospec(spec=FXRateService).return_value

            ## Mock the foreign exchange:

# Generated at 2022-06-24 01:25:35.528501
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests method __invert__ of class FXRate.
    """
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-24 01:25:43.772490
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Test constructor:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")



# Generated at 2022-06-24 01:25:55.610783
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import unittest

    from decimal import Decimal
    from pypara.currencies import EUR, USD
    from pypara.temporals import Date
    from pypara.services.fxrates import FXRateService

    ## Define a concrete foreign exchange rate service:
    class ArbitraryFXRateService(FXRateService):
        ## Defines a lookup table for foreign exchange rates:
        _lookup = {
            (EUR, USD, Date(2021, 1, 1)): Decimal("1.5"),
            (EUR, USD, Date(2021, 1, 2)): Decimal("1.6"),
            (EUR, USD, Date(2021, 1, 3)): Decimal("1.7"),
        }


# Generated at 2022-06-24 01:26:04.301242
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert isinstance(rate[0], Currency)
    assert isinstance(rate[1], Currency)
    assert isinstance(rate[2], datetime.date)
    assert isinstance(rate[3], Decimal)


# Generated at 2022-06-24 01:26:10.065583
# Unit test for constructor of class FXRateService
def test_FXRateService():

    @FXRateService.Register
    class TestRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError()

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            raise NotImplementedError()

    assert FXRateService.default == TestRateService

# Generated at 2022-06-24 01:26:18.046113
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:26:27.750993
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("2")) if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] else FXRate(ccy2, ccy1, asof, Decimal("0.5"))

        def queries(self, queries, strict=False):
            pass

    date = datetime.date.today()
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    service = MockFXRateService()

# Generated at 2022-06-24 01:26:33.456867
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # pylint: disable=missing-class-docstring

    class FXRateServiceXXX(FXRateService):
        pass

    service = FXRateServiceXXX()
    assert isinstance(service, FXRateServiceXXX)
    assert isinstance(service, FXRateService)

# Generated at 2022-06-24 01:26:39.657553
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:26:45.769570
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create new foreign exchange rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Invert the foreign exchange rate:
    rrate = ~nrate

    ## Test the inverted rate:
    assert rrate[0] == Currencies["USD"]
    assert rrate[1] == Currencies["EUR"]
    assert rrate[2] == datetime.date.today()
    assert rrate[3] == Decimal("0.5")


# Generated at 2022-06-24 01:26:52.266751
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests FXRateService method queries.
    """
    from unittest import TestCase
    from datetime import date
    from unittest.mock import MagicMock
    from pypara.currencies import Currencies

    # Case 1:
    def fx_rate(ccy1: Currency, ccy2: Currency, asof: Date) -> Decimal:
        if ccy1 == Currencies["USD"] and ccy2 == Currencies["TRY"] and asof == date(2020, 1, 1):
            return Decimal("6.8")
        elif ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == date(2020, 1, 2):
            return Decimal("0.9")

# Generated at 2022-06-24 01:27:01.522564
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .commons.zeitgeist import date
    from .fx import FXRateLookupError

    ccy1 = ccy2 = Currency("XXX")
    asof = date.today()
    error = FXRateLookupError(ccy1, ccy2, asof)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert str(error) == f"Foreign exchange rate for XXX/XXX not found as of {asof}"


# Generated at 2022-06-24 01:27:10.805445
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Tests :class:`pypara.fx.FXRate` constructor.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert isinstance(rate, FXRate)
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:27:16.358626
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:27:19.327035
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, metaclass=ABCMeta)
    assert hasattr(FXRateService, "default")
    assert hasattr(FXRateService, "query")
    assert hasattr(FXRateService, "queries")

# Generated at 2022-06-24 01:27:26.264147
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:27:37.264828
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    # pylint: disable=W0212,W0612
    @FXRateService.default.register
    class DummyService(FXRateService):
        """
        Dummy FX rate service for testing.
        """


# Generated at 2022-06-24 01:27:47.182538
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    # Test creation
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    # Test access
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:27:54.246483
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class StrictService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-24 01:28:05.795156
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .temporal import DateRange
    from .currencies import Currencies

    from .datetime import date
    from decimal import Decimal

    class TestFXRateService(FXRateService):
        def __init__(self):
            self.rates = [FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 1, 1), Decimal("1.1"))]


# Generated at 2022-06-24 01:28:17.380584
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .currencies.exceptions import InvalidCurrencyCodeError
    from .temporals import Temporals

    import os
    import sys
    import unittest

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, one)
            elif ccy1 == Currency("USD") and ccy2 == Currency("EUR"):
                return FXRate(ccy1, ccy2, asof, usdeur)

# Generated at 2022-06-24 01:28:22.383497
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    assert FXRateService.__abstractmethods__ == frozenset({'query', 'queries'})

# Generated at 2022-06-24 01:28:29.120197
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Performs unit tests for method `~FXRate.__invert__` of class `FXRate`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    return nrate == ~rrate
