

# Generated at 2022-06-24 01:18:36.455888
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .commons.zeitgeist import date
    from .decimal import Decimal
    from .decimal import localctx
    from .markets import FXRateService, FXRateServiceCache
    from .markets import FXRateServiceSqlite

    ## Create the default service:
    service = FXRateServiceCache(FXRateServiceSqlite())

    ## Check lookup without the strict argument:
    assert service.query(Currencies["USD"], Currencies["EUR"], date(2019, 2, 1)) is None
    assert service.query(Currencies["USD"], Currencies["EUR"], date(2019, 2, 1), strict=False) is None

    ## Check lookup with the strict argument:

# Generated at 2022-06-24 01:18:45.791551
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for the constructor of class FXRateService
    """
    from unittest import TestCase
    from unittest.mock import MagicMock

    class FXRateServiceTester(TestCase):
        """
        Tests the constructor of class FXRateService
        """

        def test_init(self):
            """
            Tests the constructor of class FXRateService
            """
            FXRateService()

    tester = FXRateServiceTester()
    tester.test_init()


# Generated at 2022-06-24 01:18:46.353533
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    raise NotImplementedError



# Generated at 2022-06-24 01:18:47.335402
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass


# Generated at 2022-06-24 01:18:55.331516
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:19:02.323031
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## Create a currency and a date:
    ccy1 = Currency("USD")
    ccy2 = Currency("EUR")
    date = Date.today()

    ## Define a reference rate:
    expected = FXRate(ccy1, ccy2, date, Decimal("1"))

    ## Create a mock service:
    mock = FXRateService()

    ## Create expected and actual results:
    actual = mock.query(ccy1, ccy2, date)

    ## Compare the results:
    assert not actual
    assert mock.query(ccy1, ccy2, date, strict=True) is None


# Generated at 2022-06-24 01:19:03.441185
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService != None

# Generated at 2022-06-24 01:19:15.589093
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest.mock import MagicMock
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Temporal
    from pypara.markets.fx import FXRate, FXRateLookupError, FXRateService

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    class _FXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool):
            rate: Optional[FXRate] = MagicMock(spec=FXRate)
            return rate

    rate: FXRate = FXRate(ccy1, Currencies["USD"], Temporal.today(), Decimal("2"))
    strict = True
    asof = Temporal.today()
    service = _FX

# Generated at 2022-06-24 01:19:21.703176
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2.0000"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == date.today()
    assert rate.value == Decimal("2.0000")


# Generated at 2022-06-24 01:19:22.577880
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:19:33.107131
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test case for method queries of class FXRateService .
    """
    import time
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from itertools import chain
    class MockFXRateService(FXRateService):
        def __init__(self, fxrates: Iterable[FXRate]):
            super().__init__()
            self.__fxrates = dict(chain(
                ((fxrate.ccy1, fxrate.ccy2, fxrate.date), fxrate) for fxrate in fxrates
            ))

# Generated at 2022-06-24 01:19:44.226484
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Checks if constructor of class FXRateLookupError works correctly.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.rates import FXRate, FXRateLookupError

    ## Create and check an FX rate:
    try:
        rate = FXRate.of(Currencies["EUR"], Currencies["USD"], date(2020, 1, 1), Decimal("1.0957"))
        assert rate is not None
        assert rate.ccy1 == Currencies["EUR"]
        assert rate.ccy2 == Currencies["USD"]
        assert rate.date == date(2020, 1, 1)
        assert rate.value == Decimal("1.0957")
    except Exception as e:
        raise AssertionError(e)

    ##

# Generated at 2022-06-24 01:19:46.086655
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=True):
            pass
        def queries(self, currencyPairs, dates, strict=True):
            pass

    assert issubclass(MockFXRateService, FXRateService)


# Generated at 2022-06-24 01:19:53.537209
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curve.fx import ForwardFXRateService
    from pypara.curve.fx import FXRate
    from pypara.curve.fx import FXRateLookupError
    from pypara.curve.fx import FXRateService

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()

    rate1 = FXRate(ccy1, ccy2, date, Decimal("1.1"))
    rate2 = FXRate(ccy2, ccy1, date, Decimal("0.9"))
    rate3 = FXRate(ccy1, ccy2, date, Decimal("1.2"))

# Generated at 2022-06-24 01:19:54.345591
# Unit test for constructor of class FXRateService
def test_FXRateService(): # pragma: no cover
    FXRateService()

# Generated at 2022-06-24 01:19:57.954870
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert nrate == FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ~nrate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

# Generated at 2022-06-24 01:20:02.268857
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    irate = ~rate
    assert irate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))



# Generated at 2022-06-24 01:20:06.139715
# Unit test for constructor of class FXRateService
def test_FXRateService():
    with pytest.raises(TypeError):  # hint: ABC cannot be instantiated
        FXRateService()


# Generated at 2022-06-24 01:20:17.447816
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.zeitgeist import Date
    from .currencies import Currency
    from .efxrates import FXRates
    from decimal import Decimal
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[Decimal]:
            return FXRates(asof).query(ccy1, ccy2)
        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[Decimal]]:
            return FXRates(asof).queries(queries)
    fxsrv = MockFXRateService()

# Generated at 2022-06-24 01:20:28.461124
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class LocalFXRateService(FXRateService):
        def __init__(self, rates: dict):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            rate = self.rates.get(self.TQuery(ccy1, ccy2, asof))
            if rate is None and strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return rate

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False):
            return [self.query(*query, strict=strict) for query in queries]

    ## Create

# Generated at 2022-06-24 01:20:32.676161
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-24 01:20:35.831901
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    # pylint: disable=C0103,C0111
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    except LookupError as exception:
        assert str(exception) == "Foreign exchange rate for EUR/USD not found as of 2019-11-28"



# Generated at 2022-06-24 01:20:44.059398
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    class MockService(FXRateService):
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                if query[0] == Currencies.USD and query[1] == Currencies.EUR and query[2] == date(2019, 10, 25):
                    yield FXRate.of(Currencies.USD, Currencies.EUR, query[2], Decimal("0.88"))
                else:
                    yield None
    class Test(unittest.TestCase):
        def test_queries(self):
            s = MockService()

# Generated at 2022-06-24 01:20:48.548307
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class Service(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            def _iter():
                for ccy1, ccy2, asof in queries:
                    yield FXRate(ccy1, ccy2, asof, Decimal("2"))
            return _iter()


# Generated at 2022-06-24 01:20:50.141374
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
	err = FXRateLookupError(Currency.EUR, Currency.USD, Date.today())
	assert isinstance(err, FXRateLookupError)


# Generated at 2022-06-24 01:21:01.362301
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .time import Date, Year
    from .commons.numbers import ONE
    from .fxrates import FXRateService, FXRate, FXRateLookupError
    from .test.testutils import MethodTestCase
    from datetime import date

    # Test empty query:
    with MethodTestCase(FXRateService, "queries", FXRateService.queries) as testcase:
        testcase.test(None, ValueError) # noqa: E501
        testcase.test([], [])

    # Test queries:
    with MethodTestCase(FXRateService, "queries", FXRateService.queries) as testcase:
        # On empty set:
        testcase.test([(Currency("EUR"), Currency("USD"), Date(Year(2019)))], [None])
        # On default set

# Generated at 2022-06-24 01:21:07.879376
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .zeitgeist import Date
    from .fxrates import FXRateLookupError
    date = Date("2020-02-02")
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], date)
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == date
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2020-02-02"
    return True


# Generated at 2022-06-24 01:21:18.275397
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.zeitgeist import Time
    from .currencies import Currency, Currencies
    from .services import FXRateProvider

    ## Create different kind of services:
    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    fx_rate_provider = FXRateProvider()  # type: ignore
    fx_rate_service = FXRateService()

    ## Check the default FX rate service:
    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    assert FXRateService.default is None

    ## Check the query function of the FX rate service:
    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    assert fx_rate_service.query(Currencies["USD"], Currencies["EUR"], Time.today()) is None

    ## Check the queries function of the FX rate service:
    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Generated at 2022-06-24 01:21:29.812741
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Testing the constructor of class FXRate
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:35.810716
# Unit test for constructor of class FXRateService
def test_FXRateService():

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, queries, strict=False):
            for c1, c2, d in queries:
                yield None

    # Instantiate the default FX rate service
    FXRateService.default = TestFXRateService()

# Generated at 2022-06-24 01:21:43.641059
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    from .currencies import Currency
    from .fx.fx_rate_service import FXRateService

    class TItem(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            raise NotImplementedError()

        def queries(self, queries, strict=False):
            raise NotImplementedError()

    item = TItem()
    assert item.query(Currency.USD, Currency.EUR, Date(2020, 10, 16)) is None



# Generated at 2022-06-24 01:21:52.607377
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    ## Arrange:
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    ## Act:
    result = ~nrate

    ## Assert:
    assert result == rrate


# Generated at 2022-06-24 01:22:00.693456
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:05.219894
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:16.505545
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies import CurrencyPair
    from pypara.fx import MockFXRateService
    from pypara.fx import FXRateLookupError

    # Setup a mock service:
    service = MockFXRateService()

    # Test a valid rate, with default date and strict mode:
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date.now())
    assert rate is not None and rate.ccy1 == Currencies["EUR"] and rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today() and rate.value == Decimal("1.1")

    # Test a valid rate, with default date and strict mode:

# Generated at 2022-06-24 01:22:20.439614
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .fxrates import SimpleFXRateService
    from .currencies import Currencies

    ## Create an FX rate service:
    service = SimpleFXRateService()

    ## Build a simple query:
    query = (Currencies["EUR"], Currencies["USD"], Date())

    ## Test the query:
    assert service.query(*query, strict=False) is not None

    ## Test the queries:
    assert service.queries([query])[0] is not None

# Generated at 2022-06-24 01:22:27.781464
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:38.885057
# Unit test for constructor of class FXRate
def test_FXRate():
    from typing import Iterable
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date

    def assert_rate(rate: FXRate, ccy1: Currency, ccy2: Currency, asof: Date, value: Decimal):
        assert rate.ccy1 == ccy1, "FX rate foreign currency/1 not found."
        assert rate.ccy2 == ccy2, "FX rate foreign currency/2 not found."
        assert rate.date == asof, "FX rate date not found."
        assert rate.value == value, "FX rate value not found."
        assert rate[0] == ccy1, "FX rate foreign currency/1 not found."
        assert rate[1] == ccy2, "FX rate foreign currency/2 not found."
        assert rate

# Generated at 2022-06-24 01:22:44.048852
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today()).message == \
        "Foreign exchange rate for EUR/USD not found as of {}".format(datetime.date.today())

# Generated at 2022-06-24 01:22:53.417588
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currencies
    from .datetime import Temporal

    #
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Temporal.now()

    #
    ## Implement abstract methods:
    class FXRateServiceImpl(FXRateService):
        """
        Provides a concrete class for serving foreign exchange rates.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            pass


# Generated at 2022-06-24 01:23:01.036292
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test queries method of FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # class FakeFXRateService
    class FakeFXRateService(FXRateService):
        """
        Fake FXRateService
        """
        # pylint: disable=no-self-use
        def query(self, ccy1, ccy2, asof, strict=False):
            """
            query function for FakeFXRateService
            """
            if ccy1 == ccy2:
                return FXRate.of(ccy1, ccy2, asof, Decimal("1"))

# Generated at 2022-06-24 01:23:06.641191
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .time import Date
    from .fx import FXRateService
    from decimal import Decimal
    from datetime import date
    from typing import Tuple, Iterable, Optional
    from unittest import TestCase, main

    class TestImpl(FXRateService):
        def __init__(self, date: date = date(2020, 6, 14)):
            self.date = date

# Generated at 2022-06-24 01:23:15.705762
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert(type(rate) is FXRate)
    assert(rate.ccy1 == Currencies["EUR"])
    assert(rate.ccy2 == Currencies["USD"])
    assert(rate.date == datetime.date.today())
    assert(rate.value == Decimal("2"))


# Generated at 2022-06-24 01:23:19.869196
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .temporals import Dates

    assert FXRateService._is_abstract()

    assert FXRateService.TQuery == Tuple[Currency, Currency, Date]

    assert FXRateService.query.__annotations__["return"] == Optional[FXRate]

    assert FXRateService.queries.__annotations__["return"] == Iterable[Optional[FXRate]]

# Generated at 2022-06-24 01:23:29.480415
# Unit test for constructor of class FXRate

# Generated at 2022-06-24 01:23:39.362252
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currency
    from pypara.commons.zeitgeist import Date
    from pypara.fx import FXRate, FXRateLookupError, FXRateService


# Generated at 2022-06-24 01:23:45.535043
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService.
    """
    ## Define the abstract method:
    def get_method(fx: FXRateService) -> FXRateService:
        """
        Returns the abstract method of the FX rate service.
        """
        return fx.query

    ## Check the abstract method by using the method of the base class:
    assert get_method(FXRateService()) == FXRateService.query

# Generated at 2022-06-24 01:23:52.498147
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:02.138469
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .primitives import Temporal
    from .commons.zeitgeist import now

    ## Case: Valid arguments.
    assert isinstance(FXRateLookupError(Currency("EUR"), Currency("USD"), now()), FXRateLookupError)

    ## Case: The instance properties.
    assert FXRateLookupError(Currency("EUR"), Currency("USD"), now()).ccy1 == Currency("EUR")
    assert FXRateLookupError(Currency("EUR"), Currency("USD"), now()).ccy2 == Currency("USD")
    assert FXRateLookupError(Currency("EUR"), Currency("USD"), now()).asof == now()

    # Case: Message format.
    exception = FXRateLookupError(Currency("EUR"), Currency("USD"), now())

# Generated at 2022-06-24 01:24:08.184290
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from unittest.mock import patch
    from pypara.currencies import Currencies
    from pypara.finance.markets.fx import FXRate, FXRateService

    # Define a mock service
    class MockRateService(FXRateService):
        def __init__(self, data=None):
            self.__data = data or {}

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return self.__data.get((ccy1, ccy2, asof))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield self

# Generated at 2022-06-24 01:24:14.757387
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase, TestLoader, TestSuite, TextTestRunner
    from unittest.mock import patch

    class FXRateServiceTest(TestCase):

        def test_init(self):
            with self.assertRaises(TypeError):
                FXRateService()

        def test_query(self):
            with self.assertRaises(TypeError):
                FXRateService.query(self)
            with self.assertRaises(TypeError):
                FXRateService.query(self, "EUR", "USD", Date.today())
            with self.assertRaises(TypeError):
                FXRateService.query(self, "EUR", "USD", Date.today(), strict=True)

# Generated at 2022-06-24 01:24:16.028577
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert isinstance(FXRateService(), FXRateService)



# Generated at 2022-06-24 01:24:23.072209
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, EUR, USD
    class FXRateServiceImpl(FXRateService):
        """
        A sample implementation for :class:`FXRateService` for unit testing.
        """
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == EUR and ccy2 == USD:
                return FXRate(EUR, USD, asof, Decimal("2"))
            return None
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return map(lambda q: self.query(*q, strict=strict), queries)
    us1, us2

# Generated at 2022-06-24 01:24:32.076539
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:24:38.347084
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import now
    from .exceptions import LookupError
    from .exceptions import FXRateLookupError
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], now())
    except LookupError as err:
        assert err.args is not None
    except Exception:
        assert False



# Generated at 2022-06-24 01:24:51.099903
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.fx.rates import FXRateService
    from pypara.fx.services.decorators import FXRateCache
    from pypara.fx.services.decorators import FXRateMap

    ## Create some fx rates

# Generated at 2022-06-24 01:24:52.899615
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Fail the unit test for abstract method
    pass


# Generated at 2022-06-24 01:24:56.932097
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons import chronology
    from .models import FXRateLookupError

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], chronology.date.today())
    except FXRateLookupError as ex:
        pass



# Generated at 2022-06-24 01:25:02.157124
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")



# Generated at 2022-06-24 01:25:07.188464
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import EUR, USD
    from .zeitgeist import Date

    import pytest

    service = FXRateService()
    with pytest.raises(NotImplementedError):
        service.query(EUR, USD, Date(2018, 1, 1))



# Generated at 2022-06-24 01:25:07.779576
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService  # noqa: E501

# Generated at 2022-06-24 01:25:17.568589
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from .commons.zeitgeist import Date
    from .currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == Date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:25:28.630497
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This unit test case tests the `queries` method of class `FXRateService`.
    """

    # Imports:
    import datetime
    from decimal import Decimal
    from unittest import TestCase, mock
    from pypara.currencies import Currencies

    # Test Case:
    class QueryTestCase(TestCase):
        """
        Implements a test case for `queries` method of class `FXRateService`.
        """

        def test_query(self):
            """
            Tests the `query` method of class `FXRateService` with a single query.
            """

            # The service we are going to test:
            service: FXRateService = mock.MagicMock()

            # Set a return value:

# Generated at 2022-06-24 01:25:33.662910
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for the constructor of class FXRateService.

    This is a non-test as it is abstract.
    """
    try:
        FXRateService()
    except NotImplementedError:
        return
    raise AssertionError("Expected to raise NotImplementedError.")

# Generated at 2022-06-24 01:25:44.246402
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    import pytest
    from pypara.currencies import Currencies
    from pypara.services.fxrates import FXRate, FXRateService

    class CustomFXRateService(FXRateService):
        """
        A custom foreign exchange rate service.
        """

        def __init__(self):
            """
            Initializes the foreign exchange rate service.
            """
            pass

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            # noinspection PyUnresolvedReferences

# Generated at 2022-06-24 01:25:49.425260
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Defines unit tests for class :class:`FXRateLookupError`.
    """

    ## Creating excessive test fails:
    try:
        raise FXRateLookupError(None, None, None)
    except FXRateLookupError as e:
        assert e.ccy1 is None
        assert e.ccy2 is None
        assert e.asof is None
        assert e.msg is None
        assert e.args == ("Foreign exchange rate for None/None not found as of None",)


# Generated at 2022-06-24 01:25:55.102829
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:26:03.833161
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-24 01:26:11.837643
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currency, Currencies
    import datetime
    from decimal import Decimal
    nrate0 = FXRate(Currency("EUR"), Currency("USD"), datetime.date.today(), Decimal("2"))
    rrate0 = FXRate(Currency("USD"), Currency("EUR"), datetime.date.today(), Decimal("0.5"))
    assert ~nrate0 == rrate0

    nrate1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate1 = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate1 == rrate1


# Generated at 2022-06-24 01:26:20.434452
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.currencies import Currency

    # Tests:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-24 01:26:25.965468
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:26:30.009571
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """
    import datetime
    from pypara.currencies import Currencies
    ## Initialize an FXRateLookupError:
    error = FXRateLookupError(Currencies["USD"], Currencies["EUR"], datetime.date.today())
    assert isinstance(error, FXRateLookupError)
    assert isinstance(error, LookupError)
    assert error.args == ("Foreign exchange rate for USD/EUR not found as of %s" % datetime.date.today(),)


# Generated at 2022-06-24 01:26:42.069419
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currency, Currencies
    from pypara.date_utils import Date
    from pypara.fx.fx_rate_services import InMemoryFXRateService

    fx_rate_service = InMemoryFXRateService()

    queries = (
        (Currencies["EUR"], Currencies["USD"], Date.today()),
        (Currencies["GBP"], Currencies["USD"], Date.today()),
    )

    rates = tuple(fx_rate_service.queries(queries, strict=True))
    assert len(rates) == 2
    assert isinstance(rates[0], FXRate)
    assert isinstance(rates[1], FXRate)

    # Test failure (raises a ValueError):

# Generated at 2022-06-24 01:26:51.475522
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .temporal import Temporal
    from .currencies import Currencies
    from .calendar.weekdays import Weekday
    import datetime
    from decimal import Decimal

    # Build the FX rate service:

# Generated at 2022-06-24 01:26:55.926200
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase
    from pypara.services.fxrate import FXRateService

    class _FXRateService(FXRateService):
        pass

    class _Test(TestCase):

        def test_constructor(self):
            service = _FXRateService()
            self.assertIsNotNone(service)
            self.assertEqual(service.__class__, _FXRateService)

    _Test().test_constructor()

# Generated at 2022-06-24 01:27:04.803198
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.fx import FXRateService
    from pypara.temporal import Temporal

    # The default date:
    date = datetime.date.today()

    # The fx rate provider:
    class Provider(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, date, Decimal("2"))

        def queries(self, queries, strict=False):
            for query in queries:
                yield self.query(query[0], query[1], query[2], strict)

    # Initialize a provider:
    provider = Provider()

    # Initialize a temporal instance:
    temporal = Temporal()

    #

# Generated at 2022-06-24 01:27:09.031376
# Unit test for constructor of class FXRateService
def test_FXRateService():  # noqa: D103
    assert issubclass(FXRateService, object)
    assert FXRateService.default is None
    assert FXRateService.TQuery == Tuple[Currency, Currency, Date]
    assert isinstance(FXRateService.query, AbstractMethod)
    assert isinstance(FXRateService.queries, AbstractMethod)

# Generated at 2022-06-24 01:27:19.168769
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .money import Money
    from .temporal import Temporal
    from .timeseries import TimeSeries

    from decimal import Decimal

    class StaticRateService(FXRateService):
        """
        Provides a foreign exchange rate service that returns a fixed set of hard-coded data.
        """


# Generated at 2022-06-24 01:27:29.805354
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests :class:`FXRateLookupError`.
    """
    ## Some setup:
    from pypara.currencies import Currencies
    from datetime import date

    ## Test fixture:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], date.today())

    ## Assertions:
    assert error.args == (
        "Foreign exchange rate for EUR/USD not found as of %s" % date.today(),
    )
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == date.today()
    assert str(error) == (
        "Foreign exchange rate for EUR/USD not found as of %s" % date.today()
    )


# Generated at 2022-06-24 01:27:34.079233
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Setup:
    import pytest
    from pypara.fx.simplefxrateservice import SimpleFXRateService

    # Exercise:
    service = SimpleFXRateService()
    rate = service.query()

    # Verify:
    assert rate is None

    # Cleanup:
    pytest.exit()


# This tests the static method of of class FXRate

# Generated at 2022-06-24 01:27:35.974915
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:27:38.116053
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    pass

# Generated at 2022-06-24 01:27:40.203630
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:27:52.234844
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests for :method:`FXRateService.queries` of the :class:`FXRateService` class.

    This test is considered "successful" if it completes without error.
    """

    import datetime
    from itertools import islice
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    ## Simple FX rate service implementation that returns a constant FX rate:
    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(2))


# Generated at 2022-06-24 01:28:04.490958
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """

    ## Define the currencies:
    from pypara.currencies import Currencies
    NLG = Currencies["NLG"]
    USD = Currencies["USD"]

    ## Define the dates:
    from pypara.commons.zeitgeist import Date
    D1 = Date(1994, 11, 30)

# Generated at 2022-06-24 01:28:09.417277
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for class FXRateService
    """

    # Abstract class can not be instantiated.
    from pypara.aspects import Uninstanciable

    with Uninstanciable(FXRateService):
        pass


# Generated at 2022-06-24 01:28:18.218031
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    import pytest

    ## Setup:
    date = datetime.date.today()
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    value = Decimal("1.1")

    ## Execute:
    rate = FXRate.of(ccy1, ccy2, date, value)

    ## Verify:
    assert rate[0] == ccy1
    assert rate[1] == ccy2
    assert rate[2] == date
    assert rate[3] == value

    with pytest.raises(ValueError):
        FXRate(-1, -2, -3, -4)

# Generated at 2022-06-24 01:28:22.351380
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:28:28.662405
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        from .currencies import Currencies  # noqa: F401
        from .commons.zeitgeist import Date  # noqa: F401
        from .commons.numbers import ONE  # noqa: F401
        from .commons.zeitgeist import Date  # noqa: F401

        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(2017, 1, 1))
    except FXRateLookupError as error:
        assert error.args[0] == "Foreign exchange rate for EUR/USD not found as of 2017-01-01"
