

# Generated at 2022-06-24 01:18:33.295862
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This method is used to unit test the method queries of class FXRateService.
    """
    ## Prepare the FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, ONE)

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    ## Prepare the queries:
    from datetime import date
    from pypara.currencies import Currencies

# Generated at 2022-06-24 01:18:33.855807
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-24 01:18:46.542752
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method `FXRateService.query`.
    """
    from unittest import TestCase
    from unittest.mock import Mock, patch

    from pypara.currencies import Currency, Currencies
    from pypara.exchange_rates.fx_rate_service import FXRateError, FXRateService

    cur_e = Currencies["EUR"]
    cur_u = Currencies["USD"]
    dt = "2000-01-01"

    # ---
    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service implementation.
        """


# Generated at 2022-06-24 01:18:53.571742
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:02.561922
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.

    :return: None
    """
    from .currencies import Currency
    from .temporal import Temporal
    from .timezones import TimeZones

    class FXRateServiceImpl(FXRateService):
        """
        Provides an implementation of :class:`FXRateService`.
        """


# Generated at 2022-06-24 01:19:08.766901
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies

    class FXRateTest(unittest.TestCase):

        def test_invert_fxrate(self):
            nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
            self.assertEqual(~nrate, rrate)

        def test_fxrate_of(self):
            urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

# Generated at 2022-06-24 01:19:18.764052
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.query`.
    """

    from .currencies import Currencies
    from .temporal import Temporal

    ## Define a test service:
    class TestService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable["FXRateService.TQuery"], strict: bool = False) -> Iterable[Optional[FXRate]]:
            yield None
            yield None

    service = TestService()
    assert list(service.queries([(Currencies["EUR"], Currencies["USD"], Temporal.today()) for _ in range(10)])) == [None] * 10  # noqa: E501


# Generated at 2022-06-24 01:19:21.781230
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Date

    date = Date.of("2018-01-01")
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    error = FXRateLookupError(ccy1, ccy2, date)
    assert ccy1 == error.ccy1 and ccy2 == error.ccy2 and date == error.asof


# Generated at 2022-06-24 01:19:32.178805
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency, Currencies  # noqa: F401
    from .temporal import Temporal, Date  # noqa: F401
    from .markets import Market, Markets  # noqa: F401

    ## Check the exception type:
    assert issubclass(FXRateLookupError, Exception)

    ## Successful construction:
    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(2017, 1, 1)) is not None  # noqa: E704

    ## Test the message:
    assert str(FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(2017, 1, 1))) == "Foreign exchange rate for EUR/USD not found as of 2017-01-01"  # noqa: E704

    ## Test the type checking:

# Generated at 2022-06-24 01:19:38.957563
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-24 01:19:40.768867
# Unit test for constructor of class FXRateService
def test_FXRateService(): pass

# Generated at 2022-06-24 01:19:43.149622
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class FXRateService.
    """
    print("Testing the constructor of class FXRateService.")
    a = FXRateService()

# Generated at 2022-06-24 01:19:50.004792
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:53.738975
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:01.184624
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__(): # noqa: D103
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:20:11.658275
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from unittest.mock import MagicMock, call, patch

    from pypara.currencies import Currencies
    from pypara.fxrates.sources import FXRateSource
    from pypara.temporal import Temporal

    ## Create a mock FX rate source:
    source = MagicMock(spec=FXRateSource)

    ## Create the service:
    service = FXRateService()

    ## Create a list of queries:

# Generated at 2022-06-24 01:20:22.185717
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .currencies import Currencies
    from .temporal import Temporals

    from decimal import Decimal
    from typing import Deque

    from unittest import TestCase

    from queue import Queue

    class MockFXRateService(FXRateService):

        def __init__(self, rates: Deque[FXRate]):
            self.rates = rates

        def query(self, ccy1, ccy2, asof, strict):
            rate = self.rates.popleft()
            if rate:
                return FXRate(rate[0], rate[1], asof, rate[3])
            else:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                return None

        def queries(self, queries, strict):
            for query in queries:
                ccy1

# Generated at 2022-06-24 01:20:31.901563
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the :class:`FXRateLookupError` class.
    """
    __test__ = False

    ## Imports:
    import datetime
    from pypara.currencies import Currencies

    ## Initialize:
    ccy1, ccy2 = Currencies["EUR"], Currencies["USD"]
    date = datetime.date.today()

    ## Test:
    error = FXRateLookupError(ccy1, ccy2, date)
    assert isinstance(error, LookupError)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == date
    assert error.args[0] == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {date}"


# Generated at 2022-06-24 01:20:37.508355
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    assert FXRateLookupError(None, None, None) is not None

# Generated at 2022-06-24 01:20:43.821183
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import EUR, USD
    from .date import Date
    from .exchange import FXRateLookupError
    fx = FXRateLookupError(EUR, USD, Date.today())
    assert str(fx) == "Foreign exchange rate for EUR/USD not found as of 2016-12-07"


# Generated at 2022-06-24 01:20:50.109904
# Unit test for method queries of class FXRateService

# Generated at 2022-06-24 01:20:57.095579
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")

# Generated at 2022-06-24 01:21:02.208638
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:21:02.970218
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService()



# Generated at 2022-06-24 01:21:11.027247
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Periods
    from pypara.fx import FXRateService, FXRateLookupError

    ## Dummy FX rate service
    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            if ccy1 == Currencies.USD and ccy2 == Currencies.EUR:
                return FXRate(ccy1, ccy2, asof, Decimal("0.5"))

# Generated at 2022-06-24 01:21:16.206174
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .services import DefaultFXRateService
    
    fx_rate_service = DefaultFXRateService()
    usd_eur_fx_rate = fx_rate_service.query(Currency("USD"), Currency("EUR"), Date(2018, 4, 22))
    eur_usd_fx_rate = fx_rate_service.query(Currency("EUR"), Currency("USD"), Date(2018, 4, 22))
    
    assert(usd_eur_fx_rate.value == eur_usd_fx_rate.value ** -1)

# Generated at 2022-06-24 01:21:19.198312
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the functionality of the method query of the class FXRateService.
    """
    # Given a class instance of FXRateService
    FXRateService()

    # Then the method query is expected to raise a NotImplementedError
    # noinspection PyUnresolvedReferences
    try:
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-24 01:21:27.088699
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    assert(FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) ==
           FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")))

# Unit tests for inverted FX rate

# Generated at 2022-06-24 01:21:38.105335
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    from pypara.fx.services import FXRateService
    from pypara.temporal import Temporal
    from pypara.types import JSONType

    # Define unit test for FXRateLookupError:
    class TestFXRateLookupError(FXRateService):

        def query(self, ccy1, ccy2, asof, strict = False):
            raise FXRateLookupError(ccy1, ccy2, asof)

        def queries(self, queries, strict = False):
            raise NotImplementedError("Not implemented")

    # Test FXRateLookupError constructor:

# Generated at 2022-06-24 01:21:41.573933
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert "query" in FXRateService.__abstractmethods__
    assert "queries" in FXRateService.__abstractmethods__

# Generated at 2022-06-24 01:21:45.863111
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Positive case:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:21:56.015083
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests that the constructor of class :class:`FXRateLookupError` works as expected.
    """
    ## Here we make sure that the constructor works as expected:
    from .currencies import Currency
    from .zeitgeist import Date
    error = FXRateLookupError(Currency.EUR, Currency.USD, Date.of(2016, 6, 18))
    assert error.ccy1 == Currency.EUR
    assert error.ccy2 == Currency.USD
    assert error.asof == Date.of(2016, 6, 18)
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2016-06-18"


# Generated at 2022-06-24 01:22:01.606607
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    err = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert isinstance(err, LookupError)
    assert isinstance(err, FXRateLookupError)
    assert str(err) == "Foreign exchange rate for EUR/USD not found as of 2019-10-28"
    assert err.ccy1 == Currencies["EUR"]


# Generated at 2022-06-24 01:22:08.104339
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Unit test for method __invert__ of class FXRate
    """
    ## Import packages:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.rates import FXRate

    ## Create rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Check inversion:
    assert ~nrate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-24 01:22:15.197182
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:16.308924
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # TODO: Implement test
    pass

# Generated at 2022-06-24 01:22:18.343516
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    # TODO: Implement unit test
    pass


# Generated at 2022-06-24 01:22:24.144141
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime


# Generated at 2022-06-24 01:22:29.431446
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-24 01:22:31.486220
# Unit test for constructor of class FXRateService
def test_FXRateService():
    service = FXRateService()
    # verify that constants are instantiated properly
    assert service.TQuery == tuple
    assert service.default is None


# Generated at 2022-06-24 01:22:40.621835
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ccy1 = Currency("CCY/1", "Unit Test Currency/1")
    ccy2 = Currency("CCY/2", "Unit Test Currency/2")
    error = FXRateLookupError(ccy1, ccy2, Date.now())
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == Date.now()
    assert str(error) == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {Date.now()}"
    assert "Foreign exchange rate for CCY/1/CCY/2 not found as of" in repr(error)


# Generated at 2022-06-24 01:22:43.275293
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Unit test for method __invert__ of class FXRate.
    """
    pass



# Generated at 2022-06-24 01:22:51.990633
# Unit test for constructor of class FXRateService
def test_FXRateService():  # noqa: N802
    import unittest

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of class :class:`FXRateService`.

        I am using `unittest.mock.Mock` for this purpose, which is a subclass of class `FXRateService`.
        """

        queries: Iterable[Optional[FXRate]]

        def query(self, ccy1, ccy2, asof, strict):
            pass

        def queries(self, queries, strict):
            pass

    assert issubclass(MockFXRateService, FXRateService)



# Generated at 2022-06-24 01:22:57.941789
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    ## Create a query service:
    service = FXRateService()

    ## Create a query collection:
    queries = [
        (Currency("ABC"), Currency("XYZ"), Date.now()),
        (Currency("XYZ"), Currency("ABC"), Date.now()),
    ]

    ## Check that querying should fail:
    assert list(service.queries(queries, strict=True)) == []

# Generated at 2022-06-24 01:23:04.300913
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .temporal import Date
    from .fx_rates import FXRate, FXRateService, FXRateLookupError

    # Define an FX rate service to use in test cases:
    class TestService(FXRateService):

        def __init__(self):
            self.rates = {}

        def add(self, rate: FXRate):
            """
            Adds the given FX rate to this service.
            """
            self.rates[(rate.ccy1, rate.ccy2, rate.date)] = rate

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            # Check if we have a rate

# Generated at 2022-06-24 01:23:15.057920
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for the constructor of class FXRate
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    try:
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0"))
    except ValueError:
        pass
    else:
        raise ValueError("This test case should fail to execute.")


# Generated at 2022-06-24 01:23:15.688055
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService()


# Generated at 2022-06-24 01:23:20.405685
# Unit test for constructor of class FXRateService
def test_FXRateService():
    print("** Instantiating `FXRateService` **")
    print("Trying to instantiate an abstract class ...")
    try:
        FXRateService()  # noqa: F841
    except TypeError as err:
        print(f"Caught exception: {err}")
    else:
        print("FAILED!")
    print("Done!")

if __name__ == "__main__":
    test_FXRateService()

# Generated at 2022-06-24 01:23:31.998385
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .forex.rates.db import FXRateServiceDB
    from .forex.rates.hist import FXRateServiceHist

    ## Create the services:
    db = FXRateServiceDB()
    hist = FXRateServiceHist(db)
    
    ## Create the queries:
    date = Date.of("2018-01-01")

# Generated at 2022-06-24 01:23:40.820404
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from operator import itemgetter
    from pypara.currencies import Currencies
    from pypara.fx.services.inmemory import InMemoryFXRateService

    ## Create an FX rate service:
    fx_service = InMemoryFXRateService()

    ## Load some mock FX rates:
    fx_service.append(
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1), Decimal("2"))
    )
    fx_service.append(
        FXRate(Currencies["HKD"], Currencies["JPY"], datetime.date(2019, 1, 1), Decimal("0.5"))
    )

# Generated at 2022-06-24 01:23:46.696901
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    import datetime

    eur = Currencies["EUR"]
    usd = Currencies["USD"]
    asof = datetime.date.today()

    e = FXRateLookupError(eur, usd, asof)

    assert e.ccy1 == eur
    assert e.ccy2 == usd
    assert e.asof == asof



# Generated at 2022-06-24 01:23:58.006137
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for classes and FXRateService
    """
    from .currencies import USD
    from datetime import date
    
    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, 2)

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (FXRate(ccy1, ccy2, asof, 2) for ccy1, ccy2, asof in queries)

    print(USD / USD) #-> 1 USD
    print(USD / USD) #-> 1 USD

# Generated at 2022-06-24 01:24:00.366307
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # instantiating 
    try:
        __FXRateService = FXRateService('a')
        assert False
    except TypeError:
        assert True
    else:
        assert True

# Generated at 2022-06-24 01:24:08.032413
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == datetime.date.today()


# Generated at 2022-06-24 01:24:14.650767
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fxrates import FXRateService

    ## Define the FX rate service:
    class MyFXRateService(FXRateService):
        """
        A dummy FX rate service.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("1.5"))

        def queries(self, queries, strict=False):
            for q in queries:
                yield self.query(*q)

    ## Test the FX rate service:
    service = MyFXRateService()

# Generated at 2022-06-24 01:24:21.273369
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Test imports:
    import datetime
    import unittest
    from decimal import Decimal
    from functools import partial
    from unittest.mock import Mock

    # Test subject:
    from pypara.finance import FXRateService

    # Test helper:
    def query(ccy1, ccy2, asof, strict=True):
        """
        Return USD/EUR exchange rate for all dates except two.
        """
        if asof == datetime.date.today() - datetime.timedelta(3):
            return FXRateService.TQuery(ccy1, ccy2, asof)
        elif asof == datetime.date.today() - datetime.timedelta(4):
            return FXRateService.TQuery(ccy1, ccy2, asof)
       

# Generated at 2022-06-24 01:24:30.430681
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Unit test for method __invert__ of class FXRate:
    """
    from decimal import Decimal
    from pypara.currencies import Currencies

    import datetime

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:24:39.595791
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from datetime import date
    assert FXRate((), (), (), ())
    assert FXRate((1,), (2,), (), ())
    assert FXRate((1,), (2,), (3,), (4,))
    assert FXRate(
        Currency.EUR, Currency.USD, date(2017, 1, 1), Decimal('1.2')) == FXRate.of(
            Currency.EUR, Currency.USD, date(2017, 1, 1), Decimal('1.2'))



# Generated at 2022-06-24 01:24:44.177253
# Unit test for constructor of class FXRateService
def test_FXRateService():  # pragma: no cover
    def _test(fcn):
        try:
            fcn(None)
            return False
        except TypeError:
            return True

    assert _test(FXRateService.query)
    assert _test(FXRateService.queries)

# Generated at 2022-06-24 01:24:55.430344
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from unittest import TestCase, mock

    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1)),
        (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 3)),
        (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 2)),
    ]

    with mock.patch.object(FXRateService, "query") as mock_query:
        # Dummy FXRateService instance and `query` method:
        fxrs = FXRateService()

# Generated at 2022-06-24 01:25:00.231930
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:25:03.945630
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.__abstractmethods__ == {"queries", "query"}

# Generated at 2022-06-24 01:25:13.579137
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .temporal import Date, Today
    from .fxrateservices.memory import MemoryFXRateService
    from decimal import Decimal
    MemoryFXRateService.default = MemoryFXRateService({
        (Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1)): Decimal("1.2"),
        (Currencies["EUR"], Currencies["USD"], Date(2018, 1, 2)): Decimal("1.4"),
        (Currencies["EUR"], Currencies["USD"], Date(2018, 1, 3)): Decimal("1.2")
    })
    assert MemoryFXRateService.default.query(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1)) == Decimal("1.2")
    assert MemoryFXRateService.default.query

# Generated at 2022-06-24 01:25:19.393167
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from .currencies import Currencies

    fxrate = FXRate(Currencies["EUR"], Currencies["USD"], date(2000, 1, 1), Decimal("2"))
    assert isinstance(fxrate, FXRate)



# Generated at 2022-06-24 01:25:29.685886
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        class Base:
            pass

        raise FXRateLookupError("foo", "bar", Base())

    except Exception as err:
        # Check type
        assert isinstance(err, FXRateLookupError)

        # Check attributes:
        assert err.ccy1 == "foo"
        assert err.ccy2 == "bar"
        assert err.asof == Base()

        # Check message:
        assert str(err) == "Foreign exchange rate for foo/bar not found as of <pypara.fxrates.tests.test_FXRateLookupError.<locals>.Base object at 0x000001A36BC1C748>"


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 01:25:37.673033
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Runs the unit test for module `pypara.fxrates.FXRateService`.
    """
    from pypara.currencies import Currency
    from pypara.commons.zeitgeist import Now
    from pypara.exceptions import ParaDomainError
    from .mocks import FXRateServiceMock

    ## Test an abstract class create error:
    try:
        service = FXRateService()  # type: ignore
        raise Exception("An exception was expected.")
    except TypeError:
        pass

    ## Mock a service:
    service = FXRateServiceMock()

    ## Test query method:
    assert service.query(Currency.of("EUR"), Currency.of("USD"), Now()) == FXRate(Currency.of("EUR"), Currency.of("USD"), Now().date, Decimal("1.25"))

# Generated at 2022-06-24 01:25:43.232132
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:25:45.867900
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## Create an instance:
    lookup_error = FXRateLookupError(None, None, None)

    ## Check the message:
    assert isinstance(lookup_error.message, str)



# Generated at 2022-06-24 01:25:55.441966
# Unit test for constructor of class FXRate
def test_FXRate():  # pragma: no cover
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")



# Generated at 2022-06-24 01:26:01.773584
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    # noinspection PyUnresolvedReferences
    from pypara.currencies import Currencies
    # noinspection PyUnresolvedReferences
    from pypara.currencies import Currency

    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())

    assert isinstance(e, FXRateLookupError)
    assert isinstance(e, LookupError)
    assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2018-05-01"
    assert e.ccy1 == Currencies["EUR"]
    assert e.ccy2 == Currencies["USD"]
    assert e.asof == Date.today()



# Generated at 2022-06-24 01:26:05.120572
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:26:10.609484
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import date

    # EUR/USD asof 1st Jan 2020
    eur_usd_2020_01_01 = FXRateLookupError(Currencies["EUR"], Currencies["USD"], date(2020, 1, 1))
    assert str(eur_usd_2020_01_01) == "Foreign exchange rate for EUR/USD not found as of 2020-01-01"


# Generated at 2022-06-24 01:26:11.262766
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-24 01:26:23.972431
# Unit test for constructor of class FXRateService
def test_FXRateService():  # noqa: E501,N802
    from .commons.numbers import ONE, ZERO
    import unittest

    class MockFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return ONE

        def queries(self, queries, strict=False):
            yield ZERO
            yield ONE

    ## Unit test class:
    class FXRateServiceTest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.service = MockFXRateService()

        def test_query(self):
            from .currencies import Currencies
            from .commons.zeitgeist import Date
            from .fx import FXRate
            from decimal import Decimal

# Generated at 2022-06-24 01:26:35.205307
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import EUR, USD
    from pypara.temporal import Date

    import unittest

    class TestFXRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]) -> None:
            self._rates = dict(map(lambda r: ((r.ccy1, r.ccy2, r.date), r), rates))

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return self._rates.get((ccy1, ccy2, asof))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self._rates.get(q) for q in queries)

# Generated at 2022-06-24 01:26:36.431189
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError(): pass

# Unit tests for class FXRate

# Generated at 2022-06-24 01:26:48.287898
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    from collections import Iterable
    from inspect import Signature
    from unittest.mock import Mock

    from pypara.currencies import Currency

    from .currencies import Currencies

    class MockService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    mock = MockService()
    mock.query.return_value = None
    mock.queries.return_value = iter([None])


# Generated at 2022-06-24 01:26:50.207976
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 01:26:55.752029
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Unit test that verifies that :meth:`FXRate.__invert__` method works as expected.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:27:04.696175
# Unit test for constructor of class FXRateService
def test_FXRateService():

    class FXRateServiceMock(FXRateService):
        """
        Provides a concrete mock implementation of :class:`FXRateService`.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.

            :param ccy1: The first currency of foreign exchange rate.
            :param ccy2: The second currency of foreign exchange rate.
            :param asof: Temporal dimension the foreign exchange rate is effective as of.
            :param strict: Indicates if we should raise a lookup error if that the foreign exchange rate can not be found.
            :return: The foreign exhange rate as a :class:`Decimal` instance or None.
            """

# Generated at 2022-06-24 01:27:06.527090
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    FXRateLookupError(Currency("EUR"), Currency("USD"), Date())


# Generated at 2022-06-24 01:27:13.284351
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:27:21.930424
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class `FXRateService`.
    """
    # pylint: disable=missing-function-docstring,too-few-public-methods
    from unittest.mock import Mock, patch
    from .currencies import Currencies as C
    from .zeitgeist import Date as D
    from .fxrates import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, queries, strict=False):
            pass

    class MockStrictError(LookupError):
        pass


# Generated at 2022-06-24 01:27:28.929040
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    q = FXRateLookupError(Currency("EUR"), Currency("USD"), Date(2018, 9, 27))
    assert q.ccy1 == Currency("EUR")
    assert q.ccy2 == Currency("USD")
    assert q.asof == Date(2018, 9, 27)
    assert str(q) == "Foreign exchange rate for EUR/USD not found as of 2018-09-27"



# Generated at 2022-06-24 01:27:33.590948
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except Exception as ex:
        assert str(ex) == f"Foreign exchange rate for {Currencies['EUR']}/{Currencies['USD']} not found as of {datetime.date.today()}"


# Generated at 2022-06-24 01:27:40.997432
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from unittest import TestCase, TestSuite, TextTestRunner
    from unittest.mock import MagicMock, patch

    from datetime import date
    from decimal import Decimal

    from pypara.currencies import Currency

    from pypara.finmath.fx.conversions import FXRate

    class TestFXRate___invert__(TestCase):
        """
        Tests the implementation of method __invert__ of class FXRate
        """
        def test_method_returns_a_new_FXRate_instance_with_inverted_currency_rates_and_value(self):
            # Arrange:
            ccy1 = Currency("EUR", "EUR", "978", "EUR", "€")
            ccy2 = Currency("USD", "USD", "840", "USD", "$")
            rate = FX

# Generated at 2022-06-24 01:27:50.124430
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from .commons.zeitgeist import Date
    from .currencies import Currency

    from .services import FXRateServices

    ## Create a query:
    ccy1 = Currency("AUD")
    ccy2 = Currency("USD")
    on = Date(2009, 9, 29)

    ## Query for a direct rate:
    service = FXRateServices["Direct"]
    rate = service.query(ccy1, ccy2, on)
    assert rate.ccy1 == ccy1
    assert rate.ccy2 == ccy2
    assert rate.date == on
    assert rate.value == Decimal("0.9087")

    ## Query for an inverse rate:
    rate = service.query(ccy2, ccy1, on)
    assert rate.ccy1 == ccy2


# Generated at 2022-06-24 01:28:03.831708
# Unit test for constructor of class FXRate
def test_FXRate():
    # Start test
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    # Test default constructor
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")

    # Test property access
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")

    # Test safe constructor

# Generated at 2022-06-24 01:28:11.910109
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:28:20.436292
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fxrates import FXRateService
  
    class MockFXRateService(FXRateService):
        def __init__(self):
            self.rates = [
                FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2010, 1, 1), Decimal("1.5")),
                FXRate(Currencies["USD"], Currencies["EUR"], datetime.date(2010, 1, 1), Decimal("0.5"))
            ]


# Generated at 2022-06-24 01:28:25.960643
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], 1)
    except FXRateLookupError as ex:
        assert(ex.ccy1 == Currencies["EUR"])
        assert(ex.ccy2 == Currencies["USD"])
        assert(ex.asof == 1)


# Generated at 2022-06-24 01:28:31.894377
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

