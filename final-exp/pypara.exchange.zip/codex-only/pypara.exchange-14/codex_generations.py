

# Generated at 2022-06-24 01:18:36.066705
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies 
    from pypara.commons.zeitgeist import Date
    fxrate_lookup_error = FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date(2020,1,1))
    assert fxrate_lookup_error.ccy1 == Currencies["USD"]
    assert fxrate_lookup_error.ccy2 == Currencies["EUR"]
    assert fxrate_lookup_error.asof == Date(2020,1,1)
    assert fxrate_lookup_error.__str__() == "Foreign exchange rate for USD/EUR not found as of 2020-01-01"


# Generated at 2022-06-24 01:18:36.998377
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService

test_FXRateService()

# Generated at 2022-06-24 01:18:49.812706
# Unit test for method query of class FXRateService

# Generated at 2022-06-24 01:19:01.293927
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class DumbFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate.of(ccy1, ccy2, asof, Decimal("2"))
            elif strict:
                raise FXRateLookupError(self[0], self[1], self[2])
            return None


# Generated at 2022-06-24 01:19:08.295049
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate: FXRate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate: FXRate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:10.116138
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, ABCMeta)
    assert FXRateService.__doc__ is not None
    assert FXRateService.__abstractmethods__ == {"query", "queries"}

# Generated at 2022-06-24 01:19:19.855693
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method :method:`~test_FXRateService.queries` of class :class:`FXRateService`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from unittest import mock

    ## Define an FX rate service:
    class TestService(FXRateService):
        """
        Provides an FX rate service for testing.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            ## Return the mocked result:
            return mock_fx_rates[(ccy1, ccy2, asof)]

        def queries(self, queries, strict=False):
            ## Make sure the query is a tuple:
            assert isinstance(queries, tuple)

            ## Return the mocked result:
           

# Generated at 2022-06-24 01:19:24.905533
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test method query of class FXRateService.
    """
    # Imports
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fx import FXRate, FXRateLookupError, FXRateService

    # Test success
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(1.0))
    rate = TestFXRateService().query(Currencies["EUR"], Currencies["USD"], Date.today())
    assert isinstance(rate, FXRate)
    assert rate[0] == Currencies["EUR"]

# Generated at 2022-06-24 01:19:33.657594
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert(ccy1 == Currencies["EUR"])
    assert(ccy2 == Currencies["USD"])
    assert(date == datetime.date.today())
    assert(value == Decimal("2"))


# Generated at 2022-06-24 01:19:35.216838
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, object)

# Generated at 2022-06-24 01:19:46.136434
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    class StubFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            from pypara.fx import FXRate

            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == datetime.date(2017, 9, 15):
                return FXRate(ccy1, ccy2, asof, Decimal(1.2))

            elif strict:
                from pypara.fx import FXRateLookupError

                raise FXRateLookupError(ccy1, ccy2, asof)

            else:
                return None

    ccy1 = Cur

# Generated at 2022-06-24 01:19:50.756581
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:19:59.004874
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .commons.zeitgeist import Date

    class FXRateServiceImpl(FXRateService):
        def __init__(self, rates=None):
            self.rates = rates or {}

        def query(self, ccy1, ccy2, asof, strict):
            return self.rates.get(FXRateService.TQuery((ccy1, ccy2, asof)), None)

        def queries(self, queries, strict):

            # arguments should not be modified
            assert len(queries) > 0
            ccy1, ccy2, asof = queries[0]
            assert ccy1 is not None
            assert ccy2 is not None
            assert asof is not None


# Generated at 2022-06-24 01:20:08.310713
# Unit test for constructor of class FXRateService
def test_FXRateService():
    def assert_absent(ccy1: Currency, ccy2: Currency, date: Date, strict: bool = False) -> None:
        bad_rate = FXRate.of(ccy1, ccy2, date, Decimal("2"))
        if strict:
            assert None == fx_rate_service.query(ccy1, ccy2, date, strict=True)
        else:
            assert bad_rate != fx_rate_service.query(ccy1, ccy2, date)

    def assert_present(ccy1: Currency, ccy2: Currency, date: Date, strict: bool = False) -> None:
        rate = FXRate.of(ccy1, ccy2, date, Decimal("2"))

# Generated at 2022-06-24 01:20:12.115335
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:22.526195
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class _dailyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for q in queries:
                yield self.query(*q, strict=strict)

    from .currencies import Currencies
    from .commons.zeitgeist import date
    from .commons.numbers import ONE, TWO

    ccy = Currencies["USD"]
    dfx = _dailyFXRateService()


# Generated at 2022-06-24 01:20:32.148900
# Unit test for method query of class FXRateService
def test_FXRateService_query(): ## noqa: D103
    from pypara.currencies import Currencies
    from pypara.datasets.dummy import DummyFXRateDataSet
    from pypara.dates import Date
    from pypara.services import FXRateService, DummyFXRateService
    service = DummyFXRateService(data_set=DummyFXRateDataSet())
    assert service.query(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], asof=Date(2019, 5, 31), strict=True) == FXRate(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], date=Date(2019, 5, 31), value=1.1216)

# Generated at 2022-06-24 01:20:41.788682
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Tests functionality of the FXRate constructor.
    """
    assert isinstance(FXRate, type), "`FXRate` class is not defined."

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")

    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
   

# Generated at 2022-06-24 01:20:49.156557
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .commons.zeitgeist import TODAY
    from . import FXRateLookupError

    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = TODAY.date()
    error = FXRateLookupError(ccy1, ccy2, asof)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof


# Generated at 2022-06-24 01:20:51.922680
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from pypara.currencies import Currencies
    from datetime import date
    from decimal import Decimal

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    assert ~nrate == FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))


# Generated at 2022-06-24 01:20:56.808259
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .commons.zeitgeist import Today
    from .fx import FXRate

    ## Initialize the rate service:
    class FakeFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if (ccy1, ccy2, asof) in (
                    (Currencies["EUR"], Currencies["USD"], Today),
                    (Currencies["AUD"], Currencies["USD"], Today)):
                return FXRate(ccy1, ccy2, asof, Decimal("1.0"))
            else:
                return None

    service = FakeFXRateService()

    ## Query the rate service:

# Generated at 2022-06-24 01:21:02.172494
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService.
    """
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    from .fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock :class:`FXRateService` to unit test :class:`FXRateService`.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            if ccy1 == Currencies.NONE or ccy2 == Currencies.NONE:
                return None

# Generated at 2022-06-24 01:21:07.574691
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporals import Date
    from datetime import date
    import pytest
    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.of(date(2018, 1, 1)))



# Generated at 2022-06-24 01:21:17.154833
# Unit test for constructor of class FXRate
def test_FXRate():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


if __name__ == '__main__':
    import doctest as dt

    dt.testmod(optionflags=dt.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 01:21:22.819681
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    fx = FXRate(Currencies["EUR"], Currencies["USD"], Date("2020-04-29"), Decimal("1.1"))

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 != fx[0]:
                return None
            if ccy2 != fx[1]:
                return None
            if asof != fx[2]:
                return None
            return fx

    fxservice = TestFXRateService()
    assert fxservice.query(fx[0], fx[1], fx[2], False) == fx
    assert f

# Generated at 2022-06-24 01:21:30.468420
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    print(e)
    assert e.args == (f"Foreign exchange rate for {Currencies['EUR']}/{Currencies['USD']} not found as of {datetime.date.today()}",)

# Unit tests for class FXRate
if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 01:21:42.309216
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test to see if the query method of the FXRateService works correctly.
    """
    import unittest
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService, FXRate

    class TestService(FXRateService):
        """
        Implements a test FX rate service.
        """


# Generated at 2022-06-24 01:21:49.486452
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies

    import datetime

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-24 01:21:59.845486
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import EUR, USD
    from .datasets import FXRateDataset
    from .timeseries import TemporalDimension, TemporalDimensions

    ## Create a dataset:
    dataset = FXRateDataset()

    ## Get the date (for testing)
    date = TemporalDimension.of(2019, 7, 8, TemporalDimensions.Date)

    ## Create the service:
    service = dataset.factory("USD/EUR")()

    assert service.query(EUR, USD, date) == FXRate.of(EUR, USD, date.value, Decimal("1.11545"))
    assert service.query(EUR, USD, date, strict=True) == FXRate.of(EUR, USD, date.value, Decimal("1.11545"))


# Generated at 2022-06-24 01:22:07.384884
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit tests for FXRateService.
    """
    from unittest import TestCase, mock
    from .currencies import Currency

    ## Mock the FX rate service:
    service = mock.Mock(FXRateService)

    ## Mock the queries:
    queries = [service.TQuery(Currency("EUR"), Currency("USD"), Date.today())]

    ## Test the results:
    with mock.patch.object(service, "queries") as mocked:

        ## Run the method:
        results = service.queries(queries)

        ## Check if we called the mocked method with specified arguments:
        mocked.assert_called_once_with(queries)

    ## Check the result:
    assert not list(results)


# Generated at 2022-06-24 01:22:15.959446
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-24 01:22:20.430630
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-24 01:22:32.484844
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .commons.zeitgeist import Date
    from .services import FXRateService
    from .services.in_memory import InMemoryFXRateService

    class TestFXRateService(FXRateService):

        class TestFXRate(FXRate):

            def __init__(self):
                super().__init__(Currencies["EUR"], Currencies["USD"], Date(2019, 11, 1), Decimal(1.25))

        ccy1 = Currencies["EUR"]
        ccy2 = Currencies["USD"]
        asof = Date(2019, 11, 1)
        strict = False
        fxrate = FXRateService.query(ccy1, ccy2, asof, strict)
        assert fxrate == TestFXRateService.TestFX

# Generated at 2022-06-24 01:22:38.931323
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-24 01:22:46.797849
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.rates import FXRate, FXRateService


# Generated at 2022-06-24 01:22:54.448584
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from .commons.zeitgeist import Date
    from .currencies import Currency

    # Arrange
    service = FXRateService()
    ccy1 = Currency()
    ccy2 = Currency()
    asof = Date()
    strict = True

    # Act
    rate = service.query(ccy1, ccy2, asof, strict)

    # Assert
    assert isinstance(rate, Decimal)


# Generated at 2022-06-24 01:23:00.777735
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .zeitgeist import Date
    error = FXRateLookupError(Currency("EUR", "EUR"), Currency("USD", "USD"), Date(2019, 10, 15))
    assert error.ccy1 == Currency("EUR", "EUR")
    assert error.ccy2 == Currency("USD", "USD")
    assert error.asof == Date(2019, 10, 15)
    assert error.args[0] == "Foreign exchange rate for EUR/USD not found as of 2019-10-15"


# Generated at 2022-06-24 01:23:06.460632
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["US"], datetime.date.today(), Decimal("2"))
    print(rate)
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["US"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")



# Generated at 2022-06-24 01:23:18.411522
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test the :method:`FXRateService.queries` method.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.rates.services.memory import MemoryFXRateService

    ## Create a memory service:
    service = MemoryFXRateService()

    ## Add rates:
    service.add(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    service.add(Currencies["EUR"], Currencies["USD"], datetime.date.today() + datetime.timedelta(days=1), Decimal("2"))
    service.add(Currencies["EUR"], Currencies["USD"], 10, datetime.date(2020, 1, 1), Decimal("3"))

    ## Get the queries:


# Generated at 2022-06-24 01:23:25.582413
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import d
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], d("2020-01-01"))
    except FXRateLookupError as err:
        assert f"{Currencies['EUR']!r}/{Currencies['USD']!r}" in str(err)


# Generated at 2022-06-24 01:23:37.381597
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): # type: ignore
    """
    Unit test for method queries of class FXRateService.
    """
    from .currencies import Currencies
    from .commons.zeitgeist import TemporalContext, Date

    # Define the time context:
    now = Date.today()
    temporal_context = TemporalContext(now)

    # Define the FX rate service:
    class MockService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        TQuery = Tuple[Currency, Currency, Date]

        # pylint: disable=unused-argument
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the requested FX rate, if exists.
            """

# Generated at 2022-06-24 01:23:50.022577
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    import types
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Test method query.
    class FXRateServiceSubclass(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    ## Check that the method exists:
    assert hasattr(FXRateServiceSubclass, 'query')
    assert isinstance(FXRateServiceSubclass.query, types.FunctionType)

    ## Check that

# Generated at 2022-06-24 01:23:55.959874
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # Get the current module:
    import inspect
    import sys
    module = inspect.getmodule(sys._getframe())

    # Import the module:
    from pypara.finance import fxrates
    from pypara.finance.fxrates import FXRateService

    # Mock foreign exchange rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate.of(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries, strict=False):
            for query in queries:
                yield FXRate.of(query[0], query[1], query[2], Decimal("2"))

    # Set the default fx rate service:
    module.default = MockFXRateService()

# Generated at 2022-06-24 01:24:08.562748
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This unit test checks that the method `queries` of class `FXRateService`
    returns the same foreign exchange rates as the method `query` would return
    for each given query.
    """
    from .temporal import Date
    from .currencies import EUR, USD, Currencies
    import unittest
    from .unittest_helpers import HasLogger, CallRecorder

    ## Create an abstract base class for creating FX rate services:
    class FXRateServiceBase(FXRateService):

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes an FX rate service base.
            """
            ## Keep the rates:
            self.rates = {(ccy1, ccy2, date): rate for ccy1, ccy2, date, rate in rates}


# Generated at 2022-06-24 01:24:16.939897
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as ex:
        assert str(ex) == "Foreign exchange rate for EUR/USD not found as of " + str(datetime.date.today())


# Generated at 2022-06-24 01:24:27.548171
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    # Arrange
    from pypara.currencies import Currencies
    import datetime
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date(2018, 11, 1)

    # Act
    error = FXRateLookupError(ccy1=ccy1, ccy2=ccy2, asof=asof)

    # Assert
    message = "Foreign exchange rate for {}/{} not found as of {}".format(ccy1, ccy2, asof)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert repr(error) == message



# Generated at 2022-06-24 01:24:34.968553
# Unit test for method queries of class FXRateService

# Generated at 2022-06-24 01:24:46.823148
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MyFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date(2020, 1, 1)
                or ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == datetime.date(2020, 1, 1)):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-24 01:24:51.627094
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .temporal import Today, Date

    print(repr(FXRate(Currencies["EUR"], Currencies["USD"], Today, Decimal(1))))
    print(repr(FXRate.of(Currencies["EUR"], Currencies["USD"], Date.of(2018, 12, 31), Decimal(0.5))))

# Generated at 2022-06-24 01:24:53.184001
# Unit test for constructor of class FXRateService
def test_FXRateService():  # noqa: D103
    pass

# Generated at 2022-06-24 01:24:56.785513
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    queries = (
        (Currency("EUR"), Currency("USD"), Date("2020/01/01")),
        ("EUR", "USD", Date("2020/01/01")),
    )

    for ccy1, ccy2, date in queries:
        assert FXRateService.TQuery(ccy1, ccy2, date) == queries[0]

# Generated at 2022-06-24 01:25:01.393183
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:25:06.124954
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    # Default arguments
    try:
        raise FXRateLookupError(Currency('EUR'), Currency('USD'), Date(2020, 1, 1))
    except FXRateLookupError as e:
        assert e.ccy1.name == 'EUR'
        assert e.ccy2.name == 'USD'
        assert e.asof == Date(2020, 1, 1)
        assert str(e) == 'Foreign exchange rate for EUR/USD not found as of 2020-01-01'

# Generated at 2022-06-24 01:25:15.940453
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    import pytest
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    class TestFXRateService(FXRateService):
        @staticmethod
        def query(ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2, asof) in TestFXRateService.rates:
                return TestFXRateService.rates[(ccy1, ccy2, asof)]
            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None


# Generated at 2022-06-24 01:25:20.107505
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and date == datetime.date.today() and value == Decimal("2")


# Generated at 2022-06-24 01:25:25.893893
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert( ~nrate == rrate )


# Generated at 2022-06-24 01:25:34.528077
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class DummyFXRateService(FXRateService):

        @classmethod
        def of(cls, *args, **kwargs) -> "DummyFXRateService":
            """
            Creates and returns an instance of :class:`DummyFXRateService` by validating arguments.
            """
            return cls()

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    DummyFXRateService.of()

# Generated at 2022-06-24 01:25:39.243975
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    d = Date.today()
    r = FXRateLookupError(Currencies["EUR"], Currencies["USD"], d)
    assert r.ccy1 == Currencies["EUR"]
    assert r.ccy2 == Currencies["USD"]
    assert r.asof == d


# Generated at 2022-06-24 01:25:48.438270
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """

    # Python standard library modules
    import unittest

    # PyPara modules
    import pypara.currencies as currencies
    from pypara.time import asdate

    # Class for testing
    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

            # Check the value of strict

# Generated at 2022-06-24 01:25:51.084302
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

# Generated at 2022-06-24 01:26:00.456026
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currencies
    from .temporal import Date
    from decimal import Decimal

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2018, 3, 28):
                return FXRate(ccy1, ccy2, asof.date(), Decimal("0.5"))
            return None


# Generated at 2022-06-24 01:26:10.878298
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method.
    """

    ## Set the queries:
    from .currencies import Currencies
    from .temporals import FXDate
    from .default import default_fx_rate_service
    from decimal import Decimal
    from typing import List
    import datetime


# Generated at 2022-06-24 01:26:23.328469
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.engine import FXRateService

    ## Defines a foreign exchange rate:
    class EURUSD(FXRateService):

        def query(self, ccy1, ccy2, asof, strict = False):
            return FXRate(ccy1, ccy2, asof, Decimal("1.1"))

    ## Check the default service:
    engine = FXRateService.default
    assert engine is None

    ## Define a new service:
    engine = EURUSD()
    assert engine is not None

    ## Check equality with the default:
    assert engine != FXRateService.default

    ## Set it as the default:
    FXRateService.default = engine

    assert FXRateService.default == engine

    ## Look for a rate:
    rate

# Generated at 2022-06-24 01:26:31.515661
# Unit test for constructor of class FXRate
def test_FXRate():
    # import datetime
    from pypara.currencies import Currencies
    from pypara.market.fxrates import FXRate

    fx_rate = FXRate.of(Currencies["EUR"], Currencies["USD"], Date.today(), 2)

    assert(fx_rate[0] == Currencies["EUR"])
    assert(fx_rate[1] == Currencies["USD"])
    assert(fx_rate[2] == Date.today())
    assert(fx_rate[3] == 2)


# Generated at 2022-06-24 01:26:43.366946
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date


# Generated at 2022-06-24 01:26:51.546093
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from dataclasses import dataclass
    from pypara.currencies import Currency
    from pypara.commons.zeitgeist import Date as dt

    @dataclass
    class MyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            from .fxrates import FXRate
            return FXRate(ccy1, ccy2, asof, Decimal(1))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

   

# Generated at 2022-06-24 01:26:56.478773
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    # imports
    import unittest
    from pypara.currencies import Currency, Currencies
    from pypara.commons.numbers import ZERO
    from pypara.fxrates import FXRateService, FXRateLookupError
    from pypara.curves import Temporal
    # mocks
    class FXRateServiceMock(FXRateService):
        """
        Mock for fxrate service
        """

# Generated at 2022-06-24 01:26:59.200615
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import EUR, USD
    err = FXRateLookupError(EUR, USD, datetime.date.today())
    assert err.ccy1 == EUR
    assert err.ccy2 == USD
    assert err.asof == datetime.date.today()


# Generated at 2022-06-24 01:27:05.850037
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from datetime import date
    from pypara.currencies import USD, EUR
    e = FXRateLookupError(USD, EUR, date(2014, 1, 1))

    assert e.ccy1 == USD
    assert e.ccy2 == EUR
    assert e.asof == date(2014, 1, 1)


# Generated at 2022-06-24 01:27:09.463039
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert isinstance(FXRateService, ABCMeta)
    assert isinstance(FXRateService.default, type(None))
    assert isinstance(FXRateService.TQuery, tuple)

# Generated at 2022-06-24 01:27:15.111594
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:27:27.289513
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D103

    from typing import List
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Define some test queries:
    queries: List[FXRateService.TQuery] = [
        # A valid one:
        (
            Currencies["EUR"],
            Currencies["USD"],
            date(2020, 1, 1),
        ),

        # An invalid one:
        (
            Currencies["USD"],
            Currencies["EUR"],
            date(2020, 1, 1),
        ),

        # An invalid one:
        (
            Currencies["EUR"],
            Currencies["NJK"],
            date(2020, 1, 1),
        ),
    ]

    ## Define the FX rate service:

# Generated at 2022-06-24 01:27:32.971025
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class UnitTest(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    assert UnitTest

# Generated at 2022-06-24 01:27:37.553777
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-24 01:27:44.946282
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date

    today = Date.today()
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], today)
    assert isinstance(error, TypeError)



# Generated at 2022-06-24 01:27:49.292677
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from datetime import date
    error = FXRateLookupError(Currency("EUR"), Currency("USD"), date(2020, 1, 1))
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2020-01-01"

# Generated at 2022-06-24 01:27:50.126191
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:28:03.782617
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests that multiple foreign exchange rates can be retrieved in relation to a given collection of queries.
    """
    ## Import:
    from unittest import TestCase, main
    from datetime import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Mocks:
    class MyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            results = []

# Generated at 2022-06-24 01:28:08.452704
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """Test constructor of class FXRateService."""
    assert issubclass(FXRateService, object)


# Generated at 2022-06-24 01:28:16.187200
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .lookups import FXRateLookupService
    from .temporal import Date
    fxrates = FXRateLookupService()
    EUR = Currencies["EUR"]
    USD = Currencies["USD"]
    GBP = Currencies["GBP"]
    JPY= Currencies["JPY"]
    rates = fxrates.queries([(EUR, USD, Date(2019, 1, 1)), (GBP, JPY, Date(2019, 1, 1)), (USD, GBP, Date(2019, 1, 1))])
    list(rates)

# Generated at 2022-06-24 01:28:24.222596
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-24 01:28:24.813749
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService()

# Generated at 2022-06-24 01:28:27.397993
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ccy1, ccy2, asof = Currency("EUR"), Currency("USD"), Date()
    assert FXRateLookupError(ccy1, ccy2, asof)

