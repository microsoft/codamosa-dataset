

# Generated at 2022-06-24 01:18:30.431421
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies['EUR'],
                  Currencies['USD'],
                  datetime.date.today(),
                  Decimal('2'))
    ccy1, ccy2, date, value = rate
    ccy1 == Currencies['EUR']
    ccy2 == Currencies['USD']
    date == datetime.date.today()
    value == Decimal('2')


# Generated at 2022-06-24 01:18:35.372856
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:18:48.071945
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    try:
        # Make sure the constructor raises `ValueError` when FX rate value is less then `zero`:
        r = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0"))
        assert isinstance(r, FXRate)
    except ValueError:
        # Exception is expected, do nothing.
        pass
    else:
        raise RuntimeError("Constructor of class FXRate failed to raise `ValueError`.")

    # Make sure the constructor raises `ValueError` when FX rate is to the same currency and value is not `one`:

# Generated at 2022-06-24 01:18:59.843721
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    A unit test for :method:`FXRateService.query` method.
    """
    # Import modules
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    # Create a dummy foreign exchange rate service
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None
        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    # Create an instance of the dummy service
    fxsrv = DummyFXRateService()

    # Create an EUR/USD rate for today.

# Generated at 2022-06-24 01:19:11.979834
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests whether the FXRateLookupError behaves as expected.
    """
    ## Import modules:
    from decimal import Decimal
    from pypara.currencies import CurrencyBuilder, Currency, Currencies
    from pypara.commons.numbers import ONE, ZERO
    from datetime import date
    from pypara.commons.zeitgeist import Date
    from pypara.fx import FXRateLookupError

    ## Create an FX rate lookup error and check attributes:
    lookup_error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    assert isinstance(lookup_error, FXRateLookupError)
    assert lookup_error.ccy1 == Currencies["EUR"]
    assert lookup_error.ccy2 == Currencies["USD"]

# Generated at 2022-06-24 01:19:13.110669
# Unit test for constructor of class FXRateService
def test_FXRateService():  # noqa: N802
    assert FXRateService()

# Generated at 2022-06-24 01:19:23.502802
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate.
    """
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commons import time
    def fxrate_test(ccy1: Currency, ccy2: Currency, date: Date, value: Decimal) -> None:
        """
        Tests the FXRate constructor and inverted FXRate instance.
        """
        ## Construct an FX rate:
        rate = FXRate(ccy1, ccy2, date, value)

        ## Check that created correctly:
        assert rate[0] == ccy1
        assert rate[1] == ccy2
        assert rate[2] == date
        assert rate[3] == value

        ## Construct an inverted FX rate:
        irate = ~rate

        ## Check that created correctly:
       

# Generated at 2022-06-24 01:19:26.607035
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-24 01:19:33.330174
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from currencies import Currencies
    from fx import FXRate
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:19:33.925185
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

# Generated at 2022-06-24 01:19:38.275984
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate.
    """

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-24 01:19:39.651639
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    '''
    Test FXRateService_queries
    '''
    # TODO(maurice): Implement.
    assert True

# Generated at 2022-06-24 01:19:49.319864
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Use array-based implementation for the FX rate service:
    from pypara.services.fxrates import ARRAY_IMPLEMENTATION

    ## Prepare the FX rate service:
    class MyService(ARRAY_IMPLEMENTATION):
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict)

    ## Prepare the data for the FX rate service:

# Generated at 2022-06-24 01:19:56.105412
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService
    """
    import random
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import Curve
    from pypara.curves.yieldcurves import YieldCurveBuilderContext, YieldCurveQuery, YieldCurveQueryData, YieldCurve, YieldCurveBuilder
    from pypara.curves.yieldcurves import SimpleYieldCurveInterpolator, FlatForwardYieldCurveInterpolator
    from pypara.curves.yieldcurves.interpolators.linear import LinearYieldCurveInterpolator

    # Setup the curve query
    asof = datetime.date.today()
    ccy = Currencies["USD"]

# Generated at 2022-06-24 01:20:03.586147
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-24 01:20:11.741326
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService
    """
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.fx.dummy import DummyFXRateService

    class DummyFXRateService(FXRateService):
        """
        Provides an implementation of a dummy foreign exchange rate service.

        :param rates: An iterable of :class:`FXRate`.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the dummy foreign exchange rate service.
            """
            ## Keep the rates:
            self.rates = rates


# Generated at 2022-06-24 01:20:22.280814
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # pylint: disable=missing-class-docstring
    # pylint: disable=missing-function-docstring
    # pylint: disable=no-self-use

    ## Imports:
    from typing import Iterable
    from unittest import TestCase

    from decimal import Decimal
    from datetime import date

    from pypara.currencies import Currency, Currencies
    from .fx import FXRateService, FXRateLookupError

    ## Globals:

# Generated at 2022-06-24 01:20:31.938072
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of :class:`FXRateService`.

    .. seealso:: :class:`pypara.markets.fx.tests.tests.TestFXRateService`
    """
    ## Create a test instance:
    from pypara.markets.fx.tests.tests import TestFXRateService
    from decimal import Decimal

    service = TestFXRateService()

    ## Query a single element:
    assert service.queries([(Currency("EUR"), Currency("TRY"), None)]) == [
        FXRate(Currency("EUR"), Currency("TRY"), Date(2018, 1, 1), Decimal(5.5))
    ]

    ## Query multiple elements:

# Generated at 2022-06-24 01:20:33.603481
# Unit test for constructor of class FXRateService
def test_FXRateService():
	pass

# Generated at 2022-06-24 01:20:38.784367
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class FXRateLookupError.
    """
    ## Setup:
    from pypara.currencies import Currency
    from pypara.date import Date
    ccy1 = Currency("USD")
    ccy2 = Currency("TRY")
    asof = Date.today()
    ## Test and assert:
    try:
        raise FXRateLookupError(ccy1, ccy2, asof)
    except FXRateLookupError as ex:
        assert ex.ccy1 == ccy1
        assert ex.ccy2 == ccy2
        assert ex.asof == asof
        assert ex.args[0] == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}"


# Generated at 2022-06-24 01:20:44.866756
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class FXRateServiceStub(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    FXRateServiceStub()

# Generated at 2022-06-24 01:20:50.585570
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class _FXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    assert isinstance(_FXRateService(), FXRateService)
    assert _FXRateService is not FXRateService

if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 01:20:59.044231
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currency
    from pypara.commons.zeitgeist import Date
    from pypara.fxrates import FXRateLookupError

    currency1 = Currency("EUR")
    currency2 = Currency("USD")
    asof = Date(1, 1, 2019)
    lookup_error = FXRateLookupError(currency1, currency2, asof)
    assert lookup_error.ccy1 is currency1
    assert lookup_error.ccy2 is currency2
    assert lookup_error.asof is asof


# Generated at 2022-06-24 01:21:08.182119
# Unit test for constructor of class FXRate

# Generated at 2022-06-24 01:21:16.525637
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ccy1 = Currency("EUR", "EUR")
    ccy2 = Currency("USD", "USD")
    asof = Date(2018, 1, 1)
    e = FXRateLookupError(ccy1, ccy2, asof)
    assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2018-01-01"
    assert e.ccy1.code == "EUR"
    assert e.ccy2.code == "USD"
    assert e.asof.year == 2018


# Generated at 2022-06-24 01:21:21.208039
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Verifies the operation of method queries of class FXRateService.
    """

    ## Import required types and modules:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from unittest import TestCase, TestSuite, TextTestRunner

    ## Define a test fixture class:
    class FXRateServiceQueriesTest(TestCase):
        """
        Provides unit tests for method queries of class FXRateService.
        """

        def setUp(self):
            """
            Initializes the test fixture before each test method is called.
            """
            ## Define a test service
            self.service = FXRateService()

            ## Define a test query set:

# Generated at 2022-06-24 01:21:32.010840
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    from pypara.fx.rate import FXRateService

    class FixedRateService(FXRateService):
        def __init__(self, rate: Decimal) -> None:
            self._rate = rate

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, self._rate)


# Generated at 2022-06-24 01:21:38.467400
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:21:44.525023
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    # Check the types
    assert isinstance(error, FXRateLookupError)
    assert isinstance(error, LookupError)
    assert isinstance(error, Exception)

    # Check the message
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2020-08-17"



# Generated at 2022-06-24 01:21:56.596119
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from collections import namedtuple
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency, Currencies

    # Define a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            qrate = self.queries([(ccy1, ccy2, asof)])
            return next(qrate, None)


# Generated at 2022-06-24 01:22:06.463300
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    from unittest.mock import call
    from decimal import Decimal

    from .currencies import Currencies

    fxrateservice = FXRateService()
    query = fxrateservice.queries(
        iter([
            (Currencies["EUR"], Currencies["USD"], Date.now()),
            (Currencies["EUR"], Currencies["USD"], Date.now()),
            (Currencies["EUR"], Currencies["USD"], Date.now())
        ])
    )
    assert isinstance(query, Iterable)

    queries = Mock()

# Generated at 2022-06-24 01:22:18.344076
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    r1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2020,4,4), Decimal("1.20"))
    r2 = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date(2020,4,4), Decimal("0.80"))
    assert r1 != r2
    assert ~r1 == r2
    assert ~r2 == r1
    assert str(r1) == 'FXRate(ccy1=<EUR>, ccy2=<USD>, date=datetime.date(2020, 4, 4), value=Decimal(\'1.20\'))'

# Generated at 2022-06-24 01:22:24.157588
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporals import Temporals
    from decimal import Decimal

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Temporals["2017-07-12"]:
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))
            else:
                return None

        def queries(self, qs, strict=False):
            for q in qs:
                yield self.query(*q)

    service = TestFXRateService()

# Generated at 2022-06-24 01:22:26.940271
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-24 01:22:34.031438
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MyFxRateService(FXRateService):
        def __init__(self, fxrates: Iterable[FXRate]):
            self._fxrates = fxrates

        def query(self, ccy1, ccy2, asof, strict=False):
            for fxrate in self._fxrates:
                if fxrate.ccy1 == ccy1 and fxrate.ccy2 == ccy2 and fxrate.date == asof:
                    return fxrate
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof) from None
            return None


# Generated at 2022-06-24 01:22:46.291463
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from .currencies import Currency
    from .temporal import Date
    from .contexts import Context
    from .markets.fx import FXRateService
    from .markets.fx import DummyFXRateService # type: ignore

    date_2003_01_02 = Date.of(2003, 1, 2)
    date_2003_01_03 = Date.of(2003, 1, 3)
    date_2003_01_04 = Date.of(2003, 1, 4)
    date_2003_01_05 = Date.of(2003, 1, 5)
    date_2003_01_06 = Date.of(2003, 1, 6)
    date_2003_01_07 = Date.of(2003, 1, 7)
    date_2003_01_08 = Date.of(2003, 1, 8)

    context1 = Context()


# Generated at 2022-06-24 01:22:53.667007
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime

    from decimal import Decimal
    from dateutil.parser import parse as dateparse

    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate as FXRate

    from .test_env import Mock

    ## Create a service that always returns the same FX rate:
    class DummyFXRateService(FXRateService):
        def __init__(self, rate: FXRate):
            self.rate = rate

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 != self.rate.ccy1 and ccy2 != self.rate.ccy2:
                return None
            if asof != self.rate.date:
                return None
            return self.rate


# Generated at 2022-06-24 01:23:00.119245
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    lu = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert isinstance(lu, LookupError)
    assert str(lu) == "Foreign exchange rate for EUR/USD not found as of " + str(datetime.date.today())
    assert lu.__dict__["ccy1"] == Currencies["EUR"]
    assert lu.__dict__["ccy2"] == Currencies["USD"]
    assert lu.__dict__["asof"] == datetime.date.today()


# Generated at 2022-06-24 01:23:07.665396
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import pytest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    with pytest.raises(TypeError) as e:
        nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
        rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
        assert ~nrate == rrate

    assert str(e.value) == "unsupported operand type(s) for ~: 'FXRate'"



# Generated at 2022-06-24 01:23:13.716151
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests method __invert__ of class FXRate.
    """
    from .commons.zeitgeist import Date
    from .currencies import EUR, USD
    rate = FXRate(EUR, USD, Date(2020, 1, 1), 2)
    rrate = FXRate(USD, EUR, Date(2020, 1, 1), 0.5)
    assert ~rate == rrate


# Generated at 2022-06-24 01:23:21.663960
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # The test rates
    rates = (
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5")),
        FXRate(Currencies["JPY"], Currencies["EUR"], datetime.date.today(), Decimal("0.01")),
    )

    # The test queries

# Generated at 2022-06-24 01:23:27.430138
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    from .currencies import Currency
    from .commons.zeitgeist import Date

    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date(2019, 1, 1)
    err = FXRateLookupError(ccy1, ccy2, asof)

    assert err.ccy1 == ccy1
    assert err.ccy2 == ccy2
    assert err.asof == asof


# Generated at 2022-06-24 01:23:34.056380
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass
        def queries(self, queries, strict=False):
            pass
    FXRateServiceImpl()  # noqa: E721

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 01:23:44.370301
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .market_data import MarketDataService
    from .temporal import Time

    ## Load spot FX rates:
    mds = MarketDataService()
    mds.load_fxm_file("C:/Users/levi/GitHub/pypara/data/fxm/fxm-eur-usd.csv")
    rates = mds.fx_rates(asof=Time(2019, 6, 21))

    ## Find a rate:
    assert rates.query(Currencies["EUR"], Currencies["USD"], asof=Time(2019, 6, 21)) == FXRate(Currencies["EUR"], Currencies["USD"], date=Time(2019, 6, 21), value=Decimal(1.1292))

    ## Lookup error is raised when strict mode is on:

# Generated at 2022-06-24 01:23:52.417546
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-24 01:24:02.835901
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 01:24:11.877383
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    print("\nTesting FXRateLookupError constructor")

    date = Date.current()

    try:
        raise FXRateLookupError(Currency.struct().ccy1, Currency.struct().ccy2, date)
    except FXRateLookupError as e:
        print(f"Exception: {e}")
        assert e.ccy1.code == Currency.struct().ccy1.code
        assert e.ccy2.code == Currency.struct().ccy2.code
        assert e.asof == date


# Generated at 2022-06-24 01:24:17.398728
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    
    from decimal import Decimal
    from pypara.currencies import Currencies
    
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    
    assert (
        ~nrate == rrate
    )


# Generated at 2022-06-24 01:24:26.517223
# Unit test for constructor of class FXRate
def test_FXRate():
    # Given
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    date = datetime.date.today()
    rate = FXRate(Currencies["EUR"], Currencies["USD"], date, Decimal("2"))
    ## Keep the properties:
    ccy1 = rate[0]
    ccy2 = rate[1]
    asof = rate[2]
    value = rate[3]

    # Then
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert asof == date
    assert value == Decimal("2")

# Generated at 2022-06-24 01:24:34.350262
# Unit test for constructor of class FXRateService
def test_FXRateService():
    #: Defines a foreign exchange rate service for unit tests.
    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    #: Define a test foreign exchange rate service:
    FXRateService.default = TestFXRateService()
    assert FXRateService.default is not None



# Generated at 2022-06-24 01:24:46.677434
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit-tests the constructor of class :class:`FXRateLookupError`.
    """
    from pypara.currencies import Currencies
    from pypara.zeitgeist import Date
    import datetime

    ## Make sure that required parameters are provided:
    try:
        FXRateLookupError()

    ## The exception type is correct:
    except TypeError as e:
        assert str(e) == "__init__() missing 3 required positional arguments: 'ccy1', 'ccy2', and 'asof'"

    ## Make sure that required parameters are of respective types:

# Generated at 2022-06-24 01:24:53.370238
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService
    """
    from unittest import mock

    service = mock.create_autospec(FXRateService)
    ccy1 = mock.create_autospec(Currency)
    ccy2 = mock.create_autospec(Currency)
    asof = mock.create_autospec(Date)
    assert service.query(ccy1, ccy2, asof) is None


# Generated at 2022-06-24 01:25:00.854372
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """ Tests the method __invert__ of class FXRate """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)

if __name__ == "__main__":
    import sys
    import doctest

    sys.exit(doctest.testmod(verbose=True)[0])

# Generated at 2022-06-24 01:25:05.176380
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-24 01:25:14.606844
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    ## Test
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(2007, 1, 1))
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == Date(2007, 1, 1)
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2007-01-01"


# Generated at 2022-06-24 01:25:15.481619
# Unit test for constructor of class FXRateService
def test_FXRateService():  # pragma: no cover
    assert FXRateService()

# Generated at 2022-06-24 01:25:26.023331
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Define the FX rate query:
    query = (Currencies["EUR"], Currencies["USD"], datetime.date.today())

    # Create a mocked FX rate service:
    class MockFXRateService(FXRateService):
        """
        Mocks FX rates for unit test.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            # If query is found, return the rate:

# Generated at 2022-06-24 01:25:27.664150
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-24 01:25:34.762708
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies

    class Test(unittest.TestCase):
        def setUp(self):
            pass

        def test_truth(self):
            rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            self.assertEqual(~rate, FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5")))

    unittest.main()


# Generated at 2022-06-24 01:25:44.279331
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class EUR_USD_FXRATE(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, Decimal("1"))
            elif ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))

# Generated at 2022-06-24 01:25:44.852062
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert True

# Generated at 2022-06-24 01:25:49.094679
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    This unit-test function covers the units of class :class:`FXRateService`.
    """
    ## Note that is an abstract class so we can not instantiate. The best we can do is to check that the class has the
    ## static consts and methods we expect:
    for prop in ["default", "query", "queries"]:
        assert hasattr(FXRateService, prop)



# Generated at 2022-06-24 01:25:55.611667
# Unit test for constructor of class FXRateService
def test_FXRateService():
    doc = getattr(FXRateService, "__init__", None).__doc__
    assert doc is not None, "FXRateService's constructor has no docstring"
    assert doc.find("FXRateService") != -1, "FXRateService's constructor docstring must mention FXRateService"
    assert doc.find("Abstract") != -1, "FXRateService's constructor docstring must mention Abstract"
    assert doc.find("Class") != -1, "FXRateService's constructor docstring must mention Class"


# Generated at 2022-06-24 01:26:03.142302
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency

    ## Works fine:
    try:
        raise FXRateLookupError(Currency.parse("EUR"), Currency.parse("USD"), Date.today())
    except LookupError as e:
        assert "Foreign exchange rate for EUR/USD not found as of 2017-09-12" in str(e)


# Generated at 2022-06-24 01:26:09.614179
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currency
    from .currencies import EUR, USD
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    from decimal import Decimal
    import datetime

    nrate = FXRate(cur1=Currencies["EUR"], cur2=Currencies["USD"], date=datetime.date.today(), value=Decimal("2"))
    rrate = FXRate(cur1=Currencies["USD"], cur2=Currencies["EUR"], date=datetime.date.today(), value=Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-24 01:26:21.972297
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("1.25"))
            else:
                return None


# Generated at 2022-06-24 01:26:34.034064
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.utils.temporal import TODAY

    class MockedFXRateService(FXRateService):
        """
        Provides a mocked implementation of FX rate service.
        """


# Generated at 2022-06-24 01:26:37.367026
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():  # noqa: E128
    """
    Tests inversion of the foreign exchange rate.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate
# EOF

# Generated at 2022-06-24 01:26:38.672241
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # !!!
    raise NotImplementedError("Test not implemented.")

# Generated at 2022-06-24 01:26:47.400406
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class _Test(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.25"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for q in queries:
                yield self.query(q[0], q[1], q[2])


# Generated at 2022-06-24 01:26:56.943107
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert isinstance(nrate.ccy1, Currency)
    assert nrate.ccy1 == Currencies["EUR"]
    assert nrate.ccy2 == Currencies["USD"]
    assert nrate.date == datetime.date.today()
    assert nrate.value == Decimal("2")

    urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    srate = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert srate == ur

# Generated at 2022-06-24 01:27:04.979624
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    ## Use an anonymous dummy FX rate service class:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal('1')) if ccy1 == ccy2 else None
        def queries(self, queries, strict=False):
            return map(self.query, zip(*queries))
    ## Use the dummy FX rate service:
    dummy = DummyFXRateService()

# Generated at 2022-06-24 01:27:10.609662
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import EUR, USD
    from .temporal import Date
    from .fx import FXRate

    assert FXRate(EUR, USD, Date.of(2014, 1, 2), Decimal("1.0")) == (EUR, USD, Date.of(2014, 1, 2), Decimal("1.0"))



# Generated at 2022-06-24 01:27:11.253443
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-24 01:27:18.219468
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests :method:`FXRate.__invert__` method of class :class:`FXRate`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (nrate.__invert__() == rrate)


# Generated at 2022-06-24 01:27:25.006604
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .services import ScaledRate
    from .temporals import Temporals
    import datetime
    from decimal import Decimal
    from unittest import TestCase, main

    class TestCase(TestCase):
        """
        Defines unit tests for the method query of class :class:`FXRateService`.
        """

        def test_query(self):
            from pypara.services.fx_rate_service import ScaledRateService

            service = ScaledRateService(ScaledRate(cur=Currencies["USD"], date=datetime.date(2018, 1, 1), value=Decimal(1)))

            self.assertIsNone(service.query(Currencies["USD"], Currencies["EUR"], datetime.date(2017, 1, 1)))

# Generated at 2022-06-24 01:27:32.155060
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():  # noqa: D103
    import pytest  # noqa: F401
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    ## Check the error message:
    with pytest.raises(FXRateLookupError):
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())



# Generated at 2022-06-24 01:27:37.691469
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert(ccy1 == Currencies["EUR"])
    assert(ccy2 == Currencies["USD"])
    assert(date == datetime.date.today())
    assert(value == Decimal("2"))



# Generated at 2022-06-24 01:27:49.642972
# Unit test for method queries of class FXRateService

# Generated at 2022-06-24 01:27:57.453461
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporals import Temporals

    # Given
    class MockRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == Temporals.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None

        def queries(self, queries, strict):
            for q in queries:
                yield self.query(q[0], q[1], q[2], strict)

    # When:
    query1 = Currencies["USD"], Currencies["EUR"], Temporals.today()
    query2 = Currencies["EUR"], Currencies["USD"],

# Generated at 2022-06-24 01:27:58.540068
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert False


# Generated at 2022-06-24 01:28:10.722022
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): # noqa: D301
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Temporal

    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of FX rate service.
        """

        def __init__(self):
            self.rates = {
                (Currencies["USD"], Currencies["CAD"], datetime.date(2020, 7, 1)): Decimal("6"),
            }

        def query(self, ccy1, ccy2, asof, strict=False):
            try:
                return self.rates[(ccy1, ccy2, asof)]
            except KeyError:
                pass
            return None


# Generated at 2022-06-24 01:28:15.845663
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    This unit test checks attempts to create instances of :class:`FXRateService`.
    """
    ## Attempt to create an :class:`FXRateService` instance:
    try:
        FXRateService()
    except TypeError:
        pass
    else:
        raise RuntimeError("Creation of :class:`FXRateService` is not allowed.")



# Generated at 2022-06-24 01:28:28.056760
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates.naive_in_memory import NaiveInMemoryFXRateService

    ## Create a service instance:
    service = NaiveInMemoryFXRateService()

    ## Create FX rate queries:
    queries = [
        (Currencies["USD"], Currencies["EUR"], Temporal.of_now()),
        (Currencies["USD"], Currencies["EUR"], Temporal.of(2020, 1, 1))
    ]

    ## Make FX rate queries:
    results = service.queries(queries, strict=False)

    ## Assert results:
    rate = next(results)
    assert rate.ccy1 == Currencies["USD"]
    assert rate.ccy2 == Currencies["EUR"]