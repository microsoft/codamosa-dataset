

# Generated at 2022-06-21 20:22:11.740684
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    # noinspection PyUnresolvedReferences
    from pypara.services import FXRateServices

    ## Test the default FX rate service:
    FXRateServices.default = None
    assert FXRateServices.default is None
    try:
        ## Try to query an FX rate:
        FXRateServices.query(Currency.USD, Currency.EUR, Date.today())
    except FXRateLookupError:
        pass
    except:  # noqa: E722
        assert False, "Unexpected exception was raised."

    ## Test the default FX rate service:
    FXRateServices.default = FXRateServices.fake
    assert FXRateServices.default is FXRateServices.fake

# Generated at 2022-06-21 20:22:18.978805
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:22:29.680474
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    import unittest

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies
    from pypara.services.fxrate import FXRateService

    class FXRateServiceStub(FXRateService):
        """
        Provides a stub implementation of interface FXRateService.
        """


# Generated at 2022-06-21 20:22:39.656511
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create a normal FX rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Create the rate that should be returned:
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    ## Invert the rate:
    irate = ~nrate

    ## Check if they are the same:
    assert irate == rrate

# Generated at 2022-06-21 20:22:47.077973
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    # Create a direct FX rate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    # Invert the rate
    rrate = ~nrate

    # Should have inverted FX rate
    assert rrate.ccy1 == Currencies["USD"]
    assert rrate.ccy2 == Currencies["EUR"]
    assert rrate.date == datetime.date.today()
    assert rrate.value == Decimal("0.5")



# Generated at 2022-06-21 20:22:58.240553
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Construct an instance:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Check properties:
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")

    ## Check inversion:
    irate = ~rate
    assert irate[0] == Currencies["USD"]
    assert irate[1] == Currencies["EUR"]
    assert irate[2] == datetime.date.today()
    assert irate[3] == Decimal("0.5")

#

# Generated at 2022-06-21 20:23:05.024420
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class :class:`FXRateService`.
    """
    from abc import ABC
    from pypara.commons import HasConstructorTests
    from pytest import raises
    from typing import Type

    ##
    ## FXRateService is an abstract base class (ABC):
    ##
    assert issubclass(FXRateService, ABC)

    ##
    ## FXRateService is a HasConstructorTests:
    ##
    assert issubclass(FXRateService, HasConstructorTests)

    ##
    ##  FXRateService has an abstract method called `query`, and
    ##  FXRateService has an abstract method called `queries`,
    ##
    assert FXRateService.query.__isabstractmethod__
    assert FXRateService.queries.__isabstractmethod__

    ##
   

# Generated at 2022-06-21 20:23:18.139086
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currencies
    from pypara.fx import FXRate

    # Initialize the attributes of the FXRate instances:
    currency1 = Currency(code='EUR')
    currency2 = Currency(code='USD')
    date = Date(year=2019, month=1, day=1)
    rate = Decimal(value=2.0)

    # Instantiate the object:
    fxRate = FXRate(currency1, currency2, date, rate)

    # Check the object:
    assert fxRate.ccy1 == currency1
    assert fxRate.ccy2 == currency2
    assert fxRate.date == date

# Generated at 2022-06-21 20:23:25.337547
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date
    fxrate = FXRate(Currencies["USD"], Currencies["EUR"], Date.today(), Decimal(2))
    assert fxrate.__invert__() == FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("0.5"))

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 20:23:33.029064
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates import FXRateService, FXRateLookupError

    # Unit test for method query of class FXRateService
    class DefaultFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-21 20:23:43.913157
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .commons.zeitgeist import Date
    from .currencies import Currency
    e = FXRateLookupError(Currency("EUR"), Currency("USD"), Date(2018, 3, 15))
    assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2018-03-15"
    assert e.args == ("Foreign exchange rate for EUR/USD not found as of 2018-03-15",)
    assert e.ccy1 == Currency("EUR")
    assert e.ccy2 == Currency("USD")


# Generated at 2022-06-21 20:23:51.845630
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .config import config
    from .commons.numbers import ZERO
    fx_rate_service = config.get("fx_rate_service")
    ret = fx_rate_service.queries([(Currencies["EUR"], Currencies["USD"], Date(2020,1,1)),
                                   (Currencies["USD"], Currencies["EUR"], Date(2020,2,1))])
    assert ret == [ZERO, ZERO]

# Generated at 2022-06-21 20:24:00.298861
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .zeitgeist import Date
    import datetime

    EUR = Currencies["EUR"]
    USD = Currencies["USD"]
    GBP = Currencies["GBP"]
    TRY = Currencies["TRY"]

    TODAY = Date(datetime.date.today())

    class StubFXRateService(FXRateService):
        """
        Provides a stub FX rate serivce for testing.
        """

        #: Defines exchange rates for testing.
        RATES = [(EUR, USD, TODAY, Decimal("1.2")), (USD, EUR, TODAY, Decimal("0.8")), (TRY, EUR, TODAY, Decimal("0.0"))]


# Generated at 2022-06-21 20:24:10.436487
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D103
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    class MockService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            from .fxrates import FXRate
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date("2020-01-01"):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date("2020-01-01"), Decimal("1.23"))
            else:
                return None

    class Test(unittest.TestCase):
        def test_query(self):
            service = MockService

# Generated at 2022-06-21 20:24:16.065759
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import DATE
    rate = FXRate(Currencies["EUR"], Currencies["USD"], DATE.date, Decimal(2))
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], DATE.date, Decimal(.5))


# Generated at 2022-06-21 20:24:22.956265
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:30.413932
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:24:35.914142
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    ## Test initialization
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.current())
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2017-11-03"



# Generated at 2022-06-21 20:24:42.332837
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase, main
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal

    class FXRateServiceTester(TestCase):

        def test_default_fx_rate_service(self):
            """
            Tests the the :member:`FXRateService.default` member.
            """
            ## Initial default foreign exchange rate service must be None:
            self.assertIsNone(FXRateService.default)

            ## Get the default foreign exchange rate service:
            FXRateService.default = AlwaysFXRateService()

            ## Default service must be retrieved:
            self.assertIsInstance(FXRateService.default, FXRateService)

            ## Default service must be reset:
            FXRateService.default = None


# Generated at 2022-06-21 20:24:52.925145
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """

    # The method under test:
    from .fxt import FXTRateService

    # The query and fixtures:
    queries = [
        (Currency("EUR"), Currency("USD"), Date(2018, 1, 1)),
        (Currency("USD"), Currency("GBP"), Date(2018, 1, 1)),
        (Currency("USD"), Currency("GBP"), Date(2018, 2, 1)),
    ]

    # The test:
    fxt = FXTRateService()
    results = fxt.queries(queries)
    rate1, rate2, rate3 = results

    # Validate the results:
    assert rate1.ccy1 == Currency("EUR")
    assert rate1.ccy2 == Currency("USD")

# Generated at 2022-06-21 20:25:05.673313
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ccy1 = Currency("USD")
    ccy2 = Currency("EUR")
    asof = Date("2018-06-01")
    error = FXRateLookupError(ccy1, ccy2, asof)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert str(error) == "Foreign exchange rate for USD/EUR not found as of 2018-06-01"


# Generated at 2022-06-21 20:25:11.070951
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency

    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")

    date = Date(2019, 3, 1)

    err = FXRateLookupError(ccy1, ccy2, date)

    assert err.ccy1 == ccy1
    assert err.ccy2 == ccy2
    assert err.asof == date
    assert err.args[0] == "Foreign exchange rate for EUR/USD not found as of 2019-03-01"



# Generated at 2022-06-21 20:25:17.892860
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:25:27.340834
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Test that the stub implementation just raises an exception.
    FXRateService.default = None
    try:
        FXRateService.default.query(None, None, None)
        # If we reach this point, there is something wrong.
        assert False
    except RuntimeError:
        pass

    # Test with a mock implementation.
    class Mock(FXRateService):
        # noinspection PyUnusedLocal
        def query(self, ccy1, ccy2, asof, strict=False):
            pass

        def queries(self, queries, strict=False):
            pass

    FXRateService.default = Mock()
    FXRateService.default.query(None, None, None)

# Generated at 2022-06-21 20:25:37.526717
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of :class:`FXRateService`.
    """

    class __FXRateService__(FXRateService):
        """
        Provides a sample FX rate service implementation.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            else:
                return FXRate(ccy1, ccy2, asof, Decimal("1.5"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield self.query(*query, strict=strict)

   

# Generated at 2022-06-21 20:25:48.430465
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.exceptions import CurrencyLookupError
    from pypara.exchanges.errors import FXRateLookupError

    #: A sample FX rate service implementation.
    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-21 20:25:54.407817
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:26:05.661841
# Unit test for constructor of class FXRate
def test_FXRate():
    from pypara.tests.utils.aaa import should_raise
    from .currencies import system
    from .commons.temporals import Date
    from .commons.numbers import ONE

    # Test FXRate constructor so that it throws an error if its arguments are not of the correct type:
    for ccy1, ccy2, date, value in (
        (system["EUR"], system["USD"], Date.today(), ONE),
        (system["EUR"], system["USD"], Date.today(), ONE),
        (system["EUR"], system["USD"], Date.today(), ONE),
        (system["EUR"], system["USD"], Date.today(), ONE),
    ):
        rate = FXRate(ccy1, ccy2, date, value)
        assert isinstance(rate, FXRate)

    # Test FXRate factory (class

# Generated at 2022-06-21 20:26:07.399951
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass



# Generated at 2022-06-21 20:26:15.809015
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## Import:
    from unittest import TestCase, main
    from unittest.mock import MagicMock

    ## Unittest:
    class FXRateServiceTestCase(TestCase):
        def setUp(self):
            self.fx_service = MagicMock(spec=FXRateService)

        def test_with_a_base_currency(self):
            pass

        def test_with_a_quote_currency(self):
            pass

    ## Execute:
    main()

# Generated at 2022-06-21 20:26:27.395032
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:26:28.070579
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-21 20:26:31.945184
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class Test:
        pass

    assert issubclass(Test, FXRateService)
    assert FXRateService.default is None
    assert FXRateService.TQuery == Tuple[Currency, Currency, Date]


# Generated at 2022-06-21 20:26:35.371163
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Date
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date())
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 1970-01-01"


# Generated at 2022-06-21 20:26:41.830379
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of :class:`FXRateService`.
    """
    from .currencies import Currency
    from .temporals import Temporals

    # noinspection PyUnusedLocal
    class MockRateService(FXRateService):

        # noinspection PyMethodMayBeStatic
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict)

    ## Check the strict case:
    srs = MockRateService()

# Generated at 2022-06-21 20:26:51.883490
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MockFXRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            return None


# Generated at 2022-06-21 20:26:52.561023
# Unit test for constructor of class FXRateService
def test_FXRateService():  assert True

# Generated at 2022-06-21 20:26:59.042461
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    import datetime
    asof = datetime.date.today()
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], asof)
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == asof
    assert error.args[0] == f"Foreign exchange rate for EUR/USD not found as of {asof}"


# Generated at 2022-06-21 20:27:10.630157
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert(rate[0] == Currencies["EUR"])
    assert(rate[1] == Currencies["USD"])
    assert(rate[2] == datetime.date.today())
    assert(rate[3] == Decimal("2"))

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert(~nrate == rrate)

# Generated at 2022-06-21 20:27:15.468881
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .commons.zeitgeist import Date
    from .currencies import Currency
    from .currency_rates import FXRateLookupError
    from datetime import date

    ## Assert the error message contains currencies and date:
    err = FXRateLookupError(Currency("EUR"), Currency("USD"), Date(date(2019, 1, 1)))
    assert str(err) == "Foreign exchange rate for EUR/USD not found as of 2019-01-01"


# Generated at 2022-06-21 20:27:37.037332
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx_rates import FXRateService, FXRateLookupError

    class MyFxRateService(FXRateService):  # noqa: WPS214

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if not ccy1 or not ccy2:
                return None
            return FXRate(ccy1, ccy2, asof, Decimal("1.2"))


# Generated at 2022-06-21 20:27:46.667911
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of the :class:`FXRateLookupError` class.
    """
    from .currencies import Currency

    ## Test input:
    date = "2017-01-01"
    ccy1 = Currency("EUR", "EUR")
    ccy2 = Currency("USD", "USD")

    ## Construct:
    error = FXRateLookupError(ccy1, ccy2, date)

    ## Assert:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == date
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2017-01-01"


# Generated at 2022-06-21 20:27:51.342570
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    return rate[0] == Currencies["EUR"] and \
           rate[1] == Currencies["USD"] and \
           rate[2] == datetime.date.today() and \
           rate[3] == Decimal("2")


# Generated at 2022-06-21 20:28:02.793293
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import unittest, tempfile
    from decimal import Decimal
    from .currencies import Currency
    from .temporal import Date

    class FXRateTestCase(unittest.TestCase):
        def setUp(self):
            self.ccy1, self.ccy2, self.date, self.value = Currency.of("USD"), Currency.of("EUR"), Date.of("2018-01-01"), Decimal("0.5")
            self.rate = FXRate(self.ccy1, self.ccy2, self.date, self.value)

        def test_invert(self):
            rate = self.rate
            assert rate.ccy1 == self.ccy1
            assert rate.ccy2 == self.ccy2
            assert rate.date == self.date

# Generated at 2022-06-21 20:28:06.740889
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import unittest

    class FXRateServiceTests(unittest.TestCase):
        def test_instantiation(self):
            with self.assertRaises(TypeError):
                FXRateService()

    unittest.main()

# Generated at 2022-06-21 20:28:18.299460
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .commons.zeitgeist import Date
    from .currencies import Currency, Currencies
    from .storages.dicts import DictFXRateService
    from datetime import date
    from decimal import Decimal
    from itertools import permutations

    ## Create an FX rate service:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = Date(date(2017, 4, 1))
    rate = Decimal("2")
    fx_rates = {
        (ccy1, ccy2, date): rate,
        (ccy2, ccy1, date): rate ** -1,
    }
    svc = DictFXRateService(fx_rates)

    ## Query for common queries:

# Generated at 2022-06-21 20:28:30.818794
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .commons.zeitgeist import Date

    class DemoFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (self.query(ccy1, ccy2, asof) for ccy1, ccy2, asof in queries)

    srv = DemoFXRateService()

# Generated at 2022-06-21 20:28:39.221902
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert not FXRateService.default.query(Currency.of("XXX"), Currency.of("YYY"), Date.of("2019-04-24")) is None
    assert FXRateService.default.query(Currency.of("XXX"), Currency.of("YYY"), Date.of("9999-12-31")) is None
    assert FXRateService.default.query(Currency.of("XXX"), Currency.of("YYY"), Date.of("2019-04-24"), strict=True) is not None
    # assert FXRateService.default.query(Currency.of("XXX"), Currency.of("YYY"), Date.of("9999-12-31"), strict=True) is not None
    return None


# Generated at 2022-06-21 20:28:42.325543
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .commons.temporal import Date

    # Should initialize correctly...
    err = FXRateLookupError(Currency.EUR, Currency.USD, Date.today())

    assert err.ccy1 == Currency.EUR
    assert err.ccy2 == Currency.USD
    assert err.asof == Date.today()


# Generated at 2022-06-21 20:28:43.270157
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """ Tests the constructor of class FXRateService """
    pass

# Generated at 2022-06-21 20:29:14.140437
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from unittest import mock
    from pypara.currencies import Currencies
    from datetime import date

    #
    # Test `query` method of `FXRateService` class
    #

    class TestRate(FXRate):
        value: Decimal
        @classmethod
        def of(cls, ccy1: Currency, ccy2: Currency, date: Date, value: Decimal) -> "TestRate":
            return cls(ccy1, ccy2, date, value)

    class TestRateService(FXRateService):
        store: Iterable[TestRate]

# Generated at 2022-06-21 20:29:19.761715
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """Unit test for constructor of class FXRateLookupError."""
    from .currencies import EUR, USD
    from .commons.zeitgeist import today
    ## Create an FX rate lookup error:
    err = FXRateLookupError(EUR, USD, today())
    ## Check:
    assert err.ccy1 == EUR
    assert err.ccy2 == USD
    assert err.asof == today()


# Generated at 2022-06-21 20:29:26.998776
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.
    """
    # pylint: disable=C0103
    from pypara.currencies import Currency
    from pypara.commons.zeitgeist import Date
    from pypara.fx import FXRateLookupError

    error = FXRateLookupError(Currency("EUR"), Currency("USD"), Date(2020, 1, 1))

    assert error.ccy1 == Currency("EUR")
    assert error.ccy2 == Currency("USD")
    assert error.asof == Date(2020, 1, 1)
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2020-01-01"



# Generated at 2022-06-21 20:29:33.734113
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert(~nrate == rrate)



# Generated at 2022-06-21 20:29:43.451793
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the construction of :class:`FXRateService`.
    """
    class FXRateServiceImpl(FXRateService):
        """
        Provides a dummy implementation class for FXRateService
        """


# Generated at 2022-06-21 20:29:55.448009
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the functionality of the method queries of the class FXRateService.
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService

    ## Create a mock FX rate service:
    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False):
            ## Validate the arguments:
            if not queries:
                return []

            ## Iterate over the queries:

# Generated at 2022-06-21 20:30:00.978773
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-21 20:30:14.279138
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.commons.iteration import izip
    from .currencies import Currencies

    class FRS(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, queries, strict=False):
            return iter(izip(queries, (query[0] * query[1] for query in queries)))

    cls = FRS()

    rates = cls.queries([
        (Currencies["EUR"], Currencies["USD"], Date.now()),
        (Currencies["USD"], Currencies["EUR"], Date.now()),
    ])

    assert len(rates) == 2
    for rate in rates:
        assert rate is not None
        assert rate[0] is not None

# Generated at 2022-06-21 20:30:20.191247
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    ccy1 == Currencies["EUR"]
    ccy2 == Currencies["USD"]
    date == datetime.date.today()
    value == Decimal("2")


# Generated at 2022-06-21 20:30:32.011679
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.services import FXRateService, FXRateTable

    class TestFXRateService(FXRateService):
        def __init__(self, table: FXRateTable):
            self._table = table

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return self._table.query(ccy1, ccy2, asof, strict)

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return self._table.queries(queries, strict)

    ## Create the test FX rate table:
    table = FX

# Generated at 2022-06-21 20:31:24.598768
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import today
    from pypara.finance.fxrates import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal(2))

    service = MockFXRateService()
    queries = ((Currencies["EUR"], Currencies["USD"], today()),)
    rates = service.queries(queries)
    assert next(rates) == FXRate.of(Currencies["EUR"], Currencies["USD"], today(), Decimal(2))

# Generated at 2022-06-21 20:31:32.181856
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## Import:
    import datetime
    from pypara.currencies import Currency, Currencies

    ## Create an instance of FXRateLookupError:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as error:
        assert isinstance(error, LookupError)
        assert isinstance(error, BaseException)
        assert isinstance(error.ccy1, Currency)
        assert isinstance(error.ccy2, Currency)
        assert isinstance(error.asof, datetime.date)


# Generated at 2022-06-21 20:31:35.137200
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))


# Generated at 2022-06-21 20:31:42.350817
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:31:47.248409
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate

# Generated at 2022-06-21 20:31:49.314557
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, ABCMeta)



# Generated at 2022-06-21 20:31:55.018446
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.datetime import DateTime, Day
    from pypara.fx import FXRateService
    from pypara.util.streams import LazyIterable

    # Define a foreign exchange rate service to be tested:

# Generated at 2022-06-21 20:32:05.850221
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.test import TestCase

    class FXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    testcase = TestCase("Unit test for abstract class FXRateService.")

    fxrs = FXRateService()
    testcase.assertIsNotNone(fxrs)
    testcase.assertIsNotNone(fxrs.query("XXX", "YYY", Date(2000, 1, 1)))
    testcase.assertIsNotNone(fxrs.queries([]))
