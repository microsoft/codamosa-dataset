

# Generated at 2022-06-21 20:22:12.847716
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the FX rate service.
    """

    ## Not implemented:
    class MyFXRateService(FXRateService):
        """
        Provides a dummy implementation of FX rate service.
        """

        pass

    MyFXRateService()



# Generated at 2022-06-21 20:22:18.778628
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:27.270313
# Unit test for constructor of class FXRateService
def test_FXRateService():


    class FXRateService(object):

        def query(self, ccy1, ccy2, asof):
            return FXRate(ccy1, ccy2, asof, Decimal("1.2"))


    ## Perform the test:
    result = FXRateService().query(Currencies["EUR"], Currencies["USD"], Date.now())

    ## Check the result:
    assert result.ccy1 == Currencies["EUR"]
    assert result.ccy2 == Currencies["USD"]
    assert result.value == Decimal("1.2")
    assert result.date == Date.now()

# Generated at 2022-06-21 20:22:34.427671
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Setup:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    class StubFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today() \
                    and strict is False:
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            return None

# Generated at 2022-06-21 20:22:42.233493
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(2000, 12, 31))
    except FXRateLookupError as ex:
        assert ex.ccy1 == Currencies["EUR"]
        assert ex.ccy2 == Currencies["USD"]
        assert str(ex.asof) == "2000-12-31"
        assert str(ex) == "Foreign exchange rate for EUR/USD not found as of 2000-12-31"


# Generated at 2022-06-21 20:22:48.685480
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies['EUR'], Currencies['USD'], datetime.date.today(), Decimal('2'))
    rrate = FXRate(Currencies['USD'], Currencies['EUR'], datetime.date.today(), Decimal('0.5'))
    print(~nrate, rrate)
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:22:59.387708
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    print("test_FXRateService_queries")

    from .currencies import Currencies

    from .fixtures.fxrateservice import MockFXRateService

    # Create the fixture service:
    service = MockFXRateService()

    # Create sample queries:
    queries = [
        (Currencies["EUR"], Currencies["USD"], Date.today()),
        (Currencies["USD"], Currencies["EUR"], Date.today().add_days(1)),
        (Currencies["GBP"], Currencies["USD"], Date.today().add_days(2)),
        (Currencies["USD"], Currencies["GBP"], Date.today().add_days(3))
    ]

    # Do the actual conversion:
    rates = service.queries(queries)

    # Check the results:

# Generated at 2022-06-21 20:23:05.678210
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method :method:`FXRateService.queries`.
    """
    from .currencies import Currencies as C

    ## Simple FX rate service providing EUR/USD and USD/EUR as of today:
    class SimpleFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == C("EUR") and ccy2 == C("USD") and asof == fxd:
                return FXRate(C("EUR"), C("USD"), fxd, Decimal("1.5"))
            elif ccy1 == C("USD") and ccy2 == C("EUR") and asof == fxd:
                return FXRate(C("USD"), C("EUR"), fxd, Decimal("0.667"))

# Generated at 2022-06-21 20:23:13.167187
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    import decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), decimal.Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), decimal.Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:23:19.613221
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .curves import Curve, CurveService
    import datetime

    ## Create the curve:
    ccy = Currencies["USD"]
    date = datetime.date.today()
    curve = Curve(ccy, date, CurveService.default)

    rate = curve.fxrate(Currencies["EUR"])
    assert rate.value == Decimal("1.0838")



# Generated at 2022-06-21 20:23:30.657943
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # ARRANGE
    from test.context import FXRateService1
    from pypara.currencies import Currencies
    from pypara.commons import Temporal

    # ACT
    serv = FXRateService1(lambda a, b, c: "ABC", True)
    q = [(Currencies.EUR, Currencies.USD, Temporal.DATE1),
         (Currencies.EUR, Currencies.USD, Temporal.DATE2)]
    res: Iterable[Optional[FXRate]] = serv.queries(q)

    # ASSERT
    assert res == ["ABC", "ABC"]

# Generated at 2022-06-21 20:23:38.382625
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:23:47.082290
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    # Import standard library modules:
    import datetime
    from decimal import Decimal
    from typing import List

    # Import test helpers:
    from pypara.commons.testing import assert_is_instance

    # Import from package:
    from pypara.currencies import Currencies
    from pypara.fx import FXRate

    # Create helper instances:
    class Service(FXRateService):
        """
        Provides the implementation of the abstract class :class:`FXRateService`.
        """


# Generated at 2022-06-21 20:23:58.115185
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currencies

    ## Get the FX rate service:
    service = FXRateService.default
    if not service:
        raise RuntimeError("No default FX rate service found.")

    ## Test a query with known currencies:
    try:
        rate1 = service.query(Currencies["EUR"], Currencies["USD"], Date.today(), True)
        assert isinstance(rate1, FXRate)
        assert rate1[0] == Currencies["EUR"]
        assert rate1[1] == Currencies["USD"]
        assert rate1[2] == Date.today()
        assert rate1[3] > ZERO
    except FXRateLookupError:
        pass

    ## Test an unknown query:
    rate2 = service.query(Currencies["EUR"], Currencies["XXX"], Date.today(), True)

# Generated at 2022-06-21 20:24:05.968013
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import EUR, USD
    from .zeitgeist import Date as ZDate
    from .fx import FXRateService, FXRateLookupError
    from .sources import Sources

    ## Query a single FX rate:
    rate = FXRateService.default.query(EUR, USD, ZDate(2017, 6, 22))
    assert rate.value == 1.1292

    ## Query a collection of FX rates:
    rates = list(FXRateService.default.queries([(EUR, USD, ZDate(2017, 6, 22))]))
    assert rates[0].value == 1.1292

    ## Query a collection of FX rates with strict mode:

# Generated at 2022-06-21 20:24:10.948391
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    class ConcreteFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass
        
        def queries(self, queries, strict=False):
            for query in queries:
                yield query

    assert ConcreteFXRateService().queries([(1, 2, 3)]) is not None

# Generated at 2022-06-21 20:24:19.657849
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from decimal import Decimal
    import datetime
    from .forex.fixer import Fixer, FixerError
    from pypara.forex.oanda import Oanda, OandaError

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.datetime.now()
    strict = False

    for service in (Fixer, FixerError, Oanda, OandaError):
        if service == Fixer:
            service.default.query(ccy1, ccy2, asof, strict)
        elif service == FixerError:
            try:
                service.default.query(ccy1, ccy2, asof, strict)
            except FXRateLookupError as lookup_error:
                assert lookup_error

# Generated at 2022-06-21 20:24:25.631485
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-21 20:24:34.576833
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date as d

    try:
        ## Query a non-existent foreign exchange rate:
        FXRateService.default.query(Currencies["EUR"], Currencies["USD"], d("2000-01-01"), strict=True)
    except FXRateLookupError as error:
        assert error.ccy1 == Currencies["EUR"]
        assert error.ccy2 == Currencies["USD"]
        assert error.asof == d("2000-01-01")
    else:
        raise Exception("Test failed!")


# Generated at 2022-06-21 20:24:41.656777
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the construction of :class:`FXRateLookupError` class.
    """
    from .currencies import Currency
    from .commons.zeitgeist import Date

    ## Initialize the currency instances:
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date.today()

    ## Initialize the FXRateLookupError instance:
    error = FXRateLookupError(ccy1, ccy2, asof)

    ## Check if the slots are correctly set:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof

    ## Check the error message:

# Generated at 2022-06-21 20:24:54.193029
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:25:06.840618
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    ## basic usage:
    # ------------

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate) is True

    ## other properties:
    # -----------------

    #: Other properties are not affected:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

# Generated at 2022-06-21 20:25:15.057539
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:25:23.060956
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:25:33.544300
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRate, FXRateService

    ## Create the test FX rate service:
    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof.date, Decimal(1))
            else:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof.date)
                else:
                    return None

        def queries(self, queries, strict=False):
            return (self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries)

    ##

# Generated at 2022-06-21 20:25:43.845907
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    # Imports
    import datetime

    # Imports
    from pypara.currencies import Currencies

    # A foreign exchange rate lookup error
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    # Check class
    assert(error.__class__.__name__ == "FXRateLookupError")

    # Check properties
    assert(error.ccy1 == Currencies["EUR"])
    assert(error.ccy2 == Currencies["USD"])
    assert(error.asof == datetime.date.today())

    # Check string representation
    assert(str(error) == "Foreign exchange rate for EUR/USD not found as of " + str(datetime.date.today()))



# Generated at 2022-06-21 20:25:54.865461
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService.
    """
    class TestService(FXRateService):
        """
        Dummy test service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Dummy implementation of `FXRateService.query` method.
            """
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Dummy implementation of `FXRateService.queries` method.
            """
            pass

    ## Construct the service:
    service = TestService()

    ## Check the type of this instance:
    assert isinstance(service, FXRateService)

# Generated at 2022-06-21 20:26:02.537564
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert urate[0] == Currencies["EUR"]
    assert urate[1] == Currencies["USD"]
    assert urate[2] == datetime.date.today()
    assert urate[3] == Decimal("2")

# Generated at 2022-06-21 20:26:07.613403
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .commons.zeitgeist import today
    from decimal import Decimal
    rate = FXRate(Currencies["EUR"], Currencies["USD"], today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:26:19.532364
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import pytest
    from pypara.commons.zeitgeist import Date

    from .currencies import Currency

    # Test Default FXRateService:
    with pytest.raises(TypeError):
        # default service has not been implemented yet:
        FXRateService.default.query(Currency.USD, Currency.EUR, Date(2017, 1, 1))

    # Test query():
    with pytest.raises(NotImplementedError):
        # default service has not been implemented yet:
        FXRateService.default.query(Currency.USD, Currency.EUR, Date(2017, 1, 1))

    # Test queries():

# Generated at 2022-06-21 20:26:40.501013
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    import itertools
    import unittest
    from pypara.commons.numbers import ONE, ZERO
    from pypara.currencies import Currency, Currencies
    from pypara.fx.rateservice import FXRate, FXRateService

    class MockFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date) -> Optional[FXRate]:
            for rate in self.rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate

            return None


# Generated at 2022-06-21 20:26:47.298848
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-21 20:26:55.673146
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import DateTime
    from .fx import FXRateService
    class MockedService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: DateTime, strict=False):
            return None

        def queries(self, queries: Iterable[Tuple[Currency, Currency, DateTime]], strict=False) -> Iterable[Optional[FXRate]]:
            return None

    assert MockedService().queries([]) == []

# Generated at 2022-06-21 20:26:59.074506
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert(urate[3] == Decimal("2"))


# Generated at 2022-06-21 20:27:11.037003
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Check the constructor:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    # Check indexed access:
    assert nrate[0] == Currencies["EUR"]
    assert nrate[1] == Currencies["USD"]
    assert nrate[2] == datetime.date.today()
    assert nrate[3] == Decimal("2")
    # Check named access:
    assert nrate.ccy1 == Currencies["EUR"]
    assert nrate.ccy2 == Currencies["USD"]
    assert nrate.date == datetime.date.today()
    assert nrate.value == Decimal("2")



# Generated at 2022-06-21 20:27:18.205937
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the :class:`FXRateService` class.
    """
    ## Mock FX rate service class:
    class FXRateServiceMock(FXRateService):
        """
        Provides a mock class for FX rate service.
        """
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            return None

    ## Check the validator:
    service = FXRateServiceM

# Generated at 2022-06-21 20:27:19.671631
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, (object,))


# Generated at 2022-06-21 20:27:28.318727
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    from pypara.currencies import Currencies, Currency
    from pypara.curves import Dates
    from pypara.services.fxrates import TestFxRateService

    fxrservice = TestFxRateService()
    assert fxrservice is not None
    fxr = fxrservice.query(Currencies["EUR"], Currencies["USD"], Dates.today())
    assert fxr == FXRate(Currencies["EUR"], Currencies["USD"], Dates.today(), Decimal("1.098"))


# Generated at 2022-06-21 20:27:30.667865
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of the FXRateService class.
    """
    pass



# Generated at 2022-06-21 20:27:38.677403
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    #pylint: disable=too-few-public-methods
    from .commons.zeitgeist import Date, Dates
    from .currencies import Currency
    from .markets import FXMarket

    class FXRateServiceMock(FXRateService):
        """
        Provides a mock implementation of foreign exchange rate service.
        """

        def query(
                self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False
        ) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-21 20:28:08.586499
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, metaclass=ABCMeta)



# Generated at 2022-06-21 20:28:15.697453
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from pypara.currencies import Currencies
    from datetime import date
    from decimal import Decimal
    from pypara.fx import FXRate

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:28:22.841167
# Unit test for method query of class FXRateService

# Generated at 2022-06-21 20:28:34.566673
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):
        """Implements FXRateService for testing purposes."""

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))
            else:
                return None


# Generated at 2022-06-21 20:28:42.166066
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit Tests for FXRateService class
    """
    from .currencies import Currencies
    from .temporal import Date

    try:
        FXRateService()
    except TypeError:
        pass
    else:
        raise AssertionError("abstract class FXRateService should not be instantiated")

    ## Test query method
    class TestService(FXRateService):
        def __init__(self, rates):
            self.rates = rates

        def query(self, ccy1, ccy2, asof, strict=False):
            return self.rates.get((ccy1, ccy2, asof))

        def queries(self, queries, strict=False):
            return (self.rates.get(q) for q in queries)


# Generated at 2022-06-21 20:28:49.103337
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    from .currencies import Currency
    from .commons.zeitgeist import Date

    exception = FXRateLookupError(Currency.EUR, Currency.USD, Date())

    assert isinstance(exception, LookupError)
    assert exception.ccy1 == Currency.EUR
    assert exception.ccy2 == Currency.USD
    assert exception.asof == Date()
    assert str(exception) == "Foreign exchange rate for EUR/USD not found as of {0}".format(Date())


# Generated at 2022-06-21 20:28:56.268639
# Unit test for constructor of class FXRate
def test_FXRate():
    """Unit test for constructor of class FXRate."""

    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 10, 15), Decimal("1.5"))

    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == date(2020, 10, 15)
    assert rate.value == Decimal("1.5")


# Generated at 2022-06-21 20:29:03.261349
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies, Currency
    from .temporals import Date
    from .fxrates import FXRate, FXRateService

    class MockFXRateService(FXRateService):

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            rates = []
            for query in queries:
                rates.append(self.query(*query, strict=strict))
            return rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof.date, asof.date.month)

    asof = Date(2020, 1, 1)

# Generated at 2022-06-21 20:29:06.023877
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime as dt
    from decimal import Decimal

    from pypara.currencies import Currencies
    
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], dt.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], dt.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

test_FXRate()

# Generated at 2022-06-21 20:29:16.938725
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    from .temporal import Date
    from decimal import Decimal
    from itertools import product


# Generated at 2022-06-21 20:30:25.833057
# Unit test for constructor of class FXRate
def test_FXRate():
    pass

# Generated at 2022-06-21 20:30:28.770624
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, ABCMeta)
    assert FXRateService.default is None
    assert FXRateService("CCY1", "CCY2", "Date") is not None

# Generated at 2022-06-21 20:30:36.225801
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    lookup_error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert lookup_error.ccy1 == Currencies["EUR"]
    assert lookup_error.ccy2 == Currencies["USD"]
    assert lookup_error.asof == datetime.date.today()
    assert str(lookup_error) == f"Foreign exchange rate for {Currencies['EUR']}/{Currencies['USD']} not found as of {datetime.date.today()}"



# Generated at 2022-06-21 20:30:42.773471
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:30:54.051502
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest.mock import MagicMock

    # Mock the FX rate service:
    service = MagicMock(spec=FXRateService)

    # Setup return values:
    service.query.return_value = None

    # Do the call:
    rate = service.query(None, None, None, False)

    # Verify:
    assert not rate

    # Setup return values:
    service.query.return_value = FXRate(None, None, None, None)

    # Do the call:
    rate = service.query(None, None, None, False)

    # Verify:
    assert rate

    # Setup return values:
    service.query.return_value = FXRate(None, None, None, None)

    # Do the call:
    rate = service.query(None, None, None, True)

   

# Generated at 2022-06-21 20:31:04.794921
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the :method:`FXRateService.query` method.
    """

    from pypara.currencies import Currency, Currencies
    from pypara.exchange.lookups import FXRateLookup

    ## Create a foreign exchange rate lookup:
    lookup = FXRateLookup()

    ## All input must be of a specified type:
    try:
        lookup.query(None, None, None)
        assert False, "The above call should have failed. But, it did not."
    except TypeError:
        pass

    try:
        lookup.query(Currencies["EUR"], Currencies["USD"], None)
        assert False, "The above call should have failed. But, it did not."
    except TypeError:
        pass


# Generated at 2022-06-21 20:31:11.101551
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests if the constructor of class `FXRateLookupError` initializes the instance correctly.
    """
    ## Import:
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    import datetime

    ## Initialize:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["CAD"]
    asof = Date(datetime.date.today())

    ## Test:
    _error = FXRateLookupError(ccy1, ccy2, asof)
    assert _error.ccy1 == ccy1
    assert _error.ccy2 == ccy2
    assert _error.asof == asof



# Generated at 2022-06-21 20:31:21.915607
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """

    # Local imports:
    from decimal import Decimal as D
    from random import shuffle
    from pypara.currencies import Currency as C

    # A random service:
    EUR = C["EUR"]
    USD = C["USD"]
    GBP = C["GBP"]
    TUR = C["TRY"]
    DATE = Date(2020, 1, 1)
    class Ccy1Service(FXRateService):
        @staticmethod
        def query(ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if asof != DATE or ccy1 != EUR:
                return None
            return FXRate(ccy1, ccy2, asof, D("1"))

# Generated at 2022-06-21 20:31:24.260360
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    msg = repr(FXRateLookupError(Currency("EUR"), Currency("USD"), Date.now()))
    assert msg == 'FXRateLookupError(ccy1=Currency("EUR"), ccy2=Currency("USD"), asof=Date(2019, 12, 24))'


# Generated at 2022-06-21 20:31:32.803264
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies  # noqa: E302
    from .commons.zeitgeist import Date  # noqa: E302

    ## TESTCASE:
    # Create an instance and check its properties.
    try:
        raise FXRateLookupError("EUR", "USD", "20200101")
    except FXRateLookupError as e:
        assert isinstance(e, FXRateLookupError)
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == Date("20200101")
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 20200101"

