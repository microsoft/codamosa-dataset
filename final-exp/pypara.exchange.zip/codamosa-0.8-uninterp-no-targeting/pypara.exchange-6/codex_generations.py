

# Generated at 2022-06-21 20:22:13.662921
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    from .currencies import Currencies

    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())

# Generated at 2022-06-21 20:22:19.874704
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:26.744303
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .commons.zeitgeist import Now
    from .currencies import Currencies
    for ccy1, ccy2 in ((Currencies["EUR"], Currencies["USD"]), (Currencies["USD"], Currencies["EUR"])):
        e = FXRateLookupError(ccy1, ccy2, Now())
        assert e.ccy1 == ccy1
        assert e.ccy2 == ccy2
        assert e.asof == Now()



# Generated at 2022-06-21 20:22:33.121262
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Provides unit tests for :class:`FXRate`
    """

    from .currencies import Currencies
    from .temporals import Date

    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(2017, 12, 31), 2.0)
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == Date(2017, 12, 31)
    assert rate.value == 2.0
    assert __inv__(rate) == FXRate(Currencies["USD"], Currencies["EUR"], Date(2017, 12, 31), 0.5)

# Generated at 2022-06-21 20:22:43.049467
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currency
    from .temporal import Temporal
    from .geography import Location

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[Decimal]:
            pass

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Temporal]], strict: bool = False) -> Iterable[
            Optional[Decimal]]:
            pass

    def test_FXRateService_query():
        pass

    def test_FXRateService_queries():
        pass

    def test_FXRateService_default():
        assert FXRateService.default is None

# Generated at 2022-06-21 20:22:43.704578
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-21 20:22:53.834452
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for the constructor of FXRateLookupError class.
    """
    ## Test method:
    from .currencies import Currencies

    ## Test data:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Date.current_date()

    ## Execution:
    error = FXRateLookupError(ccy1, ccy2, asof)

    ## Assertions:
    assert isinstance(error, FXRateLookupError)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof



# Generated at 2022-06-21 20:23:02.425820
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate
    from pypara.fxrates import FXRateService

    # Define the base rate:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date(2019, 8, 28)
    rate = FXRate(ccy1, ccy2, asof, Decimal("1.1100"))

    # Define the FX rate service:

# Generated at 2022-06-21 20:23:03.285436
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:23:10.579896
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert (~nrate == rrate)



# Generated at 2022-06-21 20:23:22.721011
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase, main
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    dummy_fxrate_service = FXRateService()

    class DummyFXRateService(FXRateService):
        pass

    ## Test ccy1 must be of type currency ##########################################################################

    with TestCase().assertRaises(TypeError) as ex:
        dummy_fxrate_service.query(None, Currencies["USD"], Date.today(), strict=False)

    assert str(ex.exception) == "CCY/1 must be of type `Currency`."

    ## Test ccy2 must be of type currency ##########################################################################


# Generated at 2022-06-21 20:23:27.616195
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    # Test 1: The module can be imported properly.
    import datetime
    from pypara.currencies import Currencies

    # No error should be raised
    FXRateLookupError(Currencies["USD"], Currencies["EUR"], datetime.date.today())


# Generated at 2022-06-21 20:23:34.885201
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .sources import FXRateServiceStatic
    from .currencies import Currencies
    from .temporals import Asof
    fx = FXRateServiceStatic(MCCY1=Currencies["EUR"], MCCY2=Currencies["USD"], MID=Asof.today(), MRATE=Decimal("1.2"))
    assert fx.query(Currencies["EUR"], Currencies["USD"], Asof.today(), strict=True) == FXRate.of(Currencies["EUR"], Currencies["USD"], Asof.today(), Decimal("1.2"))

# Generated at 2022-06-21 20:23:44.392696
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """

    ## Import stuff:
    import unittest
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services import MemoryFXRateService

    ## Define a fixture:
    class QueryFXRateService(MemoryFXRateService):
        """
        Provides a fixture for testing queries method of class FXRateService.
        """

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Overrides and returns the rates for a given collection of currency pairs and dates.
            """
            ## This method is called by the base class. We want to see the arguments.
            self.queries = queries



# Generated at 2022-06-21 20:23:49.296013
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class :class:`FXRateLookupError.
    """
    ## Arrange ##
    import datetime
    from pypara.currencies import Currencies

    ## Act ##
    with pytest.raises(FXRateLookupError) as ex:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    ## Assert ##
    assert ex.value.args[0] == "Foreign exchange rate for EUR/USD not found as of 2020-03-19"



# Generated at 2022-06-21 20:23:53.524472
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateLookupError
    rate = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate

# Generated at 2022-06-21 20:24:01.427324
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests the method :method:`FXRate.__invert__` of the class :class:`FXRate`.
    """
    import datetime
    import sys
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies

    class FXRateTestCase(unittest.TestCase):
        """
        Defines an unittest class for testing :method:`FXRate.__invert__`.
        """

        def test__invert__(self) -> None:
            """
            Tests :method:`FXRate.__invert__` method.
            """
            ## Test inverted rate:
            nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal(2))

# Generated at 2022-06-21 20:24:07.989800
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import *

    class TestService(FXRateService):
        """
        Provides a test service for foreign exchange service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return self._rates.get((ccy1, ccy2, asof))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self._rates.get(q) for q in queries]


# Generated at 2022-06-21 20:24:18.124513
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx_rates.services import InMemFXRateService

    svc = InMemFXRateService()
    svc.register(
        FXRate.of(
            Currencies["USD"],
            Currencies["EUR"],
            datetime.date.today(),
            Decimal("1.2")
        )
    )
    svc.register(
        FXRate.of(
            Currencies["USD"],
            Currencies["TRY"],
            datetime.date.today(),
            Decimal("5.6")
        )
    )

# Generated at 2022-06-21 20:24:25.171966
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:38.864175
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:50.232374
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import InMemoryFXRateService, FXRate

    # Setup the FX rate service
    rates = [
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
        FXRate(Currencies["USD"], Currencies["CAD"], datetime.date.today(), Decimal("1.3")),
        FXRate(Currencies["EUR"], Currencies["CAD"], datetime.date.today(), Decimal("1.5")),
    ]
    rservice = InMemoryFXRateService(rates)

    # Attempt to get rate
    rate = rservice.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate

# Generated at 2022-06-21 20:24:54.800879
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError.
    """
    import datetime

    ## Construct an exception:
    exc = FXRateLookupError(Currency("EUR"), Currency("USD"), datetime.date.today())

    ## Verify the message for the exception:
    assert exc.args[0] == "Foreign exchange rate for EUR/USD not found as of {}".format(exc.asof)

# Generated at 2022-06-21 20:25:07.255339
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.datetime import Dates
    from pypara.fx.services import FIXRateService
    from pypara.fx.models import FXRateLookupError, FXRate

    service = FIXRateService()

    ## Lookup strict inverted by date:
    rate = service.query(Currencies["USD"], Currencies["EUR"], Dates.today(), strict=True)
    assert isinstance(rate, FXRate)

    ## Lookup strict non-inverted by date:
    rate = service.query(Currencies["EUR"], Currencies["USD"], Dates.today(), strict=True)
    assert isinstance(rate, FXRate)

    ## Lookup strict inverted by date string:

# Generated at 2022-06-21 20:25:19.098072
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.market import FXRate
    from pypara.market.fx_rates import FXRateService
    import datetime
    # Test mock class
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: datetime.date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(2.06))
    # Tests
    fx_rate_service = TestFXRateService()
    fx_rate_result = fx_rate_service.query(Currencies['USD'], Currencies['JPY'], datetime.date(2019, 12, 31))

# Generated at 2022-06-21 20:25:26.042152
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-21 20:25:33.314890
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:25:39.376155
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.
    """
    ## Initialize the error:
    exc = FXRateLookupError("USD", "EUR", "2018-01-01")

    ## The message must be:
    assert exc.args == ("Foreign exchange rate for USD/EUR not found as of 2018-01-01",)

    ## The attributes must be:
    assert exc.ccy1 == "USD"
    assert exc.ccy2 == "EUR"
    assert exc.asof == "2018-01-01"


# Generated at 2022-06-21 20:25:43.129471
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:25:50.368859
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:26:16.095805
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert isinstance(rate.date, datetime.date)
    assert rate.value == Decimal("2")
    assert rate.__invert__() == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))



# Generated at 2022-06-21 20:26:27.344399
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from typing import List
    from pypara.currencies import Currencies

    ## Define a query:
    query = (Currencies["EUR"], Currencies["USD"], datetime.date(2017, 1, 2))

    ## Define an FX rate service:
    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, value = Decimal("2"))


# Generated at 2022-06-21 20:26:37.199702
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.fxtrader import FXRate, FXRateService
    from pypara.temporal import Date

    class TestFXRate(FXRateService):
        def __init__(self, *rates: FXRate) -> None:
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-21 20:26:48.576231
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.zeitgeist import Year
    from .currencies import Currencies

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal(str(ccy1.id + ccy2.id)))

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal(str(ccy1.id + ccy2.id)))

    fx = MockFXRateService()

# Generated at 2022-06-21 20:26:57.643091
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.finance import FXRateLookupError

    ## Error:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(2011, 12, 30))

    ## Assert:
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == Date(2011, 12, 30)
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2011-12-30"


# Generated at 2022-06-21 20:27:09.641370
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Prepare the service:
    class Mock:
        def __init__(self, queries):
            self._queries = queries

        @property
        def default(self):
            return self

        def query(self, ccy1, ccy2, asof, strict=False):
            key = (ccy1, ccy2, asof)
            return self._queries.get(key)


# Generated at 2022-06-21 20:27:17.335459
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Test equality
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    same_rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    other_rate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert rate == same_rate
    assert rate != other_rate

    # Test invert
    assert rate != ~other_rate
    assert rate == ~other_rate

    # Test cannot create invalid FX rate
    from decimal import Decimal
    from pypara.currencies import Currencies
    import pytest
   

# Generated at 2022-06-21 20:27:23.631158
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)



# Generated at 2022-06-21 20:27:29.421935
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    import doctest
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:35.220822
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporals import Date
    from pypara.fxtrades import FXRate

    assert FXRate(Currencies["EUR"], Currencies["USD"], Date(2017, 1, 1), Decimal("2")).__invert__() == \
           FXRate(Currencies["USD"], Currencies["EUR"], Date(2017, 1, 1), Decimal("0.5"))


# Generated at 2022-06-21 20:28:07.728763
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ~nrate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-21 20:28:17.135298
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests foreign exchange rate lookup error.
    """
    from .currencies import Currency, Currencies

    ## Setup the test data:
    ## Setup the test data:
    asof = Date.today()
    ccy1 = Currencies['EUR']
    ccy2 = Currencies['USD']

    ## Create the rate lookup error instance:
    error = FXRateLookupError(ccy1, ccy2, asof)

    ## Check the attributes:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof

# Generated at 2022-06-21 20:28:29.249608
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .currencies.service import CurrencyService
    from decimal import Decimal
    from datetime import date
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test foreign exchange rate service.
        """

        def query(self, ccy1, ccy2, asof, strict):
            return None

        def queries(self, queries, strict):
            for ccy1, ccy2, asof in queries:
                yield ccy1 == ccy2 and ccy1.code == "EUR" and asof == date(2012, 1, 1) and Decimal("1.00") or None

    #: Define the currency service
    CurrencyService.default = CurrencyService()

    #: Define the foreign exchange rate service
    FX

# Generated at 2022-06-21 20:28:39.022765
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """

    # stub
    class FXRateServiceStub(FXRateService):
        """
        Stub implementation of :class:`FXRateService`.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal('1.0'))

        def queries(self, queries, strict=False):
            ret = []
            for tq in queries:
                ret.append(FXRate(tq[0], tq[1], tq[2], Decimal('1.0')))
            return ret

    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    fxservice = FXRateServiceSt

# Generated at 2022-06-21 20:28:40.722513
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test method query of class FXRateService.
    """
    return True



# Generated at 2022-06-21 20:28:50.764164
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Test normal conversion:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

    # Test inverted conversion:
    assert ~~nrate == nrate

    # Test identity:
    irate = FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), ONE)
    assert ~irate == irate
    assert ~~irate == irate

    print("test_FXRate___invert__: Success.")


# Unit

# Generated at 2022-06-21 20:28:56.471360
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:28:59.748778
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert error.__class__.__name__ == "FXRateLookupError"

# Generated at 2022-06-21 20:29:01.360044
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import doctest
    doctest.testmod()


# Generated at 2022-06-21 20:29:13.556245
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of FXRateService
    """
    from collections import deque
    from decimal import Decimal, getcontext, ROUND_DOWN
    from unittest.mock import MagicMock, call, patch
    from zeitgeist.datetime import get_today
    from .currencies import Currencies
    from .date import Date
    from .fx_rates import FXRate, FXRateService

    getcontext().rounding = ROUND_DOWN
    today = get_today()

    ## Create a simple FX rate service:
    fxrates = deque()
    fxrates.append(
        FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("2"))
    )

# Generated at 2022-06-21 20:30:26.865582
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:30:32.929678
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    date = datetime.date.today()
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], date)
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == date
    assert str(error) == f"Foreign exchange rate for EUR/USD not found as of {date}"


# Generated at 2022-06-21 20:30:44.660990
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from .currencies import Currency, Currencies
    from .temporal import Date, Period, Periods

    from .temporal.calendar import Calendar
    from .temporal.date import DateRange

    from .currencies.counterparties import Bank

    from datetime import date

    ccys = (Currency("USD"), Currency("TRY"))
    asof = Date(date(2018, 9, 2))

    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2") if ccy1 == Currency("USD") else Decimal("1"))


# Generated at 2022-06-21 20:30:52.496885
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .commons.zeitgeist import today
    from decimal import Decimal
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = today()
    value = Decimal("1")
    o = FXRate(ccy1, ccy2, date, value)
    assert(isinstance(o, FXRate))
    assert(o.ccy1 == ccy1)
    assert(o.ccy2 == ccy2)
    assert(o.date == date)



# Generated at 2022-06-21 20:30:59.466721
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-21 20:31:09.042320
# Unit test for constructor of class FXRateService
def test_FXRateService():

    class DummyFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    # Ensure the class has an abstractmethod
    assert len(DummyFXRateService.__abstractmethods__) == 2
    assert FXRateService not in DummyFXRateService.__bases__
    assert FXRateService.default is None, 'default foreign exchange rate service is not set'

    # Ensure the class members and types
    assert FXRateService.TQuery == (Currency, Currency, Date)
    assert isinstance(FXRateService.TQuery[0], Currency)


# Generated at 2022-06-21 20:31:18.968042
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """
    from .currencies import EUR, USD

    ## Test with an FX rate lookup error:
    exc = FXRateLookupError(EUR, USD, Date(2019, 1, 1))
    assert isinstance(exc, FXRateLookupError)
    assert exc.ccy1 == EUR
    assert exc.ccy2 == USD
    assert exc.asof == Date(2019, 1, 1)
    assert str(exc) == "Foreign exchange rate for EUR/USD not found as of 2019-01-01"
    assert repr(exc) == "FXRateLookupError('EUR', 'USD', Date(2019, 1, 1))"



# Generated at 2022-06-21 20:31:29.594531
# Unit test for constructor of class FXRate
def test_FXRate():

    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create an FX rate instance:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Check the type of the object:
    assert type(rate) is FXRate, "Expected that the object is of type `FXRate`."

    ## Check the properties:
    assert rate.ccy1 is Currencies["EUR"], "Expected that first currency is EUR."
    assert rate.ccy2 is Currencies["USD"], "Expected that second currency is USD."
    assert rate.date == datetime.date.today(), "Expected that rate date is today."
    assert rate.value == Decimal("2"), "Expected that rate value is `2`."

   

# Generated at 2022-06-21 20:31:32.369163
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert isinstance(error, FXRateLookupError)

# Generated at 2022-06-21 20:31:43.826963
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.fx import FXRateService

    from decimal import Decimal
    from datetime import date

    from pypara.currencies import Currencies

    class MockRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))
            else:
                return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    ## Create the service:
    service = MockRateService()

    ## Define the test cases: