

# Generated at 2022-06-21 20:22:13.934237
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:15.717808
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests foreign exchange rate interface.
    """
    pass

# Generated at 2022-06-21 20:22:26.984512
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService
    """
    # Setup
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Temporal
    from typing import NamedTuple  # noqa: F401
    from unittest import TestCase
    class Rate(NamedTuple):
        ccy1: Currency
        ccy2: Currency
        date: Temporal
        value: Decimal

    class TestService(FXRateService):
        def __init__(self, rates: Iterable[Rate]) -> None:
            self.__rate = dict(((rate.ccy1, rate.ccy2, rate.date), rate.value) for rate in rates)


# Generated at 2022-06-21 20:22:31.140485
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        raise FXRateLookupError(Currency('EUR'), Currency('USD'), '2020-09-01')
    except FXRateLookupError as e:
        assert e.ccy1 == Currency('EUR')
        assert e.ccy2 == Currency('USD')
        assert e.asof == '2020-09-01'


# Generated at 2022-06-21 20:22:34.870988
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:22:37.198985
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert FXRateService.provider("FIXER").query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) == rate


# Generated at 2022-06-21 20:22:46.624724
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit tests for FXRateService class.
    """
    from .currencies import Currencies
    from .temporals import Date
    from .svcs.fxrate import _NaiveFXRateService

    ## FX rates are not found as of today:
    svc = FXRateService.default
    assert svc is not None
    assert svc.query(Currencies["EUR"], Currencies["USD"], Date.today()) is None
    assert svc.query(Currencies["EUR"], Currencies["USD"], Date.today(), strict=True) is None

    ## FX rates are found as of yesterday:
    assert svc.query(Currencies["EUR"], Currencies["USD"], Date.today() - 1) is not None

# Generated at 2022-06-21 20:22:58.144591
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.csv import CSVFXRateService


# Generated at 2022-06-21 20:23:04.977391
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .factory import Factory
    from .zeitgeist import Date
    import datetime
    import decimal

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Date(datetime.datetime(2019, 12, 31))

    fxrates = [
        (ccy1, ccy2, asof, decimal.Decimal("2.00")),
        (ccy1, ccy2, asof - datetime.timedelta(days=1), decimal.Decimal("1.50"))
    ]

    service = Factory.get_fxrate_service(fxrates)
    fxrate = service.query(ccy1, ccy2, asof)
    assert isinstance(fxrate, FXRate)
    assert fxrate

# Generated at 2022-06-21 20:23:18.096996
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import mock
    from pypara.fx import FXRateService
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from decimal import Decimal
    from datetime import date

    # Define mock query
    def query_mock(self, ccy1, ccy2, asof, strict=False):
        if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == date(2018, 1, 1):
            return FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal(2))

# Generated at 2022-06-21 20:23:23.541428
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-21 20:23:26.984045
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # try:
    #     FXRateService(convert=1)
    # except Exception as e:
    #     print(f'Fail: {e}')
    # else:
    #     print(f'Pass')
    pass

# Generated at 2022-06-21 20:23:32.401795
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase, main
    from .commons.zeitgeist import Date
    from .currencies import Currency

    class Unit(TestCase):
        @staticmethod
        def test_01():
            class Test(FXRateService):
                def query(self, ccy1, ccy2, asof, strict=False) -> Optional[FXRate]:
                    pass
                def queries(self, queries, strict=False) -> Optional[FXRate]:
                    pass

            Test()

    main()



# Generated at 2022-06-21 20:23:42.744617
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests that the constructor of class :class:`FXRateLookupError` works as expected.
    """

    from .currencies import CurrencyTypes, EUR, USD
    from .commons.zeitgeist import D

    ## Check that attributes are set correctly:
    error = FXRateLookupError(EUR, USD, D("2020-01-01"))
    assert error.ccy1 == EUR
    assert error.ccy2 == USD
    assert error.asof == D("2020-01-01")

    ## Check that the message is set correctly:
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2020-01-01"

    ## Run the test for all currency types:
    for currency_type in CurrencyTypes:
        ccy_1 = currency_type()
        ccy_2 = currency_

# Generated at 2022-06-21 20:23:54.788969
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase

    from .currencies import Currency
    from .temporal import Temporal

    class Service(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Temporal]], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    service = Service()

    class T(TestCase):
        def test_query(self):
            self.assertIsNone(service.query(None, None, None))

        def test_queries(self):
            self.assertEqual(list(service.queries([])), [])

    return T

# Generated at 2022-06-21 20:23:59.408288
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate.of(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-21 20:24:01.241630
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Test FXRateService constructor.
    """
    pass


# Generated at 2022-06-21 20:24:07.926593
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Temporal, Temporals
    from pypara.commons.zeitgeist import Date
    from pypara.fx.rateservices.static import StaticFXRateService
    from pypara.fx.rateservices.sequential import SequentialFXRateService

    ## Initialize the test data:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    t1 = Temporal(Date(2020, 1, 1))
    t2 = Temporal(Date(2020, 2, 1))

    ## Create an empty static service:
    empty_static = StaticFXRateService()

    ## Test the empty static service:
    assert empty_static.query(ccy1, ccy2, t1.value)

# Generated at 2022-06-21 20:24:18.129585
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, ABCMeta)
    assert FXRateService.__abstractmethods__ == frozenset({'queries', 'query'})
    assert FXRateService.__doc__ == '\n    Provides an abstract class for serving foreign exchange rates.\n    '
    assert FXRateService.__slots__ == ()
    assert FXRateService.default is None
    assert FXRateService.TQuery == (typing._GenericAlias(Currency, 'Currency'), typing._GenericAlias(Currency, 'Currency'), typing._GenericAlias(Date, 'Date'))

# Generated at 2022-06-21 20:24:30.373544
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currency
    from pypara.datetime import Date
    from pypara.fx.services import FixedFXRateService
    from pypara.fx.rates import FXRate
    from decimal import Decimal
    FXRateService_queries = FixedFXRateService()

# Generated at 2022-06-21 20:24:50.446457
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from abc import ABC, abstractmethod
    from datetime import date
    from decimal import Decimal
    from inspect import getfullargspec
    from .currencies import Currencies

    assert FXRateService.__abstractmethods__ == {"query", "queries"}
    assert isinstance(FXRateService.__doc__, str)
    assert getfullargspec(FXRateService.query) == getfullargspec(FXRateService.queries)

    # noinspection PyAbstractClass
    class FXRateServiceMock(FXRateService):

        @abstractmethod
        def query(  # noqa: W
            self,
            ccy1: Currencies,
            ccy2: Currencies,
            asof: date,
            strict: bool = False,
        ) -> Optional[Decimal]:
            pass


# Generated at 2022-06-21 20:24:57.455572
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import CURRENCIES
    from .temporal import Temporal
    from .temporal.temporality import Temporality
    from pypara.fxrates import FXRateService

    ## Define a function for testing the method:
    def test(service: FXRateService, ccy1: str, ccy2: str, asof: Temporal) -> None:
        ccy1 = CURRENCIES[ccy1]
        ccy2 = CURRENCIES[ccy2]
        asof = asof.as_date()
        rate = service.query(ccy1, ccy2, asof)
        if ccy1 == ccy2:
            assert isinstance(rate, FXRate), "FX rate to the same currency must be one."

# Generated at 2022-06-21 20:25:08.425243
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:25:20.389510
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D103
    ## -- Boilerplate:
    import datetime

    from decimal import Decimal

    from pypara.commons.numbers import ONE, ZERO

    from .currencies import Currency, Currencies

    ## -- Cases:
    ## Empty rate:
    assert FXRateService.default.query(Currencies["USD"], Currencies["EUR"], datetime.date.today(), False) is None
    assert FXRateService.default.query(Currencies["USD"], Currencies["EUR"], datetime.date.today(), True) is None

    ## Unit rate:
    assert FXRateService.default.query(Currencies["USD"], Currencies["USD"], datetime.date.today(), False) == FXRate(Currencies["USD"], Currencies["USD"], datetime.date.today(), ONE)

# Generated at 2022-06-21 20:25:30.847615
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fxrates import InMemoryFXRateService

    ## Create the service:
    service = InMemoryFXRateService(
        (_c, _r)
        for _r in (
            FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
            FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5")),
        )
        for _c in (0, 1)
    )

    ## Ensure that the service is working:

# Generated at 2022-06-21 20:25:36.972360
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime

    from pypara.currencies import Currencies

    error = FXRateLookupError(Currencies.USD, Currencies.EUR, datetime.date.today())
    assert isinstance(error, FXRateLookupError)
    assert isinstance(error, LookupError)
    assert error.ccy1 == Currencies.USD
    assert error.ccy2 == Currencies.EUR
    assert error.asof == datetime.date.today()


# Generated at 2022-06-21 20:25:37.532707
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-21 20:25:41.346686
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    # The following statements must not raise an exception:
    FXRateLookupError(ccy1=1, ccy2=2, asof=3)
    FXRateLookupError(ccy1=1, ccy2=2, asof=3).args
    FXRateLookupError(ccy1=1, ccy2=2, asof=3).__str__()


# Generated at 2022-06-21 20:25:51.950976
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.

    >>> test_FXRateLookupError()
    """
    import datetime

    from .currencies import Currencies

    from .core import raise_if_not_equal

    ## Initialize an FX rate error:
    ccy1, ccy2, date = Currencies["EUR"], Currencies["USD"], datetime.date.today()
    error = FXRateLookupError(ccy1, ccy2, date)

    ## Check properties:
    raise_if_not_equal(error.ccy1, ccy1)
    raise_if_not_equal(error.ccy2, ccy2)
    raise_if_not_equal(error.asof, date)


# Generated at 2022-06-21 20:26:03.812225
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from datetime import date
    from .commons.zeitgeist import Date

    ## Unit test for constructor of class FXRateLookupError
    def test_FXRateLookupError():
        """
        Tests the FXRateLookupError constructor.
        """
        ## The currency to be used in a test:
        ccy1 = Currency("EUR")
        ccy2 = Currency("USD")
        asof = Date(date(2019, 1, 7))

        ## Test the FXRateLookupError constructor:
        try:
            raise FXRateLookupError(ccy1, ccy2, asof)
        except FXRateLookupError as e:
            assert type(e) == FXRateLookupError
            assert e.ccy1 == ccy1
            assert e.ccy2 == ccy

# Generated at 2022-06-21 20:26:26.107622
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    if ~nrate != rrate:
        raise AssertionError("`~FXRate.__invert__()` method is not working as expected.")

if __name__ == "__main__":
    test_FXRate___invert__()

# Generated at 2022-06-21 20:26:36.287776
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests class FXRateService.
    """
    from pypara.commons.temporals import Temporals
    from pypara.currencies import Currencies

    # noinspection PyTypeChecker
    assert issubclass(FXRateService, object)

    # Opening FXRateService is not possible:
    try:

        # noinspection PyStatementEffect
        FXRateService()  # type: ignore

        # Tell why we failed:
        assert False, "Expected FXRateService to be abstract"

    except TypeError:

        # Expected:
        pass

    # Check the type of default service:
    assert FXRateService.default is None or isinstance(FXRateService.default, FXRateService)

    # Check FXRateService.TQuery:
    assert FXRateService.TQuery is tuple

    # Check T

# Generated at 2022-06-21 20:26:47.784380
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService.
    """
    from collections import Counter


    class MockService(FXRateService):
        """
        Provides a mock foreign exchange rate service implementation.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return super().query(ccy1, ccy2, asof, strict)

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            ## The default implementation just iterates over the query list:


# Generated at 2022-06-21 20:26:58.163169
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from unittest import TestCase, main
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.rates import FXRate
    class Test(TestCase): # pylint: disable=R0904,R0902
        """
        Unit test for method __invert__ of class FXRate.
        """
        def test(self):
            nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
            rrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))
            self.assertTrue(~nrate == rrate)
    main()


# Generated at 2022-06-21 20:27:09.950996
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class MyService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            self._rates = dict(rates)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if not strict:
                return self._rates.get(FXRate.of(ccy1, ccy2, asof, ZERO))
            return self._rates[FXRate.of(ccy1, ccy2, asof, ZERO)]


# Generated at 2022-06-21 20:27:15.223456
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-21 20:27:28.084010
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:33.551666
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    import datetime

    # Test:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date(2017, 7, 4))
    except FXRateLookupError as e:
        assert "Foreign exchange rate for EUR/USD not found as of 2017-07-04" == str(e)

# Generated at 2022-06-21 20:27:38.361234
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Unit test for method __invert__ of class FXRate
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-21 20:27:43.922113
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:28:17.296459
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    class _Fixture(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, queries, strict=False):
            return

    instance = _Fixture()
    import pytest
    pytest.raises(NotImplementedError, instance.query, None, None, None)



# Generated at 2022-06-21 20:28:23.749999
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pytz import timezone
    from pypara.currencies import Currency
    from pypara.currencies.money import Money
    from pypara.locales import LocalizationContext, LocalizationContextBuilder, MonetaryContext
    from pypara.temporal import TemporalContext
    from pypara.temporal.temporal import TemporalContextBuilder
    from pypara.temporal.temporal import TemporalContextBuilder
    import datetime

    # Create a fixed FX rate service:

# Generated at 2022-06-21 20:28:34.674294
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    
    The following code snippet must be executed with high degree of confidence. For this reason, it is isolated as 
    a standalone method rather than part of a class method.
    """
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    date = Date(2019, 11, 11)
    error = FXRateLookupError(ccy1, ccy2, date)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == date
    assert error.args == (f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {date}",)


# Generated at 2022-06-21 20:28:45.166205
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency # noqa: F401
    from .currencies.yahoo import CurrencyService # noqa: F401
    from .temporal import Date # noqa: F401

    fxrates = FXRateService()

    fxrate = fxrates.query("EUR", "USD", Date("2020-01-01"))
    assert isinstance(fxrate, FXRate)
    assert fxrate.ccy1 == "EUR"
    assert fxrate.ccy2 == "USD"
    assert fxrate.date == Date("2020-01-01")
    assert fxrate.value > ZERO

    fxrate = fxrates.query("USD", "EUR", Date("2020-01-01"))
    assert isinstance(fxrate, FXRate)

# Generated at 2022-06-21 20:28:54.217701
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as ex:
        assert ex.ccy1 == Currencies["EUR"]
        assert ex.ccy2 == Currencies["USD"]
        assert ex.asof == datetime.date.today()
        assert str(ex) == "Foreign exchange rate for EUR/USD not found as of " + datetime.date.today().strftime("%Y-%m-%d")

# Generated at 2022-06-21 20:28:59.309207
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert(~nrate == rrate)


# Generated at 2022-06-21 20:29:12.211532
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of the FXRateLookupError class.
    """
    from .currencies import Currencies

    ## Invalid arguments:
    with raises(TypeError):
        FXRateLookupError(None, Currencies["USD"], Date.today())

    with raises(TypeError):
        FXRateLookupError(Currencies["USD"], None, Date.today())

    with raises(TypeError):
        FXRateLookupError(Currencies["USD"], Currencies["EUR"], None)

    ## Valid:
    msg = FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date.today()).args
    assert msg == (
        "Foreign exchange rate for USD/EUR not found as of {}".format(Date.today().strftime("%Y-%m-%d")),
    )

# Generated at 2022-06-21 20:29:12.804603
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:29:19.144519
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # Imports
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateLookupError, FXRateService

    # A concrete FX rate service implementation
    class FXRateServiceImpl(FXRateService):
        def __init__(self, **rates):
            self.__rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            key = (ccy1.code, ccy2.code, asof)
            rate = self.__rates[key] if key in self.__rates else None
            if rate is None and strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return rate


# Generated at 2022-06-21 20:29:24.927053
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert(ccy1 == Currencies["EUR"])
    assert(ccy2 == Currencies["USD"])
    assert(date == datetime.date.today())
    assert(value == Decimal("2"))


# Generated at 2022-06-21 20:30:41.721993
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class FXRateLookupError.
    """
    ## Import libraries:
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateLookupError

    ## Construct some test cases:
    date = Date()
    ccy1 = Currencies["TRY"]
    ccy2 = Currencies["USD"]
    error = FXRateLookupError(ccy1, ccy2, date)

    assert(error.ccy1 == ccy1)
    assert(error.ccy2 == ccy2)
    assert(error.asof == date)
    assert(str(error) == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {date}")


# Generated at 2022-06-21 20:30:43.171005
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    assert FXRateService()

# Generated at 2022-06-21 20:30:49.085272
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.query(rate.ccy1, rate.ccy2, rate.date) == rate
    assert rate.query(rate.ccy2, rate.ccy1, rate.date) == ~rate
    assert rate.query(rate.ccy1, rate.ccy1, rate.date) == rate
    assert rate.query(rate.ccy2, rate.ccy2, rate.date) == rate

# Generated at 2022-06-21 20:30:57.331622
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    eur_usd = FXRate(Currencies.EUR, Currencies.USD, datetime.date.today(), Decimal("2"))
    assert eur_usd[0] == Currencies["EUR"]
    assert eur_usd[1] == Currencies["USD"]
    assert eur_usd[2] == datetime.date.today()
    assert eur_usd[3] == Decimal("2")


# Generated at 2022-06-21 20:30:57.903344
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-21 20:30:58.790212
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:30:59.676545
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:31:02.608977
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:31:03.507617
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:31:04.844861
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService is not None  # noqa: E702