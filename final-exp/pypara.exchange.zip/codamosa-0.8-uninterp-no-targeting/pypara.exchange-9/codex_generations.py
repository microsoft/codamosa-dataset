

# Generated at 2022-06-21 20:22:16.551591
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests queries method of FXRateService
    """

    class TestFXRateService(FXRateService):
        """
        Test FXRateService
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.

            :param ccy1: The first currency of foreign exchange rate.
            :param ccy2: The second currency of foreign exchange rate.
            :param asof: Temporal dimension the foreign exchange rate is effective as of.
            :param strict: Indicates if we should raise a lookup error if that the foreign exchange rate can not be found.
            :return: The foreign exhange rate as a :class:`Decimal` instance or None.
            """


# Generated at 2022-06-21 20:22:27.990011
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert(rate.ccy1 == Currencies["EUR"])
    assert(rate.ccy2 == Currencies["USD"])
    assert(rate.date == datetime.date.today())
    assert(rate.value == Decimal("2"))
    assert((~rate).ccy1 == Currencies["USD"])
    assert((~rate).ccy2 == Currencies["EUR"])
    assert((~rate).date == datetime.date.today())
    assert((~rate).value == Decimal("0.5"))

# Generated at 2022-06-21 20:22:32.172398
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate) == rrate


# Generated at 2022-06-21 20:22:36.242161
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    assert FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))


# Generated at 2022-06-21 20:22:42.383687
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)

# Generated at 2022-06-21 20:22:47.631734
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as error:
        assert error.ccy1 == Currencies["EUR"]
        assert error.ccy2 == Currencies["USD"]
        assert error.asof == datetime.date.today()

# Generated at 2022-06-21 20:22:54.271002
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:56.766549
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from pypara.currencies import Currencies
    from pypara.dates import Dates

    rate: FXRate = FXRate(Currencies["EUR"], Currencies["USD"], Dates(2020, 8, 8), Decimal("2"))
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], Dates(2020, 8, 8), Decimal("0.5"))


# Generated at 2022-06-21 20:23:02.056815
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:23:11.902973
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class MyService(FXRateService):
        def query(self, *args, **kwargs):
            return None

    q = MyService().query
    del MyService

    ## Test that the method rejects non-callable strict argument:
    try:
        q(None, None, None, strict="badtype")
        assert False
    except TypeError:
        pass

    ## See that strict argument is ignored as the underlying query method returns None:
    assert None is q(None, None, None)
    assert None is q(None, None, None, strict=False)
    assert None is q(None, None, None, strict=True)


# Generated at 2022-06-21 20:23:26.677989
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    from .currencies import Currency
    from .commons.zeitgeist import Date
    from pypara.conversions.fxrates import FXRateLookupError
    import datetime
    ccy1 = Currency("EUR", "EUR", "978", 2)
    ccy2 = Currency("USD", "USD", "840", 2)
    asof = Date(datetime.date.today())
    assert(FXRateLookupError(ccy1, ccy2, asof))



# Generated at 2022-06-21 20:23:27.248648
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-21 20:23:29.492940
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for class :class:`FXRateService`.

    :return: None.
    """
    ## Test the abstract methods:
    assert FXRateService.query.__name__ == "query"
    assert FXRateService.queries.__name__ == "queries"

# Generated at 2022-06-21 20:23:36.675528
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:23:42.489522
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:23:54.609335
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency, Currencies

    # Test 1:
    try:
        raise FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date.today())
    except FXRateLookupError as e:
        assert e.args[0] == "Foreign exchange rate for USD/EUR not found as of 12/17/2016"

    # Test 2:
    try:
        raise FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date(2016, 12, 17))
    except FXRateLookupError as e:
        assert e.args[0] == "Foreign exchange rate for USD/EUR not found as of 12/17/2016"

    # Test 3:

# Generated at 2022-06-21 20:23:59.293892
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:24:04.993074
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.currencies import Currencies
    import datetime
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:13.810467
# Unit test for constructor of class FXRate
def test_FXRate():

    from .currencies import Currencies

    base = Currencies["USD"]
    term = Currencies["EUR"]
    date = Date.today()
    value = Decimal("0.5")

    rate = FXRate.of(base, term, date, value)
    assert rate.ccy1 == base
    assert rate.ccy2 == term
    assert rate.date == date
    assert rate.value == value

    assert rate[0] == base
    assert rate[1] == term
    assert rate[2] == date
    assert rate[3] == value



# Generated at 2022-06-21 20:24:19.914989
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    print("test constructor of class FXRate ...")
    rate = FXRate("EUR", "USD", datetime.date.today(), Decimal("2"))
    assert rate[0] == "EUR"
    assert rate[1] == "USD"
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")
    assert rate.ccy1 == "EUR"
    assert rate.ccy2 == "USD"
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")
    print("passed")


# Generated at 2022-06-21 20:24:35.761979
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.fx import FXRate, FXRateService

    class MockFXRateService(FXRateService):
        def __init__(self):
            self.fx = {
                (Currencies["EUR"], Currencies["USD"], datetime.date(2018, 4, 1)): Decimal("1.2345"),
                (Currencies["EUR"], Currencies["USD"], datetime.date(2018, 4, 2)): Decimal("1.2346"),
                (Currencies["EUR"], Currencies["USD"], datetime.date(2018, 4, 3)): Decimal("1.2347")
            }


# Generated at 2022-06-21 20:24:40.436671
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:24:51.039941
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies

    ccy1 = Currency("CCY1", "Currency-1", "Cur1", "C1", "C", True, True, True, True)
    ccy2 = Currency("CCY2", "Currency-1", "Cur1", "C1", "C", True, True, True, True)
    date = datetime.date.today()
    value = Decimal("1.0")

    rate = FXRate(ccy1, ccy2, date, value)
    assert rate.ccy1 == ccy1
    assert rate.ccy2 == ccy2
    assert rate.date == date
    assert rate.value == value
    ccy1, ccy2, date, value = rate
    assert c

# Generated at 2022-06-21 20:24:56.908505
# Unit test for constructor of class FXRateService
def test_FXRateService():
    for method in ("query", "queries"):
        with raises(TypeError) as error:
            FXRateService.__dict__[method](None)
        assert str(error.value) == "'FXRateService' object is not callable"

# Generated at 2022-06-21 20:25:05.452525
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 20:25:16.994947
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.services.fxrates import FXRateService

    class MockFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, 2)

        def queries(self, queries, strict=False):
            for query in queries:
                yield self.query(query[0], query[1], query[2], strict)

    service = MockFXRateService()

    ## Test with a list

# Generated at 2022-06-21 20:25:24.324388
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies

    c1, c2, c3 = Currencies["EUR"], Currencies["USD"], Currencies["GBP"]
    queries = [
        (c1, c2, Date.today()),
        (c1, c3, Date.today()),
        (c2, c3, Date.today()),
    ]

    class Service(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

# Generated at 2022-06-21 20:25:34.917438
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal

    from pypara.commons.zeitgeist import Temporal
    from pypara.currencies import Currencies

    queries = (
        (Currencies["EUR"], Currencies["USD"], Temporal.of(datetime.date.today(), datetime.time())),
        (Currencies["EUR"], Currencies["USD"], Temporal.of(datetime.date.today(), datetime.time())),
        (Currencies["EUR"], Currencies["USD"], Temporal.of(datetime.date.today(), datetime.time())),
    )


# Generated at 2022-06-21 20:25:43.952627
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from datetime import date
    from pypara.currencies import Currencies
    error = FXRateLookupError(Currencies["USD"], Currencies["EUR"], date.today())
    assert isinstance(error, LookupError)
    assert error.ccy1 == Currencies["USD"]
    assert error.ccy2 == Currencies["EUR"]
    assert error.asof == date.today()
    assert error.args is not None
    assert len(error.args) == 1
    assert error.args[0] == f"Foreign exchange rate for USD/EUR not found as of {date.today()}"


# Generated at 2022-06-21 20:25:50.234824
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .commons.zeitgeist import Date
    from .currencies import Currency

    assert FXRate(Currencies["EUR"], Currencies["USD"], Date("2019-01-01"), Decimal("2"))
    assert FXRate.of(Currencies["EUR"], Currencies["USD"], Date("2019-01-01"), Decimal("2"))

# Generated at 2022-06-21 20:26:03.390655
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests FXRateService constructor.
    """

    # Test the import of this module:
    from pypara.rates.fx import FXRateService

    # Test the abstract class:
    assert isinstance(FXRateService, type)
    assert issubclass(FXRateService, ABCMeta)



# Generated at 2022-06-21 20:26:08.006018
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:26:10.614930
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import mock
    mock.Mock[FXRateService]   
    FXRateService()


# Generated at 2022-06-21 20:26:18.816125
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    from pypara.currencies import Currency, Currencies
    import datetime

    from decimal import Decimal

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    # Convert the inverted rate back to the original rate:
    assert ~rrate == nrate

    # Convert the rate back to the inverted rate:
    assert ~nrate == rrate



# Generated at 2022-06-21 20:26:30.650978
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fxrates import (
        FXRateLookupError,
        FXRate,
        FXRateService,
    )


    ## Define our FX rate service:
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (
                ccy1 == Currencies["EUR"]
                and ccy2 == Currencies["USD"]
                and asof == datetime.datetime.today().date()
            ):
                return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

            if strict is True:
                raise FX

# Generated at 2022-06-21 20:26:36.366781
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase, main, mock

    class FXRateServiceTest(TestCase):

        def test_query(self):
            service = FXRateService()
            with mock.patch.object(service, "query", mock.Mock(return_value = "test query")):
                self.assertEqual(service.query("", "", None, True), "test query")
                service.query.assert_called_with("", "", None, True)

    main()



# Generated at 2022-06-21 20:26:47.827959
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import builtins
    import datetime
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Define an FX rate service implementation for testing purposes:
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None


# Generated at 2022-06-21 20:26:54.669284
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:00.073758
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Defines unit tests for the constructor of class :class:`FXRateService`.
    """
    import pytest
    with pytest.raises(TypeError):
        FXRateService()  # pylint: disable=E0110
    with pytest.raises(TypeError):
        FXRateService.query(None, None, None)  # pylint: disable=E1101
    with pytest.raises(TypeError):
        FXRateService.queries(None, None)  # pylint: disable=E1101

# Generated at 2022-06-21 20:27:02.754054
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert hasattr(FXRateService, "query")
    assert hasattr(FXRateService, "queries")


# Generated at 2022-06-21 20:27:31.088350
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    # pylint: disable=I0011,W0106,C0103,R0201
    class FXRateServiceTester(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    # pylint: enable=I0011,W0106,C0103,R0201
    #
    # Test the constructor of class FXRateService

# Generated at 2022-06-21 20:27:36.358192
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    import datetime
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-21 20:27:41.160783
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2014-09-23"


# Generated at 2022-06-21 20:27:45.299905
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate == ~rate


# Generated at 2022-06-21 20:27:49.518967
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    import dateutil.parser
    dt = dateutil.parser.parse("2020-01-20").date()
    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], dt)
    assert isinstance(e.args[0], str)
    assert isinstance(e, Exception)


# Generated at 2022-06-21 20:28:01.004335
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Temporals
    from .currencies import Currency
    from .temporal import Temporal

    ## Create an exception:
    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Temporals.today())

    ## Check attributes:
    assert isinstance(e.ccy1, Currency)
    assert e.ccy1 == Currencies["EUR"]
    assert isinstance(e.ccy2, Currency)
    assert e.ccy2 == Currencies["USD"]
    assert isinstance(e.asof, Temporal)
    assert e.asof == Temporals.today()



# Generated at 2022-06-21 20:28:06.023901
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:28:17.688705
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    ## Import the required Python modules:
    import unittest
    import datetime

    ## Import the required package modules:
    from pypara.currencies import Currencies

    ## Define a test fx rate service:
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None


# Generated at 2022-06-21 20:28:18.681038
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:28:20.627412
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    pass


# Generated at 2022-06-21 20:29:01.406092
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D103
    from .currencies import Currencies
    from datetime import date

    def implementation(ccy1: Currency, ccy2: Currency, asof: Date) -> Optional[FXRate]:
        if ccy1 == ccy2:
            return FXRate.of(ccy1, ccy2, asof, ONE)
        if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
            return FXRate.of(ccy1, ccy2, asof, Decimal('1.1'))
        if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
            return FXRate.of(ccy1, ccy2, asof, Decimal('0.9'))
        return None


# Generated at 2022-06-21 20:29:02.714608
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    raise FXRateLookupError()

# Generated at 2022-06-21 20:29:13.092927
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import unittest
    import sys
    import os

    class TestMethods(unittest.TestCase):

        def test_constructor_of_abstract_class(self):
            ## Silence the constructor of the abstract class:
            fx_rate_service = FXRateService()

    ## Run the unit test
    test_suite = unittest.TestSuite()
    test_suite.addTest(unittest.makeSuite(TestMethods))
    result = unittest.TextTestRunner(verbosity=2).run(test_suite)
    sys.exit(len(result.errors) + len(result.failures))


# Generated at 2022-06-21 20:29:19.261761
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.time import Date

    class FXRateServiceMock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    service = FXRateServiceMock()
    result = service.query(Currencies["EUR"], Currencies["USD"], Date.today())
    assert result == FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))

# Generated at 2022-06-21 20:29:23.369970
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate("EUR", "USD", date.today(), Decimal("2"))
    assert rate.__invert__() == FXRate("USD", "EUR", date.today(), Decimal("0.5"))


# Generated at 2022-06-21 20:29:35.667702
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import USD, GBP, EUR
    from .temporals import Date
    # Make sure that the function does not fail when the service does not provide rates for all queries.
    import datetime
    expected = [1.7, None, 0.8, 1.0]
    def fx_service(*args, **kwargs):
        dates = [datetime.date(2018,1,1), datetime.date(2017,1,1), datetime.date(2018,1,1), datetime.date(2014,1,1)]
        date = args[2]
        if date in dates:
            idx = dates.index(date)
            return expected[idx] if expected[idx] is not None else FXRate(USD, EUR, date, expected[idx])

# Generated at 2022-06-21 20:29:44.656145
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    # Define a FXRateService implementation:
    class MockFXRateService(FXRateService):

        def __init__(self):
            self.cache = {}

        def query(self, ccy1:Currencies, ccy2: Currencies, asof: datetime.date, strict: bool = False):
            key = (ccy1, ccy2, asof)
            if key not in self.cache:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                return None
            return self.cache[key]


# Generated at 2022-06-21 20:29:56.786901
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test method query of class FXRateService.
    """
    from .currencies import Currencies
    from .env import Environments
    from .temporal import Temporal
    from . import currencies as module_currencies
    from . import fxrates as module_fxrates
    from . import temporal as module_temporal

    assert module_currencies.__name__ in repr(Currencies)
    assert module_fxrates.__name__ in repr(module_fxrates.FXRateServices)
    assert module_temporal.__name__ in repr(Temporal)

    date = Environments.default.now()
    assert date.year == date.date().year
    assert date.month == date.date().month
    assert date.day == date.date().day

    ccy1 = Currencies["EUR"]

# Generated at 2022-06-21 20:29:58.770867
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests :class:`FXRateService`.
    """
    assert FXRateService, "Failed to import class `FXRateService`"

# Generated at 2022-06-21 20:30:05.846420
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:31:18.075440
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # TODO: implement
    pass

# Generated at 2022-06-21 20:31:23.562183
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests if the FXRateLookupError is constructed properly.
    """
    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == datetime.date.today()
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of %s" % datetime.date.today()


# Generated at 2022-06-21 20:31:33.107232
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests that the inverse of an FX rate can be calculated.
    """

    # Import and alias required modules:
    import datetime
    import decimal
    import unittest

    from pypara.assets import FXRate
    from pypara.currencies import Currencies

    # Define a test case:
    class FXRateTest(unittest.TestCase):
        """
        Defines tests for :class:`FXRate` class.
        """

        def test_invert(self) -> None:
            """
            Tests the method `~FXRate.__invert__`.
            """

            # Stores the test data:

# Generated at 2022-06-21 20:31:44.573870
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    from .currencies import Currencies
    from .zeitgeist import LocalDate
    from decimal import Decimal
    from pytest import raises
    from pytest import mark

    @mark.parametrize("ccy1", [Currencies["EUR"], "USD", 1 / 2, Decimal("0.5")])
    def test_FXRateService_with_unexpected_ccy1(ccy1, mocker):
        """
        Tests method query with an unexpected ccy1 argument.
        """
        from .fxrates import FXRateService, FXRateLookupError

        service = FXRateService()
        with raises(TypeError):
            service.query(ccy1, Currencies["USD"], LocalDate.today())


# Generated at 2022-06-21 20:31:48.303143
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-21 20:31:59.454436
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRateLookupError, FXRateService

    ccy1 = Currencies["USD"]
    ccy2 = Currencies["TRY"]
    asof = datetime.date.today()

    class FxRateServiceMock(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["TRY"]:
                return FXRate(Currencies["USD"], Currencies["TRY"], datetime.date.today(), Decimal("7.03"))

# Generated at 2022-06-21 20:32:05.472394
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate