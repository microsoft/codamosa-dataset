

# Generated at 2022-06-21 20:22:12.043549
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """Unit test for methods queries in class FXRateService."""
    pass


# Generated at 2022-06-21 20:22:20.080605
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))  # noqa: E704

    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:22:30.448858
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from pypara.fxrates import FXRateService

    class StaticFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for _ in queries:
                yield None

    queries = [(Currencies["USD"], Currencies["EUR"], Date.of(2020, 1, 1)),
               (Currencies["USD"], Currencies["EUR"], Date.of(2020, 1, 2)),
               (Currencies["USD"], Currencies["EUR"], Date.of(2020, 1, 3))]
   

# Generated at 2022-06-21 20:22:37.556407
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__(): # noqa
    from decimal import Decimal
    from zeitgeist.datetime import Date

    EUR = Currency("EUR")
    USD = Currency("USD")
    nrate = FXRate(EUR, USD, Date.today(), Decimal("2"))
    rrate = FXRate(USD, EUR, Date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:38.690525
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass


# Generated at 2022-06-21 20:22:45.900152
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the FX rate lookup error.
    """
    import datetime
    e = FXRateLookupError("ccy1", "ccy2", datetime.date.today())
    assert isinstance(e, LookupError)
    assert e.ccy1 == "ccy1"
    assert e.ccy2 == "ccy2"
    assert e.asof == datetime.date.today()
    assert str(e) == "Foreign exchange rate for ccy1/ccy2 not found as of %s" % datetime.date.today()



# Generated at 2022-06-21 20:22:47.412971
# Unit test for constructor of class FXRateService
def test_FXRateService():  # noqa: D103
    pass

# Generated at 2022-06-21 20:22:57.407505
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .currencies import ISO4217_NAMES as ISO
    from .currencies import ISO4217_SYMBOLS as SYM
    from .currencies import ISO4217_NUMBERS as NUM
    import datetime
    ccy1 = Currencies[SYM["EUR"]]
    ccy2 = Currencies[NUM["USD"]]
    asof = datetime.date(2019, 2, 22)
    e = FXRateLookupError(ccy1, ccy2, asof)
    assert e.ccy1 == ccy1
    assert e.ccy2 == ccy2
    assert e.asof == asof


# Generated at 2022-06-21 20:23:04.576495
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    import datetime

    from decimal import Decimal

    from .fxrates import FXRate
    from pypara.fxrates.services import HistoricalFXRateService

    service = HistoricalFXRateService(
        (
            FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1), Decimal("1.1")),
            FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 2), Decimal("1.2")),
            FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 3), Decimal("1.3")),
        )
    )

    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 2)) == FX

# Generated at 2022-06-21 20:23:16.140564
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    try:
        FXRateLookupError(Currencies["EUR"], Currencies["USD"], date.today())
    except Exception as e:
        assert e.args[0] == "Foreign exchange rate for EUR/USD not found as of {}".format(date.today())
    try:
        FXRateLookupError(Currencies["EUR"], Currencies["USD"], Decimal(2))
    except Exception as e:
        assert e.args[0] == "Foreign exchange rate for EUR/USD not found as of 2"

# Unit tests for class FXRate

# Generated at 2022-06-21 20:23:27.656433
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    :return: Nothing.
    """
    import datetime
    from pypara.currencies import Currencies
    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert e.ccy1 == Currencies["EUR"]
    assert e.ccy2 == Currencies["USD"]
    assert e.asof == datetime.date.today()


# Generated at 2022-06-21 20:23:29.384676
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .services import FXMemoryService
    service = FXMemoryService()
    assert isinstance(service, FXRateService)

# Unit tests for FXRate

# Generated at 2022-06-21 20:23:33.513847
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal(2))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal(0.5))

    if ~nrate != rrate:
        raise RuntimeError("Inverted FX rate must be equal to the expected value.")


# Generated at 2022-06-21 20:23:43.451523
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of :class:`FXRateService`.
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Define the FX rate service:
    class MockFXRateService(FXRateService):

        """
        Provides a mock foreign exchange rate service.
        """


# Generated at 2022-06-21 20:23:50.151802
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:23:59.464160
# Unit test for method queries of class FXRateService

# Generated at 2022-06-21 20:24:01.293322
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, object)


# Generated at 2022-06-21 20:24:03.259283
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

FXRateService.__abstractmethods__ = frozenset({})  # type: ignore


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 20:24:10.793351
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-21 20:24:12.133279
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

test_FXRateService_queries()


# Generated at 2022-06-21 20:24:31.428156
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Given a type-safe FX rate service;
    from .services import FXRateServiceTypeSafe
    from .models.fxrates import FXRate
    
    service = FXRateServiceTypeSafe()
    assert isinstance(service, FXRateService)
    
    # When I query for EUR/USD as of today;
    rate = service.query(Currency("EUR"), Currency("USD"), Date("2019-12-27"))
    
    # Then rate is not None;
    assert rate is not None
    
    # And rate is an instance of FXRate;
    assert isinstance(rate, FXRate)
    
    # And rate is properly formed;
    assert rate.ccy1 == Currency("EUR")
    assert rate.ccy2 == Currency("USD")
    assert rate.value > Decimal("0.01")
    
    #

# Generated at 2022-06-21 20:24:37.883444
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for FXRateLookupError
    """
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.finance.fx import FXRateLookupError
    ## Try to create an instance
    try:
        FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
        assert True
    except:
        assert False # pragma: no cover
# ----------------------------------------------------------------------------------------------------------------------



# Generated at 2022-06-21 20:24:41.307733
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method :meth:`FXRateService.queries` of class :class:`FXRateService`.
    """
    pass

# Generated at 2022-06-21 20:24:41.827577
# Unit test for constructor of class FXRate
def test_FXRate():
    pass

# Generated at 2022-06-21 20:24:52.517981
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests creation of FXRateLookupError.
    """

    from pypara.currencies import Currencies
    from pypara.currencies.ext import EUR
    from pypara.currencies.ext import USD
    from pypara.currencies.ext import TRY

    from pypara.currencies.ext import today

    # The foreign exchange rates for the following dates are not available:
    for date in [today(-2), today(-1), today(1), today(2)]:
        for ccy1 in [EUR, USD, TRY]:
            for ccy2 in [EUR, USD, TRY]:
                if ccy1 == ccy2:
                    continue

                with pytest.raises(FXRateLookupError):
                    FXRateLookupError(ccy1, ccy2, date)


# Generated at 2022-06-21 20:25:01.021028
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:25:11.008358
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method :method:`FXRateService.queries`.
    """
    import datetime
    from collections import namedtuple
    from decimal import Decimal
    from unittest import mock

    from pypara.currencies import Currency, Currencies

    ccy1 = Currencies["TRY"]
    ccy2 = Currencies["EUR"]
    date = datetime.date(2019, 7, 6)
    rate = Decimal("0.0998")

    service = mock.create_autospec(FXRateService)
    FXRateService.default = service

    # mock query method to return pre-determined results:

# Generated at 2022-06-21 20:25:23.061776
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert isinstance(rate.ccy1, Currency)
    assert rate.ccy1 == Currencies["EUR"]
    assert isinstance(rate.ccy2, Currency)
    assert rate.ccy2 == Currencies["USD"]
    assert isinstance(rate.date, Date)
    assert rate.date == datetime.date.today()
    assert isinstance(rate.value, Decimal)
    assert rate.value == Decimal("2")
    rrate = ~rate
    assert isinstance(rrate, FXRate)
    assert rrate.ccy1 == Currencies["USD"]
    assert r

# Generated at 2022-06-21 20:25:26.306802
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:25:32.961029
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Eur, Usd
    from datetime import date

    class FixedFXRateService(FXRateService):
        """
        Defines a foreign exchange rate service that provides fixed, pre-populated FX rates.
        """

        #: Defines a collection of FX rates.

# Generated at 2022-06-21 20:25:54.237132
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    ccy1 == Currencies["EUR"]
    ccy2 == Currencies["USD"]
    date == datetime.date.today()
    value == Decimal("2")


# Generated at 2022-06-21 20:26:05.495399
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    r1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = r1
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == 2

    r2 = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    ccy3, ccy4, date, value = r2
    assert ccy3 == Currencies["USD"]
    assert ccy4 == Currencies["EUR"]
    assert date == datetime.date.today()

# Generated at 2022-06-21 20:26:11.426883
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:26:15.864804
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:26:23.030086
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime

    from decimal import Decimal

    from pypara.fxrates.memory import MemoryFXRateService
    from pypara.currencies import Currencies

    now = datetime.date.today()

    currs = [Currencies["EUR"], Currencies["USD"], Currencies["TRY"]]

    rates = [
        FXRate(currs[0], currs[1], now, Decimal("2")),
        FXRate(currs[0], currs[2], now, Decimal("4")),
        FXRate(currs[1], currs[2], now, Decimal("3")),
    ]

    store = MemoryFXRateService(rates)


# Generated at 2022-06-21 20:26:24.194131
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:26:34.891769
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fxrates import FixedFXRateService

    ## Given
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.datetime.today().date()
    value = Decimal("2")

    ## When

# Generated at 2022-06-21 20:26:41.591355
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    import random
    import datetime
    from decimal import Decimal
    import pytest
    from pypara.currencies import Currencies
    from pypara.exchange import FXRate, FXRateService

    ## Define a dummy FX rate service class:
    class DummyFXRateService(FXRateService):
        """
        Defines a dummy FX rate service class for testing.
        """

        def __init__(self, rates: Iterable[FXRate]):
            """
            Initializes the dummy FX rate service with a list of FX rates.
            """
            self._rates = dict(tuple(((tuple(q[0:3]), q) for q in rates)))


# Generated at 2022-06-21 20:26:51.370908
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    from .currencies import Currencies
    from .zeitgeist import Date
    from .conversions import FXRateLookupError
    from datetime import date
    today = date.today()
    obj = FXRateLookupError(Currencies.EUR, Currencies.USD, Date(today))
    assert obj.ccy1.name == "EUR"
    assert obj.ccy2.name == "USD"
    assert obj.asof.date == today
    assert isinstance(obj, FXRateLookupError)
    assert isinstance(obj, LookupError)
    assert isinstance(obj, ValueError)
    assert isinstance(obj, Exception)

# Generated at 2022-06-21 20:26:59.802978
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .commons.numbers import ZERO
    from .currencies import Currency, Currencies
    from .market.time import Date
    from .markets.fx import FXRate, FXRateLookupError
    from .markets.fx.services import FXRateService

    now = Date.today()

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2, asof) == (Currencies["EUR"], Currencies["USD"], now):
                return FXRate(ccy1, ccy2, asof, ZERO)
            return None


# Generated at 2022-06-21 20:27:39.541637
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService
    """
    from unittest.mock import patch
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.finmath.fx import FXRateService

    ## Declare the service:
    class TestFXRateService(FXRateService):
        @classmethod
        def query(cls, ccy1, ccy2, asof, strict=False):
            return Temporal(ccy1, asof, str(ccy1))

    ## Patch the service:
    with patch.object(FXRateService, "get_default_instance") as mock_get_default_instance:
        mock_get_default_instance.return_value = TestFXRateService()

        ## Test the service:

# Generated at 2022-06-21 20:27:45.346589
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:49.843413
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:28:02.580007
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    "Ensure the method queries of class FXRateService is working correctly"

    # Import required modules
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.currencies.services import CurrencyService
    from pypara.datetime.services import DateTimeService
    from pypara.markets.services import FXRateService

    # Get the default currency service
    curr_srv = CurrencyService.default
    dtime_srv = DateTimeService.default

    # Create a foreign exchange rate service
    fx_srv = FXRateService()

    # Create the first query
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()

# Generated at 2022-06-21 20:28:10.526390
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    if not (~nrate == rrate):
        raise AssertionError("Inverted FX rate calculations are problematic.")


# Generated at 2022-06-21 20:28:11.741317
# Unit test for constructor of class FXRateService
def test_FXRateService():
    FXRateService.default
#

# Generated at 2022-06-21 20:28:19.260671
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.
    """
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from .fx import FXRateLookupError
    from .variables import today
    error = FXRateLookupError(Currencies["USD"],Currencies["EUR"],Date(today()))
    error.ccy1 == Currencies["USD"]
    error.ccy2 == Currencies["EUR"]
    error.asof == Date(today())



# Generated at 2022-06-21 20:28:27.644782
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests if the __invert__ method of FXRate works as expected.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))



# Generated at 2022-06-21 20:28:37.791544
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pytest import raises
    from pypara.commons.exceptions import MethodNotImplementedError
    from pypara.currencies import Currencies
    from pypara.dates import DateFactory

    class TestFXRateService(FXRateService):

        #: Defines the foreign exchange data.
        __fx_data = dict()

        def __init__(self) -> None:
            self.__fx_data = dict()

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise MethodNotImplementedError(function="query", clazz="FXRateService", method="query")


# Generated at 2022-06-21 20:28:38.338626
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService()

# Generated at 2022-06-21 20:29:57.706793
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from .currencies import Currency
    from .dates import Date
    from .rates import FXRate

    # Define the test set:

# Generated at 2022-06-21 20:30:04.452744
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:30:16.781583
# Unit test for constructor of class FXRate
def test_FXRate():

    import datetime
    import unittest.mock
    from decimal import Decimal
    from unittest import TestCase
    from pypara.currencies import Currencies

    class FXRateTest(TestCase):
        def test_FXRate(self):
            self.assertEqual(FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2.0")).ccy1, Currencies["EUR"])
            self.assertEqual(FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2.0")).ccy2, Currencies["USD"])

# Generated at 2022-06-21 20:30:27.886960
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    from .rates import FXRateLookupError
    from .rates.services import FXRateService

    class DummyFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    ## No error:
    dummy = DummyFXRateService()
    dummy.query(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], asof=Date.now())

    ## FXRateLookupError should be raised:

# Generated at 2022-06-21 20:30:34.276696
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # ARRANGE
    class FXRateServiceMock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    # ACT
    x : FXRateService = FXRateServiceMock()
    # ASSERT
    assert x is not None

# Generated at 2022-06-21 20:30:41.074204
# Unit test for constructor of class FXRateService
def test_FXRateService():  # noqa: F811
    """
    Unit test for constructor of class FXRateService.
    """
    ## Import, instantiate, and test abstract class:
    from unittest import TestCase
    from unittest.mock import MagicMock

    class FXRateServiceTest(TestCase):
        @staticmethod
        def test_abstract():
            """
            Tests the FXRateService abstract class.
            """
            ## Instantiate abstract class:
            with self.assertRaises(TypeError):
                FXRateService()

            with self.assertRaises(TypeError):
                FXRateService(MagicMock())

    ## Run the test:
    FXRateServiceTest().test_abstract()



# Generated at 2022-06-21 20:30:45.699470
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:30:57.199058
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the FX rate service for method query.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.financials import FXRateService, FXRateLookupError

    ## Setup:
    class DummyService(FXRateService):
        """
        Provides a dummy FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns a dummy FX rate.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))


# Generated at 2022-06-21 20:31:03.603475
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    from pypara.fx.lookup import FXRateLookupError

    from pypara.fx.markets.memory import FXMarket

    mkt = FXMarket()

    date = datetime.date.today()

    rate = mkt.set_rates(Currencies["EUR"], Currencies["USD"], date, Decimal(2))

    res = mkt.query(Currencies["EUR"], Currencies["USD"], date)

    assert rate == res

    try:
        res = mkt.query(Currencies["EUR"], Currencies["USD"], date, strict=True)
    except FXRateLookupError:
        assert False


# Generated at 2022-06-21 20:31:09.942891
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies  # noqa: F401
    from pypara.temporals import Dates  # noqa: F401

    ## No exception raised:
    exception = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Dates.now())
    assert exception is not None
    assert exception.ccy1 == Currencies["EUR"]
    assert exception.ccy2 == Currencies["USD"]
    assert exception.date == Dates.now()
    assert str(exception) == f"Foreign exchange rate for EUR/USD not found as of {Dates.now()}."
