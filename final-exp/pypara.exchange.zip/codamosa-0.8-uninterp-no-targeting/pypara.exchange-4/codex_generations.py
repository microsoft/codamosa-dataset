

# Generated at 2022-06-21 20:22:11.114164
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-21 20:22:23.180943
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.fxrates import FXRateLookupError, FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: datetime.date, strict: bool = False) -> Optional[Decimal]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["USD"]:
                return ONE
            elif ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == datetime.date.today():
                return Decimal("0.5")

# Generated at 2022-06-21 20:22:26.586870
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class Foo(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False): ...
        def queries(self, queries, strict=False): ...
    assert Foo.default is None



# Generated at 2022-06-21 20:22:34.124109
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for :class:`FXRate`.
    """
    # Imports
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert isinstance(rate.ccy1, Currency)
    assert isinstance(rate.ccy2, Currency)
    assert isinstance(rate.date, datetime.date)
    assert isinstance(rate.value, Decimal)
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")

    rate = ~rate
    assert rate.cc

# Generated at 2022-06-21 20:22:45.055569
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rfxr = FXRateService()

    # Define some FX rates:
    rates = [
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2017, 1, 1), Decimal("1")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date(2017, 1, 1), Decimal("1")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date(2016, 12, 31), Decimal("0.99")),
    ]

    # Define some queries:

# Generated at 2022-06-21 20:22:55.772384
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class `FXRateLookupError`.
    """
    from pypara.currencies import Currency, Currencies
    from pypara.commons.zeitgeist import Date

    ## Initialization:
    date = Date(2020, 10, 25)
    error = FXRateLookupError(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], asof=date)

    ## Check:
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == date
    assert str(error) == f"Foreign exchange rate for EUR/USD not found as of {date}"



# Generated at 2022-06-21 20:22:57.407365
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.__main__ import run_test

    run_test(FXRateService)

# Generated at 2022-06-21 20:23:04.110028
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currency, Currencies
    from .temporals import Temporal, Temporals
    from .fxrates import FXRateService

    class Foo(FXRateService):
        def __init__(self): pass
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal): pass
        def queries(self, queries: Iterable[Tuple[Currency, Currency, Temporal]]): pass
        def asof(self, asof: Temporal): pass

    f = Foo()
    assert isinstance(f, FXRateService)
    assert isinstance(f, Foo)


# Generated at 2022-06-21 20:23:11.029099
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class FXRateService
    """
    # pylint: disable=unused-argument
    class _Foo(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            pass
        def queries(self, queries, strict = False):
            pass
    assert _Foo()

# Generated at 2022-06-21 20:23:12.800604
# Unit test for constructor of class FXRateService
def test_FXRateService():
    fx = FXRateService()
    assert fx is not None

# Generated at 2022-06-21 20:23:21.330684
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    return ~nrate == rrate


# Generated at 2022-06-21 20:23:30.908559
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests :method:`FXRateService.query` method.
    """
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(2)) if (ccy1, ccy2, asof) == (Currencies["EUR"], Currencies["USD"], datetime.date(2020, 1, 1)) else None

# Generated at 2022-06-21 20:23:38.465051
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-21 20:23:46.683995
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate( Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")
   


# Generated at 2022-06-21 20:23:57.981627
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .daterangetemporal import DateRangeTemporal
    from .fxrates import FXRateService, FXRateLookupError
    from .oracle import Oracle
    from .quandl import Quandl
    from .temporals import Temporals

    ## Setup the test cases:
    ccys = (Currency("EUR"), Currency("USD"), Currency("TRY"))
    dates = (Temporals.create_date("2019-01-01"), Temporals.create_date("2019-12-31"))

# Generated at 2022-06-21 20:24:07.033698
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    ## Define the test case method:
    def __test_FXRateLookupError(ccy1: Currency, ccy2: Currency, asof: Date):
        ## Create the error:
        error = FXRateLookupError(ccy1, ccy2, asof)

        ## Verify the error:
        assert error.ccy1 == ccy1
        assert error.ccy2 == ccy2
        assert error.asof == asof
        assert str(error) == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}"

    ## 1st test case:

# Generated at 2022-06-21 20:24:14.914603
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D202
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    r = FXRateService.default.query(Currencies["USD"], Currencies["EUR"], Date(2019, 12, 12))
    assert r.ccy1.code == "USD"
    assert r.ccy2.code == "EUR"
    assert r.date == Date(2019, 12, 12)
    assert r.value == Decimal("0.90")

# Generated at 2022-06-21 20:24:21.039753
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.fxrates import FXRateService
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency("EUR") and ccy2 == Currency("USD") and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None
    rate = TestFXRateService().query(Currency("EUR"), Currency("USD"), datetime.date.today())
    assert rate.ccy1 == Currency("EUR")
    assert rate.ccy2 == Currency("USD")

# Generated at 2022-06-21 20:24:22.183228
# Unit test for constructor of class FXRateService
def test_FXRateService(): # noqa: F811
    pass

# Generated at 2022-06-21 20:24:29.959772
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class FXRateService_impl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    try:
        FXRateService_impl()
    except Exception as e:
        assert False, f"Could no initialize an implementation of FXRateService: {e}"

# Generated at 2022-06-21 20:24:40.864009
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateServic
    """
    pass

# Generated at 2022-06-21 20:24:48.579499
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests constructor of class FXRateLookupError.
    """
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    except FXRateLookupError as exception:
        assert isinstance(exception, LookupError)
        assert exception.ccy1 == Currencies["EUR"]
        assert exception.ccy2 == Currencies["USD"]
        assert exception.asof == Date.today()

    return True


# Generated at 2022-06-21 20:24:53.699316
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    from .finance.fx import FXRateLookupError
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date())
    except FXRateLookupError as exc:
        assert repr(exc) == "FXRateLookupError('Foreign exchange rate for EUR/USD not found as of 1970-01-01')"


# Generated at 2022-06-21 20:25:01.076662
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    DummyFXRateService( )


# Generated at 2022-06-21 20:25:04.445567
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    from .testing import assert_constructor_fails_for, assert_method_for

    assert_constructor_fails_for(FXRateService, args={})
    assert_method_for(
        FXRateService,
        method="query",
        args={"ccy1": None, "ccy2": None, "asof": None},
        kwargs={"strict": False},
        raises=NotImplementedError,
        )
    assert_method_for(
        FXRateService,
        method="queries",
        args={"queries": None},
        kwargs={"strict": False},
        raises=NotImplementedError,
        )

# Generated at 2022-06-21 20:25:10.186535
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests method __invert__ of class FXRate:
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:25:17.141667
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:25:24.525031
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Basic:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    isinstance(rate, FXRate)
    rate.ccy1 == Currencies["EUR"]
    rate.ccy2 == Currencies["USD"]
    rate.date == datetime.date.today()
    rate.value == Decimal("2")

    ## Indexed:
    ccy1, ccy2, date, value = rate
    ccy1 == Currencies["EUR"]
    ccy2 == Currencies["USD"]
    date == datetime.date.today()
    value == Decimal("2")

    ## Inversion:

# Generated at 2022-06-21 20:25:35.087246
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the implementation of :method:`FXRateService.queries` method.
    """
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.fx_memory import FXMemoryService
    from pypara.temporal import Temporal

    ## Create rates:

# Generated at 2022-06-21 20:25:41.842933
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:26:04.477200
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.rates import FXRateLookupError
    eur, usd = Currencies['EUR'], Currencies['USD']
    date_ = date(2017, 1, 1)
    # Create a lookup error
    error = FXRateLookupError(eur, usd, date_)


# Generated at 2022-06-21 20:26:18.278843
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    from datetime import date
    from pypara.currencies import Currencies
    from .curves import CurveType
    from .rates import RateCurveService, RateCurveServiceCache

    ##
    ## Note: I tried to use unittest.mock.Mock.return_value and unittest.mock.sentinel.VALUE in this test;
    ##       but it did not work. Therefore, I had to hardcode the return values here.
    ##

    class FXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(Currencies["USD"], Currencies["EUR"], date(2019, 4, 9), 1)


# Generated at 2022-06-21 20:26:23.713193
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2018-11-12"



# Generated at 2022-06-21 20:26:34.493636
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date, timedelta
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.exchanges import FXRate
    from pypara.territories import Territory

    class ForTestingOnly(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if asof < date(2018, 1, 1) or asof > date(2018, 4, 1):
                return None
            if ccy1 == Currencies["USD"]:
                try:
                    return FXRate(Currencies["USD"], Currencies["EUR"], asof, Decimal("0.8"))
                except:
                    return None

# Generated at 2022-06-21 20:26:41.404383
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    # Mock FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == datetime.date(2018, 1, 1):
                return FXRate(Currencies["USD"], Currencies["EUR"], datetime.date(2018, 1, 1), Decimal("1"))
            return None


# Generated at 2022-06-21 20:26:51.374941
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.dates import Date
    from .currencies import Currency
    from .exceptions import NotImplementedError

    # This test is only implemented for demonstrating the interface.
    service = FXRateService()
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date()
    strict = False
    assert service.query(ccy1, ccy2, asof, strict) is None
    assert service.queries([(ccy1, ccy2, asof)], strict) is not None

    strict = True
    with NotImplementedError():
        service.query(ccy1, ccy2, asof, strict) or None
    with NotImplementedError():
        tuple(service.queries([(ccy1, ccy2, asof)], strict))

# Generated at 2022-06-21 20:26:59.589718
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """
    # noinspection PyProtectedMember
    from .currencies import Currencies
    from .commons.zeitgeist import Today
    ccy1, ccy2, asof = Currencies["EUR"], Currencies["USD"], Today()
    error = FXRateLookupError(ccy1, ccy2, asof)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert error.args == (error.message,)
    assert str(error) == error.message


# Generated at 2022-06-21 20:27:06.805072
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():  # noqa: D102,D103
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:27:12.423131
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    import datetime

    from pypara.currencies import Currencies

    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == datetime.date.today()


# Generated at 2022-06-21 20:27:18.587816
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class DummyFXRateService(FXRateService):
        pass

    dummy_fxrate_service = DummyFXRateService()
    assert isinstance(dummy_fxrate_service, FXRateService)



# Generated at 2022-06-21 20:27:59.231285
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:28:05.913272
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert nrate[0] == Currencies["EUR"]
    assert nrate[1] == Currencies["USD"]
    assert nrate[2] == datetime.date.today()
    assert nrate[3] == Decimal("2")
    assert ~nrate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))



# Generated at 2022-06-21 20:28:17.543981
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporals import Date

    from .currencies import Currencies

    from .services import FXRateService

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, date, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and date == Date(2019, 9, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2019, 9, 1), Decimal("1.1"))
            return None

        def queries(self, queries, strict=False):
            for currency1, currency2, date in queries:
                yield self.query(currency1, currency2, date, strict)

    EUR = Currencies["EUR"]
    USD = Currencies["USD"]

    service = TestFXRateService

# Generated at 2022-06-21 20:28:22.229017
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-21 20:28:24.802869
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    print("Unit test for method query of class FXRateService")
    assert True


# Generated at 2022-06-21 20:28:36.361502
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService abstract class.
    """
    ## Setup:
    from unittest import TestCase
    from pypara.currencies import Currencies, CurrencyMismatchError
    from pypara.temporal import Timeframes, TemporalTypeError

    class FXRateServiceImpl(FXRateService):

        """
        Serves foreign exchange rates.
        """


# Generated at 2022-06-21 20:28:43.572399
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .temporal import Date
    from .money import Money
    from .fxrates import FXRate
    from .services import FXRateService
    import datetime

    # Check if FXRate works for valid data
    rate1 = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1.1"))
    assert rate1.ccy1 == Currencies["EUR"]
    assert rate1.ccy2 == Currencies["USD"]
    assert rate1.date == datetime.date.today()
    assert rate1.value == Decimal("1.1")
    assert rate1.__invert__().value == Decimal("0.909091")

    # Check if FXRate works for invalid data

# Generated at 2022-06-21 20:28:49.759409
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 10, 18), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == Date(2018, 10, 18)
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:28:56.669833
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-21 20:29:03.453574
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .datetime import date

    class MockFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            self._rates = dict(((fx[0], fx[1], fx[2]), fx) for fx in rates)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return self._rates.get((ccy1, ccy2, asof))


# Generated at 2022-06-21 20:30:27.753514
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit-test for method queries of class :class:`FXRateService`.
    """
    ## Imports & params:
    from datetime import date
    import pytest
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    ## Define a stub for testing:
    class Stub(FXRateService):
        def __init__(self, rates: Iterable[Tuple[str, str, date, float]]):
            self.rates = [
                FXRate(Currencies[ccy1], Currencies[ccy2], dte, Decimal(value))
                for ccy1, ccy2, dte, value in rates
            ]


# Generated at 2022-06-21 20:30:32.928677
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Date
    with pytest.raises(FXRateLookupError) as e:
        raise FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date(2018, 1, 1))
    assert e.value.args[0] == "Foreign exchange rate for USD/EUR not found as of 2018-01-01"


# Generated at 2022-06-21 20:30:37.554037
# Unit test for constructor of class FXRate
def test_FXRate():
    ## Test constructor:
    assert FXRate(Currency('EUR'), Currency('USD'), Date('2018-01-01'), 1) is not None

    ## Test inverted value:
    assert ~FXRate(Currency('EUR'), Currency('USD'), Date('2018-01-01'), 1) == FXRate(Currency('USD'), Currency('EUR'), Date('2018-01-01'), 1)


# Generated at 2022-06-21 20:30:45.027814
# Unit test for constructor of class FXRate
def test_FXRate():

    with pytest.raises(ValueError):
        FXRate(object(), object(), object(), object())

    with pytest.raises(ValueError):
        FXRate(object(), object(), Date.today(), Decimal("1"))

    with pytest.raises(ValueError):
        FXRate(Currency(), object(), Date.today(), Decimal("1"))

    with pytest.raises(ValueError):
        FXRate(Currency(), Currency(), object(), Decimal("1"))

    with pytest.raises(ValueError):
        FXRate(Currency(), Currency(), Date.today(), object())

    with pytest.raises(ValueError):
        FXRate(Currency(), Currency(), Date.today(), ZERO)


# Generated at 2022-06-21 20:30:56.458245
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests some properties of the query method of the FXRateService.
    """
    from pypara.currencies import Currencies

    # Define a mocked FXRateService
    class FXRateService_Mock(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    # Define a query:
    query = FXRateService.TQuery(Currencies["EUR"], Currencies["USD"], Date.now())
    assert isinstance(query, FXRateService.TQuery)

    # Check that we cannot pass a tuple of the wrong length:

# Generated at 2022-06-21 20:31:06.627728
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    import itertools
    from unittest import TestCase
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRate, FXRateService, ONE, ZERO

    class MockRateService(FXRateService):
        """
        Provides a mock FX rate service implementation.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("42") if ccy1 != ccy2 else ONE)


# Generated at 2022-06-21 20:31:13.044288
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """

    class MockFXRateService(FXRateService):
        """
        Provides a mock implementation of the FXRateService class.
        """

        def __init__(self, rates: Iterable[FXRate]):
            """
            Initializes the FX rate service.
            """
            self._rates = rates


# Generated at 2022-06-21 20:31:23.002974
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests that the FX rate lookup service should work as expected.
    """
    from decimal import Decimal
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.fx.fx_rate import FXRateLookupError, FXRateService, FXRate

    ## Mocking the abstract class:
    mock_fxrate_service = mock.Mock(spec_set=FXRateService)
    mock_fxrate_service.query.return_value = FXRate.of(Currencies["EUR"], Currencies["USD"], Date(2017, 1, 1), Decimal("2"))

    ## Testing the fxrate service:

# Generated at 2022-06-21 20:31:32.663877
# Unit test for method queries of class FXRateService

# Generated at 2022-06-21 20:31:34.000958
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert issubclass(FXRateService, metaclass=ABCMeta)