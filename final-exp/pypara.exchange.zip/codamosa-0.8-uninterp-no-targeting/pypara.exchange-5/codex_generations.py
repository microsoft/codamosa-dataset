

# Generated at 2022-06-21 20:22:21.342380
# Unit test for constructor of class FXRate
def test_FXRate():
    # Arrange
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()
    value = Decimal("2")

    # Act
    rate = FXRate(ccy1, ccy2, date, value)

    # Assert
    assert ccy1 == rate.ccy1
    assert ccy2 == rate.ccy2
    assert date == rate.date
    assert value == rate.value


if __name__ == "__main__":
    test_FXRate()

# Generated at 2022-06-21 20:22:27.405875
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import CURRENCIES
    from .services.mock import MockFXRateService
    from .temporal import LocalDate

    ## Create the service:
    service = MockFXRateService()

    ## Available:
    assert service.query(CURRENCIES["USD"], CURRENCIES["TRY"], LocalDate.of(2018, 1, 23)) == FXRate(CURRENCIES["USD"], CURRENCIES["TRY"], LocalDate.of(2018, 1, 23), Decimal("3.75"))
    assert service.query(CURRENCIES["TRY"], CURRENCIES["USD"], LocalDate.of(2018, 1, 23)) == FXRate(CURRENCIES["TRY"], CURRENCIES["USD"], LocalDate.of(2018, 1, 23), Decimal("0.26"))

# Generated at 2022-06-21 20:22:39.353964
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal

    # Check if implementation is unable to calculate the FX rate
    class FXRateServiceImplementation(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return None

    fx_rate_service_impl = FXRateServiceImplementation()
    strict_rate = fx_rate_service_impl.query("USD", "TRY", date(2019, 5, 1), True)
    non_strict_rate = fx_rate_service_impl.query("USD", "TRY", date(2019, 5, 1), False)

    assert strict_rate is None
    assert non_strict_rate is None

    # Check if implementation is able to calculate the FX rate

# Generated at 2022-06-21 20:22:43.939455
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():  # pragma: no cover
    from .currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date("2018-06-06"))
    except FXRateLookupError as error:
        assert isinstance(error.ccy1, Currency)
        assert isinstance(error.ccy2, Currency)
        assert isinstance(error.asof, Date)


# Generated at 2022-06-21 20:22:49.102690
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest.mock import patch
    from .currencies import Currency

    with patch.object(FXRateService, "query"):
        FXRateService.query.return_value = None
        FXRateService.query(Currency(), Currency(), None)
        FXRateService.query.assert_called_once()


# Generated at 2022-06-21 20:22:59.678683
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate1 = FXRate(Currencies["EUR"], Currencies["USD"], Date.of(2018, 1, 25), Decimal("2"))
    rate2 = FXRate(Currencies["USD"], Currencies["EUR"], Date.of(2018, 1, 25), Decimal("0.5"))

    assert rate1.ccy1 == Currencies["EUR"]
    assert rate1.ccy2 == Currencies["USD"]
    assert rate1.date == Date.of(2018, 1, 25)
    assert rate1.value == Decimal("2")

    assert rate2.ccy1 == Currencies["USD"]
    assert rate2.ccy2 == Currencies["EUR"]
    assert rate2.date == Date.of(2018, 1, 25)

# Generated at 2022-06-21 20:23:05.164499
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import LocalDate
    from .exceptions import FXRateLookupError

    ccy1 = Currencies.get("EUR")
    ccy2 = Currencies.get("USD")
    dt = LocalDate(2018, 1, 1)
    error = FXRateLookupError(ccy1, ccy2, dt)

    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == dt
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2018-01-01"


# Generated at 2022-06-21 20:23:18.224257
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the foreign exchange rate service method query.
    """
    from unittest import TestCase, main
    from unittest.mock import patch
    from decimal import Decimal
    from datetime import date
    from typing import Tuple
    from pypara.currencies import Currencies
    from pypara.money import Money
    from pypara.fx import FXRateService, FXRateLookupError


# Generated at 2022-06-21 20:23:26.412883
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import unittest

    class FXRateServiceTest(unittest.TestCase):
        def test_docs(self) -> None:
            import doctest
            doctest.testmod(verbose=True)

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(FXRateServiceTest))
    unittest.TextTestRunner().run(suite)


# Execute the unit tests:
if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 20:23:33.467011
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.commons.zeitgeist import Temporals
    from pypara.currencies import Currencies
    from pypara.fx.fxtable import FXTable, FXTableEntry

    # Construct the test cases:
    tdate1 = datetime.date(2000, 1, 1)
    tdate2 = datetime.date(2000, 2, 1)
    tc1 = FXTableEntry(Currencies["EUR"], Currencies["USD"], Temporals["monthly"].floor(tdate1), Decimal("1.1"))
    tc2 = FXTableEntry(Currencies["USD"], Currencies["EUR"], Temporals["monthly"].floor(tdate1), Decimal("0.90"))

# Generated at 2022-06-21 20:23:41.042290
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()

    nrate = FXRate(ccy1, ccy2, date, Decimal("10"))
    rrate = FXRate(ccy2, ccy1, date, Decimal("0.1"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:23:48.678436
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency,Currencies
    from .commons.zeitgeist import Date
    from .fxrates import FXRateService
    from decimal import Decimal
    import datetime

    # Mocks:
    class Service(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False) -> Optional[FXRate]:
            if ccy1 == ccy2 and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("1"))
            else:
                return FXRate(ccy1, ccy2, asof, Decimal("2.5"))


# Generated at 2022-06-21 20:23:52.373825
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    >>> test_FXRateService()
    """
    fx_rate_service = FXRateService()
    with pytest.raises(TypeError):
        fx_rate_service.query(None, None, None)

# Generated at 2022-06-21 20:24:04.098487
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import CurrencyPair
    from .commons.zeitgeist import Date
    from .commons.numbers import ZERO
    from .services.fxrates import FXRateLookupError, FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False) -> None:
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)

    fxrates = TestFXRateService()

    pair = CurrencyPair("EUR", "USD")
    date = Date.of(2017, 8, 11)


# Generated at 2022-06-21 20:24:13.970476
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ccy1 = Currency.of(name="EUR", country="EU", code="978", symbol="€", exponent=2)
    ccy2 = Currency.of(name="USD", country="US", code="840", symbol="$", exponent=2)
    date = Date.of(year=2020, month=12, day=24)
    err = FXRateLookupError(ccy1, ccy2, date)
    assert str(err) == "Foreign exchange rate for ₺/€ not found as of 2020-12-24"
    assert err.ccy1 == ccy1
    assert err.ccy2 == ccy2
    assert err.asof == date


# Generated at 2022-06-21 20:24:18.817503
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:24:26.880358
# Unit test for constructor of class FXRate
def test_FXRate():

    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date(2018, 1, 1), Decimal("2"))

    assert isinstance(rate, FXRate)
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == date(2018, 1, 1)
    assert rate[3] == Decimal("2")



# Generated at 2022-06-21 20:24:28.329324
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    fx_service = FXRateService()
    assert fx_service is not None

# Generated at 2022-06-21 20:24:35.229384
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for :class:`FXRateService`.
    """
    ## Define test constants:
    ccy1 = ccy2 = None
    asof = Date(2020, 1, 1)

    ## Should be able to create instances via its constructor:
    FXRateService()

    ## Should be able to call query:
    FXRateService().query(ccy1, ccy2, asof)
    FXRateService().queries([(ccy1, ccy2, asof)])



# Generated at 2022-06-21 20:24:40.495830
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    ## Set up a positive FX rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Set up a reversed FX rate:
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    ## The inverted FX rate must be the reversed FX rate:
    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:55.145711
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main, mock

    # For making mock iterables:
    def iters(value):
        # noinspection PyShadowingBuiltins
        return (i for i in value)

    # For making mock FX rate queries with ease:
    class MockQueries:

        def __init__(self, *rates):
            self.rates = rates

        def __iter__(self):
            return ((rate[0], rate[1], rate[2]) for rate in self.rates)

    # For making mock FX rate service with ease:

# Generated at 2022-06-21 20:24:56.447801
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Add your code here
    pass

# Generated at 2022-06-21 20:25:07.949264
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    '''
    Foreign Exchange Rate Inversion Test.
    '''
    ## Import packages:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Initialize FX rates:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    ## Test FX rate inversion:
    try:
        assert(~nrate == rrate)
        print("Inversion test for FX rate has passed.")
    except:
        print("Inversion test for FX rate has failed.")

test_FXRate___invert__()

# Generated at 2022-06-21 20:25:15.873104
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from flask import Flask
    from injector import singleton, inject, Injector

    app = Flask(__name__)

    @singleton
    class FXRateFactory:
        @staticmethod
        def of(ccy1: Currency, ccy2: Currency, date: Date, value: Decimal) -> FXRate:
            return FXRate(ccy1, ccy2, date, value)

    class FXRateService(FXRateService):
        _fxrates = []

        @inject
        @ccy1.default
        @ccy2.default
        @asof.default
        def __init__(self, fxrates):
            self._fxrates = fxrates


# Generated at 2022-06-21 20:25:23.785865
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    nrate = FXRate(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], date=datetime.date.today(), value=Decimal("2"))
    rrate = FXRate(ccy1=Currencies["USD"], ccy2=Currencies["EUR"], date=datetime.date.today(), value=Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-21 20:25:34.327727
# Unit test for constructor of class FXRateLookupError

# Generated at 2022-06-21 20:25:41.951453
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services import InMemoryFXRateService

    ## Create the FX rate service:
    service = InMemoryFXRateService()

    ## Test for exact match for a currency pair and date:
    rate = service.query(Currencies["EUR"], Currencies["USD"], date(2019, 1, 1))
    assert rate == FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 1, 1), Decimal("2.0"))

    ## Test for inexact match (smaller) for a currency pair and date:
    rate = service.query(Currencies["EUR"], Currencies["USD"], date(2018, 12, 31))

# Generated at 2022-06-21 20:25:52.490502
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests queries method of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Datetime

    class TestService(FXRateService):
        """
        Provides a test implementation of the FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """

# Generated at 2022-06-21 20:25:53.528345
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-21 20:26:03.043879
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    import datetime

    er = FXRateLookupError(ccy1=Currencies["USD"], ccy2=Currencies["EUR"], asof=datetime.date.today())

    assert er.__class__.__name__ == "FXRateLookupError"
    assert er.args[0] == "Foreign exchange rate for USD/EUR not found as of 2019-03-29"
    assert er.ccy1 == Currencies["USD"]
    assert er.ccy2 == Currencies["EUR"]
    assert str(er.asof) == str(datetime.date.today())


# Generated at 2022-06-21 20:26:18.664845
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.fx import FXRate, FXRateService

    class MockFXRateService(FXRateService):
        """
        Provides a mock foreign exchange rate service.
        """


# Generated at 2022-06-21 20:26:26.157945
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate, "__invert__ method is not working."


# Generated at 2022-06-21 20:26:28.957957
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from datetime import date
    fxrate_service = FXRateService()
    res = fxrate_service.queries(queries=((Currencies["EUR"], Currencies["USD"], date.today()),))
    assert res is not None

# Generated at 2022-06-21 20:26:35.533264
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    # End of class FXRateServiceImpl

    assert FXRateService.default is None
    FXRateService.default = FXRateServiceImpl()


# Generated at 2022-06-21 20:26:43.229657
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:26:55.590058
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Create a sample FX rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    # Make sure that it is a NamedTuple:
    assert isinstance(rate, tuple)

    # Make sure that we have expected properties:
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")

    # Make sure __invert__ returns the expected FX rate:

# Generated at 2022-06-21 20:27:00.192887
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    import datetime

    from decimal import Decimal

    from .currencies import Currencies
    from .fx import FXRate

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:08.468852
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    rate = FXRate(Currencies["EUR"],Currencies["USD"],datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-21 20:27:13.373447
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-21 20:27:14.695529
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    pass


# Generated at 2022-06-21 20:27:44.837746
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal, ROUND_HALF_UP
    from pypara.currencies import Currencies
    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2").quantize(Decimal("0.01"),ROUND_HALF_UP))
    rate_inverse = ~rate
    assert rate_inverse[0] == Currencies["USD"]
    assert rate_inverse[1] == Currencies["EUR"]
    assert rate_inverse[2] == datetime.date.today()
    assert rate_inverse[3] == Decimal("0.5").quantize(Decimal("0.01"),ROUND_HALF_UP)



# Generated at 2022-06-21 20:27:49.404050
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__(): # noqa: D103
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:28:02.445337
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest
    from pypara.currencies import Currency, Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.fxrates import FXRateLookupError

    ## Construct the error:
    exc = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())

    ## Check properties:
    assert isinstance(exc, LookupError)
    assert isinstance(exc.args, tuple)
    assert len(exc.args) == 1
    assert isinstance(exc.args[0], str)
    assert exc.ccy1 == Currencies["EUR"]
    assert exc.ccy2 == Currencies["USD"]
    assert exc.asof == Date.today()

# Generated at 2022-06-21 20:28:10.773702
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from datetime import date
    from pypara.currencies import Currencies
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], date.today())
    except FXRateLookupError as err:
        assert err.ccy1 == Currencies["EUR"]
        assert err.ccy2 == Currencies["USD"]
        assert err.asof == date.today()
        assert str(err) == f"Foreign exchange rate for EUR/USD not found as of {date.today()}"


# Generated at 2022-06-21 20:28:16.195628
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert str(FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())) == "Foreign exchange rate for EUR/USD not found as of 2019-06-26"  # noqa: E501



# Generated at 2022-06-21 20:28:20.428599
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:28:28.794752
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies    
    
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")
    print(rate)
    

# Generated at 2022-06-21 20:28:38.704134
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import USD, EUR, TRY
    from .currencies.cache import CurrencyCache, CurrencyCacheError
    from .currencies.tests.test_CurrencyCache import test_CurrencyCache_lookup
    from .temporal import TemporalDimension, Temporal, Date
    from .temporal.tests.test_TemporalDimension import test_TemporalDimension_of
    from .temporal.tests.test_Temporal import test_Temporal_of
    from .temporal.tests.test_TemporalBuilder import test_TemporalBuilder_of
    from .temporal.tests.test_Date import test_Date_of
    from .temporal.tests.test_DateRange import test_DateRange_of
    from .temporal.tests.test_TimeSpan import test_TimeSpan_of

# Generated at 2022-06-21 20:28:48.793521
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase
    from unittest.mock import Mock, patch

    class MyTestCase(TestCase):

        def setUp(self) -> None:
            self.queries = Mock()
            self.strict = Mock()
            self.rate = Mock()

            self.fxrate_service = FXRateService()

        def test_query(self) -> None:
            with patch.object(FXRateService, "query", return_value=self.rate) as _query:
                self.assertIs(self.rate, self.fxrate_service.query(self.queries, self.strict))
                _query.assert_called_with(self.queries, self.strict)


# Generated at 2022-06-21 20:28:58.761067
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.lookup import Lookup
    from pypara.services.fxrates import FXRateService, FXRate

    # Mockup for FXRateService.query():
    def query(ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
        rate = rates.get((ccy1, ccy2, asof))
        if rate is None and strict:
            raise FXRateLookupError(ccy1, ccy2, asof)
        return rate

    # Mockup for FXRateService class:

# Generated at 2022-06-21 20:29:44.022595
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the :class:`FXRateLookupError` constructor.
    """
    # noinspection PyUnusedLocal
    try:
        # noinspection PyUnreachableCode
        try:
            raise FXRateLookupError
        except TypeError:
            raise
    except TypeError:
        pass


# Generated at 2022-06-21 20:29:56.368997
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies import Currency
    from .temporal import Temporal
    from .currencies import Currency


# Generated at 2022-06-21 20:29:59.607562
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    err = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert isinstance(err, LookupError)


# Generated at 2022-06-21 20:30:04.981891
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import unittest

    class TestFXRateService(unittest.TestCase):
        def test_abstraction(self):
            with self.assertRaises(TypeError):
                fxrate_service = FXRateService()

    unittest.main()

# Generated at 2022-06-21 20:30:12.512477
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Should create inverted rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal(2))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal(0.5))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:30:22.987935
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the :method:`FXRateService.query` method of :class:`FXRateService`.
    """
    
    from . import currencies

    class TestFXRateService(FXRateService):
        """
        A test implementation of :class:`FXRateService` class
        """

        def __init__(self, dict1={}):
            self._dict = dict1

        def query(
            self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False
        ) -> Optional[FXRate]:
            return self._dict.get((ccy1, ccy2, asof), None)


# Generated at 2022-06-21 20:30:33.910544
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This is a test function for method queries of class FXRateService.
    """

    import pytest

    ## Define a test service:
    class TestService(FXRateService):

        def __init__(self, data: Iterable[FXRate]) -> None:
            ## Keep the FX rates:
            self._data: Iterable[FXRate] = data

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            data = list(self._data)


# Generated at 2022-06-21 20:30:39.950225
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    >>> import datetime
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currencies
    >>> urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    >>> urate.ccy1 == Currencies["EUR"]
    True
    >>> urate.ccy2 == Currencies["USD"]
    True
    >>> urate.date == datetime.date.today()
    True
    >>> urate.value == Decimal("2")
    True
    """
    pass

# Generated at 2022-06-21 20:30:41.722711
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Just a test, to make sure mypy sees test functions.
    """

# Generated at 2022-06-21 20:30:46.442128
# Unit test for constructor of class FXRate
def test_FXRate():
    today = datetime.date.today()
    rate = FXRate(Currencies["EUR"], Currencies["USD"], today, Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == today
    assert rate.value == Decimal("2")