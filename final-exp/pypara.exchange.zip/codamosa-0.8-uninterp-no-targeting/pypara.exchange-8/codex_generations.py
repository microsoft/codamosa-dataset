

# Generated at 2022-06-21 20:22:11.305283
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert True

# Generated at 2022-06-21 20:22:13.941224
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert hasattr(FXRateService, 'default')
    assert hasattr(FXRateService, 'TQuery')
    assert hasattr(FXRateService, 'query')
    assert hasattr(FXRateService, 'queries')


# Generated at 2022-06-21 20:22:21.540756
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-21 20:22:30.962751
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests queries method of the FXRateService.
    """
    from decimal import Decimal
    from unittest import mock
    from pypara.dateutils import Temporals
    from pypara.currencies import Currencies

    # Create a mock FX rate service object
    with mock.patch.object(FXRateService, "query", return_value=FXRate(
        Currencies["USD"], Currencies["JPY"], Temporals["2020-01-01"], Decimal("111.1")
    )):
        rates = list(FXRateService.default.queries(
            queries=[
                (Currencies["USD"], Currencies["JPY"], Temporals["2020-01-01"]),
                (Currencies["USD"], Currencies["EUR"], Temporals["2020-01-01"])
            ]
        ))



# Generated at 2022-06-21 20:22:39.953734
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currency
    error = FXRateLookupError(Currency.of("USD"), Currency.of("EUR"), datetime.date.today())
    assert repr(error) == repr(
        "FXRateLookupError(ccy1=Currency(code='USD'), ccy2=Currency(code='EUR'), asof=datetime.date(2020, 2, 18))"
    )
    assert str(error) == "Foreign exchange rate for USD/EUR not found as of 2020-02-18"



# Generated at 2022-06-21 20:22:47.567369
# Unit test for constructor of class FXRateLookupError

# Generated at 2022-06-21 20:22:54.211618
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:59.425176
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies

    import datetime
    from decimal import Decimal

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-21 20:23:05.696037
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.zeitgeist import Now
    from .currencies import Currencies
    from .services.fxrates.eurofxref import EuroFXRefProvider
    from unittest import TestCase
    from unittest.mock import call, MagicMock, patch

    class FXRateServiceTestCase(TestCase):

        @patch("pypara.services.fxrates.eurofxref.load_parsed_xml")
        def test_query(self, mock_load_parsed_xml: MagicMock) -> None:
            # Arrange:
            provider = EuroFXRefProvider()

# Generated at 2022-06-21 20:23:09.481458
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## Test case 1:
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date(2019, 2, 22)
    error = FXRateLookupError(ccy1, ccy2, asof)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert str(error) == f"Foreign exchange rate for EUR/USD not found as of 2019-02-22"


# Generated at 2022-06-21 20:23:17.776800
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class FXRateLookupError.
    """
    from .currencies import Currencies
    from .temporal import Date

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    except FXRateLookupError as ex:
        assert ex.ccy1 == Currencies["EUR"]
        assert ex.ccy2 == Currencies["USD"]
        assert ex.asof == Date.today()


# Generated at 2022-06-21 20:23:28.207465
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    import pytest

    class Test1(object):
        ccy1 = Currencies["EUR"]
        ccy2 = Currencies["USD"]
        asof = datetime.date.today()
        exc = FXRateLookupError(ccy1, ccy2, asof)

        def test_message(self):
            assert str(self.exc) == \
                f"Foreign exchange rate for {self.ccy1}/{self.ccy2} not found as of {self.asof}"

    class Test2(object):
        ccy1 = Currencies["USD"]
        ccy2 = Currencies["EUR"]
        asof = datetime.date.today()

# Generated at 2022-06-21 20:23:39.036354
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests that constructor of class :class:`FXRateLookupError` works as expected.
    """
    ##
    ## Import:
    ##
    import datetime

    from pypara.currencies import Currency

    ## Define the dummy reference currency:
    refccy = Currency("EUR")

    ## Define the dummy date:
    refdate = datetime.date.today()

    ##
    ## Test no arguments exception:
    ##
    try:
        FXRateLookupError()
    except TypeError:
        pass
    except Exception as err:
        raise err

    ##
    ## Test correct arguments:
    ##

# Generated at 2022-06-21 20:23:43.198943
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.currencies.bases.fxrateservices import DictFXRateService

    service = DictFXRateService({
        (Currencies["EUR"], Currencies["USD"], date(2019, 1, 1)): Decimal("1.1"),
        (Currencies["USD"], Currencies["EUR"], date(2019, 1, 1)): Decimal("1.0")
    })

    queries = [
        (Currencies["EUR"], Currencies["USD"], date(2019, 1, 1)),
        (Currencies["USD"], Currencies["EUR"], date(2019, 1, 1)),
        (Currencies["EUR"], Currencies["USD"], date(2019, 1, 2))
    ]


# Generated at 2022-06-21 20:23:48.373217
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for class FXRate
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:23:55.137331
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    import itertools

    from decimal import Decimal

    from pypara.currencies import Currencies

    from .quotes import QuoteFactory, QuoteService

    ## Create some currencies:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    ## Create a date:
    asof = datetime.date.today()

    ## Create a quote service:
    factory = QuoteFactory(None)
    service = QuoteService(factory)
    service.set_quotes([(Currencies["EUR"], Currencies["USD"], asof, Decimal("2")), ])

    #: Create a foreign exchange service:
    service = FXRateService.default(service)

    #: Define a strict query:
    strict = True

    #: Query the foreign exchange rate:

# Generated at 2022-06-21 20:23:59.817144
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    
    from decimal import Decimal
    
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    
    assert(~nrate == rrate)
    
    
    

# Generated at 2022-06-21 20:24:00.787565
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

# Generated at 2022-06-21 20:24:07.721902
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest.mock import MagicMock, call
    from .temporal import Temporal

    ## Load dependencies:
    from .currencies import Currencies
    from .quotes.yahoo_fx import YahooFX

    ## Create instances:
    service1 = FXRateService()
    service2 = FXRateService()

    ## Check equality:
    assert service1 == service1
    assert service2 == service2
    assert service1 == service2
    assert service1 == YahooFX

    ## Check identity:
    assert service1 is service1
    assert service2 is service2

    ## Check if the default FX rate service has been set:
    assert FXRateService.default is not None
    assert FXRateService.default == YahooFX

    ## Mock the FX rate service:
    service = FXRateService()

# Generated at 2022-06-21 20:24:14.914797
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], Temporal.now(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], Temporal.now(), Decimal("0.5"))
    assert ~nrate == rrate  # noqa: B101


# Generated at 2022-06-21 20:24:25.381171
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:24:34.658468
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .temporal import Temporals
    import datetime

    # Test inverted rate
    rate1 = FXRate(Currencies["EUR"], Currencies["USD"], Temporals.date(datetime.date.today()), Decimal("2.5"))
    rate2 = FXRate(Currencies["USD"], Currencies["EUR"], Temporals.date(datetime.date.today()), Decimal("0.5"))
    assert rate1 == FXRate.of(Currencies["EUR"], Currencies["USD"], Temporals.date(datetime.date.today()), Decimal("2.5"))
    assert ~rate1 == rate2



# Generated at 2022-06-21 20:24:39.804398
# Unit test for constructor of class FXRate
def test_FXRate():
    from currencies import Currencies
    from datetime import date
    from decimal import Decimal

    EUR = Currencies['EUR']
    USD = Currencies['USD']

    today = date.today()
    FXRate(EUR, USD, today, Decimal("1"))


# Generated at 2022-06-21 20:24:45.919999
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:55.111907
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    ## Mock an FX rate service:
    class MockService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = True) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, Decimal("1"))
            if ccy1 == Currency("EUR") and ccy2 == Currency("USD"):
                return FXRate(ccy1, ccy2, asof, Decimal("2.0000"))
            if ccy1 == Currency("USD") and ccy2 == Currency("EUR"):
                return FXRate(ccy1, ccy2, asof, Decimal("0.5000"))
           

# Generated at 2022-06-21 20:24:59.444999
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests FXRateService constructor.
    """
    FXRateService.default = None
    try:
        assert FXRateService.default is None
    finally:
        del FXRateService.default



# Generated at 2022-06-21 20:25:07.338171
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    eur = Currencies["EUR"]
    usd = Currencies["USD"]
    asof = datetime.date.today()
    e = FXRateLookupError(eur, usd, asof)
    assert e.ccy1 == eur
    assert e.ccy2 == usd
    assert e.asof == asof
    assert str(e) == f"Foreign exchange rate for EUR/USD not found as of {asof}"


# Generated at 2022-06-21 20:25:08.946519
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None

# Generated at 2022-06-21 20:25:16.357562
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            elif ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))

# Generated at 2022-06-21 20:25:22.169385
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    import datetime

    from pypara.currencies import Currencies
    assert isinstance(
        FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today()), FXRateLookupError
    )


# Generated at 2022-06-21 20:25:40.776410
# Unit test for constructor of class FXRate
def test_FXRate(): 
    from .currencies import Currencies
    from datetime import date
    from decimal import Decimal
    urate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    assert(urate.ccy1 == Currencies["EUR"])
    assert(urate.ccy2 == Currencies["USD"])
    assert(urate.date == date.today())
    assert(urate.value == Decimal("2"))
    

# Generated at 2022-06-21 20:25:50.326580
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of {}".format(datetime.date.today())

    try:
        raise FXRateLookupError(Currencies["USD"], Currencies["EUR"], datetime.date.today())
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for USD/EUR not found as of {}".format(datetime.date.today())


# Generated at 2022-06-21 20:25:57.815893
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from datetime import date

    try:
        raise FXRateLookupError(Currencies.USD, Currencies.EUR, date.today())
    except FXRateLookupError as error:
        assert str(error) == "Foreign exchange rate for USD/EUR not found as of 2010-08-19"
        assert error.ccy1 == Currencies.USD
        assert error.ccy2 == Currencies.EUR
        assert error.asof == date.today()


# Generated at 2022-06-21 20:26:03.440125
# Unit test for constructor of class FXRateService
def test_FXRateService():
    obj = FXRateService()
    query_result = obj.query(None, None, None, False)
    assert query_result is None, f"None expected, got {query_result}"
    queries_result = obj.queries(None, False)
    assert queries_result is not None, f"None expected, got {queries_result}"

# Generated at 2022-06-21 20:26:12.891116
# Unit test for constructor of class FXRate
def test_FXRate():
    # pylint: disable=missing-docstring
    import datetime
    import unittest

    from decimal import Decimal
    from pypara.currencies import Currency

    class FXRateTests(unittest.TestCase):
        def test_is_equal(self):
            self.assertEqual(
                FXRate(Currency("EUR", "EUR"), Currency("USD", "USD"), datetime.date(2016, 10, 10), Decimal(1)),
                FXRate(Currency("EUR", "EUR"), Currency("USD", "USD"), datetime.date(2016, 10, 10), Decimal(1)),
            )

# Generated at 2022-06-21 20:26:17.583452
# Unit test for constructor of class FXRate
def test_FXRate():

    from random import randint
    from datetime import date

    from .currencies import Currencies

    currencies = tuple(Currencies)
    today = date.today()
    fx_rate = FXRate(currencies[randint(0, len(currencies) - 1)], currencies[randint(0, len(currencies) - 1)], today, 2)

    assert fx_rate.ccy1 in currencies
    assert fx_rate.ccy2 in currencies
    assert fx_rate.date == today
    assert fx_rate.value == 2

# Generated at 2022-06-21 20:26:28.821292
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    # Define the currency pair for the test:
    EUR = Currencies["EUR"]
    USD = Currencies["USD"]

    # Define the date for the test:
    date = datetime.date.today()

    # Define the expected FX rate:
    rate = Decimal("2")

    # Generate the series of test queries:
    queries = [(EUR, USD, date), (USD, EUR, date)]

    # Define the FX rate service for the test:

# Generated at 2022-06-21 20:26:35.452604
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert(ccy1 == Currencies["EUR"])
    assert(ccy2 == Currencies["USD"])
    assert(date == datetime.date.today())
    assert(value == Decimal("2"))


# Generated at 2022-06-21 20:26:38.291486
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # Create an instance of class FXRateService
    svc = FXRateService()
    # Check if the instance is of type FXRateService
    assert isinstance(svc, FXRateService)

# Generated at 2022-06-21 20:26:46.760005
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date(2019, 1, 1)
    e = FXRateLookupError(ccy1, ccy2, asof)

    assert e.ccy1 == ccy1
    assert e.ccy2 == ccy2
    assert e.asof == asof

    assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2019-01-01"



# Generated at 2022-06-21 20:27:26.531601
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:36.932456
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currency
    from pypara.temporal import Date

    eur = Currency.EUR
    usd = Currency.USD
    gbp = Currency.GBP

    d0 = Date(2017, 1, 4, 0, 0, 0)
    d1 = Date(2017, 1, 1, 0, 0, 0)
    d2 = Date(2017, 1, 2, 0, 0, 0)
    d3 = Date(2017, 1, 3, 0, 0, 0)

    rates =     [FXRate(eur, usd, d0, 1.1), FXRate(eur, gbp, d0, 1.2), FXRate(usd, eur, d0, 1.3), FXRate(usd, gbp, d0, 1.4)]

# Generated at 2022-06-21 20:27:43.111828
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Just make sure we can instantiate class FXRateService, nothing else.
    """
    class Test(FXRateService):
        """
        A test FX rate service.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, iterable, strict=False):
            return []

    Test()



# Generated at 2022-06-21 20:27:48.140900
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-21 20:28:00.954979
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class FXRateService
    """
    from unittest.mock import Mock
    mock = Mock()
    mock.query = lambda _1, _2, _3: None  # type: ignore
    mock.queries = lambda _: []  # type: ignore
    fxrate_service1 = FXRateService()
    fxrate_service2 = FXRateService()
    assert fxrate_service1 is not fxrate_service2
    assert mock.query(1, 2, 3) is FXRateService.query(fxrate_service1, 1, 2, 3)
    assert mock.queries([(1, 2, 3)]) == FXRateService.queries(fxrate_service2, [(1, 2, 3)])


# Generated at 2022-06-21 20:28:02.310727
# Unit test for constructor of class FXRateService
def test_FXRateService():
    default = FXRateService.default
    assert default is not None

# Generated at 2022-06-21 20:28:08.166549
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    # Dataset:

# Generated at 2022-06-21 20:28:19.358634
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import abc
    from .commons.numbers import ZERO
    from .commons.zeitgeist import Date

    class MyService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    assert issubclass(MyService, abc.ABC)
    assert issubclass(MyService, FXRateService)
    assert MyService.__abstractmethods__ == {"query", "queries"}
    assert FXRateService.__abstractmethods__ == {"query", "queries"}
    assert FXRateService.default is None
    assert FXRateService.T

# Generated at 2022-06-21 20:28:27.233474
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:28:32.863105
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:29:47.184748
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate=FXRate(Currencies["EUR"],Currencies["USD"],datetime.date.today(),Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:29:54.276084
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:30:00.682665
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara import FXRateService

    class MockService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    ## Test:
    _ = MockService()

# Generated at 2022-06-21 20:30:13.971101
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    from datetime import date
    from typing import List
    from unittest import TestCase, TestLoader, TextTestRunner
    from decimal import Decimal

    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Temporal

    class TestFXRateServiceImpl(FXRateService):
        """
        Provides a testable abstract implementation of :class:`FXRateService`.

        This implementation converts USD to EUR and EUR to USD.
        """

        def __init__(self) -> None:
            """
            Initializes the test foreign exchange rate service.
            """
            self.usd2eur = FXRate(Currencies.USD, Currencies.EUR, date(2019, 1, 1), Decimal(".8"))
            self.eur2

# Generated at 2022-06-21 20:30:19.299557
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.services.ccyservice import CCYService
    from pypara.services.temporalservice import TemporalService

    service = CCYService()
    c1 = service["USD"]
    c2 = service["ARS"]
    d = TemporalService().today

    t = (c1, c2, d)

    assert FXRateService.TQuery == t

test_FXRateService()

# Generated at 2022-06-21 20:30:26.360059
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:30:36.473122
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal

    from .currencies import Currency
    from .temporal import Date

    from decimal import Decimal
    from datetime import date

    class MockFXRateService(FXRateService):
        # noinspection PyUnusedLocal
        def __init__(self):
            pass

        # noinspection PyUnusedLocal
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate.of(ccy1, ccy2, asof, Decimal("2"))

        # noinspection PyUnusedLocal
        def queries(self, queries, strict=False):
            for q in queries:
                yield FXRate.of(*q, Decimal("2"))

    ## Create mock service
    fs = Mock

# Generated at 2022-06-21 20:30:47.745627
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Create the rate with constructor:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    # Create the rate with static method:
    srate = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert rate == srate

    # Non-currency input:
    try:
        FXRate(1, Currencies["USD"], datetime.date.today(), Decimal("2"))
        assert False
    except ValueError:
        pass

    # Non-currency input:

# Generated at 2022-06-21 20:30:54.367001
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-21 20:30:59.679402
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate