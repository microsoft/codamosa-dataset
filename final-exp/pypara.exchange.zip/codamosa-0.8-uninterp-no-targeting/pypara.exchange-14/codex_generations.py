

# Generated at 2022-06-21 20:22:13.556503
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from datetime import date
    from decimal import Decimal

    from pypara.currencies import Currencies

    fx = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("1.5"))
    assert ~fx == FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666667"))


# Generated at 2022-06-21 20:22:21.973536
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService.
    """
    class _TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, queries, strict=False):
            return None

    assert ("_TestFXRateService", ) == _TestFXRateService.__mro__
    assert "default" in FXRateService.__dict__
    assert "FXRateService" == _TestFXRateService.__name__


# Generated at 2022-06-21 20:22:23.074258
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert isinstance(FXRateService, ABCMeta)

# Generated at 2022-06-21 20:22:30.094686
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .temporals import Temporals
    from .currencies import Currencies

    ## Setup the tests:
    d1 = Temporals.today()
    d2 = Temporals.today() + 365
    query = (Currencies["EUR"], Currencies["USD"], d1)
    service = FXRateService()

    ## Test the method:
    assert service.query(*query) is None

    ## Test the strict flag:
    with pytest.raises(FXRateLookupError):
        service.query(*query, strict=True)



# Generated at 2022-06-21 20:22:38.797266
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-21 20:22:45.254435
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal

    r1 = FXRate(Currencies["USD"], Currencies["TRY"], datetime.date.today(), Decimal("5.9"))
    assert r1.ccy1 == Currencies["USD"]
    assert r1.ccy2 == Currencies["TRY"]
    assert r1.date == datetime.date.today()
    assert r1.value == Decimal("5.9")



# Generated at 2022-06-21 20:22:57.034513
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """

    from unittest import TestCase, mock

    from decimal import Decimal
    from typing import Any
    from io import StringIO

    from pypara.finance.currencies import Currencies
    from pypara.finance.fx import FXRate, FXRateService

    _ = Any
    _ = StringIO

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-21 20:23:01.959563
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["TRY"], Currencies["USD"], datetime.date.today(), Decimal("6.3608"))
    rrate = FXRate(Currencies["USD"], Currencies["TRY"], datetime.date.today(), Decimal("0.1570"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:23:09.232978
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.fx import FXRateLookupError

    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], date.today()).args == \
        ("Foreign exchange rate for EUR/USD not found as of 2019-11-09",)

# Generated at 2022-06-21 20:23:10.731347
# Unit test for constructor of class FXRateService
def test_FXRateService():
    with pytest.raises(TypeError):
        FXRateService()

# Generated at 2022-06-21 20:23:17.445402
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-21 20:23:25.676845
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError(): # pragma: no cover
    from .currencies import Currency

    ## Create a new FX rate:
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    date = Date.today()
    error = FXRateLookupError(ccy1, ccy2, date)

    ## Check the FX rate:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == date
    assert isinstance(error.args, tuple)
    assert len(error.args) == 1
    assert error.args[0] == error.__str__()


# Generated at 2022-06-21 20:23:26.169553
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService()


# Generated at 2022-06-21 20:23:33.342608
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.rates import FXRate

    class SomeService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, date in queries:
                rate = self.query

# Generated at 2022-06-21 20:23:42.672968
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 5, 10), Decimal("1.12"))
    FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 5, 10), Decimal("1.12"))
    FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 5, 10), Decimal("1.12"))
    FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 5, 10), Decimal("1.12"))
    FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 5, 10), Decimal("1.12"))

# Generated at 2022-06-21 20:23:44.446368
# Unit test for constructor of class FXRateService
def test_FXRateService():
    with pytest.raises(TypeError):
        FXRateService()

# Generated at 2022-06-21 20:23:56.406948
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .dates import Temporals
    from .charsets import Charsets
    from .commons.enums import ParaStyle
    from .samples.temperatures import TemperatureService
    from .samples.phrases import PhraseService
    from .samples.fxrates import FXRateService
    from .samples.logger import LoggerService
    from .registry import Registry
    import datetime
    import decimal
    curr_svc = Currencies.default
    temp_svc = TemperatureService.default
    phrase_svc = PhraseService.default
    fxrate_svc = FXRateService.default
    logger_svc = LoggerService.default
    registry = Registry.default
    registry.register('Currencies', curr_svc)
    registry.register

# Generated at 2022-06-21 20:24:05.135502
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests method __invert__ of class FXRate.
    """

    # Import
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Create the FX rate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    # Assert
    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:16.616928
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporal import Temporal

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, Temporal.date(asof), Decimal("2"))

        def queries(self, queries, strict=False):
            for (ccy1, ccy2, asof) in queries:
                yield FXRate(ccy1, ccy2, Temporal.date(asof), Decimal("2"))


# Generated at 2022-06-21 20:24:22.499006
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as error:
        assert "Foreign exchange rate for EUR/USD not found as of" in str(error)


# Generated at 2022-06-21 20:24:34.907717
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:24:41.799467
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit tests for query method of class FXRateService.
    """
    from .tests.fxrateservice import TestFXRateService

    ## Test the simple scenario:
    svc = TestFXRateService()
    rate = svc.query("EUR", "USD", "2017-01-01")
    assert rate.ccy1.code == "EUR"
    assert rate.ccy2.code == "USD"
    assert rate.date == "2017-01-01"
    assert rate.value == Decimal("1.25")

    ## Test the missing rate scenario:
    rate = svc.query("EUR", "USD", "2017-01-02")
    assert rate is None

    ## Test the strict missing rate scenario:

# Generated at 2022-06-21 20:24:51.040404
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """ Tests constructor of class :class:`FXRateLookupError`. """

    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as exception:
        assert exception.ccy1 == Currencies["EUR"]
        assert exception.ccy2 == Currencies["USD"]
        assert exception.asof == datetime.date.today()
        assert str(exception) == "Foreign exchange rate for EUR/USD not found as of {asof}".format(asof=datetime.date.today())



# Generated at 2022-06-21 20:24:51.943694
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass

# Generated at 2022-06-21 20:24:54.377527
# Unit test for constructor of class FXRateService
def test_FXRateService():
    try:
        FXRateService()
    except:
        assert 1
    else:
        assert 0

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 20:24:59.236193
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .services import LocalFXRateService
    try:
        service = FXRateService()
        assert False
    except TypeError:
        assert True
    assert isinstance(LocalFXRateService(), FXRateService)



# Generated at 2022-06-21 20:25:05.406194
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporals import DateRange


# Generated at 2022-06-21 20:25:13.952826
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the FX queries method of :class:`FXRateService`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MockFXService(FXRateService):
        def query(
            self,
            ccy1: Currency,
            ccy2: Currency,
            asof: Date,
            strict: bool = False,
        ) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1.1"))
            else:
                return None


# Generated at 2022-06-21 20:25:20.592983
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:25:26.387963
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method.

    >>> service = FXRateService()
    >>> ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    >>> UnresolvedOverload:
    >>> <bound method FXRateService.queries of <class 'pypara.fx.services.__test__.TestFXRateService'>>
    >>> ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    """
    pass



# Generated at 2022-06-21 20:25:38.265220
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-21 20:25:49.390148
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRates
    from pypara.fx.services import InMemoryFXRateService

    assert FXRateService.default is None
    FXRateService.default = InMemoryFXRateService(FXRates)

    # GET EUR/USD FX RATE AS OF TODAY
    fxrate = FXRateService.default.query(Currencies["EUR"], Currencies["USD"], date.today(), strict=False)
    assert fxrate is not None
    assert fxrate.ccy1 == Currencies["EUR"]
    assert fxrate.ccy2 == Currencies["USD"]
    assert fxrate.value == Decimal("2")

    # GET EUR/USD FX RATE AS OF TODAY WITH THE STR

# Generated at 2022-06-21 20:25:52.032271
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class FXRateService.
    """

    assert hasattr(FXRateService, "default")

    assert FXRateService.default is None

# Generated at 2022-06-21 20:26:03.903855
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Construct a simple FX rate service:
    class _SimpleFXRateService(FXRateService):
        def __init__(self):
            self.rates = []  # type: List[FXRate]

        def add(self, ccy1: Currency, ccy2: Currency, date: Date, value: Decimal):
            self.rates.append(FXRate(ccy1, ccy2, date, value))


# Generated at 2022-06-21 20:26:15.401677
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Tests :class:`FXRate` constructor.
    """
    ## Define the FX rate:
    from datetime import date
    from pypara.currencies import Currencies
    from decimal import Decimal
    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), 2)

    ## Assert:
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == date.today()
    assert rate.value == 2



# Generated at 2022-06-21 20:26:19.969802
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    from .temporals import Dates
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], Dates.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], Dates.today(), Decimal("0.5"))
    assert(~nrate == rrate)

# Generated at 2022-06-21 20:26:26.565702
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-21 20:26:36.633717
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from .currencies import Currency
    from .currencies import Currencies
    from .rates import DiscountRateService
    from .rates import YieldCurveRateService
    from .services import ServiceContainer

    ## Create a service container that returns an FX rate service:
    class MyContainer(ServiceContainer):
        def __init__(self):
            self.__rates = {
                (Currencies["EUR"], Currencies["USD"], date(2018, 1, 1)): Decimal("1.22"),
                (Currencies["EUR"], Currencies["USD"], date(2019, 1, 1)): Decimal("1.23"),
                (Currencies["USD"], Currencies["EUR"], date(2019, 1, 1)): Decimal("1.0 / 1.23"),
            }


# Generated at 2022-06-21 20:26:38.789493
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests whether the :class:`FXRateService` class can be initialized.
    """
    assert FXRateService()



# Generated at 2022-06-21 20:26:43.591487
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.services import FXRateService
    from pypara.currencies import Currency, Currencies
    from pypara.temporals import Date
    from pypara.time import UtcDateTime
    from decimal import Decimal
    import math

    # Create a dummy FX rate service
    class DummyFXRateService(FXRateService):
        def __init__(self):
            self.__rates = {}

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            key = (ccy1, ccy2, asof)
            value = self.__rates.get(key)
            if value is None and strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return value



# Generated at 2022-06-21 20:27:05.854346
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except Exception as ex:
        assert isinstance(ex, FXRateLookupError)
        assert ex.ccy1 == Currencies["EUR"]
        assert ex.ccy2 == Currencies["USD"]
        assert ex.asof == datetime.date.today()



# Generated at 2022-06-21 20:27:14.533327
# Unit test for constructor of class FXRateService
def test_FXRateService():

    # noinspection PyAbstractClass,PyUnusedLocal
    class _TestFXRateService(FXRateService):

        # noinspection PyMethodMayBeStatic
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        # noinspection PyMethodMayBeStatic
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return iter(())

    # noinspection PyTypeChecker,PyCallByClass
    assert isinstance(_TestFXRateService(), FXRateService)

# Generated at 2022-06-21 20:27:24.042367
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        raise FXRateLookupError(Currency("XXX"), Currency("YYY"), Date(2019, 1, 1))
    except FXRateLookupError as e:
        assert e.ccy1 == Currency("XXX")
        assert e.ccy2 == Currency("YYY")
        assert e.asof == Date(2019, 1, 1)
        assert str(e) == "Foreign exchange rate for XXX/YYY not found as of 2019-01-01"
    else:
        assert False


# Generated at 2022-06-21 20:27:32.236503
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from .currencies import Currencies

    class TestFXRateService(FXRateService):  # noqa: D204

        def __init__(self):
            self.rates = [FXRate(Currencies["USD"], Currencies["EUR"], date(2020, 1, 1), ONE / Decimal("2")),
                          FXRate(Currencies["USD"], Currencies["EUR"], date(2020, 1, 2), ONE / Decimal("2.5")),
                          FXRate(Currencies["USD"], Currencies["EUR"], date(2020, 1, 3), ONE / Decimal("2.75"))]


# Generated at 2022-06-21 20:27:39.514680
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Period

    from datetime import date
    from decimal import Decimal

    ## Create an FX rate service:
    as_of_ = date(2017, 7, 17)

# Generated at 2022-06-21 20:27:46.329549
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:27:51.088778
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")



# Generated at 2022-06-21 20:27:59.540371
# Unit test for constructor of class FXRate
def test_FXRate():

    # Unit test for constructor:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")

    # Unit test for inverted rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    irate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == irate

# Generated at 2022-06-21 20:28:06.287018
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests FXRateLookupError constructor.
    """
    ## Create an instance:
    try:
        raise FXRateLookupError(Currency("EUR"), Currency("USD"), Date(2020, 1, 1))
    except FXRateLookupError as ex:

        ## Verify the message:
        assert str(ex) == "Foreign exchange rate for EUR/USD not found as of 2020-01-01"

        ## Check the slots:
        assert ex.ccy1 == Currency("EUR"), ex.ccy1
        assert ex.ccy2 == Currency("USD"), ex.ccy2
        assert ex.asof == Date(2020, 1, 1), ex.asof

# Generated at 2022-06-21 20:28:13.528593
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:28:55.719507
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError.
    """
    ## Set test fixtures:
    ccy1 = Currency.of("EUR")
    ccy2 = Currency.of("USD")
    asof = Date.today()

    ## Create a new instance of the class:
    error = FXRateLookupError(ccy1, ccy2, asof)

    ## A lookup error should be raised:
    assert isinstance(error, LookupError)

    ## A FX rate lookup error should be raised:
    assert isinstance(error, FXRateLookupError)

    ## Check the message of the error:
    assert error.args == (f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}",)

    ## Check the slots:
    assert error.ccy

# Generated at 2022-06-21 20:29:02.947088
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .commons.zeitgeist import Date
    from .currencies import Currencies
    from .fx import FXRateService

    class MyFxRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries)

    queries = [
        (Currencies.EUR, Currencies.USD, Date.today()),
        (Currencies.USD, Currencies.EUR, Date.today())
    ]
    rates = MyFxRateService().queries(queries)

# Generated at 2022-06-21 20:29:14.657498
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies

    from .temporal import Dates

    from .fxrate.abs import FXRateService

    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                if asof == Dates["2017-02-02"]:
                    return FXRate(Currencies["USD"], Currencies["EUR"], Dates["2017-02-02"], Decimal("1.078"))
                elif asof == Dates["2017-02-03"]:
                    return FXRate(Currencies["USD"], Currencies["EUR"], Dates["2017-02-03"], Decimal("1.078"))

       

# Generated at 2022-06-21 20:29:20.946027
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    ~nrate == rrate



# Generated at 2022-06-21 20:29:28.026854
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import pytest
    from importlib import reload
    from decimal import Decimal
    from pypara.currencies import Currencies, Currency

    ## Test FXRateService:
    reload(__import__("pypara.fxrates"))
    from pypara.fxrates import FXRateService

    ## Define a dummy implementation of FXRateService:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:  # noqa: D102
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-21 20:29:39.098833
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from unittest import TestCase, mock
    from pypara.currencies import Currencies

    ## The test:
    class MockService(FXRateService):

        def __init__(self, rates: dict) -> None:
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            rate = self.rates.get((ccy1, ccy2, asof))
            if rate:
                return rate
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-21 20:29:45.931969
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for the query method of class FXRateService.
    """
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance import FXRateService

    class StubFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 in (Currencies["EUR"], Currencies["CHF"]) and \
                    ccy2 == Currencies["USD"] and \
                    asof == datetime.date(2018, 2, 5):
                return FXRate(ccy1, ccy2, asof, Decimal(2))

# Generated at 2022-06-21 20:29:52.892979
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert nrate == ~rrate


# Generated at 2022-06-21 20:30:04.610922
# Unit test for constructor of class FXRate
def test_FXRate():
    import unittest
    class FXRateTestCase(unittest.TestCase):
        def test_constructor(self):
            from pypara.currencies import Currencies
            from pypara.temporals import Date
            from decimal import Decimal
            r = FXRate(Currencies["EUR"], Currencies["USD"], Date(2019, 12, 31), Decimal("1.1"))
            self.assertTrue(isinstance(r.ccy1, Currency))
            self.assertTrue(isinstance(r.ccy2, Currency))
            self.assertTrue(isinstance(r.date, Date))
            self.assertTrue(isinstance(r.value, Decimal))
            self.assertEqual(r.ccy1, Currencies["EUR"])

# Generated at 2022-06-21 20:30:16.981239
# Unit test for constructor of class FXRate
def test_FXRate():
    ## Create an FX rate with invalid values:
    try:
        FXRate(None, None, None, None)
    except ValueError as e:
        if str(e) != "CCY/1 must be of type `Currency`.":
            raise
    else:
        raise ValueError("FX Rate construction should not accept invalid values.")

    ## Create an FX rate with invalid value:
    try:
        FXRate(Currency("EUR"), Currency("USD"), Date.today(), Decimal("0.0"))
    except ValueError as e:
        if str(e) != "FX rate value can not be equal to or less than `zero`.":
            raise
    else:
        raise ValueError("FX Rate construction should not accept invalid values.")

    ## Create an FX rate with invalid value:

# Generated at 2022-06-21 20:31:40.906304
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Dates
    from .fx_rates import FXRateService

    # Create the queries:
    rate1 = (Currencies["EUR"], Currencies["USD"], Dates.today())
    rate2 = (Currencies["EUR"], Currencies["USD"], Dates.today() + 1)
    rate3 = (Currencies["USD"], Currencies["EUR"], Dates.today())

    # Create the fx rate service:
    class FXRateServiceImpl(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None


# Generated at 2022-06-21 20:31:47.088918
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests functionality of constructor of class FXRateService.
    """
    from .core import Environment
    from .currencies import Currency
    from .temporal import Date

    fxrate_service = Environment.get_instance().get_rates()

    ## Test the service:
    rate = fxrate_service.query(Currency("EUR"), Currency("USD"), Date("2019-01-01"))
    assert rate == FXRate(Currency("EUR"), Currency("USD"), Date("2019-01-01"), Decimal("1.14624"))

# Generated at 2022-06-21 20:31:58.902288
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies, CurrencyPair
    from .services import FXRateServiceImpl
    import datetime
    from decimal import Decimal
    from typing import Optional, Tuple
    from .commons.zeitgeist import Date
    from .commons.numbers import ONE, ZERO
    from .models import FXRate

    # Check sensitivity to argument types
    service = FXRateServiceImpl()
    assert isinstance(service, FXRateService)

    # Method query should return instance of class Decimal, Optional[Decimal]
    assert isinstance(service.query(Currencies["USD"], Currencies["USD"], Date.today()), Optional[FXRate])
    assert isinstance(service.query(Currencies["USD"], Currencies["USD"], Date.today()), FXRate)

    # Assert argument types