

# Generated at 2022-06-21 20:22:12.972405
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .exchanges import Exchange
    from .factories import FXRateServiceFactory

    ## Create and configure an FX rate service:
    fx_rate_service = FXRateServiceFactory().create(Exchange.CBRF)
    assert fx_rate_service

    ## Register the default FX rate service:
    FXRateService.default = fx_rate_service

    ## Query for a rate:
    assert FXRateService.default.query("USD", "RUB", Date.today())

# Generated at 2022-06-21 20:22:23.273403
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies['EUR'], Currencies['USD'], datetime.date.today(), Decimal('2'))
    assert rate[0] == Currencies['EUR']
    assert rate[1] == Currencies['USD']
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal('2')
    assert rate.ccy1 == Currencies['EUR']
    assert rate.ccy2 == Currencies['USD']
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal('2')


# Generated at 2022-06-21 20:22:24.926553
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    FXRateService()



# Generated at 2022-06-21 20:22:30.273606
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:38.897004
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:22:41.729209
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert hasattr(FXRateService, "__abstractmethods__")
    assert "query" in FXRateService.__abstractmethods__
    assert "queries" in FXRateService.__abstractmethods__


# Generated at 2022-06-21 20:22:46.205302
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:53.538117
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    actual = ~nrate
    assert actual == rrate



# Generated at 2022-06-21 20:23:02.247625
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Prepare a set of query data:
    queries = [
        # An exact match:
        (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        # A non-match:
        (Currencies["USD"], Currencies["EUR"], datetime.date.today())
    ]

    ## Now create a mock service that returns a custom FX rate for queries:

# Generated at 2022-06-21 20:23:10.075072
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    r = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert r.ccy1 == Currencies["EUR"]
    assert r.ccy2 == Currencies["USD"]
    assert r.date == datetime.date.today()
    assert r.value == Decimal("2")



# Generated at 2022-06-21 20:23:22.702322
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase
    from unittest.mock import MagicMock, patch

    class StubbedService(MagicMock, FXRateService):
        """
        Provides a stub for abstract class :class:`FXRateService`.
        """

        # noinspection PyMissingConstructor
        def __init__(self, **kwargs):
            """
            Initializes the stubbed service.
            """
            pass


# Generated at 2022-06-21 20:23:28.555887
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-21 20:23:39.665190
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():                                                           # noqa: E302
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    ## Collect the FX rate queries:
    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.date.today(),),
        (Currencies["USD"], Currencies["EUR"], datetime.date.today(),),
        (Currencies["USD"], Currencies["CAD"], datetime.date.today(),),
    ]

    ## Create the FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return evaluate(ccy1, ccy2, asof)


# Generated at 2022-06-21 20:23:47.890905
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .commons.zeitgeist import LocalDate
    from .portfolios import Instrument

    assert isinstance(FXRateService, ABCMeta)
    assert FXRateService.default is None
    assert FXRateService.TQuery is Tuple[Currency, Currency, Date]

    fxrate_service = FXRateService()
    assert fxrate_service.query(Currencies["EUR"], Currencies["USD"], LocalDate()) is None
    assert fxrate_service.queries([(Currencies["EUR"], Currencies["USD"], LocalDate())]) is None

    instrument = Instrument(name="Test", currency=Currencies["USD"],
                            maturity=LocalDate(), notional=Decimal("100.0"))

# Generated at 2022-06-21 20:23:55.099072
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:24:00.224396
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal
    from .fxrates import FXRate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert str(~nrate) == str(rrate)
    print("method __invert__ of class FXRate passed")


# Generated at 2022-06-21 20:24:03.676664
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from datetime import date

    from .currencies import Currency

    rate = FXRate("EUR", "USD", date.today(), Decimal("1.4"))
    assert isinstance(rate, FXRate)

# Generated at 2022-06-21 20:24:09.922532
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:19.025759
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## Make sure FXRateLookupError is a subclass of LookupError:
    assert issubclass(FXRateLookupError, LookupError)

    ## Create a test object:
    from .currencies import Currencies
    from .currencies.temporal import Date
    test_object = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())

    ## Make sure created object is of the right type:
    assert isinstance(test_object, FXRateLookupError)
    assert isinstance(test_object, LookupError)

    ## Make sure `currencies` attribute have the right value:
    assert test_object.ccy1 == Currencies["EUR"]
    assert test_object.ccy2 == Currencies["USD"]
    assert test_object.asof == Date.today()

    ## Make sure

# Generated at 2022-06-21 20:24:26.006272
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for the abstract method query of the class :class:`pypara.currencies.rates.FXRateService`.
    """
    from .providers import InMemoryFXRateService

    ## Create an instance of the FXRateService:
    ## Note that the abstract service class itself can not be instantiated.
    service = InMemoryFXRateService()

    ## Query the FX rate:
    service.query("USD", "EUR", "2015-11-05")



# Generated at 2022-06-21 20:24:39.600372
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.commons.zeitgeist import DateRange, Temporal
    from pypara.currencies import EUR, USD
    from pypara.fx import FXRateService

    class TestFXRateService(FXRateService):
        rate: Decimal = Decimal('1.2')
        queries_called: int = 0
        queries_queries: list = []
        queries_strict: bool = False

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            if asof.date in (DateRange('2017-1-1', '2017-1-31').dates()):
                return FXRate(ccy1, ccy2, asof.date, self.rate)

# Generated at 2022-06-21 20:24:50.640467
# Unit test for constructor of class FXRate
def test_FXRate():
    import pytest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.assets import FXRate

    ## Construction:
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert not FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), Decimal("2"))
    assert not FXRate(Currencies["EUR"], Currencies["EUR"], datetime.date.today(), Decimal("1"))
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == \
           FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert FXRate

# Generated at 2022-06-21 20:24:53.928965
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        raise FXRateLookupError("a", "b", Date.today())
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for a/b not found as of 2020-01-21"


# Generated at 2022-06-21 20:25:04.624194
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency, Currencies
    from .commons.zeitgeist import Date, now

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], now())
    except FXRateLookupError as ex:
        assert ex.ccy1 == Currency("EUR")
        assert ex.ccy2 == Currency("USD")
        assert ex.asof == now()
        assert str(ex) == f"Foreign exchange rate for {Currency('EUR')}/{Currency('USD')} not found as of {now()}"

# Unit tests for class FXRate

# Generated at 2022-06-21 20:25:09.757678
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from .currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-21 20:25:14.021145
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query.
    """

    ## Note: We are simply testing that these methods are invokable with no other expectations.
    FXRateService().query(Currency("USD"), Currency("TRY"), Date.today())
    FXRateService().queries([])

# Generated at 2022-06-21 20:25:21.571054
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest
    ccy1 = Currency.of("EUR")
    ccy2 = Currency.of("USD")
    date = Date.of(2018, 9, 10)
    error = FXRateLookupError(ccy1, ccy2, date)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == date
    with pytest.raises(FXRateLookupError):
        raise error


# Generated at 2022-06-21 20:25:29.684634
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies

    # Test with date:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = Date(1990, 1, 1)
    msg = f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {date}"

    exc = FXRateLookupError(ccy1, ccy2, date)
    assert exc.ccy1 == ccy1
    assert exc.ccy2 == ccy2
    assert exc.asof == date
    assert str(exc) == msg


# Unit test class FXRate

# Generated at 2022-06-21 20:25:39.177628
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import EUR, USD
    from .commons.zeitgeist import date
    from .commons.numbers.exceptions import RoundingError

    assert FXRateLookupError(EUR, USD, date(2020, 1, 1)).ccy1 == EUR
    assert FXRateLookupError(EUR, USD, date(2020, 1, 1)).ccy2 == USD
    assert FXRateLookupError(EUR, USD, date(2020, 1, 1)).asof == date(2020, 1, 1)

    try:
        raise FXRateLookupError(EUR, USD, date(2020, 1, 1)) from RoundingError()
    except FXRateLookupError as ex:
        assert ex.ccy1 == EUR
        assert ex.ccy2 == USD

# Generated at 2022-06-21 20:25:43.410633
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:25:59.781205
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    from .currencies import Currencies
    from .testing import TestCase

    # Define the test case class:
    class Test(TestCase):

        def test_invert(self):
            self.assertEqual(
                ~FXRate(Currencies["EUR"], Currencies["USD"], self.date, Decimal("2")),
                FXRate(Currencies["USD"], Currencies["EUR"], self.date, Decimal("0.5"))
            )

    # Run the unit test:
    Test.run()



# Generated at 2022-06-21 20:26:05.116234
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate == ~FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-21 20:26:13.518550
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:26:21.306628
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(None)).ccy1 == Currencies["EUR"]
    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(None)).ccy2 == Currencies["USD"]
    assert FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(None)).asof == Date(None)
    assert str(
        FXRateLookupError(Currencies["EUR"], Currencies["USD"],
                          Date(None))
    ) == "Foreign exchange rate for EUR/USD not found as of None"



# Generated at 2022-06-21 20:26:33.215131
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test method queries of class FXRateService
    """
    import datetime as dt
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finmath.fx.dictfxrateservice import DictFXRateService

    # Test initialisation
    service = DictFXRateService()

    # Test set of queries parameter
    queries_set = [
        (Currencies["EUR"], Currencies["USD"], dt.date.today()),
        (Currencies["EUR"], Currencies["USD"], dt.date.today() + dt.timedelta(days=1)),
    ]

    # Test set of FX rates

# Generated at 2022-06-21 20:26:37.993532
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency, Currencies
    from .commons.zeitgeist import Date

    assert FXRateLookupError(Currency("EUR"), Currencies["USD"], Date()) == FXRateLookupError("EUR", "USD", Date())
    assert str(FXRateLookupError("EUR", "USD", Date())) == "Foreign exchange rate for EUR/USD not found as of 1969-12-31"


# Generated at 2022-06-21 20:26:43.162290
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fxrates import FXRateService


    class TestFXRateService(FXRateService):
        """
        This class provides a test implementation of an FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-21 20:26:44.936355
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # noinspection PyTypeChecker
    # This test is for doc purposes
    pass

# Generated at 2022-06-21 20:26:52.555518
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:01.051365
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method :method:`FXRateService.query`.
    """
    from .currencies import Currencies
    from .date_time import DateTime
    from .fx import FXRateService
    from .fx_rates import FXRates

    ## Make sure we have a default :class:`FXRateService` instance:
    FXRates.initialize()

    ## Some definitions:
    fxs = FXRateService.default
    none = FXRateService.default.query(None, None, None, False)
    eur = fxs.query(Currencies["EUR"], Currencies["EUR"], DateTime.today())
    usd = fxs.query(Currencies["USD"], Currencies["USD"], DateTime.today())

# Generated at 2022-06-21 20:27:26.708701
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("1"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:37.002499
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    assert TestFXRateService.__doc__.strip() == FXRateService.__doc__.strip()
    assert isinstance(TestFXRateService.query, abstractmethod)
    assert isinstance(TestFXRateService.queries, abstractmethod)
    assert TestFXRateService.__name__ == "TestFXRateService"
    assert TestFXRateService.__module__ == "pypara.fxrates"
    assert TestFXRateService.default is None
    assert Test

# Generated at 2022-06-21 20:27:43.157330
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError(): # noqa: D103
    from .currencies import Currency, Currencies
    from .commons.zeitgeist import Date
    try:
        raise FXRateLookupError(Currency.of('EUR'), Currency.of('USD'), Date(2014, 7, 1))
    except FXRateLookupError as e:
        assert str(e) == 'Foreign exchange rate for EUR/USD not found as of 2014-07-01'

# Generated at 2022-06-21 20:27:49.480097
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    ## Imports:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    ## Data:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    ## Operation:
    rate = ~nrate
    ## Validation:
    assert rate == rrate


# Generated at 2022-06-21 20:28:02.488431
# Unit test for constructor of class FXRateService
def test_FXRateService():

    from .commons.zeitgeist import now
    from .currencies import Currency

    ## Create a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof):
            if ccy2 == Currency("USD"):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

        def queries(self, queries):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof)

    ## Make the service the default:
    FXRateService.default = DummyFXRateService()

    ## Create the query tuple:
    query = (Currency("EUR"), Currency("USD"), now())

    ## Query the FX rate:
   

# Generated at 2022-06-21 20:28:14.809067
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Runs unit tests for FXRateService.
    """
    from .commons.zeitgeist import today
    from .currencies import Currency

    def run_test(ccy1: Currency, ccy2: Currency, asof: Date):
        """
        """
        print(FXRateService.default.query(ccy1, ccy2, asof))

    run_test(Currency("EUR"), Currency("USD"), today())
    run_test(Currency("EUR"), Currency("TRY"), today())
    run_test(Currency("TL"), Currency("USD"), today())
    run_test(Currency("TL"), Currency("USD"), today() - 1)
    run_test(Currency("TL"), Currency("EUR"), today())
    run_test(Currency("USD"), Currency("EUR"), today())
   

# Generated at 2022-06-21 20:28:20.302371
# Unit test for constructor of class FXRate
def test_FXRate():

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:28:27.081217
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-21 20:28:37.351335
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies  # noqa: E402, F401
    from pypara.temporal import Date  # noqa: E402, F401

    ## Invert EUR/USD:
    assert ~FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("1.25")) == FXRate(Currencies["USD"], Currencies["EUR"], Date.today(), Decimal("0.8"))  # noqa: E501

    ## Invert USD/EUR:
    assert ~FXRate(Currencies["USD"], Currencies["EUR"], Date.today(), Decimal("0.8")) == FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("1.25"))  # noqa: E501

    ## Invert

# Generated at 2022-06-21 20:28:47.344692
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.currencies import USD, EUR, GBP, JPY
    from pypara.commons.zeitgeist import Date, Dates

    ## Abstraction for FX rate service:
    class MockService(FXRateService):

        def __init__(self):
            super().__init__()

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None]

    ## FX rate service abstraction:
    assert issubclass(MockService, FXRateService)
    assert isinstance(MockService(), FXRateService)

# Generated at 2022-06-21 20:29:28.451751
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency
    from pypara.fxrates import FXRate
    from pypara.fxrates.memory import MemoryFXRateService

    # Create the FX rate service:
    fxrates = [
        FXRate("EUR", "USD", date(2018, 1, 1), Decimal("1.23")),
        FXRate("USD", "EUR", date(2018, 1, 1), Decimal("0.81")),
        FXRate("EUR", "USD", date(2018, 1, 2), Decimal("1.24")),
        FXRate("USD", "EUR", date(2018, 1, 2), Decimal("0.81"))
    ]
    fxsvc = MemoryFXRateService()

# Generated at 2022-06-21 20:29:39.677387
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.currencies.mock import MockFXRateService

    # Necessary imports for type annotations:
    from typing import List
    from datetime import date

    # Set up the service:
    service = MockFXRateService()

    # Test two currencies in the same currency:
    assert service.query(Currencies["TRY"], Currencies["TRY"], date.today()) is None

    # Test two currencies in different currency:
    assert service.query(Currencies["TRY"], Currencies["USD"], date.today()) is not None
    assert service.query(Currencies["TRY"], Currencies["USD"], date.today()) == FXRate(Currencies["TRY"], Currencies["USD"], date.today(), Decimal("0.36"))

    # Test two currencies that are not in the service:

# Generated at 2022-06-21 20:29:43.512381
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    import datetime as dt

    rate = FXRate(Currencies["EUR"], Currencies["USD"], dt.date.today(), 2)
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], dt.date.today(), 0.5)


# Generated at 2022-06-21 20:29:49.790084
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:30:01.702963
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import EUR, USD
    from .temporals import today
    from .currencies.services import FXRateService as FXRateService__

    ## Create a test fixture:
    rates = [
        (EUR, USD, today(), Decimal("2.0")),
        (USD, EUR, today(), Decimal("0.5")),
    ]
    fx_rate_service = FXRateService__(rates)

    ## Make assertions:
    assert fx_rate_service.query(EUR, USD, today()) == FXRate(EUR, USD, today(), Decimal("2.0"))
    assert fx_rate_service.query(USD, EUR, today()) == FXRate(USD, EUR, today(), Decimal("0.5"))

# Generated at 2022-06-21 20:30:09.486415
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():  # noqa: D103
    from .currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["TRY"], Currencies["USD"], Date.today())
    except Exception as e:
        assert isinstance(e, FXRateLookupError)
        assert str(e) == "Foreign exchange rate for TRY/USD not found as of 2019-08-27"



# Generated at 2022-06-21 20:30:19.957035
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import ISO4217_Currencies
    from .temporal import Temporal, DateTime

    class FixedRate(FXRateService):
        """
        Provides a fixed foreign exchange rate service model.
        """

        def __init__(self, rate1: FXRate, rate2: FXRate) -> None:
            """
            Initializes the fixed foreign exchange rate service.
            """
            self.rates = {
                (rate1[0], rate1[1], rate1[2]): rate1,
                (rate2[0], rate2[1], rate2[2]): rate2,
            }


# Generated at 2022-06-21 20:30:28.278099
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons import Temporal

    ## Test initialization:
    err = FXRateLookupError(ccy1=Currencies["USD"], ccy2=Currencies["EUR"], asof=Temporal.now())
    assert err is not None
    assert isinstance(err, Exception)
    assert type(err) is FXRateLookupError

    ## Test message:
    assert str(err) == "Foreign exchange rate for USD/EUR not found as of today"


# Generated at 2022-06-21 20:30:34.521705
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Unit test for method __invert__ of class FXRate
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert(~nrate == rrate)


# Generated at 2022-06-21 20:30:41.916087
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporals import Dates

    rate = FXRate(Currencies["EUR"], Currencies["USD"], Dates.today(), Decimal("2"))
    assert rate[0] is Currencies["EUR"]
    assert rate[1] is Currencies["USD"]
    assert rate[2] is Dates.today()
    assert rate[3] == Decimal("2")


# Generated at 2022-06-21 20:32:11.487583
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import EUR, USD
    from .temporal import Date
    from .fxrates import FXRate, FXRateService

    # Define the FX rate service
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(ccy1, ccy2, date) for ccy1, ccy2, date in queries]

    # Get the default FX rate service
    service = FXRateService.default

    # Make sure the default FX rate service