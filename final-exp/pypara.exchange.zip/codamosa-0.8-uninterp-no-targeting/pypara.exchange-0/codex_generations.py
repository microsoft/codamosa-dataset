

# Generated at 2022-06-21 20:22:13.690364
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.zeitgeist import Temporal
    from pypara.currencies import Currencies

    class Dummy(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof=asof, value=ONE)

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Temporal]], strict: bool) -> Iterable[Optional[FXRate]]:
            return map(lambda q: self.query(*q, strict=strict), queries)

    fxr = Dummy()

    assert isinstance(fxr, FXRateService)
    assert isinstance(fxr, Dummy)

# Generated at 2022-06-21 20:22:25.030365
# Unit test for method queries of class FXRateService

# Generated at 2022-06-21 20:22:30.899588
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies

    with unittest.TestCase("__init__"):
        nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
        rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
        assert ~nrate == rrate

# Generated at 2022-06-21 20:22:37.759920
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:46.846236
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    #
    # [1] Test: Test nominal case:
    #
    # The service has a foreign exchange rates for all queries.
    #
    class ForeignExchangeRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currency("A") and ccy2 == Currency("B"):
                return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
            if ccy1 == Currency("B") and ccy2 == Currency("C"):
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))

# Generated at 2022-06-21 20:22:51.681877
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from pypara.currencies import Currencies, Currency
    from pypara.temporal import Date
    assert(FXRateService)
    assert(isinstance(FXRateService, object))
    assert(issubclass(FXRateService, object))
    assert(issubclass(FXRateService, ABCMeta))

# Generated at 2022-06-21 20:22:57.611777
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:23:04.704882
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest.mock import Mock
    from pypara.currencies import CURRENCIES, EUR, USD
    from pypara.temporals import now

    ## Create the mock:
    service = Mock(spec=FXRateService)
    assert service.default == None

    ## Create the query:
    query = (EUR, USD, now().value)

    ## Create the queries:
    queries = (query, query)

    ## Mock the query response:
    service.query.return_value = FXRate(EUR, USD, now().value, Decimal("2"))

    ## Invoke the method:
    rates = list(service.queries(queries))

    ## Assert return value:
    assert len(rates) == 2

# Generated at 2022-06-21 20:23:12.048258
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-21 20:23:21.540129
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test of class :class:`FXRateService`
    """
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date

    class RateService(FXRateService):
        """
        Provides a dummy implementation of foreign exchange rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    ## Make sure that the default foreign exchange rate service is not set:
    assert FXRateService.default is None

    ## Create a dummy foreign exchange rate service:
    service = RateService()

    ## Make

# Generated at 2022-06-21 20:23:32.758547
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert nrate.ccy1 == Currencies["EUR"]
    assert nrate.ccy2 == Currencies["USD"]
    assert nrate.date == datetime.date.today()
    assert nrate.value == Decimal("2")


# Generated at 2022-06-21 20:23:34.591474
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass  # For now, nothing to do here.



# Generated at 2022-06-21 20:23:37.809084
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert (not hasattr(FXRateService, "__init__"))
    assert (FXRateService.__abstractmethods__ == {"query", "queries"})


# Generated at 2022-06-21 20:23:42.527390
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currency
    from .temporal import Date
    from .fx import FXRate
    rate = FXRate(Currency("EUR"), Currency("USD"), Date.of(2019, 5, 30), Decimal("2"))
    assert rate.__invert__() == FXRate(Currency("USD"), Currency("EUR"), Date.of(2019, 5, 30), Decimal("0.5"))


# Generated at 2022-06-21 20:23:49.777134
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Save the current default service
    saved_default = FXRateService.default

    # Set a dummy foreign exchange rate service
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            ...
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            ...

    FXRateService.default = DummyFXRateService()

    # 1. Inverted FX rate is correct
    assert ~FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == FX

# Generated at 2022-06-21 20:23:56.925085
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:24:04.060818
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:10.273231
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert (~nrate == rrate)


# Generated at 2022-06-21 20:24:11.119202
# Unit test for constructor of class FXRateService
def test_FXRateService():
    pass


# Generated at 2022-06-21 20:24:18.491276
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the foreign exchange rate lookup error class.
    """
    import datetime

    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as ex:
        assert str(ex) == "Foreign exchange rate for EUR/USD not found as of 2020-01-06"
        assert ex.ccy1 == Currencies["EUR"]
        assert ex.ccy2 == Currencies["USD"]
        assert ex.asof == datetime.date.today()



# Generated at 2022-06-21 20:24:33.039358
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """Unit :class:`FXRateService`."""
    # Dummy test:
    assert True


# Standalone test for this module.
if __name__ == "__main__":
    import doctest

    from pypara.currencies import Currencies

    # Perform doctests:
    doctest.testmod()

    # Perform unit tests:
    test_FXRateService()

# Generated at 2022-06-21 20:24:40.838050
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from .currencies import Currency

    class RateProvider(FXRateService):
        """
        Mock FXRateService
        """


# Generated at 2022-06-21 20:24:47.183186
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    nrate = FXRate(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")
    )
    rrate = FXRate(
        Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5")
    )
    assert(~nrate == rrate)

# Generated at 2022-06-21 20:24:52.322138
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date
    from pypara.fxrates import FXRateLookupError

    # Prepare a message, it should be set by the constructor
    ERROR_MESSAGE = "Foreign exchange rate for USD/EUR not found as of 2018-01-01."

    # Create an instance
    e = FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date("2018/1/1"))

    # Check message
    assert e.message == ERROR_MESSAGE

# Generated at 2022-06-21 20:24:55.135662
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService


# Generated at 2022-06-21 20:25:04.675680
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests the inversion of a foreign exchange rate.

    >>> import datetime
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currencies
    >>> nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    >>> rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.50"))
    >>> ~nrate == rrate
    True
    """
    pass


# Generated at 2022-06-21 20:25:10.623229
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    ccy1 == Currencies["EUR"]
    ccy2 == Currencies["USD"]
    date == datetime.date.today()
    value == Decimal("2")


# Generated at 2022-06-21 20:25:22.389625
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    This unit test tests the constructor of class :class:`FXRateLookupError`.
    """
    ## Import required modules:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateLookupError
    from pypara.commons.zeitgeist import Date

    ## Create FX rate lookup error with correct attributes:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()
    error = FXRateLookupError(ccy1, ccy2, date)

    ## Assert:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == date

# Generated at 2022-06-21 20:25:30.991093
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests :class:`FXRateLookupError`.
    """
    import datetime

    from pypara.currencies import Currencies

    ## Test the constructor:
    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())

    ## Make sure the error is properly initialized:
    assert e.ccy1 == Currencies["EUR"]
    assert e.ccy2 == Currencies["USD"]
    assert e.asof == datetime.date.today()
    assert str(e) == "Foreign exchange rate for EUR/USD not found as of {}".format(datetime.date.today())


# Generated at 2022-06-21 20:25:39.177089
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Import required module
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Initialize the test method
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    class TestFXRateService(FXRateService):

        def query(self, ccy2, ccy1, asof, strict = False):
            return rate

        def queries(self, queries, strict = False):
            yield rate

    # Initialize the FX rate service
    service = TestFXRateService()

    # Test method query
    assert rate == service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-21 20:26:05.075950
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Create a FX rate:
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.util.currency_fixtures import FXRateServiceName2FXRate
    import datetime
    fxrate_eur_usd = FXRate(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], date=datetime.date.today(), value=Decimal("1.1"))
    class FXRateServiceTest(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False): return fxrate_eur_usd
    test_fx_rate_service = FXRateServiceTest()

    # Query for the rate:

# Generated at 2022-06-21 20:26:14.314739
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase
    from unittest.mock import Mock, create_autospec, patch
    from pypara.currencies import Currency
    from pypara.temporal import Date
    from pypara.fxrates import CurrencyConverter, FXRate, FXRateService
    from pypara.settings import Settings

    ## Fixture:
    class MockFXRateService(FXRateService, metaclass=ABCMeta):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[Decimal]:
            return super().query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-21 20:26:16.298572
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## FX rate is not found:
    with raises(FXRateLookupError):
        raise FXRateLookupError(Currency.of("EUR"), Currency.of("USD"), Date.today())



# Generated at 2022-06-21 20:26:22.852441
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for class FXRateLookupError.
    """
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    from .currencies import Currency
    from .xfers import FXRateLookupError
    ccy1 = Currency("USD")
    ccy2 = Currency("EUR")
    asof = Date(2020, 10, 12)
    error = FXRateLookupError(ccy1, ccy2, asof)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert error.args[0] == "Foreign exchange rate for USD/EUR not found as of 2020-10-12"



# Generated at 2022-06-21 20:26:32.198892
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Initalize a dummy FX rate service:
    service = lambda ccy1, ccy2, asof: FXRate(ccy1, ccy2, asof, "0.25")
    service.queries = lambda _: (service(*i) for i in _)
    # Query an FX rate:
    assert service.query("1", "2", "3") == FXRate("1", "2", "3", "0.25")
    # Query an FX rate with error:
    assert service.query("1", "2", "3", strict=True) == FXRate("1", "2", "3", "0.25")


# Generated at 2022-06-21 20:26:40.001637
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    class MyService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and \
                asof == datetime.date(2020, 1, 1):
                return FXRate.of(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    FXRateService.default = MyService()


# Generated at 2022-06-21 20:26:47.177965
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    from decimal import Decimal
    from datetime import date

    from pypara.currencies import Currency

    assert(FXRate(Currency("EUR"), Currency("USD"), date(2000, 1, 1), Decimal("1.5811")).__invert__() ==
           FXRate(Currency("USD"), Currency("EUR"), date(2000, 1, 1), Decimal("0.63325")))



# Generated at 2022-06-21 20:26:54.858397
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal
    from .fxrates import FXRate

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:01.811805
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    ## Import packages:
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency, Currencies
    from pypara.finance.fxrates import FXRate, FXRateService

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        """
        Provides a mock foreign exchange rate (FX) service.
        """

        def __init__(self, *rates):
            """
            Initializes the mock foreign exchange rate service with rates specified.

            :param rates: An iterable of :class:`FXRate` instances.
            """
            ## Keep the slots:
            self.__rates = rates

            ## Set the super:
            super().__init__()


# Generated at 2022-06-21 20:27:03.746965
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # This method is abstract and can not have a unit test.
    ...

# Generated at 2022-06-21 20:27:46.288402
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Checks the constructor of class FXRateLookupError
    """
    from datetime import datetime
    from pypara.currencies import EUR, USD, Currencies
    import pytest

    # Check construction of exception:
    with pytest.raises(FXRateLookupError) as e:
        raise FXRateLookupError(EUR, USD, datetime.now())
    exc = e.value
    # Checks the message:
    assert exc.msg == "Foreign exchange rate for EUR/USD not found as of {}".format(datetime.now())
    # Check slots in the exception:
    assert exc.ccy1 is EUR
    assert exc.ccy2 is USD


# Generated at 2022-06-21 20:27:51.311012
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from .currencies import Currencies
    from .temporal import Date

    ## Test data:
    eur = Currencies["EUR"]
    usd = Currencies["USD"]
    today = Date.today()
    rate = FXRate(eur, usd, today, Decimal("2"))

    ## Invert the rate:
    irate = ~rate

    ## Check the inverted rate:
    assert irate == FXRate(usd, eur, today, Decimal("0.5"))

# Generated at 2022-06-21 20:28:02.792370
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    from pypara.core.exchange import FXRateLookupError

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()

    assert isinstance(FXRateLookupError(ccy1, ccy2, asof), FXRateLookupError)
    assert FXRateLookupError(ccy1, ccy2, asof).ccy1 == ccy1
    assert FXRateLookupError(ccy1, ccy2, asof).ccy2 == ccy2
    assert FXRateLookupError(ccy1, ccy2, asof).asof == asof

# Generated at 2022-06-21 20:28:15.287244
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    ## Set up the test values:
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date("2017-01-01")

    ## Set up the dummy service:
    class Dummy(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.1"))


# Generated at 2022-06-21 20:28:21.679436
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:28:29.606364
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2020, 1, 1), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date(2020, 1, 1)
    assert rate.value == Decimal("2")



# Generated at 2022-06-21 20:28:39.253712
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.fxrates import FXRateLookupError, FXRateService

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["TRL"]:
                return FXRate(ccy1, ccy2, asof, Decimal("1.5"))
            else:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                else:
                    return None


# Generated at 2022-06-21 20:28:49.294704
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency

    import datetime

    from decimal import Decimal

    from unittest import TestCase

    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            raise NotImplementedError()

    ## A dummy service instance:
    service = DummyFXRateService()

    ## Create the test case:

# Generated at 2022-06-21 20:28:50.154634
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None

# Generated at 2022-06-21 20:28:57.458471
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Tests constructor of class FXRate.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-21 20:30:18.079491
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .commons.zeitgeist import Date

    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date.now()
    err = FXRateLookupError(ccy1, ccy2, asof)
    assert isinstance(err, Exception)  # noqa: E721
    assert isinstance(err, LookupError)
    assert err.ccy1 == ccy1
    assert err.ccy2 == ccy2
    assert err.asof == asof
    assert err.args == ("Foreign exchange rate for EUR/USD not found as of 18/10/2019",)


# Generated at 2022-06-21 20:30:25.679375
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert(ccy1 == Currencies["EUR"])
    assert(ccy2 == Currencies["USD"])
    assert(date == datetime.date.today())
    assert(value == Decimal("2"))

# Generated at 2022-06-21 20:30:27.621858
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 20:30:33.246957
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ((~nrate) == rrate)


# Generated at 2022-06-21 20:30:41.228230
# Unit test for constructor of class FXRate
def test_FXRate():
    import unittest
    FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1.1"))

    # Raise ValueError if ccy1 is not of type Currency
    with self.assertRaises(ValueError):
        FXRate.of(None, Currencies["USD"], datetime.date.today(), Decimal("1.1"))

    # Raise ValueError if ccy2 is not of type Currency
    with self.assertRaises(ValueError):
        FXRate.of(Currencies["EUR"], None, datetime.date.today(), Decimal("1.1"))

    # Raise ValueError if value is not of type Decimal

# Generated at 2022-06-21 20:30:49.826195
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    ## Test:
    try:
        raise FXRateLookupError(Currency('EUR'), Currency('USD'), Date.today())
    except FXRateLookupError as e:
        ## Assert:
        assert e.ccy1   == Currency('EUR')
        assert e.ccy2   == Currency('USD')
        assert e.asof   == Date.today()
        assert e.message == "Foreign exchange rate for EUR/USD not found as of 2019-01-31"
        return
    ## Should not reach here:
    assert False



# Generated at 2022-06-21 20:31:00.990449
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of the FXRateLookupError.
    """
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date
    from pypara.finance.fx import FXRateLookupError

    ccy1 = Currency("USD", "USA", "America", "United States Dollars")
    ccy2 = Currency("EUR", "EU", "Europe", "Euros")
    date = Date(2020, 1, 1)

    err = FXRateLookupError(ccy1, ccy2, date)

    assert err.ccy1 == ccy1
    assert err.ccy2 == ccy2
    assert err.date == date
    assert err.args[0] == "Foreign exchange rate for USD/EUR not found as of 2020-01-01"


# Unit

# Generated at 2022-06-21 20:31:07.498280
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:31:12.513425
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class FXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass
        def queries(self, queries, strict=False):
            pass
    test_service = FXRateService()
    assert test_service



# Generated at 2022-06-21 20:31:17.918209
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from datetime import date
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], date.today())
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == date.today()
