

# Generated at 2022-06-21 20:22:19.874954
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .commons.zeitgeist import LocalDate, LocalDateTime
    from decimal import Decimal
    from pypara.currencies import Currency
    rate = FXRate(ccy1=Currency('EUR'), ccy2=Currency('USD'), date=LocalDate.of(2018, 1, 1), value=Decimal(2))
    inverted_rate = FXRate(ccy1=Currency('USD'), ccy2=Currency('EUR'), date=LocalDate.of(2018, 1, 1), value=Decimal(0.5))
    assert ~rate == inverted_rate


# Generated at 2022-06-21 20:22:30.309874
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.fx.rates import FXRateService
    from pypara.market.temporal import Date

    class NullFXRateService(FXRateService):
        def __init__(self, data: dict) -> None:
            self.__data = data

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return self.__data.get((ccy1, ccy2, asof))

    ## Create the FX rate service:
    usd_eur = FXRate(Currencies["USD"], Currencies["EUR"], date(2018, 1, 1), 1.22)

# Generated at 2022-06-21 20:22:37.128552
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency

    assert ~FXRate(Currency("EUR"), Currency("USD"), date(2019, 1, 1), Decimal("2")) == \
        FXRate(Currency("USD"), Currency("EUR"), date(2019, 1, 1), Decimal("0.5"))


# Generated at 2022-06-21 20:22:45.056924
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of the :class:`FXRateLookupError` class.
    """
    error = FXRateLookupError(Currency.of("EUR"), Currency.of("USD"), Date.of("2019-01-01"))
    assert error.ccy1 == Currency.of("EUR")
    assert error.ccy2 == Currency.of("USD")
    assert error.asof == Date.of("2019-01-01")
    assert error.args[0] == "Foreign exchange rate for EUR/USD not found as of 2019-01-01"


# Generated at 2022-06-21 20:22:56.863451
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## Initialize the service:
    class _Service(FXRateService):
        def __init__(self, rates: Tuple[FXRate, ...]):
            self._rates = dict(zip(((ccy1, ccy2, date) for ccy1, ccy2, date, _ in rates), rates))

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            try:
                return self._rates[(ccy1, ccy2, asof)]
            except KeyError:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                else:
                    return None


# Generated at 2022-06-21 20:23:04.230207
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    This method tests the :method:`query` method of the :class:`FXRateService`.
    """
    import pytest
    from decimal import Decimal
    from .currencies import Currencies
    from .commons.zeitgeist import Date


# Generated at 2022-06-21 20:23:09.079152
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Test construction of class FXRateService
    """
    # Import:
    import pytest

    # Test:
    with pytest.raises(TypeError):
        FXRateService()

# Generated at 2022-06-21 20:23:16.855737
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:23:23.254655
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.measurements import FXRate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:23:31.823029
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fxrates import FXRate, FXRateService
    from pypara.ledgers.zeitgeist import Date

    class InMemoryFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == datetime.date(2020, 7, 1):
                return FXRate(Currencies["USD"], Currencies["EUR"], datetime.date(2020, 7, 1), Decimal("0.9"))
            else:
                return None


# Generated at 2022-06-21 20:23:44.971496
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    #
    # Setup a normal rate:
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 1, 1), Decimal("2"))
    assert isinstance(nrate, FXRate)
    assert isinstance(~nrate, FXRate)

    #
    # Setup a reversed rate:
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], date(2019, 1, 1), Decimal("0.5"))
    assert isinstance(rrate, FXRate)
    assert isinstance(~rrate, FXRate)

    #
    # Verify normal and reversed rates are the same:
    assert ~nrate == rrate
    assert ~rrate == nrate

#

# Generated at 2022-06-21 20:23:52.046917
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:24:00.366985
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Set-up the test
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fx import FXRate
    from pypara.markets.fx import FXRateService
    from pypara.markets.fx import FXRateLookupError

    class TestService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():  # noqa: E712
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None


# Generated at 2022-06-21 20:24:07.601919
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.time import Date

    # Define the date and date range
    date = Date.today()
    date_range = Date.range(date, date.next_year()-1, timedelta=31)

    # Define the currency pairs
    ccy1, ccy2 = Currencies["EUR"], Currencies["USD"]

    # Define the FX rate values

# Generated at 2022-06-21 20:24:11.631685
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests constructor of class FXRateService.
    """

    ## Define a dummy subclass
    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service.
        """
        pass

    ## Create a dummy instance:
    DummyFXRateService()

# Generated at 2022-06-21 20:24:18.550195
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert isinstance(urate, NamedTuple)
    assert len(urate) == 4
    assert urate.ccy1 == Currencies["EUR"]
    assert urate.ccy2 == Currencies["USD"]
    assert urate.date == datetime.date.today()
    assert urate.value == Decimal("2")



# Generated at 2022-06-21 20:24:30.413789
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .commons.zeitgeist import Datum
    import datetime

    class FXRateServiceMock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError()

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield None

    rateService = FXRateServiceMock()

# Generated at 2022-06-21 20:24:37.247996
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Class method test of class FXRate

# Generated at 2022-06-21 20:24:38.021002
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    pass


# Generated at 2022-06-21 20:24:45.957021
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError.
    """
    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of {}".format(datetime.date.today())


# Generated at 2022-06-21 20:25:06.715147
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporals import Date

    ## Create a mock FX rate service:
    class MockFXRateService(FXRateService):
        def queries(inner_self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> \
                Iterable[Optional[FXRate]]:
            for ccy1, ccy2, date in queries:
                yield FXRate.of(ccy1, ccy2, date, ONE)

    ## Create a mock FX rate service instance:
    srv = MockFXRateService()

    ## Test:

# Generated at 2022-06-21 20:25:14.975918
# Unit test for constructor of class FXRateService
def test_FXRateService():  # noqa
    """
    Tests the constructor of class :class:`FXRateService`.

    Note: This is a functional test.
    """
    from pypara.currencies import Currencies
    from pypara.dates import Date

    assert FXRateService.default is None, "Class FXRateService must have a default value of `None`."

    ## The default attribute of FXRateService must be of type FXRateService
    try:
        FXRateService.default = "Not FXRateService"  # type: ignore
        assert False, "Type of attribute default of class FXRateService must be of type FXRateService."
    except TypeError:
        pass

    ## Attribute default of FXRateService must be None or an instance of FXRateService

# Generated at 2022-06-21 20:25:26.183822
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets import FXRate, FXRateService as _FXRateService

    class FXRateService(_FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError()

        def queries(self, queries: Iterable[TQuery], strict: bool  = False) -> Iterable[Optional[FXRate]]:
            yield FXRate(ccy1=Currencies['EUR'], ccy2=Currencies['USD'], date=Date(2020, 12, 31), value=Decimal(0.00))

# Generated at 2022-06-21 20:25:36.248969
# Unit test for constructor of class FXRate
def test_FXRate():
    # Imports:
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    # Prepare the context:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()
    value = Decimal("2")

    # Construct the object:
    assert FXRate(ccy1, ccy2, date, value).ccy1 == ccy1
    assert FXRate(ccy1, ccy2, date, value).ccy2 == ccy2
    assert FXRate(ccy1, ccy2, date, value).date == date
    assert FXRate(ccy1, ccy2, date, value).value == value


# Generated at 2022-06-21 20:25:46.947235
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test the quiries method of the FXRateService.
    """
    # Fixing the date
    import datetime
    date = datetime.date.today()

    # The sample queries
    from pypara.currencies import Currencies
    queries = [
        (Currencies["EUR"], Currencies["USD"], date),
        (Currencies["USD"], Currencies["EUR"], date),
        (Currencies["EUR"], Currencies["TRY"], date)
    ]

    # The stubbed FX rate service
    from pypara.currencies import FXRateService
    from pypara.currencies import Decimal, ONE
    from pypara.currencies import FXRate

# Generated at 2022-06-21 20:25:57.901571
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import AED, USD
    from .commons.zeitgeist import Date
    from .services.blank import BlankService
    from .services.services import FXRateService, FXRateServiceProvider

    ## Create mock services:
    fx_rates = ((AED, USD, Date.today(), Decimal(2.01)),)
    service = FXRateServiceProvider(BlankService(), fx_rates)

    ## Create the FX rates:
    fx_rate_1 = service.query(AED, USD, Date.today())
    fx_rate_2 = service.query(USD, AED, Date.today())

    ## Test the FX rate inversion:
    assert fx_rate_1 == ~fx_rate_2


# Generated at 2022-06-21 20:26:04.260037
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class Service(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    service = Service()
    assert service is not None

# Generated at 2022-06-21 20:26:13.870480
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies, Currency
    from pypara.exchange import FXRateLookupError, FXRateService

    # Test error message:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2020-05-17"


# Generated at 2022-06-21 20:26:22.239861
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from unittest import TestCase, mock

    class Queryable(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass

        def queries(self, queries, strict=False):
            pass

    # Create an FX rate service:
    service = Queryable()
    assert service

    # Check that the methods are actually abstract:
    with TestCase().assertRaises(TypeError):
        service.query(None, None, None)
    with TestCase().assertRaises(TypeError):
        service.queries(None)

    # Check that the abstract methods are implemented:
    assert callable(service.query)
    assert callable(service.queries)

    # Check that static field is set:
    assert FXRateService.default is None

    # Make sure that you can

# Generated at 2022-06-21 20:26:31.069730
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate.
    """
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currency

    ccy1 = Currency.of("EUR")
    ccy2 = Currency.of("EUR")
    date = datetime.date.today()
    value = Decimal("2")

    rate = FXRate(ccy1, ccy2, date, value)

    assert rate.ccy1 == ccy1
    assert rate.ccy2 == ccy2
    assert rate.date == date
    assert rate.value == value


# Generated at 2022-06-21 20:26:57.950089
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## In-memory FX rate service:
    class InMemoryFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate] = None) -> None:
            """
            Initializes in-memory foreign exchange rate service.

            :param rates: An iterable of :class:`FXRate` instances.
            """
            if rates is None:
                rates = []
            self.rates = list(rates)


# Generated at 2022-06-21 20:27:09.684722
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    ## Case 0
    from .currencies import Currencies
    from .dates import DateTime

    from .fxrates import FXRateService
    from .fxrates import FXRateService as Svc

    import pytest

    ## We should be able to create an FX rate service instance.
    svc = FXRateService()

    ## Case 0
    with pytest.raises(NotImplementedError):
        svc.query(Currencies["EUR"], Currencies["USD"], DateTime.now())
        svc.queries([(Currencies["EUR"], Currencies["USD"], DateTime.now())])

    ## Case 1
    class SvcImpl(Svc):

        def __init__(self, fx: FXRate) -> None:
            self.fx = fx


# Generated at 2022-06-21 20:27:17.795261
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    rate = FXRate(Currencies['EUR'], Currencies['USD'], date(2019, 9, 5), Decimal('2'))
    assert rate.ccy1 == Currencies['EUR']
    assert rate.ccy2 == Currencies['USD']
    assert rate.date == date(2019, 9, 5)
    assert rate.value == Decimal('2')


# Generated at 2022-06-21 20:27:27.887107
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fxt import MemoryFXRateService

    # Setup
    date = datetime.date(2016, 12, 31)
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    value = Decimal("2.0000")
    queries = [(ccy1, ccy2, date)]
    service = MemoryFXRateService(FXRate(ccy1, ccy2, date, value))

    # Test
    rates = service.queries(queries)
    assert next(rates) == FXRate.of(ccy1, ccy2, date, value)

# Generated at 2022-06-21 20:27:34.781887
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:27:42.977318
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    setattr(FXRate, '__annotations__', {})
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:27:43.920678
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## TODO:
    pass


# Generated at 2022-06-21 20:27:50.842989
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    # Import
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    # Create the native rate
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    # Create the reverse rate
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    # Verify that reverse operation is correct
    assert nrate.__invert__() == rrate
    # Verify that reverse operation is correct
    assert ~nrate == rrate


# Generated at 2022-06-21 20:27:57.317156
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests :class:`~pypara.fxrates.FXRateLookupError` constructor.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate

    ## Test positive cases:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], date.today())
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == date.today()


# Generated at 2022-06-21 20:28:05.968762
# Unit test for constructor of class FXRateService
def test_FXRateService():  # pragma: no cover

    from unittest import TestCase, main
    from .services import ListFXRateService

    ## Fixture:
    class TestFXRateService(TestCase):

        def test_query(self):
            ## Arrange:
            from decimal import Decimal
            from .services.hdf import HDFFXRateService
            hdf_service = HDFFXRateService("testdata/fx.h5")
            hdf_service.insert("EURUSD", [[1, 1.5], [2, 1.6], [3, 1.7], [4, 1.8]])

            ## Act:

# Generated at 2022-06-21 20:28:42.103444
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    e = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert e.ccy1 == Currencies["EUR"]
    assert e.ccy2 == Currencies["USD"]
    assert e.asof == datetime.date.today()
    assert str(e) == "Foreign exchange rate for €/USD not found as of " + str(datetime.date.today())


# Generated at 2022-06-21 20:28:42.637260
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService

# Generated at 2022-06-21 20:28:49.484597
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.
    """

    # Imports:
    from datetime import datetime
    from pypara.currencies import Currencies

    # Test 1:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.now().date())

    assert error.args[0] == "Foreign exchange rate for EUR/USD not found as of %s" % datetime.now().date()



# Generated at 2022-06-21 20:28:57.543300
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Unit test for constructor of class FXRate
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    r1 = FXRate(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], date=datetime.date.today(), value=Decimal("2"))
    assert r1.ccy1 == Currencies["EUR"]
    assert r1.ccy2 == Currencies["USD"]
    assert r1.date == datetime.date.today()
    assert r1.value == Decimal("2")


# Generated at 2022-06-21 20:29:03.812619
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.services.fxrates.dummy import DummyFXRateService
    from pypara.services.fxrates.env import ENVFXRateService
    from pypara.currencies import Currencies

    # Validate query method of dummy service:
    service = DummyFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), True) == FXRate(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1.25")
    )
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), False) is None

    # Validate query method of env service:
    service = ENVFXRateService()

# Generated at 2022-06-21 20:29:11.494093
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2.1"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2.1")


# Generated at 2022-06-21 20:29:18.321277
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .commons.zeitgeist import now
    from .rates import FXRateService
    from .treasuries import ConstantRateSource
    from .util.config import init_config
    from .util.context import set_default

    class MyRateService(FXRateService):
        """
        Provides an implementation for unit tests.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1.code == "USD" and ccy2.code == "TRY" and asof == now().date():
                return FXRate(ccy1, ccy2, asof, Decimal("6.0"))

# Generated at 2022-06-21 20:29:24.255286
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:29:27.604294
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:29:33.894707
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import now
    from .fx import FXRateLookupError
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], now())
    except FXRateLookupError as error:
        assert str(error) == "Foreign exchange rate for EUR/USD not found as of " + now().isoformat()

# Generated at 2022-06-21 20:30:50.223700
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from .commons.temporal import DateTime
    from .currencies import Currency, Currencies
    from .refdata import QuoteType

    from .refdata.enums import QuoteType
    from .refdata.services import QuoteTypeService
    from .refdata.services import QuoteTypeService, QuoteTypeService

    ####################################################################################################################
    # First we need to register a proper quote type service:
    ####################################################################################################################

    service = QuoteTypeService()

    service.register(QuoteType.of(Currencies["EUR"], Currencies["USD"], QuoteType.SELECTOR.MID, "MID"))
    service.register(QuoteType.of(Currencies["EUR"], Currencies["USD"], QuoteType.SELECTOR.BID, "BID"))

# Generated at 2022-06-21 20:30:51.955026
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """



# Generated at 2022-06-21 20:30:58.663713
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:31:06.311040
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == datetime.date.today()
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of " + datetime.date.today().isoformat()


# Generated at 2022-06-21 20:31:12.173281
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test if method query of class FXRateService works as expected.
    """

    ## Create a dummy service:
    class MyService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass

        def queries(self, queries, strict=False):
            pass

    ## Implicit query:
    assert FXRateService.query(MyService(), Currency("EUR"), Currency("USD"), Date.today()) is None

    ## Explicit query:
    with pytest.raises(NotImplementedError):
        FXRateService.query(MyService(), Currency("EUR"), Currency("USD"), Date.today(), strict=True)



# Generated at 2022-06-21 20:31:19.351181
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from .currencies import Currency

    ccy1 = Currency.of("EUR", "euro")
    ccy2 = Currency.of("USD", "usd")
    asof = datetime.date(2017, 8, 15)

    error = FXRateLookupError(ccy1, ccy2, Date.of(asof))
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2017-08-15"


# Generated at 2022-06-21 20:31:23.081894
# Unit test for constructor of class FXRateService
def test_FXRateService():
    service = FXRateService()
    assert service.query(Currency("EUR"), Currency("TRY"), Date.today()) is None
    assert list(service.queries([(Currency("EUR"), Currency("TRY"), Date.today())])) == [None]

# Generated at 2022-06-21 20:31:30.232014
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests the __invert__ method of class FXRate.
    """
    from pypara.currencies import Currencies

    import datetime

    from decimal import Decimal

    rate = FXRate(Currencies["EUR"],
                  Currencies["USD"],
                  datetime.date.today(),
                  Decimal("2"))
    rrate = FXRate(Currencies["USD"],
                   Currencies["EUR"],
                   datetime.date.today(),
                   Decimal("0.5"))
    assert(rrate == ~rate)

# Generated at 2022-06-21 20:31:36.674518
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.tests.fxrates import TestFXRateService

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    service = TestFXRateService()
    service.rates = [rate]

    assert service.query(
        Currencies["EUR"], Currencies["USD"], datetime.date(2016, 1, 1)
    ) == FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2015, 1, 1), Decimal("0.5"))


# Generated at 2022-06-21 20:31:44.375000
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")
