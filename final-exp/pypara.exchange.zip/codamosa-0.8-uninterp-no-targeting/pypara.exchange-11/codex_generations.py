

# Generated at 2022-06-21 20:22:13.347601
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class :class:`FXRateService`.
    """
    pass

# Generated at 2022-06-21 20:22:21.341372
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:22:27.480210
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """Unit test for constructor of class FXRateLookupError."""
    from .currencies import Currency

    try:
        raise FXRateLookupError(Currency("USD"), Currency("EUR"), Date(2000, 1, 2))
    except FXRateLookupError as ex:
        assert ex.ccy1 == Currency("USD")
        assert ex.ccy2 == Currency("EUR")
        assert ex.asof == Date(2000, 1, 2)


# Generated at 2022-06-21 20:22:34.392743
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:22:44.879515
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Unit test for constructor of class FXRateLookupError
    """
    from decimal import Decimal
    from .currencies import Currency
    from .commons.zeitgeist import Date

    ## These will pass
    FXRateLookupError(Currency.USD, Currency.EUR, Date.today())
    FXRateLookupError(Currency.USD, Currency.EUR, Date.today())

    ## These will fail
    try:
        FXRateLookupError(Currency.USD, Currency.USD, Date.today())
        assert False
    except ValueError:
        pass

    try:
        FXRateLookupError(Currency.USD, Currency.EUR, Date.today(), rate=Decimal(2))
        assert False
    except TypeError:
        pass



# Generated at 2022-06-21 20:22:53.640171
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .temporal import Date
    from datetime import date
    from decimal import Decimal
    from pypara.finance.foreign_exchange import FXRateLookupError
    # Test
    with pytest.raises(FXRateLookupError):
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date(date.today()), Decimal("2"))
# Test
assert test_FXRateLookupError() is None


# Test case for inverting an FX rate

# Generated at 2022-06-21 20:22:56.290834
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the construction of class FXRateService.
    """
    ## Check the abstractness of the class:
    assert type.__abstractmethods__ == {"query", "queries"}

# Generated at 2022-06-21 20:23:01.681507
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    try:
        raise FXRateLookupError(Currency("EUR", 2), Currency("USD", 2), Date.of_iso("2020-01-01"))
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2020-01-01"
        assert e.ccy1 == Currency("EUR", 2)
        assert e.ccy2 == Currency("USD", 2)
        assert e.asof == Date.of_iso("2020-01-01")

# Generated at 2022-06-21 20:23:09.448187
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:23:19.500857
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Temporal, Temporals
    fxRate = FXRate(Currency.of(1), Currency.of(2), Temporal.of(datetime.date.today()), Decimal(1.0))
    inverted = ~fxRate
    assert inverted.ccy1 == Currency.of(2)
    assert inverted.ccy2 == Currency.of(1)
    assert inverted.date == Temporal.of(datetime.date.today())
    assert inverted.value == Decimal(1.0) ** -1


# Generated at 2022-06-21 20:23:30.547677
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime as dt
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], dt.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == dt.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:23:41.517130
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D103
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.currencies.in_memory import InMemoryCurrencyService
    from pypara.time import LocalDate
    from pypara.fx_rates.in_memory import InMemoryFXRateService
    from pypara.fx_rates import FXRateLookupError

    class MyFXRateService(InMemoryFXRateService):

        def __init__(self):
            self.fxrates = {
                (Currency("EUR"), Currency("USD"), LocalDate(2020, 1, 1)): FXRate(Currency("EUR"), Currency("USD"), LocalDate(2020, 1, 1), Decimal(1.2)),
            }


# Generated at 2022-06-21 20:23:52.325635
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import pytest
    from pypara.currencies import Currency

    with pytest.raises(FXRateLookupError) as error:
        raise FXRateLookupError(ccy1=Currency("EUR", "EURO", "978"), ccy2=Currency("USD", "US DOLLAR", "840"),
                                asof="2017-01-01")

    assert error.value.args == ("Foreign exchange rate for EUR/USD not found as of 2017-01-01",)
    assert str(error.value) == "Foreign exchange rate for EUR/USD not found as of 2017-01-01"


# Generated at 2022-06-21 20:24:00.486439
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class FXRateServiceStub(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 != ccy2 and value != ONE:
                raise ValueError("FX rate to the same currency must be `one`.")
            return FXRate(ccy1, ccy2, asof, rate)

    rate = Decimal("2")
    fx_rate_service = FXRateServiceStub()
    fx_rate = fx_rate_service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-21 20:24:10.558761
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, Decimal("1"))

            if ccy1 == "EUR" and ccy2 == "USD":
                return FXRate(ccy1, ccy2, asof, Decimal("1.23"))

            if ccy1 == "USD" and ccy2 == "EUR":
                return FXRate(ccy1, ccy2, asof, Decimal("0.81"))


# Generated at 2022-06-21 20:24:16.577464
# Unit test for constructor of class FXRate
def test_FXRate():
    fxRate = FXRate('EUR', 'TRY', '20-08-2019', '1.0')
    assert fxRate.ccy1 == 'EUR'
    assert fxRate.ccy2 == 'TRY'
    assert fxRate.date == '20-08-2019'
    assert fxRate.value == 1.0
    print('test_FXRate ran succesfully')


# Generated at 2022-06-21 20:24:24.417244
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()
    error = FXRateLookupError(ccy1, ccy2, date)

    assert str(error) == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {date}"


# Generated at 2022-06-21 20:24:28.645133
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:34.534211
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:24:41.631425
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    class FXRateServiceMock(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None
    # Check FXRateService.query
    assert FXRateServiceMock().query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) == FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

# Generated at 2022-06-21 20:24:55.412365
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.dates import LocalDateTime

    class DummyFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate.of(ccy1, ccy2, asof, Decimal("5"))

        def queries(self, queries, strict=False):
            return map(lambda x: self.query(*x), queries)

    ## Trivial test case:
    service = DummyFXRateService()
    queries = [
        (Currencies["USD"], Currencies["EUR"], LocalDateTime.now()),
        (Currencies["JPY"], Currencies["CHF"], LocalDateTime.now()),
    ]
   

# Generated at 2022-06-21 20:25:04.805760
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate
    ccy1, ccy2 = Currencies["EUR"], Currencies["USD"]
    date = date(2000, 1, 1)
    value = Decimal("2")
    fx1 = FXRate(ccy1, ccy2, date, value)
    fx2 = FXRate(ccy2, ccy1, date, Decimal("0.5"))
    assert ~fx1 == fx2


# Generated at 2022-06-21 20:25:05.221087
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService

# Generated at 2022-06-21 20:25:16.626657
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    from .commons.numbers import ONE, ZERO
    from .fxrates import FXRate

    # Test wrong types:
    try:
        FXRate(1, Currencies["USD"], Date.today(), ONE)
        assert False
    except ValueError:
        assert True

    try:
        FXRate(Currencies["USD"], 1, Date.today(), ONE)
        assert False
    except ValueError:
        assert True

    try:
        FXRate(Currencies["USD"], Currencies["EUR"], Date.today(), ZERO)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 20:25:27.826177
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import FXCurve

    ## Assert the exception:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2020-09-15"

    ## Assert the exception:
    try:
        raise FXRateLookupError(Currencies["USD"], Currencies["TRY"], datetime.date.today())
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for USD/TRY not found as of 2020-09-15"

    ## Assert the exception:

# Generated at 2022-06-21 20:25:37.898988
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError(): # noqa:
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    import datetime

    ## Try to convert without an actual rate:
    ccy1 = Currencies["USD"]
    ccy2 = Currencies["EUR"]
    date = Date.today()
    try:
        raise FXRateLookupError(ccy1, ccy2, date)
    except FXRateLookupError as e:
        assert e.ccy1 == ccy1
        assert e.ccy2 == ccy2
        assert e.asof == date
        assert str(e) == f"Foreign exchange rate for USD/EUR not found as of {date}"

    ## Try to convert without an actual rate:
    ccy1 = Currencies["USD"]
    ccy2 = Currencies["EUR"]
   

# Generated at 2022-06-21 20:25:39.796062
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # Executing:
    pass


# Generated at 2022-06-21 20:25:44.057935
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currency
    from .temporal import Temporal
    from .temporal import Date
    
    ccy1 = Currency('EUR')
    ccy2 = Currency('USD')
    date = Date(2018,1,1)
    rate = 1.0
    
    FXRateService(ccy1,ccy2,date,rate)

# Generated at 2022-06-21 20:25:48.854122
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests for foreign exchange rate service.
    """
    from pypara.currencies import Currency  # noqa: F401
    from pypara.commons.temporal import Temporal  # noqa: F401
    from pypara.market.fx import FXRateService  # noqa: F401
    pass

# Generated at 2022-06-21 20:26:00.372297
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests :method:`FXRateLookupError.__init__` method.
    """
    from .currencies import USD
    from .time import Date
    from .externals.abc import abstractmethod
    from .externals.typing import NamedTuple, Tuple

    class FXRate(NamedTuple):
        """
        Defines a foreign exchange (FX) rate.

        :param ccy1: The first currency of the FX rate.
        :param ccy2: The second currency of the FX rate.
        """
        ccy1: str
        ccy2: str

    class FXRateService(metaclass=ABCMeta):
        """
        Provides an abstract class for serving foreign exchange rates.
        """


# Generated at 2022-06-21 20:26:20.097374
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date, timedelta
    from pypara.currencies import Currencies

    from unittest.mock import MagicMock
    from pypara.services.fxrates.abstract import FXRateService, FXRateLookupError

    ## Setup a mock service:
    class _MockFXRateService(FXRateService):
        def query(self, *args, **kwargs):
            raise NotImplementedError()

        def queries(self, queries, strict=False):
            for q in queries:
                ccy1, ccy2, asof = q
                if ccy1 == Currencies['EUR'] and ccy2 == Currencies['USD'] and asof == date.today():
                    yield FXRate(Currencies['EUR'], Currencies['USD'], asof, Decimal("2"))

# Generated at 2022-06-21 20:26:30.703230
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D102
    from .temporal import Temporal
    from .currencies import Currencies

    ## Set up a query:
    query = (Currencies["EUR"], Currencies["USD"], Temporal.now())

    ## Find a service that supports the above query:
    from .sources import Source
    from .sources.rates_api import RatesAPIFXRateService
    from .sources.open_rates import OpenRatesFXRateService

    service = None
    for service in [RatesAPIFXRateService(), OpenRatesFXRateService()]:
        try:
            service.query(*query)
            break
        except FXRateLookupError:
            pass

    assert service is not None


# Generated at 2022-06-21 20:26:39.180956
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    class _FXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None

    FXRateService.default = _FXRateService()
    try:
        fxrates = FXRateService.default.query("USD", "EUR", "2018-12-07", strict=True)
        assert fxrates is None   # pragma: no cover
    except FXRateLookupError as error:
        assert error.ccy1 == "USD"
        assert error.ccy2 == "EUR"
        assert error.asof == "2018-12-07"

# Generated at 2022-06-21 20:26:50.449824
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    class TempService(FXRateService):
        def query(self, ccy1, ccy2, _asof, _strict):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, datetime.date.today(), Decimal("2"))

        def queries(self, _queries, _strict):
            return [
                FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
                None,
            ]


# Generated at 2022-06-21 20:27:00.031180
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit tests for :method:`FXRateService.query`
    """
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.services.fx_rate.memory import MemoryFXRateService
    from pypara.temporal import Temporal

    # No services
    assert FXRateService.default is None

    # Testing with an in-memory service

# Generated at 2022-06-21 20:27:12.055243
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.currencies import Country
    from pypara.currencies import Currency
    import datetime
    from decimal import Decimal
    from pypara.currencies.exchange import FXRate
    from pypara.currencies.exchange import FXRateService
    from pypara.currencies.exchange import FXRateLookupError

    class TestService(FXRateService):
        def __init__(self):
            pass


# Generated at 2022-06-21 20:27:14.962762
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    # Create a valid foreign exchange rate:
    try:
        raise FXRateLookupError(Currency("USD"), Currency("EUR"), Date())
    except FXRateLookupError as e:
        assert isinstance(e, FXRateLookupError)



# Generated at 2022-06-21 20:27:28.003355
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    import random
    import string
    from decimal import Decimal

    sample_date = datetime.date.today()
    sample_date_guess = datetime.date(1990, 1, 1)

    queries = [("USD", "EUR", sample_date), ("TRY", "USD", sample_date), ("TRY", "USD", sample_date_guess)]
    class QueryService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            return "123" if asof == sample_date else None

        def queries(self, queries, strict):
            return [self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries]
    query_service = QueryService()

# Generated at 2022-06-21 20:27:37.498241
# Unit test for constructor of class FXRate
def test_FXRate():
    ## Try simple FX rate:
    rate = FXRate("EUR", "USD", "2018.08.16", "2")
    assert str(rate) == "FXRate(ccy1='EUR', ccy2='USD', date='2018.08.16', value='2')"

    ## Try FX rate w/ rate as float:
    rate = FXRate("EUR", "USD", "2018.08.16", 2.5)
    assert str(rate) == "FXRate(ccy1='EUR', ccy2='USD', date='2018.08.16', value='2.5')"

    ## Try to create an invalid FX rate (rate == 0):

# Generated at 2022-06-21 20:27:41.351898
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    assert str(FXRateLookupError(Currency("USD"), Currency("CAD"), Date(2018, 1, 1))) == \
           "Foreign exchange rate for USD/CAD not found as of 2018-01-01"



# Generated at 2022-06-21 20:28:03.389414
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    r = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert r.ccy1 == Currencies["EUR"]
    assert r.ccy2 == Currencies["USD"]
    assert r.date == datetime.date.today()
    assert r.value == Decimal("2")



# Generated at 2022-06-21 20:28:15.913463
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from pypara.currencies import Currencies
    from pypara.finance.temporal import Temporal

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def __init__(self):
            super().__init__()
            self._rates = {}  # type: Dict[Tuple[Currency, Currency, Temporal], Decimal]

        def __getitem__(self, item: FXRateService.TQuery) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate for a given query.
            """
            return self._rates.get(item)

        def __setitem__(self, key: FXRateService.TQuery, value: FXRate) -> None:
            """
            Sets the foreign exchange rate for a given query.
            """
           

# Generated at 2022-06-21 20:28:19.142255
# Unit test for constructor of class FXRateService
def test_FXRateService():
    ## Test abstract methods:
    abstract_methods = ("query", "queries")
    for method in abstract_methods:
        if abstractmethod(getattr(FXRateService, method, None)):
            raise RuntimeError(f"{method} is not abstract!")

# Generated at 2022-06-21 20:28:31.769263
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    with pytest.raises(ValueError) as excinfo:
        rate = FXRate(None, Currencies["USD"], datetime.date.today(), Decimal("2.0"))
    assert str(excinfo.value) == "CCY/1 must be of type `Currency`."

    with pytest.raises(ValueError) as excinfo:
        rate = FXRate(Currencies["EUR"], None, datetime.date.today(), Decimal("2.0"))
    assert str(excinfo.value) == "CCY/2 must be of type `Currency`."


# Generated at 2022-06-21 20:28:32.814834
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None

# Generated at 2022-06-21 20:28:40.183819
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal

    # Test case 1
    EUR = Currencies["EUR"]
    USD = Currencies["USD"]
    DATE = datetime.date.today()
    VALUE = Decimal("2")
    rate1 = FXRate(EUR, USD, DATE, VALUE)
    assert rate1.ccy1 == EUR
    assert rate1.ccy2 == USD
    assert rate1.date == DATE
    assert rate1.value == VALUE

    # Test case 2
    assert ~rate1 == FXRate(USD, EUR, DATE, Decimal("0.5"))


# Generated at 2022-06-21 20:28:50.040480
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Runs test for the constructor of class :class:`FXRateLookupError`.

    **Test Plan:**

    - Create an error,
    - Check that it has all of the expected properties,
    - And check that it has the expected exception message.
    """
    # Create an error:
    from .currencies import Currencies
    from .commons.zeitgeist import now
    error = FXRateLookupError(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], asof=now())

    # Check that it has all of the expected properties:
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == now()

    # Check that it has the expected exception message:

# Generated at 2022-06-21 20:28:59.951175
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .enums import Temporal

    from .testing.factories import FXRateFactory

    ## Create a foreign exchange rate:
    rate = FXRateFactory(ccy1=Currency.USD, ccy2=Currency.TRY, asof=Temporal.now().date)

    ## Create an instance of the foreign exchange rate service:
    class FXRateServiceStub(FXRateService):
        """
        Defines a stub implementation of the foreign exchange rate service.
        """


# Generated at 2022-06-21 20:29:12.309413
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    :return: True if unit test is successful.
    """
    # Import
    from unittest import TestCase, mock
    from pypara.enums import Temporal
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRateService
    from pypara.temporals import Temporals

    # Define FX rates
    FX_RATES = [
        FXRate(Currencies["USD"], Currencies["EUR"], Temporals["20180401"], Decimal("2"))
    ]

    # Create service
    SERVICE = FXRateService()

    # Arrange

# Generated at 2022-06-21 20:29:16.793124
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:30:04.298660
# Unit test for constructor of class FXRate
def test_FXRate():
    rate = FXRate(ccy1='EUR', ccy2='USD', date='20160101', value='2')

# Generated at 2022-06-21 20:30:12.662723
# Unit test for constructor of class FXRate
def test_FXRate():

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:30:14.220027
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    pass


# Generated at 2022-06-21 20:30:25.279939
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    nrates = [nrate]

    class Test(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in nrates:
                if rate[0] == ccy1 and rate[1] == ccy2 and rate[2] == asof:
                    return rate

            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries)

# Generated at 2022-06-21 20:30:31.006224
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~urate == rrate


# Generated at 2022-06-21 20:30:33.443930
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of abstract class FXRateService.
    """
    from pypara.fx import FXRateService
    assert FXRateService is not None

# Generated at 2022-06-21 20:30:39.171021
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:30:46.101125
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    atuple = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert atuple[0] == Currencies["EUR"]
    assert atuple[1] == Currencies["USD"]
    assert atuple[2] == datetime.date.today()
    assert atuple[3] == Decimal("2")


# Generated at 2022-06-21 20:30:50.063792
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-21 20:30:57.724675
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests modern class FXRateService.
    """

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    s = TestFXRateService()
    assert isinstance(s, FXRateService)

