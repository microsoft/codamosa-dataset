

# Generated at 2022-06-21 20:22:16.394159
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from .currencies import Currencies
    from .temporal import Temporal

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict = False):
            return FXRate(ccy1, ccy2, asof.date, Decimal("1.0"))

        def queries(self, queries, strict = False):
            return (self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries)

    # Test FX rate service
    fxrs = TestFXRateService()
    fxr = fxrs.query(Currencies["CAD"], Currencies["USD"], Temporal.of("2019-07-01"))

# Generated at 2022-06-21 20:22:24.048369
# Unit test for constructor of class FXRate
def test_FXRate():

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:22:30.836908
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .__main__ import _main
    from decimal import Decimal
    from datetime import date
    from .currencies import Currencies
    eur = Currencies["EUR"]
    usd = Currencies["USD"]
    nrate = FXRate(eur, usd, date.today(), Decimal("2"))
    rrate = FXRate(usd, eur, date.today(), Decimal("0.5"))
    assert ~nrate == rrate
if __name__ == "__main__":
    test_FXRate___invert__()


# Generated at 2022-06-21 20:22:39.504598
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from pypara.currencies import Currency
    from pypara.fxrates import FXRate
    from datetime import date

    currency_1 = Currency.from_str("USD")
    currency_2 = Currency.from_str("EUR")
    date_1 = date(2017, 10, 1)
    value = 2
    fx_rate = FXRate(currency_1, currency_2, date_1, Decimal(value))
    inverted = fx_rate.__invert__()

    assert(inverted.value == Decimal(0.5))

# Generated at 2022-06-21 20:22:40.205364
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService()

# Generated at 2022-06-21 20:22:45.813182
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:22:53.200572
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    import datetime

    dt = datetime.date.today()
    error = FXRateLookupError(Currencies["USD"], Currencies["EUR"], Date(dt))
    assert error.ccy1 == Currencies["USD"]
    assert error.ccy2 == Currencies["EUR"]
    assert error.asof == Date(dt)


# Generated at 2022-06-21 20:23:02.057536
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency
    from typing import List

    class MockService(FXRateService):
        def __init__(self, pairs: List[FXRate]):
            self._pairs = pairs

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pair = ccy1, ccy2, asof
            if pair in self._pairs:
                return self._pairs.index(pair)
            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None


# Generated at 2022-06-21 20:23:04.809273
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .currencies.currencies import Currencies
    from .currencies.money import Money
    from .temporal import Temporal
    assert True


# Generated at 2022-06-21 20:23:15.431930
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date as Today

    error = FXRateLookupError(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], asof=Today())
    assert type(error) == FXRateLookupError
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == Today()
    assert str(error) == "Foreign exchange rate for EUR/USD not found as of 2018-09-13"


# Generated at 2022-06-21 20:23:28.088164
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of :class:`FXRateLookupError`.

    >>> import datetime
    >>> from pypara.currencies import Currency
    >>> raise FXRateLookupError(Currency("EUR"), Currency("USD"), datetime.date.today())
    Traceback (most recent call last):
        ...
    pypara.rates.fx.FXRateLookupError: Foreign exchange rate for EUR/USD not found as of 2017-08-07
    """
    pass


# Generated at 2022-06-21 20:23:28.601451
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert True

# Generated at 2022-06-21 20:23:29.421853
# Unit test for constructor of class FXRateService
def test_FXRateService():
    assert FXRateService.default is None



# Generated at 2022-06-21 20:23:33.893608
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    This method unit tests the FXRate constructor.
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")



# Generated at 2022-06-21 20:23:40.747265
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:23:41.282595
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    pass

# Generated at 2022-06-21 20:23:54.510824
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict):
            if ccy1 != Currencies["EUR"] or ccy2 != Currencies["USD"] or asof != datetime.date.today():
                return None
            return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

        def queries(self, queries, strict=False):
            pass

    service = TestFXRateService()
    rate = service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-21 20:23:59.001912
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rate2 = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~rate1 == rate2

# Generated at 2022-06-21 20:24:04.661545
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from .currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:24:16.418654
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError(): # noqa: D103
    """
    Tests :method:`FXRateLookupError.__init__`.
    """
    ## Import local modules:
    import pytest
    from pypara.currencies import Currencies

    ## Test default constructor:
    with pytest.raises(ValueError):
        FXRateLookupError(None, None, None)

    ## Test constructor with an invalid date:
    with pytest.raises(TypeError):
        FXRateLookupError(Currencies["EUR"], Currencies["USD"], "2015-06-15")

    ## Test with valid values:
    exc = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date("2015-06-15"))
    assert exc.ccy1 == Currencies["EUR"]
    assert exc.ccy2 == Currencies["USD"]

# Generated at 2022-06-21 20:24:37.256060
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test method queries of class FXRateService.
    """
    ## Test data:
    date1 = Date.from_yyyymmdd(2019, 1, 1)
    date2 = Date.from_yyyymmdd(2019, 1, 2)
    date3 = Date.from_yyyymmdd(2019, 1, 3)
    queries = [(Currency("EUR"), Currency("USD"), date1),
               (Currency("EUR"), Currency("USD"), date2),
               (Currency("EUR"), Currency("USD"), date3),
               (Currency("CHF"), Currency("USD"), date1),
               (Currency("CHF"), Currency("USD"), date2),
               (Currency("CHF"), Currency("USD"), date3)]

    ## Define the service:

# Generated at 2022-06-21 20:24:44.598695
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:24:50.732130
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for :class:`FXRateService`.
    """
    ## Assert constructor raises an abstract method error:
    from pypara.exceptions import AbstractMethodInvocationError
    fxs = FXRateService()
    try:
        fxs.query(Currency.DEFAULT, Currency.DEFAULT, Date.DEFAULT)
    except AbstractMethodInvocationError:
        pass
    except:
        raise
    else:
        raise AssertionError

# Generated at 2022-06-21 20:24:51.403445
# Unit test for constructor of class FXRate
def test_FXRate():
    im

# Generated at 2022-06-21 20:24:57.801089
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.triples import Temporal
    from pypara.fxrates import FXRateLookupError, FXRateService

    ## Implementation:
    class Service(FXRateService):
        # noinspection PyMethodMayBeStatic
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1), Decimal("2"))

# Generated at 2022-06-21 20:25:09.395092
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime as dt
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService

    # This is a dummy class for the sake of unit testing the abstract class:
    class Dummy(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> FXRate:
            if ccy1 == Currencies['EUR'] and ccy2 == Currencies['USD'] and asof == dt.date.today():
                return FXRate(Currencies['EUR'], Currencies['USD'], asof, Decimal('2'))


# Generated at 2022-06-21 20:25:16.659060
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    print("begin test_FXRateService_query")
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.fx import FXRateLookupError
    from pypara.lib.fx.db import FXRateSQLiteService

    # Mock configuration:
    db_path = "/Users/tugce/PycharmProjects/pypara/pypara/data/fx.db"
    db_mock = FXRateSQLiteService(db_path)

    # Test ValueError:
    try:
        db_mock.query(Currency("XXX"), Currencies["USD"], Date(2020, 11, 1), strict=True)
        raise ValueError("TypeError should be raised!")
    except FXRateLookupError as e:
        print("FXRateLookupError is caught.")

# Generated at 2022-06-21 20:25:23.816964
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .__main__ import __version__

    import datetime
    from decimal import Decimal

    from pypara.currencies import Currencies

    class TestRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    FXRateService.default = TestRateService()

    assert FXRateService.default

# Generated at 2022-06-21 20:25:28.644798
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    ## Test the foreign exchange rate lookup error:
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except LookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2018-05-16"

# Generated at 2022-06-21 20:25:38.493928
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporal import Temporal
    from .currencies import Currencies

    class Tester(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof.date, ONE + ONE)

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (FXRate(ccy1, ccy2, asof.date, ONE + ONE) for ccy1, ccy2, asof in queries)

    tester = Tester()


# Generated at 2022-06-21 20:26:00.666642
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(
        Currencies["EUR"],
        Currencies["USD"],
        datetime.date.today(),
        Decimal("2")
    )
    rrate = FXRate(
        Currencies["USD"],
        Currencies["EUR"],
        datetime.date.today(),
        Decimal("0.5")
    )
    assert ~nrate == rrate



# Generated at 2022-06-21 20:26:08.285521
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests :class:`FXRateService` class.
    """
    # noinspection PyUnresolvedReferences
    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    impl = FXRateServiceImpl()
    impl  # suppress warning
    return


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 20:26:19.927394
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from pypara.currencies import Currencies
    from pypara.zeitgeist import Date
    from pypara.fxrates import FXRateLookupError
    from decimal import Decimal

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise FXRateLookupError(ccy1, ccy2, asof)

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            raise FXRateLookupError(ccy1, ccy2, asof)

    FXRateService.default = TestFXRateService()

    # ccys = (Currencies["EUR"], Currencies["USD"])
    #

# Generated at 2022-06-21 20:26:27.821789
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert isinstance(nrate, FXRate)
    assert isinstance(nrate.ccy1, Currency)
    assert isinstance(nrate.ccy2, Currency)
    assert isinstance(nrate.date, datetime.date)
    assert isinstance(nrate.value, Decimal)

# Generated at 2022-06-21 20:26:37.535234
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .currencies import Currencies
    from .currencies import CurrencySet
    import datetime

    class DummyFXRateService(FXRateService):
        """
        Provides a dummy foreign exchange rate service for testing purposes.
        """

        def __init__(self) -> None:
            """
            Initializes the dummy foreign exchange rate service.
            """
            ## Keep the slots:
            self.__cache = dict()

            ## Populate the cache:
            rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            key = (Currencies["EUR"], Currencies["USD"], datetime.date.today())
            self.__cache[key] = rate


# Generated at 2022-06-21 20:26:45.950001
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate

    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:26:57.601630
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests constructor of class `FXRateLookupError`.
    """
    ## Initialize:
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    ## Execute:
    error = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.of(2012, 9, 24))

    ## Verify:
    assert error.ccy1 == Currencies["EUR"]
    assert error.ccy2 == Currencies["USD"]
    assert error.asof == Date.of(2012, 9, 24)
    assert isinstance(error.args[0], str)
    assert error.args[0] == "Foreign exchange rate for EUR/USD not found as of 2012-09-24"


# Generated at 2022-06-21 20:27:06.103424
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.
    """
    from .currencies import Currency
    from .commons.zeitgeist import Date
    try:
        raise FXRateLookupError(Currency.EUR, Currency.USD, Date.today())
    except FXRateLookupError as e:
        assert e.ccy1 == Currency.EUR
        assert e.ccy2 == Currency.USD
        assert e.asof == Date.today()
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 2020-02-19"


# Generated at 2022-06-21 20:27:10.893068
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert isinstance(rate, FXRate)

# Generated at 2022-06-21 20:27:18.108965
# Unit test for constructor of class FXRateService
def test_FXRateService():
    import unittest

    from decimal import Decimal
    from pypara.currencies import Currencies, Currency

    assert issubclass(FXRateService, ABCMeta)
    assert issubclass(FXRateService, object)
    assert FXRateService.default is None

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """


# Generated at 2022-06-21 20:27:59.564227
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    ccy1 == Currencies["EUR"]
    ccy2 == Currencies["USD"]
    date == datetime.date.today()
    value == Decimal("2")

    print("unit test for class FXRate is complete.")


# Generated at 2022-06-21 20:28:07.098887
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .services.utils import FXRateCurrencyError, FXRateDateError, FXRateValueError
    from .services.in_memory import InMemoryFXRateService
    from datetime import date
    import pytest

    ## Tests the query method:
    ccy1 = Currency.of("EUR")
    ccy2 = Currency.of("USD")
    asof = date.today()
    fx_rate_service = InMemoryFXRateService([FXRate(ccy1, ccy2, asof, Decimal("1.0"))])
    assert (
        fx_rate_service.query(ccy1, ccy2, asof) == FXRate(ccy1, ccy2, asof, Decimal("1.0"))
    )  # noqa: E721

    ## Tests the query method with a strict lookup:

# Generated at 2022-06-21 20:28:16.287471
# Unit test for constructor of class FXRate
def test_FXRate():
    """
    Test the FX rate class constructor.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:28:21.587490
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of class FXRateService
    """

    # Creating an instance of class FXRateService
    fx_rate = FXRateService()

    # Assert if it is an instance of FXRateService
    assert isinstance(fx_rate, FXRateService)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 20:28:29.518993
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")
    return

# Generated at 2022-06-21 20:28:35.080708
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-21 20:28:42.433729
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## Check type:
    from pypara.currencies import Currency, Currencies
    from pypara.exchanges import FXRateLookupError
    from pypara.commons.zeitgeist import Date
    fxlookuperror = FXRateLookupError(Currency("USD"), Currencies["EUR"], Date(2018, 1, 1))
    assert repr(fxlookuperror) == "Foreign exchange rate for USD/EUR not found as of 2018-01-01"
    assert isinstance(fxlookuperror, FXRateLookupError)
    assert isinstance(fxlookuperror, LookupError)
    assert isinstance(fxlookuperror, Exception)
    assert isinstance(fxlookuperror, BaseException)
    assert not isinstance(fxlookuperror, TypeError)

# Generated at 2022-06-21 20:28:53.421331
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRateService as _FXRateService
    from datetime import date

    ## As of today, currency pair EUR/USD is equal to 1.33
    query = (Currencies["EUR"], Currencies["USD"], Temporal(date=date.today()))
    fxserv = _FXRateService()
    fxrate = fxserv.query(*query)
    assert fxrate[0] == Currencies["EUR"]
    assert fxrate[1] == Currencies["USD"]
    assert fxrate[2] == Temporal(date=date.today())
    assert fxrate[3] == Decimal("1.33")

# Unit test

# Generated at 2022-06-21 20:29:01.582594
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 is Currencies["EUR"] and ccy2 is Currencies["USD"] and asof is datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None

        def queries(self, queries, strict=False):
            for query in queries:
                yield self.query(*query)

    service = MockFXRateService()

# Generated at 2022-06-21 20:29:04.418434
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError(): # noqa: D103
    assert FXRateLookupError(Currency("EUR"), Currency("USD"), Date(2018, 1, 1))

# Generated at 2022-06-21 20:30:23.643617
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query on class FXRateService
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class Service(FXRateService):
        """
        A custom FX rate service implementation.
        """

        def query(self, ccy1, ccy2, asof, strict = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries, strict = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("1.0"))

    service = Service()

# Generated at 2022-06-21 20:30:34.441698
# Unit test for constructor of class FXRate
def test_FXRate():
    # Foreign exchange rate between two same currencies must be one:
    ccy1 = Currency("EUR", "Euro", "€")
    ccy2 = Currency("EUR", "Euro", "€")
    asof = Date("2019-01-01")
    rate = FXRate(ccy1, ccy2, asof, ONE)

    assert rate.ccy1 == ccy1
    assert rate.ccy2 == ccy2
    assert rate.asof == asof
    assert rate.value == ONE
    assert rate[0] == ccy1
    assert rate[1] == ccy2
    assert rate[2] == asof
    assert rate[3] == ONE

    # Following two assertions should raise ValueError:
    # rate = FXRate(ccy1, ccy2, asof, "2")
    #

# Generated at 2022-06-21 20:30:40.010020
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal

    from pypara.currencies import Currencies

    ## Test the construction of the FXRate object
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:30:51.248109
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from unittest.mock import Mock, patch
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    ## Set the date for testing:
    date = datetime.date.today()
    ## Set the pair for testing:
    pair = (Currencies["EUR"], Currencies["USD"])
    ## Set the fxrates for testing:
    fxrates = [
        FXRate(pair[0], pair[1], date, Decimal("1.20")),
        FXRate(pair[0], pair[1], date, Decimal("1.22"))
    ]
    ## Create a foreign exchange-rate service mock:
    fx_rate_service = Mock(spec=FXRateService)
    ## Define the side-effect:

# Generated at 2022-06-21 20:30:55.126226
# Unit test for constructor of class FXRate
def test_FXRate():
  try:
    FXRate("EUR", "USD", Date.today(), Decimal("2"))
  except:
    print("test_FXRate fails.")
  else:
    print("test_FXRate succeeds.")

test_FXRate()

# Generated at 2022-06-21 20:31:05.666077
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from collections import Iterable
    from types import GeneratorType
    from .commons.zeitgeist import LocalDate
    from .currencies import Currency, Currencies

    ## Implementation:
    class Test(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: LocalDate, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate.of(ccy1, ccy2, asof, Decimal("1.0"))
            return FXRate.of(ccy1, ccy2, asof, Decimal("1.0")) if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] else None


# Generated at 2022-06-21 20:31:11.689929
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies

    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date(day=31, month=12, year=2018))
    except FXRateLookupError as ex:
        assert ex.ccy1 == Currencies["EUR"]
        assert ex.ccy2 == Currencies["USD"]
        assert ex.asof == datetime.date(day=31, month=12, year=2018)
        assert str(ex) == "Foreign exchange rate for EUR/USD not found as of 2018-12-31"
    else:
        raise AssertionError("FXRateLookupError test failed!")



# Generated at 2022-06-21 20:31:22.001274
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class MyFxRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(1))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal(1))

    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    service = MyFxRateService()


# Generated at 2022-06-21 20:31:30.485601
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ## Mock some objects:
    from unittest.mock import Mock
    ccy1 = Mock(spec=Currency)
    ccy2 = Mock(spec=Currency)
    ccy1.code = "EUR"
    ccy2.code = "USD"
    asof = Mock(spec=Date)
    asof.as_string = "2020-01-31"

    ## Create the FX rate lookup error:
    error = FXRateLookupError(ccy1, ccy2, asof)

    ## Check the message:
    assert error.message == "Foreign exchange rate for EUR/USD not found as of 2020-01-31"


# Generated at 2022-06-21 20:31:36.801019
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .currencies.fixtures import CurrencyFixtureService
    from .dates import DateFixtures
    from .fxrates import FXRateFixtureService
    from .fxrates.memory import MemoryFXRateService

    ## Create the fixture service:
    fxrate_fixture_service = FXRateFixtureService(default_resolver=CurrencyFixtureService())
    fxrate_service = MemoryFXRateService(fxrate_fixture_service.query_ordered(date="today"))

    ## Query an existing FX rate:
    fxrate = fxrate_service.query(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], asof=DateFixtures["today"])
    assert fxrate is not None
    assert fxrate.date.date == fxrate_service._