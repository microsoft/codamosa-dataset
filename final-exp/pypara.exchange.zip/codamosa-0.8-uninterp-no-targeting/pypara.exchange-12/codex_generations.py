

# Generated at 2022-06-21 20:22:08.234789
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert FXRateService().query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) is None


# Generated at 2022-06-21 20:22:11.739249
# Unit test for constructor of class FXRate
def test_FXRate():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:22:21.680719
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests construction of the foreign exchange rate lookup error.
    """

    # Import the class to be tested:
    from .currencies import Currencies
    from .exchanges import FXRateLookupError

    # Test the error:
    fxerrors = FXRateLookupError(Currencies["EUR"], Currencies["USD"], Date.today())
    assert fxerrors.ccy1 == Currencies["EUR"]
    assert fxerrors.ccy2 == Currencies["USD"]
    assert fxerrors.asof == Date.today()
    assert str(fxerrors) == "Foreign exchange rate for EUR/USD not found as of {0}".format(Date.today())



# Generated at 2022-06-21 20:22:27.104653
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate

# Generated at 2022-06-21 20:22:34.342813
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .currencies import Currency, Currencies
    from .fx_rates import FXRate
    from .zeitgeist import Date
    from decimal import Decimal
    """
    Test cases for:

    1. Basic functionality of class `FXRateService`.
    2. Raise error when query currency is not found.
    3. Raise error when foreign exchange rate is None.
    """
    # Create a test service:
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool=False) -> Optional[FXRate]:
            if not isinstance(ccy1, Currency):
                raise ValueError("Argument `ccy1` is not a `Currency`.")

# Generated at 2022-06-21 20:22:45.165877
# Unit test for method queries of class FXRateService

# Generated at 2022-06-21 20:22:56.947140
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from .commons.zeitgeist import Date
    from .currencies import Currency, EUR, USD

    from mock import patch
    import pytest

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    with patch(__name__ + ".FXRateService.default", new_callable = TestFXRateService):
        assert FXRateService.default.query(EUR, USD, Date.today()) is None
        assert FXRateService.default.queries([])

    with pytest.raises(TypeError):
        FXRateService.default

# Generated at 2022-06-21 20:22:59.733539
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """Tests the functionality of method query of class FXRateService."""
    import decimal
    import datetime
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    # FXRateService.query needs to be implemented by subclasses



# Generated at 2022-06-21 20:23:11.700178
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .time import Temporal
    from .exchanges import FXRateServices
    from datetime import date
    from decimal import Decimal
    service = FXRateServices.default
    # Fail query
    try:
        service.query(Currencies["EUR"], Currencies["USD"], Temporal("2017-01-02"))
        assert False
    except FXRateLookupError:
        pass
    # Success query
    result = service.query(Currencies["EUR"], Currencies["USD"], Temporal("2017-01-03"))
    assert isinstance(result, FXRate)
    assert result.ccy1 == Currencies["EUR"]
    assert result.ccy2 == Currencies["USD"]
    assert isinstance(result.date, date)
    assert isinstance(result.value, Decimal)


# Generated at 2022-06-21 20:23:21.381504
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Fails the unit test for method queries of class FXRateService.
    """
    from .currencies import Currencies
    from .markets import FXMarket
    from .temporal import DateTime

    base = Currencies["EUR"]
    terms = [Currencies["USD"], Currencies["TRY"], Currencies["GBP"]]
    asofs = [DateTime.parse("2019-01-01"),
             DateTime.parse("2019-01-02"),
             DateTime.parse("2019-01-03")]
    strict = True

    queries = [(base, term, asof) for term in terms for asof in asofs]
    fx_market = FXMarket.of("EUR")
    rates = fx_market.service.queries(queries, strict)


# Generated at 2022-06-21 20:23:31.566230
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():  # noqa: D103
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert rrate == ~nrate


# Generated at 2022-06-21 20:23:40.506938
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    except Exception as ex:
        err = ex
    assert err.ccy1 == Currencies["EUR"]
    assert err.ccy2 == Currencies["USD"]
    assert err.asof == datetime.date.today()
    assert err.args == (
        f"Foreign exchange rate for {Currencies['EUR']}/{Currencies['USD']} not found as of {datetime.date.today()}",
    )


# Generated at 2022-06-21 20:23:48.349873
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from unittest import TestCase
    from datetime import date
    from decimal import Decimal
    from .currencies import EUR, USD
    from .markets import FX

    class FXRateTest(TestCase):
    
        def test_FXRate___invert__(self):
            from .fxrates import FXRate
            rate = FXRate(EUR, USD, date(2020, 3, 18), Decimal("2"))
            rrate = FXRate(USD, EUR, date(2020, 3, 18), Decimal("0.5"))
            self.assertEqual(rrate, ~rate)
            rate = FXRate(EUR, EUR, date(2020, 3, 18), Decimal("1"))
            rrate = FXRate(EUR, EUR, date(2020, 3, 18), Decimal("1"))

# Generated at 2022-06-21 20:23:55.889525
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class :class:`FXRateLookupError`.
    """
    _msg = "Foreign exchange rate for USD/EUR not found as of 2018-12-24"
    _ccy1 = Currency("USD")
    _ccy2 = Currency("EUR")
    _asof = Date(2018, 12, 24)
    _e = FXRateLookupError(_ccy1, _ccy2, _asof)
    assert isinstance(_e, LookupError)
    assert str(_e) == _msg


# Generated at 2022-06-21 20:23:59.736900
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert nrate == ~rrate

# Generated at 2022-06-21 20:24:07.477890
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies.currencies import Currency
    from pypara.currencies.currencies import Currencies
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    from pypara.currencies.fx import FXRateService
    from pypara.currencies.fx import FXRate
    from pypara.commons.zeitgeist import Date
    from datetime import date
    from pypara.currencies.memories import MemoryFXRateService
    service = MemoryFXRateService()
    rate = FXRate(ccy1, ccy2, Date(date.today()), 1.1)
    service.append(rate)
    assert service.query(ccy1, ccy2, Date(date.today()), False) == rate
    return service


# Generated at 2022-06-21 20:24:15.171071
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:24:19.407059
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert  rate.ccy1 == Currencies["EUR"]
    assert  rate.ccy2 == Currencies["USD"]
    assert  rate.date == datetime.date.today()
    assert  rate.value == Decimal("2")

# Generated at 2022-06-21 20:24:30.566638
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")
    assert rate[0] == Currencies["EUR"]
    assert rate[1] == Currencies["USD"]
    assert rate[2] == datetime.date.today()
    assert rate[3] == Decimal("2")
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
   

# Generated at 2022-06-21 20:24:39.511624
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    '''
    Tests the queries method of class FXRateService.
    '''

    # Imports
    import unittest
    import datetime
    import numpy
    from pypara.fx_rates.fixer import Fixer

    # Test Fixture
    class TestCase(unittest.TestCase):

        def test_query_with_an_empty_collection_of_queries_should_not_return_any_result(self):
            service = Fixer()
            queries = ()
            results = list(service.queries(queries))
            self.assertEqual(len(queries), len(results))

        def test_query_with_a_non_empty_collection_of_queries_should_return_the_correct_amount_of_results(self):
            service = Fixer()

# Generated at 2022-06-21 20:24:52.804547
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert ~rate == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))



# Generated at 2022-06-21 20:25:01.021002
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:25:07.505329
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:25:09.246311
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Unit test for constructor of class FXRateService
    """
    pass

# Generated at 2022-06-21 20:25:18.399062
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():

    ## Test construction and check the message
    try:
        raise FXRateLookupError("EUR", "USD", "20180228")
    except FXRateLookupError as e:
        assert str(e) == "Foreign exchange rate for EUR/USD not found as of 20180228"

    ## Check that the slots are set
    try:
        raise FXRateLookupError("EUR", "USD", "20180228")
    except FXRateLookupError as e:
        assert e.ccy1 == "EUR"
        assert e.ccy2 == "USD"
        assert e.asof == "20180228"


# Generated at 2022-06-21 20:25:24.994732
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:25:32.480977
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    ccy1 = Currency("EUR")
    ccy2 = Currency("CHF")
    asof = Date("2020-01-01")
    error = FXRateLookupError(ccy1, ccy2, asof)
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.asof == asof
    assert error.args[0] == f"Foreign exchange rate for {ccy1}/{ccy2} not found as of {asof}"


# Generated at 2022-06-21 20:25:33.542659
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:25:34.508380
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-21 20:25:39.446374
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:25:51.222312
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests if constructor of the abstract class :class:`FXRateService` raises the proper exception.
    """
    import pytest

    with pytest.raises(TypeError):
        FXRateService()

# Generated at 2022-06-21 20:26:00.506415
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    from .fxrates import FXRateLookupError
    from datetime import date
    try:
        raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], date(2017, 2, 1))
    except FXRateLookupError as e:
        assert e.ccy1 == Currencies["EUR"]
        assert e.ccy2 == Currencies["USD"]
        assert e.asof == Date(2017, 2, 1)
        assert e.message == f"Foreign exchange rate for EUR/USD not found as of {e.asof}"



# Generated at 2022-06-21 20:26:05.869090
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currencies
    import datetime
    def run(date: datetime.date) -> None:
        with pytest.raises(FXRateLookupError) as e:
            raise FXRateLookupError(Currencies["EUR"], Currencies["USD"], date)

    run(datetime.date.today())
    run(datetime.date(2010, 12, 25))


# Generated at 2022-06-21 20:26:13.624245
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:26:18.232888
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class FXRateServiceMock(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass

        def queries(self, queries, strict=False):
            pass

    FXRateServiceMock()

if __name__ == "__main__":
    test_FXRateService()

# Generated at 2022-06-21 20:26:24.886458
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():  # noqa: D103
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-21 20:26:35.497413
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Ensure we get None:
    service = FXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=False)  is None
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=True)   is None

    ## Ensure we get a :class:`FXRate` instance:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=False)  == rate

# Generated at 2022-06-21 20:26:47.624238
# Unit test for constructor of class FXRate
def test_FXRate(): # noqa: D401
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.currencies.european import EUR
    from pypara.currencies.north_american import USD
    from pypara.fx.rates import FXRate
    # Test with DateType
    rate = FXRate(EUR, USD, datetime.date.today(), Decimal("2"))
    assert (rate.ccy1, rate.ccy2, rate.date, rate.value) == (EUR, USD, datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == EUR
    assert ccy2 == USD
    assert date == datetime.date.today()
    assert value == Decimal("2")

# Generated at 2022-06-21 20:26:54.620531
# Unit test for constructor of class FXRate
def test_FXRate():
    from .currencies import Currency
    import datetime
    from decimal import Decimal
    eurUSDrate = FXRate(Currency.EUR, Currency.USD, datetime.date.today(), Decimal(1.1))
    assert eurUSDrate.ccy1 == Currency.EUR
    assert eurUSDrate.ccy2 == Currency.USD
    assert eurUSDrate.value == Decimal(1.1)

# Generated at 2022-06-21 20:27:01.700358
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests if the constructor of class FXRateLookupError works properly.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance import FXRate, FXRateLookupError

    #
    # Initialize:
    #
    ccy1, ccy2, asof, rate = Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1), Decimal(2)

    #
    # Check if FXRateLookupError exception is raised:
    #
    try:
        raise FXRateLookupError(ccy1, ccy2, asof)
    except FXRateLookupError as e:
        assert isinstance(e, FXRateLookupError)

# Generated at 2022-06-21 20:27:28.316002
# Unit test for constructor of class FXRate
def test_FXRate():
    from datetime import date
    from decimal import Decimal

    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 2, 1), Decimal("2"))
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == date(2020, 2, 1)
    assert rate.value == Decimal("2")


# Generated at 2022-06-21 20:27:35.060837
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.pydata.fxrates import FXRateServiceImpl
    from pypara.temporal import Temporals

    service = FXRateServiceImpl()
    queries = ( (Currencies["USD"], Currencies["EUR"], Temporals[-1])
              , (Currencies["USD"], Currencies["EUR"], Temporals[-2])
              , (Currencies["EUR"], Currencies["USD"], Temporals[-1])
              , (Currencies["EUR"], Currencies["USD"], Temporals[-2])
              , (Currencies["USD"], Currencies["USD"], Temporals[-1])
              , (Currencies["EUR"], Currencies["EUR"], Temporals[-1])
              )

# Generated at 2022-06-21 20:27:41.255877
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MyService(FXRateService):
        def __init__(self):
            self._rates = [
                ("USD", "EUR", datetime.date(2020, 1, 1), Decimal("1.5")),
                ("EUR", "USD", datetime.date(2020, 1, 1), Decimal("0.5")),
                ("EUR", "USD", datetime.date(2019, 12, 31), Decimal("0.8")),
            ]


# Generated at 2022-06-21 20:27:50.504254
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal
    svc = FXRateService.default
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert svc.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), False) == nrate
    try:
        svc.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), True)
    except:
        assert False
    assert svc.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), True) == nrate

# Generated at 2022-06-21 20:27:58.815708
# Unit test for constructor of class FXRateService
def test_FXRateService():
    class SVC(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            return FXRate(ccy1, ccy2, asof, ZERO if asof.is_weekend() else ONE)

        def queries(self, queries, strict):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)
    assert SVC()

# Generated at 2022-06-21 20:28:00.259094
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """Unit test for the constructor of class FXRateService."""
    pass

# Generated at 2022-06-21 20:28:02.033470
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries`.
    """
    pass  # FIXME: Implement this!

# Generated at 2022-06-21 20:28:06.395384
# Unit test for constructor of class FXRate
def test_FXRate():
    """Unit test for constructor of class FXRate"""
    from .currencies import Currency, Currencies
    fxrate = FXRate(Currency("EUR"), Currency("USD"), Date(2018, 7, 23), 1.18)

    assert fxrate.ccy1 == Currency("EUR")
    assert fxrate.ccy2 == Currency("USD")
    assert fxrate.date == Date(2018, 7, 23)
    assert fxrate.value == 1.18


# Generated at 2022-06-21 20:28:17.994553
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Checks the method query of the abstract class FXRateService.
    """
    ## Imports:
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from unittest import TestCase
    from unittest.mock import Mock

    ## Test target:
    from pypara.fx import FXRateLookupError, FXRateService

    ## Test subject:
    class FXRateServiceTester(FXRateService):
        """
        Provides a test subject for FXRateService.
        """
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None


# Generated at 2022-06-21 20:28:27.041523
# Unit test for constructor of class FXRateService
def test_FXRateService():
    """
    Tests the constructor of the abstract class :class:`FXRateService`.
    """
    class ConcreteFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    ConcreteFXRateService()

# Unit tests for class FXRate

# Generated at 2022-06-21 20:29:09.705925
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:29:19.721136
# Unit test for constructor of class FXRateService
def test_FXRateService():
    from abc import ABCMeta
    from unittest import TestCase, main

    class MockService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            pass
        def queries(self, queries, strict = False):
            pass

    assert issubclass(MockService, FXRateService)
    assert issubclass(MockService, ABCMeta)
    assert issubclass(MockService, object)

    class MockTestCase(TestCase):
        def test_members(self):
            assert hasattr(MockService, "default")
            assert hasattr(MockService, "TQuery")
            assert hasattr(MockService, "query")
            assert hasattr(MockService, "queries")

# Generated at 2022-06-21 20:29:27.441933
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency

    ## Check inversion for random rates:
    for ccy1 in Currency:
        for ccy2 in Currency:
            if ccy1 != ccy2:
                rate = FXRate(ccy1, ccy2, date.today(), Decimal("0.01"))
                inverted = ~rate
                assert inverted.ccy1 == ccy2
                assert inverted.ccy2 == ccy1
                assert inverted.date == date.today()
                assert inverted.value == Decimal("100")

    ## Check inversion for identity rates:
    for ccy in Currency:
        rate = FXRate(ccy, ccy, date.today(), ONE)
        inverted = ~rate
        assert inverted.ccy1 == ccy

# Generated at 2022-06-21 20:29:28.893201
# Unit test for constructor of class FXRateService
def test_FXRateService():
    # No unit tests as abstract class
    assert True

# Generated at 2022-06-21 20:29:35.628162
# Unit test for constructor of class FXRate
def test_FXRate():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    ccy1, ccy2, date, value = rate
    assert ccy1 == Currencies["EUR"]
    assert ccy2 == Currencies["USD"]
    assert date == datetime.date.today()
    assert value == Decimal("2")


# Generated at 2022-06-21 20:29:41.330979
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate



# Generated at 2022-06-21 20:29:44.930441
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate

# Generated at 2022-06-21 20:29:52.391308
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-21 20:30:04.196961
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase
    from unittest.mock import MagicMock
    from pypara.currencies import Currencies
    from pypara.currencies.fxrates import FXRateService
    from pypara.commons.zeitgeist import Date

    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            assert self.ccy1 == ccy1
            assert self.ccy2 == ccy2
            assert self.asof == asof
            assert self.strict == strict
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            self.ccy1, self.ccy2, self

# Generated at 2022-06-21 20:30:15.052853
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    date = datetime.date.today()
    eur = Currencies["EUR"]
    usd = Currencies["USD"]
    rate = FXRateService.default.query(eur, usd, date)
    rate = FXRateService.default.query(eur, usd, date, strict=True)
    assert isinstance(rate, FXRate)
    assert rate.ccy1 == eur
    assert rate.ccy2 == usd
    assert rate.date == date
    assert isinstance(rate.value, Decimal)


# Generated at 2022-06-21 20:31:45.747347
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    ## Define a fake service:
    class FakeFXRateService(FXRateService):
        """
        Provides a fake FX rate service.
        """


# Generated at 2022-06-21 20:31:57.803246
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from .currencies import Currencies
    from .temporal import Temporal, nownow

    ## Create an instance:
    fxrates = FXRateService()
    assert not callable(fxrates.query)

    ## Check the signature:
    from inspect import signature
    assert signature(fxrates.query).parameters == {
        "ccy1": "ccy1",
        "ccy2": "ccy2",
        "asof": "asof",
        "strict": "strict"
    }

    ## Check the arguments:
    try:
        fxrates.query(Currencies["USD"], Currencies["EUR"], Temporal.of(nownow(), None), strict=True)
        assert False
    except ValueError:
        pass


# Generated at 2022-06-21 20:32:08.480615
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Today

    ## Create a test FX rate service:
    class TestFXRateService(FXRateService):  # noqa: D101, D107

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(2))
