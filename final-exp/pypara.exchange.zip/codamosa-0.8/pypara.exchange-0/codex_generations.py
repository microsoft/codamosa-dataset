

# Generated at 2022-06-12 06:10:27.899896
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    # Inverting the EUR/USD FX rate must yield the USD/EUR FX rate:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate.of(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-12 06:10:38.044338
# Unit test for method query of class FXRateService

# Generated at 2022-06-12 06:10:38.552851
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

# Generated at 2022-06-12 06:10:50.449280
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.itertools import singleton
    from pypara.fx.memory import MemoryFXRateService

    ## Create a foreign exchange rate service:
    service = MemoryFXRateService()

    ## Store some FX rates:
    service.store(FXRate(Currency.of("USD"), Currency.of("TRY"), date(2020, 1, 1), Decimal("5.75")))
    service.store(FXRate(Currency.of("TRY"), Currency.of("USD"), date(2020, 1, 1), Decimal("0.17")))
    service.store(FXRate(Currency.of("EUR"), Currency.of("USD"), date(2020, 1, 1), Decimal("1.1")))
    service.store

# Generated at 2022-06-12 06:10:58.163474
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-12 06:11:08.000324
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase, mock
    from pypara.services.default_fxrate_service import DefaultFXRateService
    from pypara.currencies import Currency, Currencies
    from pypara.commons.zeitgeist import Date

    # Test forward lookup
    query = FXRateService.TQuery((Currencies['EUR'], Currencies['TRY'], Date.today()))
    fx = FXRateService.default.query(*query, strict=False)
    assert fx is not None
    assert fx.value is not None
    assert fx.value != 0
    query = FXRateService.TQuery((Currencies['TRY'], Currencies['EUR'], Date.today()))
    fx = FXRateService.default.query(*query, strict=False)
    assert fx is not None

# Generated at 2022-06-12 06:11:14.164675
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate

# Generated at 2022-06-12 06:11:24.979840
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D103
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.fxrates import FXRateService
    from pypara.services.fxrates.registry import FXRateServices

    # Case 1: Successful query for an FX rate
    fxsrv = FXRateServices.getInstance().default
    rate = fxsrv.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == datetime.date.today()
    assert isinstance(rate.value, Decimal)
    assert rate.value != Decimal(0)

    # Case 2: Unsuccessful query for an FX

# Generated at 2022-06-12 06:11:25.980952
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-12 06:11:32.784246
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    return nrate == ~rrate


# Generated at 2022-06-12 06:11:46.010925
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    
    """
    from datetime import date
    from decimal import Decimal
    from unittest import TestCase
    from typing import Iterable
    from pypara.currencies import EUR
    from pypara.fxrates import FXRateService

    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (None, None, None)

    # Need to initialize before use
    service = DummyFXRateService()
    results = service.queries(((EUR, EUR, date.today()),))

# Generated at 2022-06-12 06:11:58.790811
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test for method query of class FXRateService.
    """
    from unittest.mock import Mock
    from .currencies import Currency

    ## Create an arbitrary FX rate service:
    mock = Mock(spec = FXRateService)

    ## Configure the mock for FX rate query:
    mock.query.side_effect = lambda ccy1, ccy2, asof, strict = False: \
        "" if (ccy1, ccy2, asof) != ("USD", "EUR", datetime.date.today()) else Decimal("2")

    ## Query directly on the mock:
    assert mock.query("EUR", "USD", datetime.date.today()) == Decimal("2")
    # assert mock.query("EUR", "USD", datetime.date.today()) == None

    ## Query using the default

# Generated at 2022-06-12 06:12:08.236917
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from unittest.mock import MagicMock

    from .temporals import now

    from .currencies import Currency

    from .commons.numbers import ONE, TWO, FIVE, EIGHT

    ## Create a mock FX rate service:
    fx_rate_service = MagicMock(FXRateService)

    ## Define queries:
    queries = [
        (Currency.EUR, Currency.USD, now()),
        (Currency.EUR, Currency.USD, now()),
        (Currency.USD, Currency.EUR, now()),
        (Currency.TRY, Currency.USD, now()),
        (Currency.USD, Currency.TRY, now())
    ]

    ## Define expected answers:

# Generated at 2022-06-12 06:12:18.545535
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates.services import DummyFXRateService

    ## Set up the service:
    service = DummyFXRateService()
    service.put(FXRate(ccy1=Currencies['EUR'], ccy2=Currencies['USD'], date=date(2008, 10, 14), value=Decimal('1.3630')))
    service.put(FXRate(ccy1=Currencies['EUR'], ccy2=Currencies['USD'], date=date(2008, 10, 15), value=Decimal('1.2030')))

# Generated at 2022-06-12 06:12:29.098527
# Unit test for method queries of class FXRateService

# Generated at 2022-06-12 06:12:41.364589
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`pypara.fxrates.FXRateService.queries` implementation.
    """
    # Imports:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    # Test implementation:
    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of the foreign exchange service.
        """

        def __call__(self, ccy1: Currency, ccy2: Currency, date: Date, strict: bool = False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, date, Decimal("2"))
            return None


# Generated at 2022-06-12 06:12:42.728862
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Test for abstract
    abstracttest = 1


# Generated at 2022-06-12 06:12:55.427340
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # pragma: no cover
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporals import Date

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return iter([])

    fxrate = TestFXRateService().query(Currencies["EUR"], Currencies["USD"], Date("2019-01-01"))

# Generated at 2022-06-12 06:13:07.541165
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency
    from pypara.fx import FXRateService
    from pypara.fx.providers.mock import MockFXRateService

    ## Check the None case:
    assert None == MockFXRateService().query(Currency("XXX"), Currency("YYY"), date.today())

    ## Check a valid foreign exchange rate:
    assert FXRate(Currency("EUR"), Currency("USD"), date.today(), Decimal("1.10")) == MockFXRateService().query(
        Currency("EUR"), Currency("USD"), date.today(), False
    )

# Generated at 2022-06-12 06:13:18.946830
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    from pypara.finance.events import FXRate

    class _FXRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]):

            super().__init__()
            self.__rates = dict(rates)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:

            if strict:
                return self.__rates[(ccy1, ccy2, asof)]
            else:
                return self.__rates.get((ccy1, ccy2, asof))


# Generated at 2022-06-12 06:13:34.745401
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # Test the query method with default settings
    def test_FXRateService_query_default():

        # Define a query tuple
        QRY = FXRateService.TQuery

        # Define a foreign exchange rate service
        class ForeignExchangeRateService(FXRateService):

            def query(self, ccy1, ccy2, asof, strict=False):

                # Check if the query is exactly (USD/USD, TODAY)
                if ccy1 == ccy2 == CURRENCIES["USD"] and asof == TODAY:
                    # Try to fetch the rate
                    return FXRate(ccy1, ccy2, asof, ONE)

                # Check if the query is exactly (USD/EUR, TODAY)

# Generated at 2022-06-12 06:13:46.284706
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency, Currencies
    from .temporals import Today

    class StaticFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.

            :param queries: An iterable of :class:`Currency`, :class:`Currency` and :class:`Temporal` tuples.
            :param strict: Indicates if we should raise a lookup error if that the foreign exchange rate can not be found.
            :return: An iterable of rates.
            """

# Generated at 2022-06-12 06:13:56.133110
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import itertools as it
    from .currencies import Currencies
    from .temporals import Date
    from .finance.timeseries import Calendar

    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date("2018-10-01"), ONE)

    class MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            return rate if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date("2018-10-01") else None

        def queries(self, queries, strict=False):
            return iter((rate if q == (rate.ccy1, rate.ccy2, rate.date) else None for q in queries))



# Generated at 2022-06-12 06:14:07.653046
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Setup an instance of the service:
    from pypara.data.fxrates import FXRateServiceInMemory
    service = FXRateServiceInMemory()

    # Setup a query sequence:
    from pypara.currencies import Currency, Currencies
    from pypara.commons.zeitgeist import Date
    queries = [
        (Currencies["CAD"], Currencies["USD"], Date.today()),
        (Currencies["CAD"], Currencies["USD"], Date.today() + 1),
        (Currencies["CAD"], Currencies["USD"], Date.today() + 2),
    ]

    # Run the queries:

# Generated at 2022-06-12 06:14:16.295812
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from pypara.currencies import Currencies
    from pypara.exchanges import FXRate

    class TestFXRateService(FXRateService):
        @staticmethod
        def query(ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, 2)
            return None

    rate1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), 2)
    rate2 = FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate

# Generated at 2022-06-12 06:14:28.272968
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    import datetime

    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.rates.fixer import Fixer
    from pypara.rates.fx import FXRateService

    from pypara.commons.zeitgeist import Date

    ## Create an FX rate service instance:
    service = Fixer()

    ## Query EUR/USD FX rate as of today:
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date.today())

    ## Some assertions:
    assert rate is not None
    assert isinstance(rate, FXRate)
    assert isinstance(rate.ccy1, Currency)
    assert isinstance(rate.ccy2, Currency)
    assert isinstance(rate.date, datetime.date)

# Generated at 2022-06-12 06:14:31.758184
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies

    service = FXRateService()
    urate = FXRateService.query(service, Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-12 06:14:42.386704
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    from .currencies import Currency
    from .currencies.numerics import CurrencyNumericEnum
    from .commons.zeitgeist import date
    from .fx import FXRateService, FXRateLookupError
    from decimal import Decimal

    # Given an FX rate service that returns rates for EUR/USD, GBP/USD, EUR/GBP and USD/JPY on 2019-01-01:

# Generated at 2022-06-12 06:14:43.421865
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Test by using default
    pass


# Generated at 2022-06-12 06:14:53.274742
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies # needed for type checking
    from pypara.commons.zeitgeist import Date # needed for type checking
    from pypara.fxrates import FXRateService # needed for type checking
    # define an abstract class for currying purpose
    from typing import TypeVar, Generic
    T = TypeVar('T')
    class Curry(Generic[T]):
        @abstractmethod
        def __call__(self, t: T):
            pass
    # define a concrete class that provides a correct implementation
    class CurryCorrect(Curry[FXRateService.TQuery]):
        def __call__(self, t: FXRateService.TQuery) -> Optional[FXRate]:
            return None
    # define a concrete class that provides a wrong implementation

# Generated at 2022-06-12 06:15:16.363375
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            return None


# Generated at 2022-06-12 06:15:26.258134
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D202
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.null_fxrate_service import NullFXRateService
    from pypara.services.samples_fxrate_service import SamplesFXRateService
    import datetime

    ## Ensure that no default FX rate service is assigned at the beginning:
    service = FXRateService.default
    assert service is None

    ## Ensure that no FX rate is returned when the default FX rate service is null.
    ## Also,
    ## Ensure that a lookup error is raised when strict is set to True.
    service = NullFXRateService()
    FXRateService.default = service
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=False) is None

# Generated at 2022-06-12 06:15:36.744387
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currency
    from datetime import date
    from pypara.fx.rates import DummyFXRateService, FXRateLookupError
    d = DummyFXRateService()
    assert d.query(Currency.of("USD"), Currency.of("GBP"), date(2016, 1, 1)) == FXRate(Currency.of("USD"), Currency.of("GBP"), date(2016, 1, 1), Decimal("0.67"))

# Generated at 2022-06-12 06:15:48.114711
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import InMemoryFXRateService

    ## Create some rates:
    rates = [
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5")),
    ]

    ## Create an FX rate service instance:
    fxrate_service = InMemoryFXRateService(rates)

    ## Query EUR/USD:
    assert fxrate_service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) == rates[0]

# Generated at 2022-06-12 06:15:49.068162
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D202
    assert False

# Generated at 2022-06-12 06:16:01.207258
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from unittest import TestCase
    from .currencies import Currencies
    from .temporals import Date

    class Tested(FXRateService):
        def queries(self, queries, strict):
            eur_usd = FXRate.of(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))
            eur_try = FXRate.of(Currencies["EUR"], Currencies["TRY"], Date.today(), Decimal("3"))
            for (ccy1, ccy2, date) in queries:
                if ((ccy1, ccy2, date) == (Currencies["EUR"], Currencies["USD"], Date.today())):
                    yield eur_usd

# Generated at 2022-06-12 06:16:13.114976
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.money import Money
    from pypara.services.forex import FXRateService, FXRateLookupError

    class TestService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))

# Generated at 2022-06-12 06:16:16.864547
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies['EUR'] and ccy2 == Currencies['USD'] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal(2))
            else:
                return None

    fxrate = TestFXRateService().query(Currencies['EUR'], Currencies['USD'], datetime.date.today())
    assert fxrate.ccy1 == Currencies['EUR']
    assert fxrate.ccy2 == Cur

# Generated at 2022-06-12 06:16:25.041376
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commons.numbers import ZERO

    class TestService(FXRateService):
        pass

    for ccy in Currencies:
        ccy_name = ccy.name
        if ccy_name != "EUR":
            continue
        if ccy_name == "XCD":
            continue
        print(ccy_name)
        svc = TestService()
        rate_ccy1_eur = FXRate(ccy, Currencies["EUR"], datetime.date.today(), Decimal("1"))
        assert svc.query(rate_ccy1_eur[0], rate_ccy1_eur[1], rate_ccy1_eur[2]) == rate_ccy1_eur


# Generated at 2022-06-12 06:16:37.310537
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService, FXRateLookupError
 
    class FXRateServiceTestCase(unittest.TestCase):
        """
        Defines the unit test case for the abstract class :class:`FXRateService`.
        """

        def test_FXRateService_queries(self):
            """
            Tests the :method:`FXRateService.queries` method.
            """
            ## Create a dummy service:
            class DummyService(FXRateService):
                """
                Defines a dummy FX rate service for testing the :method:`FXRateService.queries` method.
                """


# Generated at 2022-06-12 06:17:25.331387
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D202
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    class SimpleFXRateService(FXRateService):

        def __init__(self):
            self.rates = [FXRate(Currencies["EUR"], Currencies["USD"], date(2018, 8, 1), Decimal("2")),
                          FXRate(Currencies["EUR"], Currencies["USD"], date(2018, 8, 2), Decimal("20"))]


# Generated at 2022-06-12 06:17:27.197271
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of :class:`FXRateService`.
    """

    # TODO: Implement
    pass

# Generated at 2022-06-12 06:17:38.410226
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .temporals import Date
    from .currencies import Currencies
    from decimal import Decimal

    class DummyService(FXRateService):
        """
        Provides a dummy FX rate service for testing.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2016, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2016, 1, 1), Decimal("1.0"))
            else:
                return None

        def queries(self, queries, strict=False):
            return (
                self.query(query[0], query[1], query[2], strict)
                for query in queries
            )


# Generated at 2022-06-12 06:17:49.077450
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.yahoofin.providers import (
        YFStaticFXRateProvider,
        YFStaticFXRateProvider,
        YFStaticFXRateProvider,
    )
    import datetime

    provider = YFStaticFXRateProvider()
    provider[Currencies["EUR"], Currencies["USD"], datetime.date.today()] = Decimal("1.1")
    result = provider.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    expected = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1.1"))
    assert result == expected



# Generated at 2022-06-12 06:18:00.010267
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D103
    # Arrange:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fx_rates.memory import FXRateMemory
    from pypara.commons.zeitgeist import Temporal

    # Act:
    service = FXRateMemory(
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    )

# Generated at 2022-06-12 06:18:01.098774
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass  # todo: implement this unit test

# Generated at 2022-06-12 06:18:11.347335
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date, timedelta
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            if (ccy1, ccy2) in [(Currencies["EUR"], Currencies["USD"]), (Currencies["USD"], Currencies["EUR"])]:
                if asof == date.today():
                    return FXRate(ccy1, ccy2, asof, Decimal("2"))
                if asof == date.today() - timedelta(days=1):
                    return FXRate(ccy1, ccy2, asof, Decimal("3"))
            return None

    ## Use default service as of

# Generated at 2022-06-12 06:18:24.022313
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the ``query`` method of :class:`FXRateService`.
    """
    ## pylint: disable=protected-access
    ## Import FX rate service:
    from .fx import FXRateServiceImpl

    ## Create an FX rate service:
    service = FXRateServiceImpl("./tests/fxrates/spot/", False)

    ## Check that we can get multiple rate from the service:
    assert service.query(Currency("USD"), Currency("EUR"), Date(2018, 2, 28)) == Decimal("0.81829405064")
    assert service.query(Currency("USD"), Currency("EUR"), Date(2018, 2, 28), False) == Decimal("0.81829405064")

# Generated at 2022-06-12 06:18:35.085151
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from pypara.currencies import Currency
    from pypara.fx import FXRateService
    from pypara.services.spectre import FXRateSpectre

    ## Create the foreign exchange rate service:
    service = FXRateSpectre()

    ## Prepare a list of queries:
    queries = [
        (Currency("EUR"), Currency("USD"), datetime.date(2017, 5, 18)),
        (Currency("EUR"), Currency("USD"), datetime.date(2017, 5, 16)),
        (Currency("EUR"), Currency("USD"), datetime.date(2017, 5, 19)),
        (Currency("EUR"), Currency("USD"), datetime.date(2017, 5, 15)),
    ]
    results = list(service.queries(queries))


# Generated at 2022-06-12 06:18:46.359745
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import RatesCurve
    from pypara.curves.yields.yield_curve_service import YieldCurveService
    from pypara.curves.yields.yields_curve_service import YieldsCurveService
    from pypara.fx.fx_rate_service import FXRateService, FXRateLookupError

    ## Create the curves:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

# Generated at 2022-06-12 06:20:14.037730
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrate import FXRate

    class Provider(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, date: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["GBP"] and date == Date(2020, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["GBP"], Date(2020, 1, 1), 0.890)