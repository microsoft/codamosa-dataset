

# Generated at 2022-06-12 06:10:35.213744
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import date
    from .fx import FXRate
    from .fx.services import FXRateService
    from .fx.services import InMemoryFXRateService

    #
    # Set up test.
    #
    class MyFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if rate[0] == ccy1 and rate[1] == ccy2 and rate[2] == asof:
                    return rate

# Generated at 2022-06-12 06:10:42.285592
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the FXRateService.query method of the service class.
    """

    # Import modules
    import datetime
    from decimal import Decimal
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.temporals import Temporals

    # Import class
    from .fxt import FXRateService

    # Define test class

    class FXRateServiceTest(TestCase):

        # Define test methods

        def test_query(self):
            """
            Tests query method, which should always return an FXRate object.
            """
            ## Create an FXRateService mock instance.
            service = FXRateService()

# Generated at 2022-06-12 06:10:53.246276
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest.mock import Mock, patch

    ## Create a mock FXRateService object:
    service = Mock(spec=FXRateService)
    service.strict = False

    ## Create a query and a rate:
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    date = Date(2020, 1, 1)
    query = (ccy1, ccy2, date)
    rate = FXRate(ccy1, ccy2, date, ONE)

    ## Next up is a patch:
    with patch.object(FXRateService, "query", return_value=rate) as query_mock:
        assert service.query(ccy1, ccy2, date) == rate

    ## Check the mocks:
    service.query.assert_called()

# Generated at 2022-06-12 06:11:04.312973
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pytest
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency, Currencies

    URATE = FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 1), Decimal("1.1"))
    RRATE = FXRate(Currencies["USD"], Currencies["EUR"], date(2020, 1, 1), Decimal("0.9"))

    class FXRateServiceMock(FXRateService):  # noqa: WPS601

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-12 06:11:16.874931
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # test with a basic service
    class BasicService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, 1)

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for q in queries:
                yield self.query(*q)

    bs = BasicService()
    assert bs.query(Currency('EUR'), Currency('USD'), Date('2018-01-01')) == FXRate(Currency('EUR'), Currency('USD'), Date('2018-01-01'), 1)

# Generated at 2022-06-12 06:11:28.112578
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    """
    Test method foreign exchange rate query method.
    """

    ## Method query():
    from pypara.fxrates.currencies import Currencies
    from pypara.fxrates.services import FSApi
    from .commons.temporal import as_date

    ## Get today's date:
    today = as_date()

    ## Create an FX rate service:
    service = FSApi()

    ## The following rates are valid for today:
    service.query(Currencies["USD"], Currencies["USD"], today)
    service.query(Currencies["USD"], Currencies["EUR"], today)
    service.query(Currencies["USD"], Currencies["TRY"], today)

    ## The following rates are not valid for today:
    service.query(Currencies["EUR"], Currencies["EUR"], today)

# Generated at 2022-06-12 06:11:40.017684
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import FixedFXRateService

    ## Create an FX rate service:

# Generated at 2022-06-12 06:11:51.349382
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This is a unit test for :meth:`FXRateService.queries`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.rates import FXRateLookupError

    class MockFXRateService(FXRateService):

        def __init__(self):
            pass

        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries, strict=False):
            for query in queries:
                yield self.query(*query, strict=strict)

    ## Empty query:
    with MockFXRateService() as fxservice:
        result = fxservice.queries([])


# Generated at 2022-06-12 06:11:53.403118
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    pass


# Generated at 2022-06-12 06:12:02.834673
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests :method:`FXRateService.query` of the :class:`FXRateService` class.
    """

    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    from pypara.finance import FXRateService as FRSS

    class TestFXRateService(FRSS):
        """
        Provides a mock FX rate service.
        """

        def __init__(self, rates: Iterable[FXRate]):
            self.__rates = dict((item.ccy1, item.ccy2, item.date, item) for item in rates)


# Generated at 2022-06-12 06:12:08.003870
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """Test method query of class FXRateService"""


# Generated at 2022-06-12 06:12:18.364939
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import mock
    from .currencies import Currencies
    from .temporals import Date
    from .exchanges import FXRateService
    from .exchanges import FXRateLookupError
    from .exchanges import FXRate
    ##
    ## Setup:
    ##

    # Initialize a mock service:
    service = mock.Mock(spec=FXRateService)

    # Setup the mocked method:

# Generated at 2022-06-12 06:12:28.991986
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import ZDate
    import datetime
    from decimal import Decimal
    from .rates import SimpleFXRateService

    # Given a list of queries...
    queries = [
        (Currencies["EUR"], Currencies["USD"], ZDate(datetime.date(2019, 1, 1))),
        (Currencies["USD"], Currencies["EUR"], ZDate(datetime.date(2019, 1, 1))),
    ]

    # And a list of FX rates...
    rates = [
        FXRate(Currencies["EUR"], Currencies["USD"], ZDate(datetime.date(2019, 1, 1)), Decimal("1.5")),
    ]

    # When we create a simple FX rate service...
    service = SimpleFXRateService(rates)

    # Then it returns

# Generated at 2022-06-12 06:12:36.109181
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.currencies.fxrates.defaults import FXRateService as DefaultFXRateService

    try:
        DefaultFXRateService.default.query(Currencies["EUR"], Currencies["USD"], Date.today())
    except FXRateLookupError as e:
        print(e)
    else:
        print("Done")

# Generated at 2022-06-12 06:12:40.488494
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.utils.testing import assert_equal, assert_is
    from pypara.currencies import Currencies
    from pypara.finance.curves import FXRateService as FXRateServiceManager
    from pypara.finance.curves import FXRates

    # Given
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()
    fxrate = Decimal("2")

    # When
    FXRateServiceManager.default = FXRates(fxrate)
    fxrates = FXRateServiceManager.default.queries([(ccy1, ccy2, asof)] * 10)

    # Then
    assert_equal(10, len(fxrates))

# Generated at 2022-06-12 06:12:45.407350
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .tests.fixtures import Date, Currencies
    from .commons.context import Context
    from .currencies import FXRateService as FXService

    Context.date.set(Date(2019, 4, 1))
    rate = FXService.rate(Currencies["EUR"], Currencies["USD"])
    assert rate == 1.13



# Generated at 2022-06-12 06:12:51.089605
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase
    class Test(TestCase):
        def runTest(self):
            self.assertRaises(NotImplementedError, lambda: FXRateService().query(None, None, None))
            self.fail("Success")
    Test().runTest()


# Generated at 2022-06-12 06:12:58.557741
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert None is FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=True)

# Generated at 2022-06-12 06:13:10.314964
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.bonds import BondPricingService
    from pypara.stochastics import SimulatedCurve as SimCurve

    # Define a lookup service just to simulate
    class LookupService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today() + datetime.timedelta(1):
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("1.1"))

# Generated at 2022-06-12 06:13:18.983231
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .temporal.now import Now
    from .fxrates import services
    rate = services.query(Currencies["USD"], Currencies["EUR"], Date.of(Now().date))
    assert isinstance(rate, FXRate)
    assert rate.ccy1 == Currencies["USD"]
    assert rate.ccy2 == Currencies["EUR"]
    assert rate.date == Date.of(Now().date)
    assert isinstance(rate.value, Decimal)
    assert rate.value > Decimal("0.0")


# Generated at 2022-06-12 06:13:35.035985
# Unit test for method queries of class FXRateService

# Generated at 2022-06-12 06:13:36.833829
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:13:47.147559
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from urllib.error import HTTPError
    import pytest
    from pypara.currencies import Currencies
    from pypara.services import FXRateService, FXRateServiceError

    ## GCG (Good Case Good): Test a happy path.
    rate = FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert isinstance(rate, FXRate)
    assert isinstance(rate.value, Decimal)

    ## GCB (Good Case Bad): Test a non-existent query.
    rate = FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date(1345, 1, 1))
    assert rate is None

    ## GCB (Good Case Bad): Test a non-existent query

# Generated at 2022-06-12 06:13:49.739420
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            return None
    m = MockFXRateService()
    assert m.query(None, None, None) is None


# Generated at 2022-06-12 06:13:57.354621
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of a :class:`FXRateService`.

    This test is a simple sanity check.
    """
    from .currencies import EUR, USD
    from pypara.commons.numbers import ONE

    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, ONE)

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [ FXRate.of(ccy1, ccy2, asof, ONE) for ccy1, ccy2, asof in queries ]

    # Construct

# Generated at 2022-06-12 06:14:06.474884
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import io
    import sys

    # noinspection PyUnresolvedReferences
    from pypara.fx.services.bloomberg import BloombergFXRateService

    try:
        service = BloombergFXRateService()
        rate = service.query(Currency.of("EUR"), Currency.of("USD"), Date.now().date)
        assert rate is not None
        assert type(rate) is FXRate
        assert rate.ccy1 == Currency.of("EUR")
        assert rate.ccy2 == Currency.of("USD")
    except Exception as e:
        print(e, file=sys.stderr)
        assert False

# Generated at 2022-06-12 06:14:15.771384
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    from pypara.fx import FXRate, FXRateService

    class MyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return map(lambda q: self.query(*q), queries)

    service = MyFXRateService()
    rate = service.query("EUR", "USD", Date.today())

    assert isinstance(rate, FXRate)
    assert rate.ccy1 == Currency("EUR")

# Generated at 2022-06-12 06:14:24.117147
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporals import Temporals
    from pypara.services.rate import FXRateService as SampleFXRateService

    ## Prepares some queries:
    queries = [
        (Currencies["EUR"], Currencies["USD"], Temporals.of("2018-01-01")),
        (Currencies["EUR"], Currencies["USD"], Temporals.of("2018-01-02")),
    ]

    ## Prepares some results:

# Generated at 2022-06-12 06:14:35.968559
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Test with dummy implementation.
    class DummyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return self.queries([(ccy1, ccy2, asof)], strict=strict)

        def queries(self, queries, strict=False):
            for a, b, c in queries:
                yield 1

    # Test with real implementation.
    from pathlib import Path
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.fx import FXRateProvider, FXRateProviderError

    # Obtain the path to the file.
    fp = Path(__file__).parent / "data" / "fx_rates.csv"
    if not fp.exists():
        raise FXRateProviderError

# Generated at 2022-06-12 06:14:48.063998
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    from pypara.time import now

    ## Create the instance:
    service = FXRateService()

    ## Assert that the method is abstract:
    assert service.queries(None, False) == NotImplemented

    ## Create queries:
    queries = [(Currencies["EUR"], Currencies["USD"], now())]

    ## Create the mock service:
    service = Mock()

    ## Set the mock's side effect:
    import datetime
    from decimal import Decimal
    service.side_effect = [FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))]

    ## Call the method:
    rates = [rate for rate in service.queries(queries, False)]



# Generated at 2022-06-12 06:15:14.362567
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    ## Imports:
    from .commons.zeitgeist import Temporal
    from .currencies import Currency, Currencies
    from .services.currencies import CurrencyInfoService
    from .services.fxrates import FXRateService

    ## Configure the test:
    EUR: Currency = Currencies["EUR"]
    USD: Currency = Currencies["USD"]
    dates: Iterable[Temporal] = [
        Temporal(2019, 1, 1),
        Temporal(2019, 1, 2),
        Temporal(2019, 1, 3),
        Temporal(2019, 1, 4),
        Temporal(2019, 1, 5),
    ]

    ## Test:
    cinfo: CurrencyInfoService = CurrencyInfoService.get_default()
    fxrate

# Generated at 2022-06-12 06:15:24.993842
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """Tests FXRateService.query."""
    from .currencies import Currencies, Currency
    from .exchanges import FXRateService, FXRate


# Generated at 2022-06-12 06:15:33.015941
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class DummyFXService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Date]], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    DummyFXService().query(1, *2, **3)

# Generated at 2022-06-12 06:15:39.788987
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests FXRateService.queries method.
    """

    ## Method tests:
    ## ------------

    from collections import namedtuple
    from typing import NamedTuple
    from unittest import TestCase
    from pypara.currencies import Currency, Currencies
    from pypara.currencies.exchange import FXRateService, FXRateLookupError
    from pypara.currencies.temporals import Date

    class TheService(FXRateService):
        """
        Dummy FXRateService implementation.
        """


# Generated at 2022-06-12 06:15:50.122356
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date
    from .servers import FXRateService

    ## Define a service:
    class Service(FXRateService):
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[FXRate]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("1.20"))
    service = Service()

    ## Create a foreign exchange rate query collection and execute queries:
    queries = (("EUR", "USD", Date("2015-08-11")), ("USD", "EUR", Date("2015-08-11")),)
    results = list(service.queries(queries, strict=False))

# Generated at 2022-06-12 06:16:02.128668
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Stub implementation for the abstract class for unit testing:
    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("0"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (r for r in map(self.query, *zip(*queries)))

    # Create a test instance:
    test_inst = TestFXRateService()

    # Create a test case:
    test_case = [1, 2]

    # Map the test case:
    test_result = [r for r in test_inst.queries(test_case)]

    # Assert the

# Generated at 2022-06-12 06:16:14.212168
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method of :class:`FXRateService`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from unittest import mock

    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        (Currencies["EUR"], Currencies["USD"], datetime.date.today() + datetime.timedelta(days=1)),
    ]

    service = mock.MagicMock()

# Generated at 2022-06-12 06:16:23.996310
# Unit test for method query of class FXRateService

# Generated at 2022-06-12 06:16:36.959245
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import VectorFXRateService

    ## Define cases:

# Generated at 2022-06-12 06:16:48.704281
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D103
    import unittest

    from .currencies import Currencies
    from .services import get_services
    from .temporal import Temporal

    ## Define the test case class:
    class FXRateServiceTest(unittest.TestCase):
        """
        Tests the FX rate service.
        """

        def setUp(self) -> None:
            """
            This method is invoked before each test method to perform common set up tasks.
            """
            ## Get the EOD pricing service:
            svc = get_services()["FX"]
            assert isinstance(svc, FXRateService)

            ## Keep the service:
            self.svc = svc

        def test_query_0001(self) -> None:
            """Tests the query method."""

# Generated at 2022-06-12 06:17:22.714974
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:17:25.058291
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the :method:`FXRateService.query` method.
    """
    pass


# Generated at 2022-06-12 06:17:36.842123
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal

    from pypara.commons.zeitgeist import today
    from pypara.currencies import Currency, Currencies
    from pypara.fxrates.in_memory import FXRateService as InMemoryFXRateService

    currencies = Currencies
    rates = [
        FXRate(currencies["EUR"], currencies["USD"], today(), Decimal("1.1")),
        FXRate(currencies["USD"], currencies["EUR"], today(), Decimal("0.91")),
    ]

    default = FXRateService.default  # noqa: E999
    FXRateService.default = None  # noqa: E999
    service = InMemoryFXRateService(rates)
    FXRateService.default = default


# Generated at 2022-06-12 06:17:48.486058
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests queries(Iterable[Tuple[Currency, Currency, Temporal]], strict: bool = True) -> Iterable[Optional[FXRate]]
    method of class FXRateService.
    """
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fx import FXRateService

    ## Define the FX rate service:

# Generated at 2022-06-12 06:17:59.589926
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import decimal
    import datetime
    from pypara.currencies import Currencies

    # Define the expected FX rates:
    expected = (
        (Currencies["EUR"], Currencies["USD"], datetime.date(2017, 1, 1), decimal.Decimal(1.08)),
        (Currencies["EUR"], Currencies["USD"], datetime.date(2017, 1, 2), decimal.Decimal(1.10)),
        (Currencies["EUR"], Currencies["USD"], datetime.date(2017, 1, 5), None)
    )

    # Create a mock FX rate service:

# Generated at 2022-06-12 06:18:10.376318
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import unittest

    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies


# Generated at 2022-06-12 06:18:23.056551
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Defines unit tests for the method :method:`FXRateService.query`.
    """
    import unittest
    from unittest.mock import MagicMock
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency, Currencies
    from pypara.fxrates import FXRateService

    ## Test the None-FX rate lookup:
    fx_rate_service = MagicMock(FXRateService)
    fx_rate_service.query.return_value = None
    assert fx_rate_service.query(Currencies["EUR"], Currencies["USD"], date(2020, 2, 20)) is None

    ## Test the non-None FX rate lookup:

# Generated at 2022-06-12 06:18:34.715923
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from collections import UserList
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    class MyFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict=False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == d20170101:
                return FXRate(ccy1, ccy2, asof, ONE)
            elif ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == d20180202:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-12 06:18:45.905061
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.services import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    service = TestFXRateService()


# Generated at 2022-06-12 06:18:48.986709
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    assert (
        FXRateService().queries([("EUR", "USD", Date("2018-01-01"))])
        == [(None)]
    )



# Generated at 2022-06-12 06:20:17.459182
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .temporal import Temporal
    """
    Tests queries method of class FXRateService
    """
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    date = Date(2018, 1, 1)
    fxRate = FXRate(ccy1, ccy2, date, Decimal("1.2"))
    # Test FXRateService using In-Memory FXRateService
    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if(ccy1 == Currency("EUR") and ccy2 == Currency("USD") and asof == date):
                return fxRate
            else:
                return None
        def queries(self, queries, strict=False):
            for query in queries:
                ccy1,