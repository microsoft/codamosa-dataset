

# Generated at 2022-06-12 06:10:36.449889
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest.mock import Mock
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currency, Currencies
    from pypara.currency.fx import FXRateService

    # Create a mock FX rate service:
    mock_fx_rate_service = Mock(FXRateService)

    # Create a mock FX rate:
    mock_fx_rate = Mock(FXRate)

    # Setup the mock FX rate service:
    mock_fx_rate_service.queries = Mock(return_value=[mock_fx_rate])

    # Run the method to be tested:
    fx_rates = mock_fx_rate_service.queries([(Currencies["EUR"], Currencies["USD"], Date(2017, 1, 1))])

    # Check the output:
    assert fx_

# Generated at 2022-06-12 06:10:43.002589
# Unit test for method queries of class FXRateService

# Generated at 2022-06-12 06:10:54.042932
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporals.zeitgeist import Date

    ## Create the reference rates list:
    rates = [
        FXRate(Currencies["USD"], Currencies["EUR"], Date(2017, 12, 31), Decimal("0.8")),
        FXRate(Currencies["USD"], Currencies["EUR"], Date(2018, 6, 30), Decimal("0.9")),
        FXRate(Currencies["USD"], Currencies["EUR"], Date(2019, 12, 31), Decimal("0.7"))
    ]

    ## Create the queries:

# Generated at 2022-06-12 06:11:04.373686
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    import pytest
    from decimal import Decimal
    from pypara.commons.exceptions import UnreachableException
    from pypara.currencies import Currency
    from pypara.fxrates import FXRate, FXRateService
    # Define the stub FX rate service:
    class StubFxRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currency("EUR") and ccy2 == Currency("USD") and asof == datetime.date(2019, 8, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            raise UnreachableException()
        def queries(self, queries, strict=False):
            raise UnreachableException()
    # Define a

# Generated at 2022-06-12 06:11:09.280468
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class SampleService(FXRateService):
        def query(self, *args, **kwargs):
            return None

        def queries(self, *args, **kwargs):
            return None

    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date(2000, 1, 1)

    rate = SampleService().query(ccy1, ccy2, asof)
    assert rate is None


# Generated at 2022-06-12 06:11:20.288680
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for the method query of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    ## Define the currency pair and date:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()

    ## Define the service implementation:
    class Service(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-12 06:11:29.434802
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    from unittest import mock

    from .currencies import Currencies, Currency
    from .dates import Date
    from .fxrates import FXRateService, FXRate, ONE

    service = mock.MagicMock(spec=FXRateService)
    service.queries.side_effect = [
        [ONE, None],
        [None, FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), ONE)],
        [None, None],
    ]


# Generated at 2022-06-12 06:11:33.233120
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    fxrate_service = FXRateService()
    fxrate = fxrate_service.query(Currency("USD"), Currency("EUR"), Date.today)
    print(fxrate)


# Generated at 2022-06-12 06:11:42.996841
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D103
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency

    class FXRateServiceMock(FXRateService):
        rates = {
            (Currency("USD"), Currency("EUR"), date(2019, 9, 30)): FXRate(
                Currency("USD"), Currency("EUR"), date(2019, 9, 30), Decimal("0.9")
            ),
            (Currency("EUR"), Currency("USD"), date(2019, 9, 30)): FXRate(
                Currency("EUR"), Currency("USD"), date(2019, 9, 30), Decimal("1.1")
            ),
        }


# Generated at 2022-06-12 06:11:47.906607
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal
    from .commons.zeitgeist import Date

    ## Test error conditions:

    ## Test SUT method:

    ## Test conversion:

    ## Test inverse:

    ## Test missing FX rate:

    ## Test cross currency:

    ## Test equal currency:


# Generated at 2022-06-12 06:12:02.292021
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies.adapters import CurrencyAdapter
    from pypara.datetime.adapters import DateAdapter
    # Arrange
    ccy_eur = CurrencyAdapter.from_string("EUR")
    ccy_usd = CurrencyAdapter.from_string("USD")
    asof = DateAdapter.from_string("2017-03-25")
    # Act
    lookup = FXRateService.default.query(ccy_eur, ccy_usd, asof)
    # Assert
    assert lookup is not None
    assert lookup[0] == ccy_eur
    assert lookup[1] == ccy_usd
    assert lookup[2] == asof


# Generated at 2022-06-12 06:12:06.982592
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService
    """
    try:
        # Test code
        raise NotImplementedError
    except Exception as e:
        # Test failed
        raise e
    else:
        # Test succeeded
        pass
    finally:
        # Test cleanup
        pass


# Generated at 2022-06-12 06:12:13.119344
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # pylint: disable=unused-argument,unused-variable,expression-not-assigned,unsubscriptable-object,missing-return-type-doc,missing-return-statement,missing-type-doc
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date()
    strict = True

    #### Test failed lookup:
    class Service(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False): return None
        def queries(self, queries, strict=False):
            for query in queries: yield None

    fxrs = Service()
    try:
        fxrs.query(ccy1, ccy2, asof)
        assert False
    except FXRateLookupError:
        assert True


# Generated at 2022-06-12 06:12:18.049123
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    import datetime

    fxrate_service = FXRateService()
    fxrate_service.query(Currency("EUR"), Currency("USD"), datetime.date.today(), strict=False)

# Generated at 2022-06-12 06:12:20.366029
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of class FXRateService.
    """

    pass



# Generated at 2022-06-12 06:12:29.984349
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date

    from pypara.currencies import Currencies

    queries = [(Currencies["EUR"], Currencies["USD"], date(2020, 1, 1)),
               (Currencies["USD"], Currencies["EUR"], date(2020, 1, 1))]

    rates = [FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 1), Decimal(2)),
             FXRate(Currencies["USD"], Currencies["EUR"], date(2020, 1, 1), Decimal(0.5))]

    class __FXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self._rates = rates

# Generated at 2022-06-12 06:12:42.078929
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .services.fxrates import CachedFXRateService
    from .commons.temporals import Temporals
    from .currencies import Currencies

    ## Prepare the FX rate service:
    fxrs = CachedFXRateService()

    ## Prepare the FX rate queries:
    queries = [
        (Currencies["EUR"], Currencies["USD"], Temporals["2020-02-31"]),
        (Currencies["USD"], Currencies["JPY"], Temporals["2020-02-29"]),
        (Currencies["USD"], Currencies["JPY"], Temporals["2030-10-29"]),
        (Currencies["EUR"], Currencies["USD"], Temporals["2020-03-01"]),
    ]

    ## Prepare the expected FX rates:

# Generated at 2022-06-12 06:12:54.714613
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.commons.tdd import EqualityTDDMixin
    from pypara.currencies import Currencies


# Generated at 2022-06-12 06:13:07.013933
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests :method:`FXRateService.query`.
    """
    import unittest
    from .currencies import Currency
    from .commons.numbers import ZERO
    from .commons.zeitgeist import Date
    from .fxrates import FXRate, FXRateService

    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service capable of providing a single EUR/USD rate.
        """


# Generated at 2022-06-12 06:13:18.714683
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .commons.enums import Template
    from .currencies import Currency
    from .dates import DateTime
    from .fxrates.memory import FXRateMemoryService

    fxrates = FXRateMemoryService(
        fxrates=[
            FXRate(Currency["EUR"], Currency["USD"], DateTime.of(2020, 9, 1), 1.10),
            FXRate(Currency["EUR"], Currency["USD"], DateTime.of(2020, 10, 1), 1.20),
        ],
        template=Template.CURRENCY_CCY,
    )


# Generated at 2022-06-12 06:13:32.854189
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from .currencies import Currency

    ## Initialize the query:
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date(2018, 1, 1)

    ## Do the query:
    from .rates import FXRateService
    fxrs: FXRateService = FXRateService()
    rate: Optional[Decimal] = fxrs.query(ccy1, ccy2, asof)

    ## Check the result:
    assert rate is not None


# Generated at 2022-06-12 06:13:35.788611
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    assert True


# Generated at 2022-06-12 06:13:46.823699
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import RealDate
    from .commons.zeitgeist import Date
    from .exchanges.s3fx import S3FXRateService

    fx = S3FXRateService()

    fx.query_s3_rates(['EURUSD', 'CADUSD'], date=Date(2003, 1, 2))
    
    fx.query(Currencies['EUR'], Currencies['USD'], Date(2003, 1, 2))


# Generated at 2022-06-12 06:13:51.970515
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Arrange
    ccy1 = Currencies['USD']
    ccy2 = Currencies['EUR']
    asof = date.today()
    fxrate_service = FXRateService()

    # Assert
    assert fxrate_service.query(ccy1, ccy2, asof) == None


# Generated at 2022-06-12 06:14:05.095949
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main
    from unittest.mock import MagicMock
    from . import currencies
    from .currencies import Currency
    from .datetime import Temporal
    from .fxrates import FXRateService
    from . import fxrates

    class MockCurrency(metaclass=Currency):
        USD = "USD"
        EUR = "EUR"

    class MockTemporal(Temporal):
        ONE = Temporal.from_datetime(datetime.datetime(2018, 1, 1, 0, 0, 0))
        TWO = Temporal.from_datetime(datetime.datetime(2019, 1, 1, 0, 0, 0))
        THREE = Temporal.from_datetime(datetime.datetime(2020, 1, 1, 0, 0, 0))


# Generated at 2022-06-12 06:14:14.777392
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import DtTemporal
    from decimal import Decimal
    from unittest.mock import MagicMock

    # Create the service
    service = MagicMock(spec=FXRateService)

    # Create a currency pair
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    # Create the queries
    from datetime import date

    today = date.today()
    queries = [(ccy1, ccy2, DtTemporal(today))] * 10

    # Create the rates
    rates = [FXRate(ccy1, ccy2, DtTemporal(today), Decimal("2"))] * 10

    # Populate the service
    service.queries.return_value = rates

    # Assert the rates

# Generated at 2022-06-12 06:14:23.755823
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the functionality of method queries of class FXRateService.
    """
    from .commons.zeitgeist import TODAY
    from .currencies import Currencies
    from .curvenodes import DateNode, TimeSeriesNode

    class DummyService(FXRateService):
        """
        Dummy FX rate service class.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the dummy FX rate service.
            """
            self.__rates = list(rates)


# Generated at 2022-06-12 06:14:35.753371
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase, main
    from pypara.currencies import Currency
    from pypara.datetime import Date, today
    from pypara.fx import FXRate, FXRateLookupError, FXRateService

    class FXRateServiceImpl(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.__rates = {(rate[0], rate[1], rate[2]): rate for rate in rates}

        def query(self, ccy1, ccy2, asof, strict=False):
            if strict:
                return self.__rates.get((ccy1, ccy2, asof))
            else:
                try:
                    return self.__rates[(ccy1, ccy2, asof)]
                except KeyError:
                    return None

# Generated at 2022-06-12 06:14:47.981617
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the :method:`FXRateService.query` method.
    """
    from .currencies import Currency

    ## Create a mock instance for foreign exchange rate:
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, 1)

    ## Make the mock instance the default service:
    FXRateService.default = MockFXRateService()

    ## Get a foreign exchange rate:
    rate = FXRateService.default.query(Currency("EUR"), Currency("USD"), Date("2019-01-01"))

    ## Verify the results:
    assert rate.ccy1 == Currency("EUR")
    assert rate.ccy2 == Currency("USD")
    assert rate.date == Date

# Generated at 2022-06-12 06:14:50.326982
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:15:06.866056
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert False


# Generated at 2022-06-12 06:15:16.187018
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.fxrate import FXRate
    from pypara.fxrate.rates import InMemoryFXRateProvider, MockFXRateProvider
    from pypara.temporal import Date

    # InMemoryFXRateProvider
    provider = InMemoryFXRateProvider(
        FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.25"))
    )
    assert provider.query(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1)) == FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.25"))
    assert provider.query(Currencies["USA"], Currencies["EUR"], Date(2018, 1, 1)) is None

# Generated at 2022-06-12 06:15:18.082151
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # test FXRateService.query
    assert True , "Test not implemented"



# Generated at 2022-06-12 06:15:28.024023
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from datetime import date

    ## No queries should raise ValueError:
    try:
        list(FXRateService.default.queries([]))
    except ValueError:
        pass
    else:
        assert False, "No query should raise ValueError."

    ## Query a single rate:
    rates = list(FXRateService.default.queries([(Currencies["EUR"], Currencies["USD"], date.today())]))
    assert len(rates) == 1
    assert rates[0].ccy1 == Currencies["EUR"]
    assert rates[0].ccy2 == Currencies["USD"]
    assert rates[0].date == date.today()

    ## Query multiple rates:

# Generated at 2022-06-12 06:15:33.616998
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create a mock FX rate service:
    class MockFXRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]) -> None:
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            return None


# Generated at 2022-06-12 06:15:46.794228
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .temporal import Date
    from .fx import FXRate, FXRateService
    
    ## Create an arbitrary FX rate:
    FXRateService.default = FXRateService()
    rate = FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))
    
    ## Override the query method:
    class TestService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return rate if (ccy1 == rate.ccy1 and ccy2 == rate.ccy2 and asof == rate.date) else None

    ## Perform the test:
    service = TestService()
    
    assert service.query(Currencies["JPY"], Currencies["USD"], Date.today()) is None


# Generated at 2022-06-12 06:15:53.967404
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.finance import FXRates
    class TestFXRateService(FXRateService):
        """
        TestFXRateService
        """
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            query
            """
            return FXRates[ccy1, ccy2, asof]

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            queries
            """

# Generated at 2022-06-12 06:16:03.103054
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test method queries of class FXRateService.
    """
    from decimal import Decimal
    from pypara.currencies import Currencies
    from yggdrasil.commons.tests import TestCase
    from yggdrasil.commons.time import Temporal

    class TestQuery:
        """
        Class for unit test for class FXRateService.
        """

        def __init__(self, ccy1: Currencies, ccy2: Currencies, temporal: Temporal, rate: Decimal):
            """
            Initialize attributes for unit test for class FXRateService.
            """
            self.ccy1 = ccy1
            self.ccy2 = ccy2
            self.temporal = temporal
            self.rate = rate


# Generated at 2022-06-12 06:16:15.021120
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies

    from .currencies import Currency
    ## Base class for testing fx rate service queries:
    class TestFXRateService(FXRateService):
        def __init__(self):
            self.rates = {
                (Currencies["EUR"], Currencies["USD"], Date.of("2017-12-31")): Decimal("1.25"),
                (Currencies["USD"], Currencies["EUR"], Date.of("2017-12-31")): Decimal("0.80"),
            }
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
 
            rate = self.rates.get((ccy1, ccy2, asof))

# Generated at 2022-06-12 06:16:24.441838
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.markets.futures.fxrate_service import SimulatedFXRateService, FXRateLookupError

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date.today()
    fxrate = Decimal("1.1")

    fxrate_service = SimulatedFXRateService([(ccy1, ccy2, date, fxrate)])
    assert fxrate_service.query(ccy1, ccy2, date) == FXRate(ccy1, ccy2, date, fxrate)

    fxrate_service = SimulatedFX

# Generated at 2022-06-12 06:16:59.096403
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the :method:`FXRateService.queries` method.
    """

    # Import required external modules:
    import datetime
    from decimal import Decimal

    # Import required modules:
    from ..currencies import Currency
    from ..commons.zeitgeist import Date
    from .commons.numbers import ZERO

    # Define a test fx rate:
    rate = FXRate(Currency("EUR"), Currency("USD"), Date(datetime.date.today()), Decimal("2"))

    # Define a test query:

# Generated at 2022-06-12 06:16:59.695143
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert False

# Generated at 2022-06-12 06:17:09.283008
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Rial, Dollar, Euro
    from .temporal import Month
    from decimal import Decimal
    from pypara.fxrates import FXRateService, FXRateLookupError
    from pypara.commons.collections import Interceptor

    class FakeFXRateService(FXRateService):
        _rates = {
            (Euro, Dollar, "2018-01"): Decimal("1.18"),
            (Euro, Dollar, "2018-02"): Decimal("1.16"),
            (Rial, Dollar, "2018-01"): Decimal("0.0025"),
            (Rial, Dollar, "2018-02"): Decimal("0.0030"),
        }


# Generated at 2022-06-12 06:17:22.111891
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies, Currency

    class CurrencyRateService(FXRateService):

        def __init__(self):
            pass

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

# Generated at 2022-06-12 06:17:23.505896
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:17:35.709457
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .commons.zeitgeist import Temporal

    from .forex import FXRateService

    ## Create a rate service:
    class QFXRateService(FXRateService):

        def __init__(self, *args):
            self._args = args

        def query(self, ccy1, ccy2, asof, strict=False):

            if (ccy1, ccy2, asof) in self._args:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)


# Generated at 2022-06-12 06:17:47.601048
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query of the foreign exchange rate service.
    """

    import datetime

    from .currencies import Currency, Currencies

    from .fxrates import FXRate, FXRateLookupError, FXRateService

    class FakeFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict = False):

            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date(2019, 10, 1):
                return FXRate.of(ccy1, ccy2, asof, 2)
        # end method query



# Generated at 2022-06-12 06:17:58.943051
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.fx import FXRateService
    from pypara.currencies import Currencies
    assert FXRateService.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=True) == Decimal("1.12")
    assert FXRateService.query(Currencies["USD"], Currencies["EUR"], datetime.date.today(), strict=True) == Decimal("0.89")
    assert FXRateService.query(Currencies["EUR"], Currencies["RUB"], datetime.date.today(), strict=True) == Decimal("10")
    assert FXRateService.query(Currencies["EUR"], Currencies["TRY"], datetime.date.today(), strict=True) == Decimal("25")

# Generated at 2022-06-12 06:18:09.981007
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.currencies.currencies import Currencies
    from pypara.temporals.zeitgeist import Date
    import unittest

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict):
            return FXRate(ccy1, ccy2, asof, Decimal('2'))
    service = TestFXRateService()
    currency1 = Currencies['EUR']
    currency2 = Currencies['USD']
    asof = Date.now()
    rate = service.query(currency1, currency2, asof)
    assert rate.ccy1 == currency1
    assert rate.ccy2 == currency2
    assert rate.date == asof

# Generated at 2022-06-12 06:18:22.395943
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create an instance of the abstract class:
    fxs = FXRateService()

    ## A lookup error should be raised for an invalid query:
    try:
        fxs.query(Currencies["USD"], Currencies["EUR"], datetime.date.today(), strict=True)
        raise RuntimeError("An exception should be raised.")
    except FXRateLookupError:
        pass

    ## A None should be returned for an invalid query if strict is False:
    assert fxs.query(Currencies["USD"], Currencies["EUR"], datetime.date.today(), strict=False) is None

    ## A ValueError should be raised for an invalid query:

# Generated at 2022-06-12 06:19:46.132364
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class SimpleFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("2.0"))
            else:
                return None

    rate_service = SimpleFXRateService()
    asof = datetime.date.today()
    ## Existing rate:
    rate = rate_service.query(Currencies["EUR"], Currencies["USD"], asof)

# Generated at 2022-06-12 06:19:57.819432
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of class FXRateService
    """

    # pylint: skip-file
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.content.instrument import InstrumentCode, InstrumentType
    from pypara.content.instruments import Index, Instrument, Portfolio
    from pypara.content.simulation import Simulation
    from pypara.content.position import Position
    from pypara.content.portfolio import Holdings
    from pypara.content.valuation import Valuation
    from pypara.curves import Curve, CurveService
    from pypara.fx.fx import FXRate
    from pypara.fx.fx import FXRateService as FXRateService_

    # Set simulation date:
    date = datetime.datetime.today()



# Generated at 2022-06-12 06:20:09.272241
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService

    >>> import datetime
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currencies
    >>> from pypara.rates import FXRateService, FXRate
    >>> class FXRateServiceMock(FXRateService):
    ...     def query(self, ccy1, ccy2, asof, strict: bool = False) -> Optional[FXRate]:
    ...         return FXRate(ccy1, ccy2, asof, Decimal("2"))
    ...     def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
    ...         return self.query(ccy1, ccy2, asof)
    ... 
    """
    pass

# Generated at 2022-06-12 06:20:17.952293
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import mock
    from pypara.annotations import overrides
    from pypara.currencies import Currency
    from pypara.fx import FXRate, FXRateService, FXRateLookupError
    from datetime import date

    # a test currency
    ccy1 = Currency("USD")

    # another test currency
    ccy2 = Currency("EUR")

    # a test date
    asof = date(2018, 9, 20)

    # a test FX rate
    rate = FXRate(ccy1, ccy2, asof, 1.9780)

    # a mocked FX rate service
    mock_service = mock.create_autospec(FXRateService)

    # a query
    query = FXRateService.TQuery(ccy1, ccy2, asof)

    # a query for