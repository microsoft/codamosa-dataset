

# Generated at 2022-06-12 06:10:32.329909
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.zeitgeist import Date
    from .currencies import Currencies

    from .services import FXRateServiceFactory

    fxrates = FXRateServiceFactory.get()

    # Verify error conditions
    from contextlib import suppress

    with suppress(TypeError):
        fxrates.query('EUR', Currencies["USD"], Date.today(), strict=True)
    with suppress(TypeError):
        fxrates.query(Currencies["EUR"], 'USD', Date.today(), strict=True)
    with suppress(TypeError):
        fxrates.query(Currencies["EUR"], Currencies["USD"], '2019-01-01', strict=True)

    # A reciprocal rate

# Generated at 2022-06-12 06:10:37.822059
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-12 06:10:43.751296
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService
    from pypara.zeitgeist import Temporal

    def service(query: Tuple[Currency, Currency, Temporal]):
        ccy1, ccy2, asof = query
        if ccy1 == Currencies.EUR and ccy2 == Currencies.USD:
            return FXRate.of(Currencies.EUR, Currencies.USD, asof, Decimal("1.5"))
        else:
            return None


    ## Non-strict test case:
    res = FXRateService.query(service,
                              Currencies.EUR, Currencies.USD,
                              Temporal.date(year=2019, month=1, day=1))
    assert res

# Generated at 2022-06-12 06:10:50.359308
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-12 06:10:57.759270
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    from .currencies import Currencies
    from .commons.zeitgeist import today
    rate = FXRate(Currencies["EUR"], Currencies["USD"], today(), Decimal("2.00"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], today(), Decimal("0.50"))
    assert ~rate == rrate


# Generated at 2022-06-12 06:11:07.731924
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .services.fxrateservice import FXRateService
    from .temporal import Temporal

    class TestService(FXRateService):

        def __init__(self, fxrates: Iterable[FXRate]) -> None:
            self._rates = dict([((rate[0], rate[1], rate[2]), rate) for rate in fxrates])

        def __repr__(self):
            return f"<TestService({self._rates})>"

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return self._rates.get((ccy1, ccy2, asof))


# Generated at 2022-06-12 06:11:12.629477
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.rates import FXRate

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-12 06:11:22.709564
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateService
    import unittest
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("1.2"))
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("1.2"))]
   

# Generated at 2022-06-12 06:11:35.905668
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.discrete import Temporal
    from pypara.fxrates import FXRateService

    date1 = Temporal("2018-01-01")
    date2 = Temporal("2018-01-02")
    date3 = Temporal("2018-01-03")
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    queries = ((ccy1, ccy2, date1), (ccy1, ccy2, date2), (ccy1, ccy2, date3))

    lookup = mock.Mock(spec=FXRateService.query)

# Generated at 2022-06-12 06:11:44.937823
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    ## Import packages:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    ## Pick the query instances:
    queries = ((Currencies["EUR"], Currencies["USD"], datetime.date(2020, 12, 31)),
               (Currencies["USD"], Currencies["TRY"], datetime.date(2020, 1, 1)))

    ## Define the FXRateService subclass:

# Generated at 2022-06-12 06:12:02.137818
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from datetime import date
    from unittest.mock import AsyncMock, Mock
    mock = Mock(spec=FXRateService)
    queries = [
        (Currency('EUR'), Currency('USD'), date.fromordinal(1)),
        (Currency('TRY'), Currency('USD'), date.fromordinal(2))
    ]
    mock.query.side_effect = [None, FXRate(Currency('TRY'), Currency('USD'), date.fromordinal(2), 1)]
    mock.queries(queries, True)
    assert mock.query.call_count == 2
    assert mock.query.call_args_list[0][0] == queries[0]
    assert mock.query.call_args_list[1][0] == queries[1]
    mock = As

# Generated at 2022-06-12 06:12:03.310070
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass  # TODO


# Generated at 2022-06-12 06:12:11.771527
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies.enums import AuditCurrencies as Currencies
    from .services.exchange.impls.memory import FXRateMemoryService
    from .utils.temporal import Date

    # Prepare test service
    service = FXRateMemoryService()
    service.add(Currencies.EUR, Currencies.USD, Date(2018, 11, 26), Decimal('1.1400'))

    # Test invalid parameters
    try:
        service.query(Currencies.EUR, Currencies.EUR, Date(2018, 11, 26))
        assert False, "Should not reach here!"
    except ValueError as e:
        assert "must be different" in str(e)

    # Test when the rate is not available
    rate = service.query(Currencies.EUR, Currencies.USD, Date(2017, 11, 26))
   

# Generated at 2022-06-12 06:12:13.305824
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    pass


# Generated at 2022-06-12 06:12:22.022083
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies, Currency


    class _FxRateService(FXRateService):

        #: Defines a foreign exchange rates lookup table.
        _rates = {
            (Currencies["EUR"], Currencies["USD"], datetime.date.today()): Decimal("1.2")
        }

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[Decimal]:
            key = (ccy1, ccy2, asof)
            if key in self._rates:
                return self._rates[key]

            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None

    assert _Fx

# Generated at 2022-06-12 06:12:31.719541
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from typing import Generator
    from pypara.currencies import EUR, USD
    from pypara.commons.zeitgeist import Date
    from pypara.market.fxrates import FXRate, FXRateService

    class Turnstile(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            if ccy1 == EUR and ccy2 == USD and asof == Date(2019, 10, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-12 06:12:38.295918
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date

    class _MyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            assert ccy1 == Currencies["EUR"]
            assert ccy2 == Currencies["USD"]
            assert asof == Date("2018-01-01")
            assert not strict
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-12 06:12:46.080191
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Import modules under test
    import unittest
    from decimal import Decimal
    from pypara.currencies import EUR # type: ignore
    from pypara.currencies import USD # type: ignore
    from pypara.commons.zeitgeist import Date
    from pypara.fx import FXRateLookupError
    from pypara.fx import FXRateService
    from pypara.fx import FXRate
    from pypara.testing import TestCase

    # Define a dummy FXRateService class

# Generated at 2022-06-12 06:12:58.920777
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .datetimes import Date
    from .engine.rates import FixedFXRateService
    from .utils import to_date

    ## Create a rate service:
    fx_service = FixedFXRateService(
        [(Currency.of("EUR"), Currency.of("USD"), to_date("2015-02-01"), Decimal(1.15)),
         (Currency.of("USD"), Currency.of("EUR"), to_date("2015-02-01"), Decimal(1 / 1.15))]
    )

    ## Query USD/EUR rate:
    assert fx_service.query(Currency.of("USD"), Currency.of("EUR"), Date.of(2015, 2, 1))

    ## Query USD/EUR rate on a different date:

# Generated at 2022-06-12 06:13:09.988369
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    from pypara.currencies import Currency

    # Create a dummy FX rate service.
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    # Test that the query method raises an exception, as it must be implemented in all subclasses
    try:
        DummyFXRateService().queries([], strict=False)
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-12 06:13:29.744556
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara import FXRateService
    from pypara import currencies
    from pypara import dates

    class TestFXRateService(FXRateService):

        def query(self, ccy1: currencies.Currency, ccy2: currencies.Currency, asof: dates.Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError

        def queries(self, queries: Iterable[Tuple[currencies.Currency, currencies.Currency, dates.Date]], strict: bool = False) -> Iterable[Optional[FXRate]]:
            raise NotImplementedError

    try:
        TestFXRateService()
    except TypeError:
        pass
    else:
        raise RuntimeError("Failed to raise an exception when FXRateService is constructed without arguments.")

# Generated at 2022-06-12 06:13:40.198744
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method `query` of class :class:`FXRateService`.
    """
    from .currencies import Currencies
    from .temporals import date

    ## Initialize the default foreign exchange rate service:
    from .fxrates import FXRateServices
    FXRateService.default = FXRateServices["Empty"]

    ## Test `query` method:
    assert FXRateService.default.query(Currencies["EUR"], Currencies["EUR"], date.today(), strict = True) is None
    assert FXRateService.default.query(Currencies["EUR"], Currencies["EUR"], date.today(), strict = False) is None


# Generated at 2022-06-12 06:13:52.409304
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method :method:`FXRateService.queries`
    """
    ## Create an FX rate service that returns hard-coded FX rates:
    class HardCodedFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            ## Loop through the rates:
            for rate in rates:
                ## Check if the rate is matched:
                if rate[0] == ccy1 and rate[1] == ccy2 and rate[2] == asof:
                    return rate

            ## We should have returned already. Either the rate does not exists or the runtime is not calling this
            ## method. Need to investigate...

# Generated at 2022-06-12 06:14:05.144535
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporals import Temporals
    import unittest

    class FXRateServiceTest(unittest.TestCase):
        def test_it(self):
            # Set up:
            class Mock(FXRateService):
                """
                Defines a mock FX rate service.
                """

                def __init__(self, rates: Iterable[FXRate]) -> None:
                    self.rates = rates

                def query(self, ccy1: Currency, ccy2: Currency, asof: Date) -> Optional[FXRate]:
                    for rate in self.rates:
                        if (rate.ccy1, rate.ccy2, rate.date) == (ccy1, ccy2, asof):
                            return rate
                    return None


# Generated at 2022-06-12 06:14:14.813007
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the functionality of the abstract method :method:`FXRateService.query`.
    """

    ## Import the required objects to be tested:
    from .services.mocks import MockFXRateService

    ## Initialize two mock service objects:
    fxrs = MockFXRateService()
    fxrs2 = MockFXRateService()

    ## The default FX rate service must be the first one:
    assert fxrs == FXRateService.default

    ## Set the default FX rate service to the second service object:
    FXRateService.default = fxrs2

    ## The default FX rate service must be the second one now:
    assert fxrs2 == FXRateService.default

    ## The query method must raise an exception:

# Generated at 2022-06-12 06:14:23.757303
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest.mock as mock
    import datetime

    ## Create a mock:
    service = mock.Mock(spec=FXRateService)
    service.query = mock.Mock()

    ## Create a query set:
    today = datetime.date.today()
    ccy1 = mock.Mock(spec=Currency)
    ccy2 = mock.Mock(spec=Currency)
    ccy3 = mock.Mock(spec=Currency)
    ccy4 = mock.Mock(spec=Currency)
    queries = [
        (ccy1, ccy2, today),
        (ccy3, ccy4, today),
    ]

    ## Call method:
    service.queries(queries)

    ## Verify method call pattern:
    service.query.assert_has_

# Generated at 2022-06-12 06:14:35.796928
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.env import Environment
    from pypara import FXRate

    class FXRateServiceImpl(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof.toordinal() == Date.today().toordinal():
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))
            else:
                raise FXRateLookupError(ccy1=ccy1, ccy2=ccy2, asof=asof)


# Generated at 2022-06-12 06:14:47.981433
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .time import ZonedDateTime
    from .trading.services import FXRateProvider
    from .unittest import TestCase

    ## Create a test case:
    class Test(TestCase):

        def test_query(self):

            ## Access the FX rate service:
            fxrate_service = FXRateProvider.default

            ## Create FX rate queries:

# Generated at 2022-06-12 06:14:59.924061
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from itertools import starmap
    from pypara.currencies import Currency
    from pypara.currencies.rates import FAKERateService

    srv = FXRateService.default or FAKERateService()
    queries = ((Currency("EUR"), Currency("USD"), Date(2020, 1, 1)), (Currency("EUR"), Currency("USD"), Date(2020, 2, 1)))
    rates = srv.queries(queries)
    assert len(queries) == len(rates) == 2
    assert all(starmap(lambda c1, c2, asof, rate: rate.ccy1 == c1 and rate.ccy2 == c2 and rate.date == asof, zip(queries, rates)))



# Generated at 2022-06-12 06:15:08.563962
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .currencies.registry import CURRENCIES
    from .temporal.dates import Date
    from .fx import FXRateService
    from random import choice, randint

    # Pick some currencies:
    Q = 100
    CCYS = tuple(CURRENCIES.values())
    RATES = {
        (ccy1, ccy2, Date.today()): 1 if ccy1 == ccy2 else randint(1, 100)
        for ccy1 in CCYS
        for ccy2 in CCYS
    }

    # Define a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

# Generated at 2022-06-12 06:15:30.574371
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .currencies import CurrencyPair
    from .commons.zeitgeist import Date
    from pypara.fx.memoryrateservice import MemoryRateService
    from pypara.fx.rateservicefactory import RateServiceFactory
    from pypara.fx.registries import RateServiceRegistry
    from typing import Iterable, Tuple
    from datetime import date
    
    # Define a currency pair
    EUR = Currency.of("EUR")
    USD = Currency.of("USD")
    EURUSD = CurrencyPair(EUR, USD)
    
    # Define a date
    date = date.today()
    
    # Define a query
    t = (EUR, USD, date)
    
    # Define a registry
    registry = RateServiceRegistry
    

# Generated at 2022-06-12 06:15:34.683001
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    def implementation(queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
        for ccy1, ccy2, asof in queries:
            yield self.query(ccy1, ccy2, asof, strict)

    implementation(queries)

# Generated at 2022-06-12 06:15:38.713788
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    pass


# Generated at 2022-06-12 06:15:49.359957
# Unit test for method query of class FXRateService

# Generated at 2022-06-12 06:16:01.462144
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies

    # assert FXRateService.query(Currencies["USD"], Currencies["USD"], Date.today()) == ONE
    # assert FXRateService.query(Currencies["USD"], Currencies["EUR"], Date.today()) > ONE
    # assert FXRateService.query(Currencies["EUR"], Currencies["USD"], Date.today()) < ONE

    dv = FXRateService.query(Currencies["USD"], Currencies["USD"], Date.today())

    if dv is None:
        raise AssertionError("Expected: not None, Got: None")

    dv = FXRateService.query(Currencies["USD"], Currencies["EUR"], Date.today())

    if dv is None:
        raise AssertionError("Expected: not None, Got: None")


# Generated at 2022-06-12 06:16:13.596149
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This function tests the queries function of the FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.market.fxrates import FXRateService
    from pypara.market.fxrates import FXRate

    class TestFXRateService(FXRateService):
        @classmethod
        def query(cls, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == cls.ccy1 and ccy2 == cls.ccy2 and asof == cls.asof:
                return cls.rate

# Generated at 2022-06-12 06:16:23.606704
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, value=Decimal("1"))
            elif ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, value=Decimal("2"))

# Generated at 2022-06-12 06:16:36.152966
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates.services import FXRateServiceImpl

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    service = FXRateServiceImpl(rate)

    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) == rate
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today() + datetime.timedelta(1)) == None
    assert service.query(Currencies["USD"], Currencies["EUR"], datetime.date.today()) == None


# Generated at 2022-06-12 06:16:47.712904
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .temporal import Temporal

    class FXRateServiceTest(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            try:
                return FXRate.of(ccy1, ccy2, asof, Decimal("2"))
            except:
                return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False):
            return (self.query(*query) for query in queries)


    fxr = FXRateServiceTest().query(Currency("EUR"), Currency("USD"), Date.today())
    print(fxr)
    print(isinstance(fxr, FXRate))
    print(type(fxr))


# Generated at 2022-06-12 06:16:59.190828
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.market.fxrates import FXRateLookupError, FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if (ccy1, ccy2) == (Currencies["EUR"], Currencies["USD"]):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None


# Generated at 2022-06-12 06:17:39.203111
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from uuid import uuid4
    # noinspection PyAbstractClass
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: datetime.date, strict: bool = False) -> Optional[
            Decimal]:
            return Decimal(str(uuid4())[:5])
        def queries(self, queries: Iterable[FXRateService.TQuery],
                    strict: bool = False) -> Iterable[Optional[Decimal]]:
            return [self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries]
    service = MockFXRateService()
    ## Create a set of queries:

# Generated at 2022-06-12 06:17:46.246804
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from .temporal import TimePoint
    
    # Initialize the FXRateService object
    FXRateService.default = None
    assert FXRateService.default is None
    # Execute the method
    result = FXRateService.query(Currencies["EUR"], Currencies["USD"], TimePoint.today())
    # Check the result
    assert result is None
    # Return the result
    return result


# Generated at 2022-06-12 06:17:54.150858
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fxrates import FXRate, FXRateService

    # Create a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("1.5"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate.of

# Generated at 2022-06-12 06:18:02.479291
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal

    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currency, Currencies

    class FXRateServiceTest(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            assert isinstance(self, FXRateServiceTest)
            assert isinstance(ccy1, Currency)
            assert isinstance(ccy2, Currency)
            assert isinstance(asof, Date)
            assert isinstance(strict, bool)
            return None

    fxrate_service: FXRateService = FXRateServiceTest()

    assert fxrate_service.query(Currencies["EUR"], Currencies["USD"], Date.today()) is None



# Generated at 2022-06-12 06:18:12.083688
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance import FXRateService
    from pypara.finance.memory_fxrate_service import MemoryFXRateService

    ## Create the rate service:
    fx = MemoryFXRateService()
    fx["EUR", "USD", datetime.date(2019, 1, 1)] = Decimal("1.1")
    fx["EUR", "USD", datetime.date(2019, 1, 2)] = Decimal("1.2")
    fx["EUR", "USD", datetime.date(2019, 1, 3)] = Decimal("1.3")
    fx["EUR", "USD", datetime.date(2019, 2, 4)] = Decimal("1.4")
    fx

# Generated at 2022-06-12 06:18:16.125625
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit tests for method queries of class :class:`FXRateService`.
    """

    # TODO implement this method
    pass

# Generated at 2022-06-12 06:18:26.201733
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import unittest
    
    #from pypara.currencies import Currencies
    from pypara.currencies.country import Country
    from pypara.currencies.iso4217 import Currencies
    from pypara.currencies.numeric import Numeric
    from pypara.currencies.other import Other
    from pypara.currencies.special import Special
    import datetime
    
    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.real_ccy1 = Currencies["EUR"]
            self.real_ccy2 = Currencies["USD"]
            self.real_asof = datetime.date.today()


# Generated at 2022-06-12 06:18:36.415139
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # import test modules
    from decimal import Decimal
    from typing import Iterable
    from unittest.mock import patch
    from pypara.currencies import Currency
    from pypara.exchange import FXRate, FXRateService
    from pypara.commons.zeitgeist import Date
    # define unit test
    @patch.object(FXRateService, "query")
    def test(query, self, query_: Iterable[Tuple[Currency, Currency, Date]], strict: bool = False) -> Iterable[Optional[FXRate]]:
        # TODO: Add strict attribute
        query.assert_called()
        query.assert_called_with(query_, strict)
        # return results

# Generated at 2022-06-12 06:18:48.428176
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pytest
    from datetime import date
    from decimal import Decimal

    class TestFXRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]):
            self._rates = {
                (rate.ccy1, rate.ccy2, rate.date): rate for rate in rates
            }

        def query(self, ccy1, ccy2, asof, strict=False):
            return self._rates.get((ccy1, ccy2, asof))

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    from .currencies import Currencies


# Generated at 2022-06-12 06:18:49.327123
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:20:16.052541
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import USD, EUR
    from .datetime import today
    from .rates import FXRateServiceMemory
    from .testing import Assert

    ## Create a memory service:
    service = FXRateServiceMemory()

    ## Add some sample FX rate data:
    service.update([
        FXRate.of(USD, EUR, today(), Decimal("2")),
        FXRate.of(USD, EUR, today(), Decimal("2")),
        FXRate.of(USD, EUR, today(), Decimal("2")),
    ])

    ## Lookup data and make assertions:
    with Assert.raises(ValueError):
        service.query(euro, USD, today())

    Assert.equal(service.query(USD, EUR, today()), Decimal("2"))
