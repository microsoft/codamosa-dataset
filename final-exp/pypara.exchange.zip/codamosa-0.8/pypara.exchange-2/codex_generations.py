

# Generated at 2022-06-12 06:10:25.112802
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # return: The foreign exhange rate as a :class:`Decimal` instance or None.
    assert True

# Generated at 2022-06-12 06:10:35.291987
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests :meth:`~pypara.services.fxrate.FXRateService.query` method of :class:`~pypara.services.fxrate.FXRateService`.
    """
    from ..services.fxrate import FXRateService

    class ConcreteFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):  # noqa: N805
            pass

        def queries(self, queries, strict):  # noqa: N805
            pass

    ConcreteFXRateService().query(None, None, None)
    ConcreteFXRateService().query(None, None, None, False)


# Generated at 2022-06-12 06:10:36.765493
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    '''
    This function tests method query of class FXRateService
    '''
    return 0

# Generated at 2022-06-12 06:10:38.237943
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert FXRateService.query("foo", "bar", "baz", strict=True) is None

# Generated at 2022-06-12 06:10:42.579355
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Let's create an empty FX rate service:
    fx = FXRateService()
    print(fx.query())



# Generated at 2022-06-12 06:10:53.971253
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.testing import assert_raises

    ## Defining a test FX rate service:
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:  # noqa: D102
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                return FXRate(ccy1, ccy2, asof, Decimal("1.1"))

    ## Check query:

# Generated at 2022-06-12 06:10:55.158716
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:11:05.506379
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    class FXRateServiceMock(FXRateService):
        _FX_RATE_MAP = {
            (Currencies["EUR"], Currencies["USD"]): FXRate(Currencies["EUR"], Currencies["USD"], date(2019, 6, 15), Decimal("1.12"))
        }

        def __init__(self, strict: bool = False) -> None:
            self._strict = strict

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            key = (ccy1, ccy2)

# Generated at 2022-06-12 06:11:13.598848
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of class :class:`FXRateService`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .fxrateservices import InMemoryFXRateService

    ## Create FX rate service with a single EUR/USD rate:
    service = InMemoryFXRateService([FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))])  # noqa: E501

    ## Returned rate is EUR/USD rate but inverted:
    rate = service.query(Currencies["USD"], Currencies["EUR"], datetime.date.today())
    assert rate.ccy1 == Currencies["USD"]
    assert rate.ccy2 == Currencies["EUR"]

# Generated at 2022-06-12 06:11:23.844505
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Import external modules:
    import unittest
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currency, Currencies
    from pypara.exchanges import FXRateService, FXRate

    class MockFXRateService(FXRateService):
        """Defines a mock FX rate service."""

        def __init__(self):
            """Initializes the mock FX rate service."""

# Generated at 2022-06-12 06:11:39.159307
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporals import ASOF

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [
                FXRate.of(ccy1, ccy2, asof, Decimal(1))
                for ccy1, ccy2, asof in queries
            ]

    ## Set the default FX rate service:
    FXRateService.default = TestFXRateService()

    ## Query the fx rate service:

# Generated at 2022-06-12 06:11:50.623305
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates.services import SimpleFXRateService

    class TestFXRateService(unittest.TestCase):
        """
        Tests for :class:`FXRateService`.
        """


# Generated at 2022-06-12 06:11:53.168543
# Unit test for method query of class FXRateService
def test_FXRateService_query(): 
    """
    Unit test for method query of class FXRateService
    """

    print("test_FXRateService_query")






# Generated at 2022-06-12 06:12:02.840673
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`queries` method of class :class:`FXRateService`.
    """
    from .commons.zeitgeist import Date
    from .currencies import Currency
    from .fxtrading.ecb import ECB
    from .fxtrading.rates import FXRateLookupError
    from decimal import Decimal
    from unittest import TestCase, main

    ## Define the test suite:
    class FXRateServiceTest(TestCase):
        """
        Tests :method:`queries` method of class :class:`FXRateService`.
        """

        # noinspection PyMissingOrEmptyDocstring
        def setUp(self) -> None:
            self.ecb = ECB.get()

        # noinspection PyMissingOrEmptyDocstring

# Generated at 2022-06-12 06:12:04.508196
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: Implement
    assert True


# Generated at 2022-06-12 06:12:16.632649
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # type: ignore
    """
    Unit test for method query of class FXRateService:
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MyFXRateService(FXRateService):
        """
        A dummy FX rate service.
        """
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

# Generated at 2022-06-12 06:12:28.055360
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class DummyFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.rates = rates

        def query(self, ccy1, ccy2, asof, strict=False):
            return next(
                (rate for rate in self.rates if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof), None
            )

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof)

    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies


# Generated at 2022-06-12 06:12:30.721534
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService

    :param self: The object being tested
    :return: Nothing
    """
    _test_FXRateService_query(FXRateService())


# Generated at 2022-06-12 06:12:36.877058
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest.mock import MagicMock
    FXRateServiceMock = MagicMock(spec=FXRateService)
    FXRateServiceMock.query.assert_not_called()
    FXRateServiceMock.query(1, 2, 3)
    FXRateServiceMock.query.assert_called_once()

# Generated at 2022-06-12 06:12:45.361666
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies, Currency
    from .providers.memory_rate_provider import MemoryFXRateProvider

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = date(2020, 1, 1)
    queries = [
        (ccy1, ccy2, asof),
        (ccy1, ccy2, date(2020, 2, 1)),
        (Currencies["CHF"], Currencies["JPY"], asof)
    ]

    rate_provider = MemoryFXRateProvider()
    rate_provider.add_rate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-12 06:12:54.447229
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :func:`queries` method of :class:`FXRateService`.
    """
    # TODO: Complete this unit test
    pass

# Generated at 2022-06-12 06:13:06.810291
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from .currencies import Currencies
    from .temporal import Temporal

    class MockFXRateService(FXRateService):
        def __init__(self):
            pass
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

# Generated at 2022-06-12 06:13:18.636903
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pytz import utc
    from datetime import date

    from pypara.rates.services import InMemoryFXRateService

    service = InMemoryFXRateService(
        "USD",
        "USD",
        date(2016, 1, 1),
        Decimal("1"),
        "JPY",
        "USD",
        date(2016, 1, 1),
        Decimal("0.01"),
        "USD",
        "EUR",
        date(2016, 1, 1),
        Decimal("0.8"))

    rate = service.query(Currencies["USD"], Currencies["JPY"], date(2016, 1, 1))
    assert rate.ccy1 == Currencies["USD"]

# Generated at 2022-06-12 06:13:32.361064
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .currencies import CurrencyType
    from .temporal import Date, Period
    from .temporal import PeriodType
    from .temporal import cdate, cperiod
    from .temporal import datetime
    from .temporal import pytest

    from .tools import fxrates

    from decimal import Decimal

    class SomeFXRateService1(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return fxrates.query(ccy1, ccy2, asof, strict=strict)

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return fxrates.qu

# Generated at 2022-06-12 06:13:40.365213
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    print("=" * 72)
    print("-" * 72)
    print("Started unit test for method query of class FXRateService.")
    print("-" * 72)
    print("NOT IMPLEMENTED")
    print("-" * 72)
    print("Finished unit test for method query of class FXRateService.")
    print("=" * 72)


# Generated at 2022-06-12 06:13:51.118305
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    class LocalFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

    service = LocalFXRateService()
    rate = service.query(Currencies["EUR"], Currencies["USD"], "2019-01-01")
    assert rate == FXRate(Currencies["EUR"], Currencies["USD"], "2019-01-01", Decimal("2"))


# Generated at 2022-06-12 06:14:03.847748
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: E265
    """
    Tests the queries function of the FXRateService class.
    """
    from unittest import TestCase, mock
    from .currencies import Currencies
    from .commons.zeitgeist import now
    from .fx import FXRateService, FXRateLookupError

    ## Create a test case:
    class FXRateServiceTests(TestCase):
        """
        Provides test cases for the FXRateService class.
        """

        def test_queries(self):
            """
            Tests the queries function of the FXRateService class.
            """
            ## Create queries:
            queries = [
                (Currencies["EUR"], Currencies["USD"], now()),
                (Currencies["USD"], Currencies["EUR"], now())
            ]

            ## Create a mock function:

# Generated at 2022-06-12 06:14:14.086606
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime as dt

    from decimal import Decimal
    from pypara.currencies import Currencies

    class ForeignExchangeRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, Decimal("1"))
            elif ccy1 != Currencies["USD"] or ccy2 != Currencies["JPY"]:
                return None
            elif asof == dt.date(2019, 12, 12):
                return FXRate(ccy1, ccy2, asof, Decimal("111.2"))

# Generated at 2022-06-12 06:14:22.914535
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D103
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal

    service = FXRateService()

    fx = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("2"))

    # Test strict mode
    try:
        service.query(fx[0], fx[1], fx[2], strict=True)
    except FXRateLookupError:
        pass
    except Exception as e:
        raise RuntimeError(e)

    # Test non-strict mode
    assert service.query(fx[0], fx[1], fx[2], strict=False) == None



# Generated at 2022-06-12 06:14:32.622478
# Unit test for method queries of class FXRateService

# Generated at 2022-06-12 06:14:46.986841
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:14:59.644979
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from datetime import date

    from .commons.temporal import Temporal
    from .currencies import Currencies

    class FXRateServiceStub(FXRateService):
        """
        Provides a stub implementation of the foreign-exchange rate service.
        """


# Generated at 2022-06-12 06:15:08.218886
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date

    # def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
    class M(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries)
    m = M()
    m.queries([(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1))])

# Generated at 2022-06-12 06:15:10.395084
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """ Tests for method FXRateService_query of class FXRateService """
    pass

# Generated at 2022-06-12 06:15:21.165990
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Import built-in modules
    import unittest
    from decimal import Decimal
    from datetime import date
    # Import third-party modules
    from nose.tools import assert_equal, assert_raises
    # Import pypara modules
    from .currencies import Currency, Currencies
    from .services.fxrateservice import FXRateService, FXRate
    # Define a test class
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            rv = []

# Generated at 2022-06-12 06:15:30.307178
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency, Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporal import Date

    CURRENCIES = Currencies

    class DummyRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            return FXRate(ccy1, ccy2, asof, ONE)

        def queries(self, queries, strict: bool = False):
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, ONE)

    fxrs = DummyRateService()

    assert fxrs.query(CURRENCIES["EUR"], CURRENCIES["USD"], Date.today()) == FXRate

# Generated at 2022-06-12 06:15:31.241333
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:15:37.698588
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService

    Source: https://github.com/python/mypy/issues/5562
    """
    from collections import namedtuple

    class MyQuery(namedtuple("MyQuery", ["ccy1", "ccy2", "asof"])):
        pass

    class MyService(FXRateService):
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return queries

    query = MyQuery(None, None, None)

    MyService().queries([query])

# Generated at 2022-06-12 06:15:48.656939
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporal import Temporal

    ## Implementation:
    class Mock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[Decimal]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return Decimal("2")
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                return Decimal("0.5")
            return None


# Generated at 2022-06-12 06:16:00.837127
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    ## Create the query:
    queries = [
        (Currencies["USD"], Currencies["EUR"], date.today()),
        (Currencies["EUR"], Currencies["USD"], date.today()),
    ]

    ## Create the service:
    service = FXRateService()
    service.query = mock.Mock()

    ## Mock the queries:

# Generated at 2022-06-12 06:16:38.122877
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRateService, FXRate
    import datetime
    from decimal import Decimal

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            else:
                return None

    # Create a foreign exchange rate query service:
    service = MockFXRateService()

    # Test the currency query:

# Generated at 2022-06-12 06:16:49.753328
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class FakeService(FXRateService):
        """
        Provides a fake foreign exchange rate service for testing.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date(2018, 10, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2.0"))

# Generated at 2022-06-12 06:17:02.347092
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    #
    # Tests for FXRateService that raises an exception of not found:
    #

    class MockService1(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):

            # We will be returning a fixed query:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries, strict=False):

            # We will be returning a fixed query:
            return (self.query(query[0], query[1], query[2]) for query in queries)

    # Create the mock service:
    service1 = MockService1()

    # A query with a non-existing FX rate:
    query1 = (Currency("TRY"), Currency("USD"), Date(2019, 10, 1))

    # Make sure the query is not found

# Generated at 2022-06-12 06:17:03.950174
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    pass  # TODO


# Generated at 2022-06-12 06:17:11.428452
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase
    from unittest.mock import Mock

    from .commons.zeitgeist import Date

    from .currencies import Currency

    from .fx import FXRateLookupError, FXRateService

    class FXRateServiceExtended(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Date]], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    class FXRateServiceTest(TestCase):

        def setUp(self) -> None:  # noqa: N802
            self.ccy1 = Mock(spec=Currency)
            self.ccy2

# Generated at 2022-06-12 06:17:24.336051
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests if the function queries of the class FXRateService works as expected.
    """
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.temporal import DateTime
    from pypara.temporal import DateTimeFactory
    from .test import TestCase

    class StubFXRateService(FXRateService):
        @staticmethod
        def query(ccy1: Currency, ccy2: Currency, asof: DateTime, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["TRY"] and ccy2 == Currencies["EUR"]:
                return FXRate(Currencies["TRY"], Currencies["EUR"], asof, Decimal("1.2"))
            else:
                return None


# Generated at 2022-06-12 06:17:35.607080
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    from pypara.currencies.currency_codes import CurrencyCodes
    import datetime

    class MockRate(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            assert(ccy1 == Currency(CurrencyCodes.EUR))
            assert(ccy2 == Currency(CurrencyCodes.USD))
            assert(asof == datetime.date.today())
            assert(strict == True)
            return 0.5

    MockRate().query(Currency(CurrencyCodes.EUR), Currency(CurrencyCodes.USD), datetime.date.today(), strict=True)

test_FXRateService_query()



# Generated at 2022-06-12 06:17:47.519161
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .temporals import Date
    from .temporals.zeitgeist import now

    ## No default FX rate service:
    try:
        FXRateService.default.query(Currency.EUR, Currency.USD, now(), strict=True)
    except AttributeError as e:
        assert "has no attribute 'default'" in str(e)

    ## Null FX rate service:
    from .services.fxrates import NullFXRateService
    fxrate_service = NullFXRateService()
    assert fxrate_service.query(Currency.EUR, Currency.USD, now(), strict=True) is None

    ## Cached FX rate service:
    from .services.fxrates import CachedFXRateService
    fxrate_service = CachedFXRateService()
    assert fxrate_

# Generated at 2022-06-12 06:17:58.901142
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    import datetime

    # noinspection PyPep8Naming
    class _FXRateService(FXRateService):
        """
        Defines the :class:`FXRateService` mock class.
        """

        #: Defines the default foreign exchange rate service for the runtime.
        default: Optional["FXRateService"] = None  # noqa: E704


# Generated at 2022-06-12 06:18:09.940567
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """Unit test for method query of class FXRateService."""
    import pytest
    from decimal import Decimal
    from .currencies import Currency, CURRENCIES
    from .temporal import Temporal
    from .fx import FXRateService

    class MockFXRateService(FXRateService):
        """Provides a mock foreign exchange rate service."""

        def __init__(self, *rates) -> None:
            """Initializes the mock foreign exchange rate service."""
            self.rates = rates

        def query(self, *args, **kwargs) -> Optional[FXRate]:
            """Returns the foreign exchange rate of a given currency pair as of a given date."""
            ## Normalize the argument:
            args = self._normalize(*args)

            ## Loop all given rates:

# Generated at 2022-06-12 06:19:13.648556
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:19:22.435489
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.temporal import Temporal

    class MockFXRateService(FXRateService):
        """
        Defines a mock FX rate service.
        """

        def __init__(self):
            self._rates = dict()

        def add(self, fxrate: FXRate):
            """
            Adds an FX rate to the mock FX rate service.
            """
            self._rates[fxrate[:3]] = fxrate[3]


# Generated at 2022-06-12 06:19:34.600609
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # pragma: no cover
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate
    from pypara.fxrates.fxrateservice import FXRateService

    class MockFXService(FXRateService):
        """
        Provides a mock FX rate service.
        """


# Generated at 2022-06-12 06:19:45.874781
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class MockRateService(FXRateService):
        """
        Provides a mock FX rate service that returns predefined FX rates, provided in the constructor.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the mock FX rate service.
            """
            ## Keep the slots:
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            ## Return the first match:
            return

# Generated at 2022-06-12 06:19:55.816873
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    from pypara.fx.ecb import ECBFXRateService
    from pypara.fx.utils import safe_fxrate
    from .commons.zeitgeist import Date

    # Create a FX rate service:
    service = ECBFXRateService.from_file("data/exchange_rates_from_20190101_to_20191231.csv")

    # Query for a foreign exchange rate:
    assert safe_fxrate(service.query(Currency("GBP"), Currency("USD"), Date("2020-04-19"))) == Decimal("1.2347")

# Generated at 2022-06-12 06:20:03.852288
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main

    from decimal import Decimal

    from pypara.commons.numbers import ZERO
    from pypara.currencies import Currencies
    from pypara.service import FXRateService

    # noinspection PyAbstractClass
    class MockRateService(FXRateService):
        """
        Provides a mock implementation of the FX rate service.
        """

        def __init__(self) -> None:
            """
            Initializes the mock FX rate service.
            """
            super().__init__()


# Generated at 2022-06-12 06:20:04.882270
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:20:14.582809
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from io import StringIO
    from unittest.mock import patch
    from unittest import TestCase

    from .commons.zeitgeist import Date

    from .currencies import Currencies

    from .fxrates import FXRate, FXRateService, FXRateLookupError
