

# Generated at 2022-06-12 06:10:31.995092
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commodities.temporal import Temporal


# Generated at 2022-06-12 06:10:34.073759
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    ## ...
    pass

# Generated at 2022-06-12 06:10:41.714802
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Tempore
    from decimal import Decimal
    from .fx import FXService

    ## Test a successful lookup:
    fxrates = [
        FXRate("EUR", "USD", Tempore.of("2019-02-01"), Decimal("1.13925")),
        FXRate("EUR", "USD", Tempore.of("2019-02-04"), Decimal("1.1413")),
        FXRate("USD", "TRY", Tempore.of("2019-02-01"), Decimal("5.3663")),
        FXRate("USD", "TRY", Tempore.of("2019-02-04"), Decimal("5.3612")),
    ]
    service = FXService(Currencies.iso_codes(), fxrates)


# Generated at 2022-06-12 06:10:47.687041
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the :method:`FXRateService.query` method.
    """
    from unittest import TestCase, mock
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.temporal import Date

    ## An FX rate:
    fxrate = FXRateService.query(Currencies["EUR"], Currencies["USD"], Date.today())

# Generated at 2022-06-12 06:10:59.868182
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Create an FX rate service
    from .fxrateservices import DummyFXRateService
    fxs = DummyFXRateService()
    assert fxs is not None

    # Create a set of queries
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    queries = [
        (Currencies["EUR"], Currencies["USD"], date(2019, 5, 3)),
        (Currencies["EUR"], Currencies["USD"], date(2019, 5, 5)),
        (Currencies["USD"], Currencies["TRY"], date(2019, 5, 5)),
        (Currencies["GBP"], Currencies["JPY"], date(2019, 5, 5)),
    ]

    # Query the service
    rates = fxs.queries(queries)
    assert rates is not None

    #

# Generated at 2022-06-12 06:11:07.649925
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    ## Create a mock of the abstract base class:
    from unittest.mock import Mock
    queries = Mock(spec=FXRateService)
    queries.query.side_effect = lambda *args, **kwargs: args
    
    ## Test the queries method:
    from itertools import product
    assert (1, 2, 3) in queries.queries(product((1,), (2,), (3,)))
    assert not isinstance(queries.queries(product((1,), (2,), (3,))), type(iter([])))


# Generated at 2022-06-12 06:11:19.065539
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    import pypara.caliper.fx.stub as stub

    queries = [
        (Currencies["EUR"], Currencies["USD"], date(2020, 4, 3)),
        (Currencies["USD"], Currencies["EUR"], date(2020, 4, 3)),
        (Currencies["EUR"], Currencies["USD"], date(2020, 4, 4)),
        (Currencies["EUR"], Currencies["GBP"], date(2020, 4, 3)),
        (Currencies["GBP"], Currencies["USD"], date(2020, 4, 3)),
        (Currencies["EUR"], Currencies["EUR"], date(2020, 4, 3)),
    ]


# Generated at 2022-06-12 06:11:30.835996
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date

    queries = [
        (Currencies["EUR"], Currencies["USD"], Date(2019, 1, 1)),
        (Currencies["EUR"], Currencies["USD"], Date(2019, 1, 2)),
        (Currencies["EUR"], Currencies["USD"], Date(2019, 1, 3))
    ]


# Generated at 2022-06-12 06:11:41.888819
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`pypara.models.fx.FXRateService.queries`
    """

    import datetime
    
    from decimal import Decimal
    from pypara.currencies import Currencies
    
    from pypara.models.fx import FXRateService
    
    class MockedFXRateService(FXRateService):
        
        def __init__(self):
            pass
        
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date(2019, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1), Decimal("2.3"))

# Generated at 2022-06-12 06:11:52.147097
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService
    """
    import datetime as dt
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.finance import FXRate, FXRateService

    class FXRateServiceMock(FXRateService):
        """
        A mock implementation of :class:`FXRateService` to test method queries of class FXRateService.
        """

        #: Defines the foreign exchange rates of the FX rate service

# Generated at 2022-06-12 06:11:56.586053
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert False



# Generated at 2022-06-12 06:12:08.169853
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.rates import InMemoryFXRateService

    ## Arrange:
    i = InMemoryFXRateService()
    i.register(FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 1), Decimal("1.1")))
    i.register(FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 2, 1), Decimal("1.2")))
    i.register(FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 3, 1), Decimal("1.3")))

# Generated at 2022-06-12 06:12:18.557430
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    It should return foreign exchange rates for a given collection of currency pairs and dates.
    """
    # Prepare inputs:
    from zounds import Identity, FrequencyBand
    from pypara.currencies import Currencies
    from pypara.curves import ZCCurve, ZRCurve
    from pypara.enums import Temporal, CurveType
    from pypara.frequencies import Frequencies
    from pypara.rates import RateCurve
    from pypara.references import ReferenceRate
    from pypara.service import ServiceManager, ServiceProviders
    from pypara.temporals import Temporals
    from pypara.timeseries import TimeSeries
    import numpy as np
    import pandas as pd

    # Bootstrap the environment:

# Generated at 2022-06-12 06:12:29.099630
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ## Define an FX rate service derived class for this test:
    class Dummy(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            return {"EURUSD": Decimal("1.2345")}[f"{ccy1}{ccy2}"]

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Date]], strict = False):
            return (self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries)

    ## Create an FX rate service:
    service = Dummy()

    ## Test queries method:
    assert list(service.queries([("EUR", "USD", "2020-01-01")])) == [Decimal("1.2345")]



# Generated at 2022-06-12 06:12:41.364760
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class FXRateServiceMock(FXRateService):
        """
        Provides a mock implementation of :class:`FXRateService` to use in tests.
        """

        def __init__(self):
            super().__init__()
            self._rates = {}

        @property
        def rates(self):
            return self._rates

        def add(self, ccy1: Currency, ccy2: Currency, asof: Date, rate: Decimal):
            """
            Adds a rate.
            """
            self._rates.update({(ccy1, ccy2, asof): rate})


# Generated at 2022-06-12 06:12:53.745234
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import dt
    from decimal import Decimal
    from pypara.currencies import Currencies

    class Dummy(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (FXRate(1, 2, dt.date(2020, 6, 1), Decimal(0)),
                    FXRate(1, 2, dt.date(2020, 6, 1), Decimal(1)),
                    FXRate(1, 2, dt.date(2020, 6, 1), Decimal(2)))


# Generated at 2022-06-12 06:13:06.318195
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """

    # Imports
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from typing import Iterator

    # Stub FX rate service serving only USD/EUR
    class Stub(FXRateService):
        """
        Stub FX rate service serving only USD/EUR
        """
        def query(self, ccy1, ccy2, asof, strict):
            # Check if it is USD/EUR
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                # Return USD/EUR
                return FXRate(Currencies["USD"], Currencies["EUR"], asof, Decimal(2))

            # Otherwise


# Generated at 2022-06-12 06:13:18.607224
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves.interest import Rates
    from pypara.markets import FXRates
    from pypara.markets.fx import FXRateService

    ## Create a mock-up FX rate service:
    class MockUpFXRateService(FXRateService):
        """
        Provides a mock-up FX rate service.
        """

        #: Defines a mock-up FX rate query tuple.
        TQuery = Tuple[Currency, Currency, Date]


# Generated at 2022-06-12 06:13:32.323582
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def __init__(self):
            self._store = {
                (Currency("EUR"), Currency("USD"), datetime.date(2018, 1, 1)): Decimal("2"),
                (Currency("USD"), Currency("EUR"), datetime.date(2018, 1, 1)): Decimal("2"),
                (Currency("EUR"), Currency("USD"), datetime.date(2018, 1, 2)): Decimal("3"),
                (Currency("USD"), Currency("EUR"), datetime.date(2018, 1, 2)): Decimal("0.33")
            }


# Generated at 2022-06-12 06:13:40.366603
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Test for method query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = True) -> Optional[Decimal]
    # Test for method query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = True) -> Optional[Decimal]
    pass


# Generated at 2022-06-12 06:13:56.434821
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.finance.temporal import Date

    ## Setup:
    ##
    from pypara.finance.fx import FXRateService


# Generated at 2022-06-12 06:14:07.852224
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency, Currencies
    from .temporal import Timespan, TODAY
    from .index import Index, IndexService

    def FXRateQuery(ccy1, ccy2, date) -> FXRateService.TQuery:
        return (Currencies[ccy1], Currencies[ccy2], date)

    def FXRateQueryFrame(ccy1, ccy2, dates):
        return map(lambda date: FXRateQuery(ccy1, ccy2, date), dates)

    ###
    ### Simple Test
    ###
    class SimpleFXRateService(FXRateService):
        def __init__(self, rates):
            self.__rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return

# Generated at 2022-06-12 06:14:16.402479
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.datacenters.in_memory_fxrate_datacenter import InMemoryFXRateDatacenter
    from pypara.services.fxrate_service import FXRateService

    ## Setup the datacenter:
    fxrates = [
        # Source: https://www.oanda.com/currency/converter/
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 4, 4), Decimal("1.1248")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date(2019, 4, 4), Decimal("0.8906"))
    ]
    dat

# Generated at 2022-06-12 06:14:28.401630
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This method unit tests the queries method of the FXRateService class.
    """

    from pypara.currencies import Currency, Currencies
    from pypara.temporals import Temporal, Temporals

    class TestService(FXRateService):
        """
        Provides a test FXRateService implementation.
        """

        @staticmethod
        def _query(ccy1: Currency, ccy2: Currency, asof: Temporal):
            try:
                return Temporals.fxrate(ccy1, ccy2, asof)
            except FXRateLookupError:
                return None


# Generated at 2022-06-12 06:14:38.453028
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    import datetime
    from decimal import Decimal

    class _FakeFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            raise NotImplementedError

        @staticmethod
        def queries(queries, strict=False):
            rates = []
            for ccy1, ccy2, asof in queries:
                if ccy1 == ccy2:
                    rates.append(FXRate(ccy1, ccy2, asof, ONE))
                else:
                    rates.append(FXRate(ccy1, ccy2, asof, Decimal("2")))
            return rates

    fx_rate_service = _FakeFXRateService()

# Generated at 2022-06-12 06:14:50.364211
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    # Define a sample currency pair:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    # Define a sample rate:
    rate = Decimal("2")

    # Define a sample date:
    date = datetime.date.today()

    # Define the test class:
    class TestService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 != ccy1 or ccy2 != ccy2 or asof != date:
                return None

# Generated at 2022-06-12 06:14:59.554917
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Temporals
    fx = FXRateService()
    assert list(fx.queries(None)) == []
    assert list(fx.queries([])) == []
    assert list(fx.queries([(Currencies["EUR"], Currencies["USD"], Temporals.today(),)])) == [(None,)]
    assert list(fx.queries([(Currencies["EUR"], Currencies["USD"], Temporals.today(),),
                            (Currencies["EUR"], Currencies["USD"], Temporals.today(),)])) == [(None, None)]

# Generated at 2022-06-12 06:15:08.435859
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """

    from .currencies import Currency
    from .currencies import Currencies
    from .temporal import Temporal

    # Create the FX rate service routine:

# Generated at 2022-06-12 06:15:17.074156
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService

    ## Derive a class from FXRateService:
    class MyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, ONE)

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for (ccy1, ccy2, asof) in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    ## Construct the FX rate service:

# Generated at 2022-06-12 06:15:27.600691
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Given an FX rate service
    class FXRateService1(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False):
            return iter([None, None])

    # When we call methods
    fxRateService1 = FXRateService1()
    queries1 = fxRateService1.queries(((None, None, None), (None, None, None)))
    query1 = fxRateService1.query(None, None, None)

    # Then we should get the expected results
    assert list(queries1) == [None, None]
    assert query1 is None

# Generated at 2022-06-12 06:15:50.535053
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Imports
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService, FXRate, FXRateLookupError

    # Mock FXRateService
    class MockFXRateService(FXRateService):
        def __init__(self):
            self.rates = dict()
            self.rates[(Currencies["EUR"], Currencies["USD"], datetime.date.today())] = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1.18"))
            self.rates[(Currencies["USD"], Currencies["EUR"], datetime.date.today())] = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.85"))
            self

# Generated at 2022-06-12 06:15:54.713247
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests FXRateService.queries method.
    """
    # import mock
    # TODO:
    pass

# Generated at 2022-06-12 06:16:03.462629
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    #
    class Mock(FXRateService):
        def __init__(self):
            self.__data = {
                (Currencies["EUR"], Currencies["USD"], datetime.date(2018, 1, 1)): Decimal("1.2345"),
                (Currencies["USD"], Currencies["EUR"], datetime.date(2018, 1, 1)): Decimal("0.8081"),
            }
        def query(self, ccy1, ccy2, asof, strict=False):
            fxrate = self.__data.get((ccy1, ccy2, asof), None)
            if not fxrate and strict:
                raise FXRate

# Generated at 2022-06-12 06:16:15.385668
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    ## Import the local module:
    from pypara.fx import FXRateService

    ## Define a mock service:
    class MockService(FXRateService):
        def __init__(self, rates: dict = None) -> None:
            if rates is None:
                rates = dict()
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2, asof) not in self.rates:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                return None
            return self.rates[(ccy1, ccy2, asof)]



# Generated at 2022-06-12 06:16:26.161953
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: E999
    """
    A unit test for method queries of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from functools import partial
    from unittest import TestCase
    from unittest import mock

    from pypara.currencies import Currency, Currencies
    from pypara.temporals import Date

    class TestFXRateService(FXRateService):
        """
        A dummy FX rate service for testing.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-12 06:16:38.121296
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest

    from decimal import Decimal

    from pypara.currencies import Currencies
    from pypara.dates import Date

    class FXRateServiceStub(FXRateService):
        """
        Defines a stub for foreign exchange rate service.
        """

        def __init__(self):
            """
            Initializes the foreign exchange rate service stub.
            """
            self.rates = [
                FXRate.of(Currencies["EUR"], Currencies["USD"], Date("2018-01-01"), Decimal("2")),
                FXRate.of(Currencies["EUR"], Currencies["USD"], Date("2019-01-01"), Decimal("3")),
                FXRate.of(Currencies["USD"], Currencies["EUR"], Date("2018-01-01"), Decimal("0.5"))
            ]



# Generated at 2022-06-12 06:16:49.753993
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.time import Date
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    class FxService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

    fx_service = FxService()
    rate = fx_service.query(Currencies["EUR"], Currencies["USD"], Date.today())
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.date == Date.today()
    assert rate.value == Decimal("1")


# Generated at 2022-06-12 06:17:02.347573
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService
    class TestService(FXRateService):
        def __init__(self):
            self.__rates = {
                (Currencies["EUR"], Currencies["USD"], datetime.date.today()): Decimal("2"),
                (Currencies["USD"], Currencies["EUR"], datetime.date.today()): Decimal("0.5"),
                (Currencies["JPY"], Currencies["USD"], datetime.date.today()): Decimal("0.009")
            }

# Generated at 2022-06-12 06:17:10.469756
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.time import Date

    # Define dummy FXRateService queries:
    def _dummy_queries(queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
        rates = []  # rates
        for ccy1, ccy2, asof in queries:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                rates.append(FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2")))

# Generated at 2022-06-12 06:17:23.343210
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from copy import deepcopy
    from decimal import Decimal as D
    from datetime import date as DATE
    from pypara.currencies import Currencies
    from pypara.curves import Curve, CurveLookupError, LinearCurve
    EUR = Currencies['EUR']
    USD = Currencies['USD']
    RATES = [
        FXRate(EUR, USD, DATE(2020, 1, 1), D("0.5")),
        FXRate(EUR, USD, DATE(2020, 4, 1), D("0.3"))
    ]

# Generated at 2022-06-12 06:17:59.704761
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx_rates import FXRateService, FXRateLookupError
    from pypara.zeitgeist import Date

    class _MockFXRateService(FXRateService):
        """
        Provides a mock FX rate service for testing.
        """
        _RATES = {
            (Currencies["EUR"], Currencies["USD"], Date(datetime.date.today())): Decimal("2"),
            (Currencies["USD"], Currencies["EUR"], Date(datetime.date.today())): Decimal("0.5"),
            (Currencies["USD"], Currencies["TRY"], Date(datetime.date.today())): Decimal("8")
        }


# Generated at 2022-06-12 06:18:10.453786
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2, asof) == (Currencies["EUR"], Currencies["USD"], datetime.date.today()):
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            return None

    rate = TestFXRateService().query(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-12 06:18:23.147400
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .datetime import Date
    from .fx import FXRate

    # Define an FX rate data-frame

# Generated at 2022-06-12 06:18:34.751818
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test queries method.
    """
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporals import Temporals
    from pypara.unittests.fxrates_services import MockFXRateService

    # Arrange:
    date = Temporals.now
    queries = [
        (Currencies["EUR"], Currencies["USD"], date),
        (Currencies["EUR"], Currencies["JPY"], date)
    ]

    expected = [
        FXRate(Currencies["EUR"], Currencies["USD"], date, Decimal("2")),
        FXRate(Currencies["EUR"], Currencies["JPY"], date, Decimal("200"))
    ]

    # Act:
    service = Mock

# Generated at 2022-06-12 06:18:43.808398
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.currencies.currency import CurrencyRateSource
    from pypara.currencies.service import CurrencyService

    assert CurrencyService.default.query(Currencies["EUR"], Date.today(), CurrencyRateSource.ForeignExchange) is not None, "Expected EUR FX rate to be available."
    assert CurrencyService.default.query(Currencies["EUR"], Date.today(), CurrencyRateSource.ForeignExchange) == CurrencyService.default.query(Currencies["EUR"], Date.today(), CurrencyRateSource.ForeignExchange), "Expected EUR FX rate to be deterministic."



# Generated at 2022-06-12 06:18:44.447184
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

# Generated at 2022-06-12 06:18:54.371296
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from decimal import Decimal
    from typing import List
    from pypara.currencies import Currencies
    from pypara.temporals import Date
    from pypara.fxrates import FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        def __init__(self, rates: List[FXRate]):
            self.rates = rates


# Generated at 2022-06-12 06:19:05.222537
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService
    """
    ## Create fx rate service:
    from collections import namedtuple
    from pypara.currencies import Currencies
    from pypara.dates import Temporals
    from pypara.fx import FXRate
    FXRateQuery = namedtuple("FXRateQuery", ["ccy1", "ccy2", "date", "rate"])

# Generated at 2022-06-12 06:19:16.488501
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.fx_rate_services import FXRateService, InMemoryFXRateService
    from pypara.zeitgeist import Date

    ## Create a test FX rate service:

# Generated at 2022-06-12 06:19:27.336086
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from .currencies import Currency
    from .dates import Date
    from .markets.exchange import TestFXRateService
    from .markets.exchange import FXRateLookupError
    from .temporals import Temporal
    import unittest as ut

    ## Test fixtures: