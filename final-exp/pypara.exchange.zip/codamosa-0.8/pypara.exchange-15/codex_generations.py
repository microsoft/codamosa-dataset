

# Generated at 2022-06-12 06:10:31.569501
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    """
    Tests the invert method of the FXRate class.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRate

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)


# Generated at 2022-06-12 06:10:40.105605
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # import pytest
    # from pypara.currencies import Currencies, Currency
    #
    # class DummyFXRateService(FXRateService):
    #
    #     def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[Decimal]:
    #         return None
    #
    #     def __iter__(self) -> Iterable[Optional[Decimal]]:
    #         return iter([None, None])
    #
    # s = DummyFXRateService()
    #
    # with pytest.raises(LookupError):
    #     next(s.queries([(Currencies["EUR"], Currencies["USD"], None)], strict=True))
    pass

# Generated at 2022-06-12 06:10:43.986071
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    from .currencies import Currency
    from .market import Date
    from .market import FXRateLookupError
    assert isinstance(FXRateLookupError(Currency('A'), Currency('B'), Date(2016, 9, 1)), FXRateLookupError)

# Generated at 2022-06-12 06:10:54.508942
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.dates import Temporals
    from pypara.fxrates import FXRate, FXRateService
    service = FXRateService()
    rate = service.query(Currencies["EUR"], Currencies["USD"], Temporals.today)
    assert rate is None
    rate = service.query(Currencies["EUR"], Currencies["USD"], Temporals.today, strict=True)
    assert rate is None
    rate = service.query(Currencies["EUR"], Currencies["USD"], Temporals.today, strict=False)
    assert rate is None
    rate = service.query(Currencies["EUR"], Currencies["USD"], Temporals.today, strict=True)
    assert rate

# Generated at 2022-06-12 06:10:58.308569
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    import datetime
    from pypara.currencies import Currencies
    with pytest.raises(FXRateLookupError):
        raise FXRateLookupError(Currencies["USD"], Currencies["GBP"], datetime.date.today())


# Generated at 2022-06-12 06:11:08.075116
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():

    from .currencies import Ccy
    from .temporal import Temporal

    # Reverse EUR/USD, USD/EUR:
    assert (~FXRate(Ccy("EUR"), Ccy("USD"), Temporal.now(), Decimal("1.1"))) == FXRate(Ccy("USD"), Ccy("EUR"), Temporal.now(), Decimal("0.9"))  # noqa: E501

    # Reverse JPY/EUR, EUR/JPY:
    assert (~FXRate(Ccy("JPY"), Ccy("EUR"), Temporal.now(), Decimal("1.1"))) == FXRate(Ccy("EUR"), Ccy("JPY"), Temporal.now(), Decimal("0.9"))  # noqa: E501

    # Reverse USD/JPY, JPY/USD:

# Generated at 2022-06-12 06:11:12.078535
# Unit test for constructor of class FXRateLookupError
def test_FXRateLookupError():
    """
    Tests the constructor of class FXRateLookupError.
    """
    from .currencies import Currencies
    from datetime import date
    from decimal import Decimal
    from pypara.currencies.exceptions import CurrencyLookupError
    from pypara.currencies.services import CurrencyService
    from pypara.fxrates.exceptions import FXRateLookupError
    from pypara.fxrates.services import FXRateService
    from pypara.temporal.services import TemporalService

    ## Set temporal service:
    TemporalService.default = TemporalService.Standard()

    ## Set currency service:
    CurrencyService.default = CurrencyService.Standard(Currencies)

    ## Set FX rate service:

# Generated at 2022-06-12 06:11:22.356741
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # pylint: disable=missing-docstring,invalid-name,no-self-use
    class QueryableRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self,
                    queries: Iterable[Tuple[Currency, Currency, Date]],
                    strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (FXRate.of(Currencies[ccy1], Currencies[ccy2], asof, Decimal("1.5")) for (ccy1, ccy2, asof) in queries)

    queries = (("TRY", "USD", Date(None, None, None)), ("USD", "TRY", Date(None, None, None)))

# Generated at 2022-06-12 06:11:30.413442
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    queries: Iterable[FXRateService.TQuery]
    results: Iterable[Optional[FXRate]]

    # Test the behaviour of the FXRateService.queries method
    # when the underlying service returns a set of FXRate instances:

    # Set up:
    class MockService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False) -> Optional[FXRate]:
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            return None

        def queries(self, queries, strict=False) -> Iterable[Optional[FXRate]]:
            for (ccy1, ccy2, asof) in queries:
                yield self.query(ccy1, ccy2, asof)

    import datetime
   

# Generated at 2022-06-12 06:11:41.622894
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Temporal
    from pypara.fxrates.stub import StubFXRateService
    from pypara.fxrates.services import FXRateService

    fxrateservice: FXRateService = StubFXRateService.get_instance()

    ## Test the queries method:

# Generated at 2022-06-12 06:11:58.516557
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import now
    from .fxrates import FXRateServiceStub

    queries = [
        (Currencies["EUR"], Currencies["USD"], now().date),
        (Currencies["USD"], Currencies["EUR"], now().date),
        (Currencies["EUR"], Currencies["USD"], now().add_years(1).date),
        (Currencies["USD"], Currencies["EUR"], now().add_years(1).date),
    ]

    rates = FXRateServiceStub.queries(queries)
    assert len(list(rates)) == 4

    del rates
    rates = FXRateServiceStub.queries(queries, True)
    assert len(list(rates)) == 4



# Generated at 2022-06-12 06:12:09.470416
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test method queries of class FXRateService.
    """
    ##  FXRateService is an abstract class. Implement a dummy service and test this method:
    class DummyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, ONE)

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for q in queries:
                yield self.query(*q)

    ## Create a dummy service and some queries:
    service = DummyService()

# Generated at 2022-06-12 06:12:19.313537
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class :class:`FXRateService`.
    """
    from .currencies import Currency
    from .datetime import Date
    from .fx.services import DummyFXRateService
    from .numbers import ONE
    from .types import assert_isinstance, assert_valueerror
    from .zeitgeist import Date
    from .currencies import Currencies
    from .datetime import Date

    ## Define a dummy service:
    service = DummyFXRateService()

    ## Check the query:
    assert_isinstance(service.query(Currencies["USD"], Currencies["EUR"], Date(2020, 6, 14)), FXRate)

    ## Check the query with a non-existing rate:

# Generated at 2022-06-12 06:12:20.300432
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:12:28.048835
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    import datetime
    from decimal import Decimal
    from .fxrateservices.simple import SimpleFXRateService

    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Date.of(datetime.date.today())

    service = SimpleFXRateService()

    rate = service.query(ccy1, ccy2, asof)
    assert rate.ccy1 == ccy1
    assert rate.ccy2 == ccy2
    assert rate.value == Decimal("1.12")


# Generated at 2022-06-12 06:12:29.459915
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit tests for class FXRateService's method query.
    """
    pass

# Generated at 2022-06-12 06:12:41.771696
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.exchanges.impl.services import LocalFXRateService

    ## Define data to be used by the test:

# Generated at 2022-06-12 06:12:46.020851
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    import unittest

    # TODO: Implement test_FXRateService_query
    raise unittest.SkipTest("TODO: Implement test_FXRateService_query")


# Generated at 2022-06-12 06:12:58.863472
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .dates import Date
    from .fx import FXRate, FXRateLookupError
    from .fx.rateservice import MemoryFXRateService, FXRateService

    ## Create a service:
    service = MemoryFXRateService()
    assert isinstance(service, FXRateService)

    ## Create a query:
    query = (Currency.EUR, Currency.USD, Date.TODAY)

    ## Create a FX rate:
    rate = FXRate(Currency.EUR, Currency.USD, Date.TODAY, Decimal("1.1"))

    ## Add the FX rate to the service:
    service.add(rate)

    ## Check the queries:
    results = service.queries([query], strict=True)
    for result in results:
        assert result == rate
    results = service

# Generated at 2022-06-12 06:13:10.479614
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test FXRateService queries method for fx rate
    """
    # test_FXRateService_queries
    from datetime import date
    from pypara.currencies import Currency
    from pypara.market import FXRateService
    from .environments import MockFXRateService
    from decimal import Decimal
    # get fx rate instance
    fxrateservice = MockFXRateService()
    # get foreign exchange rates
    queries = [(Currency("USD"), Currency("EUR"), date(2020, 1, 1)),
               (Currency("USD"), Currency("EUR"), date(2019, 1, 1)),
               (Currency("EUR"), Currency("USD"), date(2020, 1, 1))]
    rates = fxrateservice.queries(queries)    
    #print("test_FXRateService_qu

# Generated at 2022-06-12 06:13:23.223300
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # ------------------------------------------------------------------------------------------------------------------
    # Imports
    # ------------------------------------------------------------------------------------------------------------------
    import datetime
    import math
    import random
    import pytest
    from pypara.currencies import Currency, Currencies
    from pypara.exchange import FXRateService, FXRateLookupError

    # ------------------------------------------------------------------------------------------------------------------
    # FXRateServiceTest Class
    # ------------------------------------------------------------------------------------------------------------------
    class FXRateServiceTest(FXRateService):
        """
        Provides an FX rate service for testing purposes.
        """

        #: Defines the map of currency pairs to as-of dates to FX rates.
        _fx_rates = {}  # type: Dict[TQuery, FXRate]


# Generated at 2022-06-12 06:13:34.396801
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries`.
    """
    from random import choice
    from datetime import date
    from pypara.currencies import Currency, Currencies

    ccy1 = Currencies["USD"]
    ccy2 = Currencies["GBP"]
    asof = date.today()
    fx = FXRate(ccy1, ccy2, asof, Decimal("1.4"))
    queries = [
        (ccy1, ccy2, asof),
        (ccy2, ccy1, asof),
        (Currencies["EUR"], Currencies["USD"], asof),
        (Currencies["JPY"], Currencies["EUR"], asof),
        (Currencies["EUR"], Currencies["JPY"], asof),
    ]


# Generated at 2022-06-12 06:13:35.854627
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Run tests
    assert True == True

# Generated at 2022-06-12 06:13:37.491250
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for the method queries of the class FXRateService.
    """
    raise NotImplementedError

# Generated at 2022-06-12 06:13:47.434998
# Unit test for method queries of class FXRateService

# Generated at 2022-06-12 06:13:57.776800
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import unittest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance import FXRateService
    from pypara.finance import FXRateLookupError

    class FXRateServiceImpl(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))
            else:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                else:
                    return None


# Generated at 2022-06-12 06:14:08.490610
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # Import required local modules:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.foreign_exchange import FXRateService

    # Define the FX rate:
    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    # Define an abstract service:
    class FXService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == rate[0] and ccy2 == rate[1]:
                return rate
            return None

    # Query for EUR/USD:

# Generated at 2022-06-12 06:14:19.844421
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.datetime import Date
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateLookupError

    class FXRateServiceTest(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2 and asof == Date(2019, 5, 4):
                return FXRate(ccy1, ccy2, asof, 1)
            else:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                else:
                    return None


# Generated at 2022-06-12 06:14:20.887695
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:14:29.421962
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.exchangerates.services import ExchangeRatesFileService
    svc = ExchangeRatesFileService.from_file_name("tests/data/exchangerates.csv")
    rate = svc.query(Currencies["EUR"], Currencies["USD"], Date.today())
    assert rate is not None and rate.ccy1 == Currencies["EUR"] and rate.ccy2 == Currencies["USD"]
    assert rate.date == Date.today() and rate.value == Decimal("1.1234")
    return rate


# Generated at 2022-06-12 06:14:53.244996
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """

    from pypara.currencies import Currencies
    from pypara.time import Time

    from .commons.zeitgeist import now

    fxrateservice = FXRateService()

    ## Collection queries must return an iterator:
    assert isinstance(fxrateservice.queries([(Currencies["USD"], Currencies["EUR"], now())]), Iterable)

    ## We can safely pass an empty collection:
    assert not [fxrate for fxrate in fxrateservice.queries([])]

    ## Querying for invalid rates must raise an exception:
    iterator = fxrateservice.queries([(Currencies["USD"], Currencies["EUR"], now())])

# Generated at 2022-06-12 06:14:58.115172
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    assert FXRateService.query("foo", "bar", Date("2011-11-11"), False) == None
    assert FXRateService.query("foo", "bar", Date("2011-11-11"), True) == None


# Generated at 2022-06-12 06:15:08.772443
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.curves import FXRate
    from pypara.temporals import Temporals
    class MyFXRateService(FXRateService):
        @property
        def queries_by_name(self) -> dict:
            return {
                "EUR/USD": FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1.3"))
            }
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError("Method `query` not implemented!")

# Generated at 2022-06-12 06:15:15.324613
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .services import FXRates
    from .currencies import Currency, Currencies
    from .temporal import Date

    r = FXRates(Date.of("2017-04-10"))
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date.of("2018-01-01")
    rate = r.query(ccy1, ccy2, asof)
    assert rate == FXRate(ccy1, ccy2, asof, Decimal("1.2066"))

# Generated at 2022-06-12 06:15:25.613599
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## Setup the FX rate service:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fxt import FXRateService
    from pypara.markets.fxt import FXRateLookupError

    class MyFXRateService(FXRateService):
        """
        Provides an implementation of the foreign exchange rate service for unit testing.
        """


# Generated at 2022-06-12 06:15:36.434454
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method :method:`FXRateService.query` of :class:`FXRateService`.
    """
    from .currencies import Currency
    from .fxtransactions import convert_amount
    from .temporals import dt_from_str
    from pypara.services.fxrates import FXRateServiceImpl
    from pypara.services.fxrates.ccys import CcyRepositoryImpl
    from pypara.services.fxrates.rates import FXRateRepositoryImpl
    from pypara.services.fxrates.temporal import TemporalRepositoryImpl
    from pypara.utils import get_resource_path

    ## Create the FX rate service instance:

# Generated at 2022-06-12 06:15:41.923578
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test queries function of FXRateService
    """
    from .currencies import Currency, Currencies
    from .temporal import Temporal, Date, Period
    from decimal import Decimal
    from pypara.pmm import Market
    from pypara.fxrates import FXRateService, FXRateLookupError
    import datetime
    # create a Market and an FXRateService
    market = Market("TEST")
    fxrate_service = FXRateService()

    # specify rate values to be returned by fxrate_service
    rate_values = [Decimal("2"), Decimal("0.5"), Decimal("1"), None]

    # Implementation of lookup function (inside of fxrate_service)

# Generated at 2022-06-12 06:15:51.395156
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class BaseRateService(FXRateService):
        class Rates:
            CHF = FXRate(Currency("CHF"), Currency("CHF"), Date("2020-01-01"), Decimal("1"))
            CHF_USD = FXRate(Currency("CHF"), Currency("USD"), Date("2020-01-01"), Decimal("1"))
            EUR_EUR = FXRate(Currency("EUR"), Currency("EUR"), Date("2020-01-01"), Decimal("1"))
            EUR_USD = FXRate(Currency("EUR"), Currency("USD"), Date("2020-01-01"), Decimal("1.1"))
            EUR_USD_2020_02_01 = FXRate(Currency("EUR"), Currency("USD"), Date("2020-02-01"), Decimal("1.2"))

# Generated at 2022-06-12 06:16:03.588487
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """ """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateLookupError, FXRateService

    ## Define queries:
    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.datetime.today()),
        (Currencies["TRY"], Currencies["USD"], datetime.datetime.today()),
        (Currencies["TRY"], Currencies["EUR"], datetime.datetime.today()),
    ]

    ## Create the FX rate service:
    class FxRateServiceImpl(FXRateService):
        """ """

# Generated at 2022-06-12 06:16:15.417561
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import (
        Currency,
        )
    from pypara.fx import (
        FXRate,
        FXRateService,
        )

    ## Define the mock service:
    class _MockService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(2))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            asof = datetime.date.today()

# Generated at 2022-06-12 06:16:50.706348
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # pylint: disable=C0103
    # pylint: disable=W0613
    # pylint: disable=C0111
    # pylint: disable=R0201
    import unittest

    class TestFXRateService(FXRateService, unittest.TestCase):
        def query(self, ccy1, ccy2, asof, strict=False):
            return super().query(ccy1, ccy2, asof, strict)

    return unittest.TestCase.run(TestFXRateService, sys.argv[1:])



# Generated at 2022-06-12 06:17:02.514250
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests queries method of the :class:`FXRateService`  class.
    """
    # noinspection PyUnresolvedReferences
    from datetime import date
    from decimal import Decimal
    from time import time
    from .currencies import Currencies

    class DummyFXRateService(FXRateService):
        """
        Dummy service that only returns single FX rate.
        """

        def query(self, ccy1, ccy2, asof, strict):
            pass

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("2"))

    # Create a dummy FX rate service:
    service = DummyFXRateService()

    # Create a list of queries:
   

# Generated at 2022-06-12 06:17:10.586626
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime as dt
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == dt.date(2018, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("1.25"))
            else:
                return None

        def queries(self, queries, strict=False):
            for qccy1, qccy2, qasof in queries:
                yield self.query(qccy1, qccy2, qasof)

    rate_service = TestRateService()
    assert rate

# Generated at 2022-06-12 06:17:23.519705
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    from pypara.fx.curve import FXCurve
    from pypara.fx.curve.linear import LinearFXCurve
    from pypara.testing import assert_raises

    ## Construct the FX rate curve:
    usd = Currency.get("USD")
    eur = Currency.get("EUR")
    jpy = Currency.get("JPY")

    usdeur = FXRate(usd, eur, 0, 1.25)
    eurusd = FXRate(eur, usd, 0, 0.80)
    jpyeur = FXRate(jpy, eur, 0, 0.01)
    eurjpy = FXRate(eur, jpy, 0, 100.00)


# Generated at 2022-06-12 06:17:35.759492
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency("USD"):
                return FXRate(Currencies["USD"], Currencies["EUR"], date, Decimal("0.8"))
            else:
                return FXRate(Currencies["EUR"], Currencies["USD"], date, Decimal("1.2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
            
    tdate = datetime.date.today()
    tservice = TestFXRateService()
    rate

# Generated at 2022-06-12 06:17:46.299327
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, datetime.date.today(), Decimal("2"))

    mxs = MockFXRateService()
    result = mxs.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), False)
    assert result == FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))


# Generated at 2022-06-12 06:17:54.208586
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies

    ## Define a fake FX rate service:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            assert isinstance(ccy1, Currency)
            assert isinstance(ccy2, Currency)
            assert isinstance(asof, Date)
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, ONE)
            ccy1_added = ccy2 if ccy1 == Currencies["EUR"] else ccy1
            ccy2_added = ccy1 if ccy1 == Currencies["EUR"] else ccy2
            return FXRate(ccy1_added, ccy2_added, asof, ONE)

       

# Generated at 2022-06-12 06:18:02.516267
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.rates.inmemory import InMemoryFXRateService

    # Create a service
    service = InMemoryFXRateService()
    service.register(Currencies["USD"], Currencies["EUR"], datetime.date(2020, 1, 1), Decimal("1.1"))
    service.register(Currencies["EUR"], Currencies["USD"], datetime.date(2020, 1, 1), Decimal("1"))
    service.register(Currencies["USD"], Currencies["EUR"], datetime.date(2020, 1, 2), Decimal("1.2"))
    service.register(Currencies["EUR"], Currencies["USD"], datetime.date(2020, 1, 2), Decimal("0.8"))

    # Queries

# Generated at 2022-06-12 06:18:10.565282
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date, Period

    # Arrange
    queries = [
        (Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1)),
        (Currencies["USD"], Currencies["EUR"], Date(2018, 1, 2)),
        (Currencies["EUR"], Currencies["USD"], Date(2018, 1, 3)),
        (Currencies["USD"], Currencies["EUR"], Date(2018, 1, 4)),
    ]

    # Act
    # results = FXRateService.queries(queries)

    # Assert

# Generated at 2022-06-12 06:18:18.530533
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from datetime import date

    class FXRateServiceMock(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return None

    # Case 1: Empty service returns None
    service = FXRateServiceMock()
    assert service.query(Currencies["EUR"], Currencies["USD"], date.today()) is None



# Generated at 2022-06-12 06:19:32.341574
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the implementation of queries method of class FXRateService.
    """
    pass

# Generated at 2022-06-12 06:19:42.317410
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import tempfile
    import datetime
    import os
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commons.numbers import ZERO
    from pypara.fxrates.service import CsvFXRateService, FXRateService
    with tempfile.NamedTemporaryFile(delete=False) as fxrates_file:
        fxrates_file.write(b"""date,ccy1,ccy2,value\n""")
        fxrates_file.write(b"""2017-01-01,EUR,USD,1.5\n""")
        fxrates_file.write(b"""2017-01-02,EUR,USD,1.6\n""")

# Generated at 2022-06-12 06:19:49.253575
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.common.commons.temporals import DateTime
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]):
            self.__rates = rates

        def query(self, ccy1, ccy2, asof, strict=False):
            for rate in self.__rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return rate
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)

        def queries(self, queries, strict=False):
            return [self.query(*query, strict) for query in queries]

    assert FXRateService.default is None



# Generated at 2022-06-12 06:19:59.209005
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """Unit test for method queries of class FXRateService."""

    #: Defines a simple FX rate service.
    class DummyFXRateService(FXRateService):
        """
        Provides a dummy FX rate service.
        """


# Generated at 2022-06-12 06:20:06.696320
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.currencies.cache import CachingCurrencyService
    from pypara.currencies.rates import FXRateServiceBase

    ## Set-up the currency service:
    ccyService = CachingCurrencyService([])
    ccyService.register(Currencies["EUR"])
    ccyService.register(Currencies["USD"])

    ## Set-up the FX rate service:
    fxService = FXRateServiceBase(ccyService)
    fxService.register(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("0.8"))
    fxService.register(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 2), Decimal("0.9"))

    ## Test the result:
   

# Generated at 2022-06-12 06:20:16.889044
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.market.fxrates import FXRate, FXRateService
    from pypara.market.timeseries import TimeSeries
    from pypara.temporal import Temporal
    
    class _TestRateService(FXRateService):
        def __init__(self):
            self.rates = TimeSeries()
            self.rates.append(FXRate.of(Currencies["USD"], Currencies["EUR"], date(2020, 1, 1), Decimal("2")))
            self.rates.append(FXRate.of(Currencies["USD"], Currencies["TRY"], date(2020, 1, 1), Decimal("2")))

# Generated at 2022-06-12 06:20:26.282201
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest.mock import MagicMock

    # Define a mock FX rate service:
    fxrate_service = FXRateService()

    # Define a mock query:
    ccy1 = MagicMock(spec=Currency)
    ccy2 = MagicMock(spec=Currency)
    asof = MagicMock(spec=Date)
    fx_rate = MagicMock(spec=FXRate)

    # Define the mock query:
    def mock_query(self, ccy1, ccy2, asof, strict):
        return fx_rate

    # And set the mock:
    fxrate_service.query = MagicMock(side_effect=mock_query)

    # Then call the method: