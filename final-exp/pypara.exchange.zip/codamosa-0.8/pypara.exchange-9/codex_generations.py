

# Generated at 2022-06-12 06:10:31.027046
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Perform unit testing for the method queries of class FXRateService.
    """
    ## Import required modules:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.exchange import FXRate, FXRateService

    ## Define a mock foreign exchange rate service:
    class MockFXRateService(FXRateService):
        """
        Provides a mock foreign exchange rate service.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == (Currencies["EUR"]) and ccy2 == (Currencies["USD"]) and asof == (datetime.date.today()):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            else:
                return None

# Generated at 2022-06-12 06:10:40.015905
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies  # noqa: E402
    from .temporal import Dates  # noqa: E402
    from decimal import Decimal  # noqa: E402

    class TestingFXRateService(FXRateService):  # noqa: E301
        def query(self, ccy1, ccy2, asof, strict):
            if ccy1.name == 'EUR' and ccy2.name == 'USD' and asof == Dates.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

        def queries(self, queries, strict):
            return (self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries)


# Generated at 2022-06-12 06:10:46.873424
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(~nrate == rrate)
    assert(~nrate != nrate)


# Generated at 2022-06-12 06:10:56.994318
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D102

    from .commons.types import Temporal
    from .currencies import Currencies
    from .test_utils import TestFXRateService

    ## Prepare the test set:
    queries = [
        (Currencies["EUR"], Currencies["USD"], Temporal.today()),
        (Currencies["JPY"], Currencies["USD"], Temporal.today()),
        (Currencies["EUR"], Currencies["USD"], Temporal.tomorrow()),
    ]

    ## Prepare the mock service:

# Generated at 2022-06-12 06:11:06.958283
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporals import Temporals

    class FXRateServiceTest(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[Decimal]:
            return None

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Date]], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("1.5"))

    ## Create the FX rate service:
    fxrate_service = FXRateServiceTest()

    ## Create the FX rate queries:

# Generated at 2022-06-12 06:11:18.974925
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from io import StringIO
    from typing import List
    import unittest
    from unittest.mock import Mock

    from .commons.zeitgeist import Date
    from .currencies import Currency
    from .fxrates import FXRate, FXRateService

    class _MyFXRateService(FXRateService):
        def __init__(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> None:
            self.queries = queries
            self.strict = strict

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for q in self.queries:
                if q[0] == ccy1 and q[1] == ccy2 and q[2] == asof:
                    return

# Generated at 2022-06-12 06:11:27.304805
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currency
    from . import MockFXRateService
    from .fx.services import FXRateService

    ## Create a foreign exchange rate service with mock sources:
    current = MockFXRateService()
    sources = [current]

    ## Create a non-strict foreign exchange rate service with just one source:
    service = FXRateService(sources, strict=False)

    ## Query a currency cross:
    rate = service.query(currency1=Currency("EUR"), currency2=Currency("USD"), asof=Date.today())
    assert rate == FXRate(Currency("EUR"), Currency("USD"), Date.today(), Decimal("1.25"))

    ## Lookup an FX rate with multiple queries:

# Generated at 2022-06-12 06:11:33.867923
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate


# Generated at 2022-06-12 06:11:39.784255
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert ~nrate == rrate



# Generated at 2022-06-12 06:11:46.851576
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-12 06:11:53.111078
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-12 06:12:02.734105
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests `queries` method of class `FXRateService`.
    """
    # TODO: This is a proof of concept. Must be implemented properly.
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MyFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, ONE) if (ccy1, ccy2, asof) in self.queries(
                [(ccy1, ccy2, asof)], strict=strict) else None  # noqa: E741


# Generated at 2022-06-12 06:12:11.557673
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This is a unit test for the method queries of the class FXRateService.
    """
    from .currencies import Currencies
    from .datetime import Date
    from .numbers import Decimal
    from .temporal import Temporal

    # Foreign exchange rates for EUR/USD and EUR/GBP.
    fx_rates = {
        (Currencies["EUR"], Currencies["USD"], Date("2017-01-01")): Decimal("1.05"),
        (Currencies["EUR"], Currencies["GBP"], Date("2017-01-01")): Decimal("0.80")
    }

    # Temporal dimension for date to retrieve the foreign exchange rates.
    temporal = Temporal("2017-01-01")

    # Construct the queries.
    queries = []

    # Query 1: Find the foreign exchange rate for EUR

# Generated at 2022-06-12 06:12:20.585904
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class :class:`FXRateService`.
    """
    from unittest import TestCase
    from unittest.mock import MagicMock
    from pypara.commons.zeitgeist import as_date

    class FXRateServiceImpl(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, queries, strict=False):
            return iter([None])

    xrate_service = FXRateServiceImpl()

    fxrate1 = MagicMock()
    fxrate2 = MagicMock()


# Generated at 2022-06-12 06:12:21.078560
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

# Generated at 2022-06-12 06:12:27.934015
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    
    # Test fx rate query
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currency

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None
    
    dut = TestFXRateService()
    fxRate = dut.query(Currency("USD"), Currency("EUR"), Date("2001-01-01"))
    assert fxRate == None

# Generated at 2022-06-12 06:12:35.966709
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal

    # define a dummy rate service
    class DummyFXRS(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [ FXRate(ccy1, ccy2, asof, Decimal("1.0")) for ccy1, ccy2, asof in queries if ccy1 == ccy2 ]

    # assert None

# Generated at 2022-06-12 06:12:44.884665
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.finance import FXRateService

    class SimpleFXRateService(FXRateService):
        """
        Provides a simple FX rate service that returns foreign exchange rate if and only if the currency pair and
        the date are the same.
        """

        def __init__(self):
            self.rates = []

        def add(self, rate: FXRate) -> None:
            self.rates.append(rate)


# Generated at 2022-06-12 06:12:51.061202
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies

    class Service(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) \
                -> Iterable[Optional[FXRate]]:
            pass

    service = Service()
    rate = service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Cur

# Generated at 2022-06-12 06:13:04.039402
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency, EUR, USD
    import datetime
    from decimal import Decimal
    from .services import StaticFXRateService
    from .values import Temporal

    query = (EUR, USD, Temporal.of(datetime.date(2019, 1, 1)))

    #
    # Case #1: A query that does not yield a result:
    #

    service = StaticFXRateService({}, True)
    with service.static():
        assert service.queries([query], True) == [None]

    # Case #2: A query that yields a result.
    service = StaticFXRateService({query: Decimal(1.2)}, True)
    with service.static():
        assert service.queries([query], True) == [Decimal(1.2)]

    #
    # Case #3: A query

# Generated at 2022-06-12 06:13:21.007239
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateLookupError, FXRateService
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = datetime.date.today()
    strict = True
    urate = FXRate(ccy1, ccy2, asof, Decimal("2"))
    with mock.patch("pypara.fx.services.FXRateService.query", return_value=urate) as mock_query:
        service = FXRateService()
        rate = service.query(ccy1, ccy2, asof, strict)

# Generated at 2022-06-12 06:13:27.849059
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .fxrates import FXRateService, InMemoryFXRateService

    ## Initialize the FX rate service:
    service = InMemoryFXRateService()

    ## Try to lookup a non-existing FX rate:
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.now()) is None



# Generated at 2022-06-12 06:13:35.602102
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.dummy import DummyFXRateService

    ## Valid currency pairs:

# Generated at 2022-06-12 06:13:38.828007
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method :method:`FXRateService.query` of class :class:`FXRateService`.
    """
    ## Test the abstract method:
    with pytest.raises(NotImplementedError):
        FXRateService().query(None, None, None)


# Generated at 2022-06-12 06:13:50.569860
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests FXRateService.queries method.
    """
    ## Import required modules:
    import datetime
    from decimal import Decimal
    from unittest import TestCase

    ## Unittest class:
    class FXRateServiceQueriesTestCase(TestCase):
        """
        Defines a unit test case for testing FXRateService.queries method.
        """

        #: Defines a non-strict instance of :class:`FXRateService` for unit testing.
        non_strict = FakeFXRateService()

        #: Defines an iterable of FX rate queries.

# Generated at 2022-06-12 06:14:03.043453
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currency
    from .commons.zeitgeist import Temporal
    from .fx.static import StaticFXRateService
    from .fx.test import FIXTURE

    ccy1 = Currency(Currency.Code.USD)
    ccy2 = Currency(Currency.Code.EUR)
    service = StaticFXRateService(FIXTURE)

    # Test strict flag
    rate = service.query(ccy1, ccy2, Temporal(2012, 1, 1), strict=True)
    assert rate == FXRate(ccy2, ccy1, Temporal(2012, 1, 1), 0.7564)


# Generated at 2022-06-12 06:14:13.464820
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    import datetime
    import unittest

    from itertools import chain

    from pypara.currencies import Currencies
    from pypara.temporal import Period

    from .fx import FakeFXRateService, FXRateLookupError

    class FXRateServiceQueriesTestCase(unittest.TestCase):

        def test_query(self) -> None:

            # Arrange:
            service = FakeFXRateService()

            # Act:
            queries = [service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=True)
                       for _ in range(1000)]

            # Assert:
            self.assertTrue(all(queries))

        def test_queries(self) -> None:

            # Arrange:
            service = FakeFXRateService()
            # dates = [

# Generated at 2022-06-12 06:14:23.048272
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.dates import Temporal
    from pypara.fxrateservices.memory import MemoryFXRateService

    fxrs = MemoryFXRateService()

# Generated at 2022-06-12 06:14:32.620846
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    ## Fixture:
    ## Initialize a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        """
        Provides a dummy implementation for the FX rate service.
        """


# Generated at 2022-06-12 06:14:43.623893
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporals import Dates
    from .fxrates import FXRate
    from decimal import Decimal
    from functools import partial
    from itertools import cycle, islice
    from unittest import TestCase


# Generated at 2022-06-12 06:15:04.048946
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Executes a basic test for method query of class FXRateService.
    """
    from pypara.currencies import BASE

    # if FXRateService.default is None:
    #     raise RuntimeError("FXRateService.default is not set.")
    #
    # # Ensure that FXRateService.query works:
    # rate = FXRateService.default.query(BASE, BASE, Date(2016, 1, 1))
    # assert IS_TYPE_OF(rate, Optional[FXRate])
    # assert rate is None


# Generated at 2022-06-12 06:15:15.129168
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    # Set the values:
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    date = Date.today()

    # Create a new FX rate service:
    service = FXRateService()

    # We should be getting a NotImplementedError to be raised:
    try:
        service.query(ccy1, ccy2, date)
        raise AssertionError("Should have raised NotImplementedError.")
    except NotImplementedError:
        pass

    # Nothing to be returned in strict mode:

# Generated at 2022-06-12 06:15:25.465054
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies, Currency
    from .curves import IRR
    from .discounts import DiscountCurve

    from .commons.enums import Tenors
    from .commons.temporal import DateRange
    from .commons.enums import PeriodTypes

    import datetime

    from decimal import Decimal

    from .fxrates import FXRateService

    class CustomFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: datetime.date, strict: bool) -> Optional[Decimal]:
            return Decimal("2") if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] else None


# Generated at 2022-06-12 06:15:36.433491
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currency, Currencies

    # Define an FX rate service:
    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(datetime.date(2019, 1, 1)):
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("1.5"))

# Generated at 2022-06-12 06:15:41.924612
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D103
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate
    from pypara.fxrates import FXRateService

    import datetime

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None


# Generated at 2022-06-12 06:15:51.395457
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Performs unit testing for :class:`FXRateService.queries` method.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    ## Define the service:

# Generated at 2022-06-12 06:16:02.432041
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of FXRateService class
    """
    import json
    import pandas as pd

    def make_request(url, params):
        """
        Makes a get request to an url and returns the response as a json.

        :param url: The url to make the request to.
        :param params: The params of the request.
        :return: The json result of the request.
        """
        import requests

        response = requests.get(url, params)
        response.raise_for_status()
        return response.json()
    

# Generated at 2022-06-12 06:16:14.491038
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest

    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.services.forex import FXRateService

    class TestFxRateService(FXRateService):
        def __init__(self, queries: Iterable[FXRateService.TQuery], rates: Iterable[Optional[FXRate]]):
            self._queries = tuple(queries)
            self._rates = tuple(rates)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError()


# Generated at 2022-06-12 06:16:24.170364
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test for queries method of class FXRateService
    """
    ## Test for queries:
    from pypara.currencies import Currencies
    import datetime
    send_queries = ((Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 10)),
                    (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 11)),
                    (Currencies["EUR"], Currencies["USD"], datetime.date(2019, 1, 12)))
    received_queries = []

    class MockService(FXRateService):
        """
        A mock FX rate service.
        """

# Generated at 2022-06-12 06:16:36.964566
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    import unittest

    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.0"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)


# Generated at 2022-06-12 06:17:24.670549
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .temporal import Temporal
    from .currencies import Currency
    from .fx import FXRateService, FXRate, FXRateLookupError
    from decimal import Decimal
    from datetime import datetime
    # Mock FXRateService
    class MockFXRateService(FXRateService):
        @staticmethod
        def query(ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency("EUR") and ccy2 == Currency("USD") and asof == datetime.today():
                # EUR/USD 1.2
                return FXRate(ccy1, ccy2, asof, Decimal("1.2"))

# Generated at 2022-06-12 06:17:36.665246
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency, Currencies
    from .temporal import Temporal, TimeSpan

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            return FXRate(ccy1, ccy2, asof, 1) if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] else None

        def queries(self, queries, strict):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    fx_service = TestFXRateService()
    asof = Temporal.today()

# Generated at 2022-06-12 06:17:38.039631
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """This unit test belongs to the method queries of class FXRateService."""
    pass

# Generated at 2022-06-12 06:17:49.550829
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.commons.numbers import ONE, ZERO
    from pypara.currencies import Currency
    from pypara.fx import FXRate, FXRateService

    ## Define a rate:
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")
    asof = Date.today()
    fx = FXRate(ccy1, ccy2, asof, ONE)

    ## Define a service:
    class TestFXRateService(FXRateService):  # noqa: N801
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return fx if (ccy1, ccy2, asof) == (ccy1, ccy2, asof) else None

       

# Generated at 2022-06-12 06:17:52.435994
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    ## Create & configure the foreign exchange rate service:
    pass

# Generated at 2022-06-12 06:18:00.122952
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency

    class LocalFXRateService(FXRateService): # noqa: N801

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return list()

    service = LocalFXRateService()
    result = service.query(Currency("EUR"), Currency("USD"), Date.TODAY)
    assert result is None


# Generated at 2022-06-12 06:18:10.751514
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.datetime import Temporals
    from pypara.finance.fx.rates import FXRate, FXRateService

    class TestFXRateService(FXRateService):
        def __init__(self):
            self._rates = {
                (Currencies["EUR"], Currencies["USD"], Temporals.today()): FXRate(Currencies["EUR"], Currencies["USD"], Temporals.today(), Decimal("2")),
                (Currencies["USD"], Currencies["EUR"], Temporals.today()): FXRate(Currencies["USD"], Currencies["EUR"], Temporals.today(), Decimal("0.5")),
            }


# Generated at 2022-06-12 06:18:23.484884
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService

    class Dummy(FXRateService):
        def __init__(self):
            self._rates = {}

        def add(self, ccy1: Currency, ccy2: Currency, date: Date, value: Decimal) -> None:
            self._rates[(ccy1, ccy2, date)] = FXRate(ccy1, ccy2, date, value)


# Generated at 2022-06-12 06:18:24.660494
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:18:34.323737
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class DummyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    query = (Currencies["EUR"], Currencies["USD"], datetime.date.today())
    dfxr = DummyFXRateService()
    rate = dfxr.queries([query], strict=False)
    print(list(rate))


# Generated at 2022-06-12 06:20:02.279808
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date, Temporal
    from .services import MemoryFXRateService

    # Create services:
    fx1 = MemoryFXRateService(Currencies["USD"], Currencies["EUR"], Date(2018, 1, 1), ONE)
    fx2 = MemoryFXRateService(Currencies["USD"], Currencies["EUR"], Date(2018, 1, 2), ONE)
    fx3 = MemoryFXRateService(Currencies["USD"], Currencies["EUR"], Date(2018, 1, 3), ONE)

    # Build queries:

# Generated at 2022-06-12 06:20:13.147852
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    class FXRateServiceStub(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))
        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass
    fx = FXRateServiceStub()
    rate = fx.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())