

# Generated at 2022-06-12 06:10:28.703219
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert ~FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")) == FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))


# Generated at 2022-06-12 06:10:38.578747
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .datetime import Temporal
    from .currencies import Currency
    from decimal import Decimal

    class Mock(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, temporal: Temporal, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency("AAA") and ccy2 == Currency("BBB") and temporal == Temporal(0) and not strict:
                return FXRate(ccy1, ccy2, temporal, Decimal("0.5"))
            else:
                return None

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Temporal]], strict: bool = False) -> Iterable[
            Optional[FXRate]]:
            import itertools

# Generated at 2022-06-12 06:10:48.459365
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal

    from datetime import date
    from pypara.currencies import Currencies, Currency
    from pypara.service.fx_rates.yahoofinance import YahooFinanceFXRateService

    fx_rate_service = YahooFinanceFXRateService()
    fx_rate = fx_rate_service.query(Currencies["USD"], Currencies["EUR"], date.today())
    assert fx_rate is not None
    assert fx_rate.value is not None

    fx_rate_service.query(Currency("USD"), Currency(101, "EUR"), date.today())


# Generated at 2022-06-12 06:11:00.591947
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currencies
    from pypara.currencies.exchange_rates import FXRate, FXRateService
    from pypara.currencies.exchange_rates.memory_service import MemoryService
    from pypara.indexes.temporal import Temporal

    ## Create FX rate service:
    service = FXRateService()

    ## Create memory service:
    mservice = MemoryService()

    ## Create FX rates:

# Generated at 2022-06-12 06:11:09.504545
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal.local import LocalDate
    from .temporal.periods import Period
    from .temporal.periods import Periods

    # Create the queries:
    queries = [
        (Currencies["EUR"], Currencies["USD"], LocalDate.of(2020, 1, 1)),
        (Currencies["EUR"], Currencies["USD"], LocalDate.of(2020, 2, 1)),
        (Currencies["EUR"], Currencies["USD"], LocalDate.of(2020, 3, 1)),
        (Currencies["EUR"], Currencies["USD"], LocalDate.of(2020, 4, 1)),
    ]

    # Create and test the period service:
    psrv = Periods.default_service()

# Generated at 2022-06-12 06:11:20.454265
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    ###	Define a sample query set:
    import datetime
    from collections import namedtuple
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.futures import FUTURES
    from pypara.quotes import MarketQuotation
    from pypara.time import Period

    TQuery = namedtuple("TQuery", ["ccy1", "ccy2", "asof"])

    q1 = TQuery(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    q2 = TQuery(Currencies["USD"], Currencies["EUR"], datetime.date.today())
    q3 = TQuery(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-12 06:11:28.302687
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves.fx import FXRateService

    ## Create an FX rate service:
    class Impl(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            return None

        def queries(self, queries, strict=False):
            return list(map(lambda query: self.query(query[0], query[1], query[2], strict), queries))

    rates = Impl()

# Generated at 2022-06-12 06:11:34.920720
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert (~nrate == rrate)


# Generated at 2022-06-12 06:11:40.932233
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rate1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rate2 = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    assert(rate1 == ~rate2)


# Generated at 2022-06-12 06:11:48.260834
# Unit test for method __invert__ of class FXRate
def test_FXRate___invert__():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    nrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rrate = FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))

    assert ~nrate == rrate


# Generated at 2022-06-12 06:12:04.039995
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of :class:`FXRateService`.
    """

    ## Test service:
    class TestService(FXRateService):  # type: ignore
        """Test service class."""

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """Test query method."""
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """Test queries method."""
            return [None for _ in queries]

    queries = [(C("USD"), C("EUR"), D("2018-01-01")), (C("EUR"), C("USD"), D("2018-01-01"))]

# Generated at 2022-06-12 06:12:12.046382
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency

    from .lookups.static import StaticFXRateService
    service = StaticFXRateService(
        [(Currency(1), Currency(2), Date(2011, 1, 1), Decimal(1)), (Currency(1), Currency(3), Date(2011, 1, 1), Decimal(2))]
    )
    assert service.query(Currency(1), Currency(2), Date(2011, 1, 1)) == FXRate(Currency(1), Currency(2), Date(2011, 1, 1), Decimal(1))
    assert service.query(Currency(1), Currency(2), Date(2011, 1, 1), True) == FXRate(Currency(1), Currency(2), Date(2011, 1, 1), Decimal(1))

# Generated at 2022-06-12 06:12:24.795496
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.foreignexchange.rateservices import InMemoryFXRateService

    ## Test setup
    fxrate_service = InMemoryFXRateService([
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
        FXRate(Currencies["GBP"], Currencies["EUR"], datetime.date.today(), Decimal("0.5")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5")),
        FXRate(Currencies["USD"], Currencies["GBP"], datetime.date.today(), Decimal("2")),
    ])

    ## Test with strict mode (raises FXRateLook

# Generated at 2022-06-12 06:12:33.563715
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of class :class:`FXRateService`.
    """
    from decimal import Decimal
    from unittest.mock import MagicMock
    from pypara.currencies import Currency
    from pypara.temporal import Date

    ## Create a mocked FX rate service:
    fxrs = MagicMock(FXRateService)

    ## Create a foreign exchange rate:
    fxrt = FXRate(Currency("DEM"), Currency("USD"), Date(2017, 1, 1), Decimal("2"))

    ## Create a query:
    query = (Currency("DEM"), Currency("USD"), Date(2017, 1, 1))

    ## Specify the FX rate to be returned:
    fxrs.query.return_value = fxrt

    ## Test the service:
    assert fxrt == fx

# Generated at 2022-06-12 06:12:34.876009
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:12:35.888008
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## TODO: Implement
    pass


# Generated at 2022-06-12 06:12:44.602017
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D103
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.data.dummy import DummyFXRateService

    ## Initialize the dummy FX rate service:
    db = DummyFXRateService()

    ## Initialize a few samples:
    samples = [
        (Currencies["TRY"], Currencies["USD"], datetime.date.today()),
        (Currencies["USD"], Currencies["TRY"], datetime.date.today()),
        (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        (Currencies["USD"], Currencies["EUR"], datetime.date.today())
    ]

    ## Query the database:
    assert all(db.queries(samples))

# Generated at 2022-06-12 06:12:57.573347
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This function ensures that the function: queries of class: FXRateService works as expected.
    """

    import datetime
    from decimal import Decimal
    from unittest.mock import MagicMock, Mock, patch
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    
    def fx_rate(ccy1, ccy2, value):
        return FXRate(ccy1, ccy2, datetime.date.today(), Decimal(value))
    
    # Create some FX rates to be returned for different currency pairs:

# Generated at 2022-06-12 06:13:09.596220
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.services import FXRateService
    from pypara import Currencies, Temporals
    from decimal import Decimal

    class FXRateServiceStub(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            value = Decimal("1.1")
            if ccy1 == Currencies["USD"]:
                value = Decimal("1.33")
            elif ccy2 == Currencies["USD"]:
                value = Decimal("0.75")
            return FXRate(ccy1, ccy2, asof, value)

    # Initialize a stub
    stub = FXRateServiceStub()

    # EUR/BRL = 1.1

# Generated at 2022-06-12 06:13:20.484088
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create the service:
    class MockRateService(FXRateService):
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal(1.2)) if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] \
                else None


# Generated at 2022-06-12 06:13:35.312067
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .commons.zeitgeist import Date
    from .finance.fxrates import FXRate, FXRateService
    from decimal import Decimal
    class SimpleFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency.USDCAD and ccy2 == Currency.USD and asof == Date.today():
                return FXRate(ccy1, ccy2, asof, Decimal(1))
            return None

# Generated at 2022-06-12 06:13:46.650205
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.fx import FXRate, FXRateService
    from pypara.currencies import Currency
    from pypara.commons.zeitgeist import Date
    from pypara.commons.numbers import ZERO

    class TestFXRateService(FXRateService):
        """
        A test FX rate service.
        """

        @classmethod
        def query(cls, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2 or asof == Date(datetime.date(2019, 2, 10)):
                return None

# Generated at 2022-06-12 06:13:56.159519
# Unit test for method queries of class FXRateService

# Generated at 2022-06-12 06:14:00.702019
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ## Let's define some currency pairs and dates:
    from .currencies import CurrencyPairs, Currencies
    from .temporal import DateRange, Temporals

# Generated at 2022-06-12 06:14:11.674372
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():     # noqa: D100
    from datetime import date
    import pytest
    from pypara.currencies import Currency
    from pypara.temporal import Date
    from pypara.fx import FXRate, FXRateService
    from pypara.fx.rates import Fakes

    ## Given a service;
    service = FXRateService.default = Fakes()

    ## When we query multiple currency pairs,
    queries = [(Currency["EUR"], Currency["USD"], Date(date(2018, 2, 6))),
               (Currency["EUR"], Currency["USD"], Date(date(2018, 2, 7))),
               (Currency["EUR"], Currency["USD"], Date(date(2018, 2, 8)))]
    responses = service.queries(queries)

    ## Then foreign exchange rates should be returned:

# Generated at 2022-06-12 06:14:19.449220
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies

    class T(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

    EUR: Currency = Currencies["EUR"]
    USD: Currency = Currencies["USD"]
    t: FXRateService = T()
    assert t.query(EUR, USD, date(2018, 1, 1)) is None



# Generated at 2022-06-12 06:14:29.695169
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies, USD
    from .dates import Date

    class TestFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            return FXRate(ccy1, ccy2, asof, 1) if ccy1 == USD and ccy2 == USD and asof == Date.now() else None

        def queries(self, queries, strict):
            yield from map(
                lambda q: self.query(q[0], q[1], q[2]),
                queries
            )

    svc = TestFXRateService()
    # noinspection PyTypeChecker

# Generated at 2022-06-12 06:14:37.714367
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    #
    # References:
    # http://lessons.livecode.world/lessons/what-is-the-best-way-to-implement-an-abstract-base-class-in-python/
    #
    class FXRateServiceMock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    assert issubclass(FXRateServiceMock, FXRateService)

# Generated at 2022-06-12 06:14:49.632742
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the :method:`FXRateService.queries` method.
    """

    class Dummy(FXRateService):
        """
        A dummy override of the FXRateService class.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, ccy1.code[0].upper() + ccy2.code[0].lower())


# Generated at 2022-06-12 06:15:00.818410
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    import random
    import unittest
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRate, FXRateService, FXRateLookupError

    class MockFXRateService(FXRateService):
        """
        Provides a foreign exchange rate service implementation for testing.
        """

        def __init__(self) -> None:
            """
            Initializes the mock service.
            """
            ## Set the currencies:
            self._currencies = [Currencies["EUR"], Currencies["USD"], Currencies["GBP"]]

            ## Dates used in the tests:

# Generated at 2022-06-12 06:15:24.952335
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main
    from datetime import date

    from pypara.currencies import Currency
    from pypara.exchanges.mock import MockFXRateService


# Generated at 2022-06-12 06:15:36.287360
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .commons.numbers import ONE, ZERO
    from .currencies import Currency
    from .temporal import Date

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            return FXRate(ccy1, ccy2, asof, ONE)

        def queries(self, queries, strict):
            return [self.query(q[0], q[1], q[2]) for q in queries]

    rates = [
        (Currency("USD"), Currency("TRY"), Date.now()),
        (Currency("TRY"), Currency("USD"), Date.now()),
        (Currency("USD"), Currency("EUR"), Date.now()),
        (Currency("EUR"), Currency("USD"), Date.now()),
    ]

    service = Mock

# Generated at 2022-06-12 06:15:48.025574
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.finance.finance import FXRate
    from pypara.finance.tax.fxrate import FXRateService

    class MockService(FXRateService):
        def __init__(self, rates):
            self.rates = rates

        def query(self, ccy1, ccy2, asof, strict=False):
            if (ccy1, ccy2, asof) in self.rates.keys():
                return self.rates[(ccy1, ccy2, asof)]
            return None

        def queries(self, queries, strict=False):
            for key in queries:
                yield self.rates[key]


# Generated at 2022-06-12 06:16:00.307694
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .fxrates.queries import FXRateServiceQueries
    from decimal import Decimal
    import pytest
    from datetime import date
    FXRateServiceQueries.default = FXRateServiceQueries(path='fxrate/tests/data/USD_others_2020.csv')
    assert FXRateServiceQueries.default
    
    result = FXRateServiceQueries.default.queries(
        [
            (    
                Currencies["EUR"], Currencies["USD"], Date(date.today())
            ),
            (
                Currencies["TRY"], Currencies["USD"], Date(date.today())
            )
        ],
        strict=False
    )

    result_list = list(result)
    assert len(result_list) == 2

# Generated at 2022-06-12 06:16:12.556541
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pytest
    from pypara.currencies import Currencies

    from .commons.zeitgeist import Date

    from .currencies import Currency

    from .fxrates import FXRate, FXRateService

    class TestRateService(FXRateService):
        """
        Provides a test foreign exchange rate service for unit tests.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            pass

        def queries(self, queries, strict=False):
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            pass

    service = TestRateService()

    ## Test for invalid parameters:
    with pytest.raises(ValueError):
        service.query

# Generated at 2022-06-12 06:16:14.306307
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # TODO: Implement this unit test.
    assert True

# Generated at 2022-06-12 06:16:24.048771
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.datetime import Date
    from pypara.markets.fxrates import FXRateService
    # Test the base class
    assert FXRateService.queries(None, None) == (None,)
    # Test foreign exchange service
    class TestService(FXRateService):
        @staticmethod
        def query(currency1, currency2, temporal, strict=False) -> Optional[Decimal]:
            assert False
        @staticmethod
        def queries(queries: Iterable[Tuple[Currency, Currency, Date]], strict: bool = False) -> Iterable[Optional[Decimal]]:
            _, _, _ = queries
            yield Decimal("1.2")
            yield Decimal("0.83")
    it = TestService.queries

# Generated at 2022-06-12 06:16:36.957892
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main
    from unittest.mock import Mock
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrates import FXRate, FXRateLookupError, FXRateService

    ## Mocking FXRateService:
    class FXRateServiceMock(FXRateService):
        def __init__(self):
            super().__init__()
            self.queryMock = Mock()

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return self.queryMock(ccy1, ccy2, asof, strict)


# Generated at 2022-06-12 06:16:48.704716
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests queries.
    """
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.currencies.currencies import EUR, USD
    from pypara.currencies.fxrateservices.memo import MemoFXRateService
    from pypara.commons.zeitgeist import Date

    ## Create the queries:
    queries = [
        (EUR, USD, Date("2020-01-01")),
        (USD, EUR, Date("2020-01-01")),
    ]

    ## Create the FX rate service:
    fxrate_service = MemoFXRateService()

    ## Add some FX rates:
    fxrate_service.add(Currency("EUR"), Currency("USD"), Date("2020-01-01"), Decimal("1.1"))
    f

# Generated at 2022-06-12 06:17:01.171473
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create the FX rate service that always fails:
    class AlwaysFailsFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [None] * len(queries)

    ## Create a FX rate service:

# Generated at 2022-06-12 06:17:40.492162
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.marketdata import FXRateService

    ## Create a dummy foreign exchange rate service and register Euro-US Dollar and US Dollar-Euro FX rates:
    svc = FXRateService()
    svc.register(Currencies["USD"], Currencies["EUR"], datetime.date(2018, 1, 1), Decimal("0.8"))
    svc.register(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 1, 1), Decimal("1.25"))

    ## Make a few queries:
    rate = svc.query(Currencies["USD"], Currencies["EUR"], datetime.date(2018, 1, 1))

# Generated at 2022-06-12 06:17:41.596161
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:17:52.841670
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests for method query of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from unittest.mock import Mock, patch
    from pypara.currencies import Currencies
    from .fxrates import FXRateLookupError, FXRateService
    from .commons.zeitgeist import Temporal

    ## Mocks:
    service: FXRateService = Mock()
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = datetime.date(2016, 1, 1)

    # Without FX rate:
    service.query.return_value = None
    rate = service.query(ccy1, ccy2, date)
    assert rate is None

    # With FX rate:

# Generated at 2022-06-12 06:18:01.899556
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporal import Date, DateTime
    from pypara.foreign_exchange.stub import FXRateServiceStub

    rservice = FXRateServiceStub()

    ## Try to find EUR/USD:
    fxrate = rservice.query(Currencies["EUR"], Currencies["USD"], DateTime.today())
    if fxrate is not None:
        ccy1, ccy2, date, value = fxrate
        assert ccy1 is Currencies["EUR"]
        assert ccy2 is Currencies["USD"]
        assert date == Date.today()
        assert value == Decimal("1.25")
    else:
        assert False

    ## Try to find USD/EUR:

# Generated at 2022-06-12 06:18:11.816601
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class :class:`FXRateService`.
    """

    # Import
    import datetime
    import pytest

    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.time import Date

    # No implementation provided.
    assert FXRateService.queries.__doc__ is not None

    # No queries.
    with pytest.raises(FXRateLookupError):
        FXRateService().queries(iter([]))

    # Empty queries.
    assert list(FXRateService().queries([()])) == [None]

    # Dummy implementation.

# Generated at 2022-06-12 06:18:24.534050
# Unit test for method query of class FXRateService
def test_FXRateService_query(): # noqa: D103
    from .currencies import Currencies
    from .commons.zeitgeist import Date

    ## A list of source and target currencies
    currencies = [
        (Currencies["EUR"], Currencies["USD"], Date.of(2018, 5, 2)),
        (Currencies["EUR"], Currencies["USD"], Date.of(2018, 5, 6)),
        (Currencies["USD"], Currencies["EUR"], Date.of(2018, 5, 2)),
        (Currencies["USD"], Currencies["EUR"], Date.of(2018, 5, 3)),
        (Currencies["USD"], Currencies["EUR"], Date.of(2018, 5, 6)),
        (Currencies["USD"], Currencies["EUR"], Date.of(2018, 5, 7))]

    ## Data to be used as a backing data store for

# Generated at 2022-06-12 06:18:35.539607
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    # Import packages
    import numpy as np
    import pandas as pd
    from pypara.currencies import Currency
    from pypara.datastore import DataStore
    from pypara.fx import FXRate, FXRateService, FXRateLookupError

    # Get data store
    store = DataStore.from_path("./data.h5")

    # Define FX rate service
    service = FXRateService()

    # Test failure
    with store.session() as session:
        for row in session.query(FXRate).filter(FXRate.ccy1 == Currency.of("EUR")):
            ccy1 = row.ccy1
            ccy2 = Currency.of(row.ccy2)

# Generated at 2022-06-12 06:18:46.906115
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal

    from pypara.currencies import Currency
    from pypara.currencies import Currencies
    from pypara.finance.rates import FXRate

    dates = {
        Date(2018, 1, 1): FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.2")),
        Date(2018, 2, 1): FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 2, 1), Decimal("1.1")),
        Date(2018, 3, 1): FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 3, 1), Decimal("1.3")),
    }


# Generated at 2022-06-12 06:18:55.500321
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies

    class MyFXRateService(FXRateService):
        def __init__(self):
            self.queries = []

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            self.queries.append((ccy1, ccy2, asof))
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == Date(2019, 1, 1):
                return FXRate("USD", "EUR", Date(2019, 1, 1), Decimal("2"))

# Generated at 2022-06-12 06:19:00.771924
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # This unit test serves two purposes:
    #   - Prove that the method is abstract.
    #   - Prove that the method is public.
    assert hasattr(FXRateService, "query")
    assert callable(FXRateService.query)



# Generated at 2022-06-12 06:20:24.999742
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Test that an FXRateService subclass can be created
    class Fx(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
        def queries(self, queries, strict=False):
            return [self.query(query[0], query[1], query[2]) for query in queries]

    # Test that an FXRateService subclass can be used
    rate = Fx().query(Currencies['EUR'], Currencies['USD'], datetime.date.today())
    assert rate.ccy1 == Currencies["EUR"]