

# Generated at 2022-06-12 06:10:22.592189
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    raise NotImplementedError()


# Generated at 2022-06-12 06:10:34.292325
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of FXRateService class.
    """
    from unittest.mock import patch
    from .currencies import Currency, Currencies
    from .temporals import LocalDate

    ## Prepare the mocks and the queries:
    queries = [(Currencies["EUR"], Currencies["USD"], LocalDate(2017, 12, 31)),
               (Currencies["USD"], Currencies["JPY"], LocalDate(2017, 12, 31))]
    mock = patch("pypara.fx.FXRateService.query", return_value=None).start()

    ## Test strict mode:
    service = FXRateService()
    service.queries(queries, strict=True)  # noqa: P201

# Generated at 2022-06-12 06:10:41.782258
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from .currencies import Currency, Currencies
    from .commons.zeitgeist import Date
    from .fx import FXRateService
    from .types import Type
    import datetime


# Generated at 2022-06-12 06:10:53.191445
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test for method queries of class FXRateService.
    """
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):
        """
        Test FX rate service implementation.
        """


# Generated at 2022-06-12 06:11:04.312311
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .zeitgeist import Date
    from .fx import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            rate = (ccy1, ccy2, asof)
            if rate != (Currencies["EUR"], Currencies["USD"], Date(2019,1,1)):
                return None
            else:
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2019,1,1), Decimal("1.5"))
    
    x = MockFXRateService()
    ans = x.query(Currencies["EUR"], Currencies["USD"], Date(2019,1,1))
    assert ans is not None

# Generated at 2022-06-12 06:11:09.430778
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests :method:`FXRateService.query`.

    >> FXRateService.query("EUR", "USD", datetime.date(2018, 1, 1))
    """
    # TODO: Implement this test
    pass


# Generated at 2022-06-12 06:11:10.481980
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:11:21.189807
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """

    # Import:
    from unittest import TestCase, mock
    from pkg_resources import load_entry_point
    from dateutil.parser import parse
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fxrates import FXRateService

    # Constants:
    ASOF = parse("2018-08-21")

    # Mocks:
    class Queries:
        """
        Defines a mock service.
        """

        def query(self: "Queries", ccy1: Currencies, ccy2: Currencies, asof: ASOF, strict: bool = False) -> Decimal:
            """
            Returns a mock FX rate.
            """

# Generated at 2022-06-12 06:11:29.784814
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    class SampleFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None

    ## Rate exists and FXRate instance is returned:
    service = SampleFXRateService()
   

# Generated at 2022-06-12 06:11:41.209421
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase, main
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.fx import FXRateService

    class MockFXRateService(FXRateService):
        def __init__(self, *args, **kwargs) -> None:
            self.rates = {}

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            try:
                return self.rates[(ccy1, ccy2, asof)]
            except KeyError:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
                return None


# Generated at 2022-06-12 06:11:57.109775
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    import unittest

    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestFXRateService(FXRateService):

        def __init__(self):
            self.rates = [
                FXRate(Currencies["EUR"], Currencies["USD"], datetime.datetime(year=2018, month=1, day=1).date(), Decimal("2")),
                FXRate(Currencies["EUR"], Currencies["USD"], datetime.datetime(year=2018, month=2, day=1).date(), Decimal("3")),
                FXRate(Currencies["EUR"], Currencies["USD"], datetime.datetime(year=2018, month=3, day=1).date(), Decimal("4")),
            ]


# Generated at 2022-06-12 06:12:08.821145
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test the method query of class FXRateService.
    """
    ## Test the abstract method:
    class TestService(FXRateService):
        """
        A test implementation of :class:`FXRateService`.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            """
            Returns foreign exchange rates for a given collection of currency pairs and dates.
            """
            return map(lambda x: None, queries)

    ## Test the FX rate service class:


# Generated at 2022-06-12 06:12:18.916514
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies

    c1, c2, c3, c4 = Currency("KRW"), Currency("USD"), Currency("EUR"), Currency("PLN")
    q1, q2, q3 = (c1, c2, date.today()), (c2, c3, date.today()), (c3, c4, date.today())

    class FXRateServiceMock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2, asof) == q1:
                return FXRate(c1, c2, date.today(), Decimal("10.9"))
           

# Generated at 2022-06-12 06:12:29.312668
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the :method:`FXRateService.query` method.
    """
    from unittest.mock import Mock, patch

    # Load a mock FX rate service:
    from pypara.fx.services import FXRateService
    from pypara.currencies import Currencies
    from pypara.refdata import Date
    from pypara.fx.rates import FXRate
    fxrates_mock = Mock(spec=FXRateService)
    fxrates_mock.query.return_value = FXRate(Currencies["EUR"], Currencies["USD"], Date(2018, 1, 1), Decimal("1.5"))

    # Patch the default FX rate service:

# Generated at 2022-06-12 06:12:30.331073
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:12:42.299292
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the :class:`FXRateService` class.
    """
    import datetime
    from decimal import Decimal
    from unittest import TestCase
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRateLookupError, FXRateService
    from pypara.finance.fx.services import FXRateProvider

    class DummyService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            ## Case 1: No query:
            if ccy1 or ccy2 or asof:
                return None

            ## Case 2: EUR

# Generated at 2022-06-12 06:12:54.929658
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime

    from decimal import Decimal

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1.code == "EUR" and ccy2.code == "USD" and asof == datetime.date(2019, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            elif ccy1.code == "USD" and ccy2.code == "EUR" and asof == datetime.date(2019, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("0.5"))
            else:
                if strict:
                    raise FXRateLookupError(ccy1, ccy2, asof)
               

# Generated at 2022-06-12 06:12:56.018898
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert False, "TODO: Implement"

# Generated at 2022-06-12 06:12:57.538858
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:13:09.554928
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    ## Instantiate the class:
    class StubFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("1.3"))

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict=strict)

    service = StubFXRateService()

    ## Query:
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    import decimal


# Generated at 2022-06-12 06:13:29.581848
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class DummyFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            self.__rates: Tuple[FXRate] = tuple(rates)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.__rates:
                if rate[0] == ccy1 and rate[1] == ccy2 and rate[2] == asof:
                    return rate
            return None


# Generated at 2022-06-12 06:13:40.421388
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase
    from unittest.mock import Mock

    from pypara.currencies import Currencies

    service = Mock(spec=FXRateService)
    queries = [(Currencies["USD"], Currencies["EUR"], Date.today()), (Currencies["USD"], Currencies["TRY"], Date.today())]
    rates = [Decimal("1.3"), Decimal("6.9")]
    service.queries.return_value = iter(rates)

    ret = service.queries(queries)
    assert isinstance(ret, list)
    for rate, expected in zip(ret, rates):
        assert rate == expected


# Generated at 2022-06-12 06:13:52.650708
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal

    from .currencies import Currencies

    class MyFXRateService(FXRateService):
        def __init__(self):
            self.__rates = list()

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for rate in self.__rates:
                if rate.ccy1 == ccy1 and rate.ccy2 == ccy2 and rate.date == asof:
                    return FXRate(rate.ccy1, rate.ccy2, rate.date, rate.value)
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-12 06:13:58.770837
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): # noqa: D103,D105
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.fx import FXRateService, FXRateLookupError

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == datetime.date.today():
                return FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.8"))

# Generated at 2022-06-12 06:14:09.789516
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class FXRateServiceAlwaysNone(FXRateService):
        """
        Provides an :class:`FXRateService` that always returns none.
        """

        def query(self, ccy1, ccy2, asof, strict=False) -> Optional[Decimal]:  # noqa: E0211
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[Decimal]]:  # noqa: E0211
            return [None] * len(queries)

    service = FXRateServiceAlwaysNone()


# Generated at 2022-06-12 06:14:11.050889
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert False


# Generated at 2022-06-12 06:14:21.279122
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the :method:`FXRateService.queries` method.
    """

    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fin.fx import FXRateService

    class MockFXRateService(FXRateService):
        """
        A simple mock implementation of the :class:`FXRateService` class.
        """

        def __init__(self) -> None:
            """
            Initializes the mock FX rate service.
            """

# Generated at 2022-06-12 06:14:32.133652
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporal
    from .fxrate.service_static import StaticFXRateService

    test_fxrate_service = StaticFXRateService()

    test_fxrate_queries = (
        (Currencies["USD"], Currencies["EUR"], Temporal("2019-01-01")),
        (Currencies["EUR"], Currencies["USD"], Temporal("2019-01-01")),
    )

    test_fxrate_services_rates = test_fxrate_service.queries(test_fxrate_queries)


# Generated at 2022-06-12 06:14:37.646404
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .properties import Temporary
    from .currencies import Currencies
    from .commons.zeitgeist import Date, now
    from .finance import Money
    from .fx import FXRate

    ## Set the temporal dimension:
    asof = Date(now())

    ## Create a dummy FX rate service:
    class MyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False):
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("3"))

    fx = MyFXRateService()

    ## Test the method:

# Generated at 2022-06-12 06:14:49.555127
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency

    from ._test.test_fxrates import EUR, USD

    from .commons.zeitgeist import Date

    from .fxrates import DefaultFXRateService, FXRateLookupError

    class MockFXRateService(DefaultFXRateService):

        def __init__(self, *rates: FXRate):
            self.rates = { (rate[0], rate[1], rate[2]): rate for rate in rates }

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2, asof) in self.rates:
                return self.rates[(ccy1, ccy2, asof)]

# Generated at 2022-06-12 06:15:14.957973
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    import pytest
    from datetime import date, datetime
    from decimal import Decimal
    from collections import namedtuple
    from pypara.currencies import Currency, Currencies
    from pypara.fxrates import FXRate, FXRateService
    FXRateQuery = namedtuple("FXRateQuery", "ccy1, ccy2, asof")
    class MockFXRateService(FXRateService):
        """
        Provides an FX rate service for unit testing.
        """
        def __init__(self):
            super().__init__()
            self._rates = []
            self._rates.append(FXRate(Currencies[1], Currencies[2], datetime(2020, 8, 25).date(), Decimal("1.8")))
            self

# Generated at 2022-06-12 06:15:25.313604
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests :method:`FXRateService.query`.
    """
    ## Import module:
    import unittest

    ## Import classes:
    from tests import FXRateServiceMock
    from .currencies import Currencies

    ## Define test-case class:
    class FXRateServiceTest(unittest.TestCase):

        def test_query(self):
            """
            Tests :method:`FXRateService.query`.
            """
            ## Create the FX rate service:

# Generated at 2022-06-12 06:15:36.401003
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from unittest import TestCase, TestSuite, TextTestRunner
    from decimal import Decimal
    from datetime import date

    from pypara.currencies import Currencies
    from pypara.fx import FXRate, FXRateService

    class FXRateServiceBuilder:

        def __init__(self, *rates: FXRate) -> None:
            self.__rates = rates

        def build(self) -> FXRateService:
            class Service(FXRateService):

                def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
                    for rate in rates:
                        if ccy1 == rate.ccy1 and ccy2 == rate.ccy2 and asof == rate.date:
                            return rate
                    if strict:
                        raise FX

# Generated at 2022-06-12 06:15:45.402484
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest.mock import Mock

    ## Mock an FX rate service:
    m = Mock(spec=FXRateService)

    ## A collection of FX rate queries:
    q = [("ABC", "DEF", "GHI")]

    ## Query the FX rate service:
    m.queries(q)

    ## Ensure the query method is called with the same set of arguments
    ## and the same strict argument (False):
    m.query.assert_called_once_with(q[0][0], q[0][1], q[0][2], False)

# Generated at 2022-06-12 06:15:53.180061
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    from .currencies import create_currency
    from .exchanges import create_exchange

    ## Create currencies:
    ccy1  = create_currency("USD")
    ccy2  = create_currency("EUR")
    ccy3  = create_currency("GBP")
    ccy4  = create_currency("TRL")  # noqa: E741
    ccy5  = create_currency("CHF")
    ccy6  = create_currency("CAD")

    ## Create a list of queries:

# Generated at 2022-06-12 06:15:54.527727
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:16:03.375153
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # noqa: D103
    # Initialize
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.service import CurrencyService
    from pypara.fx.database import FXRateDB
    from pypara.temporal import DateTemporalCoord

    ## Initialize the currency service:
    CurrencyService.default = CurrencyService.inmemory()

    ## Initialize the currency service:
    FXRateService.default = FXRateDB.memory()

    ## Create two currencies, the EUR and the USD:
    eur = FXRateService.default.query(Currencies["EUR"], Currencies["USD"], DateTemporalCoord.today())
    assert eur is not None
    assert eur[3] == Decimal('2')

# Generated at 2022-06-12 06:16:15.238161
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests for the FXRate ervice abstract class.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create test query:
    query = (Currencies["EUR"], Currencies["USD"], datetime.date.today())

    ## Create service:
    class TestService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return []

    ## Execute the test:
    service = TestService

# Generated at 2022-06-12 06:16:26.051732
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date
    from .exchange.simple import FXSimpleRateService
    from decimal import Decimal
    import datetime
    
    fx = FXSimpleRateService()
    fx.set_rate(Currency("USD"), Currency("TRY"), Date(datetime.date.today()), Decimal("5.76"))
    fx.set_rate(Currency("EUR"), Currency("TRY"), Date(datetime.date.today()), Decimal("6.80"))
    fx.set_rate(Currency("GBP"), Currency("TRY"), Date(datetime.date.today()), Decimal("7.90"))


# Generated at 2022-06-12 06:16:38.038137
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from pypara.currencies import Currencies

    class SimpleFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("1.5"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate.of(ccy1, ccy2, asof, Decimal("1.5"))

    fxrate_service = SimpleFXRateService()

# Generated at 2022-06-12 06:17:25.083179
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRateService

    # the mock FX rate service:
    class FXRateServiceMock(FXRateService):
        def __init__(self):
            self.idx = {}

            # add a few rates:
            self.add(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 12, 1), Decimal("2"))
            self.add(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 12, 2), Decimal("2.5"))
            self.add(Currencies["EUR"], Currencies["USD"], datetime.date(2018, 12, 3), Decimal("3"))

# Generated at 2022-06-12 06:17:34.574182
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pprint import pprint
    from pypara.currencies import Currencies
    from pypara.services.rates.fx_rates import FXRateService

    service = FXRateService()
    rates = service.queries(
        (
            (Currencies["EUR"], Currencies["USD"], Date.today()),
            (Currencies["EUR"], Currencies["USD"], Date.today()),
            (Currencies["EUR"], Currencies["USD"], Date.today()),
            (Currencies["EUR"], Currencies["USD"], Date.today()),
        )
    )
    pprint(list(rates))

# Generated at 2022-06-12 06:17:40.876703
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from datetime import date
    from .currencies import Currency

    from .services import FXRateServiceImpl

    service = FXRateServiceImpl()
    rate = service.query(Currency("EUR"), Currency("USD"), date.today())
    assert isinstance(rate, FXRate)
    assert isinstance(rate.value, Decimal)

# Generated at 2022-06-12 06:17:50.623574
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .utils.market import USD, EUR, GBP
    from .commons.zeitgeist import Today

    ## Calculate the USD value of 100 GBP as of today:
    service = FXRateService()
    fx_rate = service.query(GBP, USD, Today)
    assert fx_rate is not None
    usd_value = 100 * fx_rate.value

    ## As a sanity check, we can calculate the same value by querying fx rates as follows:
    fx1 = service.query(EUR, GBP, Today)
    fx2 = service.query(EUR, USD, Today)
    assert fx1 is not None
    assert fx2 is not None
    usd_value2 = 100 * fx1.value * fx2.value
   

# Generated at 2022-06-12 06:17:52.487456
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    The unit test for method queries of class FXRateService.
    """
    pass

# Generated at 2022-06-12 06:18:01.756637
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of :class:`FXRateService`.
    """
    from collections import namedtuple
    from hyputils.hypothesis import strategies
    from pypara.currencies import CURRENCIES
    from pypara.zeitgeist import Temporals

    from pymarketcap import constants
    from pymarketcap.services.fx import CoinDeskFXRateService

    cls = FXRateService
    service = CoinDeskFXRateService(constants.DEFAULT_BASE_URL)

    ## Define the model:
    Cls = namedtuple("Cls", "service")

    ## Get the queries:

# Generated at 2022-06-12 06:18:11.724992
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from .currencies import Currencies
    from .fxrates import FXRate
    from .temporal import Date


# Generated at 2022-06-12 06:18:16.499861
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Checks the implementation of method queries of class FXRateService.
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 06:18:26.369393
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class FXRateService.
    """
    from .currencies import Currencies
    from .commons.zeitgeist import Today
    from .services import FXRateServiceImpl

    ## Create an FX rate service instance:

# Generated at 2022-06-12 06:18:28.738857
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Test case for method query of class FXRateService
    """
    pass


# Generated at 2022-06-12 06:19:57.577399
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .__main__ import FXRateService
    from .currencies import Currencies
    from .temporal import Temporal
    from .time import TemporalType

    import datetime
    from decimal import Decimal

    service = FXRateService()  # type: FXRateService
    today = Temporal(datetime.date.today(), TemporalType.DATE)
    queries = [
        (Currencies["EUR"], Currencies["USD"], today),
        (Currencies["USD"], Currencies["EUR"], today),
    ]
    result = service.queries(queries)
    rates = [rate for rate in result if rate is not None]
    if len(rates) < 2:
        raise AssertionError("Foreign exchange rate query returned less than 2 rates.")

    eurusd = rates[0].value  # type: Decimal


# Generated at 2022-06-12 06:20:08.663420
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    qs = [(Currencies.EUR, Currencies.USD, Date(2015, 1, 10)),
          (Currencies.EUR, Currencies.USD, Date(2015, 1, 20)),
          (Currencies.USD, Currencies.JPY, Date(2015, 2, 20))]
    from pypara.finance.rates import FixedFXRateService
    assert FixedFXRateService(iter([FXRate(Currencies.EUR, Currencies.USD, Date(2015, 1, 10), 1)])).queries(qs) == [
        FXRate(Currencies.EUR, Currencies.USD, Date(2015, 1, 10), 1), None, None]

# Generated at 2022-06-12 06:20:09.988139
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass


# Generated at 2022-06-12 06:20:18.079639
# Unit test for method queries of class FXRateService