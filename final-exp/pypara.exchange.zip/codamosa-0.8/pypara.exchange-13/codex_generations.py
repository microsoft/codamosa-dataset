

# Generated at 2022-06-12 06:10:27.945404
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests that the method query of class FXRateService raises an exception.

    >>> from pypara.exchanges import FXRateService
    >>> FXRateService().query("EUR", "USD", "2020-01-01")
    Traceback (most recent call last):
    ...
    NotImplementedError
    """


# Generated at 2022-06-12 06:10:38.090926
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    ## Import packages:
    from decimal import Decimal
    from typing import Iterable, Tuple
    from unittest import mock
    from unittest.mock import call
    from pypara.currencies import Currency, Currencies
    from pypara.time.zeitgeist import Date

    ## Defines a FXRateService stub:
    class FXRateServiceStub(FXRateService):
        """
        Defines a pragmatically useful FXRateService stub.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns a hardcoded rate.
            """

# Generated at 2022-06-12 06:10:48.331929
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies.currencies import Currencies
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    date = Date(2018, 11, 18)
    queries = [(ccy1, ccy2, date), (ccy2, ccy1, date)]

    from pypara.currencies.fxrates.fxrate_services import DefaultFXRateService
    fx_rate_service = DefaultFXRateService()
    rates = fx_rate_service.queries(queries, strict=False)
    for rate in rates:
        print(rate)



# Generated at 2022-06-12 06:10:49.414320
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert False, "Test not implemented"


# Generated at 2022-06-12 06:10:58.651858
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .temporal import date

    # Create an FX rate service
    class FXRService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["TRL"]:
                return FXRate(ccy1, ccy2, asof, 100000)
            else:
                return None

    # Check the query
    fxr = FXRateService.default.query(Currencies["EUR"], Currencies["TRL"], date())
    assert fxr is not None
    assert fxr.ccy1 == Currencies["EUR"]
    assert fxr.ccy2 == Cur

# Generated at 2022-06-12 06:11:05.736713
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .temporal import Temporal
    from ..common.testing import assert_function_correctness

    ##
    def evaluate(**kwargs):
        ## Arrange:
        svc = FXRateService()
        args = ("EUR", "USD", Temporal.of(2018, 1, 1), False)
        ## Act:
        result = svc.query(*args)
        ## Assert:
        assert result == None
        ## Return:
        return
    ##
    assert_function_correctness(evaluate, **kwargs)

# Generated at 2022-06-12 06:11:13.758343
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies import Exchange
    from pypara.fx import FXRateService

    fxservice = Exchange()

    # Query with a single value (wrapped into a tuple):
    assert fxservice.queries([(Currencies["EUR"], Currencies["USD"], datetime.date.today())]) == \
           [FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal(1.0915))]

    # Query with multiple values (wrapped into a tuple):

# Generated at 2022-06-12 06:11:24.592723
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit tests for method queries of class FXRateService.
    """
    ## Import the module:
    from pypara.fxrates import FXRateService
    from pypara.currencies import Currency
    from pypara.commons.numbers import ONE, TWO, THREE
    from pypara.commons.zeitgeist import Date
    ## Declare a fake service class:
    class FakeRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return self.queries(((ccy1, ccy2, asof),), strict=strict)[0]


# Generated at 2022-06-12 06:11:37.048505
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Import packages:
    import datetime
    from decimal import Decimal
    from pypara.currencies import EUR, USD

    # Define a class implementing the abstract FXRateService:
    class Impl(FXRateService):

        def query(self, ccy1, ccy2, asof, strict):
            assert False, "Not implemented!"

        def queries(self, queries, strict):
            yield FXRate(EUR, USD, datetime.datetime, Decimal(1))
            yield FXRate(EUR, USD, datetime.date, Decimal(2))
            yield FXRate(EUR, USD, datetime.datetime.now(), Decimal(3))
            yield None

    # Define a service instance:
    service = Impl()

    # Define a query:

# Generated at 2022-06-12 06:11:45.877252
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService
    from pypara.zeitgeist import Date

    ## Define the query:
    CUR1 = Currencies["EUR"]
    CUR2 = Currencies["USD"]
    DATE = Date.of(datetime.date.today())

    ## A dummy FX Rate Service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(1))


# Generated at 2022-06-12 06:12:02.242954
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): # noqa: E302
    import datetime

    from .currencies import Currencies

    from .common.logger import configure_logging

    from .common.para_test import assert_values, assert_dataframe, assert_series

    configure_logging()

    ## Create a dummy foreign exchange rate service that returns None for every FX rate query:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, queries, strict=False):
            return [None] * len(queries)

    ## Create the test data:
    ccy1, ccy2, asof = Currencies["EUR"], Currencies["USD"], datetime.date.today()

# Generated at 2022-06-12 06:12:11.307095
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # Import:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate

    # Setup:
    class MyService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2.0"))


# Generated at 2022-06-12 06:12:20.411476
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .services import FXRateServiceMem
    from .currencies import Currencies

    service = FXRateServiceMem()

    ## Verify that we raise an error when the service is empty:
    with pytest.raises(FXRateLookupError):
        service.query(Currencies["EUR"], Currencies["USD"], asof=Date.today(), strict=True)

    ## Verify that we still return None with strict mode off:
    assert service.query(Currencies["EUR"], Currencies["USD"], Date.today()) is None

    ## Verify that we can query the pair the opposite way:
    with pytest.raises(FXRateLookupError):
        service.query(Currencies["USD"], Currencies["EUR"], Date.today(), strict=True)

    ## Add some rates to the service:

# Generated at 2022-06-12 06:12:30.064682
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Create test data:
    data = [
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today() + datetime.timedelta(days=1), Decimal("2.5")),
        FXRate(Currencies["EUR"], Currencies["GBP"], datetime.date.today(), Decimal("1")),
        FXRate(Currencies["USD"], Currencies["GBP"], datetime.date.today(), Decimal("0.5")),
    ]


# Generated at 2022-06-12 06:12:41.528314
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return iter((None,))

    service = TestService()
    actual = list(service.queries([(Currencies["EUR"], Currencies["USD"], datetime.date.today())], strict=True))
    assert len(actual) == 1
    assert actual[0] is None

# Generated at 2022-06-12 06:12:46.199714
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from decimal import Decimal
    from . import FXRateServices
    from .currencies import Currencies

    ## Query multiple rates:
    rates = FXRateServices.default.query(Currencies["EUR"], Currencies["USD"], date.today())
    assert(isinstance(next(rates), FXRate))

# Generated at 2022-06-12 06:12:59.013096
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of :class:`FXRateService`.
    """
    from random import choices
    from unittest import TestCase
    from decimal import Decimal, localcontext
    from datetime import date
    from pypara.currencies import Currency, Currencies
    from pypara.commons.numbers import ZERO
    from pypara.market import FXRate
    from pypara.market.fx import FXRateService

    ## Setup:
    class FXRateServiceStub(FXRateService):
        """
        Provides a stubbing class for the :class:`FXRateService` abstract class.
        """


# Generated at 2022-06-12 06:13:02.625775
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Ccy, Currencies
    from .temporal import Td, Temporal
    from pypara.fx_rates import FXRateService

    class FXRateServiceStub(FXRateService):

        def __init__(self, rates: Iterable[FXRate]) -> None:
            self._rates = {FXRateService.TQuery(rate.ccy1, rate.ccy2, rate.date): rate for rate in rates}

        def query(self, ccy1: Ccy, ccy2: Ccy, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            return self._rates.get((ccy1, ccy2, asof.date), None)


# Generated at 2022-06-12 06:13:12.273214
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # arrange
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.foreignexchange import FXRateService
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            # Get the rate:
            rate = self.rates.get((ccy1, ccy2, asof), None)
            # If the force lookup error flag is on:
            if rate is None and strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            # Return the rate:
            return rate

# Generated at 2022-06-12 06:13:14.220815
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """


# Generated at 2022-06-12 06:13:33.336710
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    ## Forward-rate:
    rate1 = (Currency("EUR"), Currency("USD"), Date("2018-12-30"))
    ## Backward-rate:
    rate2 = (Currency("USD"), Currency("EUR"), Date("2018-12-30"))
    ## We can not have both rates:
    with pytest.raises(ValueError, match="same.*currency"):
        FXRateService.queries((rate1, rate2))
    ## Neither rate value can be less than or equal to zero:
    with pytest.raises(ValueError, match="less.*zero"):
        FXRateService.queries(((currency, currency, date) for currency, currency, date in (rate1, rate2)),
                              strict=True)
    ## As

# Generated at 2022-06-12 06:13:36.901332
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for the method `query` of :class:`FXRateService`.
    """
    pass


# Generated at 2022-06-12 06:13:47.179813
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # pylint: disable=missing-function-docstring

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class MockFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            super().__init__()
            self._rates = {(rate[0], rate[1], rate[2]): rate for rate in rates}

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return self._rates.get((ccy1, ccy2, asof))


# Generated at 2022-06-12 06:13:49.522734
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    FXRateService.default = FXRateService()
    assert FXRateService.default.query(Currencies["EUR"], Currencies["USD"], Date.today()) is None, \
        "FXRateService default should return None on unknown currency pairs."


# Generated at 2022-06-12 06:13:57.263471
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """
    # Imports
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.time import Time
    from pypara.finance.fx_rates import FXRate, FXRateService

    # Class Under Test
    class FXRateServiceMock(FXRateService):
        """
        Mock FXRateSerice class for testing.
        """

        #: Defines an FX rate query tuple.
        TQuery = FXRateService.TQuery


# Generated at 2022-06-12 06:14:08.126369
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import pytest

    from datetime import date
    from decimal import Decimal

    from pypara.currencies import Currency

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1=ccy1, ccy2=ccy2, date=asof, value=Decimal("1.0"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return map(lambda query: self.query(*query), queries)

    currency1 = Currency("EUR")
    currency2 = Currency("USD")
    date = date.today()


# Generated at 2022-06-12 06:14:19.494466
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    import datetime
    from decimal import Decimal
    import random

    # Arrange
    class MyFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate] = None) -> None:
            super().__init__()
            ## Set default rates:
            self._rates = [
                FXRate.of(Currencies["USD"], Currencies["USD"], Date(2010, 1, 1), ONE),
                FXRate.of(Currencies["EUR"], Currencies["EUR"], Date(2010, 1, 1), ONE),
            ]
            ## Add more if any:
            self._rates.extend(rates or [])


# Generated at 2022-06-12 06:14:29.733385
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    import unittest

    from decimal import Decimal
    from pypara.commons.zeitgeist import DateSpan, Temporal, mkdate
    from pypara.currencies import Currency, Currencies
    from pypara.fx import FXRate, FXRateService

    ## Define a mock foreign exchange rate service:

    class MockFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2) not in self.rates:
                return None
            else:
                try:
                    return self.rates[(ccy1, ccy2)][asof]
                except:
                    return None


# Generated at 2022-06-12 06:14:38.838584
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency

    EUR = Currency(
        name="Euro",
        code="EUR",
        numeric="978",
        exponent=2
    )

    USD = Currency(
        name="US Dollar",
        code="USD",
        numeric="840",
        exponent=2
    )

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)

# Generated at 2022-06-12 06:14:49.785454
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService

    >>> from pypara.commons import log
    >>> log.setup_logging()

    >>> from pypara.currencies import Currencies, Currency
    >>> from pypara.exchanges import FXRateService
    >>> fx = FXRateService()

    # Check queries:
    >>> it = fx.queries([(Currencies["EUR"], Currencies["USD"], "2019-01-01")])
    >>> next(it) is None
    True

    # Check queries attribute:
    >>> cur = Currency.of("USD")
    >>> fx.queries([(Currencies["EUR"], cur, "2019-01-01")])
    [None]
    """
    pass

# Generated at 2022-06-12 06:15:14.960577
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .services.memory import FXRateService as MemoryFXRateService
    from .services.mock import FXRateService as MockFXRateService

    ## Setup:
    mksvc = MemoryFXRateService()
    mksvc.add(Currencies["EUR"], Currencies["USD"], 1, 0.9)
    mksvc.add(Currencies["USD"], Currencies["EUR"], 1, 1.1)
    mksvc.add(Currencies["JPY"], Currencies["USD"], 1, 0.008)
    mksvc.add(Currencies["USD"], Currencies["JPY"], 1, 123)

    ## Test the mock service:
    msvc = MockFXRateService()

# Generated at 2022-06-12 06:15:25.314032
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import CcyPair
    from .temporal import AsOf
    from .fxrates import FXRateService
    from .getenv import Getenv

    import datetime

    from decimal import Decimal

    ## Create the FX rate service and stubbed Getenv instance:
    svc = FXRateService()
    getenv = Getenv()

    ## Create currency pair and date:
    ccypair = CcyPair("EUR/USD")
    date = AsOf(datetime.date.today())

    ## Expect an exception:
    try:
        svc.query(ccypair.ccy1, ccypair.ccy2, date, strict=True)
        assert False, "Must not reach here."
    except FXRateLookupError as e:
        assert e.ccy1 == ccypair.ccy1

# Generated at 2022-06-12 06:15:36.401228
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method :method:`FXRateService.queries`.
    """
    # Imports:
    import calendar
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.commons.zeitgeist import Temporals

    # Define the collection of FX rate queries:
    queries = (
        (Currencies["TRY"], Currencies["USD"], Temporals.of(datetime.date(2020, 3, 1))),
        (Currencies["TRY"], Currencies["USD"], Temporals.of(datetime.date(2020, 4, 1))),
        (Currencies["TRY"], Currencies["USD"], Temporals.of(datetime.date(2020, 5, 1))),
    )

    # Define the FX rate service mock method:

# Generated at 2022-06-12 06:15:48.068421
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    ## Imports:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import FXRateServiceStub

    ## Prepare the FX rate service stub:

# Generated at 2022-06-12 06:16:00.345300
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of class FXRateService.
    """

    # Define the test input:
    ccy1 = Currency("EUR", "Euro", "978")
    ccy2 = Currency("USD", "US Dollar", "840")
    date = Date("2018/12/31")

    # Define the test query:
    def test_query(query: FXRateService.TQuery, strict: bool, rate: FXRate = None) -> None:
        """
        Tests the FX rate query functionality.
        """
        # Execute the query:
        result = FXRateService.default.query(*query, strict=strict)

        # Check the result:
        assert (result is None and rate is None) or (result == rate)

    # Test the query:

# Generated at 2022-06-12 06:16:12.557798
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date

    class TestFXRate(FXRate):
        def __init__(self, ccy1: Currency, ccy2: Currency, date: Date, value: Decimal) -> None:
            super().__init__(ccy1, ccy2, date, value)


# Generated at 2022-06-12 06:16:22.433047
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for FXRateService.queries
    """
    from .currencies import Currency, Currencies
    from .fxrates import FXRateExtService

    # Get supported currency cross-rates.
    reference_rates = list(
        FXRateExtService.reference().queries(
            (ccy1, ccy2, Date.today())
            for ccy1 in Currency.names()
            for ccy2 in Currency.names()
        )
    )

    # Test the queries method.
    result_rates = list(
        FXRateExtService.default().queries(
            (ccy1, ccy2, Date.today())
            for ccy1 in Currency.names()
            for ccy2 in Currency.names()
        )
    )


# Generated at 2022-06-12 06:16:32.741573
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates.dummy import DummyFXRateService

    ## Initialize a dummy FX rate service:
    fxrates = DummyFXRateService()

    ## FX rate lookup must be possible:
    asof = datetime.date.today()
    assert fxrates.query(Currencies["EUR"], Currencies["USD"], asof) == \
        FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal(1.315))


# Generated at 2022-06-12 06:16:41.834695
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.cds import CDS
    from pypara.finance import InterestRate
    from .timeseries import Timeseries
    
    def empty_fx_rate_service() -> FXRateService:
        # Dummy FX rate service that does not have any FX rates
        class EmptyFXRateService(FXRateService):
            def query(self, ccy1, ccy2, asof, strict=False):
                return None
            
            def queries(self, queries, strict=False):
                return (None,) * len(queries)
        
        return EmptyFXRateService()
    

# Generated at 2022-06-12 06:16:48.312141
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    import datetime

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    service = DummyService([rate])
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) == rate


# Generated at 2022-06-12 06:17:29.276011
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase
    from unittest.mock import Mock, call
    from pypara.commons.zeitgeist import Date, Time
    from pypara.currencies import Currencies
    from pypara.services.fxrates import FXRateService

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict=strict)

    class TestCase(TestCase):

        def setUp(self):
            self.service = TestFXRateService()
            self.mock_rates

# Generated at 2022-06-12 06:17:39.203827
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.currency_providers.ecb import ECBProvider

    ## Get a provider:
    provider = ECBProvider()

    ## Test the query method:
    fxrate = provider.query(Currencies["EUR"], Currencies["USD"], Date(2019, 1, 22))

# Generated at 2022-06-12 06:17:46.596908
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import decimal
    import datetime
    from pypara.currencies import Currency
    from pypara.currencies import Currencies

    class NullFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:  # noqa: E501
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:  # noqa: E501
            for query in queries:
                yield None

    nullfx = NullFXRateService()

# Generated at 2022-06-12 06:17:58.772358
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """

    # Import packages:
    import unittest
    from datetime import date
    from decimal import Decimal

    # Import module to test:
    from pypara.currencies import Currency
    from pypara.finance import FXRateService

    # Define a class that implements the abstract class FXRateService.
    class MyFXRateService(FXRateService):
        """
        A dummy FX rate service implementation.
        """
        fx_rates = [(Currency("EUR"), Currency("USD"), date(2020, 1, 1), Decimal("2")),
                    (Currency("USD"), Currency("EUR"), date(2020, 1, 1), Decimal("0.5"))]


# Generated at 2022-06-12 06:18:03.086282
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test the :method:`query` method of the :class:`FXRateService` abstract class.
    """
    ## Note that this is a pure abstract class. You need to subclass it and override its methods to run tests.
    assert True



# Generated at 2022-06-12 06:18:12.384894
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    from pypara.currencies import Currencies
    from .commons.times import date_now, date_tomorrow
    from .commons.numbers import Decimal
    import pytest

    #: Defines a dummy FX rate service class:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate.of(ccy1, ccy2, asof, Decimal("1"))


# Generated at 2022-06-12 06:18:25.060838
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Import packages
    import datetime

    # Import modules
    import pytest
    from pypara.currencies import EUR, USD
    from pypara.rates import FXRate, FXRateService
    from pypara.zeitgeist import Date

    # Define implementation
    class StubFXRateService(FXRateService):
        """
        Provides a stub implementation of the FX rate service.
        """

        # Define the FX rate dictionary
        _FX_RATE_DICT = {
            (EUR, USD, datetime.date(2019, 1, 1)): FXRate(EUR, USD, Date(2019, 1, 1), 2),
            (EUR, USD, datetime.date(2019, 1, 2)): FXRate(EUR, USD, Date(2019, 1, 2), 3)
        }


# Generated at 2022-06-12 06:18:26.603538
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:18:36.676322
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies


# Generated at 2022-06-12 06:18:48.642235
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """Test FXRateService.queries"""
    from .currencies import Currencies
    from .curves import CurveBuilder
    from .dates import Date, DateLiteral

    from decimal import Decimal
    from unittest import TestCase
    from datetime import date

# Generated at 2022-06-12 06:20:16.403323
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal

    class Service(FXRateService):
        def __init__(self):
            pass

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[Decimal]:
            pass

        def queries(self, queries: Iterable[Tuple[Currency, Currency, Temporal]], strict: bool = False) -> Iterable[Optional[Decimal]]:
            pass

    s = Service()
    s.query(Currencies["EUR"], Currencies["USD"], Temporal.of(2018, 1, 1))
    s.query(Currencies.EUR, Currencies.USD, Temporal.of(2018, 1, 1))