

# Generated at 2022-06-12 06:10:32.424054
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from mock import Mock
    from pypara.currencies import Currencies

    ## Create the FX rate service mock:
    service = Mock(spec=FXRateService)

    ## Configure strict query:
    service.query.return_value = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=True) == FXRate.of(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")
    )

    ## Configure non-strict query:
    service.query.return_value

# Generated at 2022-06-12 06:10:40.862086
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the FXRateService.query method.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    class MyFXRateService(FXRateService):
        """
        Provides a dummy FXRateService implementation.
        """
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            if strict and (ccy1, ccy2, asof) not in self.rates:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return self.rates.get((ccy1, ccy2, asof))


# Generated at 2022-06-12 06:10:52.548063
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime 
    from decimal import Decimal
    from pypara.currencies import Currencies
    
    class MockRateService(FXRateService):
        
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                return FXRate(ccy1, ccy2, asof, Decimal("0.5"))
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-12 06:11:03.194601
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): # noqa
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class LookupErrorTest(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies['EUR'] and ccy2 == Currencies['USD']:
                return FXRate.of(Currencies['EUR'], Currencies['USD'], datetime.date.today(), Decimal("2"))
            return None


# Generated at 2022-06-12 06:11:11.376382
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporals import Date
    from pypara.fx import FXRate


# Generated at 2022-06-12 06:11:21.863259
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    # Source: http://www1.oanda.com/lang/en/currency/converter/
    #          intl/intl?lang=en&date=2010%2F04%2F07
    #          &exch=EUR&from_amount=1&from=USD&to_amount=1&to=USD

# Generated at 2022-06-12 06:11:30.136045
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries function of FXRateService.
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance import FXRateService
    from pypara.zeitgeist import Date

    ## Define an FX rate service:
    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        #: Define the FX rate map.

# Generated at 2022-06-12 06:11:41.428508
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["USD"] and \
                    ccy2 == Currencies["EUR"] and \
                    asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

    service = FXRateServiceImpl()
    assert service.query(Currencies["USD"], Currencies["EUR"], datetime.date.today()) == \
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("2"))



# Generated at 2022-06-12 06:11:44.982872
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """
    # TODO: Implement the unit test
    pass


# Generated at 2022-06-12 06:11:45.922547
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert True


# Generated at 2022-06-12 06:12:02.388426
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the querying component of :class:`FXRateService`.
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxtr.service import FXRateMemoryService

    ## Create a pair of FX rates:
    urate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    srate = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    ## Create a service with a single FX rate:
    fxrates = FXRateMemoryService(
        urate,
        urate,
        urate
    )

    ## Create a pair of queries:

# Generated at 2022-06-12 06:12:03.163330
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ...

# Generated at 2022-06-12 06:12:11.703938
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D103
    from .currencies import Currencies
    from .temporal import Clock
    from .fx import DefaultFXRateService
    from .fx.rates import (
        FXRates,
        FXSpotRate,
        FXForwardRate,
        FXImpliedForwardRate,
        FXForwardSwapRate
    )

    ## Setup the default foreign exchange rate service:
    DefaultFXRateService.default = FXRates()

    ## Unit test the query method of the default foreign exchange rate service:
    assert DefaultFXRateService.default.query(Currencies["EUR"], Currencies["USD"], Clock.today()) == \
           FXRate.of(Currencies["EUR"], Currencies["USD"], Clock.today(), Decimal("1.12"))

    ## Cleanup the default foreign exchange rate service:
    DefaultFXRateService.default = None



# Generated at 2022-06-12 06:12:20.693016
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.

    :return: None
    """

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.finance.money import Money

    # Define a dummy money:
    dummy_money = Money.of(Currency.USD, "100")

    # Define a dummy FX rate service:
    class DummyRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:

            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            rates = []


# Generated at 2022-06-12 06:12:27.267281
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import today

    from .services import MemoryFXRateService

    fxrate_service = MemoryFXRateService(
        (Currencies["USD"], Currencies["EUR"], today(), Decimal("2"))
    )
    assert fxrate_service.query(Currencies["USD"], Currencies["EUR"], today()) == FXRate(
        Currencies["USD"],
        Currencies["EUR"],
        today(),
        Decimal("2"),
    )

# Generated at 2022-06-12 06:12:39.108311
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies
    from pypara.fx import TestFXRateService
    queries = [
        (Currencies["EUR"], Currencies["USD"], date(2019, 5, 1)),
        (Currencies["USD"], Currencies["TRY"], date(2019, 5, 1)),
        (Currencies["EUR"], Currencies["CZK"], date(2019, 5, 1)),
        (Currencies["TRY"], Currencies["USD"], date(2019, 5, 1)),
        (Currencies["TRY"], Currencies["CZK"], date(2019, 5, 1)),
    ]
    service = TestFXRateService()
    rates = service.queries(queries, strict=True)

# Generated at 2022-06-12 06:12:41.809927
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    :return:
    """
    from .currencies import Currencies
    from .temporals import Today
    raise NotImplementedError()

# Generated at 2022-06-12 06:12:42.407148
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-12 06:12:55.051419
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.commons.zeitgeist import Date
    from pypara.currencies import Currency
    import datetime

    class _FXRateService(FXRateService):
        """
        Provides a dummy FX rate service class.
        """
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            rate = FXRate(ccy1, ccy2, asof, Decimal("2"))
            return rate if rate.ccy1 == rate.ccy2 else None


# Generated at 2022-06-12 06:13:01.888652
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class DummyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("2.0"))

    assert DummyFXRateService().query(None, None, None) == FXRate(None, None, None, Decimal("2.0"))


# Generated at 2022-06-12 06:13:19.974633
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    from .currencies import Currency
    from collections import OrderedDict
    from datetime import date, datetime
    from decimal import Decimal
    from pypara.fx import FXRateService, FXRateLookupError
    import unittest

    class TestFXRateService(FXRateService):
        """
        A test class for the FXRateService class.
        """

        def __init__(self, data) -> None:
            """
            Initialises the test class.
            """
            ## Keep data:
            self._data = data


# Generated at 2022-06-12 06:13:32.891282
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from unittest import TestCase, main, mock

    from decimal import Decimal
    from datetime import date

    from pypara.currencies import Currency
    from pypara.finance.fx import FXRate, FXRateService

    class TestFXRateService(FXRateService):
        def __init__(self):
            super().__init__()

# Generated at 2022-06-12 06:13:45.534465
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Times
    from .utils import in_memory
    from copy import copy
    assert in_memory().query(Currencies["USD"], Currencies["EUR"], Times[Date(2000, 1, 1)]).value == Decimal(0.8)
    assert in_memory().query(Currencies["USD"], Currencies["USD"], Times[Date(2000, 1, 1)]).value == Decimal(1)
    assert in_memory().query(Currencies["USD"], Currencies["EUR"], Times[Date(2000, 1, 1)], strict=True) is not None
    assert in_memory().query(Currencies["USD"], Currencies["EUR"], Times[Date(2000, 1, 1)], strict=True) is not None

# Generated at 2022-06-12 06:13:56.104797
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.curves import SimpleFXRateService

    class TestSFXRateService(SimpleFXRateService):
        def __init__(self):
            super().__init__(
                FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 1), Decimal("2")),
                FXRate(Currencies["EUR"], Currencies["USD"], date(2020, 1, 2), Decimal("2.5")),
            )

    sfrs = TestSFXRateService()


# Generated at 2022-06-12 06:14:07.610059
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Checks that the queries method works correctly.
    """
    from app.services.fx_rates import FIX
    from .currencies import Currencies

    # Define queries:

# Generated at 2022-06-12 06:14:15.911351
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from unittest.mock import MagicMock
    from pypara.currencies import EUR, USD

    ## Create a mock FX rate service:
    svc = MagicMock(spec=FXRateService)
    svc.query.side_effect = (None, FXRate(EUR, USD, date.today(), Decimal("2")))
    svc.queries.return_value = (None, FXRate(EUR, USD, date.today(), Decimal("2")))
    assert list(svc.queries([(EUR, USD, date.today()), (EUR, USD, date.today())])) == [None, FXRate(EUR, USD, date.today(), Decimal("2"))]

# Generated at 2022-06-12 06:14:27.839887
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests (and documents) the method queries of class FXRateService.
    """
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.currency_service import CurrencyService
    from pypara.fxrates.fx_rate_service import FXRateService
    from pypara.fxrates.memory_fx_rate_service import MemoryFXRateService

    ## Create a memory FX rate service:
    fxs = MemoryFXRateService(
        [
            ("USD", "TRL", date(2018, 1, 1), Decimal(1)),
            ("EUR", "USD", date(2018, 1, 1), Decimal(1.4)),
        ]
    )

    ## Query for a single FX rate:

# Generated at 2022-06-12 06:14:38.356915
# Unit test for method query of class FXRateService

# Generated at 2022-06-12 06:14:50.264501
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    class FXRateServiceImpl(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.000000"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("1.000000"))

    eurusd = (Currencies["EUR"], Currencies["USD"], datetime.date.today())
    dt

# Generated at 2022-06-12 06:15:01.256740
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():  # pragma: no cover
    from collections import Iterable
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.datetime import Temporal
    from pypara.fx.memory import MemoryFXRateService

    # Prepare the query:
    query = (
        (Currency.USD, Currency.EUR, Temporal.of(2018, 12, 14)),
        (Currency.JPY, Currency.USD, Temporal.of(2018, 12, 14)),
        (Currency.EUR, Currency.USD, Temporal.of(2018, 12, 14))
    )

    # Prepare the rate service:

# Generated at 2022-06-12 06:15:25.352133
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    class MyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], asof, Decimal("2"))
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"] and asof == datetime.date.today():
                return FXRate(Currencies["USD"], Currencies["EUR"], asof, Decimal("0.5"))
            return None

# Generated at 2022-06-12 06:15:36.403353
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.temperals import DATE
    from pypara.fx.services import ArrayFXRateService, DictFXRateService

    # Set case 1:
    ccy1_1, ccy1_2, ccy1_3 = "EUR", "RUB", "USD"
    ccy2_1, ccy2_2, ccy2_3 = "USD", "EUR", "RUB"
    date_1, date_2, date_3 = "2019-08-01", "2019-08-02", "2019-08-03"
    rate_1, rate_2, rate_3 = "100.00", "150.00", "200.00"

# Generated at 2022-06-12 06:15:48.067852
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This method tests queries of FXRateService and its subclasses.
    """
    from .registry import Registry
    from .currencies import Currency
    from .temporal import Temporal
    from .zeitgeist import Date

    ## Local date-time Constants:
    d20190102 = Date.of(2019, 1, 2)
    d20190103 = Date.of(2019, 1, 3)

    ## Local currency constants:
    sek = Registry.find(Currency, "SEK")
    eur = Registry.find(Currency, "EUR")
    usd = Registry.find(Currency, "USD")

    ## Create an array of queries:

# Generated at 2022-06-12 06:15:48.984422
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert False

# Generated at 2022-06-12 06:16:01.132718
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D103
    """
    Test the query method of class FXRateService
    """
    from pypara.currencies import Currency
    from pypara.datetime import Date

    ## Mock the FX rate service:
    class _MockFXRateService(FXRateService):
        """
        Provides a mock of foreign exchange rate service.
        """

        def __init__(self):
            self.rates = {
                (Currency("EUR"), Currency("CHF"), Date.today()): FXRate(Currency("EUR"), Currency("CHF"), Date.today(), Decimal("1.1"))
            }

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns a mock foreign exchange rate.
            """

# Generated at 2022-06-12 06:16:13.066940
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class MyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == ccy2: return FXRate(ccy1, ccy2, asof, ONE)
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries: yield self.query(*query)


    service = MyFXRateService()

# Generated at 2022-06-12 06:16:21.142573
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (None,)

    queries = (("EUR","USD","2020-01-01"),("USD","EUR","2020-01-01"))
    service = TestFXRateService()
    rates = service.queries(queries)
    assert rates == (None,None)

# Generated at 2022-06-12 06:16:22.748159
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method.
    """
    pass

# Generated at 2022-06-12 06:16:36.014320
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FXRateService class.
    """

    ## Prepare the base class:
    class _(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass
        def queries(self, queries, strict=False):
            pass

    ## Prepare the instance:
    service = _()

    ## The query method must be defined:
    assert hasattr(service, "query")
    assert callable(getattr(service, "query"))

    ## The queries method must be defined:
    assert hasattr(service, "queries")
    assert callable(getattr(service, "queries"))

    ## The query method must have the correct signature:
    import inspect

# Generated at 2022-06-12 06:16:43.777979
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from copy import copy
    from pypara.currencies import Currencies
    from pypara.services.fx_rates.sequence import SequenceFXRateService

    ## Create the FX rate service:

# Generated at 2022-06-12 06:17:28.370619
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method :method:`FXRateService.queries`.
    """
    ## A mock FX rate service class:
    class MockRateService(FXRateService):
        """
        Provides a mock FX rate service class for testing.
        """

        def __init__(self, rates: Iterable[FXRate], strict: bool = False):
            """
            Initialize the mock FX rate service.
            """
            self._rates = {rate[0:3]: rate for rate in rates}
            self._strict = strict

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) \
                -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-12 06:17:38.883803
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.currencies.exchangerate import FXRateService

    class FailingService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            yield None

    # Check FailingService in non-strict mode:
    failing_service = FailingService()
    assert failing_service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) is None

# Generated at 2022-06-12 06:17:49.739700
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This function tests :method:`FXRateService.queries`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    from .commons.zeitgeist import Temporal

    from .forex.fxrateservice import FXRateService

    class FXRateServiceMock(FXRateService):
        """
        Provides a mock foreign exchange rate service implementation.
        """

        def __init__(self) -> None:
            """
            Initializes the mock foreign exchange rate service implementation.
            """
            self.rates = {}

        def add(self, ccy1: Currency, ccy2: Currency, temporal: Temporal, value: Decimal) -> None:
            """
            Adds a currency pair to the mock foreign exchange rate service implementation.
            """

# Generated at 2022-06-12 06:18:00.395631
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, date=asof, value=Decimal("1.1"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries)

    rate = DummyFXRateService().query(
        Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=False)
    assert rate is not None
   

# Generated at 2022-06-12 06:18:10.920022
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the method query of class FXRateService.
    """
    from .currencies import Currencies
    from .temporals import Temporals
    from .quotes import Quote

    ##
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Temporals[Date.now()]

    ##
    _ = FXRateService.query(ccy1, ccy2, asof)

    ##
    _ = FXRateService.query(ccy1, ccy2, asof, strict=False)

    ##
    try:
        _ = FXRateService.query(ccy1, ccy2, asof, strict=True)
    except FXRateLookupError as err:
        pass

    ##

# Generated at 2022-06-12 06:18:23.528017
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for the :method:`FXRateService.queries` method.
    :return: None
    """

    from collections import namedtuple
    from datetime import date

    from .commons.zeitgeist import Date
    from .currencies import Currencies

    # Define a dummy rate service:
    DummyRateService = namedtuple("DummyRateService", ["rates"])

# Generated at 2022-06-12 06:18:34.825942
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.rates import FXRate
    from pypara.fx.services import InMemoryFXRateService

    ## Create the reference rates:
    rates = [
        FXRate(Currencies["TRY"], Currencies["USD"], datetime.date.today(), Decimal("0.18")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("1.11")),
        FXRate(Currencies["TRY"], Currencies["EUR"], datetime.date.today(), Decimal("0.2")),
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("0.9"))
    ]

    ## Create the service and query:

# Generated at 2022-06-12 06:18:40.744991
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class :class:`FXRateService`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Define the FX rate service:
    class FXRateServiceMock(FXRateService):
        """
        Provides a mock class for an FX rate service.
        """
        # pylint: disable=unused-argument,no-self-use
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """
            return FXRate(ccy1, ccy2, asof, Decimal("2"))


# Generated at 2022-06-12 06:18:51.745636
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date
    from .servicemock import FXRateServiceMock
    from .temporal import DateRange

    service = FXRateServiceMock() ###
    rr = list(service.queries([(Currencies["EUR"], Currencies["USD"], Date.fromcalendar(2020, 1, 1)),
                               (Currencies["EUR"], Currencies["USD"], Date.fromcalendar(2019, 11, 10)),
                               (Currencies["USD"], Currencies["EUR"], Date.fromcalendar(2019, 11, 10))],
                              strict=True))
    assert len(rr) == 3
    assert rr[0].value == 1.1
    assert rr[1].value == 1.2
    assert rr[2].value == 1 / 1.2


# Generated at 2022-06-12 06:18:57.356652
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.forex import FXRateService

    class TestRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]):
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> FXRate or None:
            for rate in self.rates:
                if (rate[0] == ccy1) and (rate[1] == ccy2) and (rate[2] == asof):
                    return rate
            return None
