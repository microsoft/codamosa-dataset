

# Generated at 2022-06-12 06:10:20.220396
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: Implement FXRateService.query and then unit test.
    pass


# Generated at 2022-06-12 06:10:29.772724
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.markets import FXRate

    ccy1 = Currency('EUR')
    ccy2 = Currency('USD')
    asof = Date.of(2019, 10, 1)
    rate = Decimal('1.1012')
    strict = False

    obj = FXRateService.default
    assert isinstance(obj, FXRateService)
    assert obj.query(ccy1, ccy2, asof, strict) == FXRate(ccy1, ccy2, asof, rate)

# Generated at 2022-06-12 06:10:39.275773
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    class SUT(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
            elif ccy1 == Currencies["EUR"] and ccy2 == Currencies["GBP"]:
                return FXRate(ccy1, ccy2, asof, Decimal("0.9"))

# Generated at 2022-06-12 06:10:50.449887
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import EUR, USD, GBP, Currencies
    from pypara.marketdata import FXRateService
    from pypara.commons.zeitgeist import Date

    ## Prepare three FX rate queries:
    queries = [(EUR, USD, Date.today()), (USD, EUR, Date.today()), (GBP, USD, Date.today())]

    ## Instantiate the default FX rate service:
    svc = FXRateService()

    ## Query foreign exchange rates:
    rates = svc.queries(queries, strict=True)

    ## Convert to list:
    rates = [rate for rate in rates]

    ## Check the size:
    assert len(rates) == 3

    ## Check the values:

# Generated at 2022-06-12 06:11:00.180622
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pypara.currencies import Currencies
    from pypara.refdata import ReferenceData
    from pypara.temporal import dtoday
    from pypara.currencies.fx import FXRateServiceAlphaVantage, FXRateServiceDailyFX
    
    ## Get reference data:
    refdata = ReferenceData.default
    
    ## Create an FX rate provider:
    alpha = FXRateServiceAlphaVantage(refdata, refdata.av_api_key)
    daily = FXRateServiceDailyFX(refdata)
    ## Make a query:

# Generated at 2022-06-12 06:11:09.204174
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import DefaultCurveService
    from pypara.services.fxrates import DefaultFXRateService

    ## Initialize:
    service = DefaultFXRateService(DefaultCurveService())

    ## Find an existing rate:
    assert service.query(Currencies["EUR"], Currencies["USD"], Date(2015, 1, 9)) == FXRate(
        Currencies["EUR"], Currencies["USD"], Date(2015, 1, 9), Decimal("1.1918")
    )

    ## Find a non-existing rate:

# Generated at 2022-06-12 06:11:20.203095
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .time import Date
    from .fx import FXRateService

    # A mock FX rate service
    class MockFXRateService(FXRateService):
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return (FXRate(ccy1, ccy2, date, Decimal("2")) for ccy1, ccy2, date in queries)

    # Create a mock FX rate service
    service = MockFXRateService()
    # A collection of queries
    queries = ((Currencies["EUR"], Currencies["USD"], Date("2018-12-31")),)
    # Get exchange rates from mock FX rate service 
    rates = list(service.queries(queries))

# Generated at 2022-06-12 06:11:28.036772
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .currencies import Currencies
    
    from datetime import date

    from decimal import Decimal

    from pypara.fx import FXRateService

    queries = [
        (Currencies["EUR"], Currencies["USD"], date.today()),
        (Currencies["USD"], Currencies["EUR"], date.today()),
        (Currencies["USD"], Currencies["EUR"], date.today()),
        (Currencies["USD"], Currencies["TRY"], date.today()),
        (Currencies["TRY"], Currencies["USD"], date.today()),
    ]


# Generated at 2022-06-12 06:11:29.279313
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: Test
    pass


# Generated at 2022-06-12 06:11:40.811083
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Temporals
    from decimal import Decimal
    from datetime import date
    from pypara.rates.asset import AssetRate
    from pypara.rates.fx import FXRate, FXRateService
    class _PriceService(FXRateService):
        """
        Provides a foreign exchange rate service for unit testing.
        """

        def __init__(self, *rates: FXRate) -> None:
            """
            Initializes the price service.
            """
            ## Keep the rates:
            self._rates = {
                (rate[0], rate[1], rate[2]): rate
                for rate in rates
            }


# Generated at 2022-06-12 06:11:52.799628
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Mocking
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            return FXRate(ccy1, ccy2, asof, 1.0)
    # Testing
    mfs = MockFXRateService()
    queries = [
        (None, None, None),
        (None, None, None),
        (None, None, None),
    ]
    actual = list(mfs.queries(queries, strict=False))
    expected = [
        FXRate(None, None, None, 1.0),
        FXRate(None, None, None, 1.0),
        FXRate(None, None, None, 1.0),
    ]
    assert actual == expected

# Generated at 2022-06-12 06:12:04.515275
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """

    ## Initialize the service:
    class __Service(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass

        def queries(self, queries, strict=False):
            pass

    ## Initialize the parameter set:
    service = __Service()
    ccy1 = None
    ccy2 = None
    asof = None
    strict = False

    ## Assert the argument type check:
    try:
        service.query("", "", "")
        raise AssertionError("Assertion `test_FXRateService_query` failed.")
    except ValueError:
        pass

    ## Assert None handling:

# Generated at 2022-06-12 06:12:16.632780
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    q = [
        (Currencies["USD"], Currencies["TRY"], Date("2016-01-01")),
        (Currencies["USD"], Currencies["TRY"], Date("2016-03-01")),
        (Currencies["USD"], Currencies["TRY"], Date("2016-04-01"))
    ]
    class FXRateServiceA(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("3.7"))

# Generated at 2022-06-12 06:12:18.046359
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass



# Generated at 2022-06-12 06:12:28.811030
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pytest import raises
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    # Define a foreign exchange rate service implementation:

# Generated at 2022-06-12 06:12:41.035674
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import Date, EOM

    ## Create a test data set:
    ## Note that we do not care about the values or the dates.
    ## The test payload that we are interested in is:
    ## 1. The FX rate service is successfully called,
    ## 2. The queries are successfully mapped to the FX rate service.
    data = [("EUR", "USD", Date.today()),
            ("EUR", "USD", Date.today() + EOM),
            ("USD", "EUR", Date.today()),
            ("USD", "EUR", Date.today() + EOM),
            ("CHF", "USD", Date.today()),
            ("CHF", "USD", Date.today() + EOM)]

    ## Create a mock FX rate service:

# Generated at 2022-06-12 06:12:53.146802
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    """

# Generated at 2022-06-12 06:13:06.026476
# Unit test for method queries of class FXRateService

# Generated at 2022-06-12 06:13:18.595137
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies

    class TestService(FXRateService):
        "Implements a foreign exchange rate service for testing purposes."


# Generated at 2022-06-12 06:13:32.321688
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """

    ## Import required modules:
    import datetime
    from decimal import Decimal
    from typing import Iterable, Tuple
    from unittest.mock import Mock
    from pypara.currencies import Currency

    ## Define a date:
    date = datetime.date.today()

    ## Define driving example:
    ccy1 = Currency("EUR", "Euro")
    ccy2 = Currency("USD", "US Dollar")
    query = (ccy1, ccy2, date)
    result = FXRate(ccy1, ccy2, date, Decimal("2"))

    ## Create a mock service:
    service = Mock(spec=FXRateService)
    service.query.return_value = result

    ## Test the queries method:

# Generated at 2022-06-12 06:13:42.621518
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the FX rate query method.
    """
    ## Define a query:
    ccy1 = Currency.of("EUR")
    ccy2 = Currency.of("USD")
    asof = Date.of("2020-01-01")

    # TODO: Finish this test case.



# Generated at 2022-06-12 06:13:54.576899
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal
    from unittest import TestCase, mock
    from pypara.currencies import CurrencyPair

    from .currencies import Currencies
    from .services.fxrateservice import CachingFXRateService

    dymmy = mock.MagicMock()

    class TestFXRateService(CachingFXRateService):

        def __init__(self):
            super().__init__(dymmy)

# Generated at 2022-06-12 06:14:06.432858
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.zeitgeist import now
    from .currencies import Currency
    from .service.util import FixedFXRateService
    from .service.util import FXRateService as DummyService

    ## Create a dummy service:
    svc = DummyService()

    ## Create a collection of query tuples:
    queries = [
        (Currency("USD"), Currency("TRY"), now()),
        (Currency("TRY"), Currency("USD"), now()),
        (Currency("EUR"), Currency("TRY"), now()),
        (Currency("TRY"), Currency("EUR"), now())
    ]

    ## Perform the query and check the result:
    for query in queries:
        assert svc.query(*query) is not None

    ## Create a dummy FX rate service:

# Generated at 2022-06-12 06:14:15.094483
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.times import now
    import pytest
    fx = FXRateService()
    ccy1 = Currencies["USD"]
    ccy2 = Currencies["EUR"]
    asof = now()
    rate = fx.query(ccy1, ccy2, asof)
    assert rate.__class__ == FXRate
    assert rate.ccy1 == ccy1
    assert rate.ccy2 == ccy2
    assert rate.date == asof
    with pytest.raises(FXRateLookupError):
        fx.query(ccy1, ccy2, asof, strict=True)


# Generated at 2022-06-12 06:14:15.844844
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

# Generated at 2022-06-12 06:14:24.179701
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    import pytest

    from pypara.fxrates.services import DictFXRateService

    ## Mock service:
    service = DictFXRateService({
        ("EUR", "USD", date(2020, 1, 1)): Decimal("2"),
        ("EUR", "USD", date(2020, 1, 2)): Decimal("3"),
        ("EUR", "USD", date(2020, 1, 3)): Decimal("4"),
    })

    ## Verify that we can query single FX rate:
    assert service.queries([("EUR", "USD", date(2020, 1, 1))]) == [Decimal("2")]
    assert service.queries([("EUR", "USD", date(2020, 1, 2))]) == [Decimal("3")]
    assert service.queries

# Generated at 2022-06-12 06:14:35.969350
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies, Currency

    def _get_fx_rate_service() -> FXRateService:
        from pypara.fx import FXRateService, FXRate
        from pypara.currencies import Currency


# Generated at 2022-06-12 06:14:48.063783
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method by invoking it with a dummy derived class.
    """
    from typing import overload, Tuple
    import unittest

    from .currencies import Currency
    from .temporal import Date

    from .currencies import UnitTest_Currencies as Currencies

    class DummyService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate.of(ccy1, ccy2, asof, Decimal("1.20"))
            return None


# Generated at 2022-06-12 06:15:00.557293
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Supposes the method query of class FXRateService is implemented.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## In the absence of a service, the method should return None:
    assert FXRateService.default is None
    assert FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date.today()) is None

    ## In the presence of a service, the method should return non-None:
    class DummyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    FXRate

# Generated at 2022-06-12 06:15:08.984017
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporal
    from .equities import Equities
    print('\n# Unit test for method query of class FXRateService')

    today = Temporal.today
    query = FXRateService.query
    queries = FXRateService.queries
    assert type(queries) is staticmethod

    # Tuple array of currency pairs and dates to query FX rates.

# Generated at 2022-06-12 06:15:25.970680
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Returns a foreign exchange rate for a given currency pair and date.

    :param cls: The :class:`FXRateService` class to test.
    """

    FXRate.of("EUR", "USD", "2018-01-01", "2.0000")


# Generated at 2022-06-12 06:15:36.586855
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency, Currencies
    from .temporal import Date

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict):
            return None

        def queries(self, queries, strict):
            for query in queries:
                ccy1, ccy2, asof = query
                yield self.query(ccy1, ccy2, asof, strict)

    FXRateService.default = MockFXRateService()
    rates = list(FXRateService.default.queries(
        (
            (Currencies["USD"], Currencies["EUR"], Date.today()),
            (Currencies["USD"], Currencies["TRY"], Date.today()),
        ),
        True,
    ))
    assert len(rates) == 2

# Generated at 2022-06-12 06:15:42.022562
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from dateutil.parser import parse
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import Curve
    from pypara.curves import FXRateCurve
    from pypara.curves import FXRateService as FXRateCurveService

    ## Create the FX rate data:
    fxrate = FXRate(Currencies["EUR"], Currencies["USD"], parse("2020-01-03"), Decimal("1.25"))

    def fxrate_mock(q: FXRate.TQuery, strict: bool = False) -> Optional[FXRate]:
        return fxrate if q == (Currencies["EUR"], Currencies["USD"], parse("2020-03-03")) else None

    ## Create the FX rate service:

# Generated at 2022-06-12 06:15:42.741958
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert True

# Generated at 2022-06-12 06:15:51.836336
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method :meth:`FXRateService.query` of class :class:`FXRateService`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Fake Service:
    class FakeService(FXRateService):
        """
        Provides a fake service implementation.
        """


# Generated at 2022-06-12 06:16:02.453855
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fx import FXRateService

    rate1 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rate2 = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today() - datetime.timedelta(days=1), Decimal("2"))
    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        (Currencies["EUR"], Currencies["USD"], datetime.date.today() - datetime.timedelta(days=1)),
    ]

    ## Mock service:

# Generated at 2022-06-12 06:16:14.536611
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries` method.
    """
    # Imports:
    from random import randint
    from unittest.mock import MagicMock, Mock

    # Test cases:
    CNT = 100

    # Case 1:
    class Service(FXRateService):
        """
        The test foreign exchange rate service class.
        """
        def query(self, ccy1, ccy2, asof, strict=False):
            return None

        def queries(self, queries, strict=False):
            for ccy1, ccy2, asof in queries:
                yield self.query(ccy1, ccy2, asof, strict)

    # Case 2:
    fxrate = Mock(spec=FXRate)


# Generated at 2022-06-12 06:16:24.193624
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This is a unit test for method :method:`FXRateService.queries` of class :class:`FXRateService`.
    """
    import random
    from typing import Iterable, List
    from unittest import mock
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date
    from pypara.fx import FXRate, FXRateLookupError, FXRateService

    #
    # Use case: 1
    #
    with mock.patch.object(FXRateService, "query", autospec=True) as mock_FXRateService_query:
        ccy1 = Currencies["EUR"]
        ccy2 = Currencies["USD"]
        asof = Date.today()

# Generated at 2022-06-12 06:16:32.005077
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    rate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    test = FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

    assert rate == test

# Generated at 2022-06-12 06:16:41.337529
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance import FXRate

    ## Define the query:
    query = (Currencies["USD"], Currencies["EUR"], datetime.date.today())

    ## Check the test query:
    assert(query[0] == Currencies["USD"])
    assert(query[1] == Currencies["EUR"])
    assert(query[2] == datetime.date.today())

    ## Define the fixture:
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            ## Check the input:
            assert(ccy1 == query[0])

# Generated at 2022-06-12 06:17:26.060637
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import (
        Currency,
        CurrencyISO,
    )
    from pypara.temporal import (
        Temporal,
        Date,
    )
    from pypara.fxrates.services import (
        FXRateService,
    )

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> FXRate:
            pair = (ccy1, ccy2)
            if pair == (CurrencyISO.EUR, CurrencyISO.USD):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-12 06:17:26.677453
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    assert True

# Generated at 2022-06-12 06:17:36.131862
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from decimal import Decimal
    from .currencies import Currencies
    from .zeitgeist import Dates
    fxrate = FXRate(Currencies["EUR"], Currencies["USD"], Dates["2020-01-01"], Decimal("2"))
    asof = Dates["2020-01-01"]
    queries = [(fxrate.ccy1, fxrate.ccy2, asof), (Currencies["USD"], Currencies["EUR"], asof)]
    service = MockFXRateService(fxrate)
    assert list(service.queries(queries)) == [fxrate, ~fxrate]



# Generated at 2022-06-12 06:17:44.766429
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from .commons.zeitgeist import TimePoint

    # Sample FX rate query.
    query = (Currencies["EUR"], Currencies["USD"], TimePoint(2010, 1, 1))

    # Create an instance of FXRateService.
    fx_service = FXRateService()

    # Execute the sample query.
    rate = fx_service.query(*query)

    # Make the assertion.
    assert rate == FXRate.of(*query, Decimal("1.5"))

# Generated at 2022-06-12 06:17:53.142888
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .commons.zeitgeist import NOW
    from .currencies import EUR, USD
    from .forex.forex import ForexRateService
    urate = FXRate(USD, EUR, NOW, Decimal("1.1"))
    srate = FXRate(EUR, USD, NOW, Decimal("0.9"))
    queries = [(EUR, USD, NOW), (USD, EUR, NOW)]
    foreign_exchange = ForexRateService(rates=[urate, srate])
    assert [srate, urate] == foreign_exchange.queries(queries)

# Generated at 2022-06-12 06:17:54.158152
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:18:02.478609
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from nose.tools import assert_equal, assert_is_instance, assert_raises
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.commons.temporal import Date
    from pypara.fxrates import FXRate, FXRateLookupError

    class FXRateServiceMock(FXRateService):
        """
        Provides a mockup foreign exchange rate service for testing.
        """

        #: Defines the foreign exchange rate map.

# Generated at 2022-06-12 06:18:12.083060
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.values import Temporal
    from pypara.fx import FXRateService
    from pypara.services.fx import DummyFXRateService

    ## Setup arguments:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]
    asof = Temporal.from_date(from_date=Date.from_date(2018, 9, 1))

    ## Setup FX rate service:

# Generated at 2022-06-12 06:18:24.806024
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    print ("Executing test_FXRateService_query...")
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService
    from pypara.temporals import Date
    from decimal import Decimal
    from datetime import date
    class DummyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if (ccy1, ccy2, asof) == (Currencies["EUR"], Currencies["USD"], date.today()):
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

# Generated at 2022-06-12 06:18:26.316076
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:19:48.160020
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import unittest

    class FXRateServiceImpl(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            pass

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False):
            for query in queries:
                yield None

    service = FXRateServiceImpl()

    class FxRateServiceTestCase(unittest.TestCase):
        def test_empty_queries(self):
            for rate in service.queries([]):
                self.fail(f"Unexpcted rate: `{rate}`")

    unittest.main()

# Generated at 2022-06-12 06:19:58.787924
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.dates import ISO8601Date
    from pypara.finance.fx.in_memory import InMemoryFXRateService
    from unittest import TestCase, main

    class FXRateServiceTests(TestCase):

        def test_query_should_return_none_for_non_existent_rate(self):
            ## Arrange:
            fxrates = InMemoryFXRateService({(Currency('EUR'), Currency('USD'), ISO8601Date('2019-12-31')): Decimal('1.10000'),  # noqa
                                             (Currency('GBP'), Currency('USD'), ISO8601Date('2019-12-31')): Decimal('1.300000')})  # noqa

            ## Act:
            rate = f

# Generated at 2022-06-12 06:20:06.435345
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal

    from pypara.currencies import Currencies

    eur_usd = (Currencies["EUR"], Currencies["USD"], datetime.date.today())
    gbp_usd = (Currencies["GBP"], Currencies["USD"], datetime.date.today())

    class DummyFXRateService(FXRateService):
        """
        Provides a dummy implementation of FX rate service for unit testing.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the dummy FX rate service.

            :param rates: An iterable of :class:`FXRate` instances.
            """
            self._rates: Tuple[FXRate, ...] = tuple(rates)


# Generated at 2022-06-12 06:20:16.683547
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.util.fx_rates import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Decimal:
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                return Decimal("0.8859")
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return Decimal("1.1269")
            if ccy1 == Currencies["TRY"] and ccy2 == Currencies["EUR"]:
                return Decimal("0.1925")