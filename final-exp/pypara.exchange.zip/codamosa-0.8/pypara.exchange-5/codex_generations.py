

# Generated at 2022-06-12 06:10:28.657158
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    raise NotImplementedError


# Generated at 2022-06-12 06:10:29.866757
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa: D103
    pass


# Generated at 2022-06-12 06:10:39.344580
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """Unit test for method queries of class FXRateService."""
    # References
    from .currencies import Currency, Currencies
    from .temporal import Date

    # Global variables
    queries = [
        (Currencies["EUR"], Currencies["USD"], Date(2020, 9, 30)),
        (Currencies["EUR"], Currencies["USD"], Date(2020, 10, 1)),
        (Currencies["EUR"], Currencies["USD"], Date(2020, 10, 2))
    ]

    class CustomFXRateService(FXRateService):
        """
        Custom FX rate service for unit testing.
        """


# Generated at 2022-06-12 06:10:50.480946
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests :method:`FXRateService.query` method of the :class:`FXRateService` class.
    """

    from .currencies import Currencies

    from .core.fxrate import FXRateService as FXRateService_
    from .core.fxrate import FXRateServiceError
    from .core.fxrate import FXRateServiceType

    service = FXRateService(FXRateServiceType.LocalFXRateService)
    assert issubclass(FXRateService_, FXRateService)

    with service:

        ## Lookup 1:
        rate = service.query(Currencies["EUR"], Currencies["USD"], Date.today())
        assert rate is not None
        assert rate.value > ZERO

        ## Lookup 2:

# Generated at 2022-06-12 06:11:02.350547
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.sdk.fx import FXRate

    class FXRateServiceMock(FXRateService):
        def __init__(self, queries: Iterable[FXRateService.TQuery]) -> None:
            self.queries = queries

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            for query in self.queries:
                if ccy1 == query[0] and ccy2 == query[1] and asof == query[2]:
                    if ccy1 == ccy2:
                        return FXRate(ccy1, ccy2, asof, Decimal("1"))

# Generated at 2022-06-12 06:11:10.639070
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .commons.zeitgeist import Date
    from .exchanged import FXRate, FXRateLookupError, FXRateService
    from decimal import Decimal
    class TestService(FXRateService):
        def queries(self, queries, strict = False):
            for (ccy1, ccy2, asof) in queries:
                if (ccy1, ccy2, asof) == (Currency('USD'), Currency('EUR'), Date('2000-01-10')):
                    return [FXRate(Currency('USD'), Currency('EUR'), Date('2000-01-10'), Decimal('2'))]

# Generated at 2022-06-12 06:11:21.309699
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ##
    ## 1. Test a successful query
    ##
    from unittest.mock import MagicMock
    from decimal import Decimal
    from datetime import date
    from pypara.currencies import Currencies

    ## Create a mock FX rate service:
    service = MagicMock(FXRateService)

    ## Create the FX rate service behavior:
    service.query.return_value = FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("1.1"))

    ## Do the actual query:
    assert service.query(Currencies["EUR"], Currencies["USD"], date.today()) == \
           FXRate(Currencies["EUR"], Currencies["USD"], date.today(), Decimal("1.1"))

    ## Check the method calls:
    service.query.assert_called_once_

# Generated at 2022-06-12 06:11:29.815975
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService abstract class.
    """
    import datetime
    from decimal import Decimal
    from unittest.mock import Mock
    from pypara.currencies import Currencies
    # Create a mock of a FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            return FXRate(ccy1, ccy2, asof, Decimal("1.23"))
        def queries(self, queries, strict = False):
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal("1.23"))
    mock = MockFXRateService()
    # Create a date variable for use in the test:

# Generated at 2022-06-12 06:11:41.208981
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class Mocked(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            rates = []
            for ccy1, ccy2, asof in queries:
                rates.append(self.query(ccy1, ccy2, asof, strict))
            return rates


# Generated at 2022-06-12 06:11:43.227018
# Unit test for method query of class FXRateService
def test_FXRateService_query(): pass

# Generated at 2022-06-12 06:11:59.882284
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit tests the method `query` of class FXRateService.
    """
    # noinspection PyUnusedLocal
    class Test(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            pass

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    # Assert that we can not create and instance of FXRateService
    try:
        FXRateService()
        assert False
    except TypeError:
        assert True

    # Assert that we can not create and instance of FXRateService
    try:
        Test()
        assert False
    except TypeError:
        assert True

    # Add default FX rate service to

# Generated at 2022-06-12 06:12:09.743489
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests if queries function of the class FXRateService returns foreign exchange rates for a given collection of currency pairs and dates.

    This is done by testing the queries function, through currency pairs and dates, and checking if the results
    are, as expected, rates.
    """
    ## Import modules needed by the unittest
    import unittest
    from decimal import Decimal
    from pypara.currencies import AUD, USD
    import datetime
    from pypara.fxrates import FXRate, FXRateLookupError, FXRateService

    ## Test simple queries:
    class TestFXRateService(FXRateService):
        """
        Implements the :class:`FXRateService` abstract class for testing purposes.
        """


# Generated at 2022-06-12 06:12:19.346795
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    ## Create a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            pass
        def queries(self, queries, strict=False):
            return [None]*len(queries)

    ## Create a dummy FX rate service instance:
    service = DummyFXRateService()

    ## Get the queries iterable:
    queries = FXRateService.TQuery((Currency("XXX"), Currency("YYY"), Date("2000-01-01")))
    rates = service.queries(queries)
    assert len(rates) == 1
    assert rates[0] is None

    ## Get the queries tuple:

# Generated at 2022-06-12 06:12:23.902012
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .refdata.static import StaticRates
    import datetime
    from decimal import Decimal
    sr = StaticRates()
    rate = sr.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert(isinstance(rate, FXRate))
    assert(rate.value == Decimal("1.187"))



# Generated at 2022-06-12 06:12:33.349007
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Check the query method of the FXRateService class.
    """

    # Import the typing module:
    from typing import TYPE_CHECKING

    # If we are not type checking, then return:
    if TYPE_CHECKING:
        return

    # Import useful modules:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fx import FXRate, FXRateService

    # Define a FX rate service:
    class TestFXRateService(FXRateService):
        """
        Provides a FX rate service implementation.
        """


# Generated at 2022-06-12 06:12:43.254548
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """
    import pytest
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class _FXRateService(FXRateService):
        """
        Provides a dummy implementation of FXRateService for testing.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns the foreign exchange rate of a given currency pair as of a given date.
            """

# Generated at 2022-06-12 06:12:45.349294
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # TODO: Implement unit test

    # For now, just stub:
    pass



# Generated at 2022-06-12 06:12:58.248597
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currency, EUR, USD
    from pypara.finance import FXRateService

    eur = Currency(EUR['name'], EUR['code'], EUR['num'], EUR['digits'], EUR['rounding'], EUR['cash_rounding'], EUR['cash_digits'])
    usd = Currency(USD['name'], USD['code'], USD['num'], USD['digits'], USD['rounding'], USD['cash_rounding'], USD['cash_digits'])

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            from pypara.finance import FX

# Generated at 2022-06-12 06:12:59.365724
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # To do
    pass



# Generated at 2022-06-12 06:13:10.767458
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This unit test verifies the method queries of class FXRateService.
    """
    ## Should work:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance import FXRateService

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
            return None


# Generated at 2022-06-12 06:13:31.559038
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime as dt
    from decimal import Decimal
    from pypara.currencies import Currencies, CurrencyPair

    currency_pair_1 = CurrencyPair(Currencies["EUR"], Currencies["USD"])
    currency_pair_2 = CurrencyPair(Currencies["USD"], Currencies["EUR"])
    date = dt.date.today()
    value = Decimal("2")


# Generated at 2022-06-12 06:13:44.592329
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.currencies import Currencies
    from pypara.fx import FXRate
    from pypara.temporal import Date

    ## Define the rate service:
    class TestFXRateService(FXRateService):
        """
        Provides a test implementation of :class:`FXRateService`.
        """

        ###
        # Private Attributes
        ###


# Generated at 2022-06-12 06:13:55.497364
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit tests the query method of :class:`FXRateService`.
    """
    from dateutil.parser import parse
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService

    ## An FX rate service:
    class MyFXRateService(FXRateService):  # noqa: WPS214
        """
        Provides a mock FX rate service.
        """

        def query(self, ccy1, ccy2, asof):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == parse("2018-01-01").date():
                return FXRate(Currencies["EUR"], Currencies["USD"], parse("2018-01-01").date(), Decimal("1.20"))

# Generated at 2022-06-12 06:13:57.596890
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests methods of :class:`FXRateService`.
    """
    pass

# Generated at 2022-06-12 06:14:08.349931
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    class LocalFXRateService(FXRateService):
        """
        Provides a local implementation of a foreign exchange rate service for unit testing.
        """


# Generated at 2022-06-12 06:14:19.714017
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies


    class TestFXRateService(FXRateService):
        """
        A minimalistic test FX rate service.
        """


# Generated at 2022-06-12 06:14:29.890463
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency

    from .services import FXRateService as _FXRateService, FXRateLookupError as _FXRateLookupError

    class TestFXRateService(_FXRateService):  # type: ignore
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            raise NotImplementedError

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return super().queries(queries, strict=strict)

    ## Check if we get all rates:
    service = TestFXRateService()
    assert list(service.queries([(Currency("EUR"), Currency("USD"), Date()), (Currency("TRY"), Currency("USD"), Date())]))

# Generated at 2022-06-12 06:14:38.953453
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2017, 1, 1):
                return FXRate(Currencies["EUR"], Currencies["USD"], Date(2017, 1, 1), Decimal("2"))

# Generated at 2022-06-12 06:14:50.397860
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime

    from decimal import Decimal

    from pypara.currencies import Currencies

    from .commons.zeitgeist import Date

    ## Create a query:
    query = ((Currencies["EUR"], Currencies["USD"], Date.of(datetime.date.today())),)

    ## Create an FX rate service:
    class Test(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, Date.of(asof), Decimal("1"))


# Generated at 2022-06-12 06:14:59.598573
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from pypara.currencies import Currency, Currencies
    from pypara.temporals import Date
    class Service(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(2))
        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [FXRate(ccy1, ccy2, date, Decimal(2)) for (ccy1, ccy2, date) in queries]

# Generated at 2022-06-12 06:15:18.432285
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency
    from .services.fxrateservice import StaticFXRateService

    fx = StaticFXRateService()
    assert fx.query(Currency.xEUR, Currency.xUSD, Date(2019, 1, 1)) is not None



# Generated at 2022-06-12 06:15:20.605070
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method :method:`FXRateService.query` of class :class:`FXRateService`.
    """
    pass



# Generated at 2022-06-12 06:15:26.110916
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests that method queries of class FXRateService raises NotImplementedError.
    """
    from unittest import TestCase
    class FXRateServiceSubclass(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            pass
    TestCase().assertRaises(NotImplementedError, FXRateServiceSubclass().queries, [])


# Generated at 2022-06-12 06:15:36.683033
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateLookupError, FXRateService

    # Local implementation for test purpose
    class FXRateServiceLocal(FXRateService):
        """
        Provides a local implementation of :class:`FXRateService`.
        """


# Generated at 2022-06-12 06:15:48.113119
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    import pytest
    from .currencies import Currencies
    from .dates import Date

    class TestFXRateService(FXRateService):

        def __init__(self, rates: Iterable[FXRate]):
            self.__rates = {(r.ccy1, r.ccy2, r.date): r for r in rates}

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if strict:
                return self.__rates[(ccy1, ccy2, asof)]
            else:
                return self.__rates.get((ccy1, ccy2, asof))


# Generated at 2022-06-12 06:16:00.423609
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate, FXRateService

    ## Define a custom FX rate service:
    class CustomFXRateService(FXRateService):
        _rates = {
            (
                Currencies["EUR"],
                Currencies["USD"],
                datetime.date.today()
            ): FXRate.of(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
            (
                Currencies["USD"],
                Currencies["EUR"],
                datetime.date.today()
            ): FXRate.of(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))}


# Generated at 2022-06-12 06:16:04.495812
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # Set up
    from .currencies import Currency
    ccy1 = Currency(iso="XXX")
    ccy2 = Currency(iso="YYY")
    date = Date.today()
    strict = False

    # Exercise
    T = type("T", (FXRateService,), {"query": FXRateService.query})
    t = T()

    # Verify
    with t.assertRaises(NotImplementedError):
        t.query(ccy1, ccy2, date, strict)


# Generated at 2022-06-12 06:16:12.097760
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Temporals

    from unittest.mock import Mock

    # Validate method query with a query that does not exist
    fxRateService = Mock(FXRateService)
    fxRateService.query(Currencies["EUR"], Currencies["USD"], Temporals.today()).return_value = None
    assert fxRateService.query(Currencies["EUR"], Currencies["USD"], Temporals.today()) == None



# Generated at 2022-06-12 06:16:23.436806
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.foreign_exchange import FXRateService


# Generated at 2022-06-12 06:16:34.067684
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from unittest.mock import Mock

    ## Create a mock:
    mfx = Mock(spec=FXRateService)
    assert isinstance(mfx, FXRateService)

    ## Set return values:
    mfx.query.return_value = FXRate("CCY/1", "CCY/2", Date.today(), Decimal("1"))

    ## Execute the method:
    fx = mfx.query("CCY/1", "CCY/2", Date.today(), False)
    assert fx is not None
    assert fx.value == 1


# Generated at 2022-06-12 06:17:20.121451
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    import datetime
    from decimal import Decimal
    from pypara.fx.rates.in_memory import InMemoryFXRateService
    fx_rate_service = InMemoryFXRateService()
    fx_rate_service.put(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    res = fx_rate_service.queries([(Currencies["EUR"], Currencies["USD"], datetime.date.today())])

    assert next(res) == FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

# Generated at 2022-06-12 06:17:28.464355
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .currencies import Currency
    from .temporals import Date

    ## Create mocks:
    class MFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, 1)

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    ## Create the FX rate service:
    FX_RATE_SERVICE = MFXRateService()

    ## Create query:
    QUERY = (Currency("EUR"), Currency("USD"), Date(2020, 1, 1))

    ## Query:

# Generated at 2022-06-12 06:17:29.803563
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    assert False, "FIXME"



# Generated at 2022-06-12 06:17:39.389701
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from pypara.temporals import date

    rate = FXRate.of(Currencies["EUR"], Currencies["USD"], date(2014, 1, 1), 2)

    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return rate if (ccy1 == rate.ccy1 and ccy2 == rate.ccy2 and asof == rate.date) else None

    mock = MockFXRateService()
    fx_rate = mock.query(Currencies["EUR"], Currencies["USD"], date(2014, 1, 1))
    assert fx_rate

    fx_rate = mock.query(Currencies["EUR"], Currencies["USD"], date(2014, 1, 2))


# Generated at 2022-06-12 06:17:46.663441
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date
    from .currencies import CurrencyService
    from .fxrates import FXRateService
    from .fxrates import InvertedFXRateService
    from .fxrates import SpotFXRateService

    ## Create a currency service:
    services = CurrencyService.defaults()

    ## Create currency pair:
    ccy1 = services.query("EUR")
    ccy2 = services.query("USD")

    ## Create a date:
    asof = Date.today()

    ## Create a FX rate service:
    service = InvertedFXRateService(SpotFXRateService())

    ## Query FX rate:
    rate = service.query(ccy1, ccy2, asof)
    assert rate.ccy1 == ccy1
    assert rate.ccy2 == ccy2
   

# Generated at 2022-06-12 06:17:58.814540
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date

    from decimal import Decimal

    from unittest.mock import Mock

    rate_service = Mock()  # type: FXRateService

    queries = [
        (Currency('EUR'), Currency('USD'), Date(2018, 1, 1),),
        (Currency('EUR'), Currency('USD'), Date(2018, 1, 2),),
    ]

    rates = [
        FXRate(Currency('EUR'), Currency('USD'), Date(2018, 1, 1), Decimal('2')),
        FXRate(Currency('EUR'), Currency('USD'), Date(2018, 1, 2), Decimal('2')),
    ]

    rate_service.queries.return_value = iter(rates)

    rate_service.queries.assert_not_called()


# Generated at 2022-06-12 06:18:09.900369
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests if queries method works.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    class _TestFXRateService(FXRateService):
        """
        Provides a test implementation of foreign exchange rate service.
        """
        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the test foreign exchange rate service.
            """
            self._rates = rates


# Generated at 2022-06-12 06:18:22.229117
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Import needed types:
    from unittest.mock import call, patch, sentinel

    # Import tested module:
    from pypara.fx.conversion import FXRateService

    # Create some dummy type instance:
    class DummyType(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return sentinel.rate
        def queries(self, queries, strict=False):
            return [sentinel.rate]
    instance = DummyType()

    # Call the tested function with mocked function query:
    with patch.object(FXRateService, "query") as mocked_query:
        # Call the tested function:
        it = instance.queries(sentinel.queries, sentinel.strict)
        # Check that the expected queries are made by tested function to the mocked

# Generated at 2022-06-12 06:18:34.242672
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of class :class:`FXRateService`.
    """
    # Create a query:
    import datetime
    from pypara.currencies import Currencies

    query = [(Currencies["EUR"], Currencies["USD"], datetime.date.today())]

    # Create a service:
    class TestService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries, strict=False):
            return (self.query(ccy1, ccy2, asof) for (ccy1, ccy2, asof) in queries)

    service = TestService()

    # Test the service:

# Generated at 2022-06-12 06:18:40.355872
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.inmemory import InMemoryFXRateService
    from pypara.fx.rates import FXRates

    usd_jpy = FXRates.generate(ccy1=Currencies["USD"], ccy2=Currencies["JPY"], date=datetime.date.today(), value=Decimal("109.1"))

    eur_usd = FXRates.generate(ccy1=Currencies["EUR"], ccy2=Currencies["USD"], date=datetime.date.today(), value=Decimal("1.12"))

# Generated at 2022-06-12 06:20:13.200755
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.temporals import Date
    from pypara.fx.services import FXRateService

    class TestService(FXRateService):
        def __init__(self):
            self._rates = {}

        def add(self, rate: FXRate) -> None:
            self._rates[(rate.ccy1, rate.ccy2, rate.asof)] = rate

        def remove(self, rate: FXRate) -> None:
            try:
                del self._rates[(rate.ccy1, rate.ccy2, rate.asof)]
            except KeyError:
                pass


# Generated at 2022-06-12 06:20:15.575997
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # This unit test is commented out because it is too difficult to use a mock with the abstract base class.
    # I am leaving it here for documentation purposes.

    pass


# Generated at 2022-06-12 06:20:25.778609
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime

    from decimal import Decimal
    from pypara.currencies import Currencies

    from .commons.zeitgeist import Date

    ## Create an FX rate service:
    class MockFXRService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.23"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield FXRate(query[0], query[1], query[2], Decimal("1.23"))

    ## Create an FX rate service instance: