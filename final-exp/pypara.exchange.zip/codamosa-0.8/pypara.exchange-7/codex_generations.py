

# Generated at 2022-06-12 06:10:34.783832
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Test fx.FXRateService.queries method.
    """
    ## Create a stub FX rate service:
    class StubFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            ## Implement the query functionality:
            return Decimal(1.2)

        #: Override the queries method:
        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            ## Iterate over the queries:
            for query in queries:
                ## Query the FX rate from the service:
                yield self.query(*query)

    ## Create a stub FX rate service:
    service = StubFXRateService()

    ## Create

# Generated at 2022-06-12 06:10:42.004036
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .commons.zeitgeist import TodaysDate
    from .currencies import Currencies
    from .fxrates import FXRates

    ## Create a dummy FX rate service object:
    class DummyFXRateService(FXRateService):
        def __init__(self, rates: Iterable[FXRate]) -> None:
            self._rates = dict((((rate.ccy1, rate.ccy2, rate.date), rate) for rate in rates))

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return self._rates.get((ccy1, ccy2, asof))


# Generated at 2022-06-12 06:10:53.191416
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests method query of class FXRateService.
    """

    from unittest import TestCase, mock

    from pypara.commons.zeitgeist import Temporals
    from pypara.currencies import Currencies

    from .fxrates import FXRateService

    # noinspection PyAbstractClass
    class FXRateServiceImpl(FXRateService):

        def __init__(self, rates: Iterable[FXRate]) -> None:
            self.rates = rates

        def query(self, ccy1: Currency, ccy2: Currency, asof: Temporal, strict: bool = False) -> Optional[FXRate]:
            for rate in self.rates:
                if ccy1 == rate.ccy1 and ccy2 == rate.ccy2 and asof == rate.date:
                    return rate

# Generated at 2022-06-12 06:11:04.313093
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    This function performs unit testing for :class:`FXRateLookupError`.
    """

    from .currencies import Currencies
    from .commons.zeitgeist import Date

    ## Create FX rate service:
    class FXRateServiceImpl(FXRateService):
        """
        Test implementation of FXRateService.
        """

        #: Keeps the FX rates.

# Generated at 2022-06-12 06:11:16.874821
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    '''
    Tests method queries of class FXRateService.
    '''
    import datetime
    import random
    import string

    from decimal import Decimal
    from pypara.fx.quandl import QuandlFXRateService
    from pypara.currencies import Currencies

    ## Set the date:
    date = datetime.date(2018, 7, 18)

    ## Prepare the query for EUR/USD:
    ccy1, ccy2 = Currencies["EUR"], Currencies["USD"]
    eur_usd_rate = Decimal(random.random())
    query = (ccy1, ccy2, date)

    ## Set up a test fx rate service:

# Generated at 2022-06-12 06:11:27.723107
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date

    from decimal import Decimal

    class FXRateServiceTest(FXRateService):
        """
        Provides a test implementation for foreign exchange rate service.
        """

        def query(self, ccy1, ccy2, asof, strict):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

    fxrs = FXRateServiceTest()
    assert fxrs.query(Currencies["EUR"], Currencies["USD"], Date.today(), False) == FXRate(Currencies["EUR"], Currencies["USD"], Date.today(), Decimal("2"))


# Generated at 2022-06-12 06:11:39.641839
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from pypara.currencies import Currencies
    from .values import Temporal
    from .commons.zeitgeist import Date
    from .domain.financial import FXRateService
    import datetime

    class TestRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            rate: Optional[FXRate] = None
            if (ccy1, ccy2, asof) == (Currencies['EUR'], Currencies['USD'], Date(datetime.date(2020, 1, 1))):
                rate = FXRate.of(ccy1, ccy2, Temporal.of(asof), Decimal('1.1'))

# Generated at 2022-06-12 06:11:51.033843
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests :method:`FXRateService.queries`.
    """
    #
    # Define a query:
    #
    tq = (Currency.of("EUR"), Currency.of("USD"), Date())

    #
    # Define a query service:
    #
    class __QueryService(FXRateService):  # NOQA
        """
        Provides an implementation of :class:`FXRateService` to test :method:`FXRateService.queries`.
        """

        def query(self, ccy1, ccy2, asof, strict=False):
            raise NotImplementedError()

        def queries(self, queries, strict=False):
            for tq in queries:
                yield FXRate(*tq)

    #
    # Create the query service:
    #

# Generated at 2022-06-12 06:12:03.083527
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRate
    from pypara.fxrates.inmemory import InMemoryFXRateService

    fxrates = list()


# Generated at 2022-06-12 06:12:11.679766
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency

    from datetime import date

    from decimal import Decimal

    from .fxrates import FXRateService

    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("0.5"))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield self.query(query[0], query[1], query[2], strict)

    from .currencies import Currencies

    FXRateService.default = TestFXRateService()

# Generated at 2022-06-12 06:12:27.591373
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from pyexchange.date import Temporals
    from pyexchange.fx import FXRateService
    from pyexchange.fx.convention import CurrencyConventions
    from pyexchange.fx.models import FXRateModel
    from pyexchange.fx.rates import FXRates
    from pyexchange.numbers import ZERO
    from pyexchange.temporal import Temporal
    from pypara.currencies import Currencies
    from pypara.date import Dates


# Generated at 2022-06-12 06:12:39.455384
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency, Currencies
    from .temporal import T, Temporal, TemporalFactory
    from .fxrates import FXRate, FXRateService

    ## Define a test FX rate service class:
    class TestFXRateService(FXRateService):

        def __init__(self):
            """ Initializes the test FX rate service. """

# Generated at 2022-06-12 06:12:52.414527
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests queries method of :class:`FXRateService`.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Define simple foreign exchange rate service:
    class SimpleFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"]:
                if asof == datetime.date(2019, 4, 4):
                    return FXRate(Currencies["EUR"], Currencies["USD"], datetime.date(2019, 4, 4), Decimal("1.56"))

# Generated at 2022-06-12 06:13:05.437875
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestSuite, makeSuite
    from unittest.mock import MagicMock, call, patch
    from decimal import Decimal

    from pypara.currencies import Currency, Currencies
    from pypara.markets.fx.pricingservice import PricingService

    class MockPricingService(PricingService):
        """
        Provides a unit-test mock pricing service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            """
            Returns a foreign exchange rate for a given currency pair and date.
            """

# Generated at 2022-06-12 06:13:10.214068
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """Unit test case for method query of class FXRateService."""
    # Import packages
    import concurrent.futures
    import unittest

    # Import modules
    from pypara.commons.structs import TupleList
    from pypara.currencies import Currencies
    from pypara.curves.fx import FXRate
    from pypara.curves.fx import FXRateService
    from pypara.curves.fx import FXRateLookupError
    from pypara.temporal import Date, TimeSpan

    # Class to represent an FX rate service.
    class TestFXRateService(FXRateService):
        """Provides an FX rate service for testing purposes."""


# Generated at 2022-06-12 06:13:20.684921
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests if FXRateService.queries works as expected.
    """
    ## noinspection PyUnresolvedReferences
    from .currencies import Currencies
    from .services.in_memory_fx_rate_service import InMemoryFXRateService
    from .commons.zeitgeist import ZEITGEIST as Z
    ## Create the service:

# Generated at 2022-06-12 06:13:33.153847
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, mock
    from tempfile import TemporaryDirectory
    from zipfile import ZipFile
    from .commons.temporal import Temporal
    from .currencies import Currencies
    from .curves.factory import CurveFactory
    from .data.curve import CURVE_DATA
    from .rates.factory import CurveRateServiceFactory, RateServiceFactory
    from .rates.repositories import CurveRateServiceRepository

    with TemporaryDirectory() as tmpdir:
        store = f"{tmpdir}/store"
        with ZipFile(CURVE_DATA["path"], "r") as zipfile:
            zipfile.extractall(tmpdir)
        service = RateServiceFactory.bootstrap(store, CurveFactory)
        assert service is not None
        assert isinstance(service, CurveRateServiceRepository)

# Generated at 2022-06-12 06:13:45.574355
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        (Currencies["EUR"], Currencies["USD"], datetime.date.today() - datetime.timedelta(days=1)),
        (Currencies["EUR"], Currencies["USD"], datetime.date.today() - datetime.timedelta(days=2)),
        (Currencies["EUR"], Currencies["USD"], datetime.date.today() - datetime.timedelta(days=3)),
    ]

    r = FXRateService.__subclasses__()[0](queries)

    rates = r.queries(queries, strict=True)


# Generated at 2022-06-12 06:13:56.104456
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class Service(FXRateService):
        FXRATES = (
            FXRate(Currency.of("EUR"), Currency.of("USD"), Date.of(2020, 1, 1), Decimal("1.2")),
            FXRate(Currency.of("EUR"), Currency.of("USD"), Date.of(2020, 1, 2), Decimal("1.4")),
            FXRate(Currency.of("EUR"), Currency.of("USD"), Date.of(2020, 1, 3), Decimal("1.6"))
        )

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            query = (ccy1, ccy2, asof)

# Generated at 2022-06-12 06:14:07.612738
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .currencies.currencies import MUR, USD
    from .currencies.currencies import Currencies
    from .temporal import Temporal
    from pypara.temporal import Date
    import datetime
    from decimal import Decimal
    today = Date(datetime.date.today())
    queries = [(USD, MUR, today), (MUR, USD, today), (MUR, USD, today)]
    rates = [(None, None, None), (None, None, None), (None, None, None)]
    _test_FXRateService_queries_helper(queries, rates, strict=False)
    _test_FXRateService_queries_helper(queries, rates, strict=True)

# Generated at 2022-06-12 06:14:15.739904
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass

# Generated at 2022-06-12 06:14:24.090047
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import unittest
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.curves import NullCurve
    from pypara.fx import FXRateService, FXRate

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == date(2020, 10, 31):
                return FXRate.of(ccy1, ccy2, asof, Decimal("1.25"))
            else:
                return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False):
            fx

# Generated at 2022-06-12 06:14:35.969351
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the query method of the FX rate service.
    """
    # Setup the service:
    class TestFXRateService(FXRateService):
        """
        Provides a test foreign exchange rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            yield from (None for _ in queries)

    # Create the service:
    service = TestFXRateService()

    # Test invalid FX rate arguments:
    from pypara.currencies import Currencies  # noqa: E402
    from pypara.commons.zeitgeist import TODAY  # noqa: E

# Generated at 2022-06-12 06:14:48.064977
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    #noinspection PyUnresolvedReferences
    from pypara.currencies import Currencies

    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == Date(2019, 1, 1):
                return FXRate.of(Currencies["EUR"], Currencies["USD"], Date(2019, 1, 1), Decimal("0.8"))
            return None

    service = MockFXRateService()
    rate = service.query(Currencies["EUR"], Currencies["USD"], Date(2019, 1, 1))
    assert rate.ccy1 == Currencies["EUR"]

# Generated at 2022-06-12 06:14:56.560471
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates import FXRateService

    class RateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate.of(ccy1, ccy2, asof, Decimal("2"))
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool):
            return [None for _ in queries]

    rate_service = RateService()


# Generated at 2022-06-12 06:14:58.049219
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    print('Testing FXRateService.query')


# Generated at 2022-06-12 06:15:08.721054
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from hypothesis import given
    from hypothesis.strategies import integers, lists, tuples
    from decimal import Decimal
    from pypara.currencies import Currency
    from pypara.temporal import Date
    import datetime

    class Instrument:
        """Implements an instrument model"""

        def __init__(self, ccy: Currency, amt: Decimal) -> None:
            """Initializes the instrument."""
            self.ccy = ccy
            self.amt = amt

    class FXRateService(metaclass=ABCMeta):
        """Provides an abstract class for serving foreign exchange rates."""


# Generated at 2022-06-12 06:15:10.446745
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """Unit test for method query of class FXRateService"""
    pass


# Generated at 2022-06-12 06:15:21.210829
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies

    from .datetime import Date

    from .fxrates import FXRate

    ## Prepare the variables:

# Generated at 2022-06-12 06:15:29.806871
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests abstract method `query` of class :class:`FXRateService`.
    """
    # Importing modules:
    import datetime
    import decimal
    import pytest
    from pypara.currencies import Currencies

    # Attempts to instantiate an abstract class:
    with pytest.raises(TypeError):
        FXRateService()

    # Querying for foreign exchange rate as of today:
    rate = FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert rate.ccy1 == Currencies["EUR"]
    assert rate.ccy2 == Currencies["USD"]
    assert rate.value == decimal.Decimal("0.903")

# Generated at 2022-06-12 06:15:52.156917
# Unit test for method queries of class FXRateService

# Generated at 2022-06-12 06:16:03.205876
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.

    >>> import datetime
    >>> from decimal import Decimal
    >>> from pypara.currencies import Currencies
    >>> from pypara.fx import FXRateService, FXRateLookupError
    >>> rate = FXRateService.default = FXRateService()
    >>> rate.queries([("EUR", "USD", datetime.date.today())], strict=True)
    Traceback (most recent call last):
        ...
    pypara.fx.FXRateLookupError: Foreign exchange rate for EUR/USD not found as of 2019-11-24
    >>> rate.queries([("EUR", "USD", datetime.date.today())], strict=False)
    [None]
    """
    pass

# Generated at 2022-06-12 06:16:15.105754
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
    test_fx_rate_service = TestFXRateService()
    today = datetime.date.today()
    assert test_fx_rate_service.query(Currencies["EUR"], Currencies["USD"], today) == FXRate(Currencies["EUR"], Currencies["USD"], today, Decimal("1.1"))

# Generated at 2022-06-12 06:16:24.509731
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from random import choices
    from random import seed
    from random import normalvariate
    from random import triangular
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fxrates.services.inbuilt import InbuiltFXRateService
    from pypara.temporal import Temporal
    from pypara.utils.timeseries import IndexedTimeseries

    # Create an FX rate service and fill it with some data:
    fxrate_service = InbuiltFXRateService()
    for i in range(1000):
        fxrate_service.add(
            FXRate(
                Currencies.EUR,
                Currencies.USD,
                date.fromordinal(int(temporal.ordinal)),
                Decimal(str(fxrate)),
            )
        )

# Generated at 2022-06-12 06:16:37.002335
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies

    ## Create a dummy FX rate service that always returns two:
    class DummyFXRateService(FXRateService):
        def query(self, *args, **kwargs):
            return FXRate(Currencies["USD"], Currencies["TRY"], Date(2015, 1, 1), Decimal("2"))

    fx = DummyFXRateService()

    ## Non-strict query:
    assert fx.query(Currencies["USD"], Currencies["TRY"], Date(2015, 1, 1)) == \
        FXRate(Currencies["USD"], Currencies["TRY"], Date(2015, 1, 1), Decimal("2"))

    ## Non-strict query with lack of FX rate:
    assert fx.query(Currencies["USD"], Currencies["TRY"], Date(2014, 12, 31)) is None

    ##

# Generated at 2022-06-12 06:16:38.657107
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService
    """
    assert False
## TODO: Implement unit test.

# Generated at 2022-06-12 06:16:50.139571
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    from pypara.currencies import Currency, Currencies
    from pypara.temporal import Date
    from pypara.services.fxrates.dummy import DummyFXRateService

    fxrs = DummyFXRateService()

    ## Test if query method raises a runtime error if the foreign exchange rate can not be found
    ## and the strict flag is not set.
    rate = fxrs.query(Currency("ABC"), Currency("XYZ"), Date.today())
    assert rate is None, "DummyFXRateService.query must return None if the strict flag is not set."

    ## Test if query method raises a lookup error if the foreign exchange rate can not be found
    ## and the strict flag is set.

# Generated at 2022-06-12 06:17:02.391495
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of :class:`FXRateService`
    """


# Generated at 2022-06-12 06:17:10.499069
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from decimal import Decimal
    from unittest import mock

    fx_rate_service = FXRateService()

    with mock.patch.object(fx_rate_service, "query") as mock_query:
        mock_query.return_value = Decimal("1.3")
        results = [r for r in fx_rate_service.queries([])]
        assert 0 == len(results)

        mock_query.return_value = None
        results = [r for r in fx_rate_service.queries([(None, None, None)])]
        assert 1 == len(results) and None == results[0]

        mock_query.return_value = None
        results = [r for r in fx_rate_service.queries(iter([(None, None, None)]))]
        assert 1 == len

# Generated at 2022-06-12 06:17:23.387966
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance import FXRateService
    from pypara.finance.services import LocalFXRateService

    class EchoFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal("1"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for query in queries:
                yield self.query(*query, strict)

    echo = EchoFXRateService()

# Generated at 2022-06-12 06:17:56.276603
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    rrate = FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
    rate = PyPara.FXRateService.default.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())
    assert(rate == rrate)


# Generated at 2022-06-12 06:18:04.047762
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    class Mockup(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return None

    fxr = Mockup()
    fxr.query(None, None, None)


# Generated at 2022-06-12 06:18:12.692251
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .fx import FXRate
    from .temporal import Date

    # Define fixtures
    queries = [
        (Currencies["EUR"], Currencies["USD"], Date("2019-01-01")),
        (Currencies["USD"], Currencies["GBP"], Date("2019-02-01")),
    ]

    class Mock(FXRateService):

        def __init__(self) -> None:
            self.query_index = 0
            self.rates = [
                FXRate(Currencies["EUR"], Currencies["USD"], Date("2019-01-01"), Decimal("2")),
                FXRate(Currencies["USD"], Currencies["GBP"], Date("2019-02-01"), Decimal("1.5")),
            ]


# Generated at 2022-06-12 06:18:25.194317
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal   import Decimal
    from unittest2 import TestCase, main
    from pypara.commons.numbers import ONE, ZERO
    from pypara.currencies import Currency, Currencies
    from pypara.currencies.exchange import FXRate

    class Foo(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            pass

    class TestQuery(TestCase):

        def test_FXRateService_query_happy_path(self):

            ## Create an empty FX rate service instance:
            service = Foo()

            ## Create some FX rate instances

# Generated at 2022-06-12 06:18:36.044322
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Tests the `query` method of :class:`FXRateService`.
    """
    # Import required packages:
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Create a FX rate service:
    class MyService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if (ccy1, ccy2) == (Currencies["EUR"], Currencies["USD"]):
                return FXRate(Currencies["EUR"],
                              Currencies["USD"],
                              datetime.date.today(),
                              Decimal("2"))

# Generated at 2022-06-12 06:18:37.101424
# Unit test for method query of class FXRateService
def test_FXRateService_query():  # noqa
    pass



# Generated at 2022-06-12 06:18:48.903176
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Performs unit tests on method query of class FXRateService.
    """
    import doctest
    from .currencies import (Currency, Currencies)
    from .temporal import Temporal, Temporals

    from .commons.zeitgeist import Date

    def _fixture() -> FXRateService:
        from .currencies import Currencies
        from .fxrates import (FXRate, FXRateService)

        class MockFXRateService(FXRateService):
            """
            Provides a mock foreign exchange rate service.
            """


# Generated at 2022-06-12 06:18:56.250946
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService

    :return: Nothing
    """
    import pytest
    from pypara.currencies import Currencies
    from pypara.temporal import Date
    from pypara.enums import DataSource
    from pypara.fxrates import FXRateService, FXRateServiceFactory
    ccy1 = Currencies.USD
    ccy2 = Currencies.EUR
    date = Date(2018, 8, 20)
    fxRate = FXRateServiceFactory.create(DataSource.ECB)
    assert isinstance(fxRate, FXRateService)
    queries = [(ccy1, ccy2, date), (ccy2, ccy1, date)]
    fxRates = fxRate.queries(queries)

# Generated at 2022-06-12 06:19:05.381658
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService
    """
    import unittest

    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Mock dates:
    TODAY = datetime.date.today()
    PAST = TODAY - datetime.timedelta(days=1)

    ## Add a dummy FX rate service:
    class DFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == TODAY:
                return FXRate(ccy1, ccy2, asof, Decimal("2"))

# Generated at 2022-06-12 06:19:16.842272
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import MemoryFXRateService

    ## The FX rate service:
    rservice = MemoryFXRateService()

    ## The currency pairs and dates to query:
    eur_usd = (Currencies["EUR"], Currencies["USD"], datetime.date.today())
    usd_chf = (Currencies["USD"], Currencies["CHF"], datetime.date.today())
    eur_usd_mm = (Currencies["EUR"], Currencies["USD"], datetime.date.today() + datetime.timedelta(days=1))