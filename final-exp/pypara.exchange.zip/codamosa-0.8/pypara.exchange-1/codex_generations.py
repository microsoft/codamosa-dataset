

# Generated at 2022-06-12 06:10:24.967517
# Unit test for method queries of class FXRateService
def test_FXRateService_queries(): # noqa: D103
    pass  # TODO

# Generated at 2022-06-12 06:10:36.450628
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx_rates import FXRate
    import datetime

    class MockService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == datetime.date.today():
                return FXRate(ccy1, ccy2, asof, Decimal("2"))
            return None

    mock = MockService()

    rate = mock.query(Currencies["EUR"], Currencies["USD"], datetime.date.today())

# Generated at 2022-06-12 06:10:43.027438
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.zeitgeist import Date
    from .currencies import Currencies
    from .fxrates import FXRateService

    class SimpleFXRateService(FXRateService):
        """
        Provides a simple Foreign Exchange (FX) rate service.
        """

        def __init__(self):
            """
            Initializes the FX rate service.
            """
            self._rates = {}

        def add(self, ccy1: Currency, ccy2: Currency, date: Date, value: Decimal):
            """
            Adds a new FX rate.
            """
            self._rates[ccy1, ccy2, date] = FXRate(ccy1, ccy2, date, value)


# Generated at 2022-06-12 06:10:49.293684
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import today
    from .fxrates import MockFXRateService

    assert (MockFXRateService().queries([(Currencies.USD, Currencies.EUR, today()),
                                         (Currencies.EUR, Currencies.TRY, today())])
            == [None, None])

# Generated at 2022-06-12 06:10:58.536763
# Unit test for method query of class FXRateService
def test_FXRateService_query():    # noqa: D103
    from .currencies import Currency
    from .temporal import Date, Temporal
    from .fx import FXRateService, FXRate, FXRateLookupError
    from decimal import Decimal
    service = FXRateService()

    # Test with a valid query
    class QueryValidService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof.date, Decimal(1.0))

    service = QueryValidService()

# Generated at 2022-06-12 06:11:08.297939
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    # Given
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.fx import FXRateService

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return map(
                lambda query: self.query(query[0], query[1], query[2], strict=strict),
                queries,
            )


# Generated at 2022-06-12 06:11:12.269407
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the :method:`FXRateService.queries` method.
    """

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, Decimal(1))

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            for ccy1, ccy2, asof in queries:
                yield FXRate(ccy1, ccy2, asof, Decimal(1))

    ## Perform the test:
    from .currencies import Currencies
    from .temporal import today

# Generated at 2022-06-12 06:11:22.499399
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    import random
    import unittest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services.omdb import FXRateService as OMDBFXRateService


# Generated at 2022-06-12 06:11:30.478305
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Unit test for method query of class FXRateService.
    """

    # Create a dummy service:
    class DummyService(FXRateService):
        """
        Provides a dummy service for testing purposes.
        """

        def query(self, *args, **kwargs):  # pragma: no cover
            return None

        def queries(self, *args, **kwargs):  # pragma: no cover
            return None
    service = DummyService()

    # Test the method:
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    assert service.query(Currencies["EUR"], Currencies["USD"], date.today()) is None
    assert service.query(Currencies["EUR"], Currencies["USD"], date.today(), strict=True) is None

# Generated at 2022-06-12 06:11:37.533626
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    Returns a FXRateService mock.
    """
    from .testing import mock

    class FXRateServiceMock(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            return fxrate

    return FXRateServiceMock()

fxrate = FXRate(Currencies['EUR'], Currencies['USD'], Date('2020-01-01'), Decimal(2))


# Generated at 2022-06-12 06:11:52.097100
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .commons.zeitgeist import now
    from .currencies import Currency

    class MockService(FXRateService):
        def __init__(self):
            self.rates = {}

        def query(self, ccy1, ccy2, asof, strict=False):
            rate = self.rates.get(ccy1.code, self.rates.get(ccy2.code))
            if rate is not None and asof == now():
                return rate

            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)

            return None

        def queries(self, queries, strict=False):
            return [self.query(ccy1, ccy2, asof, strict) for ccy1, ccy2, asof in queries]


# Generated at 2022-06-12 06:11:55.052860
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    assert FXRateService.queries.__doc__ is not None

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 06:12:06.085129
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    # Create a mock FX rate service
    class MockFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False) -> Optional[FXRate]:
            assert isinstance(ccy1, Curr)
            assert isinstance(ccy2, Curr)
            assert isinstance(asof, Date)
            assert isinstance(strict, bool)
            return FXRate(ccy1, ccy2, asof, Decimal("2"))

        def queries(self, queries: Iterable[FXRateService.TQuery], strict = False) -> Iterable[Optional[FXRate]]:
            assert isinstance(queries, iter)
            assert isinstance(strict, bool)
           

# Generated at 2022-06-12 06:12:17.380805
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency, Currencies
    from .temporal import Date
    import decimal
    import unittest
    from datetime import date

    class Dummy(FXRateService):
        """
        Provides a dummy FX rate service.
        """


# Generated at 2022-06-12 06:12:28.363693
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    # Test that we can successfully query the default service:
    from datetime import date
    from .currencies import Currencies
    from .temporal import Date

    ## Test date:
    date1 = Date.today()

    ## Test currencies:
    ccy1 = Currencies["EUR"]
    ccy2 = Currencies["USD"]

    ## Test the query:
    rrate = FXRateService.default.query(ccy1, ccy2, date1)

    ## Check the result:
    assert isinstance(rrate, FXRate)
    assert rrate is not None
    assert rrate[0] == ccy1
    assert rrate[1] == ccy2
    assert rrate[2] == date1
    assert rrate[3] > ZERO

    ## Test the inverse query:
    irate = ~r

# Generated at 2022-06-12 06:12:40.537133
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    There is a bug in queries method, the default iterator return single item
    """

    from .currencies import Currency
    from .temporal import Date
    from .fxrates import FXRateService



# Generated at 2022-06-12 06:12:52.563683
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import pytest
    from decimal import Decimal
    from pypara.currencies import Currencies
    from datetime import date
    from pypara.fx import FXRate

    class TestFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return (ccy1, ccy2, asof) in self.rates \
                and FXRate(ccy1, ccy2, asof, self.rates[(ccy1, ccy2, asof)])


# Generated at 2022-06-12 06:13:05.531126
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currency

    # Non strict mode:
    class MFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency.EUR and ccy2 == Currency.USD and asof == Date(2000, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal(1.))
            elif strict == False:
                return None

    mfxratesvc1 = MFXRateService()
    mfxratesvc2 = MFXRateService()
    assert isinstance(mfxratesvc1.query(Currency.EUR, Currency.USD, Date(2000, 1, 1), False), FXRate)
    assert mfxratesvc1

# Generated at 2022-06-12 06:13:18.555127
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    from decimal import Decimal
    from pypara.fxrates import FXRateService
    from pypara.currencies import Currencies
    from pypara.commons.zeitgeist import Date

    class TestService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):

            from decimal import Decimal
            from pypara.fxrates import FXRate

            if ccy1 == Currencies["USD"] and ccy2 == Currencies["TRY"]:
                return FXRate(Currencies["USD"], Currencies["TRY"], Date(2019, 1, 1), Decimal("6.11"))

            raise FXRateLookupError(ccy1, ccy2, asof)

        def queries(self, queries, strict=False):

            from decimal import Decimal

# Generated at 2022-06-12 06:13:32.281230
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests method queries of class FXRateService.
    """

    from .currencies import Currencies
    from .zeitgeist import Date

    from .commons.base import Mock
    from .commons.context import Context

    ## Assert that queries method returns an iterable:
    class FXRateServiceMock(FXRateService):
        """
        Provides a mock FX rate service for testing.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return Mock.get_value(type(self).query.__name__, None)


# Generated at 2022-06-12 06:13:40.426856
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    ## Nothing to test for an abstract class.
    pass


# Generated at 2022-06-12 06:13:52.609246
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.datetime import Date
    from pypara.services.fxrates.simple import SimpleFXRateService

    ## Create the FX rate service instance:

# Generated at 2022-06-12 06:13:57.098258
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .exchanges import Exchange as Ex
    from .exchanges import FXRateServices as SVC

    ## Create an FX rate service:
    service = SVC["OER"]

    ## Test simple FX rate queries:
    assert service.query(Ex.BU, Currencies["EUR"], Currencies["USD"], Date.today(), False)
    assert not service.query(Ex.BU, Currencies["EUR"], Currencies["USD"], Date.today(), True)



# Generated at 2022-06-12 06:14:08.125754
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.markets.forex import FXRateService

    class TestFXRateService(FXRateService):
        """
        Test implementation of FXRateService.
        """

        def __init__(self) -> None:
            """
            Initializes the FX rate service.
            """

# Generated at 2022-06-12 06:14:19.495061
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the queries method of the FXRateService class.
    """
    # pylint: disable=W0212
    # pylint: disable=C0103
    # pylint: disable=R0201
    class __FXRateService(FXRateService):
        """
        Provides an abstract class for serving foreign exchange rates.
        """
        def query(self, ccy1, ccy2, asof, strict=None):
            return None

        def queries(self, queries, strict=None):
            return [None]
    # pylint: enable=R0201
    # pylint: enable=C0103
    # pylint: enable=W0212
    fxr = __FXRateService()
    assert fxr.queries([]) == [None]

# Generated at 2022-06-12 06:14:29.734474
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    ## Define the queries:
    QUERIES = [
        (Currencies["EUR"], Currencies["USD"], datetime.date.today()),
        (Currencies["USD"], Currencies["EUR"], datetime.date.today())
    ]

    ## Define the expected:
    EXPECTED = [
        FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2")),
        FXRate(Currencies["USD"], Currencies["EUR"], datetime.date.today(), Decimal("0.5"))
    ]

    ## Define the query service:

# Generated at 2022-06-12 06:14:38.867372
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService
    from pypara.testing import Mocked

    class MockedRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            if (ccy1, ccy2, asof) in MockedRateService.queries:
                return MockedRateService.queries[(ccy1, ccy2, asof)]
            if strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            return None


# Generated at 2022-06-12 06:14:50.364208
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency, Currencies
    from .dates import ISODate, ISODateTime
    from .times import Time
    from .temporals import Temporal, ISOTemporal

    from decimal import Decimal, ROUND_HALF_UP

    class FXRateService_queries_Tester(FXRateService):
        """
        Provides an abstract base class for testing FXRateService queries method.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            """
            Initializes the FX rate service.

            :param rates: The list of FX rates.
            """
            ## Create an FX rate lookup dictionary:
            self._rates = {
                (rate[0].code, rate[1].code, rate[2]): rate
                for rate in rates
            }


# Generated at 2022-06-12 06:15:01.471177
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    from .currencies import Currency, CurrencyUtil

    from .time import Date, DateUtil

    from .time import DateInterval, DateSpan

    class TestFXRateService(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            self._query_count += 1
            return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            self._query_count += len(queries)
            return (None for _ in queries)

    usd = CurrencyUtil.get('USD')
    eur = CurrencyUtil.get('EUR')

    service = TestFXRateService()
    service._query_count = 0

# Generated at 2022-06-12 06:15:09.407731
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fexrates import FXRateService

    class _FXRateService(FXRateService):
        """
        Provides a test implementation for the FX rate service.
        """

        def __init__(self, rates: Iterable[FXRate]) -> None:
            self._rates = dict(rates)

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            key = (ccy1, ccy2, asof)
            if key in self._rates:
                return self._rates[key]
            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)

# Generated at 2022-06-12 06:15:35.474911
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies

    queries = [
        (Currencies["EUR"], Currencies["USD"], datetime.date(2020, 1, 1)),
        (Currencies["USD"], Currencies["JPY"], datetime.date(2020, 1, 1)),
        (Currencies["EUR"], Currencies["USD"], datetime.date(2020, 1, 2)),
        (Currencies["USD"], Currencies["JPY"], datetime.date(2020, 1, 2)),
    ]

    class FRSMock(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            return FXRate(ccy1, ccy2, asof, ONE)



# Generated at 2022-06-12 06:15:47.981784
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx.services import DummyFXRateService
    service = DummyFXRateService()
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), True) is not None
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), False) is not None
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), True) == FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))

# Generated at 2022-06-12 06:15:54.620841
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main
    from unittest.mock import Mock

    class MockRateService(FXRateService):
        def __init__(self, rates):
            self.rates = rates

        def query(self, ccy1, ccy2, asof, strict=False):
            return self.rates[(ccy1, ccy2, asof)]

        def queries(self, queries, strict=False):
            return (self.rates[q] for q in queries)

    class FXRateServiceTest(TestCase):
        def setUp(self):
            from decimal import Decimal
            from pypara.currencies import Currencies
            from pypara.commons.zeitgeist import Date


# Generated at 2022-06-12 06:16:02.912748
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests FXRateService.queries()
    """
    
    from datetime import date
    from .currencies import Currencies
    from .temporal import Temporal

    Currency.set_default("USD")

    from .fx_rates import InMemoryFXRateService

    service = InMemoryFXRateService(
	    [("EUR", "USD", date(2020, 6, 23), 1.1), ("TRY", "USD", date(2020, 6, 23), 0.15)]
    )

    assert all(service.queries([("EUR", Currency("USD"), Temporal(date(2020, 6, 23)))]))
    assert not all(service.queries([("EUR", Currency("USD"), Temporal(date(2020, 7, 23)))]))

# Generated at 2022-06-12 06:16:14.893225
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit tests for method queries of class FXRateService.
    """
    import datetime
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.finance.fx.rates import FXRateService

    # Define a test key-value store for queries:
    class TestFXRateService(FXRateService):
        """
        Provides a test FX rate service.
        """
        rates = [
            FXRate(Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("2"))
        ]


# Generated at 2022-06-12 06:16:16.215168
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    # TODO: Implement FXRateService unit test for method query
    pass


# Generated at 2022-06-12 06:16:17.419745
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:16:28.488082
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currency
    from .temporal import Date

    from unittest import TestCase
    from unittest.mock import Mock, call

    class SampleFXRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict = False):
            if ccy1 == Currency("EUR") and ccy2 == Currency("USD") and asof == Date(2018, 1, 1):
                return FXRate(ccy1, ccy2, asof, Decimal("1.1"))
            else:
                return None

        def queries(self, queries, strict = False):
            return [self.query(curr1, curr2, asof) for curr1, curr2, asof in queries]

    service = SampleFXRateService()

    ## No query:
   

# Generated at 2022-06-12 06:16:39.533079
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .currencies import Currencies
    from .temporal import today
    from pytest import raises
    class MyService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:
            imports = (Currencies["EUR"], Currencies["USD"])
            if (ccy1, ccy2, asof) == imports:
                raise RuntimeError()
            return None

        def queries(self, queries: Iterable[TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            rates = []
            for ccy1, ccy2, asof in queries:
                rate = self.query(ccy1, ccy2, asof, strict)
                rates.append(rate)
            return rates

# Generated at 2022-06-12 06:16:50.705866
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    import datetime

    from pypara.currencies import Currencies

    class MockFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == Currencies['EUR'] and ccy2 == Currencies['TRY']:
                if asof == datetime.date(2020,1,1):
                    return FXRate(Currencies['EUR'], Currencies['TRY'], datetime.date(2020,1,1), Decimal('6.92871'))
                else:
                    return FXRate(Currencies['EUR'], Currencies['TRY'], datetime.date(2020,1,2), Decimal('6.98742'))

    # Get the service instance
    service = MockFXRateService()

   

# Generated at 2022-06-12 06:17:24.292771
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    pass


# Generated at 2022-06-12 06:17:36.314880
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Tests the method queries of the class FXRateService.
    """
    from .currencies import Currency
    from .temporal import Temporal
    from .fx import FXRateService
    from typing import Tuple
    import dateutil.parser
    import datetime

    # Define queries
    queries = (
        (Currency.USD, Currency.EUR, Temporal(dateutil.parser.parse("2020-05-01"))),
        (Currency.EUR, Currency.USD, Temporal(dateutil.parser.parse("2020-07-01")))
    )

    # Define FXRateService
    class FXRateServiceStub(FXRateService):
        """
        A stub class for testing the class FXRateService.
        """


# Generated at 2022-06-12 06:17:37.428720
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    """
    """
    pass



# Generated at 2022-06-12 06:17:44.400975
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    """
    Unit test for method queries of class FXRateService.
    """
    ## We are using an uninitialized FX rate service:
    assert FXRateService.default is None

    ## We are using an uninitialized FX rate service:
    try:
        FXRateService.default.queries([])
        assert False, "Dereference of uninitialized FX rate service should have failed!"
    except AttributeError:
        pass

# Generated at 2022-06-12 06:17:55.517073
# Unit test for method query of class FXRateService
def test_FXRateService_query():

    class FXRS(FXRateService):

        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[FXRate]:

            if ccy1 == Currency("USD") and ccy2 == Currency("EUR"):
                return FXRate(ccy1, ccy2, asof, 1 / 1.1)
            else:
                return None

        def queries(self, queries: Iterable[FXRateService.TQuery], strict: bool = False) -> Iterable[Optional[FXRate]]:
            return [self.query(*query) for query in queries]

    rs = FXRS()
    rate = rs.query(Currency("USD"), Currency("EUR"), Date(2018, 1, 1))

# Generated at 2022-06-12 06:18:08.033434
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from .currencies import Currencies
    from .temporal import Date
    from .finance.services import FXRateMemoryService
    from .finance.presets import FXRatePresets

    ## Create an instance of the FX rate service:
    fx_rates = FXRatePresets.default.rates
    service = FXRateMemoryService.of(fx_rates)

    ## Query some FX rates:
    assert service.query(Currencies["USD"], Currencies["EUR"], Date(2016, 1, 1)) is None
    assert service.query(Currencies["EUR"], Currencies["USD"], Date(2016, 1, 1)) is None
    assert service.query(Currencies["EUR"], Currencies["USD"], Date(2016, 1, 2)) is not None

# Generated at 2022-06-12 06:18:15.322699
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    # Defines the FX rate service mock
    class FXRateServiceMock(FXRateService):

        # Implements method queries of class FXRateService
        def queries(self, queries, strict=False):
            return (self.query(*q) for q in queries)

        # Implements method query of class FXRateService
        def query(self, *args, **kwargs):
            return super().query(*args, **kwargs)

    # Defines the FX rate list

# Generated at 2022-06-12 06:18:25.945742
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from unittest import TestCase, main
    from datetime import date
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.fx import FXRateService, FXRateLookupError

    def create_fx_rate_service(qdict: dict) -> FXRateService:
        """
        Creates and returns an FX rate service with the given query dictionary.
        :param qdict: A query dictionary mapping currency pair and date to FX rates.
        :return: A query service.
        """

        class FXRateServiceImpl(FXRateService):
            """
            Provides a concrete implementation of the FX rate service for testing purpose.
            """


# Generated at 2022-06-12 06:18:26.725379
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    pass

# Generated at 2022-06-12 06:18:36.749615
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():

    import datetime

    from .commons.numbers import ONE, ZERO
    from .currencies import Currencies
    from .times import Temporal

    ## FX rate service:
    class DummyFXRateService(FXRateService):

        queries = [
            (Currencies["EUR"], Currencies["USD"], datetime.date.today(), Decimal("1.2")),
            (Currencies["TRL"], Currencies["USD"], datetime.date.today(), Decimal("1.5")),
            (Currencies["USD"], Currencies["EUR"], datetime.date.today(), None)
        ]


# Generated at 2022-06-12 06:20:04.504415
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from .commons.zeitgeist import Date, Temporals
    from .currencies import Currency, Currencies
    from decimal import Decimal
    date = Date(2018, 1, 1)
    class FixedRateService(FXRateService):
        def query(self, ccy1, ccy2, asof, strict=False):
            if ccy1 == ccy2:
                return FXRate(ccy1, ccy2, asof, Decimal("1"))
            if ccy1 == Currencies["USD"] and ccy2 == Currencies["EUR"]:
                return FXRate(ccy1, ccy2, asof, Decimal("1.5"))

# Generated at 2022-06-12 06:20:14.342568
# Unit test for method query of class FXRateService
def test_FXRateService_query():
    from decimal import Decimal
    from pypara.currencies import Currencies
    from pypara.time import now

    class TestFXRateService(FXRateService):

        def query(self, ccy1, ccy2, asof, strict):
            if ccy1 == Currencies["EUR"] and ccy2 == Currencies["USD"] and asof == now("UTC"):
                return FXRate(ccy1, ccy2, asof, Decimal("1.00"))
            elif strict:
                raise FXRateLookupError(ccy1, ccy2, asof)
            else:
                return None

    service = TestFXRateService()
    import datetime
    assert service.query(Currencies["EUR"], Currencies["USD"], datetime.date.today(), strict=False)



# Generated at 2022-06-12 06:20:25.080670
# Unit test for method queries of class FXRateService
def test_FXRateService_queries():
    from datetime import date
    from pypara.currencies import Currencies
    from .sources.mock import FXRateMockService
    from .sources.yahoo import FXRateYahooService

    ## Mock service
    nyse = FXRateMockService()
    nws = nyse.queries([
        (Currencies["USD"], Currencies["EUR"], date(2020, 3, 2)),
        (Currencies["USD"], Currencies["EUR"], date(2020, 3, 26)),
        (Currencies["USD"], Currencies["EUR"], date(2020, 3, 27)),
    ])
    assert all(map(lambda nw: nw == FXRate(Currencies["USD"], Currencies["EUR"], nw.date, Decimal("1.1")), nws))

    ## Yahoo service