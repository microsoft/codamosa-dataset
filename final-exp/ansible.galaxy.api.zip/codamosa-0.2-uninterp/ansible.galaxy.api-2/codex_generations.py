

# Generated at 2022-06-16 21:23:08.074066
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        return True
    assert test_func()



# Generated at 2022-06-16 21:23:13.255447
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:8080/api/') == 'galaxy.ansible.com:8080'
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:8080') == 'galaxy.ansible.com:8080'
    assert get_cache_id('https://user:pass@galaxy.ansible.com/api/') == 'galaxy.ansible.com:'

# Generated at 2022-06-16 21:23:25.213905
# Unit test for function g_connect
def test_g_connect():
    def test_method(self, *args, **kwargs):
        return self.api_server
    test_method = g_connect(['v1', 'v2'])(test_method)
    test_obj = GalaxyAPI('https://galaxy.ansible.com', 'test_name')
    assert test_obj.api_server == 'https://galaxy.ansible.com/api/'
    assert test_method(test_obj) == 'https://galaxy.ansible.com/api/'
    test_obj = GalaxyAPI('https://galaxy.ansible.com/api/', 'test_name')
    assert test_obj.api_server == 'https://galaxy.ansible.com/api/'
    assert test_method(test_obj) == 'https://galaxy.ansible.com/api/'

# Generated at 2022-06-16 21:23:33.588429
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Test with GalaxyAPI(name='galaxy', api_server='https://galaxy.ansible.com') < GalaxyAPI(name='galaxy', api_server='https://galaxy.ansible.com')
    galaxy_api_1 = GalaxyAPI(name='galaxy', api_server='https://galaxy.ansible.com')
    galaxy_api_2 = GalaxyAPI(name='galaxy', api_server='https://galaxy.ansible.com')
    assert not galaxy_api_1 < galaxy_api_2
    # Test with GalaxyAPI(name='galaxy', api_server='https://galaxy.ansible.com') < GalaxyAPI(name='galaxy', api_server='https://galaxy.ansible.com/api/')

# Generated at 2022-06-16 21:23:45.620151
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'

# Generated at 2022-06-16 21:23:53.211699
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:8080') == 'galaxy.ansible.com:8080'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com/api') == 'galaxy.ansible.com:'
    assert get_cache_

# Generated at 2022-06-16 21:24:05.726455
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='http://galaxy.ansible.com/api/v2/', code=404, msg='Not Found', hdrs='', fp=None)
    message = 'Error when finding available api versions from galaxy.ansible.com (http://galaxy.ansible.com/api/v2/)'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'http://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Error when finding available api versions from galaxy.ansible.com (http://galaxy.ansible.com/api/v2/) (HTTP Code: 404, Message: Not Found)'



# Generated at 2022-06-16 21:24:12.024289
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Setup
    galaxy_api = GalaxyAPI(name='test', api_server='http://localhost:8080', ignore_certs=False)
    other = GalaxyAPI(name='test', api_server='http://localhost:8080', ignore_certs=False)

    # Exercise
    result = galaxy_api.__lt__(other)

    # Verify
    assert result is False


# Generated at 2022-06-16 21:24:17.443407
# Unit test for function g_connect
def test_g_connect():
    class TestClass(object):
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com'
            self.name = 'galaxy.ansible.com'
            self._available_api_versions = {}

        @g_connect(versions=['v1'])
        def test_method(self):
            return True

    tc = TestClass()
    assert tc.test_method()



# Generated at 2022-06-16 21:24:18.202306
# Unit test for function cache_lock
def test_cache_lock():
    # TODO: Write unit test
    pass



# Generated at 2022-06-16 21:25:39.243043
# Unit test for function g_connect
def test_g_connect():
    class GalaxyConnection(object):
        def __init__(self, api_server, name):
            self.api_server = api_server
            self.name = name
            self._available_api_versions = {}
        def _call_galaxy(self, url, method='GET', data=None, error_context_msg='', cache=False):
            return {'available_versions': {u'v1': u'v1/'}}
        @g_connect(['v1', 'v2'])
        def test_method(self):
            return True
    gc = GalaxyConnection('https://galaxy.ansible.com', 'galaxy.ansible.com')
    assert gc.test_method() is True

# Generated at 2022-06-16 21:25:49.032194
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxyAPI(object):
        def __init__(self, name, api_server):
            self.name = name
            self.api_server = api_server
            self._available_api_versions = {}

        def _call_galaxy(self, url, method='GET', error_context_msg=None, cache=False):
            return {'available_versions': {u'v1': u'v1/'}}

    test_galaxy_api = TestGalaxyAPI('test', 'https://galaxy.ansible.com')

    @g_connect(versions=['v1'])
    def test_method(self):
        return 'test'

    assert test_method(test_galaxy_api) == 'test'


# Generated at 2022-06-16 21:26:02.081860
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='http://galaxy.ansible.com/api/v2/', code=400, msg='Bad Request', hdrs={}, fp=None)
    message = 'Bad Request'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'http://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Bad Request (HTTP Code: 400, Message: Bad Request Code: Unknown)'

    http_error = HTTPError(url='http://galaxy.ansible.com/api/v3/', code=400, msg='Bad Request', hdrs={}, fp=None)
    message = 'Bad Request'

# Generated at 2022-06-16 21:26:08.060548
# Unit test for function cache_lock
def test_cache_lock():
    # Test that the lock is acquired
    lock_acquired = [False]

    def func():
        lock_acquired[0] = True

    wrapped = cache_lock(func)
    wrapped()
    assert lock_acquired[0]

    # Test that the lock is released
    lock_released = [False]

    def func():
        lock_released[0] = True

    wrapped = cache_lock(func)
    wrapped()
    assert lock_released[0]



# Generated at 2022-06-16 21:26:17.188406
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=404, msg='Not Found', hdrs=None, fp=None)
    message = 'Error when finding available api versions from galaxy.ansible.com (https://galaxy.ansible.com/api/v2/)'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Error when finding available api versions from galaxy.ansible.com (https://galaxy.ansible.com/api/v2/) (HTTP Code: 404, Message: Not Found)'



# Generated at 2022-06-16 21:26:25.388859
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:8080') == 'galaxy.ansible.com:8080'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'

# Generated at 2022-06-16 21:26:32.112769
# Unit test for function cache_lock
def test_cache_lock():
    lock = threading.Lock()
    lock.acquire()
    assert not lock.acquire(False)

    @cache_lock
    def test_func():
        assert not lock.acquire(False)
        lock.release()
        assert lock.acquire(False)
        lock.release()

    test_func()
    assert lock.acquire(False)
    lock.release()



# Generated at 2022-06-16 21:26:39.335585
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('https://galaxy.ansible.com/api/', 404, 'Not Found', None, None)
    message = 'Not Found'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/'
    assert galaxy_error.message == 'Not Found (HTTP Code: 404, Message: Not Found)'

    http_error = HTTPError('https://galaxy.ansible.com/api/v2/', 404, 'Not Found', None, None)
    message = 'Not Found'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404

# Generated at 2022-06-16 21:26:42.296232
# Unit test for function g_connect
def test_g_connect():
    class GalaxyConnection(object):
        def __init__(self, name, api_server):
            self.name = name
            self.api_server = api_server
            self._available_api_versions = {}
            self._call_galaxy = lambda *args, **kwargs: {'available_versions': {'v1': 'v1/'}}

        @g_connect(['v1'])
        def test_method(self):
            return True

    assert GalaxyConnection('test', 'https://galaxy.ansible.com').test_method()



# Generated at 2022-06-16 21:26:44.548351
# Unit test for function g_connect
def test_g_connect():
    class Test(object):
        def __init__(self):
            self.name = 'test'
            self.api_server = 'https://galaxy.ansible.com'
            self._available_api_versions = {}

        @g_connect(['v1', 'v2'])
        def test_method(self):
            return True

    t = Test()
    assert t.test_method()



# Generated at 2022-06-16 21:28:51.713794
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'

# Generated at 2022-06-16 21:29:02.004949
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'



# Generated at 2022-06-16 21:29:15.145453
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI(name='foo', api_server='bar', token='baz')
    assert galaxy_api < GalaxyAPI(name='foo', api_server='bar', token='baz')
    assert galaxy_api < GalaxyAPI(name='foo', api_server='bar', token='qux')
    assert galaxy_api < GalaxyAPI(name='foo', api_server='qux', token='baz')
    assert galaxy_api < GalaxyAPI(name='qux', api_server='bar', token='baz')
    assert not galaxy_api < GalaxyAPI(name='foo', api_server='bar', token='baz')
    assert not galaxy_api < GalaxyAPI(name='foo', api_server='bar', token='qux')

# Generated at 2022-06-16 21:29:27.652534
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Test with a GalaxyAPI object and a GalaxyAPI object
    api_1 = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password', 'token')
    api_2 = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password', 'token')
    assert api_1 < api_2 is False
    assert api_2 < api_1 is False

    # Test with a GalaxyAPI object and a string
    api_1 = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password', 'token')
    assert api_1 < 'https://galaxy.ansible.com' is False
    assert 'https://galaxy.ansible.com' < api_1 is False

    # Test with a GalaxyAPI object and a None

# Generated at 2022-06-16 21:29:38.564083
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://www.example.com') == 'www.example.com:'
    assert get_cache_id('http://www.example.com:80') == 'www.example.com:80'
    assert get_cache_id('http://www.example.com:8080') == 'www.example.com:8080'
    assert get_cache_id('http://www.example.com/') == 'www.example.com:'
    assert get_cache_id('http://www.example.com:80/') == 'www.example.com:80'
    assert get_cache_id('http://www.example.com:8080/') == 'www.example.com:8080'

# Generated at 2022-06-16 21:29:47.575323
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(GalaxyError(http_code=500))
    assert not is_rate_limit_exception(GalaxyError(http_code=200))
    assert not is_rate_limit_exception(GalaxyError(http_code=404))
    assert not is_rate_limit_exception(GalaxyError(http_code=400))
    assert not is_rate_limit_exception(GalaxyError(http_code=401))

# Generated at 2022-06-16 21:29:59.122114
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Test for v1
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v1/', code=400, msg='Bad Request', hdrs={}, fp=None,
                           filename=None)
    galaxy_error = GalaxyError(http_error, message='Test')
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v1/'
    assert galaxy_error.message == 'Test (HTTP Code: 400, Message: Bad Request)'

    # Test for v2
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=400, msg='Bad Request', hdrs={}, fp=None,
                           filename=None)
    galaxy

# Generated at 2022-06-16 21:30:02.955639
# Unit test for function g_connect
def test_g_connect():
    class GalaxyConnection:
        def __init__(self, api_server, name):
            self.api_server = api_server
            self.name = name
            self._available_api_versions = {}
            self._call_galaxy = None

    gc = GalaxyConnection('https://galaxy.ansible.com', 'galaxy')
    g_connect(['v1', 'v2'])(lambda x: x)(gc)



# Generated at 2022-06-16 21:30:05.118311
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI()
    assert galaxy_api.__lt__(None) == NotImplemented


# Generated at 2022-06-16 21:30:14.090512
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(GalaxyError(http_code=500))
    assert not is_rate_limit_exception(GalaxyError(http_code=200))
    assert not is_rate_limit_exception(GalaxyError(http_code=404))
    assert not is_rate_limit_exception(GalaxyError(http_code=400))
    assert not is_rate_limit_exception(GalaxyError(http_code=401))