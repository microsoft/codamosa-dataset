

# Generated at 2022-06-16 21:23:07.889777
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=400, msg='Bad Request', hdrs={}, fp=None)
    message = 'An error occurred while retrieving the list of collections'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'An error occurred while retrieving the list of collections (HTTP Code: 400, Message: Bad Request)'


# Generated at 2022-06-16 21:23:16.776947
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxyAPI(object):
        def __init__(self, name, api_server):
            self.name = name
            self.api_server = api_server
            self._available_api_versions = {}

        def _call_galaxy(self, url, method='GET', data=None, error_context_msg=None, cache=False):
            return {'available_versions': {u'v1': u'v1/'}}

    test_galaxy_api = TestGalaxyAPI('test', 'https://galaxy.ansible.com')
    @g_connect(versions=['v1'])
    def test_method(self):
        return True

    assert test_method(test_galaxy_api)



# Generated at 2022-06-16 21:23:22.897458
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(GalaxyError(http_code=404))
    assert not is_rate_limit_exception(GalaxyError(http_code=500))
    assert not is_rate_limit_exception(GalaxyError(http_code=503))
    assert not is_rate_limit_exception(GalaxyError(http_code=504))
    assert not is_rate_limit_exception(GalaxyError(http_code=200))

# Generated at 2022-06-16 21:23:32.406584
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test constructor with no arguments
    api = GalaxyAPI()
    assert api.name == 'galaxy'
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.ignore_certs is False
    assert api.token is None
    assert api.username is None
    assert api.password is None
    assert api.client_id is None
    assert api.client_secret is None
    assert api.available_api_versions == {}
    assert api.cache_path is None

    # Test constructor with arguments

# Generated at 2022-06-16 21:23:34.733506
# Unit test for function cache_lock
def test_cache_lock():
    lock_func = cache_lock(lambda: None)
    assert lock_func() is None



# Generated at 2022-06-16 21:23:41.001031
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('url', 'code', 'msg', 'hdrs', None)
    galaxy_error = GalaxyError(http_error, 'message')
    assert galaxy_error.http_code == 'code'
    assert galaxy_error.url == 'url'
    assert galaxy_error.message == 'message (HTTP Code: code, Message: msg)'



# Generated at 2022-06-16 21:23:50.550372
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=404, msg='Not Found', hdrs=None, fp=None)
    message = 'Not Found'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Not Found (HTTP Code: 404, Message: Not Found Code: Unknown)'

    http_error = HTTPError(url='https://galaxy.ansible.com/api/v3/', code=404, msg='Not Found', hdrs=None, fp=None)
    message = 'Not Found'

# Generated at 2022-06-16 21:24:02.785347
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Test with a GalaxyAPI object and a string
    galaxy_api = GalaxyAPI(name='test_name', api_server='test_api_server')
    assert galaxy_api.__lt__('test_name') is False
    assert galaxy_api.__lt__('test_name_1') is True
    assert galaxy_api.__lt__('test_name_2') is True
    assert galaxy_api.__lt__('test_name_3') is True
    assert galaxy_api.__lt__('test_name_4') is True
    assert galaxy_api.__lt__('test_name_5') is True
    assert galaxy_api.__lt__('test_name_6') is True
    assert galaxy_api.__lt__('test_name_7') is True

# Generated at 2022-06-16 21:24:14.803515
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('https://galaxy.ansible.com', 400, 'Bad Request', {}, None)
    galaxy_error = GalaxyError(http_error, 'Galaxy Error')
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'https://galaxy.ansible.com'
    assert galaxy_error.message == 'Galaxy Error (HTTP Code: 400, Message: Bad Request)'

    http_error = HTTPError('https://galaxy.ansible.com/api/v2', 400, 'Bad Request', {}, None)
    galaxy_error = GalaxyError(http_error, 'Galaxy Error')
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2'
    assert galaxy_error.message

# Generated at 2022-06-16 21:24:28.571356
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('https://galaxy.ansible.com/api/v2/', 404, 'Not Found', {}, None)
    message = 'Galaxy server error'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Galaxy server error (HTTP Code: 404, Message: Not Found Code: Unknown)'

    http_error = HTTPError('https://galaxy.ansible.com/api/v3/', 404, 'Not Found', {}, None)
    message = 'Galaxy server error'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
   

# Generated at 2022-06-16 21:25:15.071982
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('https://galaxy.ansible.com/api/v2/', 400, 'Bad Request', {}, None)
    message = 'Galaxy error'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Galaxy error (HTTP Code: 400, Message: Bad Request)'

    http_error = HTTPError('https://galaxy.ansible.com/api/v2/', 400, 'Bad Request', {}, None)
    message = 'Galaxy error'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 400
    assert galaxy_error.url

# Generated at 2022-06-16 21:25:18.810530
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'


# Generated at 2022-06-16 21:25:31.757271
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('http://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('http://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('http://galaxy.ansible.com:8080') == 'galaxy.ansible.com:8080'
    assert get_cache_id('http://galaxy.ansible.com:8080/') == 'galaxy.ansible.com:8080'

# Generated at 2022-06-16 21:25:41.277193
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='http://127.0.0.1:8080/v2/', code=400, msg='Bad Request', hdrs={}, fp=None)
    message = 'Test Message'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'http://127.0.0.1:8080/v2/'
    assert galaxy_error.message == 'Test Message (HTTP Code: 400, Message: Bad Request Code: Unknown)'

    http_error = HTTPError(url='http://127.0.0.1:8080/v3/', code=400, msg='Bad Request', hdrs={}, fp=None)
    message = 'Test Message'

# Generated at 2022-06-16 21:25:50.288512
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='http://localhost:8080/v1/', code=404, msg='Not Found', hdrs=None, fp=None)
    message = 'Not Found'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'http://localhost:8080/v1/'
    assert galaxy_error.message == 'Not Found (HTTP Code: 404, Message: Not Found)'

    http_error = HTTPError(url='http://localhost:8080/v2/', code=404, msg='Not Found', hdrs=None, fp=None)
    message = 'Not Found'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
   

# Generated at 2022-06-16 21:26:03.494219
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password')
    assert galaxy_api.api_server == 'https://galaxy.ansible.com'
    assert galaxy_api.username == 'username'
    assert galaxy_api.password == 'password'
    assert galaxy_api.token is None
    assert galaxy_api.token_expires is None
    assert galaxy_api.token_url is None
    assert galaxy_api.available_api_versions == {}
    assert galaxy_api.cache_path is None
    assert galaxy_api.cache is None
    assert galaxy_api.cache_lock is None
    assert galaxy_api.cache_lock_path is None
    assert galaxy_api.cache_lock_timeout == 10
    assert galaxy_api.cache_max_age == 86400
   

# Generated at 2022-06-16 21:26:14.144762
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://example.com') == 'example.com:'
    assert get_cache_id('http://example.com:80') == 'example.com:80'
    assert get_cache_id('http://example.com:80/') == 'example.com:80'
    assert get_cache_id('http://example.com:80/api/') == 'example.com:80'
    assert get_cache_id('http://example.com:80/api') == 'example.com:80'
    assert get_cache_id('http://example.com:80/api/v2/') == 'example.com:80'
    assert get_cache_id('http://example.com:80/api/v2') == 'example.com:80'

# Generated at 2022-06-16 21:26:23.352894
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Test with v2 API endpoint
    http_error = HTTPError('https://galaxy.ansible.com/api/v2/', 500, 'Internal Server Error', {}, None)
    err_info = {'message': 'Internal Server Error', 'code': '500'}
    http_error.read = lambda: json.dumps(err_info)
    message = 'Error when finding available api versions from galaxy.ansible.com (https://galaxy.ansible.com/api/v2/)'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 500
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'

# Generated at 2022-06-16 21:26:35.590161
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Test for v1
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v1/', code=400, msg='Bad Request', hdrs={}, fp=None,
                           filename=None)
    err_info = {'default': 'Bad Request'}
    http_error.read = lambda: json.dumps(err_info)
    galaxy_error = GalaxyError(http_error, 'Test')
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v1/'
    assert galaxy_error.message == 'Test (HTTP Code: 400, Message: Bad Request)'

    # Test for v2

# Generated at 2022-06-16 21:26:48.357456
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api1 = GalaxyAPI(name='test', api_server='https://test.galaxy.ansible.com',
                     available_api_versions={'v2': 'api/v2', 'v3': 'api/v3'})
    api2 = GalaxyAPI(name='test', api_server='https://test.galaxy.ansible.com',
                     available_api_versions={'v2': 'api/v2', 'v3': 'api/v3'})
    assert api1.__lt__(api2) is False
    assert api2.__lt__(api1) is False

# Generated at 2022-06-16 21:27:36.013096
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        return True
    assert test_func()



# Generated at 2022-06-16 21:27:45.170318
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password')
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.username == 'username'
    assert api.password == 'password'
    assert api.token is None
    assert api.token_expires is None
    assert api.available_api_versions == {'v2': 'api/v2', 'v3': 'api/v3'}
    assert api.name == 'galaxy.ansible.com'

    api = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password', 'token')
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.username == 'username'
    assert api.password == 'password'

# Generated at 2022-06-16 21:27:51.388885
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI(name='galaxy_api', api_server='api_server', ignore_certs=False, ignore_errors=False,
                           timeout=10, token='token', username='username', password='password',
                           client_cert='client_cert', client_key='client_key')
    other_galaxy_api = GalaxyAPI(name='other_galaxy_api', api_server='other_api_server', ignore_certs=False,
                                 ignore_errors=False, timeout=10, token='token', username='username',
                                 password='password', client_cert='client_cert', client_key='client_key')
    assert galaxy_api < other_galaxy_api


# Generated at 2022-06-16 21:27:59.891836
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxyAPI(object):
        def __init__(self, api_server, name):
            self.api_server = api_server
            self.name = name
            self._available_api_versions = {}

        @g_connect(versions=['v1', 'v2'])
        def test_method(self):
            return True

        def _call_galaxy(self, url, method='GET', error_context_msg=None, cache=False):
            return {'available_versions': {u'v1': u'v1/'}}

    # Test with no available_versions
    test_galaxy_api = TestGalaxyAPI(api_server='https://galaxy.ansible.com', name='galaxy')

# Generated at 2022-06-16 21:28:02.299813
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        return True
    assert test_func() is True



# Generated at 2022-06-16 21:28:04.365570
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        return True
    assert test_func()



# Generated at 2022-06-16 21:28:16.186306
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password')
    assert galaxy_api.api_server == 'https://galaxy.ansible.com'
    assert galaxy_api.username == 'username'
    assert galaxy_api.password == 'password'
    assert galaxy_api.token is None
    assert galaxy_api.token_expiration is None
    assert galaxy_api.available_api_versions == {}
    assert galaxy_api.name == 'galaxy.ansible.com'
    assert galaxy_api.verify_ssl is True
    assert galaxy_api.ignore_certs is False
    assert galaxy_api.no_cache is False
    assert galaxy_api.cache_path is None
    assert galaxy_api.cache is None
    assert galaxy_api.cache_max_age == 0

# Generated at 2022-06-16 21:28:17.668800
# Unit test for function g_connect
def test_g_connect():
    # TODO: Write unit test for function g_connect
    pass



# Generated at 2022-06-16 21:28:26.522300
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """
    Test the GalaxyAPI constructor.
    """
    # pylint: disable=protected-access
    api = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password')
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.username == 'username'
    assert api.password == 'password'
    assert api.token is None
    assert api.token_expires is None
    assert api.available_api_versions == {}
    assert api.name == 'galaxy.ansible.com'
    assert api.verify_ssl is True
    assert api.ignore_certs is False
    assert api.timeout == 10
    assert api.cache_path is None
    assert api._cache is None

# Generated at 2022-06-16 21:28:38.373377
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Test with an empty GalaxyAPI object
    galaxy_api = GalaxyAPI()
    assert not galaxy_api.__lt__(None)

    # Test with a GalaxyAPI object with a name
    galaxy_api = GalaxyAPI(name='test')
    assert not galaxy_api.__lt__(None)
    assert not galaxy_api.__lt__(GalaxyAPI())
    assert not galaxy_api.__lt__(GalaxyAPI(name='test'))
    assert galaxy_api.__lt__(GalaxyAPI(name='test2'))
    assert not galaxy_api.__lt__(GalaxyAPI(name='test', api_server='http://test.com'))
    assert galaxy_api.__lt__(GalaxyAPI(name='test2', api_server='http://test.com'))

# Generated at 2022-06-16 21:29:16.116744
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test with no parameters
    galaxy_api = GalaxyAPI()
    assert galaxy_api.name == 'galaxy'
    assert galaxy_api.api_server == 'https://galaxy.ansible.com'
    assert galaxy_api.ignore_certs is False
    assert galaxy_api.token is None
    assert galaxy_api.username is None
    assert galaxy_api.password is None
    assert galaxy_api.available_api_versions == {'v2': 'api/v2', 'v3': 'api/v3'}
    assert galaxy_api.cache_path is None

    # Test with parameters

# Generated at 2022-06-16 21:29:17.220265
# Unit test for function cache_lock
def test_cache_lock():
    # TODO: Add unit test
    pass



# Generated at 2022-06-16 21:29:23.100648
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI(name='test', api_server='test', ignore_certs=True, ignore_errors=True)
    galaxy_api_2 = GalaxyAPI(name='test2', api_server='test2', ignore_certs=True, ignore_errors=True)
    assert galaxy_api < galaxy_api_2


# Generated at 2022-06-16 21:29:29.041439
# Unit test for function g_connect
def test_g_connect():
    def test_func(self, *args, **kwargs):
        return args, kwargs
    wrapped = g_connect(['v1', 'v2'])(test_func)
    assert wrapped.__name__ == 'test_func'
    assert wrapped.__doc__ == test_func.__doc__
    assert wrapped.__module__ == test_func.__module__
    assert wrapped.__wrapped__ == test_func



# Generated at 2022-06-16 21:29:40.151428
# Unit test for function cache_lock

# Generated at 2022-06-16 21:29:44.135338
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    _CACHE_LOCK = threading.Lock()
    assert not _CACHE_LOCK.locked()
    with cache_lock(lambda: None):
        assert _CACHE_LOCK.locked()
    assert not _CACHE_LOCK.locked()



# Generated at 2022-06-16 21:29:56.122774
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password')
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.username == 'username'
    assert api.password == 'password'
    assert api.token is None
    assert api.token_expires is None
    assert api.token_url == 'https://galaxy.ansible.com/api/v1/users/token/'
    assert api.token_valid is False
    assert api.available_api_versions == {'v2': 'api/v2', 'v3': 'api/v3'}
    assert api.headers == {'Content-type': 'application/json'}
    assert api.cache_path == '~/.ansible/galaxy_cache'
    assert api.cache

# Generated at 2022-06-16 21:30:09.063524
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='http://localhost/v1', code=400, msg='Bad Request', hdrs={}, fp=None,
                           errcode=None, errmsg=None)
    message = 'Galaxy server error'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'http://localhost/v1'
    assert galaxy_error.message == 'Galaxy server error (HTTP Code: 400, Message: Bad Request)'

    http_error = HTTPError(url='http://localhost/v2', code=400, msg='Bad Request', hdrs={}, fp=None,
                           errcode=None, errmsg=None)
    message = 'Galaxy server error'

# Generated at 2022-06-16 21:30:23.064871
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443/') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80/') == 'galaxy.ansible.com:80'



# Generated at 2022-06-16 21:30:32.777292
# Unit test for function g_connect
def test_g_connect():
    def test_func(self, *args, **kwargs):
        return "test_func"
    wrapped = g_connect(['v1', 'v2'])(test_func)
    assert wrapped.__name__ == 'wrapped'
    assert wrapped.__doc__ == test_func.__doc__
    assert wrapped.__module__ == test_func.__module__
    assert wrapped.__dict__ == test_func.__dict__
    assert wrapped.__defaults__ == test_func.__defaults__
    assert wrapped.__closure__ == test_func.__closure__
    assert wrapped.__code__ == test_func.__code__
    assert wrapped.__globals__ == test_func.__globals__
    assert wrapped.__annotations__ == test_func.__annotations__
    assert wrapped.__

# Generated at 2022-06-16 21:31:25.669174
# Unit test for function g_connect
def test_g_connect():
    # TODO: Add unit test for function g_connect
    pass



# Generated at 2022-06-16 21:31:31.483563
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    _CACHE_LOCK = threading.Lock()
    assert _CACHE_LOCK.acquire(blocking=False) is True
    assert _CACHE_LOCK.locked() is True
    assert _CACHE_LOCK.release() is None
    assert _CACHE_LOCK.locked() is False
    assert _CACHE_LOCK.release() is None
    assert _CACHE_LOCK.locked() is False
    assert _CACHE_LOCK.acquire(blocking=False) is True
    assert _CACHE_LOCK.locked() is True
    assert _CACHE_LOCK.release() is None
    assert _CACHE_LOCK.locked() is False
    assert _CACHE_LOCK.acquire(blocking=False) is True
    assert _CACHE_

# Generated at 2022-06-16 21:31:42.354915
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test constructor with no arguments
    api = GalaxyAPI()
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.token is None
    assert api.ignore_certs is False
    assert api.name == 'galaxy.ansible.com'
    assert api.available_api_versions == {}

    # Test constructor with arguments
    api = GalaxyAPI('https://galaxy.ansible.com', 'test_token', True, 'test_name')
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.token == 'test_token'
    assert api.ignore_certs is True
    assert api.name == 'test_name'
    assert api.available_api_versions == {}



# Generated at 2022-06-16 21:31:50.811517
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI('https://galaxy.ansible.com', 'username', 'password')
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.username == 'username'
    assert api.password == 'password'
    assert api.token is None
    assert api.token_expires is None
    assert api.token_url == 'https://galaxy.ansible.com/api/v1/users/token/'
    assert api.available_api_versions == {'v2': 'api/v2', 'v3': 'api/v3'}
    assert api.api_server_with_version == 'https://galaxy.ansible.com/api/v2'

# Generated at 2022-06-16 21:32:02.802635
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('http://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('http://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('http://galaxy.ansible.com:8080') == 'galaxy.ansible.com:8080'
    assert get_cache_id('http://galaxy.ansible.com:8080/') == 'galaxy.ansible.com:8080'
    assert get_cache_id('http://galaxy.ansible.com/') == 'galaxy.ansible.com:'
    assert get

# Generated at 2022-06-16 21:32:12.212576
# Unit test for function g_connect
def test_g_connect():
    def test_func(self, *args, **kwargs):
        return 'test_func'
    test_func = g_connect(['v1', 'v2'])(test_func)
    assert test_func.__name__ == 'wrapped'
    assert test_func.__doc__ == 'Wrapper to lazily initialize connection info to Galaxy and verify the API versions required are available on the\n    endpoint.\n\n    :param versions: A list of API versions that the function supports.\n    '
    assert test_func.__module__ == 'ansible.galaxy.api'
    assert test_func.__wrapped__.__name__ == 'test_func'
    assert test_func.__wrapped__.__doc__ is None

# Generated at 2022-06-16 21:32:15.048531
# Unit test for function cache_lock
def test_cache_lock():
    # Test that the lock is acquired and released
    # by calling a function that acquires and releases
    # the lock and checking that the lock is available
    # before and after the call.
    with _CACHE_LOCK:
        assert _CACHE_LOCK.locked()
        wrapped = cache_lock(lambda: None)
        wrapped()
        assert not _CACHE_LOCK.locked()



# Generated at 2022-06-16 21:32:27.433705
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=404, msg='Not Found', hdrs=None, fp=None)
    message = 'Not Found'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Not Found (HTTP Code: 404, Message: Not Found Code: Unknown)'

    http_error = HTTPError(url='https://galaxy.ansible.com/api/v3/', code=404, msg='Not Found', hdrs=None, fp=None)
    message = 'Not Found'

# Generated at 2022-06-16 21:32:34.689507
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxyClient:
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com'
            self.name = 'test'
            self._available_api_versions = {}

        def _call_galaxy(self, url, method, error_context_msg, cache=False):
            return {'available_versions': {u'v1': u'v1/'}}

    gc = TestGalaxyClient()
    @g_connect(['v1'])
    def test_method(self):
        return True

    assert test_method(gc)

    @g_connect(['v2'])
    def test_method_v2(self):
        return True
