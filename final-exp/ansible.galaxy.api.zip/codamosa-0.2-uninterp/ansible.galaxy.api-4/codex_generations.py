

# Generated at 2022-06-16 21:23:43.550549
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=404, msg='Not Found', hdrs={}, fp=None)
    message = 'Error when finding available api versions from galaxy.ansible.com (https://galaxy.ansible.com/api/v2/)'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Error when finding available api versions from galaxy.ansible.com ' \
                                   '(https://galaxy.ansible.com/api/v2/) (HTTP Code: 404, Message: Not Found)'


# Generated at 2022-06-16 21:23:52.179826
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=404, msg='Not Found', hdrs=[], fp=None)
    message = 'Not Found'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Not Found (HTTP Code: 404, Message: Not Found Code: Unknown)'

    http_error = HTTPError(url='https://galaxy.ansible.com/api/v3/', code=404, msg='Not Found', hdrs=[], fp=None)
    message = 'Not Found'

# Generated at 2022-06-16 21:24:04.359149
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='http://galaxy.ansible.com/api/v2/', code=404, msg='Not Found', hdrs=None, fp=None)
    message = 'Error when finding available api versions from galaxy.ansible.com (http://galaxy.ansible.com/api/v2/)'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'http://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Error when finding available api versions from galaxy.ansible.com (http://galaxy.ansible.com/api/v2/) (HTTP Code: 404, Message: Not Found)'



# Generated at 2022-06-16 21:24:15.449755
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI(name='name', api_server='api_server', ignore_certs=False, ignore_errors=False,
                           timeout=10, token=None, username=None, password=None, force_basic_auth=False,
                           client_cert=None, force=False, available_api_versions=None, cache=None)
    galaxy_api2 = GalaxyAPI(name='name', api_server='api_server', ignore_certs=False, ignore_errors=False,
                            timeout=10, token=None, username=None, password=None, force_basic_auth=False,
                            client_cert=None, force=False, available_api_versions=None, cache=None)
    assert galaxy_api < galaxy_api2


# Generated at 2022-06-16 21:24:29.125992
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:80/') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'

# Generated at 2022-06-16 21:24:39.158910
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:80/api/v2/') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:80/api/v2/collections/')

# Generated at 2022-06-16 21:24:46.922881
# Unit test for function g_connect
def test_g_connect():
    """
    Unit test for function g_connect
    """
    def test_method(self, *args, **kwargs):
        return True

    # Test that the decorator returns the wrapped function
    assert g_connect(['v1', 'v2'])(test_method) is not test_method

    # Test that the wrapped function returns the result of the original function
    assert g_connect(['v1', 'v2'])(test_method)(None) is True



# Generated at 2022-06-16 21:24:47.969588
# Unit test for function g_connect
def test_g_connect():
    # TODO: Add unit test
    pass


# Generated at 2022-06-16 21:24:56.173942
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test with a valid Galaxy server
    galaxy_api = GalaxyAPI('https://galaxy.ansible.com')
    assert galaxy_api.api_server == 'https://galaxy.ansible.com'
    assert galaxy_api.name == 'galaxy.ansible.com'
    assert galaxy_api.token is None
    assert galaxy_api.username is None
    assert galaxy_api.password is None
    assert galaxy_api.ignore_certs is False
    assert galaxy_api.available_api_versions == {'v2': '/api/v2/', 'v3': '/api/v3/'}

    # Test with a valid Galaxy server and a token
    galaxy_api = GalaxyAPI('https://galaxy.ansible.com', token='abc123')

# Generated at 2022-06-16 21:25:05.320838
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:443/api/') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'


# Generated at 2022-06-16 21:25:41.277317
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api1 = GalaxyAPI(name='api1', api_server='https://api1.com', token='token1')
    api2 = GalaxyAPI(name='api2', api_server='https://api2.com', token='token2')
    assert api1 < api2
    assert not api2 < api1
    assert not api1 < api1


# Generated at 2022-06-16 21:25:50.026871
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=400, msg='Bad Request', hdrs='', fp=None)
    message = 'Error when finding available api versions from galaxy.ansible.com (https://galaxy.ansible.com/api/v2/)'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Error when finding available api versions from galaxy.ansible.com (https://galaxy.ansible.com/api/v2/) (HTTP Code: 400, Message: Bad Request)'



# Generated at 2022-06-16 21:25:56.830283
# Unit test for function cache_lock
def test_cache_lock():
    """
    Test that the cache_lock decorator works as expected.
    """
    global _CACHE_LOCK
    _CACHE_LOCK = threading.Lock()
    assert not _CACHE_LOCK.locked()

    @cache_lock
    def test_func():
        assert _CACHE_LOCK.locked()

    test_func()
    assert not _CACHE_LOCK.locked()



# Generated at 2022-06-16 21:26:01.247240
# Unit test for function g_connect
def test_g_connect():
    def test_method(self, *args, **kwargs):
        return True
    wrapped = g_connect(['v1', 'v2'])(test_method)
    assert wrapped(None) == True


# Generated at 2022-06-16 21:26:12.369246
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api = GalaxyAPI(name='test', api_server='https://galaxy.ansible.com')
    assert api < GalaxyAPI(name='test', api_server='https://galaxy.ansible.com')
    assert api < GalaxyAPI(name='test', api_server='https://galaxy.ansible.com/api/v2')
    assert api < GalaxyAPI(name='test', api_server='https://galaxy.ansible.com/api/v3')
    assert api < GalaxyAPI(name='test', api_server='https://galaxy.ansible.com/api/v3/')
    assert api < GalaxyAPI(name='test', api_server='https://galaxy.ansible.com/api/v3/', token='token')

# Generated at 2022-06-16 21:26:21.735208
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=404, msg='Not Found', hdrs=[], fp=None)
    message = 'Not Found'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Not Found (HTTP Code: 404, Message: Not Found Code: Unknown)'

    http_error = HTTPError(url='https://galaxy.ansible.com/api/v3/', code=404, msg='Not Found', hdrs=[], fp=None)
    message = 'Not Found'

# Generated at 2022-06-16 21:26:34.707236
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxyAPI:
        def __init__(self, name, api_server):
            self.name = name
            self.api_server = api_server
            self._available_api_versions = {}

        @g_connect(['v1', 'v2'])
        def test_method(self):
            return True

    api = TestGalaxyAPI('test', 'https://galaxy.ansible.com')
    assert api.test_method()

    api = TestGalaxyAPI('test', 'https://galaxy.ansible.com/api/')
    assert api.test_method()

    api = TestGalaxyAPI('test', 'https://galaxy.ansible.com/api')
    assert api.test_method()


# Generated at 2022-06-16 21:26:46.638903
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxy:
        def __init__(self, api_server):
            self.api_server = api_server
            self._available_api_versions = {}
            self.name = 'test'

        @g_connect(['v1'])
        def test_method(self):
            return True

        def _call_galaxy(self, url, method='GET', data=None, error_context_msg=None, cache=True):
            return {'available_versions': {'v1': 'v1/'}}

    test_galaxy = TestGalaxy('https://galaxy.ansible.com')
    assert test_galaxy.test_method() is True



# Generated at 2022-06-16 21:26:57.733892
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://www.example.com') == 'www.example.com:'
    assert get_cache_id('http://www.example.com:80') == 'www.example.com:80'
    assert get_cache_id('http://www.example.com:443') == 'www.example.com:443'
    assert get_cache_id('http://www.example.com:8080') == 'www.example.com:8080'
    assert get_cache_id('http://www.example.com:8080/') == 'www.example.com:8080'
    assert get_cache_id('http://www.example.com:8080/api/') == 'www.example.com:8080'

# Generated at 2022-06-16 21:27:02.054207
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxy:
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com'
            self.name = 'galaxy'
            self._available_api_versions = {}

        @g_connect(versions=['v1', 'v2'])
        def test_method(self):
            return True

    tg = TestGalaxy()
    assert tg.test_method()



# Generated at 2022-06-16 21:28:03.840466
# Unit test for function cache_lock
def test_cache_lock():
    # Test that the lock is acquired and released
    # This is done by checking that the lock is not locked before and after the function call
    # and that the lock is locked during the function call
    lock = threading.Lock()
    lock.acquire()
    assert lock.locked()
    @cache_lock
    def test_func():
        assert lock.locked()
    assert not lock.locked()
    test_func()
    assert not lock.locked()



# Generated at 2022-06-16 21:28:09.248742
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='http://localhost:8080/v2/', code=400, msg='Bad Request', hdrs={}, fp=None)
    message = 'Galaxy server error'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'http://localhost:8080/v2/'
    assert galaxy_error.message == 'Galaxy server error (HTTP Code: 400, Message: Bad Request)'



# Generated at 2022-06-16 21:28:14.056316
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    _CACHE_LOCK = threading.Lock()
    assert not _CACHE_LOCK.locked()
    with cache_lock(lambda: None):
        assert _CACHE_LOCK.locked()
    assert not _CACHE_LOCK.locked()



# Generated at 2022-06-16 21:28:15.087534
# Unit test for function g_connect
def test_g_connect():
    # TODO: Add unit test
    pass


# Generated at 2022-06-16 21:28:24.866686
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Test with a GalaxyAPI object that has a lower name
    galaxy_api_1 = GalaxyAPI(name='test_galaxy_api_1', api_server='https://galaxy.ansible.com')
    galaxy_api_2 = GalaxyAPI(name='test_galaxy_api_2', api_server='https://galaxy.ansible.com')
    assert galaxy_api_1 < galaxy_api_2

    # Test with a GalaxyAPI object that has a higher name
    galaxy_api_1 = GalaxyAPI(name='test_galaxy_api_2', api_server='https://galaxy.ansible.com')
    galaxy_api_2 = GalaxyAPI(name='test_galaxy_api_1', api_server='https://galaxy.ansible.com')
    assert not galaxy_api_1 < galaxy_api_

# Generated at 2022-06-16 21:28:27.697590
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    _CACHE_LOCK = threading.Lock()
    assert _CACHE_LOCK.locked() == False
    @cache_lock
    def test_func():
        assert _CACHE_LOCK.locked() == True
    test_func()
    assert _CACHE_LOCK.locked() == False



# Generated at 2022-06-16 21:28:36.268877
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='http://localhost:8080/api/v2/', code=400, msg='Bad Request', hdrs=[], fp=None)
    message = 'Error when finding available api versions from localhost:8080'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'http://localhost:8080/api/v2/'
    assert galaxy_error.message == 'Error when finding available api versions from localhost:8080 (HTTP Code: 400, Message: Bad Request)'



# Generated at 2022-06-16 21:28:39.197350
# Unit test for function cache_lock
def test_cache_lock():
    # Test that the lock is acquired and released
    @cache_lock
    def test_func():
        return True

    assert test_func()



# Generated at 2022-06-16 21:28:50.213930
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxyAPI(object):
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com'
            self.name = 'galaxy.ansible.com'
            self._available_api_versions = {}

        def _call_galaxy(self, url, method='GET', data=None, error_context_msg=None, cache=False):
            return {'available_versions': {'v1': 'v1/'}}

        @g_connect(['v1'])
        def test_method(self):
            return True

    api = TestGalaxyAPI()
    assert api.test_method()

    api._available_api_versions = {'v2': 'v2/'}

# Generated at 2022-06-16 21:28:56.351297
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxy:
        def __init__(self, name, api_server):
            self.name = name
            self.api_server = api_server
            self._available_api_versions = None

        @g_connect(versions=['v1', 'v2'])
        def test_method(self):
            return True

    tg = TestGalaxy('test', 'https://galaxy.ansible.com')
    assert tg.test_method() is True

    tg = TestGalaxy('test', 'https://galaxy.ansible.com/api/')
    assert tg.test_method() is True

    tg = TestGalaxy('test', 'https://galaxy.ansible.com/api')
    assert tg.test_method() is True


# Generated at 2022-06-16 21:29:58.866341
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        return True

    assert test_func()



# Generated at 2022-06-16 21:30:10.982078
# Unit test for function g_connect
def test_g_connect():
    def test_func(self, *args, **kwargs):
        return "test_func"
    test_func = g_connect(['v1', 'v2'])(test_func)
    assert test_func.__name__ == 'wrapped'
    assert test_func.__doc__ == 'Wrapper to lazily initialize connection info to Galaxy and verify the API versions required are available on the\n    endpoint.\n\n    :param versions: A list of API versions that the function supports.\n    '
    assert test_func.__module__ == 'ansible.galaxy.api'
    assert test_func.__wrapped__.__name__ == 'test_func'
    assert test_func.__wrapped__.__doc__ == None

# Generated at 2022-06-16 21:30:23.774534
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com/api') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com/api/v1/') == 'galaxy.ansible.com:'
    assert get_cache_

# Generated at 2022-06-16 21:30:28.267481
# Unit test for function g_connect
def test_g_connect():
    class TestClass(object):
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com'
            self.name = 'galaxy.ansible.com'
            self._available_api_versions = {}
            self._call_galaxy = lambda x, y, z, **kwargs: {'available_versions': {'v1': 'v1/'}}

    test_obj = TestClass()
    @g_connect(['v1'])
    def test_func(self):
        return True

    assert test_func(test_obj)
    assert test_obj._available_api_versions == {'v1': 'v1/'}

    @g_connect(['v2'])
    def test_func(self):
        return True


# Generated at 2022-06-16 21:30:41.283190
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443/') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com:80/') == 'galaxy.ansible.com:80'
    assert get_cache_

# Generated at 2022-06-16 21:30:47.157036
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(GalaxyError(http_code=404))



# Generated at 2022-06-16 21:30:59.913310
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('https://galaxy.ansible.com/api/v2/', 404, 'Not Found', {}, None)
    message = 'Test message'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Test message (HTTP Code: 404, Message: Not Found Code: Unknown)'

    http_error = HTTPError('https://galaxy.ansible.com/api/v3/', 404, 'Not Found', {}, None)
    message = 'Test message'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 404
    assert galaxy_error.url

# Generated at 2022-06-16 21:31:06.167543
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url='https://galaxy.ansible.com/api/v2/', code=403, msg='Forbidden', hdrs={}, fp=None)
    message = 'Test message'
    galaxy_error = GalaxyError(http_error, message)
    assert galaxy_error.http_code == 403
    assert galaxy_error.url == 'https://galaxy.ansible.com/api/v2/'
    assert galaxy_error.message == 'Test message (HTTP Code: 403, Message: Forbidden Code: Unknown)'



# Generated at 2022-06-16 21:31:18.263113
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxyConnection(object):
        def __init__(self, api_server):
            self.api_server = api_server
            self._available_api_versions = {}
            self.name = 'test'

        def _call_galaxy(self, url, method='GET', data=None, error_context_msg=None, cache=False):
            return {'available_versions': {u'v1': u'v1/'}}

    class TestGalaxyConnection2(object):
        def __init__(self, api_server):
            self.api_server = api_server
            self._available_api_versions = {}
            self.name = 'test'

        def _call_galaxy(self, url, method='GET', data=None, error_context_msg=None, cache=False):
            return

# Generated at 2022-06-16 21:31:27.433006
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxy(object):
        def __init__(self, api_server):
            self.api_server = api_server
            self._available_api_versions = {}
            self.name = 'test'

        @g_connect(versions=['v1', 'v2'])
        def test_method(self):
            pass

    # Test that we can connect to a v1 galaxy server
    test_galaxy = TestGalaxy('https://galaxy.ansible.com')
    test_galaxy.test_method()

    # Test that we can connect to a v2 galaxy server
    test_galaxy = TestGalaxy('https://galaxy.ansible.com/api/v2/')
    test_galaxy.test_method()

    # Test that we can connect to a v2 galaxy server with /api/ app