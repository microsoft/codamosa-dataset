

# Generated at 2022-06-24 19:18:30.031010
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    var_0 = GalaxyAPI("GalaxyAPI Server", "https://ansible.galaxy.example.com", [], [])
    int_0 = -22
    dict_0 = {int_0: "GalaxyAPI Server"}
    int_1 = 1
    int_0 = 9
    dict_1 = {int_0: "GalaxyAPI Server"}
    int_2 = 1
    int_0 = -33
    dict_2 = {int_0: "GalaxyAPI Server"}
    int_3 = 1
    int_0 = -22
    int_4 = 1
    int_0 = -22
    var_1 = GalaxyAPI("GalaxyAPI Server", "https://ansible.galaxy.example.com", [], [])
    int_5 = 1


# Generated at 2022-06-24 19:18:32.044280
# Unit test for function g_connect
def test_g_connect():
    int_0 = None
    int_1 = -535
    int_2 = -849
    # Testing Case 0
    test_case_0()


# Generated at 2022-06-24 19:18:41.077698
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    _galaxy_server = 'http://localhost:8080'
    _token = 'fake-token'
    obj = GalaxyAPI(_galaxy_server, _token)


    # Attributes
    # This attribute is a derived attribute which is read-only
    # The validation was already done in the setter method
    #
    # The validation is generally done in GalaxyAPI.set_api_token()
    #
    #Attribute: api_token
    ret = obj.api_token
    assert ret == 'fake-token'


    # Attributes
    # This attribute is a derived attribute which is read-only
    # The validation was already done in the setter method
    #
    # The validation is generally done in GalaxyAPI.set_api_server()
    #
    #Attribute: api_server
    ret = obj.api_server

# Generated at 2022-06-24 19:18:44.167945
# Unit test for function cache_lock
def test_cache_lock():
    # int_0 not initialized
    func_0 = cache_lock(lambda: None)  # TODO needs type
    func_0() # TODO missing call; looks like a unit test

# Generated at 2022-06-24 19:18:46.045951
# Unit test for function g_connect
def test_g_connect():
    list_0 = None
    var_0 = g_connect(list_0)
    print(var_0)


# Generated at 2022-06-24 19:18:54.015262
# Unit test for function cache_lock
def test_cache_lock():
    int_0 = 18446744073709551615
    var_0 = cache_lock(test_case_0)
    var_0()
    var_0().int_0 = int_0
    var_0().var_0 = int_0
    var_0().list_0[0] = int_0
    var_0().list_0[1] = int_0
    var_0().int_1 = int_0
    var_0().int_2 = int_0


# Generated at 2022-06-24 19:18:56.073210
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    var_0 = GalaxyError(test_case_0(), 'test_case_0')


# Generated at 2022-06-24 19:18:57.016709
# Unit test for function g_connect
def test_g_connect():
    verify_g_connect()


# Generated at 2022-06-24 19:19:00.734257
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    var_0 = GalaxyAPI()
    attr_0 = GalaxyAPI()  # native ansible
    attr_0.name = 'native_ansible'
    int_0 = None
    var_1 = var_0.__lt__(int_0)
    int_1 = -26
    int_2 = -363


# Generated at 2022-06-24 19:19:07.003919
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    int_0 = -541
    int_1 = -1
    int_2 = -475
    var_0 = GalaxyAPI(int_0, int_1, int_2)
    int_3 = -838
    int_4 = -987
    int_5 = -838
    var_1 = GalaxyAPI(int_3, int_4, int_5)
    int_6 = -838
    int_7 = -987
    int_8 = -838
    var_2 = GalaxyAPI(int_6, int_7, int_8)
    assert var_0 < var_2 == True
    assert var_1 < var_0 == False


# Generated at 2022-06-24 19:19:58.725383
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        http_error = HTTPError(url='url', code=int, msg='msg', hdrs='hdrs', fp='fp', filename='filename')
        message = 'message'
    except:
        raise
    else:
        galaxy_error = GalaxyError(http_error, message)
        if isinstance(galaxy_error, GalaxyError) == False :
            print(galaxy_error)
        assert isinstance(galaxy_error, GalaxyError)
        assert galaxy_error.http_code == int
        assert galaxy_error.url == 'url'
        assert galaxy_error.message == 'message'



# Generated at 2022-06-24 19:20:00.938578
# Unit test for function cache_lock
def test_cache_lock():
    assert cache_lock(test_case_0)

    

# Generated at 2022-06-24 19:20:08.649326
# Unit test for function cache_lock
def test_cache_lock():
    path_1 = os.path.join(os.path.dirname(__file__), 'test_case_0.txt')
    os.makedirs(os.path.dirname(path_1), exist_ok=True)
    with open(path_1, 'w') as file_1:
        file_1.write('test_case_0(\n')
    with open(path_1, 'a') as file_1:
        file_1.write(')\n')


# Generated at 2022-06-24 19:20:14.592161
# Unit test for function g_connect
def test_g_connect():
    # Initialize instance variables
    test_object = GalaxyAPI(account=None, token=None)
    test_object.name = None
    test_object.api_server = None

    # Call function g_connect
    result = g_connect(versions=[])

    # Verify the results
    assert result == decorator

# Generated at 2022-06-24 19:20:19.172893
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # first create a GalaxyAPI instance
    api_server = "https://galaxy.ansible.com"
    args = (api_server,)
    kwargs = {'verify_ssl': True, 'force_api_version': 'v2'}

    # create a GalaxyAPI instance
    galaxy_api_0 = GalaxyAPI(*args, **kwargs)

    assert galaxy_api_0.api_server == api_server
    assert galaxy_api_0.name == None
    assert galaxy_api_0.verify_ssl == True
    assert galaxy_api_0.force_api_version == 'v2'
    assert galaxy_api_0.available_api_versions == ['v2']


# Generated at 2022-06-24 19:20:20.212686
# Unit test for constructor of class GalaxyError
def test_GalaxyError():

    galaxy_error_0 = GalaxyError(mock_HTTPError())


# Generated at 2022-06-24 19:20:27.275698
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    exception = HTTPError()
    message = 'hello'
    try:
        test_case_0()
    except HTTPError as e:
        exception = e
    err = GalaxyError(exception,message)
    print(err.message)

# Generated at 2022-06-24 19:20:35.558527
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Setup fixture
    username = 'user0'
    password = 'password0'
    client_id = 'client_id0'
    insecure = False
    url = 'http://galaxy.server.test'

    # Exercise SUT
    ansible_galaxy_api = GalaxyAPI(username, password, client_id, insecure, url)

    # Verify results
    assert ansible_galaxy_api.available_api_versions['v2'] == 'api/v2'
    assert ansible_galaxy_api.name == 'galaxy'
    assert ansible_galaxy_api.username == username
    assert ansible_galaxy_api.password == password
    assert ansible_galaxy_api.client_id == client_id
    assert ansible_galaxy_api.insecure == insecure
    assert ansible_gal

# Generated at 2022-06-24 19:20:45.775961
# Unit test for function g_connect
def test_g_connect():
    versions = ["v1","v2"]

    def decorator(method):
        def wrapped(self, *args, **kwargs):
            if not self._available_api_versions:
                display.vvvv("Initial connection to galaxy_server: %s" % self.api_server)

                # Determine the type of Galaxy server we are talking to. First try it unauthenticated then with Bearer
                # auth for Automation Hub.
                n_url = self.api_server
                error_context_msg = 'Error when finding available api versions from %s (%s)' % (self.name, n_url)


# Generated at 2022-06-24 19:20:50.012298
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError("test_url", 400, "test_msg", None, None)
    message = "test_case_0"
    galaxyError = GalaxyError(http_error, message)
    assert galaxyError.http_code == 400 and galaxyError.url == 'test_url' and galaxyError.message == "test_case_0 (HTTP Code: 400, Message: test_msg)"


# Generated at 2022-06-24 19:21:26.599175
# Unit test for function g_connect
def test_g_connect():
    versions = ['v1', 'v2']
    method = callable

    wrapped = g_connect(versions)(method)

    assert isinstance(wrapped, collections.Callable)



# Generated at 2022-06-24 19:21:27.552193
# Unit test for function g_connect
def test_g_connect():
    pass


# Generated at 2022-06-24 19:21:35.045002
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI(None, "Galaxy", "https://galaxy.ansible.com/api/")
    assert galaxy_api.name == "Galaxy"
    assert galaxy_api.api_server == "https://galaxy.ansible.com/api/"
    assert galaxy_api.token is None
    assert galaxy_api.available_api_versions == {'v2': '/api/v2/', 'v3': '/api/v3/'}
    assert galaxy_api.cache is None
    assert galaxy_api.verify_ssl


# Generated at 2022-06-24 19:21:38.270872
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert excinfo.value.args[0] == "object of type 'long' has no len()"


# Generated at 2022-06-24 19:21:45.294676
# Unit test for function g_connect
def test_g_connect():
    try:
        import ansible.module_utils.galaxy_args as _galaxy_args
        import ansible_galaxy as _ansible_galaxy
        import collections

        from ansible.cli.galaxy import GalaxyCLI as _GalaxyCLI
    except Exception as e:
        print(e)
        print("In order to run the tests, you need to install the required dependencies. Use the command: pip install -r tests/requirements.txt")
        sys.exit(1)
    galaxy_context = _ansible_galaxy.context.GalaxyContext(cli_args=_GalaxyCLI(args=[]).parse())
    ns = collections.namedtuple('object', ['api_server'])
    api_server = _galaxy_args.GalaxyAPIArgs.galaxy_api_server
    ns.api_

# Generated at 2022-06-24 19:21:49.370433
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('http_error', 'http_code', 'http_msg', 'http_hdrs', 'http_fp')
    message = 'http_reason'
    try:
        galaxy_error = GalaxyError(http_error, message)
    except Exception as e:
        assert type (e) == AnsibleError


# Generated at 2022-06-24 19:21:58.661145
# Unit test for function get_cache_id
def test_get_cache_id():
    url_0 = 'http://galaxy.ansible.com/'
    url_1 = 'http://galaxy.ansible.com/api/v1'
    url_2 = 'http://galaxy.ansible.com/api/v2'
    url_3 = 'http://galaxy.ansible.com/api/v3'
    url_4 = 'http://galaxy.ansible.com/api/v4'
    url_5 = 'http://galaxy.ansible.com/api/v5'
    url_6 = 'http://galaxy.ansible.com/api/v6'
    url_7 = 'http://galaxy.ansible.com/api/v7'
    url_8 = 'http://galaxy.ansible.com/api/v8'

# Generated at 2022-06-24 19:22:00.480118
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # No arguments
    if is_rate_limit_exception() == None:
        test_case_0()
    
    


# Generated at 2022-06-24 19:22:08.924805
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = object()
    message = object()
    ans_instance = GalaxyError(http_error, message)
    print(ans_instance.http_code)
    print(ans_instance.url)
    print(ans_instance.message)
    print(type(ans_instance.http_code))
    print(type(ans_instance.url))
    print(type(ans_instance.message))
    print(ans_instance.http_code == http_error.code)
    print(ans_instance.url == http_error.geturl())
    print(ans_instance.http_code == message.code)
    print(ans_instance.url == message.geturl())
    print(ans_instance.message == message)
    print(ans_instance.http_code == message)

# Generated at 2022-06-24 19:22:11.157113
# Unit test for function get_cache_id
def test_get_cache_id():
    test_case_0()

# Generated at 2022-06-24 19:22:44.413488
# Unit test for function cache_lock
def test_cache_lock():
    try:
        func_0 = cache_lock(test_case_0)
        func_0()
    except HTTPError as exception:
        display.display('Test cache_lock error: %s' % to_native(exception))

# Unit test runner

# Generated at 2022-06-24 19:22:54.888462
# Unit test for function get_cache_id
def test_get_cache_id():
    str_0 = '?4v4z'
    str_1 = 'B2F8T#T'
    str_2 = 'Z)a'
    str_3 = 'H7q3y'
    str_4 = '?4v4z'
    str_5 = 'B2F8T#T'
    str_6 = 'Z)a'
    str_7 = 'H7q3y'
    str_8 = '?4v4z'
    str_9 = 'B2F8T#T'
    str_10 = 'Z)a'
    str_11 = 'H7q3y'
    str_12 = '?4v4z'
    str_13 = 'B2F8T#T'
    str_14 = 'Z)a'
    str_15

# Generated at 2022-06-24 19:23:00.760835
# Unit test for function get_cache_id
def test_get_cache_id():
    str_0 = 'v'
    str_1 = 'on'
    str_2 = 'https://galaxy.ansible.com/api/'
    str_exp_0 = 'https://galaxy.ansible.com/api/'
    var_0 = urljoin(str_0,str_1,str_2)
    assert var_0 == str_exp_0
    str_3 = get_cache_id.__name__
    print(str_3)


# Generated at 2022-06-24 19:23:02.513899
# Unit test for function cache_lock
def test_cache_lock():
    str_0 = '+t?@lR@'
    var_0 = cache_lock(test_case_0)(str_0)


# Generated at 2022-06-24 19:23:06.248573
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api = GalaxyAPI(name='test', api_server='test.com')
    assert api.__lt__(3)


# Generated at 2022-06-24 19:23:15.818946
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    var_0 = None
    try:
        # class GalaxyAPI is the argument of constructor
        # the class GalaxyAPI is defined in GalaxyAPI.py, imported from ansible.module_utils
        var_0 = GalaxyAPI(None)
        assert type(var_0) == GalaxyAPI
    except Exception:
        var_0 = False
    finally:
        assert type(var_0) == bool
        assert var_0 == True

    try:
        # class GalaxyAPI is the argument of constructor
        # the class GalaxyAPI is defined in GalaxyAPI.py, imported from ansible.module_utils
        var_0 = GalaxyAPI('Test')
        assert type(var_0) == GalaxyAPI
    except Exception:
        var_0 = False
    finally:
        assert type(var_0) == bool
        assert var_0 == True



# Generated at 2022-06-24 19:23:17.231859
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    test_case_0()



# Generated at 2022-06-24 19:23:18.994000
# Unit test for function cache_lock
def test_cache_lock():
    pass


# Generated at 2022-06-24 19:23:20.907504
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    var = GalaxyAPI('test_value')
    var_0 = var.__lt__()


# Generated at 2022-06-24 19:23:31.407870
# Unit test for function g_connect
def test_g_connect():
    class GalaxyEndpoint:
        def __init__(self, api_server, name):
            self.api_server = api_server
            self.name = name
            self._available_api_versions = None

        def _call_galaxy(self, url, method='GET', data=None, error_context_msg='', cache=False):
            pass

    endpoint = GalaxyEndpoint('localhost', 'test')
    endpoint = g_connect(['v1'])(endpoint)
    endpoint.api_server = 'http://localhost:8080/api'

    with open('inputs/versions.json') as f:
        versions = json.load(f)
        version_keys = list(versions.keys())
        endpoint._call_galaxy = lambda *args, **kwargs: versions
        endpoint()

# Generated at 2022-06-24 19:24:02.476610
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    test_case_0()



# Generated at 2022-06-24 19:24:09.449094
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # Test for a non-error.
    try:
        test_case_0()
    except:
        assert False
        
    # Test for an error
    exception_0 = Exception
    try:
        with pytest.raises(exception_0):
            is_rate_limit_exception(exception_0)
    except:
        assert False



# Generated at 2022-06-24 19:24:12.130126
# Unit test for function g_connect
def test_g_connect():
    version = ['v3', 'v2']
    def fun_method(argv):
        pass
    # TODO: add test case
    # g_connect(version)(fun_method)('')


# Generated at 2022-06-24 19:24:13.902552
# Unit test for function get_cache_id
def test_get_cache_id():
    print("Running test case: %s" % test_case_0.__name__)
    test_case_0()


# Generated at 2022-06-24 19:24:16.260815
# Unit test for constructor of class GalaxyError
def test_GalaxyError():

    # Create a new error object
    error_object = GalaxyError(test_case_0(),'An error message for the user')

    # Verify the properties of the galaxy error object
    assert error_object.http_code == 429
    assert error_object.message == 'An error message for the user'



# Generated at 2022-06-24 19:24:26.527701
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    HTTPError_mock = HTTPError('http://www.example.com', 500, None, None, None)
    HTTPError_mock.code = 500
    HTTPError_mock.geturl = functools.partial(HTTPError.geturl, HTTPError_mock)
    HTTPError_mock.read = functools.partial(HTTPError.read, HTTPError_mock)

    error = GalaxyError(HTTPError_mock, 'message')
    assert error.http_code == 500
    assert error.url == 'http://www.example.com'
    assert isinstance(error.message, string_types)
    assert 'message' in error.message



# Generated at 2022-06-24 19:24:27.242112
# Unit test for function get_cache_id
def test_get_cache_id():
    # Test case 0
    test_case_0()


# Generated at 2022-06-24 19:24:33.916215
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    obj_1 = GalaxyAPI('JHdQhbx+', 'http://gfynz:7897/')
    str_1 = 't0'
    obj_2 = GalaxyAPI(str_1)
    var_0 = obj_1 < obj_2
    print('TEST: %s < %s => %s' % (repr(obj_1), repr(obj_2), var_0))


# Generated at 2022-06-24 19:24:36.046860
# Unit test for function g_connect
def test_g_connect():
    versions = ['1', '2']
    method = wrapper()
    wrapped = g_connect(versions)(method)
    wrapped('self', '*args', '**kwargs')


# Generated at 2022-06-24 19:24:40.026823
# Unit test for function get_cache_id
def test_get_cache_id():
    arg_0 = 'https://galaxy.ansible.com/api/'
    var_0 = get_cache_id(arg_0)
    if var_0 == 'galaxy.ansible.com:' :
        var_1 = 0
    else:
        var_1 = 1
    return var_1



# Generated at 2022-06-24 19:25:36.056998
# Unit test for function cache_lock
def test_cache_lock():
    pass



# Generated at 2022-06-24 19:25:38.577273
# Unit test for function g_connect
def test_g_connect():
    method = g_connect(['v1', 'v2'])
    assert hasattr(method, '__call__')


# Generated at 2022-06-24 19:25:40.463397
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        test_case_0()
    except Exception as e:
        print("Caught an exception in the test case: ", e)



# Generated at 2022-06-24 19:25:42.070889
# Unit test for function g_connect
def test_g_connect():
    # Setup
    versions = 2

    # Exercise
    g_connect(versions)

    # Verify

    # Teardown
    return


# Generated at 2022-06-24 19:25:50.211289
# Unit test for function g_connect

# Generated at 2022-06-24 19:25:51.009072
# Unit test for function g_connect
def test_g_connect():
    test_case_0()


# Generated at 2022-06-24 19:25:51.642785
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    test_case_0()


# Generated at 2022-06-24 19:26:00.520181
# Unit test for function g_connect
def test_g_connect():
    versions = ['v1', 'v2']

    def decorator(method):
        def wrapped(self, *args, **kwargs):
            if not self._available_api_versions:
                display.vvvv("Initial connection to galaxy_server: %s" % self.api_server)

                # Determine the type of Galaxy server we are talking to. First try it unauthenticated then with Bearer
                # auth for Automation Hub.
                n_url = self.api_server
                error_context_msg = 'Error when finding available api versions from %s (%s)' % (self.name, n_url)


# Generated at 2022-06-24 19:26:01.629725
# Unit test for function get_cache_id
def test_get_cache_id():
    var_0 = 'https://ansible.com/galaxy'
    var_1 = get_cache_id(var_0)


# Generated at 2022-06-24 19:26:03.093210
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        GalaxyError(test_case_0(), "test")
    except TypeError:
        pass



# Generated at 2022-06-24 19:27:08.788627
# Unit test for function cache_lock
def test_cache_lock():
    str_0 = 'hQ2X1fzF-_E7a&Mp'
    var_0 = cache_lock(str_0)
    assert var_0 == 'hQ2X1fzF-_E7a&Mp'


# Generated at 2022-06-24 19:27:12.690532
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        str_0 = 'K7hBem-85ez62#@'
        var_1 = GalaxyError(str_0, 'Gnxlx_jmTF-2*KZ')
        test_case_0()
    except Exception as e:
        print(e)



# Generated at 2022-06-24 19:27:13.562743
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    test_case_0()


# Generated at 2022-06-24 19:27:15.673460
# Unit test for function g_connect
def test_g_connect():
    str_0 = 'K7hBem-85ez62#@'
    func_0 = g_connect(str_0)
    return



# Generated at 2022-06-24 19:27:22.430488
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    var_1 = None
    str_1 = 'K7hBem-85ez62#@'
    var_1 = test_case_0()
    if var_1 is not None:
        str_2 = 'Cannot rate limit exception.Expected:{} Received:{}'.format(str_1,var_1)
        print(str_2)
    else:
        print('Cannot rate limit exception')

if __name__ == '__main__':
    test_is_rate_limit_exception()

# Generated at 2022-06-24 19:27:25.634937
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    var_1 = GalaxyError(message='message_0', http_code='http_code_0')
    return var_1


# Generated at 2022-06-24 19:27:35.967581
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    c_mock = GalaxyAPI('GalaxyName', 'GalaxyURL', False, None, None, None, None)
    assert (c_mock.name == 'GalaxyName')
    assert (c_mock.api_server == 'GalaxyURL')
    assert (c_mock.verify_ssl == False)
    assert (c_mock.api_token is None)
    assert (c_mock.client_id is None)
    assert (c_mock.client_secret is None)
    assert (c_mock.api_key is None)
    assert (c_mock.available_api_versions == {})
    assert (c_mock.current_header == {})
    assert (c_mock.token_expiration_datetime is None)

# Generated at 2022-06-24 19:27:40.556342
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        test_case_0()
    except Exception:
        print("galaxy-error.py test case 0 did not pass")
        raise
