

# Generated at 2022-06-24 19:18:48.502953
# Unit test for function cache_lock
def test_cache_lock():
    try:
        test_case_0()
    except Exception as e:
        print(e)
    else:
        print("Ok\n")


# Generated at 2022-06-24 19:18:50.260586
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    test_instance_0 = GalaxyAPI()
    test_instance_1 = GalaxyAPI()
    var_0 = test_instance_0 < test_instance_1


# Generated at 2022-06-24 19:18:53.412028
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(404, "Error 0")
    message = "Message 0"
    err_0 = GalaxyError(http_error, message)



# Generated at 2022-06-24 19:18:59.244772
# Unit test for function get_cache_id
def test_get_cache_id():
    list_0 = ['https://galaxy.ansible.com', 'https://galaxy.ansible.com/']
    var_0 = get_cache_id(list_0)
    list_1 = ['https://galaxy.ansible.com']
    var_1 = get_cache_id(list_1)
    if var_0 != var_1:
        print("test_get_cache_id was not successful")



# Generated at 2022-06-24 19:19:00.753495
# Unit test for function get_cache_id
def test_get_cache_id():
    print('Testing get_cache_id')
    test_case_0()


# Generated at 2022-06-24 19:19:08.009731
# Unit test for function g_connect
def test_g_connect():
    versions = ['v1', 'v2']

    def decorator(method):
        def wrapped(self, *args, **kwargs):
            if not self._available_api_versions:
                display.vvvv("Initial connection to galaxy_server: %s" % self.api_server)
                display.vvvv("Found API version '%s' with Galaxy server %s (%s)"
                             % (', '.join(versions), self.name, self.api_server))
            # Verify that the API versions the function works with are available on the server specified.
            available_versions = set(versions)
            common_versions = set(versions).intersection(available_versions)

# Generated at 2022-06-24 19:19:09.267446
# Unit test for function g_connect
def test_g_connect():
    url_0 = urlparse('https://galaxy.ansible.com/api/')
    test_case_0()

# Generated at 2022-06-24 19:19:19.806417
# Unit test for function g_connect
def test_g_connect():
    versions = [None]
    func = [None, None]
    args = [None, None]
    kwargs = [None, None]
    context = {'self': None}
    func[0] = 'g_connect'
    args[0] = (versions[0],)
    kwargs[0] = {'method': func[0], 'self': context['self']}
    func[1] = 'wrapped'
    args[1] = (args[0],)
    kwargs[1] = {'*args': args[0], '**kwargs': kwargs[0]}
    kwargs[0]['method'] = func[1]
    func[2] = 'get_cache_id'
    args[2] = (list_0, )
    kwargs[2]

# Generated at 2022-06-24 19:19:21.743562
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    var_0 = GalaxyAPI(None, None, None)
    var_1 = GalaxyAPI(None, None, None)
    result = var_0.__lt__(var_1)
    assert result is False


# Generated at 2022-06-24 19:19:23.629541
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # No exception expected so far
    try:
        test_case_0()
    except:
        assert False
# ---- END test cases ----


# Generated at 2022-06-24 19:19:55.838509
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    list_0 = ['https://galaxy.ansible.com/conma/conma/0.1/', 'conma_0.1.tar.gz']
    http_error_0 = HTTPError(list_0[0], 500, 'Internal Server Error', {}, None)
    message_0 = 'Internal Server Error'
    err_0 = GalaxyError(http_error_0, message_0)


# Generated at 2022-06-24 19:20:02.191079
# Unit test for function g_connect
def test_g_connect():
    var_0 = g_connect([None, None])
    try:
        var_0(test_case_0)
    except AnsibleError as e:
        print("ERROR: %s" % e)
        raise


# Generated at 2022-06-24 19:20:03.680599
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    var_0 = GalaxyAPI('www.ansible.com')
    var_1 = GalaxyAPI('www.galaxy.ansible.com')
    var_2 = False
    var_0 < var_1


# Generated at 2022-06-24 19:20:08.972390
# Unit test for function get_cache_id
def test_get_cache_id():
    func_name = "get_cache_id"
    var_0 = [u'https://galaxy-api.ansible.com']
    func_ret_val_0 = get_cache_id(var_0)
    assert func_ret_val_0 == u'galaxy-api.ansible.com:'


# Generated at 2022-06-24 19:20:20.625718
# Unit test for function g_connect
def test_g_connect():
    versions = ['v1']

    def decorator(method):
        def wrapped(self, *args, **kwargs):
            if not self._available_api_versions:
                display.vvvv("Initial connection to galaxy_server: %s" % self.api_server)

                # Determine the type of Galaxy server we are talking to. First try it unauthenticated then with Bearer
                # auth for Automation Hub.
                n_url = self.api_server
                error_context_msg = 'Error when finding available api versions from %s (%s)' % (self.name, n_url)


# Generated at 2022-06-24 19:20:25.163199
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    assert_equal(test_case_0(), None)


# Generated at 2022-06-24 19:20:31.227192
# Unit test for function g_connect
def test_g_connect():
    versions = ["1", "2"]
    method = "GET"
    obj = GalaxyClient("test", "test", "test")
    fn = g_connect(versions)(obj.test_call_galaxy)
    try:
        fn(obj, url="http://localhost:8090")
        assert False, "test_g_connect failed!"
    except Exception as e:
        print("Function test_g_connect threw an exception: %s" % e)



# Generated at 2022-06-24 19:20:40.384412
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():

    capture = AnsibleCapture()
    capture.__enter__()
    args_0 = AnsibleOptions(['--debug', '--api-key=1234', '--server=http://galaxy.ansible.com/api', '--ignore-certs'])
    var_1 = GalaxyAPI(args_0)
    var_0 = var_1.get_galaxy_url()
    capture.__exit__()

    assert capture.matches('''
Galaxy url set to http://galaxy.ansible.com/api
    ''')
    assert var_0 == 'http://galaxy.ansible.com/api'


# Generated at 2022-06-24 19:20:42.221796
# Unit test for function g_connect
def test_g_connect():
    method = g_connect(['test'])
    result = method(['test'])
    print(result)


# Generated at 2022-06-24 19:20:50.717890
# Unit test for function cache_lock
def test_cache_lock():
    try:
        from hashlib import sha1
    except ImportError:
        from sha import new as sha1

    try:
        from collections import OrderedDict as odict
    except ImportError:
        odict = dict


# Generated at 2022-06-24 19:21:20.677732
# Unit test for function get_cache_id
def test_get_cache_id():
    var_0 = urlparse("/")
    return var_0

# Generated at 2022-06-24 19:21:24.442583
# Unit test for function cache_lock
def test_cache_lock():
    this_function_name = sys._getframe().f_code.co_name
    display.vvvv(this_function_name + ": entering\n")

    var_0 = None

    var_0 = func_0()

    assert var_0 == "abc"
    display.vvvv(this_function_name + ": exiting\n")


# Generated at 2022-06-24 19:21:25.357504
# Unit test for function g_connect
def test_g_connect():
    pass



# Generated at 2022-06-24 19:21:32.710334
# Unit test for function g_connect
def test_g_connect():
    var_0 = 'https://galaxy.ansible.com'
    var_1 = 'https://galaxy.ansible.com/'
    var_2 = HTTPError(None, var_1, None, None, None)
    var_3 = 'URL does not exist'
    var_4 = QuoteError(var_1, var_3)
    var_5 = GalaxyClient(var_0)
    var_5.api_server = var_0
    get_api_version_str = var_5.get_api_version_str()
    test_case_0()



# Generated at 2022-06-24 19:21:33.638404
# Unit test for function g_connect
def test_g_connect():
    pass



# Generated at 2022-06-24 19:21:39.810958
# Unit test for function get_cache_id
def test_get_cache_id():
    var_0 = get_cache_id('https://127.0.0.1:80/api/')
    if var_0 != "127.0.0.1:80":
        print("Error: Test failed. Expected: '127.0.0.1:80', but got: " + str(var_0))
    else:
        print("Info: Test passed")

test_case_0()

# Generated at 2022-06-24 19:21:43.453057
# Unit test for function g_connect
def test_g_connect():
    var_0 = 'https://galaxy.ansible.com/api/'
    var_1 = {u'v1': u'v1/'}
    var_2 = {u'v1': u'v1/', u'v2': u'v2/'}
    test_case_0()

# Tests for function _urljoin

# Generated at 2022-06-24 19:21:44.357497
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    test_case_0()



# Generated at 2022-06-24 19:21:49.901669
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        var_0 = HTTPError(None, "Test", None, None, None)
    except Exception:
        print("Exception raised in HTTPError() while creating object of class HTTPError")
    else:
        # var_1 = GalaxyError(var_0, "Test")
        # print("value of var_1: " + str(var_1))
        print("call to test_case_0() successful")

test_GalaxyError()


# Generated at 2022-06-24 19:21:55.935013
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    output = StringIO()
    out_redirect = redirect_stdout(output)

    var_0 = GalaxyAPI(name='Test', url='http://galaxy.ansible.com', token='', ignore_certs=False, force_api_version=False, client_id=None, client_secret=None, access_token=None, refresh_token=None, verify_ssl=False)
    var_1 = 3

    var_0.__lt__(var_1)

    out_redirect.restore()
    # TODO: test it!
    raise Exception('Invalid test')


# Generated at 2022-06-24 19:22:46.818907
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    bool_0 = False
    gal_0 = GalaxyAPI('host', bool_0, bool_0, bool_0, bool_0)
    var_0 = gal_0.__lt__(bool_0)
    assert var_0 is None


# Generated at 2022-06-24 19:22:48.699548
# Unit test for function cache_lock
def test_cache_lock():
    try:
        generator_0 = test_case_0()
        var_0 = parse_api_response(generator_0)
        assert var_0 != None
    except:
        print ("Exception caught")
        assert False


# Generated at 2022-06-24 19:22:52.000380
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    obj = GalaxyAPI()
    test_case_0()



# Generated at 2022-06-24 19:22:54.473616
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    galaxy_error = GalaxyError(1, "Test")
    if galaxy_error is not None:
        display.warning("Test case 0 - galaxy_error is not None")


# Generated at 2022-06-24 19:22:56.849542
# Unit test for function g_connect
def test_g_connect():
    try:
        test_case_0()
    except:
        display.vvvv('Galaxy server is not available.')


# Generated at 2022-06-24 19:23:05.173765
# Unit test for function g_connect
def test_g_connect():
    # Tests that the method requires one of the versions specified in the decorator
    versions = [u'v1', u'v2']
    # Check that it is available for v1 when v1 is advertised as available
    galaxy_server = GalaxyServer('https://galaxy.ansible.com', 'ansible-galaxy', user_agent())
    galaxy_server._available_api_versions = {u'v1': u'v1/'}
    method_to_call = g_connect(versions)(lambda self: None)
    method_to_call(galaxy_server)
    # Check that it is available for v2 when v2 is advertised as available
    galaxy_server = GalaxyServer('https://galaxy.ansible.com', 'ansible-galaxy', user_agent())

# Generated at 2022-06-24 19:23:09.569780
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_code_info = None
    message_info = None
    http_error_info = None
    galaxy_error_obj = GalaxyError(http_code_info, message_info)
    assert isinstance(galaxy_error_obj, GalaxyError)



# Generated at 2022-06-24 19:23:19.388457
# Unit test for function get_cache_id
def test_get_cache_id():
    # Verify if get_cache_id returns an expected result in the case of failure.
    var_1 = AnsibleError("Tried to find galaxy API root at '' but no 'available_versions' are available on ")
    bool_1 = is_rate_limit_exception(var_1)
    var_2 = bool_1
    # Assert if the result is True in case of bool_1.
    assert var_2 == True

    # Verify if get_cache_id returns an expected result in the case of success.
    var_3 = is_rate_limit_exception(var_0)
    var_4 = var_3
    # Assert if the result is False in case of var_3.
    assert var_4 == False



# Generated at 2022-06-24 19:23:25.300297
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Init
    obj_0 = GalaxyAPI(['v2', 'v3'], 'url', 'name')
    # Action
    obj_0.login('username', 'password')
    obj_0.wait_import_task('task_id', 0)
    obj_0.get_collection_metadata('namespace', 'name')
    obj_0.get_collection_version_metadata('namespace', 'name', 'version')
    obj_0.get_collection_versions('namespace', 'name')


# Generated at 2022-06-24 19:23:35.787766
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    arg_0 = GalaxyAPI()
    arg_1 = GalaxyAPI()
    arg_0.name = 'testing'
    arg_1.name = 'testing'
    arg_0.api_server = 'testing'
    arg_1.api_server = 'testing'
    arg_0.base_path = 'testing'
    arg_1.base_path = 'testing'
    arg_0.token = 'testing'
    arg_1.token = 'testing'
    arg_0.oauth_token = 'testing'
    arg_1.oauth_token = 'testing'
    arg_0.ignore_certs = 'testing'
    arg_1.ignore_certs = 'testing'
    arg_0.disable_fallback = 'testing'
    arg_1.disable_fallback = 'testing'
   

# Generated at 2022-06-24 19:25:15.054277
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    try:
        assert is_rate_limit_exception(False) == False
    except AssertionError:
        print("Test case 0 failed.")

# Unit tests for functions in this file

# Generated at 2022-06-24 19:25:16.735215
# Unit test for function cache_lock
def test_cache_lock():
    assert True == bool("".join(["te", "st"]))


# Generated at 2022-06-24 19:25:22.812911
# Unit test for function g_connect
def test_g_connect():
    try:
        version = ['Available API versions', 'Available API versions']
        method = g_connect(version)
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 19:25:24.949138
# Unit test for function get_cache_id
def test_get_cache_id():
    url = 'www.example.com'
    var_0 = get_cache_id(url)
    if var_0 == 'www.example.com:None':
        return True
    else:
        return False


# Generated at 2022-06-24 19:25:33.745795
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    server = 'http://localhost:8080'
    api_key = 'test_key'
    galaxy_callbacks = 'test_galaxy_callbacks'
    allow_http_api_auth = 'test_allow_http_api_auth'
    ignore_certs = 'test_ignore_certs'
    force_basic_auth = 'test_force_basic_auth'

    temp = GalaxyAPI(server, api_key, galaxy_callbacks, allow_http_api_auth, ignore_certs, force_basic_auth)

# Generated at 2022-06-24 19:25:42.181928
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    v3_server = "https://galaxy.ansible.com"
    v3_api = "api/v3"
    display.vvv("Testing GalaxyAPI constructor with GalaxyAPI('mygalaxy', v3_server, v3_api)")
    x = GalaxyAPI('mygalaxy', v3_server, v3_api)
    display.vvv(x)
    if x.name == "mygalaxy" and x.api_server == v3_server and x.available_api_versions == {'v3': 'api/v3'}:
        return True
    else:
        return False


# Generated at 2022-06-24 19:25:45.229491
# Unit test for function cache_lock
def test_cache_lock():
    # Input parameters
    #   func
    test_func = cache_lock(test_case_0)
    test_func(1)
    # Output : test result
    #   The function should be passed
    assert True


# Generated at 2022-06-24 19:25:47.972749
# Unit test for function g_connect
def test_g_connect():
    # Require Galaxy versions v1 & v2
    versions = ["v1", "v2"]

    # Test that we verify if the function only supports unsupported versions.
    # We should fail the decorator before calling the method.
    pass


# Generated at 2022-06-24 19:25:49.665175
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    obj_GalaxyError = GalaxyError(HTTPError, '424')
    assert obj_GalaxyError.http_code == '424'


# Generated at 2022-06-24 19:25:56.275185
# Unit test for function get_cache_id
def test_get_cache_id():
    assert 'www.cnn.com:80' == get_cache_id('http://www.cnn.com/')
    assert 'www.cnn.com:80' == get_cache_id('http://www.cnn.com')
    assert 'www.cnn.com' == get_cache_id('http://www.cnn.com:80')
    assert 'www.cnn.com' == get_cache_id('https://www.cnn.com:443')
    assert 'www.cnn.com' == get_cache_id('https://www.cnn.com')
    assert 'www.cnn.com' == get_cache_id('https://www.cnn.com:')