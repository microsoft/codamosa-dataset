

# Generated at 2022-06-24 19:18:24.144697
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Arrange
    http_error_0 = HTTPError(url='url_0', code=404)
    message_0 = 'message_0'

    # Act
    galaxy_error = GalaxyError(http_error_0,message_0)

    # Assert
    assert galaxy_error.http_code == 404
    assert galaxy_error.url == 'url_0'
    assert galaxy_error.message == "(HTTP Code: 404, Message: Not Found) message_0"


# Generated at 2022-06-24 19:18:30.259805
# Unit test for function cache_lock
def test_cache_lock():
    test_case_0()

# Validates that the given URL is not None and is a properly formatted
# URL.  Altered from the Galaxy codebase.
#
# :param url: The URL to validate.
# :type url: string
#
# :return: URL if valid
# :rtype: string
#
# :raises AnsibleError: if the URL is None or improperly formatted.

# Generated at 2022-06-24 19:18:35.630136
# Unit test for function g_connect
def test_g_connect():
    # Test with no arg
    var_0 = g_connect()
    # Test with arg
    var_1 = g_connect(var_0)


# Generated at 2022-06-24 19:18:44.130378
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = to_bytes("http://127.0.0.1:8080/t/5e5f5c5b5a5")
    message = to_bytes("http://127.0.0.1:8080")
    try:
        galaxyError_object = GalaxyError(http_error, message)
        string_var = galaxyError_object.url
    except AttributeError:
        raise AnsibleError(to_bytes("Attribute Error"))
    except ValueError:
        raise AnsibleError(to_bytes("Value Error"))



# Generated at 2022-06-24 19:18:47.056677
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    bytes_0 = b'\x91\xac\x82x&\x1c'
    var_0 = GalaxyError()
    var_0.http_code = 429
    var_1 = is_rate_limit_exception(var_0)



# Generated at 2022-06-24 19:18:57.041387
# Unit test for function g_connect
def test_g_connect():
    class TestClass(object):
        def __init__(self, api_server, name):
            self.api_server = api_server
            self.name = name
            self._available_api_versions = {}
    class GalaxyError(Exception):
        def __init__(self, http_code):
            self.http_code = http_code
    test_class = TestClass(api_server='https://galaxy.ansible.com', name='galaxy')
    decorated_function = g_connect(['v1'])(test_method)
    try:
        func_result = decorated_function(test_class)
    except Exception as err:
        display.error(err)
    else:
        display.display(func_result)


# Generated at 2022-06-24 19:18:59.183120
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    HTTPError(404, 'HTTP Error 404', None, None, None)
    GalaxyError(404, 'HTTP Error 404')


# Generated at 2022-06-24 19:19:07.104417
# Unit test for function is_rate_limit_exception

# Generated at 2022-06-24 19:19:12.271204
# Unit test for function g_connect
def test_g_connect():
    versions = []
    method = {}
    args = []
    kwargs = []
    test_case_0()
    wrapped = g_connect(versions)
    ansi_join = wrapped(method)
    ansi_join(args, kwargs)


# Generated at 2022-06-24 19:19:17.328924
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    ansible_galaxy_server = GalaxyAPI(api_server='', name='n_server', user_agent='n_ua', token='n_token')
    var_0 = GalaxyAPI(api_server='', name='n_server', user_agent='n_ua', token='n_token')
    ansible_galaxy_server < var_0


# Generated at 2022-06-24 19:20:21.162627
# Unit test for function get_cache_id
def test_get_cache_id():
    test_url_0 = "https://galaxy.ansible.com"
    url_info_0 = urlparse(test_url_0)
    if url_info_0.port == None:
        port = "443"
    else:
        port = str(url_info_0.port)
    output = get_cache_id(test_url_0)
    assert output == url_info_0.hostname+":"+port


# Generated at 2022-06-24 19:20:23.187694
# Unit test for function g_connect
def test_g_connect():
    versions_0 = [
        "v1",
        "v2"
    ]
    # Execute function
    # TODO: fill this out with a test
    assert False



# Generated at 2022-06-24 19:20:27.569041
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error_0 = HTTPError(url=None, code=None, msg=None, hdrs=None, fp=None, filename=None)
    message_0 = 'test_value1'
    try:
        galaxy_error_0 = GalaxyError(http_error_0, message_0)
        galaxy_error_0.message
        galaxy_error_0.url
    except Exception as e:  # noqa
        print(e.message)



# Generated at 2022-06-24 19:20:34.800224
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api_0 = GalaxyAPI(
        api_server = 'test string',
        ignore_certs = True,
        ignore_errors = False,
        name = 'test string',
        token = 'test string'
    )

    galaxy_api_1 = GalaxyAPI(
        api_server = 'test string',
        ignore_certs = True,
        ignore_errors = False,
        name = 'test string',
        token = 'test string'
    )

    # __lt__ is not implemented, should throw an error
    try:
        galaxy_api_0.__lt__(galaxy_api_1)
    except NotImplementedError:
        pass


# Generated at 2022-06-24 19:20:37.842952
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise HttpError
    except HTTPError as http_error:
        error = GalaxyError(http_error, "Message")


# Unit testing for functions in Cache class

# Generated at 2022-06-24 19:20:42.544110
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    exception0 = GalaxyError('Error!', http_code=429)
    assert is_rate_limit_exception(exception0)

    exception1 = GalaxyError('Error!', http_code=403)
    assert not is_rate_limit_exception(exception1)

# Unit tests for class CollectionMetadata

# Generated at 2022-06-24 19:20:50.681106
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    a = GalaxyAPI()
    b = GalaxyAPI()
    c = GalaxyAPI()
    d = GalaxyAPI()

    a.name = 'b'
    b.name = 'b'
    c.name = 'c'
    d.name = 'd'

    # a < b
    assert a < b
    # a < c
    assert a < c
    # a < d
    assert a < d
    # b < c
    assert b < c
    # b < d
    assert b < d
    # c < d
    assert c < d
    # a < a
    assert not a < a
    # b < b
    assert not b < b
    # c < c
    assert not c < c
    # d < d
    assert not d < d
    # b < a

# Generated at 2022-06-24 19:20:55.000987
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError(HTTPError('url', 'status', 'msg', {} , None), 'message')
    except GalaxyError as e:
        assert True


# Generated at 2022-06-24 19:21:00.350767
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test case 0
    galaxy_api_0 = GalaxyAPI(name='')
    # Expected: No error
    assert True
    # Expected: galaxy_api_0.name to be ''
    assert galaxy_api_0.name == ''
    # Expected: galaxy_api_0.api_server to be 'galaxy.ansible.com'
    assert galaxy_api_0.api_server == 'galaxy.ansible.com'


# Generated at 2022-06-24 19:21:01.708098
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    err = GalaxyError("err message")
    assert err.message == "err message"



# Generated at 2022-06-24 19:21:37.840315
# Unit test for function get_cache_id
def test_get_cache_id():
    url = 'https://galaxy.ansible.com/api/'
    print(get_cache_id(url))

    url = 'https://galaxy.ansible.com:8080/api/'
    print(get_cache_id(url))


# Generated at 2022-06-24 19:21:44.429950
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api_obj = GalaxyAPI(force_api_version=None,
                               api_token=None,
                               ignore_certs=False,
                               force_basic_auth=False,
                               username=None,
                               password=None)
    try:
        galaxy_api_obj.__lt__()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 19:21:49.410883
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url=None, code=400, msg='Bad Request', hdrs=None, fp=None)
    bad_request_error = GalaxyError(http_error, message='Test error message')
    assert bad_request_error.http_code == 400
    assert bad_request_error.message == 'Test error message (HTTP Code: 400, Message: Bad Request)'



# Generated at 2022-06-24 19:21:56.835168
# Unit test for function g_connect
def test_g_connect():
    galaxy_0 = GalaxyAPI(None, name=None, server="https://galaxy.ansible.com", ignore_certs=True,
                         token_path=None, validate_certs=False, roles_path=None, force_basic_auth=False)
    galaxy_0.api_server = 'https://galaxy.ansible.com'
    versions = ['v1', 'v2']
    g_connect(versions)(galaxy_0.get_collections)



# Generated at 2022-06-24 19:21:58.550367
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    result = not (GalaxyAPI() < GalaxyAPI())
    assert result is True, "__lt__ with no arguments failed"



# Generated at 2022-06-24 19:22:08.193995
# Unit test for function get_cache_id
def test_get_cache_id():
    url0='https://galaxy.ansible.com/api/'
    url1='http://galaxy.ansible.com:443'
    url2='http://galaxy.ansible.com:80'
    url3='http://galaxy.ansible.com'

    assert get_cache_id(url0) == 'galaxy.ansible.com'
    assert get_cache_id(url1) == 'galaxy.ansible.com'
    assert get_cache_id(url2) == 'galaxy.ansible.com'
    assert get_cache_id(url3) == 'galaxy.ansible.com'


# Generated at 2022-06-24 19:22:19.706862
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # class GalaxyAPI(BasicGalaxyAPI):
    class MyGalaxyAPI(GalaxyAPI):
        def __init__(self):
            super(MyGalaxyAPI, self).__init__()
        def get_collection_versions(self, namespace, name):
            return ["1.0.0-beta.1", "1.0.0"]

    galaxy_name = "galaxy.ansible.com"
    galaxy_api_server = "https://galaxy.ansible.com/api"
    my_galaxy_api = MyGalaxyAPI()
    my_galaxy_api.set_connection_info(galaxy_name, galaxy_api_server)

# Generated at 2022-06-24 19:22:26.217603
# Unit test for function cache_lock
def test_cache_lock():
    test_counter = 0
    counter_lock = threading.Lock()

    @cache_lock
    def inc_counter():
        global test_counter
        with counter_lock:
            test_counter += 1

    def task(delay):
        time.sleep(delay)
        inc_counter()

    threads = [threading.Thread(target=task, args=(x,)) for x in range(5)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert test_counter == 5, "Expected counter value is 5, counter value is {}".format(test_counter)



# Generated at 2022-06-24 19:22:29.349815
# Unit test for function cache_lock
def test_cache_lock():
    collection_metadata_0 = CollectionMetadata()
    collection_metadata_0.get_role_urls(
        'jctanner', 'ansible-role-elasticsearch', 'elasticsearch', None, None, None)


# Generated at 2022-06-24 19:22:31.362550
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("https://galaxy.ansible.com/api/") == "galaxy.ansible.com:"


# Generated at 2022-06-24 19:23:01.658191
# Unit test for function g_connect
def test_g_connect():
    if test_case_0():
        test_g_connect.__name__ = 'g_connect'
        test_g_connect.__doc__ = 'Wrapper to lazily initialize connection info to Galaxy and verify the API versions required are available on the endpoint.'
        test_g_connect.__dict__ = functools.partial.__dict__['_g_connect_']


# Generated at 2022-06-24 19:23:07.137195
# Unit test for function get_cache_id
def test_get_cache_id():
    s = get_cache_id('https://galaxy.ansible.com')
    assert s == 'galaxy.ansible.com:'
    s = get_cache_id('https://galaxy.ansible.com:8443')
    assert s == 'galaxy.ansible.com:8443'
    s = get_cache_id('https://example.com:4444/')
    assert s == 'example.com:4444'
    s = get_cache_id('https://user@example.com:4444/')
    assert s == 'example.com:4444'


# Generated at 2022-06-24 19:23:11.246703
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError(HTTPError('https://galaxy.ansible.com/v3', 429, 'Too Many Requests', {}, None), 'rate-limited')
    except GalaxyError as context:
        assert context.http_code == 429


# Generated at 2022-06-24 19:23:18.485963
# Unit test for function g_connect
def test_g_connect():
    versions = [1, 2]

    def decorator(method):
        def wrapped(self, *args, **kwargs):
            if not self._available_api_versions:
                display.vvvv("Initial connection to galaxy_server: %s" % self.api_server)

                # Determine the type of Galaxy server we are talking to. First try it unauthenticated then with Bearer
                # auth for Automation Hub.
                n_url = self.api_server
                error_context_msg = 'Error when finding available api versions from %s (%s)' % (self.name, n_url)


# Generated at 2022-06-24 19:23:25.100717
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    test_http_error = HTTPError('test_url', 400, 'Bad Request', 'test_headers', StringIO('test_msg'))
    test_GalaxyError_obj = GalaxyError(test_http_error, 'test_msg')
    # check the attributes in the instance
    assert test_GalaxyError_obj.message == 'test_msg (HTTP Code: 400, Message: Bad Request)'
    assert test_GalaxyError_obj.url == 'test_url'
    assert test_GalaxyError_obj.http_code == 400
    del test_GalaxyError_obj



# Generated at 2022-06-24 19:23:26.335377
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    with pytest.raises(TypeError):
        api = GalaxyAPI()



# Generated at 2022-06-24 19:23:31.726911
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI()
    other_galaxy_api = GalaxyAPI()

    assert not (galaxy_api < other_galaxy_api)

    galaxy_api.api_server = "http://localhost"
    assert not (galaxy_api < other_galaxy_api)

    galaxy_api.api_key = "foo"
    assert galaxy_api < other_galaxy_api


# Generated at 2022-06-24 19:23:36.181773
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api_0 = GalaxyAPI()
    galaxy_api_0.name = 'test_value_0'
    galaxy_api_1 = GalaxyAPI()
    galaxy_api_1.name = 'test_value_1'
    assert galaxy_api_0 < galaxy_api_1


# Generated at 2022-06-24 19:23:38.183265
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    with pytest.raises(AnsibleError):
        raise GalaxyError(HTTPError, "Trying to test GalaxyError class")


# Generated at 2022-06-24 19:23:40.630584
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    pass


# Generated at 2022-06-24 19:24:09.712143
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError
    message = 'hi'
    with pytest.raises(GalaxyError) as excinfo:
        GalaxyError(http_error, message)
    assert "hi (HTTP Code: " in str(excinfo.value)



# Generated at 2022-06-24 19:24:12.270848
# Unit test for function cache_lock
def test_cache_lock():
    dict_0 = None

    @cache_lock
    def func(dict_0):
        return dict_0

    var_0 = func(dict_0)


# Generated at 2022-06-24 19:24:14.024634
# Unit test for function cache_lock
def test_cache_lock():
    print("Testing function: cache_lock")
    test_case_0()
    print("Passed function: cache_lock")


# Generated at 2022-06-24 19:24:24.012761
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError(HTTPError(url='https://www.example.com', code=429, msg=None, hdrs=[('Content-Type', 'application/json'), ('Content-Encoding', 'gzip')], fp=None), 'Test')
    except Exception as E:
        assert hasattr(E, 'message')
        assert hasattr(E, 'http_code')
        assert hasattr(E, 'url')
        assert E.http_code == 429
        assert E.url == to_text('https://www.example.com')
        assert E.message == 'Test'



# Generated at 2022-06-24 19:24:27.802825
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    url = "http://www.example.com"
    http_error = Exception("Example Exception")
    message = "Example Message"
    error = GalaxyError(http_error, message)

    assert error.message == "Example Message"
    assert error.http_code == Exception
    assert error.url == "http://www.example.com"


# Generated at 2022-06-24 19:24:34.299390
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:8080') == 'galaxy.ansible.com:8080'
    assert get_cache_id('https://test:test123@galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://test@galaxy.ansible.com') == 'galaxy.ansible.com:'


# Generated at 2022-06-24 19:24:36.194085
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    print('Testing GalaxyError constructor')
    test_case_0()

if __name__ == '__main__':
    test_GalaxyError()


# Generated at 2022-06-24 19:24:43.821079
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api_server = 'http://localhost:8080/api/'
    name = 'galaxy_1'
    ignore_certs = False
    verify_ssl = False
    token = None
    force_basic_auth = False
    no_logout_on_fail = False
    timeout = 90
    password_callback = None
    headers = None
    force = False
    roles_path = None
    collections_paths = None
    ansible_morty = None

    # tests the following code:
    #     class GalaxyAPI(object):
    #         def __init__(self, api_server, name, force=False, ignore_certs=False,
    #                      verify_ssl=False, token=None, force_basic_auth=False,
    #                      no_logout_on_fail=False, timeout=90

# Generated at 2022-06-24 19:24:45.574680
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('fkl.com') == 'fkl.com:'


# Generated at 2022-06-24 19:24:51.716346
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    dict_0 = dict(some_key=some_value, another_key=another_value)
    dict_1 = dict(some_key=some_value, another_key=another_value)
    obj_0 = GalaxyAPI("http://localhost")
    obj_1 = GalaxyAPI("http://localhost")
    obj_2 = GalaxyAPI("http://localhost")
    obj_0.available_api_versions = dict_0
    obj_1.available_api_versions = dict_1
    obj_2.available_api_versions = dict_0
    var_0 = obj_0 < obj_1
    var_1 = obj_1 < obj_1
    var_2 = obj_1 < obj_0
    var_3 = obj_0 < obj_2
    var_4 = obj_2 < obj_0

#

# Generated at 2022-06-24 19:25:49.123614
# Unit test for function g_connect
def test_g_connect():
    versions = 'abc'
    method = 0
    args = None
    kwargs = None
    try:
        g_connect(versions)(method)(args, kwargs)
    except TypeError as err:
        assert err.args == ("<lambda>() missing 1 required positional argument: 'self'",)
    except ValueError as err:
        assert err.args[-1] == "Unexpected version 'abc' from api version data {'v1': 'v1/'}"


# Generated at 2022-06-24 19:25:54.332511
# Unit test for function cache_lock

# Generated at 2022-06-24 19:25:55.282388
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError
    except GalaxyError:
        pass



# Generated at 2022-06-24 19:25:56.555857
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    assert test_case_0() == False


# Generated at 2022-06-24 19:25:59.909814
# Unit test for function cache_lock
def test_cache_lock():
    # Check that we correctly call the appropriate function

    with _CACHE_LOCK:
        var_0 = 1

    var_1 = 1
    assert var_1 == var_0, "test_cache_lock() failed expected={} got={}".format(var_1, var_0)


# Generated at 2022-06-24 19:26:01.441690
# Unit test for function cache_lock
def test_cache_lock():
    print("Unit test for func cache_lock")
    assert test_case_0() == None



# Generated at 2022-06-24 19:26:03.237382
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    dict_1 = None
    dict_2 = None
    dict_3 = GalaxyError(dict_1, dict_2)


# Generated at 2022-06-24 19:26:04.390988
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    var_0 = GalaxyError(AnsibleError(), "AnsibleError")


# Generated at 2022-06-24 19:26:12.555139
# Unit test for function g_connect
def test_g_connect():
    versions = "versions_0"
    method = "method_0"
    n_url = "n_url_0"
    error_context_msg = "error_context_msg_0"
    data = "data_0"
    available_versions = "available_versions_0"
    common_versions = "common_versions_0"
    self = "self_0"
    method = "method_1"
    args = "args_0"
    kwargs = "kwargs_0"
    wrapped = "wrapped_0"
    dict_0 = {'method': method}
    args = [self, *args]

    # Call function with arguments:
    # versions = "versions_0"
    # method = "method_0"
    result = g_connect(versions)(method)

    # Establish that

# Generated at 2022-06-24 19:26:19.179438
# Unit test for function get_cache_id
def test_get_cache_id():
    # Test if the returned value is correct.
    dict_0 = get_cache_id('https://galaxy.ansible.com')
    var_0 = 'galaxy.ansible.com'
    assert dict_0 == var_0

    dict_0 = get_cache_id('https://galaxy.ansible.com:8080')
    var_0 = 'galaxy.ansible.com:8080'
    assert dict_0 == var_0
