

# Generated at 2022-06-24 19:18:26.854327
# Unit test for function cache_lock
def test_cache_lock():
    #func = cache_lock(test_case_0)
    #print(func())
    collection_metadata_0 = CollectionMetadata()

# test_cache_lock()


# Generated at 2022-06-24 19:18:31.456586
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    print('Unit test for function is_rate_limit_exception')
    collection_metadata_0 = CollectionMetadata()
    collection_metadata_0.http_code = 429
    collection_metadata_0.name = "unit_test_collection"
    collection_metadata_0.version = "1.2.3"
    is_rate_limit = is_rate_limit_exception(collection_metadata_0)
    print(is_rate_limit)


# Generated at 2022-06-24 19:18:33.264370
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError("", 403, "", {}, None)
    message = "Test message"
    galaxy_error = GalaxyError(http_error, message)

    assert galaxy_error.http_code == 403
    assert message == galaxy_error.message



# Generated at 2022-06-24 19:18:37.452360
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api_0 = GalaxyAPI()
    galaxy_api_1 = GalaxyAPI()
    result = galaxy_api_0.__lt__(galaxy_api_1)
    assert result is not False or False


# Generated at 2022-06-24 19:18:42.148995
# Unit test for function g_connect
def test_g_connect():
    versions = [u'v1', u'v2']
    method = object()
    method.__name__ = 'galaxy_command'



# Generated at 2022-06-24 19:18:47.925387
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api_0 = GalaxyAPI()
    galaxy_api_1 = GalaxyAPI()
    galaxy_api_2 = GalaxyAPI()
    assert galaxy_api_0.__lt__(galaxy_api_1)
    assert not galaxy_api_1.__lt__(galaxy_api_2)
    assert not galaxy_api_0.__lt__(galaxy_api_2)
    assert not galaxy_api_2.__lt__(galaxy_api_0)


# Generated at 2022-06-24 19:18:48.724967
# Unit test for function g_connect
def test_g_connect():
    test_case_0()



# Generated at 2022-06-24 19:18:52.717135
# Unit test for function cache_lock
def test_cache_lock():
    func = test_case_0
    with _CACHE_LOCK:
        func()


# Generated at 2022-06-24 19:18:55.439713
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    test_case_1()
    test_case_2()


# Generated at 2022-06-24 19:19:03.423904
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api_0 = GalaxyAPI(
        name='http://galaxy.ansible.com/api/v1',
        api_server='https://galaxy.ansible.com',
    )
    assert galaxy_api_0.name == 'http://galaxy.ansible.com/api/v1'
    assert galaxy_api_0.api_server == 'https://galaxy.ansible.com'
    assert galaxy_api_0.available_api_versions['v1'] == '/api/v1'
    # TODO: validate or mock the _call_galaxy
    galaxy_api_1 = GalaxyAPI(
        name='AutomationHub',
        api_server='https://galaxy.ansible.com',
        token='access-token'
    )

# Generated at 2022-06-24 19:19:34.443653
# Unit test for function cache_lock
def test_cache_lock():
    collection_metadata_1 = CollectionMetadata()
    collection_metadata_1.get_collection_version_from_cache("collection_name", "collection_version")
    collection_metadata_1.get_collection_version_from_cache("collection_name", "collection_version")


# Generated at 2022-06-24 19:19:37.896847
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api_0 = GalaxyAPI()
    arg_0 = GalaxyAPI()
    n_ret = api_0.__lt__(arg_0)


# Generated at 2022-06-24 19:19:42.975569
# Unit test for function g_connect
def test_g_connect():
    """
    Wrapper to lazily initialize connection info to Galaxy and verify the API versions required are available on the
    endpoint.
    """
    def decorator(method):
        def wrapped(self, *args, **kwargs):
            if not self._available_api_versions:
                display.vvvv("Initial connection to galaxy_server: %s" % self.api_server)

                # Determine the type of Galaxy server we are talking to. First try it unauthenticated then with Bearer
                # auth for Automation Hub.
                n_url = self.api_server
                error_context_msg = 'Error when finding available api versions from %s (%s)' % (self.name, n_url)


# Generated at 2022-06-24 19:19:49.609695
# Unit test for function get_cache_id
def test_get_cache_id():
    url0 = 'https://galaxy.ansible.com/api/'
    url1 = 'https://galaxy.ansible.com/api/v2/'
    url2 = 'https://galaxy.ansible.com/api/v1/'
    url3 = 'https://galaxy.ansible.com/api/v1/collections'
    url4 = 'https://galaxy.ansible.com/api/v1/collections/helloworld'
    url5 = 'https://galaxy.ansible.com/api/v1/collections/helloworld/helloansible'
    url6 = 'https://galaxy.ansible.com/api/v1/collections/helloworld/helloansible/latest/download'

# Generated at 2022-06-24 19:19:50.523101
# Unit test for function cache_lock
def test_cache_lock():
    test_case_0()


# Generated at 2022-06-24 19:19:55.049244
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error_message = "Error occurred i.e. HTTP Code: 403, Message: User is unable to use the app: galaxy.test_error.test_galaxy_error"
    error_http_code = 403
    error_galaxy_message = "User is unable to use the app"
    test_error = GalaxyError(error_http_code, error_galaxy_message)
    assert error_message == str(test_error)


# Generated at 2022-06-24 19:19:56.928560
# Unit test for function get_cache_id
def test_get_cache_id():
    url_0 = 'galaxy.ansible.com/api/'
    cache_0 = get_cache_id(url_0)
    print("cache_0: " + cache_0)



# Generated at 2022-06-24 19:19:57.877540
# Unit test for function g_connect
def test_g_connect():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 19:19:59.056247
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    GalaxyError(HTTPError('', '', '', '', StringIO('')), "Error message")



# Generated at 2022-06-24 19:20:04.082608
# Unit test for function get_cache_id
def test_get_cache_id():
    url_0 = "https://galaxy.ansible.com"
    url_1 = "https://galaxy.example.com:8080"
    cache_id_0 = get_cache_id(url_0)
    cache_id_1 = get_cache_id(url_1)
    print("cache_id_0: " + cache_id_0 + " cache_id_1: " + cache_id_1)


# Generated at 2022-06-24 19:20:35.319052
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    internal_run_module_0 = GalaxyAPI()
    internal_run_module_0.name = 'string_value_3'
    internal_run_module_0.api_server = 'string_value_4'
    internal_run_module_0.token = 'string_value_5'
    internal_run_module_0.username = 'string_value_6'
    internal_run_module_0.password = 'string_value_7'
    internal_run_module_0.validate_certs = True
    internal_run_module_0.verify_ssl = True
    internal_run_module_0.force_basic_auth = True
    internal_run_module_0.timeout = 1
    internal_run_module_0.basic_auth_username = 'string_value_12'
    internal_

# Generated at 2022-06-24 19:20:43.650393
# Unit test for function cache_lock
def test_cache_lock():
    with _CACHE_LOCK:
        val_0 = collection_metadata_0.get_collection_filename_by_id({'namespace': 'ansible', 'name': 'netcommon'})
        val_1 = collection_metadata_0.get_collection_filename_by_id({'namespace': 'ansible', 'name': 'netcommon'})
        val_2 = collection_metadata_0.get_collection_filename_by_id({'namespace': 'ansible', 'name': 'netcommon'})
        ansible_collection_version_0 = collection_metadata_0.get_collection_version({'namespace': 'ansible', 'name': 'netcommon'})


# Generated at 2022-06-24 19:20:50.803162
# Unit test for function get_cache_id
def test_get_cache_id():
    url_1 = "https://somehost.com/path"
    url_2 = "https://somehost.com:8080/path?q=foo"
    url_3 = "http://somehost.com:8080/path?q=foo"

    cache_id_1 = get_cache_id(url_1)
    assert (cache_id_1 == 'somehost.com'), 'Incorrect ID returned'

    # TODO: Need to create a unit test for this
    cache_id_2 = get_cache_id(url_2)

    cache_id_3 = get_cache_id(url_3)
    assert (cache_id_3 == 'somehost.com:8080'), 'Incorrect ID returned'



# Generated at 2022-06-24 19:21:00.869413
# Unit test for function g_connect
def test_g_connect():
    # Initialize a class which g_connect decorator is applied
    collection_metadata_0 = CollectionMetadata()

    # Try to call the function with request api version 'v1' and 'v2'
    collection_metadata_0.get_collections_by_sha(sha256sum='sha256sum_value', api_version='v1')
    try:
        collection_metadata_0.get_collections_by_sha(sha256sum='sha256sum_value', api_version='v2')
    except AnsibleError:
        print("V2 is not supported, it's good")

    # Try to call the function with invalid version 'v3'

# Generated at 2022-06-24 19:21:03.528510
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('test_url', 'test_http_code', 'test_http_reason', 'test_headers', 'test_fp')
    message = 'test_message'
    galaxy_err = GalaxyError(http_error, message)
    assert galaxy_err.message == 'test_message (HTTP Code: test_http_code, Message: test_http_reason)'
    assert galaxy_err.http_code == 'test_http_code'
    assert galaxy_err.url == 'test_url'



# Generated at 2022-06-24 19:21:11.431579
# Unit test for function g_connect
def test_g_connect():
    # If a GalaxyAction instance is called without setting its api server, it should raise an exception.
    # This is because it tries to make a call to the Galaxy server to find out which API versions to use.
    ga_0 = GalaxyAction()
    try:
        ga_0.content_remove_version()
        return False
    except AnsibleError as e:
        if "Tried to find galaxy API root at  but no 'available_versions' are available on " in str(e):
            return True
        return False


# Generated at 2022-06-24 19:21:16.669796
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    collection_metadata_0 = CollectionMetadata()
    galaxy_error = GalaxyError(GalaxyError.SERVER_ERROR, "Generic Server error")
    galaxy_error.http_code = 400
    assert not is_rate_limit_exception(galaxy_error)
    galaxy_error.http_code = 429
    assert is_rate_limit_exception(galaxy_error)


# Generated at 2022-06-24 19:21:20.369832
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error = GalaxyError("http_error","message")


# Generated at 2022-06-24 19:21:24.443890
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api_0 = GalaxyAPI('api_name_0', 'api_server_0', 'api_key_0')
    obj = api_0
    param_0 = GalaxyAPI('api_name_1', 'api_server_1', 'api_key_1')
    x = api_0.__lt__(param_0)
    return (api_0, obj, param_0, x)


# Generated at 2022-06-24 19:21:26.550855
# Unit test for function cache_lock
def test_cache_lock():
    with _CACHE_LOCK:
        collection_metadata_1 = CollectionMetadata()


# Generated at 2022-06-24 19:21:51.504522
# Unit test for function cache_lock
def test_cache_lock():
    test_case_0()



# Generated at 2022-06-24 19:21:54.208619
# Unit test for function g_connect
def test_g_connect():
    collection_metadata_1 = CollectionMetadata()
    result = collection_metadata_1.get_collections()
    if isinstance(result, list):
        display.display('Test case 1: Passed')
    else:
        display.display('Test case 1: Failed')


# Generated at 2022-06-24 19:22:01.198706
# Unit test for function cache_lock
def test_cache_lock():
    func_name = sys._getframe().f_code.co_name
    func = getattr(CollectionManager, func_name)
    a = CollectionManager()
    a.cache_path = "test_case_0"
    display.vvv("Call orig %s()" % func_name)
    res = func(a)
    display.vvv("Call my %s()" % func_name)
    res = func(a)
    assert(res == None)


# Generated at 2022-06-24 19:22:02.712634
# Unit test for function g_connect
def test_g_connect():
    collection_metadata_0 = CollectionMetadata()
    test_case_0()



# Generated at 2022-06-24 19:22:06.153178
# Unit test for function g_connect
def test_g_connect():
    pass


# Generated at 2022-06-24 19:22:13.431056
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(
        url="https://galaxy.ansible.com/api/v2/",
        code=404,
        msg="could not find api",
        hdrs={},
        fp=None,
        errcode=404,
        _pool=None,
        _connection=None,
    )

    message = "Not Found Error"

    error_catcher = GalaxyError(http_error, message)

    assert error_catcher.http_code == 404
    assert error_catcher.url == "https://galaxy.ansible.com/api/v2/"
    assert error_catcher.message == "Not Found Error (HTTP Code: 404, Message: could not find api)"



# Generated at 2022-06-24 19:22:21.418921
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://www.google.com') == 'www.google.com:'
    assert get_cache_id('https://www.google.com:80') == 'www.google.com:80'
    assert get_cache_id('https://www.google.com:443') == 'www.google.com:443'
    assert get_cache_id('http://www.google.com:80') == 'www.google.com:80'
    assert get_cache_id('http://www.google.com:443') == 'www.google.com:443'
    assert get_cache_id('http://www.google.com') == 'www.google.com:'


# Generated at 2022-06-24 19:22:24.853812
# Unit test for function cache_lock
def test_cache_lock():
    # _CACHE_LOCK should be locked first
    if not _CACHE_LOCK.locked():
        _CACHE_LOCK.acquire()
    # test cache_lock can be locked properly
    @cache_lock
    def test_cache_lock_func():
        pass
    test_cache_lock_func()


# Generated at 2022-06-24 19:22:28.292437
# Unit test for function cache_lock
def test_cache_lock():
    cm = CollectionMetadata()
    cm.url_to_token()
    cm.token_to_url()
    cm.collection_info_url_to_metadata()
    cm.cache_lock(cm.url_to_token)
    cm.cache_lock(cm.token_to_url)
    cm.cache_lock(cm.collection_info_url_to_metadata)


# Generated at 2022-06-24 19:22:37.692123
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # at this point we have no api_token

    # Functions we'll test: is_rate_limit_exception, _for_each_page, _get_api_token, _get_headers

    # Login
    try:
        auth_data = _get_api_token(C.GALAXY_SERVER)
        headers = _get_headers(auth_data=auth_data,
                               extra_headers=None,
                               show_deprecation_warnings=True)

        # Login was successful
        assert isinstance(auth_data, dict)
        assert isinstance(headers, dict)

    except GalaxyError as e:
        # Login failed
        print("Login failed.")
        assert isinstance(e, GalaxyError)

        # retry of an HTTPError is a good thing
        assert is_rate_limit_ex

# Generated at 2022-06-24 19:23:06.948011
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Call function with arguments of different types
    http_error_0 = HTTPError('test', 1, 'test error msg', {}, None)
    try:
        GalaxyError(http_error_0, 'test_msg')
    except GalaxyError as exception_var_0:
        var_0 = exception_var_0.code
        var_1 = exception_var_0.url
        var_2 = exception_var_0.message
    assert var_0 == 1
    assert var_1 == 'test'
    assert var_2 == u'test_msg'



# Generated at 2022-06-24 19:23:17.007146
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():

    api_server = 'galaxy.ansible.com'
    ignore_certs = False
    verify_ssl = False
    user_agent = 'ansible-galaxy/2.0.0'
    user_agent_param = 'ansible_galaxy_user_agent'
    verify_ssl_param = 'ansible_galaxy_verify_ssl'

    vars_0 = {}
    api_0 = GalaxyAPI(api_server=api_server, ignore_certs=ignore_certs, verify_ssl=verify_ssl, user_agent=user_agent, variables=vars_0, user_agent_param=user_agent_param, verify_ssl_param=verify_ssl_param)

    assert api_0.available_api_versions == ('v2', 'v3')



# Generated at 2022-06-24 19:23:25.825007
# Unit test for function g_connect
def test_g_connect():
    # Test with only function name
    try :
        var_0 = g_connect({'v1', 'v2'})
        var_0_0 = type(var_0)
        assert type(var_0) is functools.partial
    except AssertionError as e:
        print("AssertionError : ", e)
    
    # Test with function name and attributes
    try :
        var_0 = g_connect({'v1', 'v2'})
        var_0_0 = type(var_0)
        assert type(var_0) is functools.partial
    except AssertionError as e:
        print("AssertionError : ", e)
    


# Generated at 2022-06-24 19:23:28.533358
# Unit test for function cache_lock
def test_cache_lock():
    dict_0 = {}
    dict_0['_ansible_timeout'] = 3.0
    var_0 = cache_lock(dict_0)


# Generated at 2022-06-24 19:23:31.550091
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    dict_0 = {}
    var_0 = is_rate_limit_exception(dict_0)
    assert var_0 == false, "Returned false: %d" % var_0


# Generated at 2022-06-24 19:23:38.093506
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("www.google.com") == "www.google.com:None"
    assert get_cache_id("www.facebook.com") == "www.facebook.com:None"
    assert get_cache_id("www.google.com:8080") == "www.google.com:8080"
    assert get_cache_id("www.facebook.com:8080") == "www.facebook.com:8080"
    
    
    
    


# Generated at 2022-06-24 19:23:41.888983
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    dict_0 = {}
    var_0 = GalaxyAPI(dict_0)
    assert isinstance(var_0, GalaxyAPI)


# Generated at 2022-06-24 19:23:44.711953
# Unit test for function g_connect
def test_g_connect():
    g_connect(versions)
    assert True



# Generated at 2022-06-24 19:23:47.461049
# Unit test for function g_connect
def test_g_connect():
    # Test case 0
    test_case_0()
    # Test case 1
    test_case_1()
    # Test case 2
    test_case_2()
    # Test case 3
    test_case_3()
    # Test case 4
    test_case_4()
    # Test case 5
    test_case_5()
    


# Generated at 2022-06-24 19:23:51.438135
# Unit test for function g_connect
def test_g_connect():
    versions = 'test'
    method = 'test'
    wrapped = g_connect(versions)(method)
    wrapped()


# Generated at 2022-06-24 19:24:25.788416
# Unit test for function g_connect
def test_g_connect():
    versions = [1, 2]

    def wrapped(self, *args, **kwargs):
        return 'test_g_connect'

    wrapped = g_connect(versions)(wrapped)
    assert(wrapped.__name__ == 'wrapped')
    assert(wrapped.__doc__ == '\n        Wrapper to lazily initialize connection info to Galaxy and verify the API versions required are available on the\n        endpoint.\n        ')
    # test_case_0 will raise error
    # test_case_0()
    # assert(wrapped(None) == 'test_g_connect')
    pass



# Generated at 2022-06-24 19:24:28.620842
# Unit test for function cache_lock
def test_cache_lock():
    func = cache_lock
    dict_0 = {}
    var_0 = is_rate_limit_exception(dict_0)
    var_0
    var_0 = func
    assert func is not None
    assert var_0 is not None


# Generated at 2022-06-24 19:24:37.221825
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI(name='ansible-galaxy', api_server='https://galaxy.ansible.com', api_key='',
                           ignore_certs=False, timeout=30, context=None)
    # Assert that name has the correct value
    assert galaxy_api.name == 'ansible-galaxy'
    # Assert that api_server has the correct value
    assert galaxy_api.api_server == 'https://galaxy.ansible.com'
    # Assert that api_key has the correct value
    assert galaxy_api.api_key == ''
    # Assert that ignore_certs has the correct value
    assert galaxy_api.ignore_certs is False
    # Assert that timeout has the correct value
    assert galaxy_api.timeout == 30
    # Assert that context has the correct value

# Generated at 2022-06-24 19:24:39.642968
# Unit test for function g_connect
def test_g_connect():
    if not isinstance(var_0, bool):
        raise AssertionError(
            "Expected type (bool), got ('{}')".format(type(var_0)))



# Generated at 2022-06-24 19:24:41.685632
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    GalaxyAPI.__lt__()


# Generated at 2022-06-24 19:24:48.587936
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Tests when all the required parameters are not passed
    # The expected behaviour is to raise a ValueError
    with pytest.raises(ValueError):
        GalaxyAPI(None, None)
    with pytest.raises(ValueError):
        GalaxyAPI(None, 'username')
    with pytest.raises(ValueError):
        GalaxyAPI('server', None)
    # Tests when all the required parameters are passed
    # The expected behaviour is to create the object correctly
    GalaxyAPI('server', 'username')


# Generated at 2022-06-24 19:24:53.418152
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_code = 429
    message = 'Response message'
    http_error = HTTPError('url', http_code, message, {}, None)
    galaxy_error = GalaxyError(http_error, 'Galaxy Error message')

    assert galaxy_error.http_code == http_code
    assert galaxy_error.url == 'url'
    assert str(galaxy_error) == message


# Generated at 2022-06-24 19:24:58.663371
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    fixture_0 = GalaxyAPI('http://example.com/api/v2/', 'foo')
    fixture_1 = GalaxyAPI('http://example.com/api/', 'baz')
    fixture_2 = GalaxyAPI('http://example.com/v2/', 'bar')
    fixture_3 = GalaxyAPI('http://example.com/galaxy/', 'baz')
    pass



# Generated at 2022-06-24 19:25:03.108187
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api_0 = GalaxyAPI(name="galaxy_server", api_server="https://galaxy.ansible.com", validate_certs=True,
                      auth_url="https://localhost/api/v1/users/1/")
    api_1 = GalaxyAPI(name="galaxy_server", api_server="https://galaxy.ansible.com", validate_certs=True,
                      auth_url="https://localhost/api/v1/users/1/")

    try:
        var_0 = api_0 < api_1
    except Exception:
        var_0 = None


# Generated at 2022-06-24 19:25:04.470964
# Unit test for function get_cache_id
def test_get_cache_id():
    assert(get_cache_id('') == ':')


# Generated at 2022-06-24 19:26:18.309944
# Unit test for function get_cache_id
def test_get_cache_id():
    dict_0 = {}
    url_info = urlparse(dict_0)

    port = None
    try:
        port = url_info.port
    except ValueError:
        pass  # While the URL is probably invalid, let the caller figure that out when using it

    # Cannot use netloc because it could contain credentials if the server specified had them in there.
    var_1 = '%s:%s' % (url_info.hostname, port or '')


# Generated at 2022-06-24 19:26:19.266536
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    GalaxyError()


# Generated at 2022-06-24 19:26:20.419212
# Unit test for function cache_lock
def test_cache_lock():
    result = cache_lock(test_case_0)
    assert isinstance(result, functools.partial)


# Generated at 2022-06-24 19:26:21.937414
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    dict_0 = {}
    var_0 = GalaxyError(dict_0, 'http_error')



# Generated at 2022-06-24 19:26:23.306493
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # test_GalaxyAPI_0()
    # test_GalaxyAPI_1()
    pass



# Generated at 2022-06-24 19:26:27.020851
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    dict_0 = {}
    int_0 = 10
    obj_GalaxyAPI = GalaxyAPI(dict_0, int_0)
    dict_1 = {}
    int_1 = 10
    obj_GalaxyAPI_0 = GalaxyAPI(dict_1, int_1)
    obj_GalaxyAPI_1 = obj_GalaxyAPI < obj_GalaxyAPI_0
    assert obj_GalaxyAPI_1 == False


# Generated at 2022-06-24 19:26:28.849727
# Unit test for function get_cache_id
def test_get_cache_id():
    url = 'https://galaxy.ansible.com/api/'
    assert get_cache_id(url) == 'galaxy.ansible.com:'


# Generated at 2022-06-24 19:26:31.753676
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    var_0 = {"http_code": "420"}
    var_1 = is_rate_limit_exception(var_0)
    assert var_1 == True
    var_2 = {"http_code": "520"}
    var_3 = is_rate_limit_exception(var_2)
    assert var_3 == True



# Generated at 2022-06-24 19:26:38.164268
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    dict_0 = {'message': 'd9d2898ed08c6989cb8e0f74e46d2b78c00cc76e', 'code': 'd9d2898ed08c6989cb8e0f74e46d2b78c00cc76e'}

# Generated at 2022-06-24 19:26:40.092517
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_function(x):
        return x

    assert test_function(1) == 1
    assert test_function(2) == 2
    assert test_function(3) == 3
    assert test_function(4) == 4
