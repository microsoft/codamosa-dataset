

# Generated at 2022-06-20 14:37:09.575109
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection_metadata1 = CollectionMetadata("namespace1", "name1")
    collection_metadata2 = CollectionMetadata("namespace2", "name2", created_str="created2", modified_str="modified2")
    assert collection_metadata1.name == "name1"
    assert collection_metadata1.namespace == "namespace1"
    assert collection_metadata1.created_str == None
    assert not collection_metadata1 != collection_metadata2
    assert collection_metadata2 != collection_metadata1
    assert collection_metadata2 != collection_metadata2


# Generated at 2022-06-20 14:37:15.175224
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Set up mocks
    message = 'GalaxyError'
    http_code = 401
    url = 'https://galaxy.ansible.com'
    http_error = HTTPError(url, http_code, message, None, None)
    err = GalaxyError(http_error, message)
    assert (err.http_code == http_code)
    assert (err.url == url)
    assert (err.message == message)



# Generated at 2022-06-20 14:37:20.860962
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        return 5
    assert test_func() == 5



# Generated at 2022-06-20 14:37:33.295278
# Unit test for function get_cache_id

# Generated at 2022-06-20 14:37:37.630727
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    test_metadata = CollectionMetadata('my_namespace', 'my_name')
    assert test_metadata.name == 'my_name'
    assert test_metadata.namespace == 'my_namespace'
    assert test_metadata.description is None
    assert test_metadata.created_str is None
    assert test_metadata.modified_str is None

# Generated at 2022-06-20 14:37:43.402784
# Unit test for function cache_lock
def test_cache_lock():
    # We can't actually test this code, because the lock will prevent two
    # instances of cache_lock from running at the same time.
    # However, this function is only used in this one module, and any
    # problems with it will be caught during other tests
    assert cache_lock(lambda: 42)() == 42



# Generated at 2022-06-20 14:37:46.978730
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api_server = 'https://galaxy.server.com'
    name = 'Galaxy Name'
    api_token = 'token'
    api = GalaxyAPI(api_server, name, api_token)
    result = api.__repr__()
    assert result == 'GalaxyAPI(galaxy_server=https://galaxy.server.com, galaxy_name=Galaxy Name, api_token=token)'

# Generated at 2022-06-20 14:37:50.640825
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    emptyObj = GalaxyAPI()
    assert repr(emptyObj) == "GalaxyAPI('', '', '', '', '')"


# Generated at 2022-06-20 14:37:59.422489
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    my_galaxy = GalaxyAPI()
    my_galaxy.name = "TEST_Galaxy"
    my_galaxy.api_server = "TEST_API"
    my_galaxy.ignore_certs = True
    my_galaxy.available_api_versions = {"v2": "api/v2", "v3": "api/v3"}
    my_galaxy.total_ame_stars = 0
    my_galaxy.ame_stars = 0
    my_galaxy.verify_ssl = True

    my_galaxy2 = GalaxyAPI()
    my_galaxy2.name = "TEST_Galaxy"
    my_galaxy2.api_server = "TEST_API"
    my_galaxy2.ignore_certs = True
    my_galaxy2.available_api_

# Generated at 2022-06-20 14:38:03.069224
# Unit test for function cache_lock
def test_cache_lock():

    mock_global = 5

    @cache_lock
    def test():
        global mock_global
        mock_global = 10

    test()
    assert mock_global == 10



# Generated at 2022-06-20 14:38:36.509410
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def func():
        return 'func'
    assert func() == 'func'



# Generated at 2022-06-20 14:38:40.937546
# Unit test for function cache_lock
def test_cache_lock():
    func = lambda: "foo"
    wrapped = cache_lock(func)
    assert wrapped.__name__ == func.__name__  # Ensure function name is preserved by decorator
    ret = wrapped()
    assert ret == func()

test_cache_lock()



# Generated at 2022-06-20 14:38:43.059849
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    c = CollectionMetadata('unit-test.name', '1.2.3')
    assert c.namespace == 'unit-test'
    assert c.name == 'name'
    assert c.version == '1.2.3'


# Generated at 2022-06-20 14:38:49.713965
# Unit test for function g_connect
def test_g_connect():
    from ansible.galaxy.api import GalaxyAPI
    @g_connect(versions=['v2'])
    def test(galaxy):
        return galaxy.api_server
    galaxy = GalaxyAPI("https://galaxy.ansible.com/")
    galaxy._available_api_versions = {u'v2': u'v2/'}
    assert test(galaxy) == "https://galaxy.ansible.com/api/"
    galaxy = GalaxyAPI("https://galaxy.ansible.com/api/")
    galaxy._available_api_versions = {u'v2': u'v2/'}
    assert test(galaxy) == "https://galaxy.ansible.com/api/"



# Generated at 2022-06-20 14:38:58.576173
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    import os
    import tempfile
    import filecmp

    # Load the mocked galaxy servers json file
    galaxy_servers = load_galaxy_servers_json()

    # Open a temporary file to write the mocked galaxy servers json file to
    mocked_galaxy_servers_fh, mocked_galaxy_servers_file = tempfile.mkstemp()
    os.close(mocked_galaxy_servers_fh)

    # Write the mocked galaxy servers json file to the temporary file
    with open(mocked_galaxy_servers_file, 'w') as f:
        f.write(galaxy_servers)

    # Instantiate a GalaxyAPI object with the mocked Galaxy servers data file
    api = GalaxyAPI(mocked_galaxy_servers_file)

    # Create the expected output for the __str__ method

# Generated at 2022-06-20 14:39:07.938185
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI()
    assert "[ GalaxyAPI: %s (%s) ]" % (api.name, api.api_server) == api.__str__()
    # we want the default name to be string "Galaxy" and api_server to be string "https://galaxy.ansible.com"
    assert "[ GalaxyAPI: Galaxy (https://galaxy.ansible.com) ]" == api.__str__()

# Define the module level set of available GalaxyAPI objects, keyed by name
GALAXY_SERVERS = {}


# Generated at 2022-06-20 14:39:22.915113
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI(api_server='http://galaxy.ansible.com', validate_certs=True)
    galaxy_api.name = 'Galaxy'
    galaxy_api.token = 'abc123'
    galaxy_api.username = 'galaxy_user'
    galaxy_api.cert_path = ''
    galaxy_api.client_key_path = ''

# Generated at 2022-06-20 14:39:28.278421
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    import mock

    _CACHE_LOCK = mock.MagicMock()
    dec = cache_lock(lambda: 'test')
    dec()
    _CACHE_LOCK.__enter__.assert_called_once_with()
    _CACHE_LOCK.__exit__.assert_called_once_with(None, None, None)



# Generated at 2022-06-20 14:39:36.473992
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert not is_rate_limit_exception(GalaxyError(http_code=404))
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))

    # 403 is not a rate limit error code
    assert not is_rate_limit_exception(GalaxyError(http_code=403))



# Generated at 2022-06-20 14:39:45.456419
# Unit test for function g_connect
def test_g_connect():
    """
    Check that g_connect decorator works as expected.
    """
    class TestConnection(object):
        def __init__(self):
            self.api_server = 'https://galaxy.ansible.com/'
            self._available_api_versions = None
        @g_connect(versions=['v1', 'v2'])
        def v1_and_v2(self):
            return True
        @g_connect(versions=['v2'])
        def v2(self):
            return True
        @g_connect(versions=['v3'])
        def v3(self):
            return True

    # Run the test.
    test_connection = TestConnection()
    assert test_connection.v1_and_v2()
    assert test_connection.v2()

# Generated at 2022-06-20 14:40:24.041283
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    exc = GalaxyError()
    exc.http_code = 403
    assert not is_rate_limit_exception(exc)
    exc.http_code = 429
    assert is_rate_limit_exception(exc)



# Generated at 2022-06-20 14:40:27.814056
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def f(a, b):
        return a + b
    assert f(1, 2) == 3



# Generated at 2022-06-20 14:40:31.949832
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI('https://galaxy.example.com')
    galaxy_api.name = 'galaxy_test'
    assert str(galaxy_api) == 'galaxy_test (https://galaxy.example.com)'

# Generated at 2022-06-20 14:40:46.150246
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from unittest.mock import patch
    from ansible.module_utils.ansible_galaxy.api import GalaxyAPI

    api = GalaxyAPI("myGalaxy")
    
    # set the object attribute
    api.name = "myGalaxy"
    api.api_server = urlparse("https://galaxy.ansible.com/")
    api.available_api_versions = {
        'v3': '/api/v3',
        'v2': '/api/v2'
    }
    
    api.token = 'myToken'
    
    # create mock of object with same attributes
    other = GalaxyAPI("myGalaxy")
    other.name = "myGalaxy"
    other.api_server = url

# Generated at 2022-06-20 14:40:54.729646
# Unit test for function cache_lock
def test_cache_lock():
    import mock

    fake_lock = mock.MagicMock()
    fake_lock.__enter__ = mock.MagicMock()
    fake_lock.__exit__ = mock.MagicMock()

    with mock.patch.object(threading, 'Lock') as mock_Lock:
        mock_Lock.return_value = fake_lock
        @cache_lock
        def fake_func(arg):
            return "arg={0}".format(arg)

        fake_func('a')

        assert fake_lock.__enter__.called, "__enter__() not called"
        assert fake_lock.__exit__.called, "__exit__() not called"



# Generated at 2022-06-20 14:41:05.116590
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    collection_version_metadata = CollectionVersionMetadata(namespace='namespace', name='name', version='version',
                                                            download_url='download_url', artifact_sha256='artifact_sha256', dependencies='dependencies')
    assert(collection_version_metadata.namespace == 'namespace')
    assert(collection_version_metadata.name == 'name')
    assert(collection_version_metadata.version == 'version')
    assert(collection_version_metadata.download_url == 'download_url')
    assert(collection_version_metadata.artifact_sha256 == 'artifact_sha256')
    assert(collection_version_metadata.dependencies == 'dependencies')



# Generated at 2022-06-20 14:41:11.278298
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    display.verbosity = 3
    # Testing the GalaxyAPI class from ansible.api
    test_inst = GalaxyAPI(name='galaxy', api_server='http://galaxy.ansible.com/api/', verify_ssl=True)
    assert str(test_inst) == '<GalaxyAPI:galaxy galaxy.ansible.com>'

# Generated at 2022-06-20 14:41:25.113651
# Unit test for function get_cache_id
def test_get_cache_id():
    test_url = "https://galaxy-api-host.example.net:443/api/"
    assert get_cache_id(test_url) == "galaxy-api-host.example.net:443"
    # Test with a port that is invalid
    test_url = "https://galaxy-api-host.example.net:a/api/"
    assert get_cache_id(test_url) == "galaxy-api-host.example.net:"
    # Test with a hostname that is invalid
    test_url = "https://galaxy-api-host_example-net:443/api/"
    assert get_cache_id(test_url) == "galaxy-api-host_example-net:443"



# Generated at 2022-06-20 14:41:35.504859
# Unit test for function cache_lock
def test_cache_lock():
    global CACHE
    CACHE = {}
    # global CACHE_LOCK

    # CACHE_LOCK = threading.Lock()

    @cache_lock
    def set_cache(name, value):
        CACHE[name] = value

    # def set_cache_lock(name, value):
    #     with CACHE_LOCK:
    #         CACHE[name] = value

    threads = []
    for i in range(10):
        t = threading.Thread(target=set_cache, args=(str(i), str(i)))
        threads.append(t)
        t.start()

    # for i in range(10):
    #     t = threading.Thread(target=set_cache_lock, args=(str(i), str(i)))
    #     threads.append(

# Generated at 2022-06-20 14:41:48.862147
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    g1 = GalaxyAPI('url1')
    g2 = GalaxyAPI('url2')

    # Different urls
    assert g1 < g2

    g1 = GalaxyAPI('url1')
    g2 = GalaxyAPI('url1')

    # Same url, different auth
    assert g1 < g2

    g1 = GalaxyAPI('url1', auth=('user1', 'pass1'))
    g2 = GalaxyAPI('url1', auth=('user2', 'pass2'))

    # Same url, different auth user
    assert g1 < g2

    g1 = GalaxyAPI('url1', auth=('user1', 'pass1'))
    g2 = GalaxyAPI('url1', auth=('user1', 'pass1'))

    # Same url, same auth
    assert not g1 < g2


# Unit

# Generated at 2022-06-20 14:42:19.988294
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    GalaxyAPI("https://example.galaxy")
    GalaxyAPI("https://example.galaxy", "https://example.artifactory/path")
    with pytest.raises(AssertionError):
        GalaxyAPI("")
    with pytest.raises(AssertionError):
        GalaxyAPI("https://example.galaxy", "https://example.artifactory/path", "https://example.another/path")



# Generated at 2022-06-20 14:42:27.646267
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api_server = 'https://galaxy.ansible.com'
    available_api_versions = {'v2': '/api/v2'}
    galaxy_api = GalaxyAPI(api_server, available_api_versions)
    assert str(galaxy_api) == "GalaxyAPI(https://galaxy.ansible.com)"

# Generated at 2022-06-20 14:42:33.003286
# Unit test for function g_connect
def test_g_connect():
    from ansible.galaxy.connection import GalaxyConnection
    # test1
    g = GalaxyConnection('https://galaxy.ansible.com')
    assert g.api_server == 'https://galaxy.ansible.com/api/'
    assert g._available_api_versions == {}

    # test2
    g = GalaxyConnection('https://galaxy.ansible.com/api/')
    assert g.api_server == 'https://galaxy.ansible.com/api/'
    # assert g._available_api_versions is None
    # TODO: update the assert test2


# Generated at 2022-06-20 14:42:40.317322
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    arg_0_obj = GalaxyAPI(name='', api_server='', token='', validate_certs=True, ignore_certs=False)
    arg_1_obj = GalaxyAPI(name='', api_server='', token='', validate_certs=True, ignore_certs=False)
    actual_result = arg_0_obj.__lt__(arg_1_obj)
    assert isinstance(actual_result, bool)

# Generated at 2022-06-20 14:42:52.330767
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Test v1 http_error
    http_error = HTTPError(url='https://galaxy.example.com/v1/roles', code=404, msg='Not Found', hdrs={}, fp=None,
                           filename=None)
    http_error.reason = 'Role not found'
    http_err_props = {'code': 404, 'url': http_error.geturl(), 'message': 'Role not found'}
    ansible_err = GalaxyError(http_error, 'Test message')
    assert ansible_err.http_code == http_err_props['code']
    assert ansible_err.url == http_err_props['url']
    assert ansible_err.message == 'Test message (HTTP Code: 404, Message: Role not found)'

    # Test v2 http_error

# Generated at 2022-06-20 14:42:54.309959
# Unit test for function cache_lock
def test_cache_lock():
    global display
    display = Display()
    func = cache_lock(test_func)
    func()


# Generated at 2022-06-20 14:43:00.155159
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """ Unit test for constructor of class GalaxyAPI """
    galaxy_api = GalaxyAPI(server='https://galaxy.ansible.com',
                           ignore_certs=False,
                           disable_cache=False,
                           cache_path='.',
                           cache_max_age=60 * 60 * 24 * 7,
                           username=None,
                           password=None)
    assert isinstance(galaxy_api, GalaxyAPI)



# Generated at 2022-06-20 14:43:02.853574
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    is_rate_limit_exception(GalaxyError("foo", http_code=429))
# End unit test for function is_rate_limit_exception



# Generated at 2022-06-20 14:43:04.794987
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI()
    repr = galaxy_api.__repr__()
    assert repr



# Generated at 2022-06-20 14:43:17.465836
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    ''' test_GalaxyAPI(object) -> None

        Test the constructor of class GalaxyAPI.
    '''
    # Setup
    mock_display = Mock(spec=Display)
    mock_display.warning = Mock(spec=Display.warning)
    mock_display.error = Mock(spec=Display.error)
    mock_galaxy = GalaxyAPI(
        galaxy='test_galaxy',
        api_server='example.galaxy.com',
        token='test_token',
        ignore_certs=False,
        ignore_errors=False,
        validate_roles=True,
        display=mock_display
    )
    # Assert
    assert 'test_galaxy' == mock_galaxy.name
    assert 'example.galaxy.com' == mock_galaxy.api_server

# Generated at 2022-06-20 14:43:49.095761
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test default values if not passed any values
    galaxy_api = GalaxyAPI()
    assert galaxy_api.api_server == GALAXY_SERVER
    assert galaxy_api.force_api == False
    assert galaxy_api.ignore_certs == False
    assert galaxy_api.token == None

    # Test if the passed values are set correctly
    galaxy_api = GalaxyAPI(api_server='http://rosie.com', force_api=True, ignore_certs=True, token='abcd')
    assert galaxy_api.api_server == 'http://rosie.com'
    assert galaxy_api.force_api == True
    assert galaxy_api.ignore_certs == True
    assert galaxy_api.token == 'abcd'

# Generated at 2022-06-20 14:43:52.329751
# Unit test for function cache_lock
def test_cache_lock():
    """
    Function test_cache_lock
    :return:
    """
    # test whether the function is properly wrapped
    assert isinstance(cache_lock(lambda: 1 + 1), type(cache_lock))



# Generated at 2022-06-20 14:43:58.859070
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    from ansible.module_utils.ansible_galaxy.api.kernel_client import KernelClient

    testing_instance = GalaxyAPI(
        name='fancy_name',
        api_server='the_server',
        auth_token='the_token',
        kernels_client=KernelClient(thread_count=1),
        allow_redirects=True,
        verify=True,
    )
    testing_instance.available_api_versions = {}
    assert repr(testing_instance) == "GalaxyAPI('fancy_name', 'the_server', kernels_client=KernelClient(thread_count=1))"

# Generated at 2022-06-20 14:44:04.154152
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class FakeGalaxyError(GalaxyError):
        def __init__(self, http_code):
            self.http_code = http_code

    rate_limit_exception = FakeGalaxyError(520)
    assert is_rate_limit_exception(rate_limit_exception)



# Generated at 2022-06-20 14:44:15.031084
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    testCollection1 = CollectionVersionMetadata("test", "hello", "0.1.0", "https://galaxy.ansible.com/download/hello-0.1.0.tar.gz",
                              "3c3b70c1918a0225f3d3e959d5a0bf5f5ad8e5c5ab5d1a2c0b5f8793ddd9a944", [])
    assert testCollection1.namespace == "test"
    assert testCollection1.name == "hello"
    assert testCollection1.version == "0.1.0"
    assert testCollection1.download_url == "https://galaxy.ansible.com/download/hello-0.1.0.tar.gz"

# Generated at 2022-06-20 14:44:19.769900
# Unit test for function cache_lock
def test_cache_lock():
    """
    If this function runs with no exceptions, cache_lock is working.
    """
    @cache_lock
    def test_function():
        pass

    @cache_lock
    def test_function_with_args(*args, **kwargs):
        pass

    @cache_lock
    def test_function_with_args_and_kwargs():
        pass

    test_function()
    test_function_with_args(1, 2, 3, four=4)
    test_function_with_args_and_kwargs(1, 2, three=3)



# Generated at 2022-06-20 14:44:26.680293
# Unit test for function g_connect
def test_g_connect():
    def test(self, *args, **kwargs):
        return "my_test"
    g_connect = g_connect(['v1', 'v2'])(test)
    g = Galaxy()
    g.api_server = 'https://galaxy.ansible.com/api/'
    g.name = 'https://galaxy.ansible.com/api/'
    print(g_connect(g))


# Generated at 2022-06-20 14:44:37.538138
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(b'http://galaxy.ansible.com/api/', 400, b'BAD REQUEST', {}, None)
    galaxy_error = GalaxyError(http_error, 'Error Desc')
    assert galaxy_error.http_code == 400
    assert galaxy_error.url == 'http://galaxy.ansible.com/api/'

    # Api v1 or invalid api format
    assert galaxy_error.message == 'Error Desc (HTTP Code: 400, Message: BAD REQUEST)'

    http_error = HTTPError(b'http://galaxy.ansible.com/api/v2', 400, b'BAD REQUEST', {}, None)

# Generated at 2022-06-20 14:44:50.374781
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    test_namespace = 'test_namespace'
    test_name = 'test_name'
    test_version = 'test_version'
    test_download_url = 'test_download_url'
    test_artifact_sha256 = 'test_artifact_sha256'
    test_dependencies = {'test_dependency': 'test_version'}
    collection_metadata = CollectionVersionMetadata(test_namespace, test_name, test_version, test_download_url,
                                                    test_artifact_sha256, test_dependencies)
    assert test_namespace == collection_metadata.namespace
    assert test_name == collection_metadata.name
    assert test_version == collection_metadata.version
    assert test_download_url == collection_metadata.download_url
    assert test_artifact_sha256

# Generated at 2022-06-20 14:44:54.606852
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    """
    Test case for `GalaxyAPI.__str__` method.

    """
    galaxy_api = GalaxyAPI(name='test', url='http://test.org/')

    assert repr(galaxy_api) == 'GalaxyAPI(name=test, url=http://test.org/)'



# Generated at 2022-06-20 14:45:32.179213
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    e = GalaxyError(http_code=429)
    assert is_rate_limit_exception(e)



# Generated at 2022-06-20 14:45:36.819171
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise HTTPError('url', 400, 'reason', None, None)
    except HTTPError as http_error:
        try:
            raise GalaxyError(http_error, 'message')
        except GalaxyError as err:
            assert err.http_code == 400
            assert err.url == 'url'



# Generated at 2022-06-20 14:45:40.370289
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    obj = GalaxyAPI('galaxy.server', 'galaxy_user', 'galaxy_pass')
    assert obj.__repr__() == "<GalaxyAPI(galaxy.server, galaxy_user)>"


# Generated at 2022-06-20 14:45:49.848809
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():  # noqa: F811
    # Test constructor of class GalaxyAPI
    galaxy_api = GalaxyAPI('https://galaxy.ansible.com', 'fake_token')
    assert galaxy_api is not None
    assert galaxy_api.api_server == 'https://galaxy.ansible.com'
    assert galaxy_api.api_key == 'fake_token'
    assert galaxy_api.available_api_versions is None
    assert galaxy_api.cache_path is None
    assert galaxy_api.name is None
    assert galaxy_api.cache_path == galaxy_api.cache_path


# Generated at 2022-06-20 14:45:57.031911
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    cm = CollectionMetadata(namespace='namespace', name='name', created_str='', modified_str='')
    assert cm.namespace == 'namespace'
    assert cm.name == 'name'
    assert cm.created_str == ''
    assert cm.modified_str == ''
    assert cm == 'namespace.name'
    assert repr(cm) == 'CollectionMetadata'


# Generated at 2022-06-20 14:46:01.000502
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    assert str(GalaxyAPI(dict(galaxy_server='http://galaxy.example.com', name='name', url='url'))) == 'name, url http://galaxy.example.com'



# Generated at 2022-06-20 14:46:01.671245
# Unit test for function g_connect
def test_g_connect():
    pass



# Generated at 2022-06-20 14:46:07.920776
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    name = "galaxy.api.test"
    api_server = "http://galaxy.ansible.com/api"
    validate_certs = False
    g_api = GalaxyAPI(name, api_server, validate_certs)

    assert g_api.name == name
    assert g_api.api_server == api_server
    assert g_api.validate_certs == validate_certs
    assert 'v3' in g_api.available_api_versions.keys()
    assert 'v2' in g_api.available_api_versions.keys()



# Generated at 2022-06-20 14:46:17.280538
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api_connection_data = dict(
        url="http://galaxy.ansible.com",
        token='fake token',
        ignore_certs=False,
        force_basic_auth=True,
        client_cert=None,
        force=False,
        auth_type='token',
    )
    galaxy_api = GalaxyAPI(galaxy_api_connection_data)
    assert galaxy_api.__repr__() == "GalaxyAPI('http://galaxy.ansible.com/api/v2')"