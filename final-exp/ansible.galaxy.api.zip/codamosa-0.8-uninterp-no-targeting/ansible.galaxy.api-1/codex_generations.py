

# Generated at 2022-06-20 14:37:50.450941
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxyapi = GalaxyAPI(name="test_name", api_server="test_api_server")
    expected = 'GalaxyAPI(name="test_name", api_server="test_api_server")'
    actual = repr(galaxyapi)
    assert expected == actual


# Generated at 2022-06-20 14:37:58.611109
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    msg = "test"
    code = 400
    http_error = HTTPError("test", code, msg, None, None)
    galaxyError = GalaxyError(http_error, msg)
    assert msg == galaxyError.message
    assert code == galaxyError.http_code
    assert "test" == galaxyError.url

    msg_new = "test_2"
    http_error_new = HTTPError("test", code, msg_new, None, None)
    galaxyError_new = GalaxyError(http_error_new, msg)
    assert msg == galaxyError_new.message
    assert code == galaxyError_new.http_code
    assert "test" == galaxyError_new.url



# Generated at 2022-06-20 14:38:05.285115
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    from ansible.module_utils._text import to_text

    galaxy_api = GalaxyAPI(api_server='foobar_api', name='foobar_name')
    expected = 'GalaxyAPI(api_server=foobar_api, name=foobar_name)'
    assert to_text(galaxy_api) == expected

# Generated at 2022-06-20 14:38:18.077331
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    """
    Test GalaxyAPI.__lt__
    """

    with pytest.raises(TypeError):
        assert GalaxyAPI.__lt__({})
    with pytest.raises(TypeError):
        assert GalaxyAPI.__lt__(None)
    with pytest.raises(TypeError):
        assert GalaxyAPI.__lt__(True)
    with pytest.raises(TypeError):
        assert GalaxyAPI.__lt__(5)
    with pytest.raises(TypeError):
        assert GalaxyAPI.__lt__([])
    with pytest.raises(TypeError):
        assert GalaxyAPI.__lt__(GalaxyAPI()) < GalaxyAPI()
    with pytest.raises(TypeError):
        assert GalaxyAPI.__lt__(GalaxyAPI()) < {}

# Generated at 2022-06-20 14:38:25.658351
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    """Test method __str__ of class GalaxyAPI (Legacy testing)"""
    api = GalaxyAPI(server="https://galaxy.server.com", token='token', ignore_certs=True, force_api_version=None)
    assert str(api) == 'GalaxyAPI - https://galaxy.server.com'

# Generated at 2022-06-20 14:38:30.103729
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    # Setup
    args = mock.Mock()
    args.api_key = 'mock api_key'
    args.server = 'mock server'
    args.validate_certs = True

    # Test
    api = GalaxyAPI(args, 'name')

    # Asserts
    assert unicode(api) == "GalaxyAPI(server='mock server', api_key='mock api_key')"

# Generated at 2022-06-20 14:38:36.585666
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_url = 'https://galaxy.ansible.com/api'
    api_token = 'api_token_value'

    galaxy_api = GalaxyAPI(galaxy_url, api_token)
    assert str(galaxy_api) == ("Galaxy API: %s (API token: %s)"
                               % (to_native(galaxy_url, errors='surrogate_or_strict'),
                                  to_native(api_token, errors='surrogate_or_strict')))


# Generated at 2022-06-20 14:38:39.890673
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # Given
    galaxy = GalaxyAPI()
    galaxy.name = 'test name'
    galaxy.api_server = 'test api_server'

    # When
    r = repr(galaxy)

    # Then
    assert r == 'GalaxyAPI: test name (test api_server)'


# Generated at 2022-06-20 14:38:42.109774
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_api = GalaxyAPI('api_server', 'name', 'url', 'token', False, False, False)
    assert str(galaxy_api) == 'GalaxyAPI api_server name url token False False False'



# Generated at 2022-06-20 14:38:45.004688
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    CollectionVersionMetadata('namespace', 'name', 'version', 'download_url', 'artifact_sha256', {'dependencies' : 'dep'})



# Generated at 2022-06-20 14:39:22.963263
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI(galaxy='galaxy_server', api_server='http://api.galaxy.ansible.com', verify_ssl=True)
    assert str(galaxy_api) == 'GalaxyAPI(galaxy="galaxy_server", api_server="http://api.galaxy.ansible.com", verify_ssl=True)'


# Generated at 2022-06-20 14:39:31.159791
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """
    Validate the constructor for class GalaxyAPI.
    """
    api = GalaxyAPI(api_server="https://galaxy.ansible.com", show_deprecation_warnings=False)
    assert api.name == "Galaxy"
    assert api.api_server == "https://galaxy.ansible.com"
    assert api.api_key is None
    assert api.ignore_certs is False
    assert api.verify_ssl is True

    api2 = GalaxyAPI(api_server="https://galaxy.ansible.com", show_deprecation_warnings=False, api_key="api_key", ignore_certs=True, verify_ssl=False)
    assert api2.name == "Galaxy"
    assert api2.api_server == "https://galaxy.ansible.com"


# Generated at 2022-06-20 14:39:41.657049
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    namespace = 'Toto'
    name = 'Tata'
    version = '0.0.1'
    created_at = '2019-12-15T14:30:07.241118Z'
    updated_at = '2019-12-20T14:40:07.241118Z'

    result = CollectionMetadata(namespace, name, version, created_at, updated_at)
    assert result.namespace == namespace
    assert result.name == name
    assert result.version == version
    assert result.created_str == created_at
    assert result.modified_str == updated_at


# Generated at 2022-06-20 14:39:46.191513
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    with patch.object(GalaxyAPI, '_connect', MagicMock()):
        galaxy_api = GalaxyAPI('name', 'g_server', 'api_server', None, None)
        assert repr(galaxy_api) == "GalaxyAPI('name', 'g_server', 'api_server', None, None)"


# Generated at 2022-06-20 14:39:49.276876
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    g_api = GalaxyAPI()
    g_api.name = 'Unit test Galaxy'
    g_api.api_server = 'http://localhost'

    assert 'Unit test Galaxy (Galaxy API: http://localhost, role API: N/A)' == str(g_api)

# Generated at 2022-06-20 14:39:55.432859
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    exception = GalaxyError(http_code=429)
    assert is_rate_limit_exception(exception)

    exception = GalaxyError(http_code=520)
    assert is_rate_limit_exception(exception)

    exception = GalaxyError(http_code=403)
    assert not is_rate_limit_exception(exception)



# Generated at 2022-06-20 14:40:00.359474
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    # Declare x as instance of class GalaxyAPI
    x = GalaxyAPI(None, dict(url='https://galaxy.ansible.com'))
    # Test that the method __unicode__ of class GalaxyAPI returns a unicode string
    assert isinstance(x.__str__(), type(u''))



# Generated at 2022-06-20 14:40:12.241520
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    from ansible.galaxy.api import GalaxyAPI

    api = GalaxyAPI('foo', 'https://galaxy.ansible.com')
    u = unicode(api)
    assert isinstance(u, unicode)

    # (galaxyapi.tests.unit.unit_galaxyapi.test_GalaxyAPI___unicode__.<locals>.<lambda>)
    assert u == u'GalaxyAPI(name=foo, api_server=https://galaxy.ansible.com)'



# Generated at 2022-06-20 14:40:23.813959
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'NAMESPACE'
    name = 'NAME'
    version = '1.0.0'
    url = 'https://download-url.com'
    sha256 = 'SHA256'
    dependencies = {'dependency1':'1.0.0'}
    cvm = CollectionVersionMetadata(namespace, name, version, url, sha256, dependencies)
    assert cvm.namespace == 'NAMESPACE'
    assert cvm.name == 'NAME'
    assert cvm.version == '1.0.0'
    assert cvm.download_url == 'https://download-url.com'
    assert cvm.artifact_sha256 == 'SHA256'
    assert cvm.dependencies == {'dependency1':'1.0.0'}


# Generated at 2022-06-20 14:40:31.682321
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://cloud.example.com') == 'cloud.example.com:'
    assert get_cache_id('https://cloud.example.com/') == 'cloud.example.com:'
    assert get_cache_id('https://cloud.example.com:443') == 'cloud.example.com:443'
    assert get_cache_id('https://user@cloud.example.com:443') == 'cloud.example.com:443'



# Generated at 2022-06-20 14:41:03.862488
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    gi = GalaxyAPI(None)
    assert gi is not None

# Generated at 2022-06-20 14:41:16.631853
# Unit test for method __lt__ of class GalaxyAPI

# Generated at 2022-06-20 14:41:25.680342
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('https://galaxy.ansible.com/api/', 400, 'Bad Request', None, None)
    http_message = 'Some Message'
    galaxy_error_v1 = GalaxyError(http_error, http_message)
    assert galaxy_error_v1.http_code == 400
    assert galaxy_error_v1.message == http_message

    http_error = HTTPError('https://galaxy.ansible.com/api/v2/', 400, 'Bad Request', None, None)
    galaxy_error_v2 = GalaxyError(http_error, http_message)
    assert galaxy_error_v2.http_code == 400
    assert galaxy_error_v2.message == "Some Message (HTTP Code: 400, Message: Bad Request Code: Unknown)"


# Generated at 2022-06-20 14:41:29.688364
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # galaxy_api = GalaxyAPI(name, api_server, ignore_certs)
    # AssertionError: assert 'GalaxyAPI' in output
    assert False


# Generated at 2022-06-20 14:41:35.627097
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.plugins.module_utils.ansible_galaxy.api.galaxy import GalaxyAPI

    mock_object = patch.object(GalaxyAPI, '_call_galaxy')
    mock_object.return_value = 'test'
    obj = GalaxyAPI('test', 'test', 'test', False)
    result = obj.__repr__()
    assert result == '<GalaxyAPI test>'

# Generated at 2022-06-20 14:41:37.911680
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=400))



# Generated at 2022-06-20 14:41:39.976703
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(message="", http_code=429))
    assert not is_rate_limit_exception(GalaxyError(message="", http_code=403))
    assert not is_rate_limit_exception(AnsibleError(message=""))



# Generated at 2022-06-20 14:41:43.346390
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI(name='galaxy_name', api_server='https://galaxy.ansible.com')
    assert str(api) == 'galaxy.ansible.com'


# Generated at 2022-06-20 14:41:45.680130
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_instance = GalaxyAPI('test_galaxy_name')
    assert unicode(galaxy_instance) == 'test_galaxy_name'

# Generated at 2022-06-20 14:41:57.227954
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from collections import namedtuple

    GalaxyAPITestCase = namedtuple('GalaxyAPITestCase', [
        'name',
        'server',
        'api_versions',
        'expected',
    ])


# Generated at 2022-06-20 14:42:47.841725
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    coll = CollectionMetadata("mynamespace", "mycoll", "abc123")
    assert coll.namespace == "mynamespace"
    assert coll.name == "mycoll"
    assert coll.latest_version == "abc123"
    assert coll.download_url is None



# Generated at 2022-06-20 14:42:50.670396
# Unit test for function g_connect
def test_g_connect():
    # Test case 1 : Checking the available API versions
    list_versions=["v1","v2"]
    assert list_versions==["v1","v2"]

#Unit test for function _urljoin is already tested in library/module_utils/urls.py



# Generated at 2022-06-20 14:42:55.359759
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error = HTTPError("http://github.com", 404, "reason", None, None)
    GalaxyError(error, "message")
    GalaxyError(error, None)
    error = HTTPError("http://github.com", 404, "reason", None, None)
    GalaxyError(error, None)



# Generated at 2022-06-20 14:42:59.588263
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    """Check that the GalaxyAPI __str__ method works correctly.

    :return: None
    """
    galaxyapi_ins = GalaxyAPI('http://localhost', 'namespace', 'name')
    assert str(galaxyapi_ins) == '{api_server: http://localhost, name: namespace.name}'  # noqa

# Generated at 2022-06-20 14:43:09.933474
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError('', 429)) == True
    assert is_rate_limit_exception(GalaxyError('', 520)) == True
    assert is_rate_limit_exception(GalaxyError('', 403)) == False
    assert is_rate_limit_exception(GalaxyError('', 403, 'Cloudflare')) == True
    assert is_rate_limit_exception(GalaxyError('', 200)) == False
    assert is_rate_limit_exception(GalaxyError('')) == False
    assert is_rate_limit_exception(Exception()) == False
    assert is_rate_limit_exception(Exception('')) == False



# Generated at 2022-06-20 14:43:21.446858
# Unit test for function g_connect
def test_g_connect():
    # g_connect can be tested by making a mock object to receive the call to the wrapped function
    class mock():
        def test(self):
            return "run"

    # Define a mock object that mimics the return of _call_galaxy
    class mock_call():
        def __init__(self, d):
            self.data = d

        def json(self):
            return self.data

    # Initialize a mock server
    class mock_server():
        def __init__(self, data):
            self._available_api_versions = data
            self.api_server = "fake_server"
            self.name = "fake_name"

        def _call_galaxy(self, url, method="GET", error_context_msg="", cache=False):
            return mock_call(data)

    # Test invalid

# Generated at 2022-06-20 14:43:34.413883
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    url = "https://galaxy.ansible.com/api/v2/roles/?page_size=3"
    http_error_json = {u'detail': u"Invalid page number '-1'. Page numbers start at 1.",
                       u'code': u'page_number_out_of_range', u'title': u'Invalid page number'}
    json_error = json.dumps(http_error_json).encode('utf-8')
    http_error = HTTPError(url, 404, "", None, None)
    http_error.read = lambda: json_error
    try:
        raise GalaxyError(http_error, "Error")
    except GalaxyError as err:
        assert err.http_code == 404
        assert err.url == url

# Generated at 2022-06-20 14:43:36.259129
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI()
    assert galaxy_api.__lt__(None)

# Generated at 2022-06-20 14:43:43.030991
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    """test_GalaxyAPI___repr__()
    """
    api = GalaxyAPI(name='test', server='test.galaxy.ansible.com')
    result = str(api)
    assert result.find('GalaxyAPI') == 0
    assert result.find('name="test"') == 1
    assert result.find('server="test.galaxy.ansible.com"') == 2

    api = GalaxyAPI(name='test', server='test.galaxy.ansible.com', token='token', ignore_certs=True)
    result = str(api)
    assert result.find('GalaxyAPI') == 0
    assert result.find('name="test"') == 1
    assert result.find('server="test.galaxy.ansible.com"') == 2

# Generated at 2022-06-20 14:43:49.255488
# Unit test for function get_cache_id
def test_get_cache_id():
    cache_id = get_cache_id(url='https://localhost:1234/api')
    assert cache_id == 'localhost:1234'
    cache_id = get_cache_id(url='https://localhost/api')
    assert cache_id == 'localhost'
    cache_id = get_cache_id(url='https://google.com/api')
    assert cache_id == 'google.com'



# Generated at 2022-06-20 14:44:26.679534
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class FakeGalaxyError(GalaxyError):
        def __init__(self, http_code, msg):
            self.http_code = http_code
            self.msg = msg
    rate_limited_error = FakeGalaxyError(rate_limit_code, "")
    assert is_rate_limit_exception(rate_limited_error) is True
    not_rate_limited_error = FakeGalaxyError(403, "")
    assert is_rate_limit_exception(not_rate_limited_error) is False



# Generated at 2022-06-20 14:44:33.870826
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI('https://galaxy.server.com', 'user@example.com', 'password')
    assert isinstance(str(api), str)
    assert isinstance(repr(api), str)
    assert str(api) == 'GalaxyAPI for https://galaxy.server.com'
    assert repr(api) == '<GalaxyAPI object https://galaxy.server.com>'



# Generated at 2022-06-20 14:44:48.954924
# Unit test for function g_connect
def test_g_connect():
    versions = ['v2']

    def test_func(self):
        pass

    test_func = g_connect(versions)(test_func)
    test_galaxy_api = GalaxyAPI('', '')
    test_galaxy_api._available_api_versions = {'v2': 'v2/'}
    test_galaxy_api.api_server = 'www.google.com'
    try:
        test_func(test_galaxy_api)
    except AnsibleError:
        raise AssertionError("Function g_connect failed")

    test_galaxy_api._available_api_versions = {'v2': 'v2/', 'v1': 'v1'}
    try:
        test_func(test_galaxy_api)
    except AnsibleError:
        raise AssertionError

# Generated at 2022-06-20 14:44:50.784454
# Unit test for function g_connect
def test_g_connect():
    """ test_g_connect
    """
    pass



# Generated at 2022-06-20 14:44:58.897861
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id(url='http://localhost:80/api') == 'localhost:80'
    assert get_cache_id(url='http://localhost:80/api/v1/') == 'localhost:80'
    assert get_cache_id(url='http://localhost:80/api/v2/') == 'localhost:80'
    assert get_cache_id(url='http://localhost:80/api/v3/') == 'localhost:80'
    assert get_cache_id(url='http://localhost/api') == 'localhost:None'
    assert get_cache_id(url='http://localhost/api/v1/') == 'localhost:None'
    assert get_cache_id(url='http://localhost/api/v2/') == 'localhost:None'

# Generated at 2022-06-20 14:45:10.736839
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    collection_version_metadata = CollectionVersionMetadata(namespace='victoria.k', name='hello', version='1.0.0',
                                                            download_url='https://galaxy-server/api/collections/victoria.k/hello/1.0.0/',
                                                            artifact_sha256='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
                                                            dependencies={'collection': ['namespace.name', 'namespace.name:1.0.0']})
    assert collection_version_metadata.namespace == 'victoria.k'
    assert collection_version_metadata.name == 'hello'
    assert collection_version_metadata.version == '1.0.0'

# Generated at 2022-06-20 14:45:15.148709
# Unit test for function cache_lock
def test_cache_lock():
    with _CACHE_LOCK:
        return True


# Generated at 2022-06-20 14:45:23.115665
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    data = dict(
        name='galaxy',
        api_server='https://galaxy.ansible.com',
        ignore_certs=False,
        token='token',
        client_key='client_key_path',
        client_cert='client_cert_path',
        available_api_versions=dict(),
    )
    api = GalaxyAPI(**data)
    display.display(api)


if __name__ == '__main__':
    run_module()

# Generated at 2022-06-20 14:45:28.966983
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    '''Unit test for GalaxyAPI constructor'''
    api = GalaxyAPI(api_server='https://galaxy.example.com',
                    auth_token='abc123456789')

    assert api.name is None
    assert api.api_server == 'https://galaxy.example.com'
    assert api.auth_token == 'abc123456789'

# Generated at 2022-06-20 14:45:35.416520
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.galaxy import GalaxyAPI

    api = GalaxyAPI(name='test', api_server='https://galaxy.server')

    api2 = GalaxyAPI(name='test', api_server='https://gal.server')
    assert api.__lt__(api2)

    api3 = GalaxyAPI(name='test2', api_server='https://galaxy.server')
    assert not api.__lt__(api3)