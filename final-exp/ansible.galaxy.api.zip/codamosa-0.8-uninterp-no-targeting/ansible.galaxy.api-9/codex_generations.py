

# Generated at 2022-06-20 14:37:03.018240
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    import mock
    import pytest
    assert is_rate_limit_exception(mock.Mock(http_code=429))
    assert is_rate_limit_exception(mock.Mock(http_code=520))
    assert not is_rate_limit_exception(mock.Mock(http_code=400))
    assert not is_rate_limit_exception(mock.Mock(http_code=403))
    with pytest.raises(AssertionError):
        is_rate_limit_exception(mock.Mock(http_code=418))
test_is_rate_limit_exception.is_rate_limit_exception = is_rate_limit_exception



# Generated at 2022-06-20 14:37:09.605130
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(GalaxyError(http_code=500))
    assert not is_rate_limit_exception(GalaxyError(http_code=502))
    assert not is_rate_limit_exception(GalaxyError(http_code=503))
    assert not is_rate_limit_exception(None)
    assert not is_rate_limit_exception(GalaxyError(http_code=200))
    assert not is_rate_limit_exception(GalaxyError(http_code=400))

# Generated at 2022-06-20 14:37:23.229341
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI(api_server=None, ignore_certs=True, validate_certs=True, url=None,
                    username='username', password='password', token=None, token_path=None, auth_url=None,
                    client_cert=None, client_key=None,
                    roles_url=None, roles_lookup_name='n')
    assert api.api_server == None
    assert api.ignore_certs == True
    assert api.validate_certs == True
    assert api.url == None
    assert api.username == 'username'
    assert api.password == 'password'
    assert api.token == None
    assert api.token_path == None
    assert api.auth_url == None
    assert api.client_cert == None
    assert api.client_key == None

# Generated at 2022-06-20 14:37:31.696926
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://example.com') == 'example.com'
    assert get_cache_id('https://example.com/path/to/api') == 'example.com'
    assert get_cache_id('https://example.com:8080/path/to/api') == 'example.com:8080'
    assert get_cache_id('https://user:pass@example.com') == 'example.com'
    assert get_cache_id('https://user:pass@example.com:8080/path/to/api') == 'example.com:8080'



# Generated at 2022-06-20 14:37:40.052058
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    fixture_data = {
    'api_server': 'https://galaxy.ansible.com'
    }
    collection_fixture_meta_data = {
        'namespace': 'best',
        'name': 'collection',
        'version': '0.12.0',
        'created_str': '2018-12-06T04:33:02.796586Z',
        'modified_str': '2018-12-06T04:33:02.796586Z'
    }

# Generated at 2022-06-20 14:37:42.737572
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError("http://galaxy.ansible.com/api/", 400, "Bad Request", None, None)
    galaxy_error = GalaxyError(http_error, "Error")
    assert str(galaxy_error) == "GalaxyError: Error (HTTP Code: 400, Message: Bad Request)", "Error handling failed"



# Generated at 2022-06-20 14:37:54.387207
# Unit test for function g_connect
def test_g_connect():
    # We will stub out the method called by the wrapper
    stub = lambda *args, **kwargs: 'done'
    func = g_connect(['v1', 'v2'])(stub)

    # First we test while the API version is not set, which should connect to the server, then call
    # stub when v1, v2 are available. If an error is thrown, the test will fail.
    c = GalaxyClient(None, None, 'https://galaxy.ansible.com', None, None)
    # We stub for this function so that it does not actually attempt to connect to a server
    c._available_api_versions = {}
    # We expect the function to return "done"
    assert func(c) == 'done'
    # We change the API version to v3, and expect to get an error
    c._available_api

# Generated at 2022-06-20 14:37:58.018794
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    from ansible.galaxy import GalaxyError
    e = GalaxyError(message="Failed", http_code=429, rate_limit=True)
    assert is_rate_limit_exception(e)



# Generated at 2022-06-20 14:38:11.516606
# Unit test for function get_cache_id
def test_get_cache_id():
    """ Test the function get_cache_id() """
    assert get_cache_id('http://galaxy.ansible.com/api/v1') == 'galaxy.ansible.com:80'
    assert get_cache_id('http://galaxy.ansible.com/api/v1/') == 'galaxy.ansible.com:80'
    assert get_cache_id('http://galaxy.ansible.com/api/v1?test=test') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/api/v1') == 'galaxy.ansible.com:443'

# Generated at 2022-06-20 14:38:14.276504
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    assert CollectionMetadata(namespace='ansible_namespace', name='collection_name', created_str='2019-05-13')

# Generated at 2022-06-20 14:39:22.844806
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    class obj:
        def __init__(self):
            self.code = 400
            self.reason = "reason"
            self.msg = "msg"
        def geturl(self):
            return "https://galaxy-api-url/v1"
    http_error = obj()

    # Case 1: v1 response
    err = GalaxyError(http_error, "message")
    assert err.http_code == http_error.code
    assert err.url == http_error.geturl()
    assert err.message.startswith(u"message (HTTP Code: 400, Message: msg)")

    # Case 2: v2 response
    http_error.msg = json.dumps({'code': 'Code', 'message': 'Message'})

# Generated at 2022-06-20 14:39:30.125803
# Unit test for function cache_lock
def test_cache_lock():
    def cache_lock_test():
        with _CACHE_LOCK:
            return 0
    mock_cache_lock = threading.Lock()
    # Test when mock_cache_lock is locked
    mock_cache_lock.acquire()
    assert cache_lock(cache_lock_test)(mock_cache_lock) == 0
    # Test when mock_cache_lock is unlocked
    mock_cache_lock.release()
    assert cache_lock(cache_lock_test)(mock_cache_lock) == 0



# Generated at 2022-06-20 14:39:42.246669
# Unit test for function g_connect
def test_g_connect():
    pass

    # class test_g_connect_class(object):
    #     def __init__(self):
    #         self._available_api_versions = {}
    #         self.name = "test"
    #         self.api_server = "https://fake.galaxy/api/"
    #
    # def _call_galaxy(*args, **kwargs):
    #     return
    #
    # test_obj = test_g_connect_class()
    # test_obj._call_galaxy = _call_galaxy
    #
    # @g_connect(['v2'])
    # def test_g_connect_func(self):
    #     pass

    # test_g_connect_func(test_obj)



# Generated at 2022-06-20 14:39:46.609469
# Unit test for function g_connect
def test_g_connect():
    """
    Unit test on g_connect
    """
    self = None
    def fake_method(self, *args, **kwargs):
        pass
    this_func = g_connect(['v1','v2'])(fake_method)
    # Make sure unit test for function g_connect does not raise exception
    this_func(self)
test_g_connect()

# Generated at 2022-06-20 14:39:58.862989
# Unit test for function g_connect
def test_g_connect():
    versions = []
    version_set = set(versions)
    ret = g_connect(versions)
    def decorator(method):
        method.__name__ = 'test_method'
        @functools.wraps(method)
        def wrapped(self, *args, **kwargs):
            # Verify that the API versions the function works with are available on the server specified.
            available_versions = set(self._available_api_versions.keys())
            common_versions = version_set.intersection(available_versions)

# Generated at 2022-06-20 14:40:03.665658
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    version = Version(1, 0, 0)
    server = GalaxyAPI(name="foo", api_server="apisrv", available_api_versions={version: "pulp_ansible/api/v2"})
    server2 = GalaxyAPI(name="bar", api_server="apisrv", available_api_versions={version: "pulp_ansible/api/v2"})

    assert server < server2
    assert not server > server2

# Generated at 2022-06-20 14:40:08.009428
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api_1 = GalaxyAPI(name='foo', api_server='http://example.com/api/1', ignore_certs=True, token='bar')
    galaxy_api_2 = GalaxyAPI(name='foo', api_server='http://example.com/api/1', ignore_certs=True, token='bar')

    assert galaxy_api_1.__lt__(galaxy_api_2) == NotImplemented



# Generated at 2022-06-20 14:40:15.256111
# Unit test for function cache_lock
def test_cache_lock():
    lock_called = False
    class mock_threading():
        class Lock():
            def __enter__(self):
                nonlocal lock_called
                lock_called = True
            def __exit__(self, type, value, traceback):
                pass
    global threading
    old_threading = threading
    threading = mock_threading
    try:
        @cache_lock
        def func():
            pass
        func()
    finally:
        threading = old_threading
        assert lock_called



# Generated at 2022-06-20 14:40:24.154778
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'test_namespace'
    name = 'test_name'
    version = '1.0'
    download_url = 'https://test.url.com/test'
    artifact_sha256 = '12345678'
    dependencies = dict(
        test_dependency_name=dict(
            version='1.0',
            download_url='https://dependency.url/test',
            sha256='12345678'
        )
    )
    assert CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies).namespace == namespace
    assert CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies).name == name

# Generated at 2022-06-20 14:40:32.431412
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    metadata = CollectionMetadata(namespace='purple_namespace', name='red_name', version='orange_version',
                                  created_str='green_created', modified_str='blue_modified')
    assert metadata.namespace == 'purple_namespace'
    assert metadata.name == 'red_name'
    assert metadata.version == 'orange_version'
    assert metadata.created_str == 'green_created'
    assert metadata.modified_str == 'blue_modified'


# Generated at 2022-06-20 14:41:04.651713
# Unit test for function cache_lock
def test_cache_lock():
    # No way to prove cache_lock is converting function
    # to thread safe, but at least verify it doesn't
    # alter function signature.
    f = lambda a, b=None: None
    g = cache_lock(f)
    assert f.__name__ == g.__name__
    assert f.__doc__ == g.__doc__



# Generated at 2022-06-20 14:41:05.405672
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    pass

# Generated at 2022-06-20 14:41:15.893536
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    metadata = CollectionVersionMetadata('test_namespace',
                                         'test_collection',
                                         '1.0.0',
                                         'https://galaxy.com/download_url',
                                         '1234567890123456789012345678901234567890123456789012345678901234',
                                         {'namespace/collection': '1.0.0'})
    assert metadata.namespace == 'test_namespace'
    assert metadata.name == 'test_collection'
    assert metadata.version == '1.0.0'
    assert metadata.download_url == 'https://galaxy.com/download_url'

# Generated at 2022-06-20 14:41:25.657089
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    assert_raises(ValueError, CollectionVersionMetadata, 'namespace', 'name', 'version', 'download_url', 'artifact_sha256', {}, 'extra_arg')
    assert_raises(ValueError, CollectionVersionMetadata, 'namespace', 'name', 'version', 'download_url', 'artifact_sha256')
    assert_raises(ValueError, CollectionVersionMetadata, 'namespace', 'name', 'version', 'download_url', 'artifact_sha256', 'dependencies')

    assert_raises(ValueError, CollectionVersionMetadata, 'namespace', 'name')
    assert_raises(ValueError, CollectionVersionMetadata, 'namespace', 'name', 'version')
    assert_raises(ValueError, CollectionVersionMetadata, 'namespace', 'name', 'version', 'download_url')


# Generated at 2022-06-20 14:41:31.479474
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    e = GalaxyError(HTTPError(url=None, code=500, msg='test error', hdrs=None, fp=None), "make test")
    assert e.http_code == 500
    assert e.url is None
    assert e.message == "make test (HTTP Code: 500, Message: test error)"


# Generated at 2022-06-20 14:41:37.809868
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    real_lock = _CACHE_LOCK
    _CACHE_LOCK = threading.Lock()
    lock = threading.Lock()
    # set function to simulate loading from cache
    @cache_lock
    def load_cache():
        """Test to simulate cache loading"""
        with lock:
            time.sleep(0)  # sleep just to keep busy

    # set function to simulate writing to cache
    # function is decorated to ensure that only one thread
    # is allowed to write to cache at a time
    @cache_lock
    def write_cache():
        """Test to simulate writing to cache"""
        time.sleep(1)  # sleep just to keep busy

    # set thread to load cache
    load_thread = threading.Thread(target=load_cache)

    # set threads to write

# Generated at 2022-06-20 14:41:39.617973
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    '''
    Test __unicode__
    '''
    pass

# Generated at 2022-06-20 14:41:51.911067
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    print("test CollectionVersionMetadata")
    namespace = "ansible_namespace"
    name = "ansible_name"
    version = "1.0.0"
    download_url = "http://download_url"
    artifact_sha256 = "sha256"
    dependencies = dict(deps = dict(namespaced_deps = dict(name = "name", version = "version")))
    CollectionVersionMetadata_obj = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert CollectionVersionMetadata_obj.namespace == namespace
    assert CollectionVersionMetadata_obj.name == name
    assert CollectionVersionMetadata_obj.version == version
    assert CollectionVersionMetadata_obj.download_url == download_url
    assert CollectionVersionMetadata_obj.artifact_sha256

# Generated at 2022-06-20 14:41:53.692660
# Unit test for function cache_lock
def test_cache_lock():
    assert cache_lock(None) is None


# Generated at 2022-06-20 14:42:03.888511
# Unit test for function g_connect
def test_g_connect():
    class TestClass(object):
        def __init__(self):
            self._available_api_versions = {}
            self.api_server = 'https://galaxy.ansible.com'
            self.name = 'Galaxy'

        @g_connect(["v1", "v2"])
        def test_function(self):
            return True

        def _call_galaxy(self, url, **kwargs):
            return {'available_versions': {u'v1': u'v1/'}}

    test_obj = TestClass()
    test_obj.test_function()
test_g_connect.unit_test = True



# Generated at 2022-06-20 14:43:10.054032
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    cv = CollectionMetadata('namespace', 'name', created_str=None, modified_str=None)
    assert cv.created_str is None
    assert cv.modified_str is None

    cv = CollectionMetadata('namespace', 'name', created_str='2019-02-24T23:58:15',
                            modified_str='2019-02-24T23:58:15')
    assert cv.created_str == '2019-02-24T23:58:15'
    assert cv.modified_str == '2019-02-24T23:58:15'

    # __str__
    assert str(cv) == 'name.namespace (created: 2019-02-24T23:58:15, modified: 2019-02-24T23:58:15)'

    # __repr__

# Generated at 2022-06-20 14:43:13.329690
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    CollectionMetadata('namespace', 'collection')



# Generated at 2022-06-20 14:43:16.882491
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # test with empty server name
    assert GalaxyAPI()

    # test with invalid server name
    with pytest.raises(AttributeError):
        GalaxyAPI(server='no.such.server')


# Unit tests for some of the methods in the class GalaxyAPI

# Generated at 2022-06-20 14:43:20.050708
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError("Test", http_code=429))
    assert is_rate_limit_exception(GalaxyError("Test", http_code=520))
    assert isinstance(is_rate_limit_exception(GalaxyError("Test", http_code=403)), bool) is False



# Generated at 2022-06-20 14:43:34.366567
# Unit test for function cache_lock
def test_cache_lock():
    # Test with no args or kwargs
    @cache_lock
    def test_func(call_count):
        call_count["count"] += 1

    call_count = {"count": 0}
    test_func(call_count)
    assert call_count["count"] == 1

    # Test with args
    @cache_lock
    def test_func_args(call_count, arg1):
        call_count["count"] += arg1

    call_count = {"count": 0}
    test_func_args(call_count, 4)
    assert call_count["count"] == 4

    # Test with kwargs
    @cache_lock
    def test_func_kwargs(call_count, arg1=0, arg2=0):
        call_count["count"] += arg1 + arg2

    call

# Generated at 2022-06-20 14:43:41.965263
# Unit test for function g_connect
def test_g_connect():
    class A():
        def __init__(self):
            self.name = 'Local Galaxy'
            self.api_server = 'http://localhost:3000/'
            self.client_id = ''
            self.key_id = ''
            self.secret_key_content = ''
            self.api_key = ''
            self._available_api_versions = ''
            self.ssl_validation=False
        def _call_galaxy(self, url, data=None, method=None, force=False, error_context_msg=None, cache=False, follow_redirects=True):
            return {"available_versions": {u'v1': u'v1/'}}

    a = A()
    a._available_api_versions = ''

# Generated at 2022-06-20 14:43:49.574476
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429, url="http://example.com"))
    assert not is_rate_limit_exception(GalaxyError(http_code=403, url="http://example.com"))
    assert not is_rate_limit_exception(GalaxyError(http_code=520, url="http://example.com"))
    assert not is_rate_limit_exception(GalaxyError(http_code=400, url="http://example.com"))


# Generated at 2022-06-20 14:43:51.876871
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    obj = GalaxyAPI('http://foo.bar')
    assert obj.__unicode__() == 'foo.bar'


# Generated at 2022-06-20 14:43:53.932624
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    obj = GalaxyAPI('name', 'api_server')
    obj2 = GalaxyAPI('name', 'api_server')
    assert(obj < obj2)

# Generated at 2022-06-20 14:43:59.650704
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class CustomException(Exception):
        pass

    from ansible.galaxy import GalaxyError

    assert not is_rate_limit_exception(Exception())
    assert is_rate_limit_exception(GalaxyError('message', http_code=429))
    assert is_rate_limit_exception(GalaxyError('message', http_code=520))
    assert not is_rate_limit_exception(GalaxyError('message', http_code=403))
    assert not is_rate_limit_exception(CustomException())

