

# Generated at 2022-06-20 14:36:56.847972
# Unit test for function cache_lock
def test_cache_lock():
    func = lambda x: x
    wrapped_func = cache_lock(func)
    assert wrapped_func(x=42) == 42


# Generated at 2022-06-20 14:36:59.782997
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    result = GalaxyAPI("mock_api_server", "mock_name", "mock_api_key")
    assert str(result) == "mock_name on http://mock_api_server"

# Generated at 2022-06-20 14:37:08.268906
# Unit test for function get_cache_id

# Generated at 2022-06-20 14:37:16.451546
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    artifact_sha256 = "deadbeef0000"
    namespace = "test"
    name = "test"
    version = "1.0.0"
    download_url = "https://galaxy.ansible.com/api/v2/collections/test/test/versions/1.0.0/artifacts/"
    dependencies = {"test": {"namespace": "test", "name": "test", "requirements": ">= 1.2.0"}}
    collection_version_metadata = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)


CollectionInfo = collections.namedtuple('CollectionInfo', ['namespace', 'name', 'versions', 'description'])



# Generated at 2022-06-20 14:37:31.571387
# Unit test for function g_connect
def test_g_connect():
    class TestGalaxy(object):
        name = 'test'
        api_server = 'http://localhost:5678'
        _available_api_versions = []
        _url_username = None
        _url_password = None

        def __init__(self):
            self.session_token= None

        def _call_galaxy(self, url, method, data=None, use_token=False, extra_headers=None, error_context_msg=None,
                         condition=None, retries=5, allow_redirects=True, cache=False):
            if url == 'http://localhost:5678/api/':
                return {'available_versions': {'v1': 'v1/'}}
            raise AnsibleError("Test!")

    testObj = TestGalaxy()

# Generated at 2022-06-20 14:37:39.550093
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI(
        name="name",
        api_server="api_server",
        ignore_certs=True,
        force_basic_auth=True,
        available_api_versions=["v2"],
        token=None,
        ignore_cache=True,
        client_cert=None,
        user=None,
        password=None,
    )

    assert api.__str__() == "<GalaxyAPI name='name' api_server='api_server' ignore_certs='True' force_basic_auth='True' available_api_versions='['v2']' token=<NoneType> ignore_cache='True' client_cert=<NoneType> user=<NoneType> password=<NoneType>>"

# Generated at 2022-06-20 14:37:43.637217
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    display.debug("TEST: galaxy_api()")

    galaxy_api = GalaxyAPI('galaxy_server', galaxy_token='token')
    # TODO: Add in additional testing

    # Unit test for GalaxyAPI._call_galaxy
    def test_GalaxyAPI_call_galaxy():
        galaxy_api = GalaxyAPI('galaxy_server', galaxy_token='token')
        display.debug("TEST: galaxy_api() ._call_galaxy()")

        # TODO: Add in additional testing
        assert galaxy_api is not None

# Generated at 2022-06-20 14:37:49.942371
# Unit test for function cache_lock
def test_cache_lock():
    class TestObj(object):
        # used to test whether cache_lock correctly pass the first parameter
        self_param = None
        @cache_lock
        def self_method(self):
            self.self_param = self

    test_obj = TestObj()
    test_obj.self_method()
    assert test_obj.self_param is not None


# Generated at 2022-06-20 14:37:59.150275
# Unit test for function g_connect
def test_g_connect():
    import sys
    import os
    Script_path = os.path.realpath(__file__)
    Script_folder = os.path.basename(Script_path)
    Package = Script_folder.replace("test_", "")
    Package_path = Script_path.replace("test_" + Script_folder, Package)
    Galaxy_path = Script_path.replace("test_" + Script_folder, "galaxy")
    if Package_path not in sys.path:
        sys.path.append(Package_path)
    if Galaxy_path not in sys.path:
        sys.path.append(Galaxy_path)
    
    # import test module
    from ..galaxy_server import GalaxyServer
    gs = GalaxyServer("")
    tmp = gs._available_api_versions
    gs._available_api

# Generated at 2022-06-20 14:38:04.567710
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI(server='https://galaxy.com/')
    expected_repr = 'GalaxyAPI(server=https://galaxy.com/, api_token=***, skip_cert_validation=False)'

    assert repr(api) == expected_repr


# Generated at 2022-06-20 14:38:43.582816
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    test_metadata = CollectionVersionMetadata("test_ns", "test_name", "1.0.0", "http://fake_url.com", "fake_sha256", [])
    assert test_metadata.namespace == "test_ns"
    assert test_metadata.name == "test_name"
    assert test_metadata.version == "1.0.0"
    assert test_metadata.download_url == "http://fake_url.com"
    assert test_metadata.artifact_sha256 == "fake_sha256"
    assert test_metadata.dependencies == []


# Generated at 2022-06-20 14:38:49.844253
# Unit test for function get_cache_id
def test_get_cache_id():
    """ Unit test for function get_cache_ie. """
    import pytest
    url = 'https://username:password@galaxy.ansible.com'
    cache_id = get_cache_id(url)
    assert cache_id == 'galaxy.ansible.com:443'



# Generated at 2022-06-20 14:38:51.546795
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    assert repr(GalaxyError) == repr(AnsibleError)
    assert str(GalaxyError) == str(AnsibleError)



# Generated at 2022-06-20 14:38:56.134074
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI(name="ansible", api_server="https://galaxy.ansible.com/api/")
    expected = "GalaxyAPI(name=u'ansible', api_server=u'https://galaxy.ansible.com/api/')"
    actual = repr(galaxy_api)
    assert type(expected) == type(actual)
    assert expected == actual



# Generated at 2022-06-20 14:39:08.685703
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("http://host.com") == "host.com:"
    assert get_cache_id("http://host.com:80") == "host.com:80"
    assert get_cache_id("http://host.com:80/path/to/api") == "host.com:80"
    assert get_cache_id("http://user:pass@host.com:80/path/to/api") == "host.com:80"
    assert get_cache_id("http://user:pass@host.com:80/path/to/api?query=yes") == "host.com:80"
    assert get_cache_id("http://host.com/path/to/api?query=yes") == "host.com:"

# Generated at 2022-06-20 14:39:16.862178
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI('https://galaxy.server', 'username', 'password', 'token')
    assert repr(galaxy_api) == "GalaxyAPI(api_server=https://galaxy.server,token=token,user=username,pass=********)"


# Generated at 2022-06-20 14:39:21.747089
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def func_to_test(a, b):
        return a, b
    assert (1, 2) == func_to_test(1, 2)


# Generated at 2022-06-20 14:39:29.067329
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # Unhappy cases
    assert is_rate_limit_exception(Exception()) == False
    assert is_rate_limit_exception(GalaxyError(http_code=400)) == False
    assert is_rate_limit_exception(GalaxyError(http_code=404)) == False
    assert is_rate_limit_exception(GalaxyError(http_code=403)) == False
    # Happy cases
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))


# Generated at 2022-06-20 14:39:38.027272
# Unit test for function g_connect
def test_g_connect():
    # this has the wrappers with the inner function
    # call the inner function
    # verify the inner function was called
    import mock

    # This is what i'm trying to mock
    versions = ['v1']

    # These are the parameters that are needed
    self = mock.MagicMock()
    method = mock.MagicMock()

    g_connect(versions)(method)(self)

    # this is what I want to verify
    method.assert_called_once_with(self)



# Generated at 2022-06-20 14:39:43.616956
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    metadata = CollectionVersionMetadata('namespace', 'name', 'version', 'download_url', 'artifact_sha256', 'dependencies')

    assert metadata.namespace == 'namespace'
    assert metadata.name == 'name'
    assert metadata.version == 'version'
    assert metadata.download_url == 'download_url'
    assert metadata.artifact_sha256 == 'artifact_sha256'
    assert metadata.dependencies == 'dependencies'


# Generated at 2022-06-20 14:41:08.383408
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collectionmeta = CollectionMetadata("ns", "name", "full_name", "created_str", "modified_str")
    assert collectionmeta.namespace == "ns"
    assert collectionmeta.name == "name"
    assert collectionmeta.full_name == "full_name"
    assert collectionmeta.created_str == "created_str"
    assert collectionmeta.modified_str == "modified_str"


# Generated at 2022-06-20 14:41:10.150721
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError('', http_code=429))
    assert not is_rate_limit_exception(GalaxyError('', http_code=500))



# Generated at 2022-06-20 14:41:15.131610
# Unit test for function g_connect
def test_g_connect():

    def test_func(func):
        func()

    test_func = g_connect(['v1', 'v2'])(test_func)
    test_func()


# TODO: remove this version in a future version.  This was an attempt to make
# the params variable optional.  However, we are going to remove the params
# variable from GalaxyClient as we move to using headers instead.

# Generated at 2022-06-20 14:41:20.163897
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI()
    assert str(galaxy_api) == 'GalaxyAPI(name=None, api_server=None)'


# Generated at 2022-06-20 14:41:25.198191
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api = GalaxyAPI(
        name='Test',
        api_server='https://galaxy.ansible.com',
    )

    api_other = GalaxyAPI(
        name='Test',
        api_server='https://galaxy.example.com',
    )

    assert api < api_other
    assert not api < api

    # Handle None
    assert not api < None
    assert not None < api
    assert not None < None



# Generated at 2022-06-20 14:41:33.564780
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    '''Check if it returns a string representation of the object.'''
    obj = GalaxyAPI("https://galaxy.ansible.com", "https://galaxy.ansible.com/api")
    expected = 'GalaxyAPI(api_server=https://galaxy.ansible.com, server=https://galaxy.ansible.com/api, ' \
        'available_api_versions={u\'v2\': u\'api-v2\', u\'v3\': u\'api-v3\'}, name=None)'

    assert obj.__repr__() == expected



# Generated at 2022-06-20 14:41:42.921242
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    from six import text_type
    from hypothesis import given
    from hypothesis import strategies as st
    from ansible.galaxy.api import GalaxyAPI
    galaxy_api_0_instance = GalaxyAPI(
        name='galaxy_name_0',
        server='galaxy_server_0',
        ignore_certs=False,
        api_token='galaxy_api_token_0',
        cache=True,
        verify_ssl=False
    )
    with pytest.raises(AttributeError):
        assert str(galaxy_api_0_instance)



# Generated at 2022-06-20 14:41:48.514981
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    test_data = {
        "namespace": "namespace",
        "name": "name",
        "created_str": "created",
        "modified_str": "modified",
    }
    metadata = CollectionMetadata(**test_data)
    assert metadata.namespace == test_data["namespace"]
    assert metadata.name == test_data["name"]
    assert metadata.created_str == test_data["created_str"]
    assert metadata.modified_str == test_data["modified_str"]


# Generated at 2022-06-20 14:41:53.964959
# Unit test for function cache_lock
def test_cache_lock():
    cache_lock(lambda: None)()
    assert True

_CACHE_DIR_LOCKS = {}
_CACHE_DIR_LOCKS_LOCK = threading.Lock()


# Generated at 2022-06-20 14:41:57.138195
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert(True == is_rate_limit_exception(GalaxyError("429 Too Many Requests")))
    assert(True == is_rate_limit_exception(GalaxyError("520 Distribution creation rate limit reached")))
    assert(False == is_rate_limit_exception(GalaxyError("403 Forbidden")))
test_is_rate_limit_exception()


# Generated at 2022-06-20 14:44:24.505732
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429)) is True
    assert is_rate_limit_exception(GalaxyError(http_code=520)) is True
    assert is_rate_limit_exception(HTTPError("foo.py", 403, "Forbidden", {}, None)) is False
    assert is_rate_limit_exception(HTTPError("foo.py", 500, "Internal Server Error", {}, None)) is False



# Generated at 2022-06-20 14:44:36.230292
# Unit test for function g_connect
def test_g_connect():
    class FakeGalaxyAPI(object):
        def __init__(self):
            self.api_server = "https://api.galaxy.ansible.com"
            self._available_api_versions = {}
            self.name = "Ansible Galaxy"
            self._auth_headers = {
                "Authorization": "Bearer 5aCjQzfQxDfo6oBUwWjL5YbHmREBJv",
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": user_agent()}
            self._cache = {}
            self._persistent_cache = {}
            self._ensure_cache_dirs()


# Generated at 2022-06-20 14:44:43.342724
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection_metadata = CollectionMetadata("namespace", "name", "created_str", "modified_str")
    assert collection_metadata.namespace == "namespace"
    assert collection_metadata.name == "name"
    assert collection_metadata.created_str == "created_str"
    assert collection_metadata.modified_str == "modified_str"



# Generated at 2022-06-20 14:44:47.249231
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    metadata = CollectionMetadata('namespace', 'name')
    assert metadata.namespace == 'namespace'
    assert metadata.name == 'name'
    assert metadata.created_str is None
    assert metadata.modified_str is None


# Generated at 2022-06-20 14:44:53.620128
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    metadata = CollectionVersionMetadata('namespace', 'name', 'version', 'download_url', 'artifact_sha256', 'dependencies')
    assert metadata.namespace == 'namespace'
    assert metadata.name == 'name'
    assert metadata.version == 'version'
    assert metadata.download_url == 'download_url'
    assert metadata.artifact_sha256 == 'artifact_sha256'
    assert metadata.dependencies == 'dependencies'


# Generated at 2022-06-20 14:45:07.557331
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError()
    http_error.code = 500
    http_error.reason = 'INTERNAL SERVER ERROR'
    http_error.geturl = lambda: 'https://cloud.redhat.com/api/galaxy/v2/roles'
    http_error.read = lambda: '{ "message": "Internal Server Error: could not load roles" }'
    ge = GalaxyError(http_error, 'Could not load roles at %s' % http_error.geturl())
    assert ge.http_code == 500
    assert ge.url == 'https://cloud.redhat.com/api/galaxy/v2/roles'

# Generated at 2022-06-20 14:45:15.965191
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api_object = GalaxyAPI(api_server='https://galaxy.ansible.com', name='galaxy.ansible.com', is_default=False,
                           token='79ccdb7eb6035b9e842bd0f0caf6fcf7', ignore_certs=False)
    assert unicode(api_object) == u"<GalaxyAPI(galaxy.ansible.com)>"



# Generated at 2022-06-20 14:45:29.127051
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Invalid Server URLs.
    with pytest.raises(AnsibleError) as excinfo:
        api = GalaxyAPI('https://', 'api_key', 'username')
    assert 'Invalid Galaxy server URL' in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        api = GalaxyAPI('https:///something', 'api_key', 'username')
    assert 'Invalid Galaxy server URL' in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        api = GalaxyAPI('http://galaxy.ansible.com', 'api_key', 'username')
    assert 'The Galaxy API server URL specified is not HTTPS' in str(excinfo.value)

    # Set value for all variables.

# Generated at 2022-06-20 14:45:30.854881
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    assert 'GalaxyAPI()' == "%s" % GalaxyAPI()


# Generated at 2022-06-20 14:45:34.166236
# Unit test for function cache_lock
def test_cache_lock():
    """
    >>> test_cache_lock()
    """
    # do nothing just to make mypy happy
    # https://github.com/python/mypy/issues/1263
    pass

