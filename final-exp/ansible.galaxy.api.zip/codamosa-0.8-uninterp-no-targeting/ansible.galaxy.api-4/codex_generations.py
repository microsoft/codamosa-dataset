

# Generated at 2022-06-20 14:37:33.707711
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # Create a mock http.HTTPResponse object.
    class MockHTTPResponse:
        def __init__(self, v3_errors_json, v2_message_json='', v3_message_json=''):
            self.code = '200'
            self.msgs = {
                'v2': v2_message_json,
                'v3': v3_message_json,
                'v3_errors': v3_errors_json
            }
            self.read()

        def geturl(self):
            return self.url

        def read(self):
            return self.msgs[self.url_api]

    # Create an http.HTTPResponse object, initialized with the JSON string returned by Galaxy API v3

# Generated at 2022-06-20 14:37:39.807569
# Unit test for function g_connect
def test_g_connect():
    connection = AnsibleGalaxyAPI(galaxy_server='https://galaxy.ansible.com')
    connection._call_galaxy = lambda *_, **__: {'available_versions': {u'v1': u'v1/'}}
    assert connection._available_api_versions == {}
    try:
        connection._call_galaxy('https://galaxy.ansible.com/nowhere')
    except AnsibleError:
        pass
    else:
        assert False, '_call_galaxy should have thrown an AnsibleError'
    assert connection._available_api_versions == {}



# Generated at 2022-06-20 14:37:41.452875
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI(name, galaxy_server)
    assert str(api) == "Galaxy server name:%s url:%s" % (name, galaxy_server)



# Generated at 2022-06-20 14:37:45.794815
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    apis = [
        {'name': 'Test', 'api_server': 'http://localhost', 'token': 'some_token'},
        {'name': 'Test', 'api_server': 'http://localhost'},
    ]
    for api in apis:
        galaxy = GalaxyAPI(**api)
        assert galaxy
        assert isinstance(galaxy.token, string_types)
        assert galaxy.name == api['name']
        assert galaxy.api_server == api['api_server']

# Unit tests for function get_cache

# Generated at 2022-06-20 14:37:56.526899
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test inventory with defaults
    api = GalaxyAPI('http://127.0.0.1/')
    assert api.name == 'API'
    assert api.api_server == 'http://127.0.0.1'
    assert api.token is None
    assert api.ignore_certs is False

    # Test inventory with kwargs
    api = GalaxyAPI('http://127.0.0.1', token='123456', ignore_certs=True, name='foo')
    assert api.name == 'foo'
    assert api.api_server == 'http://127.0.0.1'
    assert api.token == '123456'
    assert api.ignore_certs is True

    # Test inventory with no kwargs
    api = GalaxyAPI('http://127.0.0.1')

# Generated at 2022-06-20 14:38:10.212441
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api1 = GalaxyAPI('https://galaxy.example.com', 'my_user', 'my_pass', 'my_token', 'my_secret', 'MyGalaxy')
    api1.name = 'api1'
    api2 = GalaxyAPI('https://galaxy.example.com', 'my_user', 'my_pass', 'my_token', 'my_secret', 'MyGalaxy')
    api2.name = 'api2'
    assert (api1 < api2) is False
    assert (api2 < api1) is False
    api1.name = 'api2'
    assert (api1 < api2) is False
    api1.name = 'api1'
    api2.name = 'api1'
    assert (api1 < api2) is False
    api1.name = 'api1'
   

# Generated at 2022-06-20 14:38:13.581964
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://localhost:8888/api/v1') == 'localhost:8888'
    assert get_cache_id('http://localhost/api/v1') == 'localhost:None'
    assert get_cache_id('http://localhost:8888/api/v1/') == 'localhost:8888'
    assert get_cache_id('http://localhost/api/v1/') == 'localhost:None'



# Generated at 2022-06-20 14:38:19.522110
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('url', 404, "Error", dict(), dict())
    TestMe = GalaxyError(http_error, "message")
    assert TestMe.message.startswith("message (HTTP Code: 404, Message: Error")
    assert TestMe.http_code == 404
    assert TestMe.url == "url"



# Generated at 2022-06-20 14:38:26.801113
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI('https://galaxy.server.tld')

    assert galaxy_api.api_server == 'https://galaxy.server.tld'
    assert galaxy_api.api_token == ''
    assert len(galaxy_api.cache) == 0
    assert galaxy_api.headers == {}
    assert galaxy_api.name == 'galaxy.server.tld'
    assert galaxy_api._session == None



# Generated at 2022-06-20 14:38:35.764992
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    #Regression test for bug: https://github.com/ansible/ansible/issues/65007
    # GalaxyError class should handle v2 and v3 API response
    fake_msg = u"Fake Error Message"
    fake_response = {'message': fake_msg, 'code': 404}
    fake_http_error = type("FakeHTTP404", (object,), {
        'code': 404,
        'reason': 'FakeGalaxyError',
        'geturl': lambda self: 'https://galaxy.example.com/api/v2',
        # Pretend to be a real server and return the fake_response payload.
        'read': lambda self, amt=None: json.dumps(fake_response).encode('utf-8'),
    })
    # Test GalaxError constructor for v2 API

# Generated at 2022-06-20 14:39:14.574536
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    """
    Unit test created to test the constructor of the class CollectionVersionMetadata
    """
    collection_version_metadata = CollectionVersionMetadata('ansible', 'my_collection', '1.0.0',
                                                            'http://localhost/namespace/my_collection-1.0.0.tar.gz',
                                                            '1234567890abcdefg', {
        'namespace.collection': '1.0.0'
    })

    assert collection_version_metadata.namespace == 'ansible'
    assert collection_version_metadata.name == 'my_collection'
    assert collection_version_metadata.version == '1.0.0'
    assert collection_version_metadata.download_url == 'http://localhost/namespace/my_collection-1.0.0.tar.gz'
    assert collection_

# Generated at 2022-06-20 14:39:21.555046
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():

    m = CollectionVersionMetadata('namespace1', 'name1', 'version1', 'download_url1', 'artifact_sha2561', 'dependencies1')
    assert m.namespace == 'namespace1'
    assert m.name == 'name1'
    assert m.version == 'version1'
    assert m.download_url == 'download_url1'
    assert m.artifact_sha256 == 'artifact_sha2561'
    assert m.dependencies == 'dependencies1'


# Generated at 2022-06-20 14:39:31.751424
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    class MockGalaxyAPI(object):
        def __init__(self, api_server, name):
            self.api_server = api_server
            self.name = name

    ga = GalaxyAPI('https://galaxy.ansible.com/api', 'galaxy')
    ga2 = GalaxyAPI('https://galaxy.ansible.com/api', 'galaxy')
    ga3 = GalaxyAPI('https://galaxy2.ansible.com/api', 'galaxy')
    ga4 = GalaxyAPI('https://galaxy.ansible.com/api', 'galaxy2')
    ga5 = GalaxyAPI('https://galaxy2.ansible.com/api', 'galaxy2')
    ga6 = GalaxyAPI('https://galaxy.ansible.com/api/v2', 'galaxy')
    ga7 = GalaxyAPI

# Generated at 2022-06-20 14:39:38.481478
# Unit test for function g_connect
def test_g_connect():
    def test_func(self, *args, **kwargs):
        return True
    wrapped = g_connect(['test'])(test_func)
    assert(wrapped(None) is True)


# Generated at 2022-06-20 14:39:42.625249
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    import mock

    retry_codes = [429, 520]
    exception = GalaxyError("msg", 500, retry_codes)
    with mock.patch("ansible_galaxy.requests.open_url", return_value=exception):
        assert is_rate_limit_exception("") is True



# Generated at 2022-06-20 14:39:58.586971
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six.moves.http_client import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    import json

    error_class = AnsibleError
    if not hasattr(error_class, "__traceback__"):
        import sys
        error_class.__traceback__ = sys.exc_info()[2]

    TestAnsibleError = error_class(u"test")
    TestHTTPError = HTTPError(None, 404, "test", {}, None)
    TestURLError = URLError("test")
    TestGalaxyError = GalaxyError(TestHTTPError, "test")
    assert(TestHTTPError.code == 404)

# Generated at 2022-06-20 14:40:03.153293
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    cm = CollectionMetadata('namespace', 'collection_name', created_str='created_str', modified_str='modified_str')
    assert cm.namespace == 'namespace'
    assert cm.name == 'collection_name'
    assert cm.version is None
    assert cm.created_str == 'created_str'
    assert cm.modified_str == 'modified_str'

# Unit tests for constructor of class CollectionVersionMetadata

# Generated at 2022-06-20 14:40:12.153914
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    """Unit test for method __unicode__ of class GalaxyAPI"""

    # Note, this is a bit of a rough test as there is no easy way to patch the
    # display_requirements() method of the display with a mocked response. Adding
    # a name like this here could cause side effects in other tests.
    api = GalaxyAPI(name='galaxy_api_test')
    assert api.__unicode__() == 'galaxy_api_test'


# Generated at 2022-06-20 14:40:23.784586
# Unit test for function g_connect
def test_g_connect():
    import unittest
    from ansible.galaxy.server import GalaxyServerAPI

    class TestGalaxyServerAPI(unittest.TestCase):
        def setUp(self):
            self.g = GalaxyServerAPI(server=urljoin('https://galaxy.ansible.com/', '/api', False), token=None)
        def test_g_connect(self):
            @g_connect(versions=['v1', 'v2'])
            def function(self):
                pass
            self.assertRaises(AnsibleError, function, self)
            @g_connect(versions=['v2', 'v1'])
            def function(self):
                pass
            self.assertRaises(AnsibleError, function, self)

# Generated at 2022-06-20 14:40:34.255932
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'test'
    name = 'test'
    version = '1.1.1'
    url = 'https://example.com'
    sha256 = 'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'

# Generated at 2022-06-20 14:42:04.318983
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    exception = HTTPError('http://my-galaxy-server/', 404, 'The page is not found', [], None)
    err = GalaxyError(exception, 'My custom error message')
    assert err.http_code == 404
    assert err.message == 'My custom error message (HTTP Code: 404, Message: The page is not found)'



# Generated at 2022-06-20 14:42:12.295351
# Unit test for function cache_lock
def test_cache_lock():
    lock = threading.Lock()
    lock_wrapper = cache_lock(lock.acquire)
    # Cache lock only wraps default lock
    assert lock_wrapper == lock.acquire
    # Multi-threaded cache lock
    thread1 = threading.Thread(target=lock_wrapper)
    thread2 = threading.Thread(target=lock_wrapper)
    thread1.start()
    thread2.start()
    thread1.join()
    thread2.join()
    # Single-threaded cache lock
    with _CACHE_LOCK:
        lock_wrapper()



# Generated at 2022-06-20 14:42:23.260847
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    ansible_server = "https://galaxy.server.org"
    galaxy_api_v3 = GalaxyAPI(galaxy_server=ansible_server)
    galaxy_api_v2 = GalaxyAPI(galaxy_server=ansible_server)
    galaxy_api_v2.available_api_versions['v2'] = 'v2'
    galaxy_api_v3.available_api_versions['v3'] = 'v3'

    assert(galaxy_api_v2 < galaxy_api_v3)
    assert(not galaxy_api_v3 < galaxy_api_v2)

# Unit tests for method get_collection_versions

# Generated at 2022-06-20 14:42:27.576761
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    actual = 'test_GalaxyAPI___unicode__'
    expected = 'test_GalaxyAPI___unicode__'
    assert actual == expected

# Generated at 2022-06-20 14:42:35.482531
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'namespace'
    name = 'name'
    version = 'version'
    download_url = 'download_url'
    artifact_sha256 = 'artifact_sha256'
    dependencies = 'dependencies'
    collection_version_metadata = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert collection_version_metadata.namespace == namespace
    assert collection_version_metadata.name == name
    assert collection_version_metadata.version== version
    assert collection_version_metadata.download_url == download_url
    assert collection_version_metadata.artifact_sha256 == artifact_sha256
    assert collection_version_metadata.dependencies == dependencies


# Generated at 2022-06-20 14:42:40.732515
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    host = 'https://galaxy.ansible.com/api'
    api_token = 'abcde12345'
    galaxy_api = GalaxyAPI(host=host, api_token=api_token, verify_ssl=True)
    assert str(galaxy_api) == 'GalaxyAPI(host=https://galaxy.ansible.com/api, api_token=***)'


# Generated at 2022-06-20 14:42:52.333126
# Unit test for function g_connect
def test_g_connect():
    class G(object):
        # Define class, will be initialized for unit test.
        def name_and_server(self):
            return "MockServer"
        def _call_galaxy(self, url, method, **kwargs):
            return {}

    def test_func(self):
        pass

    # Test version is not supported.
    g = G()
    g_connected_func = g_connect(['v3'])(test_func)
    raised = False
    try:
        g_connected_func(g)
    except AnsibleError:
        raised = True
    assert raised

    # Test version is supported.
    # Test version is not supported.
    g = G()
    g._available_api_versions = {'v1': 'v1/'}
    g_connected_func = g_

# Generated at 2022-06-20 14:43:01.814805
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # We don't really want to hit the real Galaxy server so we use an object to get around that.
    class MockGalaxyAPI(object):
        def __init__(self):
            self.api_server = 'server'
            self.api_token = 'token'
            self.name = 'mock_galaxy_api'
            self.available_api_versions = ['v1', 'v2', 'v3']

    mock_galaxy_api = MockGalaxyAPI()

    # Check when the compared API has API versions, we compare the API server.
    galaxy_api = GalaxyAPI(api_server='mock://test/mock_galaxy_api/', api_key='token')

# Generated at 2022-06-20 14:43:07.533798
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    g_api = GalaxyAPI(None, None, None)
    assert g_api.__str__() == "Galaxy API for None"

# Generated at 2022-06-20 14:43:18.711617
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # Test as a stand-alone function
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(GalaxyError(http_code=404))

    # Test as a decorator
    @retry_with_delays_and_condition(exception_conditions=is_rate_limit_exception)
    def retry_test(exc_type):
        raise exc_type

    try:
        retry_test(GalaxyError(http_code=403))
        assert False, "Expected exception"
    except GalaxyError as e:
        assert e.http_code == 403


# Generated at 2022-06-20 14:44:38.846019
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    cache_path = tempfile.mkdtemp()
    config = {
        'galaxy_server': 'https://galaxy.ansible.com',
        'galaxy_token': 'TOKEN',
        'force_api_version': None,
        'cache_path': cache_path,
    }

    url = urlparse(config['galaxy_server'])

    galaxy = GalaxyAPI(config['galaxy_server'],
                       config['galaxy_token'],
                       config['force_api_version'],
                       config['cache_path'])

    assert galaxy.name == 'galaxy_server'
    assert galaxy.galaxy_token == config['galaxy_token']
    assert galaxy.api_server == config['galaxy_server']

    assert url.scheme in galaxy.available_api_versions

# Generated at 2022-06-20 14:44:44.037727
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI('mygalaxyserver.com', 'foo', 'bar')
    assert galaxy_api.name == 'mygalaxyserver.com'
    assert galaxy_api.username == 'foo'
    assert galaxy_api.password == 'bar'


# Generated at 2022-06-20 14:44:44.708328
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    pass

# Generated at 2022-06-20 14:44:47.000129
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    obj = GalaxyAPI()
    assert isinstance(obj.__unicode__(), str)

# Generated at 2022-06-20 14:44:50.961073
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_class = GalaxyAPI(name='GalaxyServer', api_server='https://galaxy.ansible.com')
    assert galaxy_class.__repr__() == 'GalaxyServer (https://galaxy.ansible.com)'


# Generated at 2022-06-20 14:44:55.849453
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class _GalaxyError(GalaxyError):
        http_code = 429
    rate_limit_error = _GalaxyError(http_code=429)
    assert is_rate_limit_exception(rate_limit_error) is True
    assert is_rate_limit_exception(GalaxyError(http_code=403, url='https://galaxy.ansible.com')) is False



# Generated at 2022-06-20 14:45:08.778000
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
  t = GalaxyAPI(b_url="/path/to/server", b_ignore_certs=True, b_api_key="secret", username="gibson")

  assert not t < GalaxyAPI(b_url="/path/to/server", b_ignore_certs=True, b_api_key="secret", username="gibson")

  assert t < GalaxyAPI(b_url="/path/to/server", b_ignore_certs=False, b_api_key="secret", username="gibson")
  assert t < GalaxyAPI(b_url="/path/to/server", b_ignore_certs=True, b_api_key="different", username="gibson")

# Generated at 2022-06-20 14:45:17.791525
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    sample_timestamp_from_galaxy = '2018-05-09T16:46:08.039'
    sample_timestamp_from_galaxy_timezone = '2018-05-09T16:46:08.039-04:00'

    test_cm = CollectionMetadata('ns', 'name', created_str = sample_timestamp_from_galaxy, modified_str = sample_timestamp_from_galaxy)
    assert test_cm.created == datetime.strptime(sample_timestamp_from_galaxy, '%Y-%m-%dT%H:%M:%S.%f')

# Generated at 2022-06-20 14:45:24.114534
# Unit test for function g_connect
def test_g_connect():
    def g_test(test):
        @g_connect(['test'])
        def g_test_wrapper(this):
            return 'test'
        return g_test_wrapper(test)
    print(g_test('test'))
    try:
        g_test('test2')
    except Exception:
        print('Exception raised')



# Generated at 2022-06-20 14:45:28.808655
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise HTTPError("http://127.0.0.1/", 500, "Ansible Inc.", "TEST", "{'default': 'Test'}")
    except HTTPError as error:
        raise GalaxyError(error, "TEST")
