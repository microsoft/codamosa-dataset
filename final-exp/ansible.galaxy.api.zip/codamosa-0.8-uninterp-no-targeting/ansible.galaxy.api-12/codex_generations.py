

# Generated at 2022-06-20 14:37:04.962357
# Unit test for function get_cache_id
def test_get_cache_id():
    # Galaxy servers with credentials
    assert get_cache_id('https://ansible:abc123@galaxy.ansible.com') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com/api') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com/api/v1/') == 'galaxy.ansible.com:443'
    assert get_cache_id('https://galaxy.ansible.com/api/v1') == 'galaxy.ansible.com:443'
    # Galaxy servers without credentials

# Generated at 2022-06-20 14:37:07.052015
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def locking_func():
        return True

    assert locking_func() is True
    return



# Generated at 2022-06-20 14:37:09.420062
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(
        GalaxyError(dict({"message": "rate limit exceeded", "error": 19}))
    )



# Generated at 2022-06-20 14:37:22.773361
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Save old settings
    old_api_server = []
    for setting in C.GALAXY_SERVERS:
        old_api_server.append(C.GALAXY_SERVERS[setting])
        C.GALAXY_SERVERS[setting] = 'https://%s.test.com/' % setting

    ga = GalaxyAPI(None, 'test')
    for setting in C.GALAXY_SERVERS:
        assert ga.api_server == 'https://%s.test.com/' % setting

    ga = GalaxyAPI(None, None)
    assert ga.api_server == 'https://galaxy.ansible.com/'

    # Restore old settings
    for setting in C.GALAXY_SERVERS:
        C.GALAXY_SERVERS[setting] = old_api

# Generated at 2022-06-20 14:37:26.049803
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    my_err = GalaxyError(HTTPError, "This is an error")
    assert(my_err.http_code == 500)
    assert(my_err.url is None)



# Generated at 2022-06-20 14:37:34.785740
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    params = load_fixture('galaxy_api___lt____params.json')
    expected = load_fixture('galaxy_api___lt____expected.json')
    evars = json.loads(params[0])
    params = params[1:]
    expected = expected[0]
    for i in range(len(params)):
        param = json.loads(params[i])
        with patch.dict('os.environ', evars):
            ansible_galaxy.api.galaxy.GalaxyAPI.__lt__(param[0], param[1])
        assert json.dumps(param[0]) == expected[i]

# Generated at 2022-06-20 14:37:39.104511
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    test_url = "https://galaxy.ansible.com"
    api = GalaxyAPI(test_url)
    assert test_url == api.api_server


# Generated at 2022-06-20 14:37:46.231234
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    meta = CollectionVersionMetadata('my_namespace', 'my_name', '1.0', 'my_url', 'my_sha256', 'my_dependencies')
    assert meta.namespace == 'my_namespace'
    assert meta.name == 'my_name'
    assert meta.version == '1.0'
    assert meta.download_url == 'my_url'
    assert meta.artifact_sha256 == 'my_sha256'
    assert meta.dependencies == 'my_dependencies'



# Generated at 2022-06-20 14:37:51.162408
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI('https://galaxy.server.com', 'user', 'pass')
    obj = api.__str__()
    assert obj in (
        "GalaxyAPI({'url': 'https://galaxy.server.com', 'user': 'user', 'password': '********'})",
        "GalaxyAPI({'password': '********', 'url': 'https://galaxy.server.com', 'user': 'user'})",
    )


# Generated at 2022-06-20 14:37:56.882358
# Unit test for function get_cache_id
def test_get_cache_id():
    for url in [
        'https://ansible.example.com/',
        'https://ansible.example.com',
        'https://ansible.example.com:443',
        'https://user@ansible.example.com/',
        'https://user@ansible.example.com',
        'https://user@ansible.example.com:443',
    ]:
        assert get_cache_id(url) == 'ansible.example.com'



# Generated at 2022-06-20 14:38:38.813748
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    class TestGalaxyAPI(GalaxyAPI):

        def __init__(self, server, name, available_api_versions):
            super(TestGalaxyAPI, self).__init__(server, name, available_api_versions)

    # Test that GalaxyAPI('galaxy.example.com', None, ['v1']) < GalaxyAPI('galaxy.example.com', None, ['v1', 'v2', 'v3'])
    assert TestGalaxyAPI('galaxy.example.com', None, ['v1']) < TestGalaxyAPI('galaxy.example.com', None,
                                                                            ['v1', 'v2', 'v3'])
    # Test that GalaxyAPI('galaxy.example.com', None, ['v1', 'v2']) < GalaxyAPI('galaxy.example.com', None, ['

# Generated at 2022-06-20 14:38:41.652918
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI('http://galaxy.server/api')
    assert isinstance(api, object)
    assert str(api) == 'GalaxyAPI(galaxy_server="http://galaxy.server/api", name="", scp_if_ssh=True)'


# Generated at 2022-06-20 14:38:52.133433
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI()
    galaxy_api.name = 'name'
    galaxy_api.api_server = 'api_server'
    galaxy_api.url = 'url'
    galaxy_api.token = 'token'
    galaxy_api.ignore_certs = True
    galaxy_api.ignore_errors = True
    galaxy_api.timeout = 5
    galaxy_api.validate_certs = False
    galaxy_api.available_api_versions = ['v2', 'v3']
    galaxy_api.required_roles = ['foo', 'bar', 'baz']
    galaxy_api.required_collections = ['qux', 'quux']
    galaxy_api.required_galaxy_versions = ['1.0', '2.0', '3.0']
    galaxy_api.context = dict()

# Generated at 2022-06-20 14:38:57.641404
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error = GalaxyError(HTTPError("https://api.galaxy.ansible.com", 404, "404 URL does not exist", None, None),
                        'API does not exist')
    assert error.http_code == 404
    assert error.url == "https://api.galaxy.ansible.com"
    assert error.message == "API does not exist (HTTP Code: 404, Message: 404 URL does not exist)"



# Generated at 2022-06-20 14:39:01.670436
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # Execute the method under test
    result = GalaxyAPI('localhost://1234').__str__()

    # Check the result
    assert result == 'localhost://1234', "The result does not match the expected result"


# Generated at 2022-06-20 14:39:12.596388
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # cloud.redhat.com returns 520 (Cloudflare unknown error)
    assert is_rate_limit_exception(GalaxyError("Rate limit exceeded", http_code=520))
    # galaxy.ansible.com returns 429 (Too Many Requests)
    assert is_rate_limit_exception(GalaxyError("Rate limit exceeded", http_code=429))
    # galaxy.ansible.com may return 503 (Service Unavailable) temporarily
    assert is_rate_limit_exception(GalaxyError("Rate limit exceeded", http_code=503))
    # cloud.redhat.com returns 403 (Forbidden) due to expired token
    assert not is_rate_limit_exception(GalaxyError("Invalid token", http_code=403))



# Generated at 2022-06-20 14:39:23.570165
# Unit test for function get_cache_id
def test_get_cache_id():
    urls = ['https://galaxy.ansible.com/api/v1/', 'https://example.com/',
            'https://example.com:8080/', 'https://user:pass@example.com:8080/',
            'http://example.com/v1/', 'http://example.com:8080/v2/']
    expected_cache_ids = ['galaxy.ansible.com', 'example.com', 'example.com:8080',
                          'example.com:8080', 'example.com', 'example.com:8080']

    # Test a couple of invalid URLs
    urls.append('https://galaxy.ansible.com:8080/api/v1/')
    expected_cache_ids.append('galaxy.ansible.com:8080')


# Generated at 2022-06-20 14:39:25.176273
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))



# Generated at 2022-06-20 14:39:32.924529
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/') == 'galaxy.ansible.com'
    assert get_cache_id('https://foo:bar@galaxy.ansible.com/') == 'galaxy.ansible.com'



# Generated at 2022-06-20 14:39:39.493092
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI()
    assert repr(api) == '<GalaxyAPI>'
    api.name = 'test_name'
    api.api_server = 'test_api_server'
    assert repr(api) == "<GalaxyAPI test_name 'test_api_server'>"


# Generated at 2022-06-20 14:40:16.399327
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com/api/') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://foo:bar@galaxy.ansible.com:80/api/') == 'galaxy.ansible.com:80'



# Generated at 2022-06-20 14:40:24.750235
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    ''' Unit test GalaxyAPI object ''__unicode__'' method '''
    # Initialisation of a GalaxyAPI object
    test_galaxy_api = GalaxyAPI(api_server='https://galaxy.ansible.com',
                                name='test',
                                token='my_token',
                                start_at_task=None)
    try:
        assert test_galaxy_api.__unicode__() == '<GalaxyAPI server=https://galaxy.ansible.com name=test>'
    except AssertionError:
        display.error('GalaxyAPI object ''__unicode__'' method test assertion error !')
        raise AssertionError
    else:
        display.display('GalaxyAPI object ''__unicode__'' method test ok !')

# Generated at 2022-06-20 14:40:36.301025
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    from ansible.module_utils.common.collections import is_traversable
    error = GalaxyError('test', status_code=429)
    assert is_rate_limit_exception(error)
    for error_code in [200, 404, 500, 429, 520]:
        error = GalaxyError('test', status_code=error_code)
        assert is_rate_limit_exception(error) == (error_code in RETRY_HTTP_ERROR_CODES)
    # Test that false-positive rate limit exceptions are not returned
    error = GalaxyError('test')
    assert not is_rate_limit_exception(error)
    # Test that false-positive rate limit exceptions are not returned
    error = AnsibleError('test')
    assert not is_rate_limit_exception(error)



# Generated at 2022-06-20 14:40:38.840700
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    my_galaxy_api = GalaxyAPI()
    actual = repr(my_galaxy_api)
    assert actual == "<GalaxyAPI instance: not connected>"

# Generated at 2022-06-20 14:40:46.702239
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI()
    assert isinstance(galaxy_api, GalaxyAPI)

    galaxy_api.name = 'test'
    assert 'test' in str(galaxy_api)

    galaxy_api.api_server = 'https://galaxy.ansible.com/api/galaxy/'
    assert 'https://galaxy.ansible.com/api/galaxy/' in str(galaxy_api)

    galaxy_api.token = 'abc'
    assert 'abc' not in str(galaxy_api)

    galaxy_api.username = 'admin'
    assert 'admin' in str(galaxy_api)

    galaxy_api.username = 'testuser'
    assert 'testuser' in str(galaxy_api)


# Generated at 2022-06-20 14:40:54.093922
# Unit test for function get_cache_id
def test_get_cache_id():
    expected_cache_id = 'galaxy.ansible.com'
    url = 'https://galaxy.ansible.com'
    cache_id = get_cache_id(url)
    assert expected_cache_id == cache_id
    cache_id = get_cache_id(url + '/')
    assert expected_cache_id == cache_id
    url = 'https://galaxy.ansible.com:443'
    cache_id = get_cache_id(url)
    assert expected_cache_id == cache_id



# Generated at 2022-06-20 14:41:07.501375
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """This function does not actually test GalaxyAPI, but it does demonstrate how to use it."""

    # create a new GalaxyAPI object and get the list of available tags
    a = GalaxyAPI(galaxy='https://galaxy.ansible.com/', url='https://api.galaxy.ansible.com/')
    display.display(json.dumps(a.get_profile()))
    display.display(json.dumps(a.list_roles()))
    display.display(json.dumps(a.list_tags()))
    display.display(json.dumps(a.get_user('willtheb')['summary_fields']['roles']))

# Generated at 2022-06-20 14:41:15.611963
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    collection_version_metadata = CollectionVersionMetadata(namespace='namespace', name='name', version='version', download_url='download_url', artifact_sha256='artifact_sha256', dependencies='dependencies')
    assert collection_version_metadata.namespace == 'namespace'
    assert collection_version_metadata.name == 'name'
    assert collection_version_metadata.version == 'version'
    assert collection_version_metadata.download_url == 'download_url'
    assert collection_version_metadata.artifact_sha256 == 'artifact_sha256'
    assert collection_version_metadata.dependencies == 'dependencies'



# Generated at 2022-06-20 14:41:27.223750
# Unit test for function get_cache_id
def test_get_cache_id():
    """ Test for function get_cache_id """
    # Empty url
    assert get_cache_id('') == ''
    # HTTP url without port
    assert get_cache_id('http://galaxy.ansible.com/') == 'galaxy.ansible.com:'
    # HTTP url with port
    assert get_cache_id('http://galaxy.ansible.com:443/') == 'galaxy.ansible.com:443'
    # HTTPS url without port
    assert get_cache_id('https://galaxy.ansible.com/') == 'galaxy.ansible.com:'
    # HTTPS url with port
    assert get_cache_id('https://galaxy.ansible.com:443/') == 'galaxy.ansible.com:443'
    # HTTP url with username and password
    assert get_

# Generated at 2022-06-20 14:41:34.671142
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'n'
    name = 'name'
    version = 'v'
    download_url = 'url'
    artifact_sha256 = hashlib.sha256(b'artifact').hexdigest()
    dependencies = '{}'
    obj = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert obj.namespace == namespace
    assert obj.name == name
    assert obj.version == version
    assert obj.download_url == download_url
    assert obj.artifact_sha256 == artifact_sha256
    assert obj.dependencies == dependencies



# Generated at 2022-06-20 14:42:47.231579
# Unit test for function g_connect
def test_g_connect():
    # TODO: Add tests
    pass
#


# Generated at 2022-06-20 14:42:57.483536
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import requests
    from ansible.module_utils.six.moves import http_client as httplib
    from ansible.module_utils._text import to_text
    http_connection = httplib.HTTPSConnection('galaxy.ansible.com')
    http_connection.request('GET', '/api/v2/collections/test/test/test')
    response = http_connection.getresponse()
    err = requests.HTTPError(url='test', response=response)
    error = GalaxyError(err, 'test error')
    assert isinstance(error, GalaxyError)

# Unit tests for to_native()

# Generated at 2022-06-20 14:43:03.793404
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api = GalaxyAPI()
    assert not api.__lt__('foo')
    assert not api.__lt__(None)
    assert api.__lt__(GalaxyAPI('galaxy-api-url', 'galaxy-api-name'))
    assert not api.__lt__(GalaxyAPI(api_server='galaxy-api-url', name='galaxy-api-name'))
    assert not api.__lt__(api)



# Generated at 2022-06-20 14:43:06.484336
# Unit test for function g_connect
def test_g_connect():
    versions = ["a", "b", "c"]
    assert(g_connect(versions))



# Generated at 2022-06-20 14:43:16.130387
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    server = 'galaxy.ansible.com'
    api_server = 'https://' + server
    api_key = 'some_key'
    ignore_certs = False
    ignore_errors = False
    timeout = 10
    galaxy = GalaxyAPI(server, api_key, ignore_certs, ignore_errors, timeout, api_server)

    assert galaxy.name == server
    assert galaxy.api_key == api_key
    assert galaxy.ignore_certs == ignore_certs
    assert galaxy.ignore_errors == ignore_errors
    assert galaxy.timeout == timeout
    assert galaxy.api_server == api_server



# Generated at 2022-06-20 14:43:19.325049
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    a = 'test'
    b = 'test'
    c = 'test'
    d = 'test'
    e = 'test'
    f = 'test'
    CollectionVersionMetadata(a,b,c,d,e,f)



# Generated at 2022-06-20 14:43:29.761084
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class FakeGalaxyError(GalaxyError):
        def __init__(self, http_code):
            self.http_code = http_code
    assert is_rate_limit_exception(FakeGalaxyError(429))
    assert is_rate_limit_exception(FakeGalaxyError(520))
    assert not is_rate_limit_exception(FakeGalaxyError(404))
    assert not is_rate_limit_exception(FakeGalaxyError(403))



# Generated at 2022-06-20 14:43:33.297309
# Unit test for function cache_lock
def test_cache_lock():
    lock = threading.Lock()

    @cache_lock
    def wrapped_function(args, kwargs):
        with lock:
            return None

    assert wrapped_function.__lock_applied__ is True



# Generated at 2022-06-20 14:43:36.351908
# Unit test for function g_connect
def test_g_connect():
    versions = ['v1', 'v2']
    def method():
        return versions
    method_decorator = g_connect(method)
    return method_decorator
print(test_g_connect())


# Generated at 2022-06-20 14:43:45.927927
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    a = CollectionVersionMetadata('a', 'b', 'c', 'd', 'e', 'f')
    assert(a.namespace == 'a')
    assert(a.name == 'b')
    assert(a.version == 'c')
    assert(a.download_url == 'd')
    assert(a.artifact_sha256 == 'e')
    assert(a.dependencies == 'f')



# Generated at 2022-06-20 14:45:03.323341
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    meta = CollectionVersionMetadata("namespace", "name", "version", "download_url", "artifact_sha256", {'dependency': '1.0.0'})
    assert meta.namespace == "namespace"
    assert meta.name == "name"
    assert meta.version == "version"
    assert meta.download_url == "download_url"
    assert meta.artifact_sha256 == "artifact_sha256"
    assert meta.dependencies == {'dependency': '1.0.0'}


# Generated at 2022-06-20 14:45:06.398143
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    from ansible.galaxy.api.errors import GalaxyError
    assert is_rate_limit_exception(GalaxyError(http_code=429, http_message='Too Many Requests'))



# Generated at 2022-06-20 14:45:09.175776
# Unit test for function g_connect
def test_g_connect():
    method = g_connect([u'v1'])
    def wrapped():
        return 123
    assert method(wrapped)() == 123



# Generated at 2022-06-20 14:45:10.852432
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        return True
    test_func()
    return True



# Generated at 2022-06-20 14:45:18.405382
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError('http://localhost:8888/v1', 400, 'Bad Request', {}, None)
    message = 'a test message'
    ge = GalaxyError(http_error, message)
    assert ge.message == 'a test message (HTTP Code: 400, Message: Bad Request)'


# Generated at 2022-06-20 14:45:27.190435
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    url = 'http://galaxy.server'
    api_key = 'ANSIBLE_GALAXY_KEY'
    name = 'galaxy.server'
    use_api_key = True
    ignore_certs = False
    timeout = 10
    galaxy_api = GalaxyAPI(url, api_key, name, use_api_key, ignore_certs, timeout)
    expected = 'GalaxyAPI(%s)' % name
    assert str(galaxy_api) == expected


# Generated at 2022-06-20 14:45:35.664974
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    meta = CollectionMetadata('awesomeness', 'amazing', '2019-05-29T17:27:52.690697Z', '2019-05-30T17:27:52.690697Z')
    assert meta.namespace == 'awesomeness'
    assert meta.name == 'amazing'
    assert meta.created_at == "2019-05-29T17:27:52.690697Z"
    assert meta.updated_at == "2019-05-30T17:27:52.690697Z"


# Generated at 2022-06-20 14:45:43.951223
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'
    assert get_cache_id('http://example.org') == 'example.org:'
    assert get_cache_id('http://example.org:80') == 'example.org:80'
    assert get_cache_id('http://user:pass@example.org:80') == 'example.org:80'



# Generated at 2022-06-20 14:45:50.013796
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class GalaxyError(Exception):
        def __init__(self, status_code):
            self.http_code = status_code

    assert is_rate_limit_exception(GalaxyError(429))
    assert is_rate_limit_exception(GalaxyError(520))
    assert is_rate_limit_exception(GalaxyError(404)) is False



# Generated at 2022-06-20 14:45:55.292507
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    v = CollectionMetadata('namespace', 'name', 'created', 'modified')
    assert v.namespace == 'namespace'
    assert v.name == 'name'
    assert v.created_str == 'created'
    assert v.modified_str == 'modified'

