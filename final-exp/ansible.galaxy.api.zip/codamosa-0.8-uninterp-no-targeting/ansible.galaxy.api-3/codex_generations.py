

# Generated at 2022-06-20 14:37:03.137574
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = "TestNamespace"
    name = "TestName"
    version = "1.0"
    download_url = "https://galaxy.ansible.com/api/v2/collections/TestNamespace/TestName/versions/1.0/content/"
    artifact_sha256 = "TestSha256"
    dependencies = {}

    collection_version_metadata = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)

    assert collection_version_metadata.namespace == namespace
    assert collection_version_metadata.name == name
    assert collection_version_metadata.version == version
    assert collection_version_metadata.download_url == download_url
    assert collection_version_metadata.artifact_sha256 == artifact_sha256
    assert collection_version_metadata.dependencies == {}

# Generated at 2022-06-20 14:37:07.967225
# Unit test for function g_connect
def test_g_connect():
    global _available_api_versions
    _available_api_versions = {'v1':'v1/'}
    @g_connect(['v1'])
    def test(self):
        return [self.api_server,self._available_api_versions]

    obj = GalaxyAPI('galaxy.com','token')

    # print(test(obj))
    assert test(obj) == ['galaxy.com', {'v1': 'v1/'}]

# Unittest for function _call_galaxy

# Generated at 2022-06-20 14:37:15.320408
# Unit test for function cache_lock
def test_cache_lock():
    def fake_func(*args, **kwargs):
        return args, kwargs
    wrapped = cache_lock(fake_func)
    fake_args = (1, 2, 3)
    fake_kwargs = dict(a=4, b=5, c="foo")
    try:
        # Test lock prevents more than one simultaneous access
        with _CACHE_LOCK:
            with display.unquiet():
                wrapped(*fake_args, **fake_kwargs)
    except AssertionError:
        pass
    else:
        raise Exception("_CACHE_LOCK failed to prevent simultaneous access")
    # Test lock is released
    wrapped(*fake_args, **fake_kwargs)



# Generated at 2022-06-20 14:37:29.167352
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    from ansible.galaxy import GalaxyError
    # Known rate limit error code
    is_rate_exception = is_rate_limit_exception(GalaxyError("Testing error msg.", 520))
    assert is_rate_exception
    # "Unknown" error code
    is_rate_exception = is_rate_limit_exception(GalaxyError("Testing error msg.", 403))
    assert not is_rate_exception
    # Non-Galaxy exception
    is_rate_exception = is_rate_limit_exception(HTTPError("Testing error msg.", 520, None, None, None))
    assert not is_rate_exception



# Generated at 2022-06-20 14:37:40.041284
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_code = 403
    url = "https://galaxy.ansible.com/api/v1/user/roles"
    message = to_text(
        "Galaxy response contains error [{'default': 'Could not retrieve user information from Ansible galaxy', "
        "'code': 403}], response was 403 Forbidden. Are you logged in?"
    )
    galaxy_error = GalaxyError(http_code, message)
    assert galaxy_error.message == "Galaxy response contains error [{'default': 'Could not retrieve user information " \
                                   "from Ansible galaxy', 'code': 403}], response was 403 Forbidden. Are you logged in? (HTTP Code: 403, Message: Could not retrieve user information from Ansible galaxy Code: 403)"

    galaxy_error = GalaxyError(url, message)

# Generated at 2022-06-20 14:37:41.980673
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def fun_cache_lock(args):
        return args
    assert fun_cache_lock('cache_lock') == 'cache_lock'


# Generated at 2022-06-20 14:37:53.182400
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    dependencies = {'f5devcentral.f5_modules': '*'}
    collection_version_metadata = CollectionVersionMetadata('f5networks', 'f5_modules', '0.3.3',
                                                            'https://galaxy.ansible.com/api/v2/collections/f5networks/f5_modules/0.3.3/',
                                                            'a3f6a0f6cafbfd8e4b977a7a29b6c4b7f8cc6e68b7cf1f2f523c7ab8352781d7',
                                                            dependencies)
    assert collection_version_metadata.name == 'f5_modules'



# Generated at 2022-06-20 14:38:03.025551
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.galaxy import GalaxyAPI
    from unit.compat.mock import patch
    from ansible.errors import AnsibleError

    # __lt__() takes two arguments: self and other

    # Patch __lt__() to run our own code
    with patch.object(GalaxyAPI, '__lt__', lambda x, y: x.name < y.name):

        # Test first argument(self.name) < second argument(other.name) - True
        galaxy_api1 = GalaxyAPI('galaxy_name')
        galaxy_api2 = GalaxyAPI('galaxy_name_1')

        assert (galaxy_api1 < galaxy_api2) is True

        # Test first argument(self.name) < second argument(other.name) - False
        galaxy_api1 = GalaxyAPI('galaxy_name')
        galaxy_

# Generated at 2022-06-20 14:38:15.098897
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.galaxy.api import _GalaxyAPI

    galaxy_api1 = _GalaxyAPI('my-galaxy', [], 'http://galaxy.galaxy')
    galaxy_api2 = _GalaxyAPI('my-galaxy', ['v2'], 'http://galaxy.galaxy')
    assert galaxy_api1 < galaxy_api2

    galaxy_api1 = _GalaxyAPI('my-galaxy', ['v3'], 'http://galaxy.galaxy')
    galaxy_api2 = _GalaxyAPI('my-galaxy', ['v2'], 'http://galaxy.galaxy')
    assert galaxy_api1 < galaxy_api2

    galaxy_api1 = _GalaxyAPI('my-galaxy1', ['v3'], 'http://galaxy.galaxy')
    galaxy_api2 = _

# Generated at 2022-06-20 14:38:23.459522
# Unit test for function cache_lock
def test_cache_lock():
    state = {'x': 1}
    lock = threading.Lock()
    # Use threading to test concurrency
    def function(state):
        with lock:
            state['x'] *= 2
            time.sleep(3)

    threads = [threading.Thread(target=function, args=(state,)) for _ in range(2)]
    [thread.start() for thread in threads]
    [thread.join() for thread in threads]

    assert state == {'x': 4}
test_cache_lock()



# Generated at 2022-06-20 14:38:59.059936
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    test_url = 'https://galaxy.ansible.com'
    test_token = 'something'
    api = GalaxyAPI(test_url, test_token)

    expected = "GalaxyAPI (galaxy.ansible.com) [{0}]".format(test_token[
                                                           :10])
    assert(expected == api.__repr__())


# Generated at 2022-06-20 14:39:11.270259
# Unit test for function cache_lock
def test_cache_lock():
    class RetryException(Exception):
        pass

    class DummyRequest():
        def __init__(self, headers=None, data=None):
            if not headers:
                headers = {}
            headers['User-Agent'] = user_agent()
            self.headers = headers
            self.data = data

    class DummyFunc():
        def __init__(self):
            self.headers = {}
            self.data = {}
            self.got_lock = False
            self.call_count = 0
            self.retry_count = 0

        def __call__(self, *args, **kwargs):
            if kwargs.get('headers'):
                self.headers.update(kwargs.get('headers'))

# Generated at 2022-06-20 14:39:19.411449
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    # Building GalaxyAPI object
    server = u'https://galaxy.ansible.com'
    api_key = u'public'
    _GalaxyAPI = models.GalaxyAPI(server, api_key)
    # Call __unicode__ method
    return_val = _GalaxyAPI.__unicode__()
    # Tests
    assert return_val == u'Galaxy at https://galaxy.ansible.com, using API: public'

# Generated at 2022-06-20 14:39:22.600992
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI(from_cache=False )
    expected = "GalaxyAPI(from_cache=False)"
    result = galaxy_api.__repr__()
    assert result == expected



# Generated at 2022-06-20 14:39:31.137424
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    g1 = GalaxyAPI('ansible', 'https://galaxy.ansible.com', ['v2'])
    g2 = GalaxyAPI('ansible', 'https://galaxy.ansible.com', ['v2', 'v3'])
    g3 = GalaxyAPI('ans1', 'https://galaxy.ansible.com', ['v2'])
    g4 = GalaxyAPI('ans1', 'https://galaxy.com', ['v2'])
    g5 = GalaxyAPI('ans1', 'https://galaxy.com', ['v3'])

    assert (g1 < g2) is False
    assert (g2 < g1) is True
    assert (g1 < g3) is False
    assert (g3 < g1) is True
    assert (g3 < g4) is False

# Generated at 2022-06-20 14:39:39.323707
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=500))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(Exception())



# Generated at 2022-06-20 14:39:45.489097
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('https://galaxy.ansible.com:8080/') == 'galaxy.ansible.com:8080'
    assert get_cache_id('https://http_user:secret@galaxy.ansible.com') == 'galaxy.ansible.com'
    assert get_cache_id('https://http_user:secret@galaxy.ansible.com:8080') == 'galaxy.ansible.com:8080'


# Generated at 2022-06-20 14:39:54.647584
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():

    # Tests __init__
    data = {
        'namespace': 'namespace',
        'name': 'name',
        'created_str': '2020-07-31T19:07:50.295408Z',
        'modified_str': '2020-08-06T20:55:00.708833Z',
    }
    metadata = CollectionMetadata(**data)

    for key in data:
        assert getattr(metadata, key) == data[key]

# Generated at 2022-06-20 14:40:01.089362
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """
    Test GalaxyAPI class constructor.
    """
    api_server = 'https://galaxy.ansible.com'
    token = 'SomeToken'
    ignore_certs = True
    api = GalaxyAPI(api_server, token, ignore_certs=ignore_certs)

    assert api.api_server == api_server
    assert api.token == token
    assert api.ignore_certs == ignore_certs


# Generated at 2022-06-20 14:40:15.183800
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import requests
    base_url = "https://api.example.com"

    # Test code not in v2 or v3.
    http_error = requests.exceptions.HTTPError()
    http_error.code = 400
    galaxy_error = GalaxyError(http_error, "Test error for v1.")
    assert galaxy_error.http_code == 400
    assert galaxy_error.message == "Test error for v1. (HTTP Code: 400, Message: )"
    http_error.code = 401
    http_error.reason = "Failed authentication."
    galaxy_error = GalaxyError(http_error, "Failed auth.")
    assert galaxy_error.message == "Failed auth. (HTTP Code: 401, Message: Failed authentication.)"

# Generated at 2022-06-20 14:41:03.108721
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = HTTPError(url="http://example.com", code=400, msg="test_galaxy_error", hdrs=None, fp=None)
    message = "test_message"
    with pytest.raises(GalaxyError) as error:
        raise GalaxyError(http_error, message)
    assert "test_message" in error.value.message
    assert error.value.http_code == 400
    assert error.value.url == "http://example.com"



# Generated at 2022-06-20 14:41:10.227602
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    """ This is unit test for class GalaxyError """
    fake_http_error = HTTPError('fake url', 401, method='GET')
    fake_http_error.read = lambda: to_bytes(json.dumps({'message': '401: Not authenticated'}))

    galaxy_error_obj = GalaxyError(fake_http_error, 'fake message')
    assert '401: Not authenticated' in galaxy_error_obj.message



# Generated at 2022-06-20 14:41:24.486258
# Unit test for function get_cache_id
def test_get_cache_id():
    def _assert(expected, input):
        assert expected == get_cache_id(input)

    _assert('www.ansible.com', 'https://www.ansible.com')
    _assert('www.ansible.com', 'http://www.ansible.com')
    _assert('www.ansible.com:8080', 'http://www.ansible.com:8080')
    _assert('www.ansible.com', 'https://www.ansible.com/')
    _assert('www.ansible.com', 'https://www.ansible.com/api')
    _assert('www.ansible.com', 'https://www.ansible.com/api/')
    _assert('www.ansible.com', 'https://www.ansible.com/api/v1')

# Generated at 2022-06-20 14:41:25.396428
# Unit test for function g_connect
def test_g_connect():
    return 'function g_connect'





# Generated at 2022-06-20 14:41:35.692781
# Unit test for function g_connect
def test_g_connect():
    def g_test(name, api_server, **kwargs):
        request = collections.namedtuple('request', 'url')
        r = request(url=api_server)
        response = collections.namedtuple('response', 'request')
        v1 = collections.namedtuple('v1', 'slug')
        available_versions = {u'v1': v1(slug=u'v1')}

        d = {'_available_api_versions': available_versions,
             'request': r, 'response': response, 'name': name, 'api_server': api_server, '_call_galaxy': None}
        d.update(**kwargs)

        obj = collections.namedtuple('TestClass', ' '.join(d.keys()))
        test_obj = obj(**d)


# Generated at 2022-06-20 14:41:48.972654
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    apis = [
        GalaxyAPI(
            'foo',
            'https://cloud.example/api/v2',
            available_api_versions={'v2': '/v2/', 'v3': '/v3/'},
            auth_token='',
            ignore_certs=False,
            ignore_errors=False,
        ),
        GalaxyAPI(
            'bar',
            'https://cloud.example/api/v3',
            available_api_versions={'v2': '/v2/', 'v3': '/v3/'},
            auth_token='',
            ignore_certs=False,
            ignore_errors=False,
        ),
    ]
    # The second GalaxyAPI has a greater version of the API.
    assert apis[0].__lt__(apis[1]) is True



# Generated at 2022-06-20 14:41:54.441434
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy_api = GalaxyAPI(None)
    assert galaxy_api < GalaxyAPI(None)

# Generated at 2022-06-20 14:42:03.443927
# Unit test for function get_cache_id
def test_get_cache_id():
    # Default port
    assert get_cache_id('http://example.org') == 'example.org:80'

    # Custom port
    assert get_cache_id('http://example.org:8080') == 'example.org:8080'

    # Default port, credentials in URL
    assert get_cache_id('http://user:pass@example.org') == 'example.org:80'

    # Custom port, credentials in URL
    assert get_cache_id('http://user:pass@example.org:8080') == 'example.org:8080'



# Generated at 2022-06-20 14:42:14.057930
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # call the constructor of class GalaxyError
    test_error = GalaxyError(HTTPError('test_http_error', 200, 'test_reason', 'test_body', 'test_url'), 'test_message')

    # get the attributes of test_error
    test_message = test_error.message
    test_http_code = test_error.http_code
    test_url = test_error.url

    # check the attributes
    assert test_message == 'test_message (HTTP Code: 200, Message: test_reason)', \
        'The constructor of class GalaxyError did not behave expectedly'
    assert test_http_code == 200, \
        'The constructor of class GalaxyError did not behave expectedly'
    assert test_url == 'test_url', \
        'The constructor of class GalaxyError did not behave expectedly'



# Generated at 2022-06-20 14:42:23.588597
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    name_galaxy_api = u"galaxy_api"
    api_server_galaxy_api = u"api_server_galaxy_api"
    available_api_versions_galaxy_api = u"v2"
    galaxy_api = GalaxyAPI(name_galaxy_api, api_server_galaxy_api, available_api_versions_galaxy_api)
    name_galaxy_api_repr = u"GalaxyAPI(api_server='api_server_galaxy_api', name='galaxy_api', version=v2)"
    assert repr(galaxy_api) == name_galaxy_api_repr


# Generated at 2022-06-20 14:43:02.218478
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = "testNamespace"
    name = "testName"
    version = "1.0.0"
    download_url = "testDownloadUrl"
    artifact_sha256 = "testArtifactSha256"
    dependencies = "testDependencies"

    collection_version_metadata = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert collection_version_metadata.namespace == namespace
    assert collection_version_metadata.name == name
    assert collection_version_metadata.version == version
    assert collection_version_metadata.download_url == download_url
    assert collection_version_metadata.artifact_sha256 == artifact_sha256
    assert collection_version_metadata.dependencies == dependencies



# Generated at 2022-06-20 14:43:13.121252
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    versionMetadata = CollectionVersionMetadata(namespace = "galaxy_namespace", name = "galaxy_name",
                                version = "1.0.0", download_url = "http://fake_url.com",
                                artifact_sha256 = "fake_sha",
                                dependencies = {"fake_dep": "1.0.0"})
    assert versionMetadata.namespace == "galaxy_namespace"
    assert versionMetadata.name == "galaxy_name"
    assert versionMetadata.version == "1.0.0"
    assert versionMetadata.download_url == "http://fake_url.com"
    assert versionMetadata.artifact_sha256 == "fake_sha"
    assert versionMetadata.dependencies == {"fake_dep": "1.0.0"}


# Generated at 2022-06-20 14:43:13.799021
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    assert True


# Generated at 2022-06-20 14:43:22.917843
# Unit test for function get_cache_id
def test_get_cache_id():
    from ansible.module_utils.basic import AnsibleModule

    def assert_cache_id(url, expected, expected_failed=False):
        """
        Asserts that get_cache_id(url) == expected. If expected_failed is True, the function should always raise an
        exception.
        """
        try:
            # It's a little odd to call this a second time, but we need to make sure the cache is properly cleared
            # to ensure we're not just testing the cache itself.
            assert get_cache_id(url) == expected
        except:
            if not expected_failed:
                raise

    # Test as a function
    assert_cache_id('https://my.server.com', 'my.server.com:443')

# Generated at 2022-06-20 14:43:30.104048
# Unit test for function g_connect
def test_g_connect():
    versions = ['v1', 'v2', 'v3']

    import unittest
    class MyTestCase(unittest.TestCase):
        def runTest(self):
            self.assertEqual(1, 1)

            @g_connect(versions)
            def foo():
                pass

            foo()
    # import unittest
    # unittest.main(argv=[''], exit=False)



# Generated at 2022-06-20 14:43:34.155145
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI('https://galaxy.example.org', 'foo', 'bar')
    assert repr(galaxy_api) == "GalaxyAPI('https://galaxy.example.org', 'foo', 'bar')"

# Generated at 2022-06-20 14:43:41.825737
# Unit test for function cache_lock
def test_cache_lock():
    # Note: Function cache_lock is tested in unit test galaxy.api
    # to prevent locking issues

    # Basic test to validate the lock works
    lock = threading.Lock()
    lock_value = []
    def should_lock(value):
        """
        This function should be run by multiple threads
        that will produce a list by appending a value
        to the list lock_value.
        """
        with lock:
            lock_value.append(value)

    threads = []
    # Create a thread per value to be added to list
    for i in range(0, 5):
        threads.append(threading.Thread(target=should_lock, args=(i,)))

    # Start the threads
    for thread in threads:
        thread.start()

    # Wait until all threads are completed
    for thread in threads:
        thread

# Generated at 2022-06-20 14:43:49.451818
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    test_values = dict(
        namespace='mazer_test_owner',
        name='test_collection',
        created_str='test_created_at',
        modified_str='test_modified_at',
    )
    test_collection_metadata = CollectionMetadata(**test_values)
    for attrib in test_values.keys():
        test_value = getattr(test_collection_metadata, attrib)
        assert test_value == test_values[attrib]



# Generated at 2022-06-20 14:43:58.088059
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api_server = 'https://galaxy.server.com'
    name = u'test_GalaxyAPI'
    api = GalaxyAPI(api_server, name)
    assert isinstance(repr(api), text_type)
    assert isinstance(str(api), text_type)
    assert isinstance(six.text_type(api), text_type)
    assert to_text(api) == six.text_type(api) == "GalaxyAPI '%s' at %s" % (name, api_server)
    assert to_text(api, nonstring='passthru') == six.text_type(api) == "GalaxyAPI '%s' at %s" % (name, api_server)

# Generated at 2022-06-20 14:44:06.368107
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Ensure that GalaxyAPI class compares correctly for different types of Galaxy server URLs.
    #
    # :param api_server: The URL of the Galaxy server.
    # :param name: The human-friendly name of the Galaxy server (e.g. Automation Hub).
    # :param token: An API token to use to authenticate with the server.
    # :param verify_ssl: Whether or not to verify the SSL cert of the Galaxy server.
    # :param proxy_url: Optional URL to proxy through.
    # :param proxy_cacert: Optional CA cert to use to validate the proxy.
    # :param client_cert: Optional SSL client cert to send to the Galaxy server.
    # :param client_key: Optional SSL client key to send to the Galaxy server.

    api_server = "http://galaxy.ansible.com"

# Generated at 2022-06-20 14:45:05.372433
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI('https://galaxy.ansible.com')
    utc_now = datetime.now(timezone.utc)
    api.last_sync = utc_now.replace(microsecond=0)
    assert unicode(api) == "GalaxyAPI(https://galaxy.ansible.com, last_sync=%s)" % utc_now.isoformat()



# Generated at 2022-06-20 14:45:13.390305
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection_metadata = CollectionMetadata('namespace', 'name', 'version')

    assert (collection_metadata.namespace == 'namespace')
    assert (collection_metadata.name == 'name')
    assert (collection_metadata.version is None)

    # Test the defaults
    assert (collection_metadata.download_url is None)
    assert (collection_metadata.artifact is None)
    assert (collection_metadata.dependencies == [])
    assert (collection_metadata.created_str is None)
    assert (collection_metadata.modified_str is None)


# Generated at 2022-06-20 14:45:16.792205
# Unit test for function g_connect
def test_g_connect():
    @g_connect(versions=[u'v1'])
    def test_g_connect(self):
        pass
    test_g_connect()


# Generated at 2022-06-20 14:45:20.830587
# Unit test for function get_cache_id
def test_get_cache_id():
    class MockArgs():
        api_server = 'https://galaxy.ansible.com'
        ignore_certs = False

    g = Galaxy(MockArgs())
    assert g._cache_id == 'galaxy.ansible.com'



# Generated at 2022-06-20 14:45:30.983131
# Unit test for function cache_lock
def test_cache_lock():
    global funcCalled
    funcCalled = 0
    def test_func(args, kwargs, *args, **kwargs):
        global funcCalled
        assert funcCalled == 0
        funcCalled = 1
        assert args == 1
        assert kwargs == { 'a': 1, 'b': 2, 'c': 3 }
    func = cache_lock(test_func)
    func(1, { 'a': 1, 'b': 2, 'c': 3 })
    assert funcCalled == 1
    funcCalled = 0
# End unit test for function cache_lock



# Generated at 2022-06-20 14:45:38.398678
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://galaxy-test.example.com') == 'galaxy-test.example.com:'
    assert get_cache_id('http://galaxy-test.example.com:8080') == 'galaxy-test.example.com:8080'
    assert get_cache_id('http://user:password@galaxy-test.example.com') == 'galaxy-test.example.com:'
    assert get_cache_id('http://user:password@galaxy-test.example.com:8080') == 'galaxy-test.example.com:8080'



# Generated at 2022-06-20 14:45:48.171319
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    message = 'Could not add content'
    http_code = 400
    galaxy_msg = 'galaxy message'
    galaxy_code = 400

    http_error = FakeHttpError()
    http_error.reason = galaxy_msg
    http_error.code = http_code

    error = GalaxyError(http_error, message)
    assert error.http_code == http_code
    assert error.url == ""
    assert error.message == "%s (HTTP Code: %d, Message: %s Code: %s)" % (message, http_code, galaxy_msg, galaxy_code)

# Fake class to test GalaxyError class

# Generated at 2022-06-20 14:45:55.483322
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api_server = "https://galaxy.ansible.com"
    galaxy_api = GalaxyAPI(api_server)

    # run the test
    result = galaxy_api.__unicode__()
    assert result == "GalaxyAPI https://galaxy.ansible.com"

# Generated at 2022-06-20 14:46:04.702999
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    e1 = GalaxyError("hello", http_code=403)
    assert not is_rate_limit_exception(e1)

    e2 = GalaxyError("hello", http_code=429)
    assert is_rate_limit_exception(e2)

    e3 = GalaxyError("hello", http_code=520)
    assert is_rate_limit_exception(e3)

    e4 = Exception("hello")
    assert not is_rate_limit_exception(e4)


# TODO: replace this with a more robust jwt module

# Generated at 2022-06-20 14:46:10.522122
# Unit test for function g_connect
def test_g_connect():
    x = GalaxyAPI()
    assert hasattr(x, '_available_api_versions') == False
    x.name = 'test'
    x.api_server = 'https://galaxy.ansible.com/'
    x._call_galaxy = lambda x, method=None, data=None, jsonify=False, error_context_msg='', cache=False: {u'available_versions': {u'v1': u'v1/'}}
    r = x._fetch_page_v1_collection(collection_name='collection', namespace='namespace', owner='owner')
    assert hasattr(x, '_available_api_versions') == True
    assert len(x._available_api_versions) == 2
    assert u'v1' in x._available_api_versions
    assert u'v2' in x