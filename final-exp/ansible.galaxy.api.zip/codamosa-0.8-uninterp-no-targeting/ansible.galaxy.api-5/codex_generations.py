

# Generated at 2022-06-20 14:37:09.620335
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    message = "This is a test"
    http_code = 200
    url = 'https://api.galaxy.ansible.com/v2'
    err_msg = u'%s (HTTP Code: %d, Message: %s Code: %s)' % (message, http_code, 'Unknown', 'Unknown')
    http_error = HTTPError(url, http_code, message, {}, None)
    error = GalaxyError(http_error, message)
    assert error.message == err_msg



# Generated at 2022-06-20 14:37:17.907454
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    instance = GalaxyAPI(name='galaxy.example.com', api_server='https://galaxy.example.com', ignore_certs=True)
    expected = "Galaxy API for galaxy.example.com"
    actual = instance.__unicode__()
    assert expected == actual, "GalaxyAPI.__unicode__() returned '%s' instead of '%s'" % (actual, expected)

# Generated at 2022-06-20 14:37:26.884651
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api = GalaxyAPI(api_server='galaxy_api', name='galaxy_name', available_api_versions=['v2', 'v3'],
                    default_api_version='v3')
    other_api = GalaxyAPI(api_server='another_galaxy_api', name='another_galaxy_name', available_api_versions=['v2'],
                         default_api_version='v2')

    assert api < other_api
    

# Generated at 2022-06-20 14:37:32.103311
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy = GalaxyAPI('https://localhost:8443', 'v2', 'authorization_token')
    assert str(galaxy) == 'GalaxyAPI(https://localhost:8443, versions=[v2])'

# Generated at 2022-06-20 14:37:33.355500
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    pass


# Generated at 2022-06-20 14:37:36.194892
# Unit test for function cache_lock
def test_cache_lock():
    """Test cache_lock decorator."""
    @cache_lock
    def test_func(value):
        return value

    assert test_func(0) == 0



# Generated at 2022-06-20 14:37:41.707893
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    url = 'https://galaxy.ansible.com'
    galaxy_api = GalaxyAPI(url)
    assert galaxy_api.api_server == url
    assert galaxy_api.name == 'galaxy.ansible.com'
    assert not galaxy_api.token
    assert galaxy_api.cache is None
    assert galaxy_api.cache_path is None
    assert not galaxy_api._cache
    assert not galaxy_api.options
    assert not galaxy_api.available_api_versions

    galaxy_api = GalaxyAPI(url, token='test_api_token', force_basic_auth=True)
    assert galaxy_api.api_server == url
    assert galaxy_api.name == 'galaxy.ansible.com'
    assert galaxy_api.token == 'test_api_token'

# Generated at 2022-06-20 14:37:44.377273
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    assert_raises(AssertionError, CollectionMetadata, None, 'test_collection_name')
    assert_raises(AssertionError, CollectionMetadata, 'test_namespace', None)
    assert_raises(AssertionError, CollectionMetadata, 'test_namespace', 'test_collection_name')


# Generated at 2022-06-20 14:37:55.508764
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    instance = GalaxyError(HTTPError(url="http://www.example.com", code=403, msg="simulate HTTPError", hdrs={}, fp=None), message="message")
    assert instance.http_code == 403
    assert instance.url == "http://www.example.com"
    assert instance.message == "message (HTTP Code: 403, Message: simulate HTTPError)"

    class Dummy():
        def __init__(self):
            self.code = 403
            self.url = "http://www.example.com"
            self.reason = "simulate HTTPError"
        def read(self):
            return """{"default":"default value"}"""

    instance = GalaxyError(Dummy(), message="message")
    assert isinstance(instance, GalaxyError)
    assert instance.http_code == 403
    assert instance.url

# Generated at 2022-06-20 14:38:00.206832
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    kwargs = {
        'namespace': 'ns',
        'name': 'name',
        'created_str': 'created1',
        'modified_str': 'modified1',
    }
    collection_metadata = CollectionMetadata(**kwargs)

    assert collection_metadata.namespace == 'ns'
    assert collection_metadata.name == 'name'
    assert collection_metadata.created_str == 'created1'
    assert collection_metadata.modified_str == 'modified1'

# Generated at 2022-06-20 14:39:09.554565
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    response = False
    try:
        g1 = GalaxyAPI(api_server='https://galaxy.ansible.com/api')
        response = g1 < g1
    except:
        pass
    assert response == False


# Generated at 2022-06-20 14:39:12.872617
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    namespace = 'test'
    name = 'test'
    if CollectionMetadata(namespace, name) is not None:
        msg = "test_CollectionMetadata() FAILED"
        raise AssertionError(msg)



# Generated at 2022-06-20 14:39:16.571332
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    fixture_path = os.path.join(fixture_data_path, 'galaxy', 'GalaxyAPI')
    g1 = GalaxyAPI('api1', 'https://api1.com', {})
    g2 = GalaxyAPI('api1', 'https://api1.com', {})
    # Test on same objects
    assert g1 < g2 == False
    # Test on different objects
    g2 = GalaxyAPI('api2', 'https://api2.com', {})
    assert g1 < g2 == True



# Generated at 2022-06-20 14:39:25.890635
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    from ansible.module_utils.api import GalaxyError
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))



# Generated at 2022-06-20 14:39:29.952605
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy = GalaxyAPI(name='foo', api_server='foo.com', token='12345')
    assert repr(galaxy) == 'GalaxyAPI(name=foo, api_server=foo.com)'



# Generated at 2022-06-20 14:39:42.121006
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    collection_version_metadata = CollectionVersionMetadata('conan', 'perl', '1.0.0', 'localhost', 'hash',
                                                            {'namespace': 'name', 'version': '1.0.0'})
    assert collection_version_metadata.namespace == 'conan'
    assert collection_version_metadata.name == 'perl'
    assert collection_version_metadata.version == '1.0.0'
    assert collection_version_metadata.download_url == 'localhost'
    assert collection_version_metadata.artifact_sha256 == 'hash'
    assert collection_version_metadata.dependencies == {'namespace': 'name', 'version': '1.0.0'}

# TEST for CollectionVersionMetadata.set_download_url()

# Generated at 2022-06-20 14:39:43.383855
# Unit test for function cache_lock
def test_cache_lock():
    with _CACHE_LOCK:
        assert True


# Generated at 2022-06-20 14:39:47.729659
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxyapi = GalaxyAPI('server', None, None, 'user', 'pass', namespaced=True)
    assert repr(galaxyapi) == "<GalaxyAPI('server', namespaced=True)>"

    galaxyapi = GalaxyAPI('server', None, None, 'user', 'pass', namespaced=False)
    assert repr(galaxyapi) == "<GalaxyAPI('server', namespaced=False)>"


# Generated at 2022-06-20 14:39:55.944965
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert not is_rate_limit_exception(Exception())
    assert not is_rate_limit_exception(HTTPError('url', 500, 'message', {}, None))
    assert not is_rate_limit_exception(HTTPError('url', 403, 'message', {}, None))

    assert is_rate_limit_exception(GalaxyError('url', 429, 'message'))
    assert is_rate_limit_exception(GalaxyError('url', 520, 'message'))



# Generated at 2022-06-20 14:40:01.004811
# Unit test for function g_connect
def test_g_connect():
    def isfunc(method):
        return hasattr(method, '__call__')
    for method in (g_connect, g_connect([u'v1', u'v2']), g_connect([u'v2'])):
        assert isfunc(method)
        assert isfunc(method(isfunc))
test_g_connect()



# Generated at 2022-06-20 14:41:24.347266
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    col = CollectionVersionMetadata('test_namespace','test_name','test_version','test_url','test_sha','test_dependencies')
    assert col is not None
    assert col.namespace == 'test_namespace'
    assert col.name == 'test_name'
    assert col.version == 'test_version'
    assert col.download_url == 'test_url'
    assert col.artifact_sha256 == 'test_sha'
    assert col.dependencies == 'test_dependencies'

# Specialized class to work around the changes in V2 and V3.

# Generated at 2022-06-20 14:41:35.020675
# Unit test for function cache_lock
def test_cache_lock():
    """
    Unit test for function cache_lock
    """
    import ansible.galaxy
    import ansible.galaxy.api
    import ansible.galaxy.api.cache_lock
    import ansible.module_utils.api
    import ansible.module_utils.api.retry_with_delays_and_condition
    import ansible.module_utils.urls
    import ansible.module_utils.urls.open_url
    import ansible.utils.hashing
    import ansible.utils.hashing.secure_hash_s
    import ansible.utils.path
    import ansible.utils.path.makedirs_safe
    import datetime
    import functools
    import hashlib
    import json
    import os
    import stat
    import tarfile
    import threading

# Generated at 2022-06-20 14:41:48.443717
# Unit test for function g_connect
def test_g_connect():
    # import nose
    # nose.run(__file__, env={'NOSE_NOCAPTURE': '1'})
    import mock
    from ansible.galaxy.api import GalaxyAPI
    from ansible.galaxy.playbook import PlaybookRequirement

    mock_vars = {}
    cached_galaxy = {}
    cached_galaxy['api_server'] = 'https://galaxy.ansible.com'
    cached_galaxy['ignore_certs'] = False
    cached_galaxy['ignore_errors'] = False
    cached_galaxy['name'] = 'test-galaxy'
    cached_galaxy['no_cache'] = False
    cached_galaxy['token'] = 'token'
    cached_galaxy['validate_certs'] = True


# Generated at 2022-06-20 14:41:52.836207
# Unit test for function get_cache_id
def test_get_cache_id():
    cache_id = get_cache_id('https://user:passwd@example.com:1501')
    assert 'example.com:1501' == cache_id



# Generated at 2022-06-20 14:41:58.084035
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_api = GalaxyAPI()
    expected = 'Galaxy API: %s' % galaxy_api.api_server
    actual = str(galaxy_api)
    assert actual == expected, 'Expected: %s, Actual %s' % (expected, actual)

# Generated at 2022-06-20 14:42:02.941211
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    cm1 = CollectionMetadata("namespace", "name")
    assert cm1.namespace == "namespace"
    assert cm1.name == "name"
    assert cm1.created_str is None
    assert cm1.modified_str is None


# Generated at 2022-06-20 14:42:13.344561
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.galaxy import api
    import datetime

    api_server = 'https://galaxy.ansible.com/api/'
    username = 'admin'
    password = 'password'

    api_v2 = api.GalaxyAPI(api_server=api_server, galaxy_info={'name': 'galaxy.ansible.com'},
                           role_lookup='galaxy.ansible.com.yml',
                           username=username, password=password)
    api_v3 = api.GalaxyAPI(api_server=api_server, galaxy_info={'name': 'galaxy.ansible.com'},
                           role_lookup='galaxy.ansible.com.yml',
                           username=username, password=password)

# Generated at 2022-06-20 14:42:17.118739
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    assert GalaxyAPI('foo') < GalaxyAPI('bar')
    assert not GalaxyAPI('foo') < GalaxyAPI('foo')
    with pytest.raises(TypeError):
        GalaxyAPI('foo') < 'foo'



# Generated at 2022-06-20 14:42:19.767060
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError(HTTPError('', 500, '', '', None), 'test')
    except GalaxyError:
        pass



# Generated at 2022-06-20 14:42:31.550314
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    """The GalaxyAPI __repr__ method should return a string representing the object."""
    galaxy = GalaxyAPI('https://galaxy.example.com', 'Ansible',
                       token_path=os.path.join(os.path.dirname(__file__), 'fixtures', 'token'),
                       ignore_certs=True)
    galaxy2 = GalaxyAPI('localhost', 'Ansible', ignore_certs=True,
                        token_path=os.path.join(os.path.dirname(__file__), 'fixtures', 'token'))

    assert str(galaxy) == "<GalaxyAPI galaxy=Ansible, api_server=https://galaxy.example.com, ignore_certs=True, " \
                          "token_path=/foo/ansible/test/units/lib/galaxy/token>"
   

# Generated at 2022-06-20 14:43:18.132627
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    rate_limit_error = GalaxyError("Rate limit exceeded", http_code=429)
    assert is_rate_limit_exception(rate_limit_error)
    actual_403_error = GalaxyError("Not authorized", http_code=403)
    assert not is_rate_limit_exception(actual_403_error)
    # Rate limit errors masked with 403 error code
    masked_rate_limit_error = GalaxyError("Rate limit exceeded", http_code=403)
    assert not is_rate_limit_exception(masked_rate_limit_error)



# Generated at 2022-06-20 14:43:26.398112
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # Test __repr__ of class GalaxyAPI with missing base_branch.
    galaxy_api = GalaxyAPI(name='any_name',
                           description='any_description',
                           api_server='any_api_server',
                           params={'missing': ('base_branch',)})
    assert repr(galaxy_api) == (
        "GalaxyAPI(name='any_name', description='any_description', api_server='any_api_server', "
        "params={'missing': ('base_branch',)}, available_api_versions={})")

    # Test __repr__ of class GalaxyAPI with error in base_branch.

# Generated at 2022-06-20 14:43:31.298028
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    """Unit test for method ``__unicode__`` of class ``GalaxyAPI``."""
    galaxy_api = GalaxyAPI()
    # Do not know how to test __unicode__
    assert type(galaxy_api.__unicode__())  == str



# Generated at 2022-06-20 14:43:40.336613
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():

    # set up tests
    test_GalaxyAPI__unicode__results = [
        (
            dict(
                name='foo',
                api_server='https://galaxy.server.com/',
                ignore_certs=True,
                available_api_versions=dict(
                    v2='v2',
                    v3='v3',
                ),
            ),
            u"GalaxyAPI(name='foo', api_server='https://galaxy.server.com/', ignore_certs=True, available_api_versions={u'v2': 'v2', u'v3': 'v3'}, auth_token='<hidden>')",
        ),
    ]

    # run tests
    for (args, expected_result) in test_GalaxyAPI__unicode__results:

        # create instance
        galaxy_api

# Generated at 2022-06-20 14:43:41.145001
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    pass

# Generated at 2022-06-20 14:43:46.834880
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    uri = 'https://localhost:8443'
    name = 'galaxy'
    galaxy_api = GalaxyAPI(GalaxyAuth(None, None), uri, name)
    ret_tmpl = 'Galaxy server "%s" at %s'
    assert str(galaxy_api) == ret_tmpl % (name, uri)

# Generated at 2022-06-20 14:43:58.060983
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id(url='https://galaxy.server.org/api/v2') == 'galaxy.server.org'
    assert get_cache_id(url='https://galaxy.server.org:8080/api/v2') == 'galaxy.server.org:8080'
    assert get_cache_id(url='https://user:pass@galaxy.server.org:8080/api/v2') == 'galaxy.server.org:8080'
    assert get_cache_id(url='https://galaxy.server.org/') == 'galaxy.server.org'
    assert get_cache_id(url='https://galaxy.server.org:8080') == 'galaxy.server.org:8080'

# Generated at 2022-06-20 14:44:06.282570
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    assert GalaxyError(HTTPError(url='http://example.com', code=404, msg='Not Found', hdrs=None, fp=None),
                       message='Failed to find collection') == GalaxyError(HTTPError(url='http://example.com',
                                                                                     code=404, msg='Not Found',
                                                                                     hdrs=None, fp=None),
                                                                            message='Failed to find collection')

# Generated at 2022-06-20 14:44:16.198727
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    from ansible_galaxy.galaxy_exceptions import GalaxyClientError
    api = GalaxyAPI(None, None)
    assert api.name == 'galaxy_server'
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.api_token is None

    api = GalaxyAPI('test_server', 'https://test_server.example.com', 'testtoken')
    assert api.name == 'test_server'
    assert api.api_server == 'https://test_server.example.com'
    assert api.api_token == 'testtoken'

    api = GalaxyAPI(api_server='https://test_server.example.com', api_token='testtoken')
    assert api.name == 'galaxy_server'

# Generated at 2022-06-20 14:44:20.962057
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    msg = 'message'
    # Various initializers for http_error
    http_error = HTTPError('https://example.com', 500, msg, {}, None)
    http_error.code = 1
    http_error.url = 'https://example.com'
    http_error.read = lambda : 'default'
    http_error.reason = 'default'
    http_error = HTTPError('https://example.com', 500, msg, {}, None)
    http_error.code = 2
    http_error.url = 'https://example.com/v2'
    http_error.read = lambda : json.dumps({'message': 'message', 'code': 'code'})
    http_error.reason = 'default'
    http_error = HTTPError('https://example.com', 500, msg, {}, None)

# Generated at 2022-06-20 14:45:03.971525
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    gal = GalaxyAPI('foo', 'bar')
    expected = "GalaxyAPI<name='foo',api_server='bar',api_version=None,auth_url=None,verify=None>"
    assert str(gal) == expected



# Generated at 2022-06-20 14:45:09.226838
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert not is_rate_limit_exception(GalaxyError('not a rate limit', http_code=403))
    assert is_rate_limit_exception(GalaxyError('galaxy rate limit', http_code=429))
    assert is_rate_limit_exception(GalaxyError('galaxy rate limit', http_code=520))



# Generated at 2022-06-20 14:45:11.275186
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api = GalaxyAPI('https://galaxy.server.com', 'my_token')
    # simply compare with self
    assert api > api

# Generated at 2022-06-20 14:45:15.903597
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    """
    Unit test
    """
    metadata = CollectionMetadata('namespace', 'name', 'created_str', 'modified_str')
    if metadata.namespace != 'namespace' or metadata.name != 'name' or metadata.created_str != 'created_str' or metadata.modified_str != 'modified_str':
        raise AssertionError("CollectionMetadata test failed")


# Generated at 2022-06-20 14:45:29.021343
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    dependencies = {
        'namespace_foo.collection_bar': ['1.0.0']
    }
    collection = CollectionVersionMetadata('namespace_foo', 'collection_bar', '1.0.0', 'https://galaxy.ansible.com/download/namespace_foo-collection_bar-1.0.0.tar.gz', 'f0cee2df2b6a69b994564b6f33b6e9d624d8b195c3c3e4a4c1d4fbd8a1841e13', dependencies)
    assert collection.namespace == 'namespace_foo'
    assert collection.name == 'collection_bar'
    assert collection.version == '1.0.0'

# Generated at 2022-06-20 14:45:33.418149
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    md = CollectionMetadata('namespace', 'name', 'created_str', 'modified_str')
    assert md.namespace == 'namespace'
    assert md.name == 'name'
    assert md.created_str == 'created_str'
    assert md.modified_str == 'modified_str'


# Generated at 2022-06-20 14:45:40.811293
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    meta = CollectionVersionMetadata("namespace", "collection_name", "1.0.0", "url", "sha256", {
        "namespace1.collection1": "0.9.9",
        "namespace2.collection2": "1.2.3"
    })
    assert meta.namespace == "namespace"
    assert meta.name == "collection_name"
    assert meta.version == "1.0.0"
    assert meta.download_url == "url"
    assert meta.artifact_sha256 == "sha256"
    assert meta.dependencies == {
        "namespace1.collection1": "0.9.9",
        "namespace2.collection2": "1.2.3"
    }


# Generated at 2022-06-20 14:45:50.175607
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # Test with a non-Galaxy exception and a http_code not in RETRY_HTTP_ERROR_CODES
    assert not is_rate_limit_exception(Exception())

    # Test with a Galaxy exception and a http_code not in RETRY_HTTP_ERROR_CODES
    assert not is_rate_limit_exception(GalaxyError("message", http_code=400))

    # Test with a Galaxy exception and a http_code in RETRY_HTTP_ERROR_CODES
    assert is_rate_limit_exception(GalaxyError("message", http_code=429))



# Generated at 2022-06-20 14:46:03.204430
# Unit test for function get_cache_id
def test_get_cache_id():
    """Validate that cache ids are generated properly."""
    # Note: This test will fail if there is an internet connection and DNS works
    cache_id = get_cache_id('http://galaxy.ansible.com/api')
    assert cache_id == 'galaxy.ansible.com:', "URL for galaxy.ansible.com must be 'galaxy.ansible.com:'"
    cache_id_port = get_cache_id('http://galaxy.ansible.com:80')
    assert cache_id == cache_id_port, "URL for galaxy.ansible.com:80 must be 'galaxy.ansible.com:'"
    cache_id = get_cache_id('https://galaxy.ansible.com/api')

# Generated at 2022-06-20 14:46:09.822258
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    """ Test constructor of class GalaxyError """
    mock_err_message = 'This is a mock http error'
    mock_url = 'http://api.galaxy.ansible.com/api/'
    mock_response = {'default': 'This is a galaxy error message', 'errors': []}
    mock_http_code = 500
    mock_http_error = HTTPError(mock_url, mock_http_code, mock_err_message, {}, None)
    mock_http_error.read = lambda: mock_response
    mock_msg = 'Because this is a unit test'
    galaxy_error = GalaxyError(mock_http_error, mock_msg)