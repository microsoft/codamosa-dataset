

# Generated at 2022-06-20 14:37:30.475498
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI(name="test", api_server="ansible.galaxy.com")
    assert repr(api) == "GalaxyAPI(name='test', api_server='ansible.galaxy.com')"


# Generated at 2022-06-20 14:37:35.823767
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    """
    Tests that a CollectionMetadata object is created successfully.
    """
    metadata = CollectionMetadata("namespace", "name", created_str="created", modified_str="modified")
    assert metadata.full_name == "namespace.name"
    assert metadata.created_str == "created"
    assert metadata.modified_str == "modified"


# Generated at 2022-06-20 14:37:43.457009
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():

    galaxy_api = GalaxyAPI('test_server', 'test_user', 'test_password')
    assert galaxy_api.name == 'test_server'
    assert galaxy_api.api_server == 'test_server'
    assert galaxy_api.username == 'test_user'
    assert galaxy_api.password == 'test_password'
    assert galaxy_api.ignore_certs is True

    galaxy_api = GalaxyAPI('test_server', 'test_user', 'test_password', ignore_certs=False)
    assert galaxy_api.ignore_certs is False

    galaxy_api = GalaxyAPI('test_server', 'test_user', 'test_password', verify_ssl=False)
    assert galaxy_api.ignore_certs is True


# Generated at 2022-06-20 14:37:50.710433
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    """Unit test for method GalaxyAPI.__lt__"""
    galaxy = GalaxyAPI(
        'https://galaxy.ansible.com',
        token='1234567890',
        password='ansible',  # This is the username
    )

    galaxy2 = GalaxyAPI(
        'https://galaxy.ansible.com',
        token='1234567890',
        password='ansible',  # This is the username
    )

    galaxy3 = GalaxyAPI(
        'https://galaxy2.ansible.com',
        token='234567890',
        username='ansible',
    )

    assert (galaxy < galaxy2) is False
    assert (galaxy == galaxy2) is True
    assert (galaxy2 != galaxy3) is True
    assert (galaxy3 < galaxy) is False


# Unit test

# Generated at 2022-06-20 14:37:52.248261
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    pass  # The tests have not yet been implemented.

# Generated at 2022-06-20 14:38:00.206663
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
 
    collection_metadata = CollectionMetadata('my_namespace', 'my_name')
    assert collection_metadata.namespace == 'my_namespace'
    assert collection_metadata.name == 'my_name'
    assert collection_metadata.created_str == None
    assert collection_metadata.modified_str == None

    collection_metadata = CollectionMetadata('my_namespace', 'my_name', 'my_created_string', 'my_modified_string')
    assert collection_metadata.namespace == 'my_namespace'
    assert collection_metadata.name == 'my_name'
    assert collection_metadata.created_str == 'my_created_string'
    assert collection_metadata.modified_str == 'my_modified_string'
    assert collection_metadata.created == None
    assert collection_metadata.modified == None


# Generated at 2022-06-20 14:38:07.840020
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    # Build tests
    m = CollectionMetadata(None, None)
    assert m.namespace is None and m.name is None and m.created_str is None \
        and m.modified_str is None and m.insecure is False

    # Equality tests
    m2 = CollectionMetadata(None, None)
    assert m == m2
    assert m != '{}'
    assert m != object()



# Generated at 2022-06-20 14:38:20.382723
# Unit test for function get_cache_id
def test_get_cache_id():
    # all of these are valid and should return the same cache_id:
    assert get_cache_id('https://galaxy.server.org') ==                                 get_cache_id('https://galaxy.server.org/')
    assert get_cache_id('https://galaxy.server.org') ==                                 get_cache_id('https://galaxy.server.org/api/')
    assert get_cache_id('https://galaxy.server.org') ==                                 get_cache_id('https://galaxy.server.org:443/')
    assert get_cache_id('https://galaxy.server.org') ==                                 get_cache_id('https://galaxy.server.org:443/api/')
    assert get_cache_id('https://galaxy.server.org:80') ==                              get_cache_

# Generated at 2022-06-20 14:38:29.125660
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():  # noqa
    ansible_vars = AnsibleVars(
        galaxy=GalaxyInfo(
            api_server="https://galaxy.ansible.com"
        )
    )

    galaxy_api = GalaxyAPI(ansible_vars)
    assert galaxy_api is not None
    assert galaxy_api.api_server == "https://galaxy.ansible.com"

    # test integrity of _call_galaxy
    assert "v2" in galaxy_api.available_api_versions
    assert "v3" not in galaxy_api.available_api_versions

    galaxy_api = GalaxyAPI(ansible_vars, urljoin("https://galaxy.ansible.com", "api/v2"))
    assert galaxy_api is not None

# Generated at 2022-06-20 14:38:35.361001
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    # Test 1: All values are valid
    collection_metadata = CollectionMetadata('namespace', 'name', created_str='created_str',
                                             modified_str='modified_str')
    assert collection_metadata.name == 'name'
    assert collection_metadata.namespace == 'namespace'
    assert collection_metadata.modified_str == 'modified_str'
    assert collection_metadata.created_str == 'created_str'

    # Test 2: No values are valid
    collection_metadata = CollectionMetadata('namespace', 'name')
    assert collection_metadata.name == 'name'
    assert collection_metadata.namespace == 'namespace'
    assert collection_metadata.modified_str is None
    assert collection_metadata.created_str is None



# Generated at 2022-06-20 14:39:24.480912
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(GalaxyError())



# Generated at 2022-06-20 14:39:40.519143
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """
    Test for constructor of class GalaxyAPI
    """
    mock_args = MagicMock()

    mock_args.ignore_certs = False
    mock_args.api_server = 'https://galaxy-server-url.com'

    mock_args.server_list = None
    mock_args.skip_server_validation = False

    mock_args.token = None
    mock_args.token_path = None
    mock_args.ignore_errors = False

    mock_args.timeout = 300

    mock_args.no_cache = False
    mock_args.force_deprecation = False

    mock_args.ignore_errors = False

    mock_args.force_basic_auth = False
    mock_args.log_path = None

    mock_args.debug = False
    mock_args.verbosity

# Generated at 2022-06-20 14:39:48.636562
# Unit test for function g_connect
def test_g_connect():
    class Connection(object):
        def __init__(self, api_server):
            self.name = 'connection'
            self.api_server = api_server
            self._available_api_versions = {}
            self.galaxy_token = ''

        @g_connect(['v2'])
        def test_method(self):
            pass

        def _call_galaxy(self, url, method='GET', data=None, error_context_msg=None, cache=False):
            return {'available_versions': {'v2': 'v2/'}}

    c = Connection('https://galaxy.ansible.com')
    c.test_method()

    c = Connection('https://galaxy.ansible.com/api')
    c.test_method()


# Generated at 2022-06-20 14:39:59.713126
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # TODO: These tests are not currently running as part of the unit test suite, need to update once GalaxyAPI is
    # actually being used.

    # Create a GalaxyAPI object with only required parameters
    api_server = 'foo'
    galaxy_api = GalaxyAPI(api_server)
    assert galaxy_api.api_server == api_server, "api_server is not correctly set"
    assert galaxy_api.auth is None, "auth should be None"
    assert not galaxy_api._cache, "_cache should be empty"
    assert galaxy_api.available_api_versions == {}, "available_api_versions should be empty"

    # Create a GalaxyAPI object with all parameters
    api_key = 'bar'
    cache_path = 'baz'
    proxy_url = 'qux'
    ignore_certs = True
   

# Generated at 2022-06-20 14:40:14.844696
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    '''
    Unit test for method __lt__ of class GalaxyAPI
    '''

    # Set up a fake changeset to test against, use the C() function to avoid
    # the tuple to dict conversion so we can test the actual tuple comparison
    fake_changeset = []
    fake_changeset.append(C(change='change1', object='object1', type='type1'))
    fake_changeset.append(C(change='change1', object=None, type='type1'))

    # Set up fake data for a GalaxyAPI
    finished_at = time.time() - 1
    imported_at = time.time()
    new_changeset = []
    new_changeset.append(C(change='change1', object='object1', type='type1'))

# Generated at 2022-06-20 14:40:20.335297
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxyapi = GalaxyAPI(api_server="https://galaxy.ansible.com")
    expected_msg = u'galaxy:https://galaxy.ansible.com'
    result = galaxyapi.__unicode__()
    assert result == expected_msg, "GalaxyAPI.__unicode__() returned '{}', expected '{}'".format(result, expected_msg)

# Generated at 2022-06-20 14:40:24.988046
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    metadata = CollectionMetadata(namespace='test_namespace', name='test_name')
    assert metadata.namespace == 'test_namespace'
    assert metadata.name == 'test_name'
    assert metadata.description is None
    assert metadata.created_str is None
    assert metadata.modified_str is None
    assert metadata.summary is None


# Generated at 2022-06-20 14:40:27.976638
# Unit test for function g_connect
def test_g_connect():
    import mock

    g_connect(versions=['v1'])(mock.Mock(spec=['_available_api_versions']))

# Generated at 2022-06-20 14:40:29.155799
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    assert not CollectionMetadata()

# Generated at 2022-06-20 14:40:35.856198
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    from ansible.galaxy.collection_info import GalaxyAPI

    galaxyapi = GalaxyAPI(api_server='https://galaxy.ansible.com',
                          token=None,
                          ignore_certs=False,
                          force_api_version=None,
                          available_api_versions=['v2', 'v3'])

    assert str(galaxyapi) == '[API: https://galaxy.ansible.com, API versions: v2,v3]'

# Generated at 2022-06-20 14:42:08.316021
# Unit test for function g_connect
def test_g_connect():
    @g_connect(['v1', 'v2'])
    def test_method(self):
        return "test"

    class TC:
        _available_api_versions = {}
        api_server = ''
        name = ''


# Generated at 2022-06-20 14:42:21.102859
# Unit test for function g_connect
def test_g_connect():
    @g_connect(['v1', 'v2'])
    def foo(self):
        return 1
    class baz(object):
        _available_api_versions={'v1': 'v1/'}
        api_server="http://127.0.0.1"
        name="test_galaxy"
    assert foo(baz()) == 1
    try:
        @g_connect(['v3'])
        def bar(self):
            return 1
        bar(baz())
        raise AssertionError("Did not raise error")
    except AnsibleError:
        pass



# Generated at 2022-06-20 14:42:24.880084
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def a():
        return 1
    b = a()
    assert b == 1



# Generated at 2022-06-20 14:42:29.975858
# Unit test for function g_connect
def test_g_connect():
    versions = ['v1']
    def method(self, *args, **kwargs):
        return self
    method2 = g_connect(versions)(method)
    class TestClass(object):
        _available_api_versions = {'v1': 'v1/'}
        name = 'galaxy'
        api_server = 'https://galaxy.ansible.com/'
    assert method2(TestClass(), *[])


# Generated at 2022-06-20 14:42:31.086428
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    GalaxyAPI.__lt__()



# Generated at 2022-06-20 14:42:35.665146
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    ex = GalaxyError('rate limit', http_code=429)
    assert is_rate_limit_exception(ex)



# Generated at 2022-06-20 14:42:38.442492
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    ansible_galaxy_api = GalaxyAPI()

    # Assert the correct value is returned
    assert str(ansible_galaxy_api) == "GalaxyAPI()"

# Generated at 2022-06-20 14:42:49.033172
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://foo.com') == 'foo.com:'
    assert get_cache_id('http://foo.com:') == 'foo.com:'
    assert get_cache_id('http://foo.com:443') == 'foo.com:443'
    assert get_cache_id('http://foo.com:443/api') == 'foo.com:443'
    assert get_cache_id('http://foo.com/api') == 'foo.com:'
    assert get_cache_id('http://foo.com/api/') == 'foo.com:'
    assert get_cache_id('http://foo.com/api/v2/') == 'foo.com:'
    assert get_cache_id('http://foo.com:443/api/v2/') == 'foo.com:443'

# Generated at 2022-06-20 14:42:52.343266
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI(name='test', server='https://server.com/')
    assert str(api) == 'GalaxyAPI(name=test, server=https://server.com/)'


# Generated at 2022-06-20 14:42:58.274937
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError('', 403))
    assert is_rate_limit_exception(GalaxyError('', 429))
    assert not is_rate_limit_exception(GalaxyError('', 401))
    assert not is_rate_limit_exception(GalaxyError('', 500))
    assert not is_rate_limit_exception(GalaxyError('', 503))



# Generated at 2022-06-20 14:45:51.399415
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    config = GalaxyConfig()
    api = GalaxyAPI(config=config)
    assert api.name == 'galaxy'
    assert api.api_server == 'https://galaxy.ansible.com'
    assert api.urls == {'v1': '/api/v1', 'v2': '/api/v2', 'v3': '/api/automation-hub/v1', 'v4': None,
                        'current': '/api/v2', 'token': '/api/tokens/', 'automation_hub': '/api/automation-hub/'}
    assert api.token is None
    assert api.auth is None
    assert api.available_api_versions == {'v1': '/api/v1', 'v2': '/api/v2'}
    assert api._session is None



# Generated at 2022-06-20 14:46:04.745340
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test case for instantiating class GalaxyAPI when user supplies a URL.
    # This should populate the name field.
    name = 'test_galaxy_api'
    api_server = 'https://testgalaxyserver.com'
    cert_path = 'test_cert_path'
    key_path = 'test_key_path'
    ignore_certs = False
    verify_ssl = None
    redirect = True
    proxy_setting = dict()

    galaxy_api = GalaxyAPI(name, api_server, redirect, proxy_setting, cert_path, key_path, ignore_certs, verify_ssl)

    assert galaxy_api.name == name
    assert galaxy_api.api_server == api_server
    assert galaxy_api.redirect == redirect
    assert galaxy_api.token is None

# Generated at 2022-06-20 14:46:09.780011
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    test_instance = GalaxyAPI('https://galaxy.server.com', 'username', 'password')
    result = test_instance.__str__()
    assert result == 'galaxy.server.com'

    test_instance = GalaxyAPI('https://galaxy.server.com', 'username', 'password', force_api_version='v2')
    result = test_instance.__str__()
    assert result == 'galaxy.server.com'

    test_instance = GalaxyAPI('https://galaxy.server.com', 'username', 'password', force_api_version='v3')
    result = test_instance.__str__()
    assert result == 'galaxy.server.com'