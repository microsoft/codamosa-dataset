

# Generated at 2022-06-20 14:37:04.807156
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    metadata = CollectionVersionMetadata(
        namespace='my.ns',
        name='my.coll',
        version='1.0.0',
        download_url='https://galaxy.server/download.tar',
        artifact_sha256='abcdefghijklmnopqrstuvwxyz',
        dependencies={}
    )
    assert metadata.namespace == 'my.ns'
    assert metadata.name == 'my.coll'
    assert metadata.version == '1.0.0'
    assert metadata.download_url == 'https://galaxy.server/download.tar'
    assert metadata.artifact_sha256 == 'abcdefghijklmnopqrstuvwxyz'
    assert metadata.dependencies == {}



# Generated at 2022-06-20 14:37:07.547957
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    a = GalaxyError('SomeException', 'Error message')
    assert a.http_code is None
    assert len(a.message) > 0
    assert a.url is None



# Generated at 2022-06-20 14:37:11.561956
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    g = GalaxyAPI("name", "api_server", "url_prefix", "token", "ignore_certs", ['v2', 'v3'])
    x = repr(g)
    assert x == "GalaxyAPI(name='name', api_server='api_server', url_prefix='url_prefix', token='token', ignore_certs=True, available_api_versions={'v2': 'v2', 'v3': 'v3'})"

# Generated at 2022-06-20 14:37:21.113440
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    """
        Verify __unicode__() returns the correct value.
    """
    galaxy_api = GalaxyAPI('test_galaxy', 'http://test.galaxy.example.com')
    expected_value = 'Galaxy API: test_galaxy (http://test.galaxy.example.com)'
    assert str(galaxy_api) == expected_value


# Generated at 2022-06-20 14:37:33.489501
# Unit test for function g_connect
def test_g_connect():
    import inspect
    import os
    import tempfile
    from ansible.galaxy.api import GalaxyAPI
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.urls import open_url

    GALAXY_SERVER = "localhost"
    GALAXY_SERVER_SSL = "https://localhost"
    GALAXY_URL = "http://localhost"
    GALAXY_URL_SSL = "https://localhost"


# Generated at 2022-06-20 14:37:39.017310
# Unit test for function get_cache_id
def test_get_cache_id():
    # Test with URL that does not use port
    url = 'http://www.galaxy.com/api/'
    cache_id = get_cache_id(url)
    assert cache_id == 'www.galaxy.com:'

    # Test with URL that does use port
    url = 'http://www.galaxy.com:8080/api/'
    cache_id = get_cache_id(url)
    assert cache_id == 'www.galaxy.com:8080'



# Generated at 2022-06-20 14:37:48.713721
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():

    assert is_rate_limit_exception(GalaxyError(http_code=429)) == True
    assert is_rate_limit_exception(GalaxyError(http_code=520)) == True
    assert is_rate_limit_exception(GalaxyError(http_code=400)) == False
    assert is_rate_limit_exception(GalaxyError(http_code=403)) == False
    # Test if GalaxyError gets caught
    assert is_rate_limit_exception(IOError()) == False
    # Test if http_code gets caught
    assert is_rate_limit_exception(HTTPError(http_code=429)) == True



# Generated at 2022-06-20 14:37:58.646695
# Unit test for function g_connect
def test_g_connect():
    # test for method `g_connect`
    # function: `g_connect`
    # filepath: `_ansible_galaxy/galaxy.py`
    # class: `GalaxyAPI`

    from _ansible_galaxy.galaxy import GalaxyAPI

    class GalaxyAPIStub(GalaxyAPI):

        def _call_galaxy(self, url, data=None, method=None, error_context_msg='',
                         headers=None, allow_redirects=True,
                         force_basic_auth=False, timeout=10,
                         validate_certs=True, client_cert=None,
                         cache=False):
            return {'available_versions': {'v1': 'v1', 'v2': 'v2'}}
    galaxy_api = GalaxyAPIStub()
    galaxy_api.api_

# Generated at 2022-06-20 14:38:14.917679
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://example.com') == 'example.com:'
    assert get_cache_id('https://example.com:') == 'example.com:'
    assert get_cache_id('https://example.com:80') == 'example.com:80'
    assert get_cache_id('https://example.com:80/') == 'example.com:80'
    assert get_cache_id('https://example.com/test') == 'example.com:'
    assert get_cache_id('https://example.com:8080/test') == 'example.com:8080'
    assert get_cache_id('https://example.com:8080/?a=b') == 'example.com:8080'

# Generated at 2022-06-20 14:38:28.822864
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    """
    This function is to perform unit test for class GalaxyError.
    """
    http_msg = '{"message": "Some error occurred", "code": "2404"}'
    http_error = HTTPError("https://myurl.com", 404, "Not found", {}, None)
    error = GalaxyError(http_error, "Some error occurred")
    assert error.http_code == 404
    assert error.url == "https://myurl.com"
    assert error.message == "Some error occurred (HTTP Code: 404, Message: Some error occurred Code: 2404)"

    http_msg = '{"errors": [{"title": "some error occurred", "code": "some code"}]}'
    http_error = HTTPError("https://myurl.com/v3/some_path", 404, "Not found", {}, None)
   

# Generated at 2022-06-20 14:39:05.711116
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:'
    assert get_cache_id('https://galaxy.ansible.com:80') == 'galaxy.ansible.com:80'
    assert get_cache_id('https://galaxy.ansible.com:443') == 'galaxy.ansible.com:443'



# Generated at 2022-06-20 14:39:15.430472
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():

    from ansible.module_utils._text import to_text

    class File(object):

        def write(self, value):
            pass

        def flush(self):
            pass

    class TestOutputDevice(object):

        class TestFile(File):
            pass

        def __init__(self):
            pass

        def open(self, filename, mode):
            return self.TestFile()

        def isatty(self, filename):
            return False

        def close(self, file):
            pass



# Generated at 2022-06-20 14:39:23.159140
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert not is_rate_limit_exception(GalaxyError(""))
    assert not is_rate_limit_exception(GalaxyError("", 403))
    assert is_rate_limit_exception(GalaxyError("", 429))
    assert is_rate_limit_exception(GalaxyError("", 520))



# Generated at 2022-06-20 14:39:26.934207
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(429, "Rate limit exceeded for this request"))
    assert is_rate_limit_exception(GalaxyError(520, "Rate limit exceeded for this request"))



# Generated at 2022-06-20 14:39:35.506963
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection = CollectionMetadata(namespace = 'test_namespace', name = 'test_name')
    if collection.namespace != 'test_namespace':
        raise Exception('CollectionMetadata: FAILURE: Namespace did not match the input value')
    if collection.name != 'test_name':
        raise Exception('CollectionMetadata: FAILURE: Name did not match the input value')
    if collection.created_str != None:
        raise Exception('CollectionMetadata: FAILURE: Created date was not None')
    if collection.modified_str != None:
        raise Exception('CollectionMetadata: FAILURE: Modified date was not None')
    if collection.version != None:
        raise Exception('CollectionMetadata: FAILURE: Version was not None')

# Generated at 2022-06-20 14:39:40.774076
# Unit test for function get_cache_id
def test_get_cache_id():
    my_url = 'https://galaxy.ansible.com'
    my_constructed_url = get_cache_id(my_url)
    assert my_constructed_url == 'galaxy.ansible.com:443'
    my_url = 'https://galaxy.ansible.com/api/'
    my_constructed_url = get_cache_id(my_url)
    assert my_constructed_url == 'galaxy.ansible.com:443'
    my_url = 'https://galaxy.ansible.com/'
    my_constructed_url = get_cache_id(my_url)
    assert my_constructed_url == 'galaxy.ansible.com:443'
    my_url = 'http://bogus'
    my_constructed_url = get_cache

# Generated at 2022-06-20 14:39:46.033884
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    error = GalaxyError(http_code=429)
    assert is_rate_limit_exception(error)

    error = GalaxyError(http_code=520)
    assert is_rate_limit_exception(error)

    error = GalaxyError(http_code=403)
    assert not is_rate_limit_exception(error)

    assert not is_rate_limit_exception(ValueError())



# Generated at 2022-06-20 14:39:55.577592
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    import time
    metadata = CollectionMetadata('bob', 'my_collection',
                                  created_str=time.strftime(TEXT_DATE_FORMAT, time.localtime()),
                                  modified_str=time.strftime(TEXT_DATE_FORMAT, time.localtime()))

    assert(metadata.namespace == 'bob')
    assert(metadata.name == 'my_collection')
    assert(metadata.created_str is not None)
    assert(metadata.modified_str is not None)


# Generated at 2022-06-20 14:40:04.639210
# Unit test for function get_cache_id
def test_get_cache_id():
    # Test basic functionality
    assert get_cache_id(to_text('https://galaxy.ansible.com/')) == 'galaxy.ansible.com'
    assert get_cache_id(to_text('https://galaxy.ansible.com:90000/')) == 'galaxy.ansible.com:90000'
    assert get_cache_id(to_text('https://galaxy.ansible.com:443/')) == 'galaxy.ansible.com'

    # Test with credentials
    assert get_cache_id(to_text('https://user:password@galaxy.ansible.com/')) == 'galaxy.ansible.com'

    # Make sure it works with wacky ports

# Generated at 2022-06-20 14:40:14.256691
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    """
    Test case for the method ``GalaxyAPI.__str__`` of the class ``GalaxyAPI``.
    """
    # Define the expected results
    expected = 'API: {}, Server: {}'.format(GalaxyAPI(None, None).api, GalaxyAPI(None, None).api_server)
    # Use the method under test
    result = GalaxyAPI(None, None)
    # Assert that the result obtained is equal to the expected one
    assert str(result) == expected


# Generated at 2022-06-20 14:40:45.599538
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    from ansibullbot.utils.galaxy_utils import GalaxyAPI
    obj = GalaxyAPI('galaxy')
    assert str(obj) == "Galaxy 'galaxy' not available"


# Generated at 2022-06-20 14:40:49.190194
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    g = GalaxyAPI(server="http://galaxy.ansible.com", name="Galaxy API")
    assert str(g) == "Galaxy API"


# Generated at 2022-06-20 14:40:55.181291
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    assert GalaxyAPI(name='galaxy_name', api_server='api_server') < GalaxyAPI(name='galaxy_name', api_server='api_server')
    assert not GalaxyAPI(name='galaxy_name', api_server='api_server') < GalaxyAPI(name='galaxy_name1', api_server='api_server')
    assert not GalaxyAPI(name='galaxy_name', api_server='api_server') < GalaxyAPI(name='galaxy_name', api_server='api_server1')

# Generated at 2022-06-20 14:41:06.237023
# Unit test for function get_cache_id
def test_get_cache_id():
    """ GalaxyAPI: test_get_cache_id() """
    assert get_cache_id('http://foo.com') == 'foo.com:'
    assert get_cache_id('http://foo.com:80') == 'foo.com:80'
    assert get_cache_id('https://foo.com') == 'foo.com:'
    assert get_cache_id('https://foo.com:443') == 'foo.com:443'
    assert get_cache_id('http://foo.com:8080') == 'foo.com:8080'
    assert get_cache_id('https://username:passwd@foo.com') == 'foo.com:'
    assert get_cache_id('https://username:passwd@foo.com:443') == 'foo.com:443'

# Generated at 2022-06-20 14:41:11.011962
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    """
    is_rate_limit_exception() successfully tests rate limit exception
    """
    emsg = "Testing is_rate_limit_exception()"
    omsg = "is_rate_limit_exception() failed"
    exception_obj = GalaxyError(http_code=429, msg='Too Many Requests', url='/foo/bar')
    if is_rate_limit_exception(exception_obj):
        display.display_ok(emsg)
    else:
        display.display_error(omsg)



# Generated at 2022-06-20 14:41:25.432012
# Unit test for function g_connect
def test_g_connect():
    """
    A function to help test g_connect
    """

    # define test class
    class TestGalaxy:

        # init function
        def __init__(self, name, api_server, token, path):
            self.name = name
            self.api_server = api_server
            self.token = token
            self.path = path

        # define _available_api_versions
        _available_api_versions = {'v1': 'v1/'}

        # define _call_galaxy
        def _call_galaxy(self, *args):
            # Note: The arguments are not used here.
            return {'available_versions': {'v2': 'v2/'}}

        @g_connect(versions=['v2'])
        def test(self):
            return 'Test done'

   

# Generated at 2022-06-20 14:41:29.737653
# Unit test for function g_connect
def test_g_connect():
    def method(*args, **kwargs):
        return args,kwargs
    g_connect('v1','v2')(method)('a1','a2', k1='k1')



# Generated at 2022-06-20 14:41:38.964193
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    meta = CollectionVersionMetadata('namespace1','name1','version1','download_url1','artifact_sha256',{'dependencies1':'version'})
    assert meta.artifact_sha256 == 'artifact_sha256'
    assert meta.version == 'version1'
    assert meta.download_url == 'download_url1'



# Generated at 2022-06-20 14:41:51.346643
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # Test 1
    g = GalaxyAPI("api_server", api_token="api_token", ensure=False)
    g.name = "Test GalaxyAPI"
    g.api_token = "Test api_token"
    assert str(g) == "Test GalaxyAPI (api_token: Test api_token)"

    # Test 2
    g = GalaxyAPI("api_server", api_token=None, ensure=False)
    g.name = "Test GalaxyAPI"
    assert str(g) == "Test GalaxyAPI (api_token: None)"

    # Test 3
    g = GalaxyAPI("api_server", api_token=None, ensure=False)
    g.name = None
    assert str(g) == "Test GalaxyAPI (api_token: None)"


# Generated at 2022-06-20 14:41:59.709877
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('http://localhost:12345') == 'localhost:12345'
    assert get_cache_id('https://example.com') == 'example.com:'
    assert get_cache_id('https://example.com:') == 'example.com:'
    assert get_cache_id('https://localhost') == 'localhost:'
    assert get_cache_id('https://localhost/') == 'localhost:'


# Generated at 2022-06-20 14:44:27.219130
# Unit test for function cache_lock
def test_cache_lock():
    # Verify that only one thread has the lock at a time.
    assert _CACHE_LOCK.acquire(False) is True
    assert _CACHE_LOCK.acquire(False) is False

    def threaded_func():
        with _CACHE_LOCK:
            return True

    # Verify that cache_lock decorator works when called from a thread.
    assert _CACHE_LOCK.acquire(False) is True
    assert threading.Thread(target=threaded_func).start() is True
    time.sleep(0.1)  # Allow the thread to acquire the lock.
    assert _CACHE_LOCK.acquire(False) is False



# Generated at 2022-06-20 14:44:34.529013
# Unit test for function get_cache_id
def test_get_cache_id():
    # Port number
    assert get_cache_id('https://www.example.com:40001/') == 'www.example.com:40001'
    # No port
    assert get_cache_id('https://www.example.com/') == 'www.example.com:'
    # Basic auth
    assert get_cache_id('https://user:pass@www.example.com/') == 'www.example.com:'


# Generated at 2022-06-20 14:44:48.954962
# Unit test for constructor of class CollectionVersionMetadata

# Generated at 2022-06-20 14:44:58.023907
# Unit test for function get_cache_id
def test_get_cache_id():
    url1 = "https://galaxy.ansible.com/api/v1/collections/namespace/collection/version?page=1&page_size=%s" % COLLECTION_PAGE_SIZE
    assert get_cache_id(url1) == "galaxy.ansible.com"
    url2 = "https://galaxy.ansible.com:443/api/v1/collections/namespace/collection/version?page=1&page_size=%s" % COLLECTION_PAGE_SIZE
    assert get_cache_id(url2) == "galaxy.ansible.com:443"
    url3 = "https://user@galaxy.ansible.com:443/api/v1/collections/namespace/collection/version?page=1&page_size=%s" % COLLECTION

# Generated at 2022-06-20 14:45:10.572190
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    e = HTTPError('https://galaxy.ansible.com', 404, 'Not Found', None, None)

    g = GalaxyError(e, 'foo')
    assert g.http_code == 404
    assert g.url == 'https://galaxy.ansible.com'
    assert g.message == 'foo (HTTP Code: 404, Message: Not Found)'

    e = HTTPError('https://galaxy.ansible.com/api/v2/', 429, 'Too Many Requests', None, None)
    e.read = lambda: b'{"message": "API Rate limit reached", "code": "rate_limit_exceeded"}'

    g = GalaxyError(e, 'foo')
    assert g.http_code == 429
    assert g.url == 'https://galaxy.ansible.com/api/v2/'

# Generated at 2022-06-20 14:45:26.469486
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import io
    import httplib
    def test():
        http_error = httplib.Http()
        test_message = 'test message'
        err = GalaxyError(http_error, test_message)
        assert to_text(err) == to_text('test message (HTTP Code: None, Message: None)')
        http_error.message = 'http message'
        http_error.code = 500
        err = GalaxyError(http_error, test_message)
        assert to_text(err) == to_text('test message (HTTP Code: 500, Message: http message)')
        test_message2 = 'test message2'
        http_error.read = lambda: b'{"default": "test galaxy message"}'
        err = GalaxyError(http_error, test_message2)

# Generated at 2022-06-20 14:45:37.350521
# Unit test for function get_cache_id
def test_get_cache_id():
    # Test without credentials
    url = "http://galaxy.ansible.com/api/"
    cache_id = "galaxy.ansible.com"
    assert get_cache_id(url) == cache_id
    url = "https://galaxy.ansible.com"
    assert get_cache_id(url) == cache_id
    url = "http://galaxy.ansible.com:8080"
    cache_id = "galaxy.ansible.com:8080"
    assert get_cache_id(url) == cache_id
    # Test with credentials
    url = "http://name:password@galaxy.ansible.com/api/"
    cache_id = "galaxy.ansible.com"
    assert get_cache_id(url) == cache_id

# Generated at 2022-06-20 14:45:49.811755
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Create a GalaxyAPI object without arguments
    api1 = GalaxyAPI('api.galaxy.com')

    # Create a GalaxyAPI object with an API server
    api2 = GalaxyAPI('api.galaxy.com')
    assert api1.api_server == api2.api_server

    # Create a GalaxyAPI object with an API server with a port suffix
    api3 = GalaxyAPI('api.galaxy.com:1000')
    assert api1.api_server == api3.api_server

    # Create a GalaxyAPI object with an API server
    api4 = GalaxyAPI('api.galaxy.com', ignore_certs=True)
    assert api1.api_server == api4.api_server
    assert api4.ignore_certs

    # Create a GalaxyAPI object with an API server

# Generated at 2022-06-20 14:46:00.288591
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    gapi = GalaxyAPI()
    assert gapi is not None
    assert gapi.api_token is None
    assert gapi.api_server == API_SERVER
    assert gapi.name is None
    assert gapi.timeout == 10

    gapi = GalaxyAPI(api_server=API_SERVER, api_token=API_TOKEN, name=NAME, timeout=TIMEOUT)
    assert gapi is not None
    assert gapi.api_token == API_TOKEN
    assert gapi.api_server == API_SERVER
    assert gapi.name == NAME
    assert gapi.timeout == TIMEOUT

# Generated at 2022-06-20 14:46:04.445990
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    exception = GalaxyError(http_code=429)
    assert is_rate_limit_exception(exception)
    exception = GalaxyError(http_code=403)
    assert not is_rate_limit_exception(exception)

