

# Generated at 2022-06-20 14:37:05.156992
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    exception = GalaxyError("Fake error message", http_code=429)
    assert is_rate_limit_exception(exception) is True

    exception = GalaxyError("Fake error message", http_code=403)
    assert is_rate_limit_exception(exception) is False



# Generated at 2022-06-20 14:37:11.803716
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    """ Unit test for ``GalaxyAPI.__lt__`` """
    # Test with a non-GalaxyAPI object
    api1 = GalaxyAPI(server='api.galaxy.ansible.com', namespace='galaxy', name='galaxy')
    api2 = {'name': 'galaxy'}
    assert not api1.__lt__(api2)
    assert not api2.__lt__(api1)
    # Test with a GalaxyAPI object where names are different
    api1 = GalaxyAPI(server='api.galaxy.ansible.com', namespace='galaxy', name='galaxy')
    api2 = GalaxyAPI(server='api.galaxy.ansible.com', namespace='galaxy', name='testgalaxy')
    assert not api1.__lt__(api2)

# Generated at 2022-06-20 14:37:14.430160
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI('Normal Galaxy','https://galaxy.ansible.com','token','token_secret','consumer_key','consumer_secret')
    assert str(api) == 'Galaxy API for Normal Galaxy at https://galaxy.ansible.com'



# Generated at 2022-06-20 14:37:30.192843
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    expected_msg = 'v1 API message (HTTP Code: 500, Message: default)'
    http_error = HTTPError(url=None, code=500, msg='v1 API message', hdrs=None, fp=None)
    new_error = GalaxyError(http_error, 'v1 API message')
    assert new_error.message == expected_msg

    expected_msg2 = 'v2 API message (HTTP Code: 500, Message: this is error message Code: 400)'
    http_error2 = HTTPError(url=None, code=500, msg='v2 API message', hdrs=None, fp=None)
    new_error2 = GalaxyError(http_error2, 'v2 API message')
    new_error

# Generated at 2022-06-20 14:37:39.198487
# Unit test for function get_cache_id
def test_get_cache_id():
    # URL with port 80
    url = 'http://redhat.com:80/my/url'
    cache_id = get_cache_id(url)
    assert cache_id == 'redhat.com:80'
    # URL without port
    url = 'http://redhat.com'
    cache_id = get_cache_id(url)
    assert cache_id == 'redhat.com'
    # URL with non-standard port
    url = 'http://redhat.com:28/my/url'
    cache_id = get_cache_id(url)
    assert cache_id == 'redhat.com:28'
    # URL without protocol
    url = 'redhat.com:28/my/url'
    cache_id = get_cache_id(url)

# Generated at 2022-06-20 14:37:41.033156
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    test_obj = GalaxyAPI('90.54.16.40:5000', '/api/v2')
    actual = test_obj.__lt__(None)
    assert actual == NotImplemented


# Generated at 2022-06-20 14:37:45.793614
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    g = GalaxyAPI("servername", "url_path/api/", "username", "password", False, None)
    assert g.server == "servername"
    assert g.url_path == "url_path/api/"
    assert g.username == "username"
    assert g.verify_ssl == False
    assert g.ignore_certs is False
    assert g.cert is None
    assert g.client_cert is None
    assert g.api_server == "url_path/api/"
    assert g.no_log is False
    assert g.token is None


# Generated at 2022-06-20 14:37:51.596637
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    try:
        raise GalaxyError(HTTPError('Test', 'reason', code=404), 'message')
    except GalaxyError as e:
        assert e.http_code == 404
        assert e.url == 'Test'
        assert e.message == 'message (HTTP Code: 404, Message: reason)'


# Generated at 2022-06-20 14:37:53.991836
# Unit test for function cache_lock
def test_cache_lock():
    called = [False]
    @cache_lock
    def dummy():
        called[0] = True
    dummy()
    assert called[0]


# Generated at 2022-06-20 14:38:02.952436
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    msg = "error message"
    error = HTTPError("", 401, msg, "", "")
    galaxy_error = GalaxyError(error, msg)
    assert galaxy_error.message == "error message (HTTP Code: 401, Message: error message Code: Unknown)"
    assert galaxy_error.http_code == 401


# Generated at 2022-06-20 14:38:53.033997
# Unit test for function cache_lock
def test_cache_lock():
    global test_counter
    try:
        test_counter += 1
    except NameError:
        test_counter = 1

    for i in range(10):
        @cache_lock
        def test_func():
            global test_counter
            test_counter += 1

        threading.Thread(target=test_func).start()

    time.sleep(1)
    assert test_counter == 1



# Generated at 2022-06-20 14:38:58.608119
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # Setup
    galaxy_api = init_GalaxyAPI(default_instance=True)
    galaxy_api.name = 'awx'
    galaxy_api.api_server = 'https://galaxy.ansible.com'
    # Test
    assert str(galaxy_api) == 'awx https://galaxy.ansible.com'

# Generated at 2022-06-20 14:38:59.925337
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI('https://galaxy.ansible.com')
    assert api.api_server == 'https://galaxy.ansible.com/api/'


# Generated at 2022-06-20 14:39:02.523582
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("https://galaxy.example.com:8080") == "galaxy.example.com:8080"



# Generated at 2022-06-20 14:39:13.807341
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Missing URL
    with pytest.raises(AnsibleError) as err:
        GalaxyAPI('galaxy', None)
    assert "Galaxy API server URL is required." in to_native(err.value)

    # Invalid URL
    with pytest.raises(AnsibleError) as err:
        GalaxyAPI('galaxy', 'http://')
    assert "Galaxy API server URL 'http://' is not a valid URL" in to_native(err.value)

    # Invalid API versions
    with pytest.raises(AnsibleError) as err:
        GalaxyAPI('galaxy', 'http://galaxy.com', api_versions=['api', 'v1'])
    assert "Invalid API version 'api' specified." in to_native(err.value)



# Generated at 2022-06-20 14:39:22.191941
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=200))
    assert not is_rate_limit_exception(None)



# Generated at 2022-06-20 14:39:30.315860
# Unit test for function get_cache_id
def test_get_cache_id():
    galaxy = Galaxy()
    assert galaxy.get_cache_id('https://localhost/api/v2') == 'localhost:'
    assert galaxy.get_cache_id('https://localhost:8080/api/v2') == 'localhost:8080'
    assert galaxy.get_cache_id('https://localhost:8080:8080/api/v2') == 'localhost:8080:8080'
    assert galaxy.get_cache_id('https://localhost:8080/api/v2') == 'localhost:8080'
    assert galaxy.get_cache_id('https://localhost:8080:8080/api/v2') == 'localhost:8080:8080'
    assert galaxy.get_cache_id('https://localhost:8080/api/v2') == 'localhost:8080'
    assert galaxy.get_cache

# Generated at 2022-06-20 14:39:42.733536
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    gapi = GalaxyAPI('https://galaxy.server/api')
    gapi_v2 = GalaxyAPI('https://galaxy.server/api', ['v2'])
    gapi_v3 = GalaxyAPI('https://galaxy.server/api', ['v3'])

    assert not gapi_v2 < gapi
    assert not gapi_v2 < gapi_v2
    assert gapi_v2 < gapi_v3
    assert not gapi_v3 < gapi_v2

    gapi1 = GalaxyAPI('https://galaxy.server/api', ['v2', 'v3'])
    gapi2 = GalaxyAPI('https://galaxy.server/api2', ['v2', 'v3'])
    assert gapi1 < gapi2
    assert not gapi2 < gapi1



# Generated at 2022-06-20 14:39:58.588162
# Unit test for function g_connect
def test_g_connect():
    class MockGalaxy:
        def __init__(self, available_versions):
            self.available_versions = available_versions
            self.api_server = 'http://127.0.0.1'
            self.name = 'mock'

        def _call_galaxy(self, url, method=None, token=None, data=None, force_basic_auth=False, client_cert=None,
                         error_context_msg=None, cache=False):
            data = {'available_versions': self.available_versions}
            return data

    # Mock an endpoint without v1, should fail
    galaxy = MockGalaxy({u'v2': u'v2/'})
    method = g_connect(['v1'])(lambda x: True)

# Generated at 2022-06-20 14:40:01.002659
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    exc_obj = GalaxyError('', http_code=429, json_data={"code": "rate-limit-exceeded"})
    assert is_rate_limit_exception(exc_obj) is True



# Generated at 2022-06-20 14:40:40.605013
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    '''
    Unit test for method __repr__
    '''
    api_server = 'https://galaxy.ansible.com'
    token = 'testToken'

    # Test 1: Verify the __repr__ method with token
    galaxy_instance = GalaxyAPI(api_server, token)
    assert str(galaxy_instance) == 'GalaxyAPI<galaxy.ansible.com: <TOK> (default)>'

    # Test 2: Verify the __repr__ method without token
    galaxy_instance = GalaxyAPI(api_server)
    assert str(galaxy_instance) == 'GalaxyAPI<galaxy.ansible.com: <NO_TOK> (default)>'


# Generated at 2022-06-20 14:40:49.054538
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=499))
    assert not is_rate_limit_exception(GalaxyError(http_code=200))
    assert not isinstance(GalaxyError(http_code=429), GalaxyError)



# Generated at 2022-06-20 14:40:53.415677
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(code=429, http_code=429))
    assert is_rate_limit_exception(GalaxyError(code=520, http_code=520))
    assert not is_rate_limit_exception(GalaxyError(code=403, http_code=403))



# Generated at 2022-06-20 14:41:04.270169
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection_metadata = CollectionMetadata("namespace", "name", "version", "tarball_path", "download_url")
    assert_equal(collection_metadata.namespace, "namespace")
    assert_equal(collection_metadata.name, "name")
    assert_equal(collection_metadata.version, "version")
    assert_equal(collection_metadata.tarball_path, "tarball_path")
    assert_equal(collection_metadata.download_url, "download_url")


# Generated at 2022-06-20 14:41:08.239610
# Unit test for function cache_lock
def test_cache_lock():
    lock = threading.Lock()
    assert not lock.locked()
    with cache_lock(lock.acquire)():
        assert lock.locked()
    assert not lock.locked()



# Generated at 2022-06-20 14:41:15.170267
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    class_inst = GalaxyAPI()
    param_name_value_dict = {"name": "Galaxy", "api_server": "https://galaxy.example.com", "token": "mytoken"}
    class_inst.__init__(param_name_value_dict.get("name"), param_name_value_dict.get("api_server"), param_name_value_dict.get("token"))
    method_ret_val = class_inst.__repr__()
    assert method_ret_val is not None


# Generated at 2022-06-20 14:41:26.311386
# Unit test for function cache_lock
def test_cache_lock():
    lock = threading.Lock()
    call_count = 0
    func = lambda x: x + 1
    @cache_lock
    def wrapped(*args, **kwargs):
        with lock:
            nonlocal call_count
            call_count += 1
            return func(*args, **kwargs)

    threads = [
        threading.Thread(target=wrapped, args=(i,))
        for i in range(20)
    ]
    [t.start() for t in threads]
    [t.join() for t in threads]
    if call_count != 1:
        raise AssertionError('Expected function to have been called once, was called %d times' % call_count)



# Generated at 2022-06-20 14:41:33.932168
# Unit test for function g_connect
def test_g_connect():
    class con_class():
        def __init__(self):
            self.name = ''
            self.api_server = 'https://galaxy.ansible.com'
            self._available_api_versions = []
    connection_object1 = con_class()
    test_connection_g_connect(connection_object1)
    connection_object2 = con_class()
    connection_object2.api_server = 'https://galaxy.test.test'
    test_connection_g_connect(connection_object2, True)


# Generated at 2022-06-20 14:41:37.579697
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI(u'test1', u'test2')
    assert isinstance(repr(galaxy_api), str)


# Generated at 2022-06-20 14:41:47.599631
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429, message="Too Many Requests"))
    assert is_rate_limit_exception(GalaxyError(http_code=520, message="Too Many Requests"))
    assert not is_rate_limit_exception(GalaxyError(http_code=403, message="Forbidden"))
    assert not is_rate_limit_exception(GalaxyError(http_code=400, message="Bad Request"))
    assert not is_rate_limit_exception(GalaxyError(http_code=200, message="OK"))



# Generated at 2022-06-20 14:42:44.542661
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    test_obj = GalaxyAPI()

    assert str(test_obj) == 'GalaxyAPI()'


# Generated at 2022-06-20 14:42:48.317603
# Unit test for function g_connect
def test_g_connect():
    def _test_method(connection):
        return {'hello': 'world'}

    wrapped = g_connect(['v1'])(_test_method)
    assert wrapped(None) == {'hello': 'world'}



# Generated at 2022-06-20 14:42:55.930211
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    # Test case 1
    # Bug reported: https://github.com/ansible-community/ansible-galaxy/issues/1700
    c = CollectionMetadata("namespace", "name", created_str="2019-05-16T00:00:00", modified_str="2019-05-16T00:00:00")
    assert c.created == datetime.datetime(year=2019, month=5, day=16, hour=0, minute=0, second=0)
    assert c.modified == datetime.datetime(year=2019, month=5, day=16, hour=0, minute=0, second=0)

    # Test case 2
    # Bug reported: https://github.com/ansible-community/ansible-galaxy/issues/1700

# Generated at 2022-06-20 14:43:01.387137
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    """Test for constructor of class GalaxyError"""
    http_error = HTTPError(None, 404, None, None, None)
    message = "message"
    exception = GalaxyError(http_error, message)
    assert exception.http_code == 404
    assert exception.url == None
    assert exception.message == "message (HTTP Code: 404, Message: None)"



# Generated at 2022-06-20 14:43:16.249921
# Unit test for function g_connect
def test_g_connect():
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.error import HTTPError

    versions = [u'v1', u'v2']

    def mock_call_galaxy(url, *args, **kwargs):
        if url == 'https://galaxy.ansible.com/api/':
            return {u'available_versions': {u'v1': u'v1/'}}
        elif url == 'https://galaxy.ansible.com/api/v2/':
            return {u'available_versions': {u'v2': u'v2/'}}

# Generated at 2022-06-20 14:43:22.879166
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    data = {
        'namespace': 'namespace',
        'name': 'name',
        'created': '2015-03-20T18:27:57.295800Z',
        'modified': '2015-03-20T18:27:57.295800Z',
        'download_url': 'www.TestUrl.com',
        'artifact': 'artifact'
    }

    collection_metadata = CollectionMetadata(data['namespace'], data['name'], **data)

    collection_metadata.assert_equal(data)

# Generated at 2022-06-20 14:43:35.067778
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # API only Galaxy
    # Test https based API only
    api = GalaxyAPI('awx', server='https://example.com', api_key='api_key',
                    token='token', validate_certs=False)
    assert api.name == 'awx'
    assert api.server == 'https://example.com'
    assert api.api_key == 'api_key'
    assert api.token == 'token'
    assert not api.validate_certs
    assert not api.verbose
    assert api.ignore_certs
    assert not api.ignore_errors
    assert not api.force_basic_auth
    assert api.client_cert

    # Test insecure http based API

# Generated at 2022-06-20 14:43:47.968942
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert not is_rate_limit_exception(GalaxyError(http_code=500))
    assert not is_rate_limit_exception(GalaxyError(http_code=404))
    assert not is_rate_limit_exception(Exception())
    assert not is_rate_limit_exception(RuntimeError())



# Generated at 2022-06-20 14:43:56.220243
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    error = GalaxyError(b'{}', 'http://localhost', MockResponse(429, b"429: Too many requests"))
    assert is_rate_limit_exception(error)

    error = GalaxyError(b'{}', 'http://localhost', MockResponse(520, b"520: Too many requests"))
    assert is_rate_limit_exception(error)

    error = GalaxyError(b'{}', 'http://localhost', MockResponse(403, b"403: Too many requests"))
    assert not is_rate_limit_exception(error)

    assert not is_rate_limit_exception(AssertionError)
test_is_rate_limit_exception()
del test_is_rate_limit_exception



# Generated at 2022-06-20 14:44:00.157583
# Unit test for function g_connect
def test_g_connect():
    pass


# Generated at 2022-06-20 14:45:04.170860
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI()
    assert(galaxy_api.api_server == 'https://galaxy.ansible.com')
    assert(galaxy_api.galaxy_ignore_certs is False)



# Generated at 2022-06-20 14:45:07.782645
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    '''
    Unit test for method __lt__ of class GalaxyAPI
    '''
    api = GalaxyAPI()
    result = api.__lt__() # Stub for test implementation.
    assert result == False # Incomplete test


# Generated at 2022-06-20 14:45:17.356256
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    collection_name = 'galaxy-collection'
    collection_namespace = 'galaxy-namespace'
    username = 'galaxy-username'
    version = '1.0.0'
    versions_list = ['1.0.0']

    api_server = 'https://galaxy-server/'
    galaxy_api = GalaxyAPI(api_server, username)
    collection_info = {
        'namespace': collection_namespace,
        'name': collection_name,
        'version': version,
        'versions': versions_list,
        'download_url': 'https://galaxy-server/galaxy-namespace/galaxy-collection/{0}/'.format(version),
        'summary': 'dummy summary for unit test',
        'authors': ['galaxy-author'],
    }

# Generated at 2022-06-20 14:45:30.111381
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    first_metadata = CollectionMetadata('mynamespace', 'mycollection',
                                        modified_str='2018-05-24T17:09:39.486623Z',
                                        created_str='2018-05-24T17:09:39.486623Z')
    assert first_metadata.namespace == 'mynamespace'
    assert first_metadata.name == 'mycollection'
    assert first_metadata.modified_str == '2018-05-24T17:09:39.486623Z'
    assert first_metadata.created_str == '2018-05-24T17:09:39.486623Z'


# Generated at 2022-06-20 14:45:36.120947
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    e = GalaxyError("Test", http_code=403)
    assert is_rate_limit_exception(e) is False
    e = GalaxyError("Test", http_code=429)
    assert is_rate_limit_exception(e) is True
    e = GalaxyError("Test", http_code=520)
    assert is_rate_limit_exception(e) is True


# Generated at 2022-06-20 14:45:39.469616
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    api = GalaxyAPI(name='test', server='test.com')
    assert api.name == 'test'
    assert api.api_server == 'test.com'
    return api


# Generated at 2022-06-20 14:45:51.122033
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'james.test'
    name = 'test'
    version = '0.0.1'
    download_url = 'https://github.com/ansible-collections/example.tar.gz'
    artifact_sha256 = 'b0df8c2b0ae1ac7ef1e0134c058ef3f4d73c4f9c973b8e2c0f1e7ac2dcd6c5fc'
    dependencies = {
        'collection_name': 'collection_version'
    }

    metadata = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)

    assert metadata.namespace == namespace
    assert metadata.name == name
    assert metadata.version == version
    assert metadata.download_url == download_url

# Generated at 2022-06-20 14:46:04.533608
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    """
    Test the constructur of class CollectionMetadata
    """
    metadata = CollectionMetadata('collection_namespace', 'collection_name', 'https://example.com/collections/collection_namespace/collection_name/', '2020-07-07T14:22:16.206903Z', '2020-07-07T14:22:16.206903Z')
    assert metadata.namespace == 'collection_namespace'
    assert metadata.name == 'collection_name'
    assert metadata.created_str == '2020-07-07T14:22:16.206903Z'
    assert metadata.modified_str == '2020-07-07T14:22:16.206903Z'
    assert metadata.url == 'https://example.com/collections/collection_namespace/collection_name/'



# Generated at 2022-06-20 14:46:07.598335
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI('https://galaxy.example.com')
    assert to_text(api) == 'Galaxy server https://galaxy.example.com'

    api = GalaxyAPI('https://galaxy.example.com', name='Test Galaxy')
    assert to_text(api) == 'Test Galaxy server https://galaxy.example.com'
