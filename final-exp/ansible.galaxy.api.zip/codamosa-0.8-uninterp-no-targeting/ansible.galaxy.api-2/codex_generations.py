

# Generated at 2022-06-20 14:37:24.255505
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI('name', 'https://localhost')
    assert str(api).startswith("[GalaxyAPI]") is True

# Unit test Galaxy.yml parsing functions

# Generated at 2022-06-20 14:37:37.480457
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """
    Unit test for the GalaxyAPI class.
    """
    # Verify basic initializations are possible
    _ = GalaxyAPI(server="https://galaxy.ansible.com/", token="", ignore_certs=True, api_server="https://galaxy.ansible.com/")
    _ = GalaxyAPI(server="https://galaxy.ansible.com/", ignore_certs=True)

    # Verify error checking
    with pytest.raises(AnsibleError):
        _ = GalaxyAPI()

    with pytest.raises(AnsibleError):
        _ = GalaxyAPI(url="https://galaxy.ansible.com/")

    # Verify proper conversion of ignore_certs to boolean
    galaxy_api = GalaxyAPI(server="https://localhost:12345/", ignore_certs="True")

# Generated at 2022-06-20 14:37:39.509191
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Make sure that we can instantiate GalaxyAPI without errors
    g_api = GalaxyAPI('http://example.com')

    # TODO: Add more tests
    assert g_api is not None


# Generated at 2022-06-20 14:37:48.821441
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    error = GalaxyError()
    error.http_code = 429
    assert is_rate_limit_exception(error)



# Generated at 2022-06-20 14:37:58.679545
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    namespace = 'namespace_test'
    name = 'name_test'
    created_str = '2020-06-17T04:08:41.965357'
    modified_str = '2020-06-17T04:08:41.965357'
    collection_metadata = CollectionMetadata(namespace, name, created_str, modified_str)
    # Results when execute "str(collection_metadata)"
    # CollectionMetadata: ansible.namespace_test.name_test created at 2020-06-17T04:08:41.965357
    # modified at 2020-06-17T04:08:41.965357

# Generated at 2022-06-20 14:38:02.895527
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # This should raise an exception if something is wrong
    a = GalaxyAPI('a')
    b = GalaxyAPI('b')
    a.__lt__(b)



# Generated at 2022-06-20 14:38:15.061413
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    # Test that the comparers are in alphabetical order for the name
    assert(GalaxyAPI('a') < GalaxyAPI('b'))
    assert(not GalaxyAPI('b') < GalaxyAPI('a'))

    assert(GalaxyAPI('a') < GalaxyAPI('a', url='http://b'))
    assert(not GalaxyAPI('a', url='http://b') < GalaxyAPI('a'))

    assert(GalaxyAPI('a') < GalaxyAPI('a', url='http://b', api_server='http://c'))
    assert(not GalaxyAPI('a', url='http://b', api_server='http://c') < GalaxyAPI('a'))


# Generated at 2022-06-20 14:38:22.021811
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError('', http_code=429))
    assert not is_rate_limit_exception(GalaxyError('', http_code=404))
test_is_rate_limit_exception()



# Generated at 2022-06-20 14:38:29.861057
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI()
    api.api_server = 'test-server'
    rv = api.__repr__()
    assert rv == 'GalaxyAPI(api_server=%r)' % api.api_server

# Generated at 2022-06-20 14:38:33.927887
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    exception = GalaxyError('test message', http_code=429)
    assert is_rate_limit_exception(exception)
    exception = GalaxyError('test message', http_code=520)
    assert is_rate_limit_exception(exception)



# Generated at 2022-06-20 14:39:04.720941
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error = Exception()
    error.code = 500
    error.url = 'https://galaxy.ansible.com/api/v1/'
    error.read = lambda: b'{"default": "Foo bar"}'

    g_error = GalaxyError(error, "Test for GalaxyError")
    assert g_error.http_code == 500
    assert g_error.url == 'https://galaxy.ansible.com/api/v1/'
    assert g_error.message == "Test for GalaxyError (HTTP Code: 500, Message: Foo bar)"



# Generated at 2022-06-20 14:39:15.182219
# Unit test for function cache_lock
def test_cache_lock():
    import mock
    import test.utils.ansible_runner
    called_with = []

    @cache_lock
    def func(*args, **kwargs):
        called_with.append((args, kwargs))

    with mock.patch('ansible_collections.ansible.galaxy.plugins.module_utils.urls.open_url',
                    side_effect=[mock.MagicMock() for _ in range(3)]):
        func('1', b=2)
        func('3', b=4)
        func('5', b=6)

    assert len(called_with) == 3

# Generated at 2022-06-20 14:39:19.364494
# Unit test for function cache_lock
def test_cache_lock():
    lock = threading.Lock()
    with lock:
        assert lock.locked()



# Generated at 2022-06-20 14:39:23.920125
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    namespace = 'ansible_namespace'
    name = 'collection_name'
    collection_metadata = CollectionMetadata(namespace, name)
    assert collection_metadata.namespace == namespace
    assert collection_metadata.name == name
    assert collection_metadata.created_str == None
    assert collection_metadata.modified_str == None


# Generated at 2022-06-20 14:39:31.200250
# Unit test for function get_cache_id
def test_get_cache_id():
    url = 'https://api.github.com/repos/ansible/ansible/releases/tags/v2.7.13'
    cache_id = get_cache_id(url)
    assert cache_id == 'api.github.com:None'



# Generated at 2022-06-20 14:39:35.027483
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        return 'Hello'
    assert test_func() == 'Hello'


# Generated at 2022-06-20 14:39:41.708700
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    cm = CollectionMetadata('namespace', 'name', 'version', 'tarball_url',
                            'tarball_sha256', 'dependencies')
    assert cm.namespace == 'namespace'
    assert cm.name == 'name'
    assert cm.version == 'version'
    assert cm.tarball_url == 'tarball_url'
    assert cm.tarball_sha256 == 'tarball_sha256'
    assert cm.dependencies == 'dependencies'



# Generated at 2022-06-20 14:39:49.274346
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    with pytest.raises(GalaxyClientError):
        # incorrect protocol
        GalaxyAPI('https://galaxy.server/api', 'myuser', None, 'mytoken')

    with pytest.raises(GalaxyClientError):
        # incorrect protocol
        GalaxyAPI('http://galaxy.server/api', 'myuser', None, 'mytoken')

    with pytest.raises(GalaxyClientError):
        # no username or token specified
        GalaxyAPI('http://galaxy.server/api')

    with pytest.raises(GalaxyClientError):
        # list of API versions specified
        GalaxyAPI('http://galaxy.server/api', None, ['v1', 'v2'])


# Generated at 2022-06-20 14:39:53.783762
# Unit test for function g_connect
def test_g_connect():
    from ansible.galaxy.api import GalaxyAPI
    galaxy_api = GalaxyAPI()
    galaxy_api.name = "galaxy.ansible.com"
    galaxy_api.api_server = "https://galaxy.ansible.com"
    galaxy_api.role_name = "ansible"
    galaxy_api._available_api_versions = {}
    galaxy_api._user_agent = user_agent
    return galaxy_api


# Generated at 2022-06-20 14:39:54.155831
# Unit test for function g_connect
def test_g_connect():
    pass

# Generated at 2022-06-20 14:40:54.317067
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Constructor
    tmpdir = tempfile.mkdtemp()
    gi = GalaxyAPI(tmpdir)
    assert gi
    assert isinstance(gi, GalaxyAPI)
    assert isinstance(gi, GalaxyClient)
    assert gi.cache_path
    assert gi.cache_path == tmpdir
    # tear down
    shutil.rmtree(tmpdir)



# Generated at 2022-06-20 14:41:03.602560
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    code = 404
    http_reason = "Not found"
    message = "Unable to create collection"
    http_error = HTTPError("", code, http_reason, None, None)
    err_info = {}
    err_info["message"] = http_reason

    galaxy_error = GalaxyError(http_error, message)
    galaxy_msg = galaxy_error.message
    assert galaxy_msg == "Unable to create collection (HTTP Code: 404, Message: Not found Code: Unknown)"

# Unit tests for _urljoin

# Generated at 2022-06-20 14:41:10.277128
# Unit test for function cache_lock
def test_cache_lock():
    called = False

    @cache_lock
    def func():
        nonlocal called
        called = True

    func()
    assert called


# cache-file locks to prevent concurrent updates - this is to support the cache_lock
# decorator.
#
# NOTE: The locking scheme below is advisory only. Multiple processes can still
#       attempt to access the cache file at the same time. The locking scheme
#       below only prevents those processes that use this module and utilize the
#       cache_lock decorator.
#

# Generated at 2022-06-20 14:41:17.727323
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    from urllib.parse import urlparse
    from urllib.parse import urlsplit

    galaxy_api = GalaxyAPI('galaxy.server.com', '123', 'https', 'user@email.com', 'pass')
    assert galaxy_api.name == 'galaxy.server.com'
    assert galaxy_api.token == '123'
    assert galaxy_api.url == 'https://galaxy.server.com'
    assert galaxy_api.api_server == 'https://galaxy.server.com'
    assert galaxy_api.api_key is None
    assert galaxy_api.username == 'user@email.com'
    assert galaxy_api.password == 'pass'

    galaxy_api = GalaxyAPI('api.galaxy.com', None, None, None, None, 'http://galaxy.server.com')


# Generated at 2022-06-20 14:41:24.263215
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy_api = GalaxyAPI('https://galaxy.server.org')

    assert galaxy_api.name == 'https://galaxy.server.org'
    assert galaxy_api.api_server == 'https://galaxy.server.org'
    assert not galaxy_api.ignore_certs
    assert galaxy_api.token == ''
    assert not galaxy_api.verify_ssl


# Generated at 2022-06-20 14:41:30.129512
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert not is_rate_limit_exception(GalaxyError(http_code=403))
    assert is_rate_limit_exception(GalaxyError(http_code=429))
    assert is_rate_limit_exception(GalaxyError(http_code=520))
# End unit test for function is_rate_limit_exception



# Generated at 2022-06-20 14:41:38.475348
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    g_str = to_native(GalaxyAPI(galaxy_server='foo', name='bar'))
    expected = "GalaxyAPI('foo', 'bar')"
    assert g_str == expected, 'GalaxyAPI string representation mismatch. Expected: %s, Actual: %s' % (expected, g_str)


# Generated at 2022-06-20 14:41:43.964259
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_api = GalaxyAPI("galaxy_server", "api_server", "token")
    ast.literal_eval(repr(galaxy_api))
    galaxy_api = GalaxyAPI("galaxy_server", "api_server", "token", True)
    ast.literal_eval(repr(galaxy_api))

# Generated at 2022-06-20 14:41:52.611591
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://galaxy.ansible.com') == 'galaxy.ansible.com:443'
    assert get_cache_id('http://galaxy.ansible.com/') == 'galaxy.ansible.com:80'



# Generated at 2022-06-20 14:41:54.684842
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    GalaxyAPI.__repr__()

# Generated at 2022-06-20 14:42:38.959755
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    meta = CollectionMetadata(u'namespace', u'name', u'created', u'modified')
    assert meta.namespace == u'namespace'
    assert meta.name == u'name'
    assert meta.created_str == u'created'
    assert meta.modified_str == u'modified'


# Generated at 2022-06-20 14:42:39.701510
# Unit test for function g_connect
def test_g_connect():
    # TODO
    pass

# Generated at 2022-06-20 14:42:52.222864
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    namespace = 'ns'
    name = 'name'
    created = '1/1/2018'
    modified = '2/2/2018'
    cm = CollectionMetadata(namespace, name, created_str=created, modified_str=modified)

    assert cm.name == name
    assert cm.namespace == namespace
    assert cm.created_str == created
    assert cm.modified_str == modified
    assert cm.created_at == time.mktime(time.strptime(cm.created_str, DATE_FORMAT))
    assert cm.modified_at == time.mktime(time.strptime(cm.modified_str, DATE_FORMAT))

    cm = CollectionMetadata(namespace, name, created_at=created, modified_at=modified)

    assert cm.created_str == time.strftime

# Generated at 2022-06-20 14:42:54.253717
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api = GalaxyAPI(None, {})
    assert api.__lt__(None) is NotImplemented

# Generated at 2022-06-20 14:43:03.793914
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    hostname = 'galaxy.ansible.com'
    error_type = GalaxyError
    message = 'GalaxyError'
    message_v2 = 'An error occurred while running the search API call'
    message_v3 = 'An error occurred while running the search API call'

    he = HTTPError('https://galaxy.ansible.com/api/', 500, 'Internal Server Error', None, None)
    he.read = lambda: '{"default": "Internal Server Error"}'
    e = GalaxyError(he, message)
    assert e.http_code == 500
    assert e.url == 'https://galaxy.ansible.com/api/'
    assert e.message == 'GalaxyError (HTTP Code: 500, Message: Internal Server Error)'


# Generated at 2022-06-20 14:43:16.334802
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """
    test_GalaxyAPI is a unit test for the constructor of the GalaxyAPI class.
    :return: Nothing
    """

    valid_urls = [
        'http://galaxy.ansible.com',
        'https://galaxy.ansible.com',
        'http://galaxy.ansible.com:8080',
        'http://my.galaxy.server.example.org',
        'http://localhost:8080',
        'http://127.0.0.1:8080',
        'http://127.0.0.1',
    ]

    invalid_urls = [
        'http://galaxy.ansible.com:',
        'example.org',
        'localhost',
    ]


# Generated at 2022-06-20 14:43:24.820527
# Unit test for function get_cache_id
def test_get_cache_id():
    urls = ['http://example.com/', 'http://example.com:123/', 'https://user:pass@example.com/',
            'https://user:pass@example.com:123/', 'https://user:@example.com:123/']
    results = ['example.com', 'example.com:123', 'example.com', 'example.com:123', 'example.com:123']

    # "Normal" cases
    for u, r in zip(urls, results):
        cache_id = get_cache_id(u)
        assert cache_id == r, 'url: "%s" expected result: "%s" received result: "%s"' % (u, r, cache_id)

    # Invalid URL
    cache_id = get_cache_id('http://')

# Generated at 2022-06-20 14:43:29.000297
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    g_api = GalaxyAPI('server', 'name', 'https://example.com', [])
    assert str(g_api) == 'https://example.com', 'Test should have succeeded because server and name have the right value'

# Generated at 2022-06-20 14:43:38.565710
# Unit test for function get_cache_id
def test_get_cache_id():
    cache_id = 'https://galaxy.ansible.com'
    assert(get_cache_id(cache_id) == 'galaxy.ansible.com:')

    cache_id = 'https://galaxy.ansible.com:443'
    assert(get_cache_id(cache_id) == 'galaxy.ansible.com:443')

    cache_id = 'https://galaxy.ansible.com:80'
    assert(get_cache_id(cache_id) == 'galaxy.ansible.com:80')

    cache_id = 'https://galaxy.ansible.com:162'
    assert(get_cache_id(cache_id) == 'galaxy.ansible.com:162')



# Generated at 2022-06-20 14:43:41.868585
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    api1 = GalaxyAPI('galaxy.ansible.com', 'http://api.ansible.com')
    api2 = GalaxyAPI('galaxy.ansible.com', 'http://api.ansible.com')
    assert api1 == api2
    assert api2 == api1



# Generated at 2022-06-20 14:44:25.532774
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    _CACHE_LOCK = threading.Lock()
    assert not _CACHE_LOCK.locked()
    with _CACHE_LOCK:
        assert _CACHE_LOCK.locked()
    assert not _CACHE_LOCK.locked()
    @cache_lock
    def test_func():
        pass

    assert not _CACHE_LOCK.locked()
    test_func()
    assert not _CACHE_LOCK.locked()


# Generated at 2022-06-20 14:44:33.075069
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    rate_limit_error = GalaxyError(http_code=429, http_message='Rate Limit', message='Unauthorized')
    forbidden_error = GalaxyError(http_code=403, http_message='Forbidden', message='Unauthorized')
    assert is_rate_limit_exception(rate_limit_error)
    assert not is_rate_limit_exception(forbidden_error)



# Generated at 2022-06-20 14:44:34.391347
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    assert CollectionVersionMetadata('namespace','name','version','download_url','artifact_sha256','dependencies')



# Generated at 2022-06-20 14:44:42.237587
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI(name='foo', api_server="http://galaxy.ansible.com", api_token="bar")
    assert repr(galaxy_api) == "GalaxyAPI(name='foo', api_server='http://galaxy.ansible.com', token='************')"


# Generated at 2022-06-20 14:44:48.751771
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # The proper way to instantiate a GalaxyAPI object is by calling its
    # constructor . The constructor of the GalaxyAPI class takes a parameter
    # self. A potential value for this parameter is "galaxyapi_0".
    galaxyapi_0 = GalaxyAPI(self="galaxyapi_0")

    expected_result = "GalaxyAPI object"
    result = galaxyapi_0.__repr__()

    assert expected_result == result

# Generated at 2022-06-20 14:44:54.759598
# Unit test for function cache_lock
def test_cache_lock():
    import mock

    def test_func(arg1, arg2):
        return arg1, arg2

    o_test_func = cache_lock(test_func)
    with mock.patch.object(threading.Lock, '__exit__') as mock_exit:
        result = o_test_func(1, 2)
        assert result == (1, 2)
        assert mock_exit.call_count == 1



# Generated at 2022-06-20 14:44:59.961930
# Unit test for function cache_lock
def test_cache_lock():
    global _CACHE_LOCK
    _CACHE_LOCK = FakeLock()
    lock = _CACHE_LOCK

    @cache_lock
    def test():
        return True

    assert lock.acquired == 2
    assert test()



# Generated at 2022-06-20 14:45:03.064177
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    namespace = 'ansible_namespace'
    name = 'ansible_collection'
    collection_metadata = CollectionMetadata(namespace, name)
    assert collection_metadata.namespace == namespace
    assert collection_metadata.name == name
    assert collection_metadata.created_str is None
    assert collection_metadata.modified_str is None


# Generated at 2022-06-20 14:45:13.844681
# Unit test for function g_connect

# Generated at 2022-06-20 14:45:27.129486
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    # Test for Version V2
    data = {
        "namespace": "test1",
        "name": "test2",
        "version": "test3",
        "download_url": "test4",
        "artifact_sha256": "test5",
        "dependencies": [
            {
                "namespace": "test6",
                "name": "test7",
                "version_specifier": "test8"
            }
        ]
    }
    collection_version_metadata = CollectionVersionMetadata(
        data["namespace"], data["name"], data["version"], data["download_url"], data["artifact_sha256"], data["dependencies"]
    )
    assert collection_version_metadata.namespace == data["namespace"]
    assert collection_version_metadata.name == data["name"]