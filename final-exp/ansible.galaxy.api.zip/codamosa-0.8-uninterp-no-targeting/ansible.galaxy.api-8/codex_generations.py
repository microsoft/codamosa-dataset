

# Generated at 2022-06-20 14:37:37.213078
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    local_server = GalaxyAPI(
        url='https://galaxy.server.com',
        token='some_token',
        ignore_certs=True,
    )
    assert 'GalaxyAPI object: https://galaxy.server.com' == str(local_server)

    local_server = GalaxyAPI(
        url='https://galaxy.server.com',
        token='some_token',
        ignore_certs=False,
        validate_certs=True,
    )
    assert 'GalaxyAPI object: https://galaxy.server.com' == str(local_server)


# Generated at 2022-06-20 14:37:43.793127
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # HTTP error code
    err = GalaxyError(status_code='429', message='Too many requests')
    assert is_rate_limit_exception(err)
    # Galaxy error code
    err = GalaxyError(status_code='520', message='Galaxy rate limit error')
    assert is_rate_limit_exception(err)



# Generated at 2022-06-20 14:37:47.409510
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    fixture_data = {
        'name': 'test',
        'api_server': 'http://server.com/',
        'ignore_certs': True,
    }
    galaxy_api_obj = GalaxyAPI(**fixture_data)

    assert repr(galaxy_api_obj) == 'GalaxyAPI(name=test, api_server=http://server.com/, ignore_certs=True)'



# Generated at 2022-06-20 14:37:58.078641
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    given_namespace = "test-namespace"
    given_name = "test-name"
    given_version = "1.1.1"
    given_download_url = "https://github.com/test-user/test-collection"
    given_artifact_sha256 = "279bde590da379e1af02ec2d07328c92c831dbfdcbbcced9420024f117cc6dda"
    given_dependencies = {"collection1":{"name":"collection1", "version_string":"1.0"}, "collection2":{"name":"collection2", "version_string":"2.0"}}


# Generated at 2022-06-20 14:38:00.843911
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def test_func():
        pass
    test_func()



# Generated at 2022-06-20 14:38:03.375897
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    exception = GalaxyError(http_code=429)
    assert is_rate_limit_exception(exception)



# Generated at 2022-06-20 14:38:08.108023
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api_server_url = 'https://ansible.galaxy.server.example'
    galaxy_api = GalaxyAPI(api_server_url)
    assert str(galaxy_api) == 'Galaxy API object: https://ansible.galaxy.server.example'



# Generated at 2022-06-20 14:38:12.249061
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    metadata = CollectionVersionMetadata("namespace", "name", "version", "download_url", "sha256_string", {'foo': 'bar'})
    assert metadata.namespace == "namespace"
    assert metadata.name == "name"
    assert metadata.version == "version"
    assert metadata.download_url == "download_url"
    assert metadata.artifact_sha256 == "sha256_string"
    assert metadata.dependencies == {'foo': 'bar'}

test_CollectionVersionMetadata() 



# Generated at 2022-06-20 14:38:14.959589
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI(api_server='https://galaxy.example.org', name='galaxy_name', token='token')
    expected = "<GalaxyAPI galaxy_name(https://galaxy.example.org)>"
    # Test if __repr__ returns the correct value
    assert str(galaxy_api) == expected


# Generated at 2022-06-20 14:38:20.948757
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    api = GalaxyAPI(api_server='http://example.com', ignore_certs=False, validate_certs=False)

    result = api.__unicode__()

    assert isinstance(result, str)
    assert result == 'GalaxyAPI(name=None, api_server=http://example.com)'


# Generated at 2022-06-20 14:38:52.482210
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    """Unit test for method ``GalaxyAPI.__unicode__``."""
    galaxy_api = GalaxyAPI('Ansible', 'https://galaxy.ansible.com')

    # For debugging
    assert str(galaxy_api) == "GalaxyAPI('Ansible', 'https://galaxy.ansible.com')"


# Generated at 2022-06-20 14:39:04.438077
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # http_code of API V1 endpoint
    http_code = 500
    http_error = HTTPError("http://localhost/api/v1/", http_code, "Internal server error", {}, None)
    message = "Error when trying to get roles list from Galaxy"
    galaxy_error = GalaxyError(http_error, message)
    assert(galaxy_error.http_code == http_code)
    assert(galaxy_error.url == "http://localhost/api/v1/")
    assert(galaxy_error.message == "Error when trying to get roles list from Galaxy (HTTP Code: 500, Message: Internal server error)")

    # http_code of API V2 endpoint
    http_code = 500

# Generated at 2022-06-20 14:39:11.966803
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    display.display("TESTING: test_GalaxyAPI___str__")
    c = GalaxyAPI()
    c.name = "GalaxyAPI"
    c.api_server = "https://galaxy.server.com"
    c.api_token = "12345"
    c.ssl_verify = False
    # test the GalaxyAPI str method
    assert c.__str__() == "GalaxyAPI(galaxy.server.com)"



# Generated at 2022-06-20 14:39:13.887210
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    assert is_rate_limit_exception(GalaxyError("", 429, ""))
    assert not is_rate_limit_exception(GalaxyError("", 400, ""))



# Generated at 2022-06-20 14:39:15.754572
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI(name='galaxy')
    expected_result = "GalaxyAPI(galaxy)"
    assert expected_result == to_native(galaxy_api)



# Generated at 2022-06-20 14:39:20.634033
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    # TODO: add tests
    pass


# Generated at 2022-06-20 14:39:26.357358
# Unit test for function cache_lock
def test_cache_lock():
    class TestClass(object):
        @cache_lock
        def callme(self):
            self.called = True

    test = TestClass()
    with pytest.raises(RuntimeError):
        test.callme()

    global _CACHE_LOCK
    _CACHE_LOCK = threading.Lock()
    test.callme()
    assert test.called



# Generated at 2022-06-20 14:39:29.727757
# Unit test for function cache_lock
def test_cache_lock():
    for n in range(10):
        func = cache_lock(lambda: n)
        assert func() == n



# Generated at 2022-06-20 14:39:35.567629
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    reason = 'reason'
    http_error = HTTPError('http://example.com', 404, reason, {}, StringIO(''))
    message = GalaxyError(http_error, 'message')

    assert message.http_code == 404
    assert reason in message.message



# Generated at 2022-06-20 14:39:45.723707
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    version = "1.2.3"
    download_url = "https://localhost/"
    artifact_sha256 = "8b9942a8a2a5725dbcadf44f2c626c3a3d0a96b244d1b8fa1e0c134f9ae3a277"
    dependencies = {"namespace":"ansible","name":"collection","version":"1.2.3","collection_artifact": {"sha256": "8b9942a8a2a5725dbcadf44f2c626c3a3d0a96b244d1b8fa1e0c134f9ae3a277","download_url": "https://localhost/"}}
    meta = CollectionVersionMetadata("namespace", "name", version, download_url, artifact_sha256, dependencies)

# Generated at 2022-06-20 14:40:34.387004
# Unit test for function g_connect
def test_g_connect():
    class FakeGalaxy:
        def __init__(self, name):
            self.name = name
            self.api_server = 'https://galaxy.ansible.com'
            self._available_api_versions = {}

        def _call_galaxy(self, *args, **kwargs):
            pass

    # Method should be decorated by the versions: ["v2"]
    @g_connect(versions=["v2"])
    def _test(self):
        pass

    # Should not raise.
    _test(FakeGalaxy('galaxy'), 'v2')

    # Should raise with message that the required versions are not supported.

# Generated at 2022-06-20 14:40:44.380583
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    # Negative test
    with pytest.raises(AnsibleError):
        cmta = CollectionMetadata('namespace', 'name', None, None, None, None, None, None)

    # Negative test
    with pytest.raises(AnsibleError):
        cmta = CollectionMetadata(None, 'name', None, None, None, None, None, None)

    # Negative test
    with pytest.raises(AnsibleError):
        cmta = CollectionMetadata('namespace', None, None, None, None, None, None, None)

    # Positive test
    cmta = CollectionMetadata('namespace', 'name', 'link', 'date', 'desc', ['dep1', 'dep2'], ['tag1', 'tag2'], '4')


# Generated at 2022-06-20 14:40:54.282927
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    class HTTPError(object):
        def __init__(self, code, reason, url=None):
            self.code = code
            self.reason = reason
            self.url = url

        def read(self):
            pass

        def geturl(self):
            return self.url

    class HTTPError_v2(object):
        def __init__(self, code, reason, url=None):
            self.code = code
            self.reason = reason
            self.url = url

        def read(self):
            return '{"message": "Test message", "code": "Test code", "default": "Test default"}'

        def geturl(self):
            return self.url

    ge_1 = GalaxyError(HTTPError('500', 'Test reason'), 'Test message 1')

# Generated at 2022-06-20 14:40:56.997135
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    CollectionVersionMetadata("foo", "bar", "v1.0.0", "https://galaxy.com", "hash", {})


# Generated at 2022-06-20 14:40:57.844325
# Unit test for function g_connect
def test_g_connect():
    pass



# Generated at 2022-06-20 14:41:04.212088
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    # Given
    test_galaxyapi = GalaxyAPI()
    test_galaxyapi.api_server = "http://api.galaxy.com"
    # When
    test_return = str(test_galaxyapi)
    desired_return = "Galaxy API server at 'http://api.galaxy.com'"
    # Then
    assert test_return == desired_return

# Generated at 2022-06-20 14:41:12.928912
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    c = CollectionMetadata('ns1', 'c1', '2015-07-06T00:42:35.711+00:00', '2016-07-06T00:42:35.711+00:00')
    assert c.namespace == 'ns1'
    assert c.name == 'c1'
    assert c.created_str == '2015-07-06T00:42:35.711+00:00'
    assert c.modified_str == '2016-07-06T00:42:35.711+00:00'



# Generated at 2022-06-20 14:41:25.074003
# Unit test for function cache_lock
def test_cache_lock():
    caller_lock = threading.Lock()
    called_lock = threading.Lock()
    caller_lock.acquire()
    called_lock.acquire()

    @cache_lock
    def called():
        caller_lock.release()
        called_lock.acquire()

    called_thread = threading.Thread(target=called)
    called_thread.start()

    caller_lock.acquire()
    assert called_lock.acquire(blocking=False)
    called_lock.release()
    called_thread.join()



# Generated at 2022-06-20 14:41:35.515166
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Test the constructor of class GalaxyAPI
    mocker_open = mock_open(read_data='{"server": "https://galaxy.ansible.com"}')
    mocker_open.return_value.__iter__ = lambda self: self
    mocker_open.return_value.__next__ = lambda self: next(iter(self.readline, ''))
    with patch('ansible.module_utils.six.moves.builtins.open', mocker_open, create=True):
        galaxy = GalaxyAPI()

    # Test the available_api_versions of the class
    assert galaxy.available_api_versions['v3'] == '/api/v3/'

    # Test the __repr__ of the class

# Generated at 2022-06-20 14:41:42.710335
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    meta = CollectionMetadata(namespace='namespace_test', name='name_test', created_str='create_test',
                              modified_str='modified_test')
    assert meta.namespace == 'namespace_test'
    assert meta.name == 'name_test'
    assert meta.created_str == 'create_test'
    assert meta.modified_str == 'modified_test'


# Generated at 2022-06-20 14:42:52.932421
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    first_gapi = GalaxyAPI('name', 'api_token', 'api_server')
    second_gapi = GalaxyAPI('name', 'api_token', 'api_server')

    # First with a different name
    second_gapi.name = 'other'
    assert second_gapi.__lt__(first_gapi)
    first_gapi.name = 'other'
    assert not second_gapi.__lt__(first_gapi)

    # Then with a different server
    second_gapi.api_server = 'https://api.galaxy.ansible.com'
    assert not second_gapi.__lt__(first_gapi)
    first_gapi.api_server = 'https://api.galaxy.ansible.com'

# Generated at 2022-06-20 14:43:01.689420
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'n1'
    name = 'n1'
    version = '1.0.0'
    download_url = 'http://ansible.com/download/artifact'
    artifact_sha256 = 'd4ec2174a2b0c5760ad7d4cad21bcf20cd955c918e6078d0f641232c2396b72c'
    dependencies = {
        'namespace1': {
            'name1': {
                'collection': 'collection1',
                'version_range': '1.0.0',
            },
            'name2': {
                'collection': 'collection2',
                'version_range': '2.0.0',
            },
        },
    }

# Generated at 2022-06-20 14:43:13.667921
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    # Test invalid constructor call (all required fields are None)
    invalid_collection_metadata = CollectionMetadata()
    assert invalid_collection_metadata is None

    # Test constructor call with all parameters
    collection_metadata = CollectionMetadata('namespace', 'name', 'version', 'created_str', 'modified_str')

    assert collection_metadata.namespace == 'namespace'
    assert collection_metadata.name == 'name'
    assert collection_metadata.version == 'version'
    assert collection_metadata.created_str == 'created_str'
    assert collection_metadata.modified_str == 'modified_str'



# Generated at 2022-06-20 14:43:22.806475
# Unit test for function get_cache_id
def test_get_cache_id():
    # Along with a port number and without a port number.
    url_info = 'https://galaxy.ansible.com:443/api/'
    url_info_wo_port = 'https://galaxy.ansible.com/api/'
    cache_id = get_cache_id(url_info)
    assert cache_id == 'galaxy.ansible.com:443'
    cache_id = get_cache_id(url_info_wo_port)
    assert cache_id == 'galaxy.ansible.com'
    # Test URL with credentials in it.
    url_info = 'https://galaxy.ansible.com@123:12345/api/'
    cache_id = get_cache_id(url_info)

# Generated at 2022-06-20 14:43:35.021177
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    base_error_msg = "This is a test."
    error_msg = "This is an error."
    http_error = HTTPError("https://127.0.0.1:443/api/", 500, base_error_msg, None, None)
    # Galaxy API v1
    try:
        raise GalaxyError(http_error, error_msg)
    except GalaxyError as ge:
        assert ge.message == "%s (HTTP Code: %d, Message: %s)" % (error_msg, http_error.code, base_error_msg)
    # Galaxy API v2

# Generated at 2022-06-20 14:43:46.558003
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    metadata = CollectionVersionMetadata('namespace', 'name', 'version', 'download_url', 'artifact_sha256', 'dependencies')
    assert metadata.namespace == 'namespace'
    assert metadata.name == 'name'
    assert metadata.version == 'version'
    assert metadata.download_url == 'download_url'
    assert metadata.artifact_sha256 == 'artifact_sha256'
    assert metadata.dependencies == 'dependencies'

test_CollectionVersionMetadata()



# Generated at 2022-06-20 14:43:57.946041
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    from ansible.module_utils._text import to_text
    expected_dict = {
        "created_str": "2020-01-12T14:04:11.459814Z",
        "description": "This is a simple collection.",
        "full_name": "mynamespace.mycollectionname",
        "modified_str": "2020-01-12T14:04:11.459814Z",
        "name": "mycollectionname",
        "namespace": "mynamespace",
        "readme": "This is the contents of the readme.",
    }
    metadata = CollectionMetadata(expected_dict['namespace'], expected_dict['name'], **expected_dict)
    test_dict = metadata.to_dict()

# Generated at 2022-06-20 14:44:00.286341
# Unit test for function cache_lock
def test_cache_lock():
    @cache_lock
    def some_func():
        pass
    assert some_func.__name__ == 'wrapped'
    assert some_func.__doc__ == 'wrapper function for function cache_lock'



# Generated at 2022-06-20 14:44:07.445864
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'johndoe'
    name = 'collection'
    version = '1.0.0'
    download_url = 'https://galaxy.ansible.com/api/v2/collections/johndoe/collection/versions/1.0.0/download/'
    artifact_sha256 = '6d1d2393c8e6d2e7f3d6acb0f8eac39a9a7b04cf6edb5453a8f6a29e7e83c350'
    dependencies = {'nginx': '1.0.0'}

    coll_meta = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert coll_meta is not None



# Generated at 2022-06-20 14:44:13.329863
# Unit test for function g_connect
def test_g_connect():
    def test_method(self, *args, **kwargs):
        return ("test_method", args, kwargs)
    wrapped = g_connect(['v1', 'v2'])(test_method)
    res = wrapped("a", "b", c="c")
    assert res == ("test_method", ("a", "b"), {"c": "c"})
test_g_connect()

