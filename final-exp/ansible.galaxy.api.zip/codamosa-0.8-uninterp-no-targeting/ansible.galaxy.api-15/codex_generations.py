

# Generated at 2022-06-20 14:36:58.949100
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    g = GalaxyAPI.from_server('https://galaxy.example.org', token='XXXXX')
    expected = "GalaxyAPI(name='default', server='https://galaxy.example.org', api_server='https://galaxy.example.org/api', token=****)"
    actual = repr(g)
    assert expected == actual



# Generated at 2022-06-20 14:37:04.587041
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace = 'test_namespace'
    name = 'test_name'
    version = 'test_version'
    download_url = 'test_download_url'
    artifact_sha256 = 'test_artifact_sha256'
    dependencies = {'namespace1/name1': '1.0.0'}

    cvm = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)

    assert cvm.namespace == namespace
    assert cvm.name == name
    assert cvm.version == version
    assert cvm.download_url == download_url
    assert cvm.artifact_sha256 == artifact_sha256
    assert cvm.dependencies == dependencies



# Generated at 2022-06-20 14:37:09.806102
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    # the following line, if uncommented and run, should output
    # "(HTTP Code: 404, Message: Unknown Code: Unknown)"
    #GalaxyError(HTTPError(url='url', code=404, msg='msg', hdrs='hdrs', fp='fp'), message='message')

    # for testing, we'll instead use the following
    he1 = HTTPError('url', 404, 'msg', 'hdrs', 'fp')
    assert str(GalaxyError(http_error=he1, message='message')) == \
           '(HTTP Code: 404, Message: msg Code: Unknown)'



# Generated at 2022-06-20 14:37:12.855841
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    galaxyError = GalaxyError('http_error', 'msg')
    assert galaxyError.message == 'msg (HTTP Code: None, Message: None)'
    assert galaxyError.http_code == 'http_error'



# Generated at 2022-06-20 14:37:27.832120
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    with pytest.raises(TypeError):
        # Invalid constructor call: TypeError expected
        # noinspection PyTypeChecker
        CollectionMetadata()
    with pytest.raises(TypeError):
        # Invalid constructor call: TypeError expected
        # noinspection PyTypeChecker
        CollectionMetadata('a', 'b', 'c')
    with pytest.raises(ValueError):
        # Invalid constructor call: ValueError expected
        CollectionMetadata('a', 'b', created_str='')
    with pytest.raises(ValueError):
        # Invalid constructor call: ValueError expected
        CollectionMetadata('a', 'b', created_str='9293943')

# Generated at 2022-06-20 14:37:29.675060
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI()
    assert str(api) == 'GalaxyAPI()'

# Generated at 2022-06-20 14:37:40.218260
# Unit test for function g_connect
def test_g_connect():
    class GalaxyConnection:
        def __init__(self):
            self.name = 'testing'
            self.api_server = 'https://galaxy.ansible.com'
            self._available_api_versions = {}
            self._required_api_versions = {'v1'}
            self.token = ''
            self.validate_certs = False

        def _call_galaxy(self, url, method, error_context_msg, cache):
            assert url.startswith('https://galaxy.ansible.com/api/')
            assert self._available_api_versions == {'v1', 'v2'}
            return {'available_versions': {'v1': 'v1'}}

    c = GalaxyConnection()

# Generated at 2022-06-20 14:37:46.341107
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.galaxy.api import GalaxyAPI
    from ansible.galaxy.api import GalaxyError

    class TestGalaxyAPI___lt__():

        def test_galaxy_api_1(self):
            # Constructing the object
            galaxy_api_1 = GalaxyAPI(name='test', api_server='test', timeout=0, keepalive=False,
                                     validate_certs=False, **{})
            galaxy_api_1.available_api_versions = {'v2': 'v2', 'v3': 'v3'}

            galaxy_api_2 = GalaxyAPI(name='test', api_server='test', timeout=0, keepalive=False,
                                     validate_certs=False, **{})

# Generated at 2022-06-20 14:37:57.190224
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    import sys
    import collections
    sys.modules['ansible.module_utils.galaxy_api'] = collections.namedtuple('Placeholder', ['server'])(server='https://galaxy.com')

    example_yaml = '''
        name: Galaxy API
        server: https://galaxy.ansible.com
        api_server: https://galaxy.ansible.com/api
        ignore_certs: True
        ignore_certs_set: True
        ignore_certs: True
        ignore_certs_set: True
        valid_versions:
          v2: /api/v2/
          v3: /api/automation-hub/
        available_api_versions:
          v2: /api/v2/
          v3: /api/automation-hub/
    '''
   

# Generated at 2022-06-20 14:38:08.940557
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy = GalaxyAPI()
    assert galaxy.api_server is None
    assert galaxy.name is None
    assert galaxy.token is None
    assert galaxy.token_url is None
    assert galaxy.ssl_verify is True
    assert galaxy.api_key is None
    assert galaxy.available_api_versions == {}

    galaxy = GalaxyAPI('server')
    assert galaxy.api_server == 'server'
    assert galaxy.name is None
    assert galaxy.token is None
    assert galaxy.token_url is None
    assert galaxy.ssl_verify is True
    assert galaxy.api_key is None
    assert galaxy.available_api_versions == {}



# Generated at 2022-06-20 14:38:39.986867
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    http_error = "HTTP Code: 400, Message: Not Found Code: 404"
    message = "Detail about the error"
    test_galaxy_error = GalaxyError(http_error, message)
    assert test_galaxy_error.message == "HTTP Code: 400, Message: Not Found Code: 404 Detail about the error"



# Generated at 2022-06-20 14:38:41.430884
# Unit test for function cache_lock
def test_cache_lock():
    with _CACHE_LOCK:
        pass



# Generated at 2022-06-20 14:38:43.533596
# Unit test for function cache_lock
def test_cache_lock():
    with _CACHE_LOCK:
        display.debug('May not call in parallel')
        assert True


# Generated at 2022-06-20 14:38:47.881254
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    """test __unicode__ method"""
    # test
    assert GalaxyAPI.__init__()


# Generated at 2022-06-20 14:38:53.866204
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    assert GalaxyAPI('ansible', 'https://galaxy.ansible.com').api_server == 'https://galaxy.ansible.com'

# Generated at 2022-06-20 14:39:04.278252
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():

    # No optional arguments
    collection_metadata = CollectionMetadata('namespace', 'name')
    assert collection_metadata.namespace == 'namespace'
    assert collection_metadata.name == 'name'
    assert collection_metadata.created_str is None
    assert collection_metadata.modified_str is None

    # Providing optional arguments
    collection_metadata = CollectionMetadata('namespace', 'name', 'created_str', 'modified_str')
    assert collection_metadata.namespace == 'namespace'
    assert collection_metadata.name == 'name'
    assert collection_metadata.created_str == 'created_str'
    assert collection_metadata.modified_str == 'modified_str'


# Generated at 2022-06-20 14:39:14.952622
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    # Tests the following methods:
    # * __init__
    # * __repr__

    # Create an instance of TLSv1.2 and assert that the correct API version is assigned
    galaxy_api = GalaxyAPI('https://galaxy.ansible.com', urlopen_kwargs={'context': ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)})
    assert galaxy_api.api_server == 'https://galaxy.ansible.com'
    assert galaxy_api.verify_ssl is True
    assert galaxy_api.urlopen_kwargs['context'].protocol == ssl.PROTOCOL_TLSv1_2
    assert galaxy_api.name == 'Galaxy'
    assert 'v2' in galaxy_api.available_api_versions
    assert 'v3' in galaxy

# Generated at 2022-06-20 14:39:19.450706
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    session = Mock()
    session.server_list = []

    galaxy = GalaxyAPI(session, 'ansible.galaxy')
    assert repr(galaxy) == "GalaxyAPI(name='ansible.galaxy', api_server='https://galaxy.ansible.com')"



# Generated at 2022-06-20 14:39:20.931806
# Unit test for function cache_lock
def test_cache_lock():
    with _CACHE_LOCK:
        print("test_cache_lock")



# Generated at 2022-06-20 14:39:29.778223
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id(url='https://galaxy.redhat.com/') == 'galaxy.redhat.com'
    assert get_cache_id(url='https://galaxy.redhat.com:8080/') == 'galaxy.redhat.com:8080'
    assert get_cache_id(url='https://galaxy.redhat.com:443/') == 'galaxy.redhat.com'
    assert get_cache_id(url='https://galaxy.redhat.com:443/') == 'galaxy.redhat.com'
    assert get_cache_id(url='https://galaxy.redhat.com:443/api/') == 'galaxy.redhat.com'
    assert get_cache_id(url='https://galaxy.redhat.com:80/api/')

# Generated at 2022-06-20 14:40:09.462861
# Unit test for function g_connect
def test_g_connect():
    # call g_connect directly to avoid calling Galaxy.__init__()
    # as it will look for an auth token and fail.
    def test_method(self):
        return 'hello world'
    g_connect([1])(test_method)(None)


# Generated at 2022-06-20 14:40:20.048233
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():

    # Test GalaxyAPI object.
    test_object=GalaxyAPI(server="https://galaxy.ansible.com",
                          validate_certs=True,
                          token="token",
                          ignore_certs=True,
                          force=True)

    # Test expected return of __repr__ with token.
    test_expected_repr_with_token = "<GalaxyAPI(server='https://galaxy.ansible.com', token='visible', ignore_certs=True, force=True, timeout=10)>"
    test_result = test_object.__repr__()
    assert test_expected_repr_with_token == test_result

    # Test expected return of __repr__ without token.
    test_object.token = False

# Generated at 2022-06-20 14:40:23.220170
# Unit test for function cache_lock
def test_cache_lock():

    def wrapped2(a, b=None):
        pass

    wrapped = cache_lock(wrapped2)
    assert wrapped([1, 2]) == wrapped2([1, 2])



# Generated at 2022-06-20 14:40:35.422502
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """
    Test the constructor of class GalaxyAPI
    """
    display.display('Testing GalaxyAPI constructor')

    api = GalaxyAPI(url='https://galaxy.ansible.com', token='fake_token')

    assert api is not None and api.api_server == 'https://galaxy.ansible.com' and api.api_token == 'fake_token' and api.downloaded_collections == [] and api.available_api_versions == {} and api.name == 'https://galaxy.ansible.com'

    api = GalaxyAPI(url='https://galaxy.ansible.com', token='fake_token', ignore_certs=True)

    assert api is not None and api.api_server == 'https://galaxy.ansible.com' and api.api_token == 'fake_token' and api.downloaded_col

# Generated at 2022-06-20 14:40:45.008252
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    """Test __lt__ of module ansible_galaxy.galaxy_api"""
    api_server = 'https://galaxy.ansible.com'
    galaxy = GalaxyAPI(api_server, verify=True, cache=None)
    assert(galaxy.api_server == 'https://galaxy.ansible.com')
    assert(galaxy.verify == True)
    assert(galaxy.cache == None)
    other = GalaxyAPI('https://galaxy.ansible.com', verify=True, cache=None)
    result = galaxy.__lt__(other)
    assert(result == False)
    other = GalaxyAPI('https://test.test', verify=True, cache=None)
    result = galaxy.__lt__(other)
    assert(result == False)

# Generated at 2022-06-20 14:40:53.674927
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    test_CollectionVersionMetadata = CollectionVersionMetadata('namespace', 'name', 'version', 'download_url', 'artifact_sha256', {})
    assert test_CollectionVersionMetadata.namespace == 'namespace'
    assert test_CollectionVersionMetadata.name == 'name'
    assert test_CollectionVersionMetadata.version == 'version'
    assert test_CollectionVersionMetadata.download_url == 'download_url'
    assert test_CollectionVersionMetadata.artifact_sha256 == 'artifact_sha256'
    assert test_CollectionVersionMetadata.dependencies == {}


# Generated at 2022-06-20 14:41:07.775368
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection_name = 'awx'
    namespace = 'ansible'
    created_str = '2019-12-01T18:48:38.411Z'
    modified_str = '2019-12-01T18:48:38.411Z'
    collection_metadata = CollectionMetadata(namespace, collection_name, created_str, modified_str)
    assert isinstance(collection_metadata, CollectionMetadata)
    assert collection_metadata.name == collection_name
    assert collection_metadata.namespace == namespace
    assert collection_metadata.created_str == created_str
    assert collection_metadata.modified_str == modified_str

# Generated at 2022-06-20 14:41:19.844469
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    data_str = """
    {
        "default": "Uh oh!",
        "message": "a message.",
        "code": "an error code",
        "errors": [
            {
                "detail": "foo"
            },
            {
                "title": "bar"
            },
            {
                "code": "baz"
            }
        ]
    }
    """
    data = json.loads(data_str)
    http_error = HTTPError('http://galaxy.ansible.com/api/', 500, 'Internal Server Error', None, None)
    http_error.read = lambda: data
    msg = "some message"
    galaxy_error = GalaxyError(http_error, msg)

    assert galaxy_error.url == http_error.geturl()
    assert galaxy_error.http_

# Generated at 2022-06-20 14:41:24.805194
# Unit test for function cache_lock
def test_cache_lock():
    # this is a test that tests nothing except that we can call the function without getting AttributeError: can't set attribute
    cache_lock(display.warning)

# TODO: make a StreamingJSONParser object/class which can be re-used elsewhere in Ansible

# Generated at 2022-06-20 14:41:25.446038
# Unit test for function g_connect
def test_g_connect():
    pass



# Generated at 2022-06-20 14:42:13.376510
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    class test_GalaxyError(GalaxyError):
        def __init__(self, http_code):
            self.http_code = http_code
    assert is_rate_limit_exception(test_GalaxyError(403)) == False
    assert is_rate_limit_exception(test_GalaxyError(429)) == True
    assert is_rate_limit_exception(test_GalaxyError(520)) == True
    assert is_rate_limit_exception(Exception()) == False

retry_with_delay = functools.partial(retry_with_delays_and_condition, delay_function=generate_jittered_backoff(1, 10), retry_condition=is_rate_limit_exception)



# Generated at 2022-06-20 14:42:17.700983
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    from ansible.galaxy.api import GalaxyAPI
    from ansible.galaxy.api import DEFAULT_EXPIRY
    from ansible.galaxy.api import DEFAULT_SERVER
    ga = GalaxyAPI('username', 'password', 'email', 'client_id', 'client_secret', 1, 2, 'display_name', 'api_server', 'token', 1, 1, 'cert', [], 2, 3)
    assert repr(ga) == '<GalaxyAPI username@api_server (1/2 remaining)>'



# Generated at 2022-06-20 14:42:21.102647
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    CollectionMetadata(namespace="bob", name="test_collection",
                       created_str="Wed, 23 Oct 2019 17:40:16 GMT", modified_str="Wed, 23 Oct 2019 17:40:16 GMT")

# Generated at 2022-06-20 14:42:31.096372
# Unit test for function get_cache_id
def test_get_cache_id():
    """ Unit test for get_cache_id(). """
    assert get_cache_id('http://example.com:12345') == 'example.com:12345'
    assert get_cache_id('http://example.com:12345/foo') == 'example.com:12345'
    assert get_cache_id('http://user:password@example.com:12345/foo') == 'example.com:12345'
    assert get_cache_id('http://user:password@example.com') == 'example.com:None'



# Generated at 2022-06-20 14:42:39.126788
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    gapi = GalaxyAPI(server="https://galaxy.ansible.com",
                     ignore_certs=False, validate_certs=False,
                     auth_url=None, api_server=None, client_id=None,
                     access_token=None)
    assert gapi.__repr__() == "GalaxyAPI('galaxy.ansible.com')"

# Generated at 2022-06-20 14:42:45.936358
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api = GalaxyAPI("localhost:8080")
    assert "GalaxyAPI(name='localhost', api_server='http://localhost:8080')" == str(api)


# Generated at 2022-06-20 14:42:54.410057
# Unit test for function get_cache_id

# Generated at 2022-06-20 14:42:58.997077
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
  api_server = '213.32.6.8'
  name = 'universe'
  token = 'abcde'
  api = GalaxyAPI(api_server, name, token)
  assert 'GalaxyAPI(api_server=213.32.6.8, name=universe)' == repr(api)

# Generated at 2022-06-20 14:43:10.418724
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    """
    Test GalaxyAPI.__unicode__()

    Test the __unicode__ method of the GalaxyAPI class.
    """
    print('Test GalaxyAPI.__unicode__()')

    test_galaxy_api_obj = GalaxyAPI('t.c.com', 'my-name')

    test_galaxy_api_obj.api_token = 'my-token'
    if test_galaxy_api_obj.__unicode__() != '<GalaxyAPI(t.c.com) name=my-name token=my-token>':
        raise AssertionError('test_GalaxyAPI___unicode__ 1 Failed')

    test_galaxy_api_obj.api_token = ''

# Generated at 2022-06-20 14:43:21.458959
# Unit test for function g_connect
def test_g_connect():
    import collections
    import datetime
    import functools
    import hashlib
    import json
    import os
    import stat
    import tarfile
    import time
    import threading
    from ansible.module_utils.api import retry_with_delays_and_condition
    from ansible.module_utils.api import generate_jittered_backoff
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.parse import quote as urlquote, urlencode, urlparse, parse_qs, urljoin
    from ansible.module_utils._text import to_bytes, to_native, to_text

# Generated at 2022-06-20 14:44:03.841212
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    error = HTTPError('http://test.com/test/test.json', 404, 'Not Found', {}, None)
    message = 'Unable to retrieve content_type for test_collection due to a Galaxy server error.'
    exception = GalaxyError(error, message)
    assert exception.http_code == 404
    assert exception.url == 'http://test.com/test/test.json'
    assert exception.message == 'Unable to retrieve content_type for test_collection due to a Galaxy server error. (HTTP Code: 404, Message: Not Found)'

    url = 'http://test.com/api/v2/test/test.json'
    error = HTTPError(url, 404, 'Not Found', {}, None)
    message = 'Unable to retrieve content_type for test_collection due to a Galaxy server error.'
    exception = GalaxyError

# Generated at 2022-06-20 14:44:07.702302
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    from ansible.module_utils.ansible_galaxy import GalaxyAPI

    g_api = GalaxyAPI('http://foo.example.com/')
    assert g_api < 'bar'



# Generated at 2022-06-20 14:44:16.234659
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    """
    Function to test constructor of class CollectionMetadata
    """
    collection_metadata = CollectionMetadata("namespace", "name", created_str="2020-09-24T04:52:03.365341",
                                             modified_str="2020-09-24T04:52:03.365341")
    assert collection_metadata.created_str == "2020-09-24T04:52:03.365341"
    assert collection_metadata.modified_str == "2020-09-24T04:52:03.365341"
    assert collection_metadata.created == datetime.date(2020, 9, 24)
    assert collection_metadata.modified == datetime.date(2020, 9, 24)


# Generated at 2022-06-20 14:44:25.968061
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    collection_metadata = CollectionMetadata("namespace", "name", "version")
    assert collection_metadata.namespace == "namespace"
    assert collection_metadata.name == "name"
    assert collection_metadata.version == "version"
    assert collection_metadata.namespace == collection_metadata.__dict__['namespace']
    assert collection_metadata.name == collection_metadata.__dict__['name']
    assert collection_metadata.version == collection_metadata.__dict__['version']
    assert len(collection_metadata.__dict__) == 3


# Generated at 2022-06-20 14:44:37.081897
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    # Initializes a new instance of the class.
    cm = CollectionMetadata('test-namespace', 'test-name', 'test-version', 'test-author', 'test-author-email',
                            'test-description', 'test-readme', 'test-license',  'test-min_ansible_version',
                            created_str='test-created-at-str', modified_str='test-modified-at-str')
    cm2 = CollectionMetadata('test-namespace', 'test-name', 'test-version', 'test-author', 'test-author-email',
                            'test-description', 'test-readme', 'test-license',  'test-min_ansible_version')

    assert cm.namespace == 'test-namespace'
    assert cm.name == 'test-name'
    assert cm

# Generated at 2022-06-20 14:44:41.503909
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_api = GalaxyAPI('test-galaxy-server')
    assert str(galaxy_api) == "GalaxyAPI('test-galaxy-server')"

# Generated at 2022-06-20 14:44:44.898057
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    res = GalaxyAPI(None, name='test',
                    auth_url=None, api_server='http://galaxy.ansible.com')
    assert isinstance(res.__unicode__(), str)



# Generated at 2022-06-20 14:44:50.786260
# Unit test for function get_cache_id
def test_get_cache_id():
    # GIVEN: An URL
    url = 'https://cloud.redhat.com/api/automation-hub/'
    # WHEN: The URL cache ID is computed
    cache_id = get_cache_id(url)
    # THEN: It should be what we expect
    assert cache_id == 'cloud.redhat.com:443'



# Generated at 2022-06-20 14:44:58.927658
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    """Tests the constructor of the GalaxyAPI class."""
    # Empty constructor
    api1 = GalaxyAPI()
    assert api1.name == 'unnamed_server'
    assert api1.api_server == 'https://galaxy.ansible.com'
    assert not api1.ignore_certs
    assert api1.available_api_versions['v2'] == '/api/v2'
    assert 'v3' not in api1.available_api_versions

    # Constructor with name
    api2 = GalaxyAPI('test')
    assert api2.name == 'test'

    # Constructor with name, API server, and ignore certs
    api3 = GalaxyAPI('test', 'https://test.galaxy.ansible.com', True)
    assert api3.name == 'test'

# Generated at 2022-06-20 14:45:03.622466
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    fixture = {
        'name': 'Tower',
        'api_server': 'https://galaxy.ansible.com',
        'token': 'secret',
        'ignore_certs': True,
    }

    g = GalaxyAPI(**fixture)
    assert g.name == fixture['name']
    assert g.api_server == fixture['api_server']
    assert g.token == fixture['token']
    assert g.ignore_certs == fixture['ignore_certs']
    assert g.session

