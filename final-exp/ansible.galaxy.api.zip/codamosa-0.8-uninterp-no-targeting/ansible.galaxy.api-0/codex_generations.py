

# Generated at 2022-06-20 14:37:05.849635
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():

    # Access private method
    m = GalaxyAPI('https://galaxy.server/api')
    m._available_api_versions = {'v2': 'https://galaxy.server/api/v2', 'v3': 'https://galaxy.server/api/v3'}
    m._authenticated = True
    m._api_key = '123456'

    # Test with all available api versions
    assert m.__repr__() == "GalaxyAPI(server='https://galaxy.server/api', api_versions=['v2', 'v3'], authenticated=True)"

    # Test without authenticated
    m._authenticated = False

    # Test with all available api versions

# Generated at 2022-06-20 14:37:11.638043
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    mock_name = 'ansible.builtin'
    mock_namespace = 'ansible_namespace'
    mock_time = '2020-06-25T20:28:14.597152Z'
    mock_download_url = 'https://galaxy.ansible.com/api/collections/ansible_namespace/ansible.builtin/1.0.0/download/'
    mock_sha256 = '1234'

    # CollectionMetadata created with a download url
    metadata = CollectionMetadata(mock_namespace, mock_name, mock_time, mock_time, mock_download_url)
    assert metadata.name == mock_name
    assert metadata.namespace == mock_namespace
    assert metadata.created_str == mock_time
    assert metadata.modified_str == mock_time

# Generated at 2022-06-20 14:37:24.931159
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    namespace = 'unit-test-namespace'
    name = 'unit-test-name'
    api_server = 'https://galaxy.ansible.com/'
    token = 'Zm9v'
    verify_ssl = True

    galaxy = GalaxyAPI(api_server=api_server, token=token, private=False, verify_ssl=verify_ssl)
    assert galaxy.api_server == api_server
    assert galaxy.token == token
    assert galaxy.verify_ssl == verify_ssl

    galaxy = GalaxyAPI(api_server=api_server, token=token)
    assert galaxy.api_server == api_server
    assert galaxy.token == token
    assert galaxy.verify_ssl is True

    galaxy = GalaxyAPI(api_server=api_server)
    assert galaxy.api_server == api_server

# Generated at 2022-06-20 14:37:36.994266
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    mock_config = Mock()
    mock_config.server = 'https://api.galaxy.ansible.com'
    mock_config.ignore_certs = True
    mock_config.ignore_ssl_errors = True
    mock_config.token = None
    # Test with valid token and 'ignore_ssl_errors'
    api = GalaxyAPI(mock_config)
    assert to_native(api) == "GalaxyAPI ('https://api.galaxy.ansible.com') ignore_ssl=True ignore_ssl_errors=True"
    # Test with 'ignore_ssl_errors'
    api = GalaxyAPI(mock_config)
    api.token = 'abc123'

# Generated at 2022-06-20 14:37:43.509986
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    api_server = 'https://galaxy.ansible.com'
    token = 'the_super_secret_token_to_be_shown_in_display_only'
    galaxy_api_mock = GalaxyAPI(api_server, token, skip_cert_verify=False, validate_certs=True, ignore_certs=False, force_basic_auth=False, client_cert=None,
                                log_path=None, log_debug=False, log_verbose=False)
    assert str(galaxy_api_mock) == 'GalaxyAPI(name: None, server: https://galaxy.ansible.com, token: None)'
    galaxy_api_mock.name = 'Galaxy-server'

# Generated at 2022-06-20 14:37:50.853805
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    server_config = dict(
        name='galaxy',
        api_server='https://galaxy.server',
        ignore_certs=False,
    )
    gal = GalaxyAPI(**server_config)
    assert gal.name == 'galaxy'
    assert gal.api_server == 'https://galaxy.server'
    assert gal.ignore_certs is False

    server_config = dict(
        name='galaxy2',
        api_server='https://galaxy.server/api',
        ignore_certs=True,
    )
    gal = GalaxyAPI(**server_config)
    assert gal.name == 'galaxy2'
    assert gal.api_server == 'https://galaxy.server/api'
    assert gal.ignore_certs is True

    # Note, the constructor is protected by @g

# Generated at 2022-06-20 14:37:56.776773
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    gapi = GalaxyAPI("Galaxy", "https://api.galaxy.ansible.com/")
    result = repr(gapi)
    assert repr(gapi) == repr("Galaxy <https://api.galaxy.ansible.com/>")


# Generated at 2022-06-20 14:38:01.480645
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy = GalaxyAPI("galaxy_server.name")
    assert galaxy
    assert galaxy.name == "galaxy_server.name"
    assert galaxy.available_api_versions == dict()



# Generated at 2022-06-20 14:38:07.413478
# Unit test for function is_rate_limit_exception
def test_is_rate_limit_exception():
    # Using Python 2.7's unittest.mock.call to prevent hardcoding the error code.
    from unittest.mock import call
    g = GalaxyError(message='Too Many Requests', http_code=429)
    assert is_rate_limit_exception(g)
    assert not isinstance(g, HTTPError)



# Generated at 2022-06-20 14:38:15.960312
# Unit test for function get_cache_id
def test_get_cache_id():
    test_cache_id = get_cache_id('https://galaxy.ansible.com/api/')
    assert test_cache_id == 'galaxy.ansible.com:'
    test_cache_id = get_cache_id('https://galaxy.ansible.com:443/api/')
    assert test_cache_id == 'galaxy.ansible.com:443'
    test_cache_id = get_cache_id('https://galaxy.ansible.com/test/')
    assert test_cache_id == 'galaxy.ansible.com:'



# Generated at 2022-06-20 14:38:57.468911
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    cm = CollectionMetadata('namespace', 'name', '1.2.3', 'https://example.com/api', 'http://example.com/artifact.tar.gz', 'blah')

    assert cm.namespace == 'namespace'
    assert cm.name == 'name'
    assert cm.version == '1.2.3'
    assert cm.api_server == 'https://example.com/api'
    assert cm.artifact_url == 'http://example.com/artifact.tar.gz'
    assert cm.sha256 == 'blah'


# Generated at 2022-06-20 14:39:08.777854
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    n_namespace = 'namespace'
    n_name = 'name'
    n_created = '2018-07-01T00:00:00'
    n_modified = '2018-08-01T00:00:00'

    m = CollectionMetadata(n_namespace, n_name, created_str=n_created, modified_str=n_modified)

    assert m.namespace == n_namespace
    assert m.name == n_name
    assert m.created_str == n_created
    assert m.modified_str == n_modified

    assert repr(m) == 'CollectionMetadata(namespace=%s, name=%s)' % (n_namespace, n_name)

# Generated at 2022-06-20 14:39:13.729063
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id('https://localhost') == 'localhost:'
    assert get_cache_id('https://localhost:8443') == 'localhost:8443'
    assert get_cache_id('https://localhost:8443/ansible/') == 'localhost:8443'
    assert get_cache_id('https://user:password@localhost:8443/ansible/') == 'localhost:8443'



# Generated at 2022-06-20 14:39:24.603627
# Unit test for method __lt__ of class GalaxyAPI

# Generated at 2022-06-20 14:39:30.363219
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    g = GalaxyAPI(name='test', api_server='http://localhost/')
    assert str(g) == 'test (http://localhost/)'


# Generated at 2022-06-20 14:39:38.816692
# Unit test for method __str__ of class GalaxyAPI
def test_GalaxyAPI___str__():
    galaxy_api = GalaxyAPI('https://galaxy.server.com', 'test_user')
    assert str(galaxy_api) == 'test_user@https://galaxy.server.com'
    galaxy_api = GalaxyAPI('https://galaxy.server.com', 'test_user', token='test_token')
    assert (str(galaxy_api) == 'test_user@https://galaxy.server.com')

# Generated at 2022-06-20 14:39:46.545747
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    col_meta = CollectionMetadata(namespace="ansible_namespace", name="collection_name", version="1.0.0",
                                  created_str="2020-05-08T06:00Z", modified_str="2020-05-08T06:00Z",
                                  deprecated=True, deprecated_str="2020-05-31T00:00Z", namespace_str="ansible_namespace",
                                  readme_html="<html></html>")
    assert col_meta.namespace == "ansible_namespace"
    assert col_meta.name == "collection_name"
    assert col_meta.version == "1.0.0"
    assert col_meta.created_str == "2020-05-08T06:00Z"

# Generated at 2022-06-20 14:39:54.957367
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api_server = "http://test.example.com"
    name = "test"
    username = "testuser"
    token = "testtoken"
    ignore_certs = False
    ignore_cert_errors = []
    galaxy_instance = GalaxyAPI(api_server, name, username, token, ignore_certs, ignore_cert_errors)
    result = galaxy_instance.__repr__()
    assert result == "GalaxyAPI(test@test.example.com)"

# Generated at 2022-06-20 14:40:04.356353
# Unit test for function cache_lock
def test_cache_lock():
    class TestCacheLock:
        def test(self, a, b):
            return a + b

    test_obj = TestCacheLock()

    @cache_lock
    def test_decorator(a, b):
        return test_obj.test(a,b)

    assert test_decorator(1, 1) == 2
########################################################################


GALAXY_API_URL = C.GALAXY_SERVER_LIST[0]

if C.GALAXY_SERVER_LIST:
    # We're going to default to the first server in the list and let
    # users override it with CLI args
    GALAXY_API_URL = C.GALAXY_SERVER_LIST[0]

# Used to build the Galaxy URLs that store info about the Ansible version that installed the collection
GAL

# Generated at 2022-06-20 14:40:11.960239
# Unit test for method __lt__ of class GalaxyAPI
def test_GalaxyAPI___lt__():
    galaxy = GalaxyAPI('https://galaxy.ansible.com')
    actual = galaxy < GalaxyAPI('https://galaxy.ansible.com')
    assert not actual
    actual = GalaxyAPI('https://galaxy.ansible.com/api/v1') < GalaxyAPI('https://galaxy.ansible.com/api/v2')
    assert actual
    actual = GalaxyAPI('https://galaxy.ansible.com/api/v2') < GalaxyAPI('https://galaxy.ansible.com/api/v3')
    assert actual
    actual = GalaxyAPI('https://galaxy.ansible.com/api/v2') < GalaxyAPI('https://galaxy2.ansible.com/api/v2')
    assert actual
    actual = GalaxyAPI('https://galaxy2.ansible.com/api/v2')

# Generated at 2022-06-20 14:40:42.949821
# Unit test for function cache_lock
def test_cache_lock():
    class TestClass:
        @cache_lock
        def __init__(self):
            pass

    assert isinstance(TestClass(), TestClass)



# Generated at 2022-06-20 14:40:54.042659
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api_server = "https://galaxy.ansible.com"
    name = "test"
    galaxy_api = GalaxyAPI(api_server, name)

    assert str(galaxy_api) == 'GalaxyAPI(%s, %s)' % (api_server, name)


# The format returned from a v3 pulp_ansible collection version is the following::
#
#   {
#     "data": [{
#       "type": "galaxy_collection_version_pulp_ansible_data",
#       "id": "844cec86-f668-4660-a78c-8b7a75f2f9d7",
#       "attributes": {
#         "description": "",
#         "namespace": {
#           "name": "ansible"
#         },
#

# Generated at 2022-06-20 14:41:09.468650
# Unit test for constructor of class GalaxyError
def test_GalaxyError():
    import requests
    message = "Galaxy error"
    http_code = 500
    galaxy_msg = "Galaxy message"
    error_code = 500
    http_error = requests.models.Response()
    http_error.code = http_code
    http_error.reason = http_msg = json.dumps({'message': galaxy_msg, 'code': error_code})
    http_error.geturl = lambda: ""
    http_error.read = lambda: http_msg
    error = GalaxyError(http_error, message)
    assert error.http_code == http_code
    assert error.url == ""
    assert json.loads(error.message) == {"message": message, "HTTP Code": http_code,
                                         "Message": galaxy_msg, "Code": error_code}



# Generated at 2022-06-20 14:41:13.706675
# Unit test for function cache_lock
def test_cache_lock():
    _cache_lock = threading.Lock()

    def func():
        with _cache_lock:
            pass

    func.__name__ = 'func'
    wrapped = cache_lock(func)

    assert wrapped.__name__ == 'wrapped'

    with _cache_lock:
        wrapped()



# Generated at 2022-06-20 14:41:25.556978
# Unit test for constructor of class GalaxyAPI
def test_GalaxyAPI():
    galaxy = GalaxyAPI('some_name', 'https://example.com:49321', '/path/to/api/token')
    assert galaxy.name == 'some_name'
    assert galaxy.api_server == 'https://example.com:49321'
    assert galaxy.api_token == '/path/to/api/token'
    assert galaxy._requests_session is not None
    assert len(galaxy.available_api_versions) == 2
    assert galaxy.available_api_versions.get('v2') == 'api/v2'
    assert galaxy.available_api_versions.get('v3') == 'api/v3'
    assert galaxy.CA_BUNDLE is None
    assert galaxy._cache is None

    galaxy._requests_session = None
    galaxy._prepare_http_session()
    assert galaxy._

# Generated at 2022-06-20 14:41:35.830277
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    try:
        galaxy_api = GalaxyAPI(api_server='https://galaxy.server.com',
                               name='My Galaxy',
                               client_id='CID',
                               client_secret='CS',
                               verify_ssl=True,
                               proxy_url=None,
                               access_token='TOKEN',
                               refresh_token='REFRESH_TOKEN',
                               cache=dict())
        api_name = galaxy_api.__unicode__()
    except Exception as e:
        assert False, "GalaxyAPI __unicode__() threw an exception: %s" % str(e)
    assert api_name == 'My Galaxy', "GalaxyAPI __unicode__() should have returned %s but it returned %s" % ('My Galaxy', api_name)



# Generated at 2022-06-20 14:41:49.078314
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():
    galaxy_api = GalaxyAPI()
    assert galaxy_api.api_server == GALAXY_SERVER
    assert galaxy_api.available_api_versions == {}
    assert galaxy_api.name == ""

    galaxy_api2 = GalaxyAPI(api_server="https://galaxy.example.com/api/", name="galaxy_api2")
    assert galaxy_api2.api_server == "https://galaxy.example.com/api/"
    assert galaxy_api2.available_api_versions == {}
    assert galaxy_api2.name == "galaxy_api2"

    assert u"GalaxyAPI object: api_server: https://galaxy.example.com/api/, name: galaxy_api2, available_api_versions: {}" == galaxy_api2.__unicode__()

# Generated at 2022-06-20 14:42:00.760816
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    metadata = CollectionVersionMetadata('ns_name', 'coll_name', '1.0.0', 'url', 'hash', {'collections': {}})
    assert metadata.namespace == 'ns_name'
    assert metadata.name == 'coll_name'
    assert metadata.version == '1.0.0'
    assert metadata.download_url == 'url'
    assert metadata.artifact_sha256 == 'hash'
    assert metadata.dependencies == {'collections': {}}



# Generated at 2022-06-20 14:42:11.730985
# Unit test for function get_cache_id
def test_get_cache_id():
    test_urls = {
        '':None,
        'http://example.com/url/':'example.com:',
        'https://example.com/url/':'example.com:',
        'http://example.com:9001/url/':'example.com:9001',
        'http://localhost/url/':'localhost:',
        'http://192.168.1.1/url/':'192.168.1.1:',
        'http://192.168.1.1:80/url/':'192.168.1.1:80',
        'foo':None,
        'http://':None,
        'https://':None,
        'http://x/url/':'x:',
        'gopher://example.com:9001/url/':None,
    }

# Generated at 2022-06-20 14:42:17.980204
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    galaxy_api = GalaxyAPI(name, api_server, galaxy_token)
    assert galaxy_api.__repr__() == '<GalaxyAPI name=%s, api_server=%s, token=%s>' % (galaxy_api.name, galaxy_api.api_server, galaxy_api.galaxy_token)


# Generated at 2022-06-20 14:45:32.015411
# Unit test for method __unicode__ of class GalaxyAPI
def test_GalaxyAPI___unicode__():

    display.verbosity = 3
    requests_mock.mockregistry.cleanup()

    obj = GalaxyAPI('https://galaxy.server.com')
    obj.available_api_versions = {'v2': '/api/v2', 'v3': '/api/v3'}
    unicode_str = str(obj)  # __unicode__() is called implicitly
    assert "GalaxyAPI('https://galaxy.server.com', apis=['v2', 'v3']" in unicode_str
    assert "apis=['v2', 'v3']" in unicode_str
    assert "v2='/api/v2'" in unicode_str
    assert "v3='/api/v3'" in unicode_str
    assert "auth=None" in unicode_str


# Generated at 2022-06-20 14:45:40.462560
# Unit test for function get_cache_id
def test_get_cache_id():
    assert get_cache_id("http://galaxy.ansible.com/api/") == "galaxy.ansible.com:"
    assert get_cache_id("http://galaxy.ansible.com") == "galaxy.ansible.com:"
    assert get_cache_id("http://galaxy.ansible.com:80") == "galaxy.ansible.com:80"
    assert get_cache_id("https://galaxy.ansible.com:8080/api/") == "galaxy.ansible.com:8080"
    assert get_cache_id("https://user:pass@galaxy.ansible.com:8080/api/") == "galaxy.ansible.com:8080"

# Generated at 2022-06-20 14:45:43.515426
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    api = GalaxyAPI(open('~/.ansible/galaxy_api.yml'))

    result = api.__repr__()

    assert result is not None

# Generated at 2022-06-20 14:45:52.322445
# Unit test for function cache_lock
def test_cache_lock():
    """
    Increase the state variable by 1, and return the value of state variable
    """
    state = 0
    @cache_lock
    def test_func(num):
        nonlocal state
        state += num
        return state
    # create 2 threads
    t1 = threading.Thread(target=test_func, args=(1,))
    t2 = threading.Thread(target=test_func, args=(2,))
    # start 2 threads
    t1.start()
    t2.start()
    # join 2 threads
    t1.join()
    t2.join()
    # if the state is 3, it means lock works correctly
    assert state == 3



# Generated at 2022-06-20 14:46:04.745480
# Unit test for constructor of class CollectionVersionMetadata
def test_CollectionVersionMetadata():
    namespace='coll_namespace'
    name='coll_name'
    version='1.0.0'
    download_url='http://some.galaxy.url'
    artifact_sha256='abcdefg'
    dependencies='{}'

    collection_version_metadata = CollectionVersionMetadata(namespace, name, version, download_url, artifact_sha256, dependencies)
    assert namespace == collection_version_metadata.namespace
    assert name == collection_version_metadata.name
    assert version == collection_version_metadata.version
    assert download_url == collection_version_metadata.download_url
    assert artifact_sha256 == collection_version_metadata.artifact_sha256
    assert dependencies == collection_version_metadata.dependencies


# Generated at 2022-06-20 14:46:10.565080
# Unit test for constructor of class CollectionMetadata
def test_CollectionMetadata():
    """CollectionMetadata Unit test"""
    cm = CollectionMetadata("myns", "myname")
    assert cm.namespace == "myns"
    assert cm.name == "myname"
    assert cm.created_str is None
    assert cm.modified_str is None
    assert cm.download_url is None
    assert cm.artifact is None

    assert cm.created_date() is None
    assert cm.modified_date() is None

    cm = CollectionMetadata("myns", "myname", created_str="3/1/2019", modified_str="3/2/2019", download_url="http://example.com")
    assert cm.namespace == "myns"
    assert cm.name == "myname"
    assert cm.created_str == "3/1/2019"
    assert cm.modified_str

# Generated at 2022-06-20 14:46:17.630920
# Unit test for method __repr__ of class GalaxyAPI
def test_GalaxyAPI___repr__():
    # Test with default args
    obj = GalaxyAPI()
    assert repr(obj) == "<GalaxyAPI(api_server='https://galaxy.ansible.com', name='galaxy.ansible.com')>"

    # Test with some args
    obj = GalaxyAPI(api_server='http://a', name='galaxy.ansible.com')
    assert repr(obj) == "<GalaxyAPI(api_server='http://a', name='galaxy.ansible.com')>"